# R v Nguyen [2023] EWCA Crim 1364

Court of Appeal, Criminal Division

Macur LJ, Garnham J, Steyn J

1 November 2023Judgment

MISS L BALD appeared on behalf of the Appellant

MR P ALLMAN appeared on behalf of the Crown

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

1. LADY JUSTICE MACUR: On 6 August 2021, being the first day of his trial, At Bidinh Nguyen (the
applicant) pleaded guilty to one count of producing a controlled drug of class B, namely cannabis. He was
sentenced to 58 weeks' imprisonment and ordered to pay a surcharge.

2. Two of his co‑accused pleaded guilty to conspiracy to produce controlled drugs of class B and were

sentenced to five years and three months' imprisonment and four years and one month's detention in a
young offender institution, respectively.

3. No evidence was offered against another co‑accused, Bac Van Nguyen as the prosecution was said not

to be in the public interest. Significantly, Bac Van Nguyen had been arrested at the same time and place as
the applicant. On 27 October 2020, the two men had been found in the front bedroom of a locked house
and described by a police officer as looking "very underweight and were either shivering with coldness or
fear. They spoke no English. I suspected they were victims of modern-day slavery and potentially human
trafficking."

4. Following his release from prison the applicant was held in an immigration detention centre and was
referred into the National Referral Mechanism (“NRM”) as a potential victim of **_modern slavery. He_**
received a positive 'Reasonable Grounds Decision' on 15 December 2021. On 16 November 2022 he
received a positive 'Conclusive Grounds Decision' for the period of 2019 to 2020, but this was
subsequently revoked for reconsideration of further information, namely the evidence gathered in relation
to subsequent criminal offending. On 9 January 2023, the applicant received a positive Conclusive
Grounds Decision accepting that he was a victim of modern-day slavery in Vietnam and in the United
Kingdom between the period of 2019 and 2022 for the specific purpose of forced criminality.


-----

5. The applicant took no further steps in relation to the extant conviction until making this application for an
extension of time, namely 591 days, and an application to admit fresh evidence, namely, the Single
Competent Authority (“SCA”) decision regarding his Victim of Trafficking (“VOT”) status, in support of an
application for permission to appeal.

6. In the meantime, he had been re‑arrested and charged with similar offences of production of a class B

[drug. In subsequent criminal proceedings, the section 45 Modern Slavery Act 2015 defence was raised,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
the CPS reviewed the decision to prosecute and offered no evidence against the applicant. This raised the
possibility that a similar defence, and similar result, would have been likely in 2021. Accordingly, Miss Bald,
the applicant's counsel for the 2022 offences, lodged a notice of appeal asserting that the applicant was
not advised adequately as to the availability or merit of a section 45 defence which would probably have
succeeded such that a clear injustice had been done [R v Boal [1992] QB 591] and therefore the 2021
conviction is unsafe. Further, and in the alternative, in accordance with R v AFU _[[2023] EWCA Crim 23 to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
continue with the prosecution of the applicant for the 2021 offence was an abuse of process such as to
render the conviction unsafe.

7. The applications for extension of time, admission of fresh evidence pursuant to section 23 of the
Criminal Justice Act 1968 and leave to appeal have been referred to the full court by the Registrar.

8. In paragraph 44 of Ms Bald's advice on appeal, it is recorded that:

"In instructions taken at Snaresbrook Crown Court on the 1st September 2022, the applicant explained his
reasoning for his change of plea:

He instructed that he intended to enter a not guilty plea to the offence, but having spent about 8 months in
custody, he was advised to enter a guilty plea in order to be released. He stated that he was advised that
the anticipated sentence for the offence was 12 months in which he was expected to serve 6 months that if
he entered a guilty plea he would be released. On the basis of that advice, he entered a guilty plea hoping
to be released, but he was released to immigration detention centre. He instructed that he wants to change
his plea because he did not commit the offence, but only entered a guilty plea on advice that he will be
released."

9. An endorsement uploaded onto the DCS reads as follows:

"1. I, AT DINH NGUYEN, HAVE INFORMED MY LEGAL TEAM THAT I AM NOT GUILTY OF MY
PREVIOUS CONVICTION FOR THE PRODUCTION OF CANNABIS. I WAS NOT GUILTY, I CHANGED
MY PLEA BECAUSE I WAS TOLD THAT I WOULD BE CERTAINLY BE RELEASED THAT DAY. I WAS
NOT ADVISED THAT I SHOULD NOT PLEAD GUILTY IF I AM NOT GUILTY. I WAS DESPERATE.

2. I DID NOT DO ANYTHING TO THE PLANTS I ONLY ARRIVED AT THE ADDRESS THE DAY
BEFORE.

3. I WANT TO APPEAL MY CONVICTION.

4. I HAVE BEEN ADVISED THAT THIS WILL MEAN I WILL NEED TO WAIVE LEGAL PRIVILEGE,
THEREFORE ALL OF MY LEGAL FILE WILL BE DISCLOSED TO THE PROSECUTION. I GIVE MY
CONSENT FOR THIS TO HAPPEN. I UNDERSTAND THAT THIS MAY REVEAL INCONSISTENCIES IN
MY ACCOUNT BUT I THINK THAT HAS HAPPENED DUE TO INCONSISTENT TRANSLATION RATHER
THAN MY ACCOUNT.

5. I ALSO WANT TO CHALLENGE THE ADMISSIBLITY OF MY CONVICTION IN MY CURRENT TRIAL. I
CONSENT TO WAIVING MY LEGAL PRIVILEGE IN THIS MATTER TOO. I HAVE BEEN ADVISED
ABOUT MY DEFENCE OF **_MODERN SLAVERY. I WAS EXPLOITED. I DID NOT HAVE ANY OTHER_**
CHOICE. I WISH TO PLEAD NOT GUILTY TO MY CURRENT PROCEEDINGS."

10. In 2021 the applicant was represented by counsel Mr Phillip Sutton instructed by Mitchell Solicitors
who have responded to the applicant's assertions.

11. The 2021 trial solicitors state that the applicant had been advised as to the availability of the section 45
defence at t o remote conferences b t he had said that he did not ish to p t for ard the defence at trial


-----

Trial counsel stated that, although the matter had been raised as a possibility with the court at the outset of
proceedings, as is clear from a DCS entry, his instructing solicitors had confirmed that the applicant did not
wish to pursue the section 45 defence. Further, he had confirmed with the applicant via an interpreter that
he understood what modern slavery amounted to in law, but the applicant maintained his instructions as
per his defence statement, that is, he had arrived at the cannabis farm only the day before the police
gained entry to the premises and he had not been involved in any criminality. Further, Mr Sutton said that
he had advised the applicant that he should only plead guilty if he was guilty and not simply to affect his
immediate release.

12. Miss Bald has obtained the trial solicitor's case file. She notes and brings to our attention that there are
no attendance notes or endorsements to indicate that advice regarding the section 45 defence had been
tendered. Regrettably, neither is there a transcript of the court proceedings of 6 August 2021.

13. The prosecution has lodged a Respondent's Notice in which they submit:

"The Crown Prosecution Service does not seek to contest the appeal.

Subsequent to his conviction at St Albans Crown Court for the matter which is the subject of appeal, the
appellant faced a further allegation of producing cannabis which was heard at Snaresbrook Crown Court.

In relation to that later allegation, the prosecution offered no evidence following receipt of a conclusive
grounds decision. The positive decision concluded that the appellant was, on the balance of probability, a
victim of modern slavery throughout the period of his time in UK.

Whilst there are some evidential differences between both allegations, the prosecution do not believe it
would be just or indeed proper to contest the appeal in light of that later decision."

Discussion

14. It is notable that the applicant does not expressly state that he was not advised as to the modern-day
slavery defence, and we regard it as unlikely that he was not. However, we are uncertain as to the nature
of the advice tendered to him and note that on several occasions no interpreter was available at court.
Nevertheless, we are not persuaded that the applicant received no or erroneous advice on the issue.

15. We regard it as more probable than not that the applicant was influenced in his change of plea by the
indication that the likely sentence would result in his imminent release from custody. We therefore reject
the first ground of appeal.

16. We bear in mind that this court should be cautious when overturning convictions following a guilty plea:

"The defendant having made a formal admission in open court that they are guilty of the offence will not
normally be permitted to change their mind. The trial process is not to be treated as a tactical game." (See
_R v Asiedu_ _[[2014] EWCA Crim 567.)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-N401-F0JY-C1S4-00000-00&context=1519360)_

17. However, the sole responsibility of the Court of Appeal is to determine whether the conviction is
unsafe: see R v AFU _[[2023] EWCA Crim 23 at paragraph 91. One reason why a guilty plea may be vitiated](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
may occur where there is a legal obstacle to the defendant being tried. That will be the case where the
prosecution would be stayed on the grounds that it was offensive to justice to bring the defendant to trial:
see _Asiedu at paragraph 21, as summarised in_ _R v Tredget_ _[[2022] EWCA Crim 108; also,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_ _R v Togher_

[2000] EWCA Crim 111.

18. As we indicate above, the circumstances in which the applicant was found on 27 October 2020 caused
the arresting officer to consider that he could be a VOT. This has subsequently been confirmed by the
SCA's Positive grounds finding.

19. A conclusive Positive grounds finding is inadmissible at trial but is admissible for the purpose of an
application for permission to appeal and the substantive appeal hearing assuming it is necessary and
expedient to receive such evidence: see R v AGM [2021] EWCA Crim 920 at paragraph 43, confirming R v
_Brecani_ _[2021] EWCA Crim 731._


-----

20. The Court of Appeal is not bound to accept the substance of a conclusive Positive grounds finding:

see R v AAJ _[[2021] EWCA Crim 1278 at paragraph 39, sub‑paragraph (7). However, we find no basis upon](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_

which to reject the SCA's finding. We are satisfied of the sufficiency of the inquiry made and the integrity of
the decision reached.

21. In any event, the difference in the CPS position in relation to the prosecution of the applicant's

co‑defendant, Bac Van Nguyen, whose circumstances mirrored those of the applicant in significant

respects, does raise an objective unease about the applicant's 2021 conviction. Mr Allman, who appears
on behalf of the respondent prosecution, was not counsel at the time the applicant entered his plea in

August 2021 and when no evidence was offered against his co‑accused and does not know why that

decision was made, save possibly that there was forensic evidence which linked the applicant with the
cannabis drugs being farmed. That aside, Mr Allman candidly concedes that there was no reason
objectively to distinguish between them as possible VOTs.

22. Further, Mr Allman concedes that there was no follow‑up of the arresting officer's suspicions in terms

of a referral of either the applicant or his co-accused to the NRM, contrary to CPS guidance. We note, in
fact, that not only did a NRM referral not take place but there were applications in 2021 to extend custody
time limits to accommodate the applicant's trial.

23. Unfortunately, the circumstances in the applicant's case have a depressing chime with the facts in R v
_AFU. As with that case, we find that "a far more obvious platform for a successful appeal" is by reason of_
the abuse of process so called. The relevant CPS guidance on procedure in the case of a possible VOT
defendant was not followed.

24. The exigencies of Covid restrictions upon trial no doubt played their part, but this deficit in
consideration of the applicant's position in 2020/21 and absent good reason why he was treated differently

to his co‑defendant, and the subsequent CPS decision to offer no evidence in 2022 upon receipt of the

SCA's Positive Grounds leads us to conclude that the applicant should not be held to his plea. Further, it
appears to us to be almost inevitable that, if a referral had been made at the appropriate time resulting in
the decision which is now available, the prosecution would not have proceeded to trial, alternatively, that
the section 45 defence would have succeeded.

25. Consequently, we grant leave to make the application for leave to appeal out of time, we admit the
fresh evidence, namely the minutes and letters of decision of positive grounds of finding from the SCA, we
grant permission to appeal, and we quash the conviction.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

