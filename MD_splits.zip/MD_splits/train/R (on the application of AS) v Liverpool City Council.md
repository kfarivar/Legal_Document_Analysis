# R (on the application of AS) v Liverpool City Council [2020] EWHC 3531
 (Admin)

Queen's Bench Division, Administrative Court (London)

Nicol J

21 December 2020Judgment

**Vijay Jagadesham (instructed by Greater Manchester Immigration Aid unit) for the Claimant**

**Michael Paget (instructed by Liverpool Legal Services) for the Defendant**

Hearing dates: 17th December 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Nicol:**

1. In these proceedings for judicial review the Claimant wishes to challenge the age assessment
conducted on behalf of Liverpool City Council on 23rd November 2020 (and communicated to the Claimant
on 24th November 2020) which found him not to have the claimed date of birth of 1st January 2003, but
instead to have an age of 20 years or older. The Claim Form was issued on 11th December 2020.

2. In these proceedings, the Claimant has sought interim relief. He seeks an order that the Defendant
should continue to accommodate and support him as a child in its care.

3. On 11th December 2020 Stacey J. refused the application for interim relief on the papers. The Claimant
renewed the application at an oral hearing before me on 17th December 2020.

4. The Claimant is a national of Sierra Leone. He says that he left his home country in 2015. He travelled
through Italy and Germany, among other countries. He arrived in the UK in 2019. He lived for a time in
London and then moved to the north. He has been in the care of Liverpool City Council since 2019. In the
course of his journey to the UK, the Claimant alleges that he was trafficked and subjected to physical and
sexual abuse. He asked about claiming asylum while he was in Germany. I do not know the outcome of
either application. He has now claimed asylum in the UK.

5. Although at one stage the Defendant accepted that he was a child (on 11th March 2020 with effect from
27th September 2019), the more recent decision was, as I have said, that he was aged 20 or over. The
assessment was conducted on behalf of the Defendant by Jonathon Rogers and Louisa Humphrey
(although the Claimant notes that only Mr Rogers signed the assessment and the Model Information
Sharing Proforma).

6. On the Claimant's behalf Mr Jagadesham makes many criticisms of the assessment. However, if the
application for judicial review continues, the issue will be, not whether there is a conventional error of law in
the Defendant's decision, but whether in fact the Claimant was a child at the time of the assessment. This
is because R (A) v London Borough of Croydon [2009] 1 WLR 2557establishes that if he was then a child,
he would have been entitled to the consequences that follow from that status.


-----

7. It will be seen that, even on the Claimant's case, he will turn 18 on 1st January 2021. However, Mr
Paget, for the Defendant accepted that that did not make the application for judicial review moot. That is
[because, by Children Act 1989 s.23C, even once a child in care becomes an adult, he or she continues to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C3JF-00000-00&context=1519360)
be owed certain duties by the local authority as a former relevant child. The nature of the duties are
different, though, and Mr Paget did rely on the short period before the Claimant becomes an adult as one
of the relevant factors if the balance of convenience is reached.

8. The parties also agreed that my task was to make my own decision on the application for interim relief.
Stacey J. had, as I have said, refused the application on the papers but, while proper respect would be
paid to her decision, for the Claimant to succeed it was not necessary for me to find that her decision was
wrong.

9. There was a difference between the parties as to whether it was necessary for the Claimant to show a
strong prima facie case for relief, rather than simply a triable issue before the Court considered the balance
of convenience: Mr Paget submitted that it was; Mr Jagadesham submitted that it was not.

10. Mr Paget's argument had essentially two limbs: first he submitted that in public law matters, as the
Administrative Court Judicial Review Guide said, the Court would normally consider whether there was a
strong prima facie case before displacing the decision of the public authority and granting interim relief. His
second argument was that the Claimant was here seeking a mandatory injunction and the court would
expect a higher prospect of success than a triable issue before requiring the defendant to take positive
steps.

11. As to Mr Paget's first argument, Mr Jagadesham submitted that the position was more nuanced. There
were some contexts where the Court did not insist on a strong prima facie case. Where for instance there
was an arguable case that an immigration removal would conflict with the European Convention on Human
Rights Articles 2 or 3, the Court would look at the balance of convenience if there was a triable issue – see
_R (SB Afghanistan) v Secretary of State for the Home Department_ _[2018] EWCA Civ 215 at [78]. Context_
was everything. Here the context was that the court would have to decide for itself if the Claimant was a
child when the assessment was completed.

12. As for Mr Paget's second argument, Mr Jagadesham submitted that the dichotomy between
prohibitory and mandatory injunctions had been disapproved by Lord Hoffman in _National Commercial_
_Bank Ltd v Olint Corporation [2009] UKPC 16, [2009] 1 WLR 1405PC following his own decision at first_
instance in _Film Rover_ [1987] 1 WLR 670, 680. Lord Hoffman said that trying to distinguish between
negative obligations and positive ones was a barren exercise. Mr Jagadesham also relied on _R (BG) v_
_Oxfordshire County Council_ _[[2014] EWHC 3187 (Admin) a decision of Michael Fordham QC, as he then](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D9K-PWT1-F0JY-C01F-00000-00&context=1519360)_
was, at [30]-[39]. That had been an application for permission to apply for judicial review (as well as interim
relief), but the Deputy Judge had given permission for it to be cited – see [41].

13. The resolution of this issue is, in my judgment, that there is no hard and fast rule that a claimant like
AS must show a strong _prima facie_ case, even though the relief sought might be characterised as a
mandatory injunction, but that characterisation is one factor which can properly be taken into account in
assessing the balance of convenience. The strength of the Claimant's claim (so far as it can be judged) is
also a factor to be taken into account in the balance of convenience.

14. This is an early stage of the litigation. It began only on 11th December 2020. The time for the
Acknowledgement of Service has not yet elapsed and none has been served. At the hearing on 17th
December, Mr Jagadesham also relied on the second witness statement of Ms Gibbons, the Claimant's
solicitor, made on 16th December 2020. Mr Paget did not object to him doing so, though it is unsurprising
that the Defendant has not had an opportunity to respond. In this witness statement Ms Gibbons relays
further information that she has been provided as to the Claimant's birth certificate.

15. Ms Gibbons says that she used the assistance of Dr Owolabi Bjalkander who had been recommended
to Ms Gibbons as someone who could assist with inquiries in Sierra Leone. Ms Gibbons exhibits as LG1 Dr
Bajalkander's curriculum vitae. At LG2 is an email dated 16th December 2020 which Ms Gibbons received
from Dr Bjalkander explaining the inquiries which she made regarding the copy of what was said to be the


-----

Claimant's birth certificate. Dr Bjalkander says that she went to the Registry of Births and Deaths in
Freetown, Sierra Leone with the copy that Ms Gibbons had provided and asked for it to be checked against
the original. It seems that the original was in the archives in Wellington, Freetown, but the copy which Ms
Gibbons supplied was verified by the Registry. Ms Gbbons then exhibits at LG3 what Dr Bjalkander
received back. Superficially, it appears the same as the copy of the certificate which Ms Gibbons had
previously produced. However, on closer inspection, there are additions. In the top left corner there is an
endorsement '720360 9th/12/2020'. In the top right corner there is an annotation, 'to be collected
10th/12/2020'. In the bottom left of the copy is 'verified vol OTR-213 Pg 64'. This is followed by a seal and a
signature that is illegible.

16. As I say, this litigation is at an early stage. The time for the Acknowledgement of Service has not yet
expired and there is none. In those circumstances, it is right for me to be circumspect in commenting on
the merits of the claim. However, as Stacey J. observed, the Defendant did write a detailed response to the
Pre-Action Protocol letter. I have also had the benefit of hearing submissions from Mr Paget.

17. As Mr Jagadesham emphasised, the wider task for the court on a judicial review of age assessment
decisions has a consequential impact on the test which the court will apply in deciding whether to grant
permission to apply for judicial review. Permission should be granted unless the court considers that the
Claimant's case, taken at its highest, could not properly succeed in a contested factual hearing in terms of
him establishing his claimed age – see R (FZ) v Croydon London Borough Council _[2011] EWCA Civ 59,_

[2011] HLR 22.

18. I am not here considering permission, but in my judgment, the Claimant does on the material presently
before me have, at the very least, a triable issue that permission should be granted.  I have borne in mind
the points made by Mr Paget:

i) That the Claimant has admitted having a daughter in Sierra Leone who was born in 2015. She was
therefore conceived in about 2014 when, on his account, the Claimant was 10 or 11. Although the Claimant
has said that the admission was made under duress, he accepts having had intercourse with the child's
mother before he left Sierra Leone in 2015.

ii) The Claimant's physique and demeanour which, in the opinion of the assessors were more likely if he
was aged 20 or more.

These are points in due course on which the Defendant could rely in support of its assessment, but neither
individually nor collectively nor together with the other matters on which the assessors relied do they mean
that there is no triable issue in this case. While sexual intercourse for a boy as young as the Claimant says
he was, might be unlawful in Sierra Leone, it is not impossible. Physical appearance and demeanour may
be taken into account in making an age assessment, but as the guidance from the Association of Directors
of Children's Services makes clear, they ought to be treated with caution. The point is obvious that
individuals develop and mature at different rates. There is no one size that fits all.

19. Although, as I have explained, this is not an appeal from Stacey J's order, it is right that I should record
her reasons for refusing interim relief. She said (in summary):

i) The Defendant had provided a detailed response to the Pre-Action Protocol letter from the Claimant and
had explained why it had changed its position and concluded that the Claimant was at least 20.

ii) The age assessment by the Defendant had been _Merton compliant and was in accordance with the_
earlier assessments of 29th March 2019 and 3rd September 2019.

iii) The risks of accommodating an adult with children was a factor to be weighed.

iv) The Defendant had duties to adults as well as children. If the Claimant was vulnerable and in need of
[support that could be provided by the Home Office pursuant to Immigration and Asylum Act 1999 s.95. If](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61R0-TWPY-Y0HB-00000-00&context=1519360)
the Claimant had been trafficked the National Referral Mechanism could be invoked.


-----

v) Even if there was a real issue to be tried, the existence of arguable grounds could be considered after
the Acknowledgement of Service. She considered that there was not a strong _prima facie_ case for relief
and the balance of convenience was not in favour of it.

20. Mr Jagadesham submitted that the balance of convenience favoured the Claimant.

i) As I have said already, he disputed the need to show a strong case to justify interim relief.

ii) The Defendant had previously accepted the Claimant's asserted age. That was relevant (a) because
that acceptance had not featured in the current age assessment and (b) because no good reason had
been shown for a further assessment.

iii) The age assessment which had been conducted in March 2019 was not _Merton compliant, as the_
Defendant accepted. The assessment in September 2019 had not been undertaken by someone trained in
age assessments. Neither of those earlier assessments therefore added significant weight to the present
age assessment.

iv) The assessed age of 20+ means that the Claimant could well be a child, given the appropriate margin
of error.

v) If the Claimant's criticisms of the current age assessment are well-founded it was not Merton compliant,
as Stacey J. had said. Among those criticisms are that the Claimant's first language is Krio, but he was
interviewed in English. He had an appropriate adult, Mohamed Salah, present during the interviews. Mr
Salah commented on the difficulty the Claimant seemed to encounter. In his notes of the process, Mr Salah
described the questioning of the Claimant as 'tough, repetitive intimidating and incoherent.'

vi) There is now the further evidence from Ms Gibbons.

vii) The Claimant was being supported and accommodated by the local authority and interim relief would
preserve that status quo until either the conclusion of the judicial review proceedings or, at the very least,
the determination of permission.

viii) The Claimant was being accommodated in self-contained accommodation. He was not therefore
coming into contact with other children through his accommodation, as Stacey J. appeared to believe.

ix) The Claimant had applied for asylum in the UK. If interim relief was refused, he would no longer be
accommodated in self-contained accommodation by the Defendant, but he would be dependent on
accommodation provided by the Home Office. As an adult asylum-seeker that could be anywhere in the
country. The accommodation offered might be in a hostel or other form of shared accommodation.

x) In the absence of interim relief, the Claimant would also be without the support which the Defendant is
currently obliged to provide and would not have the assistance which the Defendant must also provide to
him once he turns 18 and becomes a former relevant child.

xi) The Claimant's history is one of trauma. He gives an account of being trafficked, treated as a slave and
subjected to physical and sexual abuse..He had not so far been referred to the National Referral
Mechanism (for considering those who claimed to have been trafficked or victims of modern slavery).

21. Mr Paget for the Defendant submits that the balance of convenience favours the refusal of interim
relief. He argues

i) The full duties which the Defendant would owe to the Claimant as a child in care will last only a few more
days. On the Claimant's own case he will shortly be 18. While the Defendant would continue to owe the
Claimant some duties as a former relevant child they are much more attenuated.

ii) The Claimant will not be destitute if interim relief is refused. As an asylum-seeker he will be entitled to
support and accommodation from the Home Office.

iii) The guidance from the Association of Directors of Children's Services on which the Claimant relies
applies to the process of making an age assessment, but in this case, the Defendant has made its decision
and so that stage is passed.


-----

iv) The Defendant's decision is that the Claimant is 20 or more. Since he first approached the Defendant in
2019, if the decision is sound, the Defendant never owed the Claimant any duties (whether to care for the
Claimant while a child or as a former relevant child) since he was already an adult when he first contacted
the Defendant.

v) There was evidence that the Claimant spoke English fluently. The appropriate adult did not intervene or
object in the course of the questioning.

vi) The 2nd witness statement of Ms Gibbons takes the matter no further: the exhibit LG3 is another copy
of the birth certificate which had been included in her first witness statement.

vii) The Defendant had strong demands on its resources and services. That was an important
consideration in the balance of convenience.

22. My views as to this application have wavered, but, on reflection, I come down firmly in favour of the
grant of interim relief. My reasons are as follow:

i) It is right that, in a few days time, the nature of the duties owed to the Claimant, even on his own case,
will change. However, while the s.23C duties are more attenuated, they are real and important.

ii)  It is also right that the Claimant would not be destitute, if I refused interim relief. He will be able to look
to the Home Office for support and accommodation as an asylum-seeker. However, the nature of that
support is very much less than if he was owed the duties of a former relevant child.

iii) I was not persuaded by Mr Paget's submissions that the position is different so far as the ADCS
Guidance is concerned now that the Defendant has taken its decision. That is to ignore the particularly high
level of scrutiny that the court must pay to such a decision. As Picken J. said in _R (MVN) v London_
_Borough of Greenwich [2015] EWHC 1942 (Admin), the role of the Court is akin to that of the local_
authority. That meant that the Court should follow the Merton guidelines and should also apply the benefit
of the doubt principle.

iv) The further information regarding the Claimant's birth certificate is entitled to more credit that Mr Paget
gave it. While the document which Ms Gibbons exhibits at LG3 of her second witness statement began as
a photocopy of the birth certificate in the claim bundle, it is not identical to it. It has the additional notes,
annotations and markings which I have detailed.

v) I have taken into account the wider public interest and the mandatory character of the order which the
Claimant seeks, but they are not sufficient to lead me to conclude that interim relief should be refused.

23. The Claimant cannot be in a better position than if the Defendant had continued to accept his claimed
[date of birth. Accordingly, from 1st January 2021 he will be entitled to the duties he is owed under Children](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C3JF-00000-00&context=1519360)
_[Act 1989 s.23C, but no more.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C3JF-00000-00&context=1519360)_

24. I consider also that the interim relief which I grant should continue until the issue of permission is
determined, or further order. In the absence of agreement, it will be for the Judge considering the
application for permission to decide whether the interim relief should continue.

**Conclusion**

25. I shall grant interim relief. I will ask counsel to draft appropriate terms.

**End of Document**


-----

