# Windy Anjasmoro v The Home Office (2017) [2017] EWHC 3503 (QB)

QUEEN'S BENCH DIVISION

HQ13X05884

Straker J

Friday, 10 November 2017

10/11/2017

1. DEPUTY JUDGE STRAKER QC: The claimant, Mr Windy Anjasmoro, is an Indonesian seaman. He was born
in 1977 in a village where there are other fishermen or seamen. He has a wife and child. They live in Tegal, Java.
Mr Anjasmoro went to a vocational school in Indonesia. He secured two certificates, one in basic training and one
in boat survival. He later obtained a further certificate from the Indonesian Ministry of Transportation in engine
room watch keeping. Mr Anjasmoro told me that, since leaving school, his work has always been as an
international seafarer. He has worked out of at least the following countries or places: Malaysia, Taiwan, Spain,
Africa and Uruguay.

2. It came to pass, in circumstances I shall describe, that he secured a place as a crew member on Starward 737.
It is a fishing vessel having an overall length of 19.27 metres, just less than the length of a cricket pitch. It is
registered in Northern Ireland but worked at the material time out of North or South Shields near Newcastle.

3. Mr Anjasmoro joined it at the end of December 2012. Mr Anjasmoro received entry clearance to the United
Kingdom for the purposes of joining Starward, which ship was to work, and I find did work, beyond United Kingdom
territorial waters, that is to say 12 miles or further from the shore.

4. The defendant to this action is the Home Office which bears responsibility for the administration of amongst
other things visas and entry clearances. Mr Anjasmoro claims that the Home Office failed to take certain steps
when he sought entry clearance. Such steps should have been taken because the Home Office, it is said, should
have been alive to the possibility that Mr Anjasmoro or others in like position might be the victims of trafficking. It so
happens that the career of Starward 737 as a fishing vessel was not a success. It came to be arrested in
consequence as it appears that the ship's mortgage was not paid.

5. In the papers before me, at page 1774, there is a claim form being an admiralty claim in rem in respect of the
Starward dealing with and for sums due under a registered mortgage to secure an amount which is there set out. It
was issued on 26 March 2013. Further, it appears that at some stage this ship's condition became such that it was
not allowed to leave harbour. Nonetheless, Mr Anjasmoro, having nowhere else to go, continued to live on the ship
until 24 June 2013 when he was taken into detention on the basis that the ship not going anywhere and he having
come to the United Kingdom to work out of the United Kingdom in international waters was illegally in the United
Kingdom.

6. Mr Anjasmoro claims that the Home Office, through its officers, should have recognised that he was potentially a
victim of trafficking and that consequently he was, on 24 June or a later date but prior to 11 July when he was
released, unlawfully detained. Mr Anjasmoro by a claim issued towards the end of 2013 but seemingly served in
2014 seeks damages for breach of Articles 4 and 5 of the European Convention on Human Rights and for false
imprisonment.


-----

[7. By section 1(2) of the Human Rights Act 1998,Articles 4 and 5, amongst other articles, are to have effect for the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
purposes of the 1998 Act. By section 6, it is unlawful for a public authority such as the Home Office to act in a way
incompatible with a Convention right, and by section 7, a person who claims that a public authority has acted in
such a way, may if he or she is the victim bring proceedings.

8. One remedy available by section 8 is damages, and in this action damages are sought. Article 4 of the
European Convention on Human Rights provides in short form that no one should be held in slavery or servitude.
Further, that no one should be required to perform forced or compulsory labour. That is subject to certain
exceptions which are immaterial for present purposes.

9. Article 5 provides in short form a right to liberty and security of person. In the case of Rantsev v Cyprus [2010]

51 EHRR 1, it was found ‑‑ and the reference in the judgment is paragraph 282 ‑‑ that trafficking itself, within the

meaning of Article 3(a) of the Protocol to prevent, suppress and punish trafficking in persons, especially women and
children, and Article 4(a) of the Council of Europe Convention on Action Against Trafficking in Human Beings both
fell within Article 4 of the European Convention on Human Rights.

10. Mr Anjasmoro's case depends on his having been a victim or a potential victim of trafficking. It is therefore
appropriate to consider the meaning of trafficking. The meaning is given in international treaties, for which as

stated in Reyes v Al‑Malki [2017] UKSC 61, at paragraph 11:

"The primary rule of interpretation is laid down in article 31(1) of the Vienna Convention on the Law of Treaties
(1969):

'A treaty shall be interpreted in good faith in accordance with the ordinary meaning to be given to the terms of the
treaty in their context and in the light of its object and purpose.'

The principle of construction according to ordinary meaning of terms is mandatory ("shall"), but that is not to say
that a treaty is to be interpreted in the spirit of pedantic literalism. The language must, as the rule itself insists, be
read in its context and in the light of its object and purpose. However, the function of context and purpose in the
process of interpretation is to enable the instrument to be read as the parties would have read it. It is not an
alternative to the text as a source for determining the parties' intentions."

11. It is the protocol to prevent, suppress and punish trafficking in persons, especially women and children,
supplementing the United Nations Convention Against Transnational Organised Crime, which I have to consider.

12. This was adopted and open for signature, ratification and accession by General Assembly Resolution 55/20 of
15 November 2000. I should note that the Council of Europe Convention on Action Against Trafficking in Human
Beings made in Warsaw on 16 May 2005 carries the same or effectively the same definition of trafficking as the UN
convention.

13. Accordingly, I shall consider merely the definition in the United Nations Convention. However, I note that the
Council of Europe Convention as a preamble stated that trafficking in human beings constitutes a violation of
human rights and an offence to the dignity and the integrity of the human being, and that trafficking in human beings
may result in slavery for victims. It was also said that respect for victims' rights, protection of victims and action to
combat trafficking in human beings must be the paramount objectives.

14. The definition of trafficking is most certainly not to be considered in a vacuum. This was so stated by the
European Court of Human Rights in Rantsev. There is a series of paragraphs in that judgment which I should read.
At paragraph 272, it was said the first question which arose was whether the present case, that is to say the
Rantsev case, fell within the ambit of Article 4:

"The Court recalls that Article 4 of the European Convention makes no mention of trafficking, proscribing 'slavery',
'servitude' and 'forced and compulsory labour'."

15. The court continued:


-----

"The Court has never considered the provisions of the Convention as the sole framework of reference for the
interpretation of the rights and freedoms enshrined therein. ... it has long stated that one of the main principles of
the application of the Convention provisions is that it does not apply them in a vacuum. ... As an international
treaty, the Convention must be interpreted in the light of the rules of interpretation set out in the Vienna Convention
of 23 May 1969 on the Law of Treaties.

274. Under that Convention, the Court is required to ascertain the ordinary meaning to be given to the words in
their context and in the light of the object and purpose of the provision from which they are drawn. ... The Court
must have regard to the fact that the context of the provision as a treaty for the effective protection of individual
human rights and that the Convention must be read as a whole and interpreted in such a way as to promote
international consistency and harmony between its various provisions. ... Account must also be taken of any
relevant rules or principles of international law applicable in relations between the Contracting Parties and the
Convention should so far as possible be interpreted in harmony with other rules of international law of which it forms
part ...

275. Finally, the Court emphasises that the object and purpose of the Convention, as an instrument for the
protection of individual human beings, requires that its provisions be interpreted and applied so as to make its
safeguards practical and effective ...

276. In Siliadin, considering the scope of 'slavery' under Article 4, the Court referred to the classic definition of
slavery contained in the 1926 Slavery Convention, which required the exercise of a genuine right of ownership and
reduction of the status of the individual concerned to an 'object'. With regard to the concept of 'servitude', the Court
has held that what is prohibited is a 'particularly serious form of denial of freedom' ... The concept of 'servitude'
entails an obligation, under coercion, to provide one's services and is linked with the concept of 'slavery'. ... For
'forced or compulsory labour' to arise, the Court has held that there must be some physical or mental constraint, as
well as some overriding of the person's will ...

277. The absence of an express reference to trafficking in the Convention is unsurprising. The Convention was
inspired by the Universal Declaration of Human Rights proclaimed by the General Assembly of the United Nations
in 1948, which itself made no express mention of trafficking. In its Article 4, the Declaration prohibited 'slavery and
the slave trade in all their forms'. However, in assessing the scope of Article 4 of the Convention, sight should not
be lost of the Convention's special features or of the fact that it is a living instrument which must be interpreted in

the light of present‑day conditions. The increasingly high standards required in the area of the protection of human

rights and fundamental liberties correspondingly and inevitably required greater firmness in assessing breaches of
the fundamental values of democratic societies ...

278. The Court notes that trafficking in human beings as a global phenomenon has increased significantly in recent
years ... In Europe, its growth has been facilitated in part by the collapse of former Communist blocs. The

conclusion of the Palermo Protocol in 2000 and the Anti‑Trafficking Convention in 2005 demonstrate the increasing

recognition at international level of the prevalence of trafficking and the need for measures to combat it.

279. The Court is not regularly called upon to consider the application of Article 4 and, in particular, has had only
one occasion to date to consider the extent to which treatment associated with trafficking fell within the scope of
that Article ... In that case, the Court concluded that the treatment suffered by the applicant amounted to servitude
and forced or compulsory labour, although it fell short of slavery. In light of the proliferation of both trafficking itself
and measures taken to combat it, the Court considers it appropriate in the present case to examine the extent to
which trafficking itself may be considered to run counter to the spirit and purpose of Article 4 of the Convention such
as to fall within the scope of the guarantees offered by that Article without the need to assess which of the three
types of proscribed conduct are engaged by the particular treatment in the case in question.

280. The Court observes that the International Criminal Tribunal for the Former Yugoslavia concluded that the
traditional concept of 'slavery' has evolved to encompass various contemporary forms of slavery based on the
exercise of any or all of the powers attaching to the right of ownership ... in assessing whether a situation amounts
to a contemporary form of slavery the Tribunal held that relevant factors included whether there was control of a


-----

person's movement or physical environment, whether there was an element of psychological control, whether
measures were taken to prevent or deter escape and whether there was control of sexuality and enforced labour ...

281. The Court considers that trafficking in human beings, by its very nature and aim of exploitation, is based on
the exercise of powers attaching to the right of ownership. It treats human beings as commodities to be bought and
sold and put to forced labour, often for little or no payment, usually in the sex industry but also elsewhere ... It
implies close surveillance of the activities of victims, whose movements are often circumscribed ... It involves the
use of violence and threats against victims, who live and work under poor conditions ... It is described by Interights

and in the explanatory report accompanying the Anti‑Trafficking Convention as the modern form of the old

worldwide slave trade ... The Cypriot Ombudsman referred to sexual exploitation and trafficking taking place 'under
a regime of modern slavery' ...

282. There can be no doubt that trafficking threatens the human dignity and fundamental freedoms of its victims
and cannot be considered compatible with a democratic society and the values expounded in the Convention. In

view of its obligation to interpret the Convention in the light of present‑day conditions, the Court considers it

unnecessary to identify whether the treatment about which the applicant complains constitutes as 'slavery',
'servitude' or 'forced and compulsory labour'. Instead, the Court concludes that trafficking itself within the meaning

of Article 3(a) of the Palermo Protocol and Article 4(a) of the Anti‑Trafficking Convention falls within the scope of

Article 4."

16. That concludes for the moment the extract from the Rantsev case. I can now turn to the actual language of the
definition:

"For the purposes of this Protocol:

(a) 'Trafficking in persons' shall mean the recruitment, transportation, transfer, harbouring or receipt of persons, by
means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of
power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of
a person having control over another person, for the purpose of exploitation. Exploitation shall include, at a
minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or
services, slavery or practices similar to slavery, servitude or the removal of organs ..."

17. As a matter of language, there are two sentences, and it is the first, a long one, in which I have recorded the
position of the commas with which I am particularly concerned. The sentence consists of two lists, and having set
out those lists, signified the required purpose behind the items in those two lists if there is to be trafficking.

18. Accordingly, on the basis of the definition, as was said in a case called EK v SSHD _[[2013] UKUT 00313 (IAC):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5929-8BS1-F0JY-C1RS-00000-00&context=1519360)_

"There are three components to trafficking ...

i. the action of recruitment, transportation, etc of persons.

ii. by means of threat, force, deception, etc.

iii. for the purpose of exploitation, forced labour, etc."

19. The items given in paragraph 38 of the judgment in EK begin first with the action, and the action is ‑‑ returning

to the language of Article 3 ‑‑ the recruitment, transportation, transfer, harbouring or receipt of persons. It is clear

that everything in that list is referable to persons. That list is then followed by the list in respect of the means. This
list proceeds as follows:

"By means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse
of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve the consent
of a person having control over another person."


-----

20. When the case was opened to me by Mr Tristan Jones on behalf of Mr Anjasmoro, it was on the basis that as
far as the steps in Indonesia were concerned, the action was recruitment and the means was deception. It was
also said that the purpose was exploitation. It was not said that the means had to achieve any particular outcome,
merely that the purpose behind the means should be and was exploitation, as it equally was and had to be the
purpose behind the recruitment.

21. In the course of the trial, I pointed out that the second list in the definition, in other words the means element,
all appeared to seek to achieve something; that is to say the consent of a person having control over another
person. Mr Jones responded by pointing out that no case had considered that particular aspect, and the
achievement of consent only related to the last part of the list, ie by means of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having control
over another person.

22. Mr Russell Fortt for the Home Office took instructions on the matter and submitted that the required
achievement was necessary for all items within the list of means. In other words, for example, the definition is to be
read as transportation of persons by means of the threat of force to achieve the consent of a person having control
over another person.

23. This approach appears consistent with the language used and the way matters have been listed. In the Home

Office guidance called "Victims of modern slavery ‑ Competent Authority guidance" version 3.0, published on 21

March 2016, this is said in respect of the "means" part of the definition:

"An adult victim of human trafficking must have been subject to a 'means' ‑ the threat of use of force or other form of

coercion to achieve the consent of a person having control over another person."

24. This, of course, is entirely consistent with the language of the article, and it is entirely consistent with my view
as to what the article means. It means, to my mind, that there has to be an action: the recruitment, transportation,
transfer, harbouring or receipt of persons. There has to be a means, means of the threat or use of force or other
forms of coercion, of abduction, and so on, to achieve something, the consent of a person having control over
another person, for, as the definition says, the purpose of exploitation.

25. I should also note that the approach I have suggested as the correct approach is consistent with the passages I
have mentioned in the case of Rantsev. The very concept of trafficking involves securing a victim which involves
securing his control. No doubt there are circumstances where one would not know from whom control had been
obtained. Thus, the Home Office, through Mr Fortt, very properly emphasised that the definition would not preclude
from the definition of trafficking the man who travels to the United Kingdom with a person who is his slave.

26. In that circumstance, control must have been obtained from somebody, whether from the mother at or after
birth, or the parents, or somebody who came to be enslaved, or to ensure that somebody was enslaved. Further,
the definition carries in its list a variety of means so as to ensure that the slave who is conveyed to the United
Kingdom will be able to be treated as trafficked, as the Home Office signified is in fact the case.

27. It is also worth noting that an underlying purpose given behind the United Nations Convention is stated by
Article 5 as being criminalisation. Accordingly, one needs to be careful to ensure that the criminal act is properly
defined so that people who may potentially be convicted of it, depending on how it is enacted into domestic
legislation, can safely be convicted upon it knowing that the definition is fulfilled.

28. Further, on the approach of the claimant, some forms of trafficking would bear no relationship to any ordinary
concept of trafficking at all. For example, recruitment by deception to exploit. That can equally happen in a
parviwlan town or abroad. I should also mention that my approach to the definition does not leave any conduct,
such as for example forced labour devoid of sanction or protection.

29. After that lengthy discussion, I return to the facts of this case. I should emphasise that I decide the case both
on the basis of what I take to be the correct interpretation; namely that the means should seek to achieve the


-----

consent of a person having control over another person, and on the basis that one does not need to be concerned
with such a matter.

30. On the basis of the correct interpretation, it can immediately be noted that there is no evidence when
considering the grant of entry clearance to suggest that any means within the definition was deployed, whether in
Indonesia or the United Kingdom, to achieve the consent of a person having control over another person. Similarly,
there is no evidence to suggest that any one in June 2013 should reasonably have thought that Mr Anjasmoro had
been recruited or was being harboured by means of coercion or deception to achieve or to have achieved the
consent of a person having control over Mr Anjasmoro.

31. Such being the case, the claim being tied, as Mr Jones agreed, exclusively to trafficking must necessarily fail.
However, I shall proceed to consider the case on the basis of the definition as tendered by Mr Jones. He says Mr
Anjasmoro was recruited in Indonesia by means of deception for the purpose of exploitation. Alternatively, he says
there was a risk Mr Anjasmoro might have been so recruited. Further, he says the Home Office ought to have
taken further and other administrative steps from those taken so as to reflect the risk that Mr Anjasmoro or others in
like position might be trafficked.

32. This argument draws on paragraph 286 of the Rantsev judgment, in which it was said that there would be a
violation of Article 4 of the Convention where the authorities fail to take appropriate measures within the scope of
their powers to remove an individual from risk.

33. I should read the entirety of paragraph 286:

"As with Articles 2 and 3 of the Convention, Article 4 may, in certain circumstances, require a State to take
operational measures to protect victims, or potential victims, of trafficking ... In order for a positive obligation to take
operational measures to arise in the circumstances of a particular case, it must be demonstrated that the State
authorities were aware, or ought to have been aware, of circumstances giving rise to a credible suspicion that an
identified individual had been, or was at real or immediate risk of being, trafficked or exploited within the meaning of

Article 3(a) of the Palermo Protocol and Article 4(a) of the Anti‑Trafficking Convention. In the case of an answer in

the affirmative, there will be a violation of Article 4 of the Convention where the authorities fail to take appropriate
measures within the scope of their powers to remove the individual from that situation or risk."

34. The evidence of what occurred in 2012 derives from documentary material and from Mr Anjasmoro himself.
For reasons that will become apparent, I did not find Mr Anjasmoro to be a satisfactory witness. In _Summers v_
_Fairclough Homes Limited [2012] 1 WLR 2004[2012] UK SC26, the Supreme Court said at paragraph 52, per Lord_
Clarke, that:

"A party who fraudulently or dishonestly invents or exaggerates a claim will have considerable difficulties in
persuading a trial judge that any of his evidence should be accepted."

35. On any basis, Mr Anjasmoro acted in a deceptive way and, as it appears to me, has exaggerated his claim or
sought to state what he thought necessary for his claim. Mr Anjasmoro has, like other seafarers, a seaman's book.
This is rather like a passport and indeed can in certain instances take the place of a passport. On any basis, it is an
important document. Mr Anjasmoro seaman's book, page 334 in the bundle, is numbered YO53871. It is valid for
all parts of the world and records that it was registered at Tanjong Priok on 17 June 2011 as being valid until 17
June 2014. It contains health notes from 17 June 2011 in which vision, hearing and health all appeared marked as
good. I take that to be so because a single letter is used and is the first letter of a word I was told means "good". It
records periods of work abroad, certain vessels sailed upon, together with the category of work done.

36. It records at page 337 work on the KM Sinar Jaya between 20 July 2011 and 18 June 2012, capability and
behaviour are recorded as having been good. The document has two official stamps on it with a signature in the

column of the ship's master. The document appears to have been ‑‑ see page 433 of the bundle ‑‑ amongst those

supporting documents shown when entry clearance is sought. In his evidence to me, Mr Anjasmoro said he had
never in fact worked on the KM Sinar Jaya and that the entry was a trick of the agency he was using to secure at


-----

the end of 2012 an engagement on the Starward. He said that was the way the agency worked and that he, Mr
Anjasmoro, allowed a false entry to be made in his seaman's book which he knew was an official document. He

said, after I had told him of his privilege against self‑incrimination, that he could not answer the question whether

the seaman's book had been used in any deception.

37. In any event, Mr Anjasmoro made an application for United Kingdom entry clearance by amongst other things a
form which he signed on 21 November 2012. It is at page 184. This gave details of certain matters likely to be
known only to Mr Anjasmoro, including the dates of the birth of his parents, the full names of his spouse and child.
This form indicated at page 181 that Mr Anjasmoro was working as a deck hand at KM Sinar Jaya fishing vessel,
and the name of the company he worked for was the Indonesian Fishermen Federation.

38. In his witness statement dated 10 June 2016, Mr Anjasmoro said he obtained his employment in the United
Kingdom, ie his placement on the Starward, with the assistance of the Indonesian Fishermen's Federation and he
had not used them before. He was keen to tell me that the agents IFF had done everything in respect of securing
his place on the Starward.

39. However, I find that he must at the very least have contributed to the completion of the application for entry
clearance. Further, I consider Mr Fortt to be correct when he says that either Mr Anjasmoro had previously worked
with or for the IFF and on the KM Sinar Jaya, or that he was party to there being a false entry in his seaman's book
in the hope that either it would advance his entry clearance or support his prospect of getting a place on the
Starward.

40. The former, that is to say his having worked on the KM Sinar Jaya, appears more likely, in which case he, Mr
Anjasmoro, was seeking to bolster his case that he had been deceived by unscrupulous people to come to work in
the United Kingdom and that the agency, IFF, did everything and he knew nothing of what they did. This matter is
of a seriousness which in my view means I should approach Mr Anjasmoro's evidence with extreme caution, and, in
material part, accept only if it is corroborated. Mr Fortt points out that I could consider striking the matter out for
abuse of process. He is right so to state. He does not invite me however to go down that route, and accordingly I
do not do so.

41. I consider that in 2012, Mr Anjasmoro was looking for work as a seafarer, that he identified through IFF the
possibility of working on the Starward and that he independently and with no coercion or deception decided he
wanted to take up the opportunity, knowing that the contract would be in the terms that had been provided to him
and signed by him, page 40 of the bundle, on 20 November 2012.

42. I do not consider that he was deceived by Mr Laverty, the gentleman in Northern Ireland who was in charge of
the ship. He had signified he wanted to recruit and was prepared, as he did, to pay. There was nothing out of the
ordinary about that particular matter. The economic misfortunes that came to befall Mr Laverty were misfortunes
and there is nothing to suggest that he was reckless in the process that he took in employing staff and to provide
hands for the ship in the hope and expectation that it would be able to fish for reward in the North Sea.

43. This finding precludes any possibility in December 2012 of Mr Anjasmoro being the victim or potential victim of
trafficking. He was an adult seafarer offered work at a rate of pay materially greater than that which he recorded
himself as receiving at that time or just before that time, namely $250 a month (see page 181 of the bundle).

44. It is said that the contract contains an unusual term which ought to have alerted the state authorities to the
possibility of trafficking in 2012 or 2013. The term is article 5. I shall read this term in its English translation. It
looks as if it rather lost in translation:

"Physical protection:

1. If any seafarer of officer is intentional to strike and/or to kick to the seafarer, seafarer must first inform the protest
in writing to the agent who sent him aboard before taking any action on his own. Seafarer must be for the agent to
give them any in future instruction.


-----

2. If seafarer has been proved to have been physically abused and have written and sent his complaints to the
agent three times or more without any feet back result, then seafarer is allowed to break of the employed
agreement before the term ends.

3. In this case, employer/owner shall pay of wage and bonus based on the term on this agreement.
Employer/owner must pay off seafarer travelling to his home country. The total cost will be calculation form the
nearest port to home country of seafarer."

45. It is said that that was, in effect, a licence to abuse or to represent such an extraordinary circumstance as to be
a matter of alert. It is also said that you have to wait, so to speak, for three strikes before you are out. First, the
clause needs to be seen contextually. Secondly, the approach of a court to such a clause can be in mind. It would
never be interpreted as a licence to hit. Thirdly, the first part of it does not disable action if there is but one strike. It
merely requires report to the agent before the taking of action.

46. I do not consider that contextually ‑‑ and context is all important – it has provided an indication of trafficking or

potential trafficking.

47. I turn to consider whether there were nonetheless factors which should have prompted the Home Office to take
other and different steps from those in fact taken. The steps suggested are an individual interview and the giving of
a notice about rights to Mr Anjasmoro. The reasons why these were suggested is because in EK (to which I have
already referred), the Upper Tribunal discussed at paragraph 36 the approach that was taken in respect of domestic
workers.

48. The Upper Tribunal said it was clear that the United Kingdom had been aware since at least 1990 of the need
to provide appropriate protection through its immigration policy and rules to domestic workers who were at risk of
being brought into this country and then being subject to exploitation in the form of forced labour. That conclusion
is clear from the terms of the parliamentary debate held on 28 November to which reference had been made before
the tribunal.

49. At paragraph 29, the upper tribunal said the United Kingdom government had recognised the need to put
operational measures into place and had done that putting in place of plainly proportionate arrangements
concerning interview of a domestic worker by an entry clearance officer and the provision of relevant information in
a language which could be understood.

50. At paragraph 39, the Upper Tribunal indicated those arrangements were of a sort which could be in place in
order to comply with Article 4 of the Convention.

51. I do not consider that what obtains in respect of domestic workers necessarily obtains for maritime workers. I
accept as stated at paragraph 28 of the defendant's skeleton argument that there is no prescription in any of the
relevant jurisprudence, including Rantsev, as to the steps which a member state has to take to discharge its
administrative obligations. Plainly the spectrum of necessary measures will, at least, in part vary depending on the
nature of the visa being applied for.

52. I consider it very difficult for a judge sitting in London to specify administrative steps to be taken both abroad
and in this country which will plainly have resource implications. I draw attention to steps in this country and abroad
because a large number of countries but not including Indonesia are parties to the ILO Convention 108, the
International Labour Organisation.

53. Article 6 of that Convention states that:

"1. Each Member shall permit the entry into a territory for which this Convention is in force of a seafarer holding a
valid seafarer's identity document, when entry is requested for temporary shore leave while the ship is in port.


-----

2. If the seafarer's identity document contains space for appropriate entries, each Member shall also permit the
entry into a territory for which this Convention is in force of a seafarer holding a valid seafarer's document when

entry is requested for the purpose of ‑‑

(a) joining his ship or transferring to another ship;

(b) passing in transit to join his ship in another country or for repatriation; or

(c) for any other purpose approved by the authorities of the Member concerned.

Any member may, before permitting entry into its territory for one of the purposes specified in the preceding
paragraph, require satisfactory evidence, including documentary evidence from the seafarer, the owner or agent
concerned, or from the appropriate consul, of a seafarer's intention and of his ability to carry out that intention. The
Member may also limit the seafarer's stay to a period considered reasonable for the purpose in question.

4. Nothing in this Article shall be construed as restricting the right of a Member to prevent any particular individual
from entering or remaining in its territory."

54. There is, thus, in place a slight difference of approach between those countries and the mariners in those
countries who have signed up to the ILO convention, and those who have not. Indonesia has not or has not yet
signed up to the Convention. For the Convention countries, their seamen simply arrive in the United Kingdom
without having earlier and abroad sought entry clearance. Such will come to be the case for Indonesia if Indonesia
ratifies ILO Convention 108.

55. Accordingly, Mr Jones says and has to say that the United Kingdom should put in place interviews and the
giving of a leaflet both abroad and in the United Kingdom.

56. I should mention that something in the order of 12,000 seafarers (I was told) seek each year entry clearance to
join ships in the United Kingdom. This does not, as I understand matters, include the figures of those who do not
need entry clearance, that is to say from the ILO convention nations. Consequently, there would clearly be
resource implications. Nonetheless, Mr Jones says such steps should be taken because the Home Office knew or
ought to have known of the risk of seafarers or Indonesian seafarers being trafficked.

57. It should not be supposed there are at present no administrative measures by which trafficking might be
identified. A detailed application has to be made, supported by documents. In this case, one knows what those
documents are. They are listed on page 433 as (1) travel document or passport, (2) one passport sized photograph
not more than six months old, (3) appropriate fee, (4) seaman's log book, letter from Indonesian shipping, letter
from UK employer, itinerary. In addition, certain biometrics are required.

58. Further, continuous action occurs to identify on an evidence‑based risk and to report such risks to decision

makers so their decision can take risks into account and seek further information as necessary. Thus, Mr Robin
Myseer gave evidence of the risk and liaison overseas network, which is an advisory and consultative service giving
advice to entry clearance officers generally and specifically.

59. He describes how the role of the risk and liaison overseas network, otherwise called RALON, was to highlight
to entry clearance officers risks to assist and improve decision making. There are obviously many risk areas;
trafficking, people smuggling, document fraud, terrorism, et cetera, and he describes how various matrices, and so
forth, were carried out and how various investigations are undertaken. He draws attention to the fact that the
number of applications for joining ship visas by fishermen from Indonesian nationals was relatively low. At the time,
he says, the only join ship seaman cases on the adverse cases database were those related to fake employment
letters. An employment letter of course is one of the very things which has to be provided in any event.

60. Mr Jones says that is not enough and drew my attention to a number of reports which he discussed with
witnesses for the Home Office. I do not propose to recite all these reports and without seeking in any way to
minimise the problems they describe, they are in part at least necessarily generic.


-----

61. Mr Clifford gave evidence for the Home Office. He said it may be that the Home Office ought to have been
aware of a report called "Migrant Workers in the Scottish and Irish Fishing Industry" dated 25 November 2008. This
document says, at page 929 of the court bundle, that through its vast experience in dealing with the fishing industry,

the ITF has found that it is common practice in Indonesia and other Asia‑Pacific labour supply countries to lure

seafarers away from their homes on a false promise. Then it says further information can be seen on a particular
website, and there is also a video.

62. I do not consider I can properly say such a passage or such a report or the collection of reports I have referred
to mean that what the Home Office was doing was wrong and moreover it was in breach of Article 4 of the
Convention. I do not believe that it was. Supposing the matter at issue is luring seamen away on a false promise,
the very administrative steps I have just described can see what is the prospective employment position.
Furthermore, I do not see what for a seaman such as Mr Anjasmoro such measures would achieve. It is clear he
wanted to come to the United Kingdom, he wanted to come here to join a ship. It is clear he participated in the
application process, and it is clear that he knew what was proposed.

63. He was no doubt influenced, as everyone is, by a multitude of factors: desire to provide for his family, desire to
work the trade he had chosen, to accompany as he did his friend from Indonesia to the United Kingdom, and so on.
The essential point is that the decision was his. I asked what it was a leaflet might say, and I was referred to the

re‑amended Particulars of Claim. In considering this matter, it has to be remembered that the visiting seafarer is

visiting to join a ship which is to work outside the United Kingdom. Accordingly, the employment rights within the
United Kingdom do not obtain.

64. I, as stated, referred to the re‑amended Particulars of Claim in response to my question as to what a leaflet

might say. It was suggested that it could draw attention ‑‑ and I am looking here at the re‑amended Particulars of

Claim, paragraph 20(viii)(f), that it could draw attention to the right to a written copy of the terms and conditions of
employment, the right to be paid in accordance with the National Minimum Wage Act, the existence of organisations
that the claimant could contact once in the United Kingdom if concerned he was being mistreated or his
employment rights were not being respected, the right to be treated properly, and if a person thinks he has been the
victim of crime he can go to the local police station or call 999, the right to be given rest breaks and not to be forced
to work excessive hours, and other employment law protections in the United Kingdom, and the entitlement to free
healthcare in the United Kingdom.

65. It will be seen that the bulk of the information relates to those within the United Kingdom. That which is left is
little more than the fact that there are institutions in the United Kingdom that help seafarers, and that the United
Kingdom maintains police forces. These matters would of course be known to the seafarer.

66. It should be noted also that there can be no expectation that a ship joined in Newcastle will always port in
Newcastle, England, yet Mr Jones does not say that the leaflet should relate other than to the United Kingdom.

67. Accordingly, I consider that the risks of trafficking such as they were not such as to demand any further
administrative steps of the Home Office. Consequently, I find that Mr Anjasmoro was not trafficked out of Indonesia
and he was not a potential victim of trafficking out of Indonesia. I do not consider he suffered from any deception in
Indonesia. The contract which he accepted came to be performed, but subsequent economic circumstances
deranged its expected operation. I find that the Home Office was aware that trafficking did occur in various places
and from time to time, but the administrative steps in place were sufficient to deal with such threat as was perceived
or ought to have been perceived.

68. Accordingly, when Mr Anjasmoro arrived in Newcastle in December 2012, it was as a free man, just he had left
Indonesia a free man. The contract, of which at all material times Mr Anjasmoro had a copy, provided he would
work on Starward N737 as a deck hand and that he would get a basic wage of £700 a month with a bonus to be
decided by the master or captain. 60 per cent of the salary was to be paid on board, the balance was to be sent to
the IFF office, with that office transferring that proportion to the seafarer's family.


-----

69. I should here mention that the IFF appears, contrary to the practice which may be a preferable practice in the
United Kingdom, to operate on a basis of taking a fee from both the employee and the employer. At paragraph 12
of his first witness statement, Mr Anjasmoro said:

"The agent I arrange things through was called Mr John, who was Indonesian. There was a fee of 14 million rupiah
to the agency to get the work. This was to be paid up front, but I didn't have the money so after discussion, they
agreed I could pay a down payment of 5 million rupiah, which I funded through a loan from the bank, and repay the
rest, 9 million, from my wages. Mr John wanted to take 40 per cent of my wages until the debt was paid. If I
couldn't afford this, it would leave my family with not enough money, so he agreed that I would only pay the agency
20 per cent of my wages every month so the debt would take longer to repay. The plan was that I would be paid 60
per cent of my wages in cash, the remaining 40 would be sent to the agency, I would keep 20 per cent and pass the
remaining 20 per cent on to my family."

70. When he came to give oral evidence, Mr Anjasmoro was asked about the documents in which the loan from the
bank was recorded. He said he did not know where they were and added that his father had arranged or secured
the loan. In paragraph 1 of his witness statement, Mr Anjasmoro said:

"My father had to stop his employment as a welder because his vision became impaired. His children now support
him. At the time I came to the United Kingdom, my brother and sister, my older siblings who are both married, gave
my father 150,000 rupiah per month which was just enough to buy food."

71. Mr Anjasmoro said he was scared of the IFF. At paragraph 50 of his witness statement, he said he was very
worried about repaying the 9 million rupiah to the agency:

"Ordinarily you have to pay up front, but in my case I contracted a debt with them which I have not repaid. The
agency have a team of people who recruit workers and receive funds. They have people to find people like me. I
don't think they would be compassionate because it was not my fault that I was not paid. I am frightened that they
could be violent with me if I cannot repay them. I am worried they would fetch me from the airport and interrogate
me. They have already gone to my wife's neighbourhood looking for her, but she avoided them."

72. However, he has in fact returned to Indonesia seemingly without incident and has given varying accounts which
I do not recite of contact with them. Given my view of his evidence, together with it being more likely than not that
he had worked with them before, I do not accept that he was scared of the IFF or so scared of them as to affect his
actions.

73. Mr Anjasmoro, having arrived at Heathrow on 29 December 2012, travelled by air to Newcastle and was met by
a man called Nathan who also worked on the Starward. Mr Anjasmoro travelled from Indonesia with a friend, also
from Indonesia, also to join the ship Starward. It seems more likely than not that Mr Anjasmoro and his friend had
decided together to seek employment in the United Kingdom. Having joined the Starward, it set sail the following
day at about noon. Mr Anjasmoro says after a month, he personally was paid £600 and in the second month £700.
He says he was due £700, but in fact the contract provided for 40 per cent of the 700 to be deducted.
Subsequently, Mr Anjasmoro came to be given £100 which may be the shortfall from the first month. However, the
Starward certainly did not leave harbour after 11 April 2013 and it maybe did not leave harbour from an earlier date
than that.

74. There are two reasons why such was the case. I have already referred to the admiralty claim for non‑payment

of the ship's mortgage. Second, the ship came in any event to be prevented from leaving as it appears by the
harbour master.

75. Mr Jones argues that from 20 June 2013, whatever the position had been in Indonesia, the Home Office should
have been alive to the fact that at least Mr Anjasmoro was a potential victim of trafficking. He says he had been
harboured aboard the ship through coercion, and that as such was for the purpose of exploitation.

76. This of course proceeds on the footing of the definition of trafficking sought by Mr Jones but rejected by me.
However I proceed on the footing that such is the definition I have already found that whatever definition is used


-----

Mr Anjasmoro was not trafficked to the United Kingdom, nor was he at risk of being trafficked to the United
Kingdom.

77. Mr Jones said he became trafficked whilst aboard ship, and he should on 20 June have been so regarded. The
reason why 20 June is important is that is the date on which it is said indications of trafficking came to be available
or came readily to be available to the defendant.

78. I should interpose here to say that Klara Skrivankova was called as an expert witness. She was to help the
court on these questions: what practical steps ought to have been taken by the officers involved in the decision to
detain, the detention itself and the visa application entry clearance process to ascertain if the claimant was a victim
of trafficking? What indicia would have been apparent if those steps had been taken and what the relevant indicia
of trafficking would have been.

79. I should straight away say that I did not find her evidence of any particular value. Her report was largely based,
although she had other documents, on an interview with Mr Anjasmoro nearly three years after proceedings had
been issued. I observed to her that she used, and she used again despite my observation, the expression that she
would argue that such and such was the case. I consider an expert witness should be astute to avoid arguing a
case. The role of an expert is to give dispassionate and disinterested expert opinion on identified facts.

80. In fact, her evidence was little more than a statement of what might be indicators of trafficking which are in any
event many and varied and to a degree obvious, and which are context dependent. A difficulty for the witness is
that she was heavily or entirely dependent on what she was told by Mr Anjasmoro after the claim had been
instigated. She expresses certain conclusions, namely that from the circumstances and from the information that
he would have provided at the time of his encounter with the authorities, the following indicia of trafficking would
have been apparent; abuse of vulnerability, a deception, withholding of wages, isolation, abusive working and living
conditions.

81. I do not accept that, and I do not accept her conclusion that the government authorities failed in their
responsibilities to spot potential indicators and circumstances of trafficking and to take steps to enquire into Mr
Anjasmoro's case as a potential trafficking from their first encounter with him, as would have been pertinent, she
says, under extant policy and law at the time.

82. She based herself on information, which as presented by her does not actually appear to represent what took
place. She refers for example to migrant workers living in cramped, unsanitary conditions, but the conditions were
simply four men who shared a room in which they slept and shared a lavatory. She speaks as to the Claimant not
speaking much English and being confused about what was happening, but I do not see that that provides any
further or better assistance as to a suggestion of trafficking.

83. The living conditions she described as being appalling, in contrast to what he had earlier said in interview,
where it was a solitary matter mentioned by way of a heating rail which did not appear to work or which was
overloaded when it came to dry clothes. She also speaks as to abandonment by his employer and wages being
withheld, whereas the circumstances are as has been described by me. Accordingly, I do not rely upon or proceed
upon the basis of her evidence.

84. On 20 June at 12.45, a maritime enforcement officer sent an immigration officer an email which said:

"As discussed earlier, please find attached copies of the biodata and visa details for the four visa nationals currently
on board [what was] the fishing vessel Starward moored in western quay North Shields. The information we have
to hand is the vessel was inspected by the MCA [the marine and coastguard agency] and they have classed the
ship as unsafe and wish to withdraw its fishing boat status. The four persons on board have informed the MCA that
they have not been paid for some time and they appear to be currently to be living without electricity, heating or
drinking water. I have carried out CID and CRS checks and no additional leave appears to have been applied for
since the issue of their visas to join the Starward. With my experience limited in this area, it is my understanding
that they would not be able to leave the vessel for any major period without being in breach of their leave. Given
the circumstances, I feel they may be an easier removal for your team."


-----

85. It was added to that by way of a stress that.

"[The maritime enforcement officer] nor any other UKBA/UKBF officers have spoken to the people directly."

86. That email prompted a further email to the operational advice and support unit of the border force. This came
from an immigration officer based at the UK border force at Newcastle Airport, and records that:

"[They] had been alerted to somewhat unusual case and would like information on how to proceed and whether
actions could be taken by port officers or if action would have to be taken under enforcement auspices. The case is
thus four fishermen have been encountered upon on the above named boat [that is to say the Starward] living in
squalid conditions without pay, without food or drinking water. Two are Filipino and two are Indonesian. All
transited to the UK legally with ECs to join the ship. The MCA enforcement officer was able to provide photos of
these and the contracts from his camera phone. The ship has been impounded by MCA for safety reasons. It
appears on investigation however that shortly after they joined the ship, the company operating the ship dissolved,
which explains the lack of payment. I have further found that the ship has not left North Shields port since at least
11 April 2013 and the ship has been visited twice by UKBF officers in order to arrest the ship on behalf of the
admiralty, with the latest being on 11 April 2013. On both occasions, the ship was found locked up and unoccupied.
It transpires that the fishermen are being provided with food and drink at the local seafarer's charity, and I assume
they are availing themselves of the facilities provided there when they were not present on the ship. The men have
been to all intents and purposes abandoned by their company and left destitute with no means to leave the United
Kingdom. We are concerned that as they have been in the United Kingdom without leaving for several months,
they cannot be dealt with under the port seamen provisions and that they would have overstayed any deemed
shore leave. We would be grateful for your advice on how to take this forward as a matter of urgency as the
predicament these seafarers find themselves in is rather desperate."

87. I do not consider that these circumstances as described can be put in context as a credible suspicion that there
had been or may have been trafficking. Those circumstances as described reveal what in fact had happened: the
fishing ship had left port, had fished but had come back and had come to be arrested, and the lack of payment is
explicable through, as is said in the email, the company operating the ship dissolving. Then, of course, the matter
is one whereby the fishermen had nowhere to go because they were on the ship, but it simply does not follow that
there was any indication of trafficking as properly to be understood or at risk of trafficking as is properly understood,
or on the limited definition as given by Mr Jones.

88. The tale in those emails of is one of economic problems and abandonment and is not a matter of harbouring.
The men were able to come and go, it was not a matter of coercion. Whilst harbouring is not an antonym of
abandonment, it is by no means a synonym for abandonment.

89. I should just say a word about the work which appears to have been done on the vessel pending 20th and 24th
June. This cannot, as I have pointed out, have been overall extensive given the size of the vessel, and appears to
have been done not under any sense of coercion with, so to speak, the whip hand of the master requiring it to be
done, but rather with a view to assisting in case there was going to be any prospect of sailing.

90. I remind myself of paragraph 286 of the Rantsev case. For there to be a positive obligation:

"... it must be demonstrated that State authorities were aware, or ought to have been aware, of circumstances
giving rise to a credible suspicion that an identified individual had been, or was at real and immediate risk of being,
trafficked or exploited."

91. Mr Jones says that there were eight indicators of trafficking. He refers to operational indicators of trafficking in
human beings result from a Delphi survey implemented by the ILO and the European Commission first published in
March 2009, revised September 2009 (found at page 1485 of the court bundle). At 1487, it gives guidance as to
how to use the indicators, and then at 1488 gives indicators of trafficking of adults for labour/exploitation. Some are
described as strong indicators, some as medium indicators, some as weak indicators, and there is a long list of
such matters under various subheadings. I do not recite that particular set of matters.


-----

92. Mr Jones says there was an imposed place of accommodation, poor safety equipment, want of payment for
some time, dependence on employer for accommodation and on employer for employment, no means to leave the
United Kingdom and a contract which he criticises. He says that by the 20th June or subsequently, these matters
should have led to the view that the claimant potentially had been or had been at risk of being trafficked.

93. The difficulty for Mr Jones is that these matters cannot be divorced from their context and they do not produce
the picture he seeks to paint. The picture becomes more apparent when one looks at the sequence of events. I
had left matters with an email of 20 June when advice was sought from the operational advice and support unit of
the border force. That was a sensible step to take in respect of men said to have been abandoned, not coerced,
able to get food and drink from the seafarer's charity, in circumstances where lack of payment was explained by the
company operating the ship being dissolved.

94. At this point, I should mention the Immigration Act. Section 24(1)  of the Immigration Act provides that:

"A person who is not a British citizen shall be guilty of an offence ...

(b) if, having only a limited leave to enter or remain in the United Kingdom, he knowingly either ‑

(i) remains beyond the time limited by the leave; or

(ii) fails to observe the conditions of the leave;

(iii) if, having lawfully entered the United Kingdom without leave by virtue of section 8(1) [which enables a seaman
to arrive for the purpose of his ship being refitted or cargo being discharged so he can then go out again], he
remains without leave beyond the time allowed by section 8(1) ..."

95. Which is really to enable the ordinary circumstances of a ship to be attended to.

96. We know that he was cleared for entrance to join the ship and to work out of the United Kingdom. We know
that by section 8(1) which I rather crudely stated in terms of its effect as to what could happen, but we also know
that the ship was going nowhere and the claimant was still there on the ship in the United Kingdom. Accordingly, it
seems to me that it was perfectly reasonable to proceed on the basis that section 24 could be used.

97. Further, by paragraph 16 of schedule 2 of the Act:

"(2) If there are reasonable grounds for suspecting that a person is someone in respect of whom directions may be
given under any of [certain paragraphs which are then set out], that person may be detained under the authority of

an immigration officer pending ‑

(a) a decision whether or not to give such directions;

(b) his removal in pursuance of such directions."

98. Having stated that part of the legal background, I return to the sequence of events. On 24 June 2013, Mr
Anjasmoro was detained, and he was in fact given reasons for that detention through a document which I have at
page 552. This recorded, as was the case, that his removal from the United Kingdom was imminent, that he did not
have enough close ties, family or friends to make it likely that he would stay in one place once taken from the boat.
It is recorded that he had previously failed to comply with the conditions of his stay, temporary admission or release

‑‑ that reflects the fact that the boat had not left the port ‑‑ he had not produced satisfactory evidence of his identity,

nationality or lawful basis to be in the United Kingdom, and previously failed or refused to leave the United Kingdom
when required to do so.

99. On page 565, an immigration officer responded to an officer in Bangkok who had heard of these two
Indonesians being encountered in North Shields. The response to that officer thanked him for his email and said:


-----

"I was the immigration officer dealing with these persons following their arrest. Personally I believe this whole
problem is one which started with the UK owners of the vessel and potentially the crew having just been unwitting in
the affair. Likewise, it may be that the Indonesian agent is not fully aware of the circumstances surrounding the
seizure. Certainly the captain has not been very forthcoming. The Starward is an Irish vessel captained by Jerry
Laverty, currently berthed in North Shields having been seized by the admiralty on 19 April for reason being
unseaworthy. I have spoken to the local Fish Quay manager, Jerry Pritchard, and he informs me that the action
against the ship started with a writ, so potentially the owners were going into receivership but he couldn't be more
specific. It does however explain why the crew hadn't been paid for four months or fed! It also explains why the
local fishermen's mission were feeding the crew. Most recently a firm of solicitors had been in contact with Jerry
Pritchard asking if there were any outstanding debts or fees, so potentially the vessel maybe in the throes of
exchanging ownership, I don't know."

100. In response to that, it was said that:

"I think you [the author of the email to which I have just referred] are right. I think the agent in Indonesia were
probably unaware of the situation. From the information provided in the applications, the three Indonesians we
have here don't appear to be connected to the MV Starward. Thank you again for your help. Please contact here
in Bangkok if ever you require information or checks regarding Indonesia."

101. Matters then took a turn, because there appears to have been a telephone call about some 23, as it is put, like
cases of potentially trafficked fishermen. This arose from something which had happened in Scotland, and there
was concern in Scotland about them and it was thought there might be a connection. I pick the matter up again,
that concern having been expressed, on 27 June 2013, where matters are recorded in an email to this effect:

"Our ongoing inquiries, Operation Alto. We are dealing with a total of 23 victims."

102. Then they are identified in terms of nationalities, and then complaints which they have given are also
recorded: wages withheld, overwork, lack of adequate rest, lack of food, documents being withheld. From the
information provided, it says:

"It would appear that your four fishermen may have been subjected to similar conditions and may also be potential
victims of human trafficking. If these four fishermen are the victims of human trafficking, it will be necessary for any
police enquiry to carry out detailed interviews and recover any evidential documents, including their contracts of
employment to pursue any criminal cases. I appreciate these four fishermen are scheduled to leave the United
Kingdom tomorrow. However, you may wish to carry out further inquiries with them to establish whether they are
the victims of human trafficking before they are deported."

103. This appears to have been either the first or at least a very early suggestion or initial suggestion that anything
to do with trafficking arose in respect of the Claimant. Indeed, the evidence of Mr Lamb was to that effect, which I
accept, that there had been nothing to spring into mind or to bring forward the suggestion of potential for or actual
trafficking when this matter was considered on 20 June or when the detention began on 24 June.

104. Nonetheless, there then follows a sequence of emails which I am not going to travel through. However, on 27
June 2013, advice was given on how trafficking could be assessed. In this advice, reference was made to the
fishing vessel and it having been served as unsafe. It was advised that:

"It was not being said that these males should not be removed, but the question around the potential that they were
victims of trafficking should be explored."

105. Then various questions are posed as to the questions which might be asked.

106. I notice that the definition given of trafficking appears to accord with the interpretation which I have put upon
that definition, but that is rather a by the by observation. Interviews did in fact take place, and I have a record of
that interview which occurred on 4 July. I will just go through this interview. It was not a very long interview. Mr
Anjasmoro was asked the name of the boat, he was asked who the owner was. He was asked what type of fishing


-----

it engaged in, he was asked when it last completed a fishing trip, and he said four months ago. He was asked
about the accommodation and said it was always on the boat. He did not expect it to be otherwise. He was asked
about what payment for the work he was expecting:

"Answer: On the agreement I signed, supposedly 700 a month.

Question: Did you receive any payment?

Answer: Only it would be months.

Question: Who paid you?

Answer: The owner and the captain.

Question: Did you receive a reduction in your pay for accommodation and food?

Answer: After receiving two months of wages, the captain promised I would be paid.

Question: Who arranged for you to work on the boat?

Answer: IFF, Indonesian fishing federation.

Question: Who completed and submitted the visa application?

Answer: IFF.

Question: Did you voluntarily allow the captain to retain your passport when you were on the boat?

Answer: I kept my passport in my own bag.

Question: You have been read the definition of human trafficking and forced labour. Do you consider yourself to
have been trafficked into the United Kingdom?

Answer: No. I'm a professional but I am not satisfied with the situation. In other countries, the captain would be
punished and sent to prison.

Question: Do you want your circumstances to be referred to UK HTC?

Answer: In my heart, I haven't done anything wrong. Yes, I want it referred."

107. This led to further consideration in what is called a NRM referral. NRM stands for national referral mechanism
and is part of the means by which the competent authority, which can for our purposes be taken to be the Home
Office, assesses the possibility of trafficking. On 5 July, there is an email which records whilst these matters were

being considered that there is a two‑stage decision process:

"Stage one looks at acceptance or rejection of the NRM for progression. This can take a couple of working days to
conclude and a decision to be promulgated and served on the subject. Sharon confirmed that under policy,
detention can be maintained until the stage one decision is made. If the stage one decision is a positive one, that is
to say there is a case to answer, then the subject should be released from detention immediately and the NRM
progresses to stage two. If the stage one decision is negative, then detention can lawfully be maintained."

108. Stage two appears to be a substantive consideration of the claim.

109. Then a note dated 8 July records that a positive RG decision had been made following submission of NRM

attracting a 45‑day reflection period. The question was asked: "Do I need to arrange accommodation for the

victim?":


-----

"Where an individual is without accommodation, this will be arranged by the first responder either through existing
accommodation providers or by accessing the UK human trafficking centre who will arrange appropriate
accommodation. Once there are reasonable grounds to believe someone is a victim of trafficking, UK HTC should
be asked to ensure that accommodation therein is appropriate."

110. Consequently, such a decision having been made ‑‑ in other words that there was something here, if I can put

the matter crudely ‑‑ to be thought about so far as trafficking was concerned, immediate attempts were made to find

accommodation. Accommodation was secured on 11 July through the good graces of the Salvation Army, so 11
July ends any potential period of a false imprisonment claim.

111. I should here note that the case of _XYL v Secretary of State for the Home Department [2017] EWHC 773_
_(Admin) decides that a NRM referral does not require release from detention._

112. Accordingly, my analysis is that before, on and after 24 June, there was nothing to create a credible suspicion
that Mr Anjasmoro was or may have been a victim of trafficking. Accordingly, there was nothing to demand prior
authorisation of investigations that the arrest and detention were lawful and that the period of time until 11 July is
properly explained and entirely reasonable.

113. I should add that Mr Anjasmoro was interviewed on 8 August 2013. This casts some light on what the
position had been and differs in material ways from what he subsequently came to say. He was asked:

"Question: Did you apply for the job or did they recruit you?

Answer: I applied for it.

Question: Did you have any concerns about the job before you left Indonesia? Anything different from normal?

Answer: No, because it was not the first time. I had been used to it.

Question: What condition was the ship in?

Answer: The accommodation, normal. I don't want to say anything of complaint, but it's just normal. But to be
honest, compared to other ships, the standard was low.

Question: Did it appear seaworthy?

Answer: Yes, seaworthy.

Question: Did you have an adequate place to sleep?

Answer: Yes, I did have.

Question: Were you given enough food?

Answer: Well, I can say enough, but sometimes (Inaudible). I don't want to sound like I'm complaining.

Question: Did you eat together?

Answer: Yes, together.

Question: How many hours a day did you work?

Answer: From 12 noon until 11 pm at the mast maximum, sometimes until midnight.

Question: Did you have any days off?


-----

Answer: I get a day off when there's high wind. Even then I have to do the works at the docks, like repairing and
sewing the nets.

Question: Were you allowed to leave the dock and walk about freely?

Answer: Yes, we were given permission.

Question: Were you able to contact your family at home?

Answer: Yes, we have to do it at private cost with our own mobile.

Question: Do you remember when the ship last docked at South Shields harbour in Newcastle? Do you remember
when?

Answer: In the last month, I realised that the captain has problem with bank.

Question: When did you last see the captain? Do you remember when you last saw him?

Answer: When the police came to fetch me, the captain was on the ship until the end."

114. He was asked about the rates of pay and the normal amounts paid for the agency:

"Question: Is that the normal amount?

Answer: Yes, that's normal. In fact one year's contracts it's adequate to cover the fees.

Question: Is it a legal agency [the IFF]?

Answer: Yes, legal. It's not the first time I had a placement by the agents."

115. As it happened, the decision which came to be taken by the NRM is the surprising decision was that there had
been human trafficking. This of course in no way binds me, but requires a word of explanation. The evidence
about it was given by Beth Matthews. She recalled that on 5 July 2013, as I have already said, Mr Anjasmoro was
referred in to the national referral mechanism. She goes on to say that:

"The competent authority has five working days from the receipt of the referral to reach a decision. The timescale
impacts upon the amount of information that can be obtained prior to the RG decision."

116. RG stands for the reasonable grounds stage, that is to say the preliminary stage. There are three potential
outcomes she describes at that stage: person accepted as potential victim, person not accepted, decision
suspended.

117. After the reasonable grounds decision, the matter then has to be further considered. That is what took place.
Beth Matthews described that she was aware through contact that there were ongoing police investigations into
exploitation of overseas fishermen in Scotland, and there had also been contact with the police in Northern Ireland
where the vessel was registered. A conclusive grounds decision would only be suspended if the impact of such an
investigation would impact on the decision.

118. Then a detailed letter was received dealing with an employment tribunal complaint. Nonetheless, her decision
came to be made on 8 November 2013, and she records this:

"Competent authorities should consider whether on the balance of probability there is sufficient information to
conclude that the individual is a victim of trafficking. Balance of probabilities essentially means trafficking as
defined by the Convention is more likely than not to have happened. Decision maker should be satisfied that on the
evidence available, the event is more likely to have happened than not. This standard of proof does not require the
decision maker to be certain that the event did occur. My initial impression of the case was that while there were


-----

clearly trafficking indicators present, there was no clear evidence that coercion, deception or any other means were
used by Mr Laverty at the initial recruitment stage.

Mr Anjasmoro's account of how he obtained the contract did not seem untoward in light of his previous similar
contracts, although of course I am not suitably qualified to assess the legitimacy of employment contracts in any
country. While I have no doubt that Mr Anjasmoro has ultimately been exploited, the account would appear to
indicate this occurred as a consequent of the change in Mr Laverty's circumstances, and he subsequently breached
the contract. I believe Mr Laverty may have also have been living in the same conditions as Mr Anjasmoro at the
time of the initial encounter.

I therefore did not initially believe that Mr Anjasmoro had been recruited for the premeditated purpose of
exploitation. However, this was a very borderline case and UK HTC advocate a strong link for a positive conclusive
grounds decision with which I ultimately agreed."

119. I have a copy of that reasonable grounds consideration minute and have carefully considered it. The decision
taken cumulatively was that:

"There were considered to be reasonable grounds to suspect that the claimant was trafficked from Indonesia to the
United Kingdom [that is a potential victim of trafficking] for the purpose of forced labour. Furthermore, an account of
his current circumstances considers that the claimant requires the assistance and protection the Convention
affords. Consequently, a positive reasonable grounds decision has been made and PVOT [potential victim of
trafficking] is to be granted for a period of 45 days for recovery and reflection."

120. I have been in a position to receive evidence that has been tested. I have seen the claimant give evidence, I

have seen the claimant being cross‑examined. The matters of complaint about what happened are in truth limited.

The sequence is properly explained in the evidence of the Home Office which I have heard and considered. It does
not admit of the possibility that there was trafficking or that Mr Anjasmoro was or potentially was at risk of trafficking.
Accordingly, notwithstanding that subsequent consideration in the manner I have just described, I am clearly of the
view that this claim must fail for the reasons I have at some length given.

121. I should just add that questions of quantum were not considered before me and do not arise.

**WordWave International Ltd trading as DTI hereby certify that the above is an accurate and complete record of**
the proceedings or part thereof.

165 Fleet Street, London EC4A 2DY

Tel No: 020 7404 1400

Email: courttranscripts@DTIGlobal.eu

This transcript has been approved by the Judge

**End of Document**


-----

