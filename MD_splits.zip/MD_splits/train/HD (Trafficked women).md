# HD (Trafficked women) [2016] UKUT 454 (IAC)

Upper Tribunal (Immigration and Asylum Chamber)

Judge Coker, Judge Frances

17 October 2016Judgment

For the Appellant: Ms K. Cronin with Mr M. Moriarty and Mr B. Hashi, counsel instructed by Luqmani Thompson and
Partners, solicitors

For the Respondent: Mr S. Singh instructed by Government Legal Department

JUDGMENT: APPROVED BY THE COURT FOR HANDING DOWN (SUBJECT TO EDITORIAL CORRECTIONS)

JUDGE COKER:

**Introduction**

1. In this judgment, to which both members of the panel have contributed, the Upper Tribunal addresses the current
situation in Nigeria for victims of trafficking in order to determine the appeal of HD and to give guidance on the risk
of proscribed treatment for a Nigerian victim of trafficking. The matters in dispute between the parties are whether
and to what extent a victim of trafficking returning to Nigeria is able to access sufficiency of protection and the
consequential issue of internal relocation. The evidence concerning the trafficking process in the Nigerian context
either goes unchallenged or is acknowledged not to be in dispute.

2. This means that we can set out a relatively brief overview of matters not in dispute1 between the parties before
moving on to a consideration of the evidence that is in dispute between the parties, which requires a detailed
examination, in particular, of the significance of the NAPTIP evidence and the extent to which that evidence informs
assessment of risk on return for women who have been trafficked to the UK for the purposes of sexual exploitation
or for the purpose of domestic servitude.

3. Although victims of trafficking from Nigeria are male and female, adults and children, this judgment is specifically
concerned with adult women, who may have been trafficked as children, but are, at the date of their adverse
decision/appeal, adults. That is not to say that the guidance we provide is not relevant to girls, boys or men, but the
focus of this decision is adult women and, in this particular case, a woman trafficked whilst a child. We therefore
refer in this decision to victims of trafficking as “her”. We also observe that the majority of human beings trafficked
both within and transnationally from Nigeria are girls and women.

4. _PO (Trafficked women) Nigeria CG_ _[2009] UKAIT 00046 is the last country guidance case promulgated in the_
Upper Tribunal addressing the issues considered in this appeal. This was appealed to the Court of Appeal _(PO_
_(Nigeria) v SSHD_ _[2011] EWCA Civ 132; 22nd February 2011). Carnwath LJ [58] held that the general findings on_
the two main issues in PO (Nigeria) UKAIT should stand as interim guidance pending further consideration by the
Tribunal in either that case or another case. Those issues were set out in paragraphs 191 and 192:

“Ability and Willingness of the Nigerian Authorities to offer Protection to Victims of Trafficking

191. Our consideration of the background materials clearly demonstrates to us that in general the
government of Nigeria is both able and willing to discharge its own duty to protect its own nationals from
people traffickers In particular:


-----

(a) The Danish Information Service Report: The Protection of Victims of Trafficking in Nigeria: a Fact
Finding Mission to Lagos, Benin City and Abuja, 9/26 September 2007 (April 2008) points out that the
government of Nigeria have recognised the problem of traffickers and, since 2003, the legal and
institutional foundation for combating trafficking and, equally important, support for victims of trafficking,
have been in place in Nigeria.

(b) The National Agency for the Prohibition of Traffic in Persons and other related matters (NAPTIP) is the
principal organisation created by the Nigerian government to combat trafficking. The Trafficking in Persons
(Prohibition) Law Enforcement Administration Act, 2003 established NAPTIP and was enacted as a direct
result of Nigeria wishing to fulfil its international obligations under the Protocol to Prevent, Suppress and
Punish Trafficking in Persons, Especially Women and Children.

(c) NAPTIP's own Legal and Prosecution Department were said in the April 2008 report, to have concluded
six cases and another five were said to be pending. 58 victims of trafficking have been rehabilitated, while
another 24 were waiting rehabilitation. We accept that with more funds, NAPTIP could do more to help
victims, but the same could be said of any government agency with a finite budget.

(d) The US State Department Report suggests that whilst Nigeria is not complying with minimum
standards, it is "making significant efforts" to do so and has "demonstrated a solid commitment to
eradicating trafficking". It also spoke of NAPTIP making solid efforts to investigate and prosecute trafficking
cases, although the numbers of convicted traffickers remained low. There are clearly several reasons for
that, but not, on the evidence before us, any lack of governmental effort or desire.

Risk to Victims of Trafficking in being Re-trafficked on Return to Nigeria

192. It must be born in mind, however, that a claimant may still have a well-founded fear of persecution if
she can show that the Nigerian authorities know or ought to know of circumstances particular to her case
giving rise to his fear, but are unlikely to provide the additional protection her particular circumstances
reasonably require. To that end:

(a) A very careful examination of the circumstances in which the victim was first trafficked must be
undertaken and careful findings made. If a victim has been told that she is required to earn a particular sum
of money ("target earnings") for the trafficker or gang, before being free of any obligation to the trafficker or
gang, then, if the victim should escape before earning the target sums, there may well be a risk to the
victim that on return to Nigeria she may be re-trafficked if found. The extent of the risk of the trafficking will
very much depend on the circumstances in which the victim was originally trafficked.

(b) It must always be remembered that within Nigeria there are gangs of people traffickers operating who
generate enormous sums of money from their activities. The evidence seems to us to be clear that where a
victim escapes the clutches of her traffickers before earning the target earnings, then the traffickers are
very likely to go to extreme lengths in order to locate the victim or members of the victim's family, to seek
reprisals.

(c) In the absence of evidence that a trafficked victim has been trafficked by an individual, it should be
borne in mind that it is likely that the trafficking will have been carried out by a collection of individuals,
many of whom may not have had personal contact with the victim. Within trafficking gangs, individual
members perform different roles. One might, for example, be a photographer who takes the photograph
which is used within the victim's passport, whether or not the passport is a genuine one. One gang member
may, for example, be a forger who is involved in the preparation of false passports or other documents for
use by the victim; one might be a corrupt police official, or a border guard, whose role is to assist in
facilitating the victim's passage in some way. Gang members may perform any number of different roles
but it is essential to bear in mind that if a victim has been trafficked by a gang of traffickers, as opposed to
a single trafficker, then the risk of re-trafficking may be greater for someone who escapes before earning
the target earnings set by the trafficker, because the individual gang members will have expected to
receive a share of the target sum and will, therefore, be anxious to ensure that they do receive that share
or seek retribution if they do not.”


-----

5. This appeal comes before the Upper Tribunal because the decision of the First-tier Tribunal was found to
disclose material legal error and the decision set aside. The decision of the Upper Tribunal identifying the error of
law is attached as Appendix A.

6. The Appellant, HD, applied for asylum on 2nd January 2013. Her asylum claim was recorded as determined and
refused on 29 October 2014. She was granted leave to remain until 29 October 2015. The appellant appealed the
refusal of asylum under S83(2) of the Nationality, Immigration and Asylum Act 2002. Her appeal is limited to asylum
grounds.

7. HD's case was considered by a Competent Authority and for the reasons set out in the Conclusive Grounds
Consideration Minute dated 20 October 2014, it was concluded on the balance of probabilities that she had been
trafficked and she is therefore a victim of trafficking as defined by the Council of Europe Convention on Action
Against Trafficking in Human Beings.

8. HD attended the first day of the hearing. She was not required to give oral evidence, the factual matrix of her
claim being broadly accepted by the respondent – as to which see below. Her mental health was not, in any event,
such that it was likely that there could be oral evidence that would be of assistance to the Upper Tribunal.

**Asylum**

9. The respondent in the applicant's letter refusing to recognise her as a refugee, accepts that former victims of
trafficking are seen as a distinct group within Nigerian society and no distinction is made with regard to the type of
exploitation a former trafficked victim was subjected to. The respondent accepts that as a former victim of trafficking
her claim for asylum falls for consideration under the Refugee Convention as a member of a particular social group.

10. For the reasons set out below some young women who have been previously trafficked will face a real risk of
serious harm and being trafficked again from their home area.

11. The two issues of sufficiency of protection and internal relocation are pertinent to determine whether such an
individual will be at real risk of being persecuted.

**What is trafficking?**

12. Human trafficking is defined as:

“… the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use
of force or other forms of coercion, of abduction of fraud, of deception, of the abuse of power or of a
position of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of the
person having control over another person, for the purpose of exploitation. Exploitation shall include, at a
minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or
services, slavery or practices similar to slavery, servitude or the removal of organs.2”

13. It is uncontroversial that the essence of trafficking is that the victim is coerced or deceived into a situation in
which they are exploited. There are 3 elements3:

(a) an action – the person has been subject to the act of recruitment, transportation, transfer, harbouring or
receipt – which is achieved by

(b) a means – the threat or use of force or other forms of coercion, abduction, fraud, deception, abuse of
power, abuse of a position of vulnerability, or of giving or receiving of payments or benefits to achieve the
consent of a person having control over another person – for the purpose of

(c) exploitation - sexual exploitation, forced labour or services, slavery or practices similar to slavery,
servitude, forced criminality or the removal of organs.

14. The UNODC 2013 Paper 'Abuse of a position of vulnerability and other “means” within the definition of
trafficking in persons' 2013 states that:


-----

    - The concept of trafficking does not just refer to the _process by which an individual is moved into a_
situation of exploitation. It extends to include the maintenance of that person in a situation of exploitation.

     - Trafficking can take place within as well as between countries, and for a range of exploitative purposes
including, but not limited to sexual exploitation and exploitative labour.

15. Abuse of a position of vulnerability is cited in the Palermo protocol in the list of means through which individuals
can be subjected to a range of various actions for exploitation. There is a distinction between vulnerability as
susceptibility to or “abuse of a person's vulnerability” trafficking and abuse of vulnerability as a means by which
trafficking occurs or is made possible. The UNODC 2013 paper considers trafficking and the concept of
vulnerability:

“….. vulnerability is central to how trafficking is understood……In the context of trafficking, “vulnerability” is
typically used to refer to those inherent, environmental or contextual factors that increase the susceptibility
of an individual or group to being trafficked. These factors are generally agreed to include human rights
violations such as poverty, inequality, discrimination and gender-based violence - all of which contribute to
creating economic deprivation and social conditions that limit individual choice and make it easier for
traffickers and exploiters to operate. More specific factors that are commonly cited as relevant to individual
vulnerability to trafficking (and occasionally extrapolated as potential indicators of trafficking), include
gender, membership of a minority group, and lack of legal status…..

"2.1.2 A distinct but related concept: abuse of vulnerability as a means of trafficking.

….This distinction is important…”

16. The UNODC 2013 paper refers to the Commentary to the Council of Europe Convention against Trafficking in
Human Beings 2005 (“European Trafficking Convention”) and the EU Trafficking Directive 2011/36/EU which
explains the term abuse of vulnerability:

“.. the vulnerability may be of any kind, whether physical, psychological, emotional, family-related, social or
economic. The situation might, for example, involve insecurity or illegality of the victim's immigration status,
economic dependence or fragile health. In short the situation can be any state of hardship in which a
human being is impelled to accept being exploited. Persons abusing such a situation flagrantly infringe
human rights and violate human dignity and integrity, which no-one can validly renounce.”

17. The IOM 2015 Report Enhancing the Safety and Sustainability of the Return of Victims of Trafficking draws
together a number of statistical estimates from various international bodies including the International Labour
Organization which estimated in a report published in 2012 that the numbers of forced labour victims worldwide was
as many as 20.9 million at any given point of time during the period 2002 to 2011, 90% were exploited in the private
sector and the remaining 2.2 million by States or rebel armed forces. The ILO identified forced labour as being the
most common form of trafficking (68%) followed by forced sexual exploitation (22%). The United States Department
of Security July 2015 report identified 44,462 victims of trafficking in 2014. According to the Eurostat 2015 working
paper on Trafficking in Human Beings (in Europe), 30,146 victims were registered over the three year period 2010 2012 of whom over 80% were women and girls. 35% of the total were non EU nationals who came mainly from
Nigeria, Brazil, China, Vietnam, The Dominican Republic, Ukraine, Morocco and to a lesser extent Albania. The
report stresses that the size and scope of trafficking is still a “matter of estimation” and that greater efforts are
required to establish a standardised global data collection system. The Cherti Report records that Nigeria “is now
ranked as the top sending country to the UK according to NRM data.”

18. A 2003 paper by Louise Shelley, the director of Transnational Crime and Corruption Centre, on 'Trafficking in
Women: the Business Model Approach' refers to the growth of sexual trafficking in the previous decade and, on the
basis of analysis of government reports, interviews with law enforcement personnel and academic sources, she
identified six different models of business operating in the trafficking area. Each of these models was associated
with a different national group and, she states, reflects deep historical influences, geographical realities and the
market forces that drive the trade. She does not claim that the models fit every crime group from a particular region
but identifies them as a means to categorise the business of human smuggling and trafficking.


-----

19. The Europol 2016 report also refers to the wide range of other offences carried out by organised crime groups
where the trafficking process is the core activity. These are not merely the offences which support the exploitation
but for example include drug production, property crimes, benefit fraud. According to the Europol 2016 Report the
most commonly reported type of exploitative situation across Europe (not just Nigerians), is for sexual exploitation
followed by labour exploitation. During 2013-2014 Europol records that 90% of all communications from Member
States received by them were for sexual exploitation and 5.6% concerned labour exploitation. The remainder were
forced sham marriages and forced criminality; the majority were women; 1.9% were underage.

20. As stated in the Europol 2016 Report, although human smuggling and human trafficking share similar patterns,
they are differentiated by precise legal definitions. A crucial legal distinction between the two offences revolves
around the issue of consent: a victim of human trafficking might have consented to their transportation to a new
destination but this initial consent becomes legally irrelevant as the trafficker starts to use threats, coercion,
deception or fraud in order to exploit the victim.

21. The UNHCR has published Guidelines on International Protection (7 April 2006) on the application of Article
1A(2) of the 1951 Convention and 1967 Protocol relating to the Status of Refugees to victims of trafficking and
persons at risk of being trafficked. The Tribunal was referred in particular to the following lengthy extract from those
guidelines, which we reproduce because we consider them to be of significance, although of course aware that they
are not determinative4:

“10. An important aspect of this definition is an understanding of trafficking as a process comprising a
number of interrelated actions rather than a single act at a given point in time. Once initial control is
secured, victims are generally moved to a place where there is a market for their services, often where
they lack language skills and other basic knowledge that would enable them to seek help. While these
actions can all take place within one country's borders, they can also take place across borders with the
recruitment taking place in one country and the act of receiving the victim and the exploitation taking place
in another. Whether or not an international border is crossed, the intention to exploit the individual
concerned underpins the entire process.

…..

16. In cases where the trafficking experience of the asylum applicant is determined to be a one-off past
experience, which is not likely to be repeated, it may still be appropriate to recognize the individual
concerned as a refugee if there are compelling reasons arising out of previous persecution, provided the
other interrelated elements of the refugee definition are fulfilled. This would include situations where the
persecution suffered during the trafficking experience, even if past, was particularly atrocious and the
individual is experiencing ongoing traumatic psychological effects which would render return to the country
of origin intolerable. In other words, the impact on the individual of the previous persecution continues. …

17. Apart from the persecution experienced by individuals in the course of being trafficked, they may face
reprisals and/or possible re-trafficking should they be returned to the territory from which they have fled or
from which they have been trafficked. Reprisals at the hands of traffickers could amount to persecution
depending on whether the acts feared involve serious human rights violations or other serious harm or
intolerable predicament and on an evaluation of their impact on the individual concerned. Reprisals by
traffickers could also be inflicted on the victim's family members, which could render a fear of persecution
on the part of the victim well-founded, even if she or he has not been subjected directly to such reprisals. In
view of the serious human rights violations often involved, as described in paragraph 15 above, retrafficking would usually amount to persecution. In addition, the victim may also fear ostracism,
discrimination or punishment by the family and/or the local community or, in some instances, by the
authorities upon return. Such treatment is particularly relevant in the case of those trafficked into
prostitution. In the individual case, severe ostracism, discrimination or punishment may rise to the level of
persecution, in particular if aggravated by the trauma suffered during, and as a result of, the trafficking
process. Where the individual fears such treatment, her or his fear of persecution is distinct from, but no
less valid than, the fear of persecution resulting from the continued exposure to the violence involved in
trafficking scenarios. Even if the ostracism from, or punishment by, family or community members does not
i t th l l f ti h j ti b d i l ti f i l t t k i f t


-----

heighten the risk of being retrafficked or of being exposed to retaliation, which could then give rise to a well
founded fear of persecution.

…

21. There is scope within the refugee definition to recognize both State and non- State agents of
persecution. While persecution is often perpetrated by the authorities of a country, it can also be
perpetrated by individuals if the persecutory acts are “knowingly tolerated by the authorities or if the
authorities refuse, or prove unable to offer effective protection”. In most situations involving victims or
potential victims of trafficking, the persecutory acts emanate from individuals, that is, traffickers or criminal
enterprises or, in some situations, family or community members. Under these circumstances, it is also
necessary to examine whether the authorities of the country of origin are able and willing to protect the
victim or potential victim upon return.

22. Whether the authorities in the country of origin are able to protect victims or potential victims of
trafficking will depend on whether legislative and administrative mechanisms have been put in place to
prevent and combat trafficking, as well as to protect and assist the victims and on whether these
mechanisms are effectively implemented in practice…

23. Many States have not adopted or implemented sufficiently stringent measures to criminalize and
prevent trafficking or to meet the needs of victims. Where a State fails to take such reasonable steps as
are within its competence to prevent trafficking and provide effective protection and assistance to victims,
the fear of persecution of the individual is likely to be well-founded. The mere existence of a law prohibiting
trafficking in persons will not of itself be sufficient to exclude the possibility of persecution. If the law exists
but is not effectively implemented, or if administrative mechanisms are in place to provide protection and
assistance to victims, but the individual concerned is unable to gain access to such mechanisms, the State
may be deemed unable to extend protection to the victim, or potential victim, of trafficking.

…

27. The circumstances in the applicant's country of origin or habitual residence are the main point of
reference against which to determine the existence of a well founded fear of persecution. Nevertheless,
even where the exploitation experienced by a victim of trafficking occurs mainly outside the country of
origin, this does not preclude the existence of a well-founded fear of persecution in the individual's own
country. The trafficking of individuals across international borders gives rise to a complex situation which
requires a broad analysis taking into account the various forms of harm that have occurred at different
points along the trafficking route. The continuous and interconnected nature of the range of persecutory
acts involved in the context of transnational trafficking should be given due consideration. Furthermore,
trafficking involves a chain of actors, starting with those responsible for recruitment in the country of origin,
through to those who organize and facilitate the transport, transfer and/or sale of victims, through to the
final “purchaser”. Each of these actors has a vested interest in the trafficking enterprise and could pose a
real threat to the victim. Depending on the sophistication of the trafficking rings involved, applicants may
thus have experienced and continue to fear harm in a number of locations, including in countries through
which they have transited, the State in which the asylum application is submitted and the country of origin.
In such circumstances, the existence of a well-founded fear of persecution is to be evaluated in relation to
the country of origin of the applicant.”

22. This, in our view, is a useful and helpful distillation of the characteristics and consequences of human trafficking.
As we shall see, there is not a single model of the process of trafficking. Indeed, there are endless permutations of
the process, but all of those disclose certain common characteristics, including recruitment, transfer, harbouring and
receipt in the place of destination. That process is facilitated by either force and coercion or deceit, both involving a
lack of truly voluntary involvement by the victim, followed by a form of exploitation.

**What are the characteristics of trafficking in a Nigerian context?**

23. The IOM 2006 report identifies that early Nigerian emigration to Italy in the 1980s was not dominated by
prostitution and those who subsequently worked as prostitutes did so independently As it became more expensive


-----

financially to travel, so loans were taken out; initially from friends and family but gradually individuals became more
indebted to a sponsor – thus laying the foundations for trafficking based upon a strong pact.

24. Essential to any reliable assessment of risk on return for victims of trafficking is a correct understanding of the
nature and dynamics of the trafficking process in the Nigerian context. The overview that follows is drawn from the
written and oral evidence of three expert witnesses and a large body of documentary evidence. Those expert
witnesses, the Rev Dr Carrie Pemberton-Ford, Dr Roxanne Agnew-Davies and Mr Andrew Desmond each
responded in writing to questions asked of them by the respondent. We also received a written report from the late
Mrs Bisi Olateru-Olagbegi. We have regard to that report also but also note that, unlike the other witnesses, the
Tribunal does not have the benefit of her answers to written questions raised upon her report by the respondent
nor, of course, the benefit of receiving oral evidence from her. None of those who gave oral evidence professed that
they were “country experts”. But plainly each was an expert in their own field. Full details of their professional
expertise and experience are set out in Annex 1; no issue was taken concerning their evidence by the respondent
save as set out below.

25. The Shelley report describes Nigerian organised crime groups as multifaceted crime groups in which the trade
of women is only one part of their criminal activities. She refers to female recruiters who conclude contracts with
girls and women by manipulating voodoo traditions and forcing compliance through psychological as well as
physical pressure. She describes Nigerian traffickers as very effective because they combine the best of both
modern and older worlds by allying sophisticated forms of modern technology to tribal customs. Referencing an
IOM 1996 report on the Trafficking of Women to Italy for Sexual Exploitation she identifies the significant financial
resources gained as seen in the tremendous rise of African trafficking, particularly to Europe, since the late 1990s.
She states that small amounts of the profits are returned to the local operators of the crime groups and occasionally
to family members of the girls and women but much of the profits go to other illicit activities and are laundered.

26. It is uncontroversial, and not surprising, that the actual numbers of women and girls trafficked into domestic
servitude and/or sexual exploitation is unknown as is the numbers of returned trafficked victims. To a large extent
this reflects the nature of human trafficking: the hidden criminality from the perspective of the victim, her family and
the traffickers. But, as referenced in the CORI report 20125, in 2010 the humanitarian news and analysis service of
the UN Office for the coordination of Humanitarian Affairs, the _Integrated Regional Information Network (IRIN)_
referred to over 4000 (Nigerian) victims being intercepted between 2004 and 2009 with the numbers rising each
year according to NAPTIP.

27. Nigeria is a source, transit and destination6 country for women and children subjected to domestic servitude
and trafficking for sexual exploitation. Nigerian trafficking victims are recruited mainly from rural and to a lesser
extent urban areas and that:

“Despite the scale and volume of human trafficking originating from Nigeria, a significant proportion of it is
a highly localised phenomena. In particular, research has indicated that victims who are trafficked to
Europe (including the UK) disproportionately originate from the state of Edo in the south central part of the
country….The United Nations Office on Drugs and Crime and the Nigerian National Agency for the
Prohibition of Traffic in Persons report7 that well over ninety per cent of victims rescued from human
trafficking for the purpose of sexual exploitation who are discovered outside of Nigeria are from Edo
State”.8

28. The remaining women and children are from Delta, Kano and Borno States2. The IOM 2006 report which found
that of 800 women returned to Nigeria during 1999 – 2001 from Italy 86% came from Edo State and a further 7%
came from neighbouring Delta State. Women and girls are recruited for domestic servitude or sexual exploitation;
they are taken from Nigeria to other west and central African countries and to Europe. Mr Desmond investigated a
large Nigerian OGN involved in trafficking for sexual exploitation. He identified various different roles as follows:

    - Recruitment;

     - Performing a ritual ceremony (juju/voodoo);

     - Training in carrying out sexual acts;


-----

     - Training of the “legend”: the account to be given to the immigration authorities on arrival into the UK;

     - Instructions on what to do once accepted into the asylum process in the UK;

     - Organising the journey/trafficking out of Nigeria to the UK which according to accounts given by victims
involved corrupt airport or immigration staff in Nigeria;

     - Reception in the UK and exploitation in the UK;

     - The reselling to another cell or trader in mainland Europe.

29. The Europol 2016 Report, along with other primary, secondary and tertiary research documents before us with
specific reference to Nigeria, generally corroborate Mr Desmond's evidence to the effect that, in his experience,
victims of trafficking and suspected traffickers generally share nationality, ethnic ties and sometimes kinship links. In
Nigerian OCNs, women, unusually, play a central role in the process of exploitation. The Freedom House, Freedom
in the World 2016: Nigeria Report refers to Organised Crime Groups being heavily involved in human trafficking.

30. The Danish Report and subsequent reports including the Finnish Report and Europol 2016 Report state that:

    - Cross border trafficking usually involves a criminal group and is highly organised; the degree of
organisation may be dependent upon the size of the operation and the number of women an organisation
is moving and managing; by its very nature, transnational trafficking is complex and requires many
collaborators who perform different criminal acts – it is “virtually impossible”10 for one individual to
singlehandedly undertake such transactions; “… it needs careful planning, a sophisticated level of
organisation and the engagement of several individuals (often located in different sites and with different
tasks)11”; “ …[traffickers] operate through structures and connections which are entirely unique and
therefore have none of the weakness of other organized criminal networks; thereby making them almost
impossible to eliminate completely12”; “… [cross border trafficking] is highly complex, involving a large and
diverse range of people… most trafficking was undertaken through informal arrangements and done by
individuals known to and, in many cases, related to the trafficking victims and their life in Nigeria or were
part of their immediate family (such as a parent or husband). Just under three-quarters (72%) of victims
were recruited by someone they or their family knew well13.”

    - Each element is undertaken by individuals or small groups of individuals able to operate independently
while using an extensive network of personal important contacts across the EU: those who recruit or
procure; those responsible for smuggling and transport; those providing documentation; those seeking to
corrupt law enforcement/border controls; those involved in the provision, management and control of safe
houses; owners of premises or properties where victims are exploited (e.g. bars, hotels, etc.); those
involved in the collection, delivery and distribution of the profits; those knowingly involved in money
laundering/management of assets and proceeds of crime; complicit legal officers and legal service
providers.

    - They are particularly proficient in using fraudulent educational, business and tourism visas or
genuine/lookalike/stolen passports, and often abuse the asylum system to facilitate their victim's entry into
the EU. Nigerian women often called madams or mamas also play important roles in the exploitation
process and some of them supervise the entire trafficking process. They engage in exploitation for
economic gain. They manage victims' movements, debt and other logistical tasks, sometimes supported
by a male driver and/or a warder. African victims often do not see themselves as exploited but rather as
migrants who must repay their transportation and harbouring costs; they are prone to support or form an
alliance with their offenders. This often results in victims being reluctant to cooperate with law enforcement.
Nigerian networks often involved in trafficking in human beings are usually not active in other types of
crime.14

    - Nigerian organised criminals are a prime example of organising according to a network model – although
central persons in Nigerian networks are persons with special skills who have nurtured important contacts
(e.g. with the public officials), or have taken the initiative to gather a small group of people to organise
criminal activities and may have great influence they rarely command a clearly structured organisation.
Short term alliances are formed for specific projects and the network as such is in constant change The


-----

loose organisational form of the Nigerian networks is often very efficient and makes it more difficult for the
police to fight crime. Firstly, the central persons are less visible than in other groups…. Secondly, the
effect of putting the central person in a network out of action is not necessarily too great. While hierarchical
groups may tumble like a house of cards, the Nigerian groups rapidly restructure into new constellations
(Europol, 2003: United Nations Office on Drugs and Crime, 2002). In the Netherlands, for instance, it has
been observed arrests of a relatively high number of traffickers have not had any visible effect on the
number of Nigerian prostitutes in the country15.

31. This documentary evidence supported Mr Desmond's evidence that there was a difference between an
Organised Criminal Group (“OCG”) and an Organised Criminal Network (“OCN”): an OCG is a group of individuals
who regularly worked together in persistent criminality in a particular area causing significant harm to the
community or of cross border concern. Each member of an OCG would know who the other members of the group
were. A number of separate OCGs are linked together by a network of communication (OCN) and only one or two
members of an OCG would know the identity and contact details of another OCG. This, Mr Desmond said, ensures
the safety and security of each OCG in the event of arrest or disruption by a law enforcement agency. The loose
and fluid structure of networks (as oppose to groups) was identified by Mr Desmond and corroborated by the
Finnish report and referred to by Campana16 .

32. The Finnish Report reviewed existing significant country information and the structure of Nigerian human
trafficking networks. As with the other documentation before us17 the report identified that there was considerable
variation in the type, size and organisation of the groups or networks and this may be dependent upon the size of
the operation, the number of women being trafficked, the financial strength of the groups and how well-connected
they were with officials.

“Some groups operate a loose network using mostly family members to recruit victims. Others are well
structured; right from recruiting and travel agents to the law enforcement agencies, professional forgers,
financiers and exploiters.

Prominent players in Nigerian human trafficking possess specific skills, have cultivated important contacts
with officials, for instance, or have themselves brought together a network organising human trafficking.
They may exercise a great deal of influence in the network but the network rarely is structured. As
temporary networks are formed around specific projects and their composition changes constantly…… A
loose and flexible structure often makes the network very effective and, at the same time, more difficult for
the police to disperse. It may be hard to identify the key players and their elimination from operations does
not necessarily have a sufficient impact on the operational capacity of the network as the networks reform
themselves quickly. The key to the effectiveness of the networks is their ability to operate independently
while drawing on an extensive network of personal contacts”

33. Mr Desmond confirmed his opinion that there could be a difference between OCGs concerned with trafficking a
domestic servant and those trafficking victims for sexual exploitation because to supply a domestic servant to a
family in Europe it was possible to send her as part of the family unit.

34. Campana concludes that although commonly referred to as 'Nigerian' trafficking, in reality the ring included a
number of different nationalities and that kinship did not appear to play a key role. The average age of the offenders
was relatively high (34 years old) indicating it was a business like enterprise and not a youth gang and that there
was no violence associated with interactions between offenders at the various trafficking stages. Campana
considers the coordination of work amongst traffickers. He argues that keeping transportation and exploitation
separate decreases the overall monitoring costs. The files reviewed for the purposes of his research offer evidence
of five distinct strategies adopted by madams to monitor the victims and increase their compliance: the use of force
(limited in the cases under scrutiny); the alignment of incentives between madams and victims' families (families
back home may receive a financial benefit from the work of their daughter and so may have an incentive to
pressure their daughter to comply with the madam's orders); hostage-taking strategies whereby family members in
Nigeria can be used as a target for retaliation; voodoo rituals (contracts are often signed before a pastor who
performs rituals to sanction the agreement such rituals usually being performed in Nigeria before the journey
begins) and finally direct monitoring for example sharing the same house.


-----

_Domestic exploitation_

35. The paper by Ellis T, Akpala J “Making sense of the relationship between trafficking in persons, human
smuggling, and organised crime: the case of Nigeria” published in The Police Journal 84(1), March 2011
considered the background and context to human trafficking and smuggling in general and developed a model of
the relationship between trafficking, smuggling and organised crime. The writer considered existing documentary
evidence, contact with the UK Home Office and also undertook a small exploratory study with Nigerian law
enforcement officers. The article reports that

“According to the Home Office, domestic servitude is a key driver of demand in the trafficking of children
and young women. Any deception is based on similar promises to those outlined above [working in
restaurants, domestic work, childminding, accountancy, promise of education or training opportunities],
but, on arrival, the migrants are put to work in a house and usually never allowed out. They will have no
documents and many are also regularly physically, psychologically and sexually abused, not paid, and may
be compelled to work long hours without rest….. There is a grey area between prostitution and domestic
servitude, with many of the same types of abuse taking place. Indeed, commodification and the adaptability
of traffickers means that there is some fluidity between these two markets, and more research is needed
into the forced career path of children who are initially trafficked for domestic service, but may later be
moved into prostitution.”

36. Cherti distinguishes between trafficking for domestic servitude in the UK and sexual exploitation. In domestic
servitude cases he draws attention to the experiences of victims of domestic servitude involving a

“challenging intersection of extreme abuse with apparent normality. Exploiters in the UK may be apparently
respected members of the community, employed in a professional capacity, including in our sample people
employed as an embassy worker, social worker or teacher, locally known and with strong ties to respected
institutions such as the neighbourhood church.”

He says a striking proportion of the exploiters in the UK appear to be ordinary citizens rather than professional
criminals. He refers to instances

“where the victim was transferred from one country to the other to be exploited by the same family,
showing the importance of mobile diaspora networks in the practice. In these cases, when the sender was
not a parent but an employer in Nigeria or a 'friend' of an orphaned victim, the nature of the trafficking
seemed to be a more opportunistic transaction between them and the receiver in the UK, or one born out
of a specific economic circumstance or immediate need at that time, rather than a pattern of trafficking and
abuse.”

…

And

'Personal Traffickers' (parents, family contact or employers):

Many people particularly those trafficked for domestic servitude were trafficked by someone intimately
known to them. These traffickers appeared not to be responsible for trafficking multiple victims; rather they
would be involved in the trafficking of one person. The mechanisms for this could vary: several
respondents gave accounts of the relative or their employer in Nigeria sending a request back for a
domestic worker, or of an associate visiting the family household and promising to take the victim to a
better life in the UK. These traffickers were mainly involved in trafficking for domestic servitude.

'Personal' linking traffickers, (family friends, relatives or associates):

In a small number of cases personal traffickers would appear to be involved along with others. Friends or
relatives would be involved at the stage of recruitment and migration, however the exploiter would be
unknown to the victim. Even in these cases the number of people involved appears to be small and the
work of the trafficker to be opportune, taking the opportunity to exploit a relatives need for support rather
than systematic or a pattern of repeat behaviour Among respondents these included not only relatives


-----

but also in at least one instance old school friends, possibly former victims who had moved on to
recruitment themselves.

37. Mr Desmond also investigated networks/groups associated with domestic labour trafficking. There is, he said, a
greater police focus on these groups now. Young girls are, he said, trafficked into the UK as domestic workers by
individual traffickers who may be related to, or are the current employer of, the trafficked child/young person
whereas others are brought in by criminal networks. He said that, as with trafficking for sexual exploitation, several
people would be involved in domestic worker trafficking. He described the pattern as follows:

“… the family in the UK who wish to obtain the services of a domestic worker would have to advertise that
fact by making contact with someone in Nigeria. The victim will have been identified by someone within the
community and the family approached by the recruiter. Some form of payment will be made to the family in
order to encourage them to hand over their child…the recruiter will then need to obtain birth registration
and travel documents to facilitate that victim travelling to the UK. This may involve the services of another
person who has the skills or connections to obtain official documents with false details or a forged or
adapted passport….the original recruiter may escort that victim into the UK or it may involve an additional
person. These individuals would form an OCG. Depending on the regularity and number of times this OCG
arranged trafficking – they could also be characterised as an OCN.”

38. The Rev Dr Pemberton-Ford's evidence from a conversation she had with the director of Edo State Market
Women's Association, with victims in the UK and from what she had learnt from discussions in wider church circles
in the UK, was that there were people known to those in the church who could access cheap labour; it was possible
to obtain a domestic servant in the UK. Mr Desmond related a conversation he had at a meeting in the House of
Commons about domestic servitude when he was told that having a 'house girl or boy' to do the domestic chores
was

“equal to having the latest washing machine or dishwasher. It was a 'must have' to enforce one's standing
within the community.”

39. Mr Desmond's evidence was very clear that a person who wanted a domestic servant would 'pay on delivery';
the traffickers would have their profit on delivery and the deal was complete when the victim was sold to the person
in the UK. Trafficking for exploitation was, he said, different because the victim paid off her debt as she was paid for
her services. He also referred however to a continuing interest in someone trafficked for domestic servitude to the
extent that if a domestic servant ran away there may be some form of retribution from the employer either to the
trafficker or to the victim's family because the 'deal' had failed. In view of the conclusions that follow, it can be seen
that this view concerning retribution does not sit comfortably with the evidence considered as a whole, although it
seems reasonable to conclude the extent of or existence of any retribution would depend upon the extent and
nature of the 'employer's' contacts.

40. Mr Desmond was aware of cases where the employer's wife turned the victim out on the street where they
could fall into the hands of other exploiters or be re-trafficked. This could occur when the domestic servant became
of an age where she was attracting the attention of male members of the household or was failing in her duties.
Although there may be a transition into sexual exploitation such transition was 'domestic' and was not the purpose
of the initial trafficking. A professional household may not have connections or know an OCG or someone in an
OCG so it was more likely that they would just 'kick the victim out on the street'. If someone had been brought here
for the purpose of sexual exploitation, then the employers would, he said, know an OCG and have the necessary
contacts.

41. The Rev Dr Pemberton-Ford's evidence regarding domestic servitude was not as clear as that of Mr Desmond
or the documentary evidence before us. She appeared to be saying that those trafficked into domestic servitude
could move into being sexually exploited but she did not appear to make any distinction between those trafficked for
the purpose of domestic servitude and those trafficked for the purpose of sexual exploitation. She referred to the
possible sexual exploitation of domestic servants and said

“….. because of the fluidity of sexual exploitation and domestic servitude, what was in the mind of the
person who wanted the product meant that the fictive debt could be run out at a greater level ”


-----

When asked to explain this she said

“it was important to look at Campana and the business model set out therein. It was difficult to look at
management and who was managing recruitment and there was little understanding about how the
payments were made, the debt was fictive. Transnational movement was dangerous for most organised
criminal gangs or organised criminal networks; therefore who enforced payment of the debt was unknown.
It depended on the management structure of any particular group.”

42. She was asked who was making money from the servant and she stated:

“If the sponsor model was considered then the trolley was paid immediately, but the overall debt was held
by the sponsor… “it would take longer for domestic servitude, but the Sponsor would get the lion's share of
the profit”.

She did not

“know how a recruiter was paid except that the lesser jobs were paid off first. It was not possible to say
how complex the sponsor situation was and there was a need to look at the OCG and whether the sponsor
was in fact part of the group, but the group was fluid especially the trolleys who were financially paid. The
roles of the sponsor and the recruiter could be complex and it was a very dynamic relationship. The
sponsor was not always the same as the consumer. Chasing the money assisted but it did not always
indicate who was the sponsor”.

43. She said that the pattern described by Campana (who was describing sexual exploitation in Italy) was the same
pattern in the UK; domestic servitude was not separate from sexual exploitation. The debt was owed by the victim,
therefore if the victim did not fulfil their contract there would be reprisals. It was not relevant, she said, how much
the consumer paid.

44. Dr Agnew-Davies, in her evidence derived from her fact-finding trip in 2011, referred to conversations she had
with medical staff in hospitals and shelters in Lagos and Benin City: “Even though many of the staff do not like
trafficking they still utilise it. House workers were very common and most workers had one especially if they were
junior in their work and had a baby. The child would be brought in and the agent would be paid for the whole year.
The child would not be sent to school and they were abused. A lot of the children had behavioural or emotional
problems and may still be wetting the bed at 13 and 14 years of age. If this happened the child would simply be
replaced by the trafficker and no further payment would be made”.

_Sexual exploitation_

45. According to Cherti, sexual exploitation:

“… can involve a wider network involving pimps and madams. Some victims reported working in a brothelstyle set-up with other young women, in the majority of cases the victim was either exploited informally by a
man and his friends or sold to other men alone from a flat or the trafficker's home. Strangers, often
'professional' traffickers, played a much larger role among respondents in recruitment for sexual
exploitation. Having accompanied victims to the UK, the trafficker would typically either exploit the victim
directly themselves or leave them with a partner who would then manage the victim…. Whether these
traffickers were working alone or as part of a broader criminal organisation is not easy to discern. There
were signs of integration and coordination between people in the two countries: This included attacks on
family members or returned victims. There were also incidents of victims being transferred to another
exploiter or sent and received by different traffickers in Nigeria and the UK. Rather than necessarily
suggesting a trafficking 'production line', the existence of criminal networks beholden to the trafficker could
also be because the trafficker was seen to be powerful. Many victims of sexual exploitation met only one or
two traffickers throughout their exploitation.”

And he identifies professional traffickers as:


-----

“Typically these approach victims or their families with offers of facilitating travel abroad. In many cases
they are strangers, unknown to the family and are able to link in with networks or exploiters in Europe. In
this scenario, when the victim or their family is approached by a stranger, there may be no direct social
link. Rather than trafficking in an opportune way preying on someone within their social network to exploit
them for their own gain, there was evidence of people targeting vulnerable people. For example, recently
orphaned girls through schools, homeless shelters, on the streets or directly from prison. Sensing the
desperation of their victims they would then promise them the possibility of employment or education in
Europe.”

46. Whilst working in the anti-trafficking unit Mr Desmond said it was rare to find Nigerian victims trafficked for
sexual exploitation in London brothels; they were kept in and worked from private homes. In his view, drawing upon
his experience, Nigerian victims were “often moved on to other European countries with fewer restrictions on street
prostitution.”

47. Mr Desmond's evidence was that it was possible to get a domestic servant package and it was also possible for
a victim to be brought in and held for a period to be indoctrinated and then sold on3. There might be a time when
females were brought into the UK and there was a need to find a buyer. He gave an example of one of the
traffickers he had investigated which had led to a successful prosecution: girls were advertised on the internet, the
trafficker had photos of all his victims including of the 14 year old girl who did his chores and his cooking, whom he
then sold after she had been repeatedly raped. But he reiterated that there was a distinction between domestic
servitude and sexual exploitation.

48. Mr Desmond's opinion from his investigations and talking to victims was that whether the victim came to the UK
for domestic servitude or sexual exploitation depended on her age and experience and also whether she was a
virgin.

“She needed to be broken into the art of carrying out a sex act. A trafficker would not want to sell a person
without experience. So it may be that if a victim came into a household, those who were brought here as
virgins, were then raped and indoctrinated.”

49. He said it was usual to expect a victim to undertake domestic work in Nigeria whether they were being trafficked
for sexual exploitation or not; domestic servitude would be ancillary to the primary purpose. If not already groomed
for sexual exploitation in Nigeria, she would be groomed in the UK.

50. There were cases where a person was brought in for domestic servitude but the person who had bought her
decided that s/he wanted to get her/his money back and therefore would sexually exploit her, or s/he had
connections to sell her on.

51. Mr Desmond said he had not come across any cases where an individual was brought in for domestic servitude
and was then returned to the traffickers for sexual exploitation some years later. He said that it may be that a
person brought in for domestic servitude would subsequently be sexually exploited but the subsequent sexual
exploitation had arisen where the employers had decided to try to recoup their initial outlay.

52. Although the Rev Dr Pemberton-Ford's evidence was as above, she also agreed that where someone was
trafficked for sexual exploitation the trafficker's profit was derived from the men who paid money for sex whereas in
domestic servitude the profit came from the person who employed/bought the victim.

_Conclusions on characteristics of trafficking in a Nigerian context_

53. It can be seen that this evidence does not all point the same way. There are tensions to be found in the views
expressed. For example, whether OCGs are structured or not; whether in most cases the trafficked woman is
trafficked by those known to or related to her. The view expressed by Campana that kinship does not play a key
role resonates with the other evidence before us on the role played by professional traffickers described by Cherti
considering trafficking for the purpose of sexual exploitation.


-----

54. We are satisfied on the evidence, considered as a whole, that much of the trafficking that goes on is the work of
what will generally be a small OCG, sometimes a single family engaged principally in trafficking women or a
woman. That OCG calls upon other individuals or groups (through the OCN) to provide services for example
securing or providing travel documentation, visas, and making travel arrangements for which payment will be made
at that time. That OCN is fluid and loose19 and provides specific services at particular times.

55. The potential result of this is that networks that existed at a time when an individual is taken from her home may
not exist in the same form when she returns to Nigeria, but this does not, on the evidence before us, lead to a
finding that the mere passage of time reduces the risk of contact with the individuals who were involved in a victim's
trafficking where the particular services that were utilised for that individual may no longer exist in that form.

56. It can be seen that there are, generally, differences in the _experiences of those trafficked for the purpose of_
domestic servitude and those trafficked for sexual exploitation. A person trafficked for domestic servitude may well
be subsequently sexually exploited but such exploitation will generally be that resulting from the initial 'purchaser'
seeking to recoup her/his investment or taking advantage of an existing situation. Alternatively, where the domestic
servant attracts the unwanted attentions of males in the household, the woman of the household may simply throw
her out of the household.

57. Generally, whether trafficked for domestic servitude or sexual exploitation, the family (if there is one) of the
trafficked woman will have been complicit to a greater or lesser degree. This is an important factor when assessing
risk on return to Nigeria as the extent to which a woman's own family was complicit in her initial trafficking may well
inform the question of whether return to the family household is a realistic option. Those trafficked specifically for
domestic servitude may subsequently be sexually exploited by those who have paid the trafficker for their domestic
services, but will not necessarily have been trafficked with that aim.

58. A key difference, and one that is of central importance to the assessment of risk on return, is that the financial
interest of the trafficker who delivers a girl or woman trafficked for the purpose of domestic servitude will come to an
end at the point of delivery. We do not accept the evidence of the Rev Dr Pemberton-Ford that there remains a debt
to be paid. In so far as her evidence could be understood, she could draw on nothing other than her supposition. All
the other evidence points the other way: the trafficker will be paid at the point of delivery for providing the trafficked
woman and he or she will have no continuing interest in the trafficked person. Conversely, where a woman is
trafficked for sexual exploitation, the interest of the trafficker is a continuing one focussed on the recovery of the
investment incurred in the cost of trafficking and the expected profit which the trafficked woman owes and which
she must pay off before the trafficker's interest is extinguished.

59. There was some evidence that if a person trafficked for domestic servitude was unsatisfactory then she would
be replaced without further cost to the 'employer'. We are unable to reach a conclusion on whether this applied to
those trafficked transnationally as well as internally due to the lack of evidence. Nor were we able to reach a
conclusion who undertook the 'replacement'. It seems reasonable to conclude, given the absence of hard evidence
but in the light of the characteristics of trafficking in Nigeria that internal trafficking would be more likely to enable
this to happen or, given the nature of trafficking in domestic servitude where, for example, the child was either
previously employed or is related, there remain contacts with the original traffickers.

60. Women who have been trafficked for sexual exploitation will, broadly speaking, fall into two groups. The first,
and the largest group, being those who have been deceived into thinking the purpose of the trafficking exercise is to
deliver her into employment in the UK; she has no idea she is going to be forced into prostitution. That woman will
be raped and groomed in preparation for being put to work as a prostitute. This may occur either in Nigeria or after
arrival in the UK. Part of the experience of being trafficked will generally include an abusive period during which the
victim is 'prepared' to be put to work as a prostitute. The evidence suggests she will also be undertaking domestic
work but that is not the primary purpose of her trafficking. There is some evidence to suggest that some women, the
second group, may realise that they will be working as prostitutes but their agreement to the process has been
obtained by deceit, often by falsely representing the amount that will have to be repaid to discharge the debt owed
to the trafficker.


-----

61. The evidence indicates that women or girls trafficked for domestic servitude are generally not subjected to any
violent or physically abusive treatment until they arrive in the UK. Where a victim of trafficking is exposed to
violence it is more likely to be at the hands of the 'employer'. The evidence indicates also that a significant number
of those who are trafficked for the purpose of domestic servitude may subsequently be sexually abused by the
employer and male members of the family. Again, for the purposes of assessing risk on return of such a trafficked
woman, it is important to recognise that this sexual abuse is the act of the employer and not something that is of
any interest to the original trafficker because the debt has been paid.

**Victim profiles and indicators of risk.**

62. It is Mr Desmond's knowledge and experience that the “common profile of a typical victim of trafficking to
Europe” is likely to include some of the following characteristics20:

     - They are from Southern Nigeria (mainly Edo or Delta State);

     - They are from a rural area;

     - Mainly female;

    - Aged between 14 to 18 years;

     - From a financially poor family;

     - Brought up by guardians in some cases, but not all;

     - Suffered sexual assault and/or physical abuse by their guardian;

     - Had a limited education;

     - Had to carry out daily chores or work to supplement family income;

     - Have a strong Christian belief;

     - Brought up in a community that practised or believed in the power of juju;

     - Was the eldest or an only child;

     - Recruited by a family member or a stranger who directly contacted the family;

    - The parent or guardian was involved in and generally consented to the child/ young adult leaving with
recruiter;

    - Was promised an education or employment;

    - Happy to leave the home environment where they were ill-treated;

    - Does not have a passport;

    - Travel arrangements made by another person;

     - Does not know the identity of the port of entry into UK;

    - Does not know the name of the person who brought them into the UK;

     - Does not know place name of final destination;

     - Scared of authorities;

     - Distrusting of other persons;

     - Tired during the day and suffer from disturbed sleep patterns;

    - Suffers nightmares and often from PTSD;

     - Victims of sexual assault/ abuse once in the UK;

    - Some are pregnant or have a young child;


-----

     - Inconsistencies or gaps within their account;

     - Unable or unwilling to speak about those who trafficked them;

     - Often reluctant to disclose juju details but appeared to have been subjected to a juju ceremony/ ritual oath
taking.

63. The evidence did not suggest that it was necessary for a victim to present with all of these characteristics in
order to be recognised as a victim of trafficking or to be at real risk of being trafficked but the existence of a
selection of these characteristics should be seen to be strong identifiers. The evidence before us did not support a
finding that all Nigerian women are at real risk of being trafficked whether for sexual exploitation or domestic
servitude.

**The legal test relating to assessment of risk on return**

64. A refugee is a person who, owing to a well-founded fear of being persecuted for a reason recognised by the
Convention, which in this case is membership of a particular social group, and is outside her country of nationality
and is unable or owing to such fear unwilling to avail herself of the protection of that country. Put another way, the
Refugee Convention is concerned with protection against “being persecuted”, against a predicament or condition.
To access entitlement to protection under the Refugee Convention there needs to be analysis both of the nature of
the risk and the nature of the State response. It is the combination of these that results in that predicament or
condition resulting in the individual potentially acquiring a right to surrogate protection. As stated in the UNHCR
guidelines, an important aspect of the definition of trafficking is an understanding of trafficking as a process
comprising a number of inter-related actions rather than a single act at a given point in time21.

65. This appeal is brought under s83 of the Nationality, Immigration and Asylum Act 2002 so that in determining it
we are concerned _only with the appellant's asylum claim. Although the jurisprudence concerning Article 3 of the_
ECHR is relevant to a considerable extent in informing our assessment, in the context of trafficked women, of the
existence of a real risk of serious harm as part of the serious harm/ lack of sufficiency of protection test to be
applied in asylum cases, that assessment is to be undertaken in terms of the Refugee Convention and not the
ECHR. It was not in dispute before us that a victim of trafficking for the purpose of domestic servitude or for the
purpose of sexual exploitation will generally have sustained serious harm in the past and would, if trafficked again,
sustain serious harm again.

66. The key issues in this appeal are the availability of sufficiency of protection and the option of safe/reasonable
internal relocation – although neither party addressed the latter issue in any extensive detail, relying principally
upon the established test and submitting either that it would be unduly harsh for this particular appellant to relocate
or alternatively that there were adequate facilities available that would render relocation not unduly harsh. We
consider this in more detail below. It will frequently be the case that the same discernible characteristics which
expose her to risk in her home area will generate the same risk elsewhere.

67. It is not generally in dispute that a victim of trafficking returning to Nigeria is a member of a particular social
group who will have sustained serious harm. It is therefore not in contention that Directive 2011/36/EU on
Preventing and Combating Trafficking in Human Beings and Protecting its Victims (Trafficking Directive), the
Protocol to Prevent Supress and Punish Trafficking in Persons Especially Women and Children supplementing the
United Nations Convention against Transnational Organised Crime (2003) - the Palermo Protocol - and The
Council of Europe Convention on Action against Trafficking in Human Beings (2005) (Anti-trafficking Convention)
apply. Ms Cronin and Mr Singh did not submit that the Anti-trafficking Convention or the Palermo Protocol amended
the obligations arising under the Refugee Convention; Ms Cronin submitted that under Article 4 of the Antitrafficking Convention the UK accepted and acknowledged obligations that were relevant to determining whether a
victim of trafficking was a refugee. She submitted these duties include a duty to investigate, from material available
to the SSHD, the means by which an individual was trafficked and therefore to enable cogent evidence as to any
network or gang involved to be provided; those duties to the victim informed the issues of risk, effective protection
and relocation with regard to that individual.


-----

68. Although not specifically referenced in the cases of EK (Article 4 ECHR; Anti-trafficking Convention) Tanzania

_[[2013] UKUT 00313 (IAC), AM and BM (Trafficked women) Albania CG [2010] UKUT 00090 (IAC) and TD and AD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5929-8BS1-F0JY-C1RS-00000-00&context=1519360)_
_(trafficked women) Albania CG_ _[[2016] UKUT 00092 (IAC), Ms Cronin submitted that this holistic approach was](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J57-XW71-F0JY-C30M-00000-00&context=1519360)_
implicit in those decisions.

69. The holistic approach accords broadly, in our view, with domestic jurisprudence including _Horvath v SSHD_

[[2000] UKHL 37, Noune v SSHD [2000] EWCA Civ 306, Harakel v SSHD [2001] EWCA Civ 884 and Kacaj (Article](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFV1-DYBP-P2JP-00000-00&context=1519360)
_3 – Standard of proof – non state actors) Albania [2001] UKIAT 00018. Although in considering protection available_
in Article 3 terms there is a different analysis,4 in the vast majority of cases the outcome in terms of protection will
clearly be the same. We did not hear specific submissions on this given, in particular, that the appeal before us is
concerned only with the Refugee Convention. In R (Bagdanavicius) v SSHD [2005] UKHL 38 Lord Brown ([30]) said

“…it is perhaps not surprising that where, as in the United Kingdom, the concept of persecution by nonstate agents is recognised, a broadly similar approach is adopted under both Conventions [Refugee
Convention and ECHR] to the requirement for the person concerned to demonstrate in addition to the risk
of harm a failure in the receiving state to provide a reasonable level of protection…”.

_Bagdanavicius specifically holds that the submission made on behalf of the claimant that the_

“member state expelling the person can be in breach of Article 3 because of the risk of injury [the appellant]
runs on return even though, were that risk to eventuate, the receiving country itself would not be, was
“hopeless”.

70. What is apparent however is the need for critical and close analysis of the particular personal circumstances of
a victim of trafficking in the context of the evidenced background material. As was said in Horvath per Lord Clyde at

[513]:

“In assessing the existence of a real risk of the violation of rights occurring anything which may bear on the
likelihood of the incidents of the violation will be relevant… For example, [the applicant's] prominence in
society or political life, or anything else which might make him a particular target of persecution may be
relevant. The history of past violations, the extent to which the applicant has personally been directly
affected, either by being the victim of violence or the recipient of threats of violence, considerations of
geographical location, of all the factors which might stimulate or facilitate a violation, will be among the
circumstances to be taken into account. As also will factors which may discourage or deter or render a
violation less likely. The political and legal situation in the country should be taken into account.”

71. In Kacaj (Article 3 – Standard of proof – non state actors) Albania [2001] UKIAT 00018 [21], the Tribunal held
that Horvath was not to be read as deciding that there will be a sufficiency of protection whenever the authorities in
the receiving state are doing their best. If this best can be shown to be ineffective, it may be that an applicant can
establish that there is an inability to provide the necessary protection. But it is clear that it is a practical standard.
The fact that a system may break down because of incompetence or venality of individual officers is generally not to
be regarded as establishing unwillingness or inability to provide protection. In many cases the existence of the
system will be sufficient to remove the reality of the risk.

72. In _R (Dhima) v SSHD_ _[2002] EWHC 80 (Admin), the court held that what is critical is a combination of_
willingness and ability to provide protection to the level that can reasonably be expected to meet and overcome the
real risk of harm from non-State agents. What is reasonable protection in any case depends, therefore, on the level
of risk, without that protection, for which it has to provide.

73. The ultimate question is not whether a receiving State has complied with any particular standards of conduct but
whether the result is such as to reduce the risk below that of real risk.

74. The Palermo Protocol provides in Article 4 that, save as where stated, it shall apply to the prevention,
investigation and prosecution of offences identified by the Protocol where those offences are transnational in nature
and involve an organised criminal group, as well as to the victims of such offences. Part II of the Protocol sets out


-----

the considerations for protection of victims of trafficking. Article 8 considers the repatriation of victims and in
particular states:

“(2) …. Such return shall be with due regard for the safety of that person and for the status of any legal
proceedings related to the fact that the person is a victim of trafficking and shall preferably be voluntary.”

75. Article 16 of the Anti-trafficking Convention states, inter alia,

“2. When a Party returns a victim to another State, such return shall be with due regard for the rights,
safety and dignity of that person and for the status of any legal proceedings related to the fact that the
person is a victim, and shall preferably be voluntary.

….

5. Each Party shall adopt such legislative or other measures as may be necessary to establish repatriation
programmes, involving relevant national or international and non governmental organisations. These
programmes aim at avoiding re-victimisation. Each Party should make its best effort to favour the
reintegration of victims into the society of the State of return, including reintegration into the education
system and the labour market, in particular through the acquisition and improvement of their professional
skills….”

76. Article 14 of the Anti-trafficking Convention considers issues of residence permits. The Convention does not
amend other international instruments which enable alternative and in some scenarios greater protection and
assistance to the victims of trafficking. Article 40 (4) states

“Nothing in this Convention shall affect the rights and obligations and responsibilities of states and
individuals under international law, including international humanitarian law and international human rights
law and, in particular, where applicable, the [Refugee Convention]”

77. EK observes that the UK government has ratified the Council of Europe Anti-trafficking Convention. In so doing
the UK government not only has to take steps to prevent trafficking but also to take various steps to provide
assistance to victims of trafficking within the UK ([60]). [61] – provides that

“when a party returns a victim to another state, such return shall be with due regard for the rights, safety
and dignity of that person (Article 16(2))”.

At [63] of EK Lord Turnbull records that the UT heard submissions

“in relation to severity of harm or anticipated harm which would be necessary to show a breach of Art 3 of
the Convention (the ECHR) and the considerations which need to be taken into account if such a claim is
based on a lack of medical facilities in a receiving country”.

Lord Turnbull went on to state that the panel found force in the submission, having considered that Article 4 of the
Anti-trafficking Convention was engaged and  considering N v United Kingdom and the guidance in para 183 of the
Explanatory Report to the Anti-trafficking Convention that:

“the guidance given in para 183 of the Explanatory Report seems to contemplate a quite different standard
from the very high one described in N….”.

Lord Turnbull notes “in addition” that the basis of _EK's claims are quite different  from those in the cases_
mentioned – _EK was a victim of trafficking in relation to whom it had been held there had been a breach of the_
obligations imposed on the UK government by article 4 of the Anti-trafficking Convention and that such breach

“… exposed [EK] to harm in this country. The appellant's entitlement to reparation and the obligations
under the Anti-Trafficking Convention are considerations which had no counterpart in the other cases
under discussion.”

Lord Turnbull at [64] of EK records the submission that:


-----

“…..a duty to return with due regard to 'dignity' involved the consideration of a right in which other
protective rights, such as safety and health, were subsumed”.

He concluded [64]

“…it is appropriate to start from the appreciation that the appellant's medical condition is linked to the
breach of her rights under Art 4 of the Convention, in other words that the state should recognise a degree
of responsibility for it. From this starting point it is difficult to see that to remove the appellant at this stage,
when she suffers from such serious physical and mental health problems, from the care of the medical
regime which she presently benefits from, and to return her to a country where facilities for the proper care
of her present and likely needs are absent, to the extent that her life expectancy will be greatly reduced,
can be seen as a return with due regard for her dignity.”

This was reinforced at [65]:

“…. The only context in which Art 4 of the Convention was considered was in connection with the risk of retrafficking in Tanzania. Although it was pointed out that there were non-governmental agencies working in
Tanzania to provide assistance to victims of trafficking, no mention was made of the obligations which the
UK had undertaken in terms of Art 12, 14 or 16 of the Anti-trafficking Convention….”

And at [66]

“… the decisions were taken without taking account of the link between the appellant's precarious state of
health and the breach of the respondent's own protective obligations in terms of policy and Art 4 of the
Convention. They were taken without consideration of the duties which were engaged under Arts 12, 14
and 16 of the Anti-trafficking Convention…”

78. We were not provided with a copy of the Explanatory Report to the Anti-trafficking Convention but it is referred
to in EK and is a publicly available document. Paragraphs 183 and 184 of the Explanatory Report are directed at
the issuing of residence permits and read as follows:

“183. Thus, for the victim to be granted a residence permit, and depending on the approach the Party
adopts, either the victim's personal circumstances must be such that it would be unreasonable to compel
them to leave the national territory, or there has to be an investigation or prosecution with the victim
cooperating with the authorities. Parties likewise have the possibility of issuing residence permits in both
situations.

184. The personal situation requirement takes in a range of situations, depending on whether it is the
victim's safety, state of health, family situation or some other factor which has to be taken into account. “

Paragraphs 200 to 207 of the Explanatory Report consider the repatriation and return of victims under Article 16 of
the Anti-trafficking Convention. Paragraph 200 acknowledges that Article 16 is partly inspired by Article 8 of the
Palermo Protocol and considers both voluntary and non-voluntary return of victims of trafficking. The Explanatory
Report goes on to state:

“202. The return of a victim of trafficking is not always without any risk. Therefore, the drafters wished to
precise in the text of the convention that the return of a victim “shall be with due regard for the rights, safety
and dignity of that person”. This applies to the Party which facilitates and accepts the return of the victim
as well as, according to paragraph 2, to the Party which returns a victim to another State. Such rights
include, in particular, the right not to be subjected to inhuman or degrading treatment, the right to the
protection of private and family life and the protection of his/ her identity….

203. The drafters considered that in this respect it was important to have in mind the jurisprudence of the
European Court of Human Rights regarding article 3…… in the case of D v United Kingdom (2 May 1997,
compendium of judgments and decisions, 1997 – III) she precised that the responsibility of states parties is
also engaged when the alleged ill treatments did not follow directly or indirectly from public authorities of
the destination country….”


-----

79. The headnote in TD includes that:

(d) “…There is in general a Horvath-standard sufficiency of protection, but it will not be effective in every
case. When considering whether or not there is a sufficiency of protection for a victim of trafficking her
particular circumstances must be considered.”

_TD considers sufficiency of protection but, as can be seen from [153] and [172], the appeals were allowed_
on the basis that internal relocation would be unduly harsh given the particular circumstances of their cases. In the
case of TD herself, the tribunal found that because of her particular vulnerability she would be likely to fall into the
hands of those who would re-traffic her and the sufficiency of protection that, generally, would be available to
victims of trafficking on return would not be available to her.

80. The approach taken in _EK (which was concerned with Article 3 and was not considering serious harm and_
sufficiency of protection in the context of an asylum claim) that the Explanatory Report contemplates a different
threshold to the high threshold of N cannot survive the analysis of the Court of Appeal in the subsequent decision in
_SSHD v Said_ [2016] EWCA Civ 44223. The particular circumstances in _EK, where the UK was found to be in_
breach of article 4 Anti-trafficking Convention, may well have provided a sustainable justification that led to the
particular findings in that case – the Article 3 breach having occurred, it seems from the findings of fact in that case,
in the UK by the UK state. But unless such a finding can be made on the particular facts of the case, in our
judgement neither the Palermo protocol, the Anti-trafficking Convention nor the Explanatory Report are authority for
the proposition that the fact of having suffered serious harm in the past with continuing deficit in health can be a
substitute for rigorous analysis of the circumstances on return to Nigeria which are not the responsibility of the
Nigerian authorities, in order to succeed in resisting removal on Article 3 grounds. In reaching this conclusion we
have taken particular note of paragraph 16 of the UNHCR guidelines but note that this makes specific reference to
the other interrelated elements of the refugee definition being fulfilled.

81. We can see no justification or authority for incorporating into the word 'dignity' as used in the Palermo Protocol
and the Council of Europe Anti-trafficking Convention any amendment or alteration to the interpretation and
applicability of Article 3 ECHR/ Refugee Convention as they relate to sufficiency of protection or internal relocation.
Although the Explanatory Report refers to _D (the facts of which were at the extreme end of the spectrum), the_
consistent authority of domestic and Strasbourg jurisprudence requires some receiving state failure to provide
protection to enable international protection under the Refugee Convention or Article 3 to be provided absent the
exceptional factors of a nature such as enabled D's claim to succeed.

82. In our judgement, in the context of an asylum claim there is no alteration to the UK's obligations arising under
the Refugee Convention in the assessment of sufficiency of protection A conclusion that an individual is at serious
risk of being trafficked requires an analysis that takes account of anything and everything that may be relevant.
This analysis in the context of victims of trafficking will necessarily include an analysis of the trafficking itself
including the consequences to the victim and not merely of the particular personal circumstances of the victim at the
date of consideration. By its very nature this includes consideration of the dignity of a victim as an element to be
considered. The characterisation by Ms Cronin as requiring an holistic analysis is correct; not because the various
trafficking instruments require an altered analysis but because they re-emphasise the importance of and the wide
ranging nature of such analysis in the particular circumstances of victims of trafficking in the context of an asylum
claim5. This takes account of the dynamic experience of trafficking, the vulnerability of the victim, the practical help
available to and able to be accessed as well as the potential for future trafficking.

**Risk on return.**

83. It is not generally in dispute that if a victim of trafficking is, on return to her   country of origin, at real risk of
being trafficked then she is at real risk of being persecuted.

84.   The key issues on risk on return are

(a) The risk of re-trafficking either by the original traffickers or other traffickers.

(b) The risk of retribution from those involved in the original trafficking.


-----

(c) Vulnerability to abuse.

It is necessary to consider both groups of victims – those trafficked primarily or solely for the purpose of sexual
exploitation and those trafficked for the purpose of domestic servitude. Issues of vulnerability feed into the analysis
for both groups.

85. Whether or not NAPTIP provides a sufficiency of protection for victims of trafficking who are returned to Nigeria
is a significant matter in dispute between the parties. Therefore, it is necessary to conduct a detailed examination of
the evidence the parties have put before the Tribunal so that we can make a clear finding of fact as to the level of
protection NAPTIP can provide.

**NAPTIP**

86. The IOM 2006 report describes the establishment of NAPTIP6 in 2003 as an important step in the change in
attitude to the material financial rewards that accrue, through the emigration and prostitution of women, to families
remaining in Nigeria. NAPTIP is a specialised government agency empowered with law enforcement
responsibilities, prevention and protection responsibilities and prosecution responsibilities. The agency has an
investigation unit and a legal department which are primarily responsible for prosecuting all trafficking cases in
Nigeria. Police, immigration and customs authorities and NAPTIP have powers to arrest suspected offenders but
the powers of prosecution rest with NAPTIP. The Nigerian Government in 2008 adopted, after extensive
consultation with NAPTIP and stakeholders, a National Policy on Protection and Assistance to Trafficking Persons
(Protection Policy) covering reception, identification, sheltering, counselling, family tracing, return/repatriation,
integration, empowerment, follow-up/aftercare and disengagement in a stated holistic approach.

87. The evidence before us did not, however, indicate the extent to which attitudes have in fact changed such that
the level of trafficking is reducing. Although the evidence indicates increasing awareness of the role of deception in
trafficking, there does not appear to be evidence to support a finding that trafficking is declining.

88. The IOM 2006 report refers to a raid on NAPTIP headquarters in 2006 by armed men who destroyed
computers, documents and archives as an apparent attempt to undermine and destroy the agency's anti-trafficking
operations. The report comments that this not only indicates the brutality of the trafficking networks but also that
traffickers see NAPTIP as a real threat to their activity. The OSCE/ODIHR report records that members of a
trafficking network had threatened NAPTIP staff, judicial officers and judges. It is not clear whether this was the
same incident as recorded in the IOM report or a continuing problem. We could not find other later references to
this type of intimidation. Witness intimidation was reported as a 'big' problem. The OSCE/ODIHR interviewers were
told that witnesses will disappear and they do not want to be found. NAPTIP is recorded as saying that everyone is
frightened of repercussions, there are 'big' risks of reprisals, the traffickers have a lot of influence, including political
influence. The problem of witness intimidation is exacerbated by the length of time the case took to come trial.

89.The USA has legislation to assist in the combating of trafficking in human beings26 and places every country
into one of three Tiers27 based on the extent of their Governments' efforts to comply with the “minimum standards
for the elimination of trafficking”. The USA produces reports on nearly every country in the world (TIP Reports) in
the context that

“… while Tier 1 is the highest ranking, it does not mean that a country has no human trafficking problem.
On the contrary, a Tier 1 ranking indicates that a government has acknowledged the existence of human
trafficking, made efforts to address the problem, and complies with the TVPA's minimum standards. Each
year, governments need to demonstrate appreciable progress in combating trafficking to maintain a Tier 1
ranking”.

90. The criteria used by the US State Department to determine which Tier a particular country falls into are set out
in Annex 5 together with the 2016 TIP report on Nigeria. Of particular relevance to the issues before us are the
following extracts from the current (2016) TIP Report:

“The Government of Nigeria does not fully meet the minimum standards for the elimination of trafficking;
however it is making significant efforts to do so The National Agency for the Prohibition of Trafficking


-----

in Persons and Other Related Matters (NAPTIP) received a larger operating budget, identified and
provided services to a large number of victims, and continued extensive awareness campaigns throughout
the country. ………

RECOMMENDATIONS FOR NIGERIA:

…. continue to vigorously pursue trafficking investigations, prosecutions, and adequate sentences for
convicted traffickers; take proactive measures to investigate and prosecute government officials suspected
of trafficking-related corruption and complicity in trafficking offenses; ensure the activities of NAPTIP
receive sufficient funding, particularly for prosecuting traffickers and providing adequate care for victims;
……continue to provide regular training to police and immigration officials to identify trafficking victims
among vulnerable populations, such as women in prostitution and young females traveling with non-family
members; …

PROSECUTION

The government maintained strong anti-trafficking law enforcement efforts. …

NAPTIP conducted 507 trafficking investigations, completed at least 32 prosecutions, and secured 24
convictions during the reporting period, compared with 509 investigations, 56 prosecutions, and 30
convictions in the previous reporting period. ….An additional 148 prosecutions remained pending at the
end of the reporting period. All prosecutions occurred under the anti-trafficking law ….. The government
commenced prosecution of a Ministry of Foreign Affairs official who allegedly used his or her position to
facilitate a trafficking crime abroad; the prosecution remained ongoing at the close of the reporting period.
The government did not report any other investigations, prosecutions, or convictions of government
officials complicit in trafficking offenses; however, corruption at all levels of the government remained a
pervasive problem.

The government conducted extensive training throughout the reporting period… These programs offered
specialized training on victim identification, investigation and prosecution of trafficking cases, counseling,
intelligence collection, and monitoring and evaluation. …

PROTECTION

The government maintained strong efforts to protect trafficking victims. The government identified 943
trafficking victims, including 429 victims of sex trafficking and 514 of labor trafficking, compared with 914
victims identified in the previous reporting period. NAPTIP provided initial screening and assistance for all
victims it identified and referred them to government-run care facilities for further medical care, vocational
training, education, and shelter. The government has formal written procedures to guide law enforcement,
immigration, and social services personnel in proactive identification of trafficking victims among high-risk
populations. NAPTIP provided police, immigration, and social services personnel with specialized training
on how to identify trafficking victims and direct them to NAPTIP. Additionally, the government's national
referral mechanism provides formal guidelines for law enforcement, immigration officials, and service
providers to improve protection and assistance to trafficking victims, both within Nigeria and abroad.

….. NAPTIP operated nine shelters specifically for trafficking victims, with a total capacity of 313 victims.
Through these shelters, NAPTIP provided access to legal, medical, and psychological services, as well as
vocational training, trade and financial empowerment, and business management skills. Victims who
required additional medical and psychological treatment were provided services by hospitals and clinics
through existing agreements with NAPTIP. NAPTIP shelters offered short-term care, generally limiting
victims' stays to six weeks, although victims were allowed to extend their stays under special
circumstances. If victims needed longer-term care, NAPTIP collaborated with two shelters operated by the
Ministry of Women's Affairs and NGO-run shelters. Victims in NAPTIP shelters were not allowed to leave
unless accompanied by a chaperone. NAPTIP provided funding, in-kind donations, and services to NGOs
and other organizations that afforded protective services to trafficking victims.

…..

PREVENTION


-----

The government sustained efforts to prevent human trafficking …… The government did not make any
discernible efforts to decrease the demand for commercial sex acts. ….”

91. The TIP Report cannot be read in isolation but must be considered in the light of the criteria against which the
Report is drawn up. In particular, a Government is enjoined to make “serious and sustained efforts” to eliminate
severe forms of trafficking in persons. The Reports do not refer primarily to the effectiveness of the measures taken;
they consider the existence of such measures. For example, in the reference to the number of prosecutions
undertaken, the Report gives the number of investigations, prosecutions and convictions; there is no reference to
the number of failed prosecutions or investigations or the reasons for that; no reference to the number of
investigations/prosecutions compared to the number of identified victims; no reference to the number of
prosecutions or investigations undertaken in comparison to the numbers actually thought to be exploited either
nationally or transnationally; no breakdown between those who have been identified as internally trafficked and
those who have been returned to Nigeria as victims of trafficking. The number of successful prosecutions for
trafficking for the purpose of labour exploitation (which includes domestic servitude) exceeds those prosecutions of
trafficking for the purpose of sexual exploitation yet the evidence before us indicates that greater numbers of
women are trafficked for the purpose of sexual exploitation. There is no indication how those cases came to the
attention of NAPTIP to enable prosecutions to take place. Although there is reference to the existence of formal
written procedures and guidelines, there is no assessment as to how effective these are in practice or the extent to
which they are implemented. The OSCE/ODIHR 2011 fact finding report refers to the TIP reports and that Nigeria's
placement on Tier 1 status in 2009 for the first time

“is mostly for successful investigations and prosecution and less for efforts made in other areas such as
prevention, care and protection. It is therefore not surprising that the low-risk and high profit trade of human
trafficking…continues despite the country's Tier 1 status.”

92. Since its establishment, NAPTIP has successfully prosecuted several cases. NAPTIP reports routine difficulty in
persuading victims to divulge the names of traffickers both because of victims' fears of supernatural consequences
if they have taken a ritual oath and fear of the traffickers. The OSCE/ODIHR report records that NAPTIP does not
provide meaningful protection to either victims or to their close relatives. NAPTIP is reported to have been able to
circumvent the victim's fears by arresting the men who administer ritual oaths as accomplices and then often
mitigate a sentence if they act as informants and witnesses.

93. Ms Cronin referred to the actual manner in which victims were returned to Nigeria. She referred to victims being
returned when the NAPTIP office was closed, to the lack of security for victims who needed food, accommodation
and documentation. She referred to reports that some victims were returned to Nigeria in the clothes they had been
found in and were not allowed to bring their possessions or money with them. She referred to NAPTIP requesting
that governments liaise with them prior to return, to traffickers waiting at airports to re-traffic victims and the
powerlessness of NAPTIP to protect those victims if they were unable to meet them. She referred to the Danish
report that NAPTIP was simply unable to accommodate large numbers of returnees at any one time.

94. The references in the evidence before us, including the Danish report and the Finnish report, to requests by
NAPTIP to be notified of returns and to keeping the numbers returned low enough to enable NAPTIP to be able to
respond were not all concerned with returns from the UK, although the manner of return may impact on the
availability and ability to access protection and assistance from NAPTIP immediately on arrival. The actual manner
of return is relevant to the issue of sufficiency of protection on arrival in Nigeria. The question is the risk on return
facing any particular individual victim. The ability of NAPTIP to provide appropriate levels of support to any
particular number who may theoretically be returned at any one point is relevant to the extent that they have
requested prior notification and for the numbers to be managed to enable a returned victim of trafficking to be met
on arrival.

95. Ms Cronin submitted there were problems with NAPTIP because it performed various functions all of which
were onerous. It was not, she submitted, satisfactory to have prosecution and protection functions undertaken by
the same entity. However, it is neither appropriate nor relevant for us to express an opinion on whether such an
arrangement as set up by the Nigerian Government is or is not satisfactory. The issue before us is whether there
is either through NAPTIP or some other mechanism sufficiency of protection available for victims of trafficking


-----

96. The Danish report refers to and considers the support available through NGOs including GPI, COSUDOW,
IRRAG, WOCON, WOTCLEF, AWEG, Idia Renaissance and the Catholic Secretariat/Caritas Nigeria. The report
records that the NGOs appear to have a good working relationship with NAPTIP and the government agencies
including Ministries of Education, Social Affairs, Women and Children's Affairs. The report records that between
2004 and the date of the report (December 2006) Benin City had received 299 victims of whom 58 had been
rehabilitated and the remaining 241 victims were awaiting rehabilitation.

97. The Nigerian government in compliance with its duties under the various Conventions which it has ratified
endeavours to provide protection through a combination of legislation, the courts, Customs and Immigration
Services, NAPTIP and various NGOs. Although in general terms it cannot be concluded that non-governmental
organisations can be relied upon as assisting in the provision of sufficiency of protection that is not wholly the case
in Nigeria. The CORI report refers to the strong partnerships that have been developed at National and state levels
with the Police, Immigration and Nigerian Customs Service; the establishment of a specialised Anti-trafficking
department and the provision of services from NGOs. Some of the NGOs, for example WOTCLEF and COSUDOW,
run shelters which provide a low level of support and shelter in terms of numbers and have direct links with
NAPTIP. Other NGOs provide specialised counselling and skills training. The Ministry of Women provides shelters
and to that extent, in the context of protection, NGOs can be considered as instruments of the Nigerian State albeit
providing limited protection.

98. The Danish Report recorded the views of NGOs on whether there were reprisals against victims or their families
if the outstanding debt had not been paid. NAPTIP Benin Zonal Office stated that there had been no reports of
retaliation against victims who had testified since the establishment of the Zonal office in 2004; many of the NGOs
expressed the view that victims would be at risk but they did not provide any examples of and had no records of
individuals who had been threatened or victimised regardless of whether they had testified abroad or in Nigeria. The
Catholic Secretariat/Caritas expressed the view that if violence took place within the family there was “a good
chance that it will never be known to the public or anyone else”.

99. The NAPTIP Lagos Zonal Office said it was aware of attempts to intimidate witnesses but there were no
examples of such victims being subjected to violence. The view is expressed in the Finnish Report that local
traffickers in Nigeria do not occupy a strong position in society and can do little else than recruit new victims. The
evidence overall as recorded in the Finnish report was that although there would be little overt violence by the
traffickers, returning victims are subjected to psychological and/or emotional violence and/or pressure from their
families. The report records that victims who return before the debt is paid are likely to be re-trafficked by their
families because of a fear of retribution, although the evidence before us did not support a finding that retribution
was a significant occurrence in practice, and because of the loss of possible future financial benefit the family would
be likely to accrue after the debt has been paid. The NAPTIP Zonal office considered that most traffickers have
family ties and thus are less willing to kill or persecute a victim as a reprisal or deterrent and that local traffickers
would keep a low profile and continue their trafficking business rather than risk exposure and prosecution.
COSUDOW considered the traffickers' objective is to get the money back and the family's objective is to make
money and thus the family and trafficker “will see to it that the returned victim will be re-trafficked”.

100. The more recent OSCE/ODIHR 2011 Report records IOM in an interview in February 2011 as saying they had
cases where traffickers had threatened victims. The report also referred to the main traffickers being in Europe

“whereas the only available traffickers in Nigeria were the 'small fry' who were easily replaced in the
networks, leaving the networks operational despite the convictions.”

101. The Danish Report and the Finnish Report record that some NGOs consider NAPTIP to offer as much
protection as is required for returned victims. However, the overall view taken by NGOs was that there are simply
too many victims of trafficking compared to the resources available. The Finnish report draws upon the Trafficking
in Person's Report 2014 by USDOS and states “the reality is that many victims returning from abroad are still not
afforded proper rehabilitation and social integration”. This view is reflected in the OSCE/ODIHR 2011 fact finding
report.

102 It appeared to the members of the ATLeP (OSCE/ODIHR) delegation that


-----

“In terms of protection the capacity of NAPTIP and indeed police officers to offer protection to victims either
from reprisals from traffickers or even during the return process is weak… there is no proactive use of the
law to prevent trafficking. The continued scale of the problem of human trafficking in Nigeria suggests that
whilst there is an adequate legal framework, adequate measures have not been taken to implement
Nigerian law so as to provide effective protection”.

103. Mr Singh submitted that Dr Agnew-Davies' evidence regarding the NAPTIP shelters was some five years old
(a visit in 2011 which had not been repeated) and the purpose of the visit had not been a fact finding investigation
relating to the NAPTIP shelters or the level of protection provided but arose from general discussions she had had;
there had been no systematic research into the matters upon which she gave her opinion.

104. According to the introduction and framework of the OSCE/ODIHR 2011 report, it is “research regarding the
national laws, policies and practices of NIGERIA relating to the return of trafficked/exploited persons”. There are
specific sections on protection, returns in the context of NAPTIP and other actors. Whilst there may not have been
systematic and specific single issue research the report was plainly tasked with consideration of the practice of
return.

_Length of stay in NAPTIP shelter_

105. It is the respondent's case that it is established by the evidence that a victim could and would remain in a
NAPTIP shelter for 6 weeks; that there was no requirement or intention that victims were returned to their family
after two weeks and no policy or practice of evicting victims who do not co-operate. After a stay of 6 weeks, as
referred to by NAPTIP in their response to the questionnaire sent in these proceedings, there was the possibility of
an extension if deemed appropriate or necessary or there would be a transfer to a shelter run by an NGO or
National Women's Affairs (a Government Ministry).

106. Mr Singh submitted that more weight should be placed on the US State Department Report than on the
evidence of Dr Agnew-Davies on what she saw in two shelters over five years ago. He submitted there was no
evidence that victims were sent back to families and exposed to a risk of re-trafficking. If that was happening, he
submitted that Nigeria would not be a Tier 2 country but would be in the bottom tier.

107. Ms Cronin submitted firstly that the evidence was to the effect that it was the intention of NAPTIP to return
victims to their family as soon as possible, secondly that an individual could not stay in a shelter for more than 6
weeks in any event, thirdly that staying in a shelter for only six weeks was an inadequate period of time to facilitate
rehabilitation or reintegration for a returning traumatised victims of trafficking and finally that there were no
adequate other places for victims to go to after 6 weeks. WOTCLEF gave the numbers they had rescued as 21 in
2013 and 22 in 2014 and thus had limited capacity to take any overflow from NAPTIP. No specific submission was
advanced on behalf of the respondent as to whether or not 6 weeks was an adequate period of time to facilitate
reintegration for a returning victim of trafficking.

108. Ms Cronin submitted that in the response to the questionnaire, sent to NAPTIP in the course of these
proceedings, there was a statement of policy and not necessarily an actual indication of how long people stayed.
Ms Cronin submitted that there were gaps in the NAPTIP documentary evidence: the data reports recorded shelter
capacity but not occupancy; there was no indication of how many victims were accommodated in one year; there
was no indication how many of those who were accommodated were victims of internal as oppose to transnational
trafficking

109. The Danish Report records NAPTIP Zonal Office as saying that the normal period of time in a shelter is 2
weeks and this can be extended for victims who give evidence for as long as the criminal case is pending. The
report also refers to individuals being transferred to WOTCLEF shelters “most victims stay in WOTCLEF's shelter
for six weeks and some may stay for up to six months or more depending on their individual needs.” The
OSCE/ODIHR 2011 report states that there is no functioning witness protection scheme and that “Victim protection
is limited to those who cooperate with NAPTIP in the investigation and prosecution of traffickers and only lasts for
the short period that the victim is allowed to remain in a NAPTIP shelter”.


-----

110. In their response to the questionnaire NAPTIP stated, consistent with Dr Agnew-Davies' evidence and the
OSCE/ODIHR 2011 report, that the primary focus of NAPTIP is to seek to reunite families after the reception and
identification process was complete.

     - NAPTIP will only accommodate victims until active efforts to locate a relative are successful (often less
than two weeks);

     - The women who stay in the shelters are not free to leave at will;

    - During her visits to an active shelter in Lagos the women and children were locked in a building with
barred windows in a guarded compound, tantamount to a detention centre. Such conditions would be a
powerful trigger in trafficking cases as the environment itself would serve as a reminder of previous
situations of entrapment and deprivation of liberty;

     - Staff at the centre describe the shelter as “a transit centre” before victims are returned to their home after
2 to 6 weeks.

    - From a conversation she had with staff at the shelter: The primary role of counsellors was to provide
evidence about traffickers to enable NAPTIP to prosecute. If such evidence was not forthcoming the
victims were returned to their families within two weeks. It was the counsellor's job to find out where the
families were. Victims only tended to stay for six weeks if a prosecution was likely to take place quickly, in
which case they were kept in a locked shelter with a garden.

     - In reality NAPTIP does not offer mental health care to returnees in its shelters beyond the basic psychosocial counselling provided by untrained staff; the main purpose of the counselling was to identify victims,
obtain information to facilitate family reunion, to identify traffickers and to obtain evidence for prosecution.

111. Mr Desmond stated that it was his understanding, from what he had been told by victims and from reports that
he had read, that if a victim did not cooperate with a prosecution she was required to leave the shelter. He also
understood that even if a victim wished to remain in the shelter beyond 6 weeks that was not possible.

112. The OSCE/ODIHR 2011 report refers to the follow up conducted by NAPTIP as required in the Nigerian
Protection Policy

“Shelter is provided for in the Policy as a temporary accommodation to provide opportunity to obtain
additional information from victims and to amongst other things create opportunity for knowledge
enhancement. Follow- up/after care is provided for with the objective of ensuring that trafficked persons
remain safe and make progress and to avert any possibility of being retrafficked. In reality, follow-up/after
care mechanisms in NAPTIP are weak or at best ad hoc. …. In reality disengagement happens as soon as
victims are returned to their home communities. In the ATLeP28 interview with NAPTIP officials in Lagos
we were informed that they conduct follow up monthly for a period of three years. After three years it is
assumed that the victim is safe and no further threat. However when probed as to availability of resources
to follow up all their victims in this manner the officials qualified the assertion by further stating 'That is what
_is supposed to be but we do it more for victims who have been rehabilitated and those who have appeared_
_in court. We monitor them more closely.'”_

113. Cherti considered that family reunion was inappropriate: There was a low capacity of organisation, low value
and a lack of therapeutic assistance which resulted in further trafficking.

114. Mrs Olateru-Olagbegi took the view that parents who had been complicit in the original trafficking would
retraffick the victim due to their poverty.

_What happens after leaving a NAPTIP shelter whether after 2 weeks, after 6 weeks or because the_
_individual is unable to access a NAPTIP shelter at all_

115. The IOM 2015 report considered the outcomes of two specific projects considering return and reintegration of
victims of trafficking: the Coordinated Approach for the reintegration of victims of trafficking (“CARE”) and
Transnational Action – safe and sustainable return and reintegration for victims of trafficking (“TACT”). Specific


-----

programmes were put in place to consider the approaches necessary. The CARE project objective was to provide
flexible and tailored assistance helping returning victims of trafficking from the UK (and other EU countries) to
Nigeria, amongst other countries. The TACT project supports capacity development processes between five EU
member states (not the UK) and three priority countries (not Nigeria). Nigeria had by far the largest number of
project beneficiaries under CARE. The recommendations made were general for all the countries involved and
included

“family reunification plays a central role in the psycho-social well being of victims upon
return…consent…should always be sought…victims need to be in a trusting environment.”

116. The IOM 2015 report states

“reintegration is a fundamental though challenging aspect of return migration. Preserving migrant's rights,
ensuring their protection and well being and contributing to local development while enhancing the
reintegration perspectives of the individual, are vital facets of the AVRR [IOM Assisted Voluntary Return
and Reintegration] programmes. Enabling migrants to re-establish themselves in the society of their
country of origin and empowering them to participate in social cultural economic and political life again
should be the aim of reintegration assistance in order for the return to be successful.”

…..

“When a victim of trafficking returns to his/ her country of origin, specific support based on individual needs
is necessary to make the transition period as smooth as possible and to reduce the risk of re-trafficking.
The psychological and often physical trauma victims of trafficking could have experienced during the period
they were trafficked leave them in a fragile and precarious situation…… the victims of trafficking have
specific needs….. which are notably rooted in security concerns and potential stigmatisation in their
country of origin. Therefore the support needed encompasses a very broad range of sectors, such as
psychological assistance, medical assistance, housing, financial support, etc……… returning victims of
trafficking may face serious risks in the country of origin, meaning that these risks must always be
assessed, again through a series of questions and criteria for evaluation, and measures must be taken to
tackle these risks and to ensure the safety and security of the victim of trafficking after his/ her return.

…… safe and sustainable return forms an integral part of counter trafficking policies. The document the EU
_rights of victims of trafficking in human beings (2013)… includes provisions on the return of victims of_
trafficking, thus considering return as a fundamental right, on the same level as the reflection period, the
right to protection, the right to compensation, the right to integration and labour, etc. Safe and sustainable
return should thus be promoted and safeguarded across EU member states.”

117. The IOM 2015 Report records that the CARE project identified limited procedures in the beneficiary countries

“… for the follow up on trafficker prosecution and conviction, thus limited access to protection of victim's
rights through the judicial system, including access to compensation……The variety and complexity of the
issues that need to be urgently addressed once again demonstrate that a broad range of
stakeholders……must pool their efforts in order to effectively improve counter- trafficking policies and
better guarantee the fundamental rights of the victims….who returned to their countries of origin.”

118. In preparing her report for these proceedings, the Rev Dr Pemberton-Ford had contacted IOM and been
informed that approximately 20% of victims of trafficking appeared to be reintegrated successfully, 10% appear to
have disappeared and been recycled into trafficking and it was not known what had happened to the remaining
70%. She was not able to assist the Tribunal as to the methodology employed by the IOM in obtaining those figures
or to what period they related.

119. The Rev Dr Pemberton-Ford was unable to offer an opinion as to what had happened to the 70%, and did not
agree with Mr Singh's submission that they plainly did not fall within the 10% who had been re-trafficked. She
concluded that further research was required and the lack of knowledge was a consequence of nature of trafficking
as a hidden crime.


-----

120. Such evidence as was before us did not indicate what proportion of those that were retrafficked were trafficked
internally as opposed to transnationally. There did not appear to be any evidence from European sources to identify
whether victims of trafficking who had been identified were retrafficked or not.

121. UNODC, reported in the OSCE/ODIHR 2011 report, observes that the

“rehabilitation and reintegration facilities were inadequate because of a lack of  resources, limited time in
shelters and speedy return to families.”

**Medical/psychological/therapy**

122. Dr Roxanne Agnew-Davies was part of the OSCE/ODIHR 2011 fact-finding team and led the interviews in
discussion with NAPTIP personnel at both the Lagos and Abuja shelters. She has not visited Nigeria since then
although she had requested and obtained up to date information from psychiatrists she previously had contact with.

123. Dr Agnew-Davies' evidence derived both from her fact finding visit to Nigeria in 2011 and the updating
information she obtained from conversations in 2016. She observed that whilst NAPTIP offered a valuable service
to some trafficked victims the shelters did not equate to UK refuges by any means and were more akin to prisons or
detention centres. NAPTIP staff were not appropriately trained to support traumatised victims of trafficking from a
psychiatric perspective. Psychiatric services were overstretched, costly and were not equipped to offer trauma
focussed therapy as recommended by the National Institute of Clinical Excellence in the UK. There was also a high
prevalence of domestic violence and discrimination against people with severe mental illness in Nigeria which is not
yet adequately addressed by the state. Conditions have improved since 2011 in that there is increased availability
of newer generations of drugs, increased numbers of psychiatrists and expertise with regard to CBT and cognitive
re-processing, but “organization of services are still poor and patients can be lost in this wilderness”. The nurse and
matron interviewed at the Lagos shelter informed the OSCE/ODIHR 2011 delegation that they had never made a
referral of a victim to a psychiatrist. During the visit of the OSCE/ODIHR 2011 delegation to the NAPTIP shelter in
Abuja which has a majority of population of children they were informed by the shelter's managers that where
some of the children who displayed flashbacks and other signs of PTSD, the matron would place them in front of
the TV to “take their minds off things”.

124. Dr Agnew-Davies interviewed a number of women in the shelter in 2011 and conducted preliminary tests. In
her view 3 out of 4 were suffering from PTSD yet this had not been recognised and they were receiving no
treatment.

125. Dr Agnew-Davies recounted, on the basis of her trip, that counsellors “learned on the job” and had no
psychological or psychiatric qualifications. They were given training on how to interrogate victims for the purpose of
obtaining information to enable prosecutions to be pursued. She gave one example where NAPTIP staff suggested
that where children had been fighting in locked rooms or a woman was shouting in her sleep that was because “evil
spirits were at work”. She considered that although some short-term basic vocational training such as hairdressing
or courses on self-esteem, health, etiquette and computing were provided, neither medically nor therapeutically can
these be regarded as adequate or specialist treatment that would address the symptoms of complex PTSD or Major
Depressive Disorder. She expressed concern that in NAPTIP shelters, the onus is on the victims to discuss their
experiences with NAPTIP staff with a view to giving evidence against their traffickers in court prosecutions brought
by NAPTIP rather than as an element of psychological treatment.

126. Dr Agnew-Davies referred to a report by Ero & Yishau 2007 (a copy of which we did not have and therefore do
not know what period is referenced); NAPTIP are recorded as reporting that of 962 victims of trafficking attended to
by NAPTIP only 2 suffered from psychiatric disorders. Dr Agnew-Davies was firmly of the opinion that in the light of
her own experience of trafficked victims this was a gross underestimate and reflected “the incapacity of NAPTIP to
identify (and therefore treat) psychiatric disturbance”. Dr Agnew-Davies reported that in 2011 only one victim, who
was severely psychotic, had been referred by NAPTIP to the Lagos psychiatric hospital by 2011 and the psychiatrist
did not believe that NAPTIP considered psychological needs. That same psychiatrist, when consulted by Dr AgnewDavies over developments in the intervening five years since her visit, said that he had only treated one more victim


-----

of trafficking and NAPTIP had not referred any to the hospital. On discussing the treatment given to that victim, Dr
Agnew-Davies was of the opinion that the treatment offered was not appropriate.

127. The OSCE/ODIHR 2011 report records that

“In reality, NAPTIP does not offer mental health care to returnees in its shelters beyond the basic psychosocial counselling which their staffs provide…NAPTIP has neither the specialised personnel nor the
capacity to treat post traumatic stress disorder. Whilst NAPTIP stated they make referrals to other
agencies, those that were contacted had not received more than three or four referrals in the previous
three years”.

128. There was no challenge by Mr Singh to Dr Agnew-Davies' evidence as to the availability of psychiatric facilities
in Lagos, Benin City and elsewhere in Nigeria. Dr Agnew-Davies had visited hospitals and shelters in Lagos and
Benin City. She spoke of the small number of psychiatrists who are required to see large numbers of patients a day.
The figures she quoted were: 150 psychiatrists in total in Nigeria for 150,000,000 population. There were more
psychiatrists in the city but few in rural areas. There was essentially one clinical psychologist to every 8,000,000
people. There was also a problem of 'brain drain' where more than 70% of those trained had left for the UK, US and
Canada. There was a high proportion of people with severe mental health problems and a huge population of
people with depression and anxiety who were not accessing care at all. Those who did were not diagnosed properly
and were not getting necessary medication because access to drugs was poor. Further training was required in
primary health.

129. There was one positive story where a victim of trafficking was approached by a trafficker outside the agency.
She told staff and they contacted NAPTIP and he was arrested. The victim of trafficking was very happy and said it
was like watching a film. She had complex PTSD which was not being treated and no funding was available for her
to be rehabilitated.

130. Mr Singh submitted that additional medical and psychological care was available to victims through other
clinics with agreements with NAPTIP.

131. The CORI report, drawing on the Danish Report, provides details of facilities available other than NAPTIP.
These are limited:

     - 2 transit shelters for children in Kano and Akwa-Ibom States.

    - WOTCLEF has 1 shelter accommodating 14 victims offering support in terms of skills such as sewing,
leather working and other handcrafts; advising victims of opportunities for micro credits and small scale
loans and providing for education. On average victims stay for 6 months but some may stay longer before
it is possible to reunite them with their families.

    - COSUDOW's shelter in Benin City in 2011 was reported to be functioning under severe funding restraints
and only able to take a maximum of 18.

     - Idia Renaissance offer counselling and vocational training (in Benin City). In 2007 they rehabilitated 30
girls and women referred by NAPTIP and 5 were at that time being rehabilitated; 2 were being housed.

    - AWEG established a centre in August 2012, but there was no information how many women it provides
for.

133. The CORI report refers to the USDOS Trafficking in persons Report 2012 that

“…despite documentation of a staggering number of Nigerian trafficking victims identified in countries
around the world, the government inconsistently employed measures to provide services to repatriated
victims…..Victims were allowed to stay in NAPTIP shelters for up to six weeks – a limit which was
extended by up to four additional weeks in extenuating circumstances – during which time they received
informal educational or vocational training; after this time, those who needed long term care were referred
to a network of NGOs that could provide additional services, though few long term options were available
for adult victims”


-----

134. The Finnish report considers the support provided by NGOs and records:

“Non-Governmental organisations help in the reintegration of victims and conduct awareness campaigns
against human trafficking. The non-governmental organisations that assist victims generally receive weak
support and are poorly co-ordinated, even though some service providers are highly professional and well
informed. …The low capacity of the organisations means that support can be unreliable and lack
therapeutic value. In addition, the organisations may not necessarily be able to provide the specialist
support that victims require. The organisations lack grants for victims' school tuition, vocational training or
business setup. The shelter personnel have limited capacity to provide psychosocial and rehabilitation
support to mentally handicapped victims, and the follow-up of rehabilitated victims is inadequate.”

135. The OSCE/ODIHR 2011 report confirms that domestic and international human rights groups generally
operate without Government restriction but that the NGOs which provide care and services to victims of traffic
trafficking

“… usually have severe capacity problems in providing services to victims especially those in need of
specialized care such as a victim with a child or with mental health problems.”

136. The OSCE/ODIHR 2011 report refers to the 2014 USDOS Trafficking in Persons Report recording that the
reality is that many victims returning from abroad are still not afforded proper rehabilitation and social integration.

**Conclusions on provision of protection**

137. Drawing together all this evidence, considered in the light of the submissions, our conclusions on the extent to
which sufficiency of protection is provided by or contributed to by NAPTIP, which is the protection provided by the
government of Nigeria, are as follows.

138. We place no weight on Mr Desmond's evidence about length of stay in a NAPTIP shelter – it was anecdotal
and as he said himself this was not a matter upon which he had any specific expertise or had conducted any
research.

139. The detail of the 'empowerment' material or how individuals utilised that material or its success was not
detailed in the evidence before us. Although it was claimed that there was monitoring, it appears that this was at
most ad hoc and very limited. In particular, those who leave the shelters without any ongoing criminal prosecution
appear not to be monitored in any meaningful way. There was no report of what action was taken if such monitoring
as there was identified breaches of any return agreement or further abuse and no statistical evidence is available to
establish whether such monitoring is effective.

140. NAPTIP's evidence was that, if a family objected to taking in a family member who had been a victim of
trafficking, they would continue until they were persuaded otherwise. This caused us concern when considered in
the light of the lack of evidence of any real, meaningful or effective follow up monitoring or protection provisions
when a victim is returned either against her will or against the initial will of the family.

141. Although the evidence before us is that NAPTIP are successfully prosecuting more traffickers, are maintaining
strong Anti-trafficking law enforcement efforts and are conducting training on victim identification, investigation and
prosecution, monitoring and evaluation, there was inadequate evidence before us to support a finding that these
measures were having a significant effect either on the number of victims trafficked for the first time or on the risk of
returned victims of trafficking being trafficked again. Nigeria remains one of the most prolific suppliers of trafficked
victims both internally and transnationally. The TIP report refers to a general increase of protection being offered,
but the numbers of those offered protection is very small in relation to the numbers of those trafficked. Any
protection offered by NAPTIP is very short term and does not address the significant risks of retrafficking to those
who are vulnerable to abuse. The mode of trafficking in Nigeria is not predicated upon abduction; those targeted
are targeted because of their particular vulnerability and such vulnerability is not, on the basis of the evidence
before us, reduced following a six week stay in a NAPTIP shelter. The Nigerian government has not made any
discernible efforts to decrease the demand for commercial sex. Whilst this demand remains, combined with the


-----

continued prolific provision of trafficking in human beings in Nigeria, there exists a real risk of internal or
transnational trafficking of those identified as vulnerable.

142. We conclude that where the services of NAPTIP are made available to a returned victim of trafficking, then for
as long as the support from NAPTIP continues, which includes the stay in the shelter and such psychological
assistance as there is, then the victim will not be at risk of being trafficked during that period of time.

143. There was evidence to the effect that the period of stay in a shelter could, in exceptional circumstances, be
extended but no evidence of this actually having occurred in fact. This implies that if an extended stay does happen
the individual has been identified as particularly vulnerable to abuse. The evidence before us does not support the
view that those who are particularly vulnerable to abuse are identified and provided with an extended stay in a
shelter.

144. The evidence before us does not support Mr Singh's submission that additional medical and psychological
care was available to victims through other clinics with agreements made with NAPTIP. Although some services
were provided, they were severely constrained and inadequate.

145. The IOM 2015 report critiques reintegration packages that do not provide for effective monitoring either
qualitatively or quantitatively and Dr Agnew Davies does not consider the counselling and psychotherapeutic
services available to returned victims of trafficking to be adequate. But the successful reintegration of 20% of
returned victims of trafficking indicates that in general there is sufficiency of protection for returned victims of
trafficking. That 70% 'go missing' is a neutral factor in the assessment of sufficiency of protection; it cannot be
concluded that they have again become victims of trafficking but nor can it be assumed that they have been
successfully reintegrated.

146. There was simply inadequate evidence to identify the characteristics of those who were successfully
reintegrated. It is not known, for example, whether they were able to return to a supportive family network; whether
the assistance they had received from the country to which they had been trafficked had enabled them to obtain
skills and psychological resilience such that they were able to access assistance in Nigeria including adequate
employment opportunities and thereby avoid destitution irrespective of their family situation; whether they did not
present with identifying factors of vulnerability such that they were identifiable as vulnerable to abuse or whether
they were able to return to a part of Nigeria other than their state of origin. So although in general it is our
conclusion that there is sufficiency of protection for women in general in Nigeria and that for some returned victims
of trafficking there is sufficiency of protection, there remains a strict requirement to consider and identify whether
and to what extent an individual returned victim of trafficking presents with characteristics that render her, despite
that sufficiency of protection, at real risk of being trafficked

147. So the real question is what is the risk faced by a returned victim of trafficking on leaving the shelter or if she is
not admitted to the shelter for whatever reason. We have considered this in the context firstly of a person who was
initially trafficked for the purpose of domestic servitude and then in the context of a person who was initially
trafficked for the purpose of sexual exploitation.

_Domestic servitude_

148. Outside the shelter there is unlikely to be an adverse risk from her original trafficker. There is no outstanding
debt to be paid. Whether or not her original trafficker is successfully prosecuted will make no difference to her.

149. Generally, there is no real risk of re trafficking by reason alone of having been previously trafficked. But there
may be a risk of trafficking by reason of her vulnerability.

150. If she escaped from servitude, generally there would be no continuing interest by the trafficker or the employer
but the possibility cannot be excluded in every case. The employer of the victim may demand repayment from the
family although the extent to which such demands could be enforced could depend upon the reach of the employer,
whether the transaction was at the instigation of the family, the nature of the deceit employed if any, whether the
two ends of the transaction were in contact initially or the extent to which the OCG remains contactable. The actual


-----

process used to traffic her may have resulted, for example, in some form of payment being made to her family or
some remaining duty or responsibility may require the victim, at the instigation of her family, to return to the enduser. A fact sensitive analysis will need to be undertaken to establish whether this is reasonably likely to be the
case.

151. If her family is supportive and takes the victim of trafficking back into the family of their own volition generally
she will not face a real risk of future persecution.

152. If a victim exploited for the purpose of domestic servitude is unable or for good reason unwilling to return to her
family she may face a real risk of vulnerability to abuse as to which see below for the impact upon her in terms of a
protection claim.

153. The indicators identified by Mr Desmond that could have led to her original trafficking may, as a result of
treatment that she has received during her period of domestic servitude, be enhanced. Such treatment may well
include sexual abuse. She will be older than when she was originally trafficked and so may be at an age where she
would be trafficked in the future for sexual exploitation.

_Sexual exploitation_

154. A victim who was trafficked for the purpose of sexual exploitation who is returned to Nigeria falls into one of
two categories – either she has paid her debt29 or she has not.

_If the debt has been paid by the victim of trafficking_

155. If the debt has been paid there will be no continuing interest in the young woman from her traffickers. Whether
or not her traffickers are successfully prosecuted will have no impact upon her.

156. Generally, there is no real risk of re-trafficking by reason alone of having been previously trafficked. But there
may be a risk of trafficking by reason of vulnerability.

157. There may be a real risk of serious harm from her family, whether or not they were initially complicit in her
trafficking for sexual exploitation. It is generally reasonable to conclude that her family would expect an economic
and financial return from her consequent upon her travel to Europe. Return to her previous trafficking situation
under the duress of family pressure, family violence, ostracism and stigmatisation by her community and possible
resultant destitution, homelessness and lack of any financial security is likely in most cases to amount to serious
harm.

158. If a victim who has been sexually exploited is unable or for good reason unwilling to return to her family she
may face a real risk of vulnerability to abuse as to which see below for the impact upon her in terms of a protection
claim.

_If the debt remains outstanding_

159. If the debt has not been paid there will be some continuing interest from the trafficker. The cost of trafficking a
woman for sexual exploitation is said to be somewhere between $50,000 and $70,000. On top of that
reimbursement of cost is the profit the traffickers expect to make from the exploitation. There was no evidence who
actually bore the significant or substantive costs or how the profits were divided between members of the OCG
other than reports that the main profit goes to the traffickers in Europe, but it is plain that there may be a significant
financial burden which remains outstanding together with continuing loss of income to the trafficker from the
exploitation. If the victim escapes, that loss of investment may well be significant. On the other hand, the evidence
does not indicate, generally, that retribution will occur to the young woman in Nigeria once she has left the situation
in the UK in which she is being sexually exploited. The risks of retribution occur whilst the young woman remains
under the physical control of her trafficker in Europe through, for example, threats to her family or to her; the
maintaining of control through the oath sworn. Similarly, the evidence does not generally indicate, once the victim of
trafficking has left the control of her traffickers, that her family will be the subject of retribution.


-----

160. There will be some individuals for whom that generality does not apply for example where the young woman
has been threatened or her family has been threatened after she left the trafficker.

161. Prosecution of her trafficker may have some impact but, as set out above, the evidence indicates that the very
organisation of Nigerian trafficking groups means that prosecution of one person does little to prevent trafficking
from occurring. Thus even if the victim identifies one or more of those involved in her trafficking, it is unlikely that
this would prevent her being re-exploited by that OCG if identified as vulnerable to being trafficked again.

162. There was no clear evidence before us of the extent to which active methods are employed to find individuals
who have escaped. The evidence does however indicate that the nature of the debt, the pressure from family and
community for financial return and the oath sworn all have an impact to the extent that in some cases an individual
returns to her traffickers without the need for express physical force from them. Mr Desmond's evidence indicates
that some considerable time may pass – maybe years- before 'enforcement' takes place although this was based
on one anecdotal incident.

163. If the victim of trafficking were able to return to her family and they were both willing to accept her and able to
provide her with appropriate support she would be unlikely to retrafficked. The evidence before us does not support
a finding that Nigerian traffickers, in general, resort to abduction (although that is not the case in the North East of
Nigeria).

164. There may be some cases where the family pose a real risk. For example, if the young woman was close to
paying off the debt, her family may require her to return to the trafficker to enable her to start sending money back
to the family. Close links between victim and trafficker through family or community ties would result in her being
identified as having returned home. There may be psychological and emotional pressure either for the victim to
“voluntarily” return to her exploiters or she will simply be trafficked again.

165. Generally, there is no real risk of re-trafficking by reason alone of having been previously trafficked. But there
may be a real risk of trafficking by reason of vulnerability.

166. If a victim who has been sexually exploited and is unable or for good reason unwilling to return to her family or
home area she may face a real risk of vulnerability to abuse as to which see below for the impact upon her in terms
of a protection claim.

_Vulnerability to abuse_

167. The factors that indicate vulnerability to abuse apply whether or not the debt has been paid and whether or not
the young woman was previously trafficked for the purpose of sexual exploitation or for the purpose of domestic
servitude. These factors assume that a willing family has not taken her back into the family household and there is
no respectable reason for the victim of trafficking not to return to her family.

168. A woman returning to Nigeria after having being trafficked may be subjected to the following indicators that she
is at enhanced real risk of being trafficked:

     - Some or many of the original indicators that resulted in her being identified and trafficked originally;

     - Rejection by her family;

    - The fact of being psychologically damaged subsequent to the serious harm she has sustained during the
period she was trafficked. This may render her less able to find work or access employment and result in
her being at enhanced risk of destitution;

    - The fact of being psychologically damaged subsequent to the serious harm she has sustained during the
period she was trafficked. This may render her less able to find work or access employment and result in
her being at enhanced risk of destitution;

    - Having been subjected to sexual abuse/exploitation during domestic servitude;

     - Remaining subjected to the spiritual and psychological pressures of any oath taken;


-----

     - Destitution;

     - Poverty;

     - Subjected to pressure from her family which is likely to be rural and in poverty, to provide an income from
sexual exploitation.

169. It is not simply that a young woman may face destitution, mental health problems, lack of education or poverty
that renders her vulnerable and vulnerable to abuse and at real risk of serious harm. The identifying factors that led
to her being trafficked originally may be present to a greater or lesser extent on her return to Nigeria. She may, for
example, no longer be likely to be deceived into accepting a job that in fact results in prostitution; she may no longer
be of an age where she is likely to be trafficked for domestic servitude. But her vulnerability and the indicators of
vulnerability to abuse may be enhanced. For example, although originally trafficked for the purpose of domestic
servitude she may have been sexually abused and may now be of an age where she is vulnerable to being
trafficked for the purpose of sexual abuse; she may find her options so limited that she approaches the same or
another trafficker. That 'quasi consent' resulting from the abuse of her vulnerability, an abuse of power, being the
means by which the trafficking takes place.

170. The analysis required is not simply whether a returned victim of trafficking will be destitute or poverty stricken.
As was made plain in Said, to succeed under Article 3 on removal to an appellant's country of origin on the basis of
poverty or destitution the appellant must show harm to D and N level. In Said, the appellant fell “far short” of that
test because the highest at which his case could be put is that his PTSD and depression will make it difficult for him
to reintegrate back into life in Somalia and will have some impact on his ability to work. There was no reason to
suppose that Said would be precluded from working and he would receive financial help from a supportive family
network. There was no reason to suppose that he would be unable to access medical treatment and so it was “so
far removed from the nature of exceptional and compelling circumstances envisaged in the Strasbourg cases” as to
make clear that Article 3 would not be infringed.

171. In an asylum context, it is the vulnerability to abuse that puts her at serious risk of being trafficked, whether for
the purpose of sexual exploitation or domestic servitude. Whether the risk to which she is thus exposed amounts to
serious harm is a matter for analysis. It is not the poverty, destitution or vulnerability itself which is the basis of the
claim, but the harm that ensues from that namely the exploitation.

_Sufficiency of protection_

172. Merely because Nigeria is 'doing its best' to meet its international obligations to prevent trafficking does not
necessarily result in a finding that there is sufficiency of protection for those identified as being at risk of being
trafficked. Sufficiency of protection is the combination of willingness and ability to provide protection to a level that
can reasonably be expected to meet and overcome the real risk of serious harm from non-state agents. The
'reasonable protection' required is assessed in the context of the risk, absent that protection, against which it has to
provide.

173. As said above, the incidence of prosecution of the trafficker who trafficked the victim in Nigeria is unlikely to
have significant impact upon that individual returnee, although of course increasing prosecution of offenders may
have a long term effect on the overall numbers of young women trafficked.

174. We have referred above to the particular characteristics that may render an individual at real risk of being
trafficked. That vulnerability presents on not being able to access the services provided by NAPTIP and NGOs. If a
woman presents as vulnerable to abuse, away from NAPTIP or a supporting NGO, the Nigerian authorities,
including NAPTIP and the instruments of State are unable to provide sufficiency of protection. The lack of adequate
monitoring of those who leave NAPTIP or an NGO shelter, the short period of time where an individual is in a
shelter unless there are exceptional reasons (which in itself implies that such a young woman is particularly
vulnerable and open to abuse) renders the protection available to an individual vulnerable to abuse insufficient.


-----

175. In making an assessment whether an individual is vulnerable to abuse a careful analysis of all her personal
characteristics is required to assess whether the indicators of risk, including any mistreatment in her previous
exploitative situation and the consequences of that for her personally.

176. This vulnerability combined with the inability of the state to provide the protection as set out in particular in
paragraph 174 above will render a returned victim of trafficking at real risk of being trafficked again.

177. The question then arises of internal relocation.

**Internal relocation**

178. Paragraph 339O of the Immigration Rules deals with internal relocation:

339O (i) The Secretary of State will not make:

(a) a grant of refugee status if in part of the country of origin a person would not have a well founded fear of
being persecuted, and the person can reasonably be expected to stay in that part of the country; or

b) a grant of humanitarian protection if in part of the country of return a person would not face a real risk of
suffering serious harm, and the person can reasonably be expected to stay in that part of the country.

(ii) In examining whether a part of the country of origin or country of return meets the requirements in (i) the
Secretary of State, when making his decision on whether to grant asylum or humanitarian protection, will
have regard to the general circumstances prevailing in that part of the country and to the personal
circumstances of the person.

(iii) (i) applies notwithstanding technical obstacles to return to the country of origin or country of return.

The Secretary of State has issued policy guidance, the most recent version of which is dated January 201530.

179. We remind ourselves of what was said in Januzi _[2006] UKHL 5:_

“21. ….The decision-maker, taking account of all relevant circumstances pertaining to the claimant and his
country of origin, must decide whether it is reasonable to expect the claimant to relocate or whether it
would be unduly harsh to expect him to do so….

…

45. …..the question whether it would be unduly harsh for a claimant to be expected to live in a place of
relocation within the country of his nationality is not to be judged by considering whether the quality of life
in the place of relocation meets the basic norms of civil, political and socio-economic rights. ….”

“47. The question where the issue of internal relocation is raised can, then, be defined quite simply. …..The
words “unduly harsh” set the standard that must be met for this to be regarded as unreasonable. If the
claimant can live a relatively normal life there judged by the standards that prevail in his country of
nationality generally, and if he can reach the less hostile part without undue hardship or undue difficulty, it
will not be unreasonable to expect him to move there.”

180. Mr Singh submitted that victims of trafficking may be able to relocate internally to escape localised threats from
members of their family or traffickers (or rogue state agents), depending on their particular circumstances, the
nature of the threat and how far it would extend. Single women including those who are pregnant or have children,
particularly those with no support networks or livelihood, may be particularly vulnerable though this may be
mitigated by the existence of shelters and assistance available from both government and civic society
organisations. Freedom of movement is generally available. Whether it was possible to internally relocate to escape
localised threats depends upon a person's circumstances including support and vulnerabilities. If she returns
voluntarily a victim would have the benefit of a return IOM package.

181. In contrast, Ms Cronin submitted that the opportunity for support from other shelters after leaving NAPTIP was
rare - WOTCLEF indicated that they only rescued 21 victims of trafficking in 2013 and 22 in 2014. There was limited
capacity to take any overflow Dr Agnew Davies stressed the requirement for customised rehabilitation so that an


-----

individual was not vulnerable to retrafficking. It was submitted that it was only if an individual had skills and a secure
and protective family to return to, and no mental health problems, would she not be at risk and/or able to relocate.

182. The Cherti report states that internal relocation within other areas of Nigeria might be an alternative but this is
problematic: relocation to another area increases vulnerability especially when a victim is young, uneducated,
without much working experience, and of different religion and ethnicity to the area of relocation. Tribal and religious
differences across the country, the concentration of services to assist are in areas where trafficked people typically
originate from and the stigma of trafficking can preclude successful reintegration, particularly for someone with high
support needs.

183. The Danish Report and the Finnish Report refer to the differing views of the NGOs as to the possibility of
relocation. But both reports refer to the potential lack of social networks that would be available, language
difficulties and the lack of ethnic ties.

184. The majority of victims of trafficking come from Edo and Delta States. But, as identified in the CORI report,
traffickers operate throughout Nigeria. Anti-trafficking networks have been set up in 22 states in Nigeria, Youth
Resource Centres provide information and skill learning to young people in 7 States and sensitisation programmes
run in 7 States where trafficking is endemic. In the North-east of Nigeria, Boko Haram utilises trafficking as a
primary means of funding; its attacks include abduction on a large scale leading to extremely severe and
widespread violations through sexual slavery and violence.

185. The essential issue to be determined is whether it would be unduly harsh, for an individual for whom there is a
real risk in her home area, to relocate. Such assessment must include not only the particular personal
characteristics of the individual, but those characteristics in the context of the potential area of relocation. In
reaching that assessment note has also to be taken of the prevalence of internal trafficking within Nigeria, not
simply the risk of transnational trafficking. There is freedom of movement within Nigeria but those who move state,
or indeed cities, are readily identified as coming from elsewhere.

186. It is not possible to state, on the evidence before us, that internal relocation is _never a viable option. An_
individual factual analysis will always be required of a victim of trafficking's vulnerability and its impact on the
possibility of internal relocation if she is at real risk of being persecuted in her home area. However the evidence
before us indicates that where an individual has been identified as being at real risk of being trafficked, the
possibility of internal relocation will be severely limited; particularly where she is vulnerable to abuse because of
lack of skills, mental and psychological problems and isolation.

**Country Guidance**

187. The guidance set out in PO (trafficked women) Nigeria _[2009] UKAIT 00046 at paragraphs 191-192 should no_
longer be followed.

188. Although the Government of Nigeria recognises that the trafficking of women, both internally and
transnationally, is a significant problem to be addressed, it is not established by the evidence that for women in
general in Nigeria there is a real risk of being trafficked.

189. For a woman returning to Nigeria, after having been trafficked to the United Kingdom, there is in general no
real risk of retribution or of being trafficked afresh by her original traffickers.

190. Whether a woman returning to Nigeria having previously been trafficked to the United Kingdom faces on return
a real risk of being trafficked afresh will require a detailed assessment of her particular and individual
characteristics. Factors that will indicate an enhanced risk of being trafficked include, but are not limited to:

a. The absence of a supportive family willing to take her back into the family unit;

b. Visible or discernible characteristics of vulnerability, such as having no social support network to assist
her, no or little education or vocational skills, mental health conditions, which may well have been caused


-----

by experiences of abuse when originally trafficked, material and financial deprivation such as to mean that
she will be living in poverty or in conditions of destitution;

c. The fact that a woman was previously trafficked is likely to mean that she was then identified by the
traffickers as someone disclosing characteristics of vulnerability such as to give rise to a real risk of being
trafficked. On returning to Nigeria, it is probable that those characteristics of vulnerability will be enhanced
further in the absence of factors that suggest otherwise.

191. Factors that indicate a lower risk of being trafficked include, but are not limited to:

a. The availability of a supportive family willing to take the woman back into the family unit;

b. The fact that the woman has acquired skills and experiences since leaving Nigeria that better equip her
to have access to a livelihood on return to Nigeria, thus enabling her to provide for herself.

192. There will be little risk of being trafficked if received into a NAPTIP shelter or a shelter provided by an NGO for
the time that she is there, but that support is likely to be temporary, possibly for just a few weeks, and there will
need to be a careful assessment of the position of the woman when she leaves the shelter.

193. For a woman who does face a real risk of being trafficked if she returns to her home area, the question of
whether internal relocation will be available as a safe and reasonable alternative that will not be unduly harsh will
require a detailed assessment of her particular circumstances. For a woman who discloses the characteristics of
vulnerability described above that are indicative of a real risk of being trafficked, internal relocation is unlikely to be
a viable alternative.

**Appellant's case**

194. The appellant is a Nigerian Citizen born in June 1989; she is a catholic. She entered the UK as a visitor on a
visa issued on 17th November 2006, aged 17. She escaped from the house where she was being held in mid-2007.
In late 2012 she was referred to the Poppy Project and in early 2013 claimed asylum. Her claim was refused in July
2013. After her appeal was dismissed by the First-tier Tribunal, further evidence was submitted to the respondent
and the asylum decision of 2013 was withdrawn. On 20th October 2014 the respondent made a Conclusive
Grounds decision that the appellant has been a victim of trafficking for domestic exploitation and she was granted
12 months leave to remain in the UK. Her asylum claim was dismissed and her appeal is now before us.

**Undisputed facts**

195. The respondent accepts that the appellant is a victim of trafficking saying

“..whilst living in Nigeria [she was] visited by a woman who offered to take [her] abroad. It is accepted [she]
stayed with this female in Lagos for a number of months and undertook domestic work for her. It is also
accepted that this female brought [her] to the UK where she handed [her] over to a family. Furthermore it is
accepted that [she] undertook domestic work for this family in the UK. Finally it is accepted that, having
escaped from this situation [she] lived with various men and had sex with them in exchange for food and
accommodation.”

196. The respondent does not “positively dispute” the additional factual matters set out in the appellant's statement
of facts and evidence namely (in brief)

i. She is from a rural village called Ubogu in Delta State. She had never travelled to the nearest town Ugeli
because it was too far away.

ii. She is an only child.

iii. Her father did not work and was in his 70s when she left Nigeria.

iv. Her mother died in 2010; prior to her death the mother worked selling leaves at the village market. No
other relatives live in the village. The family lives in a mud hut.


-----

v. The appellant was beaten by her father from a young age on most days and sometimes more than once
a day. Her father started to use sticks, whips and belts. He beat her mother when he had been drinking
alcohol.

vi. She speaks English, pigeon English and a little Urhobo.

vii. She attended school from aged 7 until 14 and was taught in English. She generally did not attend
school on Fridays because she helped her mother.

viii. As she became older, her parents' ability to pay school fees decreased and she attended school less
frequently sometimes causing gaps in schooling up to 2 months.

ix. Aunty 1 (a rich woman) came to the appellant's home and on her second visit brought gifts for her
parents –clothes and food – and a mobile phone for her father.

x. The appellant was taken to Lagos by Aunty 1 and was told she was being taken abroad to go to school.

xi. In Lagos she remained in a house for 2-3 months. Aunty 2 and three other children lived there. She did
not leave the compound during that time and undertook domestic duties, slept on the floor and ate left
overs. She was shouted at by Aunty 1 and Aunty 2 if she did anything wrong. Aunty 1 told her “they've got
people around” in Nigeria.

xii. A man came to the Lagos house and took her photograph.

xiii. She believes juju/voodoo to be efficacious and believes that she is unable to recall how she travelled to
the UK because it was used to entrance her. She knew she was no longer in Nigeria because it was cold.

xiv. A man (“Uncle”) collected her, Aunty 1, Aunty 2 and the three children from the bus stop. Aunty 1,
Aunty 2 and the three children left. She remained in the house with Uncle and his wife (“Aunty 3”) and their
3 children. She was immediately required to undertake domestic duties.

xv. Initially she slept in one of the children's beds and was fed. After about two weeks she was made to
sleep on the floor and the food she was given reduced. The children started hitting her, Aunty 3 was
physically abusive and threatened her with being sent to Nigeria and imprisoned.

xvi. Male associates of Uncle came to the house, looked at her in a manner that made her afraid and
behaved inappropriately. Aunty 3 told the appellant she was not behaving properly and phoned her father.
Her father shouted at her and told her to do what she was required and that if she did not then her parents
“would have problems”.

xvii. Male associates of Uncle asked her to sit next to them and put their arm around her. She pushed them
off. She was subsequently spoken to by Aunty 3, warned she would be sent to Nigeria an imprisoned and
told that it was as if she did not want to see her parents again.

xviii. After escaping from the London house she phoned her father who told her he was not happy, their
lives were in danger. Her mother begged her to return to the London house and said that they had been
threatened.

xix. After fleeing the London household she had sexual relationships in exchange for food and
accommodation; on one occasion she became pregnant and had an abortion at the behest of the 'father'.

xx. Her father telephoned her in 2010 and told her that her mother had died of a heart attack. She has had
no contact with her father or anyone in Nigeria since.

197. The respondent accepts that the appellant was trafficked for domestic servitude and does not dispute that she
may ultimately have been subjected to sexual exploitation if she had not escaped. Nor does the respondent dispute
that the appellant was likely to have been trafficked by a “gang” “in the sense of a number of people working
together although the precise number is a matter of speculation or she is a victim of past persecution. The
respondent considers that, taking account of the appellant's specific characteristics, there is sufficiency of protection
in Nigeria and/or it would not be unduly harsh for her to relocate.


-----

**Areas of dispute**

198. We have identified 4 elements of dispute between the parties that impact on the issues of sufficiency of
protection and internal relocation:

_Who trafficked the appellant?_

199. The respondent submits there was no evidence to suggest that the appellant was trafficked other than by a
small group of people and that such a form of trafficking is quite different from an international trafficking ring “with
many hundreds of people”.

200. As can be seen above, trafficking in the Nigerian context is through small organised groups with extensive
networks for the provision of specific services for example documentation and transportation. The appellant's
evidence described the involvement of 7 people – Aunty 1, the driver of Aunty 1, Aunty 2, a photographer, the
person who arranged the false passport, Uncle and Aunty 3. Some of those individuals may not form part of the
OCG but rather fell within a network (for example probably the photographer and the person who arranged the false
passport) and it is not possible to determine who was paid for what and how much. The appellant's evidence of her
recruitment and the mode of transfer to the UK is not disputed. Given the mode of operation of traffickers in Nigeria
this plainly points to her being trafficked by an OCG, utilising a network of contacts. The reference by the
respondent to an international trafficking ring with many hundreds of people simply does not resonate with the
mode of trafficking utilised in Nigeria on the basis of the evidence before us.

201. We find the appellant was trafficked by an OCG.

_Was the appellant trafficked purely for domestic servitude?_

202. The respondent's primary submission was that the appellant had been trafficked for domestic servitude. Mr
Singh accepted there were some factors that could justify a finding that the appellant had been trafficked for the
purpose of sexual exploitation but he submitted that any sexual exploitation that either had or would in the future
take place would be at the behest of the Uncle and there was no evidence that either Uncle or Aunty 3 had the
necessary contacts to pursue her on her return to Nigeria.

203. There is, as explained above, a fluidity within trafficking. Those trafficked for domestic servitude may end up
being sexually exploited or otherwise discarded when they cease to be required for domestic servitude: whether
because they are to be replaced by a younger child or because the 'wife' in the family does not wish a young
woman in the household. We note that Mr Desmond was aware of cases where individuals were brought to the UK
and 'held' awaiting onward trafficking for sexual exploitation. The following factors point to the appellant having
been trafficked for the purpose of sexual exploitation:

     - She was at the higher age range for recruitment for 'pure' domestic servitude (age 17);

     - The provision of the mobile phone to her father;

    - The attitude of Aunty 3 towards the appellant when she refused to comply with the inappropriate
advances made towards her;

    - The approach made by Aunty 3 to her father to coerce her to co-operate;

    - The appellant's mother's plea that she return to the household because of threats her parents had
received;

     - The possible use of juju/voodoo;

     - That on transfer from one country to another she was not exploited by the same family;

     - That she was not related to any of her traffickers;

    - That the forged documents on which she travelled appear to have been of high quality.

Against this is:


-----

    - the lack of rape or forcible sexual advances (albeit there were inappropriate advances made) either in
Nigeria or in the UK;

     - The lack of sexual grooming either in Nigeria or the UK;

     - She was not given a 'legend';

     - if the sexual advances in the UK were the initiation of sexual grooming they were instigated late in the
process of trafficking – some 6-9 months after she left her home;

    - Although there is a possibility of an oath the evidence was limited as to its extent and limited to her
believing that she was unable to remember her journey because of it;

    - there does not appear to have been any attempt to trace her in the UK since her escape.

    - The cost of trafficking a person to the UK is high and no attempt appears to have been made to recoup
that cost by forcing her to work as a prostitute

204. The absence of rape/grooming appears inexplicable given the period of time that elapsed since the appellant
left her home and the cost of trafficking a person to the UK. Although Mr Desmond gave evidence of victims being
brought to the UK and held awaiting onward transportation, there was no evidence before us that during that time,
the victim would not be groomed. Although his evidence was that those trafficked for sexual exploitation would be
expected to undertake domestic tasks, those would be ancillary to the main purpose of their exploitation.

205. That a person is trafficked for the purpose of domestic servitude does not prevent sexual abuse or exploitation
but that exploitation is not in the context of trafficking. The evidence before us illustrated the vulnerability of victims
trafficked for domestic servitude and the real possibility that such victims would be sexually abused. Mr Desmond's
evidence was not that all those trafficked for domestic servitude would, where sexual advances were made by
members of the household, be 'thrown out on the street'. His evidence was that where that happened it could be
because the 'employer' had decided to exploit the victim sexually but it was not by the traffickers. The Rev Dr
Pemberton-Ford also spoke of what could be categorised as a transition to sexual exploitation where victims were
subjected to domestic servitude.

206. Having considered the appellant's evidence in the context of the overall evidence before us, we conclude that
this appellant was not trafficked for the purpose of sexual exploitation but was trafficked for the purpose of domestic
servitude. We are satisfied on the evidence before us that the household within which she was living were
intending to sexually exploit her and thus although she was not trafficked for the purpose of sexual exploitation she
was at the commencement of sexual exploitation. We are satisfied that the household decided to undertake private
exploitation, effectively at arm's length from the traffickers who brought her into the UK.

_Risk of retrafficking_

207. The personal, medical and psychotherapeutic evidence before us, which was not disputed save as referred to
below, establishes that the appellant is a young, ill-educated single woman with no skills other than domestic work.
Her family were complicit in her trafficking and she has no financial support. She has been taunted, bullied, beaten
and exploited by various perpetrators including her father and those who trafficked her. She was sexually exploited
by men who claimed to be assisting her after she fled the place of domestic exploitation. She has complex PTSD,
borderline personality disorder and major depressive disorder. She presents like a child although she is now aged
26. She has poor judgement, often getting angry and losing her temper. She takes risks in relationships in an
attempt to gain protection and security. She does not trust the police.

208. Ms Cronin submits that the appellant's persistent pattern of dissociative behaviour makes her clearly visible to
potential abusers and that she has resorted to 'survival sex'. Ms Cronin submits that, as said by Dr Agnew-Davies,
she cannot support herself or function. The abusive sexual activity is not an indication of trafficking but is an
indicator of vulnerability.

209. Mr Singh disputes that the appellant would be unable to support herself or would be unable to function. He
refers to her ability to seek assistance for example from the caretaker of the property where she now lives and from


-----

her solicitors when she became lost on her way to an appointment. He submits that the appellant is able to travel
around independently and is currently on medication that is available in Nigeria; she is not receiving any specific
intensive psychotherapeutic assistance and any such assistance would be available to her in Nigeria, albeit not to
the same standard as in the UK; there are shelters available for her in Nigeria; she would benefit from an IOM
returns financial package; the OCG/OCN was not large and there would be no interest in her on her return to
Nigeria. He submitted that the appellant was sold to Uncle and Aunty 3, who were not part of the OCG, by Aunty 1
and 2.

210. It is not possible to identify everyone involved in an OCG or the role they play within it. The evidence we heard
makes plain that the very nature of the Nigerian mode of trafficking results in identification (and thus prosecution)
being difficult and in any event the removal of a trafficker from an OCG does not make any discernible difference to
the possibility of trafficking occurring through the remains of that group. It is simply not possible to conclude that
Uncle and Aunty 3 were not part of an OCG – they had contact with Aunty 1 and 2; they sought to enforce the
applicant's domestic exploitation through contact with her parents both directly and indirectly through threats that
were made. Skilled documents forgers were employed to bring the appellant into the UK, the document escaping
the attention of ECOs and immigration officials at the border despite it being known that Nigerian forgeries were
prevalent.

211. Although the respondent asserts that Aunty 2 was not a repeat facilitator/trafficker it is not clear from the
respondent's evidence on what basis she reaches that conclusion. Aunty 2 appears from the respondent's evidence
to have visited the UK on a number of occasions with children (whether the same children or different children is not
stated); although the two children with whom she travelled when she brought the appellant in to the UK left with her,
it is not clear on what basis that conclusion was reached given that the UK does not maintain a record of
departures. Nor is it clear whether that has been the pattern on each occasion Aunty 2 travelled to the UK with
children or whether she returned to Nigeria with the children or travelled to Europe.

212. If the appellant is met by NAPTIP on arrival in Nigeria she can expect to be taken to a NAPTIP shelter.
Although in the shelter she would not be at risk of being trafficked, the evidence before us is that she would in effect
be locked up for the duration of her stay and only allowed out with a chaperone. We acknowledge that this is done
by the Nigerian authorities for a victim's protection, but in this appellant's case such restriction on her movements
would, on the basis of Dr Agnew-Davies evidence and the other medical evidence before us, which is not disputed
and which we accept, cause significant re-traumatisation. We accept Dr Agnew-Davies evidence that such retraumatisation would result in a significant deterioration in her mental capacity to cope and function.

213. It is established by the evidence that NAPTIP intend and aim to return victims of trafficking to their family as
soon as practical. Although they acknowledge that families may have been complicit in the trafficking – as here –
their response is that they keep an eye on the family. As we have seen, the level of monitoring that takes place is
inadequate and not meaningful. A return of this appellant to her father is neither appropriate nor adequate. She was
beaten and severely maltreated as a child by her father, her father was complicit in her trafficking and he threatened
her and shouted at her when she left the household. Whilst those threats may have been as a result of threats that
he received, we are satisfied that even following counselling and visits, he would continue to ill-treat the appellant if
she returned to him. She would be unable to live in her village or community without being found by her father with
the resultant abuse that would be very likely to follow. Although the appellant may be able to provide descriptions of
her traffickers and possibly the place where she was held in Lagos, it cannot be concluded that such evidence (of
events several years ago) would be likely to bring the applicant into that small group of victims who are monitored.
The level of monitoring that would take place would, we are satisfied, in her case be minimal.

214. If as a result of being unable, or justifiably in her case unwilling, to return to her father or her village, she
remains in the NAPTIP shelter for the full six weeks, there being no evidence to indicate or suggest that she would
benefit from a wholly exceptional extension of stay, she would then have to leave. Although the respondent
submitted that she would be able to go to another shelter run either by the Women's Affairs or an NGO, as we have
said above we do not accept that such further shelter is in practice available for longer than six months and in any
event the possibility of access to such an NGO shelter is effectively unavailable given the extremely sparse
numbers of beds available and the huge scale of trafficked victims in Nigeria.


-----

215. The practical result of this is that after 2 or possibly 6 weeks or at most 6 months this appellant would be
released. Although she would, if returning voluntarily, have the benefit of an IOM financial package, any such
financial package would be rapidly exhausted given her lack of employment skills and inability to function effectively
on her own; she would be homeless and living on the streets.

216. There was no evidence before us that those who trafficked the appellant attempted to find her in the UK. Mr
Desmond's evidence included details of one victim who was traced some 10 years later through her son and
required to repay the debt outstanding. There is evidence, which was not disputed, that the appellant's mother
(some time before her death in 2010) and her father received threats subsequent to the appellant leaving the
household where she had been held. (After leaving that household she was sexually exploited by men she had met
in the UK. They were not, and it has not been suggested that they were, involved in her trafficking.)

217. The evidence before us did not indicate active searches for individuals in Nigeria. If she returned to her home
area we are satisfied that her original traffickers, other than her father, are unlikely to maintain an interest to the
extent of actively seeking her out. We are satisfied that at present she would not be returning to Nigeria with the
level of personal skills that would enable her to survive without displaying the vulnerability to abuse that would
render her susceptible to trafficking.

218. We are satisfied that to return her to her father would be to place her in the position either of him being
complicit in her retrafficking or subjected to serious physical abuse.

219. The evidence before us including a psychiatric report from Dr Katona, and evidence from Dr Agnew-Davies,
satisfies us that this appellant was not only a previous victim of trafficking with characteristics that can be identified
from paragraph 62 above but that her experiences during her exploitation have rendered her at enhanced
vulnerability.

220. Irrespective of the fact that there is mental health provision, albeit to a lower standard to that in the UK, this
appellant is vulnerable. Although she is able to seek assistance, that assistance is sought from those who are in
positions of caring for her – the caretaker of her accommodation and her solicitors. When she was not in such a
protected environment she sought assistance from individuals who then sexually exploited her, were violent and
abused her. There is psychiatric assistance available in Nigeria but the availability of such assistance is not the
issue. This is not a case where the N/D threshold has to be met in order to access protection. The issue is whether
the extent of her psychiatric and mental health problems is such as to render her vulnerable to trafficking because
of an inability to protect herself. The medical evidence is that her behaviour would be likely to deteriorate due to
stress and there is a lack of facilities and/or referral available for trafficked victims from inexperienced NAPTIP staff.

221. It is the fact of her vulnerability that renders her at risk of being trafficked. Although she is older than many of
those trafficked, she displays significant numbers of the indicators. She presents as child-like because of her
psychological and mental health problems; her chronological age would not, in our view prevent her being identified
as a potential victim.

222. We are satisfied that she presents as a young woman who is at real risk of being trafficked and sexually
exploited. The TIP report shows that even though the Nigerian authorities are increasing their efforts to provide
protection and there are increasing levels of prosecution, the very nature and extent of Nigerian trafficking for
sexual exploitation renders the provision of protection for this appellant, presenting with her individual
vulnerabilities, illusory.

223. Mr Singh submitted that many victims are vulnerable with mental health difficulties and that there was a lack of
research to indicate that women in those circumstances were at risk. He submitted that if that were the case there
would be research which indicated that she and others with similar problems would be at risk. He submitted there
was no specific vulnerability that placed this appellant at risk of being trafficked that would seriously adversely
impact upon the protection available to her or render relocation unduly harsh. We do not accept this submission.
The indicators of those vulnerable to trafficking are met by this appellant, save for her age. She has previously been
trafficked for domestic exploitation. The fact that the Nigerian authorities are trying to provide protection is laudable
but does not translate into sufficiency of protection for this appellant given her vulnerability Her vulnerability has


-----

been abused previously. The CARE project which provided specific follow up for particular individuals with intensive
support being provided resulted in 20% being successfully reintegrated. The vulnerability of this appellant is such
that it is difficult to conceive of her being able to successfully reintegrate. There was no evidence before us, other
than as discussed above, to indicate that government and civil society were able to provide sufficiency of protection
for an individual presenting as this appellant does. The TIP report identifies that the authorities are making
strenuous efforts to provide protection and assistance, but it does not support a finding that there would be the
possibility of sufficiency of protection for an individual such as this appellant.

_Internal relocation_

224. The vulnerability of the applicant would be manifest on her return. Although Mr Singh submitted that she would
be able to access social and community assistance, any such assistance is concentrated in the areas where
trafficking is rife and in any event such provision is short term. Elsewhere she would have additional difficulties to
overcome including ethnicity and language. The majority of trafficking victims emanate from Edo and Delta States,
but internal trafficking occurs across Nigeria. Her vulnerability to abuse would be manifest and enhanced because
of tribal, language and isolation issues. She has no skills other than domestic skills. Given the appellant's
vulnerabilities, her limited skills and difficulties in practical management, we have no doubt that her return and
relocation elsewhere than her home region would be unduly harsh and she would remain at real risk of being
trafficked.

_Conclusion_

225. Drawing this together we conclude the appellant was trafficked to the UK by an OCG. She cannot reasonably
be required to return to her family. The protection offered by NAPTIP is short term only and on leaving the hostel
she would be at real risk of being trafficked. Internal relocation would be unduly harsh.

226. The making of the decision of the First-tier Tribunal did involve the making of an error on a point of law and is
set aside.

We re-make the decision in the appeal by allowing it.

**ANNEX 1**

**The expert witnesses**

Reverend Dr Carrie Pemberton-Ford

1. The Reverend Dr Carrie Pemberton-Ford has described the extensive research and personal links she has
developed with a large number of organisations, both governmental, non-governmental and academic. She has not
been to Nigeria and has not conducted any direct field work there. She is a Visiting Senior Research Associate at
the University of the Free State in the Republic of South Africa in the Department of Law, Senior Research
Associate at the African Studies Centre at the University of Cambridge, Director of the Cambridge Centre for
Applied Research in Human Trafficking [CCARHT], which is an affiliated non-governmental organisation with the
United Nations, and a Member of the Human Trafficking Foundation network and Director of the National Charity
Churches Alert to Sex Trafficking. She was Chair of the Educational Research Board for the United Kingdom
Human Trafficking Centre in Sheffield in 2006 and was responsible for encouraging a number of research initiatives
to explore the situation around trafficking in Nigeria and West Africa.

2. She is frequently invited to speak on issues pertaining to human trafficking in the UK, at European level and at
UN based conferences. She has worked on research proposals with the United Nations Institute for Training and
Research with particular attention to West and Central Arica. She has reported on particular manifestations of
trafficking for the Religious Congregations responding to Trafficking and Religious Sisters across Europe against
Trafficking.

3. As director of a CCARHT project for Churches Together in England she worked with Nigerian Church networks
across the UK on human trafficking “particularly its impact on females in domestic servitude false


-----

adoption/fostering, gamete harvesting and sexual exploitation.” She is writing the report (due to be published in
September 2016) which would be

“the most comprehensive study so far to have studied this important sector of a potential informal support
system for any Nigerians trafficked into the UK, and [it] will elucidate some of the patterns of exploitation
and the trafficking of females from Nigeria in the 'informal domestic labour' market of the Nigerian diaspora
in the UK.”

The project has, she said, involved face-to-face consultation with all churches in the UK, asking them about
networks into Nigeria and West Africa and an online survey. She had been looking at what was happening to those
who had been trafficked and the worries about those who had been returned. She stated that this research should
“cascade into secondary work”. The Rev Dr. Pemberton–Ford stressed the “hidden” nature of the crime, the fluidity
of domestic servitude into sexual exploitation and the need for considerably more research to enable a more
evidenced based response to the issues raised. The extent of this research was not clear from the answers she
gave in oral evidence; whether it was primary resource research; whether it was research into the social support
provided by the Nigerian based churches in the UK to victims and the effect on return to Nigeria of those victims or
whether it was research into potential involvement in trafficking. She identified that “more research” was required
but we were left unclear as to what that research would be on.  We were also left unclear from her evidence why it
was not possible for her to provide a clearer and more detailed account about domestic servitude in the UK.

4. The Rev Dr Pemberton-Ford has not undertaken any direct field research in Nigeria and has not visited Nigeria
but “over some 15 years [has] worked with survivors of trafficking abuse in the UK, and consulted with a number of
agencies in Nigeria working on trafficking and with trafficking victims. These include - the Edo State Market
Women's Association and Women of Africa and the Gender Mainstreaming Directorate in the Commonwealth
Secretariat on counter trafficking initiatives in Nigeria.”

5. Her written report and oral evidence to us addressed the issue of “debt” in trafficking for domestic servitude
primarily by analogy with Campana's report31 on financial models developed from secondary research of trafficking
for sexual exploitation in Italy. She was not able to draw on any research, either her own or research in progress
that informed her of this directly. She said that more research was needed to enable firm conclusions to be drawn.

6. Mr Singh did not take issue with the expertise of the Rev Dr Pemberton-Ford save for the following points:

(a) her approach to what she described as the “business model” for the financing of trafficking for domestic
servitude (the Campana model); and

(b) given that in “pure” domestic servitude trafficking cases, the “profit” to the traffickers came from the
person who employed the victim of trafficking, her suggestion that this person could be one of the
traffickers was flawed because that would defeat the purpose of the trafficking which was to make a gain.

Dr Agnew Davis

7. Dr Roxane Agnew-Davies is a specialist on the impact of violence, particularly domestic and sexual violence or
trauma on women's mental health. She is the Director of Domestic Violence Training Limited and an Honorary
Research Fellow in the School of Social and Community Medicine at the University of Bristol. She is an Associate
Fellow of the British Psychological Society and a full member of the Division of Clinical Psychology. For five years
she was the Head of Psychological Services for Women at Refuge, the national charity for women escaping
domestic violence and has been specialist advisor to various programmes in the Department of Health. She is a
clinical psychologist and qualified to make clinical assessments of mental health. She is a Cardiff University
accredited Expert Witness.

8. Dr Agnew-Davies last visited Nigeria in 2011 as part of a multi-disciplinary fact-finding trip to explore service
provision for victims of trafficking, funded by the Organisation for Security and Co-operation in Europe (OSCE). Her
role was to evaluate psychiatric services available to trafficking victims returning from Europe. She met with various
mental health professionals including psychiatrists, clinical psychologists, the chief nurse at state hospitals in Lagos


-----

and Benin City and representatives of NAPTIP and NGOs working with trafficked victims. In writing her report for
this appeal she sent them the section of the report dealing with that visit and asked for an update and comment.

9. Although not a specialist, nor purporting to be an expert in her knowledge of the extent or nature of trafficking in
human beings in Nigeria, she was also able to give evidence from conversations she had with nurses and doctors
she met during the course of her trip in addition to the fact finding elements she reports on. She said that “a lot of
people had child help costing the equivalent of about £500 a year”. It was, she had been told, very common
amongst young professionals with young children and 80% of young professionals in Nigeria would have a house
help. One of the nurses confirmed to her that she had a “house help child” from Togo whom she used to prevent
domestic violence against her, if the nurse did not cook food in time, her husband would beat her, but she was at
work and could not cook food, so she used the house help. Dr Agnew-Davies said she was told that many of the
nurses have house help, usually children. There were some cases where the children were sexually abused by the
husband. One nurse told her she had arranged an illegal abortion for her house help and then exchanged her for
another one.

10. Dr Agnew-Davies also commented that the prevalent attitude to mental illness in Nigeria was that it was caused
by supernatural forces.

11. Mr Singh did not take issue with Dr Agnew-Davies' expertise. He disputed her conclusion that the appellant was
unable to function on her own without active support, given her described vulnerability, but he did not take issue
with the description of her mental health diagnosis.

Mr Andrew John Desmond

12. Mr Desmond is a freelance consultant with Anti-trafficking Consultants and Trafficking.ch. The former is a
company he formed with others, the latter an association with a person in the Swiss Immigration Service
responsible for female asylum applicants. Mr Desmond is recognised by the United Nations Office of Drugs and
Crime (“UNODC”) as an expert in the field of investigating human trafficking. He has been employed by UNODC to
deliver anti-trafficking training on their behalf. He lectures and trains on human trafficking for exploitation nationally
and internationally. Between 1981 and 2012 he was a police officer with Hertfordshire Constabulary and the
Metropolitan Police. In 2008 he was recruited to New Scotland Yard Anti-Human Trafficking Team - the first
dedicated police unit within the UK. He has been both the principal and the support investigator in a number of
investigations into Organised Criminal Networks that are responsible for the trafficking of human beings for
exploitation into the UK principally from Nigeria, but also from Albania, Belarus, China and Vietnam. He has
undertaken detailed research into Juju and associated West African spiritual beliefs and the rituals used by
traffickers. In 2012 he interviewed every Nigerian suspected victim of human trafficking that came to the notice of
the Anti-Human Trafficking Team. He has trained law enforcement officers in Abu Dhabi, Switzerland and in the UK
and has trained officials and NGOs working with vulnerable victims.

13. Mr Godwin E Morka, the “Ag Director” of NAPTIP has attested that Mr Desmond has expertise on the trafficking
of persons from Nigeria and he had “no hesitation in recommending Mr Andy Desmond as a fit and proper person
to speak on the issue of trafficking of persons from Nigeria.”

14. Mr Desmond has not met HD. He has not travelled to Nigeria because he had been warned by the Nigerian
authorities that the nature of his work placed him at high risk of harm. He specifically confined his report to matters
concerning trafficking networks that being his area of expertise from his employment and consulting experience.
Although he gave anecdotal evidence (from conversations with NAPTIP officials and other law enforcement
officials) of possible risks to the appellant if she were to be returned to Nigeria he made clear that he had no
expertise either as to that or her possible circumstances if returned.

15. The respondent accepted the appellant had been trafficked by a gang in the sense of a number of people
working together. He did not take issue with the detail of Mr Desmond's evidence.

The late Mrs Bisi Olateru-Olagbegi


-----

16. The Tribunal has received a report prepared by Mrs Olateru-Olagbegi. Sadly, she died before the date of the
hearing. Mr Singh did not refer to her report either in his skeleton argument or in submissions. We have had regard
to her report and must make of it what we can, even though no questions were put to her in response to her report
and there was no opportunity to hear live evidence from her.

17. Mrs Bisi Olateru-Olagbegi's was a qualified lawyer with 39 years post qualification experience and a notary
public. She had been a consultant to a World Bank project on Women's Human Rights with the National Women
Development Centre Nigeria in 2003 and 2005 and a consultant to UNESCO Paris for the co-ordination of a
research study on the trafficking of women and children in West Africa. In March 2006 she was appointed the
Nigerian Ambassador for the elimination of gender violence. At the date of her report she was Executive Director of
Women's Consortium of Nigeria (“WOCON”) – an NGO holding UN special consultative status with a sustained
focus on human trafficking and other forms of gender violence at national, regional and international levels.

18. She was personally involved in research studies, and has written and published jointly and solely, on issues of
human trafficking in Nigeria and West Africa. She has co-ordinated activities and campaigns on behalf of WOCON,
United Nations Agencies, UNIFEM, UNICEF, UNESCO and the International Labour Organisation on issues of
violence against women and children, human trafficking and forced labour. In recognition of her work on the issue of
human trafficking and gender violence she was awarded, in March 2006, the Daisy Gorge Award by Sister to Sister
International Inc of USA at the 50th Session of the United Nations Commission on the Status of Women.

19. Mrs Bisi Olateru-Olagbegi did not meet HD; she drew her conclusions on possible risk to HD on return to
Nigeria from the evidence contained within the various witness statements given by HD and the medical information
she was supplied with.

**ANNEX 2**

**Submissions**

1. The parties have put before the Upper Tribunal a considerable body of evidence concerning the country
guidance questions to be addressed. This is itemised in the appendices to this decision. It is not possible to
discuss each and every piece of evidence that was produced to us but for the avoidance of doubt, not only have we
had specific regard to that evidence to which our attention was drawn, but also to the whole of the evidence that
was before us.

2. There was very little primary source research material before us but, where appropriate, we have endeavoured to
identify such material. Some material contained some primary source material even though overall it could be
considered secondary source.

3. Both advocates in their submissions referred to an EASO Country of Origin Information Report – Nigeria: sex
trafficking of women dated October 2015. This is tertiary research32, a useful synthesis of material (referenced)
selected by EASO for inclusion. To that extent it is a useful summary of a considerable body of material available.
We were unable to access all of the documents that are footnoted in the document as having been drawn upon.
Plainly this is not to say that the EASO document is not helpful. It is a good source for the wide ranging
documentation that is available, but it is not a report based upon independent original quantitative or qualitative
research. The interpretation of the material referred to therein remains a matter for judicial interpretation and the
weight to be placed upon the various documents in the context of an asylum appeal remains a judicial exercise.

4. Both advocates identified to us that some of what appears to be relatively recent material may in fact be
predicated upon much earlier research material, both primary and secondary source material; for example the
Finnish Immigration Service, Human Trafficking of Nigerian Women to Europe Report dated 24th March 2015 relies
to a considerable extent upon material considered in the report of the Danish Immigration Service's fact finding
mission to Lagos, Benin City and Abuja – Protection of Victims of Trafficking in Nigeria dated April 2008. This is not
to say that the more recently dated material is inaccurate but caution needs to be exercised when considering the
up to date position to ensure that assertions relied upon to reach conclusions are in fact as current as possible.


-----

Summary of submissions on behalf of the respondent

5. Mr Singh submitted that the main question to be answered with regard to a victim of trafficking was whether her
traffickers would have sufficient interest and/or capability to target her on her return to Nigeria. He submitted that
the answer to this question depended on a number of factors which included:

a. The purpose for which the individual was trafficked. If the victim was trafficked for the purpose of
domestic servitude only, then generally there would be no real risk on return because the “transaction” had
been completed, payment made and received and so there was thus no continuing interest. He also
submitted that if the victim was trafficked for domestic servitude and the sponsor/employer subsequently
decided to exploit her sexually then in the absence of any ability on the part of the sponsor/employer to
pursue her to Nigeria there would generally be no real risk on return, such exploitation being as a
consequence of the arrangements arising from the domestic servitude and not from any on-going
trafficking network/gang involvement.

b. Other factors to be taken into account included whether any attempt had been made by the trafficker to
harm the victim in the UK or to target the victim's family in Nigeria; the length of time the victim had been
away from Nigeria and the power and reach of the particular traffickers.

c. To qualify for international protection, the claimant would need to demonstrate that the reach of her
original traffickers was such that they were realistically capable of targeting the victim upon her return to
Nigeria, or that she would be at serious risk of being re-trafficked by other traffickers and internal relocation
was not a viable option.

6. Mr Singh submitted that although Nigeria does not fully meet the trafficking minimum standards set by the US
State Department, in combination with the present protection available, the following matters resulted in the Horvath
threshold being met: the amendments to existing legislation enabling stiffer penalties on conviction for trafficking;
the provision of support by NAPTIP and through NAPTIP to other NGOs; that generally freedom of movement was
possible.

7. In relation to prevention of trafficking he submitted the evidence showed that there were strong anti-trafficking law
enforcement efforts and increased penalties, convictions and sentences of up to fourteen years and an increased
budget and strong efforts to protect trafficking victims. There was no doubt that Nigeria met the Horvath standard
with the anti-trafficking law in place and there is sufficiency of protection.

8. The respondent accepted that a victim of trafficking may be at risk if the sponsor in the UK was able to pursue
the victim.

Summary of submissions on behalf of the appellant.

9. Ms Cronin submitted that the essential issue to be considered was the risk of proscribed treatment – serious
harm and lack of protection. She submitted that _PO (Nigeria) was not a starting point – the focus in that case,_
including the paragraphs that the Court of Appeal had preserved, was concerned with gangs and debt. The
enlarged focus on the nature of the exploitation namely whether for domestic servitude, for sexual exploitation or
both does not redeem _PO for its understanding of risk and protection. There is, she submitted, a requirement to_
engage with the dynamic experience of trafficking, the vulnerability of the victim, the practical help available and
accessible and for there to be an assessment of what happens when any support that may be provided on return is
withdrawn. She submitted such an approach was in accordance with paragraph 339K of the immigration rules,
article 4 Council of Europe Anti-trafficking Convention and the Palermo protocol.

10. Ms Cronin submitted that the trafficking instruments do not change the definition of who is a refugee but the
obligations that the UK has under the trafficking instruments are relevant. This includes the duty to investigate
trafficking cases. The duties to the victim should inform the assessment of risk, effective protection and relocation.
To understand risk and the opportunity for safe and reasonable relocation to avoid localised risk required a finegrained analysis, not through prescriptive evaluation of risk by reference to particular factors or by resorting to
general guidance on prescriptive types of trafficking.


-----

11. Ms Cronin submitted that an assessment of risk was not solely about gangs and debt. She acknowledged that
debt was relevant, but assessment of risk was about victims. She submitted that there may well be evidence of
ongoing interests and reach, or indeed no evidence of such matters, but for this to be the sole guidance would rule
out other evidence of the potential for retrafficking. She submitted that clear indicators of risk include the occasions
when the risk arises.

12. Ms Cronin submitted that generic guidance on risk and protection was insufficient. It was necessary to look at
the arrangements for protection to ensure that the victim was not in a situation of vulnerability. It was not a
prescriptive risk, but each case should be decided on its own facts and it was necessary to evaluate the risk with
reference to a number of factors namely :

(1) Indications of sophistication of operations or trafficking threat which extended beyond the family. There
were many variables in trafficking and it was necessary to look at the individual trafficking circumstances
focusing on the individual.

(2) Serious harm in the appellant's own country. This appellant had suffered serious domestic abuse,
lifelong domestic abuse and it was accepted that she was trafficked to Nigeria. This was highly relevant.

(3) Factors dealing with the individual victim such as background, education, experience of abuse, skills
and capacity for self-protection or capacity for sound judgment.

(4) Analysis of the position in the home state. Whether there were shelters, support, and length of stay in
the shelter. For example, in Albania there could be a stay of up to two years and there was also a realistic
work option and employment.

(5) Where the state did not provide a welfare state there had to be a safety net of the family or an ability to
provide support. The family would not be able to do so if they were complicit in the trafficking.

(6) Issues of shame and stigma. Young women returned from Europe are seen to be prostitutes and this
further impeded their integration.

(7) If there was not effective prosecution and criminalisation of trafficking then the traffickers can act with
impunity.

(8) Whether the person was in debt to the trafficker was a relevant issue but not the sole driver of the risk
on return.

**ANNEX 3**

**The Elements of Trafficking**

1. Although the Danish Immigration Service fact finding Report “Protection of Victims of trafficking in Nigeria” (“the
Danish Report”) was undertaken between 9 and 26 September 2007, subsequent reports and academic articles
draw heavily upon that report. The primary research conducted since then does not indicate any significant changes
to the mechanisms of trafficking. Traffickers utilise various methods to undertake their business. Some specialise in
document and passport forgery, while others specialise in recruitment and transportation.

2. Mr Desmond's undisputed evidence was that expenditure on the documents used to traffic women varied
depending on the quality of the documents used. If a document had been issued by a corrupt official, in that it was
genuine document in a false identity that would be far more expensive than if the document was a forgery. A forgery
is more easily detected and therefore if stopped the trafficker could lose the valuable commodity, namely the victim.
The IOM 2006 report records that research undertaken by Okojie and Prina in 2003 indicates that because Nigerian
passports can raise suspicion, false passports from other countries are used – Benin, Ghana, Togo and Senegal.

3. The Cherti Report refers to the lack of knowledge of victims of the basis upon which they entered the UK – some
understanding that somehow they had been registered as a relative, others having no idea of the capacity of their
entry. Underlying that lack of knowledge was the trust the victim had in the trafficker.


-----

4. Mr Desmond referred to periods of time spent in Lagos by victims after they have been taken from their home.
They would be kept in an outhouse with other girls in a compound that contained the large house that the madam
lived in. During the time spent in that compound which could be for several weeks or months, the young women
were sexually groomed and undertook domestic work and learnt their “legend”. A photographer may come to the
compound to take a photograph of the young woman rather than a woman being taken out of the compound.

5. Mr Desmond's unchallenged evidence was that at the time this appellant was brought into the UK, it was rare to
find Nigerians working in brothels or on the street in the UK. Street prostitution is heavily policed in the UK
compared to other European countries. Here in the UK victims of sexual exploitation who were kept in private
houses and imprisoned in the bedroom, house or flat were abused by members of the community and were
exploited by word of mouth. The UK was also a transit country to Europe, evidence supported by the IOM 2006
Report of traffickers not sending women direct to Italy but initially by plane from, for example Ghana, direct to
London, Paris or Amsterdam and then on to Italy. Longer (sometimes years) and more dangerous routes to Europe
are through the Sahara. The Cherti Report refers to Italy being the most common destination for Nigerians trafficked
to Europe for sexual exploitation.

**The “means”**

_Vulnerability_

6. Abuse of a position of vulnerability is cited in the Palermo protocol in the list of means through which individuals
can be subjected to a range of various actions for exploitation. There is a distinction between vulnerability as
susceptibility to trafficking and abuse of vulnerability as a means by which trafficking occurs or is made possible.
The United National Office on Drugs and Crime Issue paper “Abuse of a position of vulnerability and other “means”
within the definition of trafficking in persons” April 2013 (“UNODC 2013”) considers trafficking and the concept of
vulnerability:

“….. vulnerability is central to how trafficking is understood……In the context of trafficking, “vulnerability” is
typically used to refer to those inherent, environmental or contextual factors that increase the susceptibility
of an individual or group to being trafficked. These factors are generally agreed to include human rights
violations such as poverty, inequality, discrimination and gender-based violence33 - all of which contribute
to creating economic deprivation and social conditions that limit individual choice and make it easier for
traffickers and exploiters to operate. More specific factors that are commonly cited as relevant to individual
vulnerability to trafficking (and occasionally extrapolated as potential indicators of trafficking);34 include
gender, membership of a minority group, and lack of legal status…..

**2.1.2 A distinct but related concept: abuse of vulnerability as a means of trafficking.**

….This distinction is important…”

7. The UNODC 2013 paper identifies why it is important to maintain a distinction between vulnerability as
susceptibility to trafficking and the abuse of vulnerability as a means by which trafficking is perpetrated. The paper
acknowledges the potential overlap between them and that an understanding of the factors that increase
susceptibility to trafficking is relevant to the extent that it provides an insight into the kinds of vulnerability that can
be abused to enable trafficking to happen. An example given in the paper is the “irregularity of an individual's legal
status vis-à-vis the country destination it is widely acknowledged to be an important factor in enhancing their
vulnerability to being trafficked. Irregular status also appears to be a form of vulnerability that is particularly
amenable to becoming a means by which an individual is placed or maintained in a situation of exploitation.

8. The paper notes that the concept of abuse of the position of vulnerability was unique to the Trafficking in Persons
Protocol and that it is understood as referring to “any situation in which the person involved has no real and
acceptable alternative but to submit to the abuse involved”. Reference is made in the paper to the Commentary to
the Council of Europe Convention against Trafficking in Human Beings 2005 (“European Trafficking Convention”)
and the EU Trafficking Directive 2011/36/EU which explains the term abuse of vulnerability:


-----

“.. the vulnerability may be of any kind, whether physical, psychological, emotional, family-related, social or
economic. The situation might, for example, involve insecurity or illegality of the victim's immigration status,
economic dependence or fragile health. In short the situation can be any state of hardship in which a
human being is impelled to accept being exploited. Persons abusing such a situation flagrantly infringe
human rights and violate human dignity and integrity, which no-one can validly renounce.”

9. The introduction to the US State Department Trafficking Report 20167 (a hard copy of which we were not
provided with but to which reference is made in a number of documents before us) states:

“Although human trafficking affects every demographic, a common factor across all forms of **_modern_**
**_slavery is the victims' vulnerability to exploitation. Systemic social, cultural, and economic policies or_**
practices may marginalize or discriminate against individuals and groups because they are poor, are
intellectually or physically disabled, or because of their gender or ethnicity. People may lack access to
health and legal services due to their status or language barriers; and some, such as communities in
situations of crisis and children, may not be capable of protecting themselves.

Traffickers exploit these disadvantages. They prey on those who lack security and opportunity, coerce or
deceive them to gain control, and then profit from their compelled service. To prevent this, governments,
with assistance from first responders, NGOs, and local communities, should consider their own
populations, cultures, and policies to identify those individuals who may be uniquely vulnerable within their
borders. On this basis, communities can develop effective strategies to increase awareness and prevent
human trafficking.

….

Although there is no exhaustive list of groups vulnerable to human trafficking, the experiences discussed
above exemplify common challenges faced by populations at risk of **_modern slavery. Moreover, some_**
individuals may be vulnerable for more than one reason, making their exploitation even more likely.
Governments can take affirmative steps to consider those who may be uniquely vulnerable given their
country's culture, social structure, and history, and ensure those groups have access to the protections
necessary to keep them from being targeted for human trafficking.”

10. The Cherti report concludes that trafficking results from compound situations of exclusion, deprivation and
inability to access services. Protracted vulnerability is a critical element in the life histories of many trafficked
persons and in general Cherti concluded that

“… it is possible to discern a continuum of subjugation, violence, abuse or instability between the childhood
experiences and their subsequent exploitation abroad….. for the majority of respondents, the
consequences of their exploitation still impact very tangibly on their lives long after its formal 'end'. Their
lives continued to be informed by vulnerability, fear and uncertainty and in many cases by further abuse
and exploitation that in some cases lasted over a number of years, before they were formally identified by
authorities.”

_Means of recruitment and retention_

11. The process of recruitment, including the use of deception, oath taking/juju/voodoo rituals is set out in the IOM
2006 report :

“Young women's first contact with the trafficking network almost always happens through informal
networks. It varies whether it is the woman herself or the other party who first takes the initiative. In many
cases, friends or relatives of the woman are the first link. The conversations about travelling to Europe
often take place in her home or in other familiar surroundings…. The first person with whom the woman is
in contact usually has no other role in the trafficking process than to establish contact…. In this phase, the
women are lured with promises of work as maids, sales personnel, or hairdressers, or with work in
factories or restaurants, or with educational possibilities….

…. This person puts the woman in touch with a “madam” who is the most important person in the network
in Nigeria Sometimes there is a third person who acts as a sponsor and finances the trip However the


-----

sponsor and the madam will often be the same person… In addition to the madam in Nigeria, there is a
_madam in Italy who is responsible for the woman after she has arrived. The madam in Europe is closely_
connected to the madam in Nigeria; often, they will belong to the same extended family. The other central
persons are a religious leader (ohen) in Nigeria, the human smugglers who are responsible for the journey
(trolleys), and a male assistant to the madam in Italy…

…. The sponsor is responsible for paying all the costs of the journey and settling abroad. These make up a
debt that the woman is required to payback. Required documents normally cost between US$ 500 and
US$3000. In addition smugglers often charged as much US$10,000 for the trip… The debt the women
incur, however, is considerably larger, usually in the range US$40,000 to US$100,000. It normally takes
between one and three years as a prostitute in Europe to pay back this amount. Many women do not
understand the extent of what they are committing themselves to because they are not familiar with
European currencies…

… Once a woman has agreed to go to Europe, she's taken to a shrine where the pact of emigration is
confirmed and sealed….. the distribution of material goods and rights is a central element in the local
religious traditions. The religious leader (ohen) who seals the pact acts as a kind of district judge.

….. It is often later in the process, and if something goes wrong as seen from the perspective of the
traffickers, that the use of the local religious traditions takes on a clear element of abuse. If the women are
not cooperative after arriving in Europe, they may be exposed to a mixture of physical violence and new,
enforcing rituals…

….. To an increasing extent, the woman or her family must also commit themselves through a written
contract. This may be legally binding in Nigeria, and use the family home as security for the debt…. In
addition to the rituals at the traditional shrines, many women have also participated in prayer in the popular
Pentecostal congregations prior to leaving for Europe…

The pact with the sponsor is perceived as very strong by the prostituted women…… Breaking the pact
represents much ashamed towards the entire community.”

12. Cherti considers why individuals remain in trafficking circumstances sometimes for years before attempting to
escape. He stresses that it is important to recognise the reality of the control. Physical restraint, violence and
threats played a significant role and were often directed at the victim's family in Nigeria. Control was also achieved
through restricted movement or isolation, in some cases having to hide when visitors came to house. Passports
would be confiscated and any contact with other people was restricted, other than with 'clients' or family and friends
of the exploiter. But Cherti also refers to more subtle forms of control:

“The role that invisibility and isolation play in the coercion and exploitation of many victims, whether in
domestic servitude or prostitution is critical to understand…. There were cases of victims, having fled their
exploiters, returning either out of desperation and a sense of loyalty or sent back by their parents, or at the
behest of their parents or relatives. These cases also highlight important enabling contexts, such as the
vulnerability of the victim and exploitation of the trafficker's authority, the age of the victim making them
unable to consent to their situation, family expectations, and a feeling of obligation and deferred promises.
For instance, one respondent was abused constantly by her host, yet when the victim asked to be taken
back to Nigeria, the exploiter did so, yet after discussions with her family, the victim was made to beg
forgiveness and was then sent back to the UK. Victims' inaction, far from signalling 'cooperation' with their
exploiters and some sort of 'passive agency', reflects the widespread powerlessness, violence and
dislocation that keep many victims locked in their trafficking situations for years. This is particularly
important to bear in mind when a significant proportion of the victims may not be visibly restricted in their
movements….”

**Oath taking**

13. The UNHCR –Voodoo, Witchcraft and Human Trafficking in Europe 2013 report refers to a difference between
voodoo and ritual oaths states:


-----

“As Victoria Nwogu, Programme Specialist with UNIFEM/Nigeria, explains:

“Voodoo is a religion (which includes ritual oaths in its practices), while a ritual oath is a seal placed on an
agreement through rituals binding both parties to the terms of the agreement on pain of supernatural
retaliation…Voodoo is a religion based on the existence of an invisible world interconnected to the visible
world…..Ritual oaths are a practice derived from this religion. These oaths seal the pact between women
who want to move to Europe and traffickers. Traffickers commit to pay all costs of the journey, while the
women promise to repay the money, be respectful to the traffickers and engaging not to denounce the
traffickers to the police…… Ritual oaths are independent of the victim's religion. Believing in other religions
(Islam, Christianity etc) is not necessarily an obstacle to believing in the effect of oaths and voodoo magic”

14. The Cherti report defines 'juju' as referring

“to the invisible realm of gods and spirits which is as “real” as the material universe. The two worlds are
interconnected through the operation of spiritual power, accessed through prayer and ritual. 'Juju' is the
West African term for one such ritual practice…. Objects, words and gestures are imbued with supernatural
power through incantations and sacrifice to bring about a desired result….. the power… knows no
geographical boundaries; its influence can persist through time and space.”

15. Most of the evidence before us referred to oaths as “juju” oaths.

16. Mr Desmond gave examples of women with whom he had worked being offered considerable protection
methods to keep her safe and concealed from those who had trafficked her but the response had been “they will
know; the spirits will know”.

17. Although Campana does not specifically consider the recruitment process he makes reference to the use of
such rituals as a means by which madams maintain control of the victims.

18. According to Cherti

“juju oaths in Nigeria generally occur in situations where the victim is already vulnerable, (for example in a
pre-existing situation of exploitation)… facilitate[s] the journey as well as facilitate[ing] trafficking in the UK.”

He describes it as a “secondary” form of coercion:

“The presence of juju demonstrates the importance of the threat of violence on trafficked people.”

19. The EASO report refers to a paper by Pascoal: The situation of the Nigerian Human Trafficking victims and their
children in Italy 19 December 2012 which states that “many Christian girls do not swear a juju oath because of their
religious belief.” We were not provided with a copy of that report and have not been able to access it but through
the footnote it appears that this is based on an interview with one former victim of trafficking.

20. The Rev Dr Pemberton-Ford refers to the oath taking ceremony in her written evidence and says that even if the
victim was Christian and did not want to articulate the oath they would be obliged to do so. She does not provide
any source for this. The Finnish Report refers to a LandInfo 5/2006 Report that “the Girls Power Initiative
organisation (GPI) have used Christianity to decrease the power and influence juju priests have over people and to
oppose the traditional spirits so that the rituals will no longer have hold on the victims”. The report does not say to
what extent that initiative has been successful. The Danish Report records that NAPTIP states that the use of juju
has decreased although the report also refers to Mrs Olateru-Olagbegi's view that it is usually still common. She
says that it is difficult for a Christian priest too annul the oath. The Finnish report also refers to a paper by Carling in
2005 that

“pacts made in juju rituals are frequently also sanctioned with prayer rituals in Pentecostal churches to
which most of the victims belong, further broadening of pact's legitimacy.”

**Deception**

21. As the Finnish Report says


-----

“the agents of traffickers may contact girls' parents directly and offer help for their daughters to migrate
abroad for a fee…. Some recruiters assist in facilitating travel documents and may also have other people
helping them to expedite the process……. After the initial contact with the agent, the victim is put in contact
with a madam, the most important person in the human trafficking network in Nigeria and often also the
sponsor financing the journey…… Some women actively seek information about migrating to Europe as
well as financing for the journey……. Some victims have also been recruited through audio cassettes or
letters purportedly written by relations or acquaintances already in destination countries …. describing life
as being very promising and inviting victims to come and join them. Occasionally, young women have also
been deceived into migrating by recruiting them as performers in musical troupes, instead, may have
ended up in prostitution as victims of human trafficking. Sports competitions and religious festivals abroad
have also been used as an aid in recruitment…… traffickers residing in Europe have been reported to have
legally adopted teenage girls with the consent of their biological parents to facilitate the document of visas
for the girls.”

22. The Cherti report refers to victims thinking it was a job opportunity or education and it was difficult to turn down
because of the family and community expectation that it was a good opportunity that could not be refused. Cherti
reports that deception was a critical method of coercion employed – “the traffickers presented them with a
compelling offer, in general, the opportunity of sanctuary, education and (in a small number of cases) employment
as a child minder or hairdresser….while a number of respondents were subjected to high levels of physical and
sexual violence by their exploiters, the majority did not experience this in Nigeria. Traffickers seemed pleasant and
supportive until victims reached the destination country and most respondents only became aware of the
exploitation awaiting them once they had arrived. Deception in other cases involved partial information, such as pay
packages that, while attractive in Nigeria, were exploitative in the UK.”

**Debt Bondage**

23. Mr Desmond stated “The net value of trafficking the female for sexual exploitation is greater than for domestic
servitude. The OCG will receive its payment for the domestic slave virtually immediately on delivery in comparison
to the slow return of profit for a female who is sexually exploited… the 'deal' was complete when the person was
sold and delivered in the UK”. The Rev Dr Pemberton-Ford, on being asked if she agreed with this statement,
responded that “it was not that clear as it was possible for a domestic slave to move into sexual exploitation…...
because of the fluidity of sexual exploitation and domestic servitude, what was in the mind of the person who
wanted the product meant that the fictive debt could be run out at a greater level”. When pressed she responded
that it was important to look at Campana and the business model set out therein; there was no reason why the
same model could not apply.

24. The Rev Dr Pemberton-Ford was asked a number of questions about the “business model” for domestic
servitude but we must say we did not find her answers illuminating. She referred on a number of occasions to there
being a need for more research – and yet we had understood from her written evidence that such was the context
of the research she was anticipating being published in September 2016. Her answers were difficult to understand –
for example the reason why she identified a 'debt' as 'fictive'. She was asked who was making money from the
servant and she said,

“If the Sponsor model was considered then the trolley was paid immediately, but the overall debt was held
by the Sponsor… it would take longer for domestic servitude, but the Sponsor would get the lion's share of
the profit….. the lesser jobs were paid off first. It was not possible to say how complex the Sponsor
situation was and there was a need to look at the OCG and whether the Sponsor was in fact part of the
group, but the group was fluid especially the trolleys who were financially paid. The roles of the Sponsor
and the Recruiter could be a complex and it was a very dynamic relationship. The Sponsor was not always
the same as the consumer. Chasing the money assisted but it did not always indicate who was the
Sponsor.”

25. Campana, whose research on trafficking for sexual exploitation, was not primary source research, confirms
stages of exploitation which are referred to by, for example, the OSCE, UNODC, IOM, US State Department in, that


-----

“trafficking is indeed best understood as a process that consists of distinct and consecutive stages, which
can generally be identified as (1) recruitment, (2) transportation and(3) exploitation. Recruitment refers to
the acquisition of control over a victim by different means, including abduction, gross deception or
payments to the victim's relatives. Recruitment usually takes place in the source country. Transportation
refers to the movement of the victim from a source to destination country. Exploitation is the final stage of
trafficking operations and usually takes place in the destination country. The key point here is that some
stages may benefit from economies of scale more than others. For the transportation stage, an increase in
the number of victims may greatly decrease the cost –per- victim associated with setting up and running
the informal infrastructure (made up of safe houses and local agents), as well as acquiring the relevant
knowledge about visas, trafficking routes and counter- trafficking measures. At the same time, monitoring
costs tend to be lower in this stage the time during which victims are involved is shorter. The exploitation
stage, on the other hand, may present severe limits to the development of economies of scale, as victims
have to be monitored closely and individually for lengthy periods. The extent of monitoring is often very
large and includes acquiring constant and reliable information on the victim's whereabouts and the
earnings generated from each transaction between a single victim and her clients. For high-capacity
trafficking networks, the costs incurred during the exploitation stage maybe considerable.”

26. His paper suggests that there is a separation between transportation and exploitation costs: transporters expect
to be paid

“… in full at the moment of delivery…..transporters act as service providers contracted by the madams”.

Campana concludes that the network

“… does not appear to be a unified organization, but rather a collection of largely independent actors.
There is no indication of a centralised accounting system”,

And that activities appear to be largely external, and that there is a tendency towards a separation between the
transportation and the exploitation stage which is

“a crucial organisational arrangement that allows for higher trafficking capacity”. “The evidence suggests
the adoption by the traffickers of a more sophisticated model [not run on ethnic or kinship lines] based on
the division of labour and role specialization”.

27. Campana supports Mr Desmond's evidence that victims of sexual exploitation have no idea of the conditions
they will be required to work in or the hours they will have to work or the extent of the debt they are required to pay
off and the years it will take. The IOM 2006 report, drawing on academic sources from 2001 and 2003 estimates it
can take between 1 and 3 years for a prostitute to pay off this debt. The debt can be increased as punishment for
bad behaviour, but it is usually only a matter of time before the pact ends.

28. Mr Desmond was asked about debt bondage. He said this was part of the recruitment process. The victim
would be trapped in sexual exploitation with a promise that they would get a job and that their expenses would be
paid and that they could pay back 70,000. The victim would think it was Naira which would equate to about £250.
They would then go and see a juju priest to give a blessing or swear an oath on the contract that they would pay
back the money. Their soul would be collateral and the victim was then told on reaching the UK that the debt was
owed in Euros. The debt was huge, but given that an oath had been sworn the victim was now debt bound and had
been trapped. Debt bondage did not occur in domestic servitude because domestic servants were a commodity. It
was a transaction between a seller and a buyer. That is why sex trafficking was more profitable because you knew
you were going to get your money because the person would have to pay off the debt with their earnings. The
domestic servant did not pay money to anybody but could if they were going to be deployed in sexual activity and
had performed an oath ceremony. Mr Desmond had not met a domestic servant who had gone through juju.

29. There was no evidence drawn to our attention that indicated that the debt was never paid off.

30. The actual debt which a sexually exploited trafficked victim is required to repay is difficult to uncover. The IOM
2006 report brings together research figures from 2003 reports. These costs appear to break down as follows:


-----

     - The cost of trafficking a woman to Italy is between $50,000 and $70,000.

     - On arrival taken shopping for clothes, fellow prostitutes train her.

     - Either lives with the madam or in another flat where watched by a controller.

    - Living quarters can be overcrowded.

    - Not unusual for one madam to control 10 to 15 women.

     - Flat used to sleep and watch TV between shifts.

     - Work different hours but often nearly round the clock.

    - Expenses for food, lodging, and payment for the accommodation used for sex work are deducted; often
amount to $2000 a month. Remainder used to pay back the debt.

     - Have little access to the money and not allowed to send money to Nigeria.

    - Madams move the women around – enables them to offer customer variation and to prevent individual
victims developing relationships and ties to customers. Also due to changes in legislation and enforcement.

    - Repayment accelerated if woman develops a relationship to a customer who offers to pay all or part of
remaining debt.

    - Although the madam may increase the debt for bad behaviour, usually only a matter of time before the
debt is repaid; often marked with a party.

31. There was no more up to date information on the costs incurred or the debt to be repaid although there was
nothing to say that costs had gone down. It seems uncontested, other than by the Rev Dr Pemberton-Ford, that
trafficking for what could be characterised as “pure” domestic servitude does take place, and that where that
happens it may change into sexual exploitation but that is localised from those to whom the domestic servant was
sold.

32. The Rev Dr Pemberton-Ford drew very little distinction between trafficking for domestic servitude and trafficking
for sexual exploitation. Her evidence was that the same financial models existed for each. She had no direct
evidence to support that theory and no academic or other sources upon which she drew. Her conclusion to this
effect appeared to be based upon the premise that those trafficked for domestic servitude would become sexually
exploited and thus the financial involvement would be that as described by Campana, who, as we have said earlier,
was considering trafficking for sexual exploitation in Italy. She did not, in response to questions put to her, appear
to accept that there were ever situations where an individual would be trafficked solely for the purposes of domestic
servitude. She appeared to have the view that trafficking for domestic servitude would inevitably lead to sexual
exploitation; that the transition was sometimes not apparent to the victim, but that the debt for domestic servitude
remained outstanding and there was no difference in financial terms between sex trafficking and domestic service
trafficking. In response to a written question from the respondent asking how a trafficker recovered the costs of
trafficking a person for domestic servitude she says

“This is the challenge for the costly business of trafficking – domestic servitude over many years would
eventually recoup these costs, however a more expeditious method would be if the young woman involved
could be brought into a form of prostituted service, where higher remuneration could be achieved on the
outlay by the sponsor, or the madam, using her services. This could be managed in a hybrid form – some
servitude and some sexual services – as must be the case of those moving in between these forms
referenced by (Ellis, 2011).”

33. On being asked to comment on Mr Desmond's statement that “The OCG will receive its payment for the
domestic slave virtually immediately on delivery, in comparison to the slow return of profit for a female who is
sexually exploited” she responded that it was not that clear because it was possible for a domestic slave to move
into sexual exploitation. When pressed she referred to Campana and stated that it was important to look at that
business model. We did not find her evidence on this helpful. Although she has undertaken research and, given the
increasing awareness of the level of domestic servitude in the UK, we cannot accept that the description of finance


-----

provided by Campana in relation to trafficking for sexual exploitation in Italy can be utilised directly as a comparator
for domestic servitude trafficking in the UK.

34. Mr Desmond stated that in his experience there was a link between the UK and Nigeria and many victims of
sexual exploitation could easily be found by their traffickers. He gave as an example, traffickers who found the son
of a Ugandan victim, traced her through him and demanded repayment of her debt. She attempted to make
repayment of part of the debt and then met a Nigerian madam in Denmark who said she knew her and knew that
she owed a debt.

35. The Rev Dr Pemberton-Ford, in cross-examination agreed that where someone was trafficked for sexual
exploitation the profit was derived from the men who paid money for sex whereas in domestic servitude the profit
came from the person who employed the victim. She said that there were other opportunities within domestic
servitude for sexual exploitation or, for example, benefit fraud.

36. As can be seen from references above it appears that the core group, the OCG, organising the trafficking is the
group that makes the money. Individuals and other specialised groups are utilised for specific stages enabling the
exploitation to take place for example documents, cross border crossings and it seems that these tasks are
obtained and paid for as and when required.

37. Mr Desmond described the Hawala financial mechanism through which money was transferred between the UK
and Nigeria; this method of transfer of funds reduced risk to those paying and receiving money because large sums
were not being transported across borders or identifiable through established state banking mechanisms. He gave
examples of playing cards torn in half and numbers to provide identification for the senders and receivers of money.
This method of transfer of funds was, he said, an easy cross border movement of money. He said that some
traffickers would use 'clean' money to fund some elements of trafficking. For example, they were legitimately
employed and used that money to purchase the necessary documents.

38. The IOM 2006 report refers to 1999 research that part of the income from trafficking is used to expand the
business, but that large sums of money are transferred to Nigeria to be invested there. The report records that the
madams frequently live a 'plain' life in Italy, but have big houses built in Nigeria – and a comment is made that
building a house in the country of origin is “something migrants worldwide spend money on, whether they are
Pakistanis in Norway, Mexicans in the United States or Nigerians in Italy”.

_Scarring_

39. Mr Desmond referred to ritual scarring of many victims from Edo State, inflicted during the oath taking
ceremony; such scarring not generally occurring on those from other States.

40. Cherti refers to scarring occurring in some cases as part of the oath taking ritual.

41. There was no evidence before us that the scarring was inflicted in order to identify an individual as having been
trafficked for sexual or domestic exploitation.

_Violence_

42. Control of the victim extends beyond the oath-taking ceremonies to implied or threatened violence against the
victim or the victim's family. Mr Desmond gives the example of the giving of a phone which is then utilised as a
means of contact between the victim and her family either directly or indirectly to ensure compliance.

43. Although Cherti refers to some generalised violence directed to victims of trafficking or their families, his overall
conclusion is that violence or threats of violence tend only to appear once a person is in the UK. He states that the
means of coercion utilised by the traffickers demonstrates the low importance of 'physical coercion' in Nigerian
trafficking.

“Rather than physical force or abduction, the majority of trafficking is facilitated whether by an abuse of
power – people being trafficked against their will who are unable to resist their traffickers either because of


-----

their young age, or lesser power relationship, or deception – the individual being promised a job or life very
different to the exploitation they faced”.

44. This low level of violence is referred to in the Danish Report.

_Corruption_

45. The World Bank's working definition of corruption, is “the abuse of public power for private benefit”.
Transparency International takes a broader approach and understands corruption as “misuse of entrusted power for
private gain”. UNODC The Role of Corruption in Trafficking in Persons Report 2011, considering the generality of
trafficking and not specifically Nigeria, refers to corrupt behaviour as ranging from

“..violating duties, accepting or transferring bribes, facilitating transactions, to passive involvement, which
can include simply ignoring or failing to follow-up on indicators that corruption maybe taking place.”

The report identifies that opportunities for corruption exist in the trafficking chain, the criminal justice chain, the
victims support and protection chain. The report notes that most States do not systematically collect and analyse
data on investigations or prosecutions of public officials relating to human trafficking and corruption yet they record
that there is a wealth of anecdotal evidence provided by the victims of the crime and by traffickers. The report refers
to the results of corruption being easier to find than evidence of the corrupt act itself. The outcomes, for instance the
existence of fraudulent travel and identification documents used in the trafficking process, illegal border crossing or
the issuance of a visa without all the requirements being fulfilled are clues that indicate the existence of exploitation.

46. Various documents before us including for example:

    - Country information and guidance Nigeria: gender-based discrimination/ Harm/ Violence against Women
August 2015;

    - Country information and guidance Nigeria: background information, including actors of protection, and
internal relocation 9 June 2015;

    - Nigeria Country of origin information (COI) Report 14 June 2013 (reissued on 3 February 2014);

    - Protection of victims of trafficking in Nigeria. Report from Danish Immigration Service's fact-finding
mission to Lagos, Benin City and Abuja, Nigeria. April 2008;

    - Finnish immigration service, human trafficking of Nigerian women to Europe 24/03/2015;

    - UNODC The Role of Corruption in Trafficking in Persons 2011;

provide some support for Mr Desmond's contention that the level of corruption within the law enforcement agencies
enabled OCGs and OCNs in Nigeria to operate with a level of impunity. Freedom House, Freedom in the World
2016: Nigeria, 27/01/2016 refers to bribe taking within the police force, but also refers to the inspector general of
police in collaboration with an NGO launching a social media platform that allowed citizens to report police abuse
and bribe taking.

47. The Freedom House Report refers to Organised Crime Groups being heavily involved in human trafficking. The
OSCE/ODIHR 2011 research regarding the national laws, policies and practices of Nigeria relating to the return of
trafficked/ exploited persons Report compiled after a fact-finding mission to Nigeria between 19 and 26 February
2011 does not specifically refer to a level of corruption affecting criminal reprisal, but reflects what appears to be a
view taken in the documents referred to above that criminal groups in Nigeria “operate through structures and
connections which are entirely unique and therefore have none of the weakness of other organized criminal
networks; thereby making them almost impossible to eliminate completely”.

48. On the basis of the documentation before us and Mr Desmond's evidence which was not, on this issue,
challenged by the respondent, we accept that there is a level of corruption within the law enforcement agencies and
this does inevitably have an impact on the issue of trafficking. We were not taken to documentation that specifically
linked high levels of corruption to trafficking, but nevertheless it is plain that widespread corruption through the


-----

various law-enforcement agencies would have an impact not only in terms of the existence of trafficking, but also
the control that traffickers are able to exert over their victims.

**Annex 4**

**Trafficking and investigation**

1. Mr Desmond drew on his lengthy experience in his evidence on what he perceived to be indicators of trafficking
that would suggest a need to make further enquiries. He listed these as including:

     - The giving of gifts such as a mobile phone that enables contact between the victim and family or through
a third person;

    - Travel to the UK as a 'family group' where a member of the group travels frequently and/or one of the
members fails to comply with visa conditions;

     - Previous entries by a 'family member' with other children;

    - Entry as an unaccompanied asylum seeker;

     - Disappearance from local authority care;

     - Lack of any association with the person with whom the victim travels other than as an escort;

     - Escort re-entering with children;

    - Repeat journeys by an escort;

     - Lack of evidence of relationship between the escort and the person to whom the victim is delivered.

2. Ms Cronin submitted that the obligations of the UK under Article 436 to investigate trafficking cases was an
essential element of an holistic approach. The approach of the Secretary of State was, she submitted, to focus on
the criminal networks and that the Upper Tribunal should deliberate on whether the “group” have some retained
interest in the trafficking victim and their “reach” or “lack of reach”. It was submitted by her that the assertion by the
Secretary of State as to whether those who had been involved in the trafficking of a victim retained interest in her on
her return to Nigeria required more than simple assertion. She submitted that a victim's account of her entry to the
UK, the addresses at which she stayed and the nature of the work undertaken by her either in Nigeria or in the UK
could all have an impact on the assessment of the nature of the criminality that brought her to the UK. Some of this
information was, it was submitted, readily available to the Secretary of State through, for example, examination of
airline passenger manifests, consideration of entry clearance visa application forms, enquiries as to whether and
where the individuals who bring the victim to the UK lived/worked/ travelled to or from. None of this type of
information is available to the victim but could, it was submitted, be established by the Secretary of State without
disclosure of private or confidential information. The establishment of that information could, it was submitted, be
critical in terms of identifying the risks to the victim on return to her country of origin in the context not only of
sufficiency of protection but also internal relocation.

3. Ms Cronin asserted that investigations such as these were not only open to the Secretary of State but that
investigation was required to enable the Secretary of State to comply with the U.K.'s obligations under the
international trafficking instruments. We are aware that the extent to which documentation can be properly
considered to be of a nature where verification by the Secretary of State should be undertaken has been
considered by the Upper Tribunal in MJ (Singh v Belgium: Tanveer Ahmed unaffected) Afghanistan _[[2013] UKUT](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58J1-PRJ1-F0JY-C4JC-00000-00&context=1519360)_
_[00253 (IAC) the head note of which reads:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58J1-PRJ1-F0JY-C4JC-00000-00&context=1519360)_

The conclusions of the European Court of Human Rights in Singh v Belgium (Application No. 33210/2011)
neither justify nor require any departure from the guidance set out in Tanveer Ahmed [2002] Imm AR 318
(starred). The Tribunal in Tanveer Ahmed envisaged the existence of particular cases where it may be
appropriate for enquiries to be made. On its facts Singh can properly be regarded as such a particular
case.


-----

The documentation in that case was clearly of a nature where verification would be easy, and the
documentation came from an unimpeachable source.

4. In trafficking cases it is not so much documentation provided by the victim that is at question (although clearly the
production of a passport that is in some way fraudulent is open to investigation by the state) but rather the extent
and nature of any investigation to be undertaken by the Secretary of State.

5. Article 9 of the Directive states:

1. Member States shall ensure that investigation into or prosecution of offences referred to in Articles 2 and
3 is not dependent on reporting or accusation by a victim and that criminal proceedings may continue even
if the victim has withdrawn his or her statement.

2. Member States shall take the necessary measures to enable, where the nature of the act calls for it, the
prosecution of an offence referred to in Articles 2 and 3 for a sufficient period of time after the victim has
reached the age of majority.

3. Member States shall take the necessary measures to ensure that persons, units or services responsible
for investigating or prosecuting the offences referred to in Articles 2 and 3 are trained accordingly.

4. Member States shall take the necessary measures to ensure that effective investigative tools, such as
those which are used in organised crime or other serious crime cases are available to persons, units or
services responsible for investigating or prosecuting the offences referred to in Articles 2 and 3.

6. The OSCE Action Plan to Combat Trafficking in Human Beings 24 July 2003 aims to provide participating states
with a comprehensive toolkit to help them implement their commitments to combating trafficking in human beings.
In section III – investigation, law enforcement and prosecution – the action plan refers to

“encouraging investigators and prosecutors to carry out investigations and prosecutions without relying
solely and exclusively on witness testimony. Exploring alternative investigative strategies to preclude the
need for victims to be required to testify in court.”

7. The IOM 2015 report identifies five key priorities and for each of them a series of initiatives to be put in place by
EU Member States. This includes increased prosecution of traffickers resulting from enhanced cooperation of law
enforcement bodies at borders and beyond.

8. Although the references in these documents to investigation are linked to prosecution for criminal offences, there
is a recognition within the anti-trafficking instruments to the particular vulnerability and nature of the serious harm
done to a victim of trafficking together with the transnational nature of trafficking such that States are required to
investigate to enable the perpetrators to be brought to justice. By its very nature such investigation will be initiated
by the victim's disclosure of what has happened to her, but the complexity of the organisational and transnational
nature of trafficking will require specialist investigation by the State. This is recognised and referred to in the OSCE
Action Plan Annex which calls on participating states to cooperate with international law enforcement bodies. The
OSCE Action plan calls upon participating States to establish special anti-trafficking units, to provide resources and
training for developing intelligence-led policing and to encourage investigators and prosecutors to carry out
investigations and prosecutions without relying solely and exclusively on witness testimony.

9. Given the particular nature of trafficking in human beings and taking account of these matters we accept, and
there is no evidence that the Secretary of State does not, that there is a duty on the Secretary of State to
investigate allegations of trafficking with a view to the prosecution of the perpetrators. That investigation may well
include examination of matters that are out with the knowledge of the victim, although the initiation of the
investigation has come from the victim herself.

10. In so far as an individual appellant is concerned however we cannot be satisfied that it is the role of the Upper
Tribunal to require particular investigations to take place. Assessment of risk does of course require analysis of all
relevant material; that is a matter that we are sure all parties will bear in mind in presenting an appeal.


-----

**ANNEX 5**

1. Trafficking Victims Protection Act of 2000, Div. A of Pub. L. No. 106-386, § 108, as amended states:

(1) The government of the country should prohibit severe forms of trafficking in persons and punish acts of
such trafficking.

(2) For the knowing commission of any act of sex trafficking involving force, fraud, coercion, or in which the
victim of sex trafficking is a child incapable of giving meaningful consent, or of trafficking which includes
rape or kidnapping or which causes a death, the government of the country should prescribe punishment
commensurate with that for grave crimes, such as forcible sexual assault.

(3) For the knowing commission of any act of a severe form of trafficking in persons, the government of the
country should prescribe punishment that is sufficiently stringent to deter and that adequately reflects the
heinous nature of the offense.

(4) The government of the country should make serious and sustained efforts to eliminate severe forms of
trafficking in persons.

Indicia of “Serious and Sustained Efforts”

(1) Whether the government of the country vigorously investigates and prosecutes acts of severe forms of
trafficking in persons, and convicts and sentences persons responsible for such acts, that take place wholly
or partly within the territory of the country, including, as appropriate, requiring incarceration of individuals
convicted of such acts. For purposes of the preceding sentence, suspended or significantly reduced
sentences for convictions of principal actors in cases of severe forms of trafficking in persons shall be
considered, on a case-by-case basis, whether to be considered as an indicator of serious and sustained
efforts to eliminate severe forms of trafficking in persons. After reasonable requests from the Department of
State for data regarding investigations, prosecutions, convictions, and sentences, a government which
does not provide such data, consistent with the capacity of such government to obtain such data, shall be
presumed not to have vigorously investigated, prosecuted, convicted, or sentenced such acts. During the
periods prior to the annual report submitted on June 1, 2004, and on June 1, 2005, and the periods
afterwards until September 30 of each such year, the Secretary of State may disregard the presumption
contained in the preceding sentence if the government has provided some data to the Department of State
regarding such acts and the Secretary has determined that the government is making a good faith effort to
collect such data.

(2) Whether the government of the country protects victims of severe forms of trafficking in persons and
encourages their assistance in the investigation and prosecution of such trafficking, including provisions for
legal alternatives to their removal to countries in which they would face retribution or hardship, and ensures
that victims are not inappropriately incarcerated, fined, or otherwise penalized solely for unlawful acts as a
direct result of being trafficked, including by providing training to law enforcement and immigration officials
regarding the identification and treatment of trafficking victims using approaches that focus on the needs of
the victims.

(3) Whether the government of the country has adopted measures to prevent severe forms of trafficking in
persons, such as measures to inform and educate the public, including potential victims, about the causes
and consequences of severe forms of trafficking in persons, measures to establish the identity of local
populations, including birth registration, citizenship, and nationality, measures to ensure that its nationals
who are deployed abroad as part of a diplomatic, peacekeeping, or other similar mission do not engage in
or facilitate severe forms of trafficking in persons or exploit victims of such trafficking, a transparent system
for remediating or punishing such public officials as a deterrent, measures to prevent the use of forced
labor or child labor in violation of international standards, effective bilateral, multilateral, or regional
information sharing and cooperation arrangements with other countries, and effective policies or laws
regulating foreign labor recruiters and holding them civilly and criminally liable for fraudulent recruiting.


-----

(4) Whether the government of the country cooperates with other governments in the investigation and
prosecution of severe forms of trafficking in persons and has entered into bilateral, multilateral, or regional
law enforcement cooperation and coordination arrangements with other countries.

(5) Whether the government of the country extradites persons charged with acts of severe forms of
trafficking in persons on substantially the same terms and to substantially the same extent as persons
charged with other serious crimes (or, to the extent such extradition would be inconsistent with the laws of
such country or with international agreements to which the country is a party, whether the government is
taking all appropriate measures to modify or replace such laws and treaties so as to permit such
extradition).

(6) Whether the government of the country monitors immigration and emigration patterns for evidence of
severe forms of trafficking in persons and whether law enforcement agencies of the country respond to any
such evidence in a manner that is consistent with the vigorous investigation and prosecution of acts of
such trafficking, as well as with the protection of human rights of victims and the internationally recognized
human right to leave any country, including one's own, and to return to one's own country.

(7) Whether the government of the country vigorously investigates, prosecutes, convicts, and sentences
public officials, including diplomats and soldiers, who participate in or facilitate severe forms of trafficking in
persons, including nationals of the country who are deployed abroad as part of a diplomatic, peacekeeping,
or other similar mission who engage in or facilitate severe forms of trafficking in persons or exploit victims
of such trafficking, and takes all appropriate measures against officials who condone such trafficking. A
government's failure to appropriately address public allegations against such public officials, especially
once such officials have returned to their home countries, shall be considered inaction under these criteria.
After reasonable requests from the Department of State for data regarding such investigations,
prosecutions, convictions, and sentences, a government which does not provide such data consistent with
its resources shall be presumed not to have vigorously investigated, prosecuted, convicted, or sentenced
such acts. During the periods prior to the annual report submitted on June 1, 2004, and June 1, 2005, and
the periods afterwards until September 30 of each such year, the Secretary of State may disregard the
presumption contained in the preceding sentence if the government has provided some data to the
Department of State regarding such acts and the Secretary has determined that the government is making
a good faith effort to collect such data.

(8) Whether the percentage of victims of severe forms of trafficking in the country that are non-citizens of
such countries is insignificant.

(9) Whether the government has entered into effective, transparent partnerships, cooperative
arrangements, or agreements that have resulted in concrete and measurable outcomes with

(A) domestic civil society organizations, private sector entities, or international nongovernmental
organizations, or into multilateral or regional arrangements or agreements, to assist the government's
efforts to prevent trafficking, protect victims, and punish traffickers; or

(B) the United States toward agreed goals and objectives in the collective fight against trafficking.

(10) Whether the government of the country, consistent with the capacity of such government,
systematically monitors its efforts to satisfy the criteria described in paragraphs (1) through (8) and makes
available publicly a periodic assessment of such efforts.

(11) Whether the government of the country achieves appreciable progress in eliminating severe forms of
trafficking when compared to the assessment in the previous year.

(12) Whether the government of the country has made serious and sustained efforts to reduce the demand
for

(A) commercial sex acts; and

(B) participation in international sex tourism by nationals of the country.

2 The Tiers


-----

_Tier 1_

Countries whose governments fully meet the Trafficking Victims Protection Act's (TVPA) minimum
standards.

_Tier 2_

Countries whose governments do not fully meet the TVPA's minimum standards, but are making significant
efforts to meet those standards.

_Tier 2 Watch List_

Countries whose governments do not fully meet the TVPA's minimum standards, but are making significant
efforts to meet those standards AND:

a) The absolute number of victims of severe forms of trafficking is very significant or is significantly
increasing;

b) There is a failure to provide evidence of increasing efforts to combat severe forms of trafficking in
persons from the previous year, including increased investigations, prosecutions, and convictions of
trafficking crimes, increased assistance to victims, and decreasing evidence of complicity in severe forms
of trafficking by government officials; or

c) The determination that a country is making significant efforts to meet the minimum standards was based
on commitments by the country to take additional future steps over the next year.

_Tier 3_

Countries whose governments do not fully meet the minimum standards and are not making significant
efforts to do so.

3. For the years 2009, 2010 and 2011, Nigeria was a Tier 1 country. Since then it has been Tier 2. There are
differences in the overview, prosecution, protection and prevention analysis described in the TIP reports produced
for each year. A brief comparison of some elements of the Reports for the last year that Nigeria was a Tier 1
country (2011) and the current Report (2016) when it is Tier 2 illustrates the approach of the Reports in making the
assessment. In essence the Reports identify the meeting by Nigeria of aspiration and the continuing commitment to
meet those aspirations.

|2011 Tier 1|2016 Tier 2|
|---|---|
|…fully complies with the minimum standards for the elimination of trafficking|…does not fully meet the minimum standards for the elimination of trafficking, however it is making significant efforts to do so.|
|Sustained a modest number of trafficking prosecutions|Sustained strong anti-trafficking law enforcement efforts|
|Although government claimed to have increased the budget to NAPTIP, actual disbursements not disclosed.|NAPTIP received a larger operating budget,|
|Longstanding plans to relocate flagship shelter for victims were not fulfilled. Other victim's shelters operated below full capacity. Observers reported shelters at times severely lacked resources. Victims allowed to stay up to six weeks save in extenuating circumstances; after this referred to a network of NGOs|NAPTIP operated 9 shelters specifically for trafficking victims with a total capacity of 313 victims. Short-term care offered generally limiting stay to 6 weeks although victims allowed to extend stay under special circumstances. Collaboration with two other shelters operated by Ministry of Women's Affairs and NGOs.|
|Despite the documented magnitude of the problem of Nigerian trafficking victims in countries around the world, government inconsistently employed measures to provide services to repatriated victims.|Identified and provided services to a large number of victims and continued extensive awareness campaigns throughout the country.|


In September 2010 NAPTIP officials travelled to Mali
where they investigated reports of 20,000 to 40,000
women being held in forced prostitution. Officials took
no apparent action to rescue victims or arrest


In 2015 the Government passed amending legislation which
increased the penalties for trafficking offenders. Instigated 507
investigations, completed at least 32 prosecutions and secured 24
convictions 148 prosecutions remained pending at the end of the


-----

|traffickers. Of concern that NAPTIP regular travels abroad did not yield discernible results (the 2012 Report (when Nigeria was downgraded to Tier 2) refers to subsequent arrest and rescue).|reporting period.|
|---|---|
|Government did not initiate any investigations, pursue prosecutions or obtain convictions of Government officials for involvement in trafficking although corruption was known to have occurred in previous years.|The Government did not report any investigations, prosecutions or convictions, save one, of government officials complicit in trafficking offenses. Corruption at all levels of the Government remained a pervasive problem.|
|The government continued to lack a formal system for identifying victims among vulnerable populations…Some police reportedly extorted women in prostitution for money.|The government maintained string efforts to protect trafficking victims and identified 943 trafficking victims including 429 victims of sex trafficking and 514 victims of labour trafficking compared with 914 victims identified in the previous year.|
|Sustained its efforts to prevent human trafficking through campaigns to raise awareness and educate the public about the dangers of trafficking.|Sustained efforts to prevent human trafficking. NAPTIP continued to conduct extensive national and local programming, advocacy visits to primary and secondary schools, educated transportation carriers.|


NIGERIA: Tier 2

Nigeria is a source, transit, and destination country for women and children subjected to forced labor and
sex trafficking. Nigerian trafficking victims are recruited from rural and, to a lesser extent, urban areas:
women and girls for domestic servitude and sex trafficking and boys for forced labor in street vending,
domestic service, mining, stone quarrying, agriculture, textile manufacturing, and begging. Young boys in
Koranic schools, commonly known as “Almajiri children,” are subjected to forced begging. Nigerian women
and children are taken from Nigeria to other West and Central African countries, as well as to South Africa,
where they are exploited for the same purposes. Nigerian women and girls are subjected to sex trafficking
throughout Europe. Nigerian women and children are also recruited and transported to destinations in
North Africa, the Middle East, and Central Asia, where they are held captive in the commercial sex industry
or forced labor. Women from other countries in West Africa transit Nigeria to destinations in Europe and
the Middle East, where they are subjected to forced prostitution. Children from other West African countries
are subjected to forced labor in Nigeria, including in granite and gold mines. Nigeria is a transit point for
children from other countries in West Africa, who are then subjected to forced labor in Cameroon and
Gabon. Various NGOs continued to report that children in internally displaced persons (IDP) camps in
northeast Nigeria were victims of labor and sex trafficking.

During the reporting period, Boko Haram continued to forcibly recruit and use child soldiers as young as 12
years old and abduct women and girls in the northern region of Nigeria, some of whom it subjected to
domestic servitude, forced labor, and sex slavery through forced marriages to its militants. NGOs and
international observers also reported civilian vigilante groups, often identified as the Civilian Joint
Taskforce (CJTF), recruited and used child soldiers, sometimes by force. Although the government
prohibited the recruitment and use of child soldiers, government security forces conducted on-the-ground
coordination with CJTF during the reporting period. The Borno State government continued to provide
financial and in-kind resources to some members of CJTF, which was also at times aligned with the
Nigerian military in operations against Boko Haram.

The Government of Nigeria does not fully meet the minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so. During the reporting period, the government sustained
strong anti-trafficking law enforcement efforts by investigating, prosecuting, and convicting numerous
traffickers; by collaborating with 11 countries on international investigations; and by providing extensive
specialized anti-trafficking training to officials from various government ministries and agencies. The
National Agency for the Prohibition of Trafficking in Persons and Other Related Matters (NAPTIP) received
a larger operating budget, identified and provided services to a large number of victims, and continued
extensive awareness campaigns throughout the country. During the reporting period, the Borno State
government provided financial and in kind resources to some members of CJTF; CJTF recruited and used


-----

child soldiers. Additionally, despite a 2015 amendment that removed judges' ability to sentence traffickers
to fines in lieu of prison time, Nigerian courts penalized two traffickers with fines alone and gave another
three the option to pay a fine in lieu of serving time in prison.

RECOMMENDATIONS FOR NIGERIA:

Cease provision of financial and in-kind support to groups recruiting and using children; investigate and
prosecute all individuals suspected of recruiting and using child soldiers and allegedly perpetrating other
trafficking abuses against women and children; continue to vigorously pursue trafficking investigations,
prosecutions, and adequate sentences for convicted traffickers; take proactive measures to investigate and
prosecute government officials suspected of trafficking-related corruption and complicity in trafficking
offenses; ensure the activities of NAPTIP receive sufficient funding, particularly for prosecuting traffickers
and providing adequate care for victims; implement programs for the disarmament, demobilization, and
reintegration of former child combatants that take into account the specific needs of child ex-combatants;
continue to provide regular training to police and immigration officials to identify trafficking victims among
vulnerable populations, such as women in prostitution and young females traveling with non-family
members; fully integrate anti-trafficking responsibilities into the work of the Nigerian police force and the
Ministry of Labor; and continue to increase the capacity of Nigerian embassies to identify and provide
assistance to victims abroad, including through regular and specialized training for diplomatic and consular
personnel.

PROSECUTION

The government maintained strong anti-trafficking law enforcement efforts. In 2015, the government
passed amendments to the 2003 Trafficking in Persons Law Enforcement and Administration Act, which
increased the penalties for trafficking offenders. The law prohibits all forms of trafficking and prescribes a
minimum penalty of five years' imprisonment and a minimum fine of one million naira ($5,470) for sex and
labor trafficking offenses; the minimum penalty for sex trafficking increases to seven years' imprisonment if
the case involves a child. These penalties are sufficiently stringent and commensurate with other serious
crimes, such as rape.

NAPTIP conducted 507 trafficking investigations, completed at least 32 prosecutions, and secured 24
convictions during the reporting period, compared with 509 investigations, 56 prosecutions, and 30
convictions in the previous reporting period. The decrease in convictions is likely a result of the seconding
of many judges to electoral tribunals during the reporting period. An additional 148 prosecutions remained
pending at the end of the reporting period. All prosecutions occurred under the anti-trafficking law, and
prison sentences upon conviction ranged from three months' to 14 years' imprisonment. Of the 24
convictions, 16 resulted in imprisonment without the option of paying a fine. However, despite a 2015
amendment that removed judges' ability to sentence traffickers to fines in lieu of prison time, Nigerian
courts penalized five traffickers with only fines. The government also collaborated with law enforcement
agencies from Belgium, Burkina Faso, Finland, France, Germany, Mali, Norway, Sweden, Taiwan, the
United Kingdom, and the United States on 43 investigations involving Nigerian nationals during the
reporting period. The government commenced prosecution of a Ministry of Foreign Affairs official who
allegedly used his or her position to facilitate a trafficking crime abroad; the prosecution remained ongoing
at the close of the reporting period. The government did not report any other investigations, prosecutions,
or convictions of government officials complicit in trafficking offenses; however, corruption at all levels of
the government remained a pervasive problem.

The government conducted extensive training throughout the reporting period. NAPTIP, in collaboration
with international partners, provided specialized training to approximately 228 government employees,
including judges, prosecutors, and officials from NAPTIP, the Nigerian police force, and the Nigerian
Immigration Service. These programs offered specialized training on victim identification, investigation and
prosecution of trafficking cases, counseling, intelligence collection, and monitoring and evaluation. NAPTIP
officials assisted 18 countries with their anti-trafficking efforts through training courses, joint intelligence
sharing, and mutual legal assistance.

PROTECTION


-----

The government maintained strong efforts to protect trafficking victims. The government identified 943
trafficking victims, including 429 victims of sex trafficking and 514 of labor trafficking, compared with 914
victims identified in the previous reporting period. NAPTIP provided initial screening and assistance for all
victims it identified and referred them to government-run care facilities for further medical care, vocational
training, education, and shelter. The government has formal written procedures to guide law enforcement,
immigration, and social services personnel in proactive identification of trafficking victims among high-risk
populations. NAPTIP provided police, immigration, and social services personnel with specialized training
on how to identify trafficking victims and direct them to NAPTIP. Additionally, the government's national
referral mechanism provides formal guidelines for law enforcement, immigration officials, and service
providers to improve protection and assistance to trafficking victims, both within Nigeria and abroad.

In 2015, the government allocated approximately 2.5 billion naira ($13 million) to NAPTIP, which spent
roughly 581 million naira ($3 million) on victim protection and assistance during the reporting period.
NAPTIP operated nine shelters specifically for trafficking victims, with a total capacity of 313 victims.
Through these shelters, NAPTIP provided access to legal, medical, and psychological services, as well as
vocational training, trade and financial empowerment, and business management skills. Victims who
required additional medical and psychological treatment were provided services by hospitals and clinics
through existing agreements with NAPTIP. NAPTIP shelters offered short-term care, generally limiting
victims' stays to six weeks, although victims were allowed to extend their stays under special
circumstances. If victims needed longer-term care, NAPTIP collaborated with two shelters operated by the
Ministry of Women's Affairs and NGO-run shelters. Victims in NAPTIP shelters were not allowed to leave
unless accompanied by a chaperone. NAPTIP provided funding, in-kind donations, and services to NGOs
and other organizations that afforded protective services to trafficking victims.

Per provisions of the anti-trafficking law, Nigerian authorities ensured identified trafficking victims were not
penalized for unlawful acts committed as a result of being subjected to trafficking. However, in some
instances, NAPTIP authorities deemed adults in prostitution, who claimed to be working voluntarily, victims
of trafficking and detained them in shelter facilities against their will. Officials encouraged victims to assist
in the investigation and prosecution of trafficking cases, and NAPTIP reported 33 victims served as
witnesses or gave evidence during trial in the reporting period. Trafficking victims were guaranteed
temporary residence visas during any criminal, civil or other legal action. All victims were eligible to receive
funds from the victims' trust fund, which was financed primarily through confiscated assets of convicted
traffickers. During the reporting period, the government disbursed 5.4 million naira ($32,700) among 25
victims for various purposes, including vocational training and school tuition, although not necessarily in
equal amounts.

PREVENTION

The government sustained efforts to prevent human trafficking. NAPTIP continued to conduct extensive
national and local programming through radio and print media in all regions to raise awareness about
trafficking, including warning about fraudulent recruitment for jobs abroad. NAPTIP also carried out
advocacy visits to five primary and secondary schools in six states deemed to have a particularly high
trafficking incidence, sensitizing over 10,000 students; NAPTIP also educated transportation carriers in
these six states on their responsibility to prevent trafficking and smuggling. The inter-ministerial committee
on trafficking met 15 times during the reporting period, continued to implement the national action plan, and
released its first annual report. The Ministry of Labor and Productivity continued to implement the national
policy and action plan on labor migration and manage the licensing requirement for all private labor
recruitment agencies. The government did not make any discernible efforts to decrease the demand for
commercial sex acts. The Borno State government also warned that the recruitment and use of child
soldiers was prohibited; however, state government support for some members of the CJTF continued.
The government provided anti-trafficking training for its diplomatic personnel and, with foreign donor
support, to Nigerian troops prior to their deployment abroad on international peacekeeping missions.

**APPENDIX A**


-----

1. This is an appeal against the decision of Judge of the First-tier Tribunal Davda who, in a decision promulgated on
10 June 2015, dismissed the Appellant's appeal against the Respondent's decision of 29 October 2014 to refuse
her asylum claim.

2. The appeal to the First-tier Tribunal was brought under section 83(2) of the Nationality, Immigration and Asylum
Act 2002 as the appellant had been granted leave to remain in the United Kingdom for a period in excess of a year
(366 days).

3. In the First-tier Tribunal the appeal was argued, inter alia, on the basis of Article 8 ECHR. The Judge, at the end
of her decision, considered the Appellant's Article 8 claim and dismissed it. The Grounds of Appeal to the Upper
Tribunal took issue with, amongst other things, the First-tier Tribunal's assessment of the Article 8 claim. At the
hearing before us on 12 August 2015 we indicated our concern that, pursuant to section 83(2), the appeal to the
First-tier Tribunal could only have been brought on asylum grounds and that the Appellant was not entitled to rely
on Article 8 in his appeal before the First-tier Tribunal. Given that section 83 of the Nationality, Immigration and
Asylum Act 2002 was repealed by section 15 of the Immigration Act 2014 as of 20 October 2014, and given that
neither party had brought this jurisdictional issue to our attention prior to the hearing, we allowed both
representatives to make further written representations after the hearing in respect of the relevance of the
withdrawal of section 83 to the present proceedings.

4. We are grateful to the prompt response from both Mr Tufan and Mr Hoshi. We are satisfied that, as a result of the
_[Immigration Act 2014 (Commencement No 3, Transitional and Saving Provisions) Order 2014 (SI 2014/2771),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
section 83 was still applicable to the Appellant at the date of the Respondent's decision. We are therefore satisfied
that the Appellant was not entitled to rely on Article 8 and that the First-tier Tribunal Judge was not entitled to
consider Article 8. We find that the First-tier Tribunal erred in law by considering Article 8 and the decision is set
aside on this basis.

**Background**

5. The Appellant is a national of Nigeria, date of birth 30 June 1989. She is unsure when she first entered the
United Kingdom but the respondent has obtained a visa match in respect of a Visitor Visa application made by her,
or on her behalf, in Lagos on 17 November 2006. The Appellant made an asylum claim on 02 January 2013 on the
basis that she was a victim of trafficking and would face a real risk of persecution in Nigeria if removed as a
consequence of being trafficked.

6. The Respondent refused this application on 12 July 2013 and an appeal against this decision was dismissed by
the First-tier Tribunal on 11 September 2013. On 02 December 2013 the Upper Tribunal identified a material error
of law in the decision of the First-tier Tribunal. The appeal was adjourned for rehearing before the Upper Tribunal
but, following the submission of further evidence, the Respondent withdrew her decision in order to give the
application further consideration. The decision that is the subject of this appeal was made on 29 October 2014,
although the asylum decision itself is dated 28 October 2014 and records that the Appellant's claim was determined
on 20 October 2014. No issue however appears to arise as a result of these discrepancies.

**Summary basis of the Appellant's asylum claim**

7. The Appellant was an only child. She had an abusive father who would beat both her and her mother. When the
Appellant was 16 years old a woman offered to take her abroad. This woman brought the Appellant food and
clothes and a mobile phone for her father. After leaving her family the Appellant initially stayed in a house in Lagos
for two or three months with two ladies she referred to as 'aunties' and three other children. The Appellant worked in
this house and when she did something wrong the women would shout and curse her. She did not know how she
obtained a passport but could remember a man taking her photograph at the house. She eventually entered the
United Kingdom, and was taken to and left at a family residence. Although initially treated well after several weeks
her treatment became more severe. She was required to work and was not allowed to leave the house or use the
telephone. Her food was restricted and she was not allowed to use the washing machine to wash her clothes. She
had to sleep on the floor of the living room and, when hit by one of the children in the family, their mother did
nothing One night men came to the house and the manner in which they looked at her made the Appellant afraid


-----

That night her employer (the man who lived in the property) telephoned the Appellant's father and informed him that
the Appellant was not behaving well. The Appellant's father shouted at her over the phone. The men came another
time and one of them put his arm around the Appellant. She pushed him away and left the room. That night the
Appellant's employer warned her that she would be returned to Nigeria and put into prison. The Appellant
considered killing herself but instead decided to run away. By the time she did eventually run away she had lived in
the house for approximately four to six months.

8. The Appellant thereafter led a transient and unsettled life. She was accommodated by several men in exchange
for sex. In early 2008 she became involved with the Jehovah's Witnesses church and a lady called Pauline tried to
help her on several occasions. In 2010 the Appellant received a phone call from her father informed her of her
mother's death. Angry, the Appellant smashed her mobile phone. In 2012 the Appellant was introduced to the
Poppy Project. A psychiatric report diagnosed her as suffering from complex Post Traumatic Stress Disorder and an
Emotionally Unstable Personality Disorder. She had been self-harming since the age of 17.

**The Reasons For Refusal Letter**

9. In a detailed decision the Respondent considered the Applicant's factual account of being trafficked to the United
Kingdom. Although the Respondent highlighted several concerns with some aspects of the Appellant's account, she
was satisfied that these concerns were adequately allayed by other aspects of the Appellant's evidence, notably the
report by the Consultant Psychiatrist. In a summary of her conclusions (paragraph 38 of the Reasons For Refusal
Letter) the Respondent accept that the Appellant was visited by a woman in Nigeria who offered to take her abroad,
that she stayed with this woman in Lagos for a number of months and undertook domestic work for her, and that the
woman then brought the Appellant to the United Kingdom and handed her to a family. The Respondent also
accepted that the Appellant undertook domestic work for this family and, having then escaped, that she lived with
various men and had sex with them in exchange for food and accommodation.

10. The Respondent then considered whether the Nigerian authorities could provide the Appellant with a sufficiency
of protection against those who trafficked her to the United Kingdom and who exploited her labour here. In light of
the Appellant's account the Respondent was not satisfied she had been trafficked by an organised gang, as
opposed to individuals, or that she had been expected to earn a certain amount of money for the people who
brought her to the United Kingdom. With reference to the authority of PO (Nigeria) v SSHD [2011] EWCA Civ 132
and to extracts from the United States Trafficking in Person Report 2014, the Respondent was not satisfied the
Appellant would be at real risk of persecution if returned to her home area in Nigeria. The Respondent further
considered that the internal relocation option was available to the Appellant.

11. The Grounds of Appeal to the Upper Tribunal indicated that the grant of leave to remain to the Appellant
followed the issuance of a conclusive Grounds decision by the Competent Authority that the Appellant had been
trafficked as claimed.

**The decision of the First-tier Tribunal**

12. The appeal to the First-tier Tribunal was heard on 12 May 2015. Both the Appellant and the Respondent were
represented, the Appellant by Mr Hoshi who appeared before us at the error of law hearing. The Judge's
determination, which accords with the record of proceedings maintained by Mr Hoshi, indicated that the Appellant
relied on her two statements and was not cross-examination-examined (paragraph 7). The determination records
the submissions of both representatives. In her submissions the Home Office Presenting Officer accepted that the
Appellant was trafficked but argued, with reliance on PO, that she would be sufficiently protected as there was no
evidence of any gang involvement in her trafficking. The determination does not record the Respondent making any
submissions undermining the Appellant's credibility. This also accords with the Grounds of Appeal settled by Mr
Hoshi.

13. The Judge nevertheless proceeded to find the Appellant incredible with respect to several aspects of her
account, some of which had already been considered by the Respondent in her Reasons For Refusal Letter. The
Judge rejected the factual basis that supported the Consultant Psychiatrist's findings and rejected the evidence
from Ms Bisi Olateru-Olagbegi a person presented as a country expert of likely gang involvement in the


-----

Appellant's trafficking as “… at best only a presumption on the part of the author.” The Judge rejected the Appellant'
account of being trafficked by an organised gang and found, without engaging with any of the specific background
documents, that the Appellant would be afforded a sufficiency of protection by the Nigerian authorities. The Judge
dismissed the appeal.

**The Grounds of Appeal to the Upper Tribunal**

14. The Grounds contend that the Judge was not entitled to make her adverse credibility findings in circumstances
where the Appellant's factual account was unchallenged. It was further submitted that the adverse credibility
findings were insufficiently reasoned, that the Judge failed to consider or apply the Tribunal's vulnerable witness
guidance, that she failed to consider the Appellant's evidence relating to events that occurred when she was a child
in a child-sensitive manner, that her consideration of the psychiatric evidence and rejection of the country expert
evidence was inadequately reasoned and unlawful, that she failed to apply the governing country guidance
authority, and that she failed to determine a material issue, namely the Appellant's purported suicide risk.

**The error of law hearing**

15. At the outset of the hearing we indicated our preliminary view that the First-tier Tribunal Judge had, for the
reasons enunciated in the Grounds of Appeal, committed various errors of law that render the decision
unsustainable. In response Mr Tufan accepted that there were material errors of law in the determination. Mr Tufan
accepted the factual findings contained in the Reasons For Refusal Letter relating to the Appellant's account and
the credibility conclusions therein. Mr Tufan reminded us that the previous country guidance case of PO (Trafficked
_Women) Nigeria CG[2009] UKAIT 00046 had been removed from the Upper Tribunal's CG list following the Court_
of Appeal decision in PO (Nigeria) v Secretary of State for the Home Department[2011] EWCA Civ 132, although
paragraphs 191-192 remained as interim guidance pending further country guidance from the UTIAC. As the
Appellant's credibility was now accepted Mr Tufan invited us to consider whether this appeal was an appropriate
vehicle through which to issue further country Guidance in respect of victims of trafficking from Nigeria.

16. We indicated to the parties that we were satisfied the determination contained a number of material errors of
law and that, pursuant to section 12 of the Tribunals, Courts and Enforcement Act 2007, we would set aside the
decision of the First-tier Tribunal.

**Discussion**

17. We are satisfied the Judge made several serious errors vitiating the fairness of the hearing and undermining the
sustainability of the decision.

18. It is clear from the Reasons for Refusal Letter (paragraph 38) that the Respondent, despite identifying several
concerns, ultimately accepted as credible the Appellant's account of being trafficked into the United Kingdom and
her subsequent exposure to employment and sexual exploitation. This position should have been reinforced in the
mind of the Judge given that there was no cross-examination of the Appellant by the Home Office Presenting
Officer and given the absence of any submissions made by the Home Office Presenting Officer undermining the
credibility of the Appellant's account. In these circumstances we are satisfied the Judge was not entitled to go
behind the Respondent's own factual findings contained in the Reasons For Refusal Letter without first giving an
indication to the parties that she intended to do so.

19. In HA and TD v SSHD **_[2010] CSIH 28_** the Scottish Court of Session indicated, at 8, that, “As an expert body,
_the Tribunal is entitled to reject evidence notwithstanding that the evidence has not been challenged before it._
_Fairness may however require it to disclose its concerns about the evidence so as to afford the parties an_
_opportunity to address them.” We are satisfied that the Judge acted unfairly in failing to disclose her concerns to the_
Appellant's representative in respect of issues the representative reasonably considered to be uncontentious.”

20. By way of example, the Judge appeared to hold against the Appellant the fact that she was able to give a
detailed account of her life with her family prior to being trafficked, yet was unable to recall the names of those in
the family with whom she lived in the United Kingdom (45). This point had already been considered by the


-----

Respondent in the Reasons For Refusal Letter but was found not to undermine the Appellant's credibility
(paragraphs 30 to 33 of the Reasons For Refusal Letter). The Home Office Presenting Officer did not rely on this
point at the hearing and the Judge gave no indication that she regarded it as a matter of concern.

21. The Judge additionally drew an adverse inference because the Appellant provided only 'short names' of the
men in her life and the women who helped her. Yet there is no indication that the Appellant was ever asked to
provide further information about these individuals, or that she was asked to explain why she only gave first names.
The record of proceedings maintained by Mr Hoshi indicates that the Judge only asked the Appellant a few short
questions. It would not have been reasonably apparent to Mr Hoshi that the Judge had concerns with the nature of
the names provided by the Appellant. The Judge additionally finds the Appellant's explanation as to how she found
the Poppy Project to be 'self-serving' but no satisfactory reasons were offered by her in support of this finding.

22. The Judge held against the Appellant her account of the destruction of her mobile phone on being informed by
her father that her mother had died (52). The Judge records the Appellant's evidence that she was angry when she
destroyed the phone but then finds the Appellant offered no explanation for the destruction. The Appellant was
never asked at the hearing to explain why she destroyed the phone and it is inappropriate for an adverse inference
to be drawn in these circumstances. In any event, given that the appellant had just been informed by her abusive
father that her mother was dead and was, as recorded by the Judge, angry, we find it inherently plausible that the
phone was destroyed in a moment of considerable and understandable anger. The Judge drew a similar adverse
inference in respect of the Appellant's explanation for not approach the British police (she claimed she feared
arrest). The Judge stated that the Appellant did not explain why she feared arrest (57). Yet there is no indication
that the Appellant was ever asked for an explanation.

23. At paragraph 55 the Judge found that the Appellant “… _appears to have been able to conduct her life in the_
_United Kingdom for many years without difficulty in functioning before commencing her therapy where she has_
_presented to others as lacking any real capacity to cope with her position worsening since she has been in therapy”._
With respect, we do not regard a lifestyle consisting of having sex with men in exchange for food and
accommodation as an example of one being able to conduct their life without difficulty in functioning. We find this
conclusion simply not worthy.

24. In concluding that the Appellant had not been trafficked by an organised gang the Judge failed to take account
of or engage with unchallenged evidence relating to a telephone call received by the Appellant during which her
father indicated he and his wife may have problems if the Appellant did not do what she was required to do, and in
respect of a subsequent phone call in which the Appellant's mother indicated she and her husband had been
threatened.

25. We are further satisfied that the Judge materially erred in failing to refer to or seemingly apply the Joint
Presidential Guidance Note No 2 of 2010 and the Senior President of Tribunals 'Practice Direction - First-tier and
Upper Tribunal Child, Vulnerable Adult and Sensitive Witnesses' guidance when assessing the Appellant's
credibility. There was clear medical evidence that the Appellant was to be regarded as a vulnerable witness.

26. Although we are satisfied the Judge also erred in her approach to the psychiatric report and her rejection of the
country expert evidence (for the reasons identified in the Grounds of Appeal, paragraphs 29 to 37), and in her
failure to determine the claimed suicide risk, we see no utility in further exposition of those errors. We are satisfied,
for the reasons we have already given, that the determination is unsafe and that it must be re-made.

**Notice of Decision**

**The First-tier Tribunal Judge did make a material error of law.**

**Direction Regarding Anonymity – Rule 13 of the Tribunal Procedure (First-tier Tribunal)**
**(Immigration and Asylum Chamber) Rules 2014**


-----

Unless and until a Tribunal or court directs otherwise, the appellant is granted anonymity. No report of these
proceedings shall directly or indirectly identify her or any member of her family. This direction applies both to the
appellant and to the respondent. Failure to comply with this direction could lead to contempt of court proceedings.

**APPENDIX B**

**Schedule of Background Evidence**

|It e m|Document|Source|Date|
|---|---|---|---|
|1.|Home Office letter of instruction to NAPTIP||29 Jun 2016|
|2.|Premium Times – Nigeria: Over 70% of Nigeria Girl Trafficking Backed by Victims' Parents – NAPTIP|http://www.premiumtimesng.com/news/more- news/205828-70-per-cent-nigeria-girl-trafficking- backed-victims-parents-naptip.html|23 June 2016|
|3.|This Day – Nigeria: NAPTIP Expresses Solidarity with Victims of Child Labour|http://www.thisdaylive.com/index.php/2016/06/11/napti p-expresses-solidarity-with-victims-of-child-labour/|11 June 2016|
|4.|US State Department, 'US Trafficking in Persons Report' 2016|https://www.state.gov/documents/organization/258876 .pdf|1 June 2016|
|5.|Premium Times – Nigeria has Largest Number of Enslaved People in Sub- Saharan Africa – Report|http://www.premiumtimesng.com/news/headlines/204 415-nigeria-largest-number-enslaved-people-sub- saharan-africa-report.html|31 May 2016|
|6.|Europol-INTERPOL Report: Migrant Smuggling Networks|https://www.europol.europa.eu/sites/default/.../ep- ip_report_executive_summary.pdf|May 2016|
|7.|Ikeora, M., 'The Role of African Traditional Religion and 'Juju' in Human Trafficking: Implication for Anti- trafficking', Journal of International Women's Studies, vol. 17(1)|http://vc.bridgew.edu/cgi/viewcontent.cgi?article=1835 &context=jiws|May 2016|
|8.|Van Guard – Nigeria: I Aborted 320 Pregnancies – Abigail, Self-Confessed Human Trafficking Victim|http://www.vanguardngr.com/2016/04/aborted-320- pregnancies-abigail-self-confessed-human-trafficking- victim/|3 April 2016|
|9.|Van Guard – Nigeria: NAPTIP Denies Neglecting Maid Allegedly Raped by Lebanese|http://www.vanguardngr.com/2016/04/naptip-denies- neglecting-maid-allegedly-raped-lebanese/|2 April 2016|
|1 0.|Stop Violence Against Women (Nigeria) - Senate Rejects Landmark Bill on Violence against Women…|https://twitter.com/stopvawglobal/status/71706732696 5702656|April 2016|
|1 1.|Daily Trust – Nigeria: NAPTIP Urges EU to Screen Immigrations for Traffickers, Victims|http://www.dailytrust.com.ng/news/home-front/naptip- urges-eu-to-screen-immigrants-for-traffickers- victims/139427.html|23 March 2016|
|1 2.|Global Legal Monitor: Gender Equality Bill Fails in the Senate|http://www.loc.gov/law/foreign-news/article/nigeria- gender-equality-bill-fails-in-the-senate/|March 2016|
|1 3.|Premium Times – Nigeria: Human Trafficking – Asemota, Nigerian Fugitive, Extradited to UK|http://www.premiumtimesng.com/news/more- news/197539-human-trafficking-asemota-nigerian- fugitive-extradited-uk.html|27 January 2016|
|1 4.|Thomson Reuters – Nigerian Crime Gangs 'Use UK Airports' to Traffic Women – BBC|http://af.reuters.com/article/commoditiesNews/idAFL8 N15B2W1|27 January 2016|
|1 5.|Premium Times – Nigeria: Bisi Olateru- Olagbegi (1953-2015)|http://opinion.premiumtimesng.com/2016/01/03/bisi- olateru-olagbegi-1953-2015-by-reuben-abati/|3 January 2016|
|1 6.|This Day – Nigeria: Giving Victims of Human Trafficking Access to Justice (2|http://allafrica.com/stories/201601042107.html|2 January 2016|


1
7.


Freedom House: Nigeria https://freedomhouse.org/country/nigeria January 2016


-----

|1 8.|Europol, Trafficking in Human Beings in the European Union (2016)|https://www.europol.europa.eu/content/trafficking- human-beings-eu|2016|
|---|---|---|---|
|1 9.|Independent Anti-Slavery Commissioner - Strategic Plan 2015-2017|https://www.gov.uk/government/publications/independ ent-anti-slavery-commissioner-strategic-plan-2015-to- 2017|2015-2017|
|2 0.|Campana, P., 'The Structure of Human Trafficking: Lifting the Bonnet on a Nigerian Transnational Network, Brit. J. Criminol, 56, (2016)|https://www.deepdyve.com/lp/oxford-university- press/the-structure-of-human-trafficking-lifting-the- bonnet-on-a-nigerian-VMIUyaoVCI|2016|
|2 1.|Daily Trust – Nigeria: Trafficking in Persons Still a Booming Business|http://www.dailytrust.com.ng/news/home- front/trafficking-in-persons-still-a-booming- business/126002.html|24 December 2015|
|2 2.|Transparency International, People and Corruption - Africa Survey|http://www.transparency.org/whatwedo/publication/pe ople_and_corruption_africa_survey_2015|1 December 2015|
|2 2.|IRB Canada : Women without male or family support can obtain housing and employment||November 2015|
|2 3.|EASO, 'Nigeria: Sex Trafficking of Women', Country of Origin Information Report, (Oct 2015)|https://www.easo.europa.eu/sites/default/files/public/B Z0415678ENN.pdf|October 2015|
|2 4.|Women Rights Under Siege - Denying basic human rights, Italy to deport… (Sep 2015)|http://www.womenundersiegeproject.org/blog/entry/de nying-basic-human-rights-italy-to-deport-dozens-of- nigerian-women-torture/|September 2015|
|2 5.|Home Office CIG, 'Nigeria: Gender- Based Discrimination/Harm/Violence Against Women, (Aug 2015)|http://www.refworld.org/pdfid/55dda9204.pdf|August 2015|
|2 6.|BMC Health Services Research, Integrating mental health into primary care|http://bmchealthservres.biomedcentral.com/articles/10 .1186/s12913-015-0911-3|21 June 2015|
|2 7.|Home Office CIG, Nigeria: Background information including Actors of Protection and Internal Relocation|http://www.refworld.org/docid/55794ae04.html|9 June 2015|
|2 8.|Finnish Immigration Service: Trafficking Women to Europe (24 Mar 2015)|http://www.migri.fi/download/60332_Suuntaus_NigSuu ntaus_HumanTraffickingfromNigeriaFINAL200415.pdf ?b3ecfe879399d388|24 March 2015|
|2 9.|US State Department, Nigeria Human Rights Report|http://www.state.gov/j/drl/rls/hrrpt/humanrightsreport/in dex.htm#wrapper|2015|
|3 0.|International Movement Against all forms of Discrimination & Racism (IMADR) Briefing-Paper: Human Trafficking in Nigeria|http://imadr.org/wordpress/wp- content/uploads/2016/01/IMADR-Briefing- Paper_Human-Trafficking-in-Nigeria_5.11.2015.pdf|October 2015|
|3 1.|IOM (CARE and TACT Projects): Enhancing the Safety and Sustainability of the Return and Reintegration of Victims of Trafficking|http://iomfrance.org/sites/default/files/Enhancing%20th e%20Safety%20and%20Sustainability%20of%20the% 20Return%20and%20Reintegration%20of%20VoTs.p df|2015|
|3 2.|Kigbu, Challenges and Investigation and Prosecuting Trafficking in Persons' Cases in Nigeria (2015)|http://www.iiste.org/Journals/index.php/JLPG/article/vi ewFile/23683/24257|2015|
|3 3.|Reliefweb, Nigeria – IOM warns of steep rise in women trafficked from Nigeria to Italy (2015)|http://reliefweb.int/report/nigeria/iom-warns-steep-rise- women-trafficked-nigeria-italy|16 October 2015|


3 NAPTIP: 2015 Data Analysis (Annual 2015


-----

|4.|Report)|Col3|Col4|
|---|---|---|---|
|3 5.|US State Department, 'US Trafficking in Persons Report' 2011-2015|https://www.state.gov/documents/organization/245365 .pdf|2015|
|3 6.|National Crime Agency -UKHTC NRM Statistics - End of year Summary 2015|http://www.nationalcrimeagency.gov.uk/publications/6 76-national-referral-mechanism-statistics-end-of-year- summary-2015/file|2015|
|3 7.|Plambech, S., ´Between “Victims” and “Criminals”: Rescue, Deportation, and Everyday Violence Among Nigerian Migrants', in: Social Politics: International Studies in Gender, State & Society, Vol. 21, No 3, 1, September 2014.||September 2014|
|3 8.|Home Office COI, 'Nigeria' June 2013 (reissued February 2014)|https://www.scribd.com/doc/213889264/Nigeria-COI- Report-Revision-v2-14-1-31|February 2014|
|3 9.|Goddy, Human Trafficking and Interface of Slavery In The 21st Century in Nigeria (2014)|http://iiste.org/Journals/index.php/RHSS/article/view/1 5799/16614|2014|
|4 0.|Nwogu, Anti-Trafficking Interventions in Nigeria and the Principal-Agent Aid Model (2014)|http://www.antitraffickingreview.org/index.php/atrjourn al/article/view/64/62|2014|
|4 1.|NAPTIP: 2014 Data Analysis (Annual Report)||2014|
|4 2.|IPPR (Cherti, M., Pennington, J., Grant, P.), 'Beyond Borders: Human Trafficking from Nigeria to the UK', (January 2013)|http://www.ippr.org/files/images/media/files/publication /2013/01/nigeria- trafficking_Jan2013_10189.pdf?noredirect=1|January 2013|
|4 3.|IPPR: Homecoming – Return and Reintegration of Irregular Migrants from Nigeria (2013)|http://www.ippr.org/files/images/media/files/publication /2013/04/Homecoming_irregular_migrants_Nigeria_A pr2013_10661.pdf?noredirect=1|April 2013|
|4 4.|Okogbule, N.S., 'Combating the “new slavery” in Nigeria: an appraisal of legal and policy response to human trafficking', Journal of African Law, 2013||27 February 2013|
|4 5.|UNHCR - Voodoo, Witchcraft and Human Trafficking in Europe (2013)|https://www.ecoi.net/file_upload/1930_1382531731_5 26664234.pdf|2013|
|4 6.|IRB Canada: Women without male or family support can obtain housing and employment|http://irb- cisr.gc.ca/Eng/ResRec/RirRdi/Pages/index.aspx?doc= 454259|19 November 2012|
|4 7.|IMPOWR, Nigeria's Approach to Trafficking|http://www.impowr.org/journal/room-improvement- nigerias-approach-trafficking|4 September 2012|
|4 8.|CORI (UNHCR), Thematic Report, Nigeria- Gender and Age|http://www.refworld.org/pdfid/514830062.pdf|December 2012|
|4 9.|UNODC Issue Paper: Abuse of a position of vulnerability and other “means” within the definition of trafficking in persons (2012)|https://www.unodc.org/documents/human- trafficking/2012/UNODC_2012_Issue_Paper_- _Abuse_of_a_Position_of_Vulnerability.pdf|2012|
|5 0.|NAWEY (Network of Young African- Spanish Women for Empowerment): Feminism in Nigeria|http://www.nawey.net/wp- content/uploads/downloads/2012/05/Feminism-in- Nigeria.pdf|October 2011|
|5 1.|Ellis, T., Akpala, J., 'Making sense of the relationship between trafficking in persons, human smuggling, and organised crime: the case of Nigeria', The Police Journal, 84(1), March 2011||March 2011|


5
2.


WHO, Mental Health Atlas Nigeria
(2011)


http://www.who.int/mental_health/evidence/atlas/profil
es/nga_mh_profile.pdf?ua=1


2011


-----

|5 3.|UNODC Issue Paper: The Role of Corruption in Trafficking in Persons (2011)|https://www.unodc.org/documents/human- trafficking/2011/Issue_Paper_- _The_Role_of_Corruption_in_Trafficking_in_Persons. pdf|2011|
|---|---|---|---|
|5 4.|Akor, L., 'Trafficking of women in Nigeria: causes, consequences and the way forward', Corvinus Journal of Sociology and Social Policy, 2(2), 2011|https://www.google.co.uk/search?q=Akor,+L.,+%E2% 80%98Trafficking+of+women+in+Nigeria:+causes,+co nsequences+and+the+way+forward%E2%80%99,+C orvinus+Journal+of+Sociology+and+Social+Policy,+2 %282%29,+2011&ie=utf-8&oe=utf- 8&gws_rd=cr&ei=TFbpV-qKCOnZgAaw6a7QCQ|2011|
|5 5.|Nwogu, Collateral Damage (Nigeria) – Study for unpublished paper (2011)||2011|
|5 6.|Nwogu, OSCE ODIHR Research regarding the national laws, policies and practices of NIGERIA relating to the return of trafficked-exploited persons (2011)||2011|
|5 7.|Fayomi, 'Women, Poverty and Trafficking'|http://citeseerx.ist.psu.edu/viewdoc/download?doi=10. 1.1.530.6164&rep=rep1&type=pdf|2009|
|5 8.|Laczko, Trafficking in Persons and Human Development- Towards A More Integrated Policy Response|https://core.ac.uk/download/pdf/6569605.pdf|1 October 2009|
|5 9.|Danish Immigration Service: Protection of victims of trafficking in Nigeria|https://www.nyidanmark.dk/nr/rdonlyres/bad16bf3- a7c8-4d62-8334- dc5717591314/0/nigeriatrafficking2007finalpdf.pdf|2008|
|6 0.|IOM, 'Migration, human smuggling, and trafficking from Nigeria to Europe'|https://www.iom.int/files/live/sites/iom/files/What-We- Do/idm/docs/MRS23.pdf|2006|
|6 1.|Laura Cardinal Reports||2006|
|6 2.|Ikpeme & Olateru-Olagbegi (ILO), Review of Legislation & Policies on Human Trafficking and Forced Labour|http://www.ilo.org/wcmsp5/groups/public/@ed_norm/ @declaration/documents/publication/wcms_083149.p df|2006|
|6 3.|Olateru-Olagbegi, Human Trafficking in Nigeria- Root Causes and Recommendations (2006)|http://unesdoc.unesco.org/images/0014/001478/1478 44e.pdf|2006|
|6 4.|Okojei, Trafficking of Nigerian Girls to Italy – Report of the Field Study|http://www.unicri.it/topics/trafficking_exploitation/archiv e/women/nigeria_1/research/rr_okojie_eng.pdf|July 2003|
|6 5.|Prina, Trade and Exploitation of Minors and Young Nigerian Women for Prostitution in Italy|http://www.unicri.it/topics/trafficking_exploitation/archiv e/women/nigeria_1/research/rr_prina_eng.pdf|July 2003|
|6 6.|Shelly, Trafficking in Women - The Business Model Approach||2003|
|6 7.|UNODC – Extracts from website||Not dated|
|6 8.|EU External Actions Service – Nigerian Programmes|https://eeas.europa.eu/delegations/nigeria_en|Not dated|
|6 9.|NAPTIP website pages|http://www.naptip.gov.ng/|Not dated|
|7 0.|WOCON-WOTCLEF-WPSN website pages||Not dated|
|7 1.|List of Nigerian NGOs provided by SSHD with descriptions||Not dated|
|7 2.|Completed RALON NAPTIP questionnaire (response to document 1 above)||Not dated|


7
3.


Completed RALON (other
organisations) questionnaires (response
to document 1 above)


Not dated


-----

1 More detail of these issues is set out in the annexes.

2 Article 3(a) Protocol to Suppress and Punish Trafficking in Persons, especially Women and Children,
supplementing the United Nations Convention against Transnational Organized Crime (Palermo Protocol)(2003);
Article 4(a) Council of Europe Convention on Action against Trafficking in Human Beings (2005); Article 2(a) EU
Directive 2011/ 36/EU.

3 See for example International Organization for Migration: Enhancing the Safety and Sustainability of the
Return and Reintegration of Victims of Trafficking; Lessons learnt from the CARE and TACT projects 2015.

4 In _HM and others (Article 15(c)) Iraq CG_ _[[2012] UKUT 00409(IAC), the Tribunal held: Though very](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:573R-PRR1-F0JY-C0GS-00000-00&context=1519360)_
considerable weight is almost always to be attached to UNHCR guidelines on risk categories in particular countries,
it is not accepted that departure from the guidelines should only take place for a cogent and identified reason.
Cases are to be decided on the basis of all the evidence and arguments presented to the Tribunal.

5 Commissioned by the UNHCR.

6 From other African countries

7 from a 2006 census

8 Independent Anti-Slavery Commissioner Strategic Plan 2015-2017; although similar comments are
made in numerous reports including the US State Department TIP Reports, UNODC and by the experts we heard
from.

9 UNODC Measures to combat Trafficking in Human Beings in Benin, Nigeria and Togo September 2006
and corroborated by various other official documents before us: IPPR, IOM, European Commission amongst others.

10 Mrs Olateru-Olagbegi expert opinion 2nd May 2015;
WWW.europol.europa.eu/sites/default/files/publications/trafficking_in_human_beings_in_the_european_union_201
1.pdf

11 Europol 2016 Report

12 The OSCE/ODIHR research regarding the national laws, policies and practices of NIGERIA relating to
the return of trafficked/exploited persons Report compiled after a fact-finding mission to Nigeria between 19 and 26
February 2011

13 Cherti report

14 Europol 2016 Report

15 IOM 2006 Report

16 Campana suggests that those involved in trafficking networks are not continuously involved: they
participate in an activity with other offenders and then leave the network.

17 Including for example the Cherti report which refers to the many diverse individuals who may facilitate
the different stages of a trafficked journey: transporters, receivers, brothel keepers, forgers of documentation,
corrupt border guards and embassy officials. Cherti also refers to the use made of well–established structures and
services such as travel agencies, money transfer services, senior and well respected individuals within the
community and local faith healers and the ability of traffickers to bring people into the UK using legal routes without
the individual in question being questioned about the job offer received, or provided with information about the visa
they are being provided with or about their rights in the UK


-----

18 ILO, ECPAT and Anti Slavery International note the high risks of sexual exploitation for child domestic
servants. E Felicini 'From Domestic Labour to Commercial Sexual Exploitation: the hidden risk for Child Workers,
ECPAT International Journal (October 2013) refers to a first link between a child domestic worker and subsequent
commercial sexual exploitation – the promise of employment as a domestic worker is often used to recruit children
for commercial exploitation.

19 OSCE Report, IOM Report 2006

20 The same or similar characteristics were identified by Cherti and a field survey commissioned by the
UN Interregional Crime and Justice Research Institute to provide data to guide the programme of action against
trafficking in minors and women from Nigeria to Italy for sexual exploitation – Professor Okojie and ors “Trafficking
of Nigerian girls to Italy” July 2003.

21 Paragraph 10 UNHCR Guidelines 7 April 2006.

[22 See for example Said [2016] EWCA Civ 422](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JP5-M001-F0JY-C2DW-00000-00&context=1519360)

23 See in particular paragraphs 16 and 18

24 It may be that in the context of Article 3 the concept of persecution may require different analysis – see
_Said._

25 The National Agency for the Prohibition of Trafficking in Persons established by the Trafficking in
Persons (Prohibition) enforcement and Administration Act 2003; amended in 2005 and subsequently repealed and
replaced by Trafficking in Persons (Prohibition) enforcement and Administration Act 2015 which received
presidential assent on 15 March 2015.

26 The Victims of Trafficking and Violence Protection Act of 2000 (P.L. 106-386), the Trafficking Victims
Protection Reauthorization Act of 2003 (H.R. 2620), the Trafficking Victims Protection Reauthorization Act of 2005
(H.R. 972), and the Trafficking Victims Protection Reauthorization Act of 2008 (H.R. 7311), see in particular s108;
Annex 5

27 See Annex 5

28 OSCE/ODIHR delegation

29 This includes not only the actual costs incurred by the traffickers of her travel etc but the anticipated
profit before the victim is deemed to be able to retain any money she 'earns'.

30 “Under paragraph 339O of the Immigration Rules, the question to be asked is whether the claimant
would face a well-founded fear of persecution or real risk of serious harm in the place of relocation, and whether it is
reasonable to expect them to travel to, and stay in that place. This requires full consideration of the situation in the
country of origin, means of travel, and proposed area of relocation in relation to the individual's personal
circumstances. Even where country information and guidance suggest that relocation is possible, it is the ability of
the individual to relocate in practice which must be assessed. While it remains the responsibility of the claimant to
establish a well founded fear of persecution or real risk of serious harm in the country of origin, caseworkers must
demonstrate that internal relocation is reasonable/not unduly harsh, having regard to the individual circumstances
of the claimant and the country of origin information. This means taking account of the means of travel and
communication, cultural traditions, religious beliefs and customs, ethnic or linguistic differences, health facilities,
employment opportunities, supporting family or other ties (including childcare responsibilities and the effect of
relocation upon dependent children), and the presence and ability of civil society (e.g non-governmental
organisations) to provide practical support. In certain countries, financial, logistical, social, cultural and other factors
may mean that women face particular difficulties. This may be the case for divorced women, unmarried women,
widows or single/lone parents, especially in countries where women are expected to have male protection. If
women face discrimination in a possible place of relocation and are unable to work or obtain assistance from the
th iti l ti ld b bl Wh th f i f b f h f il l ti i l l t


-----

appropriate if the situation a woman would be placed in would be likely to leave her with no alternative but to seek
her family's assistance and thus re-expose her to a well-founded fear of persecution or a real risk of serious harm.
Caseworkers must consider whether the claimant, if unaccompanied, would be able to safely access the proposed
relocation area. Gender specific risks include the risk of being subjected to sexual violence…..”

31 The Structure of Human Trafficking: lifting the bonnet on a Nigerian Transnational Network, British
Journal of Criminology, 56 (2016) Campana P.

32 Primary, secondary and tertiary sources of research – Library Services VirginiaTech:

**Primary sources allow researchers to get as close as possible to original ideas, events, and empirical**
research as possible. It is an original document containing first-hand information about a topic. Such sources may
include creative works, first hand or contemporary accounts of events, and the publication of the results of empirical
observations or research.

**Secondary sources analyze, review, or summarize information in primary resources or other secondary**
resources. Even sources presenting facts or descriptions about events are secondary unless they are based on
direct participation or observation. Moreover, secondary sources often rely on other secondary sources and
standard disciplinary methods to reach results, and they provide the principle sources of analysis about primary
sources. An important facet of secondary research is that they offer an interpretation of primary research.

**Tertiary sources provide overviews of topics by synthesizing information gathered from other resources.**
Tertiary resources often provide data in a convenient form or provide information with context by which to interpret
it.

The distinctions between primary, secondary, and tertiary sources can be ambiguous. An individual document may
be a primary source in one context and a secondary source in another. Encyclopedias are typically considered
tertiary sources, but a study of how encyclopedias have changed on the Internet would use them as primary
sources. Time is a defining element.

33 See for example United Nations Global Plan of Action to Combat Trafficking in Persons. UN Doc.
A/RES/64/293 (12 August 2010), preambular paragraph 3

34 International Labour Office and the European Commission, Operational Indicators of Trafficking in
Human beings (2009)

35 http://www.state.gov/documents/organization/258876.pdf

36 Article 4 of the Palermo Protocol:

“This Protocol shall apply, except as otherwise stated herein, to the prevention, investigation and prosecution of the
offences established in accordance with article 5 of this Protocol, where those offences are transnational in nature
and involve an organized criminal group, as well as to the protection of victims of such offences.”

**End of Document**


-----

