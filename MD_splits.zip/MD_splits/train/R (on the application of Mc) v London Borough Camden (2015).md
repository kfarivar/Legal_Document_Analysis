# R (on the application of Mc) v London Borough Camden (2015) [2015] EWHC
 4034 (Admin)

QBD, ADMINISTRATIVE COURT

CO/5846/2015

Supperstone J

03/12/2015

CO/5846/2015

**[Neutral Citation Number: [2015] EWHC 4034 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J8P-R9P1-F0JY-C10K-00000-00&context=1519360)**

**IN THE HIGH COURT OF JUSTICE**

**QUEEN'S BENCH DIVISION**

**THE ADMINISTRATIVE COURT**

Royal Courts of Justice

Strand

London WC2A 2LL

Thursday 3 December 2015

**B e f o r e:**

**MR JUSTICE SUPPERSTONE**

**Between:**

**THE QUEEN ON THE APPLICATION OF MC**

Claimant

v

**LONDON BOROUGH OF CAMDEN**

First Defendant

**SECRETARY OF STATE FOR THE HOME DEPARTMENT**

Second Defendant

Computer‑Aided Transcript of the Stenograph Notes of


-----

WordWave International Limited

Trading as DTI Global

190 Fleet Street London EC4A 2AG

Tel No: 020 7404 1400 Fax No: 020 7831 8838

(Official Shorthand Writers to the Court)

**Miss Shu Shin Luh (instructed by Maxwell Gillot) appeared on behalf of the Claimant**

**Miss Holly Stout** (instructed by Leal Department, London Borough of Camden) appeared on behalf of the First
Defendant

**Mr Eric Metcalfe (instructed by Government Legal Department) appeared on behalf of the Second Defendant**

J U D G M E N T

(Approved)

Crown copyright©

1. MR JUSTICE SUPPERSTONE: Last Friday, 27 November 2015, Laing J, on the claimant's paper application
for interim relief, noted under the heading "Observations":

"(1) The competent authority has decided that there are reasonable grounds to believe that the first claimant is a
victim of trafficking and modern slavery. There is a continuing investigation into the claimant's circumstances by
the National Referral Mechanism. The second and third claimants are her children.

(2) There are concerns that 'aunty', with whom the claimant is living, is continuing to exploit her. Aunty has now
told the claimant that she and her children must leave her house by the end of November.

(3) For the reasons given in the claimants' grounds, it is well arguable that in the circumstances the first and/or
second defendant has a duty to accommodate and support the claimant and her children."

2. By way of interim relief, the judge ordered at paragraph 1 of her order ‑

"Upon the hearing referred to in paragraph 3 below or further order in the meantime, the first and second

defendants to use their reasonable endeavours forthwith to co‑operate in order to arrange safe and suitable

accommodation and support for the claimants, having regard for their particular needs and to the first claimant's
need for assistance as a potential victim of trafficking in respect of whom a reasonable grounds decision has been
made."

That order imposed an obligation on the defendants to use reasonable endeavours to co‑operate in order to ensure

that the claimant and her children are supported while the investigation continues. The judge at paragraph 3 of the
order ordered a return date for today with a time estimate of thirty minutes when the defendants may apply, if so
advised, to set this order aside or for further directions.

3. Yesterday ‑ 2 December ‑ the claimants issued an application notice for enforcement with a draft order,

paragraph 1 of which reads ‑

"1 The defendant shall forthwith comply with the order of Laing J to make arrangements for accommodation which
is safe and suitable for the claimants in the London area. Such arrangements shall have regard to the first
claimant's need to maintain her support with the women's therapy centre Kalayaan and her legal representatives


-----

and her need for assistance for her recovery and reflection as a victim of trafficking, the second claimant's need to
continue with her schooling at her current school in the London Borough of Camden and the best interests of both
child claimants. Such accommodation should be arranged no later than 4 pm on 3 December 2015 and shall be
informed to the claimant's solicitors by that time. Such accommodation shall continue until the consideration of
permission in this claim or further order."

As a result of that application notice, over the last twenty‑four hours a substantial amount of documentation

(including witness statements) has been produced directed at the issue as to whether the defendants have failed to
comply with the terms of the order of Laing J.

4. The hearing today has lasted the whole day. It concluded at 4.50 pm and because of the urgency of the matter I
am giving judgment shortly before 5.30 pm. In these circumstances I appreciate that I will not be able to deal as
fully with the very able submissions made by counsel as I would have liked.

5. Miss Stout for the council and Mr Metcalfe for the Secretary of State submit that the defendants have complied
with the order of the judge. Two accommodation options have been offered to the claimants: first, accommodation

in Sheffield provided through the Salvation Army; second, bed‑and‑breakfast accommodation in Camden for the

night of 30 November. Both options have been rejected by the first claimant. The position currently therefore is
that the claimant remains living at aunty's. Both defendants submit that the accommodation on offer in Sheffield is
appropriate and suitable for the claimants having regard to their particular needs and circumstances.

6. Miss Luh, for the claimants, summarises the defendants' position as follows in her skeleton argument:

"7. The first defendant's position is that it owes no duties towards the claimants in light of MC's status as a victim of
trafficking. That responsibility lies with the Salvation Army which has been contracted by the second defendant to
assist victims trafficking during reflection and recovery period.

8. The second defendant's position is that it's responsibility to assist the claimants in light of the positive reasonable
grounds of assessment of MC as a victim of trafficking is to refer her and her children to the Salvation Army. The
duty to assist is temporary and the Salvation Army can provide this."

7. The Secretary of State, pursuant to the relevant guidance, contracts the finding of suitable accommodation in
cases such as this to the Salvation Army. The Salvation Army completed two assessments, the first on 12
November and the second on 30 November 2015. There is no doubt that if accommodation could have been found
by the Salvation Army in London then that would be the most suitable, having regard to the claimants' particular
needs. However such accommodation was not available.

8. The relevant legal principles on this application are not in issue. The test to be applied is that in London
Borough of Newham v Sacupima in the judgment of Latham LJ at paragraph 17:

"17 Where the effects of the decision are of short duration the court will be likely to require compelling evidence of a
significant breach of the duty owed to the applicant before it will grant relief. The question of whether or not
accommodation is suitable for the claimants is a matter for the defendants but subject only to review on rationality
grounds."

9. Mr Metcalfe apologises on behalf of the Secretary of State for the fact that the evidence of the decision‑making

process in relation to the decision taken by the Secretary of State is not as complete as she would wish. However I
am satisfied on the evidence that to the extent that any of the legal duties relied on by the claimants, such as Article
3 of the European Convention on Human Rights or the Trafficking Directive, impose a requirement on the State to
ensure that certain objective minimum standards are met in relation to the provision of accommodation, the
accommodation in Sheffield plainly meets that objective minimum.


-----

10. Further, I am satisfied on the evidence that the Secretary of State did consider, as she must, whether the
accommodation in Sheffield is suitable for the claimants' needs and decided that it was. That was a decision that in
my judgment, on the evidence, she was entitled to make.

11. I have reached the same conclusion in relation to the decision taken by the local authority: first, that the council
did take a decision as to whether the accommodation offered in Sheffield is suitable and, second, that that was a
decision that the council was entitled to take. Both defendants were under a positive duty to assist and arrange
suitable accommodation for the claimants. There is in my view sufficient evidence that the defendants have

co‑operated with regard to the suitability of accommodation for the claimants and have complied with the order of

Laing J.

12. For the reasons I have given, the enforcement application shall be dismissed. The defendants invite me to
discharge the order of Laing J. I consider that in all the circumstances it is appropriate that it should remain in
place.

13. Once again, I thank all counsel for their considerable assistance with this case and I thank the court staff for
allowing me to deliver this judgment at this late hour.

14. MISS LUH: Can I, for the transcript writer's note, say that the Salvation Army's assessment was 12 November.

15. MR JUSTICE SUPPERSTONE: I am grateful.

16. MISS LUH: Secondly, would it be possible for us to have an expedited transcript of the judgment?

17. MR JUSTICE SUPPERSTONE: Certainly.

18. MISS LUH: Certainly we can undertake to pay the requisite fee for that.

19. MR JUSTICE SUPPERSTONE: On that basis I will ask for that to be done.

20. MISS LUH: I am grateful.

21. MR JUSTICE SUPPERSTONE: Do you want an inquiry made as to how long that will take? (Pause) Four to
five days I am told.

22. MISS LUH: I am grateful. I suspect it will be passed on to your Lordship for checking.

23. MR JUSTICE SUPPERSTONE: Certainly.

24. MISS LUH: The third thing would be, I suspect, a matter of the issue of costs.

25. MR JUSTICE SUPPERSTONE: Yes.

26. MISS LUH: Could I indicate at this juncture that the appropriate order is costs reserved given that the order
has remained as it stands but we have not succeeded in our enforcement application. All of it has been dealt with
together as appropriately so, as directed by Laing J.

27. MR JUSTICE SUPPERSTONE: I will hear from counsel.

28. MR METCALFE: On behalf of the Secretary of State, we ask for our costs today. There has been a lengthy
hearing in this matter. The claimants have not succeeded in their application. We were of course obliged to be

here today because ‑ ‑ ‑ ‑ ‑

29. MR JUSTICE SUPPERSTONE: What do you say about the original order to remain in place. It just seemed to
me that it was more suitable for it to remain in place rather than be discharged: first, because we dealt with the


-----

matter very speedily, but more so because the position of the claimants still remains uncertain with them residing at
present with aunty. I feel happier with the order remaining as it is in case any matter should arise in the future.

30. MR METCALFE: Certainly we do not dispute that approach. I think the fundamental point to be made in
relation to this is that your Lordship has found a substantive case that the defendants have made out in this matter.
The defendants have made a reasonable decision and assessed the offer of accommodation in Sheffield as being

suitable. The particular approach that your Lordship has made ‑ you have not in fact discharged the order ‑ goes

more to maintaining the welfare of the claimant rather than to the merits of the matter.

31. MISS STOUT:  My Lord can of course accede to costs. I would adopt the submissions of my friend, with
respect. I would add in substance this is a hearing that the claimant has lost. It was all about London versus
Sheffield. The claimant lost on that point, and that is what has taken up the whole of today. For that reason costs
should follow that event, notwithstanding the technicalities that the order made on 27th is going to stay in place.

32. MISS LUH: One of the reasons why it has been a lengthy day is that we have had to deal on the hoof with
quite a lot of information being thrown at us.

33. MR JUSTICE SUPPERSTONE: That of course was as a result of the application you put in yesterday,
certainly to a very great extent.

34. MISS LUH: To some extent, but there was a return date. The issues that we put in to evidence in submissions

of the application were issues that we had always consistently pleaded. In fact, throughout the entire pre‑action

proceedings we have been requesting information regarding how they made their decision. This is an interim

injunction ‑ interim position ‑ and the court is only able to assess on what it has. If further disclosure arises it may

be that the circumstances change. The appropriate order normally on an interim basis ‑ and that was the view

taken by Laing J ‑ was to reserve costs.

35. MR JUSTICE SUPPERSTONE: Certainly, if it had just been a return date then that would be one matter. But
the application you have made has failed. That has taken up most of the day.

36. MISS LUH: I have made my submissions. The other issue is that the claimant is a publicly funded person.

37. MR JUSTICE SUPPERSTONE: That I quite understand.

38. MISS LUH: It is a bit of a pointless exercise.

39. MR JUSTICE SUPPERSTONE: The practicalities may lead to a certain result.

40. MISS LUH: Can I ask then just for the costs of this hearing because that reflects the situation, the costs of the
defendant's costs of defending the application for enforcement, and that in my submission would sufficiently lend
clarity as the proceedings go forward.

41. MISS STOUT: My Lord, bear in mind this is what the claimant served yesterday and this is what we served.

42. MR JUSTICE SUPPERSTONE: Yes. I am minded to accept Miss Luh's submission that you are entitled to the
_costs of defending the application for enforcement. One does not want further time to be taken up on assessment_
_of costs. If I were to say a certain per centage of your costs, what would you say, Mr Metcalfe?_

43. MR METCALFE: It would depend very much on the per centage. In our respectful submission, responding to
the application for enforcement has taken the bulk of the day. We would say an appropriate level would be eighty
per cent.

44. MR JUSTICE SUPPERSTONE: Yes. Miss Stout?


-----

45. MISS STOUT: At least that. It is exactly the same issues on both applications. That is all that has been done
in defending in the course of the application in substance because it is the same.

46. MR JUSTICE SUPPERSTONE: Yes. Miss Luh?

47. MISS LUH: Eighty per cent is probably ‑ ‑ seventy to eighty per cent is what is happening at the moment on

detailed assessment. So bear in mind this is, in a way, a pointless exercise unless the claimants get a windfall in
terms of money.

48. MR JUSTICE SUPPERSTONE: It would be a certain per centage of the costs as assessed.

49. MISS LUH: Yes. Essentially you are fixing ‑ ‑ forgive me if I am slightly confused.

50. MR JUSTICE SUPPERSTONE: I would be ordering that the defendants are entitled to seventy per cent or
eighty per cent, whatever the per centage is, of their total costs.

51. MISS LUH: Of the total costs of the proceedings?

52. MR JUSTICE SUPPERSTONE: No ‑ today's hearing. It is just an easier way of doing it sometimes for the

costs Master. The alternative is to leave it as defendants' costs for defending the application for enforcement. Any
views on that, Mr Metcalfe?

53. MR METCALFE: We say they are effectively one and the same. It is extremely difficult to separate out, in
essence.

54. MR JUSTICE SUPPERSTONE: Yes. I have heard the case so it is probably better for me to do it. I would say
eighty per cent of your costs.

55. MR METCALFE: I am grateful.

56. MISS LUH: That would be eighty per cent of something that is unknown. I suppose that would be subject ‑ ‑ ‑ ‑

‑

57. MR JUSTICE SUPPERSTONE: Yes. Eighty per cent of the costs subject to assessment. If you can agree the
precise form of the order in relation to that, but are you clear as to what I am saying?

58. MISS STOUT: Yes.

59. MISS LUH: I am grateful for that. Would you like me to draw up a minute of the order and send it to your
clerk?

60. MR JUSTICE SUPPERSTONE: Would you do that? Get agreement with your colleagues.

61. MISS LUH: Of course. It is a straightforward order.

62. MR JUSTICE SUPPERSTONE: Very straightforward.

63. MISS LUH: In terms of progressing the claim, there has not been expedition obviously. My suggestion is that

the case is fit for expedition but for the defendants to be allowed the requisite twenty‑one days and permission to be

dealt with on papers as soon as possible thereafter so that the parties have some final clarity as to the position.

64. MR JUSTICE SUPPERSTONE: It will proceed in the normal way.


-----

65. MISS LUH: If you do not put "expedition" then oftentimes, even after the expiry, it does not necessarily get put
before a judge on the papers because of inundation of paperwork in the Administrative Court. I just thought it would
be in everyone's interest to have some clarity on this side of Christmas.

66. MR JUSTICE SUPPERSTONE: Mr Metcalfe?

67. MR METCALFE: The deadline is the deadline. We are required to comply with it. Whether or not the papers
are considered over the vacation is beside the point anyway. We are obliged to produce acknowledgement and
summary grounds.

68. MR JUSTICE SUPPERSTONE: I am prepared to say application for permission to be considered on the
papers as soon as possible after filing of acknowledgement of service.

69. MISS LUH: That is all I was asking for.

‑‑‑

**End of Document**


-----

