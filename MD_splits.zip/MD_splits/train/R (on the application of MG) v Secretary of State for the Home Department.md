# R (on the application of MG) v Secretary of State for the Home Department

 [2018] EWHC 31 (Admin)

Queen's Bench Division, Administrative Court (London)

Mulcahy QC (sitting as a Deputy High Court Judge)

23 January 2018Judgment

**Ms Irena Sabic (instructed by Wilsons Solicitors) for the Claimant**

**Mr David Mitchell (instructed by Government Legal Department) for the Defendant**

Hearing dates: 28 November 2017

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Ms Mulcahy QC :**

**_Introduction, Issues and Conclusion_**

1. This claim concerns a judicial review challenge by a Namibian national who entered the UK in 2006,
overstayed her leave, thereafter committed several criminal offences and is subject to deportation.

2. The issues for determination in this case are:

i) Whether the Defendant's refusal to treat the Claimant's various sets of further submissions as fresh
claims within the meaning of paragraph 353 of the Immigration Rules (“paragraph 353”) was unlawful;

ii) Whether the Defendant unlawfully detained the Claimant under the _[Immigration Act 1971 from 11](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
February 2015 until 9 May 2017 when she was released (pursuant to the grant of bail on 4 May 2017 and
the provision of accommodation under section 4 Immigration and Asylum Act 1999).

3. I have concluded that the Defendant's refusal to treat the Claimant's submissions in relation to her
relationship with her daughter as a fresh claim in light of the evidence submitted was irrational and should
be quashed and re-taken. However, I have concluded that the Defendant's refusal of the Claimant's fresh
protection claim was not unlawful. Further, I find that the Defendant has discharged the burden of proving
that the Claimant's detention after 11 February 2015 was lawful.

4. On 28 November 2017, I made an anonymity order, by consent, in order to protect the identity of the
Claimant's child and in light of the fact that she had brought a fresh claim for protection.

5. The relevant factual history is as follows.

**_The Factual Background_**

6. The Claimant, a national of Namibia, arrived in the United Kingdom (“UK”) on 26 February 2006 and
was granted leave to enter as a visitor for 6 months.

7. She then departed from the UK on an unspecified date.


-----

8. On 2 April 2006, the Claimant returned to the UK and was granted leave to enter until 2 October 2006.
She then overstayed.

9. On 7 August 2010, the Claimant was convicted at Highbury Corner Magistrates Court of being drunk
and disorderly and assaulting a constable leading to a community order and unpaid work requirement of 40
hours. She was ordered to pay £50 in compensation and £85 in costs.

10. On 5 January 2011, the Claimant was convicted at Highbury Corner Magistrates Court of destruction
or damage to property. She was sentenced to one day's detention at court.

11. On 21 April 2011, the Claimant submitted an application for Leave to Remain which was rejected as
invalid on 4 July 2011 because the relevant fee had not been paid.

12. On 2 August 2011, the Claimant was convicted at Highbury Corner Magistrates Court of
theft/shoplifting. She received a conditional discharge of 6 months.

13. On 2 December 2011, the Claimant was convicted at Wood Green Crown Court of breach of a
conditional discharge order and arson. She was sentenced to 15 months in custody. She did not appeal
against the conviction or sentence.

14. On 12 January 2012, a liability for deportation letter was issued by the Defendant. The Claimant
responded outlining family circumstances.

15. On 30 July 2012, the Claimant was served with a deportation order.

16. On 3 August 2012, the Claimant lodged an appeal against the deportation order.

17. On 15 January 2013, the Claimant's appeal in the First-tier Tribunal was allowed.

18. On 13 February 2013, the Claimant's deportation order was revoked and discretionary leave was
granted to the Claimant until 3 January 2014. The Claimant again overstayed.

19. On 10 May 2014, the Claimant was arrested for breach of the peace whilst under the influence of
alcohol.

20. On 11 May 2014, the Claimant was served with papers as an overstayer and entered immigration
detention.

21. On 28 May 2014, the Claimant applied for the facilitated return scheme which was subsequently
refused on 1 June 2014 as she had failed to sign the disclaimer.

22. On 14 August 2014, the Defendant served the Claimant with a further deportation letter with an out of
country right of appeal.

23. On 10 September 2014, the Claimant appealed against the deportation decision and made an asylum
claim.

24. On 13 October 2014, the Defendant sent a supplementary decision letter dismissing the asylum and
human rights claims.

25. On 10 February 2015, a Rule 35 assessment was undertaken. The author of the report ticked the box
which stated that the Claimant “may have been the victim of torture” and after recounting the Claimant's
account stated “Has nightmares and flashbacks and has been diagnosed with PTSD [Post-Traumatic
Stress Disorder]. Feels cannot escape this as marks on her body remind her of her past”.

26. On 11 February 2015, the Defendant's response to the Rule 35 report was sent. It was drafted by a
Mr. Turpin who stated that, “The issues in the report were fully considered and addressed in the
_'Supplementary Decision Letter' dated 13 October 2014 after you claimed asylum.” He proceeded to record_
that on 10 September 2014 the Claimant “was interviewed regarding your claim and representations were
_submitted on 10, 11, 17, 18, 23 and 29 September 2014.” He continued, “The basis of your claim was_
_outlined in the 'Supplementary Decision Letter,' notably at paragraph 31.” This was a reference to the_
specific consideration given to the Claimant's claim to be a victim of torture, and the Defendant's rejection


-----

of that claim on 13 October 2014. Mr Turpin further recorded that the decision of 13 October 2014 was
subject to an appeal, and that the outcome of the appeal was pending. Mr Turpin then stated that:

_“The medical practitioner also gave specific mention to you having nightmares and flashbacks and having_
_been diagnosed with PTSD. Also, you feel you cannot escape this as marks on your body remind you of_
_your past. However, the alleged incidents happened in the early 80's, over 20 years ago.”_

27. On 11 February 2015, an “Ad Hoc Detention Review – Rule 35” was carried out in relation to the
Claimant. This stated as follows:

_“This review has been completed in light of a Detention Centre Rule 35 report dated 10 February 2015…_
_The information contained in the report has been fully considered and the decision to detain has been_
_reviewed. Account has been taken of [the Claimant's] claim to have been ill-treated in the early 80's which_
_resulted in the injuries as indicated in the information provided in the Rule 35 report dated 10 February_
_2015. It is noted however that the claim is the same as that considered in [the Claimant's] previous asylum_
_claim. It is the case that her asylum claim has been refused with the First Tier appeal outcome awaited…_
_In light of this, and the fact that [the Claimant] has provided no new evidence to warrant fresh consideration_
_of her asylum claim, it is considered that [the Claimant's] detention should be maintained.” (sic)_

28. On 12 February 2015, the Claimant's appeal was dismissed by the First-tier Tribunal. The
determination, as relevant to the issues herein, stated as follows:

_“26. The Appellant fears persecution if she were to return to Namibia because of her family, the lack of_
_protection she might receive, the fact that she feels bitter and might attack her family and the fact that she_
_cannot internally relocate. In her skeleton argument Ms Pall argues that the Appellant would face a well_
_founded fear of persecution on grounds that she fears destitution on return to Namibia and that she will not_
_receive adequate treatment in light if (sic) her serious medical conditions._

_27. I do accept that the Appellant may have suffered in the past at the hands of her family and neighbours._
_The reports that I have before me confirm that this has had a very damaging effect on her and may have_
_lead (sic) to her alcohol abuse and subsequent behaviour._

_28. I cannot find that the Appellant's fear of her family on return is well founded. As the Appellant has said_
_in interview she is now grown up and they would not be able to hurt her anymore, she says that she will_
_stand up for herself. She is in regular contact with her daughter and grandmother. She has also said that_
_her family will not seek her out._

_29. She may feel very bitter but she has taken steps to control her behaviour as is reflected in the_
_psychiatric report. She has also given up alcohol. There is no reason now why as a mature adult she_
_should fear that she would destroy members of her family._

_30. There are two medical reports. Dr Naguib concludes that in September 2011 the Appellant did not_
_show any evidence of formal mental illness and therefore was not in need of psychiatric treatment or_
_further assessment in hospital. Dr Stamps' report also found that she did not display symptoms consistent_
_with a diagnosis of post traumatic stress disorder but to have enduring personality change after a_
_catastrophic experience and should be referred for counselling._

_…_

_33. She is a grown-up woman who can live independently and make her own way in Namibia…._

_…_

_37. The appellant showed me a few cards and photos and messages that she has sent her daughter in the_
_UK. However, it is that (sic) difficult to see how much contact they have had since she was born in 2009._
_The relationship was turbulent with her daughter's father and the appellant left permanently in 2010 when_
_she was drinking heavily. I have not been given any further details of her relationship with her daughter.”_

_38. In the circumstances I cannot be persuaded that the Appellant has a genuine and subsisting_
_relationship with her daughter it is in the child's interest to remain with her father (sic). The Appellant can_


-----

_have contact with her daughter and this could be maintained from Namibia by modern technology and_
_visits. Even if she does have a genuine relationship with her daughter it is not of the depth to outweigh the_
_public interest in deportation and would not be unduly harsh._

_39. She has one daughter in Namibia with whom she could be reunited. Therefore I cannot find that there_
_would be breaches of Article 8 were she to be removed.”_

29. On 19 June 2015, the Claimant was refused bail.

30. On 24 June 2015, the Claimant made further representations which were refused on 9 July 2015.

31. On 3 August 2015, the Claimant was refused permission to appeal to the Upper Tribunal. She was
then appeal rights exhausted.

32. On 26 August 2015, the Claimant was again refused bail.

33. On 16 September 2015, the Claimant made further representations which were refused on 5 October
2015.

34. On 26 October 2015, the Claimant made a trafficking claim.

35. On 12 November 2015, the Claimant submitted representations under paragraph 353 relating to the
risk of re-trafficking in Namibia and enclosed two medical reports, one from Professor Katona dated 2
November 2015 and the other from Dr Arnold dated 8 November 2015.

36. On 3 December 2015, the Claimant was again refused bail.

37. On 11 December 2015, the Claimant's trafficking claim was rejected by the Competent Authority. That
negative reasonable grounds decision expressly considered the report of Professor Katona.

38. On 16 December 2015, the Claimant was again refused bail.

39. On 3 March 2016, the Defendant refused the further submissions dated 12 November 2015 under
paragraph 353, stating, as relevant:

_“Your client's claim to be a victim of modern slavery_

_On 11 December 2015, a decision was made to make a negative decision, in regards to your client's claim_
_to be a victim of modern slavery._

_In support of your client's claim, you provided a psychiatric report, from Dr Cornelius Katona, dated 2_
_November 2015. This report summarises an assessment, conducted by Mr Katona at Yarl's Wood_
_Immigration Removal Centre (IRC), on 22 October 2015. In this report, Dr Katona concludes that your_
_client suffers from Post Traumatic Stress Disorder (PTSD) and Borderline Personality Disorder (BPD)._
_However, it is noted that you refused, on two occasions, to provide the un-redacted notes from the_
_assessment; a satisfactory explanation for these refusals has not been forthcoming._

_As your client has failed to provide any new or compelling evidence, there are no reasons to suggest that_
_we should depart from the findings in our letter of 11 December 2015._

_Your client's mental and physical health needs_

_…._

_Your client's medical records, which covers the period January 2015 to 5 February 2016, supplied by_
_Healthcare at Yarl's Wood IRC, shows that, at present, your client is not prescribed any anti-depressants._
_However, it is noted that your client regularly attends well-being sessions within the IRC. It is also noted_
_that on 3 December 2015, your client attended an appointment within Healthcare, where a mental health_
_care review was conducted. Your client's medical records state that they were unclear why your client had_
_been referred to the Mental Health team. The conclusion from this review was that your client should_
_continue to attend well-being sessions._

_These medical records further show that your client has attended four psychological well being_
_assessments on 24 December 2015 30 December 2015 13 January 2016 and 25 January 2016 On each_


-----

_occasion, the conclusion was that your client should continue attending well-being sessions. Your client's_
_mental and physical health is regularly monitored, and treatment is provided when deemed necessary._

_…_

_Whilst your client has provided a psychological report, which claims that she has PTSD and BPD, her_
_medical records indicate that she is not currently receiving any treatment for these conditions. As such, any_
_claim that she will require treatment in the future is purely speculative; therefore, the Tribunal findings_
_remain relevant._

_It the absence of evidence to the contrary, there are no reasons to suggest that we should depart from our_
_previous findings.”_

40. On 7 and 8 March 2016, the Claimant submitted further representations under paragraph 353.

41. On 10 March 2016, the Defendant refused those representations stating:

_“Your claims regarding your mental health were fully considered in our letters of 13 October 2014, 5_
_October 2015 and 3 March 2016, and by the Tribunal on 13 February 2015._

_You claim to suffer from Post Traumatic Stress Disorder (PTSD) and Borderline Personality Disorder_
_(BPD), and have provided a medical report from Dr Katona (sic), dated 2 November 2015, which supports_
_this claim. However, as detailed in our letter of 3 March 2016, you are not currently receiving any treatment_
_for either condition, despite your attendance at regular psychological well-being sessions, within_
_Healthcare at Yarl's Wood IRC. As such, any suggestion that you will require treatment in the future is_
_purely speculative._

_Nevertheless, should you require it, as detailed in our letter of 13 October 2014, psychological treatment is_
_available in Namibia._

_You have provided no new, or compelling information, which would suggest that we should depart from_
_our, or the Tribunal's, findings.”_

42. On 24 March 2016 and 29 March 2016, the Claimant submitted further representations under
paragraph 353.

43. On 31 March 2016, the Defendant set removal directions for the Claimant's removal from the UK (for
21 April 2016).

44. On 4 and 6 April 2016, the Claimant made further representations under paragraph 353.

45. On 6 April 2016, the Defendant refused the Claimant's further representations dated 24 and 29 March
2016 in which it was claimed that the Claimant had an ongoing and subsisting relationship with her
daughter and that removing her to Namibia would breach her rights under Article 8 European Convention
on Human Rights (“ECHR”) and contending that consideration should be given to that relationship under
section 55 of the Border, Citizenship and Immigration Act 2009. The letter stated, in relevant part, that:

_“You have submitted a plethora of documents which you claim is evidence of your client's relationship with_
_her daughter, including evidence that your client has received visits from her daughter whilst in detention,_
_and cards and letters, to and from your client and [the Claimant's daughter] and her former partner…._

_Whilst it is accepted that the evidence provided does indicate that your client does have some form of_
_relationship with her daughter; your client has been absent for almost all of her daughter's life and as such,_
_any relationship they do have will be extremely limited in nature._

_Nevertheless, as stated by the Immigration Judge in your client's appeal against deportation: “Even if she_
_does have a genuine relationship with her daughter it is not of the depth to outweigh the public interest in_
_deportation and would not be unduly harsh”._

_Your client has provided nothing which would suggest we should depart from the Tribunal's findings._

_The best interests of your client's daughter_


-----

_The best interests of your client's daughter...were fully considered in our letter of 13 October 2014, in which_
_it was found that the best interests of the child were served by her remaining in the United Kingdom with_
_her father, who has cared for her since her birth. Further to this, in your client's appeal against deportation,_
_the Immigration Judge found: “…it is in the child's interests to remain with her father. The Appellant can_
_have contact with her daughter and this could be maintained from Namibia by modern technology and_
_visits.”_

_[Safeguarding and promoting the welfare of children is defined in the guidance to section 11 of the Children](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y0C0-00000-00&context=1519360)_
_Act 2004 as:_

_“protecting children from maltreatment;_

- _preventing impairment of children's health or development (where health means 'physical or mental_
_health' and development means 'physical, intellectual, emotional, social or behavioural development');_

- ensuring that children are growing up in circumstances consistent with the provision of safe and effective
_care;_

- _and undertaking that role so as to enable those children to have optimum life chances and to enter_
_adulthood successfully.”_

_There is no evidence before us to conclude that your client's presence is needed to prevent [the Claimant's_
_daughter] from being ill treated, her health or development being impaired, or her care being other than_
_safe and effective._

_There is no suggestion that [the Claimant's daughter] relies on your client, either emotionally, or financially._
_There is no evidence which would indicate that your client has provided financially towards the care of [the_
_Claimant's daughter], either currently, or in the past._

_It is acknowledged that your client's absence will likely result in some negative emotional impact on [the_
_Claimant's daughter], but she will continue to live with her father, who will support her as she adapts to life_
_without face-to-face contact with her mother. [She] will continue to attend school where she will have the_
_stability and support which is necessary to complete her education._

_As detailed above, the Immigration Judge at appeal found that there is no evidence that your client's_
_deportation would result in your client losing all contact with [her daughter]. It is noted that your client's_
_eldest daughter,…, remains in Namibia, in the care of her maternal Great Grandmother, and by your own_
_admission, your client has maintained contact with [the Claimant's elder daughter], since her arrival in the_
_United Kingdom._

_It is acknowledged that indirect contact is not the same as remaining in the family home, or even living_
_separately, but in the same country, however, it is considered that your client could maintain contact with_

_[her daughter], if she wishes. Further to this, there is no evidence that [she] would be unable to visit your_
_client in Namibia. Consequently, it is not accepted that there are factors in your client's case that would be_
_considered very compelling if [the Claimant's daughter] remains in the United Kingdom without her._

_In the case of your client and her daughter, it is not considered that there are insurmountable obstacles to_
_family life with them being able to continue outside of the United Kingdom, nor has your client provided any_
_evidence which would demonstrate that there are compelling circumstances which will effect (sic) [the_
_Claimant's daughter], if she remained in the United Kingdom. [She] is a British citizen and can continue to_
_enjoy all the benefits afforded to her as such, upon your client's return to Namibia._

_Whilst our decision to deport your client does not prescribe any outcome, or requirement for [the Claimant's_
_former partner and daughter], this decision means that your client and [the Claimant's former partner] are_
_required to make a decision as to whether he and [the Claimant's daughter] should accompany your client_
_to Namibia, or remain in the United Kingdom._

_In the absence of any evidence to the contrary, there are no reasons which would suggest we should_
_depart from ours or the Tribunal's findings. ”_


-----

46. On 12 April 2016, the Claimant sent a Pre-Action Protocol letter of claim.

47. On 18 April 2016, the Defendant rejected the further submissions dated 4 and 6 April 2016 and
responded to the Pre-Action Protocol letter, stating (inter alia) that:

_“You and your client have submitted a number of documents to support your claim that your client has_
_maintained contact with her daughter….during her imprisonment and detention. However, whilst it is_
_accepted that the evidence provided does indicate that your client does have some form of relationship_
_with her daughter; your client has been absent for almost all of her daughter's life, and as such, any_
_relationship they do have will be limited in nature._

_It is noted that in the Witness Statement of [the Claimant's former partner], dated 11 April 2016, it states: “I_
_have now visited M with [the Claimant's daughter] at Yarlswood IRC between 4 – 5 times. The most recent_
_visit was on 5 April 2016. We spend 3 hours at Yarlswood IRC, between 2 pm and 5 pm and [the_
_Claimant's daughter] is very happy playing with her mother and they complete homework together and_
_enjoy a good family life.”_

_It is noted that as your client has been detained since 11 May 2014, a period of almost two years, it would_
_appear that direct contact with [her daughter] was extremely sporadic. As such, any relationship your client_
_had with [her daughter] is assumed to have been maintained via in-direct methods of communications._
_This is at odds with your claim that your client would be unable to maintain contact with [her daughter],_
_using these same methods of contact, upon her return to Namibia._

_Nevertheless, as stated by the Immigration Judge in your client's appeal against deportation: “Even if she_
_does have a genuine relationship with her daughter it is not of the depth to outweigh the public interest in_
_deportation and would not be unduly harsh” ._

_Your client has provided nothing which would suggest that we should depart from the Tribunal's findings._

_Whilst it is accepted that you have provided a number of document's (sic) which have not previously been_
_submitted, it is not accepted that this evidence significantly differs from that previously considered by the_
_Secretary of State and the Tribunal; as such there are no reasons apparent which would suggest that we_
_should depart from our, or the Tribunal's findings, in respect to your client's claims to family life in the_
_United Kingdom._

_…._

_Note is also taken of the letter written by [the Claimant's daughter], in which she expresses that she misses_
_her mother, and her wishes for her mother to be released from Yarl's Wood Immigration Removal Centre._

_Whilst it is accepted that your client's deportation will have a negative emotional effect on [her daughter],_
_any impact is a direct result of your client's actions._

_Your client has been convicted of a very serious offence, one which fully engages the public interest in_
_securing her removal, and none of the claims made constitute very compelling circumstances sufficient to_
_outweigh that interest._

_It is noted that you have provided evidence of your client's contact with [her daughter] during her detention;_
_however, this evidence does not suggest that the nature of her relationship with [her daughter], has_
_strengthened, or differs significantly from that which was considered by the Tribunal, which found that_
_claims to family life with a child did not outweigh the public interest in securing your client's deportation.._

_Your client has not lived as part of family unit with [her daughter] since November 2010, and since this_
_date, she has spent 3 years and 3 months, either serving her custodial sentence, or detained. It is_
_accepted that prior to her imprisonment, and between periods of detention, your client utilised her visitation_
_rights, as directed by the Court Order; however, by [the Claimant's former partner's] own admission, your_
_client has only seen [her daughter] four or five times in the past two years._

_There is no evidence which would suggest that [her daughter] relies on your client to meet her day to day_
_care, particularly given your client's absence in her life, due to imprisonment and subsequent detention._


-----

_There is no evidence which would suggest that your client provides any unique or essential care for [her_
_daughter] that she would not be able to receive from an alternative source._

_Your client has provided nothing which would suggest that she provides for [her daughter] financially, or_
_that she provides any unique, or essential care her. It is noted that due to your client's own actions, she_
_has been removed from enjoying a relationship with her daughter, for a significant period of time._

_As per the case of Devaseelan, your client has not provided any new, or compelling evidence, which would_
_suggest that we should depart from the Tribunal's settled findings._

_…._

_You claim that our decision to deport your client the Secretary of State has failed to take into account [the_
_Claimant's daughter's] rights under Article 24 of the EU Charter of Fundamental Rights._

_…_

_As detailed above, the best interests of your client's daughter,…., have been fully considered, and it has_
_been concluded that her best interests are served by remaining in the United Kingdom with her father._

_As detailed above, the Tribunal found: “Even if she does have a genuine relationship with her daughter it is_
_not of the depth to outweigh the public interest in deportation and would not be unduly harsh._

_Your client's deportation, in accordance with primary legislation, remains in the public interest and no_
_information has been provided which would suggest that we should depart from the Tribunal's settled_
_findings._

_…_

_It has been concluded that your client's submissions do not meet the requirements of paragraph 353 of the_
_Immigration Rules and do not amount to a fresh claim. This is because these submissions are not_
_significantly different from the evidence that has previously been considered.”_

48. On 20 April 2016, the Claimant issued judicial review proceedings and the following day, the
Defendant cancelled the Claimant's removal directions in light of this.

49. On 16 May 2016, the Defendant filed her Acknowledgement of Service and Summary Grounds of
Defence.

50. On 8 June 2016, permission for judicial review was refused by Upper Tribunal Judge Rimington.

51. On 15 September 2016, the Claimant amended her claim for judicial review.

52. On 21 October 2016, Upper Tribunal Judge Kopieczek transferred the claim for judicial review to the
High Court because the claim included a challenge to the lawfulness of detention.

53. On 30 November 2016, Mr John Howell QC, sitting as a Deputy High Court Judge struck out Claim
CO/5045/2016 and in relation to the instant claim (CO/5573/2016), ordered that the Claimant's application
for permission to amend the grounds of claim in the current claim be listed at the same time as the oral
renewal of permission.

54. By way of an Amended Statement of Facts and Grounds dated 19 December 2016, the Claimant
challenged the following:

i) The refusal to treat the Claimant's representations as a fresh claim under paragraph 353 of the
Immigration Rules by way of decisions dated 3 March 2016, 10 March 2016, 6 April 2016 and 18 April
2016;

ii) The Claimant's detention from 11 February 2015 onwards.

55. On 10 February 2016, the Defendant filed Amended Summary Grounds of Defence.

56. On 13 April 2017, the Claimant applied for interim relief.

57 On 4 May 2017 the Claimant was granted bail


-----

58. The Claimant was released from detention on 9 May 2017, following the provision of accommodation
within section 4 Immigration and Asylum Act 1999.

59. On 17 May 2017, Mr Peter Marquand, sitting as a Deputy High Court Judge, granted the Claimant's
application for permission on Ground 1 (fresh claim) and Ground 2 (unlawful detention) as set out in the
Amended Statement of Facts and Grounds. It is these issues which have come before me for a substantive
hearing.

**_Issues for determination_**

60. The issues which arise for determination on the fresh claim ground are as follows:

i) Is the Defendant's decision to refuse to treat the Claimant's further representations concerning her family
life in the UK, most notably with her daughter, lawful?

ii) Is the Defendant's decision to refuse to treat the Claimant's further representations concerning her claim
for international protection lawful?

61. The issues which arise for determination on the unlawful detention ground are as follows:

i) Was the Defendant's response to the Rule 35 report dated 10 February 2015 lawful?

ii) Did the Defendant assess the Claimant's continued detention following the receipt of Professor Katona's
report on 12 November 2015 against the correct policy?

iii) Was the Defendant's detention during the relevant period (11 February 2015 to 9 May 2017) otherwise
lawful?

62. I will set out the relevant legal and policy framework and then turn to address each issue.

**_The legal and policy framework_**

**_Fresh Claim test (paragraph 353)_**

63. Following the withdrawal by the Claimant of a paragraph in her skeleton argument (paragraph 9.3)
which was contentious as between the parties, there appeared ultimately to be little, if any, dispute
between the parties in relation to the test the Court should apply as to whether the Defendant's decisions in
relation to whether the Claimants' further submissions amounted to fresh claims are lawful.

64. Paragraph 353 of the Immigration Rules provides the following:

_“Fresh Claims_

_When a human rights or asylum claim has been refused or withdrawn or treated as withdrawn under_
_paragraph 333C of these Rules and any appeal relating to that claim is no longer pending, the decision_
_maker will consider any further submissions and, if rejected, will then determine whether they amount to a_
_fresh claim. The submissions will amount to a fresh claim if they are significantly different from the material_
_that has previously been considered. The submissions will only be significantly different if the content:_

_(i)              had not already been considered; and_

_(ii)               taken together with the previously considered material, created a realistic prospect of_
_success, notwithstanding its rejection.”_

65. Whether further submissions constitute a fresh claim on asylum or human rights grounds is a matter
for the Defendant. A decision as to whether a fresh claim arises can only be reviewed on _Wednesbury_
unreasonableness grounds (R v Secretary of State for the Home Department, ex parte Onibiyo [1996]
QB 768, 785D).

66. In **_R (on the application of WM (DRC)) v. Secretary of State for the Home Department_** _[2006]_
_EWCA Civ 1495 the Court of Appeal considered the task of the Defendant when considering further_
submissions and the role of the Court when reviewing such a decision. The question for the Defendant is
whether there is a realistic prospect of success in an application before an Immigration Judge


-----

67. In **_AK (Afghanistan) v Secretary of State for the Home Department_** _[[2007] EWCA Civ 535 the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFV1-DYBP-P30S-00000-00&context=1519360)_
Court of Appeal confirmed that the question which the Defendant must ask herself is “whether an
_independent tribunal might realistically come down in favour of the applicant's asylum or human rights_
_claim, on considering the new material together with the material previously considered” per Toulson LJ at_

[23]. As explained by Buxton LJ, in **_WM, in answering that question the Defendant must be informed by_**
anxious scrutiny of the material.

68. In relation to the task of the Court, Buxton LJ confirmed that the decision remains that of the
Defendant and her determination is only capable of being impugned on Wednesbury grounds (irrationality).
He stated at paragraph [11] that when reviewing a decision by the Defendant, the Court will ask two
questions:

i) First, has the Defendant asked herself the correct question? In the context of a human rights case, the
correct question is whether there is a realistic prospect of an Immigration Judge, applying anxious scrutiny,
concluding that there will be a breach of a Claimant's human rights on his or her return home.

ii) Second, in addressing that question, has the Defendant satisfied the requirement of anxious scrutiny?

69. That the approach in **_WM_** applies in paragraph 353 cases was confirmed in **_R (TK) v Secretary of_**
**_State for the Home Department_** _[[2010] EWCA Civ 1550 and MN (Tanzania) v Secretary of State for the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XXS-X9W0-YBF6-70SD-00000-00&context=1519360)_
**_Home Department_** _[2011] EWCA Civ 193._

70. The approach that the Immigration Tribunal is required to take to further evidence where there is a
previous determination by the Tribunal is set out in Devaseelan [2002] UKIAT 000702 at paragraphs [3941]

_“39. In our view the second Adjudicator should treat matters in the following way._

_(1) The first Adjudicator's determination should always be the starting-point. It is the authoritative_
_assessment of the appellant's status at the time was made. In principle issues such as whether the_
_appellant was properly represented or whether he gave evidence, are irrelevant to this._

_(2) Facts happening since the first Adjudicator's determination can always be taken into account by the_
_second Adjudicator. If those facts lead the second Adjudicator to the conclusion that, at the date of his_
_determination and on the material before him, the appellant makes his case, so be it. The previous_
_decision, on the material before the first Adjudicator and at that date, is not inconsistent._

_(3) Facts happening before the first Adjudicator's determination but having no relevance to the issues_
_before him can always be taken into account by the second Adjudicator. The first Adjudicator will not have_
_been concerned with such facts, and his determination is not an assessment of them._

_40. We now pass to matters that could have been before the first Adjudicator but were not._

_(4) Facts personal to the appellant that were not brought to the attention of the first Adjudicator, although_
_they were relevant to the issues before him, should be treated by the second Adjudicator with the greatest_
_circumspection. An appellant who seeks, in a later appeal, to add to the available facts in an effort to obtain_
_a more favourable outcome is properly regarded with suspicion from the point of view of credibility._
_(Although considerations of credibility will not be relevant in cases where the existence of the additional_
_fact is beyond dispute). It must also be borne in mind that the first Adjudicator's determination was made at_
_a time close to the events alleged and in terms of both fact-finding and general credibility assessment_
_would tend to have the advantage. For this reason, the addition of such facts should not usually lead to any_
_reconsideration of the conclusions reached by the first Adjudicator._

_(5) Evidence of other facts – for example country evidence may not suffer from the same concerns as to_
_credibility, but should be treated with caution. The reason is different from that in (4). Evidence dating from_
_before the determination of the first Adjudicator might well have been relevant if it had been tendered to_
_him: but it was not, and he made his determination without it. The situation in the appellant's own country at_
_the time of that determination is very unlikely to be relevant in deciding whether the appellant's removal at_
_the time of the second Adjudicator's determination would breach his human rights. Those representing the_


-----

_appellant would be better advised to assemble up-to-date evidence than to rely on material that is (ex_
_hypothesi) now rather dated._

_41. The final major category of case is where the appellant claims that his removal would breach Article 3_
_for the same reason that he claimed to be a refugee._

_(6) If before the second Adjudicator the appellant relies on facts that are not materially different from those_
_put to the first Adjudicator, and proposes to support the claim is in essence the same evidence as that_
_available to the appellant at that time, the second Adjudicator should regard the issues as settled by the_
_first Adjudicator's determination and make his findings in line with that determination rather than allowing_
_the matter to be re-litigated. We draw attention to the phrase 'the same evidence as that available to the_
_appellant at the time of the first determination'. We have chosen this phrase not only in order to_
_accommodate guidelines (4) and (5) above, but also because, in respect of evidence that was available to_
_the appellant, he must be taken to have made his choices about how it would be presented. An appellant_
_cannot be expected to present evidence of which he has no knowledge: but if (for example) he chooses not_
_to give oral evidence in his first appeal, that does not mean that the issues or the available evidence in the_
_second appeal are rendered any different by his proposal to give oral evidence (of the same facts) on this_
_occasion."_

**_Article 8 ECHR - general_**

71. Article 8 ECHR provides a right to respect by public authorities for private and family life, home and
correspondence. It is a qualified right and must be balanced against the legitimate aims of protecting
national security, public safety and the economic well-being of the UK; the prevention of disorder and
crime; the protection of health or morals; and the protection of the rights and freedoms of others.

72. On 13 June 2012 the Secretary of State for the Home Department laid before Parliament a Statement
of Changes in Immigration Rules (HC 194), the relevant paragraphs of which came into force on 9 July
2012 (“the family and private life Rules”).

73. Section GEN.1.1 of Appendix FM provides the following summary of the objective of the family and
private life Rules:

**_“Purpose_** _GEN.1.1. This route is for those seeking to enter or remain in the_
_UK on the basis of their family life with a person who is a British Citizen, is settled in the UK, or is in the UK_
_with limited leave as a refugee or person granted humanitarian protection (and the applicant cannot seek_
_leave to enter or remain in the UK as their family member under Part 11 of these rules). It sets out the_
_requirements to be met and, in considering applications under this route, it reflects how, under Article 8 of_
_the Human Rights Convention, the balance will be struck between the right to respect for private and family_
_life and the legitimate aims of protecting national security, public safety and the economic well-being of the_
_UK; the prevention of disorder and crime; the protection of health or morals; and the protection of the rights_
_and freedoms of others. It also takes into account the need to safeguard and promote the welfare of_
_children in the UK.”_

74. The Courts have considered whether a two-stage approach is required in considering applications
made under the Immigration Rules – i.e. an assessment of an application against the relevant Immigration
Rules followed by an assessment against the relevant Article 8 jurisprudence. In **_MF (Nigeria)_** _[2013]_
_EWCA Civ 1192, the Court of Appeal held at [46]:_

_“There has been debate as to whether there is a one stage or two stage test. If the claimant succeeds on_
_an application of the new rules at the first hurdle i.e. he shows that para 399 or 399A applies, then it can be_
_said that he has succeeded on a one stage test. But if he does not, it is necessary to consider whether_
_there are circumstances which are sufficiently compelling (and therefore exceptional) to outweigh the_
_public interest in deportation. That is an exercise which is separate from a consideration of whether para_
_399 or 399A applies. It is the second part of a two stage approach which, for the reasons we have given, is_
_required by the new rules.”_


-----

75. Article 8 is not an absolute right. When considering the impact of removal the Defendant must balance
the individual's rights to a private and family life in the United Kingdom, against the maintenance of
effective immigration control. In **_Singh v Entry Clearance Officer New Delhi_** _[2004] EWCA Civ 1075,_
Dyson LJ stated at [20]:

_“[t]he existence or non-existence of family life for the purposes of Article 8 is essentially a question of fact_
_depending on the real existence in practice of close personal ties.”_

76. If the existence of an Article 8 right is established, the case-law states that contracting states are
permitted to interfere with the enjoyment of that right provided that certain conditions are satisfied. Any
assessment of an Article 8 claim must therefore be viewed in light of the United Kingdom's right to control
the entry of foreign nationals into its territory and the necessity of fair and consistent immigration control.

77. The need for firm, fair and consistent immigration control has been recognised by the Courts (for
example, in **_Huang v Secretary of State for the Home Department_** _[2007] UKHL 11 at [16] and_ **_EB_**
**_(Kosovo) v Secretary of State for the Home Department_** _[2008] UKHL 41 at [32]). States enjoy a wide_
margin of appreciation in determining the steps to be taken to ensure compliance with the Convention with
due regard to the needs and resources of the community and of individuals (for instance, AM (Somalia) v
**_Entry Clearance Officer_** _[2009] EWCA Civ 634 at [58-61])._

78. Decisions taken pursuant to the lawful operation of immigration control will be proportionate in all but a
small minority of cases, identifiable only on a case-by-case basis (R (Razgar) v Secretary of State for the
**_Home Department_** _[2004] UKHL 27 at [20])._

79. As to the question of the proportionality of removal, the House of Lords has stated in **_Huang v_**
**_Secretary of State for the Home Department_** _[2007] UKHL 11, that even among Claimants who have_
established a family or private right, those entitled to succeed under Article 8 because the proposed
interference was disproportionate to the end to be achieved, would be “a very small minority” (at [20]).

80. In VW (Uganda) and AB (Somalia) v Secretary of State for the Home Department _[2009] EWCA_
_Civ 5, Sedley LJ observed that in order for a measure to be disproportionate, the consequences for the_
individual need to be more than mere hardship or a mere difficulty or mere obstacle. There is a
seriousness test which requires the obstacles or difficulties to go beyond matters of choice or
inconvenience.

81. The question of how much weight should be given to the different factors in a given case will vary
according to the specific circumstances. In Maslov v Austria [2008] ECHR 546 the Strasbourg Court said
(at [70]):

_“The court would stress that while the criteria which emerge from its case-law and are spelled out in the_
_Boultif and Üner judgments are meant to facilitate the application of Art 8 in expulsion cases by domestic_
_courts, the weight to be attached to the respective criteria will inevitably vary according to the specific_
_circumstances of each case.”_

**_Article 8 and the public interest in the deportation of foreign criminals_**

82. As provided in the Immigration Rules:

_“A362. Where Article 8 is raised in the context of deportation under Part 13 of these Rules, the claim under_
_Article 8 will only succeed where the requirements of these rules as at 28 July 2014 are met, regardless of_
_when the notice of intention to deport or the deportation order, as appropriate, was served._

_A398. These rules apply where:_

_(a)              a foreign criminal liable to deportation claims that his deportation would be contrary to_
_the United Kingdom's obligations under Article 8 of the Human Rights Convention;_

_(b)              a foreign criminal applies for a deportation order made against him to be revoked._

_398. Where a person claims that their deportation would be contrary to the UK's obligations under Article 8_
_of the Human Rights Convention and:_


-----

_…_

_(b)              the deportation of the person from the UK is conducive to the public good and in the_
_public interest because they have been convicted of an offence for which they have been sentenced to a_
_period of imprisonment of less than 4 years but at least 12 months;_

_…_

_the Secretary of State in assessing that claim will consider whether paragraph 399 or 399A applies and, if it_
_does not, the public interest in deportation will only be outweighed by other factors where there are very_
_compelling circumstances over and above those described in paragraphs 399 and 399A._

_399. This paragraph applies where paragraph 398 (b) or (c) applies if –_

_(a)              the person has a genuine and subsisting parental relationship with a child under the_
_age of 18 years who is in the UK, and_

_(i)                the child is a British Citizen; or_

_(ii)                the child has lived in the UK continuously for at least the 7 years immediately_
_preceding the date of the immigration decision;_

_and in either case_

_(a)              it would be unduly harsh for the child to live in the country to which the person is to be_
_deported; and_

_(b)              it would be unduly harsh for the child to remain in the UK without the person who is to_
_be deported;_

_…_

_399A. This paragraph applies where paragraph 398(b) or (c) applies if –_

_(a)              the person has been lawfully resident in the UK for most of his life; and_

_(b)              he is socially and culturally integrated in the UK; and_

_(c)              there would be very significant obstacles to his integration into the country to which it is_
_proposed he is deported.”_

83. Sections 117A to 117D of the Nationality, Immigration and Asylum Act 2002, entitled “Article 8 of the
_ECHR: Public Interest Considerations” gives statutory expression to the above provisions._

84. As set out at section 117C (Article 8: additional considerations in cases involving foreign criminals):

_“(1)            The deportation of foreign criminals is in the public interest._

_(2)            The more serious the offence committed by a foreign criminal, the greater is the public_
_interest in deportation of the criminal._

_(3)            In the case of a foreign criminal (“C”) who has not been sentenced to a period of_
_imprisonment of four years or more, the public interest requires C's deportation unless Exception 1 or_
_Exception 2 applies._

_(4)            Exception 1 applies where—_

_(a)                C has been lawfully resident in the United Kingdom for most of C's life,_

_(b)                C is socially and culturally integrated in the United Kingdom, and_

_(c)                there would be very significant obstacles to C's integration into the country to which_
_C is proposed to be deported._


-----

_(5)            Exception 2 applies where C has a genuine and subsisting relationship with a qualifying_
_partner, or a genuine and subsisting parental relationship with a qualifying child, and the effect of C's_
_deportation on the partner or child would be unduly harsh._

_(6)            In the case of a foreign criminal who has been sentenced to a period of imprisonment of_
_at least four years, the public interest requires deportation unless there are very compelling circumstances,_
_over and above those described in Exceptions 1 and 2._

_(7)            The considerations in subsections (1) to (6) are to be taken into account where a court or_
_tribunal is considering a decision to deport a foreign criminal only to the extent that the reason for the_
_decision was the offence or offences for which the criminal has been convicted.”_

85. In respect of the public interest in the deportation of foreign criminals, as explained by Jackson LJ in
**_NA (Pakistan) v Secretary of State for the Home Department_** _[2016] EWCA Civ 662, by reference to_
s.32(4) UK Borders Act 2007, _“That is a statement of public policy enacted by the legislature, which the_
_courts are obliged to respect.” (at paragraph [11]). Jackson LJ expressly approved the judgment of Laws_
LJ in SS (Nigeria) v Secretary of State for the Home Department [2013] EWCA Civ 550:

_“The importance of the moral and political character of the policy shows that the two drivers of the decision-_
_maker's margin of discretion – the policy's nature and its source – operate in tandem. An Act of Parliament_
_is anyway to be specially respected; but all the more so when it declares policy of this kind.”_

86. He continued at paragraph [22]:

_“Section 117C(1) of the 2002 Act, as inserted by the 2014 Act, re-states that the deportation of foreign_
_criminals is in the public interest. The observations of Laws LJ in SS (Nigeria) concerning the significance_
_of the 2007 Act, as a particularly strong statement of public policy, are equally applicable to the new_
_provisions inserted into the 2002 Act by the 2014 Act. Both the courts and the tribunals are obliged to_
_respect the high level of importance which the legislature attaches to the deportation of foreign criminals.”_

and at [26]:

_“it is important to bear in mind that the new Part 5A of the 2002 Act is framed in such a way as to provide a_
_structured basis for application of and compliance with Article 8.”_

**_Article 8 and the best interests of a child_**

87. In relation to the issue of the assessment that the Article 8 European Convention on Human Rights
(“ECHR”) was bound to fail before a putative First-tier Tribunal, the Claimant relies on **_Zoumbas v_**
**_Secretary of State for the Home Department_** _[2013] UKSC 74; [2013] 1 WLR 3690in which the Supreme_
Court set down the following principles (at paragraph [10]):

_“(1)            The best interests of a child are an integral part of the proportionality assessment under_
_Article 8 ECHR._

_(2)            In making that assessment, the best interests of a child must be a primary consideration,_
_although not always the only primary consideration; and the child's best interests do not of themselves_
_have the status of the paramount consideration._

_(3)            Although the best interests of a child can be outweighed by the cumulative effect of other_
_considerations, no other consideration can be treated as inherently more significant._

_(4)            While different judges might approach the question of the best interests of a child in_
_different ways, it is important to ask oneself the right questions in an orderly manner in order to avoid the_
_risk that the best interests of a child might be undervalued when other important considerations are in play._

_(5)            It is important to have a clear idea of a child's circumstances and of what is in a child's_
_best interests before one asks oneself whether those interests are outweighed by the force of other_
_considerations._


-----

_(6)            To that end there is no substitute for a careful examination of all relevant factors when the_
_interests of a child are involved in an Article 8 assessment._

_(7)            A child must not be blamed for matters for which he or she is not responsible, such as the_
_conduct of a parent.”_

88. However, as the Defendant points out, the decision under consideration in **_Zoumbas_** and the
judgment itself both preceded 28 July 2014, on which date the immigration rules were revised (HC 532)
and Part 5A (sections 117A to 117D) of the _[Nationality, Immigration and Asylum Act 2002 were brought](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)_
into force. Both of these provisions emphasised within the context of the Article 8 proportionality exercise,
the particular public interest in the deportation of foreign criminals such as the Claimant (paragraphs 398
and 399 / section 117C).

89. However, the Defendant also relies on Zoumbas in that it was confirmed at paragraph [19] that:

_“the status of the well-being of the children as a primary consideration did not require the Secretary of_
_State in every case to consider the children's best interests first and then to address other considerations_
_which might outweigh those interests. There is nothing to bar the official who acts for the Secretary of State_
_from considering the various issues, including the proportionality exercise under article 8 ECHR before_
_drafting the decision letter. The official set out the Secretary of State's conclusion before explaining the_
_reasons for that conclusion. It is important to read the decision letter as a whole and to analyse the_
_substance of the decision.”_

90. Further, it was held in that case that the fact that the decision letter set out the Secretary of State's
conclusions briefly did not give rise in that case to any inference that there had not been careful
consideration (paragraph [22]) and the Secretary of State was not obliged to record and deal with every
piece of evidence in her decision letter (paragraph [23]).

91. The assessment of the child's best interest must focus on the child, while simultaneously evaluating
the reality of the child's life situation and circumstances. The child's best interests have a freestanding
character: **_Kaur (children's best interest/public interest interface)_** _[[2017] UKUT 00014 (IAC) at [18],](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MN2-FB41-F0JY-C0PG-00000-00&context=1519360)_
although it is right to note that this case did not involve the application of the immigration rules or Part 5A of
the 2002 Act regarding foreign criminals.

92. The Claimant relies on the decision of the Upper Tribunal in **_Abdul (section 55 – Article 24(3)_**
**_Charter)_** _[[2016] UKUT 00106which determined that Article 24 of the EU Charter of Fundamental Rights](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J5G-BXT1-F0JY-C0V2-00000-00&context=1519360)_
creates a free standing right. Article 24(3) mandates that every child shall have the right to maintain on a
regular basis a personal relationship and direct contact with both her parents, unless that is contrary to his
or her interests. The Claimant places reliance on Article 24(3) as part of considering the best interests of
the child. The Defendant questions the relevance of the **_Abdul decision given that the Immigration_**
(European Economic Area) Regulations 2006 are not in issue in this case.

93. Section 55 of the Borders Citizenship and Immigration Act 2009 obliges the Defendant to devise
systems and structures for the purpose of safeguarding and promoting the welfare of children who are in
the UK. What is required of the Secretary of State by section 55 of the 2009 Act was considered by the
Upper Tribunal in JO and Others (section 55 duty) Nigeria _[[2014] UKUT 00517 (IAC). The substance of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DS0-3CC1-F0JY-C2JM-00000-00&context=1519360)_
the primary duty must be properly acknowledged, the relevant children must be identified and their best
interests must then be considered, to be followed by a considered balancing exercise. In assessing the
best interests of the affected child, the decision maker must be properly informed. Furthermore, it must be
apparent from the terms of the decision that the best interests of the child, as assessed, are ranked as a
primary consideration and accorded a primacy of importance. The second duty imposed by section 55 is to
have regard to the statutory guidance promulgated by the Defendant: _Every Child Matters – change for_
_children, November 2009._

94. Children must be recognised as rights holders and not just as adjuncts to other people's rights: see
Lady Hale in Makhlouf v SSHD (NI) _[2016] UKSC 59._

**_Trafficking_**


-----

95. In relation to the fresh protection claim, assessment of the risk that the Claimant will be trafficked on
return to country of origin necessitates attention to the Claimant's history and circumstances, including
mental health and vulnerability to exploitation, age, gender, marital status, domestic circumstances,
availability of family support as well as the prevalence and patterns of trafficking in the country of origin, in
this case Namibia (see for example TD and AD (Trafficked women) CG _[[2016] UKUT 00092 (IAC), para](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J57-XW71-F0JY-C30M-00000-00&context=1519360)_
119(h) and HD (Trafficked women) Nigeria CG _[[2016] UKUT 00454 (IAC), para 190).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KYV-1XV1-F0JY-C4N0-00000-00&context=1519360)_

96. Article 4 ECHR which is the prohibition on slavery and forced labour protects an individual against a
risk of trafficking: Rantsev [2010] 51 EHRR 1. It is a right which is absolute, unqualified and fundamental,
described as protecting 'the basic values of a democratic society': Rantsev at [62].

97. Article 4 is justiciable before the Immigration Tribunal as it is one of the ECHR rights protected by the
_[Human Rights Act 1998. The Tribunal can make a finding as to whether the Claimant was a victim of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
trafficking and consequently whether she is likely to be at risk on return, even if the Competent Authority
has made a negative decision: MS (Trafficking – Tribunal's Powers –Article 4 ECHR) Pakistan _[[2016]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JSS-BXX1-F0JY-C1FK-00000-00&context=1519360)_
_[UKUT 226. The Immigration tribunal is better equipped than the Competent Authority to make pertinent](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JSS-BXX1-F0JY-C1FK-00000-00&context=1519360)_
findings in relation to whether an individual is a victim of trafficking, not least because it will have the
advantage of hearing live evidence: see paragraph 46 of MS (Trafficking – Tribunal's Powers – Article 4
**_ECHR) Pakistan_** _[[2016] UKUT 226.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JSS-BXX1-F0JY-C1FK-00000-00&context=1519360)_

**_Unlawful detention_**

98. Paragraph 16(2) of Schedule 2 to the Immigration Act 1971 provides a power of detention pending
administrative removal as follows:

_“If there are reasonable grounds for suspecting that a person is someone in respect of whom directions_
_may be given under any of paragraphs 8 to 10A or 12 to 14, that person may be detained under the_
_authority of an immigration officer pending–_

_(a) a decision whether or not to give such directions;_

_(b) his removal in pursuance of such directions.”_

99. The power to detain in such circumstances is prescribed by the principles established in **_R. v_**
**_Secretary of State for the Home Department ex parte Hardial Singh [1984] 1 W.L.R. 704 (“the Hardial_**
**_Singh principles”). As explained by Richards LJ in R (LE (Jamaica)) v Secretary of State for the Home_**
**_Department_** _[2012] EWCA Civ 597 at [29]:_

_“iii) Subject to the limits imposed by the Hardial Singh principles, the power to detain is discretionary and_
_the decision whether to detain a person in the particular circumstances of the case involves a true exercise_
_of discretion. That discretion is vested by the 1971 Act in the Secretary of State, not in the court. The role_
_of the court is supervisory, not that of a primary decision-maker: the court is required to review the decision_
_in accordance with the ordinary principles of public law, including_ Wednesbury _principles, in order to_
_determine whether the decision-maker has acted within the limits of the discretionary power conferred on_
_him by the statute.”_

100. The Defendant's policy on the exercise of the power to detain is set out in the Enforcement
Instructions and Guidance (“EIG”).

101. Paragraph 55.10 provides that categories of persons “normally considered for detention in only very
exceptional circumstances” include _“those suffering serious mental illness which cannot be satisfactorily_
_managed within detention”, “those where there is independent evidence that they have been tortured”, and_
_“Persons identified by the Competent Authorities as victims of trafficking.”_

[102. Detention in an immigration removal centre is subject to the Detention Centre Rules 2001 (SI](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-S3R0-TX08-H0XH-00000-00&context=1519360)
_[2001/238). Rule 35 states as follows:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-S3R0-TX08-H0XH-00000-00&context=1519360)_

_“(1) The medical practitioner shall report to the manager on the case of any detained person whose health_
_is likely to be injuriously affected by continued detention or any conditions of detention._


-----

_(2) The medical practitioner shall report to the manager on the case of any detained person he suspects of_
_having suicidal intentions, and the detained person shall be placed under special observation for so long as_
_those suspicions remain and a record of his treatment and condition shall be kept throughout that time in a_
_manner to be determined by the Secretary of State._

_(3) The medical practitioner shall report to the manager on the case of any detained person who he is_
_concerned may have been the victim of torture._

_(4) The manager shall send a copy of any report under paragraphs (1), (2) or (3) to the Secretary of State_
_without delay._

_(5) The medical practitioner shall pay special attention to any detained person whose mental condition_
_appears to require it, and make any special arrangements (including counselling arrangements) which_
_appear necessary for his supervision or care.”_

103. The Detention Rule 35 Process Guidance sets out the process to be followed by Home Office staff in
response to a Rule 35 report. This includes guidance as to whether the Rule 35 report constitutes
'independent evidence of torture' for the purposes of Chapter 55.10 EIG:

_“Because each case will be different, it is not possible to provide definitive guidance on when a rule 35_
_report will constitute independent evidence of torture. However, it must have some corroborative potential_
_(it must “tend to show”) that a detainee has been tortured, but it need not definitively prove the alleged_
_torture. The following pointers may assist:_

_• A report which simply repeats an allegation of torture will not be independent evidence of torture;_

_• A report which raises a concern of torture with little reasoning or support or which mentions nothing more_
_than common injuries or scarring for which there are other obvious causes is unlikely to constitute_
_independent evidence of torture;_

_• A report which details clear physical or mental evidence of injuries which would normally only arise as a_
_result of torture (e.g., numerous scars with the appearance of cigarette burns to legs; marks with the_
_appearance of whipping scars), and which records a credible account of torture, is likely to constitute_
_independent evidence of torture.”_

104. Section 3(ii) of the Process Guidance continues:

_“Very exceptional circumstances could arise where, for example, release would create an unacceptably_
_high risk of absconding, of reoffending or of harm to the public. There will not be very exceptional_
_circumstances in the case of a routine detention absent other reasons, e.g., a removal without a high_
_absconding risk or harm issue — see Ch. 55 of the EIG. The full circumstances applicable to the detainee_
_and their reasons for detention must be considered, in order to establish whether there are very_
_exceptional circumstances that mean detention is appropriate notwithstanding the rule 35 report._

_In some cases where the rule 35 report is accepted as independent evidence of torture, there may_
_nevertheless be further information which renders the overall account of torture wholly incredible. Such_
_information may form the basis of an assessment that there are very exceptional circumstances making_
_detention appropriate._

_For instance, it may be right to detain in very exceptional circumstances if, despite the existing independent_
_evidence of torture, there is a court determination which was made with sight of a full medico-legal report_
_and which dismisses the account of torture, or there is evidence such as visa match evidence which very_
_clearly shows that at the time the detainee claims to have been tortured in one location, he was in fact_
_enrolling biometrics and applying for a visa in another location. Because genuine confusion may be an_
_issue, caution must be exercised in such a consideration.”_

105. “Independent evidence” of torture is not the same as proof of the same (see R (AM) v Secretary of
**_State for the Home Department_** _[2012] EWCA Civ 521 at [29-30]). What is required is “necessarily_
_something beyond the say so of the person concerned” (R (EO and others) v Secretary of State for the_
**_Home Department [2013] EWHC 1236 (Admin) at [68])._**


-----

106. In EO Burnett J (as he then was) stated:

_“69 ….The policy gives some help with what may inform whether there are very exceptional circumstances._
_It refers to the need to weigh risks to the public of releasing convicted offenders with particular care. A very_
_high, rather than routine, risk that the detainee will abscond might well also provide a proper basis for_
_maintaining detention. The rubric is such that a host of factors may come into play.”_

107. The Court of Appeal in **_R. (on the application of Das) v Secretary of State for the Home_**
**_Department_** _[2014] EWCA Civ 45, stated that detention policies such as chapter 55.10 provide broad_
guidance about how discretion to detain should be exercised. Such policies should not be interpreted as
having the same effect as statute (per Beatson LJ at [47]). The construction of the Defendant's policies and
questions as to whether they were applied correctly are matters for the court. If the policies have been
applied correctly, the Defendant's conclusion on their application can only be challenged on Wednesbury
grounds.

108. In R (BA (Eritrea)) v Secretary of State for the Home Department _[2016] EWCA Civ 458; [2016] 4_
WLR 101(the “BA” case) the Court considered when a Rule 35(3) report constituted independent evidence
of torture.

109. These three pointers were specifically considered in BA.

i) In relation to the first example given by the Process Guidance (the first bullet point at paragraph [103]
above) that “the mere recitation of an account of torture coupled with the fact that the doctor does not find it
_inherently incredible would not in my view be enough…The position is no different even if the doctor also_
_describes injuries or scarring which are visible on the body of the patient but does not relate them in any_
_way to the account” ([32-33])._

ii) In relation to the second example given by the Process Guidance (the second bullet point at paragraph

[103] above) that “the existence of commonly found scars coupled with a mere assertion of torture would
_not in general be enough”. However, “a reasoned explanation of why the scarring is consistent with the_
_account does lend expert support to the account (and I do not read the example as suggesting otherwise)”._
Therefore “unless the account of the detainee is inherently incredible so that there is no proper claim of
_torture capable of being corroborated, medical evidence consistent with the account will in my view_
_generally satisfy the requirement” (at [41])._

iii) In relation to the third example (the third bullet point at paragraph [103] above), “even with unusual
_scarring, the account of torture must be credible in the sense of being capable of belief. If the account is_
_inherently incredible, that will be likely fatally to undermine the conclusion that the scarring was caused by_
_torture” (at [50])._

110. It was further stated (at paragraph [46]) that

_“The fact that the Tribunal has found the evidence unconvincing does not alter its status as independent_
_evidence of torture. It does not cease to be evidence because it, or evidence to the same effect, was not_
_accepted. As Burnett J noted in EO's case [2013] ACD 116 para 68 the underlying credibility of the_
_detainee is irrelevant to the question whether something amounts to independent evidence of torture._
_Credibility is critical when evaluating the claim, but as Burnett J observed, “that does not mean that a piece_
_of evidence which supports his central claim is any less 'independent evidence' even if, in the end, the_
_claim is rejected”._

111. Finally, the Defendant is not under an obligation to interrogate a detainee's medical records or to
obtain a psychiatric assessment where there is “a mere possibility that a detainee, or potential detainee,
_might be suffering from a mental illness which might trigger Chapter 55.10 EIG” (R. (on the application of_
**_DK) v Secretary of State for the Home Department_** _[2014] EWHC 3257 (Admin) at [181] per Haddon_
Cave J).

**_The parties' cases, analysis and conclusions_**

**Ground 1: Fresh Claims**


-----

112. In relation to the first ground of challenge, I have to consider whether the Defendant's view that the
further submissions dated 12 November 2015, as well as those of 7, 8, 24 and 29 March 2016 plus those
of 4, 6 and 12 April 2016, taken together with the previously considered material, did not create a realistic
prospect of the Claimant succeeding before an Immigration Judge was irrational/Wednesbury
unreasonable, bearing in mind the need for anxious scrutiny (i.e. the need to give proper weight to the
issues and to consider the evidence in the round).

_(a) Fresh claim – relationship between Claimant and her daughter_

113. I will first address the issue of whether the Defendant's decision to refuse to treat the Claimant's
further representations concerning her family life in the UK, most notably with her daughter, was lawful.

114. As stated above, Article 8 consideration under the Immigration Rules based on paragraph 398(b) is
that:

_“the deportation of the person from the UK is conducive to the public good and in the public interest_
_because they have been convicted of an offence for which they have been sentenced to a period of_
_imprisonment of less than 4 years but at least 12 months”_

115. The same public interest principle is set out at section 117C of the 2002 Act (“Article 8: additional
_considerations in cases involving foreign criminals”)._

116. In order for Article 8 to overcome the public interest in the Claimant's deportation, it would have to be
shown firstly, that she has a genuine and subsisting parental relationship with her daughter (paragraph
399(a) and s.117C(5)), and secondly, that her deportation to Namibia would be _“unduly harsh” upon her_
daughter (paragraph 399(b) and s.117C(5))..

117. These propositions were not accepted by the First-tier Tribunal which, in its decision of 12 February
2015 found:

_“37. The Appellant's daughter in the UK is in the custody of her father. Her daughter is a British citizen and_
_I have noted the details of the Contact Order. The Appellant showed me a few cards and photos and_
_messages that she has sent her daughter in the UK. However, it is that difficult to see how much contact_
_they have had since she was born in 2009 (sic). The relationship was turbulent with her daughter's father_
_and the Appellant left permanently in 2010 when she was drinking heavily. I have not been given any_
_further details of her relationship with her daughter._

_38. In the circumstances I cannot be persuaded that the Appellant has a genuine and subsisting_
_relationship with her daughter it is in the child's interest to remain with her father (sic). The Appellant can_
_have contact with her daughter and this could be maintained from Namibia by modern technology and_
_visits. Even if she does have a genuine relationship with her daughter it is not of the depth to outweigh the_
_public interest in deportation and would not be unduly harsh._

_39. She has one daughter in Namibia with whom she could be reunited. Therefore I cannot find that there_
_would be breaches of Article 8 were she to be removed.”_

118. The Defendant concluded in her letter of 10 March 2016 that the Claimant had provided no evidence
to suggest that the nature of her relationship with her daughter “differs significantly from that considered by
_the Tribunal.”_

119. The Claimant's further representations enclosed a witness statement from the Claimant's former
partner who was the father of her daughter and documents emanating from the Claimant's daughter written
to or about the Claimant.

120. In her response letters dated 6 and 18 April 2016, the Defendant set out detailed reasons why it was
not accepted that the deportation of the Claimant would amount to an unjustified interference in the Article
8 rights of either the Claimant or her daughter, essentially on the basis that there was no evidence to
conclude that the Claimant's presence was needed to prevent her daughter from being ill-treated, or her
health or development being impaired and no suggestion of either emotional or financial reliance on the
Claimant and that contact with her daughter could be maintained from Namibia It was further stated that


-----

whilst the evidence did show some form of relationship between mother and daughter, due to her absence
for almost all of her daughter's life, any relationship they had would be limited in nature. It was noted that
the child's father's evidence was that they had visited the Claimant in detention 4-5 times for 3 hours at a
time. However, the Defendant pointed to the statement of the First-tier Tribunal that “Even if she does have
_a genuine relationship with her daughter it is not of the depth to outweigh the public interest in deportation_
_and would not be unduly harsh”. The Defendant pointed to the fact that the Claimant had been convicted of_
“a very serious offence, one which fully engages the public interest in securing her removal, and none of
_the claims made constitute very compelling circumstances sufficient to outweigh that interest.”_

121. The Claimant's case is that the starting point to consider the strength and substance of the fresh
claim relating to the relationship between the Claimant and her daughter is the determination of the Firsttier Tribunal dated 13 February 2015. It is said that at that time there was no evidence at all from the
Claimant's daughter or her former partner and daughter's father, as to the relationship between mother and
daughter. In the further representations dated 24 March 2016 and 12 April 2016, the Claimant's former
partner provided a statement and 3 letters, all post-dating the decision of the First-tier Tribunal which
included details of the level of contact between the Claimant and her daughter, the likely detrimental impact
on the daughter if the Claimant was deported and his opinion that it would be in the daughter's best
interests for her mother to be granted leave so she can exercise fully her family life with her daughter. The
Claimant's former partner also clarified that it was no longer his intention to move permanently to Ireland
with his daughter, as had been the case when he sought and was granted a court order in October 2014.
In April 2016, he and his daughter were settled and living in London and he was expressly encouraging the
relationship between his daughter and the Claimant. The representations also enclosed evidence from the
daughter expressing her wish for her mother not to be deported. It is said that the evidence is relevant to
two issues: (a) whether the Claimant has a genuine and subsisting relationship with her daughter and (b)
whether it would be unduly harsh for the daughter to remain in the UK without her mother. The Claimant
contends that it cannot be said that the evidence was incapable of leading to a positive conclusion before a
putative immigration judge, bearing in mind that the judge would be likely to hear live evidence from the
entire family.

122. The Claimant argues that the Defendant has not asked herself the correct question which is not
whether the Defendant considers that the new claim is a good one or should succeed but whether there is
a realistic prospect of an Immigration Judge, applying the rule of anxious scrutiny, thinking that the
Claimant could satisfy the criteria identified above (genuine and subsisting relationship and unduly harsh
on daughter to remain in the UK without her mother).

123. It is further said that the conclusion is irrational: the evidence which is presented in the fresh claim
may concern the same subject matter but is quite clearly different in nature and strength than anything
submitted previously. Most notably, at the First-tier Tribunal Hearing in January 2015, there was no
evidence at all from the Claimant's daughter or her father.

124. It is also said that the requirement that the Defendant apply anxious scrutiny to the assessment of the
fresh claim test is clearly not met. It is said that this is best illustrated by examining the way in which the
Defendant deals with the Claimant's daughter's best interests. The fresh claim introduced the Claimant's
daughter's voice into the fresh claim, thus she was entitled to consideration as a child rights holder, and not
just a conduit of rights of her mother. She and her father provided evidence of why it would be in her best
interests for her mother to remain in the UK - so that she can foster and develop a direct and meaningful
relationship with the Claimant. It is said that it is not in dispute that the Claimant's daughter's best interests
are to remain with her father (as was the case at the time of FTT decision in February 2015). However, the
evidence presented in the new claim demanded a further and fuller consideration of whether it is in the
Claimant's daughter's best interests for her mother to remain in the UK and the effect on her if her mother
is permanently excluded from the UK, bearing in mind that in the absence of exceptional circumstances the
Home Secretary would not even consider whether to re-admit the Claimant to the UK within 10 years of the
date of deportation (paragraph 391(1) of the Statement of Changes in Immigration Rules (1994) HC 395,
as amended). The need for a careful and balanced assessment on these points is said to be heightened in
light of the Defendant's duty under section 55 and Article 24 of the EU Charter of Fundamental Rights.


-----

125. Finally, it is contended that the Defendant's conclusion that the 'submissions are not significantly
_different from the evidence that has previously been considered' is lacking in any or any adequate_
reasoning as to why a putative Tribunal is bound to reject the Claimant's fresh claim.

126. Further, the Claimant contends that the refusal of the asylum claim was premised _“on the_
_understanding that [the Claimant's daughter] would move permanently to Ireland with her father”._

127. It is the Defendant's case that, in respect of the evidence from the Claimant's former partner, she
reasonably formed the view that this did not meet the paragraph 353 threshold. Further, as to the evidence
from the daughter herself, the Defendant contends that the documents referred to were not mentioned in
either the Amended Detailed Statement of Facts and Grounds dated 19 December 2016 or the Claimant's
Reply of 15 September 2017. Further, it is contended that the documents relied on did not express the
child's “clear wishes for her mother not to be deported” and did not “introduce…[the Claimant's daughter's]
_voice into the fresh claim”_ as submitted by the Claimant. The Defendant maintains that they cannot
evidence “a genuine and subsisting relationship with her daughter” which the First-tier Tribunal held the
Claimant had failed to establish.

128. The Defendant states that it is incorrect to assert that the refusal of the asylum claim was premised
on the understanding that the Claimant's daughter would move permanently to Ireland with her father. It is
contended that as noted at paragraph 95 of the Defendant's decision of 13 October 2014, her daughter
could not move to Ireland as the Claimant did not consent to her obtaining a renewed passport and that in
any event the fact that her daughter had subsequently remained in the United Kingdom did not avail the
Claimant of a fresh claim for the detailed reasons set out in the Defendant's letters of 10 March 2016, 6
April 2016 and 18 April 2016.

129. Having considered the material relied upon and the submissions made by both sides, I have come to
the conclusion that the decision of the Defendant that the further submissions relating to the Claimant's
relationship with her daughter, taken together with the previously considered material, did not create a
realistic prospect of the Claimant succeeding before an Immigration Judge was _Wednesbury_
unreasonable, bearing in mind the need for anxious scrutiny (i.e. the need to give proper weight to the
issues and to consider the evidence in the round). This is for the following reasons:

i) The Defendant was presented with evidence from the Claimant's former partner and material originating
from the Claimant's daughter and sent to the Claimant which was not before the First-tier Tribunal (the
Tribunal only had evidence of correspondence sent from the Claimant to her daughter) and did raise the
issue of whether there existed a relationship between the Claimant and her daughter in circumstances
where the Tribunal had stated that it was not persuaded that there was any genuine and subsisting
relationship between the Claimant and her daughter. The Defendant accepted that there was “evidence of
_a relationship” in her response dated 6 April 2016 (with it being implicit, albeit not entirely without doubt,_
that she also accepted that the requirement for such relationship to be genuine and subsisting was met).
Accordingly, the Tribunal's decision which had rested on the two limbs (no genuine and subsisting
relationship but even if there was, it was not of the depth whereby it would be unduly harsh on the
Claimant's daughter for her mother to be deported) now rested only on one.

ii) In relation to the issue of whether it would be “unduly harsh” on the Claimant's daughter for her mother
to be deported, whilst the Tribunal had concluded that even if a relationship existed it was not of a depth to
outweigh the public interest in deportation, the question of the actual depth of that relationship, albeit one
where personal contact was inevitably sporadic in light of the fact the Claimant was in immigration
detention, had to be further considered in light of the new evidence and the question of the negative
emotional impact and the best interests of the child assessed on the basis of anxious scrutiny. Whilst Mr
Mitchell orally submitted on behalf of the Defendant that it was “very difficult to see how an Immigration
_Judge would find the quality of the relationship satisfied the test” the question to be considered was_
whether there is any realistic prospect of the Claimant succeeding before an Immigration Judge bearing in
mind the need for anxious scrutiny. There was at least some evidence regarding a greater depth of
relationship and including evidence which emanated from the Claimant's daughter herself than had been
before the Tribunal when making its decision on 12 February 2015. I am not satisfied that such evidence


-----

was properly weighed in terms of its significance, given the Defendant's focus on the quantity of _direct_
contact rather than on the depth of the relationship.

iii) It is also unclear from the decision letters what consideration was in fact given to the evolving situation
where the Claimant's former partner's intentions regarding where his daughter would live and as to contact
with her mother had changed. The Claimant's former partner had been the principal witness in the criminal
trial that had led to the Claimant's imprisonment but this had all changed by April 2016 at which time he
was submitting evidence in support of a continued relationship between the Claimant and her daughter.
There is no reference to this change of position in the Defendant's response letters.

iv) Whilst it is clear that Article 24(3) of the Charter of Fundamental Rights was considered by the
Defendant, this section of the response refers back to the best interests of the child reasoning and was
considered essentially through the prism of section 11 Children Act 2004. It is not clear to me from the
responses to what extent the Defendant did take into account the Claimant's daughter's own free-standing
rights, including in relation to Article 24(3) which states that every child shall have the right to maintain on a
regular basis a personal relationship and direct contact with both his/her parents, unless that is contrary to
his/her interests.

v) Further, whilst the Defendant accepted that there was a negative emotional impact on the Claimant's
daughter, she then stated that this was the product of the Claimant's own actions and that the predominant
issue was the public interest in deportation. It is not clear whether and to what extent that admitted
negative emotional impact was assessed against the “unduly harsh” criterion (i.e. whether it would be
unduly harsh for the Claimant's daughter to remain in the UK without her mother following deportation) as
opposed to focusing on the reason why that impact had arisen.

130. Accordingly, I am not satisfied that the decisions dated 6 and 18 April 2016 applied the correct test or
asked the right question in relation to the issue of the relationship between the Claimant and her daughter
and/or satisfied the requirement of anxious scrutiny (see in particular paragraph 68 above). I make it clear
that I am not expressing any conclusion about whether the Defendant could rationally have reached the
conclusion that she did; rather that I am concerned as to the manner in which the issues were approached
and whether it was considered in accordance with the approach which has been identified in the case-law
as the one the Defendant must follow. Accordingly, I will quash the decisions of 6 and 18 April 2016 and
require the material submitted to be reconsidered by the Defendant and a fresh decision made.

131. I was told at the hearing that the Defendant is in any event going to be revisiting this particular issue
in the context of yet further evidence recently submitted by the Claimant to her in support of a fresh claim
which consists of further witness statements from the Claimant and her former partner and a detailed
report from an independent social worker which further addresses the up-to-date relationship between the
Claimant and her daughter during the period since the Claimant was released from detention in May 2017.
The documents were provided to me in advance of the hearing to keep the Court informed of these
developments but as was made clear by Ms Sabic at the hearing, the Claimant was not seeking to rely on
this fresh evidence for the purpose of the claim. The Defendant, whilst not accepting that paragraph 353
submissions had already been made to her, accepted that she would have to review and make a decision
on the new material. If that proposed review is still outstanding, the consideration of the material previously
submitted and which is the subject of this claim can be undertaken in addition to the review of the new
material.

132. I turn now to address the second issue under Ground 1, namely whether the Defendant's decision to
refuse to treat the Claimant's further representations concerning her claim for international protection as a
fresh claim was lawful.

_(b) Fresh protection claim_

133. The Claimant alleges that she is at risk of persecution on account of being a victim of trafficking who
is vulnerable to further exploitation on her return to Namibia.


-----

134. On 12 February 2015, the First-tier Tribunal concluded, in light of the evidence of Dr Naguib and Dr
Stamps, that there was no evidence of formal mental illness and no symptoms of PTSD (at paragraph 31).
Whilst it was accepted that the Claimant had suffered in the past at the hands of family and neighbours
(paragraph 27), it was concluded that the Claimant was a woman capable of living independently, that
there was regular contact with her daughter and grandmother (at paragraph 28) and she had said that her
family would not seek her out.

135. The report of Professor Katona stated that the Claimant fulfilled the criteria for PTSD and Borderline
Personality Disorder and identified that the main cause was the prolonged, severe and early onset of
physical and sexual abuse and exploitation by the Claimant's aunt's family in the UK. He concluded that
the Claimant's 'presentation is clinically plausible' (paragraph 6.6). Professor Katona specifically addressed
the opinion of Dr Stamps and Dr Naguib and provided reasons as to their differing diagnostic conclusions
(paragraph 6.7). He said that her clinical presentation was in keeping with trafficking to the UK (in section
9) and that without specialist therapy, the Claimant was extremely vulnerable to exploitation if she was
returned to Namibia (paragraph 10.3).

136. The Defendant's decision on the fresh protection claim is dated 3 March 2016.

137. The Claimant's case is that in relation to the fresh claim relating to the risk of re-trafficking made by
way of submissions on 12 November 2015, the task of the Defendant was to assess whether the new
evidence, in particular from Professor Katona, was capable of raising a case with a realistic prospect of
success before the Immigration Tribunal and that she had failed to do so, wrongly relying on the failure to
provide un-redacted notes of Professor Katona's interview with the Claimant following requests made by
the Defendant. The Claimant argues that those notes could not have any bearing on the clinical opinions
expressed by Professor Katona. It is said that the report had materially altered the factual basis of the
Claimant's protection claim and that the value of Professor Katona's report lay in making a clinical
assessment of the Claimant's mental health and her vulnerabilities to further exploitation in light of her
mental health. His report was not intended to make any findings as to veracity of the Claimant's factual
account. That was a matter for the Defendant and, in the event of a fresh claim being accepted, for the
Immigration Tribunal. The role of Professor Katona was to assist the decision maker by providing on
opinion in his area of expertise, namely the Claimant's mental health. It is for that reason that Professor
Katona made it clear in his report that: “The information given in this report is based on the history provided
_directly to me by [the Claimant], together with my own observations. The report does not rely on material_
_from any other source unless specifically stated. The absence of an event does not mean that it was not_
_described to me and nothing in my summary of [the Claimant's] account should be taken as a finding of_
_fact in relation to her fresh claim against deportation from the UK.”_

138. In light of the above, the Claimant submits that it was irrational for the Defendant to reject the opinion
of Professor Katona in its entirety because of the failure to provide the un-redacted notes, and it was still
less rational for the Defendant to conclude that a putative Immigration Judge was also bound to reject
Professor Katona's report for that reason.

139. In oral submissions, the Claimant contended that the First-tier Tribunal's reasoning was based on a
lack of vulnerability on the part of the Claimant but that the report of Professor Katona undermined that
factual finding. It was argued that it is not an answer to a fresh claim to say that the claim is hopeless
because the Competent Authority rejected it and that whilst it was open to the Defendant not to believe the
Claimant; it was not open to her to reject the medical assessment.

140. It was argued that even if the Defendant was entitled to treat the failure to provide the un-redacted
notes as a reason for rejecting Professor Katona's report (which is not accepted), this matter ought
properly to be left to a Tribunal Judge's assessment of what weight to place on his report. The Claimant
accepts that the Defendant was not bound to accept the medical expert's opinion but that the Defendant
could not have rejected it without contrary medical evidence or adequate reasoning. Here, it was said,
there was no medical evidence of equivalent quality to discount the diagnosis given by Professor Katona.
Further, the Defendant did not question Professor Katona's qualifications, specialisation or experience, the
quality of his reasoning, and the extent to which any conclusions related to established diagnostic criteria.


-----

The Defendant's treatment of Professor Katona's evidence was said plainly to offend the principle that the
Defendant should have given careful and specific consideration to the opinion expressed by a medical
expert. Finally, it was argued that the Defendant's assessment of the relevant test under paragraph 353
lacked reasoning as to why the protection claim, in light of Professor Katona's report, does not have a
realistic prospect of success before a putative Tribunal.

141. The Defendant's case is that the Claimant's claim to be a victim of trafficking was comprehensively
dismissed by the Competent Authority in its detailed refusal decision of 11 December 2015. In support of
her claim, the Claimant's previous solicitors had produced Professor Katona's report dated 2 November
2015. Significantly, as noted by the Competent Authority, its request to see the un-redacted notes of
Professor Katona's interview with the Claimant was twice refused by the Claimant's previous solicitors. The
reason for the requests was stated to be due to the stark difference in the Claimant's account as recorded
by Professor Katona, compared to that which appeared in the reports prepared by two earlier psychiatrists,
Dr Naguib and Dr Stamps, in their reports dated 28 September 2011 and 2 December 2011 respectively.

142. The Competent Authority noted Professor Katona's statement that, “nothing in my summary of [the
_Claimant's] account should be taken as a finding of fact in relation to her fresh claim against deportation_
_from the UK.” In terms of the account provided by the Claimant, the Competent Authority had stated:_

“It is considered that you have given inconsistent information about your life in Namibia and that the
_accounts you have given, regarding the “abuse” you claim to have suffered in relation to being treated like_
_a domestic worker, cannot be wholly relied upon as being truthful or accurate”_ and that the Claimant's
account of her time in the UK “significantly undermines your claim to have been trafficked.”

143. It concluded:

_“Professor Katona has concluded that your clinical presentation is in keeping with your having been_
_trafficked. Professor Katona may have been unaware that you had visited Norway and that you had control_
_of your own travel documents before arriving in the UK in April 2006. He states that you have given “a clear_
_account of being persuaded to come to the UK for your own benefit and that being forced to work against_
_your will and being restricted in her movements, with her protests ignored and the promises made to her_
_being unfulfilled” (sic) This is refuted. There is no clear account given about your journey to the UK, except_
_where you have stated that you had visited Norway first and had made an independent choice not to stay_
_there._

_In conjunction with his statement that, “… nothing in my summary of [the Claimant's] account should be_
_taken as a finding of fact in relation to her fresh claim against deportation from the UK” Professor Katona's_
_conclusion that your clinical presentation is in keeping with your having been trafficked is not accepted_
_because there is no evidence that your case meets the definitions of trafficking or modern slavery.”_

144. Professor Katona's notes were belatedly disclosed on 10 November 2017 and the Defendant points
to the fact that, consistent with the matters raised by the Competent Authority, these notes do not record
that the Claimant “visited Norway” or that she “had control of [her] own travel documents before arriving in
_the UK in April 2006.”_

145. The finding of the Competent Authority regarding the potential risk faced by the Claimant upon her
return to Namibia was said to be consistent with that of the First-tier Tribunal, which recorded in its decision
of 12 February 2015:

_“28. I cannot find that the Appellant's fear of her family on return is well founded. As the Appellant has said_
_in interview she is now grown up and they would not be able to hurt her anymore, she says that she will_
_stand up for herself. She is in regular contact with her daughter and her grandmother. She has also said_
_that her family will not seek her out.”_

146. It was against this background that the Defendant noted in her letter of 3 March 2016 that although
Professor Katona's report “claims that she has PTSD and BPD, her medical records indicate that she is not
_currently receiving any treatment for these conditions. As such, any claim that she will require treatment in_
_the future is purely speculative: therefore, the Tribunal's findings remain relevant… In the absence of any_


-----

_evidence to the contrary, there are no reasons to suggest that we should depart from our previous_
_findings.” It is said that this reasoned decision was perfectly open to the Defendant._

147. The Defendant asserted that the Claimant's lengthy Pre-Action Protocol letter which followed
subsequently on 12 April 2016 contained no suggestion that the Claimant was a victim of trafficking and did
not assert that she had legitimately made a fresh claim to such effect. The Claimant in response stated that
_“nothing turns” on this omission._

148. The Defendant contends that the Claimant has grossly oversimplified the comprehensive rationale
recorded on 11 December 2015, as adopted in the Defendant's letter of 3 March 2016, and that in addition,
the letter of 3 March 2016 proceeded to further consider the Claimant's “fear of persecution at the hands of
_her family”, “mental and physical health needs”, “[risk of]_ _destitution upon return” and “risk of harm and_
_reoffending” under each relevant heading._

149. In addition, the Defendant points to the diametrically contrasting account which the Claimant provided
to Dr Naguib and Dr Stamps produced for the purpose of the Claimant's Crown Court trial which put it on
notice regarding the potential inaccuracy of the information provided to Professor Katona.

150. I have carefully considered the report of Professor Katona, the decision of the Competent Authority
on the trafficking claim and the Defendant's response to the fresh protection claim dated 3 March 2016. I
am unable to conclude that the Defendant's view that the further submissions in relation to the fresh
protection claim, taken together with the previously considered material, did not create a realistic prospect
of the Claimant succeeding before an Immigration Judge was irrational/Wednesbury unreasonable, bearing
in mind the needs of anxious scrutiny (i.e. the need to give proper weight to the issues and to consider the
evidence in the round). This is for the following reasons:

i) There was a negative reasonable grounds decision in relation to trafficking by the Competent Authority
dated 11 December 2015 which was very detailed in its reasoning and took full account of Professor
Katona's report. This decision was not challenged by the Claimant by way of judicial review. Whilst I fully
accept that the fact that decision was not challenged by the Claimant is not determinative because the
absence of a challenge is not a bar to a new First-tier Tribunal reaching a conclusion on a full examination
of the evidence available, it is nonetheless significant that the Claimant did not herself seek to challenge
the negative decision.

ii) Professor Katona made very clear that he had relied solely on the Claimant's account and had not seen
any medical records. His diagnosis was made on the basis of her account alone and the fact that he
considered her clinical presentation was “clinically plausible”.

iii) Professor Katona's report was in contrast to two previous psychiatric reports served by the Claimant in
relation to the criminal proceedings where Dr Naguib and Dr Stamps concluded she did not have PTSD
(albeit it is fair to say it was left open whether she might have had such a condition in the past) as well as
the medical records of the Defendant assessing the Claimant's mental health whilst in detention.

iv) There were undoubtedly credibility issues arising from various changes in the Claimant's account and
the refusal to release the un-redacted notes to the Competent Authority or to the Defendant.

v) Professor Katona was seemingly unaware that the Claimant had visited Norway and that she had
control of her own travel documents before arriving in the UK in April 2006 and had apparently made an
independent choice not to stay in Norway.

vi) Whilst it is correct that Professor Katona's report provided some evidence of formal mental illness and
of symptoms of PTSD, this had to be weighed with all the evidence previously considered and also had to
take account of the limitations of that report.

vii) I do not accept the Claimant's submission that the Defendant conflated issues of medical diagnosis
and credibility. A diagnosis of mental illness is likely to be particularly influenced by the patient's
presentation to the clinician and the history given regarding the factors alleged to have given rise to the
mental illness and the symptoms experienced.


-----

viii) Further, the First-tier Tribunal had accepted that the Claimant had suffered in the past at the hands of
family and neighbours but had concluded that she was capable of living independently, had made her own
way in the UK and would do so in Namibia, that her family would not seek her out and that she could
relocate away from her family if necessary. These factors were unaffected by Professor Katona's report.

ix) The decision as to whether the further submissions, taken together with the previously considered
material, created a realistic prospect of the Claimant succeeding before an Immigration Judge was for the
Defendant and the Court can only interfere if that decision was irrational/Wednesbury unreasonable (see
paragraphs 65-70 above). I am not satisfied that there was any demonstrable error in the Defendant's
approach to the issue and in the circumstances of this case and I am unable to conclude that the requisite
threshold has been met.

151. Accordingly, I have concluded that the Defendant's refusal of the Claimant's fresh protection claim
was not unlawful and reject the Claimant's claim in this regard.

_Unlawful detention_

152. There is no issue about the lawfulness of the Claimant's detention prior to 11 February 2015.

153. As stated above, the issues which arise for determination on the unlawful detention ground are as
follows:

i) Was the Defendant's response to the Rule 35 report dated 10 February 2015 lawful?

ii) Did the Defendant assess the Claimant's continued detention following the receipt of Professor Katona's
report on 12 November 2015 against the correct policy?

iii) Was the Defendant's detention during the relevant period (11 February 2015 to 9 May 2017) otherwise
lawful?

154. The Claimant alleges that her detention after 11 February 2015 was unlawful because:

i)   the Defendant should have determined that the Rule 35 report constituted independent evidence of
torture, alternatively failed to determine whether the Rule 35 report constituted independent evidence of
torture, instead relying on her own decision which pre-dated the rule 35 report, most notably the decision
dated 13 October 2014;

ii)   the Defendant failed to give proper consideration to the report of Professor Katona and his clinical
conclusions, which led to the Defendant failing to assess the Claimant's detention against the correct policy
framework, that of “very exceptional circumstances”. It is said that the responses dated 3 and 10 March
2016 did not consider the lawfulness of detention but rather dealt with the risk on return and insofar they
rejected Professor Katona's diagnoses of PTSD and BPD, they did so unlawfully because the failure to
provide the un-redacted notes of the interview did not detract from the clinical conclusions of the report. It
is further said that the absence of treatment was not a sufficient reason for doubting the diagnosis bearing
in mind that appropriate treatment is not available in immigration detention. It is further said that it was
illogical to refer to the First-tier Tribunal's assessment which was made before Professor Katona's report
and that no account was taken of that report when reviewing detention;

iii)   her detention breached the Hardial Singh principles in that it was or should have been clear to the
Defendant that the Claimant's removal was not imminent and because the risk of absconding and harm
was repeatedly classified as high notwithstanding the Claimant's changed circumstances and support from
various organisations.

155. It is common ground that the burden is on the Defendant to satisfy the Court that the detention was
lawful.

156. The Defendant's case is that:

i) The contention that the Rule 35 report constituted independent evidence of torture did not appear in the
Amended Detailed Statement of Facts and Grounds dated 19 December 2016. The Defendant contends
that the mere fact that the author of the report noted that the Claimant “may have been the victim of torture”


-----

does not amount to independent evidence of torture within the meaning of EIG 55.10. As explained in her
own guidance, “Detention Rule 35 Process” “A report which raises a concern of torture with little reasoning
_or support or which mentions nothing more than common injuries or scarring for which there are other_
_obvious causes is unlikely to constitute independent evidence of torture.” It is stated that it is tolerably clear_
from Mr Turpin's detailed reasoning that it was his conclusion that the report did not constitute independent
evidence of torture. Accordingly, the Defendant properly concluded that the Claimant did not come within
any of the categories of detainees listed at chapter 55.10 EIG and that the issue of whether _“very_
_exceptional circumstances” existed justifying continued detention did not arise._

ii) The Defendant disputes that Professor Katona's report had been provided to her for the purpose of
chapter 55.10 EIG, relying on letters from Mrs C.H. Hopper dated 3 December 2015, 26 January 2016 and
21 March 2016 indicating that it had not. Further, the Defendant contends that it was reasonably open to
her to conclude that Professor Katona's report did not tend to show that the Claimant was “suffering
_serious mental illness which cannot be satisfactorily managed within detention” within the definition of_
chapter 55.10 EIG. The lawfulness of detention was considered in the Defendant's letters dated 3 and 10
March 2016. Set against Professor Katona's report, the Defendant was entitled to prefer the findings
reached by the First-tier Tribunal, which accorded with her own (repeated) assessment of the Claimant's
psychiatric health, as corroborated by the fact that subsequent to Professor Katona's report and in spite of
her attendance at psychological well-being sessions, the Claimant had not received any treatment for
either PTSD or BPD.

iii) In relation to the alleged breach of the Hardial Singh principles, the Defendant points to the fact that
the Claimant was consistently assessed as posing a high risk of absconding, a medium risk of re-offending
and a high risk of harm to the public and that the Claimant has made no meaningful attempt in either her
amended claim or skeleton argument to challenge the accuracy of these assessments nor has she taken
issue with the detailed rationale for maintaining detention consistently recorded by the Defendant both in
her detention reviews / minutes and the monthly progress reports. It is further contended that the length of
the Claimant's detention is a product of the fact that, as noted by the First-tier Tribunal on 15 December
2015 in relation to a bail application, she was engaged in “submitting claim after claim in an attempt to
_frustrate removal.”_

157. In relation to the Rule 35 report, whilst it is not as clear as it should have been, I accept the
Defendant's contention that Mr Turpin was indeed rejecting the report as providing independent evidence
of torture as a result of:

i) His reference to the Defendant's decision of 13 October 2014, and in particular paragraph 31 of that
decision.

ii) His noting the fact whilst that the Claimant had reported that she had been diagnosed with PTSD, this
claim was contradicted by the detailed findings in the Defendant's decision of 13 October 2014.

iii) The fact that the Claimant's erroneous claim to have been diagnosed with, and suffering from, PTSD,
was predicated on the suggestion, as reported to her examiner, that she “feels cannot escape this as
_marks on her body remind her of her past”, whereas there was no connection between any scarring and a_
diagnosis of PTSD which the Claimant did not have.

iv) The fact that having considered the Rule 35 report against the existing records applying to the
Claimant, Mr Turpin reached a reasoned decision that detention should be maintained stating: _“In the_
_absence of any other information to the contrary, it has been concluded that your ongoing detention_
_remains appropriate. The position of your detention will continue to be reviewed on a regular basis.”_

158. I further consider that Mr Turpin was entitled, on the evidence, to conclude that the Rule 35 report
was in the second category set out at paragraph 109 above (the second bullet point in the guidance) as
being a report which raised a concern of torture but with little reasoning or support or which mentioned
nothing more than common injuries or scarring for which there were other obvious causes and which was
unlikely to constitute independent evidence of torture.


-----

159. The Claimant's asylum appeal had failed some two days after the Rule 35 report and had raised
similar allegations regarding torture and trafficking as were raised by the Rule 35 report.

160. It is also relevant that the Claimant's former solicitors wrote on 12 November 2015 enclosing
Professor Katona' report stating that the Claimant “now” had independent evidence of torture and that the
Claimant had been a victim of trafficking. Accordingly, the Claimant's own legal representatives did not
appear to have considered that the Rule 35 report in and of itself constituted independent evidence of
torture.

161. In relation to Professor Katona's report and the lawfulness of detention after 12 November 2015,
there was and remains a lack of clarity as to when that report was received by the Defendant for the
purpose of a review of the lawfulness of detention as opposed to for other purposes. It was apparently sent
to Ms. Hopper of the Criminal Casework Directorate (it is said by the Claimant, for three separate
purposes) and was certainly considered by the Competent Authority in relation to the trafficking claim.
However, no decision was made in relation to its relevance to detention until the Defendant's letter dated 3
March 2016 several months later and there exist several letters from Ms Hopper stating that the report had
not been enclosed and asking for it to be sent to her.

162. So far as the impact of Professsor Katona's opinion on the lawfulness of detention was concerned, I
have concluded that it was reasonably open to the Defendant to conclude that Professor Katona's report
did not tend to show that the Claimant was “suffering serious mental illness which cannot be satisfactorily
_managed within detention” within the definition of chapter 55.10 EIG. Whatever issues may or may not_
exist regarding whether the Claimant was in fact suffering from any mental illness, the Claimant's mental
health did appear to have been satisfactorily managed within detention. I also find that compared against
Professor Katona's report, which had the limitations I have already set out above, it was reasonably open
to the Defendant to prefer the findings reached by the First-tier Tribunal, which accorded with its own
assessments of the Claimant's psychiatric health and the fact that the Claimant had not received treatment
for either PTSD or BPD.

163. In relation to the **_Hardial Singh challenge, I do not accept the Claimant's contention that the_**
Defendant was unreasonable in concluding that she was removable within a reasonable period of time.
She was subject to a deportation order as a result of criminal offences and was consistently assessed as
posing a high risk of absconding, a medium risk of re-offending and a high risk of harm to the public. This
assessment does not appear to me to be seriously challenged, notwithstanding any support the Claimant
may have received from support organisations. Further, it is clear that the length of the Claimant's
detention was in very large part due to the fact she submitted a large number of claims to prevent her
removal. It is also of relevance (albeit that the Defendant was, of course, subject to her own duty to review
the lawfulness of detention) that the Claimant's detention was the subject of repeated independent review
by the First-tier Tribunal through the five bail applications she made to the First-tier Tribunal, all of which
were unsuccessful, until her final successful application on 4 May 2017.

164. In summary, I conclude that the Defendant has discharged the burden of proving that the continued
detention of the Claimant after 11 February 2015 and/or after 12 November 2015 was assessed against
the correct policy and was lawful and I reject the claim in this regard.

**End of Document**


-----

