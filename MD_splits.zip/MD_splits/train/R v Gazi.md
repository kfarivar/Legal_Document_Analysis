# R v Gazi [2021] EWCA Crim 1420

CA, CRIMINAL DIVISION

202003189/A2

Carr LJ, Spencer J, Butcher J

Friday 17 September 2021

17/09/2021

1. MR JUSTICE BUTCHER: The applicant renews his application for permission to appeal against sentence, such
permission having been refused by the single judge.

2. On 2 March 2020, having pleaded guilty before the magistrates, the applicant, then aged 28, was committed for
sentence pursuant to section 3 of the Powers of Criminal Courts (Sentencing) Act 2000 in respect of an offence of
burglary.

3. On 22 June 2020, in the Crown Court at Sheffield, the applicant, then aged 28, pleaded guilty to two offences of
robbery.

4. On 20 November 2020, His Honour Judge Reeds QC sentenced the applicant for those offences as follows.
First, for the robbery offences, seven years' imprisonment for each, the sentences to run concurrently. Secondly,
for the burglary offence, 14 months' imprisonment, also to run concurrently. In addition, it had been ascertained
that the applicant had failed to comply with the terms of a suspended sentence order of two years' imprisonment
suspended for two years imposed on 30 August 2013 at the Crown Court at Sheffield for seven offences of dwelling
burglary and one offence of theft. The judge activated the suspended sentence in full to run consecutively to the
other sentences which he imposed. The total sentence imposed was accordingly one of nine years' imprisonment.

5. The facts of the cases can be summarised as follows. In relation to the burglary offence, the complainant Mr
Nelu Pricopie resided in a ground floor flat in Rotherham. He left his home address at 5 am on 19 January 2020.
He locked his front door but recalled leaving a small upper window open. He returned home at about 7 pm and
discovered that he had been burgled. Stolen from the flat were a laptop computer and a games console with a total
value of about £850. The small window which the complainant had earlier left ajar had been pulled further open.

6. In relation to the robbery offences, these occurred at the Admiral Casino in Rotherham in the early hours of the
morning of 20 February 2020. The casino was open throughout the night and the complainants Emma Hewitt and
Sarah Owen were both working as employees of the casino.

7. The applicant entered the casino at about 1 am. He was initially with another man who left at about 4.50 am. By
about 5.15 am the applicant was the only person in the casino and he was asked to leave by Ms Owen. After
walking a short distance, the applicant turned round and grabbed hold of Ms Owen's jacket, as well as her upper
left arm and shoulder. His threw Ms Owen to her right, causing her to fall to the floor backwards. Whilst she was
still on the floor, the applicant bent down and grabbed her jacket again. He was aggressive and shouted: "Open
that TITO, get me some money", referring to a ticket machine which changed winning tickets from within the casino
for money. Ms Owen was shocked. She got up from the floor and the applicant dragged her by the jacket towards
where her colleague Ms Hewitt was standing nearby.


-----

8. The applicant then dragged both Ms Owen and Ms Hewitt to a cupboard and told them to sit down. Ms Owen
sat down but Ms Hewitt refused. The applicant produced what appeared to be shoelaces from his pocket and
attempted to tie Ms Hewitt's hands together. Ms Hewitt continued to resist, which further angered the applicant. Ms
Owen tried to distract the applicant, but he did manage to tie Ms Hewitt's hands together. The applicant picked up
Ms Hewitt's handbag, took £5 in coins from her purse and emptied the contents of the handbag onto the floor. The
applicant then grabbed Ms Owen and Ms Hewitt by their jackets and dragged them both into a central reception
area where there was a safe. He made Ms Owen crouch down and open the safe. Ms Owen indicated to the
applicant that there was nothing in it. The applicant started to look round and then began to search the front
pockets of the float apron that Ms Owen was wearing. Both complainants were wearing float aprons which were
there to provide customers with change. Ms Owen's apron contained some keys which the applicant took. She
then managed to run away but the applicant ran after her and caught up with her. He punched her a glancing blow
to the top of her head and then dragged her back to the central reception desk area. Ms Hewitt ran away for a
second time. On this occasion she managed to get out of the casino to a local restaurant where the police were
contacted. The applicant ran off. The incident had lasted for about 20 minutes.

9. Ms Hewitt did not sustain any visible injury to her head, but she did have sore wrists with red marks caused by
the applicant trying to tie her wrists together with the shoelaces. Ms Owen sustained severe bruising to her left
upper arm and lost one of her front teeth.

10. As to the suspended sentence order, the applicant was in breach of an order imposed in August 2013 by his
failure to comply with the requirements of that order. Breach proceedings were commenced in 2013 and a warrant
was issued for the applicant's arrest. This remained outstanding until the applicant's arrest on the robbery matter.

11. In passing sentence, the judge said in relation to the robbery that it involved high culpability because of the use
by the applicant of very significant force against two women. Although there was no finding of serious physical or
psychological harm caused to either of them, for Ms Owen to lose a front tooth was nevertheless a significant injury
and the effect on each woman was significant. The case started therefore in Category 2A of the guideline with a
starting point of five years, but with an upward adjustment within the category for the significance of Ms Owen's
injury.

12. The judge identified eight different aggravating features. First, the high value of goods which were targeted as
the applicant wanted the contents of the safe. Secondly, the violence involved in attacking two victims. Thirdly, the
significant planning demonstrated by the applicant's waiting in the casino so that there were few people around.
Fourthly, the applicant targeted women who were vulnerable employees at the time, because it was the early hours
of the morning and few people were present. Fifthly, it was a persistent offence, prolonged over time. Sixthly, the
applicant restrained Ms Hewitt by tying her hands. Seventhly, the applicant had a leading role in the two-man
operation because although the other man was outside at the relevant time the judge was satisfied that he was the
applicant's accomplice. Eighthly, the applicant had a significant record of previous convictions.

13. In mitigation, the applicant had taken steps to get off drugs whilst in prison, but the judge said that he could not

give much weight to this because the offending was so serious. Apart from the impact of the Covid‑19 restrictions

when serving a prison sentence, for which some reduction was to be made, the judge considered that there was no
other mitigation. The aggravating features were so significant, even balanced against the mitigating features, that it
was necessary to impose a sentence outside the Category 2A range.

14. In relation to the extent of credit for the applicant's guilty plea, the judge said that in the Magistrates' Court he
had given what, at the time, appeared to be an unequivocal indication that he would plead guilty. When his case
went to the Crown Court in March 2020, he did not plead guilty but raised for the first time that he had been a victim
of modern slavery or forced criminality. When he next appeared in June 2020, he pleaded guilty because it was
then realised that even if his claims were true, they did not provide a defence to robbery or burglary. However, the
judge said that the applicant had continued to insist that he had been such a victim and hoped it would be a
significant mitigating feature.


-----

15. The case came back in September 2020 but the investigation by the Single Competent Authority was
incomplete and the matter was relisted for a Newton hearing for that issue to be determined, if necessary in the
absence of a report. The hearing was abandoned on the day in the light of the Single Competent Authority's report
– which had been filed the day before - which had decided that there were no conclusive grounds for considering
that the applicant had been the victim of modern slavery. The judge said that the delay caused by the applicant's
false claims was eight months and that several court hearings which were unnecessary had taken place. The

reduction for guilty plea would therefore not be one of the full one‑third because of the way matters had proceeded

by reason of the applicant's instructions to his legal advisers. The judge then reduced the sentence on each
robbery offence from nine years to seven years in order to give credit for plea, and ordered the two sentences to
run concurrently. The judge said that the burglary offence fell into Category 2 with a starting point of one year's
custody. The applicant's previous convictions for burglary made the offending more serious. The sentence of 18
months before plea was reduced to 14 months to give credit for plea, and the same principles concerning reduction
for guilty plea were applied to the burglary as to the robberies. The judge said that he had considered totality and
although consecutive sentences would be justified because there were different victims, as the applicant fell to be
dealt with for the breach of a suspended sentence, the sentence for the burglary should be made concurrent.

16. In 2013 the applicant had been made the subject of a suspended sentence of two years. Having carried out
one or two initial appointments he made no attempt whatsoever to carry out any of the sentence. He simply left the
address he was at and went back to Slovakia. The Judge said that there was nothing in the applicant's background
which would suggest that he had strong personal mitigation or any realistic prospect of rehabilitation; it was quite
the contrary. There was nothing in all the circumstances which made it unjust to activate that sentence. The
requirement was therefore to activate the original term in full. Totality had also been considered when making that
sentence consecutive.

17. In his helpful, clear and very carefully prepared submissions, Mr Donoghue, who appeared before us pro bono,
submitted that there are two bases on which it is arguable that the sentences imposed by the judge were manifestly
excessive or wrong in principle. The first of the grounds was that the sentence of nine years before credit for guilty
plea in respect of the robbery offences was disproportionate considering the facts of the case, the applicable
sentencing guidelines and other relevant aggravating and mitigating factors. In particular, he submitted that the
judge should not have gone outside the sentencing range for Category 2A offences in the 'Robbery - street and less
sophisticated commercial' guideline, or that even if he had regarded it as a Category 2A offence it should have
been treated as at the bottom of the range of seven to 12 years.

18. We do not consider that this is arguable. The judge was fully entitled to go outside the range for a Category 2A
offence, not least because he was imposing sentences for two offences of robbery and making them concurrent.
The other aggravating factors which the judge identified were also significant. The single judge said of this ground:

"The Sentencing Guidelines state that aggravating features may make it appropriate for the judge to move outside
the identified category range. In your case, the judge identified 8 aggravating features in his sentencing remarks.
These fully justified the decision to go beyond the sentencing range for Category 2A. This was a brutal robbery, in
which you played a leading role, which was planned to attack two women in the middle of the night when there

would be no‑one else around. The ordeal lasted for 20 minutes or so, during which you tied up one of your victims

and hit one in the head. You hoped to obtain a large sum from the casino's safe.

The judge was entitled to take the view that the only substantial mitigation was the impact of Covid‑19 whilst you

are in prison. He took account of this... "

19. We entirely agree with that assessment by the single judge.

20. The second ground put forward by Mr Donoghue is that the judge was wrong not to have afforded the applicant

a full discount for plea of one‑third. As to this, the single judge said:


-----

"The judge dealt with the sequence of events in his sentencing remarks ... The Single Competent Authority decided
that there were no conclusive grounds, and you abandoned your attempt to seek a Newton Hearing to persuade the
judge that you had indeed been the victim of modern slavery. In those circumstances, the judge was entitled to
take the view that you had no valid reason for delaying pleading guilty. As the judge said, the postponement of the
guilty pleas and then the delay in sentencing was caused by your false claims of modern slavery. He still gave you
a discount of over 20%.

21. Again, we agree with the single judge. It is not correct to say that the applicant's credit for plea was reduced.
He was given credit appropriate for when the plea was entered. The postponement of the applicant's guilty pleas
was due to his raising an issue as to his having been the victim of modern slavery which has not been made out
and was ultimately abandoned without a Newton hearing.

22. We thus do not consider that it is arguable that the sentences imposed were either manifestly excessive or
wrong in principle and this renewed application is refused.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

