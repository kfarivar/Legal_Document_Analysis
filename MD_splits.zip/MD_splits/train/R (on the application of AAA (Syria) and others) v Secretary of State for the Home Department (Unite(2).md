High Commissioner for Refugees intervening) and ot....

# R (on the application of AAA (Syria) and others) v Secretary of State for the
 Home Department (United Nations High Commissioner for Refugees
 intervening) and other appeals [2023] 4 All ER 253

[2023] EWCA Civ 745

COURT OF APPEAL, CIVIL DIVISION

LORD BURNETT CJ, SIR GEOFFREY VOS MR AND UNDERHILL VP

24–27 APRIL, 29 JUNE 2023

**Immigration — Asylum seeker — Removal from United Kingdom to state of which person not national or**
**citizen — Prohibition of torture, inhuman or degrading treatment or punishment — Claimants challenging**
**government policy proposing to relocate some asylum seekers to Rwanda — Whether policy lawful —**
**Asylum and Immigration Appeals Act 1993, s 2 — Human Rights Act 1998, Sch 1, Pt I, art 3 — Asylum and**
**Immigration (Treatment of Claimants, etc) Act 2004, Sch 3, para 17 — Immigration and Social Security Co-**
**ordination (EU Withdrawal) Act 2020, Sch 1, para 6 — Immigration Rules, paras 345A — 345D — Council**
**Directive 2005/85/EC, arts 25, 27 — United Nations Convention relating to the Status of Refugees 1951, arts**
**31, 33.**

In April 2022, the United Kingdom government announced the Migration and Economic Development Partnership
('MEDP') with Rwanda under which it was proposed that some people entering the United Kingdom illegally would
be relocated to Rwanda. Under the MEDP, Rwanda made a number of guarantees and assurances as to how
asylum seekers would be treated and processed. The individual claimants were asylum seekers who had arrived
irregularly by boat across the English Channel. In exercise of her powers under paras 345A–345D[a] of the
Immigration Rules, the respondent Secretary of State for the Home Department declared their asylum claims to be
inadmissible, intending that they be removed to Rwanda, as a 'safe third country' under para 345B. The individual
claimants brought judicial review proceedings challenging the government's policy. At the heart of the claims was
the proposition that it would be unlawful to remove anyone to Rwanda because there were 'substantial grounds for
believing that they would be at real risk' of treatment in Rwanda contrary to art 3[b] of the European Convention on
Human Rights (as set out in Sch 1 to the Human Rights Act 1998). The claimants' case that the Rwanda system
was seriously defective was supported by evidence of the United Nations High Commission for Refugees
('UNHCR') as intervener. The charity Asylum Aid also brought judicial review proceedings

1

seeking to challenge the procedures and arrangements surrounding the decision making and proposed removals as
unfair and thus unlawful. The Divisional Court, in essence, rejected all the generic challenges to the policy. The
claimants appealed. They contended that the Divisional Court had adopted the wrong tests, concentrating too much
on whether the Secretary of State had been 'entitled' to reach the conclusions she had about the safety of Rwanda

a Paragraphs 345A–345D, so far as material are set out at [33], below.

b Article 3 is set out at [2], below.

**[*254]**


-----

High Commissioner for Refugees intervening) and ot....

(a domestic public law approach). In particular, they submitted that the Divisional Court had failed properly to apply
the test set out in Soering v UK (App no 14038/88) (1989) 11 EHRR 439 ('the Soering test') by asking, as it should
have done, whether there were substantial grounds for believing that the asylum seekers sent to Rwanda would
face real risks of art 3 mistreatment; and that, in doing so, had failed to properly consider and assess the quality of
the guarantees and assurances given by the Rwandan government. It was common ground between the parties
that the central issue as to the safety of Rwanda was whether, bearing in mind the guarantees and assurances that
the government of Rwanda had given to the UK government, there were no substantial grounds for thinking that: (a)
Rwanda was not a safe third country, (b) there were real risks of refoulement or breaches of art 3, and (c) there
were real risks that asylum claims would not be properly and fairly determined in Rwanda. The claimants also
contended, inter alia, that the Divisional Court ought to have concluded that removal of asylum seekers to Rwanda
under the MEDP was inconsistent with art 33[c] of the United Nations Convention relating to the Status of Refugees
1951 ('the Refugee Convention'), and/or constituted the imposition of a 'penalty' contrary to art 31[d] of the
Convention and was, therefore, a breach of _[s 2[e] of the Asylum and Immigration Appeals Act 1993; that the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YH0-TWPY-Y01J-00000-00&context=1519360)_
Secretary of State had unlawfully certified Rwanda as safe for individuals under para 17(c)[f] of Pt 5 of Sch 3 to the
Asylum and Immigration (Treatment of Claimants, etc) Act 2004; and that _[arts 25[g] and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9RF3-GXFD-80K6-00000-00&context=1519360)_ _[27 of Council Directive](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9RF3-GXFD-80K8-00000-00&context=1519360)_
2005/85/EC ('the Procedures Directive') made the MEDP unlawful because they were still retained EU law. The
Secretary of State did not challenge the proposition that para 345C of the Immigration Rules was inconsistent with
the requirements of art 27(2)(a) of the Directive. However, it was her case that those requirements no longer formed
part of UK law, relying on the effect of para 6(1)[h] of Sch 1 to the Immigration and Social Security Co-ordination (EU
Withdrawal) Act 2020.

**Held** – (1) (Lord Burnett CJ dissenting) The Divisional Court had not universally applied the correct test to the
issues relating to the safety of Rwanda. The application of the _Soering test required the court to decide whether_
there were substantial grounds for believing that the asylum seekers sent to Rwanda would face real risks of art 3
mistreatment. In the present case, the Divisional Court had only considered the Soering test in relation to conditions
in Rwanda generally. In relation to other matters, such as the asylum system in Rwanda and the likelihood of the
Rwandan government's

2

assurances being realised, it had asked itself whether the Secretary of State had been 'entitled' to reach the
conclusions she had. The Soering question required the court to reach its own conclusion. Accordingly, it fell to the
present court to consider the safety of Rwanda issues afresh. In deciding those issues, special regard had to be
paid by the court to the views of the UNHCR on the grounds of special expertise and the fact that the subject matter
was within its remit. In all the circumstances, there were substantial grounds for thinking, bearing in mind the
guarantees and assurances, that Rwanda was not a safe third country, there were real risks of refoulement or art 3
breaches, and there were real risks that asylum claims would not be properly determined. Inter alia, the UNHCR
evidence clearly showed that there were important respects in which Rwanda had not so far reliably operated its
asylum process to international standards. The appeals would accordingly be allowed on that basis (see [13], [73],

[75]–[79], [84], [87], [88], [91], [92], [105], [109], [119], [129], [144], [261]–[265], [270]–[273], [293], [294], below);
_Soering v UK (App no 14038/88) (1989) 11 EHRR 439 applied._

c Article 33 is set out at [308], below.

d Article 31 is set out at [308], below.

e Section 2 is set out at [304], below.

f Paragraph 17, so far as material, is set out at [34], below.

g Articles 25 and 27, so far as material, are set out at [312], below.

h Paragraph 6, so far as material, is set out at [348], below.

**[*255]**


-----

High Commissioner for Refugees intervening) and ot....

(2) It was settled law that the Refugee Convention did not prohibit a receiving state from declining to entertain an
asylum claim where it could and would remove the claimant to another non-persecutory state. The straightforward
question, so far as the Convention was concerned, was whether the third country was safe for the applicant in the
sense that there was no real risk of their being refouled (directly or indirectly). Nor could any limitations be implied
on the state's right to take into account, when deciding whether to remove an asylum-seeker to a safe third country,
the fact that they arrived in the UK irregularly, even in circumstances where there was no regular means to do so, or
that their removal might have a deterrent effect. The state's motivation was irrelevant to the object and purpose of
the Convention: if the asylum-seeker would not face persecution or refoulement in the country to which they were
returned they would have received the protection which the Convention was intended to afford them. Further, the
removal of an asylum-seeker to a safe third country without their claim being determined was not in itself a penalty.
Whilst the term 'penalty' was not confined to sanctions of a criminal character, it was inconsistent with the wellrecognised scheme of the Convention that the expulsion of a migrant to a safe third country should be treated as a
penalty within the meaning of art 31(1), whatever the reasons for taking that course might be and however
unwelcome it might be to the migrant in question. The ground of appeal in respect of the Refugee Convention would
therefore be rejected (see [14], [118], [316], [319]–[321], [323], [326], [327]–[330], [338], [478], [527], below); dicta
of Lord Bridge in _Bugdaycay v Secretary of State for the Home Dept_ _[[1987] 1 All ER 940 at 952applied;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60HF-00000-00&context=1519360)_ _B010 v_
_[Canada (Citizen and Immigration) (2015) 41 BHRC 653 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N0T-C3G1-DYBP-W1MS-00000-00&context=1519360)_

(3) The Secretary of State could not be regarded as circumventing Parliament's intention by choosing in the present
cases to make use of her individual certification powers under Pt 5 rather than seeking to have Rwanda listed as a
generally safe country under Pt 3 or 4 of the Asylum and Immigration (Treatment of Claimants, etc) Act 2004. The
provisions of the various parts of the 2004 Act offered different possible mechanisms for limiting claimants' rights to
challenge safe third country decisions. Each mechanism would to some extent involve the Secretary of State
making a general assessment of matters relevant to the safety of the country in question, and to that extent there
was a degree of overlap between them. Nevertheless, each
**[*256]**

had its different characteristics and its different advantages and disadvantages. There was no basis for implying
into the statute an obligation to use the Pts 2–4 mechanism in every case. That ground of appeal would also
therefore be rejected (see [14], [118], [374]–[377], [478], [527], below).

(4) On a straightforward reading of the statutory language, paras 345A–345D of the Immigration Rules were
['provisions made … under the Immigration Acts', with the consequence that para 6(1) of the Immigration and Social](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:619H-Y6C3-CGXG-019X-00000-00&context=1519360)
_[Security Co-ordination (EU Withdrawal) Act 2020 had effect to disapply any inconsistent provision of retained EU](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:619H-Y6C3-CGXG-019X-00000-00&context=1519360)_
law, and there was nothing in the other provisions of the Act to suggest a legislative purpose that would justify
departing from the literal language of para 6(1). It was not, moreover, possible to draw any inference about the
intended scope of para 6(1) from what was or was not said in the Explanatory Notes or other Parliamentary
materials. It was necessary simply to apply the statutory language, which on its natural meaning applied to any
provision made under the Immigration Rules (see [14], [358], [359], [363], [366], [367], [527], below); dicta of Lord
Hodge in R (on the application of Project for the Registration of Children as British Citizens) v Secretary of State for
_[the Home [2022] 4 All ER 95 at [29]–[31] applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66FN-DF43-GXF6-800M-00000-00&context=1519360)_

(5) Whilst the court did not accept all aspects of the reasoning of the Divisional Court on the issue of whether the
decision-making process was inherently unfair, the determinative ground from the point of view of the fairness of the
process was the ground relating to the 7-day period for claimants to prepare representations. In all the
circumstances, the 7-day period specified in the notice of intent did not render the decision-making process
'structurally unfair and unjust'. Since, accordingly, that ground would be dismissed, the Divisional Court had been
right to reject Asylum Aid's claim of inherent unfairness (see [14], [118], [421], [424], [429], [430], [440]–[445], [455],

[527], below); R (on the application of Refugee Legal Centre) v Secretary of State for the Home Dept [2005] INLR
236 applied.

[Decision of the Divisional Court [2022] All ER (D) 59 (Dec) reversed in part.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6748-KD53-GXF6-82PV-00000-00&context=1519360)
**Notes**


-----

High Commissioner for Refugees intervening) and ot....

For the grant and refusal of refugee status or humanitarian protection: safe third countries and inadmissible
applications for asylum generally, see Halsbury's Laws IMMIGRATION AND ASYLUM vol 57A (2023) paras 409–
411.

[For the Asylum and Immigration Appeals Act 1993, s 2, see Halsbury's Statutes vol 31 (2021 reissue) 332.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YH0-TWPY-Y01J-00000-00&context=1519360)

[For the Human Rights Act 1998, Sch 1, Pt I, art 3, see Halsbury's Statutes vol 7(1) (2022 reissue) 890.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0GT-00000-00&context=1519360)

For the Asylum and Immigration (Treatment of Claimants, etc) Act 2004, Sch 3, para 17, see Halsbury's Statutes
vol 31 (2021 reissue) 770.
**Cases referred to**

_Akayesu ICTR-96–04 (2 September 1998), ICTR._

_[AS (Afghanistan) v Secretary of State for the Home Dept [2021] EWCA Civ 195.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:621K-TH23-GXFD-83SK-00000-00&context=1519360)_

_[B010 v Canada (Citizen and Immigration) 2015 SCC 58, (2015) 41 BHRC 653, [2015] 3 SCR 704, Can SC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N0T-C3G1-DYBP-W1MS-00000-00&context=1519360)_

_[Brown v Stott (Procurator Fiscal, Dunfermline) [2001] 2 All ER 97, [2003] 1 AC 681, (2000) 11 BHRC 179, [2001] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-6129-00000-00&context=1519360)_
WLR 817, PC.
**[*257]**

_[Bugdaycay v Secretary of State for the Home Dept [1987] 1 All ER 940, [1987] AC 514, [1987] LRC (Const) 301,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60HF-00000-00&context=1519360)_

[1987] 2 WLR 606, HL.

_[Chahal v UK (App no 22414/93) (1996) 1 BHRC 405, (1997) 23 EHRR 413, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3X3-00000-00&context=1519360)_

_[Data Protection Comr v Facebook Ireland Ltd (USA intervening) (Case C-311/18) EU:C:2020:559, [2021] 1 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:627S-7YT3-GXFD-8186-00000-00&context=1519360)_
_[(Comm) 507, [2021] 1 WLR 751, ECJ.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:627S-7YT3-GXFD-8186-00000-00&context=1519360)_

_DB v Chief Constable of Police Service of Northern Ireland_ _[[2017] UKSC 7, [2017] NI 301, [2017] 3 LRC 252.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RJF-8GD1-DYMJ-244W-00000-00&context=1519360)_

_Doody v Secretary of State for the Home Dept_ _[[1993] 3 All ER 92, [1994] 1 AC 531, [1993] 3 LRC 428, [1993] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60GY-00000-00&context=1519360)_
WLR 154, HL.

_EN (Serbia) v Secretary of State for the Home Dept, Secretary of State for the Home Dept v KC (South Africa)_

_[2009] EWCA Civ 630, [2009] INLR 459, [2010] QB 633, [2010] 3 WLR 182._

_European Roma Rights Centre v Immigration Officer at Prague Airport (United Nations High Comr for Refugees_
_[intervening) [2004] UKHL 55, [2005] 1 All ER 527, [2005] 2 AC 1, (2004) 18 BHRC 1, [2005] 2 WLR 1.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FGH-JVK0-TWP1-609F-00000-00&context=1519360)_

_G v G (Secretary of State for the Home Dept intervening) [2021] UKSC 9,_ _[[2021] 4 All ER 113, [2022] AC 544,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63P2-CP93-GXF6-82WP-00000-00&context=1519360)_

_[[2021] 2 FLR 536, [2021] 2 WLR 705.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63CX-Y1G3-CGXG-01C9-00000-00&context=1519360)_

_[Gillick v West Norfolk and Wisbech Area Health Authority [1985] 3 All ER 402, [1986] AC 112, [1986] 1 FLR 224,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-607K-00000-00&context=1519360)_

[1985] 3 WLR 830, HL.

_Govt of Rwanda v Nteziryayo_ _[[2017] EWHC 1912 (Admin), [2017] All ER (D) 203 (Jul), DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P4T-VGF1-DYBP-N46G-00000-00&context=1519360)_

_[H (A Child) (Disclosure of Asylum Documents), Re [2020] EWCA Civ 1001, [2021] 1 FLR 586.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:624B-PS33-GXFD-8198-00000-00&context=1519360)_

_HF (Iraq) v Secretary of State for the Home Dept, MK (Iraq) v Secretary of State for the Home Dept [2013] EWCA_
_[Civ 1276, [2014] 1 WLR 1329, [2013] All ER (D) 275 (Oct).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59NC-V051-DYBP-N4DT-00000-00&context=1519360)_


-----

High Commissioner for Refugees intervening) and ot....

_HJ (Iran) v Secretary of State for the Home Dept, HT (Cameroon) v Secretary of State for the Home Dept [2010]_
_[UKSC 31, [2011] 2 All ER 591, [2011] 1 AC 596, (2010) 29 BHRC 90, [2010] 3 WLR 386.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52X0-KRC1-DYBP-M3DB-00000-00&context=1519360)_

_[Ilias v Hungary (App no 47287/15) (2019) 47 BHRC 497, (2020) 71 EHRR 6, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y49-BT73-GXFD-8139-00000-00&context=1519360)_

_MSS v Belgium and Greece (App no 30696/09)_ _[(2011) 31 BHRC 313, (2011) 53 EHRR 28, [2011] INLR 533,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W32M-00000-00&context=1519360)_
ECtHR.

_NA (Sudan) v Secretary of State for the Home Dept, MR (Iran) v Secretary of State for the Home Dept_ _[2016]_
_[EWCA Civ 1060, [2017] 3 All ER 885.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P8M-7XD1-DYBP-M3KD-00000-00&context=1519360)_

_[NA v UK (App no 25904/07) (2009) 48 EHRR 337, [2008] All ER (D) 298 (Jul), ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T24-98J0-TWP1-71KH-00000-00&context=1519360)_

_[Othman (Abu Qatada) v UK (App no 8139/09) (2012) 32 BHRC 62, (2012) 55 EHRR 1, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1MB-00000-00&context=1519360)_

_R (on the application of A) v Secretary of State for the Home Dept_ _[[2021] UKSC 37, [2022] 1 All ER 177, [2021] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HY-3H43-GXF6-833F-00000-00&context=1519360)_
WLR 3931.

_R (on the application of Balajigari) v Secretary of State for the Home Dept_ _[[2019] EWCA Civ 673, [2019] 4 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XJR-HW73-GXFD-830J-00000-00&context=1519360)_
_[998, [2019] 1 WLR 4647, [2019] INLR 619.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XJR-HW73-GXFD-830J-00000-00&context=1519360)_

_R (on the application of Begum) v Special Immigration Appeals Commission, R (on the application of Begum) v_
_Secretary of State for the Home Dept, Begum v Secretary of State for the Home Dept_ _[[2021] UKSC 7, [2021] 2 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62V6-0DF3-GXFD-852C-00000-00&context=1519360)_
_[ER 1063, [2021] AC 765, [2021] INLR 316, [2021] 2 WLR 556.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62V6-0DF3-GXFD-852C-00000-00&context=1519360)_

_R (on the application of Campaign Against Arms Trade) v Secretary of State for International Trade (Amnesty_
_International intervening)_ _[[2019] EWCA Civ 1020, [2019] 1 WLR 5765, [2019] All ER (D) 146 (Jun).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VV7-8352-D6MY-P07S-00000-00&context=1519360)_
**[*258]**

_R (on the application of Detention Action) v First-tier Tribunal (Immigration and Asylum Chamber) [2015] EWCA Civ_
_[840, [2016] 3 All ER 626, [2015] 1 WLR 5341, [2016] INLR 79.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KBH-RH61-DYBP-M40J-00000-00&context=1519360)_

_R (on the application of EM (Eritrea)) v Secretary of State for the Home Dept_ _[[2014] UKSC 12, [2014] 2 All ER 192,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-CYX1-DYBP-M26P-00000-00&context=1519360)_

[2014] AC 1321, [2014] INLR 635, [2014] 2 WLR 409.

_R (on the application of Friends of the Earth Ltd) v Secretary of State for International Trade/UK Export Finance_
_(UKEF)_ _[[2023] EWCA Civ 14, [2023] All ER (D) 70 (Jan).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67F7-C4X3-RRK4-X006-00000-00&context=1519360)_

_R (on the application of Munjaz) v Mersey Care NHS Trust_ _[[2005] UKHL 58, [2006] 4 All ER 736, [2006] 2 AC 148,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MBK-0BW0-TWP1-60YS-00000-00&context=1519360)_
[(2005) 86 BMLR 84, [2005] 3 WLR 793.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4KW5-G3W0-TWW8-X1BF-00000-00&context=1519360)

_R (on the application of Plantagenet Alliance Ltd) v Secretary of State for Justice_ _[2014] EWHC 1662 (Admin),_

_[[2015] 3 All ER 261, [2015] LGR 172, DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G9F-G361-DYBP-M106-00000-00&context=1519360)_

_R (on the application of Project for the Registration of Children as British Citizens) v Secretary of State for the Home_
_Dept_ _[[2022] UKSC 3, [2022] 4 All ER 95, [2023] AC 255, [2022] INLR 189, [2022] 2 WLR 343.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66FN-DF43-GXF6-800M-00000-00&context=1519360)_

_R (on the application of Refugee Legal Centre) v Secretary of State for the Home Dept_ _[2004] EWCA Civ 1481,_

[2005] INLR 236, [2005] 1 WLR 2219.

_[R (on the application of Tabrizagh) v Secretary of State for the Home Dept [2014] EWCA Civ 1398.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DG8-5KD1-F0JY-C3Y6-00000-00&context=1519360)_

_R (on the application of Westminster City Council) v National Asylum Support Service_ _[[2002] UKHL 38, [2002] 4 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-60GY-00000-00&context=1519360)_
_[ER 654 [2002] 1 WLR 2956 [2003] LGR 23 [2002] HLR 1021](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-60GY-00000-00&context=1519360)_


-----

High Commissioner for Refugees intervening) and ot....

_R (on the application of Yogathas) v Secretary of State for the Home Dept, R (on the application of Thangarasa) v_
_Secretary of State for the Home Dept_ _[[2002] UKHL 36, [2002] 4 All ER 800, [2003] 1 AC 920, (2002) 14 BHRC 185,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-611N-00000-00&context=1519360)_

[2002] 3 WLR 1276.

_R (on the application of Z) v Hackney London BC_ _[[2020] UKSC 40, [2021] 2 All ER 539, [2020] 1 WLR 4327, [2020]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62JR-7BC3-CGXG-0027-00000-00&context=1519360)_
PTSR 1830.

_R v Asfaw_ _[[2008] UKHL 31, [2008] 3 All ER 775, [2008] 1 AC 1061, (2008) 25 BHRC 87, [2008] 2 WLR 1178.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T66-GVT0-TWP1-606B-00000-00&context=1519360)_

_Robinson (Jamaica) v Secretary of State for the Home Dept_ _[[2020] UKSC 53, [2021] 2 All ER 429, [2022] AC 659,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62H6-VPS3-GXFD-8450-00000-00&context=1519360)_

[2021] INLR 201, [2021] 2 WLR 65.

_Ruiz Zambrano v Office National de l'Emploi (ONEm)_ (Case _C-34/09) EU:C:2011:124,_ _[[2011] All ER (EC) 491,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52V8-NRC1-DYBP-K235-00000-00&context=1519360)_

[2012] QB 265, [2011] INLR 481, [2012] 2 WLR 866, ECJ.

_[Saadi v Italy (App no 37201/06) (2008) 24 BHRC 123, (2009) 49 EHRR 730, [2008] INLR 621, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2RY-00000-00&context=1519360)_

_Sagitta v Ministry of Interior (Administrative Appeal 8101/15), Israel SC._

_Schrems v Data Protection Comr (Case C-362/14) EU:C:2015:650, [2016] QB 527, [2016] 2 WLR 873, ECJ._

_Secretary of State for Education and Science v Metropolitan Borough of Tameside_ _[[1976] 3 All ER 665, [1977] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD8-PGP0-TWP1-612D-00000-00&context=1519360)_
1014, [1976] 3 WLR 641, HL.

_Secretary of State for the Home Dept v Rehman_ _[[2001] UKHL 47, [2002] 1 All ER 122, [2003] AC 153, (2001) 11](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61NX-00000-00&context=1519360)_
_[BHRC 413, [2001] 3 WLR 877.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4NM-00000-00&context=1519360)_

_[Secretary of State for the Home Dept v Thirukumar [1989] Imm AR 402, (1988) Times, 27 December, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PN7-K4N0-TXX5-50DY-00000-00&context=1519360)_

_[Soering v UK (App no 14038/88) (1989) 11 EHRR 439, [1989] ECHR 14038/88, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)_

_Sufi v UK (App nos 8319/07 and 11449/07) (2012) 54 EHRR 209, [2011] ECHR 8319/07, ECtHR._
**[*259]**
**Appeals**

In a number of appeals, the claimants, (1) AAA (Syria), AHA (Syria), AT (Iran), AAM (Syria) and NSK (Iraq), (2)
HTN (Vietnam), (3) RM (Iran), (4) ASM (Iraq), (5) AS (Iran), (6) SAA (Sudan) and (7) Asylum Aid, appealed against
the decision of the Divisional Court (Lewis LJ and Swift J) of 19 December 2022 ([2022] EWHC 3230 (Admin),

_[[2022] All ER (D) 59 (Dec)), rejecting, in essence, their claims for judicial review challenging the policy of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6748-KD53-GXF6-82PV-00000-00&context=1519360)_
respondent, the Secretary of State for the Home Department, to relocate certain asylum seekers to Rwanda,
pursuant to the Migration and Economic Development Partnership with Rwanda. The United Nations High
Commissioner for Refugees appeared as intervener ('the first intervener') in the first to fifth and seventh appeals. In
the seventh appeal, Freedom from Torture and the United Nations Special Rapporteur on Trafficking in Persons,
Especially Women and Children, appeared as second and third intervener respectively. The facts are set out in the
judgment of Sir Geoffrey Vos MR.

_Raza Husain KC, Phillippa Kaufmann KC, Sam Grodzinski KC, Christopher Knight, Paul Luckhurst, Tim Johnston,_
_Jason Pobjoy, Emma Mockford, Anirudh Mathur, Allan Cerim, Emmeline Plews, Will Bordell and Rayan Fakhoury_
(instructed by Duncan Lewis Solicitors) for the claimants in the first and second appeals.

_Richard Drabble KC, Alasdair Mackenzie, David Sellwood and Rosa Polaschek (instructed by Wilsons Solicitors_
_LLP) for the claimant in the third appeal._

_Richard Drabble KC, Leonie Hirst and Angelina Nicolaou (instructed by Wilsons Solicitors LLP) for the claimant in_
the fourth appeal.


-----

High Commissioner for Refugees intervening) and ot....

_Sonali Naik KC, Adrian Berry, Mark Symes, Eva Doerr and Isaac Ricca-Richardson (instructed by Barnes Harrild &_
_Dyer) for the claimant in the fifth appeal._

_Manjit S Gill KC, Ramby de Mello, Tony Muman and Harjot Singh (solicitor advocate) (instructed by Twinwood Law_
_Practice) for the claimant in the sixth appeal._

_Charlotte Kilroy KC, Michelle Knorr and Sarah Dobbie (instructed by Leigh Day) for the claimant in the seventh_
appeal.

_Lord Pannick KC, Sir James Eadie KC, Neil Sheldon KC, Edward Brown KC, Mark Vinall, Jack Anderson, Sian_
_Reeves, Robin Hopkins and Natasha Barnes (instructed by the Government Legal Department) for the Secretary of_
State.

_Angus McCullough KC, Laura Dubinsky KC, David Chirico, Jennifer MacLeod, Agata Patyna, Aarushi Sahore and_
_Joshua Pemberton (instructed by Baker McKenzie LLP) for the first intervener._

_Tim Buley KC, Nikolaus Grubeck and Julianne Kerr Morrison (instructed by Freshfields Bruckhaus Deringer LLP)_
for the second intervener (written submissions only).

_Adam Straw KC, Catherine Meredith, Zoe Harper and Michael Spencer (instructed by Allen & Overy LLP) for the_
third intervener (written submissions only).

_Judgment was reserved._

29 June 2023. The following judgments were delivered.

**TABLE OF CONTENTS**
**THE MASTER OF THE ROLLS** **[1]–[119]**

**Essential factual background** [16]–[28]

**Essential legal background** [29]–[34]

Authorities [29]–[32]

**[*260]**

Relevant immigration rules [33]–[34]

**The reasoning of the Divisional Court** [35]–[52]

(i) Thorough examination and reasonable inquiries [40]–[44]

(ii) Adequacy of asylum system [45]–[47]

(iii) The Gillick issue [48]

(iv) Conditions in Rwanda generally [49]–[52]

**The issues** [53]–[72]

The safety of Rwanda issues [57]–[67]

The remaining issues [68]–[72]

**Discussion of the issues** [73]–[118]

**Conclusions** [119]

**LORD JUSTICE UNDERHILL** **[120]–[455]**

**Introduction** [120]

**A. Safety of Rwanda** **[121]–[302]**

The Background Law [121]–[125]

The Shape of the Case [126]–[132]

The Rwandan Asylum System [133]–[144]

Criticisms of Particular Stages of the Process [145]–[223]

Access to the RSD Process [145]–[157]

Stage (1): DGIE [158]–[174]

Stage (2): Eligibility Officer [175]–[180]


-----

High Commissioner for Refugees intervening) and ot....

Stage (3): the RSDC [181]–[206]

Stage (4): Appeal to MINEMA [207]–[210]

Stage (5): Appeal to the High Court [211]–[223]

Criticisms Common to the System as a Whole [224]–[260]

Legal Assistance/Representation [224]–[240]

Interpreters [241]–[244]

Training [245]–[260]

Conclusion on the Adequacy of the Rwandan Asylum System [261]–[272]

Risk of Refoulement [273]–[286]

Article 3 Risks Other Than Refoulement [287]–[292]

Conclusion on the Safety of Rwanda Issue [293]–[295]

Issue 10: Gillick [296]–[301]

Issue 11: Certification [302]

**B. The Remaining Issues** **[303]–[457]**

Issue 12: Breach of the Refugee Convention [304]–[339]

Issue 13: Retained EU Law [340]–[367]

Issue 14: Circumvention of Schedule 3 to the 2004 Act [368]–[377]

Issue 15: Data Protection [378]–[400]

Issue 16: Procedural Fairness [401]–[455]

Introduction [401]–[402]

The Procedure [403]–[412]

The Grounds: Overview [413]–[416]

Ground 15: Scope of Representations [417]–[424]

Ground 16: Access to Legal Advice [425]–[430]

Ground 17: Seven Days [431]–[445]

Ground 18: Disclosure of Provisional Conclusions [446]–[450]

Ground 19: Access to Justice [451]–[453]

Ground 20: Construction of the Immigration Rules [454]

Conclusion on Asylum Aid's Appeal [455]

RM's Ground on Fairness [456]–[457]

**THE LORD CHIEF JUSTICE** **[458]–[527]**

**[*261]**

**The Issues on the Appeal** [477]

**Summary of Conclusions** [478]–[480]

**The Divisional Court's Judgment on the Article 3 and Allied Public Law Issues** [481]–[493]

**Safety of Rwanda: The asylum system and refoulement issue** [494]–[517]

**Safety of Rwanda: conditions in Rwanda** [518]–[520]

**The procedural questions** [521]–[524]

**Gillick** [525]–[526]

**Conclusion** [527]

**SIR GEOFFREY VOS MR.**

**[1] The Divisional Court (Lewis LJ and Swift J) decided, in essence, to reject all the generic challenges made in**
these proceedings to the policy of the Secretary of State for the Home Department ('SSHD') to relocate certain
[asylum seekers to Rwanda ([2022] EWHC 3230 (Admin), [2022] All ER (D) 59 (Dec)). The 10 individual appellants](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6748-KD53-GXF6-82PV-00000-00&context=1519360)
and Asylum Aid have been given permission to argue some 22 grounds of appeal in this court, and seek permission


-----

High Commissioner for Refugees intervening) and ot....

to argue one more. We have been provided with thousands of pages of documents and authorities and heard 4
days of concentrated argument.

**[2] Yet, at its foundation, the issue we have to decide is short. It is, at its most basic, whether the Divisional Court**
was right to decide, if that is what it did decide, one fairly straightforward issue, bearing in mind the guarantees and
assurances that the Government of Rwanda had given to the UK Government. The SSHD submits that the
Divisional Court decided, in effect, that there were no substantial grounds for thinking that: (a) Rwanda was not a
safe third country, (b) there were real risks of refoulement (asylum seekers being sent back to their home countries)
or breaches of art 3 ('art 3') of the European Convention on Human Rights ('ECHR'), and (c) there were real risks
that asylum claims would not be properly and fairly determined in Rwanda. The question is whether that was right.
There are, of course, other issues but that is the central one. Article 3 provides that '[n]o one shall be subjected to
torture or to inhuman or degrading treatment or punishment'.

**[3] On 14 April 2022, the then Prime Minister announced the Migration and Economic Development Partnership**
('MEDP') with Rwanda, which he said would mean that anyone entering the UK illegally might be relocated to
Rwanda. He said that '[t]he deal we have done is uncapped and Rwanda will have the capacity to resettle tens of
thousands of people in the years ahead'. The MEDP comprises a Memorandum of Understanding of 13 April 2022
('MoU') and three Notes Verbales. The MoU has an initial term of 5 years. The Notes Verbales disclosed in these
proceedings provide the guarantees of the Government of Rwanda regarding 'the asylum process of transferred
individuals', and 'the reception and accommodation of transferred individuals'.

**[4] The MEDP was developed to deter people from risking their lives in making dangerous journeys to the UK to**
claim asylum. These journeys are typically made by crossing the English Channel in small boats. They are often
facilitated by people smugglers and criminal gangs, to whom asylum seekers pay considerable sums of money. The
policy is a politically sensitive one which has attracted significant public and media attention. Notwithstanding that
position, the case must be determined on the basis of the evidence and of
**[*262]**

accepted and familiar principles of public law. Nothing in this judgment should be construed as supporting or
opposing any political view of the issues.

**[5] The appellants complain that the Divisional Court adopted the wrong tests, concentrating too much on whether**
the SSHD was entitled to reach the conclusions she did about the safety of Rwanda on the basis of four
assessment documents which she published on 9 May 2022. On the same day, the SSHD had published her
Inadmissibility Guidance to Home Office case workers outlining the powers available and the procedures to be
followed to declare asylum claims inadmissible and remove asylum claimants to safe third countries. In this context,
the appellants contend that the SSHD failed (a) to undertake a 'thorough examination' of 'all relevant generally
available information' as required by the principles explained by the European Court of Human Rights ('ECtHR') in
_[Ilias v Hungary (App no 47287/15) (2019) 47 BHRC 497, (2020) 71 EHRR 6 ('Ilias') at paras 137–141, and (b) to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y49-BT73-GXFD-8139-00000-00&context=1519360)_
ask herself the right question and take reasonable steps to acquaint herself with the relevant information to enable
her to answer it correctly as explained in Secretary of State for Education and Science v Metropolitan Borough of
_Tameside_ _[[1976] 3 All ER 665 at 695–696, [1977] AC 1014 at 1064–1065 ('Tameside'). Specifically, the appellants](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD8-PGP0-TWP1-612D-00000-00&context=1519360)_
submit that the SSHD took no or no proper account of (i) the fact that there was no independent judiciary in
Rwanda, (ii) the collapse of a similar scheme entered into between the State of Israel and Rwanda, (iii) the
Rwandan Government's misunderstanding of the meaning of refoulement, and (iv) 15 areas of inadequacy in
Rwanda's current asylum process identified by the United Nations High Commission for Refugees ('UNHCR'). The
appellants also contend that the Divisional Court failed properly to apply the test adumbrated in Soering v UK (App
no 14038/88) _[(1989) 11 EHRR 439,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)_ _[[1989] ECHR 14038/88 ('Soering') at para 88 by asking, as it should have](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)_
done, whether there were substantial grounds for believing that the asylum seekers sent to Rwanda would face real
risks of art 3 mistreatment. In doing so, they submit that the Divisional Court failed to consider the guarantees and
assurances given by the Rwandan Government in accordance with the principles established in _Othman (Abu_
_[Qatada) v UK (App no 8139/09) (2012) 32 BHRC 62, (2012) 55 EHRR 1 ('Othman') at paras 186–189. It failed, it is](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1MB-00000-00&context=1519360)_
said, to assess the quality of the assurances, and whether, in the light of Rwanda's existing practices those


-----

High Commissioner for Refugees intervening) and ot....

assurances could be relied upon, having regard to the 11 factors listed at para 189 in Othman, or equivalent factors
applicable in this case.

**[6] The UNHCR submitted that it had issued a rare unequivocal warning that there should be no transfers of asylum**
seekers to Rwanda, because of its clear view that the arrangement was incompatible with the UK's obligations
under the 1951 Convention relating to the Status of Refugees ('the Refugee Convention'). A Home Office
memorandum of 22 February 2022 recognised the UNHCR's expertise in relation to Rwanda. An 8 March 2022
Home Office email reported that the UNHCR was a critical part of assessing Rwanda's safety, and that Rwanda
depended heavily on the UNHCR for delivering its domestic asylum and refugee processes. Yet, the UNHCR
submits that it was not consulted on the final terms of the MEDP and not involved in the formulation of the
assurances given to the UK Government. The UNHCR submitted that _MSS v Belgium and Greece (App no_
[30696/09) (2011) 31 BHRC 313, (2011) 53 EHRR 28 ('MSS') at para 349, and Lord Kerr in R (on the application of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W32M-00000-00&context=1519360)
_EM (Eritrea)) v Secretary of State for the Home Dept_ _[[2014] UKSC 12, [2014] 2 All ER 192, [2014] AC 1321('EM](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-CYX1-DYBP-M26P-00000-00&context=1519360)_
_(Eritrea)') at [71]–[74], confirmed that_
**[*263]**

special regard should be paid to the views of the UNHCR where it has special expertise and the subject matter is
[within its remit (see also R (on the application of Tabrizagh) v Secretary of State for the Home Dept [2014] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DG8-5KD1-F0JY-C3Y6-00000-00&context=1519360)
_[Civ 1398 ('Tabrizagh') at [18]–[20]). That principle applied in this case.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DG8-5KD1-F0JY-C3Y6-00000-00&context=1519360)_

**[7] The UNHCR's institutional conclusion was as follows:**

'I believe that Rwanda's RSD [Refugee Status Determination] process is marked by acute unfairness and
arbitrariness, some of which is structurally inbuilt; and by serious safeguard and capacity shortfalls, some of
which can be remedied only by structural changes and long-term capacity building. I believe that asylum
seekers transferred to Rwanda are at serious risk of both direct and indirect refoulement and will not have
access to fair and efficient asylum procedures, adequate standards of treatment or durable solutions, in line
with the requirements set out in international refugee law.'

**[8] The UNHCR submitted that, unless a current evaluation of Rwanda's asylum system was irrelevant, the**
Divisional Court's judgment could not stand.

**[9] The SSHD submitted, in effect, that that was precisely the position. She said that the MoU and the** _Notes_
_Verbales did provide all the assurances that were required. There was no basis to doubt the good faith of the_
Rwandan Government's assurances. The Divisional Court had been right to conclude that _ex facie those_
assurances would be sufficient to avoid any risk of a breach of art 3. The MEDP was an entirely new arrangement.
The existing systems and past bad practices were irrelevant to an evaluation of the reliability of these new
assurances. The UK and Rwandan Governments had very strong vested interests in making the MEDP work in a
way that was lawful and complied with the Refugee Convention and with the ECHR. Rwanda was a sovereign state
signatory to the Refugee Convention, the 1984 United Nations Convention Against Torture and Other Cruel,
Inhuman or Degrading Treatment or Punishment ('UNCAT') and was a member of the Commonwealth. There was
no risk of refoulement where the Rwandan Government had specifically to consent in advance to each asylum
seeker being sent to Rwanda. Moreover, the scheme would be carefully and independently monitored by the Joint
Committee of the UK and Rwandan Governments and a Monitoring Committee comprised of people independent of
the two Governments and the UNHCR itself. If things went wrong, they would come to light. It was a scheme that
had been considered with unparalleled care and thoroughness by the UK Government. The fact finding by the
Divisional Court was to be respected by this court (see DB v Chief Constable of Police Service of Northern Ireland

_[[2017] UKSC 7, [2017] NI 301, [2017] 3 LRC 252 ('DB') at [78]–[80] per Lord Kerr and R (on the application of Z) v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RJF-8GD1-DYMJ-244W-00000-00&context=1519360)_
_Hackney London BC_ _[[2020] UKSC 40, [2021] 2 All ER 539, [2020] 1 WLR 4327('Hackney') per Lord Sales at [56],](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62JR-7BC3-CGXG-0027-00000-00&context=1519360)_

[67] and [74]).

**[10] The appellants also made a connected submission that the SSHD had unlawfully certified Rwanda as safe for**
individuals under para 17(c) of Pt 5 of Sch 3 to the Asylum and Immigration (Treatment of Claimants, etc) Act 2004
('the 2004 Act') The SSHD had it was argued created a presumption that Rwanda was safe in her assessment


-----

High Commissioner for Refugees intervening) and ot....

documents, and had, by certifying the asylum seeker's claim to be clearly unfounded under para 19(c) of Pt 5 of
Sch 3 to the 2004 Act, prevented them from appealing to the First-tier Tribunal
**[*264]**

(Immigration and Asylum), circumventing the statutory scheme. To make that certification, the SSHD had to form
the opinion under para 17(c) that Rwanda was a place where the person's life and liberty would not be threatened
by reason of his race, religion, nationality, membership of a particular social group or political opinion, and from
which the person would not be refouled. In the course of oral argument, the court asked whether that was a stricter
test than the one mentioned at [2] above, namely that there were no substantial grounds for thinking there were
[real risks of ECHR breaches in Rwanda. I will return to that point. I note at this stage that s 94 of the Nationality,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-748W-00000-00&context=1519360)
Immigration and Asylum Act 2002 allows the SSHD also to make that certification if she concludes under s 94(7)(b)
that there is no reason to believe that the person's rights under the ECHR would be breached in a third country.

**[11] The appellants also made four further main submissions that can be summarised as follows:**

(i)   Violation of the Refugee Convention: The Divisional Court ought to have concluded that removal of
asylum seekers to Rwanda under the MEDP was inconsistent with art 33 of the Refugee Convention ('art
33'), and/or constituted the imposition of a penalty contrary to art 31 of the Refugee Convention ('art 31')
and was, therefore, a breach of _[s 2 of the Asylum and Immigration Appeals Act 1993 ('the 1993 Act'),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YH0-TWPY-Y01J-00000-00&context=1519360)_
which provides that nothing in the Immigration Rules shall lay down any practice contrary to the Refugee
Convention.

(ii)   Violation of Retained EU Asylum law: The Divisional Court ought to have concluded that arts 25
and 27 ('art 27') of the _[Council Directive 2005/85/EC of 1 December 2005 on minimum standards on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9RF3-GXFD-80J9-00000-00&context=1519360)_
procedures in member states for granting and withdrawing refugee status ('the Procedures Directive')
made the MEDP unlawful because it required by art 27(2)(a) that there be a connection between the
person seeking asylum and the third country concerned on the basis of which it would be reasonable to
send that person there. The MEDP obviously envisaged sending to Rwanda asylum seekers with no such
prior connection. The Divisional Court had wrongly held, according to the appellants, that the Procedures
[Directive had ceased to be retained EU law under s 1 and Sch 1 to the Immigration and Social Security](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:619H-Y6C3-CGXG-019Y-00000-00&context=1519360)
Co-ordination (EU Withdrawal) Act 2020.

(iii)   Data Protection: The Divisional Court ought to have decided that the SSHD's alleged breaches of
the UK General Data Protection Regulation ('UK GDPR') would, if established, invalidate the SSHD's
decisions under the MEDP. This was the ground of appeal for which the appellants sought permission to
appeal from us.

(iv) **Procedural unfairness: The Divisional Court ought to have held that each of the three decisions**
taken by the SSHD in respect of every asylum seeker was rendered unlawful by procedural unfairness.
The three decisions were (a) to treat the asylum application as inadmissible under para 345A of the
Immigration Rules ('para 345A'); (b) to decide to remove the asylum seeker to Rwanda under para 345C of
the Immigration Rules ('para 345C'), having decided that Rwanda was a safe third country under para
345B of the Immigration Rules ('para 345B'); and (c) to make a certification decision under para 17(c) to
the effect that Rwanda was a safe country for the asylum seeker. The main allegations of procedural
unfairness relied upon were: (a) not allowing the asylum seeker to make

**[*265]**

general submissions as to the safety of Rwanda, (b) not providing sufficient access to lawyers, (c) allowing
the asylum seeker only 7 days to make representations, (d) failing to provide the asylum seeker with
provisional conclusions, and (e) allowing the asylum seeker only 5 days to apply to the court.

**[12] The SSHD submitted that each of these four submissions was unfounded and the Divisional Court had been**
right on each of them for the reasons it gave.

**[13] On the crucial safety of Rwanda issues, I have determined that:**


-----

High Commissioner for Refugees intervening) and ot....

(i)   The Divisional Court did not universally apply the correct test to the issues relating to the safety of
Rwanda.

(ii)   The Divisional Court ought to have asked itself whether or not there were substantial grounds for
thinking that: (a) Rwanda was not a safe third country, (b) there were real risks of refoulement or breaches
of art 3, and (c) there were real risks that asylum claims would not be properly and fairly determined in
Rwanda.

(iii)   Accordingly, it falls to this court to consider the 'safety of Rwanda issues' afresh. In deciding those
issues, special regard should be paid by the court to the views of the UNHCR on the grounds of its special
expertise and the fact that the subject matter is within its remit.

(iv)   On that basis there were substantial grounds for thinking that there were real risks that the asylum
seekers that the SSHD decided to send to Rwanda in May 2022 would be refouled or subject to breaches
of art 3, or that their asylum claims would not be properly or fairly determined in Rwanda.

(v)   There is, in these circumstances, no need to decide whether the SSHD breached either (a) her Ilias
duty to undertake a thorough examination of all relevant generally available information, or (b) her
_Tameside duty to ask herself the right questions and take reasonable steps to acquaint herself with the_
relevant information to enable her to answer them correctly.

(vi)   For the same reasons as those mentioned above, the SSHD's certification under para 19(c) was
unlawful, because the asylum seekers' ECHR claims were not clearly unfounded. It was at least arguable
that the asylum seekers' art 3 rights would be infringed and that they might be refouled. They ought,
therefore, anyway to have been given an opportunity to raise such claims in the usual way through the
First-tier Tribunal.

**[14] On the other issues, I have concluded in broad terms that the Divisional Court was right for the reasons given**
by Underhill LJ.

**[15] I will now deal with the issues in the following order: essential factual background, the essential legal**
background, the reasoning of the Divisional Court, the issues, the discussion of those issues, and my conclusions.
**ESSENTIAL FACTUAL BACKGROUND**

**[16] This summary of the factual background is a brief summary of [6]–[11], and [15]–[35] of the Divisional Court's**
judgment. Reference to those paragraphs should be made for the detail.

**[17] The SSHD declared the claims of some 47 asylum seekers to be inadmissible in May and June 2022, intending**
that they should be removed to
**[*266]**

Rwanda by charter flight on 14 June 2022. Some 32 claims for judicial review had been issued by the time of the
Divisional Court's judgment. On 10 June 2022, the Administrative Court refused an application for an interim
injunction to prevent removal. The Court of Appeal dismissed an appeal, and the Supreme Court dismissed an
application for permission to appeal. On 14 June 2022, three Claimants made applications to the ECtHR for interim
measures. NSK, RM and HTN were granted that relief. The practical consequence was that no removals to Rwanda
have yet taken place.

**[18] On 5 July 2022, the SSHD re-took all the inadmissibility, removal and some ECHR claims decisions affecting**
these appellants.

**[19] The UNHCR, as intervener, filed three witness statements of Mr Lawrence Bottinick, the High Commissioner's**
Senior Legal Officer in the UK ('Mr Bottinick'). Both the SSHD and the Government of Rwanda were able to respond
to that evidence.

**[20] It was agreed below that version 6.0 of the SSHD's Inadmissibility Guidance of 9 May 2022 was the operative**
polic doc ment The p rpose p rs ed is to enco rage ' as l m seekers to claim as l m in the first safe co ntr


-----

High Commissioner for Refugees intervening) and ot....

they reach and [to deter] them from making unnecessary and dangerous onward journeys to the UK'. The policy
explained in the Inadmissibility Guidance excludes claims made by unaccompanied children, families and EU
nationals. Its material part provides as follows:

'If a case assessed as suitable for inadmissibility action appears to stand a greater chance of being promptly
removed if referred to Rwanda (a country with which the UK has a [MEDP]), rather than to the country to which
they have a connection, [the Third Country Unit] should consider referring the case to Rwanda. An asylum
claimant may be eligible for removal to Rwanda if their claim is inadmissible under this policy and (a) that
claimant's journey to the UK can be described as having been dangerous and (b) was made on or after 1
January 2022. A dangerous journey is one able or likely to cause harm or injury.'

**[21] The SSHD considers that the MoU and the Notes Verbales underpin her conclusion that Rwanda is a safe third**
country for the purposes of para 345B. Paragraph 2 of the MoU sets out the objectives as follows:

'The objective … is to create a mechanism for the relocation of asylum seekers whose claims are not being
considered by the United Kingdom, to Rwanda, which will process their claims and settle or remove (as
appropriate) individuals after their claim is decided, in accordance with Rwanda domestic law, the Refugee
Convention, current international standards, including in accordance with international human rights law and
including the assurances given under this Arrangement.'

**[22] The MoU provides that a person may only be transferred to Rwanda with the agreement of the Government of**
Rwanda. Account will be taken of Rwanda's capacity to receive persons and the administrative needs associated
with their transfer. The UK provides the Rwandan Government with information on the persons it proposes to
transfer. If it agrees, the Rwandan Government gives 'access to its territory … in accordance with its international
commitments and asylum and immigration laws'. Persons transferred are to be provided with accommodation and
support '… adequate to ensure [their] health, security and wellbeing …'. Moreover, the Rwandan Government will
**[*267]**

have regard to information concerning (and accommodate) the special needs of a person transferred as a victim of
**_modern slavery and human trafficking._**

**[23] The MoU provides that the Rwandan Government will ensure that each person transferred will be treated and**
each asylum claim will be processed 'in accordance with the Refugee Convention, Rwandan immigration laws and
international and Rwandan standards, including under international and Rwandan human rights law, and including
but not limited to ensuring their protection from inhuman and degrading treatment and refoulement'. Specific
provisions are made in the MoU for access to interpreters, procedural or legal assistance at every stage of their
asylum claim including on appeals, and access to an 'independent and impartial due process of appeal in
accordance with Rwandan laws'. The MoU makes specific provision as to the treatment of those granted and
refused asylum, including the prevention of refoulement. Adequate support and accommodation are to be provided
'until such time as their status is regularised or they leave or are removed from Rwanda'. The obligations under the
MoU will survive its termination as regards those transferred under it.

**[24] The MoU provides for the Joint Committee to monitor and review the MEDP and to make non-binding**
recommendations, and for the Monitoring Committee to monitor the entire relocation process, and to report on
conditions in Rwanda, the processing of asylum claims and the treatment and support provided to those
transferred.

**[25] As regards the financial arrangements, the UK paid £20m to the Rwandan Government on 29 April 2022 in**
respect of preparations to receive the first group of asylum claimants. Also in April 2022, the UK paid a further
£120m as an initial contribution to a fund intended to promote economic development in Rwanda. The UK will make
further payments for the costs of processing claims, to ensure the safety and wellbeing of claimants, and for the
costs for 5 years of welfare and integration for those who stay, and for 3 years for those who do not qualify for
refugee status or humanitarian protection. The _Note Verbale concerning these financial issues has not been_


-----

High Commissioner for Refugees intervening) and ot....

disclosed. Finally, the MoU makes provision for management and protection of personal data transferred between
the governments.

**[26] The four assessment documents published by the SSHD on 9 May 2022 contain her assessment of the safety**
of Rwanda as a safe third country for the purposes of para 345B.

**[27] Each asylum seeker in these cases was detained upon arrival in the UK. Their English language skills and**
health were assessed. They were issued with a mobile phone, and given IT, welfare and legal representation
information, including information on the free duty solicitor scheme. Each asylum seeker made an asylum claim,
attended an asylum screening interview conducted by reference to a standard script and recorded on a standard
form, a copy of which record was provided to the asylum seeker. The Home Office National Asylum Allocations Unit
suspected in each case that the asylum seeker had spent time in a safe third country on their way to the UK, and
referred their case to the Third Country Unit. That Unit considered an inadmissibility decision under paras 345A and
345B, and issued each asylum seeker with a Notice of Intent. The Notice of Intent explained that they were being
considered for removal to Rwanda, and sought their representations within 7 days for those detained.

**[28] After that period expired, the Third Country Unit (in Glasgow) and the Detained Barrier Casework Team (in**
Croydon) took the decisions in respect of the asylum seekers on behalf of the SSHD. They each issued a decision
letter.
**[*268]**

The first dealt with inadmissibility, removal and certification under para 17(c). The second dealt with ECHR claims.
Removal directions also provided that, unless the asylum seeker left the UK voluntarily, they would be removed by
plane to Kigali Airport.
**ESSENTIAL LEGAL BACKGROUNDAuthorities**

**[29] In** _Soering, the ECtHR identified, in an extradition case, the test that the court should apply where it was_
removing a person to another state where it was alleged their art 3 rights would be violated. Soering is widely taken
as establishing the well-known test that the court should ask itself whether there were substantial grounds for
believing that the persons being removed would face real risks of art 3 mistreatment. The ECtHR said this at para
88:

'It would hardly be compatible with the underlying values of the Convention, that “common heritage of political
traditions, ideals, freedom and the rule of law” to which the Preamble refers, were a Contracting State
knowingly to surrender a fugitive to another State where there were substantial grounds for believing that
**he would be in danger of being subjected to torture, however heinous the crime allegedly committed.**
Extradition in such circumstances, while not explicitly referred to in the brief and general wording of Article 3,
would plainly be contrary to the spirit and intendment of the Article, and in the Court's view this inherent
obligation not to extradite also extends to cases in which the fugitive would be faced in the receiving State
**by a real risk of exposure to inhuman or degrading treatment or punishment proscribed by that Article.'**
(Emphasis added.)

**[30] In Ilias, the ECtHR explained the procedural duty of states considering the removal of asylum seekers to third**
countries without considering the merits of their asylum application. The case concerned the decision by Hungary to
return to Serbia Bangladeshi asylum seekers who had arrived in Hungary from Serbia. _Ilias has been widely_
understood as establishing that the removing state should undertake a thorough examination of all relevant
[generally available information before deciding whether to remove such a person. The ECtHR said this ((2019) 47](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y49-BT73-GXFD-8139-00000-00&context=1519360)
_[BHRC 497, (2020) 71 EHRR 6 (at paras 137–141)):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y49-BT73-GXFD-8139-00000-00&context=1519360)_

'137. Where a Contracting State removes asylum seekers to a third country without examining the merits of
their asylum applications, however, it is important not to lose sight of the fact that in such a situation it cannot
be known whether the persons to be expelled risk treatment contrary to art 3 in their country of origin or are
simply economic migrants. It is only by means of a **legal procedure resulting in a legal decision that a**
**finding on this issue can be made and relied upon In the absence of such a finding removal to a third**


-----

High Commissioner for Refugees intervening) and ot....

country must be preceded by thorough examination of the question whether the receiving third country's
**asylum procedure affords sufficient guarantees to avoid an asylum-seeker being removed, directly or**
indirectly, to his country of origin without a proper evaluation of the risks he faces from the standpoint of art 3 of
the Convention. Contrary to the position of the respondent Government, a post-factum finding that the asylum
seeker did

**[*269]**

not run a risk in his or her country of origin, if made in national or international proceedings, cannot serve to
absolve the state retrospectively of the procedural duty described above. **If it were otherwise, asylum-**
**seekers facing deadly danger in their country of origin could be lawfully and summarily removed to**
**“unsafe” third countries. Such an approach would in practice render meaningless the prohibition of ill-**
treatment in cases of expulsion of asylum seekers.

138. While the Court acknowledges the respondent Government's contention that there are cases of abuse by
persons who are not in need of protection in their country of origin, it considers that states can deal with this
problem without dismantling the guarantees against ill-treatment enshrined in art 3. It suffices in that regard,
**if they opt for removal to a third safe country without examination of the asylum claims on the merits,**
**to examine thoroughly whether that country's asylum system could deal adequately with those claims.**
In the alternative, as stated above, the authorities can also opt for dismissing unfounded asylum requests after
examination on the merits, where no relevant risks in the country of origin are established.

**_(c) Nature and content of the duty to ensure that the third country is “safe”_**

139. On the basis of the well-established principles underlying its case-law under art 3 of the Convention in
relation to expulsion of asylum-seekers, the Court considers that the above-mentioned duty requires from
**the national authorities applying the “safe third country” concept to conduct a thorough examination**
**of the relevant conditions in the third country concerned and, in particular, the accessibility and**
**reliability of its asylum system …**

140. Furthermore, a number of the principles developed in the Court's case-law regarding the assessment of
risks in the asylum-seeker's country of origin also apply, _mutatis mutandis, to the national authorities'_
examination of the question whether a third country from which the asylum seeker came is “safe” …

141. In particular, while it is for the persons seeking asylum to rely on and to substantiate their individual
circumstances that the national authorities cannot be aware of, those authorities must carry out of their own
motion an up-to-date assessment, notably, of the accessibility and functioning of the receiving country's asylum
system and the safeguards it affords in practice. The assessment must be conducted primarily with reference
to the facts which were known to the national authorities at the time of expulsion but it is the duty of those
authorities to seek all relevant generally available information to that effect … **General deficiencies well**
**documented in authoritative reports, notably of the UNHCR, Council of Europe and EU bodies are in**
**principle considered to have been known … The expelling State cannot merely assume that the asylum**
**seeker will be treated in the receiving third country in conformity with the Convention standards but,**
**on the contrary, must first verify how the authorities of that country apply their legislation on asylum in**
**practice …' (Emphasis added.)**

**[31] In Tameside** _[[1976] 3 All ER 665 at 695–696, [1977] AC 1014 at 1064–1065, the House of Lords established](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD8-PGP0-TWP1-612D-00000-00&context=1519360)_
[that a public body has a duty to carry out a sufficient inquiry prior to making its decision. Lord Diplock said [1976] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD8-PGP0-TWP1-612D-00000-00&context=1519360)
_[All ER 665 at 696, [1977] AC 1014 at 1065that 'the question for the court is,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD8-PGP0-TWP1-612D-00000-00&context=1519360)_
**[*270]**

did the Secretary of State ask himself the right question and take reasonable steps to acquaint himself with the
relevant information to enable him to answer it correctly?' (see the Divisional Court in _R (on the application of_
_Plantagenet Alliance Ltd) v Secretary of State for Justice_ _[[2014] EWHC 1662 (Admin), [2015] 3 All ER 261, [2015]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G9F-G361-DYBP-M106-00000-00&context=1519360)_
_[LGR 172 (at [100] and [139]) and the Co rt of Appeal in R (on the application of Campaign Against Arms Trade)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FN9-2GT1-DYBR-32X3-00000-00&context=1519360)_


-----

High Commissioner for Refugees intervening) and ot....

_Secretary of State for International Trade (Amnesty International intervening)_ _[2019] EWCA Civ 1020, [2019] 1 WLR_
5765(at [35]) and in R (on the application of Friends of the Earth Ltd) v Secretary of State for International Trade/UK
_Export Finance (UKEF)_ _[[2023] EWCA Civ 14, [2023] All ER (D) 70 (Jan) (at [57])).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67F7-C4X3-RRK4-X006-00000-00&context=1519360)_

**[32] Finally, the ECtHR considered in Othman how the court should deal with assurances received from a foreign**
Government as to the art 3 rights of someone considered for deportation to that foreign state. The case concerned
the intended removal of Abu Qatada to Jordan, the circumstances of which were completely different from the
present case. It is nonetheless useful to consider the guidance provided as follows at paras 186–189 of the
ECtHR's judgment:

'186. … Before turning to the facts of the applicant's case, it is therefore convenient to set out the approach the
court has taken to assurances in art 3 expulsion cases.

187. In any examination of whether an applicant faces a real risk of ill-treatment in the country to which
**he is to be removed, the court will consider both the general human rights situation in that country and**
**the particular characteristics of the applicant. In a case where assurances have been provided by the**
receiving state, those assurances constitute a further relevant factor which the court will consider. However,
assurances are not in themselves sufficient to ensure adequate protection against the risk of ill-treatment.
There is an obligation to examine whether assurances provide, in their practical application, a sufficient
guarantee that the applicant will be protected against the risk of ill-treatment. The weight to be given to
assurances from the receiving state depends, in each case, on the circumstances prevailing at the material
time …

188. In assessing the practical application of assurances and determining what weight is to be given to them,
the preliminary question is whether the general human rights situation in the receiving state excludes accepting
any assurances whatsoever. However, it will only be in rare cases that the general situation in a country will
mean that no weight at all can be given to assurances …

189. More usually, the court will assess first, the quality of assurances given and, second, whether, in
**light of the receiving state's practices they can be relied upon. In doing so, the court will have regard,**
**inter alia, to the following factors:**

(i) whether the terms of the assurances have been disclosed to the court …;

(ii) whether the assurances are specific or are general and vague …;

(iii) who has given the assurances and whether that person can bind the receiving state …;

(iv) if the assurances have been issued by the central government of the receiving state, whether local
authorities can be expected to abide by them …;

**[*271]**

(v) whether the assurances concerns treatment which is legal or illegal in the receiving state …;

(vi) whether they have been given by a contracting state …;

(vii) the length and strength of bilateral relations between the sending and receiving states, including the
receiving state's record in abiding by similar assurances …;

(viii) whether compliance with the assurances can be objectively verified through diplomatic or other
monitoring mechanisms, including providing unfettered access to the applicant's lawyers …;

(ix) whether there is an effective system of protection against torture in the receiving state, including whether it
is willing to cooperate with international monitoring mechanisms (including international human rights NGOs),
and whether it is willing to investigate allegations of torture and to punish those responsible …;


-----

High Commissioner for Refugees intervening) and ot....

(x) whether the applicant has previously been ill-treated in the receiving state …; and

(xi) whether the reliability of the assurances has been examined by the domestic courts of the
sending/contracting state …' (Emphasis added.)

_Relevant immigration rules_

**[33] The inadmissibility and removal decisions were made in the exercise of the powers in paras 345A to 345D:**

**'Inadmissibility of non-EU applications for asylum**

345A. An asylum application may be treated as inadmissible and not substantively considered if the Secretary
of State determines that:

(i) the applicant has been recognised as a refugee in a safe third country and they can still avail themselves of
that protection; or

(ii) the applicant otherwise enjoys sufficient protection in a safe third country, including benefiting from the
principle of non-refoulement; or

(iii) the applicant could enjoy sufficient protection in a safe third country, including benefiting from the principle
of non-refoulement because:

(a) they have already made an application for protection to that country; or

(b) they could have made an application for protection to that country but did not do so and there were no
exceptional circumstances preventing such an application being made, or

(c) they have a connection to that country, such that it would be reasonable for them to go there to obtain
protection.

**Safe Third Country of Asylum**

345B. A country is a safe third country for a particular applicant, if:

(i) the applicant's life and liberty will not be threatened on account of race, religion, nationality, membership of
a particular social group or political opinion in that country;

(ii) the principle of non-refoulement will be respected in that country in accordance with the Refugee
Convention;

(iii) the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman, or degrading
treatment as laid down in international law, is respected in that country; and

**[*272]**

(iv) the possibility exists to request refugee status and, if found to be a refugee, to receive protection in
accordance with the Refugee Convention in that country.

345C. When an application is treated as inadmissible, the Secretary of State will attempt to remove the
applicant to the safe third country in which they were previously present or to which they have a connection, or
to any other safe third country which may agree to their entry.

**Exceptions for admission of inadmissible claims to UK asylum process**

345D. When an application has been treated as inadmissible and either

(i) removal to a safe third country within a reasonable period of time is unlikely; or


-----

High Commissioner for Refugees intervening) and ot....

(ii) upon consideration of a claimant's particular circumstances the Secretary of State determines that removal
to a safe third country is inappropriate

the Secretary of State will admit the applicant for consideration of the claim in the UK.'

**[34] Paragraphs 17 and 19 of Pt 5 of Sch 3 the 2004 Act provide as follows:**

'17. This Part applies to a person who has made an asylum claim if the Secretary of State certifies that—

(a) it is proposed to remove the person to a specified State,

(b) in the Secretary of State's opinion the person is not a national or citizen of the specified State, and

(c) in the Secretary of State's opinion the specified State is a place—

(i) where the person's life and liberty will not be threatened by reason of his race, religion, nationality,
membership of a particular social group or political opinion, and

(ii) from which the person will not be sent to another State otherwise than in accordance with the Refugee
Convention.

…

19. Where this Part applies to a person—

…

(b) he may not bring an immigration appeal from within the United Kingdom in reliance on an asylum claim
which asserts that to remove the person to the State specified under paragraph 17 would breach the United
Kingdom's obligations under the Refugee Convention,

(c) he may not bring an immigration appeal from within the United Kingdom in reliance on a human rights claim
if the Secretary of State certifies that the claim is clearly unfounded, and

(d) he may not while outside the United Kingdom bring an immigration appeal on any ground that is
inconsistent with the opinion certified under paragraph 17(c).'

**THE REASONING OF THE DIVISIONAL COURT**

**[35] I should record first our thanks to the Divisional Court for producing an impressive, comprehensive and**
carefully organised judgment at great speed. At [39], the Divisional Court summarised the generic issues that it had
to decide. In the light of the submission that the Divisional Court applied the wrong test to its consideration of the
safety of Rwanda, it is important to look at what it said about those issues. It described the appellants' submission
**[*273]**

at [39](1) as being that the SSHD's conclusion that Rwanda was a safe third country was legally flawed. Their
primary contention was that the SSHD's assessment was contrary to art 3, based on (a) Ilias, (b) the fact that the
asylum seekers would face a real risk of art 3 ill-treatment in breach of the Soering principle, and (c) the fact that it
was inevitable that the policy would lead to occasional art 3 ill-treatment. Put another way, the Divisional Court
described the submission as being that the conclusion that Rwanda was a safe third country had not taken account
of relevant matters, was the result of insufficient enquiry, and rested on material errors of fact and was irrational. At

[39](2), the Divisional Court said that it was central to the appellants' case that the asylum claims would not be
determined effectively in Rwanda, running the risk that they would be refouled. The SSHD was not entitled to have
confidence that the Rwandan Government would honour the MoU and the Notes Verbales.

**[36] At [41]–[42], the Divisional Court held (i) that any issue that went to the legality of decisions contained in the**
SSHD's four assessments and the Inadmissibility Guidance was to be assessed as at the date of the inadmissibility


-----

High Commissioner for Refugees intervening) and ot....

decisions, and (ii) the correct focus was on the SSHD's replacement decisions issued on 5 July 2022 rather than
the earlier decisions made in May and June 2022. These decisions are not challenged in this court.

**[37] At [43]–[61], the Divisional Court dealt with the question of 'whether the assessment that Rwanda [was] a safe**
third country [was] legally flawed'. At [43], the primary submission was described as being that the SSHD's removal
decisions under para 345C were unlawful because the conclusion that Rwanda was a safe third country under para
345B was legally flawed. The primary submission was said to be put in different ways on the basis that 'the
conclusion that Rwanda [met] the criteria at 345B': (a) amounted to a breach of art 3 for the reasons explained in
_Ilias, (b) rested on material errors of fact or a failure to comply with_ _Tameside obligations, (c) was an irrational_
conclusion, and (d) was part of a policy which was unlawful in the sense explained in _Gillick v West Norfolk and_
_[Wisbech Area Health Authority [1985] 3 All ER 402, [1986] AC 112('Gillick') in that it authorised removals in breach](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-607K-00000-00&context=1519360)_
of art 3. It will be observed at once that this description of the submissions places the emphasis on the challenge to
the conclusion reached by the SSHD as to the safety of Rwanda.

**[38] At [44], however, the Divisional Court recorded that it was also submitted that removal to Rwanda would be in**
breach of art 3 'in the sense of the Soering principle because there are reasonable grounds for believing that if a
person is removed to Rwanda that will expose him to a real risk of article 3 ill-treatment because of the conditions in
Rwanda'. It then said, importantly, at [45] that the legal arguments converged on two issues as follows:

(i)   whether the SSHD's conclusion that Rwanda met the criteria for being a 'safe third country' as defined
at para 345B(ii) to (iv), was a conclusion based on sufficient evidence and thorough assessment; and

(ii)   whether the SSHD could lawfully reach the conclusion that the arrangements governing relocation to
Rwanda would not give rise to a real risk of refoulement or other ill-treatment contrary to art 3.

**[39] The Divisional Court gave its answers to these questions under four headings: (i) thorough examination and**
reasonable inquiries, (ii) adequacy of asylum system, (iii) the Gillick issue, and (iv) conditions in Rwanda generally.
**[*274] (i) Thorough examination and reasonable inquiries**

**[40] The Divisional Court dealt first at [46]–[47] with the sources of information available to the SSHD including the**
UNHCR. It then dealt with Ilias, describing it as 'an example of the application of the principle in Soering', and gave
a 'relatively brief description of the Rwandan asylum procedure'. The description is not controversial and was as
follows:

'[51] … Rwanda has a significant history of providing asylum to refugees fleeing local conflict. In July 2020, the
UNHCR reported that since 1990, Rwanda had maintained “an open door policy” to refugees from
neighbouring countries, and that there were nearly 149,000 refugees in Rwanda. The overwhelming majority
were from the Democratic Republic of Congo and the Republic of Burundi. Rwanda has also supported the
UNHCR “emergency transport mechanism” which, since 2019, has assisted a little over 1,000 asylum seekers
to be removed from Libya to Rwanda. Once in Rwanda, their claims are processed by the UNHCR and
claimants have, to date, been resettled by the UNHCR in third countries. Mr Bottinick's evidence was that at
present, some 440 asylum claimants are in Rwanda under this scheme.

[52] Persons who have fled to Rwanda from neighbouring countries have been permitted to remain in Rwanda
without going through any formal asylum determination process. The Rwandan system for determining asylum
claims has only been used to determine claims made by those coming from further afield. This is a small
number of cases. The UNHCR estimated that in the last 3 years there have been approximately 300 cases.
Asylum claims must be registered with the Directorate General of Immigration and Emigration (“the DGIE”).
The DGIE will interview the claimant, issue him with a residence permit and forward the case to the Refugee
Status Determination Committee (“the RSDC”). The RSDC comprises 11 members drawn from 11 ministries
and government departments. Each holds his position ex-officio; membership of the RSDC will be only one part
of the person's overall responsibilities. The RSDC determines the asylum claim. There is a right of appeal to
the Minister for the Ministry in Charge of Emergency Management, the government department with


-----

High Commissioner for Refugees intervening) and ot....

responsibility for, among other matters, refugee affairs. There is a further appeal from the Minister to the High
Court of Rwanda. That is an appeal in the way of re-hearing.'

**[41] The Divisional Court then summarised at [53]–[54] the appellants' submission that the Rwandan asylum**
system was not adequate to prevent the risk of refoulement, derived from Mr Bottinick's evidence as follows. The
summary is controversial before us, but it is nonetheless important to recite it:

'(1) There are instances where the Rwandan authorities have refused to register claims for asylum. To the
UNHCR's knowledge there have been 5 occasions (involving claimants from Libya, Syria and Afghanistan)
where a person has made an asylum claim to the DGIE, but the DGIE refused to accept the claim as a valid
claim. Those claims were made at Kigali Airport in Rwanda and the asylum claimants were refused entry to
and, ultimately were removed from Rwanda. Generally, Mr Bottinick is critical of the DGIE not just in terms of
its approach to registering asylum claims but also when it comes to interviewing asylum claimants. He says the
airport

**[*275]**

cases are an indication that the DGIE discriminates against those who are not nationals of neighbouring states
and, especially, against persons from Middle Eastern countries. He says the DGIE has on other occasions
refused to interview asylum claimants. He suggests the DGIE may discriminate against asylum claimants who
are lesbian, gay, bisexual, trans-sexual or inter-sex. He says the UNHCR is aware of two such cases. Mr
Bottinick also says that when the DGIE refuses to refer a claim to the RSDC it does not give reasons for its
decision. When interviews do occur, he says no record of the interview is provided to the asylum claimant.

(2) Mr Bottinick also considers the process before the RSDC is inadequate. The members of the RSDC are not
expert or trained in asylum law. He gives examples of three occasions when the RSDC refused to see the
asylum claimant. When hearings have taken place, they are too short to give claimants a fair chance to make
their case, and hearings tend to lack focus because of the size of the RSDC. There are no interpreters at
RSDC hearings which significantly prejudices claimants who speak neither French nor English. The RSDC
does not allow claimants to be represented by lawyers. The RSDC does not provide proper reasons for
decisions; decisions tend to be all in a standard form that simply informs the claimant of the outcome.

(3) Mr Bottinick is sceptical about the value of the appeal to the Minister. He says the UNHCR is not aware of
any case where the Minister has reversed a decision of the RSDC. He also points out that legal representatives
are not available for appeals to the Minister. Ministerial decisions are also in standard form and are not properly
reasoned.

(4) Mr Bottinick also says that the lack of reasoned decisions from the RSDC and the Minister impedes
effective use of the right of appeal to the High Court. This right of appeal was introduced in 2018. There is no
evidence that [any] such appeals have been filed with or heard by the High Court.

(5) Rwandan asylum law is said to be defective. Mr Bottinick refers to a “protection gap”. He says that the
definition of “political opinion” in article 7 of Rwanda's 2014 Law on Asylum does not cover the possibility of
protection against persecution on grounds of imputed political opinion or from the risk of ill treatment by nonstate actors.

(6) Mr Bottinick's opinion is that the Rwandan asylum system lacks the capacity and expertise necessary to
deal effectively with asylum claims. This is material in two ways. Important aspects of asylum law may not be
properly understood and properly applied. As an example, Mr Bottinick says that “it can be difficult for decisionmakers to understand” that asylum claims should not be denied on the premise that the claimant could hide a
characteristic protected under the Refugee Convention, such as his political opinion or sexual orientation.
Further, the Rwandan system will not be able to cope with the volume of claims generated by the MEDP. Mr
Bottinick comments that claimants in the Rwandan asylum system have insufficient access to legal assistance
and interpretation services are not available. He also raises a concern that details of asylum claimants and


-----

High Commissioner for Refugees intervening) and ot....

their claims may not have been treated as confidential and information may have been passed to the asylum
claimants' countries of origin.'

**[42] The Divisional Court then recorded at [55]–[56] that the SSHD and the Rwandan Government disputed much**
of Mr Bottinick's evidence, noting only
**[*276]**

that: (i) the UNHCR had described the 2014 Law relating to Refugees in its July 2020 Universal Periodic Review as
'fully compliant with international standards', (ii) art 7 of the 2014 Law exactly followed the language of art 1 of the
Refugee Convention, and (iii) as to whether Rwandan authorities had maintained the confidentiality of asylum
seekers, it was satisfied that the RSDC had sought information from Rwandan embassies abroad, rather than
countries of origin.

**[43] The Divisional Court went on to record at [57]–[58] that the SSHD's primary reliance was on the detailed**
contents and assurances in the MoU and the Notes Verbales (summarised at [21]–[25] above and in [18]–[27] of
the Divisional Court). Those, together with the steps she had taken to investigate the matters in the assessment
documents, were sufficient to satisfy her Ilias and Tameside duties, 'and permitted her rationally to conclude that
Rwanda does meet the criteria at paragraph 345B(ii) to (iv) … to be a safe third country'.

**[44] At [59]–[60], the Divisional Court concluded that the SSHD had complied with her** _Ilias obligations. The_
assessment documents were a thorough examination of all relevant generally available information, including that
emanating from the UNHCR. At [61], the Divisional Court concluded that the SSHD had complied with her
_Tameside obligations._
_(ii) Adequacy of asylum system_

**[45] The Divisional Court described the next question at [62] as being 'whether the [SSHD] was entitled to conclude**
that there were sufficient guarantees' to ensure proper determination of asylum claims, the absence of a risk of
refoulement, and that Rwanda was a safe third country within para 345B(ii)–(iv). That, it said, raised 'the question of
whether she was entitled' to rely on the assurances provided by the Rwandan Government.

**[46] The Divisional Court began by noting that, on their face, the assurances addressed all the UNHCR's significant**
concerns. It then dealt with Othman, noting that the ECtHR's list of criteria at para 189 was intended to be neither
prescriptive nor exhaustive. Rather, when the risk of art 3 ill-treatment was in issue, 'the court's approach must be
rigorous and pragmatic notwithstanding that ultimately it is an assessment to be undertaken recognising that the
court must afford weight to the [SSHD's] evaluation of the matter. That approach will rest on a recognition of the
expertise that resides in the executive to evaluate the worth of promises made by a friendly foreign state'.

**[47] The Divisional Court then said at [64] that it had concluded that the SSHD was 'entitled to rely on the**
assurances contained in the MOU and Notes Verbales' for the reasons given at [64]–[71], which I can summarise
as follows:

(i)   The UK and Rwanda had a well-established and long-standing relationship, as explained by Mr
Simon Mustard, the Director, Africa (East and Central) at the Foreign, Commonwealth and Development
Office. The development partnership was suspended by the UK in 2012 in response to Rwanda's
involvement in the M23 Rebellion in the Democratic Republic of Congo, and further reviewed in 2014 in
response to the assassination in South Africa of a Rwandan dissident. The Rwandan Government knew
that the UK placed importance on its compliance in good faith with the terms on which the relationship was
conducted.

(ii)   The terms of the MoU and _Notes Verbales reflected Rwanda's obligations as a signatory to the_
Refugee Convention, and were specific and detailed.

**[*277]**

(iii)   Whilst it was fair to say that (a) only a small number of claims had, thus far, been handled by the
Rwandan asylum system, and (b) it would take time and resources to develop its capacity, significant


-----

High Commissioner for Refugees intervening) and ot....

resources were to be provided under the MEDP, the Rwandan Government could control the flow of
asylum seekers and there were monitoring mechanisms. The Divisional Court concluded at [65] that there
was, for now at least, no reason to believe that they would not prove effective. Rwanda had a financial
incentive to comply.

(iv)   After significant contacts and visits, HM Government was satisfied that Rwanda would honour its
obligations under the MEDP. The Divisional Court considered that it 'could go behind this opinion only if
there were compelling evidence to the contrary', which there was not.

(v)   The Divisional Court did not consider that the UNHCR's evidence about the experience of the
Israel/Rwanda agreement in 2013 was critical for its purposes. Israel offered asylum seekers a choice
between detention in Israel or removal to Rwanda together with $3,500 and the opportunity to claim asylum
there. The UNHCR said they were not provided with support and many soon left Rwanda, and some were
sent to Uganda. The UK Government had not investigated the Israel/Rwanda scheme or the way it had
worked. It had been legally permissible for the UK Government to have assessed the MEDP on its own
terms and without comparing it to the Israel/Rwanda scheme.

(vi)   The UNHCR's opinion that, in the light of the history of refoulement and of defects in its asylum
system, Rwanda could not be relied on to comply with its obligations had come late in submissions and
was not in Mr Bottinick's statements. That opinion did not sit easily with the UNHCR's previously published
views, for example in the July 2020 Universal Periodic Review. But anyway, the question that the Divisional
Court said it had to address at [70] was 'whether, notwithstanding the opinion [of] the UNHCR, the [SSHD]
was entitled to hold the contrary opinion'.

(vii)   The authorities showed that no special weight was to be accorded to the UNHCR's evidence (HF
_(Iraq) v Secretary of State for the Home Dept, MK (Iraq) v Secretary of State for the Home Dept [2013]_
_EWCA Civ 1276, [2014] 1 WLR 1329('HF (Iraq)') at [42]–[47] per Elias LJ, and_ _AS (Afghanistan) v_
_[Secretary of State for the Home Dept [2021] EWCA Civ 195 at [17]–[23] per Davis LJ).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:621K-TH23-GXFD-83SK-00000-00&context=1519360)_

(viii)   The conclusion that Rwanda would act in accordance with the terms of the MEDP rested on 25
years of bilateral governmental relations and months of negotiation:

'We must consider it together with all the evidence before us and decide whether, on the totality of that
evidence, the [SSHD's] opinion is undermined to the extent it can be said to be legally flawed. For the reasons
we have already given, the [SSHD] did not act unlawfully when reaching the conclusion that the assurances
provided by Rwanda … could be relied on. That being so, the conclusion that, for the purposes of the criteria at
paragraph 345B(ii) to (iv) …, Rwanda is a safe third country, was neither irrational, nor a breach of article 3 of
the ECHR in the sense explained in Ilias.'

**[*278] (iii) The Gillick Issue**

**[48] The Divisional Court relied on R (on the application of A) v Secretary of State for the Home Dept** _[2021] UKSC_
_37,_ _[[2022] 1 All ER 177, [2021] 1 WLR 3931for the proposition that the relevant question was whether the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HY-3H43-GXF6-833F-00000-00&context=1519360)_
Inadmissibility Guidance positively authorised or approved unlawful conduct. It did not, because the SSHD could
lawfully conclude that Rwanda was a safe third country and that asylum claims made in Rwanda would be
effectively determined.
_(iv) Conditions in Rwanda generally_

**[49] The Divisional Court said at [73] that it would consider 'the wider Soering submission, that persons removed to**
Rwanda under the terms of the MEDP [were] exposed to a real risk of article 3 ill-treatment … by reason of
conditions in Rwanda, generally'. It dealt with the arguments that the Rwandan authorities were intolerant of
criticism, and that there might be an extreme response to criticism of the asylum seekers' conditions or treatment,
or to opposing political opinion.

**[50] The Divisional Court did not think that any direct inference could be drawn from the events at Kiziba refugee**
camp in 2018, where protesters were killed, because the circumstances were unlikely to be repeated for persons


-----

High Commissioner for Refugees intervening) and ot....

transferred under the MEDP, and the Rwandan authorities would abide by the terms of the MEDP. There was no
evidence that any individual appellant held political opinions opposed to the Rwandan Government. If they did, that
would be considered under para 345B(i).

**[51] At [77], the Divisional Court said that there was no force at all in the submission that there might be a breach of**
art 15 of the Refugee Convention regarding rights of association. The appellants' reliance on various facts as to the
repressive nature of the Rwandan Government was speculative, when the terms of the MEDP had been agreed
and could be expected to be complied with. This overbore evidence that: (i) opportunities for political opposition in
Rwanda were very limited and closely regulated, (ii) there were restrictions on the right of peaceful assembly,
freedom of the press and freedom of speech, (iii) from a US State Department report of 2020, political opponents
have been detained in 'unofficial' detention centres and that persons so detained have been subjected to torture
and art 3 ill-treatment short of torture, and (iv) prisons in Rwanda are over-crowded and the conditions are very
poor. The terms of the MEDP meant that there was no real risk of these things affecting the individuals sent to
Rwanda under the partnership.

**[52] I refer to the judgment of Underhill LJ for a summary of the Divisional Court's conclusions on the four further**
submissions identified at [11] above.
**THE ISSUES**

**[53] It was common ground between the parties to the appeal that the central issue as to the safety of Rwanda was**
whether, bearing in mind the guarantees and assurances that the Government of Rwanda had given to the UK
Government, there were no substantial grounds for thinking that: (a) Rwanda was not a safe third country, (b) there
were real risks of refoulement or breaches of art 3, and (c) there were real risks that asylum claims would not be
properly and fairly determined in Rwanda.
**[*279]**

**[54] Before I answer that question, however, it is necessary to decide whether the Divisional Court actually**
determined that question or a different one. On one analysis, the Divisional Court seems, from some of the
language it used, to have asked itself whether the SSHD was entitled to accept the assurances from the Rwandan
Government or was entitled to conclude on the evidence that there were no art 3 risks for asylum seekers sent to
Rwanda.

**[55] Accordingly, in my judgment, the first issue for this court is whether the Divisional Court asked itself the correct**
question as to the safety of Rwanda. If it did, as the SSHD submits it did, this court would only be entitled to
interfere if it made some other error of law (see DB and Hackney referred to at [9] above).

**[56] I propose therefore to identify the following issues in two parts: (i) as to the safety of Rwanda and (ii) as to the**
remaining issues.
_The safety of Rwanda issues_

**[57] Issue 1: Whether the Divisional Court addressed the right question as to the safety of Rwanda.**

**[58] Issue 2: Whether the Divisional Court was right to decide at [66] that it could only go behind the SSHD's**
opinion that Rwanda would honour its obligations if there were compelling evidence to the contrary. If not, how
should the court evaluate the reliability of guarantees and assurances given by one sovereign government to
another?

**[59] Issue 3: Whether the Divisional Court was right to decide at [67]–[71] and [73]–[74] that (a) the evidence of the**
UNHCR generally, (b) what occurred when Israel and Rwanda made a similar agreement in 2013, (c) what
occurred at the Kiziba refugee camp in 2018, and (d) Rwanda's history of refoulement and of defects in its asylum
system, did not undermine the SSHD's opinion that Rwanda would honour its obligations.


-----

High Commissioner for Refugees intervening) and ot....

**[60] Issue 4: Whether the Divisional Court was right to conclude at [73]–[77] that there was no real risk that the**
response of the Rwandan authorities to hostile political opinions expressed by asylum seekers in the future might
subject them to art 3 ill-treatment?

**[61] Issue 5: Bearing in mind the correct test, whether the Divisional Court was right to decide at [64] that the SSHD**
was entitled to rely on the assurances contained in the MoU and Notes Verbales.

**[62] Issue 6: Whether there were** **in fact substantial grounds for thinking, bearing in mind the guarantees and**
assurances, that (a) Rwanda was not a safe third country, (b) there were real risks of refoulement or art 3 breaches,
and (c) there were real risks that asylum claims would not be properly determined.

**[63] Issue 7: Whether the Divisional Court was right to conclude at [71] that the SSHD's decision that, for the**
purposes of the criteria at para 345B(ii) to (iv), Rwanda was a safe third country, was neither irrational, nor a breach
of art 3.

**[64] Issue 8: Whether the Divisional Court was right to accept at [59] that the SSHD complied with the obligations**
identified in Ilias, namely to undertake a 'thorough examination' of 'all relevant generally available information'.

**[65] Issue 9: Whether the Divisional Court was right to accept at [61] that the SSHD complied with her Tameside**
duty to ask herself the right question and take reasonable steps to acquaint herself with the relevant information to
enable her to answer it correctly.
**[*280]**

**[66] Issue 10: Whether the Divisional Court was right at [72] to decide that the Inadmissibility Policy, including the**
possibility of removal to a safe third country, was not Gillick unlawful.

**[67] Issue 11: Whether the SSHD's certification under para 17(c) was unlawful, because the asylum seekers' ECHR**
claims were not clearly unfounded under para 19(c).
_The remaining issues_

**[68] Issue 12: Whether the Divisional Court ought to have concluded that removal of asylum seekers to Rwanda**
under the MEDP was inconsistent with art 33 and/or constituted the imposition of a penalty contrary to art 31 and
was, therefore, a breach of s 2 of the 1993 Act.

**[69] Issue 13: Whether the Divisional Court ought to have concluded that arts 25 and 27 of the Procedures**
Directive made the MEDP unlawful because they were still retained EU law.

**[70] Issue 14: Whether the Divisional Court ought to have decided that the SSHD had created a presumption that**
Rwanda was safe in her assessment documents, thereby circumventing the statutory scheme under Sch 3 to the
2004 Act.

**[71] Issue 15: Whether the Divisional Court ought to have decided that the SSHD's alleged breaches of the UK**
GDPR would, if established, invalidate the SSHD's decisions under the MEDP.

**[72] Issue 16: Whether the Divisional Court ought to have decided that the decisions to treat the asylum application**
as inadmissible under para 345A, to remove the asylum seeker to Rwanda under para 345C (having decided that
Rwanda was a safe third country under para 345B), and to make a certification decision under para 17(c) to the
effect that Rwanda was a safe country for the asylum seeker, were rendered unlawful by procedural unfairness.
**DISCUSSION OF THE ISSUESIssue 1: Did the Divisional Court address the right question as to the safety of**
_Rwanda?_

**[73] It was submitted by the SSHD that it would be remarkable if such an experienced Divisional Court had, in fact,**
addressed the wrong question. It is also clear from the material parts of the Divisional Court's judgment that it
understood that the Soering test required the court to decide whether there were substantial grounds for believing
that the asylum seekers sent to Rwanda would face real risks of art 3 mistreatment (see [39](1), [44] and [73]). The


-----

High Commissioner for Refugees intervening) and ot....

issue is not, in my judgment, whether we might think that the Divisional Court understood the test it had to apply,
but whether an objective reading of its judgment shows that it did.

**[74] Moreover, in considering the process adopted by the Divisional Court, I bear closely in mind the SSHD's**
powerful submission that the Divisional Court had itself said, when it refused permission to appeal, that the ground
of appeal was 'based on a misreading of the judgment and a reference to one sentence not read in context'. The
point that it and the SSHD made was that one of the two central questions posed by the Divisional Court at [45] was
whether the SSHD could lawfully reach the conclusion that the arrangements governing relocation to Rwanda
would not give rise to a real risk of refoulement or other art 3 ill-treatment. The Divisional Court said in its
**[*281]**

permission judgment, and the SSHD now submits, that the SSHD could only lawfully do that if there would be no
risk of refoulement, and that that was the issue the court then considered at [46]–[71].

**[75] On analysis, however, it seems to me that the Divisional Court only considered the Soering test in relation to**
conditions in Rwanda generally at [73]–[77]. In relation to other matters, such as the asylum system in Rwanda and
the likelihood of the Rwandan Government's assurances being realised, it asked itself whether the SSHD had been
entitled to reach the conclusions she did. It is obvious, I think, that the question of whether the SSHD was entitled
(within a margin of appreciation) to reach a particular conclusion is a different question from whether the court
assesses that there were in fact substantial grounds for thinking there was a real risk of art 3 mistreatment.

**[76] It is also not appropriate to express the Soering question as being whether the SSHD could lawfully reach the**
conclusion that there was a real risk of art 3 mistreatment, even if it is true that she could only lawfully reach that
conclusion if she assessed there was no such real risk. The difference is between the court's assessment of the
SSHD's decision (which is a normal judicial review question) and the Soering question, which requires the court to
reach its own conclusion.

**[77] I can explain my reasoning as to the detail by reference to the text of the Divisional Court's judgment, which I**
have already summarised at [35]–[51] above:

(i)   It described the appellants' primary contention at [39](1) as being that the SSHD's assessment was
contrary to art 3, based on Ilias and Soering. The problem was that the Soering submission was, in fact,
that the court should decide whether there were substantial grounds for believing that asylum seekers sent
to Rwanda would face real risks of art 3 mistreatment. It was not just that the SSHD's assessment fell foul
of art 3.

(ii)   At [39](2), the Divisional Court again explained that the appellants' case was that the SSHD was not
entitled to have confidence that asylum claims would not be determined effectively in Rwanda.

(iii)   At [43], the primary submission was described as being that the SSHD's conclusion that Rwanda
was a safe third country was legally flawed. As I observed at [37] above, the description of the submissions
placed emphasis on the challenge to the conclusions reached by the SSHD.

(iv)   At [44], the Divisional Court recorded the correct Soering test, but then said at [45] that all the legal
arguments converged on two issues. Those two issues concentrated exclusively on the **SSHD's**
**conclusions that (i) Rwanda met the criteria for being a safe third country, and (ii) the arrangements**
governing relocation to Rwanda would not give rise to a real risk of refoulement or other art 3 ill-treatment. I
have already dealt at [74]–[75] with the reasons why it is not applying the Soering test to ask whether the
SSHD could lawfully have reached the conclusion she did.

(v)   It may be that the way the Divisional Court divided up its treatment of the issues at [45] did not help,
because it concentrated in the first section on the procedural questions raised by _Ilias as to whether the_
SSHD had made a thorough examination, rather than on the substantive question of whether there were
substantial grounds for believing that asylum seekers sent to Rwanda would face real risks of art 3
mistreatment.


-----

**[*282]**


High Commissioner for Refugees intervening) and ot....

(vi)   The Divisional Court's conclusion at [57]–[59] was that the SSHD's reliance on the assurances and
the steps taken to investigate the matters in

the assessment documents were sufficient to satisfy her _Ilias and_ _Tameside duties. It was that which_
'permitted [the SSHD] rationally to conclude that Rwanda does meet the criteria at para 345B(ii) to (iv) to
be a safe third country'. That was a permissible answer to the _Ilias and_ _Tameside questions (which I_
consider separately later), but not to the Soering question.

(vii)   At [62], the Divisional Court asked whether the SSHD was entitled to conclude that there were
sufficient guarantees to ensure proper determination of asylum claims, the absence of a risk of
refoulement, and that Rwanda was a safe third country. The approach to reliance on assurances (which I
deal with below) was a separate question from the question of whether there were substantial grounds for
believing that asylum seekers sent to Rwanda would face real risks of art 3 mistreatment.

(viii)   At [64], the Divisional Court concluded that the SSHD had been entitled to rely on the assurances
contained in the MoU and Notes Verbales. That may have been the correct question as to assurances (as
to which see below) but did not, in itself, answer the Soering question as to the adequacy of the asylum
system (which was the section of the judgment in which it appeared).

(ix)   When it came to consider Soering at [73], the Divisional Court stated the question correctly as being
whether persons removed to Rwanda under the terms of the MEDP were exposed to a real risk of art 3 illtreatment, but did so only in relation to conditions in Rwanda generally. It also answered the correct
question when it concluded at [77] '[g]iven that the person concerned would have been transferred under
the terms of the MEDP that possibility [the risk of art 3 mistreatment] is not a real risk'.



**[78] Accordingly, I conclude that as to the asylum system and everything except the general situation in Rwanda at**

[73]–[77], the Divisional Court did not ask the correct _Soering question, namely whether there were substantial_
grounds for thinking that asylum seekers sent to Rwanda under the MEDP would face a real risk of art 3
mistreatment. I note at this stage that I have reached the same substantive conclusion as Underhill LJ at [129] of
his judgment on this point.

**[79] This conclusion means that this court must look again at the Soering question. Whilst proper respect must be**
given to [73]–[77], the question is not a compartmentalised one. Accordingly, this court must, as it seems to me,
look at the situation in Rwanda for asylum seekers sent there in the round, against the backdrop, of course, of the
governmental assurances received and the terms of the MEDP itself. I turn then to deal with the approach that the
court should adopt to such assurances.
_Issue 2: Was the Divisional Court right to decide at [66] that it could only go behind the SSHD's opinion that_
_Rwanda would honour its obligations if there were compelling evidence to the contrary? If not, how should the court_
_evaluate the reliability of guarantees and assurances given by one sovereign government to another?_

**[80] I have already summarised the approach that the Divisional Court adopted to these questions at [45]–[47]**
above. Since the court is going to have to consider the Soering question for itself, it may not be necessary to deal
with this issue at length. The approach that the court must adopt towards assurances is set out in detail in the
passage I have already cited at [32] above from _Othman. In summary, the ECtHR made clear that whilst_
'assurances are
**[*283]**

not in themselves sufficient to ensure adequate protection against the risk of ill-treatment … [t]here is an obligation
to examine whether assurances provide, in their practical application, a sufficient guarantee'. It is critical to note, in
my opinion, that the ECtHR emphasised that '[t]he weight to be given to assurances from the receiving state
depends, in each case, on the circumstances prevailing at the material time'. It will, as the ECtHR also said, 'only be
in rare cases that the general situation in a country will mean that no weight at all can be given to assurances'. This,
in my judgment, is one of the more usual cases referred to by the ECtHR where the court should 'assess first, the
quality of assurances given and, second, whether, in light of the receiving state's practices they can be relied upon'.


-----

High Commissioner for Refugees intervening) and ot....

**[81] I do not find any great assistance from all of the 11 factors listed out in Othman and cited at [32] above. As the**
SSHD submitted and the Divisional Court said the factors were neither exhaustive nor prescriptive. Moreover they
were directed specifically to the unusual circumstances of Othman, which are different to those in this case. That
being said, some of the factors, particularly 7–11, have been useful to consider, by analogy with the present case,
as a form of cross-check with my assessment.

**[82] It is, however, important, as the SSHD submitted, for the court to bear closely in mind the injunction of Lord**
Bingham in _R (on the application of Yogathas) v Secretary of State for the Home Dept, R (on the application of_
_Thangarasa) v Secretary of State for the Home Dept_ _[[2002] UKHL 36, [2002] 4 All ER 800, [2003] 1 AC 920(at [9])](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-611N-00000-00&context=1519360)_
where he said 'The first [important consideration] is that the Home Secretary and the courts should not readily infer
that a friendly sovereign state which is party to the Geneva Convention will not perform the obligations it has
solemnly undertaken'.

**[83] Considering that this court is deciding the Soering question afresh, it is not strictly necessary for us to consider**
whether the Divisional Court was right to decide at [66] that it could only go behind the SSHD's opinion that Rwanda
would honour its obligations if there were compelling evidence to the contrary: we have taken into account all the
relevant material in reaching our judgments. Since the Divisional Court was right to regard the UK Government's
evaluation of the reliability of assurances as an important factor, it would certainly have needed clear evidence to
'go behind' that opinion. The UK Government has, of course, huge experience of diplomatic relations with the
Government of Rwanda. I will, in the light of my earlier conclusions, however, have to 'assess first, the quality of
assurances given and, second, whether, in light of the receiving state's practices they can be relied upon' (Othman
at para 189). In the first stage of that process, due weight must be given to the UK Government's view of the
diplomatic assurances it was receiving.

**[84] In this case, it is not suggested that the Rwandan Government's detailed guarantees and assurances,**
contained in the MEDP, were not given in good faith. In those circumstances, it can be assumed that the Rwandan
Government intended to comply with them. The question is only whether, in the light of the events on the ground, it
was or was not likely that the assurances would be complied with. Put another way, that is the heart of the Soering
question: assuming that the UK Government had received detailed and fulsome guarantees and assurances given
in good faith by a foreign sovereign Government with whom relations were long-standing and friendly, were there
substantial grounds for thinking there was a real risk that asylum seekers would face art 3 ill-treatment?
**[*284] Issue 3: Was the Divisional Court right to decide at [67]–[71] and [73]–[74] that (a) the evidence of the**
_UNHCR generally, (b) what occurred when Israel and Rwanda made a similar agreement in 2013, (c) what_
_occurred at the Kiziba refugee camp in 2018, and (d) Rwanda's history of refoulement and of defects in its asylum_
_system, did not undermine the SSHD's opinion that Rwanda would honour its obligations?_

**[85] In many ways, this question encapsulates the core of the appeal. I shall deal first with the question of what**
weight the court should give to evidence from the UNHCR in answering the Soering question. The SSHD submits
that the Divisional Court was right to say at [71] that the UNHCR's opinion as expressed in Mr Bottinick's
statements and on instructions carried no overriding or pre-eminent weight.

**[86] I shall consider each of the main authorities that has been referred to in chronological order:**

(i)   First, _MSS (2011) concerned an asylum seeker who had entered the EU through Greece and then_
applied for asylum in Belgium. It dealt with the balance between the generally known situation in Greece
and the approach to assurances given as to the Greek asylum system (see paras H32 and 352–354 and
358). At paras 347–349, the ECtHR attached 'critical importance' to the UNHCR's opinion, which contained
an unequivocal plea for the suspension of transfers to Greece. It said that the reports and materials, based
on field surveys, all agreed as to the practical difficulties involved in the application of the Dublin system in
Greece, the deficiencies of the asylum procedure and the practice of direct or indirect refoulement. The
materials were authored by the UNHCR and the Council of Europe's Commissioner for Human Rights, and
international non-governmental organisations.


-----

**[*285]**


High Commissioner for Refugees intervening) and ot....

(ii)   In _EM (Eritrea), the Supreme Court explained the approach to evidence from the UNHCR in the_
context of the risks of returning asylum seekers to Italy. At [71]–[74], Lord Kerr (with whom the other
members of the court agreed) approved the statement of Sir Stephen Sedley at [41] in the Court of Appeal
recognising that 'particular importance should attach to the views of UNHCR'. At [74], in the circumstances
of that case, Lord Kerr explained that '[w]hile, because of their more muted contents, [the UNHCR's reports
did] not partake of the “pre-eminent and possibly decisive” quality of the reports on Greece, they
nevertheless contain useful information which the court will wish to judiciously consider. … The UNHCR
material should form part of the overall examination of the particular circumstances of each of the
appellant's cases, no more and no less'.

(iii)   In _Tabrizagh (2014), Underhill LJ explained at [20] that in_ _EM (Eritrea) Lord Kerr had approved_
passages specifically asserting the legitimacy of paying 'special regard both to the facts which the High
Commissioner reports and to the value judgments he arrives at within his remit'.

(iv)   In _HF (Iraq) (2014) at [42]–[47], Elias LJ rejected the submission that the court was bound by the_
considered guidance issued by the UNHCR unless it could point to flaws in the analysis or there was fresh
evidence providing a proper basis for departing from that guidance. He dealt in detail with the previous
judgments I have mentioned concluding that 'the

authorities which demonstrate the considerable respect which the courts afford to UNHCR material are
entirely consistent with the conventional view that questions of weight are for the court'.

(v)   In AS (Afghanistan) (2021) at [17]–[23], Davis LJ reinforced, in effect, the summary of the position in
_HF (Iraq)._



**[87] In my view, these authorities demonstrate that particular importance should be attached to the evidence and**
opinions from the UNHCR, even though that evidence is not necessarily decisive nor pre-eminent. It is obvious that
the UNHCR's evidence will be of greater weight when it relates to matters within its particular remit or where it has
special expertise in the subject matter.

**[88] The Divisional Court said at [71] that the UNHCR's opinion carried no overriding weight and had to be**
considered together with all the other evidence to decide whether, on the totality of that evidence, the SSHD's
opinion was undermined to the extent it can be said to be legally flawed. In my judgment, this view was in error
insofar as the Soering test was concerned, since the focus there was not on any legal flaws in the SSHD's decision,
but on whether, on the basis of all available evidence, there were substantial grounds for thinking that asylum
seekers would face real risks of art 3 ill-treatment in Rwanda. As I have explained, the two things are not the same.

**[89] Against that background, I turn to the question of whether (a) the evidence of the UNHCR, (b) what occurred**
under the Israel/Rwanda agreement, (c) what occurred at the Kiziba refugee camp in 2018, and (d) Rwanda's
history of refoulement and of defects in its asylum system, undermined the UK Government's good faith opinion that
Rwanda would honour its obligations.

**[90] The SSHD submitted to us, in effect, that, in the light of the detailed guarantees and assurances in the MEDP**
and the UK's longstanding relationship with Rwanda and its financial and other incentives to perform on its
obligations, what happened in the past was of limited, if any, real significance. This was a key submission, because
the UNHCR's evidence was all directed to what had happened in the past and what was happening at the current
time. The SSHD said that a predictive evaluation was needed, and that in such an exercise, it was not significant
that things had been less than ideal in the past.

**[91] I do not accept that the past and the present can either be ignored or side-lined as the SSHD suggests. Of**
course, a predictive evaluation is required, and of course great weight will be given to the guarantees and
assurances of the Rwandan Government. But the likelihood of promises being performed must, anyway in part, be
judged by reference to what has happened in the past and the capacity and capability of the entity making the
promises to keep them. The SSHD acknowledges, in effect, that the Rwandan asylum system has some way to go


-----

High Commissioner for Refugees intervening) and ot....

if it is to perform according to the MoU and the Notes Verbales. But she submits that its capacity can and will be
built and that Rwanda will not accept more asylum seekers than it can handle in strict accordance with the MEDP.

**[92] The balancing exercise that the court needs to undertake in making the Soering assessment I have described**
is multi-factorial and complex. I confess to having vacillated within the decision-making process. Ultimately,
however, I have concluded that there were substantial grounds for thinking that asylum seekers sent to Rwanda
under the MEDP, as at the date of the SSHD's decision-making in these cases in July 2022, faced real risks of art 3
**[*286]**

mistreatment. That is the consequence of the historical record described by the UNHCR, the significant concerns of
the UNHCR itself, and the factual realities of the current asylum process in Rwanda. In practice, Rwanda can only
deliver on its good faith assurances if it has control mechanisms and systems in place to enable it to do so. Both
history and the current situation demonstrate that those mechanisms have not yet been delivered. They may in the
future be delivered but they are not, on the evidence, there now. I have read Underhill LJ's impressive and
comprehensive judgment on these points and broadly agree with it. As it seems to me, it supports the conclusions I
have reached.

**[93] In identifying some of the most important features of the evidence in the following paragraphs, I should not be**
taken as having excluded any parts of the massive body of evidence from my evaluation. It is, as I have said, a
multi-factorial exercise giving due weight to the Rwandan Government's assurances, coming as they do from a
party to Refugee Convention, the SSHD's opinion that the assurances will be realised, and the evidence from other
quarters, notably the UNHCR.

**[94] So far as the UNHCR is concerned, it is not disputed that it was entrusted in 1950 by the UN with the mandate**
to supervise the application of the Refugee Convention. The UNHCR has been present in Rwanda since 1993 and
had at the time of its evidence 332 staff there. It plays no official role in Rwanda's asylum system, and has been
denied observer status at RSDC sessions. It does, however, fund and train non-governmental organisations
working with the Rwandan asylum system. As the appellants submitted, a Home Office memorandum of 22
February 2022 recognised the UNHCR's expertise in relation to Rwanda, and an 8 March 2022 Home Office email
said that the UNHCR was a critical part of assessing Rwanda's safety.

**[95] The UNHCR's evidence was that Rwanda's asylum process is 'marked by acute arbitrariness and unfairness,**
some of which is structurally inbuilt, and by serious safeguard and capacity shortfalls, some of which can be
remedied only by structural changes and long-term capacity building'. The DGIE plays the role of gatekeeper to the
entire system. Although the DGIE is not authorised in law to reject asylum claims, and despite Rwandan
Government denials, it summarily rejected without reasons 8% of the 319 asylum claims of which the UNHCR was
aware between 2020 and June 2022. There are serious deficiencies in the rights of an asylum seeker to be heard
after a perfunctory 20–30 minute interview with the DGIE, from which lawyers and representatives are excluded.
The process at all levels, before the DGIE, the RSDC and the Minister, is marked by an absence of representation,
interpretation and written reasons. Where reasons are provided, they are often perfunctory and inadequate: the
Court was shown evidence of RSDC decision letters, including several issued after the conclusion of the MEDP,
which rejected asylum claims either without reasons, or with very slim reasons. For example, a standard response
from the RSDC was that 'Refugee Status requested was not granted because you don't meet the eligibility criteria,
and the reasons you provided during the interview were not pertinent'. There has not yet been an appeal to the
court and there are concerns as to the willingness of the judiciary to find against the Rwandan Government. The
same processes of DGIE, RSDC, and the Minister, as have proved defective in the past, are envisaged under the
MEDP. In this respect, I agree with, and adopt, Underhill LJ's analysis at [158]–[223], where he breaks down the
stages of the
**[*287]**

Rwandan RSD process and explains why the UNHCR's criticisms of that process merit more consideration than
was given to them by the Divisional Court.


-----

High Commissioner for Refugees intervening) and ot....

**[96] The UNHCR's evidence shows 100% rejection rates at RSDC level for nationals of Afghanistan, Yemen and**
Syria, from which asylum seekers under the MEDP may well emanate (I note here that my conclusion is the same
as Underhill LJ at [200]). The overall rejection rate for the 156 cases covered by the figures is 77%. Of the 34 recent
asylum seekers from a country with close bilateral relations with Rwanda, three were peremptorily rejected by the
DGIE, three were forcibly expelled to the Tanzanian border, two were instructed to leave Rwanda within days, and
two more were threatened with direct expulsion to their country of origin. In addition, there have been 5 recent
cases of expulsion of those arriving at Kigali airport: two Libyans removed from Kigali airport in February 2021, two
Afghans chain refouled to Afghanistan on 24 March 2022, and one Syrian chain refouled to Syria on 19 April 2022.
The cases of airport refoulement do not themselves demonstrate that there would be a real risk of identical methods
of refoulement under the MEDP, since those asylum seekers arriving in Rwanda would have been pre-approved by
the Government of Rwanda and would arrive on planned flights. These instances nonetheless illustrate, as
described by Underhill LJ at [156], 'a culture of, at best, insufficient appreciation by DGIE officials of Rwanda's
obligations under the Refugee Convention, and at worst a deliberate disregard for those obligations'. The Divisional
Court was provided with a table of instances of at least 100 allegations of refoulement and threatened refoulement
cited in the UNHCR's evidence and in notes of meetings with the SSHD. The UNHCR does not accept that the
guarantees will be sufficient to prevent the risk of these events occurring to those accepted by Rwanda under the
MEDP.

**[97] The Rwandan Government's responses to these contentions demonstrate its misunderstanding of the meaning**
of the concept of refoulement. The UNHCR says that its responses are 'indicative of fundamental
misunderstandings … of its obligations under the Refugee Convention and give no reason to believe that such
practices will change'. In essence, the Rwandan Government suggests that it can reject asylum claims and expel
people where they seek asylum using forged documents (as many do), or have not been granted an entry visa, or
where domestic immigration law allows. The UNHCR informed the UK Government in the weeks prior to a meeting
in Kigali on 25 April 2022 about three recent cases of the refoulement of two Afghans and one Syrian who were
denied asylum and put on flights out of Rwanda. The Rwandan Government's response to this claim was a
demonstration of its misunderstanding of the meaning of refoulement. It said that deceitful travellers attempting to
abuse its border openness are routinely intercepted, but if the immigrant invokes an asylum claim 'as an alternative
reason after failing to satisfy immigration entry requirements', deportation will continue whenever necessary. Whilst
it also says that such things will not happen under the MEDP, the concern of the UNHCR is as to what happens to
those sent to Rwanda under that scheme, whose asylum claims are rejected.

**[98] The detailed monitoring mechanisms are likely to come too late to affect the risk of these initial asylum seekers**
facing art 3 mistreatment. Moreover, it is unclear that these monitoring mechanisms would account sufficiently for
the approach to the granting of asylum taken up to now by the Rwandan Government, which I have outlined in the
previous paragraph.
**[*288]**

**[99] The same can be said for the training of those making asylum decisions in Rwanda. At the time of the**
Divisional Court hearing, and on the evidence before this court, there was simply insufficient evidence to
demonstrate that officials would be trained adequately to make sound, reasoned, decisions. In this respect, I agree
with Underhill LJ at [245]–[260].

**[100] The ultimate reliability of the safeguards in the Rwandan asylum system will depend on the promised ability of**
asylum seekers to appeal to the court. That is not to ignore the fact that the bulk of the claims will be determined by
non-judicial means, but to reassert that access to the courts is a core component of the right of access to justice.
The Divisional Court in _Govt of Rwanda v Nteziryayo_ _[2017] EWHC 1912 (Admin),_ _[[2017] All ER (D) 203 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P4T-VGF1-DYBP-N46G-00000-00&context=1519360)_
considered the independence of the Rwandan judiciary in an admittedly different context, but at some considerable
length. It concluded at [234]–[240] and [372]–[374] that 'the evidence points to some risk, depending on the
evidence before them and the safeguards in play, that judges might yield to pressure from the Rwandan authorities'
(see also the findings below in that case recorded at [149]). An FCDO (Foreign, Commonwealth and Development
Office) comment on an FCDO draft document entitled 'review of asylum processing: Rwanda' from April 2022 said
that Rwanda was: ' the country of contradictions For these cases I agree the legal support is likely to be


-----

High Commissioner for Refugees intervening) and ot....

independent … unless it gets political. Which may be farther down the road when refugees are in a process [of]
settlement and make demands on certain things. The Rwandan legal system is not independent, is regularly
interfered with and is politicised. Opposition/political cases do not receive a fair trial or support'.

**[101] The SSHD submitted that the UNHCR's evidence as to the Israel/Rwanda agreement was irrelevant. I do not**
agree. Mr Bottinick explained that it was illustrative of the 'danger and suffering that are, in UNHCR's view, liable to
arise from the UK's externalisation plan'. The UNHCR gathered the information it provided from interviews between
2015 and 2017 with those who had been sent to Rwanda. Arrivals under that arrangement were 'routinely moved
clandestinely to Uganda even if they were willing to stay in Rwanda'. Mr Bottinick concluded that the 'UNHCR
considers that the UK-Rwanda Agreement creates serious risks of (a) increased people smuggling, and (b) an
increase in asylum seekers being exposed to dangerous journeys and life-threatening conditions'.

**[102] The UNHCR drew our attention to the decision of the Israeli Supreme Court in Sagitta v Ministry of Interior**
(Administrative Appeal 8101/15). We were provided with an unofficial translation. It is clear from para 87 of that
judgment that the court held that the agreement between Israel and Rwanda (which we have not seen) was
'specific' insofar as it related to the rights granted to the deportees and included 'an explicit undertaking of [Rwanda]
according to which the deportees will enjoy human rights and freedoms and that the principle of non-refoulement
shall be complied with'. Accordingly, this constituted some evidence that the breaches mentioned by the UNHCR
occurred notwithstanding Rwandan Government assurances to the contrary. The Rwandan Government's response
to the allegations lacked substance. It merely said that Rwanda had entered into other transfer arrangements for
the international protection of refugees that differed from the Israel/Rwanda scheme.

**[103] As regards the events at Kiziba camp in Rwanda, the UNHCR's evidence was that in February 2018, about**
700 Congolese refugees resident
**[*289]**

there had marched towards Karongi town and camped outside the UNHCR Karongi Field Office. The refugees were
protesting against a 25% cut in food rations. Two days later, the Rwandan police fired live ammunition on protesting
refugees killing at least 12 people. Between February and May 2018, 66 refugees were arrested, and many were
charged with a range of offences including 'spreading false information with intent to create a hostile international
opinion against the Rwandan state' (art 451 of the Penal Code), 'inciting insurrection or trouble amongst the
population' (art 463 Penal Code), and participating in an illegal demonstration or public gathering (art 685 Penal
Code). Human Rights Watch's investigation found that the refugees were unarmed and that the Rwandan police
had used excessive force. Although Rwanda's National Commission for Human Rights expressed the view that the
police responded as a last resort to a violent attack, the UNHCR has grave concerns that asylum seekers relocated
under the MEDP would be at significant risk of harm and detention if they expressed dissatisfaction through
protests in Rwanda.

**[104] In my judgment, the problem with uncritical acceptance of the SSHD's view that the unequivocal assurances**
in the MEDP can wipe away all real risk of art 3 violations is that the structural institutions that gave rise to past
violations remain in Rwanda today. The DGIE will still be responsible for asylum seekers arriving from the UK. It
may have had some more training (though Mr Bottinick describes that as being at 'an extremely basic level'), but it
is the same institution. The RSDC will still decide asylum claims without the applicants being legally represented.
The members of the RSDC may have learnt something since past violations, but it is impossible to be sure that they
will be fair, when their processes are not attended by third parties. The appeals to the Minister and to the court are
largely or, in the case of the court, completely untested. Rwanda is still, as the UK Government acknowledges, a
one-party state which reacts unfavourably to dissent (see also Human Rights Watch's public letter to the SSHD
dated 11 June 2022, expressing its concerns about likely art 3 breaches). It is not an answer to say that Rwanda
will have accepted the people sent under the MEDP, because the advanced information they will have about them
will be limited and they may form adverse political opinions once there.

**[105] The application of the Soering test requires the court to find there are 'substantial grounds' for thinking there is**
a real risk of art 3 breaches. I have concluded that the matters I have mentioned, weighed against the Rwandan


-----

High Commissioner for Refugees intervening) and ot....

assurances and the SSHD's view, giving appropriate but not overriding weight to the evidence of the UNHCR,
means that such substantial grounds existed as at July 2022. I am conscious that Underhill LJ has expressed the
view at [132] that the correct date for our consideration of the generic issues was September and October 2022
when the hearing took place before the Divisional Court. I understand his reasoning, but it seems to me that this is
an appeal from the generic decisions made by the Divisional Court which were taken in respect of the position as at
July 2022. That said, I do not think that there was any material difference between the position as at the two dates,
and I would make the same decision whichever of those dates was being considered.
**[*290] Issue 4: Was the Divisional Court right to conclude at [73]–[77] that there was no real risk that the response**
_of the Rwandan authorities to hostile political opinions expressed by asylum seekers in the future might subject_
_them to article 3 ill-treatment?_

**[106] In effect, this question has already been answered under the previous issue. I do not think that the Divisional**
Court was right to compartmentalise the Soering test. It would have been better if it had asked itself whether, having
regard to all the Rwandan Government's guarantees and assurances, the SSHD's view that they would be complied
with, and all the evidence including the evidence of the UNHCR, there were substantial grounds for thinking that
asylum seekers sent to Rwanda under the MEDP would face any real risk of art 3 mistreatment. I also adopt
Underhill LJ's comments at [290]–[291].

**[107] Accordingly, in my view, the events at Kiziba, to which the Divisional Court referred at [74], were something**
that ought to have been taken into account generally in relation to the _Soering test, rather than specifically in_
relation to the conditions in Rwanda generally.
_Issue 5: Bearing in mind the correct test, was the Divisional Court right to decide at [64] that the SSHD was entitled_
_to rely on the assurances contained in the MoU and Notes Verbales?_

**[108] I can fully understand why the SSHD might have thought in good faith that she could rely on the Rwandan**
Government's assurances in the MEDP. The court has, however, now made an objective evaluation of the Soering
test on the basis of evidence that either was or ought to have been available to her. On that basis, the SSHD ought
not reasonably to have relied on the assurances in the MEDP.
_Issue 6: Were there in fact substantial grounds for thinking, bearing in mind the guarantees and assurances, that (a)_
_Rwanda was not a safe third country, (b) there were real risks of refoulement or article 3 breaches, and (c) there_
_were real risks that asylum claims would not be properly determined?_

**[109] The answer to this issue is now also clear. There were substantial grounds for thinking, bearing in mind the**
guarantees and assurances, that (a) Rwanda was not a safe third country, (b) there were real risks of refoulement
or art 3 breaches, and (c) there were real risks that asylum claims would not be properly determined. I refer
specifically to [273]–[286] of the judgment of Underhill LJ for his analysis of how the risk of refoulement may
eventuate.

**[110] It is important to understand how the conditions on the ground justify the conclusion that Rwanda was not a**
safe third country for the purposes of refoulement and art 3. In effect, that is because where a country's domestic
asylum processes are deficient to the extent set out above, and in Underhill LJ's judgment, that will provide an
insufficient safeguard, in particular for asylum seekers whose claims are rejected. Those asylum seekers risk being
returned either directly to their country of origin or indirectly through a third country. They will thereby face real risks,
in circumstances where they should not have been returned at all. A robust and effective asylum process in the
receiving state is a necessary bulwark to mitigate against the risk of refoulement and related ill-treatment.
**[*291] Issue 7: Was the Divisional Court right to conclude at [71] that the SSHD's decision that, for the purposes of**
_the criteria at paragraph 345B(ii) to (iv), Rwanda was a safe third country, was neither irrational, nor a breach of_
_article 3?_

**[111] It does not necessarily follow from what I have already said that the SSHD's decision to accept the Rwandan**
Government's assurances was either irrational or itself a breach of art 3, although it gives rise at least to a real risk
of such a breach. In the light of the answer I have given to the Soering question, it is not necessary for the court to
reach a conclusion on this issue and I would prefer not to do so.


-----

High Commissioner for Refugees intervening) and ot....

_Issue 8: Was the Divisional Court right to accept at [59] that the SSHD complied with the obligations identified in_
_Ilias, namely to undertake a 'thorough examination' of 'all relevant generally available information'?_

**[112] The Divisional Court spent much time examining the** _Ilias question of whether the SSHD made a thorough_
examination of all relevant generally available information. As explained in _Ilias itself, the duty to undertake a_
thorough examination is primarily a procedural one. Having determined the substantive question, I do not think it is
necessary to decide the procedural one, which looks in detail at the process that the SSHD undertook, rather than
the substantive issue that had to be resolved. Underhill LJ takes the same approach at [266]. The SSHD
undoubtedly considered much of the material available to the court.
_Issue 9: Was the Divisional Court right to accept at [61] that the SSHD complied with her Tameside duty to ask_
_herself the right question and take reasonable steps to acquaint herself with the relevant information to enable her_
_to answer it correctly?_

**[113] The Divisional Court also spent much time examining the** _Tameside question of whether the SSHD asked_
herself the right question and took reasonable steps to acquaint herself with the relevant information to enable her
to answer it correctly. Again, like Underhill LJ (at [266]), I do not think that, in the light of the conclusions I have
reached on the substantive question, it is necessary to answer this question.
_Issue 10: Was the Divisional Court right at [72] to decide that the Inadmissibility Policy, including the possibility of_
_removal to a safe third country, was not Gillick unlawful?_

**[114] The Divisional Court asked itself whether the Inadmissibility Guidance positively authorised or approved**
unlawful conduct. It held it did not, because the SSHD could have lawfully concluded that Rwanda was a safe third
country, and that asylum claims would be effectively determined. In the light of the answer to the Soering question,
it is not necessary to determine whether the Inadmissibility Guidance itself was also unlawful. If I had thought it
necessary to decide the Gillick issue, I would have agreed with [296]–[301] of the judgment of Underhill LJ.
**[*292] Issue 11: Were the SSHD's certifications under paragraphs 17(c) and/or 19(c) unlawful, because the asylum**
_seekers' ECHR claims were not clearly unfounded?_

**[115] The SSHD, in fact, certified (i) under para 17(c) that in her opinion Rwanda was a place where the asylum**
seekers' 'life and liberty will not be threatened by reason of [their] race, religion, nationality, membership of a
particular social group or political opinion', and 'from which the person will not be sent to another State otherwise
than in accordance with the Refugee Convention', and (ii) under para 19(c) that the asylum seekers' human rights
claims were clearly unfounded, meaning that they could not bring an immigration appeal from within the United
Kingdom in reliance on those claims.

**[116] It follows from what I have already said that the court could not endorse the SSHD's opinion under para 17(c)**
that Rwanda was a place where the asylum seekers would not be subjected to the risk of ECHR breaches or
refoulement. In that respect, I agree with Underhill LJ at [302]. It also follows that I do not agree with the SSHD's
certification under para 19(c) that the asylum seekers' ECHR claims were clearly unfounded.

**[117] As suggested at [10] above, the 'clearly unfounded' test is a stricter one than the** _Soering test which asks_
whether there are substantial grounds for thinking there are real risks of art 3 mistreatment. In these circumstances,
the SSHD ought not to have certified the appellants' ECHR claims under para 19(c). The result is that the claims
ought to have been permitted to be pursued in the usual way through the Tribunals process.
**THE REMAINING ISSUES**

**[118] I agree with the judgment of Underhill LJ as to the answers to the remaining five issues, namely:**

(i)   Issue 12: Should the Divisional Court have concluded that removal of asylum seekers to Rwanda
under the MEDP was inconsistent with art 33, or constituted the imposition of a penalty contrary to art 31?
(See the judgment of Underhill LJ at [304]–[339].)

(ii)   Issue 13: Should the Divisional Court have concluded that arts 25 and 27 of the Procedures Directive
made the MEDP unlawful because it was still retained EU law? (See the judgment of Underhill LJ at [340]–

[367] )


-----

High Commissioner for Refugees intervening) and ot....

(iii)   Issue 14: Should the Divisional Court have decided that the SSHD had created a presumption that
Rwanda was safe in her assessment documents, thereby circumventing the statutory scheme? (See the
judgment of Underhill LJ at [368]–[377].)

(iv)   Issue 15: Should the Divisional Court have decided that the SSHD's alleged breaches of the UK
GDPR would, if established, invalidate the SSHD's decisions under the MEDP? (See the judgment of
Underhill LJ at [378]–[400].)

(v)   Issue 16: Should the Divisional Court have decided that the three decisions to treat the asylum
application as inadmissible under para 345A, to decide to remove the asylum seeker to Rwanda under
para 345C, having decided that Rwanda was a safe third country under para 345B, and to make a
certification decision under para 17(c) to the effect that Rwanda was a safe country for the asylum seeker,
were rendered unlawful by procedural unfairness? (See the judgment of Underhill LJ at [401]–[455].)

**[*293] CONCLUSIONS**

**[119] I would, as I have said, allow the appeal on the** _Soering issue. The Lord Chief Justice, for the reasons he_
gives, would dismiss the appeal. Since Underhill LJ agrees with me on the _Soering issue, the appeal will be_
allowed. We will invite the parties to agree an appropriate order to reflect this judgment and that of Underhill LJ.

**UNDERHILL VP.**
**INTRODUCTION**

**[120] I have read the judgment of the Master of the Rolls. I gratefully adopt his summary of the background facts**
and issues, although I will occasionally repeat matters to save the need for cross-reference. I will use the term
'Claimants' to refer to the individual Appellants (ie apart from Asylum Aid) collectively. Like the Master of the Rolls, I
will take first the issues relating to the safety of Rwanda, on which the Claimants' submissions were advanced by
Mr Raza Husain KC and the Secretary of State's by Sir James Eadie KC.
**A. SAFETY OF RWANDAThe background law**

**[121] It has been established since the decision of the European Court of Human Rights ('the ECtHR') in Soering v**
_[UK (App no 14038/88) (1989) 11 EHRR 439, [1989] ECHR 14038/88 that it is a breach of art 3 of the European](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)_
Convention on Human Rights ('the ECHR') for a contracting state to remove an individual to a third country
(whether or not itself a contracting state) where there are substantial grounds for believing that they will be at real
risk of being treated contrary to the standards required by that article – this is the so-called 'Soering test'. The
position is helpfully summarised at para 126 of the judgment of the Grand Chamber of the ECtHR in Ilias v Hungary
[(App no 47287/15) (2019) 47 BHRC 497, (2020) 71 EHRR 6, as follows:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y49-BT73-GXFD-8139-00000-00&context=1519360)

'Deportation, extradition or any other measure to remove an alien may give rise to an issue under art 3,
however, and hence engage the responsibility of the Contracting State under the Convention, where
substantial grounds have been shown for believing that the person in question, if removed, would face a real
risk of being subjected to treatment contrary to art 3 in the receiving country. In such circumstances, art 3
implies an obligation not to remove the individual to that country …'

**[122] That principle was applied in the context of asylum-seekers in MSS v Belgium and Greece (App no 30696/09)**
_[(2011) 31 BHRC 313, (2011) 53 EHRR 28, in which the ECtHR held that Belgium was in breach of art 3 by](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W32M-00000-00&context=1519360)_
returning asylum-seekers under the Dublin regime to Greece where (as it held separately) there were substantial
grounds for believing that there was a real risk that their art 3 rights would be breached. In such a case the risk may
take the form of serious ill-treatment in the country to which they are returned, but it may also take the form of the
risk of refoulement (direct or indirect) to their country of origin where they have a well-founded fear of persecution:
in MSS both risks were in fact found to be present. References in this context to whether the third country is 'safe'
cover both aspects.
**[*294]**


-----

High Commissioner for Refugees intervening) and ot....

**[123] As regards the latter risk – that is to say, the risk of direct or indirect refoulement – the Grand Chamber in Ilias**
observes, at para 131, that 'the main issue … is whether or not the individual will have access to an adequate
asylum procedure in the receiving third country'. The reason is obvious: if the asylum-seeker does not have access
to such a procedure there will _prima facie be a real risk of their being refouled, either because their claim is not_
entertained at all or because it is not determined properly and fairly. As it says at para 137:

'Where a Contracting State removes asylum seekers to a third country without examining the merits of their
asylum applications, however, it is important not to lose sight of the fact that in such a situation it cannot be
known whether the persons to be expelled risk treatment contrary to art 3 in their country of origin or are simply
economic migrants. It is only by means of a legal procedure resulting in a legal decision that a finding on this
issue can be made and relied upon. In the absence of such a finding, removal to a third country must be
preceded by thorough examination of the question whether the receiving third country's asylum procedure
affords sufficient guarantees to avoid an asylum-seeker being removed, directly or indirectly, to his country of
origin without a proper evaluation of the risks he faces from the standpoint of art 3 of the Convention.'

It follows, as it goes on to say at para 139, that:

'On the basis of the well-established principles underlying its case-law under art 3 of the Convention in relation
to expulsion of asylum-seekers, the Court considers that the above-mentioned duty requires from the national
authorities applying the “safe third country” concept to conduct a thorough examination of the relevant
conditions in the third country concerned and, in particular, the accessibility and reliability of its asylum system.'

**[124] Where the safety of the third country depends on assurances given by its government about the treatment**
which the individual will receive on return, it is necessary to consider the reliability of those assurances in
accordance with the guidance given by the ECtHR in _Othman (Abu Qatada) v UK_ (App no 8139/09) _[(2012) 32](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1MB-00000-00&context=1519360)_
_[BHRC 62, (2012) 55 EHRR 1, as set out at para [32] of the judgment of the Master of the Rolls. But the underlying](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1MB-00000-00&context=1519360)_
question remains whether there are substantial grounds for believing that there is a real risk of a breach of art 3.

**[125] If the relocation of asylum-seekers to Rwanda under the MEDP involves a breach of their art 3 rights it would**
[of course be unlawful as a result of s 6 of the Human Rights Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)
_The shape of the case_

**[126] The Claimants contend that Rwanda is 'unsafe' in both the respects identified above – that is to say both**
because of the risk of serious ill-treatment in Rwanda itself and because of the risk of refoulement as a result of the
inadequacies of its asylum system. However, in their submissions before us – as indeed, as I understand it, they did
in the Divisional Court – they have concentrated mainly on the latter risk. I will accordingly focus on the question
identified in Ilias, namely 'whether or not the individual will have access to an
**[*295]**

adequate asylum procedure in the receiving third country'. I consider the question of other potential ill-treatment in
Rwanda at paras [287]–[291] below.

**[127] Before proceeding further I need to deal with three preliminary matters.**

**[128] First, the Claimants contend that in the part of its judgment in which the Divisional Court considered the**
adequacy of the asylum system, at paras [62]–[71], it proceeded on the basis that its task was not to decide that
question for itself but only to decide whether the Secretary of State was entitled to conclude that the system was
adequate. The Master of the Rolls considers that contention as his Issue 1 and concludes that the criticism is wellfounded. The Lord Chief Justice has reached the opposite conclusion.

**[129] For me the issue is not of crucial importance, since, for reasons which will appear, I believe that even if the**
Court asked itself the right question its answer was wrong. However, if it were necessary I would, albeit with
hesitation, accept the Claimants' submission. Like the Lord Chief Justice, I do not accept for a moment that this
experienced Court failed to appreciate the difference between the approaches required to determining a claim for


-----

High Commissioner for Refugees intervening) and ot....

judicial review and a claim of a breach of the ECHR, and I agree with him that its initial statement of the art 3 issue,
at para [39] of its judgment, was unimpeachable. But I think, with respect, that in its attempt to bring order to the
confusing way in which the issues were presented it created a problem for itself by addressing the Claimants' case
under art 3 and their conventional judicial review claim under a single heading. That made it difficult to keep the
different approaches distinct. At a number of points in the relevant passage, it uses what is unambiguously the
language of judicial review when addressing the particular issues that are determinative of its overall conclusion on
the adequacy of the Rwandan asylum system. In summary:

(1)   It begins its consideration, at para [62], by characterising the question which it had to consider as
being 'whether the Home Secretary was entitled to conclude that there were sufficient guarantees to
ensure that asylum seekers relocated to Rwanda would have their asylum claims properly determined
there and did not run a risk of refoulement … and that Rwanda was a safe third country …'. Although I give
weight to what the Lord Chief Justice says at para [489] of his judgment, it seems to me clear that the
whole sentence, including the words which I have italicised, is governed by the phrase 'entitled to conclude'
(which I also note that the Court uses again later in the same paragraph).

(2)   The Court states its conclusion, at the beginning of para [64], as being that 'the Home Secretary is
_entitled to rely on the assurances contained in the MoU and Notes Verbales'._

(3)   In para [66] of its judgment, which I quote in full at para [269] below, it places considerable weight on
the evidence of Mr Simon Mustard, the Director, Africa (East and Central) at the FCDO, stating that it could
only go behind his opinion if there were compelling evidence to the contrary. That in itself may be
consistent with the correct test, but at para [68] it describes an approach taken by him to part of the
evidence as 'permissible', observing that it did not 'consider it discloses any error of law'.

(4)   At para [70], it records the opinion of UNHCR that, in effect, the assurances given by the
Government of Rwanda ('the GoR') could not be relied on, but observes that:

**[*296]**

'[T]hat is not the question we must address. The question is whether, notwithstanding the opinion the UNHCR
has now expressed, the Home Secretary was entitled to hold the contrary opinion.'

At para [71] it says that its task is to decide whether on the totality of the evidence 'the Home Secretary's
opinion is undermined to the extent it can be said to be legally flawed'.

Despite my reluctance to believe that the Court really fell into the error alleged, we must proceed by reference to
the language which it has used unless it is clear that it does not reflect its true reasoning; and I cannot say that that
is the case.

**[130] Second, Mr Husain sought at one stage in his submissions to argue that because the Secretary of State had**
certified the human rights claims made by (most of) the individual Claimants under para 19 of Sch 3 to the Asylum
and Immigration (Treatment of Claimants, etc) Act 2004 (with which I deal more fully in connection with Issue 14
below) the Divisional Court should have been concerned only with whether their claims based on art 3 were 'clearly
unfounded' and not sought itself to determine those claims: see in particular para 43 of the AAA Claimants' skeleton
argument. With respect, that is a confusion. Although the human rights claims in question were indeed certified, the
Claimants' challenge to that certification is not before us because it succeeded in the Divisional Court (albeit, as the
Court made clear at para [179] of its judgment, on procedural grounds rather than on the substance of the art 3
claims); and the Secretary of State has not appealed. Accordingly, we are concerned only with the separate
'generic' challenge advanced by the Claimants to the lawfulness of (in shorthand) 'the Rwanda policy', and the
challenges to the lawfulness of the individual certification decisions are an irrelevance.

**[131] Having said that, I cannot help noting that the fact that the safety of Rwanda issue arises in the context both**
of the generic challenge to the Rwanda policy and of the challenges to the certification of the individual claims
potentially creates a procedural conundrum about which challenge should be prioritised. If the only challenge had
been to the certification of the human rights claims in the individual cases, the question for the Divisional Court
would have been whether an appeal to the First tier Tribunal ('the FTT') against the refusal of those claims had a


-----

High Commissioner for Refugees intervening) and ot....

realistic chance of success. If the Court had held that it did, the judicial review proceedings would have achieved
their aim and an appeal to the FTT would have proceeded. It is not clear to me that the position should necessarily
be different where, as here, claimants plead a distinct challenge to the policy underlying the individual decisions. It
is at least arguable that in such a case the better course is for the court to determine the challenge to the
certification first, and, if it succeeds, to decline to consider the generic challenge on the basis that the FTT was the
more appropriate forum, both because of its specialist expertise and because it would normally hear oral evidence[1].
However, that question no longer arises in this case, if it ever did, and I mention it only in case it is relevant to future
cases.

**[132] Third, the fact that we are on this appeal concerned with a challenge to the lawfulness of the policy means**
that we are not required to focus on the

3

dates of the decisions in the individual cases (ie 5 July 2022). In substance, we are concerned with the lawfulness
of the policy as at the date of the hearings before the Divisional Court in September and October: I note that the
Master of the Rolls takes a different view (see para [105] above) but I agree with him that the point makes no
difference in practice. Another consequence is that we are not concerned with the risk of refoulement in the case of
all or any of the individual claimants. Rather, we are concerned with the risk to the group as a whole to whom the
asylum policy is intended to be applied.
_The Rwandan asylum system_

**[133] Section 9 of the MoU reads:**

**'Asylum processing arrangement**

9.1 Rwanda will ensure that:

9.1.1 at all times it will treat each Relocated Individual, and process their claim for asylum, in accordance with
the Refugee Convention, Rwandan immigration laws and international and Rwandan standards, including
under international and Rwandan human rights law, and including, but not limited to ensuring their protection
from inhuman and degrading treatment and refoulement;

9.1.2 each Relocated Individual will have access to an interpreter and to procedural or legal assistance, at
every stage of their asylum claim, including if they wish to appeal a decision made on their case; and

9.1.3 if a Relocated Individual's claim for asylum is refused, that Relocated Individual will have access to
independent and impartial due process of appeal in accordance with Rwandan laws.

9.1.4 If a Relocated Individual does not apply for asylum, Rwanda will assess the individual's residence status
on other grounds in accordance with Rwandan immigration laws.'

(The term 'Relocated Individuals' – or RIs, as it appears in some Home Office documents – has a rather depersonalising tone, but I will sometimes use it for convenience.) More detailed guarantees are given in the Asylum
Process Note Verbale ('the APNV'). I will refer to its particular provisions later as relevant.

**[134] I should summarise in outline the Rwandan process for determining individual asylum claims, described as**
the 'refugee status determination', or 'RSD', process. The basis of the process is a law passed in 2014, in some
respects supplemented by subsequent Prime Ministerial Orders. Unfortunately, not all its details are clear, but I will
defer consideration of the points of difficulty. The relevant stages are as follows:

1 Cf my observations at para [242] of my judgment in NA (Sudan) v Secretary of State for the Home Dept, MR (Iran) v Secretary
_of State for the Home Dept_ **_[[2016] EWCA Civ 1060, [2017] 3 All ER 885, albeit that the procedural context was different.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P8M-7XD1-DYBP-M3KD-00000-00&context=1519360)_**

**[*297]**


-----

**[*298]**


High Commissioner for Refugees intervening) and ot....

(1)   A claim for asylum must be made in writing and registered with the Directorate General of
Immigration and Emigration ('DGIE'), which is an entity within the National Intelligence and Security
Service. DGIE will interview the claimant following receipt of the written claim and should within fifteen days
forward the file, including a record of the interview, to the Refugee Status Determination Committee ('the
RSDC'), which operates under the auspices of the Ministry in Charge of Emergency Management
('MINEMA'). It should also issue a temporary residence permit.

(2)   Before a case is considered by the RSDC it is reviewed by a MINEMA 'Eligibility Officer'. There is
some uncertainty about the nature and extent

of their responsibility; but in broad terms it is to see that the case is in a fit state to be determined by the
RSDC. This may involve obtaining additional information, including by conducting a further interview with
the claimant.

(3)   The RSDC is the primary decision-maker. It comprises eleven members, being senior officials (at
Director or Director General level) from the Prime Minister's Office, the ministries in charge of refugees (ie
MINEMA itself), foreign affairs, local government, justice, defence forces, natural resources, internal
security, and health, the National Intelligence and Security Service and the National Commission for
Human Rights. Membership goes with a particular post in each body and changes when that individual
changes jobs. Membership is not a full-time role: members will have other time-consuming responsibilities.
It is not therefore a specialist body, though some of the members may have some relevant expertise from
their other roles. It determines claims at regular meetings, their frequency depending on how many claims
require determination: many claims may be determined at each meeting. There is a quorum of seven. The
committee may decide the case on the basis of the file alone or ask the asylum-seeker to attend to be
questioned, referred to as an 'interview': there is an issue as to whether RIs will in all cases have an
interview and if so what its nature is.

(4)   There is a right of appeal to the MINEMA Minister.

(5)   A further appeal lies from the Minister to the High Court of Rwanda. In its current form this right was
introduced in 2018.


The GoR refers to stages (1)–(4) as the 'administrative' phase of the RSD, in contrast to stage (5), which is judicial.

**[135] The Claimants' case that that system is seriously defective is supported by UNHCR as intervener and is**
largely based on the evidence adduced by it[2]. The evidence in question consists of three witness statements from
Lawrence Bottinick, the UNHCR Senior Legal Officer in the United Kingdom, dated 9 June, 26 June and 27 July
2022, to which I refer as 'LB 1–3'. LB 2 is the most substantial: it runs to some 148 paragraphs, with numerous
exhibits. Those exhibits include previous statements by UNHCR about its concerns about the asylum system in
Rwanda, notably a seven-page Note dated 8 June 2022 headed 'UNHCR Analysis of the Legality and
Appropriateness of the Transfer of Asylum-Seekers under the UK-Rwanda Arrangement' ('the UNHCR Note'). Mr
Bottinick's evidence represents the institutional view of UNHCR, and I will sometimes refer to it as the UNHCR
evidence.

**[136] The Master of the Rolls has already quoted the conclusion to LB 2, in which Mr Bottinick expresses UNHCR's**
conclusion about the deficiencies in the Rwandan asylum system: see para [7] above. I have read what he says at
paras [85]–[88] about the weight to be given to UNHCR's opinion, and I respectfully agree with it. As he notes at
para [94], UNHCR has a large and active presence in Rwanda. It is true that the main focus of its activities is in the
large camps housing refugees from neighbouring countries, and on the 'ETM' project under which vulnerable
migrants stranded in Libya are relocated to Rwanda on a temporary basis pending resettlement elsewhere; and Mr
Bottinick complains about the limited extent to which the Rwandan government has allowed it to be engaged in the
RSD process. Nevertheless it is


-----

High Commissioner for Refugees intervening) and ot....

4

clear that UNHCR's staff in Kigali, and its partner organisations, have had extensive dealings with asylum-seekers
who have been through, or sought to go through, that process. Mr Bottinick's witness statements have been
evidently carefully prepared by reference to that experience, with as much detail and identification of sources as
practicable. There is no good reason not to accept what they say on matters of fact except where there is cogent
evidence to the contrary.

**[137] The Secretary of State responded to LB 2 in witness statements from Kristian Armstrong, the Head of the**
Third Country Asylum Partnerships unit in the Home Office ('TCAP'), dated 5, 7 and 22 July 2022. The responses
are, inevitably, dependent on information supplied by the GoR. That information is mainly contained in four exhibits
to Mr Armstrong's witness statements, as follows:

(a)   a nine-page formal Statement dated 2 July from the MINEMA Minister responding to UNHCR's
concerns ('the GoR Statement') – this is directed primarily to the UNHCR Note;

(b)   an undated seven-page response by the GoR to the criticisms made in a number of identified
paragraphs in LB 2 ('the primary GoR response');

(c)   a table dated 5 July sent in an e-mail from the Chief Technical Adviser to the Minister of Justice
headed 'Information required from GoR' responding to 37 numbered questions from the Home Office ('the
tabular response');

(d)   an e-mail dated 19 July 2022 from the Chief Technical Adviser giving additional information on the
processing of claims by the DGIE and the RSDC ('the GoR supplementary e-mail').

Those responses were required at fairly short notice, and I do not underestimate the difficulties in obtaining
information remotely. But I have to say that they are not very satisfactory. It is not stated from which departments or
other sources the statements in them are derived and they are at several points unclear, lacking in detail or
inconsistent.

**[138] The Secretary of State also relies on the witness statement of Chris Williams dated 5 July 2022. Mr Williams**
is an Assistant Director Country Returns and Projects Immigration Enforcement, who was deployed to Rwanda in
mid-May 2022 in order to support the operational aspects of the first relocations, then anticipated for 14 June. That
involved ensuring that the various assurances in the MoU and the NVs could be fulfilled. His witness statement
gives details of what he and his colleagues were told in a number of meetings and discussions with GoR officials,
including a presentation on 25 May from, among others, someone he describes as 'the DGIE Director'. Similar, but
in some respects fuller, information deriving from the same exercise appears in a Home Office document of the
same date called 'MEDP Pre-Departure Assurance' ('the PDA') exhibited by Mr Armstrong.

**[139] I should also mention the suite of 'Country Policy and Information Notes' ('CPINs') published by the Home**
Office in May 2022, all with the general title 'Review of asylum processing'. These comprise a general CPIN headed
'Rwanda: assessment' ('the Assessment CPIN') and two CPINs dealing more fully with specific aspects – 'Rwanda:
country information on the asylum system' ('the Asylum System CPIN') and 'Rwanda: country information on
general human rights' ('the Human Rights CPIN') – to which the Assessment CPIN regularly cross-refers. The
Asylum System CPIN contains an account of the system based on what the CPIT team were told by Rwandan
officials on
**[*300]**

visits in January and March 2022. Full notes of the interviews which they conducted on those visits are published
separately as 'Annex A'. The CPINs are important for the purpose of Issue 13, with which I deal below, but on the

2 I will, as is conventional, refer to UNHCR as an institution rather than as an individual.

**[*299]**


-----

High Commissioner for Refugees intervening) and ot....

issue of the safety of Rwanda it is necessary to proceed by reference to the evidence in the proceedings, as
identified above.

**[140] The Claimants' criticisms of the Rwandan system are summarised under fourteen headings in paras 92–170**
of the AAA Claimants' skeleton argument below. (The skeleton argument before us refers back to those
submissions but is less directly helpful because it is structured by reference to the criticisms which the Claimants
make of the reasoning of the Divisional Court.) UNHCR makes substantially the same criticisms under fifteen heads
in para 18 of its Written Observations in the Divisional Court.

**[141] I propose to consider the Claimants' and UNHCR's criticisms of the Rwandan asylum system in two parts.**
First, I will consider the criticisms directed at particular stages, including the question of whether asylum-seekers
can reliably gain access to the system at all. I will then address three issues which are common to the process as a
whole, namely access to legal assistance/representation; availability of interpreter services; and training. I should
make three points by way of preliminary.

**[142] First, UNHCR's evidence is, necessarily, based on its experience of the system as it operated in the period up**
to the date of LB 2, ie 26 June 2022 (with the exception of a few matters added in LB 3). It is a central part of the
Secretary of State's case that that past experience is not a reliable guide to how those relocated to Rwanda under
the MEDP will be treated, both because the GoR's assurances involve specific improvements in the system as it
may have operated previously and because it will operate in a wholly different context than before. Accordingly, in
what follows I will have to consider not only how the system has operated up to now but the nature of any proposed
changes (including, but not limited to, assurances given in the MoU and the APNV) and the likelihood that they will
be implemented.

**[143] Second, it is important to appreciate that, despite having now been in place for some time, the RSD process**
has in practice been comparatively little used: UNHCR has described it as 'nascent'. Rwanda has for many years
had a very creditable record of granting asylum to large numbers of refugees from neighbouring countries, most of
whom are accommodated in camps where UNHCR has an active role; but until August 2020 asylum was granted
on a 'prima facie basis', ie without individual assessment of the claimants. The first individual assessments made by
the RSDC were made in 2018 and the numbers remain small: see paras [195]–[197] below. There have been
comparatively few appeals to MINEMA and none to the High Court. Although the Divisional Court at paras [55] and

[70] of its judgment drew attention to a review published by UNHCR in July 2020 which was complimentary about
Rwanda's compliance with the Refugee Convention (albeit also expressing some criticisms), that statement was not
directed to the RSD process.

**[144] Third, as will appear, the GoR disputes the factual basis of many of UNHCR's criticisms. The Divisional Court**
says at para [55] of its judgment that it did not believe that it was necessary to resolve most of those disputes, and
in fact it considered only two of them: see paras [202] and [203] below. I agree that in order to reach a conclusion
on the adequacy of the Rwandan asylum system it is unnecessary, even if it were possible, to make definitive
findings on each of the disputed matters of fact. The ultimate question is always whether there are substantial
grounds to believe that there is a real risk
**[*301]**

of a breach of art 3 rights; and for that purpose what is required is an overview of the totality of the evidence (cf the
observations of Lord Hoffmann in an analogous context at paras [45]–[49] of his speech in Secretary of State for the
_Home Dept v Rehman_ _[[2001] UKHL 47, [2002] 1 All ER 122, [2003] AC 153). But it remains necessary at least to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61NX-00000-00&context=1519360)_
review the evidence relating to the more important of UNHCR's criticisms and so far as possible to form a view as
to the reliability of their factual basis.
_Criticisms of particular stages of the processAccess to the RSD Process_

**[145] UNHCR asserts that there have in the recent past been a number of instances where individuals seeking**
asylum in Rwanda have been denied the opportunity to make asylum claims at all. The evidence is of three kinds.


-----

High Commissioner for Refugees intervening) and ot....

**[146] First, UNHCR relies on four instances of 'airport refoulement'[3] between February 2021 and April 2022, in**
which six people – two Libyans, two Afghans, one Syrian and one Yemeni – who had claimed asylum at Kigali
airport on arrival were denied entry by DGIE staff and returned to the countries from which they had flown. The two
Afghans and the Syrian are believed by UNHCR to have been returned from those countries to their countries of
origin, ie refouled; it was able by rapid intervention to prevent a similar outcome for the two Libyans and the
Yemeni. Evidence about these incidents is given in LB 2 and LB 3, but they are also referred to in the UNHCR
Note, and were the subject of two Notes Verbales from UNHCR to the GoR – the first, dated 3 February 2021,
relating to the Libyans and the second, dated 21 April 2022, relating to the Afghans and the Syrian. DGIE's conduct
is said not only to show an arbitrary disregard for the requirements of the Refugee Convention but also to be
evidence of a prejudice against claimants from the Middle East and Afghanistan.

**[147] The GoR accepts that the individuals in question were denied entry and sent back as alleged, but it disputes**
UNHCR's account of the circumstances. Its response appears not only in the primary and the tabular responses but
also in a MINEMA 'Feedback' document dated 11 May 2022 responding to UNHCR's Note Verbale of 21 April.
These are not entirely consistent as regards details (and, confusingly, the primary response refers to five Syrians
rather than the single case raised by UNHCR), but the GoR's essential case is that each of the individuals in
question initially claimed entry on other grounds which proved false (eg possession of forged passports or inability
to substantiate their claim to be travelling for business) and only at that point claimed asylum.

**[148] There are two points made by the GoR in this context which the Claimants say show serious**
misunderstandings of refugee law:

(1)   In the Feedback document MINEMA says:

'… an asylum seeker is required to present his/her need for protection immediately upon arrival at the
airport/entry point but not to invoke asylum claim as an alternative reason after failing to satisfy immigration
entry requirements.'

5

'Cases referred to by UNHCR are not recognised as refoulement because all those cases are foreigners who
have been refused entry visa because they were using forged documents and thus, not meeting immigration
entry requirements.'

The Claimants point out that use of forged documents is not a reason for refusing to consider an asylum
claim.

**[149] The Divisional Court adverts to these cases (except for that of the asylum-seeker from Yemen) at paras**

[53](1) and [55] of its judgment but it makes no findings about what occurred or what conclusions can be drawn
from them. In my view the GoR's responses do not satisfactorily answer the allegation that it acted in breach of the
Refugee Convention by declining to consider the asylum claims made and that its expulsion of the claimants led to
their (indirect) refoulement in some of the cases and risked it in the others; and they do indeed show an imperfect
understanding of the requirements of the Convention.

3 This term is a useful shorthand but it should be used with caution. Where an asylum-seeker comes to Rwanda from a country
('the third country') other than their country of origin, their enforced return to the third country does not in itself constitute
refoulement. It will, however, do so if the third country then expels them in such a way as they are compelled to return to their
country of origin, where they fear persecution – ie indirect refoulement. UNHCR says that that is what happened, or was at risk
of happening, in these cases.

**[*302]**

(There is a similar statement in the tabular response in the answer to qu 34.) The Claimants point out that it is not the
case that an asylum claim must be made immediately.

(2) Th 27 i h b l ( h hi )


-----

High Commissioner for Refugees intervening) and ot....

**[150] It is UNHCR's case that these episodes are very unlikely to be the only instances of airport refoulement. It has**
no presence at the airport, and it will only get to hear of such episodes if the claimants themselves, or other
interested persons, are able to contact it, which would not always be the case.

**[151] Second, paras 112–113 of LB 2 refer to three incidents, involving two families and an individual, where**
access to the asylum process was denied to persons who were already in the country. The claimants were all
nationals of a non-African country with which Rwanda has particularly close relations ('country X'). They made
asylum claims, but DGIE did not refer them to the RSDC. Instead, it gave the claimants a short period of notice to
leave the country, and in fact thereafter simply transported them to the border (in one case Uganda and in the other
Tanzania). It is Mr Bottinick's evidence that they would have been indirectly refouled to country X if UNHCR had not
been able to intervene and find other countries willing to accept them. He relies on these episodes not simply as
instances of DGIE disregarding claimants' Convention rights but of their doing so in the interests of their relationship
with a foreign government. These incidents are not addressed in the GoR's responses or therefore in the Secretary
of State's evidence.

**[152] Third, it relies on the experience of individuals who had sought asylum in Israel but had agreed to be**
relocated to Rwanda under the terms of an agreement between Israel and the GoR. The agreement was in place
between 2013 and 2018. There is no dispute that those who accepted relocation under the agreement suffered
serious breaches of their rights under the Refugee Convention. I can adopt the summary of Mr Bottinick's evidence
on this from para 15 of the AAA Claimants' skeleton argument:

'(i) Many of those relocated were “not permitted to lodge their [asylum] claims” and reported “arrests for lack of
documentation”, “threats of deportation from unknown agents, following which eight disappeared” and
“continuous, random overnight visits by unknown agents at their

**[*303]**

accommodations”. All “feared for their personal safety, and feared refoulement to their country of nationality”.
Further asylum-seekers later became known to UNHCR, of whom another seven “went missing”. Relocated
asylum-seekers were “routinely moved clandestinely to Uganda even if they were willing to stay in Rwanda”.
Dozens of asylum-seekers reported that “their documents were confiscated” on arrival, “and they were taken to
a house in Kigali where they were kept under guard”, before being “smuggled to Uganda”.

(ii) UNHCR's interviews with 80 Eritrean and Sudanese asylum-seekers in Italy who had been relocated under
this arrangement revealed that, “feeling they had no other choice, they travelled many hundreds of kilometres
_through conflict zones” and had “suffered abuse, torture and extortion before risking their lives once again by_
_crossing the Mediterranean to Italy”. Some reported that those travelling with them had died en route to Libya._
UNHCR is aware of two individuals who were transferred from Israel to Rwanda and who (as of 2022) still have
no formal status in Rwanda despite claiming asylum several years ago. UNHCR has identified at least 50
cases of refoulement or threatened refoulement under the Israel-Rwanda arrangement.'

That evidence goes beyond the particular question of denial of access to the asylum process and also illustrates
arbitrary and oppressive behaviour by Rwandan state agents, presumably DGIE.

**[153] Although the Secretary of State was aware of the Israel-Rwanda agreement and of the problems about it, she**
did not as part of the process leading to the MEDP seek to investigate why it had failed, whether by enquiring with
the GoR or otherwise. Among other things, she did not attempt to obtain information about the terms of the
agreement or what assurances the GoR had given about the treatment of asylum-seekers relocated under it[4]. As
the Master of the Rolls explains at para [101] of his judgment, her position in the Divisional Court, and before us,
was that what had happened under a different agreement, made under different circumstances some years
previously, could shed no light on whether the GoR could be relied on to comply with its assurances under the
MEDP. She has accordingly not sought to adduce evidence contradicting or qualifying Mr Bottinick's account of a
wholesale failure by the GoR to respect the Convention rights of those returned under the agreement.


-----

High Commissioner for Refugees intervening) and ot....

**[154] I would thus accept UNHCR's evidence about all three episodes. But it is necessary to be clear what**
conclusions do and do not follow.

**[155] On the one hand, I do not accept that the evidence in question justifies the conclusion that there is a real risk**
that individuals relocated under the MEDP will be subject to airport refoulement or otherwise denied access to the
asylum process. Their situation is clearly different from that of unheralded individual asylum-seekers, and also from
that of the in-country nationals of country X. The GoR will have been supplied with their details in advance and will
have expressly agreed to accept them under the terms of the MEDP. Their flight will be expected and arrangements
put in place for their reception and

6

accommodation. In those circumstances it is in my view inconceivable that DGIE would deny them entry to the
country or would refuse them the opportunity to make an asylum claim as expressly promised in the MoU and the
APNV. The case of those returned under the Israel-Rwanda agreement may seem rather closer to the present, but
the available evidence does not establish that the circumstances in which they were unable to access the asylum
system in Rwanda are comparable to those which will obtain under the MEDP.

**[156] On the other hand, I do not accept that these episodes are of no relevance. They are evidence of a culture of,**
at best, insufficient appreciation by DGIE officials of Rwanda's obligations under the Refugee Convention, and at
worst a deliberate disregard for those obligations, together with at least a suggestion of prejudice against asylumseekers from the Middle East and Afghanistan and a willingness to take into account political considerations. Those
factors are capable of impacting on the treatment of asylum-seekers even if they are admitted to the process,
particularly given the responsibility of DGIE for the first stage of that process. I will return in due course to the
question whether the MEDP eliminates, or sufficiently mitigates, that risk.

**[157] I should mention one other issue. Paragraph 41(i) of LB 2 records that UNHCR has since 2017 received**
reports that DGIE has refused to register claims made by claimants claiming fear of persecution on the basis of
sexual orientation or gender identity. Mr Bottinick accepts that more recently two such claims have been permitted
to progress, although he also reports a very recent episode where a LGBTQI+ asylum-seeker was submitted to
very hostile questioning in his asylum interview. Similar concerns were raised by UNHCR at its meeting with Home
Office officials in March 2022. The primary GoR response says:

'LGBTIQ+ not able to register. This is demonstrably untrue. The RSDC has received applications from
LGBTIQ+ and has granted refugee status to those who have been determined as having a well-founded fear of
persecution on the basis of their sexual orientation.'

The tabular response instances a particular case where an asylum-seeker of Egyptian origin was found to have a
well-founded fear of persecution on the basis of his transgender status: see the answer to qu 28. In LB 3 Mr
Bottinick points out that that response is not inconsistent with his original evidence. However, even if there have
been cases of the kind alleged in LB 2, for similar reasons to those given at para [155] above I do not believe that
there is a real risk that RIs claiming to fear persecution on the grounds of their sexual orientation will be denied
access to the RSD process.
Stage (1): DGIEAlleged 'gatekeeper role'

**[158] The first stage of the process is the responsibility of DGIE. As a matter of Rwandan law, its role is simply to**
do the necessary preparatory work, primarily by conducting the asylum interview. But UNHCR says that DGIE also

4 Limited further information about this aspect can be gleaned from the judgment of the Israeli Supreme Court in _Sagitta v_
_Ministry of Interior, which concerned a challenge to the lawfulness of various aspects of the Israel-Rwanda Agreement. In_
particular, the Court records that the agreement included an 'explicit undertaking … according to which the deportees will enjoy
human rights and freedoms and that the principle of non-refoulement shall be complied with'.

**[*304]**


-----

High Commissioner for Refugees intervening) and ot....

performs a substantive screening or gatekeeper role which means that it may refuse to process claims, or delay
them indefinitely, so that they never proceed to the RSDC (and a residence permit is not issued): see LB 2 paras
38–39. Where this occurs there is no written decision, still less written reasons; but claimants have sometimes been
given reasons orally which are
**[*305]**

inconsistent with the Convention. Those decisions are not appealable, and although the RSDC has power to
consider a claim which DGIE has failed to refer timeously (under art 8 of a Prime Ministerial order) UNHCR has no
experience of this ever occurring. The evidence relied on in support of the allegation that DGIE plays this
gatekeeper role is identified at para 39 of LB 2 as being the airport refoulement and in-country refusal cases
discussed above, together with—

'… several cases in 2021 and 2022 where individuals were told by the DGIE that their cases would not be
referred to the RSDC solely because they had come to Rwanda on a work permit or tourist visas … [and] …
were told by the DGIE to make an application only once their permit expires.'

**[159] The GoR denies that DGIE acts as a gatekeeper in the way described: see the primary response to para 38**
of LB 2. But the denial goes no further than re-stating the statutory position that DGIE is obliged to refer claims to
the RSDC. There is a suggestion that UNHCR's evidence is based on a misunderstanding of art 8 of the Prime
Ministerial Order, but it is in my view clear that Mr Bottinick is reporting the actual experience of UNHCR staff in
Rwanda.

**[160] I have already expressed my view about the airport refoulement and in-country denial episodes. As for the**
cases where claimants were told to re-present their claims only when their current residence permits expire, I do not
believe that the GoR's general denial justifies the rejection of Mr Bottinick's evidence. I accept, however, that that
conduct falls short of expulsion or a definitive refusal to entertain the claim.

**[161] Paragraph 4.7.3 of the Asylum System CPIN records that DGIE provides 'a preliminary analysis of the**
application'. Mr Bottinick says that UNHCR staff have on several occasions been told by DGIE officials that
following the asylum interview DGIE makes a recommendation to the RSDC as to the outcome of the claim (LB 2,
para 40), but the claimant is not given a copy of that recommendation. A 'recommendation' is not quite the same as
a 'preliminary analysis' but both would involve DGIE giving the RSDC the benefit of its views on the substance of
the application.

**[162] The GoR's response to LB 2 (primary response at para 40) reads:**

'DGIE's role in the RSD process consists of preparing files to be submitted to the RSDC for consideration.
These files include information gathered about the asylum seeker. DGIE does not make any recommendation
that may influence outcome of the RSDC decision. The RSDC takes decisions based on the information
contained in the file and the additional information provided by the Eligibility Officer.'

Mr Bottinick confirms in LB 3 (para 24(d)) that that is inconsistent with what UNHCR staff have repeatedly been
told.

**[163] I note that what the response denies is that DGIE makes 'any recommendation that may influence outcome of**
_the RSDC decision'. That is not inconsistent with 'the information contained in the file' giving a statement of the_
views of the DGIE officer. Nor would it be surprising that the officer should express such views, given that they will
have interviewed the claimant and should have relevant expertise to form a view; and given also that DGIE is an
agency of the National Intelligence and Security Service which is one of the
**[*306]**

bodies which contributes a member to the RSDC. To the extent that any such analysis or recommendation is given,
it is not satisfactory that the claimant is not shown it.
**The conduct of the asylum interview**


-----

High Commissioner for Refugees intervening) and ot....

**[164] It will be appreciated that the asylum interview is of central importance because it may (subject to paras**

[184]–[185] below) be the only opportunity which a claimant has to present their case orally. Paragraphs 4.3 and 4.4
of the APNV read:

'4.3 A decision whether a Relocated Individual is recognised as having a refugee protection need will only be
taken following an appropriate examination that will, amongst other things, provide the Relocated Individual
with the opportunity to:

4.3.1 make a written application and provide evidence in support;

4.3.2 attend an interview to explain their application and answer any questions the decision maker may have;

4.3.3 to further explain their claim, including any elements that may be missing from their written application or
after the interviewer's question.

4.4 The asylum interview will:

4.4.1 be transcribed or electronically recorded in full. If the interview is transcribed, the Relocated Individual will
be given the opportunity to review and, if necessary, correct the transcript; and

4.4.2 be conducted under conditions which allow the Relocation Individual to present the grounds for their
application in a comprehensive manner. In particular;

4.4.2.1 the person who conducts the interview will be competent to take account of the personal and general
circumstances surrounding the application, including the applicant's cultural origin, gender, sexual orientation,
gender identity or vulnerability;

4.4.2.2 wherever possible, the interview with the Relocated Individual will be conducted by a person of the
same sex if the Relocated Individual so requests, unless there is reason to believe that such a request is based
on grounds which are not related to difficulties on the part of the Relocated Individual to present the grounds of
his or her application in a comprehensive manner;

4.4.2.3 be in the presence of an interpreter who is able to ensure appropriate communication between the
Relocated Individual and the person who conducts the interview. The communication shall take place in the
language preferred by the applicant unless there is another language which he or she understands and in
which he or she is able to communicate clearly.'

It is clear that some of those provisions were included in response to criticisms of the conduct of the asylum
interview which had already emerged in the course of the two visits to Rwanda by Home Office officials and/or in
their discussions with UNHCR.

**[165] I turn to consider UNHCR's criticisms of the asylum interview. UNHCR is not generally permitted to attend**
asylum interviews but its staff in Kigali speak to asylum-seekers about their experience of them.

**[166] First, it is said at para 41(a) of LB 2 that the interview with DGIE is brief and perfunctory, lasting only about**
20–30 minutes, and that it does not
**[*307]**

give the claimant a fair opportunity to explain the basis on which they are claiming asylum. That is particularly
serious since DGIE is said (LB 2 para 34) to encourage claimants not to exceed one or two pages in their initial
applications or to submit lengthy documents, such as country information reports, in support so that there may be
much that has to be amplified or explained at the interview. Mr Bottinick also says that claimants are not given an
opportunity in the interview to address 'adverse points' or to submit further information following it in order to
address points which have arisen during it (LB 2, paras 38(c) and 41(b)).


-----

High Commissioner for Refugees intervening) and ot....

**[167] The GoR's primary response to para 41(a) reads:**

'This is not true. The interview takes as much time as necessary for the applicant [to] explain clearly his or her
case. The interview guiding questions are set in way that provides the applicant the possibility to provide all
information to support their application. Applicants can be invited for more interviews if necessary.'

No copy of 'the interview guiding questions' is supplied, and the source of the information is not stated. That general
and unsourced denial does not justify a wholesale rejection of UNHCR's evidence.

**[168] The question then is whether the position will be different as a result of the MEDP. Paragraph 4.3.1 of the**
APNV expressly says that claimants will have the right to provide supporting evidence as part of the initial claim,
and para 4.3.3 allows them to further explain their claim following the interview. The APNV does not prescribe a
minimum length for the interview, but the intention is evidently that it will be long enough to allow the claimant to
explain their asylum claim and answer questions about it; and clearly in many cases thirty minutes would be
inadequate for that purpose, particularly since usually both questions and answers will have to be translated.

**[169] I do not believe that it will be a straightforward matter for DGIE officials to change the way in which they have**
been accustomed to conduct interviews. No doubt it can be done, but it requires an appreciation that their previous
approach was inadequate and effective training and monitoring. The response quoted above suggests that GoR
does not accept that there is a problem which requires to be addressed. I return to the issue of training below.

**[170] Second, it is said that no transcript or other record of the interview is provided to the claimant: LB 2, para**
41(e), LB 3 para 29(a). This is a point of obvious importance since the facts elicited at interview will form a crucial
part of the file which goes to the RSDC.

**[171] It is not entirely clear whether the GoR accepts that this is not part of its current practice. The supplementary**
GoR e-mail says:

'Records of the DGIE interview: The DGIE conducts interviews with the asylum seeker in the initial stages of
the asylum process with a view to submit the information to the RSDC and to grant the asylum seeker a
temporary residence permit. The DGIE interviews consist of the asylum seeker describing their reasons for
seeking asylum in Rwanda. The interview is recorded electronically and at the end of the interview, the asylum
seeker is presented with a written record of the interview. The asylum seeker verifies the information and can
confirm the record with a signature or can amend the record by correcting the information or providing more
information. A copy of the DGIE record of interview as

**[*308]**

verified by the asylum seeker will be made available to the asylum seeker. The legal representative retained by
the asylum seeker can assist with reviewing the records of the interviews.'

That passage starts by using the present tense but changes to the future tense.

**[172] I do not believe that that evidence is an adequate basis for rejecting UNHCR's evidence as to past practice,**
and it is more likely that it reflects the intended post-MEDP system: as we have seen, provision of a transcript, with
the opportunity to approve it, is specifically addressed by para 4.4.1 of the APNV. As to that, I should add that the
PDA comments on this obligation as follows:

**'Ability for Relocated Individual to review transcription**

RIs will have the ability to review the transcript and correct the record immediately after the interview process.
The transcript can be printed there and then. After the interview is conducted and information recorded by
DGIE on their digital system, it will be reviewed again to confirm the transcript is correct, including where
relevant, that translations are correct as transcribed by the interpreter. Once all parties are content the
document will be signed.'


-----

High Commissioner for Refugees intervening) and ot....

It is clear from para 34 of Mr Williams' witness statement that this information derives from the DGIE Director.

**[173] The real question thus is whether the requirements of the APNV will be complied with. We are here**
concerned with a specific procedural requirement rather than one involving the exercise of judgment, such as the
conduct of the interview as considered above. I see no reason to suppose that DGIE will deliberately disregard the
explicit requirement of the APNV, confirmed and amplified in the statements of the DGIE Director, that it should
supply claimants with a copy of the transcript of the asylum interview in their own language. However, the process
described in the APNV is not straightforward, and training will be required to ensure that it can be accomplished in
practice. Again, I return to this below.

**[174] Third, Mr Bottinick says (LB 2, para 41 (c); LB 3 para 28(a)) that claimants are not permitted at the asylum**
interview to be accompanied by a lawyer. The evidence about this, or in any event about whether it will continue to
be the case under the MEDP, is not clear. Because the same question arises in relation to stages (3) and (4) I
address it separately below. As will appear, my conclusion is that legal representatives are certainly not permitted at
present but it appears to be intended that henceforward they will be. (It is accordingly unnecessary to consider
whether that is in all cases necessary in the interests of fairness: I will only say that it is very likely that in some
circumstances it will be.) However, it is not clear what consideration has been given to the role that legal
representatives can play at the interview.
Stage (2): Eligibility Officer

**[175] Mr Bottinick addresses the role of the Eligibility Officer at paras 42–47 of LB 2. He points out that it is**
potentially very important because the additional information which the Eligibility Officer may obtain, and the notes
of any interview that they conduct with the claimant, will presumably go before the RSDC; but he complains that
there is no transparency about this stage of the process. It is not clear on what basis claimants may be selected for
**[*309]**

interview nor is any record of the interview shared. Nor is it clear what the file compiled for the RSDC consists of,
including what country information, UNHCR guidance, or summary of legal principles it may contain. He also says
that there is at present only one Eligibility Officer, which is unsatisfactory given the nature and importance of the
role (and also because the current incumbent does not speak English).

**[176] The GoR responses do not comprehensively address these criticisms. The GoR statement appears to say**
that the Eligibility Officer interviews every claimant (para 4); but the statement is in very general terms. As for
numbers, the answer to qu 24 in the tabular response states that there are now two Eligibility Officers and that
MINEMA is recruiting three more and plans to recruit others in future. The answer to qu 36 is similar but not
identical. It says:

'There is currently one Eligibility Officer which is adequate for the usual volume of claims received. (ToR of an
Eligibility Officer are attached below). MINEMA is actively recruiting more Eligibility Officer to cater for the
expected increase in asylum claims under this partnership.'

**[177] The 'attached ToR' would seem to be the job description for the role as advertised (apparently now to be**
described as 'Eligibility and Protection Specialist') exhibited by Mr Armstrong to his witness statement dated 2 July
2022. This reads:

'JOB PURPOSE

The Eligibility and Protection Specialist will be in charge of checking, record keeping, filing, and advocating on
behalf of migrant families. He/She will determine whether or not migrant families' various needs are met and
propose corrective measures.

DUTIES AND RESPONSIBILITIES

Under the direct supervision of the Program Manager, the Eligibility Specialist will perform the following duties:


-----

High Commissioner for Refugees intervening) and ot....

   - ·Assist in the monitoring and analysis of statistics related to migrant case processing in order to identify and
respond to developments or issues affecting decision-making quality, and to propose corrective measures.

  - ·Ensure the reception of migrants and asylum seekers and assist them in providing feedback on individual
cases.

  - ·Conduct Migrants, asylum seekers' interviews and draft their Assessments in accordance with set
guidelines.

  - ·Conduct research on country of origin information and legal issues concerning migrants and asylum
seekers, and assist in the maintenance of a local database of relevant information.

   - ·Maintain accurate and up-to date records and data related to all work on individual cases.'

The reference in the third bullet to conducting interviews and drafting assessments cannot, I think, be to any
involvement at the DGIE stage but to the Eligibility Officer's own interview (though it is not clear whether this will
occur in every case) and assessment carried out for the benefit of the RSDC.

**[178] Mr Armstrong also says, at para 46, that in the course of the negotiation of the MEDP:**
**[*310]**

'… Rwandan officials explained that individuals will be supported throughout the process by a caseworker from
the Eligibility and Protection Office in Ministry of Emergency Management (MINEMA) who will collate
information related to an individual's case and submit it to the National Refugee Status Determination
Committee for decision.'

**[179] I see no reason to doubt that the intention of the GoR is that there will be a sufficient number of Eligibility**
Officers to deal with the increase in asylum-seekers going through the RSD process as a result of the MEDP; or
that they will have for the future the functions and responsibilities described in the job description, whether or not
they precisely correspond to what their role has been in the past. I need not therefore reach a conclusion about
UNHCR's criticisms of the current position. However, it is clear that the role as envisaged is important and valuable:
given the part-time and non-specialist nature of the RSDC, it is in truth essential that it be serviced by full-time
officials who can provide it with necessary information, materials and technical advice. That being so, it is essential
that the Eligibility Officers be properly trained: I return to this below.

**[180] Finally, I should note that it is not clear from the APNV, or any of the other evidence, whether any interview**
conducted by the Eligibility Officer will be subject to the requirements specified in para 4.4 – ie that it will be
conducted through a qualified interpreter and the claimant will have the opportunity to address the record.
Stage (3): the RSDC

**[181] As regards the substantive determination of an RI's asylum claim – that is, the decision by the RSDC – the**
APNV provides as follows:

'4.5 For the purpose of taking decisions on asylum claims, decision makers will obtain up-to-date information
as to the general situation prevailing in the countries of origin of the Relocated Individual. This information will
be available to decision-makers, and they will have appropriate resources to further research and access
expertise where needed.

4.6 A decision on a Relocated Individual's asylum application will:

4.6.1 be taken on the merits of the individual application; and

4.6.2 will be objective and impartial.

4.7 Arrangements will be made to ensure that the decisions taken on individual claims are recorded.


-----

High Commissioner for Refugees intervening) and ot....

4.8 Relocated Individuals will be notified in writing of the decision that has been taken on their asylum claim.

4.9 A decision will:

4.9.1 be in one of the official languages of Rwanda and, if needed for understanding, it will be translated in
writing by an interpreter into a language that the Relocated Individual understands, free of charge;

4.9.2 include the reasons for the decision in both fact and law; and

4.9.3 a decision that is a refusal of the asylum claim will notify a Relocated Individual that they will be able to
appeal the decision on their asylum claim and provide an explanation of how to do this.'

**[182] Paragraphs 48–65 of LB 2 advance a number of criticisms of the RSDC stage of the process. I consider them**
under the following heads.
**[*311] Process**

**[183] Mr Bottinick's evidence is that in the majority of cases the RSDC takes its decision at a meeting which the**
claimant does not attend (and which indeed they will not know has taken place until they receive the decision) and
thus without receiving any submissions from him or her: see paras 56 and 59 of LB 2. This means that in such
cases the quality of the information before the Committee, at least as regards the claimant's individual
circumstances, is dependent on the quality of the asylum interview conducted by DGIE, and any further interview
conducted by the Eligibility Officer, and the records of such interviews. The claimant has no access to those records
and so is in no position to correct any errors or clarify any misunderstandings. More generally, as he says in para
65(d), they have—

'no opportunity … to present their claim in full, or address provisional adverse findings (eg to address a
credibility concern that has arisen in the view of the decision-maker(s), including through a lawyer).'

If that is a fair summary of the procedure followed it clearly has the potential for serious unfairness.

**[184] The GoR responses do not directly address this part of Mr Bottinick's evidence (although para 4.4.1 of the**
APNV provides for them to receive a copy of the transcript of the asylum interview). However, at para 36 of his
witness statement Mr Williams says that the DGIE director told him that:

'… following their asylum interview and receipt of their translated interview transcript, relocated individuals will
be given the opportunity to make oral and written representations directly to the RSDC and that the RSDC may
request further information from relocated individuals if required for the purposes of reaching a decision on their
claim.'

This is the only reference in the evidence to an RI being given the opportunity to make 'oral and written
representations' directly to the RSDC. Nothing is said about when any written representations would be expected to
be lodged or considered. The reference to oral representations is presumably to representations made by the
claimant at the meeting at which the Committee makes its decision: a separate 'hearing' would be a radical
departure from its practices which I would expect to have seen fully explained. In that case there might not be much
difference between the right to make oral representations and the 'interview' referred to by Mr Bottinick: the
important point would be that there would be an interview in every case.

**[185] If that is indeed what the DGIE Director intended to convey, it appears inconsistent with the understanding of**
the Chief Technical Adviser to the Ministry of Justice, since the passage from the supplementary e-mail quoted at
para [230] below carefully refers to 'any interview at the RSDC'. It is also inconsistent with what the Home Office
officials understood from their meetings in January and March 2022: para 4.7.3 of the Asylum System CPIN says
that 'RSDC can [my emphasis] request to meet the applicant to verify information (in a 20–40 min interview)'. It is
very unsatisfactory not to have a clear and consistent account of how the RSDC will proceed in determining the RIs'
cases.


-----

High Commissioner for Refugees intervening) and ot....

**[186] Mr Bottinick complains, on the basis of accounts from individual asylum-seekers and others who have been**
present, that where the RSDC interviews the claimant the interview is short (cf the CPIN reference to 20–40
**[*312]**

minutes) and often conducted unprofessionally (eg by preventing claimants giving proper answers or submitting
further information or by hostile questioning) or in a way that appears to show a poor knowledge of the file and/or a
failure to appreciate the requirements of refugee law (eg by a focus not on the claimed fear of persecution but on
why the claimant has not sought asylum 'closer to home'): see para 60 of LB 2. In addition, he says that
professional interpreters are rarely employed. These complaints are not addressed in the GoR's response.

**[187] Mr Bottinick also complains that where the RSDC has conducted an interview no transcript is made available**
to the claimant. That criticism is not addressed directly by the GoR, but its supplementary e-mail says:

'The refugee status determination by the RSDC is an administrative process wherein minutes of the decisionmaking process are recorded. These minutes will be made available to the relocated individual attached to their
notification of decision by the RSDC.'

Whether that is a complete answer depends on what procedure is followed in the case in question. If the RSDC
proceeds to a decision immediately after the interview the only value to the claimant of having a transcript would be
in case what they had said was relevant to an appeal; and in those circumstances the promised minute might be
adequate, depending how full it was. But if the decision is deferred to a later occasion it might be of real importance
for the claimant to have a record, both so that any errors could be corrected and as the basis for any submissions
that they might wish to make (subject to the point I have to consider next). The APNV says nothing about the
agreement of a transcript in this situation. This uncertainty is unsatisfactory.

**[188] Finally, and most importantly, Mr Bottinick complains that claimants are not entitled to make submissions to**
the RSDC through a lawyer. Paragraph 60(j) of LB 2 reads:

'There is no opportunity for asylum seekers (whether or not interviewed) to make submissions (in person or
through a lawyer) to the RSDC. Lawyers are not permitted at the RSDC stage. UNHCR and its legal aid
partners have been told repeatedly that if a person was telling the truth, they had no need for a lawyer. Over
the years, when legal aid partners have inquired about the possibility of legal representation, they have been
told that as the relevant national refugee law does not specifically refer to provision of legal representation, it
cannot be permitted.'

**[189] That evidence, so far as concerns representations by a lawyer, is not challenged by the GoR. As appears at**
para [230] below, it does now say that a claimant may be accompanied by their lawyer if the RSDC conducts an
interview, but it has not changed its position that it will not entertain submissions from them: Sir James Eadie
confirmed this in the course of his oral submissions. In my view this is a serious defect in the process. Any
representations will in most cases only be effective if made by a lawyer because typically RIs will have neither the
knowledge nor the articulacy to present their case to a non-specialist body, and still less where they will be having
to do so through an interpreter. It is true that in many, perhaps most, asylum claims the determinative issue will be
whether the claimant is telling the truth, and that what they say in their interview(s) will be of central importance. But
even on that issue there may be points to be made beyond the bare narrative; and
**[*313]**

sometimes there will be important issues about matters outside the claimant's knowledge, such as developments in
their country of origin or issues of law. It is also important to bear in mind that many RIs are likely to be especially
vulnerable as a result of their experiences, which may include a history of torture. The need to have a lawyer to
present their claim will be particularly important in such cases.
**Country information**

**[190] Paragraph 4.5.1 of the APNV acknowledges the need for decision-makers – in practice, the RSDC – to have**
access to up-to-date country information. Mr Bottinick observes that because claimants do not see the contents of


-----

High Commissioner for Refugees intervening) and ot....

their files it is impossible to know what information is in fact provided to the Committee. In its tabular response (at
qu 10) the GoR says that the RSDC is provided with 'country information reports from ministry of foreign affairs and
other open sources country information reports'. That is not very specific, though I note that the duties of the
Eligibility Officer will apparently include maintaining a relevant database (see para [177] above). On any view it will
be particularly important for RSDC members to have access to good objective information about the kinds of
country from which most RIs are likely to come, of which they will have had little previous experience.
**Reasons**

**[191] Paragraph 4.9.2 of the APNV requires that a written decision will 'include the reasons for the decision in both**
fact and law'. That is particularly important where a claim is refused. The intention is plainly that decisions should
not be 'stereotyped' but should address the particular factual case advanced by the individual claimant and identify
the legal basis for the decision.

**[192] Paragraph 61 of LB 2 deals with the reasons given by the RSDC for decisions refusing an asylum claim. Mr**
Bottinick says that UNHCR has seen the reasons given in 116 cases and that in none of them were the reasons in
sufficient detail to allow the claimant to understand why their claim had been rejected. In 36 out of 50 such refusals
in the previous year (of which he reproduces the relevant parts in a table) the reasons given amounted to no more
than some such formula as 'because you don't meet the eligibility criteria and the reasons you provided during the
interview are not pertinent'. On the occasions where something more is said it remains cursory in the extreme.
UNHCR makes the further point that decisions in this form are not only inadequate in themselves but indicate a
poor quality of decision-making.

**[193] In its primary response to para 69 of LB 2 the GoR states that:**

'The reasons are briefly provided in the notification and more detailed reasons are communicated to the
applicant in person. Templates are being adjusted to provide detailed reasons on the notification.'[5]

7

That tacitly acknowledges that reasons in the form previously given are inadequate; and in any event Sir James
accepted that before us. No examples have been produced of more detailed reasons given in recent cases before
the RSDC.

**[194] I see no reason to reject the GoR's statement that it intends that the RSDC will henceforth give more detailed**
reasons for its decisions. But the giving of proper written reasons, particularly where this has not been the practice
to date, is not a straightforward matter, and it is not possible to be confident that it will occur unless those drafting
them receive proper training.
**Outcomes and bias**

**[195] Paragraph 63 of LB 2 contains a table headed 'Overview of cases processed by RSDC as known by UNHCR**
for 2020 to 2022 (as of 21 June 2022)'. Mr Bottinick accepts that the table may be incomplete because the GoR
does not share statistics with UNHCR, but he explains the sources from which it is derived. The table shows a total
of 156 cases in the relevant period, with an overall rejection rate of 77%.

5 The GoR's primary response to para 73 of LB 2, which is concerned with the right of appeal to MINEMA, says: 'The
notification is provided by the RSDC. One of the main responsibility [sic] of the MINEMA Eligibility Officer is to give detailed
reasons for refusal and advise the applicant on the way forward (how to lodge an appeal, etc.).' Despite where that answer
appears, it seems more naturally to refer to notification of, and the reasons for, the RSDC decision rather than the MINEMA
decision. If so, it is not clear whether the reference to the Eligibility Officer giving 'detailed reasons for refusal' means that it is
intended that they will draft the RSDC's reasons.

**[*314]**


-----

High Commissioner for Refugees intervening) and ot....

**[196] Mr Bottinick draws attention to the fact that the table shows three asylum claimants from Syria, three from**
Yemen and two from Afghanistan, and that all of their claims were rejected. He also refers to eighteen claims from
Eritrea, of which ten were rejected. He says that the situation in the countries in question, and the profiles of the
individual claimants, are such that all their claims are very likely to have been well-founded and that the numbers
who were in fact rejected casts doubt on the quality of the RSDC's decision-making. More particularly, as regards
the former group he suggests at para 114 of LB 2 that the reason for the rejection of their claims is likely to be a
bias against asylum seekers from the Middle East and Afghanistan. As to that, he relies not only on the figures in
the table but on the cases of airport refoulement discussed at para [146] above. He also relies on statements which
he says that UNHCR's staff have heard senior government officials make to the effect that asylum-seekers from the
Middle East and Afghanistan should claim asylum in their own region. The latter allegation was not made for the
first time in his evidence: it has been made in UNHCR's meetings with Home Office officials in both March and April
2022.

**[197] The GoR has provided a different table, covering substantially the same period. This shows a total of 108**
claimants, including only one from each of Syria, Yemen and Afghanistan, all of whose claims were rejected, and
twenty from Eritrea, fourteen of whose claims were rejected. It has also provided short notes on the reasons for the
rejections in question, rebutting any suggestion of prejudice, but without more detail it is not possible objectively to
assess their validity.

**[198] In LB 3 Mr Bottinick addresses the differences in the numbers as regards the claimants from Syria, Yemen**
and Afghanistan and confirms that he is confident in the accuracy of his figures. He suggests that the discrepancy
may arise, at least in part, from the GoR treating linked cases as a single entry.

**[199] It is not possible definitively to resolve the difference between the two tables, but I believe we should proceed**
on the basis of UNHCR's figures, both because they are carefully explained and defended in both LB 2 and LB 3
and because we should take a 'substantive grounds/real risk' approach. In my view the surprisingly high rejection
rate of claimants from known conflict zones, where UNHCR recommends against returns, does indeed suggest a
poor quality of decision-making.
**[*315]**

**[200] As regards the more particular allegation of a bias against claimants from the Middle East and Afghanistan,**
UNHCR's figures are of course statistically frail. But I do not believe they can be disregarded, particularly when
taken with its evidence about the views expressed by senior GoR officials that they should have sought asylum
nearer to home. Such views are not uncommon generally, and they are consistent with questions reported to have
been asked by RSDC members in cases where the claimants have been interviewed (see para [186] above); they
would also be a plausible explanation for the airport refoulement cases. They constitute evidence that RSDC
members may hold such views and that they may influence its decision-making.

**[201] I accept that the changes associated with the introduction of the MEDP may improve the quality of decision-**
making and help to eliminate prejudices of the kind which UNHCR alleges are operative. But the extent to which it
will do so will depend on the effectiveness of the training which DGIE and RSDC officials receive.
**Confidentiality**

**[202] Paragraph 41(h) of LB 2 suggests various grounds for believing that DGIE may seek information about**
asylum-seekers from the authorities in their countries of origin or their embassies in Rwanda. The GoR's primary
response is to the effect that it is standard practice for the Ministry of Foreign Affairs to 'liaise with Embassies to
gather background information on the applicant and/or to gather country information'. That is ambiguous, but in the
GoR supplementary e-mail it is explained that the reference is to the Rwandan embassies (or High Commissions) in
the country of origin, to which application may be made if information is required about a 'specific event/situation'.
The e-mail states in terms that 'the DGIE and RSDC do not share the personal data of an asylum seeker with any
third party during the processing of the asylum seeker's application'. This is one of the two criticisms on which the
Divisional Court made a finding: at para [56] of its judgment it said that it was satisfied with the GoR's explanation. I


-----

High Commissioner for Refugees intervening) and ot....

find it difficult to reach a concluded view, and for the reason given at para [144] above I do not believe it is
necessary to do so.
**Protection gaps**

**[203] The Claimants allege that the drafting of art 7(1) of Law no 13, which governs eligibility for asylum in Rwanda,**
fails properly to implement the Refugee Convention because it does not cover persecution for imputed political
opinion or by non-state actors. That criticism is adopted by Mr Bottinick in LB 2 (para 82). As the Divisional Court
points out at para [55] of its judgment, it is impossible to form a view about whether that is in fact how art 7 would be
interpreted by a Rwandan court without expert evidence of Rwandan law. The AAA Claimants' skeleton argument
said that the absence of such evidence was itself a breach of the Ilias duty, but Mr Husain did not develop the point
in his oral submissions.

**[204] At paras 83–88 of LB 2 Mr Bottinick expresses a number of concerns about the ability of inexperienced**
Rwandan decision-makers to understand some of the more subtle important concepts of substantive asylum law,
such as the principle established in HJ (Iran) v Secretary of State for the Home Dept,
**[*316]**

_[HT (Cameroon) v Secretary of State for the Home Dept [2010] UKSC 31, [2011] 2 All ER 591, [2011] 1 AC 596.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52X0-KRC1-DYBP-M3DB-00000-00&context=1519360)_
This, however, is more relevant to the issue of training, which I consider separately below.
**The composition of the RSDC**

**[205] Under head (9) of its Written Observations UNHCR says:**

'UNHCR has observed a lack of training or sufficient knowledge at all stages of the Rwandan RSD system. The
changing, part-time and non-specialist composition of what is in principle the main decision-making body on
asylum claims, the RSDC, in UNHCR's view compromises the quality and integrity of the Rwandan RSD
procedure. The RSDC's members are high level functionaries from an array of ministries, whose primary
responsibilities lie elsewhere and many of whose portfolios do not otherwise include matters relevant to the
asylum procedure. UNHCR's repeated offers to provide training to the Rwandan RSD authorities have only
been taken up on two occasions, with a gap of three years in between and those trainings were short and
basic.'

The passage goes on to develop the criticism in relation to training.

**[206] I would not accept – if UNHCR intends to go this far – that a body with the composition of the RSDC is**
inherently incapable of making proper decisions on asylum claims, provided always that its members approach their
task conscientiously, and that they are provided with full information, including representations from or on behalf of
the claimant, and proper specialist support. Paragraph 4.5 of the APNV recognises this, and it seems that it is
intended that the support and information there referred to will be provided by the Eligibility Officers. However, the
main focus of UNHCR's criticism appears to relate to the absence of training. I agree that this is fundamental, and I
return to it below.
Stage (4): Appeal to MINEMA

**[207] Mr Bottinick addresses the right of appeal to MINEMA at paras 66–75 of LB 2. In short his criticisms are: that**
claimants whose claims are rejected by the RSDC are not notified in writing of their right of appeal and only
sometimes notified orally; that the right of appeal is ineffective because in the absence of a reasoned decision from
RSDC it is impossible to address the basis on which the claim was rejected; that it is unclear whether the appeal is
(adopting English terminology) by way of review or re-hearing; that MINEMA is not independent, because its
Permanent Secretary is the Secretary to RSDC; that free legal advice is not available; and that MINEMA does not
give reasons for its decisions. He also observes that UNHCR is unaware of any cases where an appeal to MINEMA
has succeeded.

**[208] Those criticisms are only partly addressed in the GoR's primary response. It appears to say that claimants are**
informed by the Eligibility Officer of the reasons for MINEMA's decision and of their right of appeal; but in fact I think


-----

High Commissioner for Refugees intervening) and ot....

the reference may be to the decision of the RSDC. It also says that two out of the five appeals to MINEMA in 2021
succeeded.

**[209] Paragraphs 5.1–5.2 of the APNV read:**

'5.1 A Relocated Individual may appeal a refusal of their asylum application to the Minister responsible for
considering such appeals.

**[*317]**

5.2 A Relocated Individual who wishes to appeal to the Minister will have the opportunity to make oral and or
written representations. Any legal representative engaged by the Relocated Individual will have the opportunity
to make submissions when appropriate before the end of the process of appeal to the minister.'

That makes clear that, whatever may have been the position in the past, MINEMA will consider representations
from the claimant's lawyer.

**[210] It will be seen that the evidence about the right of appeal to MINEMA is very limited. That makes it difficult to**
assess its effectiveness as a safeguard against wrong decisions by the RSDC. I find it hard to believe that following
the MEDP claimants will be left unaware of their right of appeal or that fuller reasons for a refusal by MINEMA will
not be given (as is intended with the RSDC). But it is impossible to form a useful view about the quality or
independence of its decisions. The issue may not be central since the ultimate safeguard should be the appeal to
the High Court, to which I now turn.
Stage (5): Appeal to the High Court

**[211] The various problems identified above about the administrative stage of the RSD process make it particularly**
important that there be a right of appeal to an independent judicial tribunal which can examine the claim afresh.
Paragraph 9.1.3 of the MoU provides:

'If a Relocated Individual's claim for asylum is refused, that Relocated Individual will have access to
independent and impartial due process of appeal in accordance with Rwandan laws.'

That commitment is amplified by paras 5.3–5.5 of the APNV, which read:

'5.3 A Relocated Individual whose appeal has been refused by the Minister will be permitted to appeal that
decision to the High Court of Rwanda.

5.4 The court will be able to conduct a full re-examination of the Relocated Individual's claim in fact and law in
accordance with Rwanda rules of court procedure.

5.5 A Relocated Individual and their representative will have the opportunity to make full representations as to
fact and law at their appeal in accordance with Rwandan rules of court procedure.'

**[212] That does not give details of the 'independent and impartial due process of appeal' afforded by Rwandan law,**
but art 47 of 'Law 30/2018 of 02/06/2018 determining the jurisdiction of courts' provides that 'the High Court also
adjudicates cases relating to the applications for asylum'. It is common ground that that provision gives an asylumseeker whose claim has been rejected by the RSDC and MINEMA what is in practice a right of appeal to the High
Court. It is also common ground that no appeal under art 47 has been brought since it became available five years
ago, and there is no evidence about how it would work in practice.

**[213] At para 143 of LB 2 Mr Bottinick says:**

'Even if the safeguards of representation and High Court appeal are now put in place for UK-Rwanda
arrangements, judges and lawyers do not have relevant experience. This raises a serious question about the
effectiveness

**[*318]**


-----

High Commissioner for Refugees intervening) and ot....

of any appeal. In any event, UNHCR does not consider that the possibility of an appeal to the High Court
provides a sufficient safeguard against a decision-making process which is flawed from the outset.'

He also repeats in this context his points that claimants are not reliably notified of the right of appeal, in this case to
the High Court, and that an appeal will be difficult in the absence of proper reasons from the RSDC and/or
MINEMA.

**[214] In the tabular response the GoR gives further information about the right of appeal to the High Court in**
answer to two questions.

**[215] First, qu 11 asked some questions about the procedural aspects of the appeal. The response reads:**

'Individuals are allowed to appeal to high court to request a judicial review of the decision given by the Minister.

– The High Court tries cases by a bench of one (1) or three (3) judges assisted by a Court Registrar. The
President of the court determines the appropriate number of the sitting judges depending on the importance of
the case.

– Evidence admissible under the rules of evidence can take the form of testimony, documents, photographs,
videos, voice recordings, DNA testing, or other tangible objects.

– High Court judgments can be appealed to the Appeal Court.'

That information is useful as far as it goes, but it does not appear to be specific to asylum appeals. If the term
'judicial review' is being used in its English sense it would appear inconsistent with the reference in para 5.4 of the
APNV to 'a full re-examination of the Relocated Individual's claim in fact and law'; but the GoR is not consistent in
its usage (see below).

**[216] Second, qu 31 asked whether there had been provision for appeals to the High Court prior to the 2018 law**
and whether it was the case that there had indeed been no appeals so far, concluding 'Can you provide any
information that will reassure our courts that anyone refused asylum will have access to this system?'. The
response says that other routes of challenge been available under different legislation prior to 2014 and had been
used on four recorded occasions. It says that there is no statutory impediment to asylum seekers appealing under
the 2018 law and that 'there are currently 44 asylum seekers who were refused refugee status after their appeal to
the Minister who are within their right [to] get an appeal/judicial review of this decision at the High Court'. This is not,
of course, a statement that any of the 44 have in fact done so.

**[217] The Claimants advanced a distinct challenge to the effectiveness of the right of appeal based on the lack of**
independence of the judiciary. A submission that the Rwandan judiciary were not independent of the government
was first made at paras 219–223 of the AAA Claimants' skeleton argument before the Divisional Court. It was not
specifically related to the effectiveness of the right of appeal against the refusal of an asylum claim but was part of a
general submission about human rights in Rwanda. Perhaps for that reason, it was not addressed in the Divisional
Court's judgment. However, in the AAA Claimants' skeleton argument before us the submission was deployed in
this context (see paras 9 and 18), and it was fully developed in Mr Husain's oral submissions.

**[218] The Claimants relied primarily on the decision of the Divisional Court (Irwin LJ and Foskett J) in** _Govt of_
_Rwanda v Nteziryayo [2017] EWHC 1912_
**[*319]**

(Admin), _[[2017] All ER (D) 203 (Jul), in which the Court upheld the refusal of Senior District Judge Arbuthnot to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P4T-VGF1-DYBP-N46G-00000-00&context=1519360)_
order the extradition of five Rwandan nationals on charges relating to the genocide on the basis that there was a
real risk they might suffer a flagrant breach of their rights to a fair trial if extradited. At para [234] of its judgment the
Court said:


-----

High Commissioner for Refugees intervening) and ot....

'We reject firmly the submission of the GoR that the judge should unequivocally have stated the judiciary was
independent and that there was no risk of bias or interference in these cases, because they are not “political”.
The clearly authoritarian nature of the regime; the long and continuing history of the influence of political will
over the justice system where the case is perceived to matter; the evidence of Gahima [a Rwandan lawyer and
activist] and others; the evidence of threats arising from criticisms of the regime, not in a political context but in
the context of the justice system; the “Osman” warnings [warnings given to Rwandan exiles in London that they
were at risk from the GoR]; the experiences of witnesses who gave evidence in genocide cases unfavourable
to the prosecution, whether in Rwanda or abroad: all these point to a high level of risk of pressure within the
system.'

At para [373] it said:

'The evidence suggests that judges are not appointed unless they have party membership of the RPF [ie the
governing party]. Their appointments have moved from being indefinite to appointment for definite terms. The
Rwandan executive can achieve the dismissal of serving judges: it has done so in recent times in respect of
around 40 individual judges. We are not in a position to say whether the suggested misconduct or corruption
was established in these cases: it may be so. But the capacity of the executive to get rid of judges is
established. In such circumstances, there can be little doubt that judges will feel exposed.'

**[219] The Claimants also place reliance on three other matters:**

(1)   On 11 June 2022 the London office of Human Rights Watch wrote to the Home Secretary expressing
the view that 'Rwanda cannot be considered a safe third country to send asylum seekers to'. In the context
of criminal trials it said:

'The Rwandan judiciary suffers from a lack of independence, due to government manipulation of the justice
system, and fair trial standards are routinely flouted, particularly in politically sensitive cases.'

(2)   The Home Office invited comments from the FCDO on a draft of the Asylum System CPIN. Against
the paragraph dealing with the availability of 'independent legal support' its reviewer noted:

'Again the country of contradictions. For these cases I agree the legal support is likely to be independent …
unless it gets political. Which may be farther down the road when refugees are in a process to settlement and
make demands on certain things. The Rwandan legal system is not independent, is regularly interfered with
and is politicised. Opposition/political cases do not receive a fair trial or support.'

**[*320]**

(The first part of that comment is directed to the separate question of legal representation, but I include it
because it shows the context.)

(3)   Reference is made to the recent trial for terrorism of Paul Rusesabagina, an opposition human rights
activist, which was described by the American Bar Association Centre for Human Rights as grossly unfair.

**[220] In his submissions before us Sir James Eadie did not dispute that the conclusions in** _Nteziryayo and the_
evidence relied on by the Claimants gave, at the least, real grounds to believe that the Rwandan judiciary was
susceptible to political pressure. But he pointed out that the context in each of those instances was the trial of
political opponents. The context in the case of asylum appeals would be completely different. The GoR would have
no political interest in the outcome of particular appeals and would have no reason to seek to manipulate them. In
so far as judges might nevertheless wish to determine appeals in accordance with what they understood to be
government policy, the GoR's declared policy was to ensure compliance with the MoU, which promised an
independent and impartial appeal.

**[221] There is force in those points. However, I do not believe that they afford a complete answer. In the first place,**
on an appeal under art 47 of the 2018 Law the High Court is being asked to overturn the decision of a Government
Minister and, indirectly, the decision of a Committee comprised of senior representatives of the principal
government bodies and agencies including the Prime Minister's Office and the National Intelligence and Security


-----

High Commissioner for Refugees intervening) and ot....

Service. Given what the Divisional Court in _Nteziryayo calls 'the influence of political will over the justice system_
where the case is perceived to matter', and the insecurity of the position of Rwandan judges, there must be a real
risk that they will be generally reluctant to allow appeals against decisions of such bodies even in the absence of
any specific pressure. Further, I do not think it can be assumed that the GoR will never have an interest in the
outcome of particular asylum appeals: the willingness to deny access to the asylum process for nationals of 'country
X' (see para [151] above) suggests that in particular circumstances it may well have an interest in denying asylum
to RIs of particular nationalities.

**[222] These concerns could in principle be met if there were evidence of how the appeal system has worked in**
practice. But since not a single appeal has so far been brought there is no such evidence.

**[223] There are distinct issues about legal representation and training, but I address these separately below.**
_Criticisms common to the system as a wholeLegal Assistance/Representation_

**[224] As we have seen, para 9.1.2 of the MoU guarantees RIs 'access to procedural or legal assistance, at every**
stage of their asylum claim'. What 'legal assistance' amounts to is amplified in paras 7 and 8 of the APNV as
follows:

**'7 Procedural and Legal Assistance**

7.1 A Relocated Individual will be provided with orientation that includes details of the asylum process and
support that is available to them free of charge.

7.2 Each Transferee will be permitted to seek legal advice or other counsel from any non-governmental or
multilateral organisation, at any stage of the asylum application process at their own expense including from an
organisation providing that support free of charge.

**[*321]**

7.3 The legal representative or other counsel engaged by a Relocated Individual in accordance with 7.2 above
will be permitted to provide legal assistance at every stage of the claim, in accordance with Rwandan law.

**8 Legal assistance at appeal**

8.1 Should a Relocated Individual wish to appeal their decision to the court of Rwanda they will be provided
with legal assistance and representation from a legal professional qualified to advise and represent in matters
of asylum, free of charge. This shall include, at least, the preparation of the required procedural documents and
participation in the hearing before the appeal court on behalf of the applicant.

8.2 Rwanda shall provide the legal advisor access to the information provided by the applicant's file upon the
basis of which a decision is or will be made. Rwanda may make an exception where disclosure of information
or sources would jeopardise national security, the security of the organisations or person(s) providing the
information or the security of the person(s) to whom the information relates or where the investigative interests
relating to the examination of applications for international protection by the competent authorities of Rwanda
or the international relations of Rwanda would be compromised.'

**[225] Although the phrase 'legal assistance' is used in the heading to both paragraphs, the text clearly distinguishes**
between legal assistance simpliciter (para 7) and legal assistance _and representation (see para 8.1). At the_
administrative stages of the RSD process the asylum-seeker will be 'permitted' to obtain legal assistance, at their
own cost or from a pro bono organisation, but a right to representation (which will be free) is only assured for any
High Court appeal.

**[226] The assurances in the APNV give rise to two questions:**


-----

High Commissioner for Refugees intervening) and ot....

(1)   Does the right to 'legal assistance' at the administrative stage of the process mean that a claimant
will be entitled to be accompanied by a lawyer at any interview and/or that their lawyer will be permitted to
make submissions, oral or in writing, to a decision-making body (ie the RSDC or MINEMA)?

(2)   How accessible in practice will legal assistance and/or representation be?

**(1) Legal Assistance**

**[227] There is no reason to doubt the assurance at para 7.1 of the APNV that RIs will be given information about**
how to access legal assistance or to suppose that any obstacles will be put in the way of their doing so (subject to
the issue about its availability). The issue here is what role the lawyers will be able to play over and above giving
advice and assistance with documents.

**[228] The UNHCR evidence is that current practice is that lawyers are not permitted to accompany claimants to**
DGIE interviews or to make any submissions to the RSDC: see paras [174] and [183] above. That evidence is
consistent with the Asylum System CPIN, paras 4.8.2–3 of which read (so far as material):

'4.8.2 During the meeting with the Rwandan Government on 18 January 2022, HO officials asked about the
availability of legal advice and support for asylum seekers during the RSD process. The Director of Response
and Recovery Unit at MINEMA explained:

**[*322]**

“Legal assistance is provided for the 2nd level claim [referral to minister for review]. Up to now there have been
no cases of an asylum seeker having a lawyer before the RSDC decision because the initial decisions are
based on analysis of facts and explanations provided by the asylum seeker …”

4.8.3 HO officials asked whether claimants were allowed to have a legal adviser for the first level claim if they
wanted one and the Director explained: “No, only at the level where a case goes before the court. …” '

(That passage appears to contain an internal contradiction about whether legal assistance is available for the
appeal to MINEMA; I return to this below.)

**[229] The GoR's response documents initially appeared to confirm that lawyers would not be entitled to accompany**
claimants to interviews or to make any submissions to the RSDC. Paragraph 22 of the GoR statement says that
legal advice is available during 'the administrative phase of the RSD process' but that legal representation is only
available if an appeal is made to the High Court. Likewise the primary response says:

'… the Rwandan RSD process is an administrative process with the possibility of appeal at the High Court.
During the administrative phase of the process lawyers' role is limited: they can assist applicants in preparing
their submissions to the RSDC but they cannot attend the RSDC sessions. At the High Court level, the RSDC
lawyers are permitted to represent the asylum seekers in accordance with the law.'

**[230] However, a rather different account is given in the GoR supplementary e-mail, which says:**

'In accordance with their constitutional right to due process, the relocated individual/asylum seeker has the
right to retain the services of a lawyer at any stage of the asylum process. The legal representative of the
asylum seeker is permitted to attend the interviews at DGIE level and any interview at the RSDC.'

Similarly, Mr Williams says at para 34 of his witness statement that he was told by the DGIE Director that RIs would
be permitted to be accompanied by a lawyer at their asylum interview. That evidence does not contradict the GoR's
previous position that a claimant's lawyers may not make submissions to the RSDC; but it is clearly a departure
from what it had previously said about attendance at interviews.

**[231] The evidence is clear that under the pre-MEDP practice claimants were not permitted to be accompanied by**
their lawyers at any interviews: although the supplementary e-mail uses the present tense, it is only reconcilable
with the other evidence if it is taken as stating the GoR's post-MEDP intentions. I am prepared to proceed on the


-----

High Commissioner for Refugees intervening) and ot....

basis that that is now what is intended, though it is very unsatisfactory that it is unacknowledged in the evidence
that this is a major change in the process. But it is another matter how easy it will be to introduce a significant
change of practice of this kind. There are bound to be questions both about its administrative implementation and
about defining the role that the lawyer should be permitted to play in an interview at each level. On any view there
will be a need for planning and training of a kind which it is very unlikely has occurred in view of the late emergence
of this evidence and which is not likely to be straightforward.
**[*323]**

**[232] There is some support for that view in an e-mail dated 31 March 2022 from Finnlo Crellin, part of the Home**
Office team based in Kigali, reporting a meeting with his counterparts in the Rwandan Ministry of Justice. This reads
(so far as material):

'The main purpose was to talk them through, and get their initial views on, the latest draught of the Asylum
Process NV … A few key points:

…

  - As expected, 7.2 and 7.3 were the biggest sticking points. They felt that this brought us back to the same
issues we discussed last week, particularly in terms of compatibility with, and potential impacts on, their
immigration system – including the risk of creating 2 asylum systems. I emphasised this was a red line for us …
Ultimately they agreed to keep the wording as it is but, in Providence's [evidently a member of the GoR team]
words, “we'll see how it works in practice” …'

It is not necessary to understand the nuances: I refer to this passage only to illustrate that the assurances about
legal assistance (the subject of paras 7.2 and 7.3 of the APNV) were regarded by the relevant GoR officials as likely
to be difficult to implement.

**[233] The position as regards the appeals to MINEMA is rather different. We are not in this context concerned (at**
least generally) with the presence of a lawyer at an interview but with whether they are entitled to make
submissions to the Minister. As to that, the evidence tends to suggest that that was not permitted pre-MEDP; but
para 5.2 of the APNV appears to confirm that it will be the case in future. I see no reason to doubt that it is intended
that that assurance will be complied with, but again adjusting to a change of this kind will not be straightforward.
**(2) Accessibility of legal assistance/representation**

**[234] It is unrealistic to suppose that RIs will be in a position to pay for legal assistance at the administrative stage**
of the RSD process. They will accordingly be dependent on _pro bono assistance. The GoR says that such_
assistance will be available from one of two NGOs in Rwanda, the Prison Fellowship ('PFR') and the Legal Aid
Forum ('LAF').

**[235] Mr Bottinick gives evidence about the assistance available from these two NGOs at para 100 of LB 2. In**
summary, he says that PFR has only a single legal officer who regularly provides assistance in the RSD process,
as part of a number of other duties: she is not a qualified lawyer, though she has a law degree. When she is not
available, there is another lawyer at PFR who can act as backup, though this is not part of his regular work. (PFR
also has some legal officers who are engaged in the ETM project referred to above but these are not available to
work on RSD cases.) As for LAF, this primarily operates in camps and urban centres outside Kigali. Mr Bottinick
says that his colleagues in Kigali have spoken to LAF for the purpose of his statement and have been told that four
of its lawyers have some previous experience in assisting in the RSD process but that they currently do so very
rarely: it routinely refers its RSD cases to PFR. He says that it was unfortunate that in its assessment visits the
Home Office team had met LAF but not PFR.

**[236] The GoR's response appears in several places:**

(1)   The GoR statement says, at para 22:

**[*324]**


-----

High Commissioner for Refugees intervening) and ot....

'The Government of Rwanda … intends to ensure access to legal advice to asylum seekers during the
administrative phase of the RSD process. The Government of Rwanda is building on existing partnership
agreements with partner organizations such as the Legal Aid Forum, the Prison Fellowship and the Rwanda
Bar Association to provide more funding aimed at increasing the partner organizations' capacity to provide free
legal aid to asylum seekers.'

(2)   The primary response when addressing para 100 of LB 2 begins by stating that 'LAF informed us that
it currently has 34 Advocates and over 20 legal officers on refugee protection and asylum procedures'. The
rest of the answer is directed to the availability of lawyers to represent RIs in the High Court and is not
relevant for present purposes.

(3)   Question 6 of the tabular response asks about arrangements for 'access to legal advice … at the
initial stage'. The answer reads:

'There is a tripartite agreement between the government of Rwanda, Legal Aid Forum and Prison Fellowship
(nongovernmental organizations) to provide legal services and legal assistance in regards to refugee
protection.

In addition, the ministry of justice has a standing agreement with Rwanda Bar Association to provide legal aid
services free of charge such pro-bono lawyers and free legal advice.'

(4)   Question 8 of the tabular response refers to UNHCR having suggested that 'there is only 1 lawyer
who is adequately trained in Rwanda to assist' and asks if that is correct and for further information about
training. The reference appears to be to para 100 of LB 2, though if so it is not very accurate. The first part
of the answer refers to numbers at the Rwandan bar generally and to their training. But it continues:

'The Legal Aid Forum has at 36 lawyers trained to provide legal assistance on matters relating to the asylum
process and migration law. The LAF lawyers have received training on Refugee protection and migration from
in-house programs and UNHCR programs.'

That statement differs from what is said in the primary response.

**[237] I should also refer to para 8.1 of the PDA, which states:**

'During the initial application process RIs can seek legal assistance at their own cost for private advice or
through NGOs during the initial stage. Two NGOs, the Legal Aid Forum and Prison Fellowship, have confirmed
to the GoR they will provide advice at no cost if RIs ask for it at the initial stage. The GoR does not have a
formal agreement with them for this.'

**[238] The GoR's statements on this aspect are unsatisfactory. It is in my view clear from UNHCR's evidence that**
the NGOs with which the GoR says it has a 'partnership' – ie PFR and LAF – would not with their present resources
be able to provide legal assistance in the administrative stage of the RSD to any substantial further number of
asylum-seekers relocated to Rwanda under the MEDP. The statements quoted at (2) and (4) above give general
(though in fact different) numbers for the lawyers/legal officers qualified to give advice in this
**[*325]**

field, but it does not follow that they would be available to advise RIs, and the effect of Mr Bottinick's evidence is
that they are in fact engaged on other work. It is true that the answer to qu (6) also refers to a 'standing agreement
with Rwanda Bar Association', but no details are given of the agreement and it is far from clear that the agreement
is relevant to legal assistance of the kind with which we are concerned here. It is also true that in the statement
quoted at (1) the GoR speaks of 'building on' its existing partnerships and funding the organisations in question so
as to increase their capacity. But that is extremely unspecific, and it appears from the PDA that there are in fact no
formal agreements in place. I believe I should accept the UNHCR evidence as stating the current position.

**[239] I turn to the question of legal representation for RIs on any appeal to the High Court, as promised in para 8.1**
of the APNV. The only concern expressed by UNHCR about this commitment is whether there are a significant


-----

High Commissioner for Refugees intervening) and ot....

number of qualified lawyers in Rwanda with the expertise to conduct such appeals, given that none have so far
been brought. Figures supplied by the GoR in the tabular response (see qu 9) show that there are over a thousand
'senior registered lawyers' in Rwanda and a further 300 'intern advocates'. Refugee law will have been part of the
curriculum in their original training and the Ministry of Justice has agreed with the Institute of Legal Practice and
Development for courses to be run on refugee law.

**[240] Mr Bottinick does not in LB 3 respond to that evidence. In my view the most that can be said is that lawyers**
conducting the first appeals in the High Court are likely to have a steep learning curve, but it does not follow that
they will be unable to give proper representation.
Interpreters

**[241] The great majority of asylum-seekers relocated to Rwanda under the MEDP will not be fluent in any of its**
official languages (English, French and Kinyarwanda). They will therefore need the services of an interpreter (a) to
make their initial claim; (b) in their interview with DGIE; (c) in any subsequent interview required by the Eligibility
Officer or the RSDC; (d) for the purposes of any appeal to the Minister or to the High Court; and (e) in any dealings
with lawyers or other advisers.

**[242] That need is recognised in the APNV. Paragraph 9 reads:**

**'Interpreter**

9.1 If a Relocated Individual requires it, an interpreter will be provided, free of charge, whenever the Relocated
Individual meets with a legal representative provided to them free of charge in accordance with 8.1 above or a
representative or employee of the Government directly involved in the Relocated Individual's asylum
application.

9.2 All written correspondence and information that a Relocated Individual receives concerning their claim and
the asylum process will be translated by an appropriate interpreter, free of charge, if they require it to
understand.

9.3 A Relocated Individual who has the opportunity to consider a written transcript of their interview will have
the assistance of an interpreter, free of charge, if needed for understanding.'

(I note that para 9.1 does not provide for access to an interpreter in making the initial claim; but that is unlikely to
matter in practice if the claimant has access to a lawyer for that purpose.)
**[*326]**

**[243] It appears from para 9 of the PDA that although the GoR has contracted for the provision for RIs of**
interpreters in a number of languages, including Arabic, it has not been able to do so for a number of other
languages, including Kurdish, Vietnamese and Albanian (all languages spoken by the Claimants in this case) and
also Pashto (which will be relevant to many Afghan nationals). The PDA says:

'To mitigate this, they have agreed to use the virtual interpretation facilities the Home Office have offered to
them through the Home Office contract with The Big Word (TBW). They have opted for telephone interpreting,
face to face interpreting by way of an online platform and translation services (for the SOPS, orientation pack
and other written documents where necessary). They intend to use TBW only where necessary and when their
current contractors cannot provide a service. This was set up ahead of the scheduled charter flight on 14/6 and
has been tested to ensure the service is functioning. Longer term, GoR will look to negotiate their own separate
contract with the TBW with assistance from the dedicated HO team.'

It appears from Mr Williams' witness statement that this difficulty only emerged in a meeting with the DGIE Director
on 26 May.

**[244] In para 35 of LB 3 Mr Bottinick expresses concerns about this arrangement, on the basis that not all officials**
involved in the process speak fluent English An interpreter based in Rwanda could assist such officials by using


-----

High Commissioner for Refugees intervening) and ot....

Kinyarwanda where necessary, and interpreting anything said in Kinyarwanda to the asylum-seeker, which a
remote interpreter could not do. I understand the concern, and remote interpretation is no doubt sub-optimal; but
there is no reason to suppose that a DGIE official who was not fluent in English would be asked to conduct an
interview in which English was the medium of interpretation. This problem by itself may not undermine the fairness
or effectiveness of the system, but it reinforces the need for those conducting an interview to have the skills and
experience to cope professionally with difficulties of this kind.
Training

**[245] It is obvious, and undisputed, that officials making asylum decisions, or otherwise contributing to the process,**
need to be properly trained. That is recognised in the APNV, para 4.2 of which reads:

'Asylum decisions will be taken by decision-makers who are appropriately trained to take a decision on an
asylum claim in accordance with the Refugee Convention and are able to seek advice from senior officials or
external experts if necessary.'

However, there are two particular reasons why proper training is essential in the circumstances of this case.

**[246] First, as noted above, Rwanda has comparatively little experience of assessing and determining individual**
asylum claims, and still less claims from claimants with the nationalities that are likely to be typical of those
relocated under the MEDP. On its own figures the total number of claims determined by the RSDC between 2019
and June 2022 is 152, of whom 115 were from DRC and Burundi, and another 20 from Eritrea. It has determined no
claims
**[*327]**

requiring consideration of conditions in the countries from which the Claimants originate – that is, Syria, Iraq, Iran
(most of these being ethnic Kurds), Vietnam, Sudan or Albania. These Claimants are likely to be broadly
representative of the cohort of asylum-seekers liable to be relocated under the MEDP, except that they include noone from Afghanistan (from which the RSDC has so far determined only one claim). A table exhibited to LB 3 gives
figures, on the basis of the information available to the UNHCR (which it accepts may be incomplete), of all cases in
the process over the relevant period, including those not yet determined: although that shows a handful of cases
from Syria, Sudan and Afghanistan, the proportionate picture is the same. The RSDC, together with DGIE and the
Eligibility Officers in so far as their work feeds into its decisions, will be effectively starting from scratch in acquiring
an understanding of the situations in those countries.

**[247] Second, the system in place at the date of the conclusion of the MEDC had the serious deficiencies identified**
in the earlier discussion, which need to be addressed by effective training.

**[248] In those circumstances particularly thorough and effective training is required in order that the relevant**
institutions and individuals can deal properly with RIs. Paragraph 18(i) of the UNHCR Note reads:

'There is a need for an objective assessment of the fairness and efficiency of the asylum procedures, followed
by a range of capacity development interventions including, but not limited to, sustained capacity building and
_training for all actors working in the Rwandan national asylum system.' (My emphasis.)_

I agree.

**[249] The question of the current level of training of those operating the system is addressed at paras 89–98 of LB**
2. Mr Bottinick summarises his evidence in para 89 as follows:

'UNHCR has observed serious shortcomings in knowledge and training regarding RSD among relevant officials
at all levels. UNHCR considers that this lack of training gives rise to a serious risk that refugees will be refused
recognition by the Rwandan Government and refouled.'

He goes on to say that UNHCR provided a three-day training course to officials in June 2017 but that, although it
had repeatedly offered further training the offers had not been taken up until December 2021 when it was invited to


-----

High Commissioner for Refugees intervening) and ot....

co-facilitate, together with MINEMA, the Rwanda Law Reform Committee and the University of Rwanda, a
workshop for DGIE and RSDC staff and officials. The workshop was intended to last four and a half days but in fact
lasted just over three because of the unavailability of the intended attendees. Paragraphs 93–97 of LB 2 read as
follows:

'93. The training was attended by only 15 participants. Out of 11 RSDC members at the time, eight attended,
but even some of those could only attend partially because of their conflicting professional schedules and
ministerial commitments (and one attended for only two days). The RSDC chair (who was new to the process
at the time and had not yet attended any RSD-related adjudication) and secretary missed at least the first day
of the training which covered basic principles of refugee law.

**[*328]**

94. At the time of the training, most RSDC members were new, had no prior exposure to RSD and had not
attended RSDC deliberations. One of the officials remarked that he did not understand why he was required to
undertake RSD given that his departmental role was not connected to asylum.

95. The training was targeted at an extremely basic level. It included, in the main, general principles of refugee
law, in addition to brief and basic training on assessing individual claims and interviewing techniques. My
colleagues felt that the basic knowledge of the attendees did not allow them to cover crucial areas such as how
to deal with claims based on membership of a particular social group.

96. The participants' lack of relevant knowledge and skills was particularly apparent during a simulation of
RSDC interviews and decision making. Observations from UNHCR's trainers noted that the participants lacked
interviews skills and had very limited or no understanding of how to assess refugee status. In a simulation
involving a husband and wife, the “couple” were interviewed together and the husband was allowed to answer
for the wife. In addition, there was no opportunity for the “asylum seeker” to express relevant gender-based
violence related elements of her claim. It was also noted that elaborate leading questions were asked by
participants and that the “asylum seeker” was not given an opportunity to respond in full to questions, nor were
they alerted to adverse credibility points. When making their assessments of the cases, participants were
unable to demonstrate knowledge of how to assess credibility and COI; or of key concepts in refugee law. This
is not surprising given that the participants are senior civil servants with no background in RSD.

97. In UNHCR's view, this short (and truncated) one-off workshop cannot be considered adequate training to
ensure fair RSD decision making, especially for training participants with little or no prior knowledge and
experience of refugee law. RSDC members still at the end of the training lacked by some distance the requisite
knowledge and skills to make fair, reliable RSC decisions. RSDC members require significant further in-depth
on-the-job training and shadowing of appropriate procedures. However, in UNHCR's view, while that is
necessary to rectify some of the problems in the RSDC process, it would be far from sufficient: the nonspecialist composition of the RSDC is inimical to fair, reliable RSD decision-making. UNHCR was further
concerned by attitudes expressed by Rwandan authorities during this training that DGIE are within their rights
to deny access to its territory or to RSDC procedures if they consider the profile of an individual applicant
unpalatable, including on unspecified grounds of national security. The Rwandan staff and officials present at
UNHCR's December 2021 training did not appear to consider such “screened out” persons as asylum seekers
or consider that their deportation would constitute refoulement.'

He says at para 91 that he is unaware of any other outside body providing training for participants in the process.

**[250] The GoR's response to that evidence appears in a number of places and cannot readily be summarised.**

**[251] I start with the GoR statement. Paragraph 23 says:**

'The Government of Rwanda has … taken measures to build the expertise of persons involved in processing
the claims of asylum seekers.

**[*329]**


-----

High Commissioner for Refugees intervening) and ot....

The Rwanda Institute of Legal Practice and Development (ILPD) will be providing bloc courses, periodic
trainings and workshops on refugee law and other related laws to Eligibility Officers, RSDC Members, lawyers,
and high court judges.'

**[252] The primary GoR response cross-refers on this aspect to the tabular response. This has several answers**
referring to training.

**[253] First, qu 4 asked what training 'interviewing officers' – ie the DGIE officers who conduct the asylum interview**
– receive. The answer is:

'The interviewing officers at DGIE have received different trainings on international protection of refugees,
international law of refugees, rights-based approach to migration law, national laws relating to refugees and
migrants, interview skills, etc. – These various trainings were provided through:

1. Rwanda Institute of legal practice and development (ILPD).

2. The International Institute of Humanitarian Law/San Remo, Italy.'

**[254] Second, qu 7 asked various questions about the RSD Committee, including what training they have received.**
The answer is:

'They have received training on refugee status determination. … In addition to the periodic training/workshops
on international refugee law and asylum process offered by UNHCR (the latest trainings by UNHCR were
offered in 2018 and 2021). UNHCR also offered training to RSDC members at International Institute of
Humanitarian Law/San Remo, Italy. The members also bring on board complementary expertise from their
respective specialized institutions. The diverse expertise which is uniquely relevant to the work the committee
ranges from human rights perspective, diplomacy & global trends, refugee management, security and migration
matters, etc. So, RSDC is purposely comprised of members with varying knowledge and expertise that enables
objective consideration of asylum claims.'

**[255] Third, qu 26 asked if there was 'any record of how many people attended the UNHCR training for the RSD'.**
The answer is:

'Two Eligibility Officers and one RSDC members were trained at San-Remo. 9 out of the 11 RSDC members
participated in the training co-organized by MINEMA and UNHCR in December 2021 and 10 out of 11 in the
one organized by MINEMA in December 2018. Two RSD members completed online training in eligibility and
RSD process. These training normally serves to harmonize on principles that guide the decision making. In
addition, each of the RSDC members has completed training in her/his area (human right, humanitarian
protection, international justice, migration, socio economic inclusion, etc) that build analytical skills for the
member to contribute efficiently during the committee sessions.'

**[256] The primary GoR response adds two further points. First, it disputes Mr Bottinick's account that not everyone**
attended the whole of the December 2021 workshop, saying that 'the figures provided [in the tabular response] are
accurate to our knowledge'. Second, the response to para 144 of Bottinick 2 says:
**[*330]**

'A training for RSD members is also being organized and shall be facilitated by local learning institutions
(University of Rwanda and Institute of Legal Practice and Development) but also by institutions concerned by
the RSD process including MINEMA, MINIJUST, NCHR, DGIE, MINAFFET.'

**[257] Finally, Mr Williams says at para 44 of his witness statement, amplifying what appears in the relevant part of**
the PDA:

'The DGIE Director informed me that all DGIE Immigration Officers are trained on asylum and international
protection, including how to register asylum applications, conduct asylum interviews, and write reports for the


-----

High Commissioner for Refugees intervening) and ot....

Refugee Status Determination Committee (RSDC). The Director informed me on 17 June 2022 that DGIE
Immigration Officers undergo a minimum of six months training at a dedicated training college followed by onthe-job training once they commence their duties. The Director also told me on 17 June that most of the
training is in-house but DGIE Immigration Officers have received training from international organisations
including the International Organization for Migration (IOM) and international partner countries.'

**[258] The Secretary of State's evidence is responded to in para 34 of LB 3. I need not reproduce it in full. In short:**

(1)   Mr Bottinick maintains his evidence about the partial attendance at the UNHCR workshop in
December 2021.

(2)   He identifies 'San Remo', as referred to in the tabular response, as the International Institute of
Humanitarian Law in San Remo. He says that he has established from enquiries with the Institute that only
four individuals from the DGIE had attended training there between 2017–2022, of whom only one
attended training in refugee law.

(3)   He says that the Rwandan Institute of Legal Practice and Development referred to in the GoR
Statement and the tabular response does not at present offer training or programmes on refugee law and
that the University of Rwanda does not offer a module on refugee law.

(4)   He exhibits an email from the International Organisation for Migration referred to in Mr Williams'
evidence confirming that it has never provided any training on refugee determination in Rwanda.

**[259] In my judgment, Mr Bottinick's evidence raises a clear case to answer that the level of training made available**
to the key players in the asylum process – the DGIE officials who conduct the interviews, the Eligibility Officers, the
members of the RSDC, the MINEMA Minister or the officials who advise him or her on appeals – is not sufficient to
equip them to perform their functions properly. I do not believe that the Secretary of State's evidence, based on the
information obtained from the GoR, provides a satisfactory answer. In particular:

–   As regards the training of DGIE officials, the answer in the tabular response is at a very general level
and is contradicted by Mr Bottinick, on the basis of the enquiries which he specifies. As for Mr Williams'
evidence, what he was told by the Director General was in the most general terms and unsupported by any
kind of documentary evidence or records: on the one point where he is more specific (training by the IoM)
his evidence is contradicted by the e-mail produced by Mr Bottinick.

**[*331]**

–   As regards members of the RSDC, I take the GoR's point that many of them have backgrounds which
may be relevant to some aspects of the questions that they have to determine. But that must be
supplemented by a sound training in the basics of refugee law, together with support from specialist
advisers (presumably the Eligibility Officers) where points of difficulty arise. The GoR's references to
courses and workshops from outside bodies are in very general terms and are also to some extent
contradicted by the evidence from or about the bodies in question obtained by Mr Bottinick. As regards
UNHCR's own training, his evidence about the problems experienced in the December 2021 workshop is
compelling.

**[260] It is not ideal that this important point should turn on the Court's assessment of hearsay evidence from the**
GoR produced at short notice in response to the evidence of Mr Bottinick. But in truth the nature and extent of the
training of officials involved in the asylum process should have been assessed in depth, with reference to
documents and records so far as available, as part of the investigations carried out when the MEDP was still in
gestation.
_Conclusion on the adequacy of the Rwandan asylum system_

**[261] I start by acknowledging that there is nothing in the evidence that would justify the conclusion that the GoR**
has entered into the commitments in the MoU and the APNV in bad faith. There is no reason to suppose that it does
not wish to ensure that RIs have their asylum claims determined fairly and effectively. But aspiration and reality do
not necessarily coincide. As we have seen, the RSD process is a recent creation and it has so far had little


-----

High Commissioner for Refugees intervening) and ot....

experience of dealing with asylum-seekers with the characteristics of those liable to be relocated under the MEDP.
The UNHCR evidence in my view clearly shows that there are important respects in which it has not so far reliably
operated to international standards. It is its case, and the Claimants', that even if there is a will to make the
necessary changes they cannot be achieved in the short term and certainly have not been achieved yet. At paras
143–144 of LB 2 Mr Bottinick says:

'143. Rwanda's serious capacity issues cannot be addressed within a short space of time. …

144. Moreover, at the time of making this statement, UNHCR is unaware of any steps being initiated that might,
after a sustained period of capacity building, eventually permit certain of the commitments in the Notes
Verbales and MOU to be fulfilled. UNHCR is not, for example, aware of interpreters, lawyers or decision
makers being hired or trained by the Rwandan Government at present.'

I should say that when Mr Bottinick refers to 'capacity' it is clear from the context that he is not referring primarily to
ability to cope with numbers but to skills and experience more generally. It is not, therefore, an answer to say that
the GoR can decline to accept more RIs than the RSD process can cope with in the early stages of the MEDP.

**[262] The essential question is thus to my mind whether the changes necessary to ensure compliance with the**
GoR's assurances had been, or in any event would be, implemented before relocations under the MEDP began to
take place: that was of course initially intended to be on 14 June 2022 (only two
**[*332]**

months after the conclusion of the MEDP), although as I have said the position should now be judged as at the
dates of the hearing in the Divisional Court.

**[263] I have not found it entirely straightforward to answer that question. The evidence is not as complete as could**
be wished; and, as already noted, we have not had the advantage of the kind of detailed examination, with the
benefit of expert evidence and cross-examination, that would have been possible in the FTT if the Secretary of
State had not certified the Claimants' human rights claims. In the end, however, I have reached the conclusion that
the Rwandan system for refugee status determination was not, as at the relevant date, reliably fair and effective.

**[264] In reaching that conclusion I have taken into account the totality of the defects identified in the discussion**
above. Those which have weighed with me particularly, not least because they are not clearly addressed in the
APNV, are:

(1)   the evidence of the way in which asylum interviews are conducted by DGIE – see paras [164]–[166]
above;

(2)   the absence of any opportunity for a claimant to present their case to the RSDC through a lawyer –
para [189];

(3)   the evidence that the RSDC does not have sufficient skills and experience to make reliable decisions
in claims of the kind with which we are concerned; the evidence in question includes not only its character
and composition but also the evidence about its conduct of interviews, the limited support available to it
and the evidence of apparently aberrant outcomes – see paras [181]–[201] and [205]–[206];

(4)   the evidence that the NGOs who it is said can provide legal assistance to RIs during the
administrative stage of the RSD are unlikely to have sufficient capacity to do so – see paras [234]–[238];

(5)   the fact that the appeal process to the High Court is wholly untested, coupled with grounds for
concern about whether the culture of the Rwandan judiciary will mean that judges are reluctant to reverse
the decisions of the Minister and the RSDC – see paras [218]–[221].

But I repeat that the defects of the system must be regarded as a whole, and there are several other areas of
concern identified above.


-----

High Commissioner for Refugees intervening) and ot....

**[265] Those problems could be resolved by making further changes to the process (eg allowing lawyers to make**
representations to the RSDC); by 'capacity building' (eg as regards provision of legal assistance); and, importantly,
by effective training of all those involved in the process (as noted at several points above). But the evidence is that
those steps have not yet been taken or in any event not to the extent necessary to ensure the present fairness and
reliability of the system: see in particular paras [245]–[260].

**[266] Like the Master of the Rolls (see his Issues 8 and 9), I believe that that conclusion means that it is**
unnecessary to consider separately the issues relating to the adequacy of the inquiries conducted by the Secretary
of State, whether by reference to Ilias or to Tameside. I would only make two observations.

**[267] On the one hand, I would accept that this is not a case where the Home Office was merely going through the**
motions of assessing the adequacy of the Rwandan asylum system. There were evidently dedicated civil servants
genuinely trying to establish how the RSD process worked and to obtain assurances that addressed the perceived
problems.

**[268] On the other hand, however, perhaps as the result of the pressure of the timetable to which they were**
required to work, I believe that the officials in
**[*333]**

question were too ready to accept assurances which were unparticularised or unevidenced or the details of which
were unexplored: the late emergence of the problem about interpreters is an illustration of this. We were referred by
Mr Husain to a review of the Rwanda CPINs which was undertaken in July 2022 for the Independent Advisory
Group on Country Information ('IAGCI'). IAGCI acts on the instructions of the Independent Chief Inspector of
Borders and Immigration, to whom it provides advice to the Chief Inspector of the UK Border Agency to allow him to
discharge his obligation under _[s 48(2)(j) of the UK Borders Act 2007. The researcher responsible for the review](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y1CY-00000-00&context=1519360)_
criticised various aspects of the way in which the Asylum System CPIN was prepared, including 'very limited critical
information on the Rwandan asylum system' and 'fundamental gaps of information and unanswered questions with
regards to procedural practicalities and implications', together with more specific methodological criticisms of the
conduct of the interviews contained in the Annex A CPIN. As the Divisional Court pointed out at para [59] of its
judgment, and as Sir James emphasised in his oral submissions, the Chief Inspector has not himself made any
recommendations, and it is not known whether or to what extent he will endorse those criticisms. But I note that
they are consistent with my own conclusion. I should also say in this connection that I believe that it is unfortunate
that officials did not engage with UNHCR on their first visit to Rwanda in January 2022. Their initial intention was to
do so; but it seems that, for reasons that are unclear, they did not receive the necessary clearance from the
Secretary of State.

**[269] I have not so far addressed the reasoning of the Divisional Court. It says, at paras [64]–[66]:**

'[64] In the present case we consider the Home Secretary is entitled to rely on the assurances contained in the
MOU and Notes Verbales, for the following reasons. The United Kingdom and the Republic of Rwanda have a
well-established relationship. This is explained in the witness statement of Simon Mustard, the Director, Africa
(East and Central) at the Foreign, Commonwealth and Development Office. This has comprised a development
partnership set out in various agreements (referred to as Development Partnership Agreements) since 1998.
The relationship is kept under review. In 2012 it was suspended by the United Kingdom government in
response to Rwanda's involvement in the so-called “M23 Rebellion” in the Democratic Republic of Congo, and
in 2014 the relationship was further reviewed in response to the assassination in South Africa of a Rwandan
dissident. Since then, the United Kingdom has continued to provide Rwanda with financial aid, but this has
been tied to specific activities. Thus, while there is a significant history of the two governments working
together, the Rwandan government has reason to know that the United Kingdom government places
importance on Rwanda's compliance in good faith with the terms on which the relationship is conducted.

[65] The terms of the MOU and _Notes Verbales are specific and detailed. The obligations that Rwanda has_
undertaken are clear. All, in one sense or another, concern Rwanda's compliance with obligations it already


-----

High Commissioner for Refugees intervening) and ot....

accepts as a signatory to the Refugee Convention. The Claimants have placed particular emphasis on whether
the Rwandan asylum system will have the capacity to handle asylum claims made by those who are
transferred under the terms of MOU. It is a fair point that, to date, the number of claims

**[*334]**

handled by the Rwandan asylum system has been small. It is also fair to point out, as Mr Bottinick has, that it
will take time and resources to develop the capacity of the Rwandan asylum system. However, significant
resources are to be provided under the MEDP, and by paragraph 3.3 of the MOU the number of persons that
will be transferred will depend on the consent of the Rwandan government, taking account of its capacity to
deal with persons in the way required under the MOU and the _Notes Verbales. The MOU also contains_
monitoring mechanisms in the form of the Joint Committee (paragraph 21 of the MOU) and the Monitoring
Committee (paragraph 15 of the MOU). For now, at least, there is no reason to believe that these bodies will
not prove to be effective. Lastly, the MOU makes provision for significant financial assistance to Rwanda. That
is a clear and significant incentive towards compliance with the terms of the arrangement.

[66] Moreover, Mr Mustard explains that HM Government is satisfied that Rwanda will honour its obligations. At
paragraph 20 of his statement, he says this:

“The British High Commission in Kigali led initial conversations with the [Government of Rwanda] regarding the

[MEDP] and participated in negotiations in support of the Home Office. Since these negotiations began, there
has been a renewed focus on our bilateral relationship with an increase in contact at an official and ministerial
level. Prior to signing the agreement, Home Office officials visited the Rwanda on many occasions, meeting
government and non-governmental interlocutors, and carried out further discussions virtually. The Rwandan
Permanent Secretary to the Ministry of Foreign Affairs also led a delegation to London for further talks. These
negotiations have been conducted transparently and in good faith throughout. In light of the considerations
described in this witness statement, and the manner in which the negotiations [with] our Rwandan counterparts
were conducted, we are confident that Rwanda will honour its commitments under the MEDP.”

We consider that we could go behind this opinion only if there were compelling evidence to the contrary. We do
not consider such evidence exists.'

**[270] As discussed at paras [128]–[129] above, it seems from that passage that the Divisional Court erred by**
approaching its task in this part of its judgment as one of review rather than seeking to reach its own conclusion.
But even if I am wrong about that, I do not believe that its reasoning can be supported. It did not seek to engage
with the details of UNHCR's criticisms of the RSD process. As I read it, the principal reason why it thought that this
was unnecessary was the weight that it attached to Mr Mustard's assessment, representing the view of the UK
Government, that the GoR would honour its commitments under the MEDP. As to that, I would accept that great
weight should indeed be given to the Government's assessment that the GoR negotiated the MEDP in good faith
and with a genuine willingness to comply with its obligations under it, for the reasons which the Court gives at paras

[64]–[65] of its judgment. I agree that there is no reason to doubt the genuineness of the GoR's intentions: it is for
that reason that I have found that there is no risk of RIs being denied access to the RSD process (see para [155]
**[*335]**

above). But the real issue here is not the good faith of the GoR at the political level but its ability to deliver on its
assurances in the light of the present state of the Rwandan asylum system.

**[271] The Divisional Court does in fact in para [65] acknowledge that 'it will take time and resources to develop the**
capacity of the Rwandan asylum system'; but it believes that that concern is sufficiently answered by the facts that
significant resources are to be provided to the GoR under the MEDP and that it has the right to control the numbers
of RIs admitted so that they do not exceed the capacity of the RSD process at any given time. However, the
provision of resources does not mean that the problems in the Rwandan system can be resolved in the immediate
term; and even if the flow of RIs is restricted for the time being in order for improvements to take effect that does not
justify the denial of a fair and effective asylum system to the earlier arrivals.


-----

High Commissioner for Refugees intervening) and ot....

**[272] In short, the relocation of asylum-seekers to Rwanda under the MEDP would involve their claims being**
determined under a system which, on the evidence, has up to now had serious deficiencies, and at the date of the
hearing in the Divisional Court those deficiencies had not been corrected and were not likely to be in the short term.
_Risk of refoulement_

**[273] The result of my conclusion in the preceding section is that there are substantial grounds for believing that**
there is a real risk that the asylum claims of RIs may be wrongly refused. On the face of it, it would appear to follow
that there was a real risk of them being refouled. Where an asylum-seeker's claim is rejected the country in
question will typically require them to leave the country (in the absence of any other basis on which they might claim
residence), and since they will have been found to be at no risk in their country of origin, there is no reason why
they should not be returned there; and even if they are in the first instance returned to some other country that does
not exclude the possibility of indirect refoulement. The reason why the ECtHR in _Ilias insisted on the need to_
establish that there was an adequate asylum system in the country of return is that the existence of such a system
is regarded as an essential protection against the risk of refoulement.

**[274] It may be, however, that the Secretary of State wishes to submit that a finding that the Rwandan asylum**
system is inadequate would not in the circumstances of this case mean that there is a real risk of refoulement. At
the start of the part of her skeleton argument dealing with the safety of Rwanda she advances five 'overarching
submissions'. The fifth, which appears at para 8 of the skeleton, is that the Court should not seek to interpret
Rwandan asylum law or predict how it might apply in particular cases because it was sufficient to rely on para 9.1.1
of the MoU. The paragraph continues:

'Furthermore, even if some deficiency in Rwandan asylum law were identified … it would not give rise to a risk
of refoulement or Article 3 ill treatment unless there were to be evidence of intention to send the asylum seeker
back to their country of origin.'

A footnote reads:

'Rwanda has no returns agreement with any of the countries in question … The MOU provides, at para 10.3,
for relocated individuals to apply for residence even if refused asylum.'

**[*336]**

**[275] The statements made in the footnote are referenced to passages in the witness statements of Mr Williams**
and Mr Armstrong. It is sufficient to refer to the latter. Mr Armstrong says, at para 85:

'The statement of Chris Williams sets out what he was told by DGIE officials about what would happen to
relocated individuals who are refused asylum. Senior officials from DGIE in Rwanda confirmed that if an
individual who was relocated to Rwanda under the MEDP had their asylum claim refused and all their appeal
rights were exhausted, they would be eligible to be issued a Resident Card. They said that they envisaged that
all relocated individuals would be permitted to remain in Rwanda and that no relocated individuals would be
forcibly returned to their country of origin. They also explained that the Government of Rwanda did not have
returns agreements or arrangements in place with any country with the exception of neighbouring countries.'

The statements there attributed to the DGIE officials are consistent with statements made in the GoR statement
(see para 5) and the tabular response (answers to qus (12) and (22)).

**[276] Paragraph 10.3 of the MoU, also referenced in the footnote, reads:**

'10.3 For those Relocated Individuals who are neither recognised as refugees nor to have protection need in
accordance with paragraph 10.2, Rwanda will:

10.3.1 offer an opportunity for the Relocated Individual to apply for permission to remain in Rwanda on any
other basis in accordance with its domestic immigration laws and ensure the Relocated Individual is provided
with the relevant information needed to make such an application;


-----

High Commissioner for Refugees intervening) and ot....

10.3.2 provide adequate support and accommodation for the Relocated Individual's health and security until
such a time as their status is regularised or they leave or are removed from Rwanda.'

Reference should also, I think, be made to para 10.4, which reads:

'For those Relocated Individuals who are neither recognised as refugees nor to have a protection need or other
basis upon which to remain in Rwanda, Rwanda will only remove such a person to a country in which they
have a right to reside. If there is no prospect of such removal occurring for any reason Rwanda will regularise
that person's immigration status in Rwanda.'

**[277] Although the submission which I have quoted from the skeleton argument is ostensibly addressed only to a**
situation where there is 'some deficiency in Rwandan asylum law', the logic of the point might be thought to apply to
a situation where the asylum system as a whole was inadequate and thus liable to produce wrong outcomes: that
is, it might be said that its inadequacy did not matter 'unless there were to be evidence of intention to send the
asylum seeker back to their country of origin'.

**[278] The issue was not addressed by the Divisional Court, since in the light of its conclusion on the adequacy of**
the Rwandan asylum system it did not arise.

**[279] The submission in question was not developed in the hearing before us. In his opening submissions Mr**
Husain referred to it but only to contend that
**[*337]**

the point was not open to the Secretary of State because it had not been pleaded in a Respondent's Notice. He
said that it was in any event bad but that he would address it in his reply if necessary. In the event, Sir James Eadie
made no oral submissions on this point and Mr Husain did not revert to it.

**[280] Mr Husain is right to say that this submission should have been raised in a Respondent's Notice. With some**
hesitation, however, I think that I should consider it, although in the absence of oral argument I can and should only
deal with it briefly.

**[281] I start by setting out what is said in the GoR statement and the tabular response as referred to above:**

(1)   Paragraph 5 of the GoR statement reads:

'Practice shows that a number of asylum applications are made by individuals looking for the right to work and
reside in Rwanda and not necessarily in need of international protection under the Refugee Convention and the
national laws relating to refugees. As mentioned above, the RSD process is nonadversarial and actively seeks
provide durable solutions to all individuals claiming asylum. To this effect, it is the Government of Rwanda's
policy to not conduct deportations of persons whose asylum claims are rejected. The DGIE endeavors to
provide legal residence to persons residing in Rwanda. A significant portion of asylum applicants are granted
legal residence in Rwanda on other grounds such as work/business permits and dependent/relatives permits.'

(2)   Question 12 in the tabular response asks how many of those who are refused asylum are forcibly
removed from Rwanda. The answer is:

'None. Rwanda has a policy of no deportation. Most of those whose refugee status are not accepted are
granted legal residence permit on other grounds. Others leave voluntarily.'

(3)   Question 22 of the tabular response reads:

'Relocated individuals who are refused asylum and are not grated another leave status in Rwanda. We
understand that at present there are no returns agreements with the main countries of origin for those likely to
come to you under the arrangements. Do you intend to reach out to these countries to negotiate these and if
not would you otherwise remove these individuals and if so how?'

The answer is:


-----

High Commissioner for Refugees intervening) and ot....

'There are no intentions to conclude return agreements with countries at the moment. the relocated individuals
will be issued with resident permits which will allow them to have resident travel document in case they want to
return to their country of origin: a resident travel document issued to a foreigner legally residing in Rwanda who
is not a refugee and who is unable to acquire any other travel document. it should be noted that under this
arrangement and in respect of domestic laws and all other international conventions on refugees and human
rights that Rwanda has signed, no relocated

**[*338]**

individual will be removed or sent back to a country where he/she may face danger or persecution. If any
individual needs to be removed from the country, formal consultations through the available diplomatic
channels will be done to effect the removal.'

**[282] In my view none of those statements can be treated as a reliable assurance that an RI whose asylum claim is**
refused will be permitted to remain in Rwanda and enjoy basic rights equivalent to those granted by the Refugee
Convention. I would make three points.

**[283] First, as to the possibility of the RI being granted legal residence on other grounds, it is – unsurprisingly – not**
said that this occurs in every case (the tabular response says 'most', but the GoR statement says 'a significant
portion'). It is in fact easy to see how the grant of 'work/business permits' and 'dependent/relatives permits' may be
appropriate for migrants from neighbouring countries, who have historically constituted the great majority of asylumseekers in Rwanda; but the circumstances of RIs will be wholly different. Whether or not some RIs may be granted
legal residence on another basis, the question remains of what will happen to those who are not, who are likely to
be the great majority.

**[284] Second, para 10.3.2 refers in terms to the removal of RIs whose asylum claims fail and who do not qualify for**
a right to remain on any other basis. Paragraph 10.4 provides that they will only be removed to a country where
they have the right to reside, but that would of course include their country of origin, in which the GoR would (ex
_hypothesi wrongly) have decided that they did not face a risk of persecution or other ill-treatment._

**[285] Third, while there is no reason to doubt the statement that Rwanda has at present no return agreements with**
the countries of which RIs are likely to be nationals, and no intention 'at the moment' to conclude any such
agreement, that falls well short of a guarantee that it will not do so in future. In any event direct return is not the only
way that refoulement can occur, as the cases referred to at para [146] illustrate.

**[286] In short, even if the Secretary of State is seeking to advance the (prima facie surprising) argument that it does**
not matter if Rwanda's asylum system is inadequate because RIs whose claims are wrongly refused will in every
case be allowed to stay I would not accept that argument.
_Article 3 Risks other than refoulement_

**[287] As noted above, the Claimants also allege that the repressive nature of the Rwandan regime means that**
asylum-seekers and refugees will be at risk of inhuman and degrading treatment within the meaning of art 3 if they
engage in protests against or other criticisms of the GoR. The Master of the Rolls sets out the nature of the case in
rather more detail at para [103] of his judgment.

**[288] This aspect of the case is addressed in the judgment of the Divisional Court at paras [73]–[77] under the**
heading 'Conditions in Rwanda generally'. It acknowledges that there is clear evidence that the GoR is intolerant of
dissent; that there are restrictions on the right of peaceful assembly, freedom of the press and freedom of speech;
and that political opponents have been detained in unofficial detention centres and have been subjected to torture
and art 3 ill-treatment short of torture. However, it concludes that there is no real risk that persons returned under
the MEDP would be ill-treated even if they expressed dissent or protest (whether about their own treatment or on
other issues). Paragraph [77] concludes:
**[*339]**


-----

High Commissioner for Refugees intervening) and ot....

'… [T]he Claimants' submission is speculative. It does not rest on any evidence of any presently-held opinion.
There is no suggestion that any of the individual Claimants would be required to conceal presently-held political
or other views. The Claimants' submission also assumes that the response of the Rwandan authorities to any
opinion that may in future be held by any transferred person would (or might) involve article 3 ill-treatment.
Given that the person concerned would have been transferred under the terms of the MEDP that possibility is
not a real risk. It is to be expected that the treatment to be afforded to those transferred will be kept under the
review by the Monitoring Committee and the Joint Committee (each established under the MOU). Further, the
advantages that accrue to the Rwandan authorities from the MEDP provide a real incentive against any mistreatment (whether or not reaching the standard of article 3 ill-treatment) of any transferred person.'

**[289] In the light of the conclusion that I have reached on the refoulement issue I do not need to decide whether the**
Divisional Court's conclusion was correct, and I prefer not to do so since we heard only very limited oral
submissions about it. I confine myself to two observations.

**[290] First, I respectfully doubt whether it is relevant that the Claimants themselves have not been shown to hold**
any opinions of a kind which are likely to attract adverse attention from the GoR[6]. We are, as I have said,
concerned with a generic challenge, and the question must be whether there is a real risk that RIs generally may
suffer serious ill-treatment in Rwanda if they engage in any protest or express dissent.

**[291] Second, while I see the force of the point made by the Divisional Court that the GoR is likely to be very chary**
about any ill-treatment of RIs, it is right to note that documents produced by the Secretary of State show officials
expressing concern about this very aspect: an FCDO official reviewing the draft CPIN noted that asylum-seekers
'would need to be 100% compliant and subservient to very stringent top-down rules in Rwanda'.

**[292] I note the Master of the Rolls' observation at para [106] above that it would have been better if the Divisional**
Court had dealt with this aspect as an undifferentiated part of the Soering test. For myself, I see some advantages
in analysing it separately because the nature of the art 3 risk is different. But I agree that they are not wholly
distinct. The nature of the Rwandan government is a relevant background consideration in considering some
aspects of the RSD process.
_Conclusion on the safety of Rwanda issue_

**[293] For the reasons given above, I believe that the evidence before the Divisional Court established that there**
were substantial grounds to believe that asylum-seekers relocated to Rwanda under the MEDP were at real risk of
refoulement, and that accordingly such relocation would constitute a breach of art 3 of the ECHR and contravene s
6 of the 1998 Act.

8

**[294] I have thus reached the same conclusion as the Master of the Rolls about the overall safety of Rwanda issue.**
The Lord Chief Justice has reached the opposite conclusion. It will be sufficiently apparent from my reasoning
above why I respectfully take a different view from him.

**[295] I have not found it necessary to address separately each of the eleven issues identified by the Master of the**
Rolls under this heading, though I have in substance covered most of them in my analysis. However, I should say
something more about his Issues 10 and 11.
_Issue 10: Gillick_

6 I should record that the Claimants in any event contend that they do in fact hold such opinions inasmuch as in their witness
statements they express strong opposition to being relocated to Rwanda and some of them have 'participated in acts of dissent'
in this country: see para 42 of the AAA skeleton argument.

**[*340]**


-----

High Commissioner for Refugees intervening) and ot....

**[296] The effect of my conclusions thus far is that a decision to remove an asylum-seeker to Rwanda would be**
unlawful because it would involve a breach of their art 3 rights. It follows that a published policy which positively
authorised or approved such removals would also be unlawful: the relevant principles derive from the decision of
the House of Lords in _Gillick v West Norfolk and Wisbech Area Health Authority_ _[[1985] 3 All ER 402, [1986] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-607K-00000-00&context=1519360)_
112and have recently been restated by the Supreme Court in R (on the application of A) v Secretary of State for the
_Home Dept_ _[[2021] UKSC 37, [2022] 1 All ER 177, [2021] 1 WLR 3931.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HY-3H43-GXF6-833F-00000-00&context=1519360)_

**[297] The question then is whether the Secretary of State has promulgated such a policy. On 9 May 2022 she**
published version 6 of Guidance to case-workers headed 'Inadmissibility: safe third country cases' ('the
Inadmissibility Guidance')[7]. As regards relocation to Rwanda, the Guidance says:

'If a case assessed as suitable for inadmissibility action appears to stand a greater chance of being promptly
removed if referred to Rwanda (a country with which the UK has a Migration and Economic Development
Partnership (MEDP)), rather than to the country to which they have a connection, TCU should consider
referring the case to Rwanda. An asylum claimant may be eligible for removal to Rwanda if their claim is
inadmissible under this policy and (a) that claimant's journey to the UK can be described as having been
dangerous and (b) was made on or after 1 January 2022. A dangerous journey is one able or likely to cause
harm or injury.

…

Those progressed for consideration for relocation to Rwanda under the MEDP will be taken from the detained
and non-detained cohort and be identified in line with processing capacity. Priority will be given to those who
arrived in the UK after 9 May 2022.

…

Decision makers must take into account country information of the potential country/countries to where removal
may occur in deciding whether referral into a particular route is appropriate in the particular circumstances of
that claimant.'

Country information relating to Rwanda was published on the same day in the form of the CPINs identified at para

[139] above. Consistently with the

9

guidance that decisions must be taken by reference to the particular circumstances of each claimant, these do not
purport to reach a definitive conclusion on whether Rwanda is a safe third country. However, they state the views of
the CPIT on a number of issues relevant to that question, the most important of which are summarised as 'key
judgments' in the Assessment CPIN. These include, under the heading 'refoulement', the judgment that:

'There are not substantial grounds for believing that a person, if relocated, would face a real risk of being
subjected to treatment that is likely to be contrary to Article 3 ECHR by virtue of being refouled or returned to a
place where they have a well-founded fear of persecution.'

**[298] The Master of the Rolls considers that in view of his conclusion on the substantive issue of the safety of**
Rwanda it is unnecessary to decide whether the Inadmissibility Guidance is unlawful: see para [114] of his
judgment. However, I think I should say that I believe that the Guidance and the Assessment CPIN, taken together,
do constitute policy guidance which, in the light of the conclusions reached above, is indeed unlawful.

7 As explained by the Divisional Court at para [15] of its judgment, this has since been superseded by version 7, which applies
to asylum claims made on or after 28 June 2022. Version 6 is the correct version for our purposes, but it is common ground that
version 7 is substantially identical as regards the issues in these cases.

**[*341]**


-----

High Commissioner for Refugees intervening) and ot....

**[299] The Divisional Court held that the Inadmissibility Guidance was lawful: see para [72] of its judgment. But that**
simply reflects its substantive decision on the issue of the safety of Rwanda.

**[300] Ground 6 of the consolidated grounds of appeal, advanced before us by Ms Sonali Naik KC, reads:**

'The Court was wrong to conclude that R's inadmissibility policy on removals to Rwanda was not unlawful
either under the conventional Gillick test or under a Gillick test necessarily modified in cases involving a real
risk of Article 3 ECHR breach.'

**[301] Since for the reasons which I have given I would hold that the policy was indeed unlawful on what I believe to**
be a conventional basis, I see no advantage in considering the alternative submission that 'the Gillick test' requires
modification in cases based on art 3, though I feel bound to say that I had some difficulty in understanding it.
_Issue 11: Certification_

**[302] I have already made the point that we are not in this appeal concerned with the challenge to the Secretary of**
State's decision to certify the human rights claims made by (most of) the Claimants under para 19 of Sch 3 to the
2004 Act: see para [130] above. However, I agree with the Master of the Rolls that it follows that the Secretary of
State's decisions certifying the individual human rights claims could not be sustained on this ground, as well as on
the grounds on which they were in fact quashed by the Divisional Court: see para [116]. As to whether it would also
have followed, if the Court had reached the same conclusion, that the appeal to the FTT would have proceeded in
priority to the generic challenge (see his para [117]), I refer to what I say at para [131] above.
**B. THE REMAINING ISSUES**

**[303] Although our conclusion on the safety of Rwanda issue means that the Rwanda policy must be declared**
unlawful, it is necessary to consider the remaining issues raised by the Claimants' grounds of appeal, not only in
case of
**[*342]**

an appeal to the Supreme Court but also because they will remain relevant if the defects in the Rwandan asylum
system are in due course resolved. I gratefully adopt the Master of the Rolls' categorisation of the remaining issues,
and I take them in turn. Responsibility for arguing these issues on behalf of the Claimants was divided between
different counsel; they were argued on behalf of the Secretary of State by Lord Pannick KC.
_Issue 12: Breach of the Refugee ConventionIntroduction_

**[304]** _[Section 2 of the Asylum and Immigration Appeals Act 1993 is headed 'Primacy of Convention' and reads:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YH0-TWPY-Y01J-00000-00&context=1519360)_

'Nothing in the immigration rules (within the meaning of the 1971 Act) shall lay down any practice which would
be contrary to the Convention.'

('The Convention' is defined in s 1 as the Refugee Convention.)

**[305] In** _European Roma Rights Centre v Immigration Officer at Prague Airport (United Nations High Comr for_
_Refugees intervening) [2004] UKHL 55,_ _[[2005] 1 All ER 527, [2005] 2 AC 1, Lord Steyn said, at para [41] of his](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FGH-JVK0-TWP1-609F-00000-00&context=1519360)_
opinion:

'It is necessarily implicit in s 2 that no administrative practice or procedure may be adopted which would be
contrary to the Refugee Convention. After all, it would be bizarre to provide that formal immigration rules must
be consistent with the convention but that informally adopted practices need not be consistent with the
convention. The reach of s 2 of the 1993 Act is therefore comprehensive.'

Although in the Secretary of State's skeleton argument that statement is described as obiter it is not suggested, nor
did Lord Pannick submit, that we should not follow it. It seems that the Divisional Court may have had some doubts
about its correctness because at para [122] of its judgment it observed that 'Section 2 of the 1993 Act is directed
only to ensuring consistency between the Immigration Rules and the Refugee Convention' and questioned whether


-----

High Commissioner for Refugees intervening) and ot....

the 'practice' challenged in these cases fell within the terms of the section because paras 345A–345D said nothing
about removal of asylum-seekers to Rwanda; but it went on to say that it would not dismiss this part of the case on
that basis. Lord Steyn's statement has been quoted with approval in at least two subsequent decisions of this Court
– EN (Serbia) v Secretary of State for the Home Dept, Secretary of State for the Home Dept v KC (South Africa)

_[2009] EWCA Civ 630, [2009] INLR 459, [2010] QB 633(per Stanley Burnton LJ at para [58]); and Re H (A Child)_
_[(Disclosure of Asylum Documents) [2020] EWCA Civ 1001, [2021] 1 FLR 586 (per Baker LJ at para [12]). I proceed](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:624B-PS33-GXFD-8198-00000-00&context=1519360)_
on the basis that it is correct.

**[306] It is the Claimants' case that the removal of asylum-seekers to Rwanda on the basis of paras 345A–345D of**
the Immigration Rules and the Inadmissibility Guidance constitutes a practice which is contrary to the Convention
and accordingly unlawful under s 2. That case is formulated in four distinct grounds of appeal, namely grounds 9–
12 in the consolidated grounds. These read:

'9. The Court erred in failing to address the question of whether asylum-seekers removed to Rwanda would be
accorded their rights under the Refugee Convention as a matter of vires as opposed to rationality.

**[*343]**

10. The Court erred in concluding at [126] that the MEDP Scheme as set out in paragraphs 345A-D of the
Immigration Rules was consistent with the Refugee Convention and therefore not ultra vires s2 of the 1993 Act.

11. The Court erred in finding that inadmissibility and/or removal to Rwanda did not constitute a penalty for the
purposes of Article 31 of the Refugee Convention.

12. The Court was wrong to find, for the purposes of Article 31 of the Refugee Convention, that the removal of
RM, before his asylum claim would have been considered, to a third country with which he has no prior
connection, with the avowed aim of deterring them or others from seeking asylum in the UK after arriving by
unlawful means, did not constitute a penalty and therefore was consistent with _[s.2 of the Asylum and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YH0-TWPY-Y01J-00000-00&context=1519360)_
Immigration Appeals Act 1993.'

**[307] Grounds 9 and 11 were pleaded in AAA and were advanced by Mr Husain; grounds 10 and 12 were pleaded**
in ASM and RM respectively and were advanced by Mr Richard Drabble KC. As will appear, there is some overlap
between the grounds, but I will take them as my structure in addressing this issue. I will consider ground 10 first,
then grounds 11 and 12 together, and finally ground 9.

**[308] For the purpose of grounds 10–12 the relevant provisions of the Convention are arts 31 and 33, and it will be**
convenient to set them out now. Article 31 reads:

**'Refugees unlawfully in the country of refuge**

1. The Contracting States shall not impose penalties, on account of their illegal entry or presence, on refugees
who, coming directly from a territory where their life or freedom was threatened in the sense of article 1, enter
or are present in their territory without authorization, provided they present themselves without delay to the
authorities and show good cause for their illegal entry or presence.

2. The Contracting States shall not apply to the movements of such refugees restrictions other than those
which are necessary and such restrictions shall only be applied until their status in the country is regularized or
they obtain admission into another country. The Contracting States shall allow such refugees a reasonable
period and all the necessary facilities to obtain admission into another country.'

Article 33 reads:

**'Prohibition of expulsion or return (“refoulement”)**


-----

High Commissioner for Refugees intervening) and ot....

1. No Contracting State shall expel or return (“refouler”) a refugee in any manner whatsoever to the frontiers of
territories where his life or freedom would be threatened on account of his race, religion, nationality,
membership of a particular social group or political opinion.

2. The benefit of the present provision may not, however, be claimed by a refugee whom there are reasonable
grounds for regarding as a danger to the security of the country in which he is, or who, having been convicted
by a final judgment of a particularly serious crime, constitutes a danger to the community of that country.'

Ground 10

**[309] This ground is pleaded in very general terms. However, Mr Drabble's primary submission, as formulated at**
para 58 of ASM's skeleton argument, is
**[*344]**

that 'there is an implied obligation on a receiving state, inherent in the basic structure of the Convention, to process
a claim for asylum made by a refugee physically present in its territory'. It would follow that it was a breach of the
Convention for a state to remove a person who has made an asylum claim to another country, however safe,
without determining their claim and according them the rights of a refugee under the Convention if the claim is
established.

**[310] The factors relied on in support of that primary submission are identified in the same paragraph of the**
skeleton argument as follows:

'That implied obligation arises as a combination of the declaratory nature of refugee status (which requires
investigation of the individual's circumstances and the nature of his claim) and Convention provisions, including
the prohibition on refoulement (Article 33), the prohibition on penalties for illegal entry or presence (Article 31),
the duty to afford refugees the same treatment as “aliens” (Article 7), the prohibition on discrimination on
grounds of country of origin and the right of access to courts (Article 16). Even Article 9, which permits
provisional measures against an individual where “essential to national security”, does so only “pending a
determination by the Contracting State that that person is in fact a refugee”.'

(It is unnecessary to set out the full terms of arts 7, 9 and 16 as there referred to: their effect is adequately
summarised.)

**[311] In support of the submission that the obligation in question could be implied from the terms of the Convention**
the skeleton argument refers to the following provisions of art 31(1) of the Vienna Convention on the Law of
Treaties 1969 ('General rule of interpretation'), which reads:

'1. A treaty shall be interpreted in good faith in accordance with the ordinary meaning to be given to the terms
of the treaty in their context and in the light of its object and purpose.

2. …

3. There shall be taken into account, together with the context:

(a) …

(b) any subsequent practice in the application of the treaty which establishes the agreement of the parties
regarding its interpretation;

(c) …'

**[312] That submission is contrary to the practice which has prevailed in the European Union since the coming into**
force of the 'Dublin system' in 1997 (initially in the form of the Dublin Convention, but since succeeded by the Dublin
II and III Regulations), which permits member states to decline to entertain asylum applications from claimants who
had previously applied to another member state. It is also contrary to arts 25–27 of European _[Council Directive](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9RF3-GXFD-80J9-00000-00&context=1519360)_


-----

High Commissioner for Refugees intervening) and ot....

_[2005/85/EC 'on minimum standards on procedures in Member States for granting and withdrawing refugee status'](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9RF3-GXFD-80J9-00000-00&context=1519360)_
('the Procedures Directive'), which explicitly recognise the legitimacy of treating an asylum application as
inadmissible, and refusing to consider it, if a country other than a member state 'is considered as a safe third
country for the applicant' (art 25(2)(c)). The 'safe third country concept' is defined in art 27, which reads:

'1. Member States may apply the safe third country concept only where the competent authorities are satisfied
that a person seeking asylum will be treated in accordance with the following principles in the third country
concerned:

**[*345]**

(a) life and liberty are not threatened on account of race, religion, nationality, membership of a particular social
group or political opinion;

(b) the principle of non-refoulement in accordance with the Geneva Convention is respected;

(c) the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman or degrading
treatment as laid down in international law, is respected; and

(d) the possibility exists to request refugee status and, if found to be a refugee, to receive protection in
accordance with the Geneva Convention.

2. The application of the safe third country concept shall be subject to rules laid down in national legislation,
including:

(a) rules requiring a connection between the person seeking asylum and the third country concerned on the
basis of which it would be reasonable for that person to go to that country;

(b) rules on the methodology by which the competent authorities satisfy themselves that the safe third country
concept may be applied to a particular country or to a particular applicant. Such methodology shall include
case-by-case consideration of the safety of the country for a particular applicant and/or national designation of
countries considered to be generally safe;

(c) rules in accordance with international law, allowing an individual examination of whether the third country
concerned is safe for a particular applicant which, as a minimum, shall permit the applicant to challenge the
application of the safe third country concept on the grounds that he/she would be subjected to torture, cruel,
inhuman or degrading treatment or punishment.

3. When implementing a decision solely based on this Article, Member States shall:

(a) inform the applicant accordingly; and

(b) provide him/her with a document informing the authorities of the third country, in the language of that
country, that the application has not been examined in substance.

4. Where the third country does not permit the applicant for asylum to enter its territory, Member States shall
ensure that access to a procedure is given in accordance with the basic principles and guarantees described in
Chapter II.

5. Member States shall inform the Commission periodically of the countries to which this concept is applied in
accordance with the provisions of this Article.'

Both the Dublin system and the Procedures Directive are parts of the 'Common European Asylum System', and the
Dublin system proceeds on the basis that member states are safe third countries.

**[313] In tacit recognition of that difficulty, the skeleton argument advances what appears to be an alternative to the**
primary submission Paragraph 63 reads:


-----

High Commissioner for Refugees intervening) and ot....

'The operation of the Dublin III scheme indicates that a constrained application of the “safe third country”
concept, with clear procedures and a robust protective legal framework, may be consistent with the
Convention.'

**[*346]**

As I understand it, that alternative proceeds on the basis that, although the Convention itself says nothing about
contracting states being entitled to decline to entertain an asylum application where the applicant could go to a safe
third country, such a right, if sufficiently 'constrained', might be capable of being implied in the light of its object and
purpose and by reference to subsequent practice. It refers only to the Dublin system, and it does not explicitly
extend to the safe third country concept as defined in the Procedures Directive, which goes beyond the Dublin
regime in as much as it applies to non-EU states; but the reasoning behind the alternative would seem to apply in
the case of removal to any safe third country.

**[314] Mr Drabble contended that that alternative reading of the Convention does not assist the Secretary of State**
because the MEDP is not sufficiently 'constrained'. Paragraph 73 of ASM's skeleton argument reads:

'The MEDP scheme represents a significant departure from the Dublin III framework and an extension of the
“safe third country” concept beyond that permitted by the Convention. Rwanda is not a country included in
Parts 2–4 of Schedule 3 [to the _[Asylum and Immigration (Treatment of Claimants, etc) Act 2004], and is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y1HF-00000-00&context=1519360)_
therefore not subject to the statutory presumption of safety; there has been no Parliamentary scrutiny of the
Secretary of State's decision to treat Rwanda as a safe country. Rwanda is, obviously, not bound by EU
standards nor the Common European Asylum System …; it is not a signatory of the [European Convention on
Human Rights]; it is not subject to the jurisdiction of the [Court of Justice of the European Union] or the
European Court of Human Rights. The MEDP scheme is underpinned not by statutory provisions, but by the
Rwandan MOU and accompanying Notes Verbales …, paragraphs 345A–C of the Immigration Rules and
relevant policy guidance.'

**[315] Mr Drabble advanced three further arguments under this ground:**

(1)   that the targeting of the MEDP Scheme on asylum-seekers who arrive in the UK by irregular means
'is contrary to the recognition, inherent within the protection framework of the convention and in article 31 in
particular, that refugees may need to undertake journeys by irregular or criminal means in order to reach
safety' – see R v Asfaw _[[2008] UKHL 31, [2008] 3 All ER 775, [2008] 1 AC 1061(ASM skeleton argument](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T66-GVT0-TWP1-606B-00000-00&context=1519360)_
paras 66–67);

(2)   that 'the stated purpose of the MEDP scheme … to deter refugees from undertaking 'irregular and
dangerous' journeys to the UK … is entirely inconsistent with the spirit and purpose of the Convention',
particularly given the absence of available regular and safe means (ASM skeleton argument para 68); and

(3)   that 'the deterrent purpose of the MEDP scheme is inconsistent with the prohibition on 'penalties' for
illegal entry or presence imposed by article 31 of the Refugee Convention' (ASM skeleton argument para
69).

The third of those arguments is the subject of grounds 11 and 12, and I deal with it in that context.

**[316] The starting-point in considering those submissions is that it is in my view settled law that the Refugee**
Convention does not prohibit a receiving state from declining to entertain an asylum claim where it can and will
remove the claimant to another non-persecutory state. That was clearly stated by
**[*347]**

Lord Bridge in _Bugdaycay v Secretary of State for the Home Dept_ _[[1987] 1 All ER 940, [1987] AC 514. That](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60HF-00000-00&context=1519360)_
decision in fact covers four distinct cases. The relevant case for our purposes is Musisi, where the applicant was a
Ugandan national who had arrived in the UK from Kenya and claimed that he was at risk of persecution in Uganda.
The Home Secretary proposed to return him to Kenya. That decision was quashed in the High Court, whose
decision was upheld by the Court of Appeal, on the basis that the Home Secretary had not considered his claim that


-----

High Commissioner for Refugees intervening) and ot....

he would be refouled from Kenya to Uganda. Although the House of Lords upheld the Court of Appeal's decision,
[Lord Bridge began his analysis by saying ([1987] 1 All ER 940 at 952, [1987] AC 514 at 532):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60HF-00000-00&context=1519360)

'… I can well see that if a person arrives in the United Kingdom from country A claiming to be a refugee from
country B, where country A is itself a party to the Convention, there can in the ordinary case be no obligation
on the immigration authorities here to investigate the matter. If the person is refused leave to enter the United
Kingdom, he will be returned to country A, whose responsibility it will be to investigate his claim to refugee
status and, if it is established, to respect it. This is, I take it, in accordance with the “international practice”

[referred to in the evidence]. The practice must rest upon the assumption that all countries which adhere to the
Convention may be trusted to respect their obligations under it. Upon that hypothesis, it is an obviously
sensible practice and nothing I say is intended to question it.'

He goes on to say that where that assumption was shown to be unsafe return to country A would be contrary to the
prohibition on refoulement (in that case indirect refoulement) in art 33; but what matters for our purposes is his
statement of the position where there is no such risk.

**[317] Lord Bridge's statement is consistent with the academic commentary. The discussion of art 31 in Professor**
James Hathaway's The Rights of Refugees under International Law (2nd edn, 2021) is particularly useful because it
considers the travaux préparatoires. He says, at p 519, that 'Art. 31 in no way constrains a state's prerogative to
expel an unauthorized refugee from its territory'. He observes that it might seem ironic that an asylum country which
is generally prohibited from imposing penalties on refugees may nonetheless expel them; but he goes on at pp
519–520 to demonstrate, by reference to the statements made on behalf of the original signatories in the course of
the Conference which led to the Convention, that that was indeed the intention. The position was most clearly
stated by the argument of the Canadian representative that no modification of the text as regards this issue was
required, since 'the consensus of opinion was that the right [to expel refugees who illegally enter a state's territory]
would not be prejudiced by adoption of Article [31]'. He goes on to point out that what he calls the 'potentially
devastating impact' of that decision is mitigated by the duty of non-refoulement in art 33: 'any expulsion of a refugee
must therefore not expose the refugee, directly or indirectly, to a risk of being persecuted'.

**[318] To the same effect, in his analysis and commentary on the Travaux Préparatoires to the Refugee Convention**
Dr Paul Weis says at pp 302–303:

'Article 31 refers to “penalties”. It is clear from the _travaux préparatoires that this refers to administrative or_
judicial convictions on account of illegal entry or presence, not to expulsion …

**[*348]**

Paragraph 1 does not impose an obligation to regularise the situation of the refugee nor does it prevent the
Contracting States from imposing an expulsion order on him. However, a refugee may not be expelled if no
other country is willing to admit him …'

See also Goodwin-Gill and McAdam The Refugee in International Law (4th edn, 2021) at p 278.

**[319] Against that background, I see no room for the kinds of implied obligation contended for by Mr Drabble.**
Specifically, there is no warrant for implying a prohibition on removal except where the third country satisfies the
particular requirements either of the Dublin system or of art 27 of the Procedures Directive (including the
requirement that the application have a connection with that country). The straightforward question, so far as the
Convention is concerned, is whether the third country is safe for the applicant in the sense that there is no real risk
of their being refouled (directly or indirectly). Nor can any limitations be implied on the state's right to take into
account, when deciding whether to remove an asylum-seeker to a safe third country, the fact that they arrived in the
UK irregularly, even in circumstances where there was no regular means to do so, or that their removal may have a
deterrent effect. The state's motivation is irrelevant to the object and purpose of the Convention: if the asylumseeker will not face persecution or refoulement in the country to which they are returned they will have received the
protection which the Convention is intended to afford them. (This conclusion is subject to the ostensibly distinct
'penalty' issue discussed under grounds 11 and 12 )


-----

High Commissioner for Refugees intervening) and ot....

**[320] My conclusion is reinforced by the observations of Lord Bingham at para [18] of his opinion in the** _Roma_
_Rights case. The case involved, in part, the interpretation of the Refugee Convention. Lord Bingham accepted_
counsel's submission that the Convention 'should be given a generous and purposive interpretation, bearing in mind
its humanitarian objects and purpose', but he continued:

'But I would make an important caveat. However generous and purposive its approach to interpretation, the
court's task remains one of interpreting the written document to which the contracting states have committed
themselves. It must interpret what they have agreed. It has no warrant to give effect to what they might, or in an
ideal world would, have agreed. This would violate the rule, … expressed in art 31(1) of the Vienna
Convention, that a treaty should be interpreted in accordance with the ordinary meaning to be given to the
terms of the treaty in their context. It is also noteworthy that art 31(4) of the Vienna Convention requires a
special meaning to be given to a term if it is established that the parties so intended. … It is in principle
possible for a court to imply terms even into an international convention. But this calls for great circumspection
since, as was said in Brown v Stott (Procurator Fiscal, Dunfermline) _[[2001] 2 All ER 97 at 114, [2003] 1 AC 681](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-6129-00000-00&context=1519360)_
at 703:

“… it is generally to be assumed that the parties have included the terms which they wished to include and on
which they were able to agree, omitting other terms which they did not wish to include or on which they were
not able to agree.”

And caution is needed—

**[*349]**

“if the risk is to be averted that the contracting parties may, by judicial interpretation, become bound by
obligations which they did not expressly accept and might not have been willing to accept.” '

**[321] The pleaded challenge is to para [126] of the Divisional Court's judgment. However, that merely expresses its**
overall conclusions on the issue of compatibility with the Refugee Convention. Its essential reasoning as regards
this aspect appears in para [121] of its judgment, where it said:

'Mr Drabble KC submitted that the Refugee Convention imposes an obligation on contracting states to
determine all asylum claims made, on their merits. We disagree. There is no such obligation on the face of the
Convention. The obligation that is imposed is the one at article 33, not to expel or return a refugee to a place
where his life or freedom would be threatened by reason of any of the characteristics that the convention
protects. Mr Drabble's submission was that an obligation to determine asylum claims would be consistent with
the spirit and purpose of the Convention and could therefore reasonably be assumed. Again, we disagree.
Obligations in international treaties are formulated with considerable care. They reflect balances struck
following detailed negotiations between states parties. An obligation to determine every asylum claim on its
merits would be a significant addition to the Refugee Convention. There is no reason to infer the existence of
an obligation of that order; to do so would go well beyond the limits of any notion of judicial construction of an
international agreement; and the protection that is necessary if the purpose of the Convention is to be met, is
provided by article 33.'

I agree.
Grounds 11 & 12

**[322] In both these grounds the contention is that the removal of asylum-seekers to Rwanda under the MEDP**
constitutes a 'penalty' within the meaning of art 31(1). They differ from ground 10 because they depend on the
meaning of the word 'penalty' and thus do not depend on the implication of any term. However the underlying issue
is in fact in my view the same, and I can take them fairly shortly.

**[323] It follows from my reasoning in relation to ground 10 that the removal of an asylum-seeker to a safe third**
country without their claim being determined is not in itself a penalty: indeed the passages from the academic
commentators which I have quoted are all in the context of art 31(1). However, Mr Husain and Mr Drabble


-----

High Commissioner for Refugees intervening) and ot....

submitted that expulsion may become a penalty within the meaning of the article depending on the facts of a
particular case. I summarise their submissions in turn.

**[324] Mr Husain contended (see para 64(ii) of the AAA Claimants' skeleton argument) that 'the reasons why, and**
the conditions to which, a person is being removed are highly relevant and may convert a removal which is lawful
_per se into an impermissible penalty'. As for the 'reasons' element in that formulation, he relied on the fact that the_
asylum-seekers who were liable to relocation to Rwanda under the MEDP were being removed 'for the purposes of
imposing a detriment on them and deterring others from arriving in the same way'. He relies on an observation in a
commentary on the term 'criminal
**[*350]**

offence' in the International Covenant on Civil and Political Rights, adopted by Professor Guy Goodwin-Gill in a
paper on art 31 commissioned by UNHCR, to the effect that 'every sanction that has not only a preventative but
also a retributive and/or deterrent character is … to be termed a penalty'. As for the 'conditions to which [the
Claimants would be] removed', he relied on the fact that they would be being removed to 'significantly inferior
processes and human rights protection'.

**[325] Mr Drabble submitted that the term 'penalty' required a broad and purposive construction in line with the**
humanitarian purpose of the Convention: as we have seen, that was accepted by Lord Bingham in the Roma Rights
case. Adopting that approach, he submitted that expulsion could constitute a penalty if it was detrimental to the
applicant in some specific way such as separation from family members or a supportive community. He also relied
on the deterrent purpose of the MEDP.

**[326] Both counsel relied on the decision of the Supreme Court of Canada in** _B010 v Canada (Citizen and_
_Immigration)_ _[2015 SCC 58,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N0T-C3G1-DYBP-W1MS-00000-00&context=1519360)_ _[(2015) 41 BHRC 653, [2015] 3 SCR 704. The case concerned a Canadian statutory](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N0T-C3G1-DYBP-W1MS-00000-00&context=1519360)_
provision – s 37(1) of the Immigration and Refugee Protection Act 2001 – which rendered a person 'inadmissible',
which effectively denied them access to refugee determination procedures, if they had engaged in 'in the context of
transnational crime, activities such as people smuggling'. The issue was whether on its true construction that
provision applied to illegal migrants who had assisted other illegal migrants but had not done so in return for any
financial or other benefit. The Court held that it did not. As part of her reasoning in support of that construction
McLachlin CJ, delivering the judgment of the Court, held that 'omitting a financial or other benefit limitation' would
be inconsistent with art 31(1) of the Convention: see para [62] of her judgment. At para [57] she sets out art 31(1)
and adopts a statement in a textbook that—

'an individual cannot be denied refugee status—or, most important, the opportunity to make a claim for such
status through fair assessment procedures—solely because of the way in which that person sought or secured
entry into the country of destination'

and that—

'[o]bstructed or delayed access to the refugee process is a “penalty” within the meaning of art 31(1) …'

At para [63] she says:

'The respondents contend that art 31(1) of the Refugee Convention refers only to criminal penalties. This
interpretation runs counter to the purpose of art 31(1) and the weight of academic commentary: JC Hathaway,
_The Rights of Refugees Under International Law (2005), at pp 409–412; Gallagher and David, at pp 164–168;_
GS Goodwin-Gill and J McAdam, The Refugee in International Law (3rd edn, 2007), at p 266. The generally
_accepted view is that denying a person access to the refugee claim process on account of his illegal entry, or_
for aiding others to enter illegally in their collective flight to safety, is a “penalty” within the meaning of art 31(1).
The law recognizes the reality that refugees often flee in groups and work together to enter a country illegally.
Article 31(1) thus does not permit a

**[*351]**


-----

High Commissioner for Refugees intervening) and ot....

state to deny refugee protection (or refugee determination procedures) to refugees solely because they have
aided others to enter illegally in an unremunerated, collective flight to safety. Rather, it targets those who assist
in obtaining illegal entry for financial or other material benefit.'

**[327] Mr Husain relied on the words that I have italicised and submitted that they were directly applicable to the**
present case. He acknowledged that the Court in B010 was not concerned with a situation where the migrant would
be being removed to a safe third country, but he submitted that that was immaterial. I do not agree. In my view it is
a crucial distinction. The views endorsed by McLachlin CJ in paras [57] and [63] of her judgment are concerned with
denial of, or obstructions or delay to, access to the refugee determination process for a migrant who is in the
country. They are not concerned with expulsion, as to which, as I have sought to show in connection with ground
10, the Convention imposes no restrictions save for the duty of non-refoulement imposed by art 33.

**[328] The same point applies to Professor Goodwin-Gill's wide definition of 'penalty' (see para [324] above). I have**
no difficulty with the proposition that the term is not confined to sanctions of a criminal character; but the issue here
is whether it extends to expulsion.

**[329] In short, it is in my view inconsistent with the well-recognised scheme of the Convention that the expulsion of**
a migrant to a safe third country should be treated as a penalty within the meaning of art 31(1), whatever the
reasons for taking that course may be and however unwelcome it may be to the migrant in question.

**[330] The Divisional Court addressed the effect of art 31(1) at paras [123]–[125] of its judgment. At para [125] it**
says:

'There is, therefore, a clear consensus. Article 31 does not prevent a state expelling a refugee. States must not
act in breach of article 33; removal that is not contrary to article 33 is not a penalty for the purposes of article
31. On this basis, neither decisions on inadmissibility under paragraph 345A of the Immigration Rules, nor
decisions under paragraph 345C on removal to Rwanda are contrary to the Refugee Convention. The latter
because one premise of a paragraph 345C decision is that the country concerned is a safe third country, as
defined at paragraph 345B of the Immigration Rules. The deterrent purpose that the Home Secretary pursues
in relation to removals to Rwanda does not, of itself, render removal to Rwanda contrary to article 31, let alone
article 33 of the Refugee Convention. Further, the simple fact of removal to Rwanda is not sufficient to make
good the Claimants' submission that removal is a penalty contrary to article 31. That submission would
succeed only when removal amounts to a breach of article 33. Looked at on this basis, the Claimants' article 31
submission merges with their submission on whether Rwanda is a safe third country. If it is a safe third country,
decisions taken in exercise of the powers in paragraphs 345A–345D of the Immigration Rules are not in breach
of article 31; if, however, Rwanda is not a safe third country, removal would be both contrary to paragraph
345C of the Immigration Rules and to both article 31 and article 33 of the Refugee Convention.'

Again, I agree.
**[*352] Ground 9**

**[331] As pleaded this ground is decidedly opaque. However, as developed at paras 53–58 of the AAA Claimants'**
skeleton argument it appears to comprise four points.

**[332] First, it is contended that the Divisional Court's error in approaching the question of whether Rwanda was a**
safe third country on a review basis rather than reaching its own conclusion infected its reasoning also on the
Refugee Convention issues. I do not agree. Its dispositive reasoning, which I have set out at paras [321] and [330]
above, does not depend on its assessment of the safety of Rwanda. Even if it did the point would go nowhere since
I believe that its conclusion on the Refugee Convention issues which it considered was correct in any event.

**[333] The second and third points appear to go together. The Claimants had argued in the Divisional Court that**
Rwandan law was incompatible with two articles of the Refugee Convention, as follows:

(1)   Article 1C(1) of the Convention provides for refugee status to lapse where a refugee 'has voluntarily
re availed himself of the protection of the country of his nationality' We were not referred to the terms of


-----

High Commissioner for Refugees intervening) and ot....

the relevant Rwandan legislation, nor was there any expert evidence of Rwandan law, but in their skeleton
argument in the Divisional Court (see para [390]) the AAA Claimants relied on para 10.5.1 of the Asylum
System CPIN. This states that '[a] refugee who returns to their country of origin loses his/her refugee status
and will be required to submit a new asylum claim to the authorities if he/she returns to Rwanda': there is a
footnote reference to a Ministerial Instruction dated 1 June 2016 (no 02/2016). That is said to mean that a
refugee will lose protection if they return to their country of nationality, however temporarily or for whatever
reason, eg to see a dying relative.

(2)   Article 1F(b) disapplies the Convention in the case of persons who have 'committed a serious nonpolitical crime outside the country of refuge prior to [their] admission to that country as a refugee'. The AAA
Claimants' skeleton argument in the Divisional Court states at para [394] that 'an asylum-seeker who has
been prosecuted for any non-political felony will automatically be excluded from refugee status': no
reference is given to the statutory provision relied on, but it seems from the rest of the paragraph that the
exclusion only applies to an asylum-seeker who has been successfully prosecuted.

**[334] The Claimants complain that the Divisional Court failed to address those points. I accept that it did not**
expressly consider them, though the omission is venial in view of the plethora of arguments with which it was faced.
But I do not believe that the points are good in any event. The material relied on falls well short of establishing that
Rwandan law fails to give effect to either art 1C or art 1F. As we have seen, the MoU contains an express provision
that RIs will be treated in accordance with the Refugee Convention (see para 9.1.1). We do not have the text of
either of the domestic instruments relied on, still less any expert evidence. Even if they are accurately reproduced,
we do not know whether under Rwandan law the requirements of the Convention would trump any contrary
provision of the domestic legislation (or in any event any ministerial instruction). But even if that is not the case, it
would be surprising if a Court seeking to construe domestic law in
**[*353]**

accordance with Rwanda's obligations under the Convention were unable to do so. It is for the Claimants to
establish that the Rwanda policy contravenes s 2, and I do not believe that (in this respect) they have done so.

**[335] The fourth point is based on art 15 of the Convention ('Right of association'), which obliges contracting states,**
as regards 'non-political and non-profit-making associations and trade unions', to 'accord to refugees lawfully
staying in their territory the most favourable treatment accorded to nationals of a foreign country, in the same
circumstances'. (Article 7(1) contains a more general non-discrimination provision, but that adds nothing to the
argument.) At paras 386–389 of their skeleton argument in the Divisional Court the AAA Claimants had relied on
various materials in support of a submission that art 15 would not be complied with as regards RIs. Some of the
materials simply showed that there were serious restrictions on freedom of speech and freedom of assembly in
Rwanda, and at para [77] of its judgment the Divisional Court held that that did not demonstrate any discrimination
against refugees as opposed to other foreign nationals, which is the subject of art 15. However, the Claimants
complain that that rebuttal fails to address one of the materials relied on, which was para 3.8.3 of the Human Rights
CPIN, which reads:

'In 2016, the Rwandan Government's Ministry in Charge of Emergency Management (MINEMA), published
Ministerial instructions determining the management of refugees and refugee camps. Article 2 refer to
“Prohibited acts and behaviors for refugees” and states that “Political activities” and “Gatherings based on
ethnicity, nationality, or any other sectarian ground” and participating in, or inciting others into unlawful riots are
prohibited.'

(The Ministerial Instruction seems to be the same as that referred to at para [333](1) above.) That Instruction does
appear to impose specific restrictions on refugees. The Claimants complain that the Divisional Court failed to deal
with it and submit that it shows that the art 15 rights of RIs would not be respected. In her submissions resisting the
grant of permission to appeal the Secretary of State drew attention to art 12 of the Ministerial Instruction, which
provides for refugees to enjoy (in effect) the full rights accorded by the Convention, including 'membership to
association of forums with non-political orientation'; but the Claimants contend that that is in very general terms, and
art 2 is plainly a derogation from it


-----

High Commissioner for Refugees intervening) and ot....

**[336] I would reject the Claimants' submission. I do not believe that the terms of art 2 of the Ministerial Instruction**
establish that the art 15 rights of RIs would not be recognised. Despite the distinction between 'political activities'
and 'gatherings based on ethnicity, nationality, or any other sectarian ground', I am not satisfied that the latter class
of activities would qualify as 'non-political' under art 15: on a purposive construction it seems very unlikely that a
purely social, or other non-political, meeting of, say, Kurdish or Albanian refugees would be held to be caught by art
2 because it was a 'gathering based on ethnicity [or] nationality'. It is also far from clear that the same restrictions
would not apply to other non-nationals. In the absence of any authoritative expert evidence on these points I do not
consider that the Claimants' submission is made out.

**[337] I should add that other arguments were relied on by the Secretary of State, and the Divisional Court, in**
response to the Claimants' points on Rwandan law; but the foregoing is sufficient for me to reject them.
**[*354] Conclusion**

**[338] For the reasons given, I would reject grounds of appeal 9–12.**

**[339] It may in fact be arguable that the effect of my earlier conclusion that RIs would be at risk of refoulement from**
Rwanda because of the inadequacy of its asylum system is that relocation there would constitute a practice which
contravened art 33 and would thus be unlawful under s 2 on a different basis; but the case was not put that way and
I need not consider it here.
_Issue 13: Retained EU lawIntroduction_

**[340] This issue concerns whether para 345C of the Immigration Rules is compatible with retained EU law.**
Paragraphs 345A–345D of the Rules were introduced by Statement of Changes HC 1043, dated 10 December
[2020, to take effect at 23.00 on 31 December 2020, ie at the moment of 'IP Completion' as defined in the European](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5Y26-JS33-CGXG-0486-00000-00&context=1519360)
_[Union (Withdrawal Agreement) Act 2020. For convenience I will set out para 345C again here:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5Y26-JS33-CGXG-0486-00000-00&context=1519360)_

'When an application is treated as inadmissible, the Secretary of State will attempt to remove the applicant to
the safe third country in which they were previously present or to which they have a connection, or to any other
_safe third country which may agree to their entry.' (My italics.)_

The point to note for our purposes is that the italicised words explicitly contemplate the removal of an asylumseeker to a safe third country with which they have no connection[8].

**[341] The retained EU law which para 345C is said to contravene is the Procedures Directive, to which I have**
already referred in connection with Issue 12. The Directive came into force in the UK, by virtue of s 2 of the
European Communities Act 1972, on 2 January 2006. (I should also mention, because it is part of the wider picture,
that a separate Directive relating to aspects of substantive asylum law – the 'Qualification Directive' (2004/83/EC) –
came into force shortly afterwards.)

**[342] The Procedures Directive imposes a number of requirements on member states as regards the procedure for**
determining applications for asylum, including (by art 6(2)) a requirement that all adults with legal capacity should
have the right to make an application for asylum and (by art 8) that any such application should be appropriately
examined. So far as relevant for our purposes, art 25 allows member states to treat an asylum application as
'inadmissible', and accordingly not to examine it, in a number of particular situations identified in para 2. These
include, at (c), where 'a country which is not a Member State is considered as a safe third country for the applicant,
pursuant to Article 27'. I have already set out art 27 in full at para [312] above. For present purposes I need only
note that para 2(a) requires member states to implement 'rules requiring a connection between the person seeking
asylum and the third country concerned on the basis of which it would be reasonable for that person to go to that
country': I will refer to that as 'the connection requirement'.


-----

High Commissioner for Refugees intervening) and ot....

10

**[343] It is the Claimants' case that the Procedures Directive remains part of UK law by reason of** _[s 4 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SNC-4N71-DYCN-C2DC-00000-00&context=1519360)_
European Union (Withdrawal) Act 2018, which preserves the force, as 'retained EU law', of EU legislation given
effect by the 1972 Act. On that basis, they submit, para 345C of the Immigration Rules is unlawful, because,
contrary to art 27(2)(a), it permits removal to a country with which the applicant has no connection.

**[344] The Secretary of State does not challenge the proposition that para 345C is inconsistent with the**
requirements of art 27(2)(a) of the Directive. However it is her case that those requirements no longer form part of
UK law. She relies on the effect of the _[Immigration and Social Security Co-ordination (EU Withdrawal) Act 2020](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:619H-Y6C3-CGXG-019X-00000-00&context=1519360)_
('ISSCA'), which received the Royal Assent on 11 November 2020. I need to set out the structure of the Act and the
relevant provisions in some detail.
ISSCA: the Act and the Parties' Submissions

**[345] The long title of ISSCA is as follows:**

'An Act to make provision to end rights to free movement of persons under retained EU law and to repeal other
retained EU law relating to immigration; to confer power to modify retained direct EU legislation relating to
social security co-ordination; and for connected purposes.'

As foreshadowed by the long title, the Act has two substantive Parts. Part 1 is headed 'Measures relating to ending
free movement', and Pt 2 'Social security co-ordination'. We are concerned with Pt 1, which came into force on 31
December 2020, ie coinciding with IP Completion Day.

**[346] Part 1 of ISSCA comprises ss 1–5. The principal substantive section is s 1, which gives effect to Sch 1 to the**
Act. It reads:

**'Repeal of the main retained EU law relating to free movement etc**

Schedule 1 makes provision to—

(a) end rights to free movement of persons under retained EU law, including by repealing the main provisions
of retained EU law relating to free movement, and

(b) end other EU-derived rights, and repeal other retained EU law, relating to immigration.'

The other substantive sections are ss 2–3. Both address particular issues related to the ending of free movement.
In summary:

–   Section 2 preserves the rights of Irish citizens under the long-standing common travel area
arrangements.

–   Section 3 requires the Secretary of State to formulate a policy covering 'legal routes from the EU and
family reunion' for protection claimants, or potential protection claimants, who wish to enter the UK from a
member state.

Sections 4 and 5 are ancillary.

**[347] Schedule 1, which as we have seen is given effect by s 1, is headed 'Repeal of the main retained EU law**
relating to free movement etc'. It comprises three Parts. Part 1 is headed 'EU-derived domestic legislation' and

8 One of the conditions for inadmissibility in para 345A – condition (iii)(c) – does in fact incorporate a connection requirement,
but that does not read over into the operation of para 345C in a case where inadmissibility has been established on another
basis.

**[*355]**


-----

High Commissioner for Refugees intervening) and ot....

revokes certain specified provisions of primary legislation and statutory instruments. Part 2 is headed 'Retained
Direct EU Legislation' and repeals the
**[*356]**

Workers Regulation (European Parliament and _[Council Regulation 492/2011/EU), which is the EU provision](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JK-C8H3-GXFD-81B0-00000-00&context=1519360)_
conferring the right of freedom of movement for workers within the EU.

**[348] We are concerned with Pt 3 of the Schedule, which is headed 'EU-derived rights etc': it is thus concerned with**
rights other than those conferred directly by domestic or EU legislation, which are the subjects of Pts 1 and 2. It
comprises paras 5 and 6. Paragraph 5 is concerned with rights derived from a free movement agreement made
between the European Union and the Swiss Confederation. Paragraph 6 reads (so far as relevant):

'(1) Any other EU-derived rights, powers, liabilities, obligations, restrictions, remedies and procedures cease to
be recognised and available in domestic law so far as—

(a) they are inconsistent with, or are otherwise capable of affecting the interpretation, application or operation
of, any provision made by or under the Immigration Acts (including, and as amended by, this Act), or

(b) they are otherwise capable of affecting the exercise of functions in connection with immigration.

(2) The reference in sub-paragraph (1) to any other EU-derived rights, powers, liabilities, obligations,
restrictions, remedies and procedures is a reference to any rights, powers, liabilities, obligations, restrictions,
remedies and procedures which—

(a) continue to be recognised and available in domestic law by virtue of _[section 4 of the European Union](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SNC-4N71-DYCN-C2DC-00000-00&context=1519360)_
(Withdrawal) Act 2018 (including as they are modified by domestic law from time to time), and

(b) are not those described in paragraph 5 of this Schedule.

(3) …'

('EU-derived' is not a defined term, but it is obvious, and not disputed, that as a matter of language it would apply to
the obligations imposed on the UK Government by the Procedures Directive.)

**[349] The effect of para 6(1) of Sch 1 to ISSCA (to which I will refer simply as 'para 6(1)') is thus to disapply EU-**
derived rights to the extent that they are inconsistent with any provision made by or under 'the Immigration Acts'.
[That term is defined by s 61(2) of the UK Borders Act 2007, which provides that '[a] reference (in any enactment,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y1H6-00000-00&context=1519360)
including one passed or made before this Act) to “the Immigration Acts” ' is to a specified list of statutes. For our
[purposes what matters is that those statutes include the Immigration Act 1971, but for reasons which will appear I](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
should give the rest of the list:

['(a) the Immigration Act 1971,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

[(b) the Immigration Act 1988,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61G0-TWPY-Y03P-00000-00&context=1519360)

[(c) the Asylum and Immigration Appeals Act 1993,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YG0-TWPY-Y0BK-00000-00&context=1519360)

[(d) the Asylum and Immigration Act 1996,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y1FP-00000-00&context=1519360)

[(e) the Immigration and Asylum Act 1999,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)

[(f) the Nationality, Immigration and Asylum Act 2002,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)

[(g) the Asylum and Immigration (Treatment of Claimants, etc) Act 2004,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y1HF-00000-00&context=1519360)


-----

High Commissioner for Refugees intervening) and ot....

[(h) the Immigration, Asylum and Nationality Act 2006,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y01F-00000-00&context=1519360)

(i) this Act,

[(j) the Immigration Act 2014,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)

[(k) the Immigration Act 2016,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)

**[*357]**

(l) Part 1 of the Immigration and Social Security Co-ordination (EU Withdrawal) Act 2020 (and Part 3 so far as
relating to that Part), and

[(m) the Nationality and Borders Act 2022.'](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)

(Item (l) was added by s 4(1) of ISSCA.)

**[350]** _[Section 3(2) of the Immigration Act 1971 provides, so far as relevant, that:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y09P-00000-00&context=1519360)_

'The Secretary of State shall from time to time … lay before Parliament statements of the rules, or of any
changes in the rules, laid down by him as to the practice to be followed in the administration of this Act for
regulating the entry into and stay in the United Kingdom of persons required by this Act to have leave to enter
…'

The Immigration Rules are made pursuant to that provision, and although their precise legal status is notoriously
anomalous, it is not in issue before us that for the purposes of para 6(1) they are to be regarded as made 'under'
the 1971 Act. Part 11 of the Rules regulates applications for asylum: paras 345A–345D fall under that Part.

**[351] It is the Secretary of State's case that art 27(2)(a) of the Directive is 'inconsistent with, or … otherwise**
capable of affecting the … operation of' paras 345A–345D of the Immigration Rules because it imposes a
connection requirement which they do not; and that accordingly, by virtue of para 6(1), it ceases to that extent to be
recognised and available in domestic law. It follows that those paragraphs cannot be impugned on the basis that
they fail to give effect to the connection requirement.

**[352] The Claimants' answer to the Secretary of State's case was advanced by Mr Drabble. He submitted that if**
para 6(1) is read in the context of the Act as a whole it is clear that the reference to provisions of 'the Immigration
Acts' is intended to be only to those provisions which are concerned with immigration as opposed to asylum, which I
will call 'immigration in the narrower sense': immigration and asylum are distinct legal subject-matters, with very
different origins and characters. He pointed out that the primary purpose of the Act as defined in the long title
(ignoring its social security co-ordination aspect) is to end free movement, and that that is all that the heading to Pt
1 refers to: free movement is wholly concerned with immigration and has nothing to do with asylum. He accepted
that the long title and s 1 refer not only to ending rights to free movement but also to repealing 'other retained EU
law relating to immigration'; and that that additional element is reflected in the phrase 'free movement _etc' in the_
headings to s 1 and Sch 1. But he submitted that the phrase 'relating to immigration' takes its colour from the
primary purpose and can only be read as referring to immigration in the narrower sense; and that the same goes for
the 'etc'. That being so, the reference to provisions of 'the Immigration Acts' must be similarly limited so as to apply
only to provisions relating to immigration as opposed to asylum.

**[353] Mr Drabble sought to reinforce that submission by referring to the Immigration, Nationality and Asylum (EU**
[Exit) Regulations 2019, SI 2019/745, which were made under powers conferred by s 8 of the 2018 Act to correct](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8V5W-TDH2-8T41-D0FP-00000-00&context=1519360)
'deficiencies in retained EU law' and which revoked a number of community instruments. He relied in particular on
the fact that Sch 1, which contains the relevant revocations, is divided into two Parts – Pt 1 being headed
'Revocations related to immigration and nationality' and Pt 2 'Revocations related to
**[*358]**


-----

High Commissioner for Refugees intervening) and ot....

asylum' (the latter including the Dublin Convention and the Dublin III Regulation). He submitted that that dichotomy
illustrated how 'immigration' and 'asylum' were treated as distinct subject areas in the context of Brexit-related
legislation, itself reflecting the fact that they are regarded as distinct concepts in EU law which are subject to entirely
separate legal frameworks.

**[354] To the same effect, but more generally, Mr Drabble referred to the list of statutes in s 62(1) of the 2007 Act**
and pointed out that the long titles, of which he handed in a schedule, are drafted on the basis that 'immigration' and
'asylum' are distinct: that is, if the statute contains provisions relating to asylum as well as immigration the long title
always refers to both. For example, the long title of the _[Immigration Act 2016 begins 'An Act to make provision](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
about the law on immigration and asylum'.

**[355] Mr Drabble also referred to the Explanatory Notes to ISSCA. It is well established that Explanatory Notes are**
admissible aids to construction insofar as they 'cast light on the objective setting or contextual scene of the statute,
and the mischief at which it is aimed': see _R (on the application of Westminster City Council) v National Asylum_
_Support Service_ _[[2002] UKHL 38, [2002] 4 All ER 654, [2002] 1 WLR 2956, per Lord Steyn at para [5]. Paragraph 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-60GY-00000-00&context=1519360)_
of the Notes give a very full 'Overview of the Act'. It focuses wholly (leaving aside the social security co-ordination
aspect) on the need to end free movement between the EU and the UK and makes no mention of asylum.
Paragraphs 70–71 of the Commentary on the particular provisions of the Act read as follows:

'70. Paragraph 6 ensures any directly effective rights that will have been saved by the EUWA 2018 and would,
in the absence of this paragraph, be retained, cease to apply insofar as they are inconsistent with, or are
otherwise capable of affecting the interpretation, application or operation of, specified domestic immigration
legislation or functions. For example, the residence rights that are derived from Articles 20 and 21 of the TFEU
(rights of citizenship and free movement) will be retained EU law and, unless they are disapplied would provide
a right to reside in the UK for certain groups, for example “Chen” carers who are primary carers of an EU
citizen child who is in the UK and is self-sufficient. However, the rights derived from Articles 20 and 21 would
continue to apply in non-immigration contexts unless disapplied.

71. The following is a non-exhaustive list of the directly effective rights relevant to this Paragraph. …'

The list is in the form of a table which identifies seven treaties (broadly, the various EU and EEA/Switzerland
treaties and the Association Agreements with Turkey) and some thirty particular provisions of those treaties. The
subject area of each provision is identified. Several of the subject areas are identified in terms as 'free movement',
either of workers or of services, but the remainder are also concerned with aspects of the free movement rights
(such as discrimination on grounds of nationality or rights of family members of those exercising such rights). The
Procedures Directive does not appear on the list and none of the subject matters has anything to do with asylum.

**[356] Mr Drabble submitted that the passages from the Explanatory Notes quoted above confirm, what was in any**
event clear from the language of the Act itself, that Pt 1 of ISSCA is concerned only with 'immigration' in the
narrower sense and was not intended to have any effect on asylum law. He
**[*359]**

made what was substantially the same point by reference to various other Parliamentary materials relating to what
became ISSCA, none of which refer to any impact on asylum law. I need not refer to them in detail, but they are the
report of the House of Lords Delegated Powers and Regulatory Reform Committee (HL Paper 118, 25.8.20); the
Delegated Powers Memorandum dated 24 July 2020, supplied to the Committee by the Home Office; the
Government response to the Committee's report (HL Paper 141, 14.10.20 – see Annex 1); and the report of the
House of Lords Select Committee on the Constitution (HL Paper 120, 2.9.20).

**[357] Finally, Mr Drabble referred us to two recent decisions of the Supreme Court, Robinson (Jamaica) v Secretary**
_of State for the Home Dept_ _[[2020] UKSC 53, [2021] 2 All ER 429, [2022] AC 659, and G v G (Secretary of State for](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62H6-VPS3-GXFD-8450-00000-00&context=1519360)_
_[the Home Dept intervening) [2021] UKSC 9, [2021] 4 All ER 113, [2022] AC 544. In fact it is the latter which is the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63P2-CP93-GXF6-82WP-00000-00&context=1519360)_
more directly relevant for our purposes, and I take it first. A father resident in South Africa had brought proceedings


-----

High Commissioner for Refugees intervening) and ot....

under the Hague Convention for the return of his child who had been brought by the mother to England. The mother
had claimed asylum for herself and her child. The High Court had imposed a stay on the Convention proceedings
pending the determination of the asylum claim. The issue in the Supreme Court was whether it had been right to do
so. The Home Secretary was an intervener in the appeal. The Court handed down its decision on 19 March 2021.
The only judgment was given by Lord Stephens. For the purpose of his review of 'the legal landscape governing
asylum applications' he said, at paras [83]–[84]:

'[83] In so far as applicable to the United Kingdom the principal EU measures are (i) the Qualification Directive
and (ii) the Procedures Directive (together, “the Directives”).

[84] The Secretary of State accepts, for the purposes of this appeal, and I agree, that the relevant provisions of
the Directives are directly effective and remain extant in domestic law as “retained EU law” after the United
Kingdom's withdrawal from the EU.'

He went on to summarise a number of the provisions of both Directives. Mr Drabble did not contend that Lord
Stephens' statement that the Directives remained law following the UK's withdrawal from the EU was binding on us:
it was debatable whether it formed part of the ratio but even if it did the point had not been the subject of any
argument. He submitted that it was nevertheless weighty support for his proposition that not only the Court but the
Secretary of State understood the position in the same way. He pointed out that although the Court was not
addressed about the effect of ISSCA Lord Stephens was certainly aware of it, since in Robinson, which concerned
_Zambrano rights and in which he had delivered a judgment in December 2020, he had referred to the possibility that_
the law as declared in that case might change following IP Completion Day as a result of ISSCA, which he
described as providing for 'repeal of the main retained EU law relating to free movement' (see paras [29]–[30]).
Discussion and Conclusion

**[358] The starting-point must be that on a straightforward reading of the statutory language paras 345A–345D of**
the Immigration Rules are 'provisions made … under the Immigration Acts', with the consequence that para 6(1)
has effect to disapply any inconsistent provision of retained EU law.
**[*360]**

**[359] I accept, however, that it is necessary to construe the statute purposively, which means having regard not**
simply to the literal meaning of the words in question but to the legislative purpose, to be gleaned from the entirety
of the provisions of the Act (in practice Pt 1) and any admissible contextual materials. Both Mr Drabble and Lord
Pannick referred us to paras [29]–[31] of the judgment of Lord Hodge in _R (on the application of Project for the_
_Registration of Children as British Citizens) v Secretary of State for the Home Dept_ _[[2022] UKSC 3, [2022] 4 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66FN-DF43-GXF6-800M-00000-00&context=1519360)_
_[95, [2023] AC 255(the so-called 'BritCits' case). I need not set the passage out in extenso, but the essential point is](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66FN-DF43-GXF6-800M-00000-00&context=1519360)_
that the primary source for ascertaining the intention of Parliament must be the words used read in the context of
the statute as a whole (para [29]). External aids to interpretation, such as Explanatory Notes, can only play a
secondary role (para [30]).

**[360] Accordingly I start with what can be learnt about the purpose of Pt 1 from the statute itself. It is clear from the**
long title, as well the language and structure of its provisions, that the main purpose is to end the right to free
movement and to repeal legislation related to it; and I accept that that is a purpose that has nothing to do with
asylum. However that is not the only purpose. Section 1(1)(b) says in terms that Sch 1 makes provision to 'end
_other EU-derived rights, and repeal_ _other retained EU law, relating to immigration'; 'other' must mean other than_
related to free movement.

**[361] The question then is whether the phrase 'relating to immigration' defines that secondary purpose in a way**
which excludes EU-derived rights relating to asylum. I do not believe that this is clear. Mr Drabble is right that in
some legislative contexts 'immigration' and 'asylum' are treated as distinct subject-matters. But I am not persuaded
that there is any settled practice. There are instances in the legislative context of the term 'immigration' being used
[to cover both immigration, in the narrower sense, and asylum. One example is the Immigration Act 2016: although](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
Mr Drabble relies on the fact that the long title refers to both asylum and immigration, it is also significant that the
short title does not Equally the 'Immigration Rules' include the entirety of the UK's rules governing the


-----

High Commissioner for Refugees intervening) and ot....

[determination of asylum claims (see Pt 11) and are of course made under the Immigration Act 1971. (It may also be](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
pertinent to note, though strictly it is outside the legislative context, that the leading textbook, _Macdonald's_
_Immigration Law & Practice, treats asylum law as an integral part of its subject.) That broader use is not loose or_
illogical: the effect of a grant of asylum is to confer on the beneficiary the right to remain in the UK notwithstanding
that they do not have British nationality, or other right of abode, and the relevant law can perfectly naturally be
regarded as an aspect of immigration law.

**[362] If the use of the term 'immigration' itself does not clearly connote an 'asylum-exclusive purpose', I see nothing**
else in the statute that does so. The fact that the primary purpose of Pt 1 is to end free movement is in my view
neutral: it does not follow that the 'other' EU-derived rights relating to immigration law need be in some sense akin
to freedom of movement rights or otherwise relate to immigration in the narrower sense. The only overall purpose of
Pt 1 that can be discerned from the Act itself is to remove or qualify EU-derived rights which are inconsistent with
domestic immigration legislation, including the Immigration Rules: there is no _a priori reason why the rights in_
question should not relate to asylum.
**[*361]**

**[363] The upshot of that discussion is that there is nothing in the other provisions of the Act to suggest a legislative**
purpose that would justify departing from the literal language of para 6(1).

**[364] I turn to the extraneous materials relied on by Mr Drabble. I accept that the Parliamentary materials referred**
to strongly suggest that the Government, as the promoter of what became ISSCA, did not at the time that the bill
was going through Parliament have any specific intention that the EU-derived rights affected by para 6(1) would
include rights of asylum-seekers: if it did, it is hard to think that the responsible Home Office officials would not have
referred to it in the Explanatory Notes and in the Government's response to the relevant committee reports in the
House of Lords. That is consistent with the Secretary of State's stance in G v G (though it should be noted that her
concession referred only to 'the relevant provisions' of the Directives).

**[365] That has given me some pause. But it does not follow from the fact that the promoters of a statute have not**
foreseen all the particular consequences of its provisions that such consequences must be treated as falling outside
its purpose so as to justify departing from their otherwise clear meaning. What matters in this case is not whether
the Government specifically intended that 'asylum rights' should fall within the scope of para 6(1) but whether it is
clear that it specifically intended that they should fall outside its scope.

**[366] I do not believe that that is established. That is not simply because of the secondary role that extraneous**
materials of this kind play in the construction exercise. It is also because it is not clear that there was any reason at
the time that the bill was going through Parliament for the Government to have considered the question of its impact
on asylum rights one way or the other. When the Qualification and Procedure Directives first came into force Pt 11
of the Immigration Rules was re-drafted so as to give effect to their provisions. There was accordingly no general
reason to suppose that there was any inconsistency on which para 6(1) would operate: the Directives would simply
remain in effect as retained EU law following IP Completion Day, as the Secretary of State accepted in G v G. It is
true that in the particular case of para 345C such an inconsistency has emerged, but paras 345A–345D were only
added to the Rules on 10 December 2020, after ISSCA had received Royal Assent. We do not know for how long it
had been intended to introduce a rule which allowed removal to a safe third country with which the applicant had no
connection; or whether it had been appreciated that such a rule would be inconsistent with art 27(2)(a); or, if so,
whether it was intended that para 6(1) would or might provide the answer. But what matters for present purposes is
that it is not clear that at any relevant time the Government anticipated an inconsistency between the Immigration
Rules and retained EU law. That being so, it is not possible to draw any inference about the intended scope of para
6(1) from what was or was not said in the Explanatory Notes or other Parliamentary materials. It is necessary
simply to apply the statutory language, which, as I have said, on its natural meaning applies to any provision made
under the Immigration Rules.


-----

High Commissioner for Refugees intervening) and ot....

**[367] I would accordingly uphold the Divisional Court's conclusion on this issue. I have not found it necessary to**
refer to its reasoning, which is at paras [106]–[118] of its judgment; but I do not detect any substantial difference
between it and my own.
**[*362] Issue 14: Circumvention of Schedule 3 to the 2004 Act**

**[368]** _[Section 33(1) of the Asylum and Immigration (Treatment of Claimants, etc) Act 2004 reads:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y0W2-00000-00&context=1519360)_

'Schedule 3 (which concerns the removal of persons claiming asylum to countries known to protect refugees
and to respect human rights) shall have effect.'

**[369] Schedule 3, which is headed 'Removal of Asylum Seeker to Safe Country', is in five Parts, but Pt 1 is**
introductory and we are concerned with the relationship between Pts 2–4 on the one hand and Pt 5 on the other.

**[370] Parts 2–4 provide for, respectively, three 'Lists of Safe Countries'. Part 2 sets out a list of countries which are**
regarded as safe for the purpose of both the Refugee Convention and the ECHR: they are all EU or EEA states.
Parts 3 and 4 make provision for the Secretary of State to list, by order in the form of a statutory instrument, other
states which are to be regarded as safe for the purposes of, in the case of Pt 3, both the Refugee Convention and
the ECHR and, in the case of Pt 4, the Refugee Convention only. The statutory instrument requires the approval of
both Houses of Parliament. The consequences of such listing vary between the different Parts. In short:

–   For states listed in Pt 2 there is, for the purpose of any decision to remove a person to a country of
which they are not a national or of any legal challenge to such decision, (a) an irrebuttable presumption
that any person removed to such a state would not be at risk of ill-treatment contrary to the Refugee
Convention or of removal to any other state other than in accordance with the requirements of the Refugee
Convention ('the Refugee Convention presumption') and (b) a rebuttable presumption that no person
removed to such a state will either be subject to ill-treatment contrary to art 3 or be removed from it in
breach of their ECHR rights ('the human rights presumption'): both presumptions appear in para 3.
Paragraph 5 provides, consistently with those presumptions, that where the Secretary of State certifies that
it is proposed to remove a person to a state of which they are not a citizen, there shall be (a) an absolute
bar on a person whom it is proposed to remove to a Pt 2 state bringing an immigration appeal based their
Refugee Convention rights and (b) a bar on their bringing such an appeal based on a human rights claim if
the Secretary of State certifies that the claim is clearly unfounded – the Secretary of State being obliged so
to certify unless satisfied that it is not clearly unfounded.

–   For Pt 3 states, the (irrebuttable) Refugee Convention presumption applies (para 8), and the
corresponding bar on bringing an immigration appeal on Refugee Convention grounds (para 10(3)). There
is no human rights presumption but there is a bar on bringing an immigration appeal based on human
rights claims in the same terms as under Pt 2 (para 10(4)).

–   For Pt 4 states, the position is the same as under Pt 3 save that (the relevant paragraphs being 13 and
15), although the Secretary of State has a power to bar an appeal based on a human rights claim by
making a 'clearly unfounded' certificate she is not obliged to do so.

It should be noted that where the presumptions apply they are general in character: that is, the presumption of
safety applies to everyone proposed to be removed to the country in question.
**[*363]**

**[371] Part 5 is headed 'Countries Certified as Safe for Individuals'. Paragraph 17 provides:**

'This Part applies to a person who has made an asylum claim if the Secretary of State certifies that—

(a) it is proposed to remove the person to a specified State,

(b) in the Secretary of State's opinion the person is not a national or citizen of the specified State, and

(c) in the Secretary of State's opinion the specified State is a place—


-----

High Commissioner for Refugees intervening) and ot....

(i) where the person's life and liberty will not be threatened by reason of his race, religion, nationality,
membership of a particular social group or political opinion, and

(ii) from which the person will not be sent to another State otherwise than in accordance with the Refugee
Convention.'

Paragraph 19 provides:

'Where this Part applies to a person—

(a) …

(b) he may not bring an immigration appeal in reliance on an asylum claim which asserts that to remove the
person to the State specified under paragraph 17 would breach the United Kingdom's obligations under the
Refugee Convention,

(c) he may not bring an immigration appeal in reliance on a human rights claim if the Secretary of State
certifies that the claim is clearly unfounded, and

(d) …'

There is accordingly no presumption of the kinds provided for in Pts 2–4. Part 5 is concerned only with a bar on the
bringing of immigration appeals. The relevant certifications – under paras 17(c) and 19(c) – necessarily require an
assessment of the risk to the particular individual.

**[372] Rwanda is not listed in Pt 2 and has not been specified in an order made under Pt 3 or Pt 4. The Secretary of**
State has, however, in the case of each of the Claimants certified under para 17(c) that Rwanda is a place where
their life and liberty will not be threatened on any of the specified grounds and from which they will not be refouled –
in short, that it is safe. (She has also, as we have seen, certified their human rights claims as clearly unfounded
under para 19(c); but that is not the material certification for the purpose of this issue.) The decision letters in each
case, which are in this respect in standard form, say that the decision is based in part on the judgment in the
Asylum System CPIN.

**[373] The Claimants' case as regards this issue can be summarised as follows:**

(1)   It is implicit in the structure of Sch 3 that the statutory intention is that any general presumption as to
the safety of a country must be effected by including it in a List under one of Pts 2–4, which requires the
approval of Parliament.

(2)   The effect of the assessments contained in the CPINs is in substance to create a general
presumption that Rwanda is a safe country.

(3)   Accordingly the making of a certificate under para 17 based on those assessments circumvents the
statutory scheme by applying a presumption which has not received Parliamentary approval and is
therefore unlawful.

**[*364]**

**[374] I do not believe that that case is well-founded. Specifically, I do not accept that the assessments contained in**
the CPINs constitute presumptions of the same kind as those enacted in Pts 2–4 of Sch 3: they are of an essentially
different character. The Preface to the Assessment CPIN begins, in what is evidently standard language for CPINs,
by describing their purpose and nature generally. The fourth paragraph reads:

'In addition to background information obtained from a range of sources, [CPINs] also include relevant caselaw
and our (CPIT's) general assessment of the key aspects of the refugee status determination process (that is
risk, availability of protection, possibility of internal relocation, and whether the claim is likely to be certified as
“clearly unfounded”).'


-----

High Commissioner for Refugees intervening) and ot....

It continues:

'This note provides an assessment of Rwanda's asylum system, support provisions, integration opportunities
as well as some of the general, related human rights issues for use by Home Office decision makers handling
particular types of protection and human rights claims.

It is not intended to be an exhaustive survey of a particular subject or theme.

It analyses the evidence relevant to this note – that is: information in the contained in the separate country
information reports (see below); refugee/human rights laws and policies, in particular paragraph 345B of the
immigration rules which sets out when a country is a “safe third country of asylum”; and applicable caselaw –
describes this and its inter-relationships, and provides an assessment of whether, in general, there are
substantial grounds for believing that a person, if relocated to Rwanda, would face a real risk of being
subjected to treatment contrary to Article 3 of the European Convention on Human Rights (ECHR).'

After referring to the other CPINs which I have identified at para [138] above, it concludes:

'Decision makers **must, however, still consider all claims on an individual basis, taking into account each**
case's specific facts.' (Emphasis in original.)

**[375] That approach recognises that the exercise for which CPINs are required is one of taking decisions on a**
case-by-case basis: that is stated in terms in the final sentence but is in fact clear from the entirety of the passage.
The assessments contained in the CPIN will of course be general in character, but that is not inconsistent with
individualised decision-making. As Lord Kerr observed at para [70] of his judgment in R (on the application of EM
_(Eritrea)) v Secretary of State for the Home Dept_ _[[2014] UKSC 12, [2014] 2 All ER 192, [2014] AC 1321, '[t]he court](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-CYX1-DYBP-M26P-00000-00&context=1519360)_
must examine the foreseeable consequences of sending a claimant to the receiving country bearing in mind both
the general situation there and the claimant's personal circumstances' (my emphasis). As regards the first element,
it is not only legitimate but inevitable that caseworkers will have regard to general assessments of the kind
contained in CPINs. As the Secretary of State observes at para 91 of her skeleton argument,

'The notion of a completely “ad hoc” or “one-off” assessment is unreal: it is inevitable that recurring issues will
arise in relation to particular countries which it is desirable to resolve on a consistent basis.'

**[*365]**

I accept that some of the assessments contained in the CPINs are likely in practice to be treated as definitive of the
particular question which they address – see, for example, the assessment about the risk of refoulement quoted at
para [297] above. But that does not mean that the nature of the exercise under Pt 5, which requires individualised
decision-making, can be equated with the application of a presumption under Pts 2–4.

**[376] That being so, the Secretary of State cannot in my view be regarded as circumventing Parliament's intention**
by choosing in these cases to make use of her individual certification powers under Pt 5 rather than seeking to have
Rwanda listed as a generally safe country under Pt 3 or 4. The provisions of the various Parts offer different
possible mechanisms for limiting claimants' rights to challenge safe third country decisions. Each mechanism will to
some extent involve the Secretary of State making a general assessment of matters relevant to the safety of the
country in question, and to that extent there is a degree of overlap between them. Nevertheless, each has its
different characteristics and its different advantages and disadvantages. Parts 3 and 4 give the Secretary of State
the advantage of being able to apply a general presumption of safety, without having to make an individualised
assessment, but they involve the no doubt cumbersome exercise of enacting secondary legislation and obtaining
Parliamentary approval. I can see no basis for implying into the statute an obligation to use the Pts 2–4 mechanism
in every case where the Secretary of State makes a 'general' assessment of some kind. Indeed, given the fact that,
as I have said, there will be an element of such assessment in every individual decision, it is hard to see how such
an implication would be workable.


-----

High Commissioner for Refugees intervening) and ot....

**[377] I would accordingly uphold the Divisional Court's conclusion on this issue also. Again, I have not found it**
necessary to set out its reasoning, which is at paras [78]–[84] of its judgment; but it is to the same effect as mine.
_Issue 15: Data protection_

**[378] The eighth issue considered by the Divisional Court was defined by it as follows:**

['Have there been breaches of the Data Protection Act 1998 and/or the UK General Data Protection Regulation](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y13M-00000-00&context=1519360)
in the implementation of the Rwanda policy? Do such breaches invalidate decisions taking under either
paragraph 345A or 345C of the Immigration Rules?'

That issue arose from grounds of challenge pleaded by SAA and argued before the Divisional Court, as also before
us, by Mr Manjit Gill KC. I will refer to them as 'the data protection grounds'.

**[379] The Divisional Court dismissed the data protection grounds and refused permission to appeal. In my**
judgment dated 14 March 2023 considering the outstanding applications for permission to appeal I directed that the
application be adjourned to the hearing of the appeal on the other issues, on a 'rolled-up' basis. In the event we
heard oral submissions from Mr Gill directed simply to the issue of permission.

**[380] For the reasons I give below I would refuse permission to appeal. That being so, it is unnecessary that I set**
out the factual and legal background, which are fully set out in the judgment of the Divisional Court.

**[381] The Court addressed the data protection grounds at paras [127]–[149] of its judgment. It explains at paras**

[127]–[130] that, pursuant to the terms of the MoU, once SAA had been served with a Notice of Intent to relocate
him to
**[*366]**

Rwanda the Home Office provided the Rwandan authorities with details of SAA's name, date of birth, sex,
nationality, and the date he made his asylum claim in the United Kingdom, together with a photograph. At para

[131] it summarised SAA's case as follows:

'First, that transfer of personal data to Rwanda on the terms set out in the MOU is contrary to the requirements
in Chapter V of Retained European Parliament and _[Council Regulation (2016/679/EU), better known as the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JK-CY73-GXFD-82XN-00000-00&context=1519360)_
United Kingdom General Data Protection Regulation (“the UK GDPR”). Chapter V makes provision regulating
the transfer of personal data to third countries. _Second, that the Home Secretary has failed to comply with_
article 13 of the UK GDPR, which requires a data controller when obtaining personal data from a data subject
to provide information, for example on the purposes for which the data obtained will be processed. Third, that
the data protection impact assessment prepared by the Home Secretary in respect of the MEDP, to meet the
requirements of article 35 UK GDPR, is defective.'

**[382] The Divisional Court did not, however, decide any of those issues. Instead, at para [132], it pointed out that**
there was what it called a 'logically prior issue', namely:

'Even assuming that SAA is correct on any or all of his submission on compliance with the UK GDPR, does
that affect the legality of any decision the Home Secretary has taken under paragraph 345A or 345C of the
Immigration Rules such that it would be appropriate to quash that decision for that reason?'

As to that, it recorded Mr Gill's case as follows (para [133]):

'The submission for SAA is to the effect that the power to make decisions under the Immigration Rules (i.e.,
decisions under paragraph 345A and 345C) depended on compliance with whatever requirements might arise
[either under the UK GDPR or under its counterpart, the Data Protection Act 2018 … In consequence, failure to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)
comply with data protection law would require the conclusion that the immigration decisions were unlawful and
should be quashed.'


-----

High Commissioner for Refugees intervening) and ot....

**[383] The Divisional Court did not accept that submission. Between paras [135] and [142] it considered each of the**
three complaints identified in para [131] and concluded that even if each was made out it would not have the
consequence that the decision to relocate SAA should be quashed. In short:

(1)   As regards the alleged failure to carry out a proper data protection impact assessment ('DPIA')
pursuant to art 35 of the UK GDPR, it held that '[t]he legal requirement to undertake that assessment is not
a matter that is integral to the validity of the decisions (to be taken in the future) under the Immigration
Rules' (para [135]).

(2)   As regards the alleged breach of the obligation to provide SAA with sufficient information about the
processing of his data, pursuant to art 13, it held that there was 'no relevant connection between a breach
of article 13, the consequences of the breach, and any standard going to the validity of the public law
decision' (para [137]). It pointed out that SAA had free-standing remedies under the UK GDPR and the
2018 Act.

**[*367]**

(3)   As regards compliance with the requirements of Ch V of the UK GDPR, it accepted that the
Secretary of State's decision to remove SAA to Rwanda depended on the consent of the GoR to receive
him and that the personal data sent to Rwandan authorities as noted at para [381] above was sent for the
purpose of obtaining that consent. But it held that it did not follow that any non-compliance with the
conditions imposed by Ch V for transfer of personal data to third countries meant that the GoR's consent
was ineffective or therefore that the removal decision was invalid (para [141]). It noted that that conclusion,
reached on public law principles, was reinforced by the fact that neither the UK GDPR nor the 2018 Act
provided that past transactions relying on data processed in breach of data protection law are thereby
invalidated (para [142]).

**[384] Having performed that exercise, it concluded, at para [143]:**

'All this being so, the data protection law submissions in this case are not capable of producing the conclusion
that the Home Secretary's decisions under Immigration Rules are unlawful.'

It went on at paras [144]–[148] to express some views on the substance of SAA's complaints but on an expressly
obiter basis.

**[385] SAA now advances a single ground of appeal, ground 23 in the consolidated grounds, which reads:**

'The court erred in holding that the Appellant's data protection arguments were not relevant to any public law
decision, and it erred in not addressing the Appellant's data protection arguments lawfully, or adequately, or at
all.'

**[386] That challenges the basis on which the Divisional Court decided the eighth issue, but in order to identify the**
reasoning behind the challenge it is necessary to look at the skeleton argument. This makes thirteen points, at
paras 32–47. I will consider those points in turn. I should say that Mr Gill did not seek to develop them in his oral
submissions, which were addressed to broader questions which I have to say did not appear to me to bear on the
Divisional Court's dispositive reasoning.

**[387] The first point is that the Divisional Court's 'logically prior issue' had not been raised by the Secretary of State**
but was instead raised by the court itself in the course of oral submissions. Even if that is correct, it goes nowhere if
the point is in fact good.

**[388] The second point is that the Divisional Court 'did not address the relevant public law decisions … or consider**
how the data arguments related to them'. I do not accept that. On the contrary, it is precisely the exercise which the
Court carried out between paras [135] and [142] of its judgment.

**[389] The third point arises from para [134] of the Divisional Court's judgment, where it said:**


-----

High Commissioner for Refugees intervening) and ot....

'As a matter of principle, it cannot be that any breach of any rule on the part of a public authority or for which
that authority is responsible, occurring in the context of either making or executing a public law decision will
necessarily affect the validity of that public law decision. To take an obvious example, if a person being
removed from the United Kingdom was assaulted by a Home Office official on his way to the airport, that
assault would be unlawful but would not in itself compromise the

**[*368]**

legality of the immigration decision that was the reason for removal. On its facts, this example is some way
distant from the cases now before us. However, on the facts that are before us, the same conclusion should be
reached.'

It is said that the assault example is not analogous with the circumstances of the present case. But the Court
expressly acknowledged that. The example was simply offered as a vivid example of the general principle. The
relationship between the alleged breaches of data protection law and the public law decisions taken in SAA's case
was carefully considered in the paragraphs to which I have referred.

**[390] The fourth point is that 'compliance with the SSHD's obligations under** _[DPA 2018 and UK GDPR is a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)_
necessary prerequisite or a sine qua non in practice of a removal decision under para 345C'. That may be correct,
but it does not follow that non-compliance invalidates the decision.

**[391] The fifth point is that the decision whether Rwanda was a safe third country within the meaning of para 345B**
required a consideration of whether its data protection regime was adequate. Mr Gill contended that there was a
wealth of evidence that that was not the case and that the Secretary of State had failed to assess the relevant risks
by carrying out a properly comprehensive DPIA. But a case of that kind does not fall within the eighth issue as
defined by the Divisional Court, which is the subject of the ground of appeal. (It does not in fact appear that the
Court believed that such a case was before it at all, and I have not been able to identify it in SAA's original grounds
of judicial review.)

**[392] The sixth point is that a DPIA had to be carried out before a decision was reached to transfer the personal**
data in question or under paras 345B and 345C. That may be so, but it does not address the Divisional Court's
point that the carrying out of the DPIA was not integral to the removal decisions taken.

**[393] The seventh and eight points are, respectively, that 'the burden was on SSHD to carry out such an inquiry**
and to undertake such a DPIA' and that a DPIA was necessary not only by reference to art 35 itself but also
because it was required by art 71 of 'the Withdrawal Agreement 2020'. But again, neither point addresses the
question whether its carrying out was integral to the removal decisions.

**[394] The ninth point is that the scope of the DPIA should conform to the guidance given in the case-law of the**
Court of Justice of the European Communities in such cases as Schrems v Data Protection Comr (Case C-362/14)
EU:C:2015:650, [2016] QB 527, [2016] 2 WLR 873, and _Data Protection Comr v Facebook Ireland Ltd (USA_
_intervening) (Case_ _C-311/18) EU:C:2020:559,_ _[[2021] 1 All ER (Comm) 507, [2021] 1 WLR 751. The Divisional](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:627S-7YT3-GXFD-8186-00000-00&context=1519360)_
Court had in the obiter section of its judgment said that those cases did not provide the appropriate yardstick, and
that point is challenged in the skeleton argument. But none of this goes anywhere if the Divisional Court's logically
prior point is good.

**[395] The tenth point develops the argument that the Secretary of State failed to comply with the requirements of**
art 13 of the UK GDPR, noting that the Divisional Court had in the obiter part of its judgment appeared to accept
that that was so. But that only serves to emphasise that the issue here is not whether there was a breach but
whether it impacted on 'the validity of the public law decision' (see para [383](2) above). That question is not
addressed.

**[396] The eleventh point is that 'all such enquiries' – which I take to be a reference to the DPIA but perhaps also to**
the requirements of Ch V of the UK GDPR – had to be made prior to the transfer of the data, which was itself

**[*369]**


-----

High Commissioner for Refugees intervening) and ot....

required by the GoR prior to any relocation decision. But the answer is the same as to the fourth point: it does not
follow that non-compliance invalidates the decision.

**[397] The twelfth point is that**

'… the SSHD would have to investigate and inquire if there are any other risks in Rwanda to the essence of the
asylum seekers correlated human rights under the ECHR, including to his rights to data protection under Art 8
ECHR, such as to make a removal decision under para 345C inappropriate.'

As with the fifth point, a case that para 345C had not been complied with because of a risk of data protection
breaches in Rwanda that would impact on SAA's privacy is not within the scope of the eighth issue (nor have I been
able to identify it in the original grounds of judicial review).

**[398] The thirteenth point appears to be that the Secretary of State is relying on the MEDP, which is a treaty taking**
effect at the level of international law, in order to justify a breach of domestic data protection law. That bears no
relation to the basis on which the Divisional Court decided the eighth issue – or, so far as I can see, to any
argument advanced by the Secretary of State.

**[399] Although I have thought it right to go through each of the points in the skeleton argument, the simple fact is**
that neither there nor in Mr Gill's oral submissions has SAA advanced any response to the Divisional Court's
dispositive reasoning that has any real prospect of success.

**[400] I would accordingly refuse permission to appeal on ground 7.**
_Issue 16: Procedural fairnessIntroduction_

**[401] In addition to the seven claims brought by individual Claimants, on 9 June 2022 the charity Asylum Aid**
brought judicial review proceedings seeking to challenge:

'… [t]he procedure and arrangements (including the Inadmissibility Guidance …) adopted by the SSHD in
respect of forced removals to Rwanda made pursuant to the Migration and Economic Development Partnership
announced on 14 April 2022'.

As developed, its challenge was specifically to the fairness of the procedure leading up to the decision in the case
of any individual that they should be relocated to Rwanda – or, more accurately, the several decisions which lead to
that outcome. The challenge is to the overall fairness of the system and is generic in character: it is not concerned
with the fairness of the decisions taken in the cases of any individual Claimants. That challenge is considered at
paras [380]–[429] of the Divisional Court's judgment, together with some related challenges to the fairness of the
procedure advanced by individual Claimants. It was dismissed.

**[402] Permission to appeal was given by the Divisional Court on six grounds, to which I will return below: they were**
originally numbered 1–6 but they have been re-numbered 15–20. Those grounds were advanced before us by Ms
Charlotte Kilroy KC. The AAA Claimants and RM also have permission to advance grounds on procedural fairness
(grounds 21 and 22 respectively). The AAA Claimants do not raise any point not advanced by Asylum Aid; I
address
**[*370]**

RM's ground at para [456] below. The charity Freedom from Torture and the United Nations Special Rapporteur on
Trafficking in Persons were given permission to intervene by written submissions. I have read their submissions and
bear them in mind in considering the issues raised by Asylum Aid's grounds.
The Procedure

**[403] For ease of reference, I repeat here the terms of paras 345A–345D of the Immigration Rules:**

**'Inadmissibility of non-EU applications for asylum**


-----

High Commissioner for Refugees intervening) and ot....

345A. An asylum application may be treated as inadmissible and not substantively considered if the Secretary
of State determines that:

(i) the applicant has been recognised as a refugee in a safe third country and they can still avail themselves of
that protection; or

(ii) the applicant otherwise enjoys sufficient protection in a safe third country, including benefiting from the
principle of non-refoulement; or

(iii) the applicant could enjoy sufficient protection in a safe third country, including benefiting from the principle
of non-refoulement because:

(a) they have already made an application for protection to that country; or

(b) they could have made an application for protection to that country but did not do so and there were no
exceptional circumstances preventing such an application being made, or

(c) they have a connection to that country, such that it would be reasonable for them to go there to obtain
protection.

**Safe Third Country of Asylum**

345B. A country is a safe third country for a particular applicant, if:

(i) the applicant's life and liberty will not be threatened on account of race, religion, nationality, membership of
a particular social group or political opinion in that country;

(ii) the principle of non-refoulement will be respected in that country in accordance with the Refugee
Convention;

(iii) the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman, or degrading
treatment as laid down in international law, is respected in that country; and

(iv) the possibility exists to request refugee status and, if found to be a refugee, to receive protection in
accordance with the Refugee Convention in that country.

345C. When an application is treated as inadmissible, the Secretary of State will attempt to remove the
applicant to the safe third country in which they were previously present or to which they have a connection, or
to any other safe third country which may agree to their entry.

**Exceptions for admission of inadmissible claims to UK asylum process**

345D. When an application has been treated as inadmissible and either

(i) removal to a safe third country within a reasonable period of time is unlikely; or

**[*371]**

(ii) upon consideration of a claimant's particular circumstances the Secretary of State determines that removal
to a safe third country is inappropriate

the Secretary of State will admit the applicant for consideration of the claim in the UK.'

**[404] The decision-making process followed in the cases of the individual Claimants is fully set out at paras [29]–**

[35] of the Divisional Court's judgment. It was common ground that the same process was intended to be followed
in all cases involving removal to Rwanda under the MEDP. I will gratefully reproduce the Court's account, though in
slightly edited and abbreviated form.


-----

High Commissioner for Refugees intervening) and ot....

**[405] Persons considered as potentially appropriate for relocation to Rwanda would have been detained shortly**
after arrival in the United Kingdom, and would be subject to the usual steps applied to all newly-detained persons.
Among other matters, each person detained was to be:

(a)   subject to an assessment of his language skills to determine proficiency in English;

(b)   assessed by healthcare staff with a view to deciding if further healthcare provision is required;

(c)   issued with a mobile phone and given information about IT facilities at the detention centre;

(d)   given information about the centre's welfare officer; and

(e)   given information on how to obtain legal representation, if he did not already have it, including
information on the free duty solicitor scheme.

**[406] If they made an asylum claim, as all the Claimants did, shortly after the claim was made (usually within a day**
or so) they would attend an asylum screening interview.

**[407] Each claim was then considered by the Home Office National Asylum Allocations Unit ('the NAAU'). The**
Inadmissibility Guidance provided that if the NAAU suspects that the claimant '… may [in the course of travelling to
the United Kingdom] have spent time in or have a connection to a safe third country …' the case must be referred to
the Third Country Unit ('the TCU') for consideration of whether an inadmissibility decision should be taken. The TCU
then reviewed claims referred to it to determine whether they '… [appear] to satisfy paragraphs 345A and 345B of
the Immigration Rules'. If a case fell into this category, the TCU would issue the claimant with a standard-form
Notice of Intent.

**[408] I need not set out the full terms of the Notice of Intent, but it begins as follows:**

'We have evidence that before you claimed asylum in the United Kingdom, you were present in or had a
connection to [name the safe country or countries]. This may have consequences for whether your claim is
admitted to the UK asylum system.

We will review your particular circumstances and the evidence in your case, and consider whether it is
reasonable to have expected you to have claimed protection in [country or countries] (or to have remained
there if you had already claimed or been granted protection), and whether we should consider removing you
there or elsewhere.'

It goes on to inform the recipient that if inadmissibility action appears appropriate a safe third country, including
Rwanda, may be asked if it will admit him or her. The Notice includes the following statement:
**[*372]**

'If you wish to submit reasons not already notified to the Home Office why your protection claim should not be
treated as inadmissible, or why you should not be required to leave the UK and be removed to the country or
countries we may ask to admit you (as mentioned above), you should provide those reasons in writing within 7
calendar days [for detained cases] or 14 calendar days [for non-detained cases] of the date of this letter. After
this period ends, we may make an inadmissibility decision on your case, based on the evidence available to us
at that time.'

Since in cases of the kind with which we are concerned the claimant will be in detention, the relevant period for the
provision of such reasons would be seven days. It was the Secretary of State's evidence, although this is not stated
in the Notice of Intent, that that period can, as a matter of discretion, be extended on request: see para [434] below.

**[409] Following the expiry of the seven-day period the Secretary of State proceeds to take the relevant decisions,**
being:

–   a decision that the claim is inadmissible, applying para 345A of the Immigration Rules;

– the decision on removal to Rwanda applying para 345C (and para 345D where necessary);


-----

High Commissioner for Refugees intervening) and ot....

–   a decision on certification under para 17 of Sch 3 to the 2004 Act; and

–   where a human rights claim has been made, a decision on certification under para 19(c) of Sch 3.

**[410] Although that fourfold break-down of the relevant decisions appears to reflect the structure of the decision**
letters, Ms Kilroy submitted that in substance the Secretary of State was obliged to make at least six decisions,
identified at paras 43–50 of Asylum Aid's skeleton argument. It is unnecessary to go through her analysis because
the decisions in question can be broken down in various ways: what matters is her overall point, which I accept, that
the decision-making process may involve numerous questions and that that will be reflected in the matters on which
claimants may wish to make representations. I note, because our focus so far has been on issues relating to the
safety of Rwanda, that one issue that may arise under para 345A is whether there were exceptional circumstances
preventing a claimant from making an application for asylum in any safe third country through which they may have
passed: see head (iii)(b).

**[411] Removal directions can be issued as soon as those decisions are communicated. In the case of the**
Claimants, removal directions were issued only a few days after the initial decisions in late May/early June 2022. In
accordance with normal practice governing removal directions, there would be an interval of at least five days
between the date of the direction and the proposed date of removal.

**[412] I should mention one other point about the structure of paras 345A–345D. A claimant may make**
representations which do not go either to the issue of inadmissibility under para 345A or to whether Rwanda is a
safe third country under para 345C (which brings in the criteria in para 345B). Specifically:

(1)   As Lord Pannick confirmed when asked by the Court, para 345B does not address the risk of serious
ill-treatment within the country in question: head (iii) as drafted is concerned only with ill-treatment in any
country to

**[*373]**

which the third country might remove the claimant. Removal to a third country where there was such a risk
would involve a breach of art 3 in accordance with the Soering principle.

(2)   Neither paragraph requires consideration of other personal matters which a claimant might wish to
advance as reasons why they should not be removed to a safe third country, for example medical issues or
the presence of other family members in the UK: para 345A is concerned entirely with inadmissibility, and
para 345C simply states the consequence of inadmissibility, namely removability to a safe third country.

The Secretary of State does not dispute that any such representations would have to be considered by her, but it is
not entirely clear where they fit into the formal analysis. Lord Pannick said that they did not fall for consideration
under any specific provision of the Rules, but that in taking a removal decision under para 345C the Secretary of
State would be obliged by s 6 of the Human Rights Act to decide whether removal would breach the person's
Convention rights. The latter proposition is no doubt correct, but in principle a claimant is not confined to
representations based on Convention rights. My provisional view is that representations relating to all matters other
than inadmissibility would in fact go to whether removal is 'inappropriate' under para 345D(ii); but it is unnecessary
to reach a final conclusion.
The Grounds: Overview

**[413] Asylum Aid's primary case, as Ms Kilroy confirmed, is that the seven-day period allowed for the making of**
representations following the service of a Notice of Intent will in virtually every case be too short to allow for the
making of any effective representations. Its ground 17 challenges the Divisional Court's rejection of that case.

**[414] The length of time reasonably required will of course depend on a number of factors, including (a) the scope**
of the matters on which representations may be made, (b) whether the claimants will need legal advice and (c)
whether they need further information from the Secretary of State in order to be able to make effective
representations. The Divisional Court made findings on those questions, and they are the subject of the challenges
in grounds 15–16 and 18. Grounds 19 and 20 are of a rather different character. Although it might be more logical
to re order the gro nds I ha e fo nd it simpler to take them in the order that the are ad anced


-----

High Commissioner for Refugees intervening) and ot....

**[415] In the light of our decision on the issue of the safety of Rwanda no removals under the MEDP will be**
proceeding for some time. To that extent, the generic challenge to the system for taking decisions for such
removals has become academic. That does not mean that we should not determine Asylum Aid's appeal, because
removals may resume in due course, whether as a result of a successful appeal or because the defects in the
Rwandan asylum system are effectively addressed. However, we should confine ourselves to deciding the specific
issues raised by the grounds, and should eschew offering any wider guidance about what procedural fairness might
entail in future cases of this kind, where the circumstances may be different. In any event, the hearing before us did
not afford an opportunity for a general review of the procedure adopted.

**[416] There was no dispute before us as to the fundamental requirements of common law fairness. They are**
classically stated by the House of Lords in Doody v Secretary of State for the Home Dept _[[1993] 3 All ER 92, [1994]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60GY-00000-00&context=1519360)_
1 AC 531,
**[*374]**

but we were referred also to the judgment of this Court in R (on the application of Balajigari) v Secretary of State for
_the Home Dept_ _[2019] EWCA Civ 673,_ _[[2019] 4 All ER 998, [2019] 1 WLR 4647(at paras [45]–[61]). It is well-](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XJR-HW73-GXFD-830J-00000-00&context=1519360)_
recognised that procedural fairness is a matter of peculiar importance in asylum cases: see, eg, the observations of
Bingham LJ in Secretary of State for the Home Dept v Thirukumar [1989] Imm AR 402 at 414. The application of
those principles in a given case depends on the particular circumstances of that case, and I do not propose to
burden this judgment with further citation of authority.
Ground 15: Scope of Representations

**[417] Ground 15 begins with a general averment that the Divisional Court was wrong to reject Asylum Aid's case**
that the Rwanda policy was systemically unfair. However, that general pleading is followed by the specific criticism
– introduced by the word 'including' – of the Court's finding that 'procedural fairness did not require the provision of
information relating to, or the opportunity to make representations on, the matters set out in para 345B(ii)–(iv) …';
and the skeleton argument is directed only to that criticism. The issue raised by this ground is whether fairness
required that asylum claimants served with a Notice of Intent should be able to make effective representations
about the safety of Rwanda generally (ie, broadly, the matters covered by heads (ii)–(iv) under para 345B of the
Immigration Rules) – 'the general safety question' – or only about why it was unsafe for the particular claimant
(broadly, head (i) under para 345B) – 'the specific safety question'. Ms Kilroy submitted that that dichotomy is
artificial and breaks down when it has to be applied in practice. I have sympathy with that submission: see Lord
Kerr's observations in EM (Eritrea) referred to at para [375] above. But the distinction plays an important part in the
reasoning of the Divisional Court, and I will accept it for present purposes.

**[418] In the Divisional Court the Secretary of State's initial position was that fairness required that claimants be**
entitled to make effective representations on the question whether 'Rwanda is a safe country' simpliciter. But in the
course of the October hearing, she changed her position as a result of questions from the Court. Her revised
position was that fairness only required that claimants should be entitled to make representations about 'whether
there is any reason specific to the Claimant why Rwanda would not be a safe third country in the individual
circumstances of the Claimant'. The Court permitted her to advance that revised case, but it was not possible to
hear submissions about it at the hearing, and the issue was resolved on the basis of written representations lodged
subsequently: more details can be found at paras [386]–[387] of the judgment.

**[419] The Divisional Court accepted the Secretary of State's revised submission. Its reasons appear at paras [388]–**

[395]. The relevant passage for our purposes starts with para [390]. The drafting is complicated by the fact that the
Court was considering both this issue and the related issue of whether the Secretary of State should be expected to
provide further information; but the gist of its conclusion was that fairness required that they be entitled to make
representations on the specific but not the general safety question. At para [391] the Court summarises Asylum
Aid's submissions to the contrary, which included the submission that it was impossible in practice to distinguish
between the two questions. At para [392] it responds to those submissions as follows:
**[*375]**


-----

High Commissioner for Refugees intervening) and ot....

'A distinction does exist between the criteria at paragraph 345B of the Immigration Rules. Criterion (i) is
formulated by reference to the asylum applicant's own circumstances and characteristics, criteria (ii)–(iv) are
framed by reference to the general position in the country in question. The real issue is whether that distinction
is material for the purposes of setting what is required by law for fair exercise of the paragraph 345C power to
remove to a safe third country. Our conclusion is that the distinction between what an asylum claimant may be
able to say about his own circumstances and how those might be relevant to whether he is removed to a
particular country, and whether that country, generally, complies with its obligations under the Refugee
Convention does determine the extent of the legal requirement of procedural fairness in this context.
Procedural fairness requires that an asylum claimant should have the opportunity to make representations on
matters within the criterion at paragraphs 345B(i) of the Immigration Rules. Those are matters relevant to any
decision to remove (self-evidently) and matters the asylum claimant is uniquely placed to consider and explain.
Matters known to the asylum claimant may be a relevant consideration; the Home Secretary must take it into
account; and the duty to act fairly must apply to require the claimant to have an opportunity to make
representations. The same applies to the criteria at paragraph 17(c) of Schedule 3 to the 2004 Act which are
also directed to the specific position of the asylum claimant. _Criteria (ii)–(iv) within paragraph 345B of the_
Immigration Rules are different, and _require evaluation of whether, generally, the relevant country complies_
_with its obligations under the Refugee Convention. Those matters will go well beyond the circumstances of any_
one asylum claimant; they are also criteria which the Home Secretary, given the resources available to her, is
well-placed to assess. We do not consider that the duty that the Home Secretary act fairly in exercise of the
_power at paragraph 345C of the Immigration Rules requires an asylum claimant to have the opportunity to_
_make representations on these matters. It is not enough to say that criteria (ii)–(iv) are relevant to the decision_
to remove and since the asylum claimant is the subject of that decision he must have a legal right to comment
on those matters before the decision is made. That is a non-sequitur. The scope of the obligation to act fairly is
measured in specifics. This is not to say that any individual faced with the possibility of removal to a third safe
country could not seek to persuade the Home Secretary that one or other of criteria (ii)–(iv) was not met, and
that if such representations were made, the Home Secretary should have regard to them. But such
representations would not be made in exercise of any legal right arising out of an obligation to ensure
procedural fairness. Further, to the extent that an asylum claimant may wish to make such representations he
has sufficient information about what such representations must be directed to, by reason of paragraph 345B
itself. That explains the matters the Home Secretary must consider. The legal duty to act fairly does not require
the Home Secretary provide him with all the material available to her; the legal duty to act fairly does not in the
present context require that an asylum claimant be put in the position to second-guess the Home Secretary's
evaluation on criteria (ii)–(iv).'

**[420] I have italicised the parts of the passage which decide as a matter of principle the scope of the matters on**
which fairness requires that claimants should be entitled to make representations. It is true that the Court goes on to
**[*376]**

acknowledge that the Secretary of State might have to consider representations made otherwise than by way of
legal right, but I need not for present purposes try to unpack that proposition, and I will focus on the italicised words.
The last three sentences are concerned with the separate issue of whether the Secretary of State was obliged to
provide asylum-seekers whom she proposed to relocate to Rwanda with 'all the material she has relied on to decide
that Rwanda is a safe third country (including the material she relied on to reach the conclusion that Rwanda would
abide by its obligations under the MOU and the notes verbales)' (see para [385](2) of the judgment); but the issues
are clearly related, and the Court's reasoning clearly reflects its reasoning on the issue of the scope of the
representations which they were legally entitled to make.

**[421] In the circumstances of the present case the Divisional Court's conclusion in para [390] of its judgment,**
amplified in para [392], was in my respectful view wrong. As Ms Kilroy submitted, as a matter of principle a person
should be permitted to make representations about any matter relevant to an adverse decision about their case,
and it is no answer to say that they might not be as 'well-placed' as the decision-maker to make the decision itself. I
accept that there may in some cases be matters contributing to the decision about which representations would for
some objective reason be pointless But that is not the case here An individual asylum seeker may not personally


-----

High Commissioner for Refugees intervening) and ot....

know anything about Rwanda, but they are entitled to rely on the research or expertise of people or institutions
representing their interests. The position might be different if there had already been a decision of the Court (or
perhaps some other authoritative independent body). In that case fairness might indeed not require that claimants
have the opportunity to seek to persuade the Secretary of State to go behind that decision (at least unless they
could provide compelling evidence of a relevant change of circumstances[9]). The Divisional Court made this very
point at para [395] of its judgment, where it said:

'… [F]or the future … the generic issues raised by the Claimants as to why relocation to Rwanda would be
unlawful have now been determined by this court (subject to any appeal) and subject to any relevant new
information emerging.'

But those were not the circumstances here. There had been at the date of the removal decisions no determination
by the Court; and fairness required that the Claimants have the opportunity to try to persuade the Secretary of State
that her conclusion on the general safety issue was wrong.

**[422] I should say that the Secretary of State did not make any substantive submissions in support of the impugned**
statement. Rather, Lord Pannick's submission to us was that the issue was academic because the Secretary of
State had in fact undertaken to consider all submissions, whether on the general or on the specific safety question.
Whether or not that is so, the point is important in principle.

**[423] I should record that the Secretary of State filed a Respondent's Notice in relation to this ground, contending**
that if there was in fact 'a common law obligation to invite representations on the general safety of Rwanda, it was
sufficient that the Secretary of State gave notice that she considered Rwanda to be a safe country and invited
representations as to whether there was any

11

reason the person should not be removed from the UK to Rwanda'. I am inclined to think that that is correct, but
even if it is it does not affect the substance of Asylum Aid's challenge.

**[424] In summary, I believe the point raised by ground 15 is good, but it does not necessarily impugn the Divisional**
Court's overall conclusion.
Ground 16: Access to Legal Advice

**[425] At para [403] of its judgment, in the section addressing procedural failures alleged by individual Claimants, the**
Divisional Court said:

'There have been criticisms of the lack of access to legal advice. Given the scope of the right to make
representations in this context, we do not consider that procedural fairness requires that a person who is at risk
_of action under the Inadmissibility Guidance be provided with legal representation for the right to make_
_representations to be an effective right [my italics]. It is essentially a matter of fact as to why he did not claim_
asylum in a third country on route to the United Kingdom. It is essentially a matter of fact for him to give his
reasons why he should not be removed to Rwanda.'

Notwithstanding that general conclusion, it went on briefly to consider what access to legal advice the individual
Claimants had in fact had and it found that the process was in that regard fair.

**[426] Asylum Aid's challenge is only to the statement which I have italicised. Even if the Claimants in these cases**
did in fact all have access to legal advice, if that statement is wrong it is capable of leading to injustice if relied on in
other cases, and I believe we should address it.

9 Cf the position where a party seeks to persuade the First-tier Tribunal to depart from a Country Guidance decision of the
Upper Tribunal.

**[*377]**


-----

High Commissioner for Refugees intervening) and ot....

**[427] The impugned statement proceeds on the basis that fairness only requires that claimants should be entitled to**
make representations on circumstances arising from their specific factual histories, so it would in any event have to
be reconsidered in the light of my conclusion on ground 15. But Ms Kilroy submitted that, even on the basis on
which the Court proceeded, the statement cannot be defended. She submitted that the right to make
representations must be effective, and that that went beyond a right simply to supply relevant facts to the decisionmaker. It was unrealistic to believe that asylum-seekers who had just arrived in the UK and (usually) spoke no
English could make effective representations, even on the specific safety question, without legal assistance, let
alone understand the relevant law – and all the more so in the light of the scope and complexity of the decisionmaking scheme governing removals to Rwanda under the MEDP. She also pointed out that the Secretary of State's
decisions in the present cases show that she insists on the provision of documentary materials, such as medical
reports, by way of supporting evidence, and that asylum-seekers in the Claimants' situation would plainly be unable
to comply with those requirements without professional assistance.

**[428] As with ground 15, the Secretary of State did not, either in her skeleton argument or in Lord Pannick's**
submissions before us, advance any substantial submissions in support of the impugned statement, pointing out
that in the Divisional Court she had sought to resist this part of Asylum Aid's challenge on the factual basis that
claimants were provided with access to state-funded legal advice.

**[429] In my view it is impossible, for essentially the reasons given by Ms Kilroy, to support a general proposition (if**
this is really what the Court
**[*378]**

intended) that procedural fairness will never require that an asylum-seeker who is at risk of removal to Rwanda
under the MEDP be provided with legal assistance to make representations before the removal decision is taken,
even if they are not addressing the general safety question. There may be cases where a decision is fair even
where there has been no access to legal assistance, but they are likely to be exceptional. As we have seen, the
Secretary of State does not contend otherwise and it is her policy to ensure that legal assistance is indeed
available.

**[430] I therefore believe the point raised by ground 16 is good, but, again, it does not necessarily impugn the**
Divisional Court's overall conclusion.
Ground 17: Seven Days

**[431] It is, as I have said, Asylum Aid's case that seven days was simply too short a period for claimants to prepare**
effective representations in response to a Notice of Intent to remove them to Rwanda. The Divisional Court rejected
that submission on the basis that its finding that fairness did not require that claimants have an opportunity to make
representations about the general safety question meant that seven days were adequate: see para [421] of the
judgment. That reasoning is undermined by my conclusion on ground 15. In any event, Ms Kilroy did not accept that
even on that basis seven days would be adequate. In those circumstances, I will focus directly on the parties'
submissions before us rather than considering the issue through the lens of the judgment.

**[432] I start with the applicable legal principles. At para [27] of his judgment in R (on the application of Detention**
_[Action) v First-tier Tribunal (Immigration and Asylum Chamber) [2015] EWCA Civ 840, [2016] 3 All ER 626, [2015] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KBH-RH61-DYBP-M40J-00000-00&context=1519360)_
WLR 5341, another case involving the adequacy of procedural timetables, albeit in a different context, Sir John
Dyson MR reviewed the relevant authorities and accepted counsel's summary of their effect, as follows:

'… (i) [I]n considering whether a system is fair, one must look at the full run of cases that go through the
system; (ii) a successful challenge to a system on grounds of unfairness must show more than the possibility of
aberrant decisions and unfairness in individual cases; (iii) a system will only be unlawful on grounds of
unfairness if the unfairness is inherent in the system itself; (iv) the threshold of showing unfairness is a high
one; (v) the core question is whether the system has the capacity to react appropriately to ensure fairness (in
particular where the challenge is directed to the tightness of time limits, whether there is sufficient flexibility in
the system to avoid unfairness); and (vi) whether the irreducible minimum of fairness is respected by the


-----

High Commissioner for Refugees intervening) and ot....

system and therefore lawful is ultimately a matter for the courts. I would enter a note of caution in relation to
(iv). I accept that in most contexts the threshold of showing inherent unfairness is a high one. But this should
not be taken to dilute the importance of the principle that only the highest standards of fairness will suffice in
the context of asylum appeals.'

That summary was approved by the Supreme Court in _A: see para [68] of the judgment of Lord Sales and Lord_
Burnett. Point (v) is of particular relevance for our purposes. I return to the actual decision in Detention Action at
para [439] below.
**[*379]**

**[433] Ms Kilroy referred us to a wealth of evidence identifying the difficulties faced by claimants, even if they have**
good legal assistance. It is simplest if I reproduce verbatim, with some minor editing, the summary of that evidence
at paras 23–25 of her skeleton argument.

'23. First, there are a wide range of relevant issues that may be specific to an individual, such as mental or
physical health, family ties in UK, or the need for family reunion once recognised as a refugee, which require
instructions and evidence. Particular difficulties meeting the tight time limits may arise where there is a history
of trauma, including torture, trafficking, and/or sexual or gender-based violence, which makes it difficult to take
full instructions at speed. In addition to inadmissibility and safe third country issues, investigations and
representations must be conducted on more standard issues, such as lawfulness of detention, applications for
bail, trafficking indicators, and NRM referrals, and any age dispute issues.

24. Second, Asylum Aid's evidence [from Toufique Hussain, a solicitor at Duncan Lewis with extensive
experience in this field] was that it was generally not possible to prepare witness statements addressing even
individualised matters relevant to inadmissibility and removal to Rwanda within the seven-day period. As shown
in [tables produced to us showing the timetables for the representations made in these cases], in only one case
was a witness statement served in advance of the initial decisions, and that had to be supplemented later with
further instructions. In all other cases, witness evidence providing relevant individualised information was
produced after removal directions had been set.

25. The Court has recognised the relevance of medical evidence to the decisions in individual cases. Again,
Asylum Aid's evidence showed that it was not possible to obtain medical evidence within a seven-day
timescale. In all the Claimants' cases where medical evidence was produced by the individual (and all but one
when it was produced through a r 35 report) it was only obtained after removal directions were set.'

**[434] Lord Pannick did not seek to address the details of that evidence. As he put it in his submissions, 'seven days**
may or may not be adequate: it depends on the case'. His essential point was that claimants were entitled to ask for
an extension if they needed more time, and that it was the Secretary of State's policy to grant an extension if
reasonable grounds were shown. He pointed out that such extensions had in fact been granted in several of the
Claimants' cases and that if one was unreasonably refused they were entitled to seek judicial review. He
acknowledged that the Notice of Intent makes no reference to the right to seek an extension, nor does it appear in
any guidance to caseworkers. He referred us, however, to para 23 of the witness statement of Mr Ruaridh McAskill,
the Acting Head of the TCU in Glasgow, which reads:

'Where individuals request an extension of time to respond to an NOI these requests are considered on a caseby-case basis taking into account the reasons requested for the extension, how long they have had to respond,
their access to legal representation and whether it would be reasonable to have expected reasons to have
been submitted prior to the extension request. There are no fixed criteria for an extension to be granted or
refused. Factors weighing in favour of an extension of time

**[*380]**

include if someone has not had access to adequate legal advice, if they provide good reasons why they have
not been able to make representations (such as illness, trauma or electronic communication failures); factors
weighing against include if they had the opportunity to instruct legal representatives and chose not to do so


-----

High Commissioner for Refugees intervening) and ot....

Discretion has been used in most cases to extend the time period to respond to the NOI. If an extension is
refused further representations are generally considered.'

Lord Pannick drew attention to the final sentence. The seven-day period did not represent an absolute cut-off, even
where an extension was not sought.

**[435] Lord Pannick submitted that the existence of that policy meant that the process was sufficiently flexible to**
avoid systemic unfairness and accordingly could not itself be said to be unfair or unlawful. He submitted that there
were good reasons why 'the standard period should be as short as seven days'. It was in the public interest that
removal decisions should be made without delay: indeed that was in the claimant's interest also, particularly if they
were in detention.

**[436] In support of his submissions Lord Pannick relied on the decision of this Court in** _R (on the application of_
_Refugee Legal Centre) v Secretary of State for the Home Dept_ _[2004] EWCA Civ 1481, [2005] INLR 236, [2005] 1_
WLR 2219. That case, which is one of the decisions on which Sir John Dyson drew in his summary of the relevant
principles in Detention Action, involved a challenge to the fast-track system for adjudication of asylum claims which
the Secretary of State believed to be clearly unfounded. Under that system the entire process from initial interview
to final decision was compressed into a period of three days, with no opportunity for the claimant to put in further
representations following the interview. The basis of the challenge was that that timetable was quite inadequate for
the preparation of the claimant's case, including in particular any medical or other evidence that might need to be
obtained. A central part of the Secretary of State's answer, as here, was that the system was operated flexibly, so
that if it became clear that a case could not be dealt with fairly within that timetable caseworkers would remove it
from the fast track. This Court believed that the system was defective in the absence of what it described (see para

[18] of the judgment of the Court given by Sedley LJ) as 'a clearly stated procedure – in public law, a policy – which
recognises that it will be unfair not to enlarge the standard timetable in a variety of instances'. It continued, at para

[19]:

'To assert, without any real evidence to support it, that a general principle of flexibility is “deeply ingrained” is
not good enough. Putting the relevant issues in writing – and we assume without question that what is put in
writing will be made public – is not simply a bureaucratic reflex. It will concentrate official minds on the proper
ingredients of fair procedure; it will enable applicants and their legal representatives to know what these
ingredients are taken to be; and if anything is included in or omitted from them which renders the process
legally unfair, the courts will be in a position to say so.'

However, it declined to hold that that defect meant that the policy itself should be declared to be unlawful. As it put it
at para [23]:

'… [P]rovided that it is operated in a way that recognises the variety of circumstances in which fairness will
require an enlargement of the

**[*381]**

standard timetable – that is to say lawfully operated – the … system itself is not inherently unfair. A written
flexibility policy to which officials and representatives alike can work will afford a necessary assurance that the
3-day timetable is in truth a guide and not a straitjacket.'

**[437] The significance of the** _Refugee Legal Centre decision does not depend on comparing the lengths of the_
periods in that case and this, or other details of the two systems. But Lord Pannick relied on it as demonstrating that
there was nothing unlawful in the Secretary of State adopting a standard procedural timetable which would in some
cases not give asylum claimants a fair opportunity to make representations provided that it was also her policy to
allow for departures from the timetable where that was necessary in the interests of fairness. He also noted that the
Court did not regard a failure to promulgate that policy in writing as rendering the system inherently unfair and thus
unlawful.


-----

High Commissioner for Refugees intervening) and ot....

**[438] It was put to Lord Pannick in the course of oral submissions that, notwithstanding the Court's ultimate**
conclusion in the Refugee Legal Centre, it evidently expected that the Secretary of State would develop and publish
its flexibility policy: it said at para [25] that it had 'indicated what in our view needs to be done to obviate [the risk of
injustice]'. He was asked whether he accepted that the Secretary of State ought now to publish as a policy the
approach which was said by Mr McAskill to operate in practice, and to refer to it in the Notice of Intent. He was not
prepared to accept that proposition in those terms, arguing that published policies specifying detailed criteria were
sometimes positively disadvantageous as encouraging a tick-box approach; the most that he would say was that
when there had been some more experience of the system the Secretary of State might think it desirable to publish
some guidance about the basis on which extensions should be granted.

**[439] Ms Kilroy in her reply submitted that the practice of granting extensions could not justify a standard timetable**
which on the evidence was too short in every case. She countered Lord Pannick's reliance on the Refugee Legal
_Centre case by referring us to the decision in Detention Action. That case raised a challenge to the fairness of the_
Fast Track Rules introduced in the Immigration and Asylum Chamber of the First-tier Tribunal, which required
asylum-seekers to prepare and present their appeals within seven days of the refusal of their claim. The Court
found that that timetable was so tight that it was inevitable that a significant number of appellants would be denied a
fair opportunity to present their cases. The response of the Lord Chancellor, as the rule-maker, was that r 14 of the
Fast-Track Rules provided that if the Tribunal was satisfied that the case could not justly be decided within those
timescales it must disapply those Rules. The Court did not accept that that was an adequate safeguard, essentially
because the procedural structure created constraints which would make it very difficult in practice for appellants to
make an application under r 14 or for the Tribunal to accede to it: see paras [42]–[44] of the judgment of Sir John
Dyson.

**[440] I have not found this issue entirely easy, but in the end I have concluded that the seven-day period specified**
in the Notice of Intent does not render the decision-making process 'structurally unfair and unjust', to adopt the
language of Sir John Dyson in _Detention Action; and I would accordingly dismiss ground 17. My reasons are as_
follows.

**[441] The evidence clearly establishes, and it is in any event obvious as a matter of common sense and**
experience, that in many cases it will indeed be
**[*382]**

impossible for claimants to submit effective representations within seven days of receipt of a Notice of Intent, even if
they have ready access to legal assistance and only wish to make representations on matters specific to their
particular circumstances. But I do not believe that it establishes that it will be impossible in every case. Not every
case, for example, will require the submission of medical evidence; nor in every case will there be a factual basis for
a claim of exceptional circumstances under para 345A(b)(ii). It cannot be assumed that the Claimants' cases are
representative of the range of cases in which Notices of Intent in relation to relocation to Rwanda might be served:
quite apart from the possibility of selection bias in those who brought proceedings and whose cases were heard by
the Divisional Court, the process of identifying issues and gathering evidence is likely to be more uncertain and
require more consideration when dealing with a newly-applied policy. Even if – as I accept may well be the case –
the limit is too short in the majority of cases, it is impossible to assess the relative proportions. In short, I agree with
Lord Pannick's laconic summary that seven days may or may not be adequate.

**[442] That being so, I see nothing wrong in principle in the Secretary of State imposing a 'base-line' timetable which**
is realistic at least in the most straightforward cases and allows those cases to be decided promptly, provided that
she is ready and willing to grant extensions in those cases where more time is reasonably required. I do not believe
that it is inherently unfair to employ a model where there is a minimum period available to all claimants to make
representations, together with consideration of what longer period may be required in particular cases. There is, as
Lord Pannick submitted, an important public interest in decisions on removals under the MEDP being made – one
way or the other – as expeditiously as is consistent with fairness. Seven days is no doubt the shortest realistic
period, but a deadline of, say, fourteen or twenty-one days would very likely still require extensions in some cases
and would mean that decisions were delayed in others for a longer period than was necessary or desirable.


-----

High Commissioner for Refugees intervening) and ot....

**[443] That puts the focus on the Secretary of State's policy of flexibility. For the reasons given by Sedley LJ in the**
_Refugee Legal Centre case, I do not think it is good enough that that policy is not formally published in the form of_
guidance to caseworkers nor referred to in the Notice of Intent. Claimants and their advisers need to know that the
seven-day timetable can be extended where that is shown to be necessary in the interests of fairness. I do not
accept Lord Pannick's submission that publication of formal guidance may do more harm than good: there should
be no risk of a tick-box approach if the guidance (which need not be elaborate) is expressed in appropriately flexible
terms. It is also in my opinion important that the guidance makes it clear that the seven-day period should not be
treated as a norm and that the grant of extensions is not necessarily exceptional. It may be that if experience shows
that extensions are required in a very large number of cases, the Secretary of State might wish to consider
providing for a rather longer base-line period; but that must be a matter for her.

**[444] I should make it clear that I should not be taken to be endorsing the Secretary of State's current policy in the**
precise terms given by Mr McAskill, which were not the subject of submissions before us, beyond recording an
observation by Ms Kilroy that they contained no specific reference to the overriding requirement of fairness. It must
ultimately be a matter for the Secretary of State how she chooses to formulate any guidance which she may give.
**[*383]**

**[445] Although for that reason I believe that this aspect of the decision-making process requires improvement, it**
follows from the approach of this Court in the Refugee Legal Centre case that that does not justify a declaration that
the process is unlawful. I do not believe that that conclusion is inconsistent with _Detention Action. The crucial_
feature in that case was that the power ostensibly available to the Tribunal under r 14 was in reality highly
constrained.
Ground 18: Disclosure of Provisional Conclusions

**[446] At para [389] of its judgment the Divisional Court said:**

'Contrary to the submission made by some of the Claimants, fairness did not require that the Claimants have
the opportunity to make representations in response to some form of provisional view that such circumstances
existed. What fairness requires in the context of a decision under paragraph 345A(iii)(b) of the Immigration
Rules is an opportunity for the Claimant to provide any explanation he has for not making an asylum claim
before reaching the United Kingdom. Fairness did not require the opportunity to make representations in
response to the Home Secretary's evaluation (or provisional evaluation) of that explanation.'

**[447] Ground 18 reads:**

'The court is wrong to conclude that the common law does not require individuals to have access to the
SSHD's provisional conclusions against them.'

In its skeleton argument Asylum Aid makes clear that the challenge in ground 18 is to para [389] of the Divisional
Court's judgment, as quoted above. It refers to various authorities which establish, as Lord Mustill put it in Doody
[([1993] 3 All ER 92 at 108, [1994] 1 AC 531 at 563), that 'the right to make representations is of little value unless](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60GY-00000-00&context=1519360)
the maker has knowledge in advance of the considerations which, unless effectively challenged, will or may lead to
an adverse decision'.

**[448] In her skeleton argument in response the Secretary of State pointed out that the Notice of Intent informed**
claimants that she was considering whether it was reasonable to expect them to have claimed protection in the
specified countries through which they had passed and that put them sufficiently on notice of the need, if they could,
to advance reasons why that was not the case.

**[449] In her oral submissions Ms Kilroy made it clear that because of the pressure of time she largely relied on the**
contents of Asylum Aid's skeleton argument; such short points as she did make did not substantially develop what
appears there. Lord Pannick did not make any oral submissions. That being so, I need only say that I accept the
Secretary of State's submission and would dismiss this ground.


-----

High Commissioner for Refugees intervening) and ot....

**[450] I should clarify one related point. I have concluded that ground 15 is well-founded. We did not, however, hear**
any submissions on the specific question of what, if any, information over and above what the Secretary of State
published in the MoU and the CPINs she was obliged to provide in order to give the Claimants a fair opportunity to
make representations on the safety of Rwanda; and I accordingly say nothing about that question. I would,
however, observe that the materials which were in fact disclosed in these proceedings appear sufficient to satisfy
any such obligation as there may have been.
**[*384] Ground 19: Access to Justice**

**[451] It was part of Asylum Aid's case that the inadequacy of the time given for representations had a knock-on**
effect on the adequacy of the standard five-day notice given in removal directions: see para [385](5) of the
Divisional Court's judgment. The Court addressed that submission at para [420] of its judgment, where it said:

'One point to note in the present case is that the access to court submission is parasitic on the unfair system
submission. Ms Kilroy accepted that if the period permitted for representations before the decisions was lawful,
then removal directions within the standard form would be lawful.'

**[452] Ms Kilroy told us that that did not accurately reflect what she had said to the Court; but, irrespective of**
whether in fact she made the concession attributed to her it seems to us to be plainly right. At paras 29–32 of its
skeleton argument (which Ms Kilroy did not, again for reasons of time, significantly amplify in her oral submissions)
Asylum Aid argues that the dismissal of its case on the other grounds makes ground 19 unanswerable because if
there has been inadequate opportunity to make representations prior to the removal decision claimants will need
longer than five days to issue Court proceedings. But that depends on the basis on which the other grounds failed.
If, for example, I had accepted the Divisional Court's statement that it was unnecessary for claimants to have
access to legal advice prior to a decision on removal under the MEDP, there would be force in the point that five
days was an inadequate time to find and instruct a lawyer from scratch and to bring legal proceedings. But my
conclusion on ground 17 means that the system has sufficient flexibility to ensure that claimants will in fact have
adequate time to make effective representations (ignoring aberrant decisions, which can only be addressed on a
case-by-case basis). If that is the case, the claim based on a systemic denial of access to justice does indeed fall
away.

**[453] I would accordingly dismiss ground 19.**
Ground 20: Construction of the Immigration Rules

**[454] Ground 20 reads:**

'The Court's analysis of the Immigration Rules and para. 17 of Schedule 3 to the 2004 Act is flawed.'

Asylum Aid's essential contention is that the distinction drawn by the Divisional Court, in connection with the 'Scope
of Representations' issue, between head (i) and heads (ii)–(iv) under para 345B does not properly reflect the
requirements of the Refugee Convention and is inconsistent with the approach required of the Secretary of State in
making a certificate under para 17 of Sch 3. It is thus not a distinct ground but a further argument in support of
ground 15. Since I have accepted Ms Kilroy's point on ground 15 for other reasons I need say no more about it.
Conclusion on Asylum Aid's Appeal

**[455] I do not accept all aspects of the reasoning of the Divisional Court on the issue of whether the decision-**
making process was inherently unfair, as is reflected in my conclusions on grounds 15 and 16. But, as I have said,
the
**[*385]**

determinative ground from the point of view of the fairness of the process is ground 17. Since I would dismiss that
ground I believe that the Court was right to reject the claim of inherent unfairness, and I would dismiss Asylum Aid's
appeal.
RM's Ground on Fairness


-----

High Commissioner for Refugees intervening) and ot....

**[456] Ground 22, which is pleaded in some detail, raises both a general challenge to the fairness of the Secretary of**
State's decision-making process as regards relocation to Rwanda and a specific challenge to its conclusion that in
his particular case (unlike those of most of the other Appellants) the inadmissibility decision did not fall to be
quashed. The pleaded criticisms were developed at paras 11–36 of RM's skeleton argument, but in his oral
submissions Mr Drabble (who was also under some pressure of time) did no more than refer us to the fact that the
skeleton argument contained a procedural chronology of his particular case which he invited us to read as
illustrating with particularity why seven days would almost never give enough time for proper submissions to be
made.

**[457] In the version of this judgment handed down (subject to editorial correction) on 29 June, I did not refer**
specifically to ground 22, and in post-judgment submissions counsel have asked for clarification as to whether the
intention was that it should be dismissed. I should confirm that that is indeed the Court's intention. RM's general
challenge raises no points that I have not considered in relation to Asylum Aid's appeal. As regards the decision in
his particular case, the Divisional Court gave reasons at paras [357]–[358] of its judgment why the inadmissibility
decision of 5 July 2022 was not unfair. That specific reasoning is not addressed either in ground 22 itself or in RM's
skeleton argument, and I can identify no error of law in it. I should note that RM did in fact make further submissions
on 9 July, addressed to the question why he had not claimed asylum in France: those will no doubt be carefully
considered by the Secretary of State if the issue of relocation to Rwanda becomes live in his case.

**LORD BURNETT CJ.**

**[458] These appeals concern the lawfulness of the Home Secretary's decisions to remove to Rwanda a cohort of**
people who arrived irregularly in the United Kingdom by small boats across the English Channel and then claimed
asylum. There are ten individual appellants, all single men, whose countries of origin are Syria, Iran, Iraq, Vietnam,
Sudan and Albania. To qualify for removal, it must have been reasonable for them to have claimed asylum in a safe
country on the way. All arriving by small boats across the Channel have necessarily been in a safe third country but
it may not be reasonable for all to claim asylum there. The claimants would be free to claim asylum in Rwanda. We
are not concerned with the political merits of the underlying policy.

**[459] The appeals relate to generic claims which contend, for a variety of reasons, that it would be unlawful for the**
Home Secretary to remove anyone from the United Kingdom to Rwanda. The individual circumstances of the
claimants play no part in their arguments. Before the Divisional Court of the High Court the individual appellants
(and others) also raised challenges based upon the circumstances in which their individual cases were considered
by the
**[*386]**

Home Office. Many were successful in those challenges with the consequence that new decisions will need to be
taken on the individual cases whatever the outcome of these appeals on generic issues. The proceedings were
issued between 8 and 14 June 2022. The evidence upon which the Divisional Court decided the issues was filed
over the course of the summer of 2022. We have considered the appeal on the same evidence which, in
consequence, is now out of date.

**[460] Asylum Aid was also a claimant for judicial review before the Divisional Court. Its core submission is that the**
procedures surrounding the decision making and proposed removals are unfair and thus unlawful. It appeals the
Divisional Court's dismissal of its claim.

**[461] The judgment of the Divisional Court was handed down on 19 December 2022 following hearings in**
[September and early October: Lewis LJ and Swift J [2022] EWHC 3230 (Admin), [2022] All ER (D) 59 (Dec). By its](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6748-KD53-GXF6-82PV-00000-00&context=1519360)
orders the court dismissed the generic claims for judicial review. There has been no appeal by the Home Secretary
in respect of the individual decisions.

**[462] At the heart of the claims for judicial review is the proposition that it would be unlawful to remove anyone to**
Rwanda because there are 'substantial grounds for believing that they would be at real risk' of treatment in Rwanda


-----

High Commissioner for Refugees intervening) and ot....

contrary to art 3 of the European Convention on Human Rights ('ECHR'). That is the well-known test first articulated
[by the Strasbourg Court in Soering v UK (App no 14038/88) (1989) 11 EHRR 439, [1989] ECHR 14038/88 (at para](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)
88 _et seq) in the context of an extradition case. It was soon applied to removal cases generally. The_ _Soering_
argument in these appeals has two components which make up the 'safe country' issue. First, the appellants submit
that the conditions that they would face in Rwanda would give rise to the relevant risk. Secondly, they submit that
defects in Rwanda's consideration of asylum claims would give rise to a risk of good claims being refused and the
further risk that Rwanda would return individuals (refoule in the language of the 1951 Refugee Convention) to the
countries from which they claimed protection.

**[463] The principal decision of the Strasbourg Court dealing with that test in cases of removal of asylum seekers by**
[an ECHR state to another state it considers safe is Ilias v Hungary (App no 47287/15) (2019) 47 BHRC 497, (2020)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y49-BT73-GXFD-8139-00000-00&context=1519360)
71 EHRR 6.

**[464] It is the second aspect of the art 3 issue that was the focus of argument before us. On that second aspect the**
task of the Divisional Court was to determine whether deficiencies in the Rwandan system for dealing with asylum
applications are such that there are substantial grounds for believing that they would face a real risk of being
returned to their countries of origin despite having a valid claim for asylum.

**[465] The claimants, supported by the United Nations High Commissioner for Refugees ('UNHCR'), submit that**
such grounds remain despite the bespoke agreement reached between the Government of the United Kingdom and
the Government of Rwanda, known as the Migration and Economic Development Partnership ('the agreement').
The agreement is contained in a Memorandum of Understanding ('MoU') dated 14 April 2022 and diplomatic Notes
_Verbales which provide guarantees by Rwanda regarding 'the asylum process of transferred individuals' and 'the_
reception and accommodation of transferred individuals' respectively. The position of the claimants and the UNHCR
is that the system for dealing with asylum claims in Rwanda is such that the
**[*387]**

aspirations set out in these documents are undeliverable for any person seeking asylum there, including the 11
claimants involved in this appeal. It also entails the proposition that the proposed monitoring arrangements which
are designed to ensure that Rwanda deals with asylum applicants appropriately with no relevant risk of refoulement
for those with valid claims are likely to be ineffective.

**[466] It is the opinion of His Majesty's Government that Rwanda will comply with the terms of the agreements and**
abide by the assurances it has given. The intense scrutiny upon those who would be sent to Rwanda coupled with
the monitoring mechanisms contained in the agreement and those of the British High Commission in Kigali, with
embedded Home Office officials, provide additional and necessary safeguards. The UNHCR disagrees, believing
that the asylum system in Rwanda does not have the capacity to deliver consistently accurate and fair asylum
decisions and that there is a concomitant risk that some refugees will not be recognised as such and will be subject
to _refoulement. Capacity in this sense is not concerned only with the number of asylum seekers who arrive in_
Rwanda but the ability of the various parts of the system there to deliver reliable decisions on their applications.

**[467] The evidence in support of the claims for judicial review was largely provided by the UNHCR through**
Lawrence Bottinick, Senior Legal Officer and Acting Representative for the UNHCR in London, expressing an
institutional view. The evolution of the evidence was unusual in that it joined issue with the British Government point
by point, with exchanges of evidence. The UNHCR, an interested party in these proceedings, assumed the mantle
of claimant. That is not to criticise it but to draw attention to the unusual nature of its engagement in these claims.
Moreover, the UNHCR made clear that it is opposed as an institution to any attempt 'to offshore' asylum claims in
the manner contemplated by the agreement in question. It has an institutional interest in the outcome of these
claims for judicial review. It nonetheless has unrivalled practical experience of the working of the asylum system in
Rwanda through long years of engagement.

**[468] Rwanda is a country which has emerged from one of the most shocking and destructive periods of violence in**
recent history. Ethnic rivalry led to genocide in 1994 when over 500,000 Tutsi were murdered by Hutu. Many Hutu


-----

High Commissioner for Refugees intervening) and ot....

were also murdered and estimates of the total death toll are much greater. There was protracted violence thereafter
before stability was restored. The ethnic violence in Rwanda had a long history and erupted repeatedly in the
second half of the twentieth century. This is not the place for even a short description. Following the 1994 genocide
the International Criminal Tribunal for Rwanda was established. It gave a relatively short account of the genocide in
its first judgment delivered on 2 September 1998 (Akayesu ICTR-96–04) to which reference might be made. The
government which emerged after the genocide has been the subject of much criticism for its human rights record.
The region has been unstable for decades with large population movements. Rwanda has received hundreds of
thousands of refugees from the Democratic Republic of Congo and Burundi (according them refugee status prima
_facie, rather than considering individual circumstances) and has worked with the UNHCR to house and support_
those refugees. It has also worked with the UNHCR to provide sanctuary for over 500 refugees from Libya while the
UNHCR decides their asylum claims and seeks to resettle them. For all this the UNHCR gives the Government of
Rwanda credit. But it is critical of the way in which individual asylum claims have been dealt with hitherto and
considers
**[*388]**

that the aspirations in the agreement between the two governments are unachievable at present. They will require,
in particular, changes in attitude and training which are not yet in place.

**[469] The UNHCR does not question the good faith of the Government of Rwanda. In my view, there is nothing in**
the materials before the Divisional Court which credibly questions that good faith or the genuine determination of
Rwanda to deliver its side of the agreement reached with the British Government. Similarly, there is no suggestion
that the British Government will do other than seek to ensure that Rwanda will deliver on the agreement.

**[470] At the heart of this issue, therefore, is whether, despite the efforts of both Governments and the protections**
built into the agreement, the relevant risk of bad decision making and subsequent refoulement remains. This calls
for an evaluative exercise where past relevant events inform the evaluation and must be coupled with judgements
about good faith, intentions to deliver, the capacity of the system to deliver and the effect of monitoring. Good faith
and intentions to deliver fall squarely within an assessment of the value of these diplomatic assurances. Capacity
issues are perhaps hybrid, falling within diplomatic assessment and also more straightforward questions of fact.
There are questions about whether the will of the central Government of Rwanda will be effective in dictating the
approach and conduct of officials down the chain. There must also be consideration of the practicalities of removing
someone from Rwanda to their home country (assuming a 'wrong' asylum decision). None of the appellants has a
passport and Rwanda has no arrangements in place for returns to the countries from which any of these appellants
hails. If sent to Rwanda each will travel on a British document for that purpose alone.

**[471] The Divisional Court has been criticised for saying that it would need 'compelling' evidence to differ from the**
evaluation of the British Government. I think that description is apt to describe the approach of a court to the
evaluation of a diplomatic assurance. The worth of a diplomatic assurance calls for an exercise of judgement in
which the government has expertise and access to advice which a court does not have. A court is not institutionally
well-equipped to make such a judgement. The situation is analogous to assessments of risks to national security
where a court is slow to differ from the assessment of the government: _Secretary of State for the Home Dept v_
_Rehman_ _[2001] UKHL 47,_ _[[2002] 1 All ER 122, [2003] AC 153([50]);](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61NX-00000-00&context=1519360)_ _R (on the application of Begum) v Special_
_Immigration Appeals Commission, R (on the application of Begum) v Secretary of State for the Home Dept, Begum_
_v Secretary of State for the Home Dept_ _[2021] UKSC 7,_ _[[2021] 2 All ER 1063, [2021] AC 765([70] to [71]). But](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62V6-0DF3-GXFD-852C-00000-00&context=1519360)_
where the assessment of future conduct engages practical considerations which arise from past conduct the
position is not as stark. In this case there is very detailed evidence of the way in which the Rwandan asylum system
has operated when considering individual claims before the summer of 2022. There were undoubted deficiencies.
Whether they are capable of being made good is not an issue on which the government has special institutional
expertise.

**[472] This evaluative exercise of assessing future risk does not require the resolution of all conflicts of evidence**
between the Government of Rwanda and the UNHCR in the sense of deciding on the balance of probability whether


-----

High Commissioner for Refugees intervening) and ot....

something did or did not happen. That is in any event impractical in the context of this litigation for at least two
reasons. There is material before the court from Rwanda provided to the British Government in answer to questions
**[*389]**

designed to counter concerns raised by the UNHCR. The Government of Rwanda is not a party to these
proceedings nor, diplomatically, could it be expected to engage as if it were a litigant. Moreover, there is no
practical way to test the evidence in these proceedings, still less to explore ambiguities in language and the like
which were drawn to our attention. But it would not be the correct approach when evaluating a future risk of this
nature.

**[473] The approach to evaluating the ultimate relevant future risk, which is of** _refoulement, is analogous, but not_
identical, to the evaluation of the risk under consideration in _Rehman. That case concerned the evaluation of_
whether a person's presence in the United Kingdom constituted a risk to national security. Such an evaluation did
not depend upon a point-by-point consideration of past events by reference to a standard of proof: Lord Hoffmann
at [55].

**[474] Before turning to the issues which arise in this appeal it is, in my view, necessary to consider what the**
Divisional Court (and in turn this court) was being asked to determine on the 'safe country' issue. Mr Husain KC,
who appeared as the principal advocate for the appellants on this issue, recognised that the proposition being
advanced on their behalf was that it was not safe for anybody to be sent to Rwanda. All would face the relevant
risks irrespective of the number removed or their personal makeup. But the arguments both before us and the
Divisional Court at times became confused by the introduction of issues which were hypothetical and moved far
from the consideration of a single generic case or the concrete cases represented by these appellants. For
example, in much of the political hyperbole which surrounded the announcement of the Rwanda policy there was
talk of Rwanda, within a few years, being a destination for thousands of asylum seekers who arrived irregularly in
the United Kingdom. The UNHCR evidence questions whether Rwanda can cope with the volumes apparently
contemplated. Yet the evidence before the Divisional Court was that the physical capacity for housing asylum
seekers in Rwanda was limited to 100; that of the 47 originally identified for removal the Home Office expected in
fact to remove about 10; and that the starting point for any removal under the agreement was for the two
governments to agree who would be sent to Rwanda. That would be determined by the capacity of the Government
of Rwanda to receive and process the individuals concerned. It also gave the Government of Rwanda complete
control so that they might reject any proposed name.

**[475] The Divisional Court was not considering whether it is 'safe' for Rwanda immediately to receive substantial**
numbers. Similarly, the voluminous papers in this case identify hypothetical special problems it is said that some
groups of people would face. But we are not considering whether it would be 'safe' for every conceivable type of
person to be sent to Rwanda. For example, the UNHCR have provided evidence which suggests that were
nationals of an unnamed country with which Rwanda has close relations to seek asylum it is unlikely they would
ever receive it. It is not difficult to deduce the identity of that country. Were the British Government unwise enough
to seek to remove any such nationals to Rwanda, and were Rwanda improbably to agree to accept them, they
would have strong legal grounds to resist. The UNHCR also raised concerns about gay and lesbian asylum seekers
in Rwanda. We are not concerned, and nor was the Divisional Court, to determine whether, hypothetically, there
may be individuals bearing particular characteristics who would face the relevant risks in Rwanda.
**[*390]**

**[476] The argument of the appellants before the Divisional Court was, that in respect of each of them, there were**
substantial grounds for believing that there was a real risk that they would be returned to their home countries after
a wrong refusal of asylum in Rwanda. They also suggest a relevant risk of art 3 ill-treatment in Rwanda itself. They
submit that the same risks would attach to anyone sent to Rwanda irrespective of any personal characteristics. That
encapsulates the core safety issue in these proceedings.
**The Issues on the Appeal**


-----

High Commissioner for Refugees intervening) and ot....

**[477] There is a multitude of grounds of appeal on which permission to appeal has been granted and one**
(concerning data protection) where the Divisional Court's refusal to grant permission to apply for judicial review is
the subject of an application for permission to appeal. They break down into the following categories:

(i)   Did the Divisional Court apply the right test when deciding the art 3 issues (answering for itself
whether the relevant substantial grounds existed) or did it apply a domestic public law approach by asking
whether the Home Secretary was entitled to conclude that art 3 would not be breached by the claimants'
removal to Rwanda? (Master of the Rolls issue 1)

(ii)   Was the Divisional Court wrong to reject the contention that there are substantial grounds to believe
that there is a real risk that the claimants would be refouled from Rwanda despite being genuine refugees?
(Master of the Rolls issues 2 to 7)

(iii)   Was the Divisional Court wrong to reject the contention that there are substantial grounds to believe
that the claimants are at real risk of facing treatment contrary to art 3 while in Rwanda? (Master of the Rolls
issues 2 to 7)

(iv)   Was the Divisional Court wrong to conclude that the British Government has sufficiently explored the
likelihood of refoulement from Rwanda both in terms of ECHR law (Ilias) and domestic law (Secretary of
_State for Education and Science v Metropolitan Borough of Tameside_ _[[1976] 3 All ER 665, [1977] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD8-PGP0-TWP1-612D-00000-00&context=1519360)_
1014)? (Master of the Rolls issues 8 and 9)

(v)   Was the Home Secretary's policy unlawful when viewed against the test identified in the Supreme
Court in R (on the application of A) v Secretary of State for the Home Dept _[[2021] UKSC 37, [2022] 1 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HY-3H43-GXF6-833F-00000-00&context=1519360)_
_[ER 177, [2021] 1 WLR 3931applying Gillick v West Norfolk and Wisbech Area Health Authority [1985] 3 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HY-3H43-GXF6-833F-00000-00&context=1519360)_
_[ER 402, [1986] AC 112? (Master of the Rolls issue 10)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-607K-00000-00&context=1519360)_

(vi)   Was the Divisional Court wrong to conclude that the Home Secretary acted lawfully in using the
power in para 17 of Pt 5 of Sch 3 to the Asylum and Immigration (Treatment of Claimants, etc.) Act 2004 to
certify Rwanda as a safe third country, because she was entitled to conclude that persons would not be
subjected to treatment in Rwanda prohibited by the Refugee Convention or refouled if they were indeed
refugees? A second argument advanced by the appellants is that the power is inapt to create a
presumption that a country is safe and that the Home Secretary should have sought Parliamentary
approval by laying a Statutory Instrument as provided for by that Act. (Master of the Rolls issues 11 and
14)

**[*391]**

(vii)   Was the Divisional Court wrong to conclude that the Home Secretary was entitled to certify the
individual human rights claims as clearly unfounded on the basis that Rwanda is a safe third country?
(Master of the Rolls issue 11)

(viii)   Was the Divisional Court wrong in finding that the Home Secretary's policy did not breach the
prohibition on refoulement under art 33 of the Refugee Convention? (Master of the Rolls issue 12)

(ix)   Was the Divisional Court wrong to conclude that the removal of individuals to Rwanda did not
constitute a penalty for the purposes of art 31 of the Refugee Convention? (Master of the Rolls issue 12)

(x)   Was the Divisional Court wrong to conclude that _[Council Directive 2005/85/EU on minimum](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9RF3-GXFD-80J9-00000-00&context=1519360)_
standards in member states for granting and withdrawing refugee status ('the Procedures Directive') was
not part of retained EU Law? Article 27(2)(a) of that directive requires there to be a connection between a
person seeking asylum and a safe third country to which it is proposed to send him. None of the claimants
has a connection with Rwanda. (Master of the Rolls issue 13)

(xi)   Was the Divisional Court wrong to reject the argument that procedures surrounding the identification
of individuals for removal to Rwanda, in particular the seven-day time limit for making representations as to
why removal to Rwanda would be inappropriate, is systemically unfair and thus unlawful? (Master of the
Rolls issue 16)


-----

High Commissioner for Refugees intervening) and ot....

(xii)   Was the Divisional Court wrong to refuse permission to apply for judicial review on the basis that the
scheme necessarily breaches data protection law? (Master of the Rolls issue 15)

**Summary of Conclusions**

**[478] I have had the advantage of reading in draft the judgment of Underhill LJ and agree, for the reasons he gives,**
in respect of issues (vi) and (viii) to (xii) as I have identified them above. I shall not burden this judgment with any
further discussion of those issues. On several issues, however, it is my misfortune to differ in my conclusion from
both the Master of the Rolls and Underhill LJ.

**[479] First, on whether the Divisional Court applied the wrong test when considering the safety of Rwanda on the**
_refoulement issue. Secondly, on whether there are substantial grounds for believing that an asylum seeker sent to_
Rwanda would face a real risk of refoulement following a flawed decision. Thirdly, with the Master of the Rolls, on
whether there are substantial grounds for believing that a removed asylum seeker would be at real risk of art 3 illtreatment in Rwanda. In my view, the Divisional Court did not err in the way suggested and the relevant risks are
not established on the evidence. It follows that I do not consider that the underlying policy is unlawful in a Gillick
sense. Moreover, I agree with the Divisional Court that the posited removals, and the underlying policy, are not
unlawful for want of investigation either in accordance with Ilias or Tameside.

**[480] On issue (vii), the Master of the Rolls and Underhill LJ have concluded that the Secretary of State was wrong**
to certify the individual claims on the basis that Rwanda is a safe third county. Their conclusion followed inevitably
from their ruling that Rwanda is not a safe third country. Despite having reached the contrary conclusion on the
central issue of safety I nonetheless agree that these claims should not have been certified. The whole question of
**[*392]**

safety, as our judgments demonstrate, is contestable. For the reasons given by Underhill LJ at [130] I agree that
this conclusion does not affect the outcome of these appeals.
**The Divisional Court's Judgment on the article 3 and Allied Public Law Issues**

**[481] The first issue arises from grounds of appeal that suggest that the Divisional Court made a fundamental error**
in its approach to the art 3 ECHR question. It failed to appreciate that it was for the court to make the judgement
about whether there are substantial grounds for believing that the claimants would be at real risk of treatment
contrary to art 3 through being returned to their countries of origin having been wrongly refused asylum. Instead, it
is argued that the court applied the conventional domestic public law test by asking whether the Home Secretary
was entitled to come to the conclusion that Rwanda was safe for these purposes. As Lewis LJ observed when the
point was raised at the hearing which dealt with permission to appeal:

'… paragraph 45 of the judgment said that the issue was whether the [Home Secretary] could lawfully reach
the conclusion that the arrangements governing relation to Rwanda would not give rise to a risk of refoulement.
The [Home Secretary] could only do that if there was no risk. That is the issue the court then considered from
paragraphs 46 to 71.'

In that passage Lewis LJ was using 'risk of refoulement' as shorthand for 'substantial grounds for believing there is
a real risk'.

**[482] It would indeed be remarkable if the Divisional Court failed to appreciate that its function, when considering**
art 3 risks (both arising from refoulement and conditions in Rwanda itself), was to make an assessment for itself. It
could properly be described as the most basic of errors in an ECHR based claim. It would be all the more
remarkable given the composition of the court. In my view, a reading of the judgment dealing with these issues as a
whole demonstrates that no such error was made.

**[[483] In the introductory section of its judgment at [4] the court referred to s 6 of the Human Rights Act 1998. That](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)**
requires public authorities to act compatibly with the ECHR. It is axiomatic that where s 6(1) of the Human Rights
Act applies, it is unlawful for the Home Secretary to act in a way which is incompatible with an ECHR right. In
judicial review proceedings challenging a removal decision on the basis that it is contrary to s 6 because the


-----

High Commissioner for Refugees intervening) and ot....

claimant will be subjected to a violation of his art 3 ECHR rights, it is for the court to determine whether or not the
decision would result in such a violation. The court will have due regard to the evaluation of the decision maker and
be sensitive to matters such as institutional competence in making evaluative judgements about the future where
that feature is present. The reference to s 6 suggests that the Divisional Court was approaching the issue on the
correct basis.

**[484] Having set out the factual and legal background the court sought to identify the issues it was required to**
determine. It was faced with a plethora of disparate and overlong pleadings and skeleton arguments. The parties
had themselves been unable to agree a coherent list of issues. At [39] the court distilled the issues to 12. The first
issue began:
**[*393]**

'The Home Secretary's conclusion that Rwanda is a safe third country is legally flawed. The Claimants' primary
contention is that this assessment is contrary to article 3 of the ECHR. This rests on: (a) the decision of the

[Strasbourg Court] in [Ilias] that a state cannot remove an individual asylum-seeker without determining his
asylum claim unless it is established that there are adequate procedures in place in the country to which he is
to be removed that will ensure that the individual's asylum claim is properly determined and he does not face a
risk of refoulement to his country of origin; (b) the submission that the removal of the individual Claimants to
Rwanda will put them at real risk of article 3 ill-treatment (in breach of the principle recognised in Soering …)
and (c) the contention that, systemically, it is inevitable that the policy to remove asylum claimants will lead to
occasions when a person will be subjected to article 3 ill-treatment.'

The art 3 issue is correctly stated in points (a) and (b). The third point is the Gillick issue. The court then added that
the same points were argued on conventional judicial review grounds. It continued, in summarising issue 2, to note
that the central contention was that the asylum claims would not be determined effectively thereby running the risk
of refoulement, directly or indirectly. It recorded the way in which the case was put, namely that the Home Secretary
could not have confidence that Rwanda would comply with the agreement reached or abide by its assurances.

**[485] The court returned to these issues at [43] to [45]. At [43] it repeated the claimants' primary submission that**
the Home Secretary's conclusion that Rwanda is a safe country was legally flawed. That was put by the claimants
in several ways. First, it 'amounts to a breach of article 3 … for the reasons explained' in _Ilias 'namely that the_
asylum claims … would not be effectively determined in Rwanda and the asylum claimants run a risk that they will
be refouled directly or indirectly …'; secondly, that the Home Secretary failed to comply with the Tameside duty and
made her decision on material errors of fact; thirdly that the decision to treat Rwanda as a safe third country was
irrational; and fourthly that the Rwanda policy was unlawful in the sense explained in _Gillick 'in that it positively_
authorises or approves removals that would be in breach of article 3 … (ie exposes persons to a real risk of article 3
ill-treatment)'.

**[486] In this paragraph the court is referring to two different types of argument – one relying upon art 3 and the**
other upon conventional public law principles. In [44] the court noted that it was also argued that the claimants
would face a real risk of ill-treatment in Rwanda and that to remove them there 'would be in breach of article 3 … in
the sense of the Soering principle because there are reasonable grounds for believing that if a person is removed to
Rwanda that will expose him to a real risk of article 3 ill-treatment because of the conditions in Rwanda'. In [45] the
court repeated the formula whether the 'Home Secretary could lawfully reach the conclusion that the arrangement
governing relocation to Rwanda would not give rise to a real risk of refoulement or other ill-treatment contrary to
article 3'.

**[487] The way in which the case was argued before the Divisional Court, as indeed it was before us, focused on**
_Ilias not simply for the proposition that if there were substantial grounds for believing that there would be a real risk_
of refoulement then removal to Rwanda would breach art 3. Ilias is also relied upon to support the submission that
there is a free-standing procedural
**[*394]**


-----

High Commissioner for Refugees intervening) and ot....

obligation of investigation under art 3 ECHR which, if not satisfied, would render removal unlawful in art 3 terms
even if it could be shown that such reasonable grounds for belief did not in fact exist.

**[488] The court dealt with questions of investigation, whether under art 3 or** _Tameside, risk of_ _refoulement and_
adequacy of the Rwandan asylum system (in the light of the Migration and Economic Development Partnership)
under a single heading: Was the assessment that Rwanda is a safe third country legally flawed? That entailed
resolving issues both by reference to the ECHR and s 6 of the Human Rights Act as well as applying conventional
public law principles. Having considered the question of investigation and inquiries ([46] to [61]) the court turned to
the adequacy of the Rwandan asylum system. The first sentence in [62] is criticised:

'Next we consider whether the Home Secretary was entitled to conclude that there were sufficient guarantees
to ensure that asylum-seekers relocated to Rwanda would have their asylum claims properly determined there
and did not run a risk of refoulement in accordance with the obligations in Ilias and that Rwanda was a safe
third country in accordance with the criteria in paragraph 345B(ii) to (iv) of the Immigration Rules.'

**[489] That long sentence is capable of being read in different ways with the words 'entitled to conclude' governing**
all that follows or only part of it. Additional punctuation would have assisted. But the obligations on the state
identified in _Ilias do not depend upon a Government forming a tenable view, but a correct view. They have an_
objective element. Moreover, para 345B, which is designed to ensure compliance with the ECHR and Refugee
Convention, is couched in terms of the objective establishment of various criteria, and not qualified by 'if the
Secretary of State is of the opinion' or similar words. In reading this part of the judgment it should not be forgotten
that the court was considering both art 3 and conventional public law challenges in tandem because that is the way
they were argued. The term 'legally flawed' covered both. Moreover, this paragraph must be read in the context of
what has gone before. The Divisional Court then stated its conclusion at [71]. The court discussed the status of
evidence from the UNHCR and continued:

'We must consider it together with all the evidence before us and decide whether, on the totality of that
evidence, the Home Secretary's opinion is undermined to the extent that it can be said to be legally flawed. For
the reasons we have already given, the Home Secretary did not act unlawfully when reaching the conclusion
that the assurances provided by Rwanda in the MOU and Notes Verbales could be relied on. That being so the
conclusion that, for the purposes of the criteria at paragraph 345B(ii) to (iv) of the Immigration Rules, Rwanda
is a safe third country, was neither irrational nor a breach of article 3 of the ECHR in the sense explained in
_Ilias.'_

**[490] The relevance of the assurances (along with monitoring arrangements) was that they were said by the Home**
Secretary to mitigate such risk as there was that there might be refoulement. Her case was that substantial grounds
for believing that there was a real risk were not present. The adequacy of the assurances was attacked by the
claimants and the UNHCR. Her conclusion would be legally flawed if such a real risk was present despite the
assurances.
**[*395]**

The criteria in para 345B referred to in [71] are: (ii) that the principle of non-refoulement will be respected in
accordance with the Refugee Convention; (iii) that the prohibition on removal, in violation of the right to freedom
from torture and cruel, inhuman, or degrading treatment … is respected in that country; and (iv) that the possibility
exists to request refugee status and to receive protection in accordance with the Refugee Convention. The breach
of art 3 explained in Ilias was removal to a third country in which there were substantial grounds for believing that
the asylum seeker would face a real risk of ill-treatment or of being subjected to _refoulement. There would be a_
breach of art 3 if either real risk existed on the evidence. The Divisional Court had identified the relevant
_refoulement risk at [9] of its own judgment and referred to para 134 in the judgment of the Strasbourg Court in Ilias:_

'The Court would add that in all cases of removal of an asylum seeker from a Contracting State to a third
intermediary country without examination of the asylum requests on the merits, regardless of whether the
receiving third country is an EU Member State or not or whether it is a State Party to the Convention or not, it is
the duty of the removing State to examine thoroughly the question whether or not there is a real risk of the


-----

High Commissioner for Refugees intervening) and ot....

asylum seeker being denied access, in the receiving third country, to an adequate asylum procedure,
protecting him or her against refoulement. If it is established that the existing guarantees in this regard are
insufficient, art 3 implies a duty that the asylum seekers should not be removed to the third country concerned.'

**[491] The Home Secretary's decision could only be lawful if such a real risk did not exist. I would add that in [72],**
when dealing with the Gillick issue, the Divisional Court added that if the relevant criteria under paras 345A to C
were met 'removal to that country will not, applying the principles in Ilias (themselves a particular application of the
principle in Soering), give rise to a breach of article 3 of the ECHR'.

**[492] The court went on to consider 'conditions in Rwanda generally' from [73] which it described as the 'wider**
_Soering submissions, that persons removed to Rwanda … are exposed to a real risk of article 3 ill-treatment not for_
any reason connected with the handling of their asylum claim but by reason of conditions in Rwanda, generally'.
This part of the judgment straightforwardly considers the evidence and competing arguments and concludes that
there is no such real risk. That approach reinforces the reality that in considering the central art 3 issue, both by
reference to the risk of refoulement and treatment in Rwanda itself, the Divisional Court applied the right test. With
respect to the Divisional Court, I accept that its use of language ('entitled to conclude' etc eg in [64]) in a discussion
of issues that raise both ECHR and public law points of law has generated some confusion but, when read as a
whole, I am not persuaded that this criticism of the judgment is made out.

**[493] This issue is more than a technical one. It feeds into the role of an appellate court in a case where the first**
instance court has made an assessment on the basis of all the evidence on the question of whether the action
[under scrutiny would breach the ECHR and be unlawful by virtue of s 6 of the Human Rights Act 1998. We have](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)
been presented with thousands of pages of materials (leaving aside the superabundance of authorities – most not
referred to) said to be of relevance to the question whether Rwanda is a safe third country for art 3 purposes. If the
Divisional Court applied the wrong test,
**[*396]**

it would be open to this court to allow the appeal on that basis and remit the matter for fresh consideration at first
instance. Alternatively, this court could undertake the evaluation. I have the misfortune to disagree with the Master
of the Rolls and Underhill LJ on this issue. Inordinate delay would be caused by remitting the _refoulement art 3_
issue to the High Court and so I shall proceed to consider the issue as if sitting at first instance, having considered
for myself all the evidence. I am grateful to Underhill LJ for his comprehensive review of the evidence which informs
this issue and will express my conclusions relatively briefly.
**Safety of Rwanda: The asylum system and refoulement issue**

**[494] The Strasbourg Court has explained that when considering whether substantial grounds have been shown**
that an individual would face a real risk of treatment contrary to art 3 that the analysis of the evidence said to
[support that conclusion must be 'rigorous': see eg Chahal v UK (App no 22414/93) (1996) 1 BHRC 405, (1997) 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3X3-00000-00&context=1519360)
[EHRR 413 (at para 96); Saadi v Italy (App no 37201/06) (2008) 24 BHRC 123, (2009) 49 EHRR 730 (at para 128);](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2RY-00000-00&context=1519360)
_Sufi v UK_ (App nos 8319/07 and 11449/07) (2012) 54 EHRR 209, _[2011] ECHR 8319/07 (at para 214). For_
example, in cases where the argument rests on assertions of general violence in a country the court has made
clear that not every situation of general violence will give rise to such a risk. A general situation of violence would
only be of sufficient intensity to create such a risk 'in the most extreme cases' where there was a real risk of illtreatment simply by virtue of an individual being exposed to such violence on return: NA v UK (App no 25904/07)
[(2009) 48 EHRR 337, [2008] All ER (D) 298 (Jul) (at para 115). The assessment of risk in an art 3 exercise requires](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4T24-98J0-TWP1-71KH-00000-00&context=1519360)
careful consideration of all the evidence in the context of the position in which removed persons will find
themselves.

**[495]** _Ilias establishes that in cases where an ECHR state removes an asylum seeker to another state without_
considering the merits of an application, the removing state has a duty to examine thoroughly the adequacy of the
procedures in the receiving country to determine whether they protect against refoulement. The Strasbourg Court
was concerned to determine whether the applicant was adequately protected against removal, directly or indirectly,
to his or her country of origin in circumstances where art 3 risks had not been properly evaluated: see [130] to [138].


-----

High Commissioner for Refugees intervening) and ot....

**[496] The art 3 question boils down to whether substantial grounds have been shown for believing that there is a**
real risk of refoulement, directly or indirectly, to a country in which the applicant in fact needs protection, because of
deficiencies in the asylum processes in the third country, here Rwanda.

**[497] To answer that question, it is helpful to consider what would happen to individuals identified for removal by**
the Home Office and accepted by Rwanda. There is no reason to suppose that the practical and purely
administrative steps agreed between the governments will not be followed.

**[498] Those removed will arrive at Kigali and be accommodated at the Hope Hostel where they will be free to come**
and go. That has a capacity of 100. The evidence describes plans for further sites to be identified. According to the
reception and accommodation Note Verbale they will be provided with mobile telephones with internet access. They
will be given a temporary residence permit for three months on arrival. That will be extended if the asylum claim
**[*397]**

is not completed within three months. Those removed to Rwanda will be provided with financial support by the
British Government in Rwanda at the same level they would receive in the United Kingdom during the asylum
process, and thereafter, for a total of five years if granted asylum and up to three years if not. Those who make an
asylum claim will be interviewed by the Directorate General of Immigration and Emigration ('DGIE'). The asylum
claim would then be considered by the Refugee Status Determination Committee ('RSDC'). If the claim is refused
there is a right of appeal to the relevant ministry ('MINEMA'). If that appeal fails, there is a further right of appeal to
the High Court and from there to the Appeal Court. Only on the hypothesis that an asylum claim has failed at all four
stages will the question of removal arise.

**[499] In the event of a refusal of protection under the 1951 Convention the agreement requires Rwanda to consider**
whether there are other humanitarian grounds which preclude removal to the person's country of origin. It also
requires Rwanda to consider any application from a failed asylum seeker to remain in Rwanda on any other basis.
Only then does removal become a possibility.

**[500] Paragraph 10.4 of the MoU provides that 'Rwanda will only remove such a person to a country in which they**
have a right to reside. If there is no prospect of such removal occurring for any reason Rwanda will regularise that
person's immigration status in Rwanda'. These are important provisions which significantly reduce the prospects of
_refoulement. There is other evidence about the prospects of removal. In practical terms forcible removal from_
Rwanda to a failed asylum seeker's country of origin is possible only if that country is willing to accept such returns.
Therein lies a difficulty for all governments. The unequivocal evidence is that Rwanda has no agreements for return
with any country material for these purposes. There is other evidence suggesting that removal is unlikely which is
set out in the judgment of Underhill LJ. I do not ignore the evidence from the UNHCR that there have been
instances of 'airport _refoulement' (which is not a risk in these cases). Rwanda immediately returned a Syrian to_
Turkey and an Afghan to Dubai. The evidence suggests that from there they were sent to their countries of origin.
Nor do I overlook the evidence that, in different contexts, people have been pushed over the border by the DGIE
into Tanzania or Uganda. The circumstances were very different.

**[501] Objection is taken that the practical likelihood of refoulement was not addressed as a separate issue by the**
Divisional Court and referred to before us only in the skeleton argument of the respondent without oral elaboration
by Sir James Eadie KC. The way in which it was dealt with by the court below and in argument should not lead to
the conclusion that a relevant consideration in the overall evaluation of the risk of refoulement should artificially be
left to one side. In the scheme of determining whether a proposed course of action amounts to a breach of s 6 of
the Human Rights Act (and therefore the ECHR itself) the court making the decision must consider all the evidence
before it. The Divisional Court reposed confidence in the MoU (it quoted para 10.4) and the monitoring
arrangements. The evidence of the practicality of removal, with which para 10.4 is concerned, was before it. Part of
the Secretary of State's case before the Divisional Court was that there will be little practical chance of removal in
any of these cases. In agreement with Underhill LJ, I would not ignore this evidence despite there being no
respondent's notice in respect of it. My conclusion, having regard to all the evidence, is that the risk of
**[*398]**


-----

High Commissioner for Refugees intervening) and ot....

_refoulement of a failed asylum seeker sent by the United Kingdom to Rwanda is low and that the assessment of this_
evidence is relevant to determining the overall evaluation of whether substantial grounds for believing there is a real
risk of refoulement have been established.

**[502] The UNHCR has provided cogent evidence that various individuals or groups of people have been denied**
access to the Rwandan asylum process at the entry stage. Individuals have been turned away at the airport;
families in Rwanda have been denied the opportunity to make a claim; and large numbers who travelled from Israel
to Rwanda under an agreement (the details of which are unknown) did not have their claims properly assessed.
They were either pushed across the border into neighbouring countries or left Rwanda and travelled to Europe.
None of this, troubling though it is, suggests that anyone sent from the United Kingdom to Rwanda is at real risk of
similar treatment. The passage of each individual would be agreed in advance. They would be met on arrival at
Kigali and would be expected to make asylum claims. Their journey through the asylum process and beyond would
be monitored. Underhill LJ has analysed the evidence relating to the nature of the interview that can be expected to
be conducted by the DGIE, the involvement of an eligibility officer and the early stages of engagement in the
asylum process in Rwanda. The RSDC acting on the fruits of the interview, further country information and possibly
personal appearance of the person in question will make its decision. I share the concerns identified by the UNHCR
about whether those involved in the RSDC have sufficient training and expertise to deal appropriately with asylum
claims and also whether what are reported as ingrained attitudes of scepticism towards claims made by Middle
Eastern nationals will be influential. There is certainly evidence of poor practice. There will, no doubt, be changes in
respect of those considered under the agreement with the United Kingdom. But the question is whether the system
as a whole can be relied upon to deliver appropriate outcomes.

**[503] To my mind an important factor in answering that question is whether the monitoring arrangements, both**
formal and informal, provide sufficient protection to drive good decision making and thus to reduce the risk of
_refoulement below the level that would give rise to a breach of art 3 by the United Kingdom in sending people to_
Rwanda.

**[504] The Strasbourg Court has recognised the importance of effective monitoring arrangements when considering**
assurances in support of the removal of a named individual to a country where, in the absence of the assurances,
there is every reason to suppose that art 3 standards will not be met there. The principles were drawn together in
_[Othman (Abu Qatada) v UK (App no 8139/09) (2012) 32 BHRC 62, (2012) 55 EHRR 1 (at para 89). Othman (Abu](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1MB-00000-00&context=1519360)_
Qatada) had been convicted of terrorism in Jordan in absentia and was to be removed to Jordan on the strength of
assurances from the Jordanian Government that he would not be ill-treated and would get a fair retrial. The
approach of the court does not read over precisely to generic, rather than person-specific, assurances.
Nonetheless, the purpose of the list of factors set out by the Strasbourg Court was to focus attention on whether the
assurances would be effective. Monitoring compliance with the agreement is an important factor.

**[505] It is reasonable to assume that individuals who find themselves in Rwanda would be familiar with the**
agreement reached between the governments. With the assistance of lawyers in England, those unwilling to be
removed to Rwanda would have been engaged in resisting on all available
**[*399]**

grounds. In referring to 'informal' monitoring I have in mind the reality that anyone removed to Rwanda, with their
internet connected mobile phone, will be in a strong position to raise any personal concerns that they are not being
treated in accordance with the agreement. It is probable that they will be in contact with family and friends, their
English lawyers, the British High Commission and, indeed, the UNHCR in Rwanda. The UNHCR would be expected
to pay close attention to what was happening on the ground despite having no formal role in the monitoring
arrangements. It has done that in respect of refugees generally in Rwanda beyond the aspects where it has its own
agreements with the government. Those sent from the United Kingdom will be housed with other asylum seekers.
One way or another, shortcomings in the provision of interviews, transcripts, interpreters, lawyers, reasons for
decisions etc in accordance with the agreement would readily come to light with a good chance of their being dealt
with.


-----

High Commissioner for Refugees intervening) and ot....

**[506] Importantly, the formal monitoring provided both by the agreement and by arrangements put in place in the**
British High Commission in Kigali would also do so.

**[507] The first formal part of the monitoring arrangements involves the British High Commission in Kigali with Home**
Office officials embedded there to monitor compliance with the agreement. Finnlo Crellin was posted to the High
Commission in Kigali as Home Office liaison officer. The role, which will be a permanent one for the duration of the
agreement, involves developing relationships with players in all parts of the system in Rwanda to flag concerns and
to make the agreement work. As he puts it, 'the extent of these relationships between the respective Governments
is key to the strength and collaborative nature of the [agreement], allowing both sides to assess progress, discuss
specific issues or flag any concerns – including around implementation of the assurances in the MoU and [Notes
_Verbale] – and to resolve these effectively'. Kristian Armstrong, a senior Home Office official, explains that the_
Home Office officials in Kigali have the right under the MoU to observe any stage of the asylum process. This
enables the United Kingdom to monitor, on a constant basis, that the assurances are being met and the system in
Rwanda is working. It also provides accountability by the Government of Rwanda to the United Kingdom for the
assurances given under the agreement. He adds that there is an agreement that Rwanda will provide a quarterly
report to the United Kingdom on the outcome of each asylum claim and appeal, the status of each relocated
individual in Rwanda and details of anyone who has left or been removed from Rwanda. The agreement makes
provision for complaints which adds another safeguard.

**[508] The agreement also makes provision for independent monitoring. The MoU provides for an independent**
Monitoring Committee to which each government nominates four members, operating independently of the
governments. Those nominations were made and the Terms of Reference of the Monitoring Committee agreed.
The MoU ensures unfettered access by the Monitoring Committee to relevant records, officials and facilities. The
Monitoring Committee is designed to ensure that there are frequent independent and authoritative reports on how
all parts of the system are performing in Rwanda. It will provide reassurance to the British Government that
relocation of individuals to Rwanda is compatible with the 1951 Convention and the ECHR. In my view this
monitoring arrangement will provide significant assurance that the agreement is being abided by, pick up problems
and enable any that develop to be dealt with.
**[*400]**

**[509] The next level of monitoring which the agreement establishes is the Joint Committee. The MoU provides for**
the agreement to be closely managed. The Joint Committee is made up of senior officials from the United Kingdom
and Rwanda. It first met in Kigali on 31 May 2022 to discuss preparations for the initial flight and the work to ensure
that assurances contained in the agreement are implemented. Its role is to provide direction and manage the
implementation of the commitments set out in the MoU. The United Kingdom representatives on this committee are
the British High Commissioner in Rwanda, a Senior Operational Director from Immigration Enforcement, a senior
member of Home Office Legal Advisors and Mr Armstrong. The Rwandan members include members from the
DGIE, MINEMA and the Foreign Ministry. Its terms of reference have been agreed.

**[510] A function of the Joint Committee is to discuss plans for the number of individuals to be relocated to Rwanda**
over the forthcoming year, with a particular focus on the immediately following quarter. This plan will be a joint effort
produced with a view to ensuring that the numbers are realistic on both sides having regard to capacity to deal with
the individuals and asylum claims in accordance with the agreement.

**[511] These multiple levels of protective monitoring provide powerful reassurance that the terms of the agreement**
will be honoured and that if there are problems they will be picked up and ameliorated. I understand the concerns of
UNHCR but do not consider that the organisation is giving sufficient weight in its assessment to the strong interest
of both governments to make this arrangement work, the detailed monitoring arrangements which will pick up any
problems and the ability to sort them out if they arise. If significant problems arose giving rise to the relevant risk of
_refoulement the British Government would be unable to continue lawfully to send people to Rwanda. The reputation_
of Rwanda in this very high-profile public agreement is at stake. More prosaically, there are powerful financial
incentives at work, described in general terms by Mr Armstrong. Not only is every cost associated with the reception
and processing of asylum seekers being met by the United Kingdom and those removed to Rwanda provided with


-----

High Commissioner for Refugees intervening) and ot....

an income, but substantial sums of future aid support depend upon Rwanda's compliance with the agreement.
These factors operate in an environment of a deepening relationship between the United Kingdom and Rwanda in
recent years explained in the evidence from Simon Mustard of the Foreign Commonwealth and Development
Office. He does not seek to avoid confronting some of the profound human rights concerns that remain, particularly
concerning the lack of tolerance for political opposition to the government of President Kagame. He expresses the
confidence of the Foreign Office that the Government of Rwanda will honour its commitments.

**[512] The focus of concern of the UNHCR set out in Mr Bottinick's evidence is on the administrative stages of the**
asylum process: DGIE interview; RSDC consideration of the claim and then the appeal to MINEMA. Those
concerns arise particularly if Rwanda deals with substantial numbers of claims. He says very little about the
Rwandan Courts beyond observing that the right of appeal to the High Court, introduced some years ago, does not
yet appear to have been utilised and, so far as the UNHCR are concerned, the jurisdiction and procedures that will
be applied are unclear.

**[513] The** _Note Verbale records that 'the court will be able to conduct a full re-examination of the Relocated_
Individual's claim in fact and law in accordance with Rwandan rules of court procedure.' There will be legal
**[*401]**

representation. Proceedings will be in public and an adverse decision may be appealed. The UNHCR does not
suggest that the judges of the High Court and Appeal Court in Rwanda will not deal with cases that reach the courts
properly. Before the Divisional Court the appellants had developed a nascent argument that the Rwandan Courts
generally lack independence which was expanded before us. The submission, in short, is that the Rwandan
judiciary cannot be expected to disagree with the conclusion of MINEMA, a government department.

**[514] Mr Husain relied upon the decision of the Divisional Court (Irwin LJ and Foskett J) in** _Govt of Rwanda v_
_Nteziryayo_ _[[2017] EWHC 1912 (Admin), [2017] All ER (D) 203 (Jul) which concerned a request for extradition of a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P4T-VGF1-DYBP-N46G-00000-00&context=1519360)_
Hutu for genocide arising out of the events of 1994. The request was made in 2013, an earlier request from 2006
eventually having been unsuccessful in April 2009. The argument before the District Judge was that the requested
person would not get a fair trial in Rwanda. The judgments of both the Senior District Judge at first instance and the
Divisional Court explored in detail questions of judicial independence in Rwanda. They expressed concerns of a
lack of independence in some types of politically charged case. Nonetheless, their conclusions did not rest on the
simple proposition that the judiciary was not independent and would thus deliver a result desired by the
government: see [365] to [384] of the judgment of the Divisional Court and Annex 3 citing from the judgment of the
Senior District Judge. The pivotal issue was the effectiveness of the legal profession in criminal cases of that sort.

'[377] … The closer we have read the evidence in this case, the firmer has become our agreement with the
judge below that defence capacity is the vital element, the capstone, of the case. Whilst in the context of our
court system adequate representation is of course important, other safeguards in the system such as
responsible unbiased prosecution, witness protection, unchallenged and complete judicial independence taken
together, mean that inadequate defence may be compensated for and a reasonable quality of justice delivered
overall. Even in that context, it is well established that miscarriages of justice will occur, where defence
representation is inadequate. However, in the context of Rwanda, with the difficulties and weaknesses we have
identified, the presence or absence of effective defence is absolutely central. We are completely of one mind
with the judge below on that point.'

**[515] The lack of independence of the Rwandan judiciary in 'politically sensitive cases' was also called into question**
by Human Rights Watch in a letter dated 11 June 2022 to the Home Secretary, a view essentially accepted by the
Foreign Office. The question, as it seems to me, is whether the government would put pressure on the courts to
adhere to the administrative view and whether the courts would be influenced by that pressure or, it might be said,
themselves go along with the decision come what may, without any pressure being exerted. That question must be
answered in the context of the agreement between the governments which rests upon a desire, indeed
determination, of Rwanda to demonstrate the integrity of its asylum system including the independence and efficacy


-----

High Commissioner for Refugees intervening) and ot....

of its High Court and Court of Appeal. The Rwandan judiciary, on the hypothesis that appeals reach the High Court
or beyond, will be under detailed scrutiny, indeed international scrutiny.
**[*402]**

**[516] Sir James Eadie KC submitted that the context of these possible appeals is very far removed from**
prosecutions in which the state has an interest in securing a conviction for genocide or for offences alleged against
political opponents. A particular terrorism trial was referred to in evidence. He submitted that an asylum appeal
against an administrative decision is of a different character and bears no obvious political dimension which would
give rise to the risk of manipulation. Those are points well-made. He also referred to what I would regard as a
circularity at the heart of the appellants' submission on this point. The Government of Rwanda had entered into a
solemn agreement to abide by all its legal obligations regarding asylum claims, putting in place special features not
hitherto available to other asylum applicants, and relies positively on the safeguard of an independent judicial
process after the completion of the administrative determination of asylum claims. There is an obvious need for the
judiciary of Rwanda in the High Court and Appeal Court to show its independence. One would expect it to do so.

**[517] I have indicated my conclusion (see [501] above) that the risk of** _refoulement at the end of the process_
(including administrative and legal appeals) in cases involving individuals sent to Rwanda from the United Kingdom
pursuant to the agreement is low. I am also satisfied that the terms of the agreement, the strong incentives on the
Government of Rwanda to deliver its side of the bargain, the general scrutiny under which all decisions will be made
and the strong monitoring arrangements in place lead to a conclusion that the risks of wrong or perverse decisions
are also low. My evaluation of all the evidence, only a part of which has been referred to in the three judgments we
are delivering, results in the conclusion that substantial grounds for believing that there is a real risk that
deficiencies in the asylum system will lead to wrong decisions and refoulement have not been established.
**Safety of Rwanda: conditions in Rwanda**

**[518] The Divisional Court dealt with this issue between [73] and [77]. It identified two bases upon which it was**
suggested that persons removed to Rwanda would face a real risk of treatment prohibited by art 3 ECHR. The first
relates to a general intolerance of political criticism and the second to events which occurred in Kiziba refugee
camp in 2018 when protests about the conditions in the camp resulted in disturbances which were violently
supressed by the Rwandan police and resulted in deaths. As to the second, the Divisional Court, correctly in my
view, considered that it was unlikely anything similar could happen to those sent to Rwanda under the agreement.
They will not be in a refugee camp. As it said at [74]:

'The treatment of transferred persons, both prior to and after determination of their asylum claims is provided
for in the MoU … and in the Support NV. For the reasons already given, we consider the Rwandan authorities
will abide by the terms set out in these documents … The Support NV includes (at paragraph 17) that a
mechanism is to be established to allow complaints about accommodation and support provided under the
MoU to be raised and addressed. Provision for those arrangements is strong support for the conclusion that the
possibility of complaint on such matters, made by persons transferred under the [agreement] does not give rise
to any real risk that the consequence of complaint will be article 3 ill treatment.'

**[*403]**

**[519] The court dealt with the wider submission concerning whether those transferred to Rwanda would be at real**
risk of art 3 ill-treatment because of the way the Rwandan authorities might respond to expressions of opinion
adverse to them or acts of political protest. Between paras [76] and [77] the Divisional Court rejected that
submission for reasons with which I agree:

'[76] There is no suggestion that any of the individual Claimants … holds any political or other opinion that is
adverse to the Rwandan authorities. If there were such evidence it would fall to considered under paragraph
345B(i) of the Immigration Rules. A proper application of that criterion would be sufficient to ensure that were a
person to face a real risk of article 3 ill-treatment, he would not be transferred. That being so, the Claimants'
case comes to the proposition that, following removal to Rwanda, it is possible that one or more of those


-----

High Commissioner for Refugees intervening) and ot....

transferred might come to hold opinions critical of the Rwandan authorities, and that possibility means that
now, the Soering threshold is passed.

[77] There is evidence that opportunities for political opposition in Rwanda are very limited and closely
regulated. The position is set out in the “General Human Rights in Rwanda” assessment document, one of the
documents published by the Home Secretary on 9 May 2022. There are restrictions on the right of peaceful
assembly, freedom of the press and freedom of speech. The Claimants submitted that this state of affairs might
mean that any transfer to Rwanda would entail a breach of article 15 of the Refugee Convention (which
provides that refugees must be accorded the most favourable treatment accorded to nationals in respect of
non-political and non-profit-making associations and trade unions). However, we do not consider there is any
force in this submission at all. Putting to one side the fact that article 15 does not extend to all rights of
association, it is, in any event, a non-discrimination provision – i.e., persons protected under the Refugee
Convention must not be less favourably treated than the receiving country's own citizens. There is no evidence
to that effect in this case. Returning to the material covered in the Home Secretary's assessment document,
there is also evidence (from a US State Department report of 2020) that political opponents have been
detained in “unofficial” detention centres and that persons so detained have been subjected to torture and
article 3 ill-treatment short of torture. Further, there is evidence that prisons in Rwanda are over-crowded and
the conditions are very poor. Nevertheless, the Claimants' submission is speculative. It does not rest on any
evidence of any presently-held opinion. There is no suggestion that any of the individual Claimants would be
required to conceal presently-held political or other views. The Claimants' submission also assumes that the
response of the Rwandan authorities to any opinion that may in future be held by any transferred person would
(or might) involve article 3 ill-treatment. Given that the person concerned would have been transferred under
the terms of the [agreement] that possibility is not a real risk. It is to be expected that the treatment to be
afforded to those transferred will be kept under the review by the Monitoring Committee and the Joint
Committee (each established under the MOU). Further, the advantages that accrue to the Rwandan authorities
from the [agreement] provide a real incentive against any mis-treatment (whether or not reaching the standard
of article 3 ill-treatment) of any transferred person.'

**[*404]**

**[520] In my view the appellants fall short of establishing that there are substantial grounds for believing that there is**
a real risk that they will face treatment prohibited by art 3 ECHR in Rwanda.
**The procedural questions**

**[521]** _Ilias concerned the removal of two asylum seekers by Hungary to Serbia without any examination of the_
merits of the claims. Serbia was deemed by Hungarian law to be a 'safe third country' on the basis that it was a
candidate member to join the European Union and was required to satisfy EU standards when considering asylum
applications. The Hungarian authorities did not explore the realities of the position at all and had no special
arrangements with the Serbian authorities. Between [139] and [141] the court explained that a state applying the
'safe third country' concept must conduct a thorough examination of the relevant conditions and reliability of the
asylum system in the third country concerned. It must carry out of its own motion an up-to-date assessment of the
accessibility and functioning of the receiving country's asylum system and the safeguards it affords in practice. The
expelling State cannot merely assume that the asylum seeker will be treated in the receiving third country in
conformity with the Convention standards but must first verify how the authorities of that country apply their
[legislation on asylum in practice: MSS v Belgium and Greece (App no 30696/09) (2011) 31 BHRC 313, (2011) 53](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W32M-00000-00&context=1519360)
EHRR 28 (at para 359).

**[522] These paragraphs were relied upon by the appellants in support of the submission that in safe third country**
cases there is a free-standing procedural obligation to examine the receiving state's asylum system, which the
Home Secretary failed adequately to do. In consequence, submits Mr Husain KC, the proposed removals are
unlawful in art 3 terms on procedural grounds.

**[523] Like the Divisional Court I accept that this case bears little resemblance to the circumstances which obtained**
in Ilias where the Hungarian authorities made no investigations at all into the systems to which the applicants would


-----

High Commissioner for Refugees intervening) and ot....

be exposed in Serbia. On the contrary, the British Government has explored extensively the realities for asylum
seekers on the ground in Rwanda. To the extent that deficiencies in the general system of considering asylum
claims have been identified, the agreement between the governments has sought to remedy them. It was submitted
that further inquiries of various sorts should have been made and, in particular, the British Government should have
explored the terms and effectiveness of an agreement between the Governments of Rwanda and Israel by which
individuals were moved from Israel to Rwanda over a number of years.

**[524] Even if further inquiries might have been made on this or other matters, there is no question here of the**
British authorities simply assuming that the Rwandan asylum system was adequate. On the contrary, the realities
were explored and perceived difficulties addressed. I agree with the Divisional Court the Ilias investigative duty was
complied with. It is unnecessary to consider whether the Strasbourg Court was creating a truly free-standing
investigative or procedural duty. Moreover, I agree with the Divisional Court that the Tameside duty was complied
with essentially for the reasons it gave.
**Gillick**

**[525] I indicated at [479] that because my conclusion is that Rwanda is a 'safe third country' for art 3 purposes it**
follows that the various policies that enable
**[*405]**

the Home Secretary to send migrants there are not unlawful in _Gillick terms. That was the view taken by the_
Divisional Court. At [72] the court set out how that conclusion runs against each of the various policy documents
which make up the Rwanda policy:

'The next matter under this heading is the Claimants' submission that the policy by which persons whose
asylum claims are held to be inadmissible may be returned to Rwanda, is Gillick unlawful. The meaning of the
judgment of the House of Lords in _Gillick has been considered recently by the Supreme Court in_ _R(A) v_
_Secretary of State for the Home Department [2021] 1 WLR 3931. The Supreme Court emphasised that the_
relevant question is whether the policy under consideration positively authorises or approves unlawful conduct
(in the present context, a removal decision in breach of ECHR article 3). Against this standard the
Inadmissibility Policy, which includes the possibility of removal to a safe third country, is not unlawful. Removal
decisions depend on the application of paragraph 345B of the Immigration Rules, and the conclusion reached
against the criteria in that paragraph that the country concerned is a “safe third country for the particular
applicant”. If the relevant criteria are met (see above at paragraph 11), removal to that country will not, applying
the principles in Ilias (themselves, a particular application of the principle in Soering), give rise to a breach of
article 3 of the ECHR. Even if the scope of the policy for this purpose is extended to cover the general
conclusion in the 9 May 2022 assessment documents and the conclusion reached following consideration of
the further evidence filed in these proceedings by the UNHCR, the position remains the same. The conclusion,
based on all that material, that generally, asylum claims made in Rwanda by persons transferred pursuant to
the terms of the MOU would be entertained and effectively determined was a lawful conclusion. And, in any
event the final decision on removal would also have to take account of the asylum claimant's personal
circumstances – i.e., the criterion at paragraph 345B(i) of the Immigration Rules.'

**[526] The** _Gillick question, reaffirmed by the Supreme Court in the_ _A case referred to by the Divisional Court,_
requires that where the question is whether a policy is unlawful, 'that issue must be addressed looking at whether
the policy can be operated in a lawful way or whether it imposes requirements which mean that it can be seen at
the outset that a material and identifiable number of cases will be dealt with in an unlawful way' (A at [63]). The
policy (reflected in the materials to which the Divisional Court referred) seeks to ensure that art 3 ECHR is not
violated when individuals are removed to Rwanda. Taken as a whole that is the aim of the policy. As Underhill LJ
explains, if the policy in fact exposes individuals to the material risk of ill-treatment it fails not only because the
decisions taken under it would be unlawful for art 3 reasons; it would also be unlawful in _Gillick terms as_
(necessarily) authorising unlawful action. But if I am right in my conclusion on the central issue that is not the case.
For completeness I should add that the decision of the House of Lords in R (on the application of Munjaz) v Mersey


-----

High Commissioner for Refugees intervening) and ot....

_Care NHS Trust_ _[[2005] UKHL 58, [2006] 4 All ER 736, [2006] 2 AC 148, to which Ms Naik KC drew our attention,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MBK-0BW0-TWP1-60YS-00000-00&context=1519360)_
leads to no different conclusion: see the A case at [79].
**[*406] Conclusion**

**[527] The central question in these appeals is whether there are substantial grounds for believing that removal of**
these appellants and any individual to Rwanda pursuant to the agreement with the Government of Rwanda will give
rise to a real risk of treatment contrary to art 3 ECHR either (a) as a result of deficiencies in the asylum system with
a consequent real risk of _refoulement or (b) in Rwanda itself. My conclusion accords with that of the Divisional_
Court. The evidence taken as a whole does not support such a real risk in either case. I agree with Underhill LJ and
Sir Geoffrey Vos MR that the other grounds fail. Our different conclusions on the central issue deliver a different
conclusion on the Gillick issue (which adds nothing to the central question). I also agree with the Divisional Court on
the procedural issues (Ilias and Tameside). In the result, I would dismiss the appeals.

Appeals allowed.

Wendy Herring Barrister.

**End of Document**


-----

