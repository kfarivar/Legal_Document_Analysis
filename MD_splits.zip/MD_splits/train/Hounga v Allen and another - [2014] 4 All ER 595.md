# Hounga v Allen and another [2014] 4 All ER 595

[2014] UKSC 47

SUPREME COURT

LADY HALE DP, LORD KERR, LORD WILSON, LORD CARNWATH AND LORD HUGHES SCJJ

31 MARCH, 1 APRIL, 30 JULY 2014

**Employment — Discrimination — Racial discrimination — Dismissal — Defence of illegality — Employer**
**arranging for employee to present false identity to United Kingdom immigration authorities — Employee**
**knowingly participating in arrangement — Employee working for employer in United Kingdom without right**
**to work or right to remain — Employer exploiting vulnerability of employee consequent on her immigration**
**status — Employer dismissing employee — Employee claiming compensation for discrimination —**
**Whether defence of illegality available to employer — Race Relations Act 1976, s 4(2)(c).**

H was of Nigerian nationality. In January 2007, aged about 14, she came to the United Kingdom under
arrangements made by A and A's family using false documents of identity. H had been working as a home help for
A's brother in Nigeria and had accepted the proposal that she should go to live with A, and work as a home help,
but also go to school and be paid £50 per month in addition to the provision of bed and board. After H arrived in the
United Kingdom she lived in A's home and looked after her children, although she had no right to work in the United
Kingdom, and after July 2007, no right to remain. She was not enrolled in a school and was paid no wages. In July
2008 A evicted H from the house, and thereby dismissed her from the employment. In proceedings subsequently
brought by H in the employment tribunal, the tribunal found that A had dismissed H from her employment because
of her vulnerability consequent upon her immigration status, ie upon the absence of any right for her either to
remain in the United Kingdom or to have taken employment in the first place. The tribunal held that A had unlawfully
discriminated against H in that on racial grounds, namely on the ground of nationality, she had, by dismissing her,
[treated H less favourably than she would have treated others contrary to s 4(2)(c)[a] of the Race Relations Act 1976.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)
The tribunal ordered A to pay compensation to H for the resultant injury to her feelings. H appealed against the
decision of the tribunal on other claims which it had not upheld, and A cross-appealed. The Employment Appeal
Tribunal (the EAT) dismissed the appeal and cross-appeal, but the Court of Appeal allowed the further cross-appeal
of A on the basis that the illegality of the contract of employment formed a material part of H's complaint, and that to
uphold it would be to condone the illegality. H appealed to the Supreme Court. The court considered, inter alia, the
accepted international definition of 'trafficking in persons', which provided that the recruitment, transportation,
transfer, harbouring or receipt of a child for the purpose of exploitation was to be considered 'trafficking in persons'.
The United Kingdom was a party to the

1

a Section 4, so far as material, provides: '(2) It is unlawful for a person, in the case of a person employed by him at an
establishment in Great Britain, to discriminate against that employee … by dismissing him, or subjecting him to any other
detriment.'

**[*596]**


-----

Council of Europe Convention on Action against Trafficking in Human Beings, whose purposes included the
prevention of trafficking, the protection of the human rights of victims and the design of a comprehensive framework
for their protection and assistance, and under which each state was to provide, in its internal law, for the right of
victims to compensation from the perpetrators. The tribunal had made no finding whether H was the victim of
trafficking, but its findings included the existence of factors which fell within the list of indicators of forced labour
published by the International Labour Organisation in that H had been subject to physical harm or threats of
physical harm, withholding of wages, and threat of denunciation to the authorities as having irregular immigration
status

**Held – (Per Lady Hale, Lord Kerr and Lord Wilson) The defence of illegality would not, in the instant case, defeat**
the complaint of H in the statutory tort of unlawful discrimination. The defence of illegality rested upon the
foundation of public policy, and thus was a rule which was capable, on proper occasion, of expansion or
modification; so that it was necessary, first, to ask what the aspect of public policy was which founded the defence,
and second, to ask whether there was another aspect of public policy to which the application of the defence would
run counter. The aspect of public policy which founded the defence was the concern of the courts to preserve the
integrity of the legal system. In the instant case, the considerations of public policy which militated in favour of
applying the defence so as to defeat the complaint of H scarcely existed: the tribunal's award of compensation to H
did not allow her to profit from her wrongful conduct in entering into the contract, because it was an award of
compensation for injury to feelings consequent upon her dismissal; the award did not permit evasion of a penalty
prescribed by the criminal law, because H had not been prosecuted for her entry into the contract and, even had a
penalty been thus imposed on her, the award would not represent evasion of it; the award did not compromise the
integrity of the legal system by appearing to encourage those in the situation of H to enter into illegal contracts of
employment; and the application of the defence of illegality so as to defeat the award might possibly compromise
the integrity of the legal system by appearing to encourage those in the situation of A to enter into illegal contracts
of employment as it might engender a belief that they could even discriminate against such employees with
impunity. Asking whether there was another aspect of public policy to which the application of the defence of
illegality would run counter required the court to consider whether A had been guilty of 'trafficking' in bringing H from
Nigeria to the United Kingdom and into A's home; on the findings of the tribunal, H's case was one of trafficking, or
very close to trafficking, by A and her family, such that it would be a breach of the United Kingdom's international
obligations under the Convention against Trafficking for its law to cause H's complaint to be defeated by the
defence of illegality. Accordingly, the public policy in support of the application of the defence, to the extent that it
existed at all, should give way to the public policy to which its application was an affront, and (Lord Carnwath and
Lord Hughes concurring for less extensive reasons) H's appeal would therefore be allowed (see [25], [26], [37],

[42]–[52], [53], [59], [67], below).

Dicta of Lord Mansfield in Holman v Johnson (1775) 1 Cowp 341 at 343, of Bowen LJ in Maxim Nordenfelt Guns
_and Ammunition Co v Nordenfelt [1893] 1 Ch 630 at 661, and of Lord Hoffmann in R v Lyons_ _[[2002] 4 All ER 1028](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-60R9-00000-00&context=1519360)_
_[at [27] applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-60R9-00000-00&context=1519360)_
**[*597]**

Dicta of McLachlin J in Hall v Hebert [1993] 2 SCR 159 at 169 and Rantsev v Cyprus (2010) 51 EHRR 1 at para
282 adopted.
**Notes**

[Section 4 of the Race Relations Act 1976 was repealed by the Equality Act 2010, s 211(2), Sch 27, Pt 1, with effect](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)
from 1 October 2010.

For discrimination: protected characteristic of race, see 33 _Halsbury's Laws (5th edn) (2013) para 61, and for_
formation of contracts of employment: illegality, and racial discrimination and harassment, see 39 Halsbury's Laws
(5th edn) (2009) paras 18, 536.
**Cases referred to**

_Boulter v Clark (1747) Bull NP 16._


-----

_[CN v UK (2012) 34 BHRC 1, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)_

_Cross v Kirkby [2000] CA Transcript 321._

_[Enfield Technical Services Ltd v Payne [2008] EWCA 393, [2008] IRLR 500, [2008] ICR 1423.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W2V4-00000-00&context=1519360)_

_Gray v Thames Trains Ltd_ _[[2009] UKHL 33, [2009] 4 All ER 81, [2009] 1 AC 1339, [2009] 3 WLR 167.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7WS4-NV00-Y96Y-G1FB-00000-00&context=1519360)_

_Hall v Hebert [1993] 2 SCR 159, Can SC._

_Hall v Woolston Hall Leisure Ltd_ _[[2000] 4 All ER 787, [2001] 1 WLR 225, [2001] ICR 99, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61K2-00000-00&context=1519360)_

_[Holman v Johnson (1775) 1 Cowp 341, (1775) 98 ER 1120, [1775–1802] All ER Rep 98.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-20M1-00000-00&context=1519360)_

_Howard v Shirlstar Container Transport Ltd_ _[[1990] 3 All ER 366, [1990] 1 WLR 1292, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-611R-00000-00&context=1519360)_

_Maxim Nordenfelt Guns and Ammunition Co v Nordenfelt [1893] 1 Ch 630, CA._

_National Coal Board v England_ _[[1954] 1 All ER 546, [1954] AC 403, [1954] 2 WLR 400, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP40-TWP1-60M2-00000-00&context=1519360)_

_[R (on the application of B) v Merton London BC [2003] EWHC 1689 (Admin), [2003] 4 All ER 280.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61KV-00000-00&context=1519360)_

_R v L_ _[[2013] EWCA Crim 991, [2014] 1 All ER 113, [2013] 2 Cr App R 247.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_

_R v LM_ _[2010] EWCA Crim 2327, [2011] 1 Cr App R 135._

_R v Lyons_ _[[2002] UKHL 44, [2002] 4 All ER 1028, [2003] 1 AC 976, [2002] 3 WLR 1562.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-60R9-00000-00&context=1519360)_

_[Rantsev v Cyprus (2010) 28 BHRC 313, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

_[Relaxion Group plc v Rhys-Harper [2003] UKHL 33, [2003] 4 All ER 1113, [2003] ICR 867.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7P90-TWP1-61H8-00000-00&context=1519360)_

_Saunders v Edwards_ _[[1987] 2 All ER 651, [1987] 1 WLR 1116, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-6088-00000-00&context=1519360)_

_Siliadin v France_ _[(2005) 20 BHRC 654, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

_Stone & Rolls Ltd (in liq) v Moore Stephens (a firm)_ _[2008] EWCA Civ 644,_ _[[2008] 2 BCLC 461,[2009] AC 139,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7T98-S4P0-Y9D6-82FP-00000-00&context=1519360)_

[2008] 3 WLR 1146; affd _[[2009] UKHL 39, [2009] 4 All ER 431, [2009] AC 1391, [2009] 3 WLR 455.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G018-00000-00&context=1519360)_

_Tinsley v Milligan_ _[[1993] 3 All ER 65, [1994] 1 AC 340, [1993] 3 WLR 126, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61F7-00000-00&context=1519360)_

_Vakante v Addey & Stanhope School_ _[[2004] EWCA Civ 1065, [2004] 4 All ER 1056, [2005] ICR 231.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DYT-1RH0-TWP1-620M-00000-00&context=1519360)_
**Additional cases referred to in list of authorities**

_Jones v MBNA International Bank [2000] CA Transcript 1272._

_[Mullarkey v Broad [2009] EWCA Civ 2, [2009] All ER (D) 143 (Jan)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TV5-YDR0-Y96Y-H1N2-00000-00&context=1519360)_
**[*598]**

_[Onu v Akwiwu, Taiwo v Olaigbe [2014] EWCA Civ 279, [2014] IRLR 448, [2014] ICR 571.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C80-S0H1-DYPB-W1K9-00000-00&context=1519360)_

_[Patmalniece v Secretary of State for Work and Pensions [2011] UKSC 11, [2011] 3 All ER 1, [2011] 1 WLR 783.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5340-0831-DYBP-M519-00000-00&context=1519360)_

_[R (on the application of Elias) v Secretary of State for Defence [2006] EWCA Civ 1293, [2006] IRLR 934, [2006] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1JR-00000-00&context=1519360)_
WLR 3213.


-----

**Appeal**

Mary Hounga appealed with permission of the Supreme Court given on 27 November 2012 from the decision of the
[Court of Appeal (Longmore, Rimer LJJ, and Sir Scott Baker) on 15 May 2012 ([2012] EWCA Civ 609, [2012] IRLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:562R-J251-DYPB-W2CG-00000-00&context=1519360)
_[685) allowing the cross-appeal of Adenike Allen and Kunle Allen from the decision of the Employment Appeal](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:562R-J251-DYPB-W2CG-00000-00&context=1519360)_
Tribunal (Silber J, K Edmondson and MV McArthur) on 31 March 2011 (i) dismissing the appeal of Miss Hounga
from the decision of the employment tribunal that the contract of employment between Miss Hounga and Mr and
Mrs Allen was tainted with illegality and she therefore could not bring claims for unfair dismissal, breach of contract,
unpaid wages and holiday pay, that race discrimination claims other than that relating to dismissal were outside the
jurisdiction of the tribunal, and that she was entitled to an award of compensation for injury to feelings in the sum of
£6,000 and interest; and (ii) allowing the cross-appeal of Mrs Allen from the decision of the tribunal that Miss
[Hounga's claim for unlawful race discrimination under s 4(2)(c) of the Race Relations Act 1976 succeeded. Mr Allen](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)
played no part in the proceedings. Anti-Slavery International appeared as an intervener. The facts are set out in the
judgment of Lord Wilson.

_David Reade QC and Niran de Silva (instructed by Anti Trafficking and Labour Exploitation Unit) for Miss Hounga._

_Thomas Linden QC and Laura Prince (instructed by Crowther Solicitors) for Mrs Allen._

_Jan Luba QC, Kathryn Cronin, Ronan Toal and Michelle Brewer (instructed by Public Interest Lawyers) for Anti-_
Slavery International.

_Judgment was reserved._

30 July 2014. The following judgments were delivered.

**LORD WILSON**

(with whom Lady Hale and Lord Kerr agree).
**Issue**

**[1] In what circumstances should the defence of illegality defeat a complaint by an employee that an employer has**
discriminated against him by dismissing him contrary to s 4(2)(c) of the _[Race Relations Act 1976? The 1976 Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)_
was repealed by s 211(2) of, and Sch 27 to, the Equality Act 2010 and with effect from 1 October 2010 the provision
in s 4(2)(c) has been subsumed in s 39(2)(c) of the 2010 Act.
**Introduction**

**[2] The appellant, Miss Hounga, appears to have a current age of about 21. She is of Nigerian nationality and now**
resides in England. In January 2007, when she was aged about 14, she came from Nigeria to the UK under
arrangements made by the family of the respondent, Mrs Allen, who is of joint Nigerian and British nationality and
who resides in England with her children.
**[*599]**

Pursuant to these arrangements, in which Miss Hounga knowingly participated, her entry was achieved by her
presentation to UK immigration authorities of a false identity and their grant to her of a visitor's visa for six months.
For the following 18 months Miss Hounga lived in the home of Mrs Allen and of her husband who, albeit formally a
respondent to it, plays no part in this appeal. Although Miss Hounga had no right to work in the UK, and after July
2007 no right to remain in the UK, Mrs Allen employed her to look after her children in the home.

**[3] In July 2008 Mrs Allen evicted Miss Hounga from the home and thereby dismissed her from the employment.**
This appeal proceeds on the basis that, by dismissing her, Mrs Allen discriminated against Miss Hounga in that on
racial grounds, namely on ground of nationality, she treated Miss Hounga less favourably than she would have
treated others.

**[4] In due course Miss Hounga issued a variety of claims and complaints against Mrs Allen in the employment**
tribunal (the tribunal). The one claim or complaint which the tribunal upheld was her complaint of unlawful


-----

discrimination but only that part of it which related to her dismissal. In this regard it ordered Mrs Allen to pay
compensation to her for the resultant injury to her feelings in the sum of £6,187. The Employment Appeal Tribunal
(the appeal tribunal) dismissed Mrs Allen's cross-appeal against the order ([2011] EqLR 569). But the Court of
[Appeal upheld a further cross-appeal brought by Mrs Allen against it and set it aside ([2012] EWCA Civ 609, [2012]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:562R-J251-DYPB-W2CG-00000-00&context=1519360)
_[IRLR 685). By a judgment given by Rimer LJ, with which Longmore LJ and Sir Scott Baker agreed, the court held](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:562R-J251-DYPB-W2CG-00000-00&context=1519360)_
that the illegality of the contract of employment formed a material part of Miss Hounga's complaint and that to
uphold it would be to condone the illegality. It is against the Court of Appeal's order, dated 15 May 2012, that Miss
Hounga brings her appeal. A small claim generates an important point.
**Facts**

**[5] Miss Hounga and Mrs Allen both gave oral evidence to the tribunal, which concluded that both of them, but**
particularly Mrs Allen, had lied to it. The unreliability of the evidence must have made the tribunal's task of resolving
factual issues difficult. Furthermore the tribunal's rejection of part of Miss Hounga's complaint on jurisdictional
grounds, explained in para [18](c), below, may have led it to consider that it had no need to make certain findings.
But whether these factors entirely explain the tribunal's widespread failure to find facts is unclear. The absence of
findings has hampered the inquiry at all three appellate levels.

**[6] Miss Hounga's evidence was that, when she travelled to the UK in January 2007, she had been aged only 14.**
She said that an affidavit which she had sworn in Lagos just prior to her journey, in which she asserted that she had
been born in July 1986 and so was then aged 20, was untrue. Mrs Allen contended before the tribunal that the
assertion in Miss Hounga's affidavit was true or, at any rate, that she had been an adult by the date of her entry into
the UK.

**[7] Expert evidence supported Miss Hounga's contention that in January 2007 she had been aged only 14. A**
consultant paediatrician with expertise in assessing age reported in January 2009 that at the date of his report she
was aged about 16 and was certainly no more than 18. In June 2009 a local authority conducted a _Merton-_
compliant age assessment and concluded similarly that, at the date of its assessment, Miss Hounga was aged 16
[(see R (on the application of B) v Merton London BC [2003] EWHC 1689 (Admin), [2003] 4 All ER 280). The](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61KV-00000-00&context=1519360)
**[*600]**

tribunal said only that it was impossible to make a definite finding in relation to Miss Hounga's age. It referred to the
report and to the assessment but, while it did not make an express finding about her age even in approximate
terms, it gave no reason for disagreeing with them. It also accepted Miss Hounga's assertion that in the affidavit
sworn in Lagos she had falsified her date of birth. In these circumstances, unsatisfactory though they are, it is
reasonable to proceed—and to conclude that the tribunal proceeded—on the basis that, at the time of her entry into
the UK, Miss Hounga had been aged about 14.

**[8] A psychological report on Miss Hounga, dated July 2009, was presented to the tribunal on her behalf but in its**
reasons the tribunal did not refer to it. The psychologist reported that Miss Hounga's cognitive functioning might well
be in the extremely low range and indicated a learning disability; that she had long-term emotional difficulties; and
that she functioned at a developmental age much lower than her chronological age which, again, the writer took to
be 16 as at the date of the report. The tribunal did acknowledge that Miss Hounga was illiterate and had not
received an education in Nigeria but it added that she spoke English well.

**[9] Understandably the tribunal did not resolve an issue whether, as Miss Hounga claimed, her parents were dead.**
It did find, however, that in due course Miss Hounga had joined the well-to-do family of Mrs Allen's brother in Lagos;
that for two years she had lived there as a home help; that in due course Mrs Allen's mother, who lived in England
but was visiting Lagos, and Mrs Allen's brother had jointly put a proposal to Miss Hounga, which she had willingly
accepted, that she should go to live in England with Mrs Allen, where she would again work as a home help but
would also go to school; and that, by telephone, Mrs Allen had offered to pay her £50 per month additional to the
provision of bed and board. The tribunal found that it was the prospect of education in England which particularly
attracted Miss Hounga.


-----

**[10] The tribunal found that Mrs Allen's brother in Lagos had thereupon masterminded a plan, in which Mrs Allen**
and her mother had been complicit, to secure Miss Hounga's entry into the UK. It was pursuant to the plan that Miss
Hounga had sworn the affidavit, drafted in terms directed by Mrs Allen's brother, in which she had asserted not only
that she had been born in July 1986 (and that her birth certificate had been lost) but also that her surname was that
of Mrs Allen's mother. The affidavit had led to the issue to Miss Hounga of a Nigerian passport in that name. Mrs
Allen's family had then caused Miss Hounga to be driven to the British High Commission in Lagos, where she had
produced a document by which Mrs Allen's mother, pretending to be Miss Hounga's grandmother, had purported to
invite her to come to stay with her in England. The High Commission had thereupon given her entry clearance. Mrs
Allen's brother had then purchased a ticket for her travel to England. On arrival at Heathrow on 28 January 2007
Miss Hounga had confirmed to an immigration officer that the purpose of her visit was to stay with her grandmother.
Miss Hounga's passport had thereupon been endorsed with a visitor's visa, valid for six months.

**[11] The tribunal found that Miss Hounga:**

(a) knew the difference between right and wrong;

(b) knew that the assertions in her affidavit about her name and date of birth had been false;

(c) knew that she had secured the right to enter the UK on false pretences;

(d) knew that it was illegal for her to remain in the UK beyond 28 July 2007; and
**[*601]**

(e) knew that it was illegal for her to take employment in the UK.

**[12] Mrs Allen met Miss Hounga at Heathrow and took her to her home in Hanworth, Middlesex. For the next 18**
months Miss Hounga acted, according to the tribunal, as a sort of au pair. She helped to care for the three small
children of Mrs Allen and her husband, who at that time was also living in the home. She also did housework. She
was not entirely confined to the house. She went with the family by car to the supermarket but stayed inside the car
while Mrs Allen did the shopping. Occasionally she went with the family to the local park; and once they all went to
Thorpe Park. She knew the whereabouts of the key to the front door and was allowed to open it to callers. Mrs Allen
bought earrings and clothes for her.

**[13] But Miss Hounga was never enrolled in a school and, although she was provided with bed and board, she was**
never paid £50 per month or any wages at all.

**[14] It was Miss Hounga's case before the tribunal that, prior to her departure from the home on 17 July 2008, Mrs**
Allen had regularly treated her with violence and threats and had thereby harassed her. Miss Hounga gave a
detailed account, albeit unsupported by dates, of various acts of violence allegedly perpetrated upon her by Mrs
Allen and of ugly threats allegedly made by her. Mrs Allen denied all these allegations. In the event the tribunal
made only two findings in this regard, namely first that Mrs Allen had inflicted serious physical abuse on Miss
Hounga and second that she had caused her extreme concern by telling her that, were she to leave the house and
be found by the police, she would be sent to prison because her presence in the UK was illegal.

**[15] But the tribunal did accept in full Miss Hounga's account of the incident which led to her departure on 17 July**
2008, as follows:

(a) on that evening Mrs Allen was angry to discover that the children had not eaten the supper which she had
directed Miss Hounga to prepare for them;

(b) Mrs Allen smacked and hit Miss Hounga;

(c) after Miss Hounga had put the children to bed, Mrs Allen attacked and beat her, threw her out of the house and
poured water over her;


-----

(d) on his return from work, Mrs Allen's husband let Miss Hounga back into the house but he later changed his mind
and said that Mrs Allen could do whatever she liked to Miss Hounga;

(e) thereupon Mrs Allen opened the front door, told Miss Hounga to leave the house and to die and pushed her
outside again;

(f) that night Miss Hounga slept in the garden in her wet clothes;

(g) at 7:00 am she tried to get back into the house but no one would open the door; and

(h) she then made her way to a supermarket carpark, where she was found and taken to the social services
department of the local authority.
**Proceedings**

**[16] In December 2008 Miss Hounga's claim was filed in the tribunal on her behalf. It did not, at first, recite Mrs**
Allen's address: for, although she had lived there for 18 months, Miss Hounga had remained unaware of it. It was
only later that her lawyers discovered it. Miss Hounga's claim had various components. They fell into two groups,
which, in the interests only of convenience, I will describe as the contract claims and the discrimination complaints.
The former included claims for unfair dismissal, breach of contract, unpaid wages and holiday pay. The latter were
[brought under the Race Relations Act 1976 (the Act) and comprised complaints of racial](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)
**[*602]**

discrimination both in the form of harassment prior to Miss Hounga's dismissal contrary to s 3A of the Act and in
relation to the dismissal itself contrary to s 4(2)(c) of the Act.

**[17] Mrs Allen filed an initial response to the claims and complaints in which she alleged that, other than perhaps**
meeting Miss Hounga in Hanworth, she had had no dealings with her in any way and had never employed her. At a
case management discussion Mrs Allen changed her account only to the extent of accepting that Miss Hounga had
visited her house on a number of occasions. It was only later that Mrs Allen accepted that Miss Hounga had lived in
her house for an extended period.

**[18] (a) The tribunal upheld Miss Hounga's assertion that there had been a contract of employment between her**
and Mrs Allen. In the appellate proceedings Mrs Allen did not challenge this determination.

(b) The tribunal dismissed Miss Hounga's contract claims on the basis that, as she knew, it was illegal for her to
have entered into the contract of employment and that the defence of illegality operated so as to defeat such of her
claims as were based on it. Miss Hounga unsuccessfully appealed to the appeal tribunal against the dismissal of
her contract claims but did not appeal further in that regard.

(c) The tribunal dismissed Miss Hounga's complaint of pre-dismissal harassment on the ground that she had not
[complied with the grievance procedure made applicable to such a complaint by Sch 4 to the Employment Act 2002](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y000-00000-00&context=1519360)
and that she was therefore precluded from presenting it by s 32(2) of that Act. The appeal tribunal dismissed Miss
Hounga's appeal in this regard. The Court of Appeal, however, upheld her further appeal in this regard. It held that
the tribunal and the appeal tribunal had failed to consider her assertion that the circumstances were as specified in
[reg 11(3)(c) of the Employment Act 2002 (Dispute Resolution) Regulations 2004, SI 2004/752 and that therefore,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GYD0-TWPY-Y1GR-00000-00&context=1519360)
by reg 11(1), the grievance procedure did not apply. The court ruled, however, that it would be futile to remit the
point for determination by the tribunal because the complaint of discrimination in relation to pre-dismissal
harassment would in any event face defeat on the ground on which the court was rejecting the complaint of
discrimination in relation to the dismissal itself.

(d) The tribunal upheld Miss Hounga's complaint of discrimination in relation to the dismissal itself. It was agreed
that on any view the grievance procedure did not apply to this complaint. The tribunal found that Mrs Allen had
dismissed Miss Hounga from her employment because of her vulnerability consequent upon her immigration status,
ie upon the absence of any right for her either to remain in the UK or to have taken the employment in the first
place. It made the order for compensation which the Court of Appeal subsequently set aside.


-----

**New points**

**[19] A month prior to the hearing in this court Mrs Allen, by her solicitors, indicated that she proposed at its**
inception to apply for permission under para 6.3.3 of UKSC Practice Direction 6 to raise two points which had not
been raised on her behalf at any earlier stage of the proceedings. The court received argument on the application
accordingly.

**[20] The first point was based on s 4(3) of the 1976 Act, which has not been replicated in the 2010 Act. The effect**
of the subsection was that, in the case of employment for the purposes of a private household, it was not unlawful
for the employer to discriminate against the employee by dismissing her (or him)
**[*603]**

on ground of nationality (as opposed to grounds of race or ethnic or national origins). Miss Hounga conceded that,
had it been invoked before the tribunal, the subsection would have defeated her complaint of discrimination in
relation to dismissal on ground of nationality and that such had indeed been the ground on which in the event the
tribunal had upheld it. She contended, however, that, had it then been invoked, she would, as foreshadowed by the
general terms of her claim form, have presented the grounds of discrimination as being those of race or ethnic or
national origins. Mrs Allen, for her part, conceded that, in the light of its terms, the subsection could not operate so
as to defeat the complaints of pre-dismissal harassment which, were this court to uphold Miss Hounga's appeal
against the Court of Appeal's application of the illegality defence, would fall to be remitted to the tribunal.

**[21] The second point was that, in asking itself pursuant to s 1(1)(a) of the 1976 Act whether on ground of**
nationality Mrs Allen had treated Miss Hounga less favourably than she would treat other persons, the tribunal had
fallen into error in its construction of the hypothetical 'other persons'. Without objection on behalf of Mrs Allen, the
tribunal had compared her treatment of Miss Hounga with her hypothetical treatment of a British subject, ie a
person entitled to remain and work here. That such was the correct comparison had not been challenged on behalf
of Mrs Allen whether in the appeal tribunal or in the Court of Appeal. Nevertheless her second new point was that
such was an incorrect comparison. She wished to argue that many foreign nationals had rights to remain and work
in the UK; that therefore it did not follow from a person's foreign nationality that she (or he) had no such right; that
therefore an employer who discriminated against an employee of foreign nationality on grounds that she had no
right to remain or work in the UK did not discriminate against her on ground of nationality; put another way, that it
was incorrect to construct a comparator who had such rights; and that the correct comparator was a person who
had a foreign nationality other than Nigerian but who was remaining in the UK illegally and had no right to work.

**[22] Following receipt of the argument this court announced that it refused to grant permission to Mrs Allen to**
introduce either of the new points. The basis of its refusal was only that the points were raised too late. The result of
the refusal is that, in the event that the court were to uphold Miss Hounga's challenge to the Court of Appeal's
application of the illegality defence to her complaint in relation to dismissal, the tribunal's award would be restored
and not amenable to further challenge. In that event, her complaint in relation to pre-dismissal harassment on
grounds of race or ethnic or national origins would be remitted to the tribunal to determine whether the ground
identified by the Court of Appeal for possible disapplication of the grievance procedure existed and, if so, whether
the complaint was established.
**The defence of illegality**

**[23] It will thus be seen that, of the various claims and complaints made by Miss Hounga against Mrs Allen in the**
tribunal, the only one to reach this court is the complaint of discrimination in relation to her dismissal. This particular
complaint may well be said not to capture the gravamen of Miss Hounga's case against Mrs Allen. Irrespective of
whether all of it can form the subject of a civil claim, the case which, on the tribunal's exiguous findings, Miss
Hounga makes against Mrs Allen relates centrally to her participation in the plan to secure her entry into the UK on
a false basis; to Mrs Allen's failure to pay her the promised wages and, in particular, to secure for her the promised
education
**[*604]**


-----

(although the tribunal made no finding that Mrs Allen had never intended to secure it for her); and to her acts of
serious violence towards Miss Hounga over 18 months, coupled with threats of imprisonment which were entirely
convincing to Miss Hounga and which in effect disabled her from taking any steps to rescue herself from her
situation in Mrs Allen's home. In the event it was Mrs Allen's eviction of her which precipitated her rescue. Cruel
though the manner of its execution was, the dismissal was, in a real sense, a blessing for Miss Hounga. But, while
the facts upon which the present appeal is founded may not represent Miss Hounga's essential case against Mrs
Allen, the clean legal issue remains: was the Court of Appeal correct to hold that the illegality defence defeated the
complaint of discrimination?

**[24] The application of the defence of illegality to a claim founded on contract often has its own complexities. But, in**
[that it was unlawful (and indeed a criminal offence under s 24(1)(b)(ii) of the Immigration Act 1971) for Miss Hounga](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)
to enter into the contract of employment with Mrs Allen, the defence of illegality in principle precluded her from
enforcing it. In this regard a claim for unfair dismissal might arguably require analysis different from a claim for
wrongful dismissal. But a claimant for unfair dismissal is nevertheless seeking to enforce her contract, including
often to secure her reinstatement under it. In _Enfield Technical Services Ltd v Payne_ [2008] EWCA 393, _[[2008]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W2V4-00000-00&context=1519360)_
_[IRLR 500, [2008] ICR 1423, the Court of Appeal, while rejecting its applicability to the two cases before it, clearly](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W2V4-00000-00&context=1519360)_
proceeded on the basis that a defence of illegality could defeat a claim for unfair dismissal. This present appeal
proceeds without challenge to the conclusion of the tribunal, upheld by the appeal tribunal, that the defence indeed
precluded Miss Hounga's claim for unfair dismissal. Equally there is no challenge to the dismissal on that same
basis of her claim for unpaid wages although the considerations of public policy to which I will refer from para [46]
onwards might conceivably have yielded a different conclusion.

**[25] Unlawful discrimination is, however, a statutory tort: in relation to discrimination in the field of employment, see**
ss 56(1)(b) and 57(1) of the 1976 Act, now ss 124(6) and 119(2)(a) of the 2010 Act. The application of the defence
of illegality to claims in tort is highly problematic.

**[26] In** _National Coal Board v England_ _[[1954] 1 All ER 546, [1954] AC 403an employee sued his employer for](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP40-TWP1-60M2-00000-00&context=1519360)_
breach of statutory duty in respect of injuries suffered in an explosion. It had occurred while the employee was
implementing an unlawful arrangement between him and a colleague that he, rather than the colleague, should join
a cable to a detonator. The House of Lords accepted that he had been contributorily negligent but rejected the
[defence of illegality. Lord Asquith of Bishopstone said ([1954] 1 All ER 546 at 558, [1954] AC 403 at 428–429):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP40-TWP1-60M2-00000-00&context=1519360)

'The appellants relied on the maxim “ex turpi causa non oritur actio” as absolving them of liability … The vast
majority of cases in which the maxim has been applied have been cases where, there being an illegal
agreement between A and B, either seeks to sue the other for its enforcement or for damages for its breach.
That, of course, is not this case. Cases where an action in tort has been defeated by the maxim are
exceedingly rare. Possibly a party to an illegal prize fight who is damaged in the conflict cannot sue for assault:
_Boulter v Clark [(1747) Bull NP 16] … If two burglars, A and B, agree to open a safe by means of explosives,_
and A so negligently handles the explosive charge as to injure B, B might find

**[*605]**

some difficulty in maintaining an action for negligence against A. But if A and B are proceeding to the premises
which they intend burglariously to enter, and before they enter them B picks A's pocket and steals his watch, I
cannot prevail on myself to believe that A could not sue in tort … The theft is totally unconnected with the
burglary.'

But, although it has since become established that the defence will sometimes defeat an action in tort, the
circumstances in which it will do so have never been fully settled.

**[27] In Saunders v Edwards** _[[1987] 2 All ER 651, [1987] 1 WLR 1116the purchasers of a flat sued the vendor for](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-6088-00000-00&context=1519360)_
damages for the tort of deceit in having fraudulently represented to them that the premises included a roof terrace.
By arrangement between the parties, the price of the flat had been improperly reduced below its value, and the
price of chattels also included in the sale had been correspondingly inflated above their value, in order to enable the
purchasers to pay less stamp duty. The Court of Appeal held that the vendor could not rely on the defence of


-----

[illegality. Kerr LJ, with whom Bingham LJ agreed, held ([1987] 2 All ER 651 at 659, [1987] 1 WLR 1116 at 1127)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-6088-00000-00&context=1519360)
that the purchasers' dishonest apportionment of the price was wholly unconnected with their cause of action and
that their moral culpability in that regard was greatly outweighed by that of the vendor in making the fraudulent
[representation. Nicholls LJ, with whom Bingham LJ also agreed, held ([1987] 2 All ER 651 at 665, [1987] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-6088-00000-00&context=1519360)
1116 at 1132) that the question (which he answered negatively) was whether to uphold the claim would be an
affront to the public conscience in appearing indirectly to encourage the unlawful conduct of which the purchasers
had been guilty.

**[28] For six years the public conscience test was applied to defences of illegality to claims both in tort and in**
contract: see, for example, Howard v Shirlstar Container Transport Ltd _[[1990] 3 All ER 366, [1990] 1 WLR 1292. But](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-611R-00000-00&context=1519360)_
in _Tinsley v Milligan_ _[[1993] 3 All ER 65, [1994] 1 AC 340all members of the House of Lords, including the two](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61F7-00000-00&context=1519360)_
[dissenting judges, agreed that the public conscience was, as Lord Browne-Wilkinson observed ([1993] 3 All ER 65](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61F7-00000-00&context=1519360)
_[at 85, [1994] 1 AC 340 at 369), too imponderable a factor. The majority of the House considered that, once that test](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61F7-00000-00&context=1519360)_
was stripped out of the law, a reliance test was laid bare, namely that, in the words of Lord Browne-Wilkinson
[([1993] 3 All ER 65 at 91, [1994] 1 AC 340 at 376), a claimant 'is entitled to recover if he is not forced to plead or](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61F7-00000-00&context=1519360)
rely on the illegality, even if it emerges that the title on which he relied was acquired in the course of carrying
through an illegal transaction'. Before the House was, indeed, a claim to property, namely by Ms Milligan to a joint
and equal equitable interest in a home which she had agreed to be vested in the sole name of Ms Tinsley, her
cohabitant, only in order that she, Ms Milligan, could represent herself to be Ms Tinsley's lodger and claim state
benefits accordingly.

**[29] In the wake of the Tinsley case the reliance test has inevitably taken hold; and it has been applied to claims in**
tort. In Stone & Rolls Ltd (in liq) v Moore Stephens (a firm) _[[2009] UKHL 39, [2009] 4 All ER 431, [2009] AC 1391, a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G018-00000-00&context=1519360)_
company sued its auditors for negligence in failing to detect fraudulent transactions into which its former controlling
[director had caused it to enter. It was held both in the Court of Appeal (([2008] EWCA Civ 644, [2008] 2 BCLC 461,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7T98-S4P0-Y9D6-82FP-00000-00&context=1519360)

[[2009] AC 1391) and, by a majority, in the House of Lords ([2009] 4 All ER 431, [2009] AC 1391) that the conduct of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G018-00000-00&context=1519360)
the director was to be attributed to the company; and that the defence of illegality defeated it. In his judgment in
**[*606]**

the Court of Appeal, with which Keene and Mummery LJJ agreed, Rimer LJ referred to the reliance test and
[described its effect in stark terms as follows ([2008] 2 BCLC 461, [2009] AC 1391(at [16])):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7T98-S4P0-Y9D6-82FP-00000-00&context=1519360)

'The relevant question it identifies is whether, to advance the claim, it is necessary for the claimant to plead or
rely on the illegality. If it is, Tinsley v Milligan decided that the axe falls indiscriminately and the claim is barred,
however good it might otherwise be. There is no discretion to permit it to succeed.'

[In the House of Lords, Lord Phillips of Worth Matravers concluded ([2009] 4 All ER 431, [2009] AC 1391 at [86])](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X04-5KY0-Y96Y-G018-00000-00&context=1519360)
that the illegal conduct formed the basis of the company's claim, in other words that the company was forced to rely
on it. He had, however, observed (at [25]):

'I do not believe … that it is right to proceed on the basis that the reliance test can automatically be applied as
a rule of thumb. It is necessary to give consideration to the policy underlying ex turpi causa in order to decide
whether this defence is bound to defeat [the company's] claim.'

**[30] I will explain in paras [42] and following why I consider that Lord Phillips was correct to soften the effect of the**
reliance test by the need to consider the underlying policy. The test continues to carry maximum precedential
authority but has attracted criticism. It is said that it can work arbitrarily: it was only the presumption of a resulting
trust which saved Ms Milligan from having to plead the agreement to defraud and, had Ms Tinsley instead been, for
example, her daughter, a presumption of advancement might well have operated and, if so, Ms Milligan would have
had to plead the agreement. It is also said that the concept of a need to 'rely' on an unlawful act is often easier to
state than to apply. These concerns were summarised in the report of the Law Commission entitled The Illegality
_Defence, presented to Parliament on 16 March 2010, Law Com No 320, at paras 2.13–2.15, to which was annexed_
a draft Bill which, in relation to claims to equitable interests, would have replaced the reliance test.


-----

**[31] Meanwhile, however, another test, overlapping with the reliance test but not coterminous with it, had been**
developed in relation to tort—and in particular was to be applied to complaints of unlawful discrimination: the
inextricable link test.

**[32] In Cross v Kirkby [2000] CA Transcript 321, the claimant was a hunt saboteur and the defendant a local farmer.**
The claimant shouted to the defendant 'You're fucking dead' and jabbed him in the chest and throat with a broken
baseball bat. In order to ward off further blows, the defendant grappled with him. He wrested the bat from him and
hit him on the head, causing his skull to fracture. The Court of Appeal held that the claimant's claim for assault and
battery failed both because the defendant was acting in self-defence and because it was defeated by the illegality
defence. Beldam LJ, with whom Otton LJ agreed, said (at [76]):

'In my view the [defence] applies when the claimant's claim is so closely connected or inextricably bound up
with his own criminal or illegal conduct that the court could not permit him to recover without appearing to
condone that conduct.'

Judge LJ said (at [103]) that the defence arose if the facts behind the claimant's claim were 'inextricably linked with
his criminal conduct' and that this factor went 'well beyond questions of causation in the general sense'. He added
**[*607]**

(at [125]) that, if the defendant's behaviour was truly disproportionate overall, it might be powerful evidence that the
claimant's criminal conduct was not sufficiently linked to the injuries so as to attract the defence.

**[33] Three months later, in Hall v Woolston Hall Leisure Ltd** _[[2000] 4 All ER 787, [2001] 1 WLR 225, the inextricable](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61K2-00000-00&context=1519360)_
link test was applied to a complaint of unlawful sex discrimination. The employer dismissed the employee because
of her pregnancy and thus discriminated against her on ground of sex. Her wages were £250 net per week but, to
her knowledge, were misrepresented on her pay slips as £250 gross per week so that the employer might account
to the Inland Revenue for less sums than were due. Rejecting the employer's defence of illegality, the Court of
Appeal allowed her appeal against a refusal to include in her award compensation for loss of earnings. Peter
Gibson LJ held (at [46]) that there was no inextricable link between the employee's complaint and the employer's
illegal underpayments to the Revenue. After citing the decision in the Cross case, Mance LJ said:

'[79] While the underlying test therefore remains one of public policy, the test evolved in this court for its
application in a tortious context thus requires an inextricable link between the facts giving rise to the claim and
the illegality, before any question arises of the court refusing relief on the grounds of illegality. In practice, as is
evident, it requires quite extreme circumstances before the test will exclude a tort claim.' (Emphasis supplied.)

He also concluded (at [80](D)) that there was no such inextricable link.

**[34] In** _Relaxion Group plc v Rhys-Harper [2003] UKHL 33,_ _[[2003] 4 All ER 1113, [2003] ICR 867, the House of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7P90-TWP1-61H8-00000-00&context=1519360)_
Lords determined a different point, namely that an employer might discriminate against an employee in breach of
the discrimination statutes even by acts occurring after termination of the employment. But Lord Rodger of
Earlsferry quoted with approval from the judgments of Peter Gibson and Mance LJJ in the Hall case and if, as one
might assume, he thereby impliedly endorsed the inextricable link test, he clearly thought that it would seldom, if
ever, lead to the defeat of a complaint of discrimination. For he said (at [210]):

'where a contract of employment is tainted by illegality, an employee may none the less complain that her
employer discriminated against her on the ground of her sex by dismissing her, since both the Equal Treatment
[Directive and the [Sex Discrimination Act 1975] are designed to provide effective relief in respect of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8J0-TWPY-Y0RT-00000-00&context=1519360)
discriminatory conduct “rather than relief which reflects any contractual entitlement which may or may not
exist”.'

**[35] In** _Vakante v Addey & Stanhope School_ _[2004] EWCA Civ 1065,_ _[[2004] 4 All ER 1056, [2005] ICR 231, the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DYT-1RH0-TWP1-620M-00000-00&context=1519360)_
Court of Appeal upheld a defence of illegality to a teacher's complaint against a school of unlawful discrimination by
dismissal on racial grounds. The teacher was an asylum-seeker who was not entitled to work in the UK without a
work permit, which he never obtained. He had represented to the school that he did not need a permit and it was


-----

unaware that its employment of him was unlawful. Mummery LJ, with whose judgment Lord Slynn of Hadley and
Brooke LJ agreed, analysed the inextricable link test as follows:

'[9] Although Hall's case uses some of the familiar language of legal and factual causation (“connection”, “link”),
the test does not restrict the

**[*608]**

tribunal to a causation question. Matters of fact and degree have to be considered: the circumstances
surrounding the applicant's claim and the illegal conduct, the nature and seriousness of the illegal conduct, the
extent of the applicant's involvement in it and the character of the applicant's claim are all matters relevant to
determining whether the claim is so “inextricably bound up … with” the applicant's illegal conduct that, by
permitting the applicant to recover compensation, the tribunal might appear to condone the illegality.'

Mummery LJ went on to hold (at [34]) that the teacher's employment 'was unlawful from top to bottom and from
beginning to end' and (at [36]) that his complaint was so inextricably linked with the illegality of his employment that,
were it to have upheld it, the tribunal would have appeared to condone the illegality. In their case comment, A Bogg
and T A Novitz 'Race discrimination and the doctrine of illegality' (2013) 129 LQR 12 suggest that a series of errors
entered the law in the Vakante case. They are right to say that, in para [9] of Mummery LJ's judgment above, there
was a loosening of the inextricable link test and an entry into it of factors which, logically, might not have been
entitled to entry. But whether the loosened test led the Court of Appeal to make the wrong decision is much less
clear.

**[36] In Gray v Thames Trains Ltd** _[[2009] UKHL 33, [2009] 4 All ER 81, [2009] 1 AC 1339, the House of Lords, while](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7WS4-NV00-Y96Y-G1FB-00000-00&context=1519360)_
not disapproving the inextricable link test, expressed reservations about it. The claimant was injured in the
Ladbroke Grove rail disaster and in consequence suffered post-traumatic stress disorder. This led him to commit
manslaughter, for which he was ordered to be detained in hospital. He sued two railway companies for negligence,
which they admitted. The House held however that the defence of illegality barred such part of his claim as sought
general damages arising out of his detention and damages for the loss of earnings which followed it. It held that the
defence precluded compensation for losses arising from the sentence passed upon him for a criminal act for which
he had had responsibility, albeit diminished. So, as Lord Rodger pointed out at [63], the case was different from the
_National Coal Board case and the Cross case, in which the claimant had been engaged in an unlawful activity at the_
time when the defendant committed the alleged tort. Nevertheless reference was made to the inextricable link test.
Lord Hoffmann said (at [54]):

'It might be better to avoid metaphors like “inextricably linked” or “integral part” and to treat the question as
simply one of causation. Can one say that, although the damage would not have happened but for the tortious
conduct of the defendant, it was caused by the criminal act of the claimant … Or is the position that although
the damage would not have happened without the criminal act of the claimant, it was caused by the tortious act
of the defendant?'

In the same vein Lord Rodger observed (at [74]) that opinions were likely to differ about whether the alleged tort
was inextricably linked with the claimant's criminal conduct. I agree but am not convinced that the alternative inquiry
suggested by Lord Hoffmann is any more likely to secure consistency of decision-making.

**[37] Every formulation of a requirement to identify the active or effective cause of an event—or an act to which it is**
inextricably linked—has a potential
**[*609]**

for inconsistent application driven by subjective considerations. In his article entitled 'Ex Turpi Causa—when Latin
avoids liability' in the Edinburgh Law Review 18 (2014) 175, Lord Mance made a related point at p 184:

'Your painter negligently leaves your front door open, and a thief enters. Of course, in your action for
negligence against the painter, the painter is responsible for causing the loss of your goods. Equally, however,
in your action for theft of the goods against the thief, if he is caught, he is the cause. Causation, like much else
in the law, depends on context.'


-----

**[38] The subjectivity inherent in the requisite value judgment is well demonstrated by the facts of the present case.**
Three judges in the Court of Appeal were of the view, articulated in the judgment of Rimer LJ, that Miss Hounga's
complaint was inextricably linked to her own unlawful conduct—'obviously' so. They considered that the only
difference between the complaints of Miss Hounga and of Mr Vakante was that, whereas his employers were
unaware of the illegality, Mrs Allen and Miss Hounga were 'equal participants' in entry into the illegal contract of
employment. 'Whichever party bore the greater responsibility for making of the illegal contract', said Rimer LJ,
['[Miss Hounga] was a willing participant in it.' He made a further point ([2012] EWCA Civ 609, [2012] IRLR 685 (at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:562R-J251-DYPB-W2CG-00000-00&context=1519360)

[61])):

'Ms Hounga's dismissal discrimination case was dependent upon the special vulnerability to which she was
subject by reason of her illegal employment contract: she was relying on the facts that she was an illegal
immigrant, had no right to be employed here, effectively had no rights here at all and so could be treated less
well because of her inferior situation.'

**[39] But were Mrs Allen and Miss Hounga equal participants in entry into the illegal contract? Was there any doubt**
about the identity of the party who bore greater responsibility for it? And, despite the superficial attraction in logic of
Rimer LJ's further point, should Mrs Allen's cruel misuse of Miss Hounga's perceived vulnerability arising out of the
illegality, by making threats about the consequences of her exposure to the authorities, be a further justification for
the defeat of her complaint? As I will explain in para [49], such threats are an indicator that Miss Hounga was the
victim of forced labour but in the hands of the Court of Appeal they become a ground for denial of her complaint.

**[40] If, indeed, the test applicable to Mrs Allen's defence of illegality is that of the inextricable link, I, for one, albeit**
conscious of the inherent subjectivity in my so saying, would hold the link to be absent. Entry into the illegal contract
on 28 January 2007 and its continued operation until 17 July 2008 provided, so I consider, no more than the context
in which Mrs Allen then perpetrated the acts of physical, verbal and emotional abuse by which, among other things,
she dismissed Miss Hounga from her employment.

**[41] But the bigger question is whether the inextricable link test is applicable to Mrs Allen's defence.**
**Public policy**

**[42] The defence of illegality rests upon the foundation of public policy. 'The principle of public policy is this …' said**
Lord Mansfield by way of preface to his classic exposition of the defence in Holman v Johnson (1775) 1 Cowp 341
at 343, _[[1775–1802] All ER Rep 98 at 99. 'Rules which rest upon the foundation of public policy, not being rules](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-20M1-00000-00&context=1519360)_
which belong to the fixed or customary law, are capable, on proper occasion, of expansion or modification': Maxim
_Nordenfelt_
**[*610]**

_Guns and Ammunition Co v Nordenfelt [1893] 1 Ch 630 at 661(Bowen LJ). So it is necessary, first, to ask 'What is_
the aspect of public policy which founds the defence?' and, second, to ask 'But is there another aspect of public
policy to which application of the defence would run counter?'

**[43] An answer to the first question is provided in the decision of the Canadian Supreme Court in** _Hall v Hebert_

[1993] 2 SCR 159. After they had been drinking heavily together, Mr Hebert, who owned a car, allowed Mr Hall to
drive it, including initially to give it a rolling start down a road on one side of which there was a steep slope. The car
careered down the slope and Mr Hall was seriously injured. The Supreme Court held that the illegality of his driving
did not bar his claim against Mr Hebert but that he was contributorily negligent as to 50%. At the outset of her
judgment on behalf of the majority, McLachlin J ([1993] 2 SCR 159 at 169), announced her conclusion about the
basis of the power to bar recovery in tort on the ground of illegality, which later she substantiated in convincing
terms by reference to authority. Her conclusion was as follows:

'The basis of this power, as I see it, lies in [the] duty of the courts to preserve the integrity of the legal system,
and is exercisable only where this concern is in issue. This concern is in issue where a damage[s] award in a
civil suit would, in effect, allow a person to profit from illegal or wrongful conduct, or would permit an evasion or
rebate of a penalty prescribed by the criminal law. The idea common to these instances is that the law refuses
to give by its right hand what it takes away by its left hand '


-----

**[44] Concern to preserve the integrity of the legal system is a helpful rationale of the aspect of policy which founds**
the defence even if the instance given by McLachlin J of where that concern is in issue may best be taken as an
example of it rather than as the only conceivable instance of it. I therefore pose and answer the following questions:

(a) Did the tribunal's award of compensation to Miss Hounga allow her to profit from her wrongful conduct in
entering into the contract? No, it was an award of compensation for injury to feelings consequent upon her
dismissal, in particular the abusive nature of it.

(b) Did the award permit evasion of a penalty prescribed by the criminal law? No, Miss Hounga has not been
prosecuted for her entry into the contract and, even had a penalty been thus imposed upon her, it would not
represent evasion of it.

(c) Did the award compromise the integrity of the legal system by appearing to encourage those in the situation of
Miss Hounga to enter into illegal contracts of employment? No, the idea is fanciful.

(d) Conversely, would application of the defence of illegality so as to defeat the award compromise the integrity of
the legal system by appearing to encourage those in the situation of Mrs Allen to enter into illegal contracts of
employment? Yes, possibly: it might engender a belief that they could even discriminate against such employees
with impunity.

**[45] So the considerations of public policy which militate in favour of applying the defence so as to defeat Miss**
Hounga's complaint scarcely exist.

**[46] But what about the second question posed in para [42]? It requires the court to consider whether Mrs Allen was**
guilty of 'trafficking' in bringing Miss Hounga from Nigeria to the UK and into the home in Hanworth.
**[*611]**

**[47] The accepted international definition of trafficking is contained in the UN Protocol to Prevent, Suppress and**
Punish Trafficking in Persons (the Palermo Protocol) signed in 2000 and ratified by the UK on 9 February 2006.
Article 3 provides:

'(a) “Trafficking in persons” shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception,
of the abuse of power or of a position of vulnerability … for the purpose of exploitation. Exploitation shall
include, at a minimum … sexual exploitation, forced labour or services, slavery or practices similar to slavery,
servitude or the removal of organs;

(b) The consent of a victim of trafficking in persons to the intended exploitation set forth in subparagraph (a) of
this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation shall
be considered “trafficking in persons” even if this does not involve any of the means set forth in subparagraph
(a) of this article.'

So did Mrs Allen, together with other members of her family, recruit and/or transport and/or receive Miss Hounga,
being then a child, for the purpose of exploitation, namely forced labour or servitude?

**[48] In her claim form Miss Hounga alleged that the UK Human Trafficking Centre had accepted her as a victim of**
human trafficking. Before the tribunal she filed a report on herself made by Ms Skrivankova, Trafficking Programme
Coordinator, Anti-Slavery International, which intervenes in this appeal. The report must be handled with care
because Ms Skrivankova did not interview Miss Hounga and relied on written material, in particular her witness
statement, which included disputed allegations in relation to which the tribunal made no findings. At all events Ms
Skrivankova reported that all the elements in the definition of trafficking in the Palermo Protocol were present in
Miss Hounga's case. She suggested that it was a classic case of the trafficking of a vulnerable child, lacking family
support, by people known to her, who abused her natural trust in them with promises which were not kept and who
subjected her to forced labour In this latter regard Ms Skrivankova referred to a list of six indicators of forced labour


-----

published by the International Labour Organization (the ILO), which takes the view that, if at least two of the
indicators are present, forced labour exists.

**[49] The tribunal made no finding whether Miss Hounga was the victim of trafficking. No doubt it considered that it**
had no need to do so. It is only at this third level of appeal that the issue crops up again; and this court's duty to be
fair to Mrs Allen demands that it should approach the issue with the utmost caution. Nevertheless, although the
court should remember, for example, that Miss Hounga was not actually locked into the home, it is hard to resist the
conclusion that Mrs Allen was guilty of trafficking within the meaning of the definition in the Palermo Protocol. Thus,
of the ILO's six indicators of forced labour, there might be argument about the existence of the second (restriction of
movement) but, on the tribunal's findings, there certainly existed the first (physical harm or threats of it), the fourth
(withholding of wages) and the sixth (threat of denunciation to the authorities where the worker has an irregular
immigration status). Judicious hesitation leads me to conclude that, if
**[*612]**

Miss Hounga's case was not one of trafficking on the part of Mrs Allen and her family, it was so close to it that the
distinction will not matter for the purpose of what follows.

**[50] The Council of Europe Convention on Action against Trafficking in Human Beings (CETS No 197) (the**
Convention) was done in Warsaw on 16 May 2005 and, following ratification, the UK became obliged to adhere to it,
as a matter of international law, on 1 April 2009. Among the purposes of the Convention, set out in art 1, are the
prevention of trafficking, the protection of the human rights of victims and the design of a comprehensive framework
for their protection and assistance. By art 4, the Convention imports the definition of trafficking set out in the
Palermo Protocol. Article 15 provides:

'3 Each party shall provide, in its internal law, for the right of victims to compensation from the perpetrators.'

It is too technical an approach to an international instrument to contend that para 3 relates to compensation only for
the trafficking and not for related acts of discrimination. In my view it would be a breach of the UK's international
obligations under the Convention for its law to cause Miss Hounga's complaint to be defeated by the defence of
illegality. As Lord Hoffmann said in R v Lyons _[[2002] UKHL 44, [2002] 4 All ER 1028, [2003] 1 AC 976(at [27]):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-60R9-00000-00&context=1519360)_

'Of course there is a strong presumption in favour of interpreting English law (whether common law or statute)
in a way which does not place the United Kingdom in breach of an international obligation.'

**[51] Article 4 of the European Convention for the Protection of Human Rights and Fundamental Freedoms 1950 (as**
set out in Sch 1 to the Human Rights Act 1998) provides:

'1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.'

[In Rantsev v Cyprus (2010) 28 BHRC 313 a Russian woman, aged 20, had gone to work as an artiste in a cabaret](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)
in Cyprus. Three weeks later she was found dead in a street. The European Court of Human Rights (the ECtHR)
upheld her father's complaint that Cyprus was in breach of art 4 in that its regime for the issue of visas for cabaret
artistes had failed to afford effective protection to her against trafficking and that its police had failed properly to
investigate events during those weeks which suggested that she was the victim of it. For present purposes the
importance of the court's judgment lies in the following:

'282. There can be no doubt that trafficking threatens the human dignity and fundamental freedoms of its
victims and cannot be considered compatible with a democratic society and the values expounded in the
convention. In view of its obligation to interpret the convention in light of present-day conditions, the court
considers it unnecessary to identify whether the treatment about which the applicant complains constitutes
“slavery”, “servitude” or “forced and compulsory labour”. Instead, the court concludes that trafficking itself,
within the meaning of art 3(a) of the Palermo Protocol and art 4(a) of the Anti-Trafficking Convention.'


-----

**[52] In Siliadin v France** _[(2005) 20 BHRC 654, the ECtHR ruled that a 15-year-old girl, brought from Togo to France](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_
and made to work for a family without pay for 15 hours a day, had been held in servitude and required to perform
forced labour and that France had violated art 4 by having failed to
**[*613]**

[introduce criminal legislation which would afford effective protection to her. In CN v UK (2012) 34 BHRC 1, the court](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3G2-00000-00&context=1519360)
[made an analogous ruling against the UK. After the events in that case, Parliament had provided, by s 71 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95F0-Y97X-74X7-00000-00&context=1519360)
Coroners and Justice Act 2009, which extends to England, Wales and Northern Ireland, that it is a specific criminal
offence to hold a person in slavery or servitude or to require her (or him) to perform forced labour. No doubt mindful
of their obligations under art 4, the UK authorities are striving in various ways to combat trafficking and to protect its
victims. I refer, for example, to the Draft Modern Slavery Bill (Cm 8770) presented to Parliament in December 2013
and in particular to the amendments to it proposed by the government in its paper (Cm 8889) presented in June
2014 by way of response to the report of a parliamentary committee on the draft Bill. I note, for example, that one
such amendment would provide a statutory defence to a victim of trafficking who, as a result, has been compelled
to commit a crime. Although Miss Hounga is not in that category, the decision of the Court of Appeal to uphold Mrs
Allen's defence of illegality to her complaint runs strikingly counter to the prominent strain of current public policy
against trafficking and in favour of the protection of its victims. The public policy in support of the application of that
defence, to the extent that it exists at all, should give way to the public policy to which its application is an affront;
and Miss Hounga's appeal should be allowed.

**LORD HUGHES**

(with whom Lord Carnwath agrees).

**[53] I agree that Miss Hounga's appeal should be allowed in relation to her claim for the statutory tort of**
discrimination, committed in the course of dismissal. I also agree that it follows that her claim in relation to alleged
pre-dismissal harassment on grounds of race or ethnic origin (again a claim in relation to the statutory tort) should
be remitted to the tribunal to determine whether the ground identified by the Court of Appeal for possible
disapplication of the grievance procedure existed and, if so, whether the complaint was established. I am, however,
unable to go quite so far in the basis for this conclusion as Lord Wilson feels able to do.

**[54] As Lord Wilson's penetrating analysis clearly shows, a generalised statement of the conceptual basis for the**
doctrine under which illegality may bar a civil claim has always proved elusive. The same search for it produced a
similar conclusion through no less than three concentrated Law Commission documents, Consultation Papers 154
(1999) and 160 (2001) and its report on the limited case of illegality as it affects claims to beneficial interests under
trusts—The Illegality Defence (Law Com 320) (March 2010). A case in which, as I understand it, all the members of
this court are agreed on the outcome of the appeal is not a suitable vehicle to essay a general synthesis such as
has been so difficult to formulate. I attempt no more than a bare summary of such aspects of the question as affect
the present case, which is a claim in tort. Miss Hounga's contractual claims have rightly not been pursued either in
the Court of Appeal or in this court.

**[55] The various analyses offered in past cases are largely, as it seems to me, different ways of expressing two**
connected aspects of the basis for the law of illegality. The first is that the law must act consistently; it cannot give
with one hand what it takes away with another, nor condone when facing right what it condemns when facing left.
The second is that before this principle operates to bar a civil claim, and particularly one in tort, there must be a
sufficiently close connection between the illegality and the claim made. Neither proposition is
**[*614]**

suggested as a comprehensive test. En route to the answer in an individual case, the court is likely to need to
consider also the gravity of the illegality of which the claimant is guilty and her knowledge or intention in relation to
it. It will no doubt also consider the purpose of the law which has been infringed and the extent to which to allow a
civil claim nevertheless to proceed will be inconsistent with that purpose. Other factors may arise in individual
cases. It is via considerations such as these that the general public policy is to be served. Public policy very


-----

obviously underlies the rules upon illegality as it affects civil claims, but I do not think that the cases establish a
separate trumping test of public policy.

**[[56] Whilst Lord Mansfield's early statement of the law in Holman v Johnson (1775) 1 Cowp 341, [1775–1802] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-20M1-00000-00&context=1519360)**
_[ER Rep 98 cannot be treated as a comprehensive test for the application of the law of illegality, it is important to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-20M1-00000-00&context=1519360)_
remember one central feature of it, which remains true. When a court is considering whether illegality bars a civil
claim, it is essentially focusing on the position of the claimant vis-à-vis the court from which she seeks relief. It is not
primarily focusing on the relative merits of the claimant and the defendant. It is in the nature of illegality that, when it
succeeds as a bar to a claim, the defendant is the unworthy beneficiary of an undeserved windfall. But this is not
because the defendant has the merits on his side; it is because the law cannot support the claimant's claim to relief.
[Lord Mansfield's classical expression of this principle was as follows ((1775) 1 Cowp 341 at 343, [1775–1802] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-20M1-00000-00&context=1519360)
_[ER Rep 98 at 99):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-20M1-00000-00&context=1519360)_

'The objection that a contract is immoral or illegal as between plaintiff and defendant sounds at all times very ill
in the mouth of the defendant. It is not for his sake, however, that the objection is ever allowed; but it is founded
in general principles of policy which the defendant has the advantage of, contrary to the real justice, as
between him and the plaintiff, by accident, if I may so say.'

**[57] This is, as it seems to me, consistent with elementary justice. If the bank robbers (or terrorists) are using**
explosives in their crime, and A is injured by a premature explosion attributable to the carelessness of B, it does not
seem to me to be controversial to deny A a civil claim against B. That will not be because he voluntarily accepted
the risk of B's negligence; on the contrary he no doubt relied on B to do his job well. It will be because there is such
a close connection between the illegality and the civil claim that the court could not consistently condemn the first
and give relief upon the second. For the same reason, claims by one criminal against another in relation to bad
driving in escape from the crime will fail.

**[58] Conversely, when the illegality is not sufficiently closely connected to the claim, and can properly be regarded**
as collateral, or as doing no more than providing the context for the relationship which gives rise to the claim, the
bar of illegality will not fall. An example is Saunders v Edwards _[[1987] 2 All ER 651, [1987] 1 WLR 1116, where a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-6088-00000-00&context=1519360)_
claim in fraud relating to the sale of real property was not defeated by a collateral agreement between the parties to
[deflate the price in order to avoid stamp duty. Bingham LJ stated the principle thus ([1987] 2 All ER 651 at 665–666,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-6088-00000-00&context=1519360)

[1987] 1 WLR 1116 at 1134):

'Where issues of illegality are raised, the courts have … to steer a middle course between two unacceptable
positions. On the one hand it is unacceptable that any court of law should aid or lend its authority to a

**[*615]**

party seeking to pursue or enforce an object or agreement which the law prohibits. On the other hand, it is
unacceptable that the court should, on the first indication of unlawfulness affecting any aspect of a transaction,
draw up its skirts and refuse all assistance to the plaintiff, no matter how serious his loss or how
disproportionate his loss to the unlawfulness of his conduct … [O]n the whole the courts have tended to adopt
a pragmatic approach to these problems, seeking where possible to see that genuine wrongs are righted so
long as the court does not thereby promote or countenance a nefarious object or bargain which it is bound to
condemn. Where the plaintiff's action in truth arises directly ex turpi causa, he is likely to fail … [w]here the
plaintiff has suffered a genuine wrong, to which allegedly unlawful conduct is incidental, he is likely to succeed
…'

Once again, it can be seen that the proportionality to which Bingham LJ was directing his attention was such as lay
between the claimant's offence and the claim, not as between the claimant's turpitude and that of the defendant.
However, although the relative turpitude of claimant and defendant is not the test, the extent of the claimant's
turpitude may be relevant to determining whether there is a sufficiently close connection between the illegal act and
the claim. An example is Vakante v Addey & Stanhope School _[[2004] EWCA Civ 1065, [2004] 4 All ER 1056, [2005]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DYT-1RH0-TWP1-620M-00000-00&context=1519360)_
ICR 231, in which the claimant had obtained his employment not only in breach of immigration law but also by
criminal deception which caused the employers to take him on, and to risk themselves committing an offence, quite


-----

innocently; there his illegal acts were held to be so central to his claims for statutory discrimination, both in
employment and in dismissal, as to bar them.

**[59] For the reasons given by Lord Wilson, I agree that the claim of statutory tort in the present case was set in the**
context of the claimant's unlawful immigration, but that there was not a sufficiently close connection between the
illegality and the tort to bar her claim. Contrast her claim to recover for breach of contract of employment (or, by
statutory extension, for unfair dismissal), when such claims depend on a lawfully enforceable contract of
employment but her whole employment was forbidden and illegal.
**Human trafficking?**

**[60] Human trafficking is a very serious crime, recognised both internationally and nationally. Those who practise it**
can expect, and receive in England and Wales, severe penalties. The position of those who have been transported
is, however, more complex. First, the line between (on the one hand) trafficking properly so called and (on the
other) the often rapacious demands for money made by agents of persons who are only too keen to be transported
to a western country may sometimes be difficult to discern in a particular case. The latter situation is generally
referred to as smuggling, to distinguish it from trafficking. Second, assuming that the case is indeed one of
trafficking, properly so called, the question arises how offences committed by the trafficked person ought to be
treated.

**[61] The UK is bound by a series of international instruments, all of which adopt the same definition of trafficking,**
which originates in the Protocol to the UN Convention against Transnational Organized Crime 2000 (the Palermo
Protocol), ratified by the UK on 9 February 2006. The accepted definition is, as set out by Lord Wilson:

'For the purposes of this Protocol:

**[*616]**

(a) “Trafficking in persons” shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception,
of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person, for the purpose of exploitation.
Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of
organs;

(b) The consent of a victim of trafficking in persons to the intended exploitation set forth in subparagraph (a) of
this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation shall
be considered “trafficking in persons” even if this does not involve any of the means set forth in subparagraph
(a) of this article.'

The same definition appears in subsequent international instruments, the Council of Europe Convention on Action
against Trafficking in Human Beings 2005 (CETS No 197) (the Council of Europe Convention), ratified by the UK on
[17 December 2008 and the directly effective EU Directive 2011/36/EU on Preventing and Combating Trafficking in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)
Human Beings and Protecting its Victims (the EU Directive), which came into effect on 6 April 2013, after the events
with which this case is concerned. The first two instruments are not part of English law, but it is of course a general
principle of that law that ambiguous questions of construction are to be resolved in favour of compliance with the
UK's international obligations where reasonably possible, and such obligations may similarly inform the application
of open questions of common law.

**[62] It follows that, under these instruments, transportation amounts to trafficking if, in the case of an adult it is (a)**
accomplished by threat, force, deception or the other forms of coercion referred to and (b) only if it is undertaken
with a view to exploitation, in the sense defined. In the case of a child, (b) suffices. Assuming for the moment that
Miss Hounga was a child at the time, which seems overwhelmingly likely, it remains necessary that the
transportation was undertaken with a view to her exploitation Her subsequent exploitation (again assuming despite


-----

the absence of findings that it is correctly so described) is no doubt evidence of a prior intent on the part of Mrs
Allen, but it is not conclusive, and the tribunal has made no finding one way or the other.

**[63] However that may be, if this was trafficking, the position of offence(s) committed by Miss Hounga remains to be**
considered. None of the international instruments, nor any rule of English criminal law, provides any automatic
defence to a trafficked person who commits a criminal offence: see R v L _[[2013] EWCA Crim 991, [2014] 1 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_
_[113 (at [13] and [17] per Lord Judge CJ) and R v LM](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_ _[2010] EWCA Crim 2327, [2011] 1 Cr App R 135 (at [13] and_

[14]). The mechanism of the instruments is different. The second and third of them (although not the first) stipulate
that signatory states must have a system which allows for the discretionary non-punishment of those who have
committed offences which they were compelled by their trafficking to commit. This is particularly necessary in the
several European countries where
**[*617]**

it is a general principle of the criminal law that prosecution must follow the commission of any offence (see for
example s 152(2) of the German Code of Criminal Code of Procedure and art 112 of the Italian Constitution) but it
applies also in England and Wales where the Crown always has an ex post facto discretion to decide against
prosecution if it is not judged to be in the public interest. Thus art 26 of the Council of Europe Convention provides:

'Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of not
imposing penalties on victims for their involvement in unlawful activities, to the extent that they have been
compelled to do so.'

Article 8 of the EU Directive is to the same effect:

'Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties on
victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to [trafficking].'

**[64] Thus, the internationally recognised rule is clear, as is English criminal law. The trafficked victim, assuming that**
is what she is, is not relieved of criminal liability for an offence which she has committed. If, however, she was
compelled to commit it as a direct consequence of being trafficked, careful consideration ought to be given to
whether it is in the public interest to prosecute her. In the present case, there is no finding that Miss Hounga was
compelled to commit the immigration offences which she committed; the tribunal understandably found that she
was well aware of what she was doing and voluntarily did it in the hope of advantage. Young as she clearly was,
she was no doubt under the influence of Mrs Allen and that would constitute very real mitigation if punishment were
in question. But what her trafficking, if that is what it was, does not do is to take away the illegality of what she
knowingly did.

**[65] Article 6(6) of the Palermo Protocol provides:**

'Each State Party shall ensure that its domestic legal system contains measures that offer victims of trafficking
in persons the possibility of obtaining compensation for damage suffered.'

It is not possible to interpret this international obligation as requiring English law to permit Miss Hounga to recover
damages for the statutory tort of discrimination. That statutory tort is not in any sense co-extensive with trafficking or
for that matter with exploitation. For the same reasons, it would not be possible to interpret this article as requiring
English law to depart from its general principles of illegality so as to enable a person such as Miss Hounga to
recover wages under an unlawful contract of employment. Moreover, the EU Directive, now in force, is more
specific and explains what art 6(6) appears to have in mind:

'Article 17

**Compensation to victims**


-----

Member States shall ensure that victims of trafficking in human beings have access to existing schemes of
compensation to victims of violent crimes of intent.'

**[*618]**

**[66] For the sake of completeness, it should be noted that there are currently government proposals to reinforce the**
English statutory law on trafficking: see the Draft Modern Slavery Bill (Cm 8770) and proposed adjustments to it
following consideration by the joint parliamentary committee (Cm 8889). They are mostly directed to making more
severe the controls of, and penalties upon, traffickers, but there are some which affect the position of victims. These
are at present proposals only and there can be no certainty that they will be enacted in the form currently
suggested. But even if they are, they would not alter the position set out above in any manner which would alter the
conclusions set out above in relation to Miss Hounga. The proposals include:

(a) to provide a trafficked person with a statutory defence to a criminal offence but only where he or she has been
compelled to commit the offence; this would be a change to English law, but there is in this case no sufficient
evidence, still less a finding, that Miss Hounga was compelled to commit her immigration offences;

(b) to provide for amendments to the _[Proceeds of Crime Act 2002 so as to enable victims of trafficking to be](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y037-00000-00&context=1519360)_
compensated out of the confiscatable assets of traffickers; there is already a power to order compensation, which
may be payable out of confiscatable assets, but even if this alters the position significantly it will be directed at
compensation for trafficking and for the reasons set out above would not impact on the application of the ordinary
principles of illegality as a bar to civil claims.
**Conclusion**

**[67] For these reasons my conclusion is that Miss Hounga succeeds in her appeal, on the particular facts of this**
case, on the ground that there is insufficiently close connection between her immigration offences and her claims
for the statutory tort of discrimination, for the former merely provided the setting or context in which that tort was
committed, and to allow her to recover for that tort would not amount to the court condoning what it otherwise
condemns. But it is not possible to read across from the law of human trafficking to provide a separate or additional
reason for this outcome. Even if one assumes in Miss Hounga's favour that her treatment by Mrs Allen in England
amounted to slavery or forced labour, and even if one assumes, without any findings of fact, that Mrs Allen brought
her to England with the purpose of so treating her, she does not appear to have been compelled to commit the
immigration offences which she certainly did commit.

Appeal allowed.

Carla Dougan-Bacchus Barrister.

**End of Document**


-----

