# Sajid v R [2023] EWCA Crim 1346

Court of Appeal, Criminal Division

Lord Justice William Davis, Mr Justice Holgate and Her Honour Judge De Bertodano

17 November 2023Judgment

**Richard Canning (instructed by Maurice Andrews Solicitors) for the Appellant**

**Tim Storrie KC (instructed by CPS Appeals unit) for the Respondent**

Hearing dates : 3 November 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on [date] by circulation to the parties or their representatives
by e-mail and by release to the National Archives.

.............................

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

Note - include here the details of any specific reporting restrictions that have been made by the court. This will have
been identified in the Criminal Appeal Office Summary under the Reporting Restrictions heading or from the Court
Order. The wording of any reporting restriction must appear in RED TEXT.

**LORD JUSTICE WILLIAM DAVIS :**

1. On 26 September 2019 in the Crown Court at Manchester Minshull Street Mohammed Awais Sajid was
convicted of conspiracy to commit violent disorder. The following day he was convicted of causing
grievous bodily harm with intent. He subsequently was sentenced to a total term of 18 years'
imprisonment. Other defendants were convicted of violent disorder or conspiracy to commit disorder.
They included a man named Habibur Rahman and a man called Aslan Ali.

2. Those convictions related to an incident on 17 October 2017 in Church Road, Rochdale. Rahman had
been driving in Church Road. He was angered by the driving of a female driver. He subjected her to a
tirade of abuse. This was witnessed by some men who were working as tree surgeons in the area. They
intervened to protect the lady driver from Rahman's abuse and to urge him to leave. Rahman turned on
the tree surgeons. He threatened them with violence saying that they were “in his area”. He left saying
that he would be back with his “boys” who would be armed.


-----

3. After Rahman left, he telephoned one of his brothers. That brother called other men. One was Ali. Ali
in turn telephoned Sajid. Within a matter of minutes Rahman was back in Church Road. He was joined
there by a large group of men including Ali and Sajid. Many of the men were armed with machetes, knives
and similar weapons. After a brief episode of extreme violence, the group left in various vehicles.

4. The case against Sajid was that he had an axe. The tree surgeons were attacked. According to an
eye-witness named Sutherland, Sajid used the axe to attack one of the tree surgeons named Brooksbank
causing severe injuries including near traumatic amputation of his left hand. Sutherland later picked out
Sajid as the man with the axe at an identification procedure. A man named Shoaib Imran gave evidence
that he came into Church Road whilst the violence was in progress. He had heard the sounds of a
disturbance from the nearby sports field where he had been with some friends and had gone to Church
Road to see what was going on. According to him, one of the friends he was with was someone named
Zafran Khan. He said that he did not see how Brooksbank sustained his injuries. However, he said that he
saw Sajid holding an axe which was obviously blood-stained. Imran also said that he had been visited by
Sajid (who then was in company with Zafran Khan) a few days after the incident when Sajid had demanded
to have Imran's mobile telephone. Sajid said that he was taking the mobile telephone of anyone who had
been in Church Road. When Imran handed over his telephone, Sajid removed the SIM card and snapped
it in two. The telephone was kept by Sajid.

5. The trial in September 2019 was a re-trial. In February 2019 a jury had not been able to agree on
verdicts in relation to Rahman, Ali and Sajid. At the first trial Imran had not given evidence. At that point
he was not known to the police as a potential witness. His evidence was served relatively shortly before
the re-trial. When interviewed by the police Sajid provided a very short prepared statement which said that
he had no involvement in the offences alleged against him. Other than that, he made no comment to all
questions. In his defence statement he said that he was present at the scene but that this was coincidental
and had nothing to do with a call to arms from Rahman. He denied that he had been carrying an axe. He
did not give evidence at either trial.

6. Sajid now applies for an extension of time of approximately 2 years 4 months for leave to appeal
against his convictions. He also applies for leave to call evidence not called at either trial pursuant to
section 23 of the Criminal Appeal Act 1968. The fresh evidence on which Sajid seeks to rely consists of a
recording of a conversation between the witness Imran and two men, namely Zafran Khan and his nephew
called Tanzeel Khan. The conversation took place in May 2020. Zafran and Tanzeel recorded the
conversation on a mobile telephone. Tanzeel provided the mobile telephone and, with it, the recording to
Sajid's solicitors in March 2021.

7. The hearing of the applications was on 3 November 2023. We heard the evidence of Tanzeel and
Zafran de bene esse. We also read the full transcripts of the recordings made on the mobile telephone.
The respondent called evidence from two police officers, one named Lutkevitch and one named Soutter.
They had been the officers in charge of the case at trial and who had been involved with Imran becoming a
witness in the case. We read statements from Sajid's solicitor dealing with the receipt of the mobile
telephone from Tanzeel and from expert witnesses who considered the recording and its apparent
provenance.

8. At the conclusion of the hearing of the applications, we announced that both applications were
dismissed and that Sajid had no arguable grounds of appeal against his convictions. We said that we
would give written reasons at a later date. These are our written reasons.

9. In August or early September 2019 Imran had come into contact with the police because he had been
the victim of a kidnapping. The kidnapping appeared to be linked to dealing in drugs in which Imran
potentially had been involved. Imran who was aged 19 was referred as a possible victim of **_modern_**
**_slavery. The single competent authority quickly made a conclusive grounds decision that Imran was such_**
a victim. Part of the evidence relied on was the fact that he had been kidnapped by those further up the
drug dealing chain. When Imran was being asked about the kidnapping, he referred to his fear as to what
might happen to him. He said that he was worried that he could be attacked with an axe. The police
asked him why he thought that might be a possibility to which he responded that he had seen an axe being


-----

used when members of the drug dealing gang had attacked people in the street. The police realised that
he was referring to the incident in Church Road. As a result an independent police officer conducted an
ABE interview with Imran in which said that he had seen Sajid with a bloodied axe. At a later date he
made a witness statement.

10. Zafran's evidence to us was that he had been contacted by Imran via Snapchat early in 2020. In the
conversation which followed, Zafran said that Imran had told him that, although he had given evidence in
the trial implicating Sajid, he had not been at the scene. The police had used him as a witness. After
further Snapchat conversations, Zafran said that Imran agreed to meet him on a friendly basis. Zafran's
account was that he wanted to hear Imran's side of the story. Imran was at this point a witness in the
forthcoming kidnapping trial. He was no longer living in Rochdale. Rather, he had been moved to the
Midlands for his own safety. We heard that in due course those charged with kidnapping pleaded guilty to
that offence and so Imran did not have to give evidence. However, that was not known at the point he met
Zafran who travelled to the Midlands to meet Imran. Zafran said that he asked Tanzeel to take him to the
meeting with Imran. They went in a van used by Tanzeel to make Amazon deliveries. The two of them
discussed in advance the purpose of their trip. Zafran said that it had been Tanzeel's idea to record the
conversation. He stated that, so far as he could recall, the three of them had spoken about other things
before Imran admitted that he had not been at the scene of the incident in Church Road. Zafran did not
recall Imran saying where in fact he had been at the time.

11. In the course of cross-examination of Zafran, it emerged that he had attended the trial in September
2019 though he said that he was not there when Imran gave his evidence. Zafran said that he did not
know that Imran had mentioned his name 17 times during the course of the evidence as being someone
who had been with Imran in Church Road. He said that he had provided a statement to Sajid's solicitors
during the trial. By his evidence about events in Church Road, he would have been able to say that
Imran's evidence was not true. Zafran told us that he was not asked to give evidence. In the course of the
hearing, Sajid's counsel invited us to receive the witness statement provided by Zafran at the trial in
September 2019. We agreed in principle to that course. In the event, the solicitors who had represented
Sajid at trial were not able to provide a copy of that witness statement. According to them, they had no
such statement on file.

12. Tanzeel's account to us was that he had agreed to accompany Zafran. He had decided to record the
meeting with Imran because he did not trust Imran and he was concerned that Imran may intend to set
them up. For this reason he was initially reluctant to go to the meeting. After the meeting Tanzeel believed
that what had been said by Imran would help Sajid. As a result Tanzeel gave the recording to Sajid's
solicitors a couple of weeks after the meeting.

13. In cross-examination Tanzeel said that he had had no access to the case papers from the trial prior to
meeting Imran. However, when it was pointed out to him that either he or Zafran had referred to the
content of Imran's witness statement and ABE interview in the course of the meeting, he said that Sajid
had briefed him in advance as to what was in Imran's statements. This had been when Tanzeel had visited
Sajid in prison. It was also identified that the recording had been provided to Sajid's solicitor about 10
months after the conversation. When asked why there had been such a long delay, Tanzeel said that it
had taken time for him to obtain another telephone. The telephone on which he had recorded the
conversation was his Amazon work telephone which he needed to keep until he could get a replacement.
He did not know why he had not simply gone to the solicitor with the telephone so that the solicitor could
listen to it. It then transpired that Tanzeel had sent copies of the recording to his ex-partner and a man
called Samir Hussain who was “good with computers”. He gave no satisfactory explanation for providing
these people with copies of the recording nor any reason why he did not do the same for the solicitor.

14. The transcript of the recording revealed a preliminary conversation of no consequence. Then Zafran
or Tanzeel said that Imran had asked the police for a favour to which the police had said that he needed to
do something for them. It was suggested to Imran by one or other of the men who had come from
Rochdale that the police had said that Imran would be put in jail because they were “dirty coppers”. What
the police had done was described as blackmail. It was after this encouragement that Imran said that he
wasn't there “when it fucking happened” He suggested that a police officer (most probably Lutkewich) had


-----

been in the video room from which he had given evidence via live link. He said that he had given his
evidence from a script which had been written by the police. He also said that he had been given £10,000
by someone from the Crown Prosecution Service.

15. The police officers in their evidence said that Imran's evidence had not been scripted. Lutkevich said
that he had not been in the live link room with Imran when he had been giving evidence. He had been at
Minshull Street Crown Court throughout the trial. Imran had been at another court building in another city
when he gave evidence. Lutkevich said that, after Imran had made his statement in which he said that
Zafran was with him in Church Road, he had spoken to Zafran. Zafran had refused to make a statement.
He had signed an entry in the officer's daybook confirming that fact.

16. In his submissions on behalf of Sajid, Mr Canning (who was not counsel at trial) said that the only
proper reading of the transcripts of the conversation between Zafran, Tanzeel and Imran was that Imran
admitted that he had not told the truth on oath. He argued that the only significance of the delay of 10
months before the recording was provided to Sajid's solicitor was that, for a considerable time, it was not
contemplated that the recording would be used in any appeal. He conceded that the circumstances which
Imran said underpinned his lies at the trial were not credible. This court could not reasonably conclude that
Imran was paid £10,000 by the Crown Prosecution Service or that he gave his evidence from a script.
What mattered was that Imran told Zafran and Tanzeel that he was not in Church Road. Thus, we could
not be sure that he did not lie in his evidence at trial. In that event, the convictions could not be safe. Mr
Canning argued that at any re-trial the prosecution would be highly unlikely to call Imran. That was
indication enough of the true value of Imran's evidence in the light of the recording. He invited us to
conclude that this was the only sensible conclusion given that the prosecution had not asked Imran about
the recording once its existence became known.

17. Mr Storrie KC prosecuted the case at trial and represented the respondent before us. He did not
confirm Mr Canning's view as to the attitude that would be taken by the prosecution to Imran's evidence
were the convictions to be quashed. Rather than abandon Imran, the most likely course to be taken by the
prosecution would be to rely on the recording as an attempt to pervert the course of justice. A direct link to
Sajid was established by the fact that Tanzeel had visited him in prison prior to the visit to the Midlands and
that he had briefed Tanzeel about Imran's evidence at trial.

18. Mr Storrie argued that the evidence of the recording was not credible in that the supposed volte-face of
Imran was orchestrated by Tanzeel and Zafran. There was no record of what had passed between those
men and Imran prior to the meeting. The recording itself showed that in the early stages Tanzeel and/or
Zafran had made suggestions to Imran to trigger him to say that he had lied at Sajid's trial. Mr Storrie's
submission was that these were allies of Sajid who had visited Sajid before meeting Imran and who had
planned to feed lines to Imran. The respondent's case was that there was no credible account of how the
material had come into existence. Mr Storrie pointed out that at the trial Sajid had not suggested to Imran
that he was not present at the scene. Zafran had been at the trial. He could have given evidence. He did
not. Sajid for whatever reason chose not to rely on him even though, according to Zafran, he was at court
and his evidence would have established that Imran was not in Church Road. Mr Storrie argued that the
incredible reasons given by Imran for lying at the trial could not be ignored. They demonstrated that his
account to Tanzeel and Zafran was untrue. It was facile to suggest that this meant that no reliance could
be placed on anything Imran said at any stage of the proceedings.

19. Our starting point must be the evidence given by Imran at the trial. We have a transcript of the entirety
of his evidence. It occupied most of two days although there were periods during which the court was
occupied with legal submissions. He gave evidence in chief. He was cross-examined at length by counsel
for all four defendants who were on trial. His evidence plainly was not given by reference to a script. At
times he was asked about apparent inconsistencies between what he had said in his ABE interview and in
his witness statement. On occasion he lost patience with counsel who was cross-examining him. Having
read the whole of his evidence, we see no indication that he was anything but a witness giving evidence of
what he had seen and heard. This necessarily is impressionistic since we have not seen and heard him
give evidence. Equally, we could identify no point at which he appeared to be saying what others wanted
him to say


-----

20. He began by saying that he was with Zafran and others when he went to Church Road. He then
identified all of the other defendants who were on trial as being present in Church Road. He only
mentioned Sajid as the man holding an axe after he had referred to all of the other defendants. He then
described the visit to his home a few days after the incident by Sajid and Zafran during which Sajid took his
mobile telephone. If he had not been in Church Road, it made little sense for him to say that he was with
someone (Zafran) who was friendly with the defendants who could have contradicted his evidence. In fact,
Zafran was in Church Road at the end of the incident. So Imran was accurate in respect of Zafran's
presence even though, according to the case now advanced by Sajid, Imran himself was not in Church
Road.

21. When Imran was cross-examined by counsel then representing Sajid, it was suggested to him that he
had said that Sajid had an axe because Sajid was an associate of the person who had kidnapped him.
The proposition was that Imran “had falsely placed him (Sajid) with this axe”, not that Imran had falsely
said that Sajid was in Church Road or that he, Imran, was in that location There were questions about the
visit by Sajid and Zafran to Imran's home when Sajid had taken Imran's mobile telephone. The thrust of
the questions was that Imran had two telephones whereas he apparently had told the police that he had
only one. At no stage was it suggested that Sajid had not visited Imran as he had described.

22. In relation to the recording made by Tanzeel of the meeting with Imran, the allegation is that Imran lied
about seeing Sajid with an axe because the police put him up to it. The proposition is that they were keen
to convict Sajid of serious offending. The first trial had ended in a jury disagreement even though the jury
had had the evidence of Sutherland identifying Sajid as the man who used the axe. Therefore, they
persuaded Imran to give evidence implicating Sajid which could be used at the re-trial. We had no
satisfactory account of the lever the police had available to persuade Imran to give false evidence. Imran
was part of an investigation into drug dealing in Rochdale. His case along with a number of others was
sent to the Crown Prosecution Service for a charging decision. As we already have observed, Imran was
the subject of an NRM referral which resulted in a conclusive grounds decision that Imran was a victim of
**_modern slavery. The Crown Prosecution Service determined that prosecution of Imran was not in the_**
public interest. In those circumstances, there was no opportunity for the police to offer Imran any
inducement to provide false evidence against Sajid. The only other involvement Imran had with the police
was in respect of him being kidnapped. This allegation was prosecuted to conviction. If the police had
wished to suborn Imran to give false evidence, it might be thought that they would require him to give
evidence in line with what Sutherland had said i.e. that he had seen Sajid use the axe to attack Mr
Brooksbank, whereas he went no further in his evidence than to say that he saw Sajid with a bloodied axe
after the incident.

23. The recording made by Zafran and Tanzeel is said to be fresh evidence which renders Sajid's
conviction unsafe. For us to receive the evidence, section 23(1) of the Criminal Appeal Act 1968 requires
us to conclude that it is necessary to do so in the interests of justice. Section 23(2) identifies particular
matters to which we must have regard, namely whether the evidence is capable of belief and whether it
affords a ground for allowing the appeal. The matters in section 23(2) are not an exhaustive list of the
matters to which we may have regard.

24. It is accepted that the voices on the recording are those of Tanzeel, Zafran and Imran. There is no
reason to conclude that the recording was made other than in the circumstances described by Tanzeel and
Zafran, namely when they were sitting in a van with Imran somewhere in the Midlands. We have no
independent evidence of the circumstances in which Imran came to meet Tanzeel and Zafran or of the
communications which preceded their meeting. According to Zafran, Imran contacted him out of the blue
early in 2020 via Snapchat. In their initial conversation Imran said that he had given evidence against Sajid
but that he had not been there i.e. in Church Road. Zafran said that there was further contact via Snapchat
before there was an agreement to meet on a friendly basis. So far as Zafran was concerned, this was
because he wanted to hear Imran's side of the story. Zafran was unable to say why Imran wanted to have
a meeting. Tanzeel accompanied Zafran to the meeting with Imran. The supposed reason for this was
because Zafran needed a lift. However, Tanzeel had discussed Imran's evidence in advance with Sajid.
He had been briefed about what Imran had said in court. The only reasonable inference is that Tanzeel's


-----

reason for accompanying Zafran was not as he described. That leads inevitably to the conclusion that
Zafran's account of his contact with Imran is at best incomplete and at worst wholly misleading. As Mr
Storrie put it in argument, there is no credible account of how the recording came to be made.

25. This is significant when considering the course of the discussion between Zafran, Tanzeel and Imran.
As we have noted, it was Tanzeel or Zafran who began the conversation in relation to Imran's evidence
and who stated that the police had put Imran up to saying what he did about Sajid. On the face of the
recording this statement emerged without any context or explanation. We are driven to the conclusion that
there was discussion with Imran prior to the commencement of the recording. It is a reasonable inference
that something was said about what Sajid's view was, since Tanzeel had visited Sajid in prison and had
been briefed about Imran's evidence. It is impossible to reach any clear conclusion as to what else might
have been said. All that can be said with certainty is that Zafran and Tanzeel did not give a full and proper
account of their dealings with Imran.

26. It follows that the recording cannot be taken as a true reflection of what Imran did and saw. We are
fortified in that conclusion by what happened to the recording after it had been made. Mr Canning said that
it was not provided to Sajid's solicitor because it was not contemplated that it would be used in an appeal.
Why that should have been so is unclear. If it were a recording of Imran freely admitting that he had told
lies at Sajid's trial, there would no reason to delay at all in providing it to Sajid's solicitor. Tanzeel's initial
evidence on this issue was misleading. Rather than providing the recording to the solicitor within a matter
of weeks as he first said in his evidence, it was 10 months before he did so. In the meantime, he sent
copies to various people including someone who was “good with computers”. If the recording were as it
appeared on its face, it is reasonable to infer that Tanzeel would have told Sajid about it without delay. It is
inconceivable that Sajid then would have done anything other than inform his solicitor of the position.
Tanzeel's evidence was that he had visited Sajid following the meeting with Imran. Tanzeel must have told
him what had happened with respect to Imran. Sajid's failure to do anything immediately thereafter speaks
volumes as to the true significance of the recording.

27. We also take note of Mr Canning's concession that parts of what Imran said are incredible. He was
not paid £10,000 whether by the Crown Prosecution or anyone else. He was not provided with a script.
Yet that is what he said as part of his account of how he came to give evidence against Sajid at the trial.
The suggestions made by Imran in the course of the conversation about the activity of the Crown
Prosecution Service and the provision of a script by the police cannot be true. This undermines the
credibility of everything Imran said on the recording. It does not undermine the evidence Imran gave at
trial.

28. We determine that the evidence of the recording was not capable of belief. Mr Canning argued that,
had the recording been available at trial, Imran would have been cross-examined about it. The jury were
deprived of that cross-examination. That meant that Sajid was deprived of a fair trial. This proposition is
not sustainable. No unfairness would be involved in depriving a party of the opportunity to cross-examine
in relation to unreliable material.

29. The recording post-dated the trial by several months. It did not exist at the time of the trial. Thus, it
could not reasonably have been adduced at trial.  However, evidence was available which, if accepted,
would have shown Imran's evidence to be wrong. Zafran was at court during the trial. He says that he
made a statement but was not called. Whether he made a statement or not does not matter. Sajid's
solicitors must have been aware of his presence at court as, in all probability, was Sajid himself. They
knew that Imran had said that he had come to the scene with Zafran. Zafran could have contradicted that
part of Imran's evidence. He was not called to give evidence. There is no explanation, reasonable or
otherwise, for the failure to call him if Zafran was telling the truth. We can and do have regard to this
failure when considering the receipt of the fresh evidence.

30. For all of these reasons, the evidence which Sadiq applies to adduce pursuant to section 23 of the
1968 Act is not capable of belief and does not afford any ground for allowing an appeal against Sadiq's
convictions. So it was that we dismissed the application to extend time for leave to appeal against
conviction and to adduce fresh evidence.


-----

**End of Document**


-----

