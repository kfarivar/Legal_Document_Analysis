# R (on the application of KTT) v Secretary of State for the Home Department

_[[2021] EWHC 2722 (Admin), [2022] 1 WLR 1312, [2021] All ER (D) 05 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6406-MM63-GXF6-850H-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 12/10/2021**

# Catchwords & Digest

**IMMIGRATION - HUMAN TRAFFICKING - REFUSAL OF DISCRETIONARY LEAVE**

The Administrative Court allowed the appeal by the claimant Vietnamese national, who had been brought
to the UK by people traffickers and had been forced to work as a prostitute following arrival in the UK. She had
appealed against the decision by the defendant Secretary of State to refuse her claims for asylum and human rights
protection. The Secretary of State had accepted that she had been a victim of modern slavery in other countries.
However, in accordance with the Secretary of State's then policy which was set out in Version 2 of 'Discretionary
Leave for Victims of Modern Slavery' (the MSL Policy), the Secretary of State had rejected the claimant's claims. In
agreement with the claimant, the court held that the MSL Policy was contrary to art 14 of the Council of Europe
Convention on Action Against Trafficking in Human Beings 2005 because it failed to permit the grant of MSL to a
victim on the ground that she had to remain in the UK to advance an asylum/protection claim which had been based
on the fear of being re-trafficked if she was returned to her country of origin.

# Case History


EOG v Secretary of State for the Home Department (AIRE Centre intervening); KTT v
Secretary of State for the Home Department

_[[2022] EWCA Civ 307, [2023] QB 351, [2022] 3 WLR 353, [2022] INLR 213, [2022] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
_[ER (D) 70 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_
—

R (on the application of KTT) v Secretary of State for the Home Department

_[[2021] EWHC 2722 (Admin), [2022] 1 WLR 1312, [2021] All ER (D) 05 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6406-MM63-GXF6-850H-00000-00&context=1519360)_
Reversing

EOG (anonymity order made) v Secretary of State for the Home Department

_[[2020] EWHC 3310 (Admin), [2021] 1 WLR 1875, [2020] All ER (D) 37 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61G2-7543-GXFD-80RX-00000-00&context=1519360)_
—


17/03/2022

CACivD

12/10/2021

AdminCt

03/12/2020

AdminCt


-----

# Cases referring to this case

XY v Secretary of State for the Home Department

_[[2024] EWHC 81 (Admin), [2024] 1 WLR 2272, [2024] All ER (D) 01 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6B7G-1CS3-RT19-B2M9-00000-00&context=1519360)_
Applied

Nautical Challenge Ltd v Evergreen Marine (UK) Ltd

_[[2022] EWHC 206 (Admlty)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R8-S783-CGX8-00M3-00000-00&context=1519360)_
Considered

# Cases considered by this case

MN v Secretary of State for the Home Department; IXU v Secretary of State for the
Home Department (AIRE Centre and another intervening)

_[[2020] EWCA Civ 1746, [2021] 1 WLR 1956, [2020] All ER (D) 128 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6233-WXB3-GXFD-81YV-00000-00&context=1519360)_
Considered

**End of Document**


23/01/2024

AdminCt

08/02/2022

ADMLTYCT

21/12/2020

CACivD


-----

