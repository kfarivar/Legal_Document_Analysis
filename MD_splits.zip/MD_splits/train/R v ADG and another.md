# R v ADG and another

_[[2023] EWCA Crim 1309, [2024] 1 WLR 2027, [2023] All ER (D) 37 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69KB-VVH3-RRM6-V221-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 08/11/2023**

# Catchwords & Digest

**CRIMINAL LAW - APPEALS AGAINST CONVICTIONS – MODERN SLAVERY**
**DEFENDANTS AND WHETHER CONVICTIONS UNSAFE**

The Court of Appeal, Criminal Division, allowed the defendants' appeals against their convictions for
conspiracy to supply class A drugs. The defendants, both aged 17, had been sentenced to a three-year youth
rehabilitation order (YRO) (in addition to concurrent three-year YROs for other drug offences to which they had
pleaded guilty). At trial, the first defendant had argued that he had been 'targeted, utilised and exploited by the
others', while the second defendant had contended that he had been threatened and accused of stealing drugs and
had had to continue selling drugs in order to pay off his debt. The defendants contended that the judge had wrongly
[directed the jury that, to make good the defence under s 45 of the Modern Slavery](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
been required to show that there had been, or might have been, compulsion. The court held that the s 45 defence
for those under 18 years did not include the requirement of compulsion, and that, in circumstances where the judge
had added in another element to the defence which the law did not require, and where it was not possible to say
that the jury had not been influenced by that additional step on the routes to verdict, the convictions were rendered
unsafe. Accordingly, the court quashed the convictions. No retrial was ordered.

# Cases considered by this case

R v NHF

_[[2022] EWCA Crim 859](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S2-RRH3-CGX8-016K-00000-00&context=1519360)_
Considered

**End of Document**


26/05/2022

CACrimD


-----

