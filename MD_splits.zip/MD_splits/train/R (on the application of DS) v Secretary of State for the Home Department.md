# R (on the application of DS) v Secretary of State for the Home Department

 [2019] EWHC 3046 (Admin)

Queen's Bench Division, Administrative Court (London)

Kerr J

15 November 2019Judgment

**Ms Shu Shin Luh (instructed by Deighton Pierce Glynn Solicitors) for the Claimant**

**Mr William Irwin (instructed by Government Legal Department) for the Defendant**

Hearing date: 11th October 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Kerr:**

**Introduction**

1. This judicial review application challenges the government's policy requiring that a person whose claim
to be a victim of human trafficking has been rejected, can only have the decision reconsidered if one of a
class of bodies intercedes with government on the person's behalf. The claimant's individual claim has
been now been resolved by a recent decision on reconsideration after initial rejection, that she is, after all,
a victim of trafficking.

2. The essence of the challenge is that the state is responsible under international law instruments for
identifying and assisting victims of trafficking and may not delegate important aspects of that duty to nonstate bodies. It is said that a rigid policy, not on its face admitting of any exceptions, is leading the
defendant to close her eyes and mind to relevant evidence that individuals are victims of trafficking after
being wrongly identified as non-victims.

3. The defendant says the policy is reasonable and lawful; it is a legitimate means of performing the state's
duty in a manner that is efficient, swift and effective. It is necessary and lawful to bar direct access by
individuals and organisations, including legal representatives, to the remedy of reconsideration, so as to
manage cases in an orderly way, deter repetitious and long winded advocacy and use the state's
resources effectively and efficiently.

**Relevant Law and Policy**

4. Signatory states to the Council of Europe Convention on Action against Trafficking in Human Beings
(ECAT) have agreed to combat trafficking in human beings using the measures provided for in ECAT.
Human trafficking violates article 4 of the European Convention on Human Rights (ECHR), which prohibits
slavery, servitude, forced or compulsory labour.

5. Article 4 of ECAT defines trafficking in human beings. There is a detailed definition. It is common
ground that it includes sexual slavery. Article 10 of ECAT contains measures that signatory states must


-----

take to protect and promote the rights of victims. This includes a duty to provide trained and qualified
persons to identify and help victims through a procedure established by the state.

6. Since the protection of victims is a paramount objective, identifying the victims is of the first importance.
The Directive 2011/36/EU on preventing and combating trafficking in human beings and protecting its
victims (the Anti-Trafficking Directive) also requires member states to take measures to identify, assist and
protect victims. Article 11(4) provides simply:

“Member States shall take the necessary measures to establish appropriate mechanisms aimed at the
early identification of, assistance to and support for victims, in cooperation with relevant support
organisations.”

7. The above propositions form the bare bones of the domestic and international law and policy needed for
this case. The parties' written arguments, especially those of the claimant, went into much more detail. I
was referred to a substantial body of case law and explanatory materials. I do not find it necessary to refer
to all the instruments and cases, except to the extent below.

8. A more detailed account of the relevant law and policy can be found in Underhill LJ's judgment in _R_
_(TDT) v. Secretary of State for the Home Department [2018] 1 WLR 4922; see also Farbey J's account in_
her judgment in R (MN) v. Secretary of State for the Home Department _[2018] EWHC 3268 (QB) at [16]-_

[26].

9. The United Kingdom performs its duties under ECAT and the Anti-Trafficking Directive through the
National Referral Mechanism (NRM). The NRM is an administrative process operated by the defendant to
identify and ensure support and assistance for victims of trafficking. It has no statutory underpinning and is
set out in a policy document: _Victims of_ **_modern slavery – Competent Authority guidance (the CA_**
guidance).

10. Three different versions of the CA guidance were before me. The first two date from March 2016 and
were both labelled “version 3.0”. The third was published on 2 September 2019 and is labelled “version
8.0”. In the MN case, Farbey J upheld the government's submission that it was lawful to apply the balance
of probabilities as the standard of proof when making a “conclusive grounds” decision. She explained the
process thus, referring to the “version 3.0” published on 21 March 2016, at [2]:

“Under the [CA] guidance, the identification of a person as a victim of trafficking is a two-stage process.
The first part is the 'reasonable grounds decision' which acts as an initial filter designed to determine
whether someone is a 'potential' victim of trafficking (p.50). At this stage, when the CA [competent
authority] receives a referral under the NRM, it must decide whether it is 'reasonable to believe' that a
person is a victim of trafficking on the information available (p.50). According to the CA guidance, this
standard of proof will be satisfied where the CA 'suspects but cannot prove' that a person is a potential
victim (p.19). It is a 'relatively low threshold' (p.20). The second stage involves further inquiry and leads to
a 'conclusive grounds decision' as to whether someone 'is in fact a victim' (p.50). At this second stage, the
CA must consider whether there is sufficient information that the individual is a victim on the balance of
probabilities.”

11. The parties referred me to different parts of different versions of the CA guidance. The only major
difference of substance drawn to my attention is that in the latest version, the National Crime Agency
(NCA) is no longer a “competent authority”; only the Home Office is; hence the advent of the term “Single
Competent Authority” or SCA. That aside, although the wording has changed quite a lot, the substance
has not changed much.

12. Neither counsel submitted that recent changes found in the September 2019 version would affect the
outcome of this case. The claimant's case was considered against the previous versions. There must
have been others in between, which I have not been shown. I will take the content from the most recent
incarnation of the CA guidance except where indicated below.

13. The CA guidance “gives information for staff in the Single Competent Authority (SCA) in the Home
Office, to help them decide whether a person referred under the [NRM] is a victim of **_modern slavery”_**


-----

(p.7). It describes the legal framework on **_modern slavery. It states the two stage process; first, the_**
“reasonable grounds” decision and then the “conclusive grounds” decision.

14. The SCA, i.e. designated specialist staff within the Home Office, replaced the previous competent
authorities on 29 April 2019 (p.16). Referrals for consideration by the SCA are received from “first
responders”. These bodies are “designated organisations which can refer potential victims of **_modern_**
**_slavery in the UK into the NRM” (p.17)._**

15. The first responders are then listed: the Home Office itself, local authorities, Health and Social Care
Trusts, police forces, the National Crime Agency, Trafficking Awareness Raising Alliance, Migrant Help,
Kalayaan, the Gangmasters and Labour Abuse Authority, the Medaille Trust, the Salvation Army,
Barnardo's, the National Society for the Prevention of Cruelty to Children, Unseen UK, New Pathways, the
Black Association of Women Step Out and the Refugee Council.

16. Bodies called “support providers” are also recognised by the defendant and in the CA guidance. They
are contracted by government to provide care for victims or potential victims, under a “victim care contract”.
They are charitable or philanthropic organisations dedicated to protecting and furthering the needs of
victims of human trafficking. Some of those organisations feature in the written evidence in this case
further mentioned below.

17. Returning to the CA guidance, there is then much explanation about different types of modern slavery
and human trafficking. It makes grim reading; sexual exploitation of children, enforced servitude, sexual
slavery, forced criminality and forced removal of body organs are among the topics discussed.

18. The CA guidance then sets out in more detail the process of evidence gathering for the purpose of
carrying out the two stage decision making process. In some cases, it is explained, there will be enough
evidence to make a positive “reasonable grounds” decision; in others, further enquiries will be needed.

19. If the reasonable grounds decision is positive, there is a “recovery and reflection period” of at least 45
days. The SCA must then go on to consider and make a “conclusive grounds” decision. This should be
made as soon as possible once the 45 days has elapsed. If there is not enough evidence to make the
decision, further evidence must be gathered.

20. The SCA must “make every effort to request all available information that could prove useful in
establishing if there are conclusive grounds” (p.53). This information must be gathered, where appropriate,
from the first responder, a support provider, police, a local authority or the Independent Child Trafficking
Advocate.

21. Relevant medical evidence must be considered. There is a separate section on the views of experts
during the NRM process (p.73ff). “Potential victims of modern slavery may rely on documentary evidence
to support their claim in the NRM” (p.73). The SCA must assess the weight properly to be given to expert
documentary evidence.

22. A personal interview is in most cases not necessary, but may be. For example, the potential victim
may be asked to account for inconsistencies in her account (pp.54-55). Sometimes written questions
submitted via a support provider will suffice (p.54). Vulnerabilities and sensitivities must be taken into
account when assessing the veracity of the account given by the potential victim.

23. There is then a section (p.65) headed “[a]ppeals against a reasonable grounds or conclusive grounds
decision”. The wording has barely changed from the March 2016 versions. This passage in the CA
guidance sets out the policy challenged in the present judicial review:

“Reconsideration of a reasonable grounds or conclusive grounds decision

If the first responder [in the March 2016 versions: 'a first responder'] or support provider involved in the
case wishes to submit additional evidence, or they raise specific concerns that the decision is not in line
with published guidance, the SCA must look at whether they wish to reconsider the decision. This is not a
formal right of appeal and the decision should only be reconsidered where there are grounds to do so.


-----

This informal arrangement does not extend to other parties such as legal advisors and non governmental
organisations outside the NRM. However those third parties could ask the support provider or first
responder involved in the case to request a reconsideration. A support provider or first responder is not
obliged to consider that request or provide reasons for not making a reconsideration request.

If a legal representative or non governmental organisation outside the NRM requests a reconsideration
from the SCA they should be notified that:

'Our policy in the published SCA guidance clearly set outs [sic] that reconsideration requests of NRM
decisions may only be made by first responders or support providers involved in the case. You are not the
first responder or support provider involved in this NRM case so under the published guidance we cannot
reconsider the NRM decision based on your request. There is no breach of our policy as you are not
entitled to make a reconsideration request in our guidance.

It is open to you to request a reconsideration via a first responder or a support provider involved in the
case. If a support provider or first responder submits a reconsideration request in this case it may be
considered in line with the published guidance.'”

**The Facts**

24. The case has a tortuous history, of which I will omit as much as I can. The claimant is now 31, born in
1988. Her account is as follows. She grew up in Tirana, Albania. She studied at the university there and
had an arranged marriage. Her husband abused and beat her. Her parents sided with the husband. In
2014, the claimant began working at a shop in Tirana.

25. She was approached by a man whom I shall call Mr X, with whom she formed a friendship and sexual
relationship. I interject that on 3 April 2014, her passport was used to travel to Italy. The claimant denies
that it was she who travelled to Italy. In June 2014, her husband saw her in a car with Mr X. Her husband
and her family threatened to kill her. Her family disowned her.

26. For a while, Mr X protected her in a hotel and at a house. He offered her a new life with him. This
was, the claimant says, the “lover boy” method of recruiting women for prostitution: manipulating her into
thinking her boyfriend cared for her, to gain her trust before forcing her into sexual exploitation.

27. From June to December 2014 the claimant was forced to have unprotected sex with numerous men,
about four or five each day. Mr X and others were beating and raping her. She had no phone, nor means
of escape, nor access to medical treatment. She became pregnant, she knew not by whom. Then, one
night, Mr X told her to flee and hide because the police were coming.

28. She feared that if she complained to police, they would return her to Mr X, who knew some policemen,
or send her to prison. She took a taxi to a woman friend's house. She called her father, who threatened to
kill her. She was heavily pregnant but dared not seek medical care. Her friend and her friend's husband
arranged her escape in a lorry from Tirana on 7 January 2015.

29. Having reached this country, on 16 January 2015 she went to the Bristol Red Cross, distressed and 36
weeks pregnant. On 6 February 2015, Bristol City Council's social services department referred her to the
NRM as a potential victim of trafficking. A positive “reasonable grounds” decision was made, indicating
that there were reasonable grounds for believing her to be a victim of trafficking.

30. She therefore received help to make an asylum claim and specialist support from Unseen UK, a
charity and contracted support provider funded by the defendant. Her daughter was born in March 2015.
She was interviewed by an officer of the defendant on 30 June 2015. She received counselling from two
other organisations and was able to appoint immigration solicitors.

31. Eventually, on 10 January 2017 the defendant wrote to her. The Albanian authorities had, the
defendant explained, found a record of the claimant leaving Albania for Italy on 3 April 2014 using her own
passport. The claimant denied that it was she, said she had shown her passport to Mr X and that she no
longer had it by the time she left Albania.


-----

32. Her immigration solicitors pointed out that it was plausible that her passport had been used by
someone else without her knowledge. Her account, they said, was consistent, detailed and credible.
However, the defendant did not believe it and issued a negative “conclusive grounds” decision on 25 April
2017. That was then challenged by judicial review.

33. After permission was granted, the parties settled the claim: the defendant agreed to disclose
documents from the Albanian authorities and to withdraw and re-take the contested decision. The matter
was reconsidered. While that was underway, the claimant's second daughter was born in May 2017. The
father is not in contact with the claimant. The claimant was diagnosed with depression and post-traumatic
stress disorder.

34. On 10 August 2018, the defendant made a second negative conclusive grounds decision. The basis
of that second decision was essentially the same as the first: her account was not believed because of the
passport entry for 3 April 2014. The claimant then instructed her present solicitors, who retained an expert
independent law enforcement consultant, Mr Steve Harvey.

35. Mr Harvey had extensive experience of border crossings in Europe and of work relating to organised
crime, including human trafficking, in south eastern Europe. His report of 12 October 2018 (the Harvey
report) stated, in essence, that it is quite easy and not uncommon for people to pass unnoticed in and out
of Albania, or to do so using someone else's passport. He also confirmed the prevalence of the “lover boy”
method of recruiting women into enforced prostitution.

36. The claimant's solicitors then wrote a pre-action protocol letter to the defendant on 17 October 2018,
demanding that the defendant withdraw his negative conclusive grounds decision of 10 August and take a
fresh, lawful decision taking into account the new evidence in the Harvey report, which had not been
obtained when the 10 August decision was made.

37. The defendant responded on 31 October 2018, declining to reopen the matter. In relation to the
Harvey report, the letter referred to the CA guidance. According to the CA guidance, said the defendant:

“… it is open to you to request a reconsideration via a first responder or a support provider involved in the
case. If a first responder or support provider submits a reconsideration request in this case it may be
considered in line with the published guidance. Therefore, the report you have provided by Mr Steve
Harvey cannot be considered unless and until the above process is followed.”

38. This claim was then brought, challenging the negative conclusive grounds decision of 10 August 2018.
The claimant asserted that the treatment of her individual case had been unlawful and that the refusal to
reconsider the matter in the light of the Harvey report was also unlawful. On 16 January 2019, His Honour
Judge Bidder QC granted permission and directed anonymity for the claimant, an order that remains in
place.

39. The substantive hearing was listed for 14 May 2019 but was vacated by Nicol J on 13 May, by
consent. The defendant confirmed that he would make a fresh conclusive grounds decision within three
months. The claimant was given leave to withdraw her challenge to the decision of 10 August 2018.

40. The consent order records that the defendant agreed to consider “all relevant material now in the
possession of the Defendant including everything contained in the Claimant's bundle for substantive
hearing…”. That would clearly include the Harvey report, in relation to the issue of whether the claimant
had untruthfully denied leaving Albania on 3 April 2014.

41. Nicol J also adjourned, by consent, the challenge to the lawfulness of the reconsideration policy set
out in the CA guidance. The parties were to update the court if agreement were reached. If not, the
challenge would be relisted for a substantive hearing. No agreement was reached but the defendant then
sought a stay of the remainder of the challenge until after 9 September 2019.

42. That application was made on 24 May 2019 and was based on the assertion that the CA guidance was
“under active review by the Home Office”. In the grounds of the application the defendant said he
anticipated that “any judgment the court reaches will be rapidly overtaken by the developing policy”. The
judicial process could distract and slow down the process


-----

43. The claimant opposed the stay application, which Swift J refused on 5 June 2019, noting that the
review appeared to have been ongoing since October 2017 and “[t]he evidence which describes the
matters within the scope of the review does not suggest that the review will consider the matter in issue …
i.e. whether the ability to request reconsideration of a decision … should extend to persons such as the
Claimant and her legal representatives...” The matter was then listed for 11 October 2019.

44. On 3 September 2019, the defendant issued a short letter to the claimant's solicitors enclosing a
revised conclusive grounds decision, replacing the earlier negative decision of 10 August 2018. This time
the decision was positive. Reasons for the change of mind do not appear to have been given, apart from
the statement that the decision had been made “[f]ollowing further enquiries into your client's case… .” On
10 September 2019 the claimant was given leave to remain in this country for five years, until 9 September
2024.

45. The defendant then failed to file her skeleton argument in time and applied on 4 October for an
adjournment “pending the publication of the review of the role of first responders and the publication of
statutory guidance at the end of October 2019”. In the written application, the defendant confirmed that, as
set out in Nicol J's order, she had “agreed to reconsider this Claimant's case in light of the evidence now
submitted”.

46. In fact, the reconsideration exercise had already taken place. Opposing the adjournment application in
a letter of 7 October, the claimant's solicitors accepted that the Claimant's case had “now been settled” but
gave detailed reasons for opposing the application to adjourn. They argued that the legality of the
reconsideration policy remained a live issue and there were grounds for scepticism about whether the long
awaited review would bear fruit soon.

47. On 8 October, I refused the adjournment application. The hearing then proceeded on 11 October.
The defendant produced a brief and late skeleton argument the day before the hearing (for the lateness of
which Mr Irwin handsomely apologised) and relied heavily on the second witness statement of Mr Russell
Bramley, dated 4 October 2019, prepared in support of the unsuccessful adjournment application.

**The Issues, Reasoning and Conclusions**

48. The extensive and detailed arguments of Ms Luh, for the claimant, can be paraphrased more briefly,
as follows:

(1) The duty of the state to identify victims in order to assist and protect them must be performed of the
state's own motion, without requiring a victim to identify herself or apply for victim status; but nothing in
ECAT, the Anti-Trafficking Directive or article 4 of the ECHR prevents a victim from asserting and making
known to the state that she is a victim of trafficking.

(2) Where a victim does so, the state is obliged to act on her information and consider it, just as in cases
arising in the Strasbourg court where a state is under an operational duty to protect victims against
breaches of article 4 of the ECHR (Chowdury v. Greece [2017] ECR 300 at [103]-[104], [110]; J v. Austria

[2017] ECR 37 at [90], [109]-[111]).

(3) The duty does not stop once an initial decision has been made, if the initial decision turns out to be
wrong. If it did, the state would be failing to perform the duty properly and the rights of victims to
assistance and protection afforded to them under ECAT, the Anti-Trafficking Directive and article 4 of the
ECHR would be denied to them.

(4) Where plausible or credible fresh evidence or new information puts an initial decision in a different
light, the state may not refuse to consider it by invoking procedural bars erected in the name of
administrative efficiency and convenience. A duty to investigate further may arise, just as it can arise in
cases under article 2 of the ECHR (Brecknell v. United Kingdom (2008) 46 EHRR 42 at [70]-[71] and [75]).

(5) Similarly, at common law a decision maker may formulate a policy to deal with particular types of
multiple applications but must not apply the policy rigidly, nor close his or her mind and refuse to listen to
evidence or argument in favour of an exception: _British Oxygen Co v. Minister of Technology [1971] AC_
610 L d R id t 625D Th id ti li i th NRM i l t th i i l


-----

(6) Nor must a decision maker adopt a policy precluding consideration of individual cases on their merits,
unlawfully fettering a discretion to reconsider: ibid. and see also R(S) v. Secretary of State for the Home
_Department_ _[2007] EWCA Civ 546, per Carnwath LJ at [50]. The reconsideration policy in the NRM_
violates that principle also.

(7) The requirement that reconsideration requests must be channelled through a first responder or a
support provider is an unlawful delegation of the duty to identify victims. The duty must be performed by
the state itself, not its delegates. The delegation of the duty to filter reconsideration requests is an
abdication of the state's responsibility.

(8) It is no answer that the first responders and support organisations are responsible under the NRM for
bringing victims to the defendant's attention in the first place. The ECAT and the Anti-Trafficking Directive
encourage the state to collaborate with support organisations but do not authorise delegation to those
organisations of the duty to identify victims. The NRM itself (correctly) places that duty on the SCA, where
it remains.

(9) The recognition that cases must sometimes be reconsidered entails acceptance that initial decisions
may be wrong or flawed. An effective remedy to put them right must be accessible to victims; as in other
human rights contexts “procedures for asserting or defending rights must be effectively accessible”
(Gudanaviciene v. Director of Legal Aid Casework [2015] 1 WLR 2247, per Lord Dyson MR (judgment of
the court) at [71]).

(10) The restrictive reconsideration policy impairs the effectiveness of the remedy against a wrong
adverse decision, as shown by the facts of this case, where it took expert legal representation, an expert
report and two judicial reviews to break down the procedural bar. Written evidence shows that first
responders and support providers are not equipped to obtain and deploy the material needed to support a
reconsideration request.

(11) The reconsideration policy operates arbitrarily, inconsistently and without transparency, failing to
measure up to those requirements, articulated in R (Lumba) v. Secretary of State for the Home Department

[2012] 1 AC 245, SC. A negative decision is not accompanied by any information about how to challenge
the decision by judicial review or request a reconsideration, in breach of ECAT article 12(1)(d) requiring
provision of “information, in particular as regards [the victim's] legal rights and the services available to
them, in a language that they can understand .. .”

49. For the defendant, Mr Irwin made submissions which I paraphrase as follows:

(1) The policy is acceptable, lawful and reasonable. Referral of a person into the NRM is different from the
process of determining immigration or asylum applications. The process is not the making of an
application and determination of the application. It is a process to enable and empower a class of people,
victims of trafficking, who are not able to refer themselves into the NRM. An individual cannot “self-refer”
into the NRM.

(2) Within the structure of the NRM, the SCA can be likened to the “brain” of the NRM; while the first
responders and support providers may be likened to its “eyes and ears”. For the SCA to operate
effectively, it is essential that information about potential victims is transmitted to it by first responders and
support providers effectively.

(3) Triage is an essential and legitimate component of this process. It is necessary for effective and
orderly case management. Individuals and organisations that are not first responders or support providers
do not have the training and expertise to identify victims. Being a first responder is a professional role;
they have a duty to notify the Home Office of potential victims, under section 52 of the Modern Slavery Act
2015.

(4) The SCA must make its decisions within a very tight timescale. A reasonable grounds decision is
intended to be made within five days of notification; a conclusive grounds decision, within 45 days of a
positive reasonable grounds decision. Mr Irwin emphasised that the process needs to be “nimble”.


-----

(5) Mr Bramley's evidence is that first responders and support providers are “ideally placed to ensure that
cases of potential victims that merit reconsideration by the SCA are referred accordingly”. Their
“professional judgment … acts to ensure that potential victims are identified appropriately”.

(6) Legal representatives, on the other hand, are apt to present large amounts of unfiltered information,
evidence and submissions of poor quality and low probative value, in an undisciplined way. It is
reasonable to deploy the triage services of first responders and support providers to weed out weak cases
where reconsideration is not justified and would merely burden the SCA unnecessarily and detract from its
role in identifying victims.

(7) Indeed, there would be a risk of frustrating the work of the SCA if organisations other than first
responders or support providers could make requests for reconsideration. It would become, Mr Irwin
submitted, burdened with giving primary consideration to reconsideration decisions rather than focussing
on dealing with cases where expert first responders or support providers have already assessed the case
concerned.

(8) Mr Irwin pointed out that the role of the SCA within the NRM is only part of the machinery in place in
this country to ensure compliance with the state's obligations under the ECAT and in respect of article 4 of
the ECHR. The duties include provision of assistance and protection, not just identification of victims (see
_R (TDT) v. Secretary of State for the Home Department [2018] 1 WLR 4922, per Underhill LJ at [31]-[36])._

(9) In relation to identification, the ECAT and other relevant international instruments contain no provisions
requiring the state to provide any right of appeal or reconsideration at all. It is matter of policy choice that
the United Kingdom has chosen, through the CA guidance, to provide for a right of reconsideration.

(10) That provision goes above and beyond the obligations of the United Kingdom under the ECAT. It is
therefore not a legitimate basis of challenge to the defendant's policy to assert that not every part of the
duty to identify victims is discharged through the policy framework of the SCA, within the NRM.

(11) Nonetheless, Mr Bramley's evidence is that the defendant “would expect a pragmatic approach to be
taken in respect of reconsiderations”. For example, new material could come to light via a different first
responder from the one that initially referred the person concerned into the NRM. A legal representative
could approach a first responder or support provider and request it to make a request for reconsideration.

(12) The reconsideration policy is not above and beyond the law, but subject to it. If it is not lawfully
operated, judicial review may be available. Furthermore, the policy is under review and the government is
committed to introducing fresh statutory guidance this year under section 49 of the **_Modern Slavery Act_**
2015, as Mr Bramley explains in his written evidence.

50. I have carefully considered these rival contentions. I come to my reasoning and conclusions. Both
parties agree that the state is under a duty to identify victims of human trafficking, undertaken by the United
Kingdom by signing up to the obligations in the ECAT and arising also under article 4 of the ECHR and the
Anti-Trafficking Directive. The parties agree that the United Kingdom is required to perform this duty.

51. The parties also agree that the duty to identify victims of human trafficking is performed by the SCA,
i.e. by members of the defendant's staff, on behalf of the United Kingdom, as its chosen instrument, in
accordance with the administrative processes of the NRM. I agree with Mr Irwin, for the defendant, that in
respect of the NRM the first responders and support providers can be likened to the eyes and ears and the
SCA as its brain.

52. I also agree with Mr Irwin that there is nothing wrong with entrusting to the first responders and support
providers the task of receiving and considering requests for reconsideration of individual cases and
submitting them to the SCA, where those bodies are presented with information and evidence (which will
usually be fresh evidence not previously available) that in the opinion of that body raises a real possibility
that a previously taken rejection decision may be wrong or flawed.

53. This form of triage is plainly lawful, provided it does not replace and usurp the decision making
function of the SCA. For example, a first responder or support provider might take the view that a request
for reconsideration presented to it is ill-founded and without merit In such a case the body forming that


-----

view may inform the SCA that the issue has been raised and of the reasons why in its view the request for
reconsideration lacks merit.

54. In such a case, there would be no legal difficulty with the SCA deciding on a summary basis that it
agreed with the view of the referring body (first responder or support provider) and declining to entertain
the request for reconsideration, adopting the view and reasoning of the referring body. In such a case,
there would be no failure by the United Kingdom (through the SCA) to perform its identification duty.

55. I also agree with Mr Irwin that a nimble NRM with swift decision making is a laudable and desirable
policy objective which should be promoted and nurtured. Although the stated deadlines may prove
unrealistic, for example in cases such as this where information has to be obtained from the authorities in
other countries, it is right that the NRM should operate in a manner that promotes early certainty and
avoids prolonged uncertainty and delay.

56. I accept, also, that the defendant is entitled to be concerned about the risk that the NRM's valuable
resources will be sapped by vexatious and time wasting reconsideration requests based on flimsy if any
foundations. This court too, regrettably, sometimes receives representations in writing or orally of the
same kind and, like the defendant, has to strive to protect its resources against unfair consumption, without
missing any good points among the bad ones.

57. The concern is a valid one but I find no suggestion that it arises in cases of reconsideration requests
undertaken by this claimant's solicitors. Ms Frances Lipman, the claimant's solicitor, explains in her written
evidence how the claimant's case came to her attention. In her second statement, she explains that she
has acted in about 40 cases in which negative reasonable grounds or conclusive grounds decisions have
been challenged, of which 27 cases proceeded to issue of judicial review proceedings. The vast majority
have led to the defendant agreeing to reconsider the negative decision.

58. Ms Luh, for the claimant, makes clear in her written submissions (paragraph 57) that the claimant
“does not suggest … that every request for reconsideration must be acceded to; the submission is that
every request must be considered on its own merits”. However, “[w]hat the Defendant cannot do is refuse
to consider the request at all, yet that is how her administrative process is intended to work if a victim does
not go through the correct administrative process…”, i.e. via a first responder or support provider.

59. The concession that not every reconsideration request must be acceded to is, with respect, plainly
correct. The SCA can give short shrift to time wasters. However, there is real force in the second part of
Ms Luh's proposition: that the SCA cannot refuse to consider a reconsideration request at all, merely
because it does not come from a first responder or support provider.

60. I am not able to accept the submission of Mr Irwin that the spectre of disruption to the important work
of the SCA provides legal justification for the policy under challenge in this case, if the policy is tainted with
the vices of rigidity, institutional disregard of potentially relevant evidence and unlawful delegation of the
state's duty to identify victims of human trafficking.

61. I must therefore consider whether the policy does, in substance, display those vices. I return to the
wording of the policy. It refers to the informal arrangement whereby reconsideration requests may be
received from a first responder or support provider. The arrangement “does not extend to other parties
such as legal advisors and non governmental organisations outside the NRM”. Those third parties “could
ask the support provider or first responder involved in the case to request a reconsideration”.

62. However, “[a] support provider or first responder is not obliged to consider that request or provide
reasons for not making a reconsideration request”. So, if approached by a person (or her relative or friend
or lawyer) claiming to be a victim of trafficking, whose claim to be one has already been rejected by the
SCA, the first responder or support provider may simply ignore the approach or tell the person to go away,
without considering the case.

63. It is therefore not adequate for Mr Irwin to submit, or Mr Bramley in his written evidence to point out,
that an individual or legal representative could approach the first responder or support provider involved in


-----

the case (or, perhaps, a different one not previously involved in the case) and ask that body to make a
reconsideration request to the SCA.

64. The policy permits such an approach to be ignored without considering whether the case for
reconsideration is good or bad. The case need not, under the policy, be considered by the first responder
or the support provider, let alone the SCA. The latter would not even be made aware of any refused
request to reconsider a negative decision.

65. The policy then goes on to instruct the SCA's trained staff to reject requests for reconsideration from
alleged victims or their legal or other representative made directly to the SCA. Such a request should be
met, says the policy, with the riposte that:

“reconsideration requests of NRM decisions may only be made by first responders or support providers
involved in the case. You are not the first responder or support provider involved in this NRM case so
under the published guidance we cannot [my italics] reconsider the NRM decision based on your request.
…”

66. The standard response then states that it is “open to you to request a reconsideration via a first
responder or a support provider involved in the case” and that “if a support provider or first responder
submits a reconsideration request … it may be considered [by the SCA] in line with the published
guidance.” But, as I have explained, the policy permits support providers and first responders not to
consider the merits of the matter at all.

67. The NRM process plainly and correctly includes a discretionary power to reopen negative decisions.
The discretion must be exercised in accordance with the duty to identify victims. I accept Ms Luh's
submissions on the nature of that duty: it must be performed of the state's own motion; it is a continuing
duty; and if there has been a prior negative decision, relevant evidence casting doubt on the correctness of
that decision must not be disregarded.

68. To hold otherwise would be to dilute the content of the duty and water down the protection afforded to
victims of trafficking by ECAT, the Anti-Trafficking Directive and article 4 of the ECHR, which is absolute
and may not be subject to derogation even in time of war or other national emergency. If victims of
trafficking could be denied that protection for administrative reasons, the NRM would not be operating in
compliance with the international obligations of the United Kingdom.

69. The discretionary power to reopen negative decisions (both at the reasonable grounds stage and the
conclusive grounds stage) is vested in the SCA, according to the process set out in the CA guidance
explaining the operation of the NRM. It is not vested in the first responders, nor in the support providers. It
used to be vested also in the NCA, but no longer.

70. As administrative lawyers know, “[a] discretionary power must, in general, be exercised only by the
public authority to which it has been committed. It is a well-known principle of law that when a power has
been conferred to a person in circumstances indicating that trust is being placed in his individual judgment
and discretion, he must exercise that power personally unless he has been expressly empowered to
delegate it to another” (de Smith's Judicial Review, 8th edition (2018) at 5-159)).

71. The footnote to that passage (footnote 518) includes a brief discussion of the origin and scope of the
maxim _delegatus non potest delegare and there follows some discussion of exceptions to the principle,_
including the _Carltona principle that ministers act through civil servants, enabling the civil service to_
function effectively. Mr Irwin did not suggest the present case is one where that principle or any other
exception to the doctrine can be invoked.

72. In my judgment, this policy does entail an abdication of the state's responsibility to perform the
identification duty, in cases where a negative decision needs reconsidering in the light of relevant new
material and the request for reconsideration is made directly to the SCA, not by a first responder or support
provider but by a victim or victim's friend or relative or representative.

73. An attempt is made to answer that charge by Mr Bramley's evidence that government would “expect a
pragmatic approach to be taken in respect of reconsiderations”; so that for example reconsideration might


-----

be requested by a different first responder from the one that made the initial referral to the NRM; although
that is not what the CA guidance states.

74. However, Ms Kate Garbers, managing director of Unseen UK, a first responder and support provider,
gives evidence that her organisation's contract terms do not include any duty to request reconsiderations
and that there is no written guidance available to the organisation from the defendant indicating when such
a request should be made.

75. In her statement, Ms Garbers explains why support provider staff in her organisation cannot be
expected to have the expertise to spot flawed rejection decisions and do not have access to relevant
documents that would be needed to support a reconsideration request.

76. Ms Rachel Smith, now of the Human Trafficking Foundation (not a first responder or support provider)
formerly worked for an organisation called Hestia, now a contracted support provider, previously also a first
responder. Her evidence is that when Hestia did request reconsideration of negative decisions, that was
done on the limited basis of the information available to the relevant support worker during the period of his
or her involvement with the potential victim.

77. Hestia was not in a position, says Ms Smith, to request further documents beyond those already
available to the client and was not able to put the reconsideration process on hold pending receipt of
further evidence such as reports from a doctor or counsellor which might have persuaded the SCA to
reopen a negative decision.

78. Those witness statements were served on the defendant in September 2019, together with Ms
Lipman's evidence already mentioned. That evidence has not been contradicted or commented on by the
defendant. It is unchallenged.

79. Mr Irwin also pointed out that refusals to reconsider individual negative decisions, applying the
reconsideration policy, are subject to challenge by judicial review if made unlawfully. That is true. Ms
Lipman's experience of bringing such challenges shows that, indeed, the policy is being defeated in some
individual cases by judicial review or the threat thereof. The very lawyers the policy seeks to exclude are
forcing departures from it.

80. The availability of judicial review does not make the policy lawful if it is otherwise unlawful. The
evidence before me indicates willingness to depart from the policy under direct threat of litigation but I have
no evidence of any broader willingness on the SCA's part to entertain reconsideration requests outside the
policy, other than under threat of litigation. That does not surprise me because to do so would contradict
the terms of the CA guidance.

81. I note also that the wording of the policy encourages potential victims and their legal representatives to
approach a first responder or support provider. Presumably, this could lead to refusals by those bodies to
consider the matter at all, which would accord with the wording of the policy, as I have explained above.

82. Victims' lawyers might then consider bringing a judicial review of such a refusal. Or the victim's lawyer
might succeed in enlisting the support of such a body by persuading it to act as a “postbox”. The salvation
of the victim's cause might then turn on the happenstance that an enterprising lawyer is able, or unable, to
obtain help from a sympathetic first responder or support organisation.

83. These dismal thoughts lend force to the proposition that the real vice lies in the policy itself. There is
also force in Ms Luh's argument that the restrictive nature of the policy impairs the effectiveness of the
victim's remedy of reconsideration as a safeguard against breach of the duty to identify victims of human
trafficking; and that the reconsideration policy operates arbitrarily, inconsistently and without transparency.

84. There is evidential support for that proposition. But I prefer to rest my decision primarily on the words
of the policy itself. On its face, it is rigid and does not admit of exceptions. However strong the merits of a
case for reconsideration, the identity of the requesting person may determine whether the request is
considered or ignored. In my judgment, that is an unlawful fetter on the discretion to reopen negative
decisions.


-----

85. For those reasons, the reconsideration policy under challenge is not lawful. The claim succeeds.
Subject to any further submissions, I think this judgment is sufficient remedy for the illegality and that an
order attempting to declare the extent of the illegality could be difficult to formulate and would add nothing
of substance to the judgment itself. The government is already committed to reviewing the policy.

**End of Document**


-----

