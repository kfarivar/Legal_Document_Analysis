# Basfar v Wong UKEAT/0223/19

EMPLOYMENT APPEAL TRIBUNAL

SOOLE J (SITTING ALONE)

20 NOVEMBER 2019, 31 JANUARY 2020

31 JANUARY 2020

M Sethi, S Berry for the Appellant

P Webb, I Shrivastava for the Respondent

Reynolds Porter Chamberlain LLP; Wilson & Co Solicitors

_SUMMARY_

_DIPLOMATIC IMMUNITY_

The Claimant was employed by the Respondent diplomat to work as a domestic servant at his diplomatic residence
in the UK, having previously been employed by him in his diplomatic household in Saudi Arabia. By her ET1 form
she contended that she was a victim of international trafficking by the Respondent and had been employed in
conditions amounting to modern slavery. She made complaints including wrongful (constructive) dismissal, failure
to pay the National Minimum Wage, unlawful deductions from wages and breach of the Working Time Regulations
_1998. The Respondent applied to strike out all the claims (which were denied) on the basis of diplomatic immunity,_
contending that his employment of the Claimant did not constitute a 'commercial activity exercised…outside his
official functions' within the meaning of art 31(1)(c) of the _Vienna Convention on Diplomatic Relations 1961 as_
enacted into domestic law by s.2(1) _Diplomatic Privileges Act 1964. The application proceeded on the basis of_
assumed facts as pleaded in the ET1.

The Employment Tribunal dismissed the application and the defence of diplomatic immunity. In doing so, it held that
(i) the decision of the Court of Appeal in Reyes v Al-Malki [2015] ICR 289on the meaning of 'commercial activity' in
a case involving similar assumed facts was not binding in circumstances where the Supreme Court had allowed the
appeal on another ground (R v Secretary of State for the Home Department, ex parte Al-Mehdawi [1990] 1 AC
876followed); and (ii) the non-binding observations of three Justices of the Supreme Court in Reyes (Lord Wilson,
Baroness Hale and Lord Clarke) on the meaning of 'commercial activity' were to be preferred to those of the Court
of Appeal and two Justices of the Supreme Court (Lord Sumption and Lord Neuberger).

The EAT allowed the Respondent's appeal. It rejected his argument that the decision of the Court of Appeal on
'commercial activity' was binding (Al-Mehdawi considered); but held that the current state of the law on that issue
was represented by the conclusion in _Reyes of Lords Sumption and Neuberger and the Court of Appeal._
Accordingly, it held that the defence of diplomatic immunity succeeded.

**SOOLE J:**

(reading the judgment of the court)


-----

**[1] This appeal concerns the defence of diplomatic immunity. The particular question is whether a serving**
diplomat's employment of a 'trafficked' domestic servant at his diplomatic residence constitutes a 'commercial
activity exercised…outside his official functions' within the meaning of art 31(1)(c) of the _Vienna Convention on_
_Diplomatic Relations 1961 ('the 1961 Convention') as enacted into domestic law by s 2(1) Diplomatic Privileges Act_
_1964. The appeal in turn raises a question on the doctrine of precedent. I will refer to the parties as the Claimant_
and Respondent.

**[2] The Respondent appeals from the Judgment of the Employment Tribunal at London Central (Employment**
Judge Brown) ('the Tribunal') sent to the parties on 13 June 2019 following a hearing on the Respondent's
application that the Claimant's claims should be struck out on the ground of diplomatic immunity. The Tribunal
dismissed the application.

**[3] The application proceeded on the agreed basis that the Claimant's case should be considered at its highest, i.e.**
on assumed facts, as pleaded in her ET1 claim. In essence, this is that in circumstances of modern slavery the
Claimant was trafficked by the Respondent to the UK in order to work as a domestic servant in his diplomatic
residence.

**[4] The assumed facts may be taken shortly from the Judgment. The Claimant is of Philippine nationality. She was**
employed by the diplomatic household of the Respondent in Saudi Arabia from November 2015. On 1 August 2016,
she was brought to the UK to continue working for the Respondent in this country. The UK Border Agency issued
her with an Overseas Domestic Workers Visa as a private servant in a diplomatic household. In order to obtain that
visa she was provided with a contract or statement of main terms and conditions of employment. These included
employment to work 8 hours a day, 50 hours per week, with 16 hours free time each day and 1 day off work each
week and 1 month off each year. She was to be provided with sleeping accommodation and paid at the National
Minimum Wage.

**[5] On the assumed but disputed facts, her employment and treatment bore no relation to these apparent terms**
and conditions and amounted to circumstances of **_modern slavery. She was a victim of international trafficking,_**
exploited by the Respondent and his family. It is agreed that the Respondent was at all material times, and remains,
a serving diplomat in this country and that he employed the Claimant to work in his official diplomatic residence.

**[6] By the Claimant's ET1 form presented on 18 October 2018, she brought complaints of wrongful (constructive)**
dismissal, failure to pay the National Minimum Wage, unlawful deductions from wages, claims under the Working
_Time Regulations 1998, failure to provide written wage slips and failure to provide written employment particulars._
The form states that her employment ended on 24 May 2018.

**[7] Article 31(1) of the 1961 Convention provides, so far as relevant:**

'1. A diplomatic agent shall enjoy immunity from the criminal jurisdiction of the receiving State. He shall also
enjoy immunity from its civil and administrative jurisdiction except in the case of:…

(c) an action relating to any professional or commercial activity exercised by the diplomatic agent in the
receiving State outside his official functions.'

**[8] Article 39(2) provides, as relevant:**

'2. When the functions of a person enjoying privileges and immunities have come to an end, such privileges
and immunities shall normally cease at the moment when he leaves the country, or on expiry of a reasonable
period in which to do so, but shall subsist until that time… However, with respect to acts performed by such a
person in the exercise of his functions as a member of the mission, immunity shall continue to subsist.'

**[9] With one important qualification, the assumed facts of this case are materially the same as those in Reyes v Al-**
_Malki [2014] ICR 135, [2015] ICR 289and [2017] ICR 1417('Reyes'). The qualification is that in_ _Reyes the_
respondent ceased to be a serving diplomat in the course of the litigation, namely on 29 August 2014 between the
decision in the EAT and the hearing in the Court of Appeal. This change in the facts was not treated as material in


-----

the Court of Appeal but was decisive in the Supreme Court. As will be seen, this becomes potentially relevant on
the issue of precedent.

**[10] Before the Tribunal, the Claimant contended that there was a further difference from the assumed facts in**
_Reyes. In that case it was not clear that the respondent had personally trafficked the employee. However, the_
Tribunal concluded that this was not a material difference from the assumed facts in the present case ([53]); and the
Claimant has not pursued that argument in answer to this appeal.

**[11] It is common ground that the binding effect of the Supreme Court decision in Reyes is that, on the assumed**
facts, the Respondent's activity was 'outside his official functions' within the meaning of art 31(1)(c). Accordingly,
the sole issue under the Article is whether it was 'relating to any…commercial activity' exercised by him in the UK.

**[12] The Respondent's first submission before the Tribunal was that it was bound by the decision of the Court of**
Appeal in _Reyes to conclude that his employment of the Claimant did not constitute 'commercial activity'. The_
Claimant's response was that the effect of the subsequent Supreme Court decision was that the Court of Appeal
decision on that point was persuasive only; and that the non-binding observations on the point of three Justices of
the Supreme Court (Lord Wilson JSC, Baroness Hale of Richmond PSC and Lord Clarke of Stone-cum-Ebony)
should be preferred. The Respondent's alternative submission was that the non-binding observations of the two
other Justices (Lords Sumption JSC and Neuberger of Abbotsbury), together with the unanimous decision of the
Court of Appeal, should be preferred. The first issue on precedent depends on the correct interpretation of the
decision of the Court of Appeal in R v Secretary of State for the Home Department, ex parte Al-Mehdawi [1990] 1
AC 876('Al-Mehdawi'). For convenience of reference only, I will refer to the two groups of Supreme Court Justices
as 'the majority' and 'the minority' respectively.

**[13] The Tribunal accepted the submissions of the Claimant and held that (i) the decision of the Court of Appeal**
was not binding [55-73] and (ii) the observations of the majority in the Supreme Court were to be preferred [74-88].
Accordingly, the defence of diplomatic immunity was rejected.

_REYES V AL-MALKI_

**[14] It is necessary to start with the history and reasoning of the successive decisions in Reyes. The employment**
tribunal rejected Mr Al-Malki's defence of diplomatic immunity, accepting the claimants' argument that the defence
constituted a procedural bar which was in breach of art 6 of the ECHR.

**[15] On the respondent's appeal to the EAT, the claimants conceded that a literal application of the words**
'commercial activity' did not permit the claims to proceed [8]. The concession was based on the statement of Laws
J, as he then was, in Propend Finance Pty Ltd v Sing (1997) 111 ILR 611 that 'commercial activity' referred to any
'activity which might be carried on by the diplomat on his own account for profit' (p.635). However, the claimants
reserved the right to argue at a higher level that a broader view should be taken of the words 'commercial activity'.
In allowing the respondent's appeal, Langstaff P agreed with the employment tribunal that the activity was outside
his 'official functions'; but held that art 6 was no bar to reliance on the immunity.

**[16] The claimants' appeal to the Court of Appeal was heard in November 2014. In his judgment, Lord Dyson MR**
noted that the two claimants had been employed for periods in 2011; and that 'The employers have now left the
United Kingdom' [1-2]. This reflected the fact, subsequently recorded in the judgment of Lord Sumption [4], that the
respondent's posting in London had come to an end on 29 August 2014. However the hearing before the Court of
Appeal proceeded without consideration of art 39(2). Under art 31(1)(c) the claimants advanced the argument,
which they had reserved below, that their employment by the respondent did constitute 'commercial activity' by him.

**[17] The Court of Appeal rejected that argument. In an extensive analysis, following a wide-ranging review of**
international and domestic material on the _1961 Convention in general and art 31 in particular, Lord Dyson (with_
whom Arden and Lloyd Jones LJJ agreed) held that the actions of the respondent neither constituted 'commercial
activity' nor were exercised by him 'outside his official functions'. Lord Dyson considered the meaning of
'commercial activity' with particular regard to the interpretative principles of the _Vienna Convention on the Law of_


-----

_Treaties 1969 ('the 1969 Convention'); the overall scheme of the_ _1961 Convention; the travaux preparatoires;_
domestic and international authority; and the 'trafficking dimension'.

**[18] Having reached his conclusion Lord Dyson observed:**

'This may appear to be an affront to one's sense of justice and fairness, but...it is salutary to bear in mind the
concluding words of the decision in Tabion v Mufti 73 F 3d 535, para 15 : “there may appear to be some
unfairness to the person against whom the invocation occurs. But it must be remembered that the outcome
merely reflects policy choices already made. Policymakers…have believed that diplomatic immunity not only
ensures the efficient functioning of diplomatic missions in foreign states, but fosters goodwill and enhances
relations among nations. Thus, they have determined that apparent inequity to a private individual is
outweighed by the great injury to the public that would arise from permitting suit against the entity or its agents
calling for application of immunity” [77].

**[19] The Supreme Court decided Ms Reyes' appeal on a different ground based on the fact that on 29 August 2014**
the respondent's posting in London had come to an end; and that in consequence any entitlement to continuing
immunity depended on the provisions of art 39(2). With the support of all other members of the Court, Lord
Sumption held that the employment of Ms Reyes by the respondent constituted acts which were clearly outside his
'functions as a member of the mission' within the meaning of art 39(2); and that accordingly the respondent was no
longer entitled to any immunity: [48]. The appeal was allowed on that basis alone.

**[20] Thus the judgments of the Supreme Court on the position under art 31(1)(c) are not binding: see Lord**
Sumption at [51] and Lord Wilson at [56-57]. However, the Court heard full argument on the point. As to the words
'outside his official functions', those functions were treated as having the same meaning as 'his functions as a
member of the mission' in art 39(2): [50]. In consequence the present Respondent does not dispute that his
activities were outside his official functions; and the sole focus is on the issue of 'commercial activity'.

**[21] The judgment of Lord Sumption (with whom Lord Neuberger agreed) considered and answered this point**
comprehensively. It rejected the argument that the assumed actions of the respondent employer, including its
trafficking dimension, constituted 'commercial activity'.

**[22] Without attempting an exhaustive summary, the following points in the reasoning are particularly noteworthy.**
First, that the 'exercise' of a professional or commercial activity '… means practising the profession or carrying on
_the business. The diplomatic agent must be a person practising the profession or carrying on (or participating in_
_carrying on) the business. He must, so to speak, “set up shop” [21(2)]. This was the gist of the reasoning of Laws J_
in Propend [21(3)].

**[23] Secondly, that any wider scope for the exception would have the effect that the immunity in respect of non-**
official acts would mean very little, 'for every purchase that a diplomat might make in the course of his daily life from
_a business carried on by someone else would be a commercial activity exercised by the diplomat for the purpose of_
_art 31(1)(c)', which in turn would be contrary to the carefully constructed scheme of the 1961 Convention: [21(6)]._

**[24] Thirdly, that the authorities most directly in point are from the United States, notably the leading case of**
_Tabion v Mufti 73 F 3d 535. Whilst that and other decisions were influenced by the State Department's 'Statement_
of Interest' and the constitutional division of powers which requires US courts to show 'substantial deference' to the
executive's views on such matters, that did not undermine their authority: [25].

**[25] Fourthly, that this interpretation was not undermined by the 'trafficking dimension' or the related provisions of**
the 'Palermo Protocol' (2000), i.e. the Protocol to Prevent, Suppress and Punish Trafficking in Persons, Especially
Women and Children'. By way of analogy _'…if I knowingly buy stolen property from a professional fence for my_
_personal use, both of us will incur criminal liability for receiving stolen goods and civil liability to the true owner for_
_conversion. The fence will also be engaging in a commercial activity. But it does not follow that the same is true of_
_me. 46. For the same reason, it cannot matter that the trafficking may enable the ultimate employer to pay the_
_victim less than the proper rate or nothing at all. To pursue the analogy, I will no doubt pay the fence less for the_
_stolen goods than I would have had to pay for the same goods to an honest shopkeeper. But that does not alter the_


-----

_characterisation of my purchase, which is no more the exercise by me of a commercial activity in the one case than_
_it is in the other. Likewise, the employment of a domestic servant to provide purely personal services cannot_
_rationally be characterised as the exercise of a commercial activity if she is paid less than the going rate or the_
_national minimum wage, but not if she is paid more. One might perhaps loosely say that the victim is being treated_
_as a commodity. But a figure of speech should not be confused with a legal concept.': [45-46]._

**[26] Lord Sumption concluded that if the respondent had still been in post and the question had therefore arisen for**
direct decision, '… I would have held that he was immune, because the employment and treatment of Ms Reyes did
_not amount to carrying on or participating in carrying on a professional or commercial activity. Her employment,_
_although it continued for about two months, was plainly not an alternative occupation of Mr “Al-Malki's''. Nothing that_
_was done by him or his wife was done by way of business…There is no sense which can reasonably be given to art_
_31(1)(c) which would make the consumption of goods and services the exercise of a commercial activity.' [51]._

**[27] Lord Wilson, with whom Baroness Hale and Lord Clarke agreed, stated that he was pleased that the Court**
would not be answering the central question under art 31(1)(c) in any binding form. He continued: 'Lord Sumption
_JSC's emphatic answer to the question is “no”. His answer is (if he will forgive my saying so) the obvious answer. It_
_may be correct. But my personal experience has been that, the more one thinks about the question, the less_
_obviously correct does his answer become.' [57]._

**[28] He then referred to five aspects of the background. First, the evidence demonstrating that the UK confronted a**
significant problem in relation to the exploitation of migrant domestic workers by foreign diplomats [59]. Secondly,
the universality of the international community's determination to combat human trafficking [60]. Thirdly, the
definition of trafficking in the Palermo Protocol and the subsequent Council of Europe Convention on Action against
_Trafficking in Human Beings (2005), which endeavoured to encompass the whole sequence of actions that leads to_
the exploitation of the victim [61]. In consequence he questioned the suggested analogy between an employer of a
trafficked migrant and a purchaser of stolen goods at a cheap price : '…another rational view is that the relevant
_“activity” is not just the so-called employment but the trafficking; that the employer of the migrant is an integral part_
_of the chain, who knowingly effects the “receipt” of the migrant and supplies the specified purpose, namely that of_
_exploiting her, which drives the entire exercise from her recruitment onwards; that the employer's exploitation of the_
_migrant has no parallel in the purchaser's treatment of the stolen goods; and that, in addition to the physical and_
_emotional cruelty inherent in it, the employer's conduct contains a substantial commercial element of obtaining_
_domestic assistance without paying for it properly or at all” [62]._

**[29] Fourthly, that diplomatic immunity was an aspect of state immunity; and thus it was relevant to take account of**
s.3(3) of the State Immunity Act 1978 whose definition of a 'commercial transaction' excluded from state immunity
'any contract for the supply of goods or services'. Section 16(1)(a) of that statute, which purported to provide
immunity where the proceedings concerned the employment of the members of a mission including staff in its
domestic service, could be disregarded as incompatible with art 6 _ECHR:_ _Benkharbouche v Embassy of the_
_Republic of Sudan [2019] AC 777. He continued: 'I cannot readily explain why proceedings relating to a contract of_
_employment entered into by a foreign state, for performance in the UK, will not in principle attract immunity in_
_circumstances in which, if the contract is entered into by a diplomat, it will in principle attract immunity' [65]._

**[30] Fifthly, if the purpose of diplomatic immunity as defined in the 1961 Convention was 'not to benefit individuals**
but to ensure the efficient performance of the functions of diplomatic missions as representing states', a question
arose as to how that purpose accorded with a result which gave diplomatic immunity in circumstances where, as
here, there was no apparent link between the duties of the employee and the official functions of the diplomatic
employer [66].

**[31] On the other side of the scale, Lord Wilson recognised two 'perceived problems'. First, art 31(1) of the 1969**
_Convention required the interpretation of treaties to be undertaken in accordance with the ordinary meaning to be_
given to its terms, in their context and in the light of its object and purpose. He was persuaded that, when agreeing
to the terms of the 1961 Convention, the parties would have rejected any suggestion that the proceedings brought
by Ms Reyes related to any commercial activity exercised by Mr Al-Malki [67].


-----

**[32] However, in contrast to Lord Sumption's opinion, he was '… less persuaded that, even if (which is debatable)**
_art 31 of the 1961 Convention does not by its terms contemplate any future development of its meaning, the latter_
_would have been unable to develop over 56 years. Article 31(3)(c) of the Vienna Convention on the Law of Treaties_
_requires the interpretation of an article to take account of any relevant rules of international law applicable in the_
_relations between the parties; and the requirement is not further qualified.' [67]. He indicated that this in turn could_
allow an interpretation which took account of the emergence of an international prohibition against trafficking.

**[33] The second perceived problem was that an international treaty calls for international interpretation by**
reference to 'broad principles of general acceptation'; and not least in respect of protection to be afforded to
diplomats serving abroad. Thus, it would be a 'strong thing for this court to divert from the US jurisprudence set out
_in Tabion…and to adopt the robust interpretation of art 31(1)(c) for which Ms Reyes contends.' Conversely, '…it is_
_difficult for this court to forsake what it perceives to be a legally respectable solution and instead to favour a_
_conclusion that its system cannot provide redress for an apparently serious case of domestic servitude here in our_
_capital city.' Lord Wilson concluded: 'In the event my colleagues and I are not put to that test today.” Far preferable_
_would it be for the International Law Commission, midwife to the 1961 Convention, to be invited, through the_
_mechanism of art 17 of the statute which created it, to consider, and to consult and to report upon, the international_
_acceptability of an amendment of art 31 which would put beyond doubt the exclusion of immunity in a case such as_
_that of Ms Reyes' [68]._

**[34] In their short following judgment, Baroness Hale and Lord Clarke observed that, had the proper construction of**
art 31(1)(c) risen for decision, '…we would associate ourselves with the doubts expressed by Lord Wilson JSC as to
_whether the construction adopted by Lord Sumption JSC in this particular context is correct especially in the light of_
_what we would regard as desirable developments in this area of the law.' [69]._

_PRECEDENT_

**[35] In** _Al-Mehdawi, the Court of Appeal was faced with the question of whether it was bound by its previous_
decision in a case (R v Diggines, Ex parte Rahmani [1985] QB 1109('Rahmani')) where, on appeal to the House of
Lords ([1986] AC 475), it had been held that the issue determined both at first instance and by the Court of Appeal
did not arise on a true view of the relevant facts and law. The Court held that it was not so bound, albeit its previous
decision was strong persuasive authority: pp 881A-883C. However, the present parties disagree as to the true ratio
of its decision to that effect.

**[36] In** _Rahmani, an immigration adjudicator, in purported exercise of a power under r 12 of the_ _Immigration_
_Appeals (Procedure) Rules 1972, had dismissed an appeal without a hearing. At first instance and in the Court of_
Appeal it was held that the denial of a hearing was a breach of the rules of natural justice. On appeal to the House
of Lords the important question of principle was whether a power conferred by statute and exercised without
procedural impropriety or irregularity could nonetheless be quashed upon judicial review for breach of the rules of
natural justice. However, at the hearing the House raised the point that r 12 had no application to the particular
facts; and dismissed the appeal on that sole basis.

**[37] In Al-Mehdawi, Counsel for the Secretary of State (Mr John Laws) submitted that the case of Rahmani must**
be seen as one continuous piece of litigation; and in consequence its true ratio was the simple one propounded in
the House of Lords and the views expressed by the Court of Appeal on the issue of principle, albeit of high
persuasive value, were not binding on that Court: p 881E. He submitted that the three established exceptions to the
principle of stare decisis identified in _Young v Bristol Aeroplane Co Ltd [1944] KB 718, 729 were not exhaustive:_
_“They may well be inapt where the House of Lords, in giving the final decision of a case, expressly indicates that on_
_the true facts, the issue resolved by the Court of Appeal did not require to be decided.” (pp.881H-882A)._
Alternatively, such a case might be akin to the second exception in _Young v Bristol Aeroplane, namely that_ _“The_
_court is bound to refuse to follow a decision of its own which, though not expressly overruled, cannot, in its opinion,_
_stand with a decision of the House of Lords.”: Young at p 729._

**[38] In considering these submissions, Taylor LJ observed that the House of Lords in Rahmani had gone further**
than stating simply that the issue below did not arise for decision. Lord Scarman had stated: “Your Lordships have


-----

_not, therefore, considered, nor have they heard arguments upon, the point of principle which was the ground of_
_decision in both courts below. Accordingly I express no opinion on the point. I must not be understood to have_
_indicated even a provisional view upon the soundness or otherwise of the alleged principle. Indeed, it would be_
_dangerous, in my view, to discuss the point save in a case where the circumstances and the facts require it to be_
_decided.” (p.478). Taylor LJ commented “It would be strange indeed if despite those final words, the decision of this_
_court is to be regarded as binding authority on the point of principle.” (p 882E)._

**[39] Counsel for Al-Mehdawi submitted that the ratio of a court's decision remained binding even if the facts upon**
which the court based it subsequently turned out to be wrong; and cited observations to that effect by A.L. Goodhart
in his essay 'Determining the ratio decidendi of a case' (Yale Law Journal, Vol XL, No.2, p 161 (1930)). To this
Taylor LJ responded: _“But here, it is not merely that knowledge subsequent and extraneous to the proceedings_
_shows the facts to be wrong; the House of Lords in the very case, giving its final opinion, has ruled that the issue_
_determined below did not arise for decision.”: p 883B._

**[40] Taylor LJ (with whom Nicholls and O'Connor LJJ agreed) concluded that the Court was not bound by its**
reasoning in Rahmani, albeit it was of powerful persuasive influence: p 883C. He suggested that, if the case should
go further, the House of Lords might consider it appropriate to consider stare decisis in this context “… in which a
_decision of their Lordships' House may neither overrule nor be on all fours with the decision of this court in the_
_same case.”: pp 883H-884A. The House declined the invitation: p 894B. In doing so Lord Bridge of Harwich_
described the successful submission in the Court of Appeal as that “Ex parte Rahmani was not of binding authority
_since the House of Lords had decided the case on a different ground and had held that the point of principle_
_decided by the Court of Appeal did not arise.”: p 893H- 894A._

**[41] On behalf of the Respondent, Mr Sethi QC submitted here and below that the true ratio of the decision on**
precedent in Al-Mehdawi is that the Court of Appeal is not bound by its previous decision where the House of Lords,
in deciding the case on a different factual basis, has expressly ruled that on the true facts the issue resolved by the
Court of Appeal did not require to be decided by that Court. In support he cites Mr Laws' submissions at p 882A and
Taylor LJ's statement at p 883B that “the House of Lords in the very case, giving its final decision, has ruled that the
_issue determined below did not arise for decision.” The Supreme Court had made no such express ruling in its_
decision in Reyes. Accordingly, the decision in the Court of Appeal on the issue of whether the activities constituted
'commercial activity' was binding on itself and therefore all lower courts and tribunals.

**[42] On behalf of the Claimant, Ms Webb responded that the true ratio of** _Al-Mehdawi was that a case must be_
considered as one continuous piece of litigation; and that accordingly its true ratio was to be found in the decision at
the highest level in the litigation. This was Mr Laws' essential and successful submission: p 881E. Accordingly the
Court of Appeal's decision on the meaning of 'commercial activity' formed no part of the binding ratio in Reyes; and
was persuasive only. She cited in support subsequent decisions of the Court of Appeal (Brownlie v Four Seasons
_Holdings Incorporated [2016] 1 WLR 1814) and at first instance (Iranian Offshore Engineering and Construction CO_
_v Dean Investment Holdings SA [2019] 1 WLR 82)._

**[43] In Brownlie, the Court of Appeal had to consider the status of its previous decision on a particular issue, in**
circumstances where the Supreme Court had reversed the result on another ground and therefore did not have to
deal with the particular issue: _OPO v MLA [2014] EMLR 4; [2015] 2 WLR 1373. Citing_ _Al-Mehdawi, Arden LJ_
accepted that the decision of the Court of Appeal in OPO on that issue was “… no longer binding under the doctrine
_of precedent, though it would constitute strong persuasive authority…” [89]._

**[44] In Iranian Offshore Engineering, Andrew Baker J observed, in respect of the substantive issue considered by**
the Court of Appeal in OLO and in Brownlie that “Further, each decision was reversed by reference to other points
_in the Supreme Court… so that even if those passages had been part of the ratio in the Court of Appeal they would_
_not strictly now bind me.” [12]._

**[45] The Tribunal preferred the Claimant's submissions on the effect of Al-Mehdawi [64-66] and concluded that the**
Court of Appeal decision in Reyes was persuasive only [73.5].


-----

**[46] In reaching its decision on precedent, the Tribunal also took into account its conclusion that the Court of**
Appeal had (at least arguably) given a 'composite answer' to the two questions of whether the respondent's
activities (i) constituted 'commercial activity' and (ii) were carried on within his 'official functions' [62; 73.3]; and Lord
Wilson's statement that he was pleased that the Supreme Court was not giving a binding interpretation on the
issues raised by art 31(1)(c) [71; 73.5].

**[47] In support of the Tribunal's conclusion on the correct interpretation of** _Al-Mehdawi, Ms Webb in this appeal_
cited two further decisions. In Helena Partnerships Ltd v Commissioners for HMRC _[2012] EWCA Civ 569 Lloyd LJ,_
citing Al-Mehdawi, stated “If the decision of the Court of Appeal had not been subject to an appeal, that statement
_might have been part of the ratio decidendi. However, since it was appealed, and since the decision of the House of_
_the Lords went on a different basis, what the Court of Appeal said cannot be regarded as part of the ratio of the_
_case”: [55]._

**[48] In Thorpe v Commissioners HMRC [2009] EWHC 611 (Ch), Sir Edward Evans Lombe (sitting as a judge of the**
High Court) gave detailed consideration to the ratio of Al-Mehdawi [37-41]. Having cited Taylor LJ's judgment at p
883A-B, he concluded: _“It seems to me that in arriving at this conclusion Lord Justice Taylor was accepting the_
_submission of Mr Laws at p 881 that the case had to be considered as one continuous piece of litigation_
_notwithstanding that it was divided into hearings at first instance, in the Court of Appeal and in the House of Lords.”_

[41]. Applying that principle to the particular decision of the Court of Appeal on the issue under review, the Judge
concluded that the decision formed no part of the ratio of the case; and that accordingly, 'though of great persuasive
value', it was not binding on him [41].

_Respondent's submission on precedent_

**[49] In challenging the Tribunal's conclusion on precedent, Mr Sethi submits first that his alternative interpretation**
of the Court of Appeal's decision in Al-Mehdawi is supported by the critical passage in Taylor LJ's judgment where
he drew a distinction between the position where it is “…merely that knowledge subsequent and extraneous to the
_proceedings shows the facts to be wrong” and where “…the House of Lords in the very case, giving its final opinion,_
_has ruled that the issue determined below did not arise for decision.” (p 883B)._

**[50] Secondly, the statements of the Court of Appeal in** _Brownlie and_ _Helena Partnership simply referred to the_
decision in Al-Mehdawi. Accordingly, the only relevant focus must be on the language of that decision. Furthermore,
since _Brownlie was itself overturned in the Supreme Court, it was itself not binding. As to the first instance_
decisions, Iranian Offshore simply depended on Brownlie. As to Thorpe, the judge's identification of the ratio in Al_Mehdawi was wrong and should not be followed._

**[51] Thirdly, he points to the summary of the law in Halsbury's Laws of England, Volume 11 (2015) para 30. Under**
the heading 'Court of Appeal decisions' it states : “The decisions of the Court of Appeal upon questions of law must
be followed by Divisional Courts and courts of first instance and, as a general rule, are binding on the Court of
Appeal until a contrary determination has been arrived at by the Supreme Court. There are, however, three
exceptions to this rule; thus: (1) the Court of Appeal is entitled and bound to decide which of two conflicting
decisions of its own it will follow; (2) it is bound to refuse to follow a decision of its own which, although not
expressly over-ruled, cannot, in its opinion, stand with a decision of the Supreme Court; and further is not bound by
_one of its decisions if the Supreme Court has decided the case on different grounds, ruling that the issue decided_
_by the Court of Appeal did not arise for decision; and (3) the Court of Appeal is not bound to follow a decision of its_
own if given per incuriam.” (emphasis supplied). The footnote to the emphasised proposition cites Al-Mehdawi as
authority.

**[52] He also referred to** _The Law-Making Process, Michael Zander (2015). Under the heading 'Is the Court of_
Appeal bound by its own decisions?' and consideration of the _Young v Bristol Aeroplane exceptions, the author_
states: “A variant of the second exception is where the first case decided by the Court of Appeal goes on appeal to
_the House of Lords which rules that the point decided by the Court of Appeal did not arise for decision. If the issue_
_then comes up again, the Court of Appeal is not bound by its own previous decision – see [Al-Mehdawi]: p 228._


-----

**[53] Fourthly, that in circumstances where (as here) the decision of the Court of Appeal had been made on the**
basis of assumed facts, it was immaterial that the decision of the House of Lords had been made on the basis of a
separate true fact, i.e. that the respondent's diplomatic status had ended. It was commonplace for the Court to
make binding decisions on the basis of assumed facts.

**[54] Fifthly, that the Tribunal was in any event bound as a matter of precedent by the definition of 'commercial**
activity' in _Propend (Laws J) and the EAT decision in_ _Reyes which proceeded on the basis of the claimant's_
concession based on Propend.

**[55] Sixthly, that the Tribunal was wrong to state that the Court of Appeal in** _Reyes had treated the issues of_
'commercial activity' and 'official functions' as a composite question; or to treat that, or Lord Wilson's expression of
pleasure that the observations of the minority were not binding, as relevant to the issue of precedent.

_CONCLUSION ON PRECEDENT_

**[56] In my judgment, for the reasons essentially advanced by Ms Webb here and below, the Tribunal was right to**
conclude that the Court of Appeal decision in Reyes is not binding.

**[57] First, I consider that the decisions of the Court of Appeal in Brownlie and Helena Partnership bind lower courts**
and tribunals as to the correct interpretation of Al-Mehdawi; alternatively, they are highly persuasive authority which
should be followed. Whilst the discussion in those cases involves no detailed analysis of that decision, each
identifies the ratio of Al-Mehdawi in terms to the broad effect that a decision of the Court of Appeal on a particular
issue ceases to bind that Court when an appeal to the Supreme Court is allowed on other grounds and the issue
therefore does not fall for decision. Furthermore, that conclusion is consistent with the proposition that the Court in
_Al-Mehdawi accepted Mr Laws' central submission that a case was to be seen as one continuous and_
unfragmented piece of litigation; and that in consequence the only true ratio was to be found in the decision at the
highest level in the particular litigation.

**[58] Secondly, I respectfully agree with the conclusion of Sir Edward Evans-Lombe in Thorpe that Taylor LJ indeed**
accepted that core submission of Mr Laws; and that accordingly it was the true ratio of Al-Mehdawi. The contrary
argument places undue weight on Taylor LJ's observation that the House of Lords had 'ruled' that the issue
determined below did not arise for decision (p.883B). In that sentence, Taylor LJ was simply drawing a distinction
between the position (i) where subsequent events show the factual basis of a decision to be wrong (decision
remains binding) and (ii) where the highest court concludes that a material change in the facts makes it
unnecessary for it to reach a decision on the issue which was determined below (decision on that issue no longer
binding). He was not suggesting that stare decisis in this context depends on whether the highest court has in its
judgment made an express ruling that it had been unnecessary for the Court of Appeal to reach a decision on the
issue. Nor can I see any principled basis for an interpretation which depends upon any such formalistic
requirement.

**[59] I read Halsbury and Mr Zander's commentary to the same effect. Their respective references to a ruling that**
the point or issue decided by the Court of Appeal 'did not arise for decision' simply mean those cases where the
highest court concludes that it does not need to make a decision on the point decided below. This is further
supported by the statement in _Cross and Harris, Precedent in English Law (4th ed., 1991) – supplied by the_
Respondent after the hearing - which states that 'The Court of Appeal is not bound by a decision of its own where
_the earlier decision was taken on appeal to the House of Lords and the House decided that the point on which the_
_Court of Appeal had given a ruling did not arise for decision' (p 154)._

**[60] Thirdly, I am not persuaded that the position is any different where the decision of the Court of Appeal is**
based on facts which have been assumed rather than found. I can see no good reason why e.g. an interlocutory
decision based on a set of assumed facts should have a different status for the purpose of precedent than a
decision after trial where those facts have been established. I should add that I do not accept the Claimant's
contention that the respondent's status as a serving diplomat was not one of the assumed facts in Reyes.


-----

**[61] Fourthly, if the Court of Appeal's decision in Reyes was not binding on it, I do not accept that the Tribunal was**
nonetheless bound by the decision of Laws J in Propend, let alone by the claimants' qualified concession before the
EAT in Reyes. In any event, the point is now academic at this appellate level.

**[62] For completeness, I agree that the Tribunal was wrong to support its decision on precedent on the additional**
grounds that the Court of Appeal in Reyes had (at least arguably) dealt with the issues of 'commercial activity' and
'outside his official functions' as one composite question; or by reference to Lord Wilson's statement that he was
pleased that the Supreme Court's observations on art 31(1)(c) were not binding. As I understood Ms Webb to
acknowledge, it is clear from Lord Dyson's judgment that he considered those two ingredients of art 31(1)(c) quite
distinctly: see in particular [29]. In my judgment the issue of precedent depends on the correct interpretation of the
decision in Al-Mehdawi.

**[63] My conclusion is that the Court of Appeal's decision on the issue of whether the respondent's conduct**
constitutes 'commercial activity' does not bind that Court. Since the reason for the rule on precedent is that the only
true ratio is that which decided the case in the Supreme Court, it must also follow that lower courts and tribunals are
not bound by the Court of Appeal decision in Reyes. Accordingly, the Respondent's appeal on that ground must be
dismissed.

_WHETHER COMMERCIAL ACTIVITY_

**[64] However the decision of the Court of Appeal on that issue is of course persuasive authority. The second**
question on this appeal is whether the Tribunal was right to prefer the observations of the majority in the Supreme
Court to the reasoning and conclusion of the Court of Appeal and the Supreme Court minority.

**[65] The Tribunal concluded that the correct approach was “to decide which of the non-binding dicta of the superior**
_Courts I should follow”. [77]. For this purpose it first observed that “Ordinarily, a lower court would be likely to follow_
_the dicta of the majority of the Supreme Court in another case brought on identical facts.” [80]. It then concluded_
that it should make the assumption that, had the Supreme Court been required to make a decision on the correct
interpretation of art 31, the majority would not have adopted the construction proposed by Lord Sumption: _“The_
_majority did not agree with that construction” [81]. The Tribunal adopted the reasoning of that majority [82], citing_
various extracts from their judgments [83-86]. It concluded that the claim related to 'commercial activity' exercised
outside the respondent's 'official functions' [87] and thus rejected the defence of diplomatic immunity [88].

_RESPONDENT'S SUBMISSIONS_

**[66] In challenging this conclusion, Mr Sethi makes the following particular submissions. First, that the Tribunal in**
its consideration of _Reyes took no real account of the very detailed reasoning of the Court of Appeal or of the_
Supreme Court minority. After passing references thereto [76-78], its focus turned to the observations of the
Supreme Court majority. It then simply adopted the reasoning of that majority without further consideration and
analysis: [82].

**[67] Secondly, that the Tribunal was wrong to proceed on the basis of an assumption that, if the point had fallen for**
binding decision, the majority would not have adopted the construction proposed by Lord Sumption. That
assumption was unwarranted because the observations of the majority amounted only to expressions of doubt as to
whether the interpretation adopted by the minority and the Court of Appeal was correct. Thus Lord Wilson expressly
accepted that Lord Sumption's 'emphatic' answer to the question 'may be correct' [57]; conceded that when
agreeing to its terms the parties to the 1961 Convention would have rejected any suggestion that the proceedings
brought by Ms Reyes related to any commercial activity exercised by her employer [67]; observed that in the
context of international interpretation of an international treaty it would be a 'strong thing' for the Court to divert from
the US jurisprudence set out in Tabion and to adopt the 'robust interpretation' for which Ms Reyes contended [68];
and stated that it would be preferable for the International Law Commission ('ILC') to be invited to consider, consult
and report upon the international acceptability of an amendment which would put beyond doubt the exclusion of
immunity in such a case [68]. No subsequent amendment had been made to art 31. Furthermore, the short
judgment of Baroness Hale and Lord Clarke simply expressed their agreement with what it described as 'the


-----

doubts' expressed by Lord Wilson as to whether the construction adopted by Lord Sumption was correct in this
particular context.

**[68] Thirdly, the Tribunal should have preferred the very detailed reasoning of the Court of Appeal and the**
Supreme Court minority. The clear and emphatic conclusion reached in those judgments should have been
preferred to the doubts expressed by the Supreme Court majority.

**[69] Fourthly, even if not strictly bound thereby, the High Court decision in Propend and the EAT decision in Reyes**
were highly persuasive; as is the US decision in _Tabion. The correctness of Laws J's statement in_ _Propend was_
expressly acknowledged in _Reyes by Lord Dyson MR ([17]) and Lord Sumption ([21(3)]). In this context of the_
international interpretation of an international treaty, the authority of Tabion was accepted by Lord Dyson ([13]-[14])
and Lord Sumption ([23]).

**[70] Fifthly, that in referring ([85]) to Lord Wilson's contrast between a 'legally respectable solution' and a**
conclusion that the legal system 'cannot provide redress for an apparently serious case of domestic servitude'
([68]), the Tribunal had taken no account of his statements in the same paragraph that the Court was not put to the
test of making that choice and that it would be preferable for the ILC to be invited to consider an amendment to art
31. In any event, the degree of seriousness of the subject matter could not affect the issue of whether or not there
was diplomatic immunity in the particular case.

_CLAIMANT'S RESPONSE_

**[71] In response, Ms Webb emphasised that the Claimant's situation is not simply that of an employee seeking to**
enforce employment rights. On the assumed facts she is a victim of trafficking, exploitation and **_modern slavery_**
conducted by the Respondent. She refers to the broad definition of trafficking in the Palermo Protocol (2000) and to
Lord Wilson's observation that this definition 'endeavours to encompass the whole sequence of actions that lead to
_the exploitation of the victim' [61]. She points to the evidence which was before the Supreme Court and as updated_
in such other documents as the 2014 report from the ILO 'Profits and poverty: the economics of forced labour'. As
expressed by Lord Wilson 'The perceived immunity makes trafficking with a view to domestic servitude a low risk,
_high reward activity for diplomats': [59(5)]._

**[72] Adopting the observations of Lord Wilson, art 31(1)(c) should now be interpreted in the light of the “universality**
_of the international community's determination to combat human trafficking” [60] as expressed through the Palermo_
_Protocol (2000), the Council of Europe Convention on Action against Trafficking in Human Beings (2005) and the_
_Arab Charter on Human Rights (2004). In that context, there was no true analogy between the employer of a_
trafficked domestic servant and the purchaser of stolen property at a cheap price [62].

**[73] The Tribunal was right to have preferred these arguments when reaching its decision on the issue of**
'commercial activity' as applied to the assumed facts in this case; and not to prefer the reasoning of the Court of
Appeal or the Supreme Court minority in Reyes or the decisions in Propend and Tabion.

**[74] As to** _Reyes, the Tribunal had expressly referred to and taken into account the judgments of the Court of_
Appeal and the Supreme Court minority: see [75]. There was no error of law nor perversity in its conclusion that the
correct approach was to decide 'which of the non-binding dicta of the superior Courts' should be followed [77]. The
Respondent's challenge to its decision placed undue weight both on the Tribunal's conclusion that it should assume
that the majority would not have adopted the construction proposed by Lord Sumption ([81]) and on its adoption of
Lord Wilson's reference to an 'apparently serious' case of domestic servitude [85]). Ms Webb emphasised that
assessment of the various judgments should not involve a mere 'counting of heads'.

**[75] As to the United States cases, with the exception of** _Sabbithi v Al Saleh 605 F Supp 2d 122, these did not_
involve consideration of the element of human trafficking. In that jurisdiction deference was given to a Statement of
Interest by the Government. Furthermore, Tabion and all the other decisions also found that the employment of the
domestic servant was within the official functions of the diplomat; and thus were at odds with the unanimous
decision of the Supreme Court on that point.


-----

**[76] The Tribunal had taken the appropriate course of preferring the approach set out in the judgment of Lord**
Wilson; and, in the context of an internationally-recognised trafficking problem, adopting a modern-day meaning to
the language of art 31(1)(c). Even on the narrow interpretation favoured by Lord Sumption, the critical feature of
trafficking the Claimant as a commodity was properly to be described as 'commercial activity'.

_CONCLUSION_

**[77] The question which fell for decision by the Tribunal is a pure question of law, to which there is a right and a**
wrong answer. For this reason, the submissions relating to the approach taken by the Tribunal to that question are
of limited assistance. The question on appeal is whether the Tribunal's conclusion was correct in law. In effect, I
have to consider the question of law afresh.

**[78] For this purpose, I make two preliminary observations. First, I need no persuasion of the natural impulse to**
provide legal redress for victims of this abhorrent trade. However, as all the judgments of the Court of Appeal and
Supreme Court emphasise, diplomatic immunity involves countervailing issues of high international policy.

**[79] Secondly, the parties have rightly not taken me through the detail of the domestic and international material**
which was considered by the Court of Appeal and Supreme Court in Reyes or thereby reargued the case through
that extensive material. Instead they have taken the sensible course of pointing to the conclusions and observations
in the various judgments of the higher courts in _Reyes and then presented arguments as to which should be_
regarded as the more persuasive.

**[80] This inevitably results in a somewhat invidious task for a lower tribunal. However, I am fully persuaded that, at**
least at this level, greater weight should be given to those judgments of the higher courts in _Reyes which, in the_
light of detailed analysis of the relevant material, provide a clear (albeit non-binding) conclusion on the point; and
that lesser weight should be given to judgments which express even very strong doubts on that conclusion. This is
not to fall into the error of treating judgments in the first category as if they were binding, nor of 'counting heads', but
is simply to give greater weight to those higher judicial observations which have reached emphatic conclusions on
the point. Whether those conclusions should ultimately prevail is a matter for resolution at a higher level.

**[81] In Reyes the Court of Appeal reached a clear and fully reasoned decision, on assumed facts akin to those in**
the present case, that this was not 'commercial activity'. The material which it considered was comprehensive,
taking full account of the relevant international treaty obligations and international authority, notably _Tabion; and_
endorsing existing domestic authority, in particular _Propend. In the Supreme Court, Lord Sumption reviewed this_
and further material in great detail and reached a conclusion, albeit in non-binding terms, which accorded with the
Court of Appeal on the issue of 'commercial activity'. Lord Neuberger agreed with his analysis and conclusion.

**[82] I should add that I do not accept the Claimant's submission that, of the US decisions, it is only Sabbithi which**
involves the 'trafficking dimension': see Lord Sumption's discussion of those decisions at [47].

**[83] By contrast, Lord Wilson's judgment on this point does not reach a clear conclusion to the contrary. Thus, it**
recognises the force of established features of international law in this respect; and accepts that when agreeing to
the terms of the 1961 Convention the parties would have rejected any suggestion that the proceedings brought by
Ms Reyes related to any commercial activity exercised by her employer. Having advanced arguments that
interpretation should not be frozen in time but should reflect developments in international law, Lord Wilson
nonetheless acknowledges that the established principles for the international interpretation of international treaties
would make it a 'strong thing' to divert from the jurisprudence in the United States, in particular Tabion. The wish for
a 'legally respectable solution' providing redress is made clear. However, in circumstances where the Court is 'not
being put to that test', he concludes that it would be preferable for the ILC to review the whole matter and consider
the 'international acceptability' of an amendment to put the matter beyond doubt. The judgment of Baroness Hale
and Lord Clarke then associates them with what it describes as 'the doubts' expressed by Lord Wilson on the
construction adopted by Lord Sumption.

**[84] In circumstances where the observations of Lord Wilson, Baroness Hale and Lord Clarke were expressed in**
these relatively tentative terms, I consider that the Tribunal was wrong to proceed on the basis of an assumption


-----

that, if it had been necessary to decide the point, the majority would not have adopted the construction proposed by
Lord Sumption. In my judgment the decisions of the Court of Appeal and of Lords Sumption and Neuberger
represent the current state of the law on the issue of 'commercial activity'. Accordingly, I would allow the appeal on
this ground and hold that the defence of diplomatic immunity succeeds.

Appeal allowed.

**End of Document**


-----

# Basfar v Wong

_[[2022] UKSC 20, [2023] AC 33, [2022] 4 All ER 1, [2022] 3 WLR 208, [2022] IRLR 879, [2022] ICR 1255, [2022] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66D5-W2V3-CGX8-0542-00000-00&context=1519360)_

_[ER (D) 15 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65VW-8B93-CGX8-03XJ-00000-00&context=1519360)_

**Court: Supreme Court**
**Judgment Date: 06/07/2022**

# Catchwords & Digest

**EMPLOYMENT - DIPLOMATIC PRIVILEGE – WHETHER RESPONDENT DIPLOMAT ENTITLED TO IMMUNITY**
**IN CLAIM ALLEGING MODERN SLAVERY AND BREACH OF EMPLOYMENT RIGHTS**

The Supreme Court (by a majority) ruled that, on the assumed facts, an employment claim for wages and
breaches of employment rights (the claim), brought by the appellant migrant domestic worker who alleged that she
had been a victim of **_modern slavery, fell within the exception from immunity provided for in art 31(1)(c) of the_**
Vienna Convention on Diplomatic Relations. Accordingly, the court held that, if the appellant's allegations were
proved, the respondent (a diplomat representing the Kingdom of Saudi Arabia in the UK and the appellant's former
employer) did not have immunity from the civil jurisdiction of the courts of the UK. The court so ruled in
circumstances where the employment tribunal (the tribunal) had dismissed the respondent's application to strike out
the claim, but the Employment Appeal Tribunal had allowed his appeal. The court held that, applying the general
rule of interpretation set out in art 31(1) of the Vienna Convention on the Law of Treaties 1969, employing a
domestic worker did not, itself, constitute the exercise of a 'commercial activity' by a diplomatic agent, within the
meaning of the exception, but that it was necessary to examine the context and, importantly, the purpose of the
relevant provision. The court held that, on the assumed facts, the respondent and his family had enjoyed the benefit
of the appellant's services for almost two years, initially for a fraction of her contractual entitlement to wages and
latterly for no pay at all, which had amounted to a substantial financial benefit. Accordingly, the court held that the
deliberate and continuing course of conduct by which that benefit had been gained was properly characterised as
the exercise of a commercial activity, that the case was a 'paradigm example of domestic servitude' and that the
tribunal's judgment, refusing to strike out the claim, would be reinstated.

# Case History


Basfar v Wong

_[[2022] UKSC 20, [2023] AC 33, [2022] 4 All ER 1, [2022] 3 WLR 208, [2022] IRLR 879,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66D5-W2V3-CGX8-0542-00000-00&context=1519360)_

[[2022] ICR 1255, [2022] All ER (D) 15 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65VW-8B93-CGX8-03XJ-00000-00&context=1519360)


06/07/2022

SC


-----

—
Basfar v Wong

[(2020) (2020) UKEAT/0223/19, [2020] IRLR 248, [2020] ICR 1185](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YD0-JNY3-GXFD-81K8-00000-00&context=1519360)
Reversing

# Cases referring to this case

Republic of Mozambique (acting through its Attorney General) v Credit Suisse
International and others

_[[2023] EWHC 2215 (Comm), [2023] All ER (D) 28 (Sep)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:695D-4BJ3-S1DC-J4YJ-00000-00&context=1519360)_
Considered

R (on the application of AAA (Syria) and others) v Secretary of State for the Home
Department (United Nations High Commissioner for Refugees intervening) and other
cases

_[[2023] EWCA Civ 266, [2023] All ER (D) 59 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67V9-6BG3-RRJH-1005-00000-00&context=1519360)_
Considered

Barnet London Borough Council v AG (a child) and another

_[[2022] EWCA Civ 1505, [2023] Fam 261, [2023] 2 All ER 1128, [2023] 3 WLR 249,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68DX-9X83-RRSD-Y245-00000-00&context=1519360)_

_[[2023] 1 FLR 895, [2022] All ER (D) 76 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:683H-H3J3-SN10-Y534-00000-00&context=1519360)_
Considered

# Cases considered by this case

A local authority v AG and others (children) (domestic abuse)

_[[2020] EWFC 18, [2020] Fam 311, [2021] 1 All ER 257, [2020] 3 WLR 133, [2020] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61SB-3TB3-GXFD-84JX-00000-00&context=1519360)_
_[FLR 1265, [2020] All ER (D) 119 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:603T-DXC3-GXFD-80H1-00000-00&context=1519360)_
Considered

Al-Malki and another v Reyes and another

_[[2017] UKSC 61, [2019] AC 735, [2018] 1 All ER 629, [2017] 3 WLR 923, [2018] 1 LRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RNF-6RT1-DYBP-M0KY-00000-00&context=1519360)_
_[613, [2018] IRLR 267, [2017] ICR 1417, (2017) Times, 27 October, [2017] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RK3-69N1-DYJ0-80TW-00000-00&context=1519360)_
_[85 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PRN-G9R1-DYBP-N2T4-00000-00&context=1519360)_
Explained

Reyes v Al-Malki (Secretary of State for Foreign and Commonwealth Affairs)

_[[2015] EWCA Civ 32, [2016] 2 All ER 136, [2016] 1 WLR 1785, [2015] IRLR 289,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JF5-45X1-DYBP-M0GN-00000-00&context=1519360)_

[[2015] ICR 931, [2015] All ER (D) 56 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F7K-PXK1-DYBP-N1V4-00000-00&context=1519360)
Explained

Rantsev v Cyprus and Russia (Application 25965/04)

_[[2010] ECHR 25965/04](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X02K-00000-00&context=1519360)_
Considered

R v Tang

_[[2009] 2 LRC 592](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-83C5-00000-00&context=1519360)_
Considered

Fothergill v Monarch Airlines Ltd

[[1981] AC 251, [1980] 2 All ER 696, [1980] 3 WLR 209, [1980-84] LRC (Comm) 215](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-6134-00000-00&context=1519360)


31/01/2020

EAT

04/09/2023

CommlCt

14/03/2023

CACivD

18/11/2022

CACivD

16/03/2020

FamCt

18/10/2017

SC

05/02/2015

CACivD

07/01/2010

EctHR

28/08/2008

AusHCFull

10/07/1980

HL


-----

Considered

**End of Document**


-----

