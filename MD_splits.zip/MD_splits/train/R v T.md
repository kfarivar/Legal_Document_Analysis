# R v T [2021] EWCA Crim 1071

CA, CRIMINAL DIVISION

202002317 B2

Simler LJ, Jeremy Baker J, HHJ Dhir QC

Thursday, 29 April 2021

29/04/2021

LADY JUSTICE SIMLER:

Introduction

2 On 8 February 2008 in the Crown Court at Wood Green, HHJ Browne QC sentenced T to a fine in the sum of
£200, with 14 days' imprisonment to be served in default. She was also ordered to pay £300 by way of prosecution
costs. T was of previous good character on her conviction.

3 On her behalf, in addition to the application to which we have just referred, there is also an application to admit
fresh evidence. We have considered that material de bene esse by agreement between the parties.

4 Neither Birds Solicitors nor Felicity Gerry QC, who are now instructed on behalf of T, acted in the original
proceedings. Indeed, they were not instructed until 23 November 2018, when they were instructed to advise on
appeal. Despite very extensive efforts by them, they did not begin to obtain documentation in relation to this case
until 1 August 2019. By then, Wood Green Crown Court had confirmed that the only documents retained on the file
in relation to this case were the indictment and the record sheet.

5 Philippa Southwell of Birds Solicitors has provided a witness statement which describes the difficult disclosure
process that continued thereafter, leading finally in July 2020, to the receipt of extensive material concerning
trafficking from the Central England Law Centre, which did not come into existence until well after the conviction.

This included medical material from Hope for Justice, also post‑dating the conviction, and disclosures from the

Metropolitan Police Service and ACRO, again, post-dating the conviction. There was then an exchange under the
procedures in R v McCook, and in September 2020 this application for an extension of time and for leave to appeal
was lodged at the Criminal Appeal Office.

6 Having considered all the material in this case, including the material relating to T's circumstances, and the

non‑involvement of presently instructed leading counsel and solicitors in the original trial, we are satisfied that

grounds for granting the extension of time sought have been made out.

The facts

7 It is unnecessary to set out the detailed history of these proceedings, the trafficking of T, and how that emerged,
for reasons that will become clear. In short, the facts of the offence itself can be summarised as follows. On 12
July 2007 at around 8.30pm two undercover police officers attended at 118 Warham Road in Crouch End, London,
acting on information that the property was being used as a brothel. T was present. She explained the services
offered by the women and introduced them to some of those women. Each officer selected a woman, and gave T


-----

£50 in cash. The officers were taken to rooms where they received a massage. They were offered sexual services,
at which point each officer made excuses and left. A warrant was executed at the property and T was arrested for
controlling prostitutes for gain. The offence was recorded on the Police National Computer as one of "managing or
assisting in the management of a brothel... subject acting as a maid at premises used for prostitution... introducing
clients to prostitutes and taking money."

8 In police interview the following day, T said she only worked as a prostitute at the property, but she admitted
showing clients into the property and taking money from the police officers on the previous day.

The appeal

9 There are two grounds of appeal advanced by Ms Gerry on T's behalf. The first ground challenges the conviction

as a nullity because the applicant pleaded guilty to a summary‑only offence. Alternatively, she submitted that there

is fresh evidence in the form of the decision of the competent authority, together with the supporting material, which
reached a decision on conclusive grounds that T was a victim of trafficking, and had this been known at the time
she would not have been prosecuted. So far as that alternative second ground is concerned, although Mr

Douglas‑Jones QC on behalf of the respondent, conceded that in light of the fresh material, T's criminality or

culpability was reduced to a level to which she might well not have been prosecuted, nonetheless, he submitted that
she has not shown, as she must, substantial injustice to support exceptional leave in this case.

[10 He submitted because this ground is founded on a change in law, namely the Modern Slavery Act 2015,that T](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
needs to satisfy the substantial injustice test before the court considers the safety of her conviction. That
requirement to satisfy substantial injustice was disputed by Ms Gerry, who submitted that the requirement could and
should be disapplied in this case, but in any event, that T has indeed suffered substantial injustice through the
conviction for an offence committed as a trafficked person and the consequential effects of such a conviction.

11 We do not need to resolve that question because it is clear to us, and indeed not disputed, that the offence to
which T pleaded guilty was a summary only offence. T was committed by the magistrates' court to the crown court
in respect of the summary only offence and the crown court had no power to deal with it accordingly. Since there
has been no conviction on indictment, it is also the case that this court, the Court of Appeal, has no jurisdiction to
hear the appeal.

12 Accordingly, Mr Justice Jeremy Baker and I, reconstituted ourselves as a Divisional Court and granted
permission to apply for judicial review of the decision to commit T to the crown court on the charge of managing a
brothel. We quash the committal of that charge. Our decision has the effect of quashing the conviction, but if
necessary, the conviction is quashed in any event, as the crown court acted outside its jurisdiction. The result is
that the sentence also falls away. We dispense with the issue and service of any claim form and abridge all
necessary time limits.

13 We were also invited on T's behalf to make an order anonymising these proceedings under s.11 of the
Contempt of Court Act 1981. This case was listed anonymously to preserve the position, should we decide that
permanent anonymity should be accorded. The application is not opposed.  We have concluded that such an
order should be made here. T is a recognised victim of trafficking. Her conviction and sentence are both nullities,
and her status has been recognised. Had her status been recognised at the time, it is likely that she would not
have been prosecuted. Having regard to these and other considerations identified in the authorities, we have
concluded that a permanent anonymity order is necessary in the interests of justice and proportionate in the
circumstances. Accordingly we make that order.

_____________

**End of Document**


-----

