# R v Aliaj [2020] EWCA Crim 943

CA, CRIMINAL DIVISION

201902497 A4

Dingemans LJ, Cutts J, HHJ Karu

Friday, 26 June 2020

26/06/2020

LORD JUSTICE DINGEMANS:

Introduction

1 This is the hearing of an appeal against sentence pursuant to the leave of the single judge. The ground of
appeal for which leave was granted raises the issue whether the sentencing judge was entitled to find that the
appellant had a leading role in a conspiracy to supply class A drugs. The appellant also renews other grounds of
appeal following the refusal of leave by the single judge.

2 The appellant is a 29‑year‑old Albanian national. He had no previous convictions before the convictions which

are the subject of this appeal against sentence. He had entered the United Kingdom illegally from Albania and was
removed in 2015, but he returned within a few months of that date. He was aged 26 or 27 at the time of the
offending.

3 On 8 May 2019 in the Crown Court at Canterbury, he pleaded guilty on re-arraignment to conspiracy to supply
class A drugs. That was on day 11 of a trial before HHJ Catherine Brown and a jury. The trial continued against
co-defendants.

4 In his defence statement the appellant alleged that he was compelled to work as a drug dealer and carry out a

variety of tasks for the so‑called gang, raising the **_modern slavery defence. The National Referral Mechanism_**

rejected his case, but that did not prevent him presenting that case by way of defence to the jury. The change of

plea took place just after the close of the prosecution evidence. He was then re‑arraigned and, as I have noted,

pleaded guilty and he indicated that he was going to do so on “a basis”, although at that stage the basis of plea had

not been reduced to writing. The trial continued against the co‑defendants, some of whom gave evidence. An

application for a noting brief on behalf of the appellant for the remainder of the trial was refused on the basis that
the solicitor's fee, which would have included a litigator's fee for the purposes of the trial, was sufficient. This is one
of the renewed grounds of appeal.

The basis of plea and Newton hearing

5 On 22 May 2019, the appellant submitted a basis of plea which was rejected by the prosecution. The issue
between the prosecution and defence was the role performed by the appellant for the purposes of the Sentencing
Guidelines. The prosecution contended that the appellant had a leading role and the appellant contended and
contends now that his role was only a significant role. This is the ground of appeal for which permission was


-----

granted. On the same day, on 22 May 2019, the appellant pleaded guilty to producing a class B drug, namely
cannabis, in respect of a count which had been transferred from the Crown at Hull. That takes us to 22 May 2019.

6 There was a Newton Hearing on 3 June 2019. It appears that on 29 May 2019 the appellant's legal
representatives were provided with a note made by the judge of the evidence given by the defendants in the
continued trial, but we were told by Mr Patel this morning that the note was in general terms. After the Newton
Hearing took place on 3 June, the judge reserved her ruling and set out in a ruling which she handed down on 10
June 2019 her reasons for finding that the appellant had a leading role and not just a significant role.

7 On 10 June the sentencing hearing continued and on 11 June the appellant was sentenced to 15 years'
imprisonment for the conspiracy to supply class A drugs and to nine years' imprisonment concurrent with the other
sentence for the production of the class B drugs. The appellant has renewed his application for permission to

appeal against that sentence. It is also relevant to note that co‑defendant Ervis Dervishi pleaded guilty and was

sentenced to six years and nine months' imprisonment and co‑defendant Izmir Basha was convicted after the trial

and sentenced to seven years' imprisonment. The appellant contends that there was an impermissible disparity
between his sentence and those imposed on Mr Dervishi and Mr Basha and this is again a renewed ground of

appeal. It is not necessary to set out the sentences imposed on all the other co‑defendants.

The circumstances of the offence

8 The appellant and his co‑defendants were part of an Albanian organised crime group which operated an

established cocaine supply business between 1 May 2018 and 31 December 2018. It became known as the “24/7
conspiracy” because it operated every day. They operated an established telephone drugs line predominantly in
the Tunbridge Wells area using established key numbers. Once an order was received, the network would then
use a secondary or "platform" phone to contact the street dealer to inform them of the location so that the delivery
could take place. Customers would provide their post code location and the key number would then be used to
confirm the deal. The dedicated key numbers were 1814 and 5998 as far as the endings of the numbers were
concerned. They were never in the hands of street dealers or in the same location as the drugs and were known as
“sterile” or “clean” drugs lines. There was no direct link between the drivers and the drugs lines, and protecting the
telephone numbers had been one way of protecting the operation.

9 The organised crime group purchased a fleet of vehicles which was available for those who were delivering the
cocaine. A total of 25 separate vehicles had been identified as linked to the group. There was also some
suggestion that there was one person on foot and that arose from a notebook.

10 The group leased two properties in Tunbridge Wells to use as a base for delivery drivers to stay at and those
properties were 22 Liptraps Lane and 5 Willow Tree Road. The evidence suggests that the negotiations for the
lease of 5 Willow Tree Road were made by another person, but the appellant signed the lease. He relies on this
fact to show that he did not have a leading role, because, as it is put, important people use other lesser people to
give their names on official documents. The group also leased properties in the London area at which the two
sterile telephone numbers were located and at which some members of the group resided. One of the properties
was 29 Melville Court in Deptford and the drug lines were located at 29 Melville Court between 23 May and 22
August 2018, but also between 30 September and 19 October 2018. There was an unidentified property in the
Romford area and the drugs lines were relocated to Romford between 22 August and 30 September. That followed
the arrest of two members of the group. Members of the group also leased and resided at a property in Gravesend
and another property in London at 98 Brockley Rise.

11 Further, during the evening of 16 July 2018 in Tunbridge Wells, a man called Mr Hoxhaj was a passenger in a
silver Volkswagen Golf which collided with a Vauxhall motorcar. He was in fact a rival drug dealer who had started
dealing on the group's home turf. There was a fight and during the confrontation a Range Rover pulled up and two
men got out and Mr Hoxhaj was attacked. He was stabbed and suffered a punctured lung. No charges were
brought from the incident, but the 1814 drugs line ceased to operate for a short while and there were reports made
to undercover police officers who were purchasing drugs that there was too great a police presence in the area for


-----

the group to operate. The 1814 line became operational a few days later and that became known as the “Hoxhaj
incident”.

12 On 19 October 2018 a search warrant was executed at 29 Melville Court in Deptford. The appellant and Mr
Basha were arrested trying to escape. The 1814 phone was seized along with the appellant's personal mobile and
the phone ending 5598. A download of the 1814 phone revealed the numbers of several contacts, many saved as
locations to which couriers delivered. As the warrant was being executed and the number was stopped from being
answered, a text was received from a customer saying he had spent around £400 that week and he wanted to know
when his next delivery was. Cell site analysis was carried out of the 1814 number and the appellant's personal
phone and showed that they were consistently collocated. The inference drawn from that by the prosecution was
that he was operating the drugs line. There was also taken from a table a notepad that displayed a number of
annotated numbers equating to the same pattern reflected on the burner phones seized from members of the
network when arrested in Tunbridge Wells.

13 On 26 November 2018, just over a month after his first arrest, the appellant having been released from custody,
was arrested again at 149 Lee Street in Hull. On that day the appellant was seen getting out of a Vauxhall van and
entering Lee Street. The vehicle had earlier been under surveillance on a street known as Devon Street and the
appellant was known to be wanted by the police. When officers tried to speak to him, he tried to escape through a
rear window and was arrested. He was found to be in possession of master keys for an address at 6 Devon Street.
The Lee Street address was searched and a significant cannabis cultivation operation was discovered. There were
89 mature plants; there were lighting set ups; electricity was being bypassed; there were heat sources and plant
food. A second address, 107 Mersey Street, was searched and there were 66 mature cannabis plants located
there, again with all the relevant paraphernalia. Finally, at Devon Street there were 68 mature plants with
associated equipment. That gave a total of 223 cannabis plants being cultivated in three separate locations, which
was an operation capable of producing significant quantities for commercial use, but not industrial quantities. The
appellant had a mobile phone seized from him in Hull and there were relevant extracts. He gave a no comment
interview, as indeed he had in relation to the matter in Tunbridge Wells.

The prosecution's case on the appellant's role for the class A conspiracy.

14 The prosecution case was that the appellant occupied a leading role in the conspiracy because he had
substantial links to and influence on others. He would also have had an expectation of a significant financial gain
and the evidence of his involvement was from the end of July to the end of November 2018. He was found to have

been involved in the purchase of a top‑up voucher on a single occasion, which the prosecution said demonstrated

someone who was not involved at street level. He was also noted to have sourced six vehicles for the members of
the group to use to supply cocaine and he was the name on the lease of 5 Willow Tree Road in Tunbridge Wells.
His DNA was on the 1814 and 5598 drugs phones from the internal areas of the phones, which were the SIM and
the battery compartment, although it is also fair to note, as Mr Patel has reminded us this morning, that DNA from
other persons was located on those phones. He was collocated with the 1814 drugs line throughout the period of
the conspiracy, including when the telephone moved to another location such as Romford and the phone was used
to direct others to send messages. His mobile phone was recovered from outside Melville Court and that showed
the evidence of collocation.

15 The particular prosecution evidence relied on a table showing where the appellant and various phones were
located (known at trial as the “co-location table”) text messages referring to payment for travel papers and a Range
Rover Sport being sent to Albania for the appellant's father and other cars in Albania, and other evidence about
purchases made by the appellant according to text messages that he had written in Albanian.

The appellant's case about his role

16 The appellant's case was that he worked in the operation from May 2018 when he was brought into the United
Kingdom until the raid on Melville Court. He owed £14,000 to the people who had brought him into the United
Kingdom and he worked for them to pay off his debts. He was being paid at about the rate of £1,000 per week and
the people above him in the operation, and to whom he owed the money, deducted it from the sums owed. He was


-----

also given £20 to £30 for food costs which were deducted from his wage. They purchased an Audi which he was
asked to drive and do errands with and, after paying off the debt, he was allowed to keep his wages. That didn't
amount to a great deal because Melville Court was raided and the group disbanded. He was expected to do roles
at the behest of the leaders of the operation, which included weighing drugs and packaging. That was done at an
address close to Melville Court.

17 He signed the lease for 5 Willow Tree Road and he did not reside there for more than a couple of days. He had
to drive people as required or drop them at destinations. He was also asked to identify and buy vehicles for people
higher up in the group and he used Google translate on his phone to send messages regarding vehicles. He did
not operate either the 1814 or 5598 phones because did he not speak, read or write English and would have been
unable operate them. He said he slept in Melville Court with others. He sent money to his fiancé and his mother in
2016 and he bought his fiancé a ring, but that was for £20 in 2018 when he was street dealing. He did not buy
vehicles and send them to Albania. He had lied in his text messages to impress a woman. He did not own any
cars, land or business.

The ruling following the Newton hearing

18 The judge, having heard the appellant give evidence, found from the primary evidence involving the appellant
that the appellant was at the headquarters throughout the relevant period from at least the middle of July with the
sterile phones and the platform phones. The only other people who were there were Aldi Aliaj, who was still to be
arrested, and Izmir Basha. Basha, who spoke English well, was in October 2018 the main operator of the sterile
phones. The judge said, having heard and seen the evidence, including Basha giving evidence during the trial, that
the court was sure that Basha was doing so under the direction and instructions of the other occupants of the flat,
which was the appellant and Mr Aldi Aliaj. Mr Patel told us this morning that Mr Aldi Aliaj was in fact no relation of
the appellant.

19 When the headquarters had to move following an attack on the rival drug dealer, the appellant moved with the
key phones to Romford and that was demonstrated by the co-location table. The appellant was in contact with all
the other defendants, including on occasion with their mobile phones rather than just their burner phones. The
judge found that he was the only person to be linked to everyone before the court. The judge found this evidence
of particular importance. The appellant was the only one who was in a position to direct and influence the actions of
those below him in the hierarchy. Whether or not he spoke English was irrelevant in the context, since all of the
defendants were Albanian and would have understood his orders in Albanian. He also sourced or was involved in

the sourcing of six cars and the court accepted the evidence of another co‑defendant Metalia that when he was

recruited to the conspiracy he was put in touch with the appellant who made the arrangements for him to have the
car and he continued to be in touch with him thereafter. The appellant was involved with the rental of the property
at 5 Willow Tree Road and he was named as a tenant. He was certainly one of the leaders who was directing the

likes of the co‑defendants Kuci, Metalia and Vucaj. The court rejected the submission that the court should ignore

the evidence of co‑defendants. In reaching her conclusions, the court was entitled to use their evidence concerning

the operation of the conspiracy and the appellant's role in it.

20 The court was sure that the basis of plea did not reflect the true position and in reaching conclusions the court
had taken into account all of the evidence and all of the documentation before it. The court also agreed with the
prosecution that it was a concern that photographs of one property, the let property, were provided on his behalf,
alleged by his father to be a derelict shop referred to by the appellant's messages. The absence of evidence on
other properties and documents was said to be telling, because it was open to the appellant to provide evidence to
rebut a prima facie case which had been raised by what he had said in his text messages. The burden of proof
remained on the prosecution, but in the absence of material messages from the appellant were evidence against
him.

21 The court was confident, having assessed the evidence as a whole, how the conspiracy operated and what the
appellant was doing with it. In rejecting the basis of plea, the court also had regard to the sheer lack of any
particularity in the assertions made by the appellant. The appellant had given no detail of who it was who had got


-----

him involved in the conspiracy, by contrast to the other defendants; who was giving him orders, again by contrast to
the other defendants; and who was paying him and other matters which might have lent some semblance of reality
to what he asserted. The vagueness of his assertions, said the judge, only served to reinforce the conclusion that
he had sought to portray his role in a way which did not reflect the reality of the situation.

Sentencing remarks

22 When sentencing, the judge found, based on the totality of the evidence, that it was a conspiracy that amounted
to serious organised crime with a turnover on the evidence of a minimum of £1 million pounds, but was in reality
likely to have been in the region of £4 million. The court was assisted by consideration of R v Khan _[[2013] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58GH-J8S1-F0JY-C26C-00000-00&context=1519360)_
_[Crim 800 and the court concluded that the appellant was at the heart of the conspiracy. He had also pleaded guilty](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58GH-J8S1-F0JY-C26C-00000-00&context=1519360)_
to a charge of producing the class B drug, cannabis. The appellant at 26 or 27 was the oldest of the defendants by
several years. He had been in the UK illegally and he had returned after deportation. The volume of the drugs was
several times the indicative amount of 5kg for category 1 cases. This was serious organised crime and the judge
found him to be at the heart of it.

23 The judge also noted as far as personal mitigation that there was a lack of previous convictions, but that was of
limited impact given the seriousness of the offending. He was also to be sentenced for his leading role in the
cannabis operation in Hull. The appropriate course the judge took was to impose a sentence for conspiracy to
supply class A drugs that reflected the totality of his offending, including the class B drugs, and that offending on the
class B drugs was placed in category 2 as an operation that was capable of producing significant quantities for
commercial use. His guilty plea had come only at the close of the prosecution case and his basis of plea had been
rejected at a Newton Hearing so that any discount was inappropriate. Clearly, the court took it into account, to a
limited degree, his showing of an acceptance of his criminality and, therefore, the sentence imposed was one of 15
years on the class A conspiracy and nine years for the class B conspiracy.

24 I should just mention the sentences on Mr Dervishi and Mr Basha, because these are, as I have already
indicated, relied on by way of disparity arguments. Dervishi was 20 years old when the events occurred. He was in
the United Kingdom unlawfully in June 2007 when he had been caught in possession of 32 wraps of cocaine. He
was sentenced to 28 months' detention and deported to Albania, but returned and his role was acting as a key
lieutenant for the appellant. He could speak good English and was therefore the organiser of the houses, car
insurance and other arrangements. He had personal mitigation, including a 25 per cent credit for plea and his age.
His sentence was six years and nine months' custody, reduced from nine years.

25 Mr Basha was 23 in 2018 with no previous convictions. He was based at the headquarters with the appellant
and, although he gave evidence through an interpreter, he was a good English speaker. This was the attribute that
led to him being recruited to play a central role in the operation. He was the main operator of the sterile platform
phones and, although the appellant and Aliaj were in charge, Basha was undertaking a key operational role. He
was plainly trusted by the leaders of the conspiracy and, so far as his sentence was concerned, he was sentenced
to seven years' custody.

The grounds of appeal including the renewed grounds of appeal

26 The appellant was granted permission to appeal on whether the judge was entitled to find that the appellant had
a leading role in the conspiracy. The appellant also renewed grounds of appeal. These were first, that the judge
should have provided a noting brief to the appellant for the remainder of his trial after plea. Secondly there was a
justiciable disparity of sentence with the sentences imposed on Mr Dervishi and Mr Basha.

27 In relation to the sentence for production of cannabis, where the sentence was concurrent with the sentence for
the class A conspiracy, the renewed grounds of appeal were that the sentence was manifestly excessive because
the sentence was above the range set out in the guideline for category 2. It was also contended that the appellant
did not play a leading role and no credit seems to have been given for his guilty plea in that case.

28 We will deal with all of the grounds and then deal with the question of leave at the end, because, as Mr Patel
has fairly pointed out there is an element of overlap Logically the first issue to address is whether the judge


-----

should have provided a noting brief for the appellant for the remainder of the trial. In our judgment, it was not unfair
to refuse to provide a noting brief for the appellant. This was for two reasons. First of all, on the evidence before
us, the appellant was provided with the relevant information about what had been said against him at the trial. If he
had been provided with a noting brief he would not have had the opportunity to ask questions at the trial, but it was
essential that he knew what was being said at the trial. The information before us shows that he knew what had
been said before the Newton Hearing. The second reason is that the provision of a noting brief was covered by the
litigator's fee which had been paid to the solicitors for the whole of the trial. Whether, if there had been any
unfairness, that would have been enough to dispose of that ground of appeal is not an issue that we need to
address, because we are sure that there was no unfairness to the appellant. For these reasons we will refuse the
renewed application for permission to appeal in relation to this ground because it takes the appellant no further
forward.

29 We turn next to consider the main point on the appeal, namely whether the judge was wrong to make the finding
that the appellant had a leading role. A leading role is one which is directing or organising the buying and selling on
a commercial scale with substantial links to and influence on others in the chain and an expectation of substantial
financial gain. A significant role was evidence of operational or management function within a chain and financial
advantage and some awareness and understanding of the scale of the operation. The finding of fact that the
appellant had a leading role was a finding made by the judge who had seen the trial, of which the defendant was
part until day 11, and who had seen and heard the defendant and appellant before us give evidence. In such
cases, it is established that appellate courts should be cautious in overturning findings of fact made by first-instance
judges. This is because first-instance judges will have taken into account the whole sea of the evidence, rather
than indulged as an appellate court in impermissible island hopping to parts only of the evidence. It is for these
reasons that judges hearing appeals on facts only interfere if a finding of fact was made which had no basis in the
evidence or when there was demonstrable misunderstanding of relevant evidence or a demonstrable failure to
consider relevant evidence so that the decision could not reasonably be explained or justified.

30 We can see nothing which would justify our interfering with the careful findings of fact made by the judge. For
example, one of the appellant's complaints was that he said he was making a great deal of money from his drug
dealing and had properties and cars in Albania. He now says that these were idle boasts made to impress women,
but it was for the judge who heard all the evidence to assess whether that was or might have been true and the
judge was sure that it was not. This was a perfectly reasonable decision open to the judge and there is no
justiciable basis for us to interfere with this.

31 Similarly, all the other complaints about the findings of fact, made eloquently to us today by Mr Patel on behalf
of Mr Aliaj, fall into the same category. The fact that Mr Aliaj did not have English and the fact that his name was on
the tenancy for one of the properties, are all points which might have assisted the judge to find him to have a
significant rather than a leading role. However, it was for the judge to assess these matters in the light of all the
other evidence, and that was the approach taken by the judge. As I have already indicated, we can find no basis on
which the judge's conclusions can be fairly criticised.

32 We then turn to the issue of the disparity of sentences with the sentences imposed on Mr Dervishi and Mr
Basha. We do not consider that there was any basis to say that there was any impermissible disparity. The reason
for the differences in sentences was because the judge assessed the roles of the appellant and co-defendants very
differently. We have rejected the challenges to the finding of fact that the roles were different. Therefore, the
sentences were within the permissible ranges. For that reason, we refuse the renewed application for permission to
appeal on that ground of appeal.

33 So far as the class B sentence is concerned, it might be noted that this sentence was concurrent to the first
longer sentence for the class A conspiracy, so that whatever we do in relation to it will not make any difference to
the sentence to be served by the appellant. In those circumstances, we also refuse the renewed application for
permission to appeal.

34 For all these reasons we dismiss the appeal. Before I do so, I should thank

Mr Patel very much for his assistance.


-----

__________

**End of Document**


-----

