# R v Tran [2023] EWCA Crim 1078

Court of Appeal, Criminal Division

Popplewell LJ, Tipples J

30 August 2023Judgment

MR FITZGERALD appeared on behalf of the Appellant.

THE RESPONDENT was not present and was not represented.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

LORD JUSTICE POPPLEWELL :

1 Following a guilty plea at a pre-trial hearing, the appellant was sentenced in the Crown Court at
Maidstone to 27 months' imprisonment for production of cannabis. He appeals with leave of the single
judge.

2 A police search discovered the appellant and his co-accused in a property above a disused shop in
Chatham, where, across nine rooms, there were found some 1,250 cannabis plants in various stages of
growth, with an estimated value of £500,000. The electricity had been bypassed and the usual
paraphernalia was in use for the commercial production of cannabis. There were squalid living conditions,
with two mattresses on the floor, a shower and a kitchen of sorts. The co-accused had a mobile phone.

3 The appellant, now 50, is Vietnamese and came from a poor rural community. He is the father of four
young children and came to this country illegally some 15 years ago or more, as an economic migrant, in
order to provide a better life for his family. He incurred a debt to the people smugglers who helped him
travel, who put him to work in a cannabis factory to pay off the debt. He was caught and sentenced in 2009
to 2 years' imprisonment on a guilty plea. We have no reliable indication of the scale of that operation.

4 Having been deported, he returned illegally to this country some time prior to 2017 and was put to work
in restaurants, construction sites and cannabis growing facilities in order to pay back a debt of some
£26,000. He had suffered serious injuries to his head and legs when working on a building site, resulting in
several months in hospital. As a result, he was on medication and his memory was affected.

5 In interview, the appellant explained that he suffered from psychosis and that, approximately six months
before his arrest, he had been bundled into the back of a van and transported to the property where he had
remained ever since, cultivating the cannabis there.


-----

6  Although no defence under the **_Modern Slavery Act was advanced, the judge, when sentencing,_**
accepted that the appellant and his co-accused had been preyed upon by others who had exploited them
in the cannabis operation for which they were being sentenced.

7 The judge categorised the offending as within Category 2 of the relevant guideline, involving an
operation capable of producing significant quantities of cannabis for commercial use. He treated the
appellant as playing a lesser role, performing a limited function under direction as a gardener and being
engaged by pressure and coercion. The guideline indicates a starting point of 1 year and a range of 26
weeks to 3 years for that category.

8 The judge took into account the previous conviction as an aggravating factor and treated as mitigating
factors that the appellant was sorry for what he had done; and that prison conditions would be harder for
him, because he did not speak English and would have no family visitors. The judge treated the
appropriate sentence after a trial as one of 3 years' imprisonment and reduced it for the guilty plea.

9 Mr Fitzgerald accepts that some increase from the starting point of 1 year was required for the previous
conviction, but submits that a notional sentence after trial of 3 years could not be justified; and, moreover,
cannot have given any allowance for the hardship of serving the sentence in a foreign prison, which the
judge said he would treat as mitigation. Accordingly, he submitted the sentence was manifestly excessive.

10 We agree. The appellant was a vulnerable foreigner being exploited by those to whom he was in debt
and, whilst the coercion was not suggested to be such as to provide a defence under the Modern Slavery
Act, it nevertheless put this appellant squarely within the lesser role category with its starting point of 1
year. The previous conviction could not justify going to the top of the range.

11 Given the remorse and the personal mitigation, in our view, the appropriate sentence after a trial would
have been one of 16 months, which, with 25 per cent credit for the guilty plea, would result in a sentence of
12 months. Accordingly, we quash the sentence and substitute a sentence of 12 months' imprisonment.
To that extent, the appeal is allowed.

_____________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge._**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

