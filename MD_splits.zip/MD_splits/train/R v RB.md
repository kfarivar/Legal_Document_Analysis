# R v RB [2021] EWCA Crim 230

CA, CRIMINAL DIVISION

2019/04180/B3, 2019/04182/B3

Davis LJ, Jay J, Collins J

Friday 19th February 2021

19/02/2021

___________________

Friday 19[th] February 2021

**LORD JUSTICE DAVIS: I shall ask Mr Justice Jay to give the judgment of the court.**

MR JUSTICE JAY:

1.  On 9[th] October 2019, following a trial in the Crown Court at Woolwich before His Honour Judge Evans QC and
a jury, the applicant RB was convicted unanimously of four offences of being concerned in the supply of controlled
drugs (heroin and cocaine), contrary to section 4(3)(b) of the Misuse of Drugs Act 1971.

2. On 18[th] October 2019, he was sentenced by the trial judge to a total of six years' detention in a young offender
institution.

3. The applicant was acquitted on counts 3 and 4 of the indictment following a successful submission of no case to
answer.

4. Two co-accused (Alaka and Bond) were convicted on two counts, and one was acquitted altogether.

5. The applicant applies for an extension of time (seven days) in which to apply for leave to appeal against both
conviction and sentence after refusal by the single judge.

6. The facts of the case are set out in the Criminal Appeal Office Summary and it is unnecessary to set them out in
full detail. The case concerned a "county lines" drug network in and around Maidstone. Counts 1 and 2 involved
the supply of heroin and cocaine between 24[th] June and 10[th] July 2018. Counts 5 and 6 covered the period 11[th]
July to 20[th] July. Two vulnerable girls, [an age], were used to carry the drugs to individual purchasers.

7. The applicant did not deny that he was involved in drug dealing over these periods. There were essentially two
issues in the case. The first involved the applicant's defence that he was the victim of modern slavery: see section
45 of the Modern Slavery Act 2015. The second is that the applicant was not the person known by the nickname
"Reeks" or "Big Reeks", who had control of a phone ending with the numbers 347 and who, on the Crown's
contention, was the leader of the operation. The user of that phone (whoever he was) gave instructions to others to
deliver drugs to individual purchasers.

8. These two issues were interconnected because if the jury were sure that the applicant was "Big Reeks", his
section 45 defence would be very much weaker. There was evidence that prior to January 2018 the applicant had
acted under a form of compulsion


-----

9. The applicant was arrested on 19[th] July. Class A drugs were found at his flat, together with money and a
Samurai sword. He declined to comment when interviewed. He provided a short prepared statement in which
reference was made to his claims in another case that he was the victim of modern slavery.

10. The applicant's evidence at trial was that "Big Reeks" was the head of the gang who forced him to sell drugs.
The applicant said that he was beaten up by members of this gang and that on one occasion had been threatened
with a knife. He said that he made no money for himself as a result of these activities.

11. No complaint is made about the judge's summing-up or his directions to the jury on the section 45 defence.
The sole ground of appeal against conviction is that the jury must have been under pressure to reach their verdicts
and that, accordingly, the verdicts were unsafe.

12. We may consider the merits of this ground with reference to a chronological narrative of what occurred during
the course of this lengthy trial. The trial was due to conclude on 9[th] September 2018, but for various unavoidable
reasons seriously overran. One juror had made it clear that her business commitments meant that she could not sit
during the week commencing 9[th] September. The applicant's Perfected Grounds of Appeal suggest that this was
the previous week, but that is an error. There was discussion at the Bar as to the best course of action in these
circumstances. It was known that another juror could not sit beyond Wednesday 9[th] October. The judge took the
view that the juror with the business commitment would have to be discharged. Defence counsel agreed. It is said
that counsel had no option but to agree. We do not understand that any appeal point arises at this stage. At some
point it also became clear that another juror could not sit beyond Friday 11[th] October, owing to a pre-booked
holiday.

13. The jury went out to consider their verdicts at 10.48am on Monday 7[th] October 2019. The parties were called
back into court at 3.30pm because there was an issue regarding the health of juror number 2. She stated that she
could not continue; that she felt stressed and unwell. The judge heard evidence from the jury bailiff and the court
clerk. The juror said that she was not being permitted to express her opinions in the jury room. She appeared to be
having some sort of panic attack. The jury was sent home at 3.35pm, and the judge indicated that he would receive
submissions the following morning.

14. On 8[th] October, juror number 2 had not returned to court. She said that she was too unwell to attend. The
applicant's counsel did not oppose the course that the judge said he would take, namely to discharge juror number
2. The judge gave a short ruling setting out his reasons. When the jury (now of ten) was back in court at 11.22am,
he directed them that it was imperative that each of them be allowed to have their say. He also asked them
individually and collectively whether they felt able to continue to deliberate fairly and impartially and to return a true
verdict in accordance with the evidence. The judge received nothing to indicate that any juror felt otherwise.

15. We do not understand that any proposed appeal point arises in relation to this sequence of events. In our view,
the trial judge handled a difficult situation fairly and precisely.

16. The jury then continued their deliberations between 11.35am and 3.48pm. At that point a jury note was
received that one of their number could not sit beyond 3pm the following day, 9[th] October, although could return on
the 10[th]. But, as we have said, owing to the personal situation of another juror, the jury would be down to nine if
their deliberations went beyond then. There was a further jury note whose contents could not be revealed. At 4pm
the jury was sent home with the direction that only a unanimous verdict would be acceptable.

17. On 9[th] October the jury were sent out at 10.35am and returned unanimous verdicts at 12.54pm.

18. In support of the proposed ground of appeal it is said that an examination of the surrounding circumstances, as
well as the precise sequence of events, demonstrates that the jury were placed under improper pressure. It is said,
first, that it is striking that the jury reached their verdicts in a multi-handed and difficult case, which took 70 days, the
evidence of which occupied 53 days, after only approximately ten hours of deliberation; secondly, that the jury were
aware that they would be down to nine in number if verdicts could not be reached by early afternoon; and thirdly,
that the jury were also aware that another of their number could not sit beyond the Friday. Miss Zimbler did not


-----

submit that the judge acted improperly, or that he was bound to discharge the jury. Her point was the more abstract
one: that the jury were placed under improper pressure.

19. The respondent observed that the trial judge handled the developing situation carefully after hearing
submissions from counsel at every point. The judge expressly warned the jury not to feel under pressure of time.
The jury's verdicts were not uniform across the defendants, and no inference can be drawn that they were rushed
or ill-considered verdicts.

20. We have carefully considered Miss Zimbler's submissions, which were commendably succinct on this issue.
We have concluded that they raise no arguable point fit for further consideration by this court. We agree with the
observations of the single judge that the trial judge gave clear (and we would add user friendly) directions on the
law, as well as the route to verdict, and that the issues in this admittedly lengthy case were neither particularly wideranging nor complex. Further, the judge gave careful consideration as to what to do at every relevant stage, and
did not allow any pressure of time to cause him to rush his decision making. The fact that the jury clearly gave
individual consideration to the cases of the three co-defendants is another pointer to a fair and considered
deliberative process. There was no indication from the jury that they felt under pressure of time, independently of
the judge's direction to them. The argument that ten hours' deliberations gives rise to the inference that full
consideration was not given to the evidence in this case cannot be sustained. As the Advice on Appeal rightly
states, "how long a jury should take to reach a decision is tantamount to saying how long is a piece of string?"

21. The second jury note received by the judge at 3.48pm on 8[th] October may well have provided some indication
of how close they were to reaching a unanimous decision.

22. A further difficulty from the applicant's perspective is Miss Zimbler's concession that the judge would not have
been bound to discharge the jury during the course, for example, of the morning of 9[th] October.

23. Accordingly, we must refuse the application for an extension of time in which to apply for leave to appeal
against conviction.

24. We turn to the proposed appeal against sentence. In his detailed sentencing remarks, the judge accepted in
the applicant's favour that at the outset he was forced into drug dealing. The compulsion had ceased in
approximately January 2018. The judge was sure that the applicant was in control of the 347 phone, as well as
another drugs phone, and that "Big Reeks" was a fabrication. The judge stated that the applicant played at the very
least a "significant role". He rejected the Crown's submission that he played a "leading role". He was clearly "the
central cog in the wheel". The judge said that the applicant would not be sentenced on the basis that he recruited
the 16 year old girls.

25. The aggravating features of the offence were the "county lines" and sophisticated nature of the operation. The
applicant had a number of relevant previous convictions for drug offending and possession of weapons, and these
offences were committed whilst he was on bail for suspicion of supplying Class A drugs and possession of a knife.

26. The mitigating features were the applicant's age ([an age] when the offending started), and the fact that he was
significantly exploited when his drugs offending started.

27. The judge said in terms that he had regard to three relevant guidelines of the Sentencing Council, namely:
drugs, youth and totality. The judge's reasoning was as follows: in relation to counts 1 and 2, the starting point
under the drugs guideline for an offender with a "significant role" is six years six months' custody, with a range of up
to seven years. The starting point was the same for counts 5 and 6.

28. At page 8E of the transcript, the judge had in mind a sentence of five and a half years' custody for each
offence. But, given that he proposed to impose concurrent sentences, there would be an upwards adjustment to six
years' custody for counts 1 and 2, and a downwards adjustment to five years' custody for counts 5 and 6. The
judge said in terms that, but for the applicant's age, the sentence would have been significantly higher. He no
doubt had in mind that this offending was on the cusp of "significant role" and "leading role" (although on the side of
"significant role").


-----

29. The grounds of appeal are that the overall sentence was manifestly excessive for the following reasons. First,
it is said that the judge was not entitled to conclude that "Big Reeks" was a fabrication. Secondly, it is contended
that the judge gave insignificant weight to the applicant's personal history and that in the past he had been a victim.
Thirdly, the judge failed to recognise that the applicant's previous convictions were committed during the period of
exploitation. Fourthly, it is contended that there was disparity with the co-accused Alaka. Fifthly, it was argued that
inferences can be drawn in the applicant's favour from the acquittal of Alaka on counts 1 and 2. The jury must have
accepted Alaka's evidence that he had been exploited by someone higher up the chain. The applicant's case was
similar to that of Alaka, and the jury's conviction of the applicant must have been on the basis that the applicant's
defence failed under other limbs of section 45 of the Act, including the fact that he had (or might have had) an
alternative course of action.

30. We are grateful for Miss Zimbler's oral submissions which were presented clearly and persistently. Like the
single judge, though, we have concluded that these grounds are not well-founded.

31. The judge presided over the trial and was entitled to reach the sure conclusion he did about "Big Reeks". The
judge was clearly aware of the history, but the applicant's recent, more serious offending came after January 2018.
The judge said in terms that he gave considerable weight to the applicant's youth.

32. Finally, the co-accused Alaka had to be sentenced on two counts, not four. The jury may well have accepted
that Alaka may have been the victim in connection with counts 1 and 2, but they were entitled to reach a different
conclusion on the applicant's different role and personal circumstances. Ultimately, this was an issue for the judge
to consider in the light of all the evidence.

33. The overall sentence was on the severe side, but we cannot accept that it was, even arguably, either wrong in
principle or manifestly excessive.

34. The application for an extension of time in which to apply for leave to appeal against sentence is therefore
refused.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

