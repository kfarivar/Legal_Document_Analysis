# R v Wabuela [2020] EWCA Crim 783

CA, CRIMINAL DIVISION

2019/01825/B5, 2019/02168/B5, 20190/02170/B5 & 20190/02202/B5

Holroyde LJ, Cheema-Grubb J, HHJ Lucraft

9 June 2020

09/06/2020

Tuesday 9[th] June 2020

LORD JUSTICE HOLROYDE:

1. The three appellants were tried in the Crown Court at Inner London on charges of trafficking a person within the
UK for exploitation, contrary to section 4(1A)(b) and (5) of the Asylum and Immigration (Treatment of Claimants,
etc) Act 2004. On 11[th] April 2019, at a late stage of the trial, Dean Alford and Michael Karemera each pleaded
guilty to three such offences. On 17[th] April 2019, Glodi Wabelua was convicted by the jury of the one offence with
which he was charged. On 14[th] May 2019 the trial judge, Her Honour Judge Karu, sentenced each of them to terms
of imprisonment: three years six months in Wabelua's case; a total of four years in Alford's case; and a total of five
years in Karemera's case. In addition, she made in each case a Slavery and Trafficking Prevention Order
("STPO"), pursuant to section 14 of the **_Modern Slavery Act 2015. All three now appeal by leave of the single_**
judge against the STPO. In addition, Wabelua renews his applications for leave to appeal against conviction, and
for leave to appeal against the length of his prison sentence. We will refer to the appellants by their surnames for
convenience only, and intend no disrespect in doing so.

2. Pursuant to a direction by the single judge, Mr Hugh Davies QC argued the appeal against the STPO on behalf
of all appellants, and Ms Bex QC represented the prosecution. Mr Moloney QC and Mr Alexander represented
Wabelua in his renewed applications. We express at the outset our gratitude to all counsel for their written and oral
submissions. We are particularly grateful to Mr Moloney and Mr Alexander who have been good enough to act pro
bono.

3. In an earlier trial in the Crown Court at Woolwich, Wabelua had pleaded guilty on 30[th] January 2015 to an
offence of conspiracy to supply class A drugs, namely heroin and crack cocaine. Alford and Karemera had
subsequently been convicted by the jury of that offence. The date of the conspiracy was "on or before 11[th]
September 2014". In a nutshell, it was alleged that the appellants and others had played leading roles in a county
lines operation which supplied drugs from London to Portsmouth and Folkestone. Those based in London had
used mobile phones to advertise the drugs to users, and then despatched couriers to take the drugs to the users.

4. In this trial, the charges related to the exploitation of vulnerable persons – five children aged 15 or 16, and a
young adult with mental health problems – who were used by the appellants to transport the drugs from London to
Portsmouth and to supply them to drug users.

5. The particulars of the offence charged against Wabelua in count 6 of the indictment were that between 16[th] and
27[th] June 2014 he intentionally arranged or facilitated the travel within the United Kingdom of a named youth, with a
view to exploitation of him. The youth was only 16 years old when Wabelua, then aged 20, sent him to Portsmouth
to supply crack cocaine


-----

6. The appellants applied to Mr Recorder (now His Honour Judge) Aaronberg QC to stay the prosecution as an
abuse of the process. Initially the grounds on which that application was made included a misconceived argument
based on a plea of autrefois convict. That argument was rightly abandoned, but other grounds were pursued in a
hearing which lasted for eight days. The Recorder refused the application in a detailed written ruling on 18[th] August
2017. He noted that in the trial at Woolwich of Alford and Karemera, there had been an agreed fact before the jury
that on 29[th] July 2014 Wabelua had been arrested in the company of five males, one of whom was the youth named
in count 6 of the present indictment. There was, however, no reference to that youth's age or to the fact that he had
been used by Wabelua as a courier on three occasions in June 2014.

7. In relation to the various grounds relied on by the appellants, the Recorder held:

a. The charges in the present proceedings were not founded on the same facts, and did not arise out of the same
incident, as the charges on the Woolwich indictment. He accepted that in the Woolwich trial the prosecution,
knowing that there might in future be charges of human trafficking offences, had avoided adducing evidence
relating to the couriers who were the subject of the present charges. He held that the circumstances of the drugs
conspiracy had been "carefully circumscribed by the Crown in the Woolwich trial so as to avoid any activity in
relation to the present … couriers featuring at all or in any significant way in that trial".

b. He rejected a submission that the human trafficking charges should have been prosecuted at the same time as
the drugs conspiracy. Any prejudice which might be caused to the appellants could be guarded against during the
present trial and if necessary in sentencing.

c. He found that the appellants had at no time been told in terms that they would never under any circumstances
be charged with human trafficking offences.

d. He did not accept that either Karemera or Alford had acted in some way to his detriment, or would be prejudiced
if the present trial were to proceed.

e. Nor did he accept that there was any risk of any form of double jeopardy in sentencing.

f. He was satisfied that the present trial was in the public interest.

8. By the time that application had been concluded, there was no time available for the trial to proceed before the
Recorder. It was therefore adjourned, and came before Her Honour Judge Karu. An application was made to the
judge to re-open the abuse of process application, on the basis that the Recorder had been misinformed by the
prosecution about important matters. In a ruling on 27[th] November 2018, the judge held that there had been no
relevant change of circumstances and that the Recorder's ruling therefore could not be re-opened.

9. With that summary of the background, we turn to Wabelua's renewed application for leave to appeal against
conviction. Two grounds of appeal are now put forward: first, that the prosecution of the offence of trafficking was
an abuse of the process of the court; and secondly, that the judge had erred in refusing to admit a statement of a
police officer in which that officer recounted something said to him by the youth named in count 6.

10. A plea of autrefois convict is only available where the same offence is charged in a second indictment.
However, a judge has a discretion – recognised by the House of Lords in Connelly v DPP [1964] AC 1254– to stay
proceedings where a second charge arises out of the same or substantially the same set of facts as an earlier
charge of which the defendant has been convicted. In _R v Beedie [1997] 2 Cr App R 167, it was held that this_
discretion should be exercised in favour of a defendant unless the prosecution establishes that there are special
circumstances for not doing so. In that case, the court also accepted a submission that a defendant should not be
tried again on the same facts for more serious offences on an ascending scale of gravity.

11. In arguing that the Recorder should have exercised this discretion in Wabelua's favour, Mr Moloney submits
that "the alleged conduct on which both indictments were based was essentially the same conduct". He relies on R
_v Phipps_ _[[2005] EWCA Crim 33, in which it was said that, save in special or exceptional circumstances, the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG61-DYBP-P1YF-00000-00&context=1519360)_
prosecution should not be permitted to bring "a second set of proceedings arising out of the same incident as the


-----

first set of proceedings". He also relies on _R v Dwyer_ _[2012] EWCA Crim 10, in which it was said that the_
underlying principle is that the obligation on the prosecutor is to lay all the charges which it wishes to bring arising
out of the same incident. Mr Moloney says that reference was made by the prosecution in the Woolwich
proceedings to the fact that the appellants had used drug runners who were aged under 18, and that in sentencing
for the drugs conspiracy the judge at Woolwich had been obliged by section 4A of the Misuse of Drugs Act 1971 to
treat as an aggravating feature the use of persons aged under 18 to supply drugs. He relies on the fact that
Wabelua on 29[th] July 2014 was in the company of the youth named in count 6.

12. Mr Moloney accepts that the trafficking offence could properly have been charged in the same indictment as
the drugs conspiracy. He submits that the evidence was available to the prosecution as at the date of the trial at
Woolwich. The prosecution had however chosen not to take that course.

13. Ms Bex, in response, submits that at the date of the Woolwich trial, which could not be delayed without a
necessity to seek an extension of the custody time limit, the state of the investigation into the human trafficking did
not permit a decision as to charge then being made. She further points out that Wabelua has at no stage admitted
the elements of the human trafficking offence.

14. Mr Moloney's submissions were well argued, but we cannot accept them. The Recorder was in our judgment
entitled to find that the trafficking charge was not based on the same or substantially the same set of facts as the
drugs conspiracy. It may be noted that in Beedie, exactly the same conduct had been relied on first to support a
charge of an offence contrary to the Health and Safety at Work Act and then to support a charge of manslaughter.
In Phipps the same course of driving was the subject of charges, at separate times, of driving with excess alcohol
and driving dangerously. In Dwyer it was contended on behalf of the appellant that the court, when sentencing him
at an earlier hearing for offences of possession with intent and possession of controlled drugs, had already dealt
with the conduct which had become the subject of a later prosecution for conspiracy to supply controlled drugs.
Here, the Woolwich indictment charged Wabelua in relation to his conduct in entering into an agreement with others
to supply drugs. The present indictment, in contrast, charged him in relation to his conduct in intentionally arranging
travel for a child with a view to exploiting him. That was a distinct form of criminality involving different conduct at a
different time. That essential point is not altered by the fact that the drugs conspiracy charged in the Woolwich
indictment was aggravated by the use of persons aged under 18 to supply the drugs. That aggravating feature
does not involve the crucial and distinct element of human trafficking. We are satisfied that this was not a case of
the prosecution seeking a second bite at the same cherry.

15. It does not appear that there is maintained any challenge to the judge's refusal to re-open the Recorder's ruling.
That concession is, in our judgment, appropriate. The judge rightly observed that the effect of section 40 of the
Criminal Procedure and Investigations Act 1996 was that the Recorder's ruling had binding effect and an application
to discharge or vary it could only be made if there had been a material change of circumstances. She was entitled
to find that the matters relied on by the defence did not meet that test.

16. The second ground of appeal against conviction relates to the judge's refusal to permit Wabelua to adduce
evidence that the victim of his trafficking offence had told a police officer that nobody had forced him to sell drugs
and that he had done it for the money. Wabelua's defence to the human trafficking charge was that he had
believed the youth concerned to be aged over 18, and had no intention of exploiting him. It was common ground
that the youth would not attend court at the behest of either the prosecution or the defence. It was submitted that
the hearsay evidence of his statement to the police officer was admissible because it supported Wabelua's belief
that the youth was an adult. The judge held, correctly in law, that it was not necessary for the prosecution to prove
that the youth concerned did not consent to act in the manner which Wabelua had arranged or facilitated. On that
basis she ruled that the hearsay evidence was not relevant to any issue which the jury had to decide, and therefore
should not be admitted.

17. Mr Moloney and Mr Alexander in their written submissions contend that this hearsay evidence should have
been admitted because the fact that the youth concerned was able to be so assertive with a police officer, and to
rationalise his reasons for being involved in drug dealing, was evidence of his confident and assertive disposition
and thus supportive of Wabelua's assessment of his maturity.


-----

18. Ingenious as that submission is, we are unable to accept it. Even if the jury might have been prepared to
accept that Wabelua had thought the matter through in the way suggested, this brief statement could not assist him.
Brashness, self-confidence and a wish to make what appears to be easy money are commonly found in
adolescents as well as in adults. The fact that the youth concerned spoke to a police officer in terms which may
have demonstrated those characteristics could not be said to provide any support for Wabelua's evidence as to his
own state of mind. The judge was clearly correct to refuse to admit the evidence.

19. In those circumstances we agree with the single judge that there is no arguable ground on which Wabelua can
challenge the safety of his conviction on this indictment.

20. The ground of appeal against sentence is that there is disparity between the length of Wabelua's sentence for a
single offence and the length of the sentences imposed on Alford and Karemera for three offences.

21. We can deal with this ground shortly, because we agree with the single judge that it is unarguable. The judge
had heard all the evidence against Wabelua at the trial, and was in the best position to assess the criminality of
each of the three appellants. Alford and Karemera had each entered his pleas on a basis which was agreed by the
prosecution and accepted by the judge. She also had to have regard to totality in their cases. It is not submitted
that Wabelua's sentence, viewed in isolation, was in any event too long. An argument based on disparity cannot
succeed in those circumstances.

22. For those reasons, grateful though we are to Mr Moloney and to Mr Alexander, we refuse their renewed
applications on behalf of Wabelua.

23. We turn to the appeal against the STPO. Such an order can be made when a court is sentencing a defendant
for a relevant offence, or on a free-standing application by a Chief Officer of Police (and certain other designated
persons) which is not dependent upon a conviction.

24. The power to make an STPO on sentencing is contained in section 14 of the Modern Slavery Act 2015, which
provides:

"14 Slavery and trafficking prevention orders on sentencing

(1) A court may make a slavery and trafficking prevention order against a person ('the defendant') where it deals
with the defendant in respect of —

(a) a conviction for a slavery or human trafficking offence,

(b) a finding that the defendant is not guilty of a slavery or human trafficking offence by reason of insanity, or

(c) a finding that the defendant is under a disability and has done the act charged against the defendant in respect
of a slavery or human trafficking offence.

(2) The court may make the order only if it is satisfied that—

(a) there is a risk that the defendant may commit a slavery or human trafficking offence, and

(b) it is necessary to make the order for the purpose of protecting persons generally, or particular persons, from the
physical or psychological harm which would be likely to occur if the defendant committed such an offence.

(3) A 'slavery or human trafficking offence' means an offence listed in Schedule 1.

(4) The Secretary of State may by regulations amend Schedule 1.

(5) For the purposes of this section, convictions and findings include those taking place before this section comes
into force."

25. It is also relevant to consider section 17 of the Act, which provides:


-----

"17 Effect of slavery and trafficking prevention orders

(1) A slavery and trafficking prevention order is an order prohibiting the defendant from doing anything described in
the order.

(2) The only prohibitions that may be included in the order are those which the court is satisfied are necessary for
the purpose of protecting persons generally, or particular persons, from the physical or psychological harm which
would be likely to occur if the defendant committed a slavery or human trafficking offence.

(3) The order may prohibit the defendant from doing things in any part of the United Kingdom, and anywhere
outside the United Kingdom.

(4) Subject to section 18(1), a prohibition contained in a slavery and trafficking prevention order has effect—

(a) for a fixed period, specified in the order, of at least 5 years, or

(b) until further order.

(5) A slavery and trafficking prevention order —

(a) may specify that some of its prohibitions have effect until further order and some for a fixed period;

(b) may specify different periods for different prohibitions.

(6) If a court makes a slavery and trafficking prevention order in relation to a person who is already subject to such
an order (whether made by that court or another), the earlier order ceases to have effect."

26. By section 30 of the Act, a person who without reasonable excuse does anything which he is prohibited from
doing by an STPO commits an offence, triable either way and punishable, on conviction on indictment, with
imprisonment for up to five years.

27. The judge in her sentencing remarks recognised that an STPO should only be made if it was both necessary
and proportionate. She observed that the statute required her to consider whether there was a risk that any
defendant would commit another slavery or human trafficking offence and that it is necessary to make the order for
the purposes of protecting the public from harm. On the evidence she had heard, including the evidence which
Karemera had given before he changed his pleas to guilty, she was, she said, "more than satisfied" that there was
such a risk.

28. The precise terms of the order which the judge made in respect of each of the appellants can be seen from the
copy of it which is annexed to this judgment.

29. The grounds on which these orders are challenged are the same in each case. Mr Davies submits first that the
order was wrong in principle because the requisite risk was not established and in any event the order was not
necessary. Secondly, the terms of the order were wrong in principle and/or disproportionate and/or ambiguous.

30. Mr Davies submits that it will rarely be possible to say that there is no risk at all that a defendant who has
committed a slavery or human trafficking offence will not commit another such offence in the future; and that any
such risk can be said to carry with it the likelihood of physical or psychological harm to the victim. He submits that it
is therefore appropriate to read the statutory provision as applying only to a risk which is sufficient to justify the
making of a STPO, and to give the word "necessary" – which is used both in section 14(2) and section 17(2) – its
full weight. He submits that in the circumstances of this case, there was no real risk, and no necessity for an order.
If the court is against him on that, Mr Davies challenges the individual terms of the orders.

31. Mr Davies has invited our attention to Home Office guidance as to STPOs. He has also assisted the court with
materials relating to the nature of county lines drug dealing, which he submits are relevant to the issue of whether
an order, or an order in these terms, was necessary.


-----

32. There is little if any authority on the correct approach for a court to take when considering the exercise of its
power under section 14 of the 2015 Act. Mr Davies draws an analogy with the principles relevant to Sexual Harm
Prevention Orders, and their predecessors, Sexual Offences Prevention Orders, and refers to a number of cases
decided in that context. He relies on the statement in _R v Steven Smith [2012] 1 Cr App R (S) 82 at [4] that a_
Sexual Offences Prevention Order

"must meet the twin tests of necessity and clarity. The test of necessity brings with it the subtest of proportionality."

Further, in reliance on Steven Smith in the sexual context, Mr Davies submits that in a human trafficking case, if the
necessary risk is established, three questions must then be addressed: (1) Is the making of an order necessary to
protect from harm? (2) If some order is necessary, are the terms proposed nonetheless oppressive? (3) Overall
are the terms proportionate?

33. In this case, each of the appellants must spend a number of years in prison. Having entered prison as young
adults, they will leave in their mid to late 20s at the earliest. Each will be on licence for a substantial period when
released. Further, by reason of his conviction, each will be barred from working with children and vulnerable adults
under the _[Safeguarding Vulnerable Groups Act 2006 and will be listed on the Disclosure and Barring Service](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y01P-00000-00&context=1519360)_
database. It will be possible for a Chief Officer of Police to apply for a STPO if an appellant's behaviour after
release makes such an application appropriate. Thus, submits, Mr Davies, there are already regimes in place
which provide protection for the public against the harm which would be likely to result from any future relevant
offence. Moreover, he submits, the court should be careful to avoid making an STPO which is not necessary
because it may thereby impede the rehabilitation of an offender, for example by making it harder for him to find
lawful employment or to reintegrate into society.

34. Ms Bex submits that the judge was entitled to find that there was a risk and that it was necessary to make an
STPO in each case. Each of the appellants had significant previous convictions. Each had been engaged in
supplying class A drugs for profit, and had relied on human trafficking to do so. One of the grounds on which they
had chosen the victims of the trafficking offences was the vulnerability of those persons for whose welfare the
appellants had shown a disregard.

35. Ms Bex further submits that the safeguarding provisions which are already in place, as mentioned by Mr
Davies, will have effect largely in the context of lawful employment and therefore do not assist in relation to the risk
of further offending. She submits that the fact that a free-standing application could be made in future is not an
answer to the necessity for an order following conviction, particularly having regard to the important role of an order
of this kind in deterring an offender from further crime and in making it more difficult for him to engage in further
crime. She submits that whilst the wording of some of the particular provisions of the order may have left
something to be desired, each of the terms imposed by the judge was necessary and proportionate to protect the
children and vulnerable adults who would be likely to be harmed by further human trafficking offences. She points
to the use of multiple mobile phones in the drug supply operation, and submits that the prohibitions imposed by the
judge in respect of the ownership and possession of mobile phones were therefore clearly necessary. She submits
that prohibitions in relation to computers are also necessary because they too can be used to communicate through
social media. Both counsel made helpful submissions as to the detail of the wording of some of the clauses of the
order which we have annexed to this judgment.

36. Having reflected on these submissions, we would summarise the principles which are applicable in a case
covered by section 14(1) of the 2015 Act as follows:

(a) As subsection (2) makes clear, an order can only be made if the court is satisfied that there is a risk that the
defendant may commit a slavery or human trafficking offence and satisfied that the order is necessary for the
purpose of protecting persons generally, or particular persons, from the physical or psychological harm which would
be likely to occur if the defendant committed such an offence. The subsection does not require the court to apply
any particular standard of proof.


-----

(b) Although an STPO is a civil order, breach of it carries a serious criminal sanction. The risk that the defendant
may commit a slavery or human trafficking offence must therefore be real, not remote, and must be sufficient to
justify the making of such an order. In considering whether such a risk is present in a particular case, the court is
entitled to have regard to all the information before it, including in relation to any previous convictions of the
defendant concerned, or in relation to any previous failure to comply with court orders.

(c) The order must be necessary for the purpose of protecting persons generally, or particular persons, from the
physical or psychological harm which would be likely to occur if the defendant committed a further slavery or human
trafficking offence, and not merely desirable or helpful in that regard.

(d) In many cases where the risk is identified, there will also be a necessity to make an order. However, they are
distinct preconditions to the making of an order and they require separate consideration. In determining whether
any order is necessary, the court must consider whether the risk is sufficiently addressed by the nature and length
of the sentence imposed, and/or the presence of other controls on the defendant, and/or the important ability of a
Chief Officer of Police to apply for an order if it becomes necessary to do so at some time in the future.

(e) The criterion of necessity applies not only to the making of an order at all, but also to the individual terms of the
order where one is necessary.

(f) The terms of the order must in addition be both reasonable and proportionate to the purpose for which it is
made: that is one of the reasons why the court must first have made a clear assessment as to why an order is
necessary. The court should take into account any adverse effect of the order on the defendant's rehabilitation, and
the realities of life in an age of electronic means of communication.

(g) The terms of the order must be clear, so that the defendant can readily understand what he is prohibited from
doing and those responsible for enforcing the order can readily identify any breach.

(h) A draft order must be provided to the court and to all defence advocates in good time to enable its terms to be
considered before the sentencing hearing. We recognise the pressures on judges and advocates, and we
recognise that the sentencing process may follow immediately after the jury's verdicts. However, the necessary
careful consideration cannot be given to the proposed order if the draft is produced at the last moment.

37. In the present case the judge was in our view entitled to find that there was a risk that each of these appellants
may in future commit a slavery or human trafficking offence. She had heard the evidence at trial, which clearly
showed the deliberate exploitation of persons who were vulnerable by reason of youth or, in one case, by reason of
mental health issues. True it is that the appellants, all now aged 26, were aged only about 20 at the time of the
offences, and there was therefore scope for them to mature and to put their offending behind them – as indeed
material which we have seen from the prison suggests that Alford for one is managing to do. But that prospect is in
our view relevant to the issue of necessity rather than to the existence of a risk which was more than remote.

38. As to necessity, we are persuaded by Ms Bex's submissions that the judge was entitled to find that it was
necessary to make an order.

39. In our judgment, however, the terms of the order made against each appellant cannot all be regarded as
necessary. We accept that it is necessary to take steps to prevent the appellants having access to untraceable
mobile phones and computers which could be used for the purposes of communications in future drug dealing and
related human trafficking. If, however, such devices are registered in the name of an appellant, and the current
address of each appellant is known to the police, we do not accept that it is necessary to prohibit altogether even
the possession of a second phone or computer. We see no necessity for the order in clause 4, preventing contact
between the appellants, which on any view is a substantial interference with each appellant's right to a private life.
Given that the essence of the appellants' conduct was for the most part to keep themselves out of the limelight and
to use mobile phones to despatch others to deliver the drugs, and that there was limited evidence of any appellant
himself making a car journey, we see no necessity for prohibiting the ownership or use of a vehicle without prior
notification to the police. Nor in the circumstances of this case do we see any necessity for the order made in


-----

clause 6, prohibiting each appellant from undertaking or arranging any journey for a person under the age of 18,
save in very limited circumstances.

40. We would add that even in respect of the prohibitions which we accept are necessary, the drafting of the order
is unsatisfactory in certain respects. In clause 3, it is not clear to us whether the intention is to permit more than
one computer only if all the computers (as opposed to the second or subsequent computers) are for the purposes of
lawful employment. Nor do we find it clear what is meant by the reference to an "operational" police station, rather
than to a police station, in the context of an appellant being required to provide information to somebody at a police
station. In clause 8, despite Ms Bex's submissions, we remain of the view that the reference to a "change/upgrade"
is very far from clear. As Mr Davies pointed out in his submissions in reply, the very fact that the members of this
court and Ms Bex were engaged in a debate about it for some minutes illustrates the difficulties confronting a
defendant who wishes to know what precisely he may and may not do. Whilst in one sense these deficiencies may
be thought minor and easily capable of correction, their significance in the circumstances of this case is that they
suggest a failure to give sufficiently clear thought to the necessary terms of the order.

41. Finally, we are concerned as to the duration of the orders. Given that the appellants were young adults when
they committed the offences, we see no necessity for the orders to extend for 15 years. In our judgment, a
significantly shorter period will suffice.

42. In the result, we allow each of the appeals against sentence to this limited extent. We uphold the judge's
decision that STPOs were necessary, but we quash the terms which she imposed and we substitute in each case
the following:

"During the period of seven years from 14[th] May 2019:

(a) You must not own or possess any mobile phone handset or SIM card, or any computer, unless (i) it is
registered with your service provider in your full name and at your current address, and (ii) details of its make,
model and identification number have been provided to the police within three days after you acquire it.

(b) You must notify your home address to the nearest police station and notify any change of that address to the
police within seven days after you move."

______________________________

A N N E X:

TERMS FOR EACH DEFENDANT

This order imposes the following prohibition(s) and requirements upon you:

1. You must not own or possess more than one mobile phone handset

2. You must not own or possess more than one mobile phone SIM card and this must be registered in your full
name and address (as outlined in this order) with the service provider

3. You must not own or possess more than one computer, save for the purposes of lawful employment, and you
must provide details of this lawful employment (details: place of work, name of employer) within 3 days to the
nearest operational police station to where you are living. For the avoidance of doubt, a computer includes, but is
not limited to:

a. desktop computer

b. laptop computer

c. tablet computer

d Netbook


-----

4. You must not contact, by any means, directly or indirectly: [INSERT CO-DEFENDANTS]

5. You must not own or be insured to drive a vehicle which you have not notified the police the details of (details:
make, model and registration number); you must notify the police at the nearest operational police station to where
you are living,

6. You must not drive, escort or arrange the travel of any person under the age of 18 in any vehicle, save for
members of your family whose parent or guardian is aware of your conviction(s) for offences contrary to section 4
(1A) (b) of the Asylum and Immigration (Treatment of Claimants etc.) Act 2004.

7. You must disclose your home address to the nearest operational police station to where you will be living - and
to notify the police of any change of address within 7 days of moving.

8. You must not own or possess a mobile phone handset or SIM card unless you have notified the police at the
nearest operation police station to where you will be living, of the details of that mobile phone handset and SIM card
AND notify the police within 3 days of any change/upgrade of these items

9. You must not own or possess a computer unless you have notified the police at the nearest operational police
station to where you will be living, of the details of your computer (including make model and serial number) AND
notify the police within 3 days of any change/upgrade of these items

For a period of 15 years

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

