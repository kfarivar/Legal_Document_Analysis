# R v AM [2022] EWCA Crim 651

Court of Appeal, Criminal Division

Fulford LJ, Simler LJ, and HHJ Edmunds

17 March 2022Judgment

MR IAN HENDERSON QC & MR TOMAS QUINN appeared on behalf of the Applicant

_________

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**J U D G M E N T**

**LADY JUSTICE SIMLER:**

**Introduction**

1.  On 11 August 2021, in the Central Criminal Court before the Recorder of London, HHJ Mark Lucraft
QC and a jury, the applicant ([an age]) was convicted of conspiracy to cause grievous bodily harm with
[intent, contrary to section 1(1) of the Criminal Law Act 1977 (count 1); and murder contrary to common law](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BG90-TWPY-Y135-00000-00&context=1519360)
(count 2). He was sentenced by the Judge on 17 September 2021 (by which time he was 18) to five years'
detention on count 1 and detention at Her Majesty's Pleasure on count 2, with a period of 21 years (less
[501 days on remand) specified as the minimum term under section 322 of the Sentencing Act 2020.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)

2. There were three co‑accused all convicted of the same two offences. Muhammad Jalloh, born 5

December 2001, was sentenced to detention for life with a minimum term of 27 years; Vagnei Colubali,
born 18 January 1998, was sentenced to life imprisonment with a minimum term of 27 years; David Ture,
born 9 October 2001, was sentenced to detention for life with a minimum term of 26 years.

3. The applicant now applies for an extension of time of 20 days in which to renew his application for leave
to appeal against sentence and for a representation order after refusal by the single judge. Mr Henderson
QC appeared with Mr Quinn pro bono on his behalf, and we are grateful to them both for the assistance
they have provided, both by way of written submissions and at the hearing. We say at once that in light of
the explanation provided in the letter of 19 January 2022 that we extend time to validate this renewed
application.

**Factual background**


-----

4. The context of both offences was violent rivalry between the North and South Newham gangs, each
offender being allied to the North Newham gang.

5. On 15 April 2020 the applicant made internet searches for "hunting knives". The applicant was a close

associate of Jalloh. The other two co‑accused, Colubali and Ture, were close associates. The group

started to communicate together as a four on 24 April 2020. The next day the applicant and Jalloh
travelled to Woodford Green, where they collected a stolen car, which they drove back to Newham and
parked in Whitelegg Road.

6.  On 26 April Ture travelled from the hostel where he had been staying in central London and Colubali
travelled from Enfield to North Newham. They met up with the applicant and Jalloh at the City View Hotel
in E15. All four then took a taxi to Whitelegg Road, each carrying a bag. In order to avoid detection their
mobile phones were turned off or left at their addresses. Once at Whitelegg Road they changed their
clothes, and then, armed with large knives and machetes, they got into the stolen car with Colubali as the
driver. They drove to the South Newham area and into Freemasons Road - considered to be the heart of
the Southside Newham territory. It appears they did not have a specific target but intended to attack any
young man they considered was connected to rival territory by virtue of presence in the area.

7. At 9.42 pm they pulled up as an unidentified man crossed the road as their car passed him. The
applicant, Jalloh and Ture got out of the car and ran after the man. CCTV shows that they had knives in
their hands. The unknown man realised what was happening and was able to escape. The applicant,
Jalloh and Ture then returned to the car. The car continued to drive around the immediate area. At 9.57
pm they stopped next to another man walking along Prince Regent Lane but for some reason decided not
to attack him. The car drove on.

8. At 10.17 pm David Gomoh left his house on Lambert Road to go to the shops. He turned into
Freemasons Road and soon afterwards their vehicle approached him. They asked him, “Where are you
from?” The applicant, Jalloh and Ture then jumped out of the car and ran after him. He tried to run but
was caught and set upon. The three laid into him with long knives that they had been carrying. He was
stabbed no fewer than ten times with wounds to his head and body, some as deep as 19.5 cms. He
managed to stagger back to his home, where he collapsed on the doorstep. Despite emergency surgery
he died soon after having reached hospital. He was only 24 years old and leaves behind a devastated
family.

9. The four men made their escape in the stolen car, before they were forced to abandon it in North
Newham when one of the wheels came off. They tried to wipe down the areas of the car they had touched
and to remove anything connecting them to it. They returned on foot to Whitelegg Road, where they
changed their clothes. The applicant and Jalloh returned to the hotel. Ture went back to his hostel and
Colubali returned to his home in Enfield.

10. The next day Colubali and Ture travelled to Cambridge. The applicant and Jalloh returned to
Whitelegg Road to retrieve clothing that the group had abandoned the previous night. The weapons used
and the clothing they wore were never found and were probably hidden, discarded or destroyed.

**The sentence**

11. The applicant was [an age] at the date of sentence (born on [a date]). He had five convictions for 14
offences spanning the period 2018 to 2020. In 2018 he received a YRO for battery, theft and simple
possession of class B drugs. In 2019 a further YRO was made for possession of an article with a blade on
school premises. In 2020 he was sentenced for offences of possessing class A drugs with intent to supply,
simple possession of class A and class B drugs, and failing to surrender. His most recent offence was in
March 2020, when he was given an absolute discharge for simple possession of class B.

12. There were victim personal statements available to the Judge and we too have read them. They are
from David's mother, Marianne Gomoh, dated 29 July 2021, and his sister Lizzie Gomoh, dated 10 August

2021. Both speak of the devastation caused by the murder of a much‑loved, talented and hard‑working

young man.


-----

13. There was a pre‑sentence report in the applicant's case because of his age, [an age] at the date of

commission of the offence. We too have read that report. It sets out the applicant's background
circumstances, including that he was [an age] when he first became involved in gangs; that he had used
the term “family” when describing his experiences with those gangs. Despite that, he recognised that he
felt pressure to take part in criminality due to the peer group with which he had associated, although he
consistently denied any motivation to harm others. The family had been moved to Telford in 2019 because
of safety concerns in the local community around his involvement and exposure to this group. They had
always been considered a significant concern due to the pull they appeared to have over him. His London

peer group was linked to pro‑criminal gangs known for substance misuse, drug dealing, weapons and

violence, and it was thought, this had significantly impacted on his thinking, behaviour, decision making
and perception of risk, both to himself and to others. Notwithstanding the move to Telford, it appears he
returned to London. The report referred to a Conclusive Grounds Decision that the applicant was a victim
of modern slavery by virtue of forced criminality.

14. The Judge also had a psychiatric report from 2019 referring to the applicant's presentation as being
consistent with that of an individual with conduct disorder, which was thought to explain the pattern of his
repetitive, persistent dissocial, aggressive and defiant conduct, with the frequency and severity of those
behaviours being outside the normal range of behaviour for an adolescent of the same age and same
sociocultural context. The applicant was assessed nonetheless as presenting a high risk of reoffending
and as being a very high risk of serious harm.

15. When sentencing all four offenders the judge was required to identify the appropriate starting point for

the minimum term in each case. So far as the co‑accused are concerned, paragraph 4 of Schedule 21

provides for a starting point of 25 years for an offender aged over 18 who commits an offence with a
weapon or knife brought to the scene. This was the starting point taken for Jalloh, Colubali and Ture.
There were aggravating features of the murder that applied to all four: first, significant planning and
premeditation; secondly, particularly dangerous weapons; thirdly, a group attack on an unsuspecting,
entirely innocent lone man at night; fourthly, the context of the murder was gang rivalry, in respect of which
the supply of drugs was at its core; and fifthly, the murder was marked by its brutality. A potential
mitigating factor of an intention to cause serious bodily harm rather than to kill was found not to be
available in any of their cases, and the Judge made clear that the only mitigating factor was the age of
each, and that had to be considered, as he observed, in the assessment of the appropriate minimum
terms. In addition, the minimum term had to be increased to reflect the offending in count 1 (the
conspiracy to cause grievous bodily harm), which was a category 1 culpability A offence. This meant,

viewed alone, it had a starting point of 12 years' custody and a category range of 10‑16 years. In each

case the co-accused had previous convictions which aggravated the seriousness of these offences.

16. So far as the applicant is concerned, the Judge made clear that his age put him in a different position
because he was under 18 when the murder was committed. In his case, paragraph 6 of Schedule 21
meant that the appropriate starting point for determining the minimum term was 12 years. The applicant,

like his co‑accused, took a knife to the scene to be used as a weapon, but unlike in the case of his adult

co‑accused, that is not reflected in the 12 year starting point. This factor therefore warranted a significant

upward adjustment. There were the same aggravating features as the Judge had identified in the other
cases, and the only real mitigation was his age. The Judge did, however, refer expressly to the contents of

the pre‑sentence report and to the applicant's active engagement in courses while in custody and positive

attitude and behaviour. The Judge took the minimum term of 21 years less time on remand, to which we
have referred.

**The application**

17. Mr Henderson QC and Mr Quinn do not contend ‑ quite rightly ‑ that there is any basis for criticising

the approach adopted by the Judge in this case. He identified all factors that were proper to his
consideration The simple point made in concise focused submissions advanced by Mr Henderson is


-----

that the applicant's age and immaturity, as identified in the pre‑sentence report (which provided real insight

into this applicant) was not properly reflected in the minimum term adopted by the Judge. The applicant's
age should have been properly reflected, as should his immaturity, and the contention is that this was not
done.

18. We have reflected carefully on this submission but concluded that the grounds are not arguable. The
Judge presided over the trial and was particularly well placed to assess both the applicant's close
involvement in all aspects of this grave offending, and his maturity, character and attitude to the offences
and to gang violence more broadly. It is clear from his careful sentencing remarks that he had in mind the
need for a careful approach, given that the four defendants' ages at the time of the offence fell on different
sides of the age thresholds. He took an entirely proper approach by moving from each starting point to a
position where the disparity between the offenders was nothing more than a fair reflection of those age

differences: see to this effect Attorney‑General Reference Nos 143 and 144 of 2006 _[[2007] EWCA Crim](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFW1-DYBP-P011-00000-00&context=1519360)_

_[1245 at paragraph 27.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFW1-DYBP-P011-00000-00&context=1519360)_

19. Relative youth was a prime mitigating factor in the case of each offender and the effective difference of
six years between the longest and shortest minimum terms to be served, properly and adequately reflected
both the differences in age and the differences in maturity. It seems to us, notwithstanding the
submissions advanced by Mr Henderson, and as he realistically accepted, that there is a limit to which the
assessment of immaturity can be taken where a judge is sentencing in a case as serious as this one. It
involved cold, calculated planning; the setting about to kill any random man on the streets who fitted their
chosen profile; and deliberate behaviour afterwards to conceal what they had done. The applicant played
his full part in all of that. The judge made a careful assessment giving express consideration to the

pre‑sentence report. The sentence he imposed properly reflected the criminality involved and the personal

circumstances of this applicant, both so far as his own age and maturity are concerned.

20. We understand why this application was pursued by Mr Henderson. It was pursued in a compelling
and masterly way, but notwithstanding the submissions made, this application is refused for all these
reasons.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400Email: Rcj@epiqglobal.co.uk

**End of Document**


-----

