# R v Saffa [2021] EWCA Crim 661

CA, CRIMINAL DIVISION

202100311 A2

Edis LJ, Farbey J, HHJ Flewitt

Friday, 16 April 2021

16/04/2021

MRS JUSTICE FARBEY:

1 On 5 January 2021, in the Crown Court at Manchester Minshull Street before HHJ Nield, the appellant, then aged
23, pleaded guilty to one offence of producing a controlled drug of Class B (cannabis) contrary to s.4(2)(a) of the
_[Misuse of Drugs Act 1971.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)_

2 On 19 January 2021 HHJ Edwards imposed a sentence of 12 months' imprisonment. The appellant appeals
against sentence by leave of the single judge.

3 The facts of the offence may be shortly stated. At around 6.00 am on 1 December 2020 police attended a house

in Ashton‑under‑Lyne. The appellant was in the living room. Officers found 72 mature cannabis plants, as well as

transformers, filters and fans. The electricity to the house had been bypassed. The appellant was arrested and
interviewed. He put forward a prepared statement in which he said that he had arrived in the United Kingdom on 27
November 2020 in the back of a lorry. He had been brought to the house to work in return for his travel to the UK.
He accepted that he had watered the plants but said that he did not know that they were cannabis. He denied
abstracting electricity.

4 The appellant was sentenced on a written basis of plea in which he said that he was not told before he travelled
that he would be required to pay back his traffickers by helping to grow cannabis. He was living in a single room in
the house, the rest of which was a cannabis farm. He reiterated that his job was to water the plants. He was
frightened of the consequences of not carrying out that job. He had no part in bypassing the electricity meter.

5 The sentencing hearing had been adjourned for the Crown to consider the basis of plea, which was in the event
accepted. We have found nothing on the Digital Case System to suggest that the court considered a referral under
the National Referral Mechanism with a view to determining whether the appellant should be treated as the victim of
**_modern slavery, though it is not necessary for us in this case to address that matter further._**

6 The judge made the following sentencing remarks:

"This was a relatively sophisticated cannabis operation occupying, as I see from the photographs, a significant
amount of space at [the address]: 72 matured plants and all the hallmarks of active growth. I accept that you were
one of life's victims in all of this and acting under the instruction of others, and so to an extent you were very much
'an innocent abroad'. But to those addicted to drugs in the city, of whom there are many, this would have caused
significant harm and garnered – brought - significant profit to those engaged in the growing. You must have been
aware of the scale of this operation just by looking at it, even if you were oblivious to the bypassing of the meter.


-----

I give you credit for pleading guilty. I treat you as a young man of aged either 22 or 23 years of age, of good
character. I deal with you on the basis that you were involved through exploitation and that your role is a Lesser
Role, Category 2, with a range of six months to three years. The least sentence in my judgment for this offence is
one of 12 months' imprisonment, and that the orders that the prosecution have asked for will apply, as will the costs
order that follows. Thank you very much indeed."

7 These were the entirety of the remarks which the judge made. They were excessively brief. He did not
adequately explain why he placed the offence in Category 2 within the relevant sentencing guideline. He did not
explain what discount he had applied for the guilty plea. Whatever discount he did apply, he must have had in mind
an upward adjustment from the starting point in the guideline and come down again to 12 months for the plea. He
did not explain why he had decided to make an upward adjustment, if indeed that is what he intended to do. The
judge treated as an aggravating factor that the appellant must have been aware of the scale of the operation, but he
failed adequately to explain how he reached that conclusion or how that factor outweighed the mitigation provided
by the appellant's previous good character.

[8 The judge was under a statutory duty now set out in s.52 of the Sentencing Act 2020 to explain to the appellant in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)
ordinary language the effect of the sentence. Although the appeal would not fall to be allowed on this basis, we
think it right to note that the judge did not carry out that duty.

9 In all these circumstances, Mr Joe Allman on behalf of the appellant submits that the sentence of 12 months was
manifestly excessive. We agree. The judge was under no duty to provide expansive sentencing remarks: _R v_

_Chin‑Charles_ _[2019] EWCA Crim 1140, [2019] 1 W.L.R. 5921. However, the judge in this case failed adequately to_

engage with major planks of the sentencing exercise.

10 In our judgment, there were no grounds for a sentence above the 12 months starting point for a Category 2,
Lesser Role offence, from which a downward adjustment ought to have been made in order to reflect previous good
character. The sentence of 12 months must be quashed and a lower sentence imposed. A sentence of eight
months before discount for guilty plea is just and proportionate. Applying a discount of 25 per cent for the plea
which was given at the PTPH, we substitute a sentence of six months. To this extent this appeal is allowed.

______________

**End of Document**


-----

