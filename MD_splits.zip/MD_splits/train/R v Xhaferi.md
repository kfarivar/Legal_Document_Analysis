# R v Xhaferi [2024] EWCA Crim 1039

Court of Appeal, Criminal Division

Lord Justice Warby, Mr Justice Cavanagh and Mr Justice Wall

15 August 2024Judgment

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**Mr A Hill appeared on behalf of the Appellant**

**____________________**

**J U D G M E N T**

**(Approved)**

**____________________**

Friday 16 August 2024

**LORD JUSTICE WARBY:**

1. On 18 June 2024, in the Crown Court at Isleworth, the appellant was sentenced by Her Honour Judge Rose to
23 months' imprisonment for two offences. For an offence of producing a controlled drug of Class B, contrary to
section 4(2)(a) of the Misuse of Drugs Act 1971, to which he had pleaded guilty during his trial, he was sentenced to
22 months' imprisonment. For an offence of failure to surrender, contrary to section 6 of the Bail Act 1976, to which
he had pleaded guilty at an earlier hearing, the judge imposed one month's imprisonment, which she ordered to run
consecutively.

2. On this appeal, which is brought with the leave of the single judge, the appellant challenges the sentence for the
production offence. No issue is taken with the sentence for the Bail Act offence.

3. The grounds of appeal are that the sentence was far in excess of the appropriate starting point in the Sentencing
Council guideline when neither the facts of the offending, nor the circumstances of the offender justified such an
uplift. It is submitted that the judge failed to give adequate weight to the appellant's true role and to his mitigation.

4. The relevant facts can be shortly stated. On the morning of 15 July 2021 police attended and entered a house in
Feltham which had been reported as being used to grow cannabis. They had apparently been prompted by
intelligence from British Gas. As the officers attempted to force entry, the appellant appeared at an upstairs
windows. Told to stay where he was, the appellant instead jumped from the window and attempted to run away.
He was apprehended.

5. A search of the house revealed that cannabis was being grown on a commercial scale. In three of its six rooms,
with lighting and ventilation, there were some 100 plants in various states of growth. Expert evidence later
estimated the street value of the plants at £70,000.


-----

6. The appellant was found to be in possession of two iPhones which had been used to make calls as the police
tried to enter the house, which was boarded up. It later proved that the calls had been made to one Giviliano
Leskaj. Leskaj was later apprehended, pleaded guilty to the production of cannabis and was sentenced to two and
a half years' imprisonment on the basis that he had played a significant role in the offending.

7. The appellant was aged 23 at the time of the offending and 25 at the date of sentence. He was of previous good
character, with no convictions or cautions for any offending in the United Kingdom. He had entered the UK illegally
from his home in Albania.

8. In interview the appellant's account was that he had been living at the property for three months, acting as the
cannabis gardener. He claimed that he had been put under pressure to do so to pay back someone to whom he
owed £24,000 for bringing him into the country. He said that he ran away because this was his first encounter with
police. His defence at trial was that he was a victim of **_modern slavery. By his guilty plea, he abandoned any_**
attempt to maintain that defence.

9. The judge held that the case fell into harm category 2, as the operation was capable of producing significant
quantities for commercial use and was well above the category 3 starting point of 20 plants. She concluded,
however, that the appellant had played a lesser role, without influence on others above him in the chain. The
starting point was therefore 12 months, with a range of 26 weeks to three years' imprisonment. However, his case
was not towards the lower end of the scale, because he was not engaged through pressure or coercion and he did
receive money.

10. The judge identified the ongoing nature of the operation as an aggravating factor. She also said that "there is
some question of the premises having unlawful access to utility supplies, bearing in mind what was said about the
British Gas intelligence". She declined to give credit for the appellant's guilty plea, which had been entered after the
Crown's case had effectively been called. She concluded by stating that taking account of the nature of the
offending and everything she knew about the appellant, the appropriate sentence was one of 22 months'
imprisonment.

11. There is no dispute, nor do we doubt, that the judge identified the correct guideline category and starting point.
We have, however, concluded that she erred in positioning this case within the guideline range and that, in
consequence, the sentence was manifestly excessive. That is for three main reasons.

12. First, this was a substantial commercial operation within category 2 and well beyond the category 3 starting
point based on 20 plants. But it nevertheless fell a long way short of the top end of the category 2 range, which
encompasses all commercial operations short of those that are capable of producing "industrial" quantities.

13. Secondly, in referring to the ongoing nature of the operation, the judge correctly identified one aggravating
feature of the case which clearly did fall to be taken into account. But this is only an aggravating factor to the extent
that it has not already been taken into account in identifying the offence category. Further, the judge's reference to
the possibility of unlawful access to utility supplies does cause us some concern. That is a matter listed in the
guideline as a potential aggravating factor. But, as the judge acknowledged in her sentencing remarks, there was
no information about the matter, other than the fact that the police raid was prompted by intelligence from the utility
provider. We do not consider that this could amount to a sound basis for increasing the sentence passed on the
appellant to any substantial extent, when he was not said to have initiated or established the operation, or to have
known about any unlawful abstraction of power.

14. Thirdly, and most importantly, this offending was committed by a relatively young man who was said to lack
maturity, who was of previous good character, and who had expressed remorse. All of these are matters listed in
the guideline's non-exhaustive catalogue of factors reflecting personal mitigation. The judge made no express
reference to any of these matters. We do bear in mind that she said she had taken account of all the circumstances
of the case. But we conclude that she cannot have afforded appropriate weight to these significant mitigating
features.


-----

15. In our judgment, the appellant's role did not justify any uplift from the category starting point. The scale of the
operation and its ongoing nature over the three months in which the appellant was involved did require such an
uplift, but there were no other aggravating features of the case of any weight. We do not consider that the nature of
the offending and the aggravating factors would justify a sentence as long as 22 months' imprisonment. The
personal mitigation to which we have referred should have exerted substantial downward pressure on the sentence.

16. The result is that we allow the appeal. We quash the sentence of 22 months' imprisonment and substitute a
sentence of 16 months' imprisonment.

___________________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground Floor, 46 Chancery Lane, London WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________

**End of Document**


-----

