# R (on the application of PM) v Secretary of State for the Home Department

 [2023] EWHC 1551 (Admin)

King's Bench Division, Administrative Court (Birmingham)

The Hon. Mrs Justice Steyn DBE

23 June 2023Judgment

**Samantha Knights KC and Miranda Butler (instructed by Bindmans LLP) for the Claimant**

**Alan Payne KC and Colin Thomann (instructed by Government Legal Department) for the Defendant**

Hearing date: 22 March 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 23 June 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

THE HON. MRS JUSTICE STEYN DBE

**Mrs Justice Steyn DBE :**

A. Introduction

1. The claimant is a victim of **_modern slavery. She is also an asylum seeker whose application for_**
refugee status has yet to be determined. There are separate financial support regimes for victims or socalled 'potential' victims of modern slavery and for asylum seekers. This judgment concerns the financial
support provided to the claimant in the period when it had been determined that there were reasonable
grounds to believe that she was a victim of modern slavery (prior to the conclusive decision that she is a
victim), and she had been assessed as eligible for support pursuant to s.98 of the Immigration and Asylum
Act 1999 ('the IAA') (prior to the determination that she was eligible for support pursuant to s.95 of that
Act).

2. By her claim, the claimant challenged the Secretary of State's cessation, on 6 July 2020, of support
payments ('trafficking support') to victims or potential victims of **_modern slavery in 'initial' full-board_**
asylum-seekers' accommodation ('the cessation decision'). By her amended claim, she also challenged the
re-instatement of financial support on 28 August 2020 at a significantly lower level. As the parties have
done, I shall refer to victims or potential victims of **_modern slavery, together, as 'victims' and to the_**
financial support provided to them in that capacity as 'trafficking support', while recognising that **_modern_**
**_slavery encompasses more than trafficking._**

3. The three grounds of claim are:


-----

i) The Secretary of State unlawfully failed to pay financial support to the claimant, and those in a like
situation, in accordance with §15.37 of the **_[Modern Slavery Act 2015 – Statutory Guidance for England](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
_and Wales (version 1.01, published on 24 March 2020 and in force until 27 August 2020; 'the Guidance');_

ii) The Secretary of State unlawfully failed to consult and/or make appropriate inquiry when reinstating
financial support at a significantly lower rate in an amended version of the Guidance which came into force
on 28 August 2020 (version 1.02; 'the Amended Guidance'); and

iii) The Secretary of State failed to provide adequate financial support to meet the essential living needs of
victims in initial accommodation, including the claimant.

4. On 15 March 2021, Pepperall J granted permission on Grounds 2 and 3, but refused permission on
Ground 1. On 5 November 2021, Fordham J stayed the claim pending the judgment of the High Court in R
_(JB) v Secretary of State for the Home Department [2021] EWHC 3417 ('JB'). On 11 March 2022, I stayed_
the claim pending the outcome of the appeal in _JB. The Court of Appeal gave judgment on 25 October_
2022: JB (Ghana) v Secretary of State for the Home Department [2022] EWCA Civ 1392 ('JB (Ghana)').

5. I granted permission in respect of Ground 1 at the outset of the hearing, the Secretary of State having
conceded, in light of JB (Ghana), that permission should be granted to pursue that ground. With respect to
Ground 1, the parties agree that _JB (Ghana), in which the court held that the Secretary of State had_
unlawfully failed to make payments of £65 per week to those supported under s.95 of the IAA in initial
accommodation, resolves the claimant's claim regarding the failure to make payments to her pursuant to
that provision but they disagree as to her entitlement to support under s.98 of the IAA. Until a few days
prior to the hearing, it was agreed that the claimant was supported under s.95 from 23 June 2020.
However, in a statement dated 21 March 2023, Steve Smyth, Chief Caseworker in the Secretary of State's
Asylum Financial Support team provided evidence that the claimant was only granted s.95 support on 1
December 2020. That is now common ground.

6. Neither the Guidance nor the Amended Guidance which is the subject of this claim remains in effect. On
1 March 2023, following the completion of a review, the Secretary of State issued a new version of the
statutory guidance.

7. As the Modern Slavery Victim Care Contract 2020, issued by the Secretary of State, records in section
2.2 of schedule 2.21,

“Modern slavery is a serious and brutal crime in which people are treated as commodities and exploited
for criminal gain. … **_Modern slavery includes human trafficking, slavery, servitude and forced and_**
compulsory labour. Exploitation takes a number of forms, including sexual exploitation … and victims come
from all walks of life. … In few other crimes are human beings used as commodities over and over again,
for the profit of others. Victims endure experiences that are horrifying in their inhumanity.”

As a victim of **_modern slavery, the claimant is entitled to anonymity: ss.1 and 2(1)(db) of the Sexual_**
Offences (Amendment) Act 1992.

B. Applications to admit late evidence and submissions

8. On the eve of the hearing the Secretary of State applied to adduce further evidence in the form of the
statement of Mr Smyth to which I have referred and an accompanying exhibit. It is in the interests of justice
to grant permission to rely on that late evidence, not least as it includes evidence provided pursuant to the
Secretary of State's duty of candour, on which the claimant relies.

9. Following the hearing, the claimant filed an application on 4 May 2023 seeking permission to rely on an
undated letter from Serco ('the Serco letter'), the fifth witness statement of the claimant dated 3 May 2023,
and a further note from Counsel for the claimant dated 4 May 2023. In a written response, dated 12 May
2023, while criticising the claimant's failure to disclose the Serco letter earlier, in compliance with her duty
of candour, the Secretary of State does not object to the claimant's application. In the circumstances
explained in the letter from the claimant's solicitors, and having regard to the clear relevance of the Serco
letter, it is appropriate to admit this late evidence, and the parties' submissions addressing it.


-----

C. Factual and procedural background

10. The claimant is a Kenyan national. She was (on her case) subjected to female genital mutilation
('FGM') at about the age of 12; and came to the United Kingdom as an adult, on 20 April 2002, in
circumstances where her uncles and elders from her family village were pressuring her to continue her
mother's work performing FGM. She paid an agent to facilitate her journey to the UK. On arrival she was
taken to a brothel where she was sexually exploited for a period of 10 months.

11. On escaping the brothel in February 2003, she was given a place to sleep by an African woman she
met on the street and subsequently lived for a number of years in Leicester with a friend of that woman. In
2007, she began living with a man ('S') with whom she had started a relationship the year before. She
made applications for leave to remain as the partner of a settled person in 2008 and 2014, both of which
were refused.

12. In 2015, the claimant disclosed to her GP that she had been subjected to FGM in Kenya and forced
sexual exploitation in the UK. She was diagnosed as suffering from post-traumatic stress disorder (PTSD).

13. On 29 May 2018, the claimant submitted an application for leave to remain on private and family life
grounds, providing a detailed account of what she had been through. That application was rejected as she
did not have a passport. However, in light of the disclosures made by the claimant in her statement, in
early February 2019 the Home Office referred the claimant to the National Referral Mechanism ('NRM'),
which is responsible for determining whether she is a victim of **_modern slavery, and treated her_**
application for leave to remain as a claim for asylum.

14. On 8 February 2019, the Competent Authority within the Home Office determined that there are
reasonable grounds to believe that the claimant is a victim of modern slavery ('the Reasonable Grounds
decision'). As a result, the claimant became entitled to support and assistance as a potential victim.

15. The claimant was assigned an Outreach Support Worker employed by Ashiana, Sheffield, an
organisation which has been sub-contracted by the Salvation Army to provide support and assistance to
victims of modern slavery. The Salvation Army is the Prime Contractor funded by the Secretary of State
pursuant to the Victim Care Contract ('VCC') (which was renewed and retitled the Modern Slavery Victim
Care Contract ('MSVCC') in January 2021), by which means the Secretary of State seeks to discharge her
duty to support victims. Ashiana is one of 12 subcontractors which provide support. The claimant first met
her Support Worker on 20 February 2019.

16. From the end of February 2019, the claimant began receiving £35 per week as a potential victim of
**_modern slavery. At that time, she was still living with S, and so she did not require accommodation. Her_**
Support Worker also provided the claimant with emotional support and arranged counselling sessions for
her.

17. The claimant had not previously disclosed her experiences of trafficking and sexual exploitation to her
partner. When he read the statement she had provided to the Home Office in around May 2019, their
relationship began to break down. About a year later, on 7 May 2020, the claimant was rendered homeless
when S told her to leave his house for good. The claimant initially stayed with a friend. Her Support
Worker, whom she informed of her changed circumstances, made an application to the Home Office for the
claimant to be provided with accommodation as an asylum seeker.

18. On 13 May 2020, the claimant was granted support under s.98 of the IAA. She moved into 'initial
accommodation' at the Britannia Hotel in Nottingham ('the Hotel'). She lived in the Hotel for more than nine
months, until 24 February 2021. I address the evidence as to the support and payments she received from
the Hotel in the context of addressing the grounds below. Initially, following her move to the Hotel, the
claimant continued to receive £35 per week trafficking support.

19. The timing of the claimant's move into the Hotel was in the early stages of the Covid-19 pandemic.
“Pre-pandemic, an individual could typically be expected to live in initial accommodation for only a short
_time”: JB (Ghana), [31]. On 27 March 2020, in view of the pandemic, the Secretary of State suspended for_


-----

a period of three months the requirement for those who were no longer entitled to asylum support to leave
the accommodation provided pursuant to the IAA. As Bean LJ stated in JB (Ghana) at [33]:

“In consequence, the Secretary of State was left to source additional accommodation for asylum seekers
coming into the support system on an urgent and every-increasing basis. This was achieved, largely, by
accommodating those entrants in hotels.”

20. On 6 July 2020, the Secretary of State made the cessation decision by which she stopped all
trafficking support payments to victims or potential victims of trafficking who were in initial accommodation,
whether it was provided to them pursuant to s.95 or s.98 of the IAA . On 8 July 2020, the claimant was
informed by her Support Worker that her trafficking support would be discontinued.

21. On 15 July 2020, this claim was filed, together with an application for interim relief. On 16 July 2020,
HHJ McCahill (sitting as a judge of the High Court) made an interim order requiring the Secretary of State
to pay the claimant £65 per week (the figure claimed pursuant to §15.37 of the Guidance), and arrears. On
23 July 2020, the Secretary of State applied to vary the interim order to reduce the reinstated weekly
payment (and the sum to be paid in arrears) from £65 per week to the sum of £35 per week that the
claimant had been receiving prior to the cessation decision. The claimant did not oppose that application.
An order to that effect was made by Eady J on 18 August 2020. By the same order, this claim was joined
with the case of LT (CO/2551/2020). LT has since withdrawn his claim as, following the grant of refugee
status, he is no longer eligible for legal aid.

22. On 27 July 2020, the Secretary of State resumed paying the claimant £35 per week, and she has been
paid arrears of £105 in respect of the three-week period following the cessation decision during which she
received no trafficking support payments.

23. On 24 August 2020, the Secretary of State filed summary grounds of defence.

24. On 28 August 2020, the Secretary of State replaced the Guidance with the Amended Guidance.
Paragraph 15.37 of the Amended Guidance provided for financial support in the sum of £25.40 per week to
be provided to any “potential victim or victim of **_modern slavery receiving VCC support” who was also_**
receiving support under ss.95, 98 or 4 of the IAA .

25. Since 27 October 2020, those supported under s.95 or s.4 of the IAA in initial accommodation have
been eligible to receive a payment of £8 per week to cover the costs of buying items to meet their needs
relating to clothes, non-prescription medication and travel. In _JM v Secretary of State for the Home_
_Department [2021] EWHC 2514 (Admin), [2022] PTSR 260Farbey J held that the Secretary of State had_
not properly recognised or carried out her duty to provide those supported pursuant to s.95 of the IAA with
the means of communication.

26. On 17 November 2020, the Secretary of State reduced the claimant's trafficking support to £25.40.
Although that reduction accorded with the Amended Guidance, no application to vary the interim order
requiring the Secretary of State to make payments in the sum of £35 per week had been made. However,
Counsel for the Secretary of State, Mr Payne KC, informed me that in view of the interim order, the
claimant was in fact paid trafficking support at the rate of £35 per week throughout the period she was in
the Hotel, and indeed beyond, albeit in respect of the period from 17 November 2020 she received the
difference of £9.60 per week by way of a back payment after she had left the Hotel.

27. The claimant filed an amended Statement of Facts and Grounds ('SFGs'), and further evidence, on 4
November 2020. On 1 December 2020, Pepperall J granted the claimant permission to rely on her
amended SFGs and additional evidence, and gave the defendant the opportunity to file amended grounds
of defence.

28. On 1 December 2020, the claimant was granted support pursuant to s.95 of the 1999 Act. At this point
she became eligible to receive a weekly payment of £8.24 per week in respect of her needs relating to
clothes, non-prescription medication, travel and communication, although she only in fact received these
payments in arrears nearly a year after she had left the Hotel. On 24 February 2021, the claimant was


-----

provided long-term self-catering accommodation, at which point she started to receive asylum and
trafficking support in the sum of £65 per week.

29. On 15 March 2021, Pepperall J made the permission decision to which I have referred. On 31 March
2021, the claimant applied to renew her application for permission on Ground 1. The parties agreed the
renewal should be dealt with at the substantive hearing of the claim and, as I have indicated, the Secretary
of State ultimately conceded permission should be granted. The Secretary of State filed detailed grounds
of defence ('DGDs') on 30 April 2021.

30. By letter dated 11 November 2022, the Home Office notified the claimant of the Conclusive Grounds
decision in the following terms:

“On 8 February 2019 we said there were Reasonable Grounds to accept that you may be a victim of
**_modern slavery (human trafficking and/or slavery, servitude or forced or compulsory labour)._**

Following further enquiries into your case, the Single Competent Authority has decided that you are a
victim of modern slavery.

**Our decision**

We found the following types of exploitation occurred: forced prostitution and sexual exploitation in the UK
in 2002-2003.”

Once it was conclusively determined that the claimant was a victim of trafficking, she ceased to be eligible
for the trafficking support element that she had previously been receiving. The sum she received weekly
reduced to £40.85 (later raised to £45: see paragraph ý39 below).

31. As I have said, the hearing of this claim was stayed pending the judgments of the High Court and
Court of Appeal in _JB/JB (Ghana). On 20 October 2021 and 2 February 2023, the claimant applied to_
adduce further evidence. Those applications were granted by Andrew Baker J on 15 March 2023, subject
to such permission being “without prejudice to any question of weight or, to the extent the same consists of
_evidence of opinion, admissibility as expert evidence”. On 29 December 2022, the defendant filed_
amended DGDs and the second statement of Mark Ryder, an Adult Victim Support Policy Manager
working in the Home Office's Modern Slavery Unit, pursuant to a consent order dated 24 November 2022.

32. On 17 and 22 February 2023, the Secretary of State adduced further documents in response to
requests made by the claimant. At the outset of the hearing, as I have said, the Secretary of State applied
to adduce the statement of Mr Smyth.

D. The legal and policy framework

**_Asylum support_**

33. Part VI of the IAA makes provision for subsistence support to be provided to asylum seekers,
including, but not limited to, those who are victims or potential victims of modern slavery.

34. Under s.95(1) of the IAA, the Secretary of State may provide or arrange for the provision of support to
asylum seekers who appear to the Secretary of State to be destitute or likely to become destitute within a
prescribed period. In accordance with s.96(1) of the IAA, asylum support provided under s.95 has two key
elements: accommodation and “essential living needs”.

35. Temporary asylum support is provided for by s.98, pending determination of eligibility under s.95.
Section 98 of the IAA provides, so far as relevant:

“(1) The Secretary of State may provide, or arrange for the provision of, support for –

(a) asylum-seekers, or

(b) dependants of asylum-seekers,

who it appears to the Secretary of State may be destitute.


-----

(2) Support may be provided under this section only until the Secretary of State is able to determine
whether support may be provided under section 95.

(3) Subsections (2) to (11) of section 95 apply for the purposes of this section as they apply for the
purposes of that section.

…”

36. Although ss.95 and 98 are expressed as powers to provide support, they were converted to duties by
Council Directive 2003/9/EC which laid down the minimum standards for the reception of asylum seekers:
_R (JM) v Secretary of State for the Home Department [2021] EWHC 2514 (Admin), [2022] PTSR 260, [15]_
[to [16]; and regulation 5 of the Asylum Seekers (Reception Conditions) Regulations (SI 2005/7).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-MPB0-TX08-H185-00000-00&context=1519360)

37. As pleaded by the Secretary of State, ss.95-98 of the IAA are supplemented by the Asylum Support
[Regulations 2000 (SI 2000/704) ('the Regulations') which make provision as to the concept of “essential](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-99F0-TX08-H0Y1-00000-00&context=1519360)
_living needs” for those who are “destitute” within the meaning of both s.95 and s.98. Regulation 9 provides:_

“9.— Essential living needs

(1) The matter mentioned in paragraph (2) is prescribed for the purposes of subsection (7)(b) of section 95
of the Act as a matter to which the Secretary of State may not have regard in determining for the purposes
of that section whether a person's essential living needs (other than accommodation) are met.

(2) That matter is his personal preference as to clothing (but this shall not be taken to prevent the
Secretary of State from taking into account his individual circumstances as regards clothing).

(3) None of the items and expenses mentioned in paragraph (4) is to be treated as being an essential living
need of a person for the purposes of Part VI of the Act.

(4) Those items and expenses are–

(a) the cost of faxes;

(b) computers and the cost of computer facilities;

(c) the cost of photocopying;

(d) travel expenses, except the expense mentioned in paragraph (5);

(e) toys and other recreational items;

(f) entertainment expenses.

(5) The expense excepted from paragraph (4)(d) is the expense of an initial journey from a place in the
United Kingdom to accommodation provided by way of asylum support or (where accommodation is not so
provided) to an address in the United Kingdom which has been notified to the Secretary of State as the
address where the person intends to live.

(6) Paragraph (3) shall not be taken to affect the question whether any item or expense not mentioned in
paragraph (4) or (5) is, or is not, an essential living need.

(7) The reference in paragraph (1) to subsection (7)(b) of section 95 of the Act includes a reference to that
provision as applied by section 98(3) of the Act and, accordingly, the reference in paragraph (1) to _“that_
_section” includes a reference to section 98.” (Emphasis added.)_

38. Regulation 10 provides:

**“10.— Kind and levels of support for essential living needs**

(1) This regulation applies where the Secretary of State has decided that asylum support should be
provided in respect of the essential living needs of a person.

(2) As a general rule, asylum support in respect of the essential living needs of that person may be
expected to be provided weekly in the form of a cash payment of £40.85.


-----

..

(5) Where the Secretary of State has decided that accommodation should be provided for a person by way
of asylum support, and the accommodation is provided in a form which also meets other essential living
needs (such as bed and breakfast, or half or full board), the amount specified in paragraph (2) shall be
treated as reduced accordingly.” (Emphasis added.)

39. The sum of £40.85 referred to in reg.10(2) is the rate that has been in place since 21 February 2022.
However, it has been increased, administratively, to £45, backdated to 21 December 2022, in compliance
with a mandatory order made by Fordham J in CB v Secretary of State for the Home Department [2022]
_EWHC 3329 (Admin). In the period from 6 February 2018 until 8 June 2020, the sum specified in regulation_
10(2) was £37.75. On 8 June 2020, a temporary exceptional increase to the general rate of asylum support
was made, increasing the rate from £37.75 to £39.60. On 20 February 2021, the figure stated in reg.10(2)
was increased to £39.63.

40. The rate of weekly support payments made under the asylum support regime has been the subject of
detailed judicial consideration: JB (Ghana), [29], citing R (SG) v SSHD [2016] EWHC 2639 (Admin), [2017]
1 WLR 4567, [7]-[8].

**_The Asylum Accommodation and Support Services Contract_**

41. For those in full-board accommodation, providers are required to provide services in line with the
“Statement of Requirements” in Schedule 2 to the Asylum Accommodation and Support Contract ('AASC').
A statement from Simon Bentley of the Home Office's Asylum and Family Policy Unit, dated 10 September
2020 (adduced in _R (MLK and SG) v SSHD,_ and disclosed in these proceedings on 17 February 2023),
states:

“20. Section 2.3.5 states that: 'The Authority's preference is for Initial Accommodation to be provided on a
“full board” basis'. However, Section 2.6.5 states that the persons may be provided with either:

    - full board accommodation of at least three (3) meals per day and essential personal hygiene items and
_toiletries; or_

     - accommodation and cash to the appropriate value, as advised by the Authority.”

42. The Statement of Requirements makes no distinction between asylum seekers in initial
accommodation by reference to whether they were supported pursuant to s.95 or s.98.

**_The recognition of victims of modern slavery_**

43. The process of recognition of victims of **_modern slavery, including human trafficking, involves two_**
stages. The first involves determining whether there are 'reasonable grounds' to believe that the person in
question is a victim of **_modern slavery (a so-called 'potential' victim). The second stage, which is only_**
reached if a positive reasonable grounds decision was made, involves deciding on 'conclusive grounds'
whether the person is a victim of modern slavery.

**_Trafficking recovery support_**

44. The European Convention on Action Against Trafficking in Human Beings 2005 ('ECAT') is the
principal international measure designed to combat trafficking in human beings. Among other matters, it is
concerned with the treatment of those in respect of whom there are reasonable grounds to believe that
they are victims of trafficking and the support to be provided to them by Contracting States. The UK signed
ECAT in March 2007 and ratified it on 17 December 2008, but it has not been incorporated into UK law.
Whilst individuals cannot enforce its provisions directly, insofar as the Secretary of State has adopted parts
of ECAT as her own policy in guidance, she must follow that guidance unless there is good reason not to
do so: R (EM) v SSHD [2018] EWCA Civ 1070, [2018] 1 WLR 4386, [19]; JB (Ghana), [9].

45. As Bean LJ observed in JB (Ghana) at [11]:


-----

“Analogous provision was made under Article 11 of the EU Anti-Trafficking Directive (Directive
2011/36/EU), prior to the UK's withdrawal from the European Union at the end of the transition period. The
scope of this duty was examined by the Court of Appeal in the EM case. Peter Jackson LJ held at [65] as
follows:

'The general duty on the State under Arts. 11(2) and (5) of the Directive is to provide assistance and
support to a PVoT [potential victim of trafficking] by mechanisms that at least offer a subsistence standard
of living through the provision of appropriate and safe accommodation, material assistance, necessary
medical treatment including psychological assistance, counselling and information, and translation and
interpretation services.'” (Emphasis added.)

46. It is common ground that until the entry into force of s.68 of the Nationality and Borders Act 2022 on 30
January 2023, the rights contained in the Directive were retained EU law under ss.2(b) and 4 of the
European Union (Withdrawal) Act 2018.

47. As Underhill LJ recounted in R (MD) v Secretary of State for the Home Department [2022] EWCA Civ
_336 [2022] PTSR 1182 at [27], an episode in March 2018 “casts light on the Secretary of State's_
_obligations as regards subsistence payments”. With effect from 1 March 2018 she reduced the amounts_
payable to service users who had been receiving an essential living needs payment from the Home Office
under regulation 10(2) of £37.75 together with a “top-up” payment from the Salvation Army (though funded
by the Home Office) under the VCC of £27.75, from a total of £65 to £37.75. This change was made on the
basis that the Secretary of State “believed that it was wrong that they should receive more than was
_received by asylum-seekers for essential living needs”. Underhill LJ continued:_

“27. … In R (K and M) v Secretary of State for the Home Department [2018] EWHC 2951 (Admin), [2019] 4
WLR 92, … Mostyn J held that that reduction was unlawful because it was based on a misunderstanding of
the concept of 'subsistence' in the Directive, to which the VCC was intended to give effect. In the context of
the Directive the term 'subsistence' went beyond the minimum required to stave off destitution, i.e.
essential living needs, and also covered pecuniary assistance with the recovery needs which were peculiar
to victims of trafficking; and the 'top-up' in the subsistence payment reflected that element. …

31. …the financial support provided for is intended to not only meet the essential living needs of victims but
also to assist more widely with their 'social, psychological, and physical recover' (a phrase deriving from
Article 12.1 of the ECAT).”

48. In _R (K and another) v Secretary of State for the Home Department [2018] EWHC 2951 (Admin),_

[2019] 4 WLR 92('K & AM'), in a passage cited with approval by the Court of Appeal in JB (Ghana) at [14],
Mostyn J considered the scope of “subsistence” needs as provided for under article 12.1 of ECAT and
article 11 of the EU Anti-Trafficking Directive ('the Directive'). He observed at [29]:

“[Counsel] drew my attention to regulation 9(4) of the Asylum Support Regulations 2000 which excludes,
among other things, the cost of computers (which would include smartphones), travel, recreational items
and entertainment in the assessment of 'essential living needs' for the purposes of asylum support. But
some money for these purposes is surely reasonably required by a person in the highly vulnerable and
distressing position of a victim of trafficking. This has recently been in effect conceded by the Home
Secretary through the contract change of 1 November 2018…”

**_The Statutory Guidance_**

49. The Guidance was first published on 24 March 2020 (JB (Ghana), [15]), pursuant to s.49 of the
**_Modern Slavery Act 2015. It remained in effect until it was replaced on 28 August 2020 by the Amended_**
Guidance. “Annex F – Detail of support available for adults in England and Wales” of the Guidance
provided details of “the support available to adult victims of modern slavery” (§15).

50. Annex F (§§15.1-15.29) addressed the provision of accommodation to adult victims of **_modern_**
**_slavery under the headings “Emergency Accommodation”, “Accommodation provided through the Victim_**
_Care Contract”, “Accommodation provided through the asylum system”, “Accommodation provided through_


-----

_Local Authority services”, “Self-supported accommodation” and “Other accommodation”. Paragraph 15.13_
provided, under the heading “Accommodation provided through the asylum system”:

“Outreach support and financial support payments provided through the Victim Care Contract are available
for potential victims and victims in Asylum accommodation during their time in the NRM.”

51. Under the heading “Outreach support”, §15.30 provided:

“Outreach support refers to the services provided to victims who enter VCC support but who are not in
VCC accommodation. This support includes access to all support usually available to victims in VCC
accommodation, except for the accommodation-related elements.”

52. The key paragraphs of Annex F of the Guidance provided so far as relevant:

**“Financial Support**

15.35 Potential victims and victims of **_modern slavery who have entered the NRM, received a positive_**
Reasonable Grounds decision and are in VCC accommodation or outreach support, will be paid financial
support. This payment will continue while they remain in VCC support for as long as they are assessed to
have a recovery need for this assistance. Financial support is intended to meet the potential victim's
essential living needs during this period and assist with their social, psychological and physical recovery.

15.36 The current rate of financial support payable by the Home Office to potential victims or victims of
**_modern slavery receiving VCC support depends on the accommodation they are in. The rates are as_**
follows:

- £65 per week for those in self-catered VCC accommodation

- £35 per week for those in catered VCC accommodation

- £39.60 per week for those receiving outreach support in other accommodation

- …

**Financial support for potential victims who are also receiving asylum support**

15.37 The payment rates will be adjusted if the potential victim or victim of modern slavery receiving VCC
[support is also an asylum seeker or failed asylum seeker receiving financial support under sections 95, 98](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61R0-TWPY-Y0HB-00000-00&context=1519360)
or _[section 4 of the Immigration and Asylum Act 1999 ('Asylum Support'). In these circumstances, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y1G5-00000-00&context=1519360)_
individual will receive £65 per week, made up of payments from asylum support and a further payment
from the VCC to take the total payment to £65 per week.” (Emphasis added.)

53. In the Amended Guidance, the key paragraphs of Annex F were amended to provide (so far as
relevant, and with the new wording shown underlined):

“Financial Support

15.35 Potential victims and victims of **_modern slavery who have entered the NRM, received a positive_**
Reasonable Grounds decision and are in VCC accommodation or outreach support, will be paid financial
support. This payment will continue while they remain in VCC support – until they have received a
Conclusive Grounds decision. Where an individual has received a positive Conclusive Grounds decision,
they will continue to receive financial support for as long as they are assessed to have a recovery need for
this assistance through a Recovery Needs Assessment, subject to the RNA guidance. Where an individual
receives a negative Conclusive Grounds decision, they will receive support as set out in paragraph 7.2.
Financial support is intended to meet the potential victim's essential living needs during this period and
assist with their social, psychological and physical recovery.

15.36 The current rate of financial support payable by the Home Office to potential victims or victims of
**_modern slavery receiving VCC support depends on the accommodation they are in. The rates are as_**
follows:

- £65 per week for those in self-catered VCC accommodation


-----

- £35 per week for those in catered VCC accommodation (only for exceptional circumstances where the
individual is assessed as requiring catered accommodation as they are not capable of preparing their own
food due to disability, debilitating illness or ongoing treatment for severe substance use and addiction).

- £39.60 per week for those receiving outreach support in other accommodation

- …

**Financial support for potential victims who are also receiving asylum support**

15.37 The payment rates will be adjusted if the potential victim or victim of modern slavery receiving VCC
support is also receiving support under sections 95, 98 or section 4 of the Immigration and Asylum Act
1999 ('Asylum Support'). In these circumstances, the individual is receiving asylum support because they
have been assessed as destitute or an assessment is being made on whether they are destitute. In both
cases support is provided by asylum support to meet their essential living needs. Generally, support to
cover essential living needs is provided through a payment of £39.60 per week, but in some cases
essential living needs are met through in-kind assistance or a combination of in-kind assistance and
payments. A further payment will be made from the VCC of £25.40 (calculated at £65 per week minus the
current essential living rate of £39.60 provided by asylum support) to assist with their social, psychological
and physical recovery from exploitation.”

54. The Amended Guidance has been amended on a number of occasions since it was published in
August 2020. The current statutory guidance is not in issue in this claim.

**_Victim Care Contract_**

55. The version of the VCC which was in effect at the material time in 2020 provided as follows in
Schedule 2 to Volume 3, which is entitled “Authority Requirements: Provision of Adult Victims of Modern
**_Slavery Care & Consultation Services”:_**

“6. Subsistence payments

F-001. The Contractor shall provide Service Users with Subsistence Payments in cash and these
Subsistence Payments are to be paid to Service user [sic] on the following basis:

a. On a Weekly basis (same day every week), payable pro rata for part weeks;

b. The first Subsistence Payment being payable to the Service User within 48 hours of entering the
Accommodation; and

c. The Subsistence Payments shall cease when the Service User exits the Service.

The table below provides details of the Subsistence Payments that may be payable to Service Users:

…

F-002 The Contractor shall:

a. Keep complete, accurate and auditable records for each and every Subsistence Payment made to
Service Users;

b. Ensure that these records are available for inspection by the Authority; and

c. Electronically transmit these records to the Authority within 5 working days of a request for the records
being made by the Authority”.

|Service User Type|Value of Subsistence Payment|
|---|---|
|Service User in Catered Accommodation provided by the Contractor|£35|
|Service User in Self-Catered Accommodation provided by the Contractor|£65|


Service user accommodated by the Authority, and in receipt of Subsistence
Payments through that Service


£65 minus the amount of Subsistence
received by the Authority


-----

|Service user Not Accommodated by the Contractor or the Authority (e.g. Living with friends or family)|£35|
|---|---|


56. The reference in the table to accommodation provided by the “Contractor” is to accommodation
provided either by the Salvation Army directly or indirectly through its subcontractors. As Underhill LJ
observed in MD at [24]:

“'The Authority' is a reference to the Secretary of State. It is common ground that the reference to 'the
amount of subsistence received _by the Authority' is a slip for 'from the Authority'. Even as corrected, the_
language is rather opaque, but it is not in dispute that the effect is to require the deduction of sums
received under the Asylum Support Regulations by victims of trafficking who had made asylum claims.
Thus a victim receiving asylum support would receive an essential living needs payment from the Home
Office under regulation 10 (2) together with a 'top-up' payment from the Salvation Army (though funded by
the Home Office) under the VCC to bring the total to £65; for the period from 6 February 2018, for example,
the two payments would be respectively £37.75 and £27.25. It is necessarily implicit in that approach that a
'subsistence payment' under the VCC is intended to cover more than essential living needs…”

**_The Frequently Asked Questions document_**

57. On 29 January 2020, the Head of the VCC at the Home Office sent a 'Frequently Asked Questions'
document to the Salvation Army “to be cascaded to support providers in order to address common
_questions”. The document, entitled “FAQS about subsistence”, was re-sent on 6 April 2020. It included the_
following questions and answers:

“2. Subsistence for catered accommodation clients:

**a) Are we correct in understanding that Catered Accommodation clients are entitled to and should**
**get £35 pw regardless of benefits or income from work etc.?**

Yes – unless they are receiving support from the asylum support system, in which case their financial
support should be £65 pw minus the NASS [i.e. National Asylum Support Service] payment.

…

**4. Subsistence for outreach NASS clients:**

**a) Are we correct in understanding that Outreach NASS clients are entitled to and should get £65**
**pw minus the NASS payment? eg. If client receiving £37.75 from NASS then they are only entitled to**
**the £27.25 top up from the VCC. This is regardless of any other income?**

This should be the position for all clients who are also receiving financial support from NASS, regardless of
where they are accommodated. Any other income should be declared to the asylum support system.”

58. In JB (Ghana) Bean LJ referred to question and answer 2, quoted above, and observed at [35] that
when the Guidance was issued:

“the Head of the Victim Care Contract at the Home Office understood paragraph 15.37 to apply to all
asylum seekers in receipt of cash asylum support, regardless of whether they were accommodated in fullboard or self-catered accommodation.” (Emphasis added.)

**_JB (Ghana)_**

59. In JB (Ghana) the claimant sought judicial review of the Secretary of State's failure to pay him £65 per
week during the period from 31 March 2020 to 28 August 2020. Throughout that period JB was supported
in initial accommodation pursuant to s.95 of the IAA. The claim succeeded in the High Court before Peter
Marquand (sitting as a Deputy Judge of the High Court) who held at [29]:

“There is no ambiguity in the policy and there is no lacuna. The policy is clear as it states that a person
who is both a Potential Victim and an asylum seeker receiving financial support under, in this case, section
95 IAA will receive a total of £65 per week This sum is to be made up of payments from asylum support


-----

plus a further payment from the VCC. … It makes no difference that the Claimant did not receive, as a
matter of fact, the financial support under section 95 IAA that he was entitled to, in whole or part, during the
relevant period…”

60. His judgment was upheld on appeal. Bean LJ (with whom Peter Jackson and Baker LJJ agreed)
stated:

“64. In my view the judge was right for the reasons he gave. Paragraph 15.36 of the March 2020 Guidance
does draw a distinction between catered and self-catered VCC accommodation and, if the matter ended
there, the Claimant would not have been entitled to payments of £65 per week. But the matter did not end
there, because of the inclusion in the document of paragraph 15.37. This states in categorical terms that if
a potential victim of trafficking is also an asylum seeker and receiving asylum support, a further payment is
to be made to him to make a total (including the asylum support) of £65 per week. Nothing is said about
any offset for the value of meals provided in catered accommodation; nor is any distinction made between
claimants who are in catered accommodation and those who are in self-catered accommodation. It would
not have been difficult to draft a paragraph making such a distinction, and an amended scheme was
introduced five months later.

65. It seems to me a reasonable inference that the reason why paragraph 15.37 in the March 2020 version
reads as it does is because (as noted by Farbey J in the _JM case) the practice before the onset of the_
pandemic was that people in JB's position would typically spend only a short time (we were told 4-6 weeks
was a common period) in catered accommodation before being moved on. Although the document was
issued on 24 March 2020, it had been drafted before the onset of the pandemic and the beginning of the
series of lockdowns which we all remember. But that is not a reason to change the plain and obvious
meaning of paragraph 15.37.

66. I do not consider that there is any merit in the Secretary of State's argument that since JB was not in
fact 'receiving financial support' (in the sense of cash payments) under the 1999 Act for a period beginning
on 24 March 2020 that placed him outside paragraph 15.37. I accept the submissions of Mr Buttler that,
firstly, most asylum seekers, even if housed in full board initial accommodation, had been receiving some
cash support as well; and that JB should have been, as was subsequently recognised. It would have
created a very curious anomaly if someone receiving very modest cash payments towards essential living
needs was entitled to be 'topped up' to £65 per week, whereas someone receiving no such payments was
not.

67. It is well established that in construing a policy document a court should not subject the wording to the
kind of fine analysis which might be applied to a statute or a contract: see Tesco Stores Ltd v Dundee City
_Council [2012] PTSR 983per Lord Reed. But the document must still be interpreted objectively. …_

68. The principle set out in cases such as Raissi and Mahad is that documents of this kind should mean
what they say, and should be interpreted as they would be read by a reasonable claimant or support
worker or advisor. …

69. I am entirely unable to accept the argument that paragraph 15.37 contained an obvious error within the
terms of Inco Europe Ltd vs First Choice Distribution [2000] 1 WLR 586…

71. In the present case it is not obvious what the substance of para 15.37 would have been if the drafter
had not made what Ms Giovannetti submits is an obvious error. Moreover, it is far from obvious that the
drafter did not intend a claimant in JB's position to receive a top-up to bring his total payments to £65 per
week. The construction of para 15.37 which the judge found to be correct is consistent with the terms of the
Victim Care Contract between the Home Office and the Salvation Army; and also with the answer given to
question 2 in the FAQs document first issued by the Home Office in January 2020 and re-issued soon after
the promulgation of the guidance on 6 April 2020. It is impossibly ambitious for the Secretary of State to
contend that there was an obvious mistake of the _Inco type in all three documents. As Mr Buttler put it,_
pithily and correctly, a flaw in the design of a policy is not the same as a drafting error.” (Emphasis added.)

61. Finally, I note that at [73] Bean LJ, having stated that the lawfulness of the Amended Guidance issued
on 28 August 2020 was not in issue made the following (obiter) observation:


-----

“I will only say that as at present advised I can see no reason why the Secretary of State should have been
precluded from making the amendment which she did.”

E. The evidence regarding payments to the claimant and in general to those supported pursuant to
**s.98**

62. I shall consider the general evidence regarding payments to those supported pursuant to s.98 of the
IAA before addressing the specific evidence of payments made to the claimant. The Secretary of State's
preference is for initial accommodation to be provided on a full-board basis, but as Mr Ryder acknowledged
in his first statement, cash payments can be made where essential living needs are not otherwise fully met
by the accommodation provider.

63. In his second statement, dated 29 December 2022, Mr Ryder stated:

“9. It remains the position that individuals supported under s.98, including victims of modern slavery, and
in initial accommodation generally have their needs met through in-kind support provided for by full board
accommodation. …

10. S.98 support is intended to be provided on a short-term basis. Those housed in initial accommodation
would generally not receive a cash Asylum Support payment from the Home Office for essential living
needs because either those needs would ordinarily not arise on a short-term basis, or they could
adequately be met by the full board basis of the accommodation. …” (Emphasis added.)

However, the evidence of Mr Smyth dated 21 March 2023 was adduced by the Secretary of State in part to
“provide further clarification on paragraphs 9 to 11 of Mark Ryder's second witness statement”.

64. At paragraphs 49 to 59 Mr Smyth stated:

“Payments under s.98

[Historical Payments under s.98 of the Immigration and Asylum Act 1999](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61R0-TWPY-Y09F-00000-00&context=1519360)

49. At paragraph 9 of MR 2 it was stated, inter alia, that 'Those housed in initial accommodation would
generally not receive a cash Asylum Support payment from the Home Office for essential living needs…'

50. For transparency purposes I wish to clarify that historically, the SSHD has provided subsistence
payments to those supported under s.98.

…

52. Prior to the introduction of ASPEN cards (introduced in November 2016 and by May 2017 it had
superseded other means of centralised payment), the SSHD had a fund set up called the Accommodation
Gatekeeper Hardship Fund ('AGH Fund').

53. This was a mechanism set up to make one-off subsistence payments to those individuals who
(allegedly) did not have any funds but had accommodation, whether private or otherwise.

54. Those who sought payment under the AGH Fund were advised that they would need to submit an
ASF1 (s.95 application) to be considered for ongoing support and that the AGH Fund was a one-off
payment.

55. Once ASPEN cards were introduced, this fund ceased to operate as the SSHD now meets her
obligations under s.98 by way of the provision of full-board accommodation which meets an individual's
essential living needs.

Other Limited circumstances in which payments made to s.98 individuals

56. Under Schedule 2 of the Asylum Accommodation and Support Contract ('AASC'), the SSHD's
preference is for accommodation providers to provide accommodation on a full board basis. However, the
SSHD will consider alternative methods of delivery by the accommodation provider such as self-catered or
half board provision.


-----

57. In the half board and/or self-catered situations, the accommodation provider can and in some cases
shall, under the AASC, provide payments to individuals who are in receipt of s.98 support to meet their
essential living needs.

58. This however is distinct from a direct s.98 payment by the SSHD to the individual. These payments are
contractual in nature, rather than statutory, in order for the provider to meet the requirements of the AASC
because, for whatever reason, the provider is unable to provide full-board accommodation.

59. As set out below, the SSHD accepts that she has a discretion to make payments to individuals in
receipt of s.98 support however, she does not do so. There may be exceptions to this however, without
doing a case by case analysis she would be unable to say when such exceptions have been applied.”

65. In his statement in MLK and SG (see paragraph ý41 above), Mr Bentley stated:

“9. For as long as the person remains in initial accommodation, support to cover their 'essential living
needs' is provided by the accommodation provider in the form of full board in-kind provision, cash or
vouchers, or a mixture of both. The accommodation providers are contractually obliged to provide the
support to meet the 'essential living needs' of those they accommodate. How the support is provided varies
from provider to provider (depending on the type of accommodation and the facilities which are provided). I
go on to explain this in more detail in paragraphs 19-22 below.

10. I should emphasise that this applied whether the person was supported under section 98 (i.e. pending
consideration of an application for section 95 support) or under section 95 (i.e. having been found eligible
for section 95 support but awaiting a move into dispersal accommodation).

…

[Having explained the content of sections 2.3.5 and 2.6.5 of the Statement of Requirements in Schedule 2
to the AASC (see paragraph ý41 above), he continued:]

21. Where the provider is unable to meet a need by providing it directly, they provide a cash allowance or
voucher. For instance, where the provider does not have a washing machine on site, they may provide a
cash payment so that the service user may use a laundrette off site. This cash allowance is not a portion of
the weekly cash payment referenced by the Claimants; the provider will be fulfilling their contractual
obligations by making this payment, which is why it is in cash and not by way of the Aspen card.

22. Both of the claimants are currently accommodated in hotels in areas of the country where Serco is the
accommodation provider. The full package of support provided by Serco in hotels consists of:

- 3 meals per day, including non-alcoholic beverages.

- A laundry service.

- Free wi-fi.

- Access to healthcare.

- Access to a phone which allows them to contact Migrant Help via a freephone number who provide
advice and support. …

- A cash allowance to enable the persons to buy essential items, such as hygiene and sanitary products.
They are free to spend money in the way they wish. Currently, £5 per week is provided to males and £10 to
females.”

66. The sub-contractor which provided the claimant's accommodation throughout the relevant period was
also Serco.

67. The Secretary of State also relies on a statement (adduced by the claimant) made by Rachel Smith, a
Project and Communications Coordinator at the Human Trafficking Foundation, dated 14 August 2020, in
which Ms Smith said:


-----

“Asylum seekers in catered section 98 accommodation do not receive any financial support and did not
prior to July 2020 when subsistence payments for asylum seekers who are also victims of trafficking were
discontinued.

On 26 June 2020 the HTF was alerted by a caseworker working in the asylum sector in the West Midlands
to problems with the payment of subsistence payments for asylum seekers who were also potential victims
of trafficking within the National Referral Mechanism (NRM) who were in catered section 98
accommodation. …

This caseworker advised that people in this situation were being provided with either only £5 (men) or £10
(women) weekly as a gift in kind or in lieu of financial support they would otherwise be receiving in section
95 support (currently £39.60 per week for a single adult). HTF has since gained clarity that this payment is
not given in all catered accommodation, but is seemingly paid on discretion of the accommodation
provider.”

68. In her first statement, dated 14 July 2020, made after she had been in the Hotel for about eight weeks,
the claimant stated that she “received £40.00 from the people at the Hotel” when she moved in on 13 May
2020 and, she had “not received any other money from them since then”. Reliance is also placed by the
Secretary of State on a statement from the claimant's Support Worker (which is unsigned and undated, for
reasons explained by the claimant's solicitor, but which was served with the claim on 15 July 2020), which
states:

“It is my understanding that [the claimant] was given a one-off payment of £40 by the Hotel within the first
two weeks. I am not sure who gave this to her and why. [The claimant] has not received any payments
from the Home Office under section 98. It is my understanding that they are not providing any cash
allowances to anyone in section 98 accommodation.”

69. In her third statement dated 20 October 2021 the claimant said, “I have received certain ad hoc
_payments, but I don't have a record of these”. In her fourth statement dated 2 February 2023, the claimant_
said:

“The asylum accommodation was a hotel. I was not entitled to any financial support under section 98
asylum support, so the only money I received at this time was my £35 of weekly trafficking support (as well
as a couple of one off payments, as I mentioned in my previous statements).” (Emphasis added.)

70. With her fifth statement dated 3 May 2023, the claimant adduced the Serco letter. This letter states:

“To whom it may concern,

**Withdrawal of weekly cash support**

This hotel contingency site has been giving service users £5 per week to purchase essential items that are
not provided by the hotel.

From week commencing 14[th] December, we will cease providing this weekly cash support for service
users. We will, instead, be providing service users with the essential items that they require. This change
will bring us in line with other contingency sites across the country.

The essential items that we are now providing includes:

- shower gel

- shampoo

- deodorant

- toothbrushes

- toothpaste

- razors

- sanitary towels


-----

Should you require any of these items, please speak to the on-site staff and they will arrange this for you.
Provision of these products will be monitored.”

71. The Serco letter is undated. As the claimant was in the Hotel from 13 May 2020 to 24 February 2021,
and I accept she was provided with a copy of this letter while she was there, the reference to the cessation
of cash support from 14 December must be a reference to 14 December 2020. This is also consistent with
the claimant's third statement in which she said:

“I would also like to highlight that the hotel began offering toiletries such as shampoo, shower gel, female
hygiene products and toothpaste in November 2020. We had to go down to the office to collect them. They
also started washing our clothes. Before this they only provided us with toilet tissue.”

72. In her fifth statement the claimant states that she is unsure whether she provided the Serco letter to
her former solicitors, and unable to check her messages due to a change of phone. Having provided it to
her current solicitors on 22 March 2023 in response to a request for information about her application for
s.95 support (which arose in light of Mr Smyth's evidence that her application was not determined until 1
December 2020), they raised questions with her as to whether she had received the payments referred to
in the Serco letter. The claimant states:

“On 26 April 2023, I responded to my solicitors by email to confirm that I did remember receiving cash
payments from the hotel, although I did not know what they were for. It seems these payments may not
have been clear from previous statements. I would like to clarify them.

After the initial £40 payment I received on arrival at the hotel, I remember receiving sporadic payments of
cash from the hotel. The hotel staff would tell us when payments were being made and to attend the
Reception to collect the payments. I do not remember when these started. Sometimes it would be £5 a
week, sometimes it would be £20 to cover four weeks. I was not told and did not understand what this was
for. I would use the money for buying food or topping up my phone.

Around the end of November 2020, the hotel started providing toiletries and doing our laundry following the
intervention of the Red Cross. After this, we stopped receiving any cash from the hotel.

The time in the hotel was very stressful for me and I did not always understand the different cash payments
I was receiving from trafficking support and the hotel: the payments being at different times and different
amounts and not being explained, the trafficking support stopping for a while in July 2020 and the amounts
varying during my time in the hotel. Everything was in cash and it was hard to keep track. My depression
also got worse during my time in the hotel, which made it hard to remember things. All I know that the little
money I did receive from the hotel and from trafficking support was never enough and I was constantly
stressed about not having basic essential items.”

F. The evidence regarding sufficiency of recovery and essential living needs support

73. The claimant received trafficking support of £35 per week throughout the period that she was living
with S, that is, from the end of February 2019 until 13 May 2020. The claimant's evidence is that during this
period she would use the money to travel to see her GP, attend the Wellbeing Centre (fortnightly) and to
buy sleeping tablets, toiletries and topping up her phone. Prior to the onset of the pandemic she also used
it to travel (fortnightly) to the reporting centre, which cost about £20 per month, and to travel to see her
counsellor, using a bus pass that cost about £20 per week. Initially her Support Worker had travelled to see
her weekly or fortnightly to provide her with the £35 per week payment in cash, but from around April/May
2020 the payments were pre-loaded onto a card, enabling the claimant to withdraw money at a cash point.

74. While she was in the Hotel, the claimant received trafficking support of £35 per week from 13 May
2020 until 17 November 2020 (although for a three-week period following the cessation decision she
received no trafficking support payments, but a back payment has been made). From 17 November 2020
until she left the Hotel on 24 February 2021, the claimant received trafficking support payments in the sum
of £25.40 per week.

75. The claimant also received non-financial trafficking support from her Support Worker who provided the
claimant with emotional support liaised with her legal representative and arranged counselling sessions


-----

The counselling sessions helped to some extent with the claimant's experience of flashbacks, nightmares
and difficulty sleeping but they stopped shortly after she moved to the Hotel. She had three sessions on the
phone before being told by her Support Worker that there was no further funding.

76. The Hotel provided the claimant with:

i) Accommodation;

ii) Three meals per day, including non-alcoholic beverages at meal times;

iii) Free wi-fi in the reception area for 20 minutes per day;

iv) From November 2020, a laundry service; and

v) From November 2020, toiletries, including sanitary pads.

vi) Until mid-December 2020, a cash allowance of £5 per week to enable her to buy essential items such
as toiletries: see paragraphs ý119 to ý120 below.

77. On 31 July 2020 the Independent Anti-Slavery Commissioner, Dame Sara Thornton, wrote to the
Minister for Safeguarding at the Home Office, Victoria Atkins MP, expressing her concerns about the
termination of trafficking payments for those in initial accommodation. She explained that:

“Whilst providing full-board emergency accommodation may meet a person's essential living needs, it does
not recognise their status as a potential victim of modern slavery. I am aware that there is an expectation
that any further essential needs, such as travel costs and toiletries are expected to be met by asylum
support, but I am concerned as to whether this is happening routinely in practice.

My office has been contacted by multiple organisations within the sector who have expressed significant
concerns regarding this recent change. I understand that some are having to provide supermarket
vouchers to survivors to enable them to meet their essential needs and I have been sighted on a case
where an individual has resorted to begging following their loss of financial support. This is not only
detrimental to their recovery, but also puts them at risk of further exploitation.”

78. The claimant has explained the effect of the cessation decision on her, albeit she was affected for only
three weeks because her representatives were able to obtain interim relief:

“On 6 July 2020, my weekly trafficking payments were suddenly stopped. I was therefore receiving no
financial support whatsoever. This was an incredibly difficult and stressful time for me. While £35 was not
enough, it was at least something. I did not have money on my phone so I could not call or even text. I
could not contact my support worker, which made me feel very anxious and isolated. I could not buy any of
my own food. I would sometimes be so hungry I could not sleep and I would have flashbacks to the time I
was trafficked. During this time, my depression worsened and I had to call the doctor, who increased my
depression medication and prescribed 9 days' worth of sleeping tablets. Having no money or freedom to
buy what I desperately needed made me feel like I lost all control over my life.”

79. During the period that the claimant received £35 per week trafficking support, her evidence is that she
used it to buy:

i) Sanitary pads and toiletries, such as toothpaste, lotion, oil for her hair, shampoo and shower gel: until
November 2020, the Hotel provided no toiletries other than toilet tissue. In her first statement the claimant
said she spent approximately £10 per month on toiletries and sanitary pads. In her second statement she
said that she spent about £4 per week on toiletries, but no longer needed to buy sanitary pads as the Hotel
had begun providing them. From late November 2020, the Hotel began providing toiletries.

ii) Meals and snacks: in her first statement the claimant said food cost her about £20-£30 per month. She
explained that although the Hotel provided three meals a day sometimes she could not eat what was on
the menu so she would order takeaway at a cost of about £6.50. She does not eat fish, having never liked
it from a young age, and the Hotel provided fish and chips or fish cakes for dinner about two or three times
per week. She asked the Hotel if she could have just the side dishes (e.g. a bowl of chips) without the fish,


-----

but they refused. The claimant said that the Hotel provided cereal in the morning and crisps, a banana or
chocolate in the afternoon, but she still felt hungry and so would “always top up on the food”.

iii) Drinks: the claimant said drinks, including water, cost her about £5 per week. She said that the Hotel
provided orange juice with a meal but she would get thirsty during the day. There was no kitchen sink from
which she could get water to drink. She said the Hotel told her to drink the water from the bathroom tap but
she could not do so as it triggered memories of having to do so while she was held in the brothel.

iv) Phone top up: the claimant said that she spent about £5 per week (or £20 per month) on topping up her
phone so that she could contact her friends and family. She acknowledged that the Hotel provided free wi-fi
in the reception area, but explained that it was only free for the first twenty minutes, after which time it cost
£7. In addition, she felt that she could not have a private conversation with her legal representative,
support worker or friends in the Hotel reception area; and there were Covid measures in place requiring
people to socially distance. There was a telephone in her room, but it could not be used to make outgoing
calls, only to call reception. There was a telephone at reception but on the one occasion when she had
asked to use it to call Migrant Help (a free call), as her phone had broken, the Hotel refused. In any event,
she did not feel comfortable discussing her experiences or how she was feeling using a phone located in a
reception area.

v) Travel: in her first statement the claimant said her bus fare to and from her friend's house was about
£15-20 per month. As meeting friends was an important part of her recovery, she had done so since the
easing of lockdown, to keep herself distracted and to focus on the positive side of things. In her second
and fourth statements the claimant said that travel to visit her friend and to see her GP cost about £10-15
per week. She also said her local church had referred her to a counselling service, with the first session
due to take place on 24 November 2020, and the return ticket would cost £7. In her fourth statement, the
claimant said the Hotel helped with some travel costs, paying for a taxi when she had had to report to the
Home Office and on an occasion when she had to go to hospital.

vi) _Clothes: the claimant said she could not afford clothes and had to make do with what she had. But_
when she had to buy new clothes, such as winter clothes or boots, she had to avoid spending money on
other purchases, such as not topping up her phone that week or not travelling to see friends. While she
was in the Hotel, she was provided with shoes and a dressing gown by the Red Cross.

vii) _Postage and photocopying: the claimant said sometimes she had to pay to make photocopies of_
documents and pay for postage, so that she could post documents to her legal representative as she did
not have an email address.

viii) _Medication: the claimant said she had to pay for medication, such as paracetamol and sleeping_
tablets. She also bought stress relief tablets costing £2 for a pack of 24 which lasted about eight days.

ix) Laundry products: the Hotel only began washing the claimant's clothes from November 2020. Before
then, she bought laundry products for about £3.50 and washed her clothes in the sink, hanging them
around the room to dry. This too reminded her of being trafficked.

80. The claimant said that when she was receiving £35 per week trafficking support it was “barely enough”
to meet her “essential living needs let alone to facilitate recovery”. In her fourth statement, the claimant
described the reduction of her trafficking support, on 17 November 2020, from £35 to £25.40:

“The previous amount was barely enough to survive on. To lose nearly £10 a week was really significant to
me, as it was nearly 1/3 of all the money I received each week. As I had less money, I had to speak to my
friends less, which was very hard as my friends are an important part of my recovery. I also could not
afford to buy any of my own food any more and went hungry whenever I could not eat the food provided by
the hotel.”

81. On 1 December 2020, the claimant was granted s.95 support. She became entitled to £8.24 per week
asylum support but this was not paid until January 2022, nearly a year after she had left the Hotel, when
she received it as a back-payment. Although there was a lengthy delay between the claimant's application
for s.95 support and the decision that she was eligible, in the context of this claim, no complaint has been


-----

raised that this delay was unlawful. It appears that her application was initially refused on 10 June 2020 for
failure to provide bank statements. The claimant appealed and on 23 June 2020 the decision was
withdrawn, and at the same time the Secretary of State sent a request for information to the claimant at the
Hotel. However, the claimant only responded after request for information was uploaded onto the Home
Office's MoveIT system on 11 November 2020. The Secretary of State received the claimant's response on
26 November 2020.

82. Mr Smyth has given evidence that the average time for determining whether an individual is entitled to
s.95 support, from the moment of grant of s.98 support has varied over the last few years (summarising his
evidence) as follows:

He states that despite a large increase in the volume of applications for s.95 support over the last three
years, “at any one time the total number of applications awaiting a decision is rarely more than a few days
_worth of intake”._

83. The claimant has adduced evidence from specialist organisations working with victims which address
the harm caused by the cessation decision and support the claimant's case that the financial support
provided by the Secretary of State fails to meet victims' essential living and recovery needs.

84. The statements of Rachel Smith of the Human Trafficking Foundation and Anna Sereni, of AntiSlavery International are primarily directed at addressing the impact of the cessation decision. Given that
decision is not defended, and arrears have been paid, it is unnecessary to describe that evidence.
However, in discussing the level of financial support given to victims, Ms Smith states:

“Although the £35 per week was less than what is stipulated in the SSHD's policy the amount helped to pay
for clothing, phone data, toiletries, etc. The Foundation is still concerned that the subsistence payments
simply amounted to the minimum sum needed to stave off destitution.”

**Time period** **Processing time**

5.69 days

November 2021 17.10 days

45.53 days

5 days

December 2022 8.99 days

9.79 days

85. Anti-Slavery International have provided a letter in support of this claim dated 2 October 2020. The
letter addresses the cessation decision and then describes the setting of the rate of £25.40 under the
Amended Guidance:

“We do not know how this rate was decided on or the methodology or assessment of needs used to arrive
at this amount. The MSSIG Victim Support Group [Modern Slavery Strategy and Implementation Group:
see paragraph ý143 below] was not consulted with regarding the rate. While we understand that this rate
applies to people in temporary catered accommodation we consider it too low. As this is initial
accommodation, it is likely that people will need to buy basics including clothes, toiletries, a phone and
data on top of ongoing expenditure. As above, it is our understanding that the subsistence payments
provided to people in the NRM and supported by the Victim Care Contract are to support recovery. This is
different to survival or meeting basic needs and should be enough to allow for recovery including
recreation, travel and entertainment.”

86. Clare Moseley, Director and Founder of Care 4 Calais, provided two statements. In her first she states
that “the facilities and items available to residents varies between hotels and locations” and that the
following items are not widely available: clothes and shoes; mobile phones; children's items, including
nappies and prams; sanitary products and toiletries; additional food particularly for children as there is a

|Time period|Processing time|
|---|---|
|March 2020|5.69 days|
|November 2021|17.10 days|
|February 2022|45.53 days|
|August 2022|5 days|
|December 2022|8.99 days|
|January 2023|9.79 days|


-----

lack of suitable food provided; and transportation. She states that “messages of extreme concern for the
_mental wellbeing of residents [in initial accommodation] are frequently received by volunteers. Messages_
_regularly display extreme hopelessness, suicidal thoughts, signs of depression and severe anxiety”. She_
concludes that “these asylum seekers are at risk of destitution, further exploitation for those that are also
_victims of trafficking and there are serious concerns that prolonged stay in these hotels without adequate_
_support will lead to a deterioration of their mental health.” In her second statement, Ms Moseley said that_
there had been some changes, such as a slight improvement in the food provided in initial accommodation,
the reduction in confiscation of asylum seekers' phones, and the provision of £8.24 per week to those in
receipt of s.95 support in initial accommodation, but she expressed the view that,

“the very limited financial support [does] not even begin to meet the essential needs of asylum-seekers in
initial accommodation”.

87. The Refugee Council reported in April 2021 that their staff were “extremely concerned about gaps in
_support for people, and have often had to step in to provide basics like shoes and coats and make sure_
_people receive the food they need”. The report stated that:_

“The majority of people living in hotels are accommodated on a 'full board' basis so have no access to
cash, making it impossible for them to buy or replace essential items. Refugee Council staff often receive
requests for items such [as] plasters, paracetamol, umbrellas, nail clippers, combs, pens and notebooks,
none of which can be considered luxuries but are not supplied to them…

People in hotels have limited access to the internet and many do not have mobile phones. This situation
has been made worse by the widespread confiscation of people's mobile phones by the Home Office in
arrival in the countries. This means many people have to rely on charities such as the Refugee Council
providing mobile handsets. Mobile phones are not a luxury item – they are needed to access vital
information, contact Migrant Help, advice agencies or connect with health services.”

88. In July 2022, the Refugee Council published an updating report which contains a number of specific
findings noting that those in initial accommodation lack access to clothing, essentials, appropriate and
nutritious food, as well as phones and the internet.

89. Farbey J's observation in _JM_ at [130] applies with equal force to the statements adduced by the
claimant in this case:

“These statements come from respected practitioners in the field of refugee care. They are doubtless the
product of intelligent observation over time and aim to assist the court. But I must tread carefully in the
weight to be attached to them.”

90. As in JM ([131]), these witnesses have not

“been put forward as giving expert evidence in accordance with CPR Pt 35; and the court's permission
would have been needed to do so (CPR r 35.4(1)). Their views are expressed in generalised language …
Their statements … amount to the sort of material that Popplewell J has called 'a partial body of relevant
evidence, in both senses of the word' (Refugee Action _[2014] EWHC 1033 (Admin) at [134]).”_

91. Mr Ryder states with respect to the £35 trafficking support rate for those in catered VCC
accommodation:

“I understand that responsibility for victim support policy was passed from the Ministry of Justice to the
Home Office in 2014. Based on discussions with my predecessor when I took up this role in May 2021, the
rationale behind the £35 rates under the previous VCC is not clear and we do not know what the policy
intention was at the time from contemporaneous documentation or corporate memory.”

92.  With respect to initial or full board asylum accommodation he states:

“It remains the position that individuals supported under s.98, including victims of modern slavery, and in
initial asylum accommodation generally have their needs met through in-kind support provided for by fullboard accommodation. In initial accommodation, provided under s.98, it is expected that support is
provided, consisting of food and drinks, which includes three meals a day, plus a food service for babies


-----

and small children, which is available whenever necessary. The food must include options which cater for
special dietary, cultural or religious requirements. Additional provisions include baby care equipment and
disposable nappies, plus personal toiletries and feminine hygiene products. All bills and any taxes are
covered by the Authority/Home Office/Provider. Providers also provide travel assistance, which may
include transport to attend appointments including doctor, dentist, hospital, birth or death registry
appointments. Some sites have Wi-Fi, broadband, and phones with Sim cards including data.

S.98 support is intended to be provided on a short-term basis. Those housed in initial accommodation
would generally not receive a cash Asylum Support payment from the Home Office for essential living
needs because either those needs would ordinarily not arise on a short-term basis, or they could
adequately be met by the full board basis of the accommodation. It is for the same reasons that it is
sufficient for the MSVCC to provide a payment of £24.15 to individuals supported by s.98 to assist their
social, psychological and physical recovery.”

93. Mr Ryder states that trafficking support is provided “to assist” victims with their social, psychological
and physical recovery from exploitation. As recovery needs vary widely, it would be very difficult, or nearly
impossible, for the Secretary of State to set a specific 'one-size fits all' trafficking support payment if she
were required to meet each victim's recovery needs, rather than assist in their recovery.

94. Mr Ryder states:

“Support and material assistance provided by the MSVCC to 'assist' victims in their recovery should be
viewed holistically as a package, rather than focussing on financial support as the sole means of assisting
a victim's social, psychological and physical recovery.”

He states that victims could apply with the assistance of their Support Workers, via a purchase order, for
the cost of wider travel needs related to their modern slavery experiences to be met through the VCC. In
March 2022, the Home Office updated the statutory guidance, setting out in detail what additional recovery
costs victims, including those receiving asylum support, can claim through the MSVCC, and the procedure
for doing so.

95. With respect to the reduction in trafficking support from £35 to £25.40, Mr Ryder states that claimants
had been receiving £35 “due to an unintended anomaly in the previous VCC”. The change

“brought the claimants in line with how other victims who were receiving Asylum Support, but who were not
in catered asylum accommodation, were already being treated by the VCC financial support policy. This
payment of £25.40, when combined with what the claimants would have already been receiving through
Asylum Support (through payments or in-kind assistance, or both), ensured that they were receiving the
same overall amount as a victim receiving £65 a week from the VCC and i) that their essential living needs
were being met (by Asylum Support) and ii) that they were being assisted with their social, psychological
and physical recovery from their modern slavery experience (through their £25.40 VCC payment).

The claimants were able to use this recovery related financial support payment (£25.40) towards assisting
their recovery as they saw fit, and alongside the additional recovery costs assistance … available to all
victims. A reduction in the recovery payment does not in and of itself mean it becomes insufficient in
_assisting victims towards their recovery, particularly when considered holistically alongside the wide range_
of other material assistance and additional recovery costs support the SSHD makes available to all victims
of modern slavery to assist their recovery through the MSVCC, which since March 2022, has been set out
clearly in published Statutory Guidance (originally published in version 2.8).”

96. Mr Ryder has provided evidence that on 12 November 2021, Ministers agreed to begin engagement
with the Salvation Army to implement a new financial support policy pursuant to which there will be two
rates:

i) An “Essential Living Rate” which will be the same as the rate of Asylum Support for those in dispersal
accommodation (currently £45). This rate will be adjusted where the victim is staying in catered
accommodation.


-----

ii) A “Recovery Rate” or ('RR') “specifically for the purpose of assisting victims in their social, psychological
and physical recovery”.

97. Mr Ryder states:

“The RR has been determined through Home Office market research into the cost of different items and
services that may be needed by victims of **_modern slavery to assist their recovery. These services and_**
items were identified through the stakeholder engagement process I outline in my 1[st] WS …, namely
through a call for evidence sent to over 1,000 key **_Modern Slavery stakeholders on 18 June 2020, with_**
responses correlated on or around 17 August 2020, with follow up workshops and engagement.

Using the market research, we have identified a reasonable and rational RR to assist with victim's
recovery, which is to be used alongside the direct funding of additional recovery costs available through the
MSVCC…

To give a robust indication of the cost of these items and services which make up the RR (travel,
communication, distraction activities such as health and fitness, or wellness classes and a miscellaneous
amount), across England and Wales, we assessed the costs of items and services in each area where
there is currently MSVCC safehouse accommodation. For example, with respect to transport, the amount
was reached by considering the average price of the maximum day ticket price identified in each
safehouse location. In areas where two or more providers were identified and where locations offered a
localised and wider area day ticket, the highest ticket price was used to calculate the average cost across
the safehouse locations. This methodology was quality assured and approved by the Home Office Analysis
and Insight.

We reviewed the evidence base underpinning the RR in April 2022 and then again in October 2022
considering inflation rises in the UK. On 30 November 2022, Ministers agreed that the RR should be set at
£26.14 per week and reviewed annually and amended if necessary to coincide with the annual review of
the Asylum Support rate...”

98. Mr Ryder explains that the new Recovery Rate is based on the following breakdown, although it is a
matter for any victim how they choose to spend this trafficking support:

**Recovery item/service** **Amount**

Travel £5.64

Communication £3.00

Health/Fitness/Wellness £7.50

Miscellaneous £10.00

**Total** **£26.14**

G. Ground 1: Correct Construction of paragraph 15.37 of the Policy

**_The issues_**

99. The agreed issues in respect of Ground 1 are:

“Whether the Defendant unlawfully failed to make payments of £65 per week to the Claimant (and those in
like situation to her) as a victim of trafficking supported under s.98 Immigration and Asylum Act 1999
[pursuant to the Modern Slavery Act 2015 – Statutory Guidance for England and Wales (as in force until](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
28 August 2020) ('the Guidance')?

a. Did PM receive 'financial support' pursuant to s.98 IAA 1999 and/or was she in a position provided for
under paragraph 15.37?

b. If so, was she entitled to receive £65 per week pursuant to §15.37 of the Guidance (minus the amount of
financial support received pursuant to s 98 IAA 1999) for the period 13 May 2020 [to] 28 August 2020?”

|Recovery item/service|Amount|
|---|---|
|Travel|£5.64|
|Communication|£3.00|
|Health/Fitness/Wellness|£7.50|
|Miscellaneous|£10.00|
|Total|£26.14|


-----

100. In relation to the claimant personally, the question is whether she was entitled to payments of £65 per
week from 13 May 2020 to 27 August 2020, rather than the lesser payments of £35 per week which she
received.

**_The parties' submissions_**

101. The claimant submits the interpretation of §15.37 of the Guidance adopted by the Court of Appeal in
_JB (Ghana) is binding. That case raised a substantially similar question and largely answers the issue of_
interpretation raised by Ground 1. The facts of JB's case were strikingly similar to the claimant's case; the
only point of distinction being that JB was granted s.95 support much more quickly than the claimant.
Paragraph 15.37 of the Guidance expressly refers, in undifferentiated terms, to financial support provided
pursuant not only to s.95 but also s.98 (and s.4) of the IAA.

102. The evidence demonstrates that the claimant received cash payments from the accommodation
provider which payments must have been made to provide for the claimant's essential living needs
pursuant to s.98 of the IAA. Indeed, the Secretary of State expressly pleaded in her Amended DGDs that
on admission to the Hotel, the claimant “received a one-off payment of £40.00 [provided] by her
_accommodation provider”. The claimant submits the only sensible inference is that the payment was made_
as part of the support package. The Serco letter provides further proof that the claimant was provided with
financial support pursuant to s.98. In the circumstances, the claimant submits that her case falls squarely
within §15.37 as interpreted by the Court of Appeal.

103. The Secretary of State accepts that, in accordance with _JB (Ghana), if the claimant had been_
accommodated in the Hotel pursuant s.95 of the IAA during this period, she would have been entitled to
£65 per week. The only deductions that the Secretary of State would be permitted to make from the weekly
figure of £65 would be to reflect any financial payments of asylum support received (and not support
provided in kind by way of full board accommodation). However, the claimant was supported throughout
the relevant period under s.98, not s.95. The Secretary of State contends the entitlement to £65 per week
referred to in §15.37 of the Guidance did not apply to her. In support of this submission the Secretary of
State contends, first, that the claimant was not in “accommodation” as defined in §15.36 and therefore
§15.37 does not apply; secondly, the claimant did not receive financial support paid pursuant to s.98.

104. The first of the Secretary of State's two arguments runs as follows:

i) There is no express provision in the VCC for any payment by the Salvation Army to victims supported in
full board accommodation under s.98. This is because the third entry in the table at F-001 (paragraph ý52
above) addresses the position of victims accommodated by the Secretary of State “and in receipt of
_subsistence payments through that service”. There is no entry in the table to address the position of those_
accommodated by, but not receiving subsistence payments from, the Secretary of State.

ii) The reference to “payment rates” in §15.37 of the Guidance must be a reference to the rates referred to
in §15.36.

iii) Paragraph 15.36 does not stipulate the rate of financial support payable to those supported under s.98
of the IAA. The claimant was not in any of the types of accommodation identified in the first three bullet
points in §15.36 of the Guidance.

iv) Paragraph 15.37 is concerned with adjusting the payment rates of those who are identified as eligible
under §15.36. It follows from (iii) that §15.37 does not apply to those such as the claimant who were
supported in full board accommodation under s.98 of the IAA.

v) The Secretary of State contends that in JB (Ghana) at [35] the Court of Appeal has misread paragraph
2 of the FAQs document (see paragraphs ý57-ý58 above), as the capitalised term “Catered
Accommodation” was a reference to VCC catered.

vi) In circumstances where the Guidance made no provision for trafficking support payments to be made
to victims in full board accommodation provided pursuant to s.98 of the IAA, the Secretary of State
reasonably exercised her discretion to make payments of £35 per week, on a par with the provision for
i ti i t d VCC d ti


-----

105. The claimant submits that the Secretary of State should not be permitted to pursue the argument that
§15.37 of the Guidance needs to be construed by reference to the categories of individuals identified in
§15.36 of the Guidance, as it has not been pleaded even in the Amended DGDs served on 29 December
2022. It was first raised in the Secretary of State's skeleton argument. In any event, the claimant contends
that it is a bad point, essentially for the reasons with which I agree and explain in my analysis below.

106. The second basis on which the Secretary of State contested Ground 1 concerns the characterisation
of “ad hoc” cash payments made by the accommodation provider. The Secretary of State submits such
payments may have been discretionary, rather than contractual. For example, the accommodation provider
could have chosen to provide a “welcome package” in the exercise of its discretion rather than to fulfil its
contractual obligation to provide for service users essential needs.

107. But even if they were provided pursuant to the accommodation provider's contractual obligations,
such _ad hoc payments are not “financial support” provided by the Secretary of State. As Sir Duncan_
Ouseley observed in MK v Secretary of State for the Home Department [2020] EWHC 3217 (Admin) at [2]:

“… the Home Office does not pay, and has not paid, a cash allowance to those living in full-board
accommodation. A cash allowance may be paid by the accommodation provider, pursuant to its contract
with the Secretary of State, but it is not the Secretary of State who makes those payments.”

Consequently, such ad hoc payments cannot properly be regarded as “financial support” provided pursuant
to s.98 of the IAA.

108. On the basis of the claimant's first witness statement in which she said she received a single cash
payment of £40 on entering the Hotel, the Secretary of State submits that even if such a payment
constitutes “financial support” within the meaning of §15.37 of the Guidance, it would only result in an
adjustment for the single week when the claimant received that payment.

109. The claimant submits that the Secretary of State's submissions merely repeat arguments that were
made unsuccessfully in _JG (Ghana); and it is plain and obvious that cash payments made by the_
accommodation provider were made with a view to fulfilling the Secretary of State's obligation under s.98 to
provide for essential living needs that were not being met in kind.

**_Analysis and decision_**

110. The approach to be taken to the interpretation of the Guidance is that described by Bean LJ in JB
_(Ghana) at [67]-[68] (quoted in paragraph ý60 above), and taken by the Court of Appeal in construing the_
very same paragraphs of the Guidance that are in issue in this claim.

111. The first of the Secretary of State's bases for resisting Ground 1 was not pleaded. Although there is
considerable force in the claimant's objection to it being raised so late, it is a point of interpretation of the
Guidance which has been fully argued. The court inevitably has to consider §15.37 of the Guidance in
context and so, in circumstances where there is no prejudice to the claimant, I do not consider that the
Secretary of State should be precluded from placing reliance on §15.36 of the Guidance.

112. However, I agree with the claimant that the point is unsustainable. First, the argument that the
claimant was not in a type of accommodation identified in §15.36, and so §15.37 did not apply, would have
applied – if it were a good point – to the claimant in JB (Ghana). Victims such as JB who remained in 'initial
accommodation', although they had been assessed as eligible for s.95 support, were in precisely the same
type of full-board asylum accommodation as victims such as the claimant who were accommodated
pursuant to s.98 of the IAA. The argument is inconsistent with JB (Ghana) and with the Secretary of State's
pleaded concession that the claimant and LT were entitled to £65 per week in respect of any period prior to
the publication of the Amended Guidance during which they were supported pursuant to s.95 of the IAA.

113. Secondly, the types of accommodation identified in §15.36 and the opening words of §15.37 stating
that the “payment rates will be adjusted” have not been altered in the Amended Guidance, and yet it is
acknowledged that §15.37 of the Amended Guidance made provision for victims in full-board
accommodation, whether supported pursuant to ss.95, 98 or 4, to receive trafficking support payments in
th f £25 40 k


-----

114. Thirdly, in JB (Ghana) – by which I am, of course, bound - the Court of Appeal considered §15.36
when interpreting §15.37, and rejected essentially the same submissions as are now pursued before me:

i) Leading Counsel for the Secretary of State in JB (Ghana), Ms Giovanetti KC, submitted that the correct
interpretation of the Guidance turned on “the nature of the accommodation provided”: JB (Ghana), [42].

ii) Ms Giovanetti made the same submission that the VCC does not address payments to be made to
victims in full-board asylum accommodation: JB (Ghana), [45].

iii) She also submitted, by reference to both §15.36 and §15.37, that the Guidance does not address
payments to be made to “the cohort of Potential Victims in full board asylum accommodation”: JB (Ghana),

[43], [45] and [48].

iv) The point that the _question in the FAQs document, question 2, concerned “those in VCC_
_accommodation” was also made to the Court of Appeal: JB (Ghana), [50]._

115. The Court of Appeal agreed with Mr Marquand that there was “no lacuna” in the Guidance (JB, [29];
_JB (Ghana), [36] and [64]). The Court of Appeal also agreed with Mr Marquand that there was “no_
_ambiguity” (JB, [29], JB (Ghana), [36] and [64]), Bean LJ observing that the judge's construction of §15.37 -_
the “categorical terms” of which were identified at [64], and clearly apt to cover those receiving financial
support pursuant s.98, as well as s.95 (see paragraph ý107 above) - was consistent with the terms of the
VCC and the answer given to question 2 in the FAQs document ([71]).

116. In my judgment, even taking these reasons alone, the Secretary of State's first basis for contesting
Ground 1 inevitably fails. Moreover, fourthly, in _K & AM Mostyn J had criticised the Secretary of State's_
failure to comply with the statutory duty under s.49(1) of the Modern Slavery Act 2015 to issue guidance:
_K, [4]-[8]. The Guidance was subsequently published to fulfil that duty, and in circumstances where Mostyn_
J had made the determination as to the meaning of “subsistence” in the context of ECAT and the Directive
to which I have referred, and his decision was not appealed (paragraphs ý47-ý48 above). The Guidance
reflected Mostyn J's conclusion in stating unequivocally at §15.35 that:

“Potential victims and victims of **_modern slavery who have entered the NRM, received a positive_**
Reasonable Grounds decision and are in VCC accommodation or outreach support, will be paid financial
support.”

117. The claimant was “in outreach support”, and being provided with such support throughout the
relevant period by, and through, her “Outreach Support Worker”. The term “outreach support” was defined
in §15.30 of the Guidance. Mr Ryder confirmed in his evidence that where “a potential or confirmed victim
_is not accommodated in MSVCC accommodation, they will receive outreach support” within the meaning of_
§15.30 of the Guidance.

118. The Guidance clearly and unambiguously specifies that, among others, victims in outreach support
will receive financial support (§15.35). In §15.36, having said that the rate of financial support depends on
the accommodation the victim is in, the Guidance gives differing rates for those in VCC accommodation,
depending on whether it is self-catered (£65) or catered (£35) and then provides the rate of:

“£39.60 per week for those receiving outreach support in other accommodation”.

119. The Secretary of State has merely asserted that the claimant was not in any of the types of
accommodation specified in §15.36 of the Guidance. On the face of it, the term “other accommodation”
refers to accommodation other than VCC accommodation. The starting point was that those such as the
claimant who were not in VCC accommodation and who were receiving outreach support were entitled to a
trafficking support payment of £39.60 per week. But that entitlement was adjusted by §15.37 for “potential
_victims who are also receiving asylum support”._

120. Even if this last point were wrong, the Court of Appeal held that if consideration of the payment due to
JB ended with §15.36, he would not have been entitled to £65 per week (JB (Ghana, [64]); and the same is
true of the claimant. But “the matter did not end there” because §15.37 – which I note appears under a new
heading (“Financial support for potential victims who are also receiving asylum support”):


-----

“states in categorical terms that if a potential victim of trafficking is also an asylum seeker and receiving
asylum support, a further payment is to be made to him to make a total (including the asylum support) of
£65 per week.”

121. Given that §15.37 expressly refers to ss.95, 98 and 4, without differentiation, that conclusion applies
with as much force to those who were supported pursuant to s.98 as it does to those supported pursuant to
s.95, leaving only the question whether the claimant was receiving “financial support” pursuant to s.98 of
the IAA.

122. In light of the evidence to which I have referred above, it is clear that providers of initial
accommodation were contractually required to provide for the essential living needs of asylum seekers,
whether they were supported under s.95 or s.98, and that they could do so by making provision in kind, in
cash or through a combination of both. It is also evident that throughout the period from 13 May 2020 until
14 December 2020, Serco adopted the approach of making provision through a combination of in kind and
cash support.

123. Even without the Serco letter, I would have inferred that the £40 paid to the claimant on entering the
Hotel was not a payment made by Serco as a matter of discretion but that it represented a payment, in
respect of several weeks, to meet those of the claimant's essential living needs that were not met in kind at
the Hotel. I would also have found, in light of the claimant's third and fourth statements, that she received
more than one such payment (albeit the amount and timing of any further such payments was opaque). I
acknowledge that Ms Smith's understanding was that such payments were at the discretion of the provider,
and the claimant herself referred to them as _ad hoc, but it is inherently unlikely that Serco would have_
made payments to asylum seekers that it did not consider itself contractually obliged to make in order to
meet their essential living needs.

124. I note that Mr Bentley's evidence and Ms Smith's evidence both referred to Serco making payments
of £5 to men and £10 to women. This is consistent with the evidence before Farbey J in JM that “Serco
_hotels provided … a cash allowance of £5 for men and £10 for women”. The Serco letter that the claimant_
received and has adduced gives the figure of £5, rather than £10, per week. It is addressed “[t]o whom it
_may concern” and so may not have given the accurate figure for women in the Hotel. But the claimant's_
most recent evidence is that she was paid £5 per week by the Hotel, either in the form of £20 payments
representing £5 per week for four weeks or in the form of £5 for a single week. I do not regard her
recollection in this regard as entirely reliable: she acknowledged in her third statement, which was made
much closer to the time than her fifth statement, that she found it difficult to remember what she had
received. So it is possible that she may in fact have received £10 per week from the Hotel. However, the
rate of £5 per week is consistent with the claimant's contemporaneous evidence in her first statement that
at that point, eight weeks after she had entered the Hotel, she had received only one payment of £40
(which would have represented eight weeks' worth of payments at £5 per week). Accordingly, I conclude
that she received £5 per week from the Hotel in cash. Those cash payments were stopped with effect from
14 December 2020.

125. The cash payments were not “one-off” or “ad hoc”, although it is understandable that they were
perceived by some, including the claimant, as ad hoc, given the variation in the number of weeks paid at
any one time, and the lack of explanation as to their purpose.

126. It is true that these cash payments were provided by Serco and not by the Secretary of State. But in
my judgment the Secretary of State's submission that these payments were not paid pursuant to s.98 of
the IAA is misconceived. The Secretary of State's statutory duty was to provide for the claimant's “essential
_living needs”. As Mr Payne KC accepted, that duty is non-delegable, albeit the Secretary of State can, as_
she did, discharge it through contractors and sub-contractors.

127. The Secretary of State's reliance on the fact that the cash payments were not made directly by the
Home Office, in support of the submission that the claimant did not receive “financial support under
_sections 95, 98 or section 4” (§15.37), appears, in effect, to be a veiled attempt to resurrect the contention_
that “financial support” in §15.37 refers to those in receipt of a payment pursuant to regulation 10(2) and
not to those whose essential living needs were met in full board accommodation through a combination of


-----

in-kind and cash support: see JB, [20] and [25]. That submission was rejected by the High Court (JB, [20])
and not pursued before the Court of Appeal (JB (Ghana), [58]). In any event, it is plain that the Court of
Appeal accepted that the receipt of “very modest cash payments towards essential living needs” amounted
to the receipt of “financial support” within the meaning of §15.37 of the Guidance (JB (Ghana), [66]). There
is no proper basis on which the modest cash payments towards essential living needs which the claimant
received from the Hotel can be distinguished from the modest cash payments towards essential living
needs which JB should have received (albeit in fact he did not).

128. Given the terms of §15.37, the same type of payment, provided for the same purpose, to asylum
seekers housed in the same type of accommodation cannot be “financial support” if provided under s.95
(as the Court of Appeal held it was) and yet not “financial support” if provided under s.98. Indeed, the
Secretary of State does not go so far as to contend for such a distinction. Her argument is that the cash
payments the claimant received were not provided under s.98, but for the reasons I have given I reject that
contention.

129. I accept that this interpretation creates the anomaly that a victim in initial support who received their
asylum support entirely in kind would have been entitled to £39.60 per week trafficking support, whereas a
victim in initial support who received (or was entitled to receive) their asylum support through a
combination of in kind and financial support would be entitled to £65 per week (less the value of the
financial support). But the type of asylum financial support the claimant received from the Hotel is
indistinguishable from that received by JB, so the analysis in JB (Ghana) clearly applies.

130. Accordingly, the claimant succeeds on Ground 1. I conclude that during the period 13 May 2020 to 27
August 2020 the Secretary of State unlawfully failed to make payments of £65 per week to the claimant, as
a victim of **_modern slavery supported under s.98 of the IAA, pursuant to the Guidance. The claimant_**
received £35 per week (recovery support payment) and £5 per week (cash payment towards essential
living needs) during that period, and so she was underpaid £25 per week.

H. Ground 2: Lawfulness of the reduction in the level of financial trafficking support

**_The issues_**

131. The agreed issues in respect of Ground 2 are:

“Whether the Defendant's Amended Guidance published on 28 August 2020 for those in the Claimant's
position (VOTs receiving support under s.98 IAA 1999) was unlawful. In particular:

a. Whether the Defendant was obliged to consult before implementing the Amended Guidance and, if so,
whether there was adequate consultation and/or enquiry;

b. Whether the level of financial support under the Amended Guidance unlawfully failed to meet victims'
recovery needs consistent with the Defendant's obligations under ECAT and the EU Directive; and/or

c. Whether the Amended Guidance unlawfully discriminated contrary to Article 4 and 14 ECHR against
victims of trafficking in initial accommodation by providing them with less financial support than to other
victims.”

**_The evidence regarding the introduction of the Amended Guidance_**

132. On 4 August 2020, officials in the Home Office's Modern Slavery Unit put a written submission to the
Secretary of State ('the Ministerial Submission') which stated:

“Issue

The provision of interim financial support for the cohort of potential and confirmed modern slavery victims
who are housed in 'initial accommodation' provided through asylum support (generally full-board
accommodation), and the provision of back payments.

**Timing**


-----

**Immediate – We are being legally challenged as a result of the absence of a policy position on financial**
support for this cohort of **_modern slavery victims. In addition, we are receiving critical media and_**
stakeholder interest, including correspondence from the Independent Anti-Slavery Commissioner, on our
current position. An early response would enable The Salvation Army to implement proposed changes as
soon as possible [REDACTION].

**Recommendation**

That you:

- Agree to introducing an interim weekly payment of £25.40 for potential and confirmed victims of modern
**_slavery who are initial accommodation until the new wider financial support policy is introduced._**

- **Agree that changes should be implemented as a matter of urgency through a contract change notice**
[with The Salvation Army, an update to the Modern Slavery Act 2015: Statutory Guidance for England and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
Wales and an announcement through the Modern Slavery newsletter to stakeholders.

- [REDACTION]

- Agreeas per our legal obligation that in principle, any potential or confirmed victims of modern slavery
who were in initial asylum accommodation and who did not receive appropriate financial support from the
VCC up until the date when the interim policy is implemented, should be granted back payments at a rate
of £35 per week. …

**Equality Duty: Has a Policy Equality Statement been completed? Yes**

…

**_Discussion_**

1. The case of K & AM v SSHD [2018] considered whether the cessation of additional payments to
**potential and confirmed victims of** **_modern slavery who were in receipt of asylum support, was_**
**unlawful. The judgment in this case held that the Victim Care Contract (VCC) did not intend for**
potential/confirmed victims of modern slavery who are also supported under s95 Asylum and Immigration
Act 1999 accommodation to only receive payments through the asylum support system and that the
reduction in support was unlawful. As a result of the judgment, those in s95 asylum support continue to
receive a total financial assistance package of £65 per week; this is currently made up of payments from
the asylum support system (£39.60) and the VCC (£25.40). The £39.60 payment is framed as a way of
meeting ordinary 'essential living needs', whilst the £25.40 covers other needs related to recovery from
exploitation.

2. **However, there is currently a gap in the VCC in relation to financial support for the cohort of**
**potential** **_modern slavery victims who are receiving asylum support in the form of 'initial_**
**accommodation'. [REDACTION]**

3. [REDACTION]

4. The new financial support policy that you (Minister Atkins and Home Secretary) agreed in March
**this year, will ultimately address this gap by ensuring this group are entitled to apply for**
**individualised financial support to meet their recovery need. Whilst other aspects of the policy can be,**
and have been, brought in sooner, the process to apply for individualised financial support for recovery
from exploitation requires careful planning and implementation, including face-to-face conversations
between service users and support workers, and the introduction of a new case-working process and team.
Transition to the new policy is planning for winter as part of the operationalisation of the new **_Modern_**
**_Slavery Victim Care Contract._**

5. **Initial accommodation is a form of temporary support within the asylum system. It is generally**
provided as full-board, with food and toiletries provided on-site in-kind, but in some instances the persons
receive vouchers to buy their own toiletries or food (in cases where cooking facilities are available in the
accommodation). In normal times, this form of accommodation is used to house asylum seekers under the


-----

provisions of section 28 of the Immigration and Asylum Act 1999 while consideration is given to whether
they qualify for support under section 95 of the 1999 Act (i.e. they are destitute as claimed). If the section
95 application is granted the person is moved to 'dispersal accommodation' (generally flats and houses)
and starts to receive the £39.60 per week standard asylum support payment and the £25.40 top up, from
the VCC, if they are also a potential or confirmed victim of **_modern slavery. It should be noted that the_**
level of the weekly asylum cash allowance for those in s95 support is reviewed annually, using a
methodology developed in 2014 which has been accepted by the Court of Appeal as rational and lawful.

6. Due to pressures created by COVID-19, the asylum estate is at full capacity, and nearly all new
**asylum seekers entering asylum support are being placed in initial accommodation or more**
**commonly hotels, with no cash payments, including those who have been approved for section 95**
**support. …**

7. **It follows that the pressure on the asylum accommodation estate has impacted the VCC. More**
victims of modern slavery than would ordinarily be affected by this gap in policy and contractual provision
may now be disadvantaged by it, making the case for change even more pressing. The increased numbers
in emergency hotels/hostels with no cash payments has highlighted the inconsistency in the VCC financial
support for this cohort, and there has been a significant increase in interest/pressure from stakeholders.
We have not received seven pre-action protocol letters and three judicial review claims on this issue.

[REDACTION], that the SSHD is obliged to make payments, reflecting her enhanced obligations under the
Trafficking Directive, not only to those potential and confirmed victims in dispersal accommodation but also
to those in initial accommodation.

8. **Given timeframes, [REDACTION]** **and increased pressure from stakeholders we consider it**
**necessary to make an immediate change to the VCC to provide cash payments to**
**potential/confirmed victims of** **_modern slavery whilst they are in initial accommodation. This_**
immediate change will only be in place until the wider changes to financial support are rolled out later in the
year. The following options have been considered for this interim approach.

**_Option 1_**

9. Option 1 would be to provide these individuals with a cash payment of £35 per week in line with
**the current VCC rate for service users accommodated in catered VCC accommodation.**

[REDACTION]

10. **However, most other victims in the asylum support system are in dispersal accommodation**
**only and receive £25.40 from the VCC to cover recovery needs (in addition to £39.60 from the**
**asylum support system, bringing their total weekly payment to £65). The difference between the**
proposed £35 and £25.40 paid to other victims could therefore be construed as an acknowledgment that
the package of support provided in full-board facilities does not fully meet the 'essential living needs' test.

[REDACTION]

11. We do not recommend this option as it would have the effect of providing potential/confirmed victims of
**_modern slavery in initial accommodation a higher level of support than those in dispersal accommodation,_**

[REDACTION].

**_Option 2_**

12. Option 2 would be to treat this group the same as other asylum seekers who receive a 'top up'
**of £25.40 from the VCC. This approach would make an assumption that the package from initial**
accommodation (made up of full or partial in-kind) accommodation is equivalent in value to £39.60 in cash
payments and is therefore enough to meet the individuals' basic essential living needs, whilst leaving
£25.40 to cover other recovery related needs. It is important to maintain that full-board accommodation is
considered sufficient to meet the essential living needs of individuals for a temporary period, and that some
items covered essential for those in dispersal accommodation (e.g. needs related to keeping the
accommodation clean) don't apply to those in full-board accommodation. As stated in paragraph 5, some
forms of initial accommodation are not full-board in all respects, as food vouchers are provided to purchase
food However the value of the package of support provided is intended to be the same regardless of how


-----

it is provided. This option would also align this group with other asylum seekers who are also
potential/confirmed victims and supported through the VCC. The £25.40 payment would continue to be
paid regardless of whether the essential living needs element continued to be provided fully or only partially
in-kind (if the Minister for Immigration Compliance and the Courts and Home Secretary Agree the proposal
to provide some of it in cash after the 35 days period).

13. [REDACTION]

14. [REDACTION] It should be noted however, that there are currently only c.28 individuals in VCC catered
accommodation – and that this accommodation is provided where an individual is unable to provide food
for themselves, e.g. due to disability, or substance addition. The two groups are not therefore in reality the
same. In addition, VCC catered accommodation only provides food and some household cleaning, and
therefore does not necessarily provide the same level of in-kind support as initial accommodation.

**_Option 3_**

15. **Option 3 would be to do nothing. This is not recommended for the reasons set out in this**
**advice.**

**_Recommendations_**

16. Option 2 (top up rate of £25.40) remains the recommended [REDACTION] Current estimates are
there are approximately 8,000 individuals in asylum full-board accommodation. Given how data on the
NRM and asylum support systems are collated and stored, we do not have an accurate record of how
many victims of **_modern slavery are in asylum full-board accommodation, however, we have_**
approximately 2,360 potential/confirmed victims of **_modern slavery who are supported by the asylum_**
support system. For the avoidance of doubt, this top up payment would only be paid to potential/confirmed
victims of modern slavery for the duration of their residency in full-board accommodation.

**Do you agree that we should proceed with Option 2: Providing a weekly payment of £25.40 for**
**potential/confirmed victims of** **_modern slavery who are in initial accommodation in line with our_**
**international legal obligations following the judgment in K & AM, as an intermediate temporary**
**approach ahead of wider financial support changes?**

…”

(Underlining added (save in §8), bold in the original. All references to redactions are to information
removed by the defendant on the grounds it benefits from legal professional privilege.)

133. The recommendation was accepted and, as I have said, the Amended Guidance which reflected it
was published on 28 August 2020.

134. The evidence given by Mr Ryder in his first statement was that:

“it is not currently, nor at any time has it been the case that asylum-seeker potential or confirmed victims of
trafficking accommodated in full board/fully catered asylum accommodation would receive £65 per week in
**_modern slavery financial support payments._**

Ahead of the policy change it is my understanding that asylum seeking potential victims not accommodated
by the VCC and not in dispersal accommodation under asylum support, were paid a single payment of £35
per week from the VCC as per section 6 of Schedule 2 of the previous VCC.”

The first sentence quoted above is now subject to the caveat that following JB (Ghana) the Secretary of
State has paid arrears to bring the rate up to £65 per week for victims who were supported pursuant to
s.95 of the IAA in initial accommodation before 28 August 2020. But I accept that when the Amended
Guidance was brought in, irrespective of the terms of the Guidance, there was not in fact any history of any
victims in such accommodation receiving trafficking support of £65 per week.

135. Mr Ryder also said in his first statement:


-----

“It is my understanding that … the amendment to the [Guidance], formulated in August 2020, was intended
to be an interim amendment formulated on an urgent basis in response to the judgment of Mostyn J, and
head of wider financial support policy reform, including stakeholder engagement.”

136. I accept that the Amended Guidance was introduced on an interim basis in circumstances where a
full review was under way. But it is obviously wrong to suggest that any urgency was as a result of the
need to respond to Mostyn J's judgment in K & AM. That had been handed down on 8 November 2018,
more than 21 months before the Amended Guidance was published.

137. As I have said, on 6 July 2020, the Secretary of State made the cessation decision by which she
stopped all trafficking support payments to victims who were asylum seekers in initial accommodation. In
response to my question whether the Secretary of State accepts the cessation decision was unlawful Mr
Payne KC stated that his instructions were not to oppose the challenge on that issue.

138. The cessation decision was unlawful and, given the clear effect of K & AM, which the Secretary of
State had chosen not to appeal, absolutely indefensible. Although arrears calculated by reference to the
£35 per week rate that was in fact being paid prior to the cessation decision have been paid, it is
nonetheless important to recognise not only that the cessation decision was unlawful but also how clear
and obvious that was when the Amended Guidance was under consideration. When the Amended
Guidance was introduced, victims in initial accommodation were _in fact receiving no trafficking support_
(unless, as in the claimant's case, they had secured interim relief from the court). But the only reason they
were not still receiving £35 per week was due to the patently unlawful decision that had been made seven
weeks earlier.

139. The immediate urgency in August 2020 was to remedy the situation created by the unlawful
cessation decision; not to respond to a judgment given in 2018.

140. The Secretary of State acknowledges in her grounds and evidence that there was no consultation
prior to publication of the Amended Guidance. In her summary grounds, in response to a request for
documents “relating to any consultation undertaken with stakeholders, and relating to the Equality Act prior
_to taking the decision”, the Secretary of State responded:_

[“No such consultation took place, nor was there an Equality Act 2010 assessment. The direction [i.e. the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
Amended Guidance] was considered to be a clarification of the contractual position.”

141. Mr Ryder explained in his second statement:

“23. In August 2020, the Home Office published updated Statutory Guidance clarifying that potential and
confirmed victims of modern slavery, who were also receiving Asylum Support, whether in the form of a
subsistence payment, or in kind through virtue of being accommodated in catered accommodation, or a
combination of both, should receive £25.40 per week from the VCC. This was an update to clarify the
existing interplay between VCC support and Asylum Support, to ensure that different parts of the Home
Office were not duplicating support provision.

I understand that the claimants had previously been receiving £35 a week due to an unintended anomaly in
the previous VCC, which from a Home Office perspective at the time, was not the correct VCC rate for
them because they were receiving Asylum Support (whether in-kind support or subsistence payments or
both) and also residing in Asylum Support accommodation. This change therefore brought the claimants in
line with how other victims who were receiving Asylum Support, but who were not in catered asylum
accommodation, were already being treated by the VCC financial support policy. This payment of £25.40,
when combined with what the claimants would have already been receiving through Asylum Support
(through payments or in-kind assistance, or both), ensured that they were receiving the same overall
amount as a victim receiving £65 a week from the VCC and i) that their essential living needs were being
met (by Asylum Support) and ii) that they were being assisted with their social, psychological and physical
recovery from their modern slavery experience (through their £25.40 VCC payment).

…


-----

The August 2020 policy clarification was not a policy change. It was the correction of an unintended effect
of the wording of the then policy document. The SSHD did not consider it necessary or appropriate to
consult on this correction by way of amendment, which removed an anomaly and brought the claimants in
line with other victims in receipt of Asylum Support (those not in catered asylum accommodation). As
explained in my 1[st] WS…, the Home Office then went on to engage stakeholders to gather evidence to
inform development of the new financial support policy.”

142. The lack of any consultation prior to the introduction of the Amended Guidance is also supported by
the claimant's evidence, but in view of the Secretary of State's acknowledgment that there was no
consultation it is unnecessary to provide any further outline of that evidence. The Secretary of State's
evidence is that she had already begun engaging with stakeholders in July 2020, but that was for the
purpose of introducing and developing a new financial support policy. In terms of inquiry, the Secretary of
State has adduced evidence of a costed analysis of recovery needs that has been undertaken in the
context of that review. However, it is acknowledged no such exercise was undertaken prior to the
introduction of the Amended Guidance.

**_The parties' submissions on Ground 2(a) (consultation/Tameside duty of inquiry)_**

143. The claimant submits that where an established benefit is being withdrawn, there will usually be an
obligation to consult beneficiaries before withdrawal: R (A) v South Kent Coastal CCG [2020] EWHC 372
_(Admin), [57], citing R (LH) v Shropshire Council [2014] EWCA Civ 404, [21]. She contends this case falls_
within the fourth category identified by Hallett LJ (giving the judgment of the court) in _R (Plantagenet_
_[Alliance Ltd) v Secretary of State for Justice [2014] EWHC 1662 (QB), [2015] 3 All ER 261 at [98](2), that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G9F-G361-DYBP-M106-00000-00&context=1519360)_
is, “a failure to consult would lead to conspicuous unfairness”.

144. The claimant also submits that the Secretary of State unreasonably failed to take any steps to
acquaint herself with information relevant to her decision to cut trafficking support. She was under a legal
duty to meet victims' recovery needs (inter alia through the provision of financial support) but failed to
identify and consider those needs when cutting support, in breach of the _Tameside duty:_ _R (Campaign_
_Against Arms Trade) v Secretary of State for International Trade [2019] EWCA Civ 1020 at [58] and [145]._

145. The claimant submits that in this case the established benefit was either (a) £65 per week that ought
to have been paid in accordance with the Guidance (for the reasons given in respect of Ground 1); or (b)
£35 per week that was in fact paid. The effect of the cessation decision and the reintroduction of trafficking
support at the lower level of £25.40 per week was to cut trafficking support:

i) by £9.60 per week (i.e. 27%) compared to the status quo ante of £35 per week); and

ii) (if the court accepts Ground 1) by £39.60 per week (i.e. 113%) compared to the sum of £65 per week
payable pursuant to the Guidance.

146. The evidence of the claimant's solicitor, Elizabeth Barratt, is that trafficking support was first
introduced in 2009. Whereas there is an annual review of asylum support, and the amount payable
increases in line with inflation, the trafficking support element had never increased prior to the cessation
decision, so far as the claimant is aware. In any event, it had been paid at the rate of £35 per week to
victims in initial accommodation for at least five years. On the basis, as I understand it, that trafficking
support for this cohort was £35 per week when it was first introduced, Ms Barratt has calculated that if it
had been adjusted for inflation, using the Consumer Price Inflation ('CPI') tables, the current value would
be £89.18. She recognises that this figure reflects inflation for all items, including some, such as the
purchase of vehicles, which are irrelevant. By reference only to the categories she suggests are
reasonably related to recovery (namely, clothing and footwear, health, transport services, communication,
education, recreation and culture, restaurants and personal care), Ms Barratt calculates that if trafficking
support had increased in line with inflation the current value would be £81.19.

147. In providing this evidence, the claimant does not seek to assert what the level of trafficking support
should be, but she submits that the fact that it had been severely cut in real terms was a matter that the
Secretary of State should have identified pursuant to her Tameside duty. And it increased the importance


-----

of consulting stakeholders - such as the **_Modern Slavery Strategy and Implementation Group (MSSIG),_**
which consists of charities, NGOs and some statutory bodies, including Anti-Slavery International, Human
Trafficking Foundation, the Salvation Army and the Independent Anti-Slavery Commissioner's Office – in
order to obtain information about the impact that substantially reducing trafficking support would have on
the recovery of this cohort of victims.

148. The claimant emphasises that even a small deduction would have been significant given that her
entire needs as a victim and as an asylum seeker had to be met by the asylum support she received in the
Hotel together with the trafficking support payment. But the deduction was not small. Even the lower of the
two figures (referred to above) is significant as a proportion of the amount she (and others in a like
situation) received.

149. The claimant contends that it is not tenable in light of JB(Ghana) for the Secretary of State to say the
Amended Guidance corrected an error in the Guidance. There may have been a “flaw in the design” of the
Guidance, but that was not the same as a “drafting error” (JB (Ghana), [71]). The Amended Guidance
represented a new policy approach. The Secretary of State has provided no cogent reason as to why it
was necessary to cut support on an urgent basis, without undertaking a legally adequate inquiry or
consultation. The Secretary of State's intention to review the policy cannot, the claimant submits, justify
taking decisions prematurely and without consultation prior to the outcome of that review.

150. The Secretary of State submits that the guidance given by the Court of Appeal in _Plantagenet_
_Alliance shows that for the court to impose a duty to consult is exceptional. Given the nature of the decision_
to issue the Amended Guidance, no duty to consult arose.

151. First, the Secretary of State relies on the fact that it was interim guidance pending the full review that
was in progress. Its interim nature was evident from the Ministerial Submission: see “The Issue” and “The
_Recommendations”. The claimant has not identified any authority in which a duty to consult on an interim_
policy has been imposed. The notion that the Secretary of State had to undertake a consultation both in
relation to interim measures and in relation to her longer-term policy is, in this particular context,
misconceived.

152. The second key characteristic that the Secretary of State relies on is that the introduction of the
Amended Guidance did not constitute a shift in policy or a change in approach. It was designed to correct
an anomaly by which one category of victims were receiving far more than others, and to achieve the
previous policy objectives by making clear the position the Secretary of State had previously understood to
be applicable. The Amended Guidance clarified the position in the interim pending the full review that was
in progress, removing any ambiguity or unintended effect of a literal reading of the Guidance which
resulted in duplication of support.

153. The Secretary of State contends that the claimant's argument that the amendment resulted in the
withdrawal of an “established benefit” goes too far as there had not, prior to the pandemic, been any
established practice of paying this cohort £65 per week. The figure of £35 per week had been set by the
Ministry of Justice before responsibility transferred to the Home Office in 2014. In the context of the review,
the Secretary of State had not been able to ascertain how that figure had been arrived at or the particular
recovery needs it was intended to meet as there was no breakdown. All that could be said was that the
Secretary of State for Justice must have thought it was an appropriate amount at that time, but it could not
be said he had decided it was the “minimum” appropriate to assist recovery: K & AM, [30].

154. The Secretary of State submits that it was not irrational to start from the figure of £65 per week that
victims in dispersal accommodation were receiving, and deduct the value of the essential living needs
component that those in initial accommodation were receiving in kind (at least in the main). This brought
the support for victims in initial accommodation into line with the support being provided to victims in
dispersal accommodation, meaning that all asylum-seeking victims received the same level of support. The
claimant's evidence regarding inflation is irrelevant to this policy of alignment.

155. Further, the Amended Guidance needed to be issued rapidly and without delay because of (i) the
extended periods individuals were having to remain in initial accommodation as a result of the pandemic;


-----

and (ii) the absence of any specific provision for trafficking support for this cohort within the VCC and
Guidance.

156. With respect to the _Tameside_ duty, the Secretary of State relies on the principles identified by the
Divisional Court in Plantagenet Alliance at [99]-[100], which fall to be applied in the specific context which
she again emphasises was interim guidance being produced, pending the completion of the ongoing
review of the financial support policy, to correct an identified anomaly. The Secretary of State relies on
Bean LJ's observation in JB (Ghana) at [73] that he could see no reason why the Secretary of State should
have been precluded from making the amendment which she did (paragraph ý61 above).

**_Analysis and decision – Ground 2(a): consultation/Tameside_**

157. The Secretary of State was not under a statutory duty to consult. The question is whether a duty to
consult arose at common law. There is no general duty to consult at common law: Plantagenet Alliance,

[98(1)]. As the Divisional Court observed in Plantagenet Alliance at [98(2)]:

“There are four main circumstances where a duty to consult may arise. First, where there is a statutory
duty to consult. Second, where there has been a promise to consult. Third, where there has been an
established practice of consultation. Fourth, where, in exceptional cases, a failure to consult would lead to
conspicuous unfairness. Absent these factors, there will be no obligation on a public body to consult (R
_(Cheshire East Borough Council) v. Secretary of State for Environment, Food and Rural Affairs_ _[2011]_
_EWHC 1975 (Admin) at paragraphs [68–82], especially at [72]).” (Emphasis added.)_

158. In this case, the claimant does not contend any duty to consult arose by reason of a promise to
consult, or a practice of doing so. No reliance is placed on the concept of legitimate expectation. In these
circumstances, a conclusion that a duty to consult arises is exceptional. Where there has been no promise
or practice giving rise to a legitimate expectation (whether procedural or substantive), the common law will
be “slow to require a public body to engage in consultation” (Plantagenet Alliance, [98(3)]).

159. As the Divisional Court observed in Plantagenet Alliance at [99]:

“A public body has a duty to carry out a sufficient inquiry prior to making its decision. This is sometimes
known as the Tameside duty since the principle derives from Lord Diplock's speech in Secretary of State
_for Education and Science v Metropolitan Borough of Tameside_ _[[1976] 3 All ER 665 at 696, [1977] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD8-PGP0-TWP1-612D-00000-00&context=1519360)_
1014 at 1065, where he said: '[T]he question for the court is, did the Secretary of State ask himself the right
question and take reasonable steps to acquaint himself with the relevant information to enable him to
answer it correctly?'”

160. In R (Balajigari) v Secretary of State for the Home Department _[2019] EWCA Civ 673, [2019] 1 WLR_
4647, the Court of Appeal (Underhill, Hickinbottom and Singh LJJ) approved Plantagenet Alliance at [99]
[100] and described the relevant principles which are to be derived from the authorities since Tameside in
the following terms at [70]:

“… First, the obligation on the decision-maker is only to take such steps to inform himself as are
reasonable. Secondly, subject to a Wednesbury challenge (Associated Provincial Picture Houses Ltd v
_Wednesbury Corpn [1948] 1 KB 223), it is for the public body and not the court to decide upon the manner_
and intensity of inquiry to be undertaken: see R (Khatun) v Newham London Borough Council [2005] QB
37, para 35 (Laws LJ). Thirdly, the court should not intervene merely because it considers that further
inquiries would have been sensible or desirable. It should intervene only if no reasonable authority could
have been satisfied on the basis of the inquiries made that it possessed the information necessary for its
decision. Fourthly, the court should establish what material was before the authority and should only strike
down a decision not to make further inquiries if no reasonable authority possessed of that material could
suppose that the enquiries they had made were sufficient. Fifthly, the principle that the decision-maker
must call his own attention to considerations relevant to his decision, a duty which in practice may require
him to consult outside bodies with a particular knowledge or involvement in the case, does not spring from
a duty of procedural fairness to the applicant but rather from the Secretary of State's duty so to inform
himself as to arrive at a rational conclusion. Sixthly, the wider the discretion conferred on the Secretary of


-----

State, the more important it must be that he has all the relevant material to enable him properly to exercise
it.”

161. In my judgment, the question whether this aspect of Ground 2 is made out falls to be viewed primarily
through the lens of the Tameside duty. A duty to consult outside bodies may arise, as the Court of Appeal
observed, from the duty to carry out sufficient inquiry.

162. I agree with the claimant that the Secretary of State unreasonably failed to take any adequate steps
to acquaint herself with information relevant to her decision to cut trafficking support. The decision that it
was unnecessary to consult, or to make further inquiry, was based on a flawed conception of the nature of
the decision.

163. First, on proper analysis, the decision was to _reduce the amount victims had been receiving, and_
were entitled to receive, in trafficking support. There is no evidence, and no sign in the version of the
Ministerial Submission provided to the court, of any recognition that the proposal was a _reduction of_
support. Instead, the Ministerial Submission refers to a _gap_ in support which the _introduction of the_
proposed payment is intended to fill.

164. Secondly, victims in initial accommodation had been receiving £35 per week. The only reason they
were not still receiving that sum was due to the unlawful cessation decision a few weeks earlier. There is
no recognition in the Ministerial Submission that what was proposed was a _very substantial reduction in_
support, even taking the figure victims had in fact been receiving prior to the cessation decision, rather than
their considerably higher entitlement under the Guidance.

165. Thirdly, the decision that it was unnecessary to consult was in part based on the interim nature of the
guidance. However, although it was introduced at a time when the Secretary of State was undertaking the
review, and so intended to publish a further version of the guidance once that review was complete, the
decision was not interim in a sense that was of any relevance in deciding whether it was necessary to
consult or undertake further inquiry. The reduction of trafficking support for all those victims in initial
accommodation who were in receipt of it during the years that the Amended Guidance was in force was not
_provisional on any decision to be taken following the review. I agree with the claimant that the Secretary of_
State's intention to review her policy could not rationally justify a premature decision, taken without
consultation or adequate inquiry, to reduce trafficking support substantially prior to the outcome of that
review.

166. Fourthly, the decision that it was unnecessary to consult was also based, in part, on the fallacy that
the decision to reduce the trafficking support for this cohort to £25.40 per week involved no change of
policy, amounting to no more than a clarification or correction of an error in the Guidance. It cannot be said
that it had ever been the Secretary of State's policy to pay that rate to victims in initial accommodation. She
had never done so. Her argument in _JB(Ghana)_ was that her policy, on a proper understanding of the
Guidance, was to pay victims in initial accommodation £35 per week, in line with the entitlement of those in
catered VCC accommodation, and with the payments she had in fact made. There was a flaw (or flaws) in
the design of the Guidance which led to anomalies in the amount of trafficking support paid to distinct
groups of victims. But it was not obvious from the Guidance what the substance of the policy would have
been if its design had been properly thought through: see JB (Ghana) at [71]. Consequently, the decision
to accept the recommendation in the Ministerial Submission and to publish the Amended Guidance selfevidently involved a choice and the adoption of a new policy.

167. Fifthly, the premise in the Ministerial Submission that there was a “gap” in the Guidance, leaving the
cohort of victims in initial accommodation without any trafficking support, and so creating an _urgent_
situation, was misguided. There was no gap: they had an entitlement to support in accordance with the
Guidance. The only reason they were not receiving any trafficking support was because of the unlawful
cessation decision. The urgent problem could have been remedied by withdrawing the cessation decision.

168. That said, I accept that once it was identified in the claims that were filed following the cessation
decision that the Guidance provided for victims in initial accommodation to receive £65 per week less the
small amount of financial support they received, it was open to the Secretary of State to take the view that


-----

she needed to act swiftly to avoid continuing to pay £65 per week to this cohort. If the Secretary of State
wished to remove the entitlement to £65 per week before consulting or undertaking an assessment, it
would have been open to her to have withdrawn the cessation decision and amended the Guidance to
reflect the reinstatement of payments of £35 per week (even if only on a temporary basis while the
appropriate rates for all victims was the subject of consultation and review). As that would not have
involved a _de facto_ reduction in trafficking support it would have been justifiable to proceed in that way
without first undertaking a consultation or further inquiry.

169. But in my judgment the urgency of the need to reinstate trafficking support was not capable of
justifying making a substantial de facto reduction in trafficking support without taking any steps to inquire
as to the impact that would have on those affected, or to identify, assess and evaluate the recovery needs
that trafficking support payments should assist in meeting. Mr Ryder states that the rationale underlying the
original introduction of the £35 per week rate was unclear but it was only long after the Amended Guidance
was introduced that any attempt to ascertain the rationale was made.

170. Once the nature of the decision the Secretary of State took is properly understood, in my view it is
clear that the failure to consult outside bodies such as MSSIG, or otherwise to gather any information as to
the impact that a (de facto) 27% reduction in trafficking support would have on the recovery of victims,
breached the Tameside duty. Accordingly, I conclude that the Amended Guidance was unlawful.

**_The parties' submissions on Ground 2(b) (recovery needs)_**

171. The claimant further submits that the Amended Guidance is unlawful because the trafficking support
of £25.40 per week unlawfully failed to meet victims' recovery needs.

172. The claimant contends that the Secretary of State's argument that her obligation is only to “assist”
victims in their recovery appears to amount to a suggestion that “any level of trafficking support, however
_low, will assist with recovery and therefore meet the Defendant's international obligations”. The claimant_
submits this is not the case. Article 13 of ECAT requires that potential victims of trafficking should be able
to “recover and escape the influence of traffickers”. The preamble to the Directive provides that victims
should receive assistance and support including “at least a minimum set of measures that are necessary to
_enable the victim to recover and escape from their traffickers”. Jurisprudence of the European Court of_
Human Rights emphasises that measures to safeguard the rights of victims must be “practical and
_effective”: see, e.g. Rantsev v Cyprus and Russia (2010) 51 EHRR 1, [284]-[285]. This includes a positive_
“protection duty” which has the aim not only of protecting the victim from further harm but also of facilitating
recovery: _Chowdhury v Greece_ (App. No. 21884/15), _VCL and AN v UK (App. Nos. 74603/12 and_
77587/12, [153] and [159]. These standards are considerably higher than mere assistance.

173. The claimant submits that the cut in support “reduced financial assistance below the level previously
_acknowledged to meet recovery needs”; and it did so in circumstances where the level of trafficking_
support had been subject to an ongoing real term cut, as it had never been adjusted in line with inflation.

174. The claimant contends the level of trafficking support provided under the Amended Guidance failed
cover the items set out in the _Slavery and Trafficking Survivor Care Standards ('the Care Standards'),_
which were adopted by the Secretary of State in October 2017. The Care Standards stipulate that victims
require a range of material support, including the following: (i) at least three changes of clothing; (ii)
sufficient funds in order to be able to travel as needed; (iii) a mobile phone; (iv) Wi-Fi; and (v) access to a
computer and printer.

175. The claimant draws attention to Mr Ryder's evidence that mobile phones, credit, coats and winter
boots are not provided “as standard by the contract”, and that for clothing accommodation providers and
support workers are “expected to use charitable donations”. The claimant submits that he tacitly
acknowledges that victims in initial accommodation do not receive three sets of clothing, mobile phones,
access to computers, and there is not automatic access to internet or phones with data. So the items
identified by Mostyn J and the Care Standards are not supplied.


-----

176. The claimant contends that the Secretary of State has failed to show that the level of trafficking
support provided under the Amended Guidance met the recovery needs identified by Mostyn J in K & AM.
The claimant submits that the Secretary of State cannot rely on a policy review which took place after the
Amended Guidance was introduced. Such _ex post facto evidence regarding future changes to trafficking_
payments is irrelevant and cannot change the lawfulness of payments made to date.

177. The claimant submits that the Secretary of State's reliance on the possibility of a victim securing
additional recovery payments from the Home Office is misplaced given that no reference was made to that
possibility until March 2022, victims and those advising them were unaware of this possibility until recently,
and ad hoc payments would not satisfy the long-term needs.

178. The Secretary of State submits that, as regards the level of support provided to victims with respect
to their recovery needs, the obligation under Article 12 is one of “assisting” their recovery. In _R (ZV) v_
_[SSHD [2018] EWHC 2725 (Admin) Garnham J at [122] described the support envisaged under article 11 of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5THF-NB01-F0JY-C2JK-00000-00&context=1519360)_
the Directive and article 12 of ECAT as:

“modest levels of assistance [comprising of] measures, for example, capable of ensuring the subsistence
and to emergency medical support, rather than to the more sophisticated support treatment for which Ms
Knights contends.”

With respect to Garnham J's observations as to the modesty of support payments to be made, Mostyn J in
_K & AM observed at [30] that he did not disagree that “such a level should be the minimum” (although he_
otherwise disagreed with the quoted passage).

179. The Secretary of State contends that the claimant's reliance on the mere fact that a higher rate was
previously provided cannot assist given the absence of institutional memory as to how the rates were
originally set, and the lack of evidence that the earlier rates represented an assessment of the “minimum”
level necessary to assist recovery.

180. The Secretary of State submits that it was reasonable and rational to bring the level of trafficking
support for victims in initial accommodation into line with that provided to victims in dispersal
accommodation. She relies on the detailed work undertaken in the context of the review as demonstrating
that there is no basis for the contention that the rate adopted in August 2020 was insufficient to meet the
Secretary of State's obligations. That review identified the items which trafficking support should cover and
the likely costs involved, and arrived at a rate of £26.14, closely approximating that paid by way of
trafficking support to victims in August 2020.

181. The Secretary of State relies on the second statement of Mr Ryder in rebuttal of the claimant's
contention that the Care Standards were not met. Mr Ryder states that (i) the MSVCC ensures that victims
have three sets of clothing, including any existing clothing, and provides three sets of clothing if necessary;
(ii) travel to a wide range of recovery related appointments is directly funded pursuant to the MSVCC; and
(iii) “Asylum support and MSVCC payments meet communication needs”. With respect to Wi-Fi and access
to a computer and printer, Mr Ryder states:

“Victims can use their MSVCC recovery payments to access Wi-Fi or to help access to a computer and
printer, for example by going to a library or an internet café. If a victim already has a smart phone when
they enter MSVCC support they can access public Wi-Fi.”

182. Support for recovery was not provided solely in the form of trafficking support payments. Victims
received other support, such as free healthcare via the National Health Service ('NHS') (including free
prescriptions, dental treatment and sight tests), the practical and emotional assistance of an Outreach
Support Worker, support with travel (as described above), and where appropriate, as in the claimant's
case, psychological support such as counselling may be provided. The Secretary of State also contends
that the Amended Guidance envisaged a case-by-case assessment pursuant to which additional support of
a financial or in-kind nature could be sought and made available.

183. The Secretary of State notes that the current rate of £26.14 rate of trafficking support reflects an
adjustment to account for inflation. The fact that £35 rate had not been adjusted for inflation does not


-----

render the Amended Guidance unlawful in view of the lack of any evidence as to the rationale for setting
that rate and the lack of any significant change to the CPI index in 2019-2020 or to inflation price indexes
between March and August 2020.

**_Analysis and decision – Ground 2(b) (recovery needs)_**

184. It is clear, in accordance with the authorities cited in paragraphs ý44 to ý48 above, that the Secretary
of State is required to provide victims with some financial support, going beyond the support provided to
meet their essential living needs, as part of the package of measures designed to assist victims in their
physical, psychological and social recovery. As Mostyn J observed in K & M “some money” for purposes
such as travel, recreation, entertainment and use of a computer or smartphone is reasonably required to
assist in such recovery. The Secretary of State is not obliged to provide more than modest levels of
assistance for these purposes.

185. The fact that the aim is to “assist” victims in their recovery does not mean, and Mr Payne did not
contend it means, that the Secretary of State could rationally set the rate at any level at all, no matter how
low, on the basis that any sum at all might be said to “assist”. It is for the Secretary of State to set the rate,
as primary decision-maker. But her decision is subject to review on Wednesbury grounds, and there would
undoubtedly come a point at which, if that approach were taken, the rate would be found to be below the
minimum rationally required to comply with ECAT, the Directive, the Secretary of State's policy and the
authorities to which I have referred.

186. However, I am not persuaded that the Secretary of State's determination in August 2020 that a rate of
£25.40 per week trafficking support was sufficient to assist in meeting the recovery needs of victims in
initial accommodation was irrational.

187. First, there is no evidence as to how the rate of £35 per week for those in catered VCC
accommodation was adopted. It is clear that the trafficking support for victims in dispersal accommodation
was already the lower figure of £25.40, and the higher sum to which those in initial accommodation and
receiving financial support pursuant to ss.95, 98 or 4 were entitled was a result of a flaw in the decision of
the Guidance. In these circumstances, the fact that the new rate represented a significant reduction in the
trafficking support paid to victims in initial accommodation does not, in and of itself, show that it was
irrational for the Secretary of State to determine that it was sufficient (together with the non-pecuniary
support that is available) to assist in meeting the cohort's recovery needs.

188. Secondly, it seems to me that I can place little weight on the evidence of Ms Barratt as to the extent
of the real term cut, having regard to inflation for these reasons. (i) Ms Barratt's evidence is not expert
evidence adduced pursuant to CPR Part 35. (ii) Her calculations are based on inflation from 2009, whereas
the evidence is not clear that the rate was £35 in 2009. The evidence before me is that the rate had been
£35 for at least five years prior to August 2020. So any calculation of the effect of inflation ought to begin
from 2015, not 2009. (iii) The higher levels of inflation in the period since August 2020 are not relevant to
this challenge to the lawfulness of the setting of that rate on 28 August 2020.

189. I accept that the rate of £35 per week was not adjusted by reference to inflation in the five years prior
to August 2020. However, as inflation was low during that period, to the extent that the £35 rate itself
reflected a cut in real terms compared to five years earlier, it appears to have been relatively minimal
compared to the figures put forward by Ms Barratt.

190. Thirdly, while the Secretary of State cannot rely on evidence of the subsequent review in the context
of Ground 2(a), and would not be able to rely on such _ex post facto evidence if this were a reasons_
challenge, it does not seem to me that she is precluded from relying on it in the context of this claim that
the court should find that by setting the rate at £25.40 the Secretary of State failed to meet the claimant's
recovery needs. That evidence provides strong support for the Secretary of State's submission that it was
reasonably open to her to decide that the rate of £25.40 was sufficient to assist in meeting the recovery
needs of victims in initial accommodation.


-----

191. Fourthly, the claimant's evidence as to the use to which she put the trafficking support that she
received does not demonstrate that the rate of £25.40 was unlawful. I have borne in mind the evidence
adduced by the claimant that she, and others in a similar position, felt that they had to use their trafficking
support to meet their essential living needs. However, first, the question as to the adequacy of the support
for essential living needs is separate (and I address it in the context of Ground 3). Secondly, given that the
support provided to meet the essential living needs of asylum-seekers is purposely set at a level
comparable to the lowest 10% income group in the UK (see _CB v Secretary of State for the Home_
_Department [2022] EWHC 3329 (Admin), Fordham J, [22]), it is unsurprising that victims may choose to put_
their trafficking support towards meeting their living costs. But that does not detract from the point that the
trafficking support is an additional payment that victims may choose to spend as they wish.

192. The claimant was able to use her trafficking support to travel to meet friends and to communicate
with them using her phone. She was also able to use her trafficking support to supplement the food and
drinks provided by the Hotel in circumstances where three meals a day (including a choice) and nonalcoholic beverages were provided, but as a consequence of her recovery needs the claimant
understandably wished to have more control over what she ate, and to avoid drinking tap water from the
bathroom. On the figures that she provided, taking her initial figure of expenditure of £15-20 per month on
travel rather than her later claim that she had spent £10-15 per week on this item, and bearing in mind that
her expenditure on toiletries and laundry was met by the cash payment from the Hotel, it came to just short
of the rate of £25.40 even when she was receiving the higher rate.

193. The evidence does not demonstrate any failure to comply with the Care Standards in the claimant's
case. She had been in the UK for nearly two decades when she entered the Hotel. She had a phone.
There is no evidence to suggest that she was lacking three sets of clothing; and she was provided with
some clothing and footwear with the support of her accommodation provider. The Hotel also paid for taxis
for the claimant to attend appointments.

194. Accordingly, I reject the claimant's contention that the level of financial support under the Amended
Guidance unlawfully failed to meet victims' recovery needs.

**_[The parties' submissions on Ground 2(c) (discrimination) and s.31(2A) Senior Courts Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y172-00000-00&context=1519360)_**
**_1981_**

195. The third basis on which the claimant contends the Amended Guidance was unlawful is that it
unlawfully discriminated contrary to Article 4 and 14 ECHR against victims of trafficking in initial
accommodation by providing them with less financial support than to other victims.

196. The claimant relies on Thlimmenos v Greece (34369/97) (2001) 31 EHRR 15 at [46] (a case which
was applied by the Supreme Court in R (DA) v Secretary of State for Work and Pensions [2019] 1 WLR
3289, [44]) for the proposition that article 14 of the European Convention on Human Rights ('ECHR')
requires like cases to be treated alike, and persons whose circumstances are significantly different to be
treated differently. It is well-established that victims, potential victims, asylum-seeking victims, all constitute
an “other status” under article 14: R (JP and BS) v SSHD [2020] 1 WLR 918, [146] and [150].

197. On the face of it, under the Amended Guidance, the financial support for victims in initial
accommodation was materially inferior to the financial support provided to victims in other forms of
accommodation. In particular, the claimant draws attention to the significantly lower trafficking support rate
for a victim in initial accommodation compared to a victim in catered VCC accommodation or a victim in
receipt of outreach support whilst living in accommodation other than VCC or asylum accommodation (e.g.
living with friends). She submits that the recovery needs of the victims are the same irrespective of the
nature of their accommodation.

198. The claimant contends that having established _prima facie discrimination, the burden rests on the_
State to provide a justification: JP and BS, [151]-[152]. The court must apply the fourfold proportionality test
outlined by the Supreme Court in R (Tigere) v Secretary of State for Business Innovation and Skills [2015]
_UKSC 57, [2015] 1 WLR 3820, [33]._


-----

199. The claimant particularly emphasises that there was no good reason to differentiate between victims
who were in full board accommodation, on the basis that one was also an asylum seeker (in initial
accommodation) and the other was not (and was in VCC accommodation). The claimant acknowledges
that a victim in catered VCC accommodation will have high needs, but submits that the claimant too has
complex and specialist recovery needs. Indeed, Mr Ryder's evidence shows that those in catered VCC
accommodation have greater material provision made for them, undermining any argument that they have
a greater need than those in initial accommodation for financial support.

200. The lack of any principled reason for the difference in trafficking support rates in the Amended
Guidance is evident, the claimant submits, from the fact that the Secretary of State has now introduced a
policy which provides the same level of trafficking support (now £26.14) irrespective of the accommodation
in which the victim is living. For this additional reason, the claimants submit the Amended Guidance was
not lawful.

201. The Secretary of State acknowledges that under the Amended Guidance there was a difference
between the trafficking support payments received by those in catered asylum accommodation (£25.40 per
week), those in catered VCC accommodation (£35.00 per week), and those living in other accommodation
(not provided pursuant to the IAA or the VCC) receiving outreach support (£39.60). The Secretary of State
submits, first, that the contention that no distinction was justified is mistaken given the high and specialist
recovery needs of those in catered VCC accommodation and the fact that those living with friends are in a
materially different situation as they do not benefit from having their essential living needs met by way of inkind and financial support.

202. Secondly, the Secretary of State submits that the Amended Guidance was an interim step in the
process that she has undertaken to iron out the anomalies in the Guidance. The Policy Equality Statement
attached to the Ministerial Submission noted:

“It is recognised that this approach (top up of £25.40) may result in differences between those in different
types of catered accommodation, however, this is an interim approach ahead of wider changes to the
financial support system that will ensure all potential/confirmed victims of **_modern slavery supported_**
through the VCC receive the financial support they require based on an assessment of recovery need.
However it is considered that the recommended approach will result in greater consistency than the
alternative option of a rate of £35 per week, considering the numbers of individuals accommodated in the
different cohorts. In June 2020, it is estimated that approximately 28 individuals were in VCC catered
accommodation, compared to approximately 2,360 individuals who are potential/confirmed victims of
**_modern slavery who are in some form of asylum support accommodation. VCC catered accommodation_**
is provided where the service user is not capable of preparing their own food due to disability, debilitating
illness or ongoing treatment for severe substance use/addition.”

The Secretary of State acknowledges that there were anomalies in the policy, but denies that these
rendered the (interim) Amended Guidance unlawful.

203. Thirdly, the differences identified by the claimant have been rectified with effect from March 2023:
there is now a single Recovery Rate. The argument is, therefore, academic and the Secretary of State
submits that the court should apply s.31(2A) of the Senior Courts Act 1981 to this limb (and Ground 2
generally).

**_Analysis and decision – Ground 2(c) (discrimination) and_** **_[s.31(2A) Senior Courts Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y172-00000-00&context=1519360)_**
**_1981_**

204. In view of my conclusion that the Amended Guidance was unlawful for the reasons that I have given
in respect of Ground 2(a), and in circumstances where the Secretary of State has further amended the
statutory guidance to provide a single rate of trafficking support (or Recovery Rate as it is now called), I
agree with Mr Payne that any consideration of whether the distinctions between victims based on the type
of accommodation in which they were living were justifiable has been rendered academic. The Secretary of
State has reduced the level of trafficking support for those in catered VCC accommodation or receiving
outreach support while in non-asylum and non-VCC accommodation to the level of victims living in asylum


-----

accommodation. In these circumstances, I consider it unnecessary to add further to the length of this
judgment by addressing this limb.

205. However, I reject the contention that relief should be refused in respect of Ground 2(a) on which the
claim has succeeded pursuant to s.31(2A) of the Senior Courts Act 1981. In my view, if the unlawful
cessation decision and the subsequent failure to make due inquiry or consult before reducing trafficking
support below the previously paid level of £35 had not occurred, it is not highly likely that the Secretary of
State would have reduced trafficking support to victims in initial accommodation to the level of £25.40 at
the point in time when she did. On the contrary, she would first have undertaken the review which has
ultimately led to the new single Recovery Rate.

I. **Ground 3: whether the essential living needs of victims of trafficking are met in initial**
**accommodation**

**_Scope of the issue_**

206. The agreed issue in respect of Ground 3 is:

“Whether the Defendant has failed to provide adequate financial support to meet the essential living needs
of victims of trafficking in initial accommodation in breach of her obligations under ECAT and the EU
Directive.”

207. The claimant contends that she and other victims in catered accommodation did not have their
_essential living needs met. Although the issue is stated as a failure to meet the essential living needs of_
victims in initial accommodation, in fact, and as a matter of logic, the claimant's submission encompassed
all asylum-seekers supported pursuant to s.98 of the IAA in initial accommodation.

208. Mr Payne submits that this court is being asked to undertake a similar analysis in respect of those
supported pursuant to s.98 of the IAA to that which was undertaken by Farbey J in _JM, but without any_
comparable evidence. This case is fundamentally a challenge to the Amended Guidance and the court
does not have developed submissions on the questions as to which needs are essential living needs in the
context of short-term support pursuant to s.98. He urges me not to embark on such an analysis. As Farbey
J observed in JM at [30]:

“Judicial review claims are brought by individual claimants: neither solicitors nor counsel may properly
claim to act on behalf of groups of people from whom they do not have instructions (R (DV)) v Secretary of
_State for the home Department [2021] 4 WLR 75, paras 51 and 70 per Dame Victoria Sharp P).”_

209. In reply, Ms Knights accepted that it would be difficult for the court to make a broad finding in respect
of this ground. Nonetheless, she submitted that there is sufficient evidence before me to make general
findings that there were widespread issues at the particular time with which this claim is concerned of
failure to meet the travel and communication needs, and failure to provide toiletries, to those supported in
initial accommodation under s.98 of the IAA.

210. I agree with the Secretary of State that the broad issue that the claimant seeks to raise is not one that
I should entertain on the basis of the limited evidence and submissions on this issue that I have received
and heard. I consider that in addressing this ground I should go no further than considering whether the
evidence demonstrates any failure to meet the claimant's essential living needs.

**_Analysis and decision_**

211. The essential needs that the claimant submits were not met in her case were for: (i) toiletries; (ii)
laundry; (iii) food and beverages; (iv) Wi-Fi; (v) clothing; and (vi) travel to attend appointments.

212. The need for toiletries obviously is an essential need for those supported pursuant to s.98 of the IAA:
it is not a need that can be said to arise only in the longer term. In the claimant's case the evidence
demonstrates that the need was met:

i) From May to mid-December 2020 the Hotel met this need by providing the claimant with £5 per week
which exceeded the sum she required to spend on toiletries JM shows that the Secretary of State's


-----

detailed analysis of the cost of “toiletries/healthcare/household cleaning items” in mid-June 2020 was £1.55
(adjusting £1.52 for 1.7% inflation): JM, [53]. The claimant's own evidence in her first statement was that
toiletries (including sanitary pads) cost her £10 per month (i.e. about £2.50 per week). Surprisingly, this
increased in her next statement to £4 per week (excluding sanitary pads which were by then being
provided by the Hotel). But even the higher figure was lower than the financial support she received from
the Hotel.

ii) From November 2020 to February 2021 the Hotel met this need by providing the claimant with toiletries.
She has not suggested that her need for toiletries was not met once the Hotel began providing them.

213. The need to be able to wash clothes is also, plainly, an essential need for those supported pursuant
to s.98 of the IAA. In the claimant's case, the evidence demonstrates that the need was met:

i) From May 2020 to mid-December 2020, the financial support provided by the Hotel also covered the
purchase of laundry detergent which the claimant was able to use to wash her clothes in her bathroom.

ii) From November 2020 the Hotel provided the claimant with a laundry service. She does not suggest that
there was any failure to meet this need once the Hotel began washing her clothes.

214. Although the claimant understandably found it triggered memories of her exploitation to have to wash
and dry her clothes in her room, in the way that she did before the Hotel provided a laundry service, I do
not consider that this amounts to a failure to meet her essential living needs while she was supported
under s.98. She had the choice, if she wished or considered it necessary for her recovery, to direct part of
her trafficking support to using a laundrette. By the time she was supported pursuant s.95, the Hotel was
providing a laundry service.

215. The provision of food and non-alcoholic drinks are also, of course, essential living needs for those
supported under s.98. The evidence is that the Hotel provided the claimant with three meals per day
(giving a choice, including a vegetarian option) and non-alcoholic drinks at each meal. Although the
claimant chose to spend some of her trafficking support on takeaway food, snacks and drinks (as she was
of course entitled to do, it being a matter for her how to spend the money she received), I do not consider
that this demonstrates a failure on the part of the accommodation provider to meet this essential living
need. The claimant has said that fish was often served which she did not like, but she has not addressed
the evidence that the provider offered a choice.

216. The ability to communicate using a phone or Wi-Fi was an essential living need for the claimant while
she was supported pursuant to s.98, as well as subsequently when she became eligible for s.95 support.
This essential living need was not as extensive as her recovery need for contact with friends (to which she
directed some of her trafficking support), but even in the context of short-term support she at least needed
to be able to contact her Support Worker, her legal representative, Migrant Help and a family member (if
any) who she wished to inform of her new situation. Given that the claimant was supported under s.98 for a
period of more than six months, her essential living need extended beyond this to the ability to
communicate also with friends.

217. The evidence is that the Hotel provided free Wi-Fi for 20 minutes per day in the reception area.
Although this was not a secluded area in which the claimant could have a conversation over the phone,
she would have been able to communicate privately via email, WhatsApp, or another messaging or
webchat platform. In addition, there was the possibility that the claimant could have made use of free Wi-Fi
available outside the Hotel, although again such public places would have enabled private messaging but
not private phone conversations.

218. In my judgment, given the lengthy period for which the claimant was supported under s.98, the ability
to have some private phone conversations was an essential living need. It was not met in-kind by the Hotel
through Wi-Fi being available in her room, or through any financial support provided by the Hotel to enable
her to top up her phone. Nor was this need met by making Wi-Fi available only in the reception area as the
kinds of conversations that she needed to have with her legal representatives and Support Worker, and
even with friends about how she was feeling, entailed the need to be able to speak privately. I note that the


-----

payments to which she became entitled on being assessed as eligible for s.95 support did not cover the
communication need: see JM.

219. However, as a result of being a victim in receipt of trafficking support, the whole package of support
that the claimant received as a victim and an asylum seeker did ensure that her essential communication
need (as well as her more extensive recovery need in this area) was in fact met. Although this does mean
that a small part of the trafficking support that the claimant used to top up her phone was directed to
meeting an essential living need. But in circumstances where the claimant in fact received £35 per week
trafficking support, and I have rejected the contention that the rate of £25.40 was too low to comply with the
obligation to assist in meeting her recovery needs, looking at the overall picture I conclude that the
claimant's essential living need in respect of communication was met.

220. The claimant had been in the UK for nearly two decades before she entered the Hotel, and for most
of that time she had been living either with a friend or a partner. There is nothing to suggest that she lacked
three (or more) sets of clothing, or footwear, when she moved into the Hotel. While she was in the Hotel,
she was provided with shoes and a dressing gown, and the evidence is that the Hotel was able to source
other charitable donations of clothing, if required. Once the claimant became eligible for s.95 support, she
became entitled to a weekly payment which was calculated to meet her essential living needs in respect
clothing and footwear (as well as travel and non-prescription medication). Although the claimant has
referred to saving her trafficking support to buy winter clothes or boots, I am not persuaded that there was
a failure to meet her essential living need for clothing and footwear.

221. As regards travel, the evidence is that the Hotel did pay for taxis when the claimant needed to report
to the Home Office and on one occasion when she went to hospital. There is no evidence that the claimant
had other appointments beyond ordinary walking distance for which she was provided no assistance with
travel. As I have said, the s.95 payments included a sum to meet her travel need.

222. Accordingly, I conclude that the Secretary of State met the claimant's essential living needs and
reject this ground of claim. However, I note that a source of difficulty for the claimant, and more generally
for those in a similar position, was that on occasions payments were made in arrears. It is obviously vital
that sums of money that are intended to meet a victim's or an asylum seeker's essential living needs are
made available at the point in time when those needs arise. It is also fair to note, however, that this case
concerns events during the early stages and first year of the pandemic, and at a time when the number of
people in initial accommodation was rapidly rising due at least in part to protective Covid measures.

J. Conclusion

223. The claim succeeds on Grounds 1 and 2(a). The remainder of the claim is dismissed.

**End of Document**


-----

