# AS (Safety of Kabul) (CG) [2018] UKUT 118 (IAC)

UK Upper Tribunal (Immigration and Asylum Chamber)

Upper Tribunal Judges Allen and Jackson

23 March 2018Judgment

For the Appellant: Ms S Naik QC, Ms B Poynor and Mr B Bundock of Counsel, instructed by J D Spicer Zeb
solicitors

For the Respondent: Mr S Singh QC, instructed by the Government Legal Department

**COUNTRY GUIDANCE**

_Risk on return to Kabul from the Taliban_

(i) A person who is of lower-level interest for the Taliban (i.e. not a senior government or security services official,
_or a spy) is not at real risk of persecution from the Taliban in Kabul._

_Internal relocation to Kabul_

(ii) _Having regard to the security and humanitarian situation in Kabul as well as the difficulties faced by the_
_population living there (primarily the urban poor but also IDPs and other returnees, which are not dissimilar to the_
_conditions faced throughout may other parts of Afghanistan); it will not, in general be unreasonable or unduly harsh_
_for a single adult male in good health to relocate to Kabul even if he does not have any specific connections or_
_support network in Kabul._

(iii) However, the particular circumstances of an individual applicant must be taken into account in the context of
_conditions in the place of relocation, including a person's age, nature and quality of support network/connections_
_with Kabul/Afghanistan, their physical and mental health, and their language, education and vocational skills when_
_determining whether a person falls within the general position set out above._

(iv) _A person with a support network or specific connections in Kabul is likely to be in a more advantageous_
_position on return, which may counter a particular vulnerability of an individual on return._

(v) Although Kabul suffered the highest number of civilian casualties (in the latest UNAMA figures from 2017) and
_the number of security incidents is increasing, the proportion of the population directly affected by the security_
_situation is tiny. The current security situation in Kabul is not at such a level as to render internal relocation_
_unreasonable or unduly harsh._

_Previous Country Guidance_

(vi) The country guidance in AK (Article 15(c)) Afghanistan CG [2012] UKUT 163 (IAC) in relation to Article 15(c) of
_the Qualification Directive remains unaffected by this decision._

(vii) _The country guidance in AK (Article 15(c)) Afghanistan CG [2012] UKUT 163 (IAC) in relation to the_
_(un)reasonableness of internal relocation to Kabul (and other potential places of internal relocation) for certain_
_categories of women remains unaffected by this decision._


-----

(viii) _The country guidance in AA (unattended children) Afghanistan CG [2012] UKUT 00016 (IAC) also remains_
_unaffected by this decision._

**TABLE OF CONTENTS**

**_Description_**
**_Paragraphs_**

**Introduction** **1-4**

The Country Guidance Question 1

**The Appeal** **5-13**

**The Legal Framework** **14-44**

Burden of Proof 41-44

**The Evidence** **45-171**

The Experts 47-66

Evidence on risk 67-97

Internal Relocation 98-154

Returns 155-171

**Findings and Reasons** **172- 252**

Risk 173-188

Reasonableness 189-235

Previous Country Guidance 236-240

Summary of general conclusions 241

The Appellant's claim 242 -252

**Notice of Decision**

**Appendix A**
Schedule of Background and Expert Evidence considered by the Tribunal

**Appendix B**
Extract from EASO Country of Origin Information Report, Afghanistan: Security
Situation” (August 2017).

**Appendix C**
Error of Law Decision

**Appendix D**
Senior President's Practice Direction No 10 (2010)

**GLOSSARY**

AMASO  - Afghanistan Migrants Advice and Support Organisation

AAN  - Afghan Analysts Network

|Description|Paragraphs|
|---|---|
|Introduction|1-4|
|The Country Guidance Question|1|
|||
|The Appeal|5-13|
|||
|The Legal Framework|14-44|
|Burden of Proof|41-44|
|||
|The Evidence|45-171|
|The Experts|47-66|
|Evidence on risk|67-97|
|Internal Relocation|98-154|
|Returns|155-171|
|||
|Findings and Reasons|172- 252|
|Risk|173-188|
|Reasonableness|189-235|
|Previous Country Guidance|236-240|
|Summary of general conclusions|241|
|The Appellant's claim|242 -252|
|||
|Notice of Decision||
|||
|Appendix A||
|Schedule of Background and Expert Evidence considered by the Tribunal||
|||
|Appendix B||
|Extract from EASO Country of Origin Information Report, Afghanistan: Security Situation” (August 2017).||
|||
|Appendix C||
|Error of Law Decision||
|||
|Appendix D||
|Senior President's Practice Direction No 10 (2010)||


-----

AGEF  - Experts in the Fields of Migration and Development

AGEs  - Anti-government elements

AVRR  - Assisted Voluntary Return and Reintegration

DTM  - Displacement tracking matrix

EASO  - European Asylum Support Office

ERIN  - European Reintegration Network

GBV  - Gender based violence

GDP  - Gross domestic product

HRW  - Human Rights Watch

IDPs  - Internally displaced persons

IEDs  - Improvised explosive devices

IOM  - International Organisation for Migration

IPSO  - International Psychosocial Organisation

IRA/IFA  - Internal relocation alternative/Internal flight alternative

ISKP  - Islamic State of the Khorasan Province

NGOs  - Non-governmental organisations

UN  - United Nations

UNAMA  - UN Assistant Mission in Afghanistan

UNFPA  - UN Population Fund

UNHCR  - UN High Commissioner for Refugees

UNOCHA  - UN Office for Coordination of Humanitarian Affairs

**DECISION AND REASONS**

Introduction

1. The question posed by the Upper Tribunal for country guidance in this case is:

_“Whether the current situation in Kabul is such that the guidance given in AK (Afghanistan) [2012] UKUT_
_00163 (IAC) needs revision in the context of consideration of internal relocation.”_

2. The guidance in AK on this point at B is as follows:

_“(iv) Whilst when assessing a claim in the context of Article 15(c) in which the respondent asserts that_
_Kabul city would be a viable internal relocation alternative, it is necessary to take into account (both in assessing_
_“safety” and “reasonableness”) not only the level of violence in that city but also the difficulties experienced by that_
_city's poor and also the many Internally Displaced Persons (IDPs) living there, these considerations will not in_
_general make return to Kabul unsafe or unreasonable._

_(v) Nevertheless, this position is qualified (both in relation to Kabul and other potential places of internal_
_relocation) for certain categories of women. The purport of the current Home Office OGN on Afghanistan is that_
_whilst women with a male support network may be able to relocate internally, “… it would be unreasonable to_
_expect lone women and female heads of household to relocate internally” (February 2012 OGN, 3.10.8) and the_
_Tribunal sees no basis for taking a different view.”_

3. Also important in the specific context of the question posed in the present country guidance case are the fuller
findings in paragraph 243 of AK, which appear immediately prior to the conclusion set out in (iv) above:

_“As regards Kabul city, we have already discussed the situation in that city and we cannot see that for the_
_purposes of deciding either refugee eligibility or subsidiary protection eligibility (and we are only formally tasked with_
_deciding the latter) that conditions in that city make relocation there in general unreasonable, whether considered_
_under Article 15(c) or under 15(b) or 15(a). We emphasise the words “in general” because it is plain from Article_


-----

_8(2) and our domestic case law on internal relocation (see AH (Sudan) in particular) that in every case there needs_
_to be an enquiry into the applicant's individual circumstances; and what those circumstances are will very often_
_depend on the nature of specific findings made about the credibility of an appellant in respect of such matters as_
_whether they have family ties in Kabul. But here our premise concerns an appellant with no specific risk_
_characteristics and someone found to have an uncle in Kabul: see above paras 3, 5, 154, 186 and below, paras_
_250-254). …”_

4. When considering the question posed for the present case, we bear in mind that the focus in AK was on Article
15(c) of Council Directive 2004/83/EC of 29 April 2004 on Minimum Standards for the Qualification and Status of
Third Country Nationals or Stateless Persons as Refugees or as Persons Who Otherwise Need International
Protection and the Content of the Protection Granted (the “Qualification Directive”) and eligibility for subsidiary
protection, rather than the issue of internal relocation in the context of the Refugee Convention and that the
evidence before that panel on the socio-economic conditions in Kabul was relatively limited compared to what is
before us in the present appeal. We also bear in mind that the decision in AK was based principally on evidence
from 2010 to 2011 and on any view, there have been rapid and significant changes in both Kabul and Afghanistan
as a whole in the intervening period.

The Appeal

5. The Appellant, a national of Afghanistan born on 1 January 1986, appealed the Respondent's decision dated 12
February 2015 to refuse his asylum and human rights claim. His appeal was dismissed by First-tier Tribunal Judge
Bradshaw in a determination promulgated on 30 July 2015. Although Judge Bradshaw accepted that the Appellant
would be at risk on return to his home area from the Taliban, his asylum appeal was dismissed on the basis that he
could internally relocate to Kabul. The Appellant's human rights appeal was dismissed on the basis that there
would be no disproportionate interference with the Appellant's right to respect for private and family life contrary to
Article 8 of the European Convention on Human Rights.

6. The Appellant sought permission to appeal on two grounds, first, that the Judge failed to properly consider
submissions made to him on Article 15(c) of the Qualification Directive and secondly, that she failed to properly
consider the evidence in relation to internal relocation. Permission was granted on both grounds by UTJ Taylor on
2 October 2015. At an early stage, the appeal was identified as possible country guidance.

7. In his decision promulgated following a hearing on 27 April 2017 (Appendix C) UTJ O'Connor found an error of
law such that it was necessary to set aside the decision of Judge Bradshaw. In so finding, he stated that “The
findings of primary fact made by the First-tier Tribunal have not been the subject of challenge and are preserved, as
is the conclusion that the Appellant would be at risk of suffering persecutory treatment in his home area.” In
addition, the finding that the Appellant is not at risk on return to his home area or elsewhere from the Afghan
government has not been challenged and stands.

8. For the purposes of the present appeal and, in particular, the letter of instruction to the experts, the following are
agreed facts.

a) The Appellant (dob 1 January 1986) is a single man from Kardai village, Laghman province, Afghanistan. He is
thus 31 years of age.

b) The Appellant's father was the imam of the local mosque and well-known in the village, where the Taliban have
a presence. He refused to cooperate with them or propagate for them and was labelled a government agent. In
2006 the Taliban killed him.

c) The Appellant's brother reported their father's murder to the authorities and 10 days later there was an attack on
the local Taliban by government forces. The Taliban suspected the Appellant's brother of spying for the
government and killed him in 2007.

d) Sometime later the Taliban abducted the Appellant from his house and detained him away from the village along
with others. While detained, he was not fingerprinted or photographed by the Taliban. A week later, the Appellant


-----

escaped during a night raid by government forces and returned to Kardai village, whereupon his maternal uncle
passed him to a friend and then to an agent to take him out of Afghanistan.

e) The Appellant fled Afghanistan clandestinely in 2008 and entered the United Kingdom towards the end of that
year, having passed through other countries en route. The Appellant's mother, younger brother and maternal uncle
remained in Kardai village.

f) The Appellant would be at risk of persecution if returned to his local area.

9. For the purposes of instructions to the experts, there were a number of facts which they were asked to assume
although they were not agreed aspects of the Appellant's account between the parties. These included the
Appellant's claim that when in Afghanistan he attended school for nine years and thereafter worked with his brother
in farming; that he has not had contact with his mother, younger brother and maternal uncle since arriving in the
United Kingdom; and that the Appellant has no family or support in Kabul.

10. In summary, the Appellant's case is that he is at risk from the Taliban in his home area and also in Kabul,
where there would be no sufficiency of protection from such risk. In any event, internal relocation to Kabul is not
reasonable because he is at risk of harm (kidnapping/extortion of money) on account of his westernised profile;
because he has no family or other support network in Kabul to assist him in obtaining accommodation and/or
employment; because he is at risk of being in conditions comparable to those of an IDP (with greater risk of
unemployment, limited access to adequate housing, limited access to water and sanitation and food insecurity) and
that reintegration assistance will not relieve these issues.

11. It is important to note at the outset that it is not the Appellant's case that treatment in Kabul would be in breach
of Article 3 of the European Convention on Human Rights or Article 15(c) of the Qualification Directive.

12. In summary, the Respondent's case is that although the Appellant would be at risk of persecution if returned to
his local area in Afghanistan, he would be able to safely and reasonably internally relocate to Kabul and for this
reason is not entitled to be recognised as a refugee under the Refugee Convention nor be granted humanitarian
protection.

13. It is important to note at the outset, that the Respondent does not rely on there being a sufficiency of protection
for the Appellant from the Taliban in Afghanistan, or in particular in areas where he is accepted to be at risk. The
Respondent acknowledges that however willing the Afghan authorities are, they would usually be unable to offer
effective protection. For this reason, we do not in this decision, set out in any detail the substantial evidence before
us on the capacity of the Afghan forces, issues of corruption and human rights abuses within them, nor do we set
out evidence before us on the judiciary in Afghanistan.

Legal framework

14. By Article 1A(2) of the Refugee Convention, a refugee is a person who is out of the country of his or her
nationality and who, owing to a well-founded fear of persecution for reasons of race, religion, nationality or
membership of a particular social group or political opinion, is unable or unwilling to avail him or herself of the
protection of the country of origin.

15. Article 8 of the Qualification Directive provides as follows:

1. As part of the assessment of the application for international protection, Member States may determine that an
_applicant is not in need of international protection if in a part of the country of origin there is no well-founded fear of_
_being persecuted or no real risk of suffering serious harm and the applicant can reasonably be expected to stay in_
_that part of the country._

2. In examining whether a part of the country of origin is in accordance with paragraph 1, Member States shall at
_the time of taking the decision on the application have regard to the general circumstances prevailing in that part of_
_the country and to the personal circumstances of the applicant._


-----

3. Paragraph 1 may apply notwithstanding technical obstacles to return to the country of origin.

16. The Immigration Rules provide in Rule 339O(i):

(i)   The Secretary of State will not make:

(a)   a grant of refugee status if in part of the country of origin a person would not have a well founded fear of being
_persecuted, and the person can reasonably be expected to stay in that part of the country; or_

(b) _a grant of humanitarian protection if in part of the country of return a person would not face a real risk of_
_suffering serious harm, and the person can reasonably be expected to stay in that part of the country._

_(ii)  In examining whether a part of the country of origin or country of return meets the requirements in (i)_
_the Secretary of State, when making a decision on whether to grant asylum or humanitarian protection, will have_
_regard to the general circumstances prevailing in that part of the country and to the personal circumstances of the_
_person._

_(iii) (i) applies notwithstanding technical obstacles to return to the country of origin or country of return._

17. From the above, a person is not a refugee if they can reasonably be expected to live in another part of their
home country where they would not have a well-founded fear of persecution. In such circumstances, a person has
the option of internal relocation, also known as an internal flight alternative. Once the issue of internal relocation
has been raised there are two discrete questions to determine whether there is an option of internal relocation.
First, does the person have a well-founded fear of persecution in the proposed place of relocation? If yes, then
there is no internal relocation option and the person is a refugee. There is also no internal relocation option if the
person would be subject to inhuman or degrading treatment within the meaning of Article 3 of the European
Convention on Human Rights (the “ECHR”) in the proposed place of relocation or if it would be in breach of Article
15(c) of the Qualification Directive. If not, then secondly there must be an assessment of whether in all the
circumstances, it would be reasonable or not unduly harsh to expect the person to relocate to that place.

18. Lord Bingham summarised the approach to reasonableness in Januzi v Secretary of State for the Home
Department [2006] 2 AC 426, at [21]:

_“The decision-maker, taking account of all relevant circumstances pertaining to the claimant and his_
_country of origin, must decide whether it is reasonable to expect the claimant to relocate or whether it would be_
_unduly harsh to expect him to do so… There is, as Simon Brown LJ aptly observed in Svazas v Secretary of State_
_for the Home Department [2002] 1 WLR 1891, para 55, a spectrum of cases. The decision-maker must do his best_
_to decide, on such material as is available, where on the spectrum the particular case falls… All must depend on a_
_fair assessment of the relevant facts.”_

19. Further, at [47], Lord Hope stated the position as follows:

_“The question where the issue of internal relocation is raised can, then, be defined quite simply … it is_
_whether it would be unduly harsh to expect a claimant who is being persecuted for a Convention reason in one part_
_of his country to move to a less hostile part before seeking refugee status abroad. The words “unduly harsh” set_
_the standard that must be met for this to be regarded as unreasonable. If the claimant can live a relatively normal_
_life there by the standards that prevail in his country of nationality generally, and if he can reach the less hostile part_
_without undue hardship or undue difficulty, it will not be unreasonable to expect him to move there.”_

20. The test was considered further by the House of Lords in AH (Sudan) v Secretary of State for the Home
Department [2008] 1 AC 678, upon which we had detailed submissions from the parties as to the scope of the test
of reasonableness of internal relocation. We therefore set out more fully the judgements in that case and the
principles which flow from it, not all of which were controversial between the parties.

21. First, Lord Bingham, having referred to his own judgement at [21] of Januzi, (set out above), went on to say at

[5]:


-----

_“Although specifically directed to a secondary issue in the case, these observations are plainly of general_
_application. It is not easy to see how the rule could be more simply or clearly expressed. It is, or should be, evident_
_that the enquiry must be directed to the situation of the particular applicant, whose age, gender, experience, health,_
_skills and family ties may all be very relevant. There is no warrant for excluding, giving priority to, consideration of_
_the applicant's way of life in the place of persecution. There is no warrant for excluding, or giving priority to,_
_consideration of conditions generally prevailing in the home country. I do not estimate the difficulty of making_
_decisions in some cases. But the difficulty lies in applying the test, not in expressing it. The humanitarian object of_
_the Refugee Convention is to secure a reasonable measure of protection for those with a well-founded fear of_
_persecution in their home country or some part of it; it is not to procure general levelling-up of living standards_
_around the world, desirable though of course that is.”_

22. Baroness Hale confirmed at [20] that the House was all agreed that the correct approach was that set out by
Lord Bingham in Januzi and further endorsed the following submission from the United Nations High Commissioner
for Refugees (UNHCR) of the correct approach:

_“The correct approach when considering the reasonableness of IRA [internal relocation alternative] is to_
_assess all the circumstances of the individual's case holistically and with specific reference to the individual's_
_personal circumstances (including past persecution or fear thereof, psychological and health condition, family and_
_social situation, and survival capacities). This assessment is to be made in the context of the conditions in the_
_place of relocation (including basic human rights, security conditions, socio-economic conditions, accommodation,_
_access to health care facilities), in order to determine the impact on that individual of settling in the proposed place_
_of relocation and whether the individual could live a relatively normal life without undue hardship.”_

23. The assessment must therefore consider the particular circumstances of the individual applicant in the context
of conditions in the place of relocation. The test of reasonableness is one of great generality, excluding only a
comparison with conditions in the host country in which protection has been sought, per Lord Bingham at [13] and
Baroness Hale at [27].

24. Secondly, the test of reasonableness is not analogous to, or to be equated with, the test under Article 3 of the
ECHR, per Lord Bingham at [9] and Baroness Hale at [21-22 and 26]. If, however, conditions in the proposed place
of relocation do breach Article 3 of the ECHR, internal relocation would automatically be unreasonable without
more.

25. Thirdly, the correct comparator by which to judge reasonableness is not against the conditions for the worst of
the worst in that country. Put another way, it is not a consideration of whether a person's circumstances will be
worse than the circumstances of anyone else in that country, per Baroness Hale at [27-28].

26. Finally, Lord Brown, who expressly agrees with the opinion of Lord Bingham (and both of whom are expressly
agreed with by Lord Hope at [18]), expanded upon the test of reasonableness at [42] as follows:

_“As mentioned, one touchstone of whether relocation would involve undue hardship, identified in the_
_UNHCR guidelines referred to in the passage already cited from para 47 of Lord Hope's speech in Januzi, is_
_whether “in the context of the country concerned” the claimant can live “a relatively normal life”. The respondents_
_are fiercely critical of the Tribunal's approach to this question in the present case. In particular they criticise the_
_Tribunal's conclusion as to “the subsistence level existence in which people in Sudan generally live”. To my mind,_
_however, this criticism is misplaced. It is not necessary to establish that a majority of the population live at_
_subsistence level for that to be regarded as a “relatively normal” existence in the country as a whole. If a significant_
_minority suffer equivalent hardship to that likely to be suffered by claimant on relocation and if the claimant is as_
_well able to bear it as most, it may well be appropriate to refuse him international protection. Hard-hearted as this_
_may sound, and sympathetic although one inevitably feels towards those who have suffered as have these_
_respondents (and the tens of thousands like them), the Refugee Convention, as I have sought to explain, is really_
_intended only to protect those threatened with specific forms of persecution. It is not a general humanitarian_
_measure. For these respondents, persecution is no longer a risk. Given that they can now safely be returned_
_home, only prove that their lives on return would be quite simply intolerable compared even to the problems and_


-----

_deprivations of so many of their fellow countrymen would entitle them to refugee status. Compassion alone cannot_
_justify the grant of asylum.”_

27. It is the Respondent's reliance on this last paragraph at [42] of Lord Brown's speech, in particular, the reference
to a significant minority of the population, that the Appellant took significant issue with during the course of the
hearing before us for the following reasons. First, it was submitted that this could not be relied upon because it was
an obiter dicta comment (because in fact the conditions considered in Sudan were those of the majority of the
population), expressed in a minority judgement (not expressly endorsed by Lord Bingham, Baroness Hale or Lord
Hoffmann) and therefore not binding upon the Upper tribunal.

28. Secondly, there has been no application of the proposition of a comparison with a significant minority of the
population in any Court or Tribunal since AH (Sudan).

29. Thirdly, the proposition was inconsistent with the _ratio in AH (Sudan) as articulated by Lord Bingham, with_
whom all agreed, which was to expressly approve of the test set out in Januzi without excluding or giving priority to
consideration of the applicant's way of life in the place of persecution or the conditions generally prevailing in the
home country.

30. Fourthly, the proposition is also inconsistent with the judgement of Baroness Hale in AH (Sudan) as it would
inevitably lead to a comparison with the very worst lives led by fellow nationals.

31. Fifthly, it is inconsistent with the UNHCR guidelines which were endorsed by Lord Bingham in Januzi as giving
_“valuable guidance” on a proper approach to assessing reasonableness._

32. Sixthly, it is inconsistent with the ratio of the Court of Appeal in AA (Uganda) v Secretary of State for the Home
Department [2008] EWCA Civ 579, specifically with the judgment of Buxton LJ who referred to some conditions in
the place of relocation as being unacceptable even if widespread in that place.

33. Finally, the proposition is inconsistent with the decision of the Upper Tribunal in FB (Lone Women – PSG –
internal relocation – AA (Uganda) considered) Sierra Leone _[2008] UKAIT 00090, in which it was reiterated that_
there are some forms or degrees of hardship which will be unduly harsh irrespective of how many others endure
them.

34. In response, Mr Singh relied upon the fact that Lord Brown's speech in AH (Sudan) had been expressly
approved by Lord Hope and also by Buxton LJ in AA (Uganda), who described Lord Browne's judgment at [42]
_“valuably explain[ing] some further aspects of the jurisprudence of undue harshness”._

35. As to what a significant minority would be, it was submitted by Mr Singh that significant minority was
simply something sufficiently great in number to be worthy of attention and the opposite to insignificant. In
reality, he submitted that the population of Kabul is a significant minority of the population in Afghanistan
and even a significant minority of the population of Kabul itself could still amount to a significant minority of
the population of Afghanistan as a whole.

36. We do not consider that Lord Brown's judgment in AH (Sudan) is either strictly obiter dicta or a minority
judgment such that it is not binding on the Upper Tribunal. This is because first, it was expressly approved
by Lord Hope; secondly, it is not inconsistent with the speeches of Lord Bingham or Baroness Hale in AH
(Sudan); and thirdly, in any event it was expressly approved by Buxton LJ in AA (Uganda) which is itself
binding on us.

37. When assessing the reasonableness of internal relocation, the language used in Januzi and AH
(Sudan) is of standards or conditions generally prevailing in the home country and of whether a person can
live a relatively normal life. There is of course no single standard or set of conditions which apply
throughout a country, but a range of examples of 'normal' or conditions which are experienced either in
particular parts of the country, or throughout it by groups of people. One can envisage for example, that
there will almost inevitably in any country in the world be differences between standards generally
prevailing in urban as opposed to rural areas, and between the capital or large cities and other areas. That


-----

is not to say that because the majority of the population live in, for example a rural area, the conditions in
urban areas could not said to be normal or include conditions generally prevailing in the home country. We
consider that Lord Brown's reference to a significant minority of the population is expanding on what is
contained in the speeches of Lord Bingham and Baroness Hale, and is simply a way of expressing what is,
in practice, required to identify standards or conditions generally prevailing in the home country, reflecting
that there is not a single standard or set of conditions which apply to a simple numerical majority of the
population throughout the entire geographical territory of a country.

38. In support of this, we rely on what was said by Buxton LJ in AA Uganda, which expressly endorses
Lord Brown's speech, including the significant minority point at his [42]:

_“16. Whilst Immigration Judge Coker did not have the benefit of the House of Lords in AH (Sudan) she_
_clearly had the jurisprudence that their Lordships confirmed in mind when she said, at the end of her §38,_
_that the situation facing AA was the same as that of many other young women living in Kampala, and_
_quoted Lord Hope of Craighead, who asked whether the claimant could live a relatively normal life judged_
_by the standards that prevail in his country of nationality generally: those standards, or the relevant_
_hardship, being as Lord Brown of Eaton-under-Haywood explained in AH (Sudan) that of a significant_
_minority in the country. The evidence before the AIT in this case did not reveal how widespread in the_
_context of Uganda as a whole are the conditions reported by Dr Nelson, and did not suggest that they_
_affect anyone other than young women. The factual case is therefore significantly different from that in AH_
_(Sudan) where slum conditions were widespread in Sudan, and affected everyone, men women and_
_children alike, and of all ages. Immigration Judge Coker should therefore have considered whether it was_
_appropriate to apply the test formulated by Lord Hope of Craighead to a case where the comparator or_
_constituency in the place of relocation is limited to persons who suffer from the same specific_
_characteristics that expose the applicant to danger and hardship in the place of relocation._

_17. There is, however, a further and more fundamental reason why it is difficult or impossible to apply the_
_jurisprudence of AH (Sudan) to the present case. There, the conditions in the place of relocation included_
_poverty, disease and the living of a life that was structured quite differently from that from which the_
_appellants had come in Darfur. It had been open to the AIT to hold that exposure to those conditions,_
_shared by many of the refugees' fellow-countrymen, did not amount to undue harshness. But the present_
_case is different. On the evidence accepted by the AIT, AA is faced not merely with poverty and lack of_
_any sort of accommodation, but with being driven into prostitution. Even if that is the likely fate of many of_
_her fellow countrywomen, I cannot think that either the AIT or the House of Lords that decided AH (Sudan)_
_would have felt able to regard enforced prostitution as coming within the category of normal country_
_conditions that the refugee must be expected to put up with. Quite simply, there must be some conditions_
_in the place of relocation that are unacceptable to the extent that it would be unduly harsh to return the_
_applicant to them even if the conditions are widespread in the place of relocation.”_

39. The test, or comparator for the purposes of assessing reasonableness, is as set out in AH (Sudan),
including as expressly set out by Lord Brown, with the caveat that there are some conditions that are
unacceptable even if widely suffered in the place of relocation. That particular point was confirmed and
expanded upon by the Upper Tribunal in FB (Lone women – PSG – internal relocation – AA (Uganda)
considered) Sierra Leone [2008] UKAIT 00090, which held at [39] that “[AA (Uganda)] is affirmation, in line
_with AH (Sudan) that [internal] relocation must be reasonable, in other words, that it must not have such_
_consequences upon the individual as to be unduly harsh for her. Inevitably, it will be unduly harsh if an_
_appellant is unable for all practical purposes to survive with sufficient dignity to reflect her humanity. That_
_is no more than saying that if survival comes at a cost of destitution, beggary, crime or prostitution, then_
_that is a price too high.”_

40. The final principle that therefore flows from AH (Sudan) is that when considering the standards or
conditions prevailing generally in the country of nationality, it is not necessary to establish that a majority of
the population live in those particular conditions, but only that a significant minority suffer equivalent
hardship to that likely to be suffered by the applicant on relocation. What follows is then a personalised
assessment of whether the applicant would be as well able to bear it ia most or whether those conditions
are in any event unreasonable for example because they involve crime destitution prostitution and the


-----

like. There is no requirement for a specific numerical, geographical or other qualification on what is a
significant minority of the population. That phrase carries its ordinary and natural meaning of something of
a sufficiently great number to be worthy of attention in the context of the population of the home country
and not insignificant and its application should be self-evident on an assessment of the factual evidence in
the majority if not all cases. If interpreted this way, there is no central inconsistency with Baroness Hale's
speech in AH (Sudan) which highlighted, inter alia, the concern that the comparator should not be with the
poorest of the poor in a particular country.

_Burden of Proof_

41. The burden of proof is on the Appellant to establish that he is a refugee. The degree of likelihood of
persecution needed to establish an entitlement to asylum is decided on a basis lower than the civil
standard of the balance of probabilities. This is expressed as a “reasonable chance”, “a serious possibility”
or “substantial grounds for thinking” in the various authorities. That standard of probability not only applies
to the history of the matter and to the situation at the date of decision, but also to the question of
persecution in the future if the Appellant were to be returned.

42. We received submissions from both parties as to the correct burden of proof on the test of
reasonableness for internal relocation. On behalf of the Appellant it was submitted that in accordance with
the UNHCR guidelines and the Michigan Guidelines on “The Internal Protection Alternative”, the burden is
on the decision-maker (both the Respondent and the First-tier Tribunal/Upper Tribunal) or in the alternative
that there was a shared burden between an applicant and the Respondent.

43. On behalf of the Respondent, Counsel relied on the Upper Tribunal's decision in AMM and others
(conflict: humanitarian crisis; returnees; FGM) Somalia CG [2011] UKUT 00445 (IAC), that where the issue
of internal relocation is raised, an applicant must make good on the submission that relocation would not
be reasonable.

44. As confirmed most recently by the Senior President of the Tribunals in Secretary of State for the Home
Department v SC (Jamaica) [2017] EWCA Civ 2112 (handed down after the hearing in the present appeal),
at 36, there is no burden of proof in relation to the overall issue of whether it is reasonable for a person to
internally relocate.

Evidence

45. We begin by identifying the experts who submitted written evidence and gave oral evidence before us,
setting out their relevant areas of expertise and our overall impressions of that evidence in general terms,
including as to the weight to be attached to their evidence generally.

46. We go on to consider below the evidence before us, both written and oral, first as to risk on return to
Kabul and secondly as to safety and reasonableness of internal relocation by setting out the current
situation in Kabul in particular, but also in relation to Afghanistan more widely. In line with the legal
framework set out above, we undertake a holistic assessment of the conditions generally prevailing in
Afghanistan to assess the reasonableness of internal relocation, but for practical reasons we separate out
and very broadly summarise the evidence in relation to particular topics sequentially which contribute to the
holistic assessment. The full list of evidence before the Upper Tribunal in this appeal is set out in Appendix
B which has been considered by us in its entirety and the absence of any express reference to it in the
summary included (which is of necessity a brief summary) should not be taken as an indication that a
particular piece of evidence or part of it has not been taken into account when reaching our conclusions set
out below.

**The Experts**

47. Three experts were instructed, each of whom submitted written reports and gave oral evidence before
us, on the basis of joint written instructions. Further to receipt of the written reports from each expert, the
Respondent asked further questions of each expert which were responded to by way of supplementary


-----

written reports. We set out initially our overview of the experts and their evidence and go on to consider
later the detail of that evidence by topic.

48. Dr Liza Schuster is a Reader in the Department of Sociology at the University of London and has been
employed as a researcher at both the University of Oxford and the London School of Economics. She has
visited and lived in Afghanistan for significant periods of time since 2011 (totalling around five years),
during which she has lived with Afghan families and in different settings in Kabul. Dr Schuster is one of
less than a dozen non-Afghans who live and work doing research in this field in Kabul. Since November
2016, Dr Schuster has been based in Kabul undertaking a research project studying migration decisions,
policy-making and migration culture based at the university there.

49. Of particular relevance for this appeal, Dr Schuster has conducted research in Afghanistan since 2012
as to the consequences of forced return for Afghan migrants and their families and the migration decisionmaking process. This involved a number of in-depth interviews with individuals and their families. In the
initial project, she interviewed 32 young men who had been deported and the families of 12 others in Kabul
and Pule Khumri. In total, Dr Schuster has spoken to approximately 120 people who have been returned
to Kabul against their will from EU states. She remains in touch with 12 of them, all of whom are no longer
in Afghanistan.

50. In 2014, Dr Schuster set up the Afghanistan Migrants Advice and Support Organisation (AMASO) with
Abdul Ghafoor, an Afghan man who was forcibly returned to Afghanistan following a failed application for
asylum in Norway. AMASO was initially supported by money from Norway to support others on return, for
example by accessing IOM packages and providing advice to those who didn't understand what was
happening. Dr Schuster trained Mr Ghafoor and provided initial funding, but he now runs the organisation
himself, funded from external grants. AMASO provides information to those returned to Afghanistan and to
those wishing to leave the country, explaining processes to them, options and support available, helping to
channel support and occasionally facilitating skype or video-conferencing for out of country appeals. It also
provides limited accommodation for up to 10 men in Kabul.

51. In the last three years, Abdul Ghafoor has been contacted by more than 300 individuals and Dr
Schuster remains in contact with him to discuss cases. Of that number, he has interviewed 180 people
and Dr Schuster was present for about 40 of those interviews. Of those 300 people, they have lost touch
with 75, about 65 have left Afghanistan and 40 remain in Afghanistan, of which 20 are in Kabul.

52. At present, Dr Schuster is following 18 families after return to Afghanistan, which includes a range of
ethnic tribes, people from both Kabul and the provinces, and a mix of people from different income groups
and family sizes. The project is looking at their plans, hopes and fears for the future.

53. Dr Schuster was specifically asked about living conditions and economic survival in Kabul and the present
humanitarian situation. In particular, she was asked to consider sources of independent support; employment
opportunities; levels of subsistence; destitution; shelter/accommodation and accessible amenities; and availability of
healthcare; as well as the situation for IDPs. Dr Schuster's report was based in part on fieldwork with those who
have been returned or their families and in part informed by first-hand experience of time in the country, hearing
comments, concerns and questions from Afghans.

54. Overall, we found Dr Schuster's evidence to be clear, comprehensive, well-researched from both
written sources and contacts in Afghanistan and based on her own in-depth experience from living in
Afghanistan, working with those who have been returned there and through AMASO. We attach significant
weight to Dr Schuster's evidence which we found to be of great value in understanding the socio-economic
conditions in Kabul. The only slight caution we have considered when assessing her evidence, which is in
no way a criticism of it, is to note that the returnees that she has had direct or indirect exposure to are a
very small number of those who had been forcibly returned to Kabul in the last five years, out of the
hundreds of thousands forcibly returned from Pakistan, Iran and the west in the last 12 months alone and
that those persons are likely to be in the most difficult situations to have sought assistance from AMASO
(because those returnees leading a relatively normal life without significant difficulties in Kabul would have
no need to seek such assistance).


-----

55. Dr Antonio Giustozzi is a Senior Visiting Professor at the War Studies Department of Kings College
London and was previously a visiting research fellow at the London School of Economics and Political
Science, Development Studies Institute. Dr Giustozzi has been working on issues in relation to
Afghanistan since 2003, at its peak he would spend about three months a year there, it is currently down to
a few weeks each year depending on work. He has had numerous books and articles published in relation
to Afghanistan and is a relatively frequent visitor to Afghanistan. The methodology used by Dr Giustozzi
depends on the nature of the project but in general is less reliant on written sources which there is a
shortage of, and relies more on interviews with the government, the opposition, civil society and opposition
parties. Dr Giustozzi has two researchers or research managers in Kabul and also works with Afghans
and experienced journalists for both contacts and information. He recognises that sources may have their
own agenda and he seeks out as many sources as possible to compare and test for reliability.

56. Dr Giustozzi has given expert evidence in a number of country guidance cases before the Upper
Tribunal and has broadly been found to be knowledgeable with reliable analysis of the issues, particularly
when his reports were limited to uncontentious facts rather than prepared on the basis of assumptions
about a particular appellant.

57. In this appeal, Dr Giustozzi was specifically asked about the Taliban and any risk to the Appellant from
them if he internally relocated to Kabul and whether there would be any sufficiency of protection from the
Taliban in Kabul.

58. Overall, we found Dr Giustozzi to be knowledgeable about the Taliban's activities and modus operandi
in Afghanistan based on his significant experience and work in this field. We found his written report to be
relatively brief with less explanation and reasoning for the conclusions reached than could have been
expected in the circumstances of this appeal. However, his oral evidence was much clearer, with more
express analysis and reasoning to support his propositions. We found that he was clear as to where
assumptions had been made based on his experience and knowledge and where there was (or was not)
supporting evidence to the views given. However, there were inconsistencies within Dr Giustozzi's
evidence which are difficult to reconcile, which we deal with in the specific evidence sections below and
there is a lack of support by other commentators for some of his conclusions (such as from Borhan Osman
(a political analyst in the Afghanistan Analysts Network who focuses on insurgent groups) on the existence
of the black list and use of targeted hit teams, recorded in the EASO Country of Origin Information Report
“Afghanistan – Individuals targeted by armed actors in the conflict” (December 2017)). Overall, we found
Dr Giustozzi to have given thorough evidence to which we also attach weight. We pause here to record
that we have attached significant weight to the EASO Country of Origin Information Reports, which are
thoroughly researched and comprehensive reports from a broad range of sources.

59. In some respects, there was an overlap between some of the evidence given by Dr Schuster and Dr
Giustozzi as to the need for or relevance of support networks in Kabul for employment and accommodation
purposes. We pause at this point to note that their evidence on this issue was not entirely consistent and
set out the detail below in the relevant sections.

60. Ms Emily Winterbotham is a Senior Research Fellow at the Royal United Services Institute in the
International Security Studies Department, prior to which she has been a researcher for the Afghanistan
Research and Evaluation Unit and as a Political Advisor for the Office of the European Union Special
Representative. She lived and worked in Afghanistan between 2009 and 2015 and since then has
returned for five weeks in total for various pieces of work. She has had a number of papers, articles and
reports published and has conducted research for a number of different bodies, including the UK Foreign
Office and Department for International Development.

61. Ms Winterbotham was specifically asked about the security situation in Kabul and to what extent this is
changed since the Upper Tribunal's assessment in 2012 in AK. In particular, she was asked about security
incidents, casualties and human rights abuses in Kabul and the willingness and/or ability of the authorities
to offer protection to the population. In addition, specific questions were asked about the risk of forcible
recruitment by anti-government elements; of kidnapping; of bonded or hazardous labour; and of violence,
including sexual violence.


-----

62. Overall, we found Ms Winterbotham's evidence to be of significantly less assistance and carry far less
weight than the other experts due to her approach to writing her report and giving evidence generally.
Although we accept that this was Ms Winterbotham's first experience of appearing in the Upper Tribunal as
an expert witness in a country guidance case, we find her approach to this task to be of concern. In
particular, it became apparent from her oral evidence that when writing her report, Ms Winterbotham
approached the task by using material that she already had available to her and had amassed over the
years in her work, rather than undertaking any specific further investigation into particular points or
checking for updates to or additional sources to the material that she did rely upon. The material that she
had available to her was collected for a range of different purposes over a period of time which preceded
her instructions and whilst not necessarily irrelevant to the questions asked of her, was not specifically
collected for this purpose nor was it necessarily up to date or the most relevant material on which reliance
could or should have been placed. In many instances, material relied upon dated back as far as 2008 and
2009, and a significant proportion of sources were from the period before AK was heard in the Upper
Tribunal. There was also an example of a draft article being relied upon as a source despite the fact it was
not the final version which was published.

63. It was also clear during the course of her oral evidence that there were inaccuracies in the footnotes in
Ms Winterbotham's report and that she had significant difficulty identifying whether her evidence was her
own opinion or whether sourced from other evidence (both in the written report and in oral evidence).
Where there was a claimed source, some were wrongly identified in the footnotes and many were not
specifically or even generally identified at all for various reasons which were unexplained on the face of the
report and at best only partially explained in oral evidence. Further, there was at least one instance where
it was not clear whether a source was an editorial or a news story. This is in contrast to Dr Giustozzi's
evidence during which he could identify sources (with sufficient generality to know the organisation and
level of person within it, even if not by name) and identify where his evidence was based either on
particular source material or his own conclusions.

64. In some parts, Ms Winterbotham also accepted in oral evidence that risks based on particular
characteristics (such as age, which she referred to as her nuance on the facts of this case further to reports
in which the conclusions were much broader, for example being applicable to men of any age) in parts of
her report were included because they were the particular characteristics of this Appellant, rather than
because there was any supporting evidence or reasoning for that being separately identified as a risk or
relevant characteristic. That approach is particularly unhelpful in the context of a country guidance case
where general guidance is to be given applicable to many more people than this individual Appellant and
was of particular concern when this was not clear on the face of her written report. Further, terminology
used in the report was not defined, and used interchangeably, for example, there was a lack of clarity on
whether a reference was being made to an IDP or to a returnee, or both. It was accepted that an IDP was
distinct from a returnee but there were examples of Ms Winterbotham answering questions about an IDP
by talking about returnees.

65. This approach to giving expert evidence in a country guidance case falls below the standards set out
in paragraph 10 of the Senior President's Practice Direction No 10 (2010) (set out in full in Appendix D) and
the decision of the Upper Tribunal in MOJ and Others (Return to Mogadishu) Somalia CG _[[2014] UKUT](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DDJ-W7M1-F0JY-C2YF-00000-00&context=1519360)_
_[00442 (IAC), which we would have expected and consequently significantly reduces the weight which we](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DDJ-W7M1-F0JY-C2YF-00000-00&context=1519360)_
have attached to the evidence as we are not persuaded that it is comprehensive or up to date. For the
reasons set out above, we have approached Ms Winterbotham's evidence with caution.

66. However, we do acknowledge Ms Winterbotham's extensive experience of living and working in
Afghanistan as well as her detailed knowledge of specific areas of work that she has been involved in and
we do take her evidence into account for these reasons.

**Evidence on risk**

**_Risk from the Taliban_**


-----

67. Before setting out the evidence, primarily from Dr Giustozzi, of the specific situation in Kabul, we set
out the evidence (also primarily from Dr Giustozzi) as to Taliban operations and priorities more generally
for background and context.

68. Dr Giustozzi gave evidence as to the sophisticated structure of the Taliban who have significant
manpower and financial resources. The Taliban is of the view that they are the legitimate government of
Afghanistan and seek to establish their own regime there with shadow governments and departments,
albeit with a decentralised structure involving multiple centres of power and a weak hierarchy. In some
areas where they are in control (perhaps 40 to 50 districts out of 318 in Afghanistan), the Taliban have set
up a real government, including appointing a mayor, employing people to run basic city administration and
setting up courts. In contrast where they are not in control of an area, the Taliban operate underground.
The Taliban have extensive physical infrastructure and staff both in Afghanistan and abroad and the total
manpower exceeds 200,000 men (including paid in support elements), of which 150,000 are fighters
(60,000 members of full time mobile units, the remainder are local militias) and on top of that number Dr
Giustozzi estimates there would be a few hundred thousand sympathisers and unpaid supporters. The
Taliban raise revenue through tax on economic activity as well as raising money from external
organisations and there are estimates that they have a budget of between $1.5 and $2 billion a year from
these sources.

69. Dr Giustozzi describes the decentralised structure of the Taliban as including five or six Shuras (one,
that of Mullah Rasul in western Afghanistan is set apart from the others) which are autonomous centres of
power, away from a central leadership and who operate on their own authority. There are Military
Commissioners at provincial level. There are 10 districts in each province and within those districts there
are individual Taliban commanders. The EASO Report “Afghanistan – Individuals targeted by armed
actors in the conflict” refers to a single Shura (the Rahbari Shura, also commonly referred to as the Quetta
Shura) and to an ongoing decline in the provincial and district structures.

70. The Taliban have dedicated units at the provincial level (at least one in each province), with a team of
20 or so Taliban intelligence operatives tasked with hunting down and executing collaborators. In Kabul,
the Taliban have two separate networks. The first is dedicated to conflicts operations, for example fighters
attacking high-profile targets. The structure of this network is insulated from other Taliban structures for
security reasons to prevent infiltration or complex attacks being compromised. The second network
focuses on collection of intelligence and routine targeting of wanted individuals, for example two-man
assassination teams, planting mines on cars and other small-scale attacks. Dr Giustozzi referred to claims
that there were a few hundred people in such networks, including those providing support such as safe
houses and intelligence. Those who carry out specific attacks are normally from outside of Kabul, often
coming from Pakistan, being brought into the city to be deployed a few days before a planned attack. The
EASO report “Afghanistan – Individuals targeted by armed actors in the conflict” included evidence from
other sources casting doubt on the existence of such specific dedicated units operating.

71. Dr Giustozzi's oral evidence was that these dedicated units each establish their own targets based on
priorities and available intelligence, albeit his written report referred to evidence from Judge Safi (a Taliban
Judge interviewed by one of Dr Giustozzi's researchers on 23 June 2016) that priorities were set by the
military leader of each province. His evidence was however consistent on the highest priority being those
who posed the greatest threat to the Taliban - senior serving government officials, the security services
and spies. At a lower priority level Dr Giustozzi referred to deserters and collaborators although not
necessarily in that order, depending on how you defined both. There are two types of deserters, those who
simply left or quit the Taliban (such as for personal reasons like a sick family member) and those who
defected to the government, who would be seen as a collaborator. The latter being more serious but there
was a need to discourage anyone leaving and a concern that someone may become an informant when
they left. Collaborators could include all those who defy Taliban rules or are seen to be in-line with the
government. Collaborators would include all security forces, government authorities, foreign embassies,
the UN, NGOs and anyone passing information to the government about the Taliban. These collaborators
could number several hundred thousand people and Dr Giustozzi accepted that the Taliban do not have
the resources to possibly individually follow up on all of them.


-----

72. Although successful targeting by the Taliban of high-profile targets is their highest priority because of
the impact of such attacks, it is more difficult to achieve this given that they are the best protected and it
involves larger teams of people, many of whom would be killed in the effort. Dr Giustozzi explained that as
the Taliban believe they are the legitimate government, they need to demonstrate to the public that they
are the legitimate authority whose goals and regulations are to be respected. It is therefore considered
necessary to also take action against a person of low-level interest when the opportunity arises rather than
named individuals because of the Taliban's need to show that they are serious about sentencing people,
enforcing their regulations and because it helps to scare people leading to the collapse of the government.
In these cases, who is killed is less important than the numbers killed, with any assassinations still making
the headlines.

73. The Taliban introduced a new system from around 2006, which has been quite mature from 2010, for
the identification, warning, trying and sentencing of persons before a sentence is carried out. Those who
are targeted are limited to those who have already been sentenced by a Taliban court. Once a sentence
has been imposed it remains forever until carried out. It is only those who have been warned and
sentenced who can legitimately be targeted by the Taliban. However, EASO in their report “Afghanistan –
Individuals targeted by armed actors in the conflict” refer to evidence of violence and targeting based on
personal or local disputes outside of this system.

74. Dr Giustozzi describes a “blacklist”, containing the names of around 14,500 people who are wanted by
the Taliban. He has never seen such a list, nor does he have clear or comprehensive details on the nature
and use of such a list and accepts that he has been unable to corroborate information about the blacklist.
The EASO report “Afghanistan – Individuals targeted by armed actors in the conflict” also finds no specific
evidence to support the existence of or details about the blacklist, although at least one source was also of
the view that the Taliban does keep a blacklist of priority targets and another that local commanders may
have their own lists but no centrally organised list. Dr Giustozzi is of the view that the blacklist does exist
because of the information to that effect he has had from the Taliban, because of the known warnings
given to people and because it would be logical to maintain such a list.

75. Dr Giustozzi did not know whether there was a single or master blacklist but referred to a central
information hub in Peshawar, with connected small hubs in Afghanistan and he presumed that the Taliban
would make use of the computers they are known to have to maintain the blacklist, by using their
sophisticated infrastructure in Pakistan, Iran and Afghanistan. Information about the blacklist would be
passed via a courier system, with messages being carried by individuals using memory or writing.

76. In his written report, Dr Giustozzi stated that information about collaborators is exchanged between all
components of the Taliban, excluding the Shura of Mullah Rasul (or Rasool, both spellings are used, who
has its own list) but in oral evidence stated that it was unknown whether the Shuras coordinate on such
matters. A complete copy of the blacklist would be available to all of the Shuras but not at a provincial or
lower level. Instead, a Shura would only share names of people on the list who they thought were in their
province with the Military Commissioner responsible for that area. The Military Commissioner would then
decide what names to share at the district level, which would then in turn be shared with individual
commanders in relation to people that intelligence showed were within that person's particular area. As a
result, an individual commander would only likely to have a few names from the blacklist, the full list being
unmanageable, a security risk and impractical to carry for use in printed form. Dr Giustozzi's evidence was
that the blacklist may be given to members of the Taliban and paid agents (who may get a version of the
list) but it is not likely to be shared with informers. Local Taliban may, with permission, have access to the
blacklist if a request for such access is justified, for example, to check whether a local suspect is wanted.

77. It is assumed that high profile individuals or those who pose a serious danger to the Taliban, such as
spies, are automatically on the blacklist as are wanted people, but for those at a lower level, they would
only be added if they had received two warnings from the Taliban (which would be sent to or left at the
address of the individual). An individual failing to comply with two warnings would then be sentenced for
the crime of collaborating with the enemy. The sentence takes the shape of a third letter or verbal
communication, passed on to the collaborator or somebody close to him. A sentence implies that the
individual has been added to the blacklist Not all of those who received warnings would be added to the


-----

blacklist, as it allowed people an opportunity to change or repent, or to make deals with the Taliban
instead. A person could not be targeted simply because they were a relative of a person who is a target or
a threat to the Taliban. Dr Giustozzi assumed that the details included on the blacklist would be a person's
name, father's name and place of birth as that is the usual way to identify people in Afghanistan.

78. Dr Giustozzi's evidence on whether a person could be removed from the blacklist was that this was
possible only in one of two ways. First, by death and secondly, by contribution to the Taliban's cause in
such a way that the individual would be offered an amnesty. In his written report, he said that sentences
issued from 1996 onwards remained valid and would be implemented by the Taliban whenever possible
and that events a significant time in the past would not affect that. However, the likelihood of a particular
target being picked from the blacklist depends on the Taliban's operational environment and in oral
evidence, he stated that a person who had done something a long time ago and had a lower profile would
be a lower priority for the Taliban as they would be likely to pose a lesser risk of damage to them.

79. Dr Giustozzi's evidence described the increasing sophistication of the Taliban's intelligence operation
and ability to track down individuals, by reference to a significant number of informers, including agents
within the government and the intelligence services. He refers to government officials' belief referred to in
an article in 2011 in the Los Angeles Times that even in areas of weak Taliban presence the Taliban are
informed of everything that happens. Elders in Taliban villages have also confirmed the existence of
informers in the local area but who cannot be identified specifically. The evidence that Dr Giustozzi relies
on from Judge Safi is that the Taliban are able to monitor who enters Afghanistan that their intelligence has
people at Kabul airport and elsewhere who provide regular reports about new arrivals. Arrivals in small
places are easily spotted, but less so in large cities and people living alone tend to attract attention
because it is highly unusual to live alone in Afghan society.

80. In terms of targeting of wanted individuals, Dr Giustozzi's evidence was that intelligence is used to
track a person's movements and information is shared if there is specific intelligence that a person has
moved into a different province or area or that such movement is expected so that a temporary checkpoint
can be erected by the Taliban to stop someone. The Taliban uses temporary checkpoints in such cases
on the roads out of Kabul to identify specific targets based on specific intelligence about the type of car
they would be travelling in and the time of travel. These checkpoints may also have the benefit of stopping
other individuals who have not been specifically targeted but who, for example, look nervous or are
dressed in a particular way such as to arouse interest or adverse attention.

81. Despite this background primarily from his written report and his conclusions set out therein, in oral
evidence Dr Giustozzi was of the view that unless references were sought specifically from the Appellant's
home village (which would be required for stable employment or formally rented accommodation, not
accommodation in a dormitory or casual labour), no one would know the Appellant's whereabouts and
there would be very little chance that the Taliban would even know he was in Afghanistan. Taliban
informers in Kabul would not necessarily know that the Appellant was wanted (even if he was on the
blacklist).

82. The EASO report “Afghanistan – Individuals targeted by armed actors in the conflict”, relying on an
interview with Abubakar Siddique (a senior correspondent specialising in coverage of Afghanistan and
Pakistan and editor of 'Ganhara' website), states that the list of people for whom the Taliban will invest
resources and planning to track and target into the major cities is limited to between a few dozen and up to
a hundred persons. Other than targeting involving personal enmities, rivalries or disputes, Mr Siddique's
view was that the Taliban would probably not target lower level individuals or their family members after
relocating to the cities.

83. As the Respondent accepts that there is no sufficiency of protection from the Taliban in Kabul, we do
not detail in this decision Dr Giustozzi's evidence reaching the same conclusion.

**_Risk of recruitment to an armed group_**

84. In the Afghan context, there appears to be no agreement about the meaning of forced recruitment to
armed groups, instead commentators refer to mobilisation of fighters and agreement within social


-----

structures for recruitment, albeit with the use of coercion, duress or force in some cases. There is also the
possibility that the term forced recruitment necessarily applies to children because they're not old enough
to make an informed choice as opposed to a more literal use of force for their recruitment.

85. Dr Giustozzi and Ms Winterbotham gave evidence as to the traditional method of Taliban recruitment,
which works through family, tribal and ethnic local religious networks, also using local specialised cells in
Afghanistan and significant recruitment pools in Pakistan. Recruitment would usually be because
someone is a member of a tribal or kinship group and is instructed to join by elders. Recruitment is not
necessarily on an ideological basis but can be through incentives for individuals (such as protection, cash,
motorcycles, mobile phones and credit for them) as well as through coercion or direct threats. A person is
most likely to be recruited through tribal, clan or family ties. Ms Winterbotham accepted that there was
limited evidence of armed groups using threats and coercion in order to force individuals to join them in
Kabul and limited evidence of this elsewhere as well, albeit noting that there was a lack of monitoring
information in Afghanistan which meant the absence of documented instances should not itself justify the
conclusion that they did not occur.

86. In the alternative to forced recruitment or mobilisation, Ms Winterbotham gave evidence as to
individuals feeling compelled to join armed groups, not limited to the Taliban. She referenced a significant
body of work relating to both developed and developing countries on radicalisation and recruitment by
armed groups albeit noting that the theories do not necessarily apply in the context of different countries or
conditions. Overall, she stated that whether a person feels compelled to join an armed group is not a linear
assessment but a complex nonlinear process for which it is not possible to profile individuals. Instead
there are a number of factors or drivers for recruitment which may be relevant, including social and
economic factors (such as lack of social structures, lack of housing, lack of employment, issues of
achieving manhood and desirability of marriage), economic incentives, status for an individual and an
opportunity to seek glory.

87. There is also the possibility of individuals joining armed groups for reasons of protection, or conversely
for honour and revenge in the context of the Pashtunwali code of honour. Dr Giustozzi argues that the
importance of revenge should not be overstated given that revenge is most frequently directed at an
individual, extending in some cases to male kin but not more general targets.

88. In addition to the above, Ms Winterbotham accepted that a person could also choose to join the police
or security forces in Afghanistan for similar reasons, albeit this is a less attractive option given the
significant casualties suffered from these groups, that salaries offered are lower than those from militant
groups and recruitment into the government forces requires a high degree of vetting.

89. Ms Winterbotham's evidence was that there is greater evidence about children being at risk of forced
recruitment than adults, but there was a continuing vulnerability for teenagers and those into their 20s and
30s who are not married, extending to a general risk for able-bodied men of any age. In her oral evidence,
Ms Winterbotham was unable to substantiate her view that risk is not significantly reduced by increasing
age per se and that able-bodied men are all at risk of recruitment into an armed group.

**_Risk due to westernisation_**

90. The EASO Country of Origin Information Report “Afghanistan – Individuals targeted under societal and
legal norms” (December 2017) includes a specific section on targeting of Afghan returnees on the basis of
'Westernisation' following time spent in Europe or Western countries. Their broad conclusion on this is as
follows:

_“Documented instances of individual targeting of returning Afghans on the basis of 'Westernisation' due to_
_having travelled in or lived in Europe, holding Western ID documents, or adopting ideas that seem to be_
_'un-Afghan', 'Western' or 'European' following time spent outside Afghanistan were scarce. Varying_
_descriptions by sources indicated that there were 'occasional reports' of alleged kidnapping and targeting,_
_or, that not everyone is at risk, but it 'does happen,' though the scale and prevalence is 'difficult to quantify',_
_or, that targeting does not specifically occur because of having sought asylum or having travelled to_
_Western countries.”_


-----

91. Dr Schuster, in oral evidence stated that after a person has been out of Afghanistan it would be
relatively easy for them on return to change their physical appearance so as not to stand out. However, it
would be more difficult to change values and attitudes that have been learnt and developed whilst away
from Afghanistan. A person would have to monitor and self-censor their behaviour on return. An
individual's capacity to self-censor would depend upon their maturity, their mental health and their ability to
be astute about the social surroundings in Afghanistan, being able to pick up on what it is inappropriate to
say and to do.

92. Dr Schuster also referred to the assumptions that people make about those who have been away from
Afghanistan about their lifestyle, and question whether they have retained their Islamic faith, drink alcohol,
or have relationships with women for example. The EASO report “Afghanistan – Individuals targeted under
societal and legal norms” also refers to perceptions of those on return, including concern that returnees
fear being labelled by insurgents as spies and a perception by others that an individual would be wealthy
having accumulated funds abroad with the consequent fear of kidnapping for ransom for this reason.
There is however very limited evidence of kidnapping other than isolated cases.

93. The EASO report “Afghanistan – Individuals targeted under societal and legal norms” does not find
any agreement from its sources of a collective or consistent attitude toward 'Westernisation' in Afghan
society. There are references to broader Western influence on Afghan society in recent decades due to
the international military presence and the increasing popularity, particularly amongst young Afghans,
towards Western trends and influences (such as fashion, entertainment and tattoos). There are however
strong conservative views held amongst individuals, family groups and wider communities.

94. Both Dr Schuster and the EASO report “Afghanistan – Individuals targeted under societal and legal
norms” refer to the risk of someone saying the wrong thing at the wrong time, even in Kabul (which
generally has a higher tolerance for westernisation than rural areas) which would not necessarily, but may,
cause difficulties and because a person has returned from the West could be used against them with
accusations made. Further, the sources both refer to the need for guidance on Afghan cultural norms to
those who have been absent from the country and the importance of family, friends or connections to
support their understanding of the limits and boundaries of societal norms and behavioural expectations.

**_Other Risks_**

95. There was some, albeit limited, evidence before us of wider risks to individuals in Afghanistan but we
do not set out the detail of such potential categories other than to mention, for example by reference to the
EASO Country of Origin Information Report “Afghanistan – Individuals targeted by armed actors in the
conflict” (December 2017), that there is some evidence of risk to individuals involved in education,
healthcare, journalism, the security forces, government workers and to Shia Muslims.

96. Ms Winterbotham, consistently with the Samual Hall Report in 2013 “Old Practice, New Chains:
**_Modern Slavery in Afghanistan” also refers to risks of sexual exploitation and trafficking, particularly for_**
children and youths in large, impoverished families, especially when the family is in debt. Girls are most
vulnerable between the ages of 11 and 19 years old and younger men, who are most vulnerable between
the ages of 11 and 15. In most cases, exploitation is done through the family, by deception or otherwise.

97. In the context of the particular characteristics of the Appellant in this appeal and the country guidance
issue of internal relocation to Kabul, together with only very limited evidence before us on these wider risk
categories, we consider that it is not appropriate for us to make any general findings in the present country
guidance case on any of these matters as they are outwith the scope of this appeal.

**Evidence relevant to assessing the option of internal relocation**

**_The UNHCR position_**

98. The UNHCR Eligibility Guidelines for assessing the international protection needs of asylum-seekers
from Afghanistan, dated 19 April 2016, provides in relation to the option of internal relocation, so far as
relevant to the present case, as follows:


-----

_“An assessment of the availability of an internal flight or relocation alternative (IFA/IRA) requires an_
_assessment of the relevance as well as the reasonableness of the proposed IFA/IRA. An IFA/IRA is_
_relevant only if the proposed area of relocation is practically, safely and legally accessible, and if the_
_individual concerned would not be exposed to a further risk of persecution or serious harm in the area of_
_relocation. In assessing the relevance of an IFA/IRA for Afghan applicants, the following considerations_
_must be taken into account:_

(i) _The volatility and fluidity of the armed conflict in Afghanistan in terms of the difficulty of identifying_
_potential areas of relocation that are durably safe; and_

(ii) _The concrete prospects of safely accessing the proposed area of relocation, taking into account the_
_risks associated with the widespread use of IEDs and landmines throughout the country, attacks on fighting_
_taking place on roads, and restrictions on civilians' freedom of movement imposed by AGE's._

_…_

_Where the applicant has a well-founded fear of persecution at the hands of a non-State agent, the ability of_
_the agent to pursue the applicant to the area of proposed relocation needs to be assessed, as well as the_
_ability of the State to provide protection in that area. Where the agent of persecution is an AGE, evidence_
_about AGEs' capacity to carry out attacks outside the area under their effective control needs to be taken_
_into account._

_…_

_Whether an IFA/IRA is reasonable must be determined on a case-by-case basis, taking fully into account_
_the security, human rights and humanitarian environment in a prospective area of relocation at the time of_
_the decision. In particular, the poor living conditions and precarious human rights situation of Afghans who_
_are currently internally displaced in Afghanistan are relevant considerations that need to be taken into_
_account in assessing the reasonableness of a proposed internal flight or relocation alternative. UNHCR_
_considers that a proposed IFA/IRA is reasonable only where the individual has access to (i) shelter, (ii)_
_essential services such as sanitation, healthcare and education; and (iii) livelihood opportunities._
_Moreover, UNHCR considers an IFA/IRA is reasonable only where the individual has access to a_
_traditional support network of members of his or her (extended) family or members of his or her larger_
_ethnic community in the area of prospective relocation, who have been assessed to be willing and able to_
_provide genuine support to the applicant in practice._

_UNHCR considers that the only exception to the requirement of external support are single able-bodied_
_men and married couples of working age without identified specific vulnerabilities. Such persons may in_
_certain circumstances be able to subsist without family and community support in urban and semi-urban_
_areas that have the necessary infrastructure and livelihood opportunities to meet the basic necessities of_
_life and that are under effective Government control. Given the breakdown in the traditional social fabric of_
_society caused by decades of war, mass refugee flows and internal displacement, a case-by-case analysis_
_will, nevertheless, be necessary.”_

99. The Human Rights Watch Report “Pakistan Coercion, UN Complicity: The Mass Forced Return of
Afghan Refugees”, (February 2017) records the UNHCR, in December 2016, cautioning against returning
failed Afghan asylum seekers to Kabul on an internal flight alternative basis for the following reasons:

_“Kabul faces serious pressures on housing and services, due to years of primary and secondary population_
_displacements … resulting in large-scale movements to the city, together with a natural (non-conflict-_
_related) process of urbanization from rural areas. In 2016, the situation was made worse by the fact that_
_more than 25 percent of Afghan returnees from Pakistan went to Kabul. This has immediate_
_consequences for the assessment of Kabul as a proposed internal flight alternative, in particular with_
_regards to the [criterion] of “reasonableness.” The considerations presenting in the April 2016 [Eligibility]_
_Guidelines remain relevant for assessments of Kabul as an internal flight alternative. In the context of a_
_dramatic increase in competition for access to scarce resources, the availability of an IFA will need to be_
_considered on a case-by-case basis, taking into account the particular circumstances of the individual_
_applicant ”_


-----

**_The security situation_**

100. The Human Rights Unit of the United Nations Assistant Mission in Afghanistan (UNAMA) is
mandated by UN Security Council Resolutions to monitor and report on the situation of civilians in the
armed conflict in Afghanistan, particularly on civilian casualties. UNAMA has produced a number of midyear and annual reports on the Protection of Civilians in Armed Conflict in Afghanistan since 2009.

101. Before setting out the content of the most recent reports, it is important to bear in mind the
methodology used by UNAMA when compiling the data. The incidents that are included of civilian
casualties include wherever possible on-site investigations and are compiled from information obtained
directly by UNAMA. For verification of each incident involving a civilian casualty, UNAMA requires at least
three different and independent types of sources. If UNAMA are not satisfied with the quantity or quality of
information concerning an incident, it will not consider it is verified and unverified incidents are not included
in the report. For these reasons, UNAMA does not claim that the statistics presented in their reports are
complete and they acknowledge possible underreporting of civilian casualties given the limitations inherent
in their operating environment.

102. Dr Schuster reiterated a commonly held view that because of the strict methodology employed by
UNAMA, the number of civilian casualties were likely to be underreported. This was also likely to be
because those who have been killed will normally be buried within 24 hours and there is no follow-up on
those who are seriously injured who may die at a later date and not all deaths are reported. She gave an
example of official data from a recent attack on a mosque which stated that 35 to 37 people had died,
however she spoke to a taxi driver who lost four members of his own family and 30 who were killed in the
same attack were buried on the same day at the same cemetery he was at, suggesting casualties were
much higher. Dr Schuster's view, based on experience as well as interviews with senior advisers to the
justice sector support programme in the Ministry of Justice, a lieutenant colonel in the Army and a
journalist, is that casualty numbers given by the authorities in Afghanistan are deliberately kept as low as
possible to reduce panic amongst the public.

103. The UNAMA mid-year report for 2017 shows armed conflict continuing to cause severe harm to
civilians across Afghanistan, killing and injuring civilians at levels similar to the same period in 2016 (1
January to 30 June). In the first half of 2017, there were 5,243 documented civilian casualties, comprising
1,662 deaths and 3,581 injured. The key trends observed were that there was an overall decrease in
civilian casualties from ground engagement and increases in civilian casualties from improvised explosive
devices (IEDs), with 40% of civilian casualties resulting from the latter in civilian populated areas. The
majority of civilian casualties from IEDs occurred in the context of suicide and complex attacks. The
second leading cause of civilian casualties remained ground engagements but there was a 10% decrease
in civilian casualties from this compared to the same period in 2016.

104. The majority of civilian casualties, 67%, were attributed to Anti-Government Elements (“AGEs”)
(made up of 43% Taliban, 19% unidentified AGEs, 5% Daesh/ISKP); followed by 18% attributed to ProGovernment forces; 10% jointly attributed (for example in cross-fire incidents) and 5% other (for example
from detonation of explosive remnants and cross-border shelling and shooting).

105. In relation to Kabul specifically, _“Kabul province continued to record the highest number of civilian_
_casualties, mainly in Kabul city. Of the 1,048 civilian casualties (219 deaths and 829 injured) documented_
_in Kabul province, 94 per cent resulted from suicide and complex attacks carried out by Anti-Government_
_Elements in Kabul city.”  This was a 26% rise compared to 2016 and 70% of all civilian casualties from_
suicide and complex attacks occurred in Kabul city, most of whom resulted from a relatively small number
of incidents.

106. Although the casualty figures are highest in Kabul (city and province) this is also the area with the
highest population and highest density of population. Population estimates for Kabul city range between
3.5 and 7 million people. The Respondent, assuming that the total civilian casualties for 2017 based on
figures from the UNAMA mid-year report are 2,100, submits that that shows a very low percentage of the
population affected. Even if there were 5000 civilian casualties in a year, based on a population of 4.5
million that still equates to less than 0 01% of the population affected


-----

107. The number of security incidents per province varies considerably, with southern regions being
historically being the worst affected. The “EASO Country of Origin Information Report, Afghanistan:
Security Situation” (December 2017) sets out in the two maps reproduced at Appendix C, first, the security
incidents per province from September 2016 to May 2017 and in the second map, the number of security
incidents compared to population for the same period. On neither measure is Kabul the worst affected
province and as measured by incidents per 1000 inhabitants, it is one of the least affected provinces.

108. Following the mid-year report in 2017, UNAMA provided a shorter quarterly report to 30 September
2017 which showed an overall slight decrease of 6% in the number of civilian casualties compared to the
same period last year, with 8019 in total (2640 deaths and 5379 injured).

109. UNAMA's observations in their mid-year report for 2017 are as follows:

_“The armed conflict continued unabated in Afghanistan during the first six months of 2017. As in 2016,_
_sustained ground fighting between Anti-Government Elements and Pro-Government Forces in numerous_
_provinces across the country coincided with asymmetric attacks in villages, towns, and cities by Anti-_
_Government elements, mainly using indiscriminate tactics. Reflecting the extent to which the armed_
_conflict invaded the lives of Afghans countrywide during the first of the year, violence killed and maimed_
_civilians in nearly every conceivable setting of day-to-day life. Civilians lost their lives, limbs, sight or_
_suffered harm while inside of their own homes, travelling on public roads, attending classes, praying in_
_mosques, purchasing food, playing outside, working in offices, labouring in agricultural fields, visiting the_
_bank and lying in hospital beds._

_While this report documents extreme civilian harm throughout Afghanistan, the findings within can never_
_accurately portray the extent of human suffering endured by thousands of Afghan civilians affected by_
_conflict during the first half of 2017. Beyond the egregious cases of civilian death or injury highlighted in_
_this report, armed conflict changed the lives of countless civilians through displacement and damage to_
_homes, schools, and medical clinics – amongst other facilities – all of which restricted access to education,_
_healthcare, and economic opportunities, including gainful employment. The psychological trauma imposed_
_on members of the civilian population and local communities by the loss of family and friends in violent and_
_unpredictable circumstances, and by the ever-present risk of becoming civilian casualties themselves,_
_must not be understated._

_The changing composition of civilian casualties during the first six months of 2017 raises serious concerns_
_regarding civilian protection. Despite a decrease in civilian casualties in ground engagements, including a_
_substantial decrease in the number of civilian deaths caused by ground fighting between Anti-Government_
_Elements and Pro-Government Forces, civilian casualty numbers remained at similar levels to the first half_
_of 2016 with increases in child deaths and women casualties._

_Anti-Government Elements continue to display contempt for civilian lives by using indiscriminate tactics_
_and perpetrating attacks deliberately targeting, killing and injuring civilians in violation of international_
_humanitarian law. Attacks targeting civilian Government workers, tribal elders, religious leaders, and_
_civilians perceived to support the Government continued. Even where Anti-Government Elements_
_appeared to direct attacks at non-civilian objects, indiscriminate and disproportionate tactics were often_
_used – principally the detonation of explosive weapons in civilian-populated areas. This meant that Afghan_
_civilians often bore the brunt of such attacks, regardless of the target. Such methods also generated_
_disproportionate civilian casualties on numerous occasions.”_

110. The UNAMA 'Afghanistan Annual Report on Protection of Civilians in Armed Conflict: 2016' followed
a mandate in the same terms as the mid-year report in 2017 and the same methodology. In summary, that
report concluded:

_“Conflict-related violence exacted a heavy toll on Afghanistan in 2016, with an overall deterioration in_
_civilian protection and the highest total civilian casualties recorded since 2009 when UNAMA began_
_systematic documentation of civilian casualties. Against a backdrop of protracted ground fighting, the_
_battlefield permeated civilian sanctuaries that should be spared from harm, with suicide attacks in_


-----

_mosques; targeted attacks against district centres, bazaars and residential homes; and the use of schools_
_and hospitals for military purposes._

_Between 1 January and 31 December, UNAMA documented 11,418 civilian casualties (3,498 deaths and_
_7,920 injured) …_

_In 2016, UNAMA documented record numbers of civilian casualties from ground engagements, suicide and_
_complex attacks and explosive remnants of war, as well as the highest number of civilian casualties_
_caused by aerial operations since 2009. Increases in civilian deaths and injuries from these tactics drove_
_the overall three per cent rise in civilian casualties, while civilian casualties from improvised explosive_
_devices and targeted and deliberate killings decreased.”_

111. We have also been provided with copies of the annual reports from UNAMA for 2011, 2012, 2013,
2014, 2015 and the mid-year report for 2016. The overall trend shown in these reports is that the number
of civilian casualties are increasing year on year (since UNAMA records began in 2009) with significant
increases in 2013 and then year on year from 2014. The earlier reports show significant increases in
civilian casualties due to ground engagements, albeit this trend appears to be reversing in the two most
recent reports set out above, with IEDs becoming the reason for the majority of civilian casualties in the
last 12-18 months. The earlier reports also show disproportionate increases in civilian casualties of women
and children which are not highlighted in the same way in the most recent reports.

112. The Appellant has produced a schedule of major security incidents causing or risking civilian
casualties in Kabul from 1 January 2016 to 17 November 2017 (compiled from various sources and news
articles/reports, most of which were in evidence before us). That document provides an overview of 141
incidents, the casualty figures and detail of the incidents where known from news or other sources. That
schedule refers to many complex attacks, the majority of which are targeted attacks on politicians,
members of the military, security or police forces, mosques (in particular Shia mosques), NGOs or involve
international actors either as part of embassies or individuals. There are in almost every example
additional deaths and casualties from those in the immediate vicinity in addition to those specifically
targeted. The list also includes a not insignificant number of bomb or rocket attacks without specific
targeting and also a smaller number of incidents which could be described as arising from a criminal
situation such as armed robbery. The incidents recorded involve casualties ranging from several hundred
(the largest being the attack on 31 May 2017 which killed 92 and injured 491) down to a single person or
few individuals.

113. The EASO Report “Afghanistan: Security Situation” states that there were 290 security incidents in
Kabul City between 1 September 2016 and 31 May 2017. These included 24 incidents of violence
targeting individuals; 23 of armed confrontations and airstrikes; 63 explosions; 49 involving security
enforcement; 112 non-conflict related incidents and 19 other incidents.

114. The Appellant has also produced various maps which show that the incidents set out in their
schedule of major security incidents (referred to above and produced from the same sources where
location was identified) evidenced before us are geographically spread around Kabul city rather than being
concentrated in a particular area or areas.

115. In addition to the security situation set out above, there was also some evidence before us of not
insignificant levels of crime in Kabul, but a lack of detail of particular crime rates or risk and nothing that
suggested there was any greater risk of being a victim of crime for one group of people (such as returnees)
compared to any other resident of Kabul.

**_Overview of conditions in Afghanistan_**

116. Before setting out the evidence in relation to specific indicators relevant to the reasonableness of
internal relocation and in relation to Kabul specifically, we note for context and an overview, the following
summary of the situation in Afghanistan from the United Nations Office for the Coordination of
Humanitarian Affairs (“UNOCHA”) in December 2017, as set out in its report “Humanitarian Needs
Overview 2018”:


-----

_“Afghanistan is one of the world's most complex humanitarian emergencies, characterised by escalating_
_conflict, causing over one million people to be living in new and prolongued displacement. In 2018, 3.3_
_million people will need life-saving assistance. Violations of international humanitarian and human rights_
_law are commonplace, with frequent reports of summary executions, kidnappings, and attacks on civilian_
_infrastructure. … Civilian casualties are at the highest levels seen with 8,019 documented in the first nine_
_months of the year. Two thirds of these civilian casualties were women and children._

_Amidst growing signs that what was once a low intensity conflict has now escalated into a war, the UN_
_strategic review of 2017 reclassified Afghanistan from a post-conflict country to one in active conflict. …_

_Sustained levels of displacement – 360,000 people have been internally displaced so far during 2017 –_
_combined with ongoing returnee influxes of more than 546,000 have also had a profound impact in parts of_
_the country; overloading health facilities, schools, depressing labour wages and increasing rents. …_

_… Conflict affected and returnee populations are also more likely to utilise negative coping mechanisms_
_such as early and forced marriage, child labour, and family separation. They are also likely to be exposed_
_to domestic and sexual violence and, even secondary and multiple displacement. Over 50 percent of_
_people displaced by conflict in Afghanistan have now been displaced twice or more, compared to just_
_seven percent five years ago._

_After four decades of conflict, there are huge economic and development challenges in the country, which_
_cannot be remedied by humanitarian aid. Approximately 39 percent of the population live below the_
_poverty line, an estimated 10 million people have limited or no access to essential health services, and as_
_many as 3.5 million children are out of school. … Some 1.9 million people are severely food insecure,_
_predominantly due to lack of or limited access to sustainable job opportunities, while 40 percent of all_
_children under the age of five are stunted. In total, the humanitarian community has identified that 8.7_
_million people have chronic needs which require longer-term systemic actions to address”_

117. It is to be noted that the approach in the UNOCHA “Humanitarian Needs Overview” has changed
significantly between the 2017 and 2018 report due to the reclassification of Afghanistan as one in active
conflict. This has led to the 2018 report focusing on acute needs arising from distinct drivers (including
conflict, natural disasters and cross border influxes) rather than chronic needs arising from years of
structural challenges and underdevelopment in Afghanistan.

118. For further context, the summary in the UNOCHA “Humanitarian Needs Overview 2017” (based on
the previous approach) included the following:

_“Afghanistan remains one of the dangerous, and most violent, crisis ridden countries in the world. The_
_continued deepening and geographic spread of the conflict has prompted a 13% increase in the number of_
_people in need of humanitarian assistance in 2017, now 9.3 million. ..._

_The country is facing increasing numbers of people on the move. In 2016 the conflict has led to_
_unprecedented levels of displacement, reaching half a million in November – the highest number recorded_
_to date. 56% of the displaced are children and face particular risk of abuse, and exploitation, as well as_
_interrupted school attendance and harmful child labour. Multiple forms of GBV, particularly early and_
_forced marriage, domestic, psychological, and sexual abuse are reported, affecting individuals in hosting_
_and displaced communities alike. Further, a lack, or loss of civil documentation, with difficulties in_
_obtaining documents outside of the province of origin, regularly results in hindered access to services for_
_considerable numbers of affected individuals._

_Recent estimates suggest over 9 million people have limited or no access to essential health services. …_
_Severe food insecurity is on the rise with 1.6 million people severely food insecure. 2016 nutrition surveys_
_show global acute malnutrition prevalence ranging from 10.9 to 20.7%. Severe acute malnutrition has_
_breached emergency thresholds in 20 of 34 provinces. 1.8 million people require treatment for acute_
_malnutrition, of which 1.3 million children are under five._

_Magnifying this crisis of forced displacement, 2016 saw the unprecedented return of some 600,000_
_registered refugees and undocumented Afghans from Pakistan. For the majority, return is triggered by_


-----

_shrinking asylum space and community acceptance, and the experience often abrupt and distressing._
_After more than 30 years living in Pakistan, many have arrived into an unfamiliar country with few_
_possessions, assets or social support networks.”_

119. As referred to in part in the extracts above, Afghanistan has experienced significant changes and
movement in its population since the beginning of 2016, which follows a period of over four decades which
has seen significant movement for conflict (and other) reasons. In 2016, the World Bank estimated that 1
in 5 people in Afghanistan is a returnee following international displacement which has occurred since
1979. In 2016, around 1 million people returned to Afghanistan from Pakistan and Iran, which against a
population estimated to be between 28 and 32 million is significant and placed a particular strain on the
government and aid organisations who do not have the capacity or resources to meet the needs of such a
large number of people. For example, the financial support offered by the UNHCR halved from $400 per
person to $200 per person during this period due to lack of resources. In addition, UNOCHA estimated
that nearly a million Afghans were internally displaced (for conflict and to a lesser extent, natural disaster
reasons) in an 18-month period prior to its Humanitarian Needs Overview 2018 report and that 30 out of 34
provinces recorded some level of forced displacement.

**_Kabul - overview_**

120. Kabul is the largest city in Afghanistan and has experienced rapid growth in recent years, including
from returnee populations, IDPs and economic migrants. Population estimates for the city range between
3.5 million and 7 million people. It is an ethnically diverse city with communities of almost all ethnicities
and no group clearly dominating. People tend to move to areas where they already have family or into
particular districts as part of a larger group with the same ethnicity. Neighbourhoods within the city have
become associated with different ethnic groups, particularly in the outskirts.

121. The total inflow of people to Kabul recorded between 1 January 2016 and 22 June 2017 was
680,260, which included a total of 325,518 returnees to Afghanistan (111,500 undocumented returnees
from Pakistan and Iran, 203,164 documented returnees from Pakistan and Iran and 10,854 from other
countries). The remainder were internally displaced persons and economic migrants.

122. In December 2016 the UNHCR commented (as recorded in the Human Rights Watch Report
“Pakistan Coercion, UN Complicity: The Mass Forced Return of Afghan Refugees”) the following about the
impact of returnees on Kabul as follows:

_“Kabul has been significantly affected by the surge in returns from Pakistan, with almost a quarter of the_
_55,000 registered returnee families, and a similar percentage of the 240,000 undocumented returnee_
_families, settling in Kabul's overcrowded informal settlements. In light of the well-documented contraction_
_of Kabul's economy following the withdrawal of international forces in 2014, the city's absorption capacity_
_has been extremely limited due to the low availability of livelihoods … appropriate shelter, and access to_
_basic services, particularly health and education.”_

123. According to the UNOCHA “Humanitarian Needs Overview 2018”, Kabul province is one of four
provinces in the highest category for severity of needs (together with Kunduz, Nangarhar and Kandahar,
and a further six provinces are in the second highest category) defined as areas where multiple needs
converge, and an integrated response is required.

124. Dr Schuster's evidence was that conditions in Afghanistan have worsened, in particular following the
withdrawal of international security forces in 2014 which led to an economic crash and a lack of optimism
for the future by ordinary Afghans. There is greater awareness of more security incidents in Kabul, the
effects of which can be seen around the city with blast walls getting taller and increasing in number and
increasing numbers of roads blocked off or with height restrictions to prevent large vehicles travelling. The
so-called Green zone has become more militarised and other areas of the city feel fragile.

125. Ms Winterbotham also describes the physical changes in Kabul as evidence of the changing security
situation, with more barricades, higher barricades and more areas with restricted access. In 2002 it was
possible to walk freely around the city, but she would not contemplate doing so now as an international


-----

person. From her own perspective, Ms Winterbotham has cancelled or delayed trips to Kabul in 2017
based on inadequate security arrangements for her there and is of the view that it is only safe to travel
around the city in an armoured vehicle.

126. Since 2014, insecurity in Kabul has increased and has been more affected by suicide and complex
attacks as evidenced from the UNAMA figures and Ms Winterbotham described the effect of that on people
living in the city as increasing fear of travel, of going to local places and significant detrimental mental
impact after 30 to 40 years of conflict.

127. There was limited evidence before us about crime in Kabul city (as opposed to security incidents
detailed above) and the ability (or inability) of the police and state officials to deal with this, as well as
evidence as to corruption within the police and judiciary. There was however little detail in the evidence
about crime rates in Kabul city or whether any particular groups or geographical areas are specifically
affected.

128. For ordinary Afghans in Kabul, most use non-motor vehicles as a means of travel. Buses and taxis
are used as an alternative to cars (which are used only by those who are better off) but there is no
extensive public transport system in Kabul. For those in employment, some employers provide bus
facilities to transport people to and from work but there are examples of such buses being targeted in
attacks where there are links to foreign bodies or the Afghan authorities. The roads in Kabul are generally
dusty, muddy and unpaved with increasing congestion. There are safety concerns about particular roads
which have been targeted due to specific locations along the route or because they are main routes
through, into, or out of the city (usually due to targeting of high profile traffic such as military convoys or
diplomatic vehicles). However, Ms Winterbotham accepted the greatest danger on the roads in and
around Kabul was bad driving.

**_Housing and associated amenities_**

129. The Islamic Republic of Afghanistan's Report “The State of Afghan Cities” in 2015 found that 86% of
urban houses in Afghanistan can be classified as slums according to the UN habitat definition. In Kabul,
around 74% of people live in informal settlements (houses without formal planning permission) which have
very limited sanitation, drainage or access to potable water. Many of these settlements, which now spread
over the hills surrounding Kabul towards surrounding villages, are now well established but have never
been subject to building regulations or planning control.

130. In terms of available accommodation in Kabul, the IOM “Baseline Mobility Assessment, Summary
Results, Afghanistan” records the following shelter as available:

_“Many just squat in abandoned buildings. Often, the latter do not have any doors, windows and even roofs._
_In Kabul city, a monthly rent could reach 10,000 AFN ($147) in central urban areas/districts. The usual_
_cost in the outskirts varies between 2,500 AFN and 6,000 AFN ($37-87) depending on the type of_
_accommodation and the amenities it might offer. In Dehsabz and Mirbachakot districts Returnees and_
_IDPs stay at houses made out of mud bricks, straw and stones that are unstable and vulnerable to natural_
_disasters. However, the rent for better-quality accommodation is 2,000 AFN – 5,000 AFN ($30-74).”_

131. Dr Schuster also referred to people squatting, living in tents and making their own bricks to build
accommodation. Her evidence was also that a single room could be rented in Kabul for $100 a month, but
such accommodation is difficult to find and would require payment of 6 months' rent in advance. There
were rare examples of groups of young men renting such a room together.

132. Dr Schuster gave an example of the type of accommodation that would be likely for a family in Kabul
including a taxi driver, which would be a small house comprising of three rooms and include a basic toilet
emptying into a mud gutter in the street, with occasional or no electricity and using gas for light and
heating.

133. Throughout Afghanistan, most households rely on wood, charcoal or waste for heating. Access to
electricity was relatively high in urban areas – with a report from 2011/12 estimating some access for 95%
of urban households, albeit not with a regular supply.


-----

134. UNOCHA's “Humanitarian Needs Overview 2018” states that 45% of Afghans use unimproved water
sources. Access to improved water sources (those that adequately protect water from external
contamination) is relatively high in Afghan cities, with access through public and private pumps, public and
private wells or piped water. Unimproved water sources in cities include unprotected wells, water tanks
and surface water. The situation outside of the cities is much worse and access to clean water can be
source of quarrel and conflict in some areas.

135. In Kabul city, there are a limited number of water sources from kariz (acquifers), canals and pumps
and the piped-water system covers less than 20% of the population of the city. The majority of people get
water from wells or pumps, which can be some distance from their accommodation and involve long
queues. The alternative is to purchase water – the evidence on the price of which varied between 20
Afghanis for 4.5 litres, to 50 Afghanis for a 20-litre bottle to the same price for a 200-litre barrel.

136. UNOCHA's “Humanitarian Needs Overview 2018” states that 68% of Afghans have no access to
improved sanitation. Access to improved sanitation (facilities that hygienically separate human excreta
from human contact) is lower in Afghan cities than access to improved water sources.

137. Data collected from the United Nations Population Fund (“UNFPA”) in 2013 stated that of the
households in Kabul, 95% had access to electricity; 87% to a TV set; 97% to a mobile phone; 50% had
improved sanitation facilities; 43% had a fridge; 33% a computer; 26% a car and 10% had access to the
internet. However, the percentages are likely to be lower now due to the population growth since then.

138. In terms of a person's ability to access available accommodation, the evidence of Dr Giustozzi and Dr
Schuster differed as to whether references would be needed for a single man to obtain such
accommodation. Dr Giustozzi's evidence was that it is possible to rent accommodation without
connections or references in Kabul, particularly for dormitory accommodation. References would only be
needed for more formal rented accommodation. Dr Schuster's evidence was that a single young man
would be able to rent a room if a landlord could be assured of his behaviour (for example that he would not
harass women and was not taking drugs) and with money could obtain such accommodation on a
temporary basis in advance of a reference. However, in her opinion, references were crucial to obtain
stable accommodation.

139. Dr Giustozzi and Dr Schuster referred to people arriving in Kabul tending to go to the area where
people from their province lived and were of the view that a person would be likely to find people from their
village or someone who knew their family (Dr Schuster's view was that this was “inevitable”) who would be
able to vouch for a person and/or help them find a place to stay as well. Dr Schuster referred to the very
strong tradition of hospitality in Afghanistan, albeit the availability of such assistance has been eroded over
time due to the impact of hostilities over 40 years which increased suspicion of single people and reduced
resources available.

**_Healthcare_**

140. There was limited evidence before us as to the availability of healthcare in Afghanistan and we record
as an overview a summary of the information available from the EASO Report: “Afghanistan – Key socioeconomic indicators, state protection, and mobility in Kabul City, Mazar-e Sharif and Herat City” (August
2017).

141. In summary, that report recorded evidence that Afghanistan had made progress in providing
healthcare, but serious obstacles persisted. A Basic Package of Healthcare Services system was
introduced in 2003 with the aim of providing the minimum essential health services in all primary healthcare facilities. The Essential Package of Hospital Services followed in 2005. These have improved the
situation but there is inequality of access to healthcare for women (due to a lack of female health care
professionals) and those in rural areas; there are financial barriers to individuals and problems of
corruption, insecurity and poor regulation. Separately there is a private healthcare system, but it is very
expensive.


-----

142. In terms of mental health care, the same EASO Report recorded very high levels of mental health
problems in Afghanistan (particularly depression, anxiety and PTSD) creating significant needs but that
there was a lack of trained professionals (psychiatrists, social workers, psychologists) and an inadequate
infrastructure. Although the Public Health Minister reported that psychological services were available at
some 1,500 health centres around the country with 300 dedicated mental health clinics; there was only one
dedicated mental health hospital in Kabul and Samual Hall's study in 2016 referred to there being only
three trained psychiatrists and ten psychologists in the whole of Afghanistan.

143. In Kabul specifically, there is better access to healthcare than in the provinces and the most qualified
staff work there with specialist clinics and hospitals; albeit there is still significant room for improvement.
There remains a shortage of equipment and demand which outstrips supply. Nearly half of Kabul residents
can not afford medical treatment (as patients need to buy their own medicines and, in any event,
pharmacies are poorly equipped). There are also instances of health facilities being targeted by armed
grounds, including in Kabul.

**_Employment/socio-economic conditions_**

144. The Afghan economy was previously boosted by the presence of international forces and
reconstruction, with growth rates of around 14% in 2012. However, since 2013, the GDP growth rate has
fallen to under 2% and if population growth is factored in, the growth rate essentially drops to zero with
some, such as the Afghanistan Analyst Network, of the view that there is actually a declining average percapita income. The last unemployment figures were released in 2014 from the Afghanistan Living
Conditions Survey which reported unemployment of 24% and a further 15.3% people underemployed and
Dr Schuster referred to official figures in 2015 showing a national unemployment rate of 40% (with figures
higher in the cities than in rural areas). The general view, shared by Dr Schuster, is that the position will be
worse now due to the declining economic situation, with continuing decline in foreign and domestic
investment and due to annual population growth. The latest indicator before us was from the Asia
Foundation survey in 2016, which found only 45% of all respondents saying that they were involved in
activity that generates money.

145. The EASO Country of Origin Information Report: “Afghanistan – Key socio-economic indicators, state
protection, and mobility in Kabul City, Mazar-e Sharif and Herat City” sets out the employment position in
cities. It records approximately 20% of employment being formal, including employment in the
government, NGOs, international organisations and within the formal economy, mainly within the public
sector; and 80% of employment being low skilled informal labour. The latter would include low skilled jobs
in the bazaars, day labourers in the construction industry, seasonal agricultural workers and apprentices in
family businesses. Employment is also available in the service sector, albeit many were informal or day
labouring work only. High skilled jobs are available in the public sector, in health and education sectors
and opportunities are available for those with monetary and social capital to start up a business. Access to
employment can be hampered by lack of basic skills like literacy, numeracy and vocational skills; often
referred to in the evidence as a 'rural skill set' not transferable in urban environments.

146. In relation to Kabul specifically, EASO states (in the same report) as follows:

_“Kabul is the financial and political centre and largest city of the country and hosts most of the international_
_agencies. It has a higher level of industrialisation than other cities. However, according to the Kabul city_
_Master Plan, the employment structure of Kabul province is 79.4% agriculture, 5.7% industry, and 14.9%_
_services. Even if the population of Kabul province is 80% urban, most inhabitants depend on agriculture_
_for a living, either directly or indirectly.”_

147. The International Organisation for Migration (IOM) describes the position in Kabul, in their report
“Baseline Mobility Assessment, Summary Results, Afghanistan” (June 2017) (which uses the Displacement
Tracking Matrix (DTM) system) as follows:

_“Kabul city, as the country's capital, provides significantly more employment opportunities. However, only_
_about 5% of IDPs and Returnees possess their own businesses (shop-keeping, stock deliveries, trading at_
_the markets, selling small size goods on the streets, small restaurants). It is common for IDPs to rent other_


-----

_people's cars in order to use them as taxis to earn a daily wage. The DFPs report that over 50% of the_
_respondents say that their families have at least one member that migrated to Iran, Turkey or Europe and_
_supports his/her relatives by sending money.”_

148. The US Department of State Annual Report in 2016 referred to a minimum wage for certain
employment in Afghanistan (permanent government workers and non-permanent private sector workers, of
6000 Afghanis ($103) and 5,500 Afghanis ($95) a month respectively). The same report showed the
poverty line in Afghanistan to be 1150 Afghanis ($20) a month and over one third of population earning
below that level. In contrast, the Asia Foundation Survey of the Afghan People in 2016 showed
respondents reporting average monthly household incomes of 10,949 Afghanis ($165) with urban areas
reporting higher incomes of 14,284 Afghanis ($215).

149. Dr Schuster describes the job market as very competitive, with positions being given to family
members rather than being advertised or with appointment on the basis of merit. She gave examples of
people working in return for food or accommodation and employment in a range of jobs being done for long
periods without a salary in the hope of a proper job being obtained in the future. The intense competition
for jobs can be partially explained by the fact that it is normal for one person to support an extended family
of up to 15 people.

150. Dr Schuster explained that day labouring work is available, normally as a porter or some other
manual work such as within the construction industry. Such work is obtained by people standing in the
street but is also often obtained through a contact or network. Day labouring work is extremely precarious,
unlikely to be regular and could be for occasional work for half a day only. The pay is little for short
periods. UNOCHA, in the “Humanitarian Bulletin, Afghanistan” (June 2017) stated that a person could
earn, at most, 300 Afghanis ($4.40) a day as a day labourer. Dr Schuster stated that those who are
confident, competent and strong would obtain employment first and vulnerabilities such as mental health
problems may affect a person's ability to gain such employment, but it was difficult to quantify the effect.

151. Another desired or preferred occupation in Kabul is to be a taxi driver. Dr Schuster described high
demand for such a position and opportunities were likely to be shared or given to those who were known
and trusted first. She had knowledge of a person who borrowed money from abroad to buy an unlicensed
taxi, but this was risky because it could be confiscated and to obtain a licence a person would need to
bribe officials in Kabul.

152. Dr Schuster's view was that it was impossible for a person to get work, even as a day labourer,
without a significant network or contacts in Kabul. She did not have experience of anyone being able to
obtain stable employment or survive without a deep network (which may be friendship based as well as
familial) and/or resources. On the contrary, she had witnessed young men visibly destitute on the streets
of Kabul, begging, being in bonded labour, being trafficked or being addicted to drugs and that such
instances had increased in the last year.

153. However, Dr Giustozzi's evidence was that a person does not need any references or network to
obtain unskilled labouring work. Although they may be asked their name and where they are from, there
would be no further checks on that information or that person for such work. Similarly, a person who has
specialist skills who could demonstrate them (for example a tradesman such as a plumber), an apprentice
or person setting up a businessman would not need references to do so because they could demonstrate
their skills. However, highly skilled jobs, particularly those involving handling money (for example
accountants) or long-term employment is likely to require references for a person to be employed.

154. Ms Winterbotham's evidence was that those who were reliant on ad hoc, unskilled employment were
more susceptible to trafficking and/or recruitment into bonded or hazardous occupations in both the licit
and illicit sectors; as well as being more susceptible to other coercive practices. However, there was no
specific evidence of this in Kabul and she identified boys between the ages of 11 and 15 and irregular
migrants as those being most at risk.

**_Returns procedure and available assistance on return_**


-----

155. There are different procedures and assistance packages in place depending on whether a person is
voluntarily returning to Afghanistan or being forcibly returned, and the assistance received varies
depending on where a person is returned from. There are also schemes of support for which we have
documentary evidence but no further evidence of such assistance actually being provided.

156. IOM has assisted over 15,041 voluntary returnees from Europe since 2003 and in 2016 alone, 6,711
people voluntarily returned to Afghanistan from Europe through the Assisted Voluntary Return and
Reintegration programme (AVRR). The AVRR programme has four main components – preparation;
return; reception and reintegration. As to reception, at the airport, a person will see a representative of the
Ministry of Refugees and Repatriations office, have the opportunity to speak to representatives of other
Ministries and be able to speak to a representative of IOM. Money is made available in cash to returnees
(forced and voluntary) for transportation to their onward destination or to accommodation at the Jangalak
reception centre (available for up to two weeks). Medical assistance is also available at the airport.

157. Dr Schuster is only aware of 43 people having taken up the offer of accommodation in the Jangalak
reception centre in the last five years. Of those returning in 2016, only 1092 took up the offer of
reintegration assistance after arrival and it is thought that the low take up is more to do with returnees not
applying for help rather than being refused support or inadequate resources to assist. Reintegration
assistance includes in-kind assistance for the purchase of goods and services, help with training or setting
up a business or help to secure accommodation. Of those who received reintegration assistance from the
IOM, one in six received this additional package of between €800 and €2500 to assist with their life plan for
accommodation, employment or education.

158. The evidence varied as to support in cash for returnees from the United Kingdom (primarily under the
Facilitated Returns Scheme), with some sources suggesting returnees were given £100 to help them; Dr
Schuster referred to voluntary returnees receiving between £200 and £500 and others suggesting up to
£750 in cash and there was reference to an assisted voluntary return package primarily focused on
families, but which was now available to young single males. Dr Schuster's evidence was that forced
returnees could receive up to £900 in-kind but not in cash. She stated that if a person was astute, financial
support of £200 to £500 could last a person a month to six weeks, but a person unfamiliar with the system
and prices in Kabul could be ripped off and funds only last them a week to ten days.

159. Dr Schuster's evidence was that IOM packages changed in August 2016 and the situation thereafter
was not yet clear about what support was available or from whom. There was no witness evidence from
the Respondent as to what was provided to whom in reality and the UK government had not consented to
IOM releasing their data on this to Dr Schuster when she requested this for the purposes of her expert
report.

160. The IOM is also able to give clothing to individuals if necessary on return, assist them with airport
formalities and counselling. Counselling includes psychological counselling but also advice as to housing
and employment. In addition, mine awareness training is offered and advice leaflets are available about
medical facilities, transportation and opening a bank account. Similar information can be obtained from
government ministries as well.

161. Outside of IOM, there is evidence of other smaller organisations offering assistance to returnees.
These include the International Psychosocial Organisation (IPSO), AMASO, Experts in the Fields of
Migration and Development (AGEF) and European Reintegration Network (ERIN). IPSO is funded by the
German government and offers accommodation and counselling services (for up to 400 or 500 people a
day) as well as training and self-awareness groups. AMASO provides information and support to returnees
and has a small apartment which can accommodate a maximum of 10 men for a few nights. AGEF assists
returnees from the UK and Germany, offering the same type of support as IOM with packages to open or
join a business, training and helping to find a person a placement or employment. The package
compensates a returnee for their enterprise for a period of six months.

162. A leaflet from ERIN detailed assistance provided in Afghanistan to returnees including reception
assistance, onward travel, emergency temporary housing and immediate necessities on return; with
reintegration packages to help a person set up a small business find a work placement or undertake


-----

further education and training. Dr Schuster was aware of ERIN and the provision of accommodation and
travel, but the reintegration support referred to was still in the planning phase with possible service
providers and not yet provided to returnees.

163. The UNHCR provides assistance to returnees, including as cash grants but this was primarily
directed towards returnees from Pakistan who received $400 per person (reducing to $200 per person)
which was used to help reintegration needs – the money being spent on food, shelter and transport with a
small number being able to invest in a business or build a house.

**_Evidence of the experience of returnees to Afghanistan_**

164. There are a number of specific studies about the position of returnees to Afghanistan (including
reports as to procedures on arrival) including quantitative and qualitative data, in addition to which we
heard evidence from Dr Schuster as to her knowledge and experience of those who have returned.

165. In 2017, the UNHCR published “Tough choices for Afghan refugees returning home after exile” which
detailed results of a survey of 4285 people by face-to-face interview on the point of arrival (primarily
returnees from Pakistan) and a telephone interview with some 1300 returnees three months after return.
93% of respondents stated that they were warmly received by communities on return to Afghanistan and
75% said that three months after arrival they felt they had made the right decision to return. Dr Schuster
was surprised by these results and considered that the context of reasons why people were leaving
Pakistan may have influenced the outcome as a comparison of conditions.

166. In May 2017, Amnesty International interviewed 18 women, men and children who had recently been
deported to Afghanistan from Europe which showed that group had significant fear on return and there
were instances where risk had been realised with people being injured or killed after return. Although this
is an in-depth study, it is of a very small number of people out of thousands of returns from Europe, 90% of
whom were single males rather than families or women and children.

167. In 2015-2016, the Refugee Support Network monitored the experience of 25 care leavers (those who
had come to the United Kingdom as unaccompanied asylum seeking children, were granted leave to
remain up to just before their 18th birthday and who were then returned to Afghanistan having been
refused further leave to remain) after return to Kabul which found that they had all experienced a range of
interconnected difficulties on return, including with families and forming relationships, with insecurity,
continuing education, finding sustainable work and mental health difficulties. The sample size of this group
was out of a total of 2,018 care leavers who had been removed to Afghanistan since 2007. Those
monitored had been referred to the Refugee Support Network's Youth on the Move programme in the UK
and then referred to their Monitoring Officer on return to Kabul.

168. UNOCHA's Humanitarian Needs Overview 2018 included household level emergency assessments
of newly displaced populations in 2016 which showed that 70% of such households had no food stocks
and only 25% of households had one weeks' worth of supplies. In terms of housing, 40% were able to find
refuge with families or friends and 33% were in rented accommodation but vulnerable to eviction as a
result. The same report found that returnees were in a similar position to those who had been internally
displaced, with access to shelter, secure tenure, food and economic security all remaining critical for some
time after they have settled. Returnees were found to be almost entirely dependent on improvised family
arrangements and international humanitarian support to survive.

169. Dr Schuster referred to different experiences depending on whether a person voluntarily returned to
Afghanistan or was forcibly returned; albeit caution should be applied to those recorded as having
voluntarily returned as many are required to sign papers and as such are effectively forced to return. Dr
Schuster described those returning voluntarily as having time to prepare in advance and reactivate
networks in Afghanistan whereas those forcibly returned are often in denial of what is about to happen, not
accepting the situation and therefore do not prepare in advance. They also suffer feelings of stigma and
shame, generally or within their family unit due to the perceived cost to others of failed migration. There
are also different experiences for those returning from Pakistan (who are mainly family groups, many of
whom had been out of Afghanistan for decades), to those returning from Iran (who are more likely to be


-----

single men, but the group also includes a significant number of unaccompanied minors, single women and
emergency medical cases), to those returning from the West (a much smaller number and almost entirely
made up of single men).

170. Of those that Dr Schuster has had direct or indirect contact with (for example through studies or
through Abdul Ghafoor/AMASO), most of those who have been forcibly returned to Afghanistan have left
again. Only one remained after two years, but of relatively recent returnees, 20 remained in Kabul. Of
those 20, some were supported by IOM and some with funds from abroad. Five of them were working as
labourers but only one was being sustained by this employment, the other four were homeless. Three of
the other 15 were living in the AMASO accommodation and the situation of the others was unknown. In Dr
Schuster's experience, the only people who successfully reintegrated with a home and job were those with
family networks or resources. Dr Schuster is aware of groups of returnees from Iran forming their own
networks in Kabul and a single man could be received into a network through a single contact or through
work.

171. A range of factors contribute to an individual's decision as to whether to re-migrate. Dr Schuster and
Nassim Majidi set out three main reasons for re-migration, first, debt (for example from money borrowed to
pay for the initial migration); secondly, family commitments and thirdly, the shame of failure or
'contamination' leading to stigmatisation. The failure, or perception of failure (for example, some in
Afghanistan see those deported as people who are lazy, stupid or criminal – there being some culpable
reason for their return), can lead to a loss of status and therefore prospects for a person. In addition,
people leave Afghanistan again due to fear of the security situation and for wider socio-economic reasons,
including that they were unhappy to have been returned and preferred their experience of life elsewhere.

Findings and reasons

172. We follow the same structure as above for our findings, dealing first with general findings and then
those specific to this Appellant. We deal firstly with whether a person has a well-founded fear of
persecution in Kabul (if so, then there is no option of internal relocation to Kabul), and if not, our
assessment of whether it would be reasonable or not unduly harsh to expect a person to internally relocate
to Kabul. As above, the Appellant does not claim that conditions in Kabul are in breach of Article 3 of the
European Convention on Human Rights, nor does he claim that the situation there meets the threshold in
Article 15(c) of the Qualification Directive. As such, save where necessary in the context of responding to
the Appellant's invitations to us to make findings or statements on previous country guidance cases, we
make no specific findings about Article 3 or Article 15(c).

**General Findings – risk**

173. We consider first the risk of persecution by the Taliban in Kabul to a person who is accepted to be at
risk on return from them in their home area. The two main ways in which it is said that this may arise is
first, through specific targeting of an individual in Kabul, and secondly, through a chance encounter with a
person, for example at a temporary checkpoint in or around the city. We deal with each in turn.

174. The risk of a specific individual being successfully targeted depends upon their identification as a
target (for example, due to past or present actions/circumstances) and the ability of the Taliban to locate
and then carry out an attack on that person, as well as their will or priorities in doing so. The evidence was
broadly in agreement as to the order of importance of targets for the Taliban in Afghanistan being (i) senior
serving government officials and the security services, (ii) spies, and at the lower level, (iii) other
collaborators (including the wider security forces, government authorities, foreign embassies, the UN,
NGOs and anyone passing information to the government about the Taliban) and deserters. Dr Giustozzi's
evidence was that the Taliban keep a blacklist of all those who are wanted by the Taliban/identified as
legitimate targets, some of whom are included just because of their high-profile position and others at a
lower-level are identified because they have been through a system of sentencing and only then are they a
legitimate target.

175. Dr Giustozzi's evidence as to the existence of a blacklist setting out the names of people sought by
the Taliban as legitimate targets comes only from limited Taliban sources has not been corroborated by


-----

any other external sources and is not supported by other commentators and acknowledged experts in the
field (see the EASO Report “Afghanistan – Individuals targeted by armed actors in the conflict”). Dr
Giustozzi has never seen such a list, nor is he able to give clear information about its content or use from
his sources, with much of the detail filled in with conclusions he has drawn as such matters. There are
aspects of the evidence about the blacklist, for example, as to its size and comprehensiveness, which itself
undermines a conclusion that such a thing exists.

176. We do not find that there is sufficient evidence before us to find the existence of a single blacklist
operated by the Taliban to identify targets. However, even if we are wrong about that, there is scant
evidence of who is on such a list and it would in any event take an extraordinary series of events for a
person who is on such a list to be found and targeted.

177. Dr Giustozzi's evidence was that the blacklist contained 14,500 names covering people not only in
Afghanistan but also in Pakistan and other countries, including those who have been sentenced (following
a process by which a person has to receive two written warnings from the Taliban left at that person's
address, which were not complied with and then a sentence would be passed that would communicated in
writing or verbally to the person or someone close to them) and those automatically included because of
their profile as someone posing a serious danger to the Taliban. The number of people included worldwide
raises immediate questions as to the comprehensiveness of the list given that the security forces alone in
Afghanistan number many times the total 14,500 said to be on the list. There was a lack of any evidence
or even opinion as to why only a relatively small proportion of those who were described as legitimate
targets for the Taliban were on the list. That casts doubt as to its existence at all and shows that in any
event there is no reliable evidence about a person's inclusion on it or the reasons for such inclusion.

178. Dr Giustozzi's evidence did not include any information as to the process by which names were
added to the blacklist and could only infer that the information included would be a person's name, father's
name and place of birth given that that is the usual way to identify people in Afghanistan. He could also
only infer that there was a digital master copy held somewhere based on his knowledge that the Taliban
have such technology and infrastructure available to them and that a paper copy would be unwieldy and
impractical to use. The lack of detail about such a list, particularly given the importance placed on it by Dr
Giustozzi as a means of identifying those at risk from the Taliban, does not support a conclusion that such
a blacklist exists.

179. Further, in any event, even if a blacklist did exist in the way described by Dr Giustozzi, his evidence
as to who has access to it and how it is used places a lower level person of interest at very negligible risk
(so low as to not amount to a real risk) even if they are named on it because it would require an
increasingly unlikely series of events to unfold. There was no suggestion that the complete blacklist was
shared with anyone other than a handful of Shuras at the very top of the organisation; nor that it was
disseminated in complete form to any lower level within the Taliban (even to provincial Military
Commanders); nor that it was in anyway searchable or accessible by others within the Taliban either
quickly (for example, for individuals to be checked against it during a random encounter) or at all. To the
contrary, local Taliban members, fighters or dedicated units tasked with hunting down wanted individuals,
would, on Dr Giustozzi's evidence, only be given details of a few names of wanted individuals believed to
be within their area of operations. No information as to the people on the blacklist would be given to
informers.

180. The further step required for a person to be identified and targeted is therefore some information
about his whereabouts. That would require a person to come to the attention of an informer, but even if
they did (for example by providing their details directly to them for the purposes of obtaining a reference for
employment or accommodation, which for the reasons set out below would not be required in every case),
an informer would not have any access to the list to know that a person was on it or wanted. At its highest,
that informer may tell the Taliban of a person's details, for example as general information given about a
person new to an area, but it is unclear as to how such information would realistically be relayed to a
person within the Taliban who happened to know, from the small number of names that anyone other than
a very senior figure within the Taliban is likely to be given, that the person they received information about
was on the blacklist


-----

181. If, in the alternative, for some reason a person came to the direct attention of an ordinary Taliban
member (not via an informer), again, the possibility that the person's name was one of a small number of
wanted people thought to be within that Taliban member's area of operations, or would reach a sufficiently
high level within the organisation to have a much larger list of names, is beyond remote. There is no
particular reason why such information would be checked or passed on higher up the chain of command
about someone about whom was no immediate reason to suspect, or potentially only a person of low-level
interest. There was no suggestion in the evidence before us that the Taliban had the required
sophistication, widespread technology or resources to conduct checks on every name of those who come
to their attention, via an informer or ordinary member. Given the vast population movement both internally
in Afghanistan and inflow of people from abroad, the task of running basic identity checks against the
blacklist system described by Dr Giustozzi would be enormous – if all were monitored, well over a million
people in 2016 alone. We do not find that therefore that there is anything other than a fanciful risk of
identification as a target for all of these reasons.

182. Further, even if (which for the reasons above is highly unlikely) a person was identified either in their
home area or in Kabul as being on a blacklist (even if that also exists) and that information was passed on
to the relevant Taliban member, Dr Giustozzi's evidence is that there is a single dedicated unit of around
20 people operating in Kabul province tasked with hunting down and executing targets (albeit we accept
that his evidence was of at least one per province and he had not sought information as to whether there
were any more than one in Kabul or any other province). Although his evidence was that low-level people
of interest were pursued because they were easier to successfully kill and the number of opponents killed
(as opposed to named or high-profile targets) is important within the general objectives of asserting
authority as the legitimate power in Afghanistan and undermining the current government; there would still
need to be a decision on the priority of targets amongst a population of 3.5 to 7 million people, with such
limited resources.

183. The evidence of Mr Siddique recorded in the EASO report (set out above) shows that the list of
people for whom the Taliban will invest resources and planning to track and target in major cities is limited
to between a few dozen to up to a hundred persons. Further, there is a lack of supporting evidence of
targeting of low-level individuals in Kabul, cities/urban areas or areas outside of Taliban control (as also
found by the European Court of Human Rights in H and B v UK¸ 70073/10, 44539/11, Chamber Judgment

[2013] ECHR 298 (9/4/13)). Overall, this adds an additional level of remoteness such that in totality, there
is insufficient evidence to support a real risk of a low-profile person being identified, located and targeted
even if there is a blacklist on which their name appeared. In the absence of a blacklist at all, that risk is
fanciful at most.

184. As to the prospect of a chance encounter placing a person at risk on return to Kabul from the Taliban,
we find little evidence to support any real risk arising from such a situation. There is evidence (which is
uncontroversial and has not been specifically challenged) of the Taliban setting up temporary checkpoints
in and around Kabul city based on specific intelligence, although no quantification or estimate of the
number or range of locations (other than including main routes in and out of the city) used was submitted
by either party. That specific intelligence is said to include the expected movement of a targeted person
(or persons – such as employees of the state, other countries or NGOs), including the day and time of
travel, means of travel (up to and including identification of a specific vehicle) and destination, or at least
expected route. We find that such specific intelligence indicates targeting of the most high-profile people,
given that significant or at least very well-placed resources would be required to identify such specific
information. The specific intelligence identified also suggests higher-profile targets as opposed to lowerlevel individuals are far, as a matter of practicality, far less likely to be travelling in specific vehicles or have
such predictable movements.

185. There is of course the possibility that a checkpoint set up to target a specific person or group may
also involve others being stopped either randomly or because of a suspicion based on a particular feature.
The features suggested in evidence could be that a person is wearing a shirt and tie (which may indicate
that they are a state employee of some sort) or has English contacts on a mobile phone. There is however
no specific evidence of such incidents regularly occurring or at all. The only example that appears in the


-----

evidence is of an Australian man taken off a bus by the Taliban, but the evidence is inconsistent as to
whether he was specifically targeted by name or coincidentally by his appearance or other feature.
Although we accept that a person is likely to need to travel in and around Kabul for work and other daily
necessities, the chances of encountering such a checkpoint, being stopped at it, being questioned by the
Taliban, being identified as a target and suffering harm as a result are, cumulatively, too remote to give rise
to a real risk of harm. For the reasons set out above, there is no real risk that even if a blacklist exists and
a person's name is on it, that that information could or would be obtained at a temporary checkpoint
because of the lack of availability of access to a complete or searchable list; or that the person's name
would, coincidentally, happen to be one of a very small number given to a local Taliban member.

186. We do not find that there is any real risk of an adult male being forcibly recruited (for example through
threats or coercion) to an armed group in Kabul. There is scant evidence of any such instances occurring
in Kabul and goes against the traditional methods of recruitment of the Taliban in particular. We do
however consider the risk of a person feeling compelled to join an armed group for socio-economic
reasons, as opposed to forced recruitment, further below in the context of reasonableness of internal
relocation.

187. We do not find a person on return to Kabul, or more widely to Afghanistan, to be at risk on the basis
of 'Westernisation'. There is simply a lack of any cogent or consistent evidence of incidents of such harm
on which it could be concluded that there was a real risk to a person who has spent time in the west being
targeted for that reason, either because of appearance, perceived or actual attitudes of such a person. At
most, there is some evidence of a possible adverse social impact or suspicion affecting social and family
interactions, and evidence from a very small number of fear based on 'Westernisation', but we find that the
evidence before us falls far short of establishing and objective fear of persecution on this basis for the
purposes of the Refugee Convention.

188. As above, there was only limited evidence before us of other possible risk factors to individuals in
Afghanistan (which were not relevant to the Appellant in this appeal) which are outwith the ambit of this
appeal and we make no specific findings on them.

**General Findings - reasonableness**

189. It is not necessary to rehearse here the numerous authorities in which evidence and opinions from
the UNHCR have been positively endorsed by the domestic and international Courts. It is uncontroversial
that significant weight can and should be attached to such evidence from the UNHCR as the Guidelines on
International Protection and the “Eligibility Guidelines for Assessing the International Protection Needs of
Asylum-Seekers from Afghanistan” (2016) and we do so in this appeal.

190. In terms of safety, the UNCHR suggests two initial considerations, first, the volatility and fluidity of the
armed conflict in Afghanistan in terms of the difficulty of identifying potential areas of relocation that are
durably safe; and secondly, the prospects of safely accessing the proposed area of relocation. In relation
to Kabul, it is well defended as the capital city in terms of retaining control for the current government and
in fact, in recent years the authorities have a good record of maintaining (or in one instance, re-taking)
control of larger cities. Although taking Kabul is likely to be seen by AGEs as the ultimate prize and one
which would inevitably lead to the downfall of the current government, there is little evidence before us of
that being attempted let alone achieved in the foreseeable future. In that sense, the volatility and fluidity of
armed conflict in Afghanistan is likely to be less in Kabul compared to smaller urban centres and rural
areas where control does change between the state authorities and AGEs (or with no clear overall control).

191. As can be seen from the UNAMA reports, the nature of security incidents in Kabul also follows a
relatively consistent pattern, with the focus on suicide and complex incidents rather than air strikes and
ground engagement which are more common in other parts of Afghanistan. That type of attack includes
wider civilian casualties than the specific target of the attack and also potential significant collateral
damage to lives and property.

192. The numbers of civilian casualties in Kabul are increasing year on year and from the information
available to date from 2017 are at record levels since UNAMA started gathering such data in 2009. To that


-----

extent, the intensity of conflict in Kabul city (as well as more widely in Afghanistan shown by the overall rise
year on year in civilian casualties) is increasing. As the panel commented in AK, there is a fluid situation
which should be monitored and kept under review, but at the present time, we find for the reasons set out
below that the security situation in Kabul does not exclude it as an option for internal relocation for a single
male as in this appeal.

193. In the first half of 2017, UNAMA recorded 1,048 civilian casualties (219 deaths and 829 injured) in
Kabul province, the vast majority of which (94%) were caused by suicide and complex attacks carried out
by AGEs (the Taliban, ISKP and others). A relatively small number of the security incidents in Kabul city
caused the majority of the casualties, with the attack on 31 May 2017 alone accounting for more than half
of the casualties in the period. The security incidents in Kabul city are spread around rather than being
concentrated in a particular area or areas and include as targets individuals, government and international
buildings as well as civilian areas including roads, shops and mosques, thus affecting many areas of
everyday life.

194. The expert witnesses before us were in agreement as to the deterioration in the security situation in
Kabul, particularly since the withdrawal of international security forces in 2014, with experience of this
being evident on the streets of the city with increasing protection measures being used (for example, a
greater number of and higher blast walls, more height restrictions on roads and more roads closed off).

195. We do not underestimate the negative effect of the security incidents felt generally on the residents of
Kabul who have increasing fear of incidents within the city affecting themselves and their wider
family/community and specifically on those who are directly affected as a casualty or family member,
particularly if that person was a breadwinner in the family and unable to continue in work. This is
particularly so in the context of a country which has suffered four decades of conflict and whose resilience
has decreased as a result.

196. However, despite the number and impact of security incidents in and around Kabul city, we find that
these are not at such a high level so as to make internal relocation to Kabul unsafe. In particular, although
not necessary to reach the threshold in Article 15(c) of the Qualification Directive, we note that the
evidence before us shows that the level of indiscriminate violence falls very far short of that sort of
threshold and directly affects (by way of death or injury) only a tiny proportion of the population of Kabul
city - less than 0.01% even if there were 5000 incidents in a year (more than double the numbers recorded
by UNAMA in the first half of 2017 plus the same again assuming the same numbers in the second half of
2017) with a population of 4.5 million. The calculations vary depending on the population estimates but
even on conservative calculations with high casualty figures and low population estimates, the percentages
of people affected are incredibly small. This remains the case even with significant underreporting of
casualty figures by UNAMA based on their strict methodology for casualties to be included.

197. Further, we find that the security situation affects the entire population of Kabul city, as shown by the
varied locations and targets of attacks throughout the city and not just a particular geographical area or
particular group of residents. In particular, we do not find that there is any increased risk to returnees over
and above that faced by the population of Kabul city as a whole. The Appellant's contention that returnees
are more exposed to random and indiscriminate violence because of their need to seek day-to-day
employment and move about the city to do so does not have any evidential basis. It is not just returnees
who need to move around the city, the majority of its residents need to do so for work and normal daily
necessities, travelling in from the outskirts of the city where accommodation is more affordable for day-today as well as regular employment. In any event, we do not find that regular movement of itself materially
adds to the risk of exposure to indiscriminate violence – contrary to, for example, a situation where security
incidents are focused on a particular area where a person would need to go to for employment. Although it
may be that the richest residents of Kabul have greater resources to protect themselves and their property
from the risk of indiscriminate violence, they are the significant minority and are not in any event insulated
from the broader security situation particularly as they also live in higher risk more central areas of the city.

198. Although we have considered the specific situation in Kabul, we also find that it is not significantly
worse, if at all, than the security situation prevalent throughout the majority of Afghanistan. The UN


-----

strategic review in 2017 has reclassified Afghanistan from a post-conflict country to one in active conflict,
assessing the situation for the country as a whole.

199. Conflict is present in the vast majority of provinces in Afghanistan resulting in civilian casualties and
internal displacement of the population. The number of incidents and number of resulting casualties varies
significantly between provinces but so do the population as well as population density and geography of
the province which impacts on the latter. Although the highest number of civilian casualties is recorded in
Kabul in the UNAMA figures, it is also the province with the highest population and population density. The
maps in Appendix B show the worst affected provinces by number of security incidents and number of
security incidents compared to population. On neither measure is Kabul the worst or even one of the worst
affected areas. We find that the security situation is one which affects the majority of the population of
Afghanistan and extends throughout the majority of the territory.

200. On the second point raised by the UNHCR for consideration, the Respondent has proposed Kabul as
a place of internal relocation (and that is the only area within the ambit of this appeal that we are able to
consider) and that is also where a person would be directly returned to by the Respondent. There is
therefore no identifiable issue with a person safely accessing the proposed area of location. They would
be returned directly to it.

201. The further consideration highlighted by the UNHCR for those who have a well-founded fear of
persecution from an AGE is the ability of the AGE to pursue the person to the area of proposed relocation
as well as the ability of the state to provide protection in that area. Evidence of the AGEs capacity to carry
out attacks outside the area under their effective control needs to be taken into account. We have
considered these points already above as to risk on return for a person to Kabul from the Taliban or other
AGE. There is no real risk that a low-level individual would be successfully targeted by the Taliban in
Kabul.

202. We return here as a starting point to the views of the UNHCR in determining the reasonableness of a
place of internal relocation taking into account the security, human rights and humanitarian environment in
Kabul, which provides an appropriate structure for the relevant factors to be considered about the
proposed place of relocation. As set out above, the UNCHR considers that internal relocation is
reasonable only where an individual has access to (i) shelter, (ii) essential services such as sanitation,
healthcare and education; and (iii) livelihood opportunities. Further, the UNHCR consider that it is only
reasonable where a person also has access to a traditional support network of members of his or her
(extended) family or members of his or her larger ethnic community in the area of proposed relocation who
have been assessed as willing and able to provide genuine support to a person. However, there is a
possible exception to this last requirement for single able-bodied men and married couples of working age
without identified specific vulnerabilities who may, in certain circumstances, be able to subsist without
family and community support in urban and semi-urban areas that have the necessary infrastructure and
livelihood opportunities to meet the basic necessities of life and that are under effective Government
control. A case-by-case analysis will nevertheless be necessary.

203. We take into account that the last UNHCR guidelines on Afghanistan were issued in April 2016 and
are usually only issued every few years, such that the evidence of a continuing deterioration of conditions
in Afghanistan since that date has not expressly been taken into account. However, we also take into
account that in December 2016, although the UNHCR cautioned against returns to Kabul on an internal
relocation basis because of the sudden and significant increase in population (caused by rapid
urbanization as well as the influx of IDPs and returnees), it maintained the April 2016 statement as
remaining relevant for assessments of internal relocation to Kabul. We note that 2016 was characterised
not only by the sudden and significant increase in population but also by a deteriorating security situation,
which would have been taken into account by the UNHCR in December 2016. We are not aware of any
more recent assessment of the situation by the UNHCR, although we bear in mind that while the security
situation has since worsened further in 2017 and the influx of population relocating to Kabul (internally from
within Afghanistan and externally from other countries) has continued, it has not been at such a high level
as seen in 2016. We do not consider therefore that there has been such a significant shift in conditions in


-----

Kabul since December 2016 so as to affect the weight we attach to the UNHCR position confirmed at that
time.

204. We consider first the issue of whether a support network is necessary for a person to internally
relocate to Kabul without undue harshness, given that this issue runs through the evidence on
accommodation and employment as well as the grain of social life in Afghanistan.

205. The social norms in Afghanistan are for people to live in family groups (immediate and more
commonly extended family groups) within communities of the same ethnic/tribal group. This provides,
dependent on the availability of resources and general situation of such groups/communities, a level of
support for an individual within Afghanistan. Such networks have importance both socially and
economically, in terms of employment and accommodation. A single person living alone is outside of the
social norms in Afghanistan and relatively uncommon.

206. Much of the evidence before us, particularly from Dr Schuster, emphasised the importance of support
networks to an individual for most aspects of basic life and survival with her key conclusions being that a
person would be highly unlikely to find accommodation or employment without a person to vouch for them
(other than perhaps with significant financial resources, for example to put down six months' rent in
advance for accommodation). However, Dr Giustozzi, whilst also acknowledging the importance of support
networks in society, stated that these were not essential for a person to obtain basic accommodation and
employment in Kabul and although a person may be asked who they are, their father's name and where
they come from, it is not necessarily the case that that information would be checked or that it would be
followed up by contact for a reference from such information, i.e. from a person's family or home area.

207. Whilst we accept the evidence that for more formal and/or expensive accommodation or to obtain
more skilled employment (particularly for those jobs requiring, for example, trustworthiness, i.e.
accountants or those handling large sums of money) is likely to require references form someone within a
support network, we prefer the evidence of Dr Giustozzi that this is not essential to obtain accommodation
or employment in every case. He was able to give specific examples of situations where such a reference
or support network would or would not be essential with justification for why that was so depending on the
context, particularly of the type of employment sought.

208. There are a number of variables which are also relevant to consider about the nature of a support
network which means that it is not a simple or straightforward question as to whether a person has one to
determine whether they would be in a better position if one exists at the point of return. We do not
however doubt that a person with a strong family or other support network in Kabul (or potentially in
Afghanistan) would be in a stronger position on return to Kabul, particularly if that support network included
wealthy or influential individuals with good connections themselves.

209. We take into account that there was little evidence before us about the differing quality of support
networks for an individual or recognition that the material usefulness of a support network must depend on
the resources and position of those in it. The Appellant's position was put more simply as a binary
question as to whether there was a support network leading to a better or worse outcome without any
recognition that its relevance to a person on return was likely to be somewhere on a spectrum depending
on variable factors.

210. It was accepted by Dr Schuster that the impact of decades of conflict in Afghanistan has reduced the
ability of ordinary Afghans to help extended family members or members of their community given their
own reduced resources, such that some who are willing to help may not be able to do so. It is also
reasonable to infer that many families and/or communities may not have the required connections or status
to provide any material support, for example in helping them to secure employment. It is not therefore a
simple question as to whether a person has a support network in Kabul, but more of an assessment, if
needed, of the nature and quality of such a support network.

211. We also do not consider that the issue is limited to whether a person has a support network only in
Kabul, as the system of checks and references in which a person can be vouched for could also


-----

reasonably be used across other parts of Afghanistan (although we appreciate that this would preclude
direct practical support in Kabul city).

212. Further, we do not consider that the issue of support networks is a question which answered in the
negative for a particular person would necessarily remain the same after return. Networks can be
reactivated and established. Dr Schuster gave evidence of single men and returnees from Iran forming
their own support network and also that it was possible for a single man to be included within a network
through a single member of it, which may happen, for example, through employment. We also find it
reasonable to assume that it may happen through a member of a person's wider community or tribe given
Dr Schuster's evidence that, it is inevitable that a person would make contact with someone from such a
group on return to Kabul.

213. We do not find that it is an essential requirement for a person to have an existing support network in
Kabul for them to be able to access housing or employment there and that conclusion is supported Dr
Giustozzi's evidence and by the UNHCR's position that there are possible exceptions to the need for a
support network for single able-bodied men and married couples of working age without identified specific
vulnerabilities in urban and semi-urban areas with the necessary infrastructure and livelihood opportunities
to meet the basic necessities of life and are under effective Government control. For the reasons set out
below, we find that Kabul is such a place where a support network is not essential, and that internal
relocation is generally reasonable without one for a single male in good health.

214. In relation to shelter/available accommodation, there are a variety of types of shelter in use in Kabul
city, together with an unknown level of homelessness (albeit there was no evidence before us of
widespread homelessness or destitution). The types of accommodation available range from tents,
squatting in abandoned buildings and makeshift accommodation in camps, to dormitory accommodation,
renting a room, and small dwellings through to apartments and houses. These range from the lowest to
highest cost. There is no evidence before us as to the breakdown of the proportion of people who live in
different types of accommodation or whether different types of accommodation are inhabited by particular
groups.

215. The evidence shows that around 74% of people in Kabul currently live in informal settlements which
have very limited sanitation, (only 50% of the population had access to improved sanitation facilities in
2013, which is likely to be lower now), drainage or access to potable water (only 20% of the total
population had access to piped water in 2013 which is likely to be lower now but water can be purchased),
but those in informal settlements are likely to have access to electricity (albeit with irregular supply, 95% of
the population had access to electricity in 2013, although that is also likely to be lower now due to
population growth in the city). Those informal settlements inevitably cover a range of types of
accommodation but share similar standards in terms of associated amenities and the lack of
regulation/building control.

216. We find that apart from the minority who have the greatest financial means to afford the highest
priced accommodation in central urban areas/districts in Kabul, which offer the best available
accommodation and amenities, the vast majority of residents in Kabul live in relatively poor
accommodation with less access to basic associated services. It is reasonable to infer that the majority of
returnees would settle in these informal settlements given that they cover the majority of the
accommodation in the city. The population living in informal settlements in Kabul far exceeds the number
of returnees and IDPs in the city and also contains the urban poor.

217. For social and practical reasons, a single male may have a more limited choice of accommodation in
Kabul than families because there may be suspicion as to a single male living near family groups or
women; although there is some evidence of single rooms and other accommodation being available, as
well as of groups of single men sharing accommodation. As a single man, a person's need for
accommodation would however be less than for a larger family group which may to some extent mean that
he is no worse off as a single man for this reason, even if some accommodation is unavailable for those
social reasons.


-----

218. The further practical considerations for access to accommodation are a person's financial resources
(which we cover below) and whether a support network is needed. For the reasons set out above, we
have concluded that a support network is not essential for access to accommodation of a comparable
standard to that of the majority of the population in Kabul.

219. In conclusion, we do not find that a single male returning to Kabul would be unable to find some sort
of accommodation which is comparable to that available for the majority of the population in Kabul, even
without support from a network in the city,

220. The accommodation situation is not dissimilar throughout the rest of Afghanistan where the standard
of accommodation and access to basic amenities like improved water sources and improved sanitation is
poor. In 2015, it was found that 85% of urban houses in Afghanistan were classified as slums and only
45% had access to improved water sources in 2018. We do not find that a single male returning to Kabul
would face accommodation conditions which are materially worse than that available in other parts of
Afghanistan.

221. In terms of access to other essential services, we have set out the evidence as to access to
healthcare above and there was no specific evidence before us on access to education, which is not
directly relevant to an adult male returnee. Although there is a basic package of healthcare in Afghanistan,
around a third of the total population have inadequate access to it with significant barriers and inequality of
access. The position is better in Kabul in particular and urban areas generally rather than rural areas and
is better for men than for women, albeit around half of all residents in Kabul cannot afford medical
treatment. There is little to suggest that a returnee in good health is any worse off or has any less access
to healthcare than the majority of the population in Kabul, and the position is better there than in other parts
of Afghanistan.

222. In terms of employment and economic conditions, we take into account at the outset the high rates of
unemployment (as well as under-employment) and the fact that over a third of the population in
Afghanistan earn below the poverty line of 1150 Afghanis ($20) a month. Stable, higher quality/better paid
employment is difficult to obtain in Kabul (or elsewhere) without appropriately placed connections that a
person can rely on – the evidence before us is consistent in that regard, that jobs are not advertised, and
employment not offered on the basis of merit or open competition but are given to members of a
family/those with connections.

223. However, Dr Schuster and Dr Giustozzi gave evidence of availability of lower skilled jobs which did
not require specific skills, experience or connections, including day labouring or portering work and other
occupations such as being a taxi driver. This evidence was supported in the wider documentary evidence
before us, which also included reference to other low or unskilled labour such as jobs in the bazaars, in the
construction industry and agricultural workers. Work as a day labourer would be precarious, without
guarantee of regular work and may only earn a person up to $4.40 a day. However, in the context of a city
where Dr Schuster's evidence was that one breadwinner would often support up to fifteen members of his
extended family, a single man could survive much better on low or unskilled jobs, or irregular work as his
needs would be far less.

224. There were limited examples before us of individuals who, for economic reasons, may have been
more susceptible to poor employment conditions or coercion (including working in return for
accommodation or even with no salary, bonded labour, employment in hazardous occupations and so on).
Ms Winterbotham accepted that there was no specific evidence of the latter in Kabul and in any event,
younger boys rather than adults were more at risk. Of the former, we are unable to conclude from the
isolated examples that this is a widespread problem.

225. As a minor point, we do attach some weight to the fact that Kabul remains a destination of choice for
returnees (for example, with almost a quarter of returnees from Pakistan in 2016 settling in Kabul), IDPs
and economic migrants given that it has greater economic prospects than other areas.


-----

226. In light of our findings above and due to what Ms Winterbotham described as the complex non-linear
reasons why people joined armed gangs, we do not find that it has been established that there is any real
risk that a single man will feel compelled to join an armed gang for economic survival in Kabul.

227. Finally, we take into account the evidence about possible assistance on return to Kabul for those
returned, voluntarily or forcibly. There was before us a variety of evidence of different forms of support
from different organisations, much of which suffered from a lack of take-up from individuals more than a
lack of available resources. We are mindful that there was little firm evidence of what support was in reality
being provided to returnees (and how that differed, if at all, between voluntary and forced returnees) and
that the position as at August 2017 was specifically unclear as to IOMs continuing involvement or not in the
provision of the main packages of support. However, overall, we find that there is sufficient evidence
before us to establish that there is a basic level of support, referred to by some as a 'parachute package'
which includes the offer of temporary accommodation, travel expenses and either cash on return or
support in-kind for those with a plan to establish themselves in Kabul. Even if, on Dr Schuster's evidence,
this may only last a person four to six weeks (or less if not astute or lack knowledge of local prices), that
places a returnee from the United Kingdom in a better position than many other returnees (for example
those from Iran in particular) and IDPs. This additional, albeit limited support, makes a material, even if
only marginal, difference to the reasonableness of return to Kabul for a single healthy male.

228. Overall, although the economic conditions in Kabul are poor, we find that those conditions affect the
urban poor as much as returnees and IDPs and that together, these groups likely account for the majority
of the population in Kabul (in particular taking into account what information there is as to unemployment
and under-employment in the context of the economy as a whole). We find that there are livelihood
opportunities available for single men in good health on return to Kabul such that there is no real likelihood
that they would be forced to turn to crime, be subject to exploitative work or join an armed AGE.

229. We find that if anything, the economic conditions in Kabul, the capital city in which there are greater
employment opportunities than other, particularly rural areas, are better than other parts of Afghanistan.

230. Our findings above show that it is not generally unsafe or unreasonable for a single healthy man to
internally relocate to Kabul. However, we emphasise that a case-by-case consideration of whether internal
relocation is reasonable for a particular person is required by Article 8 of the Qualification Directive and
domestic authorities including Januzi and AH (Sudan). When doing so, we consider that there are a
number of specific factors which may be relevant to bear in mind. These include, individually as well as
cumulatively (including consideration that the strength of one factor may counteract and balance the
weakness of another factor):

(i) Age, including the age at which a person left Afghanistan.

(ii) Nature and quality of connections to Kabul and/or Afghanistan.

(iii) Physical and mental health.

(iv) Language, education and vocational and skills.

231. We consider age as a relevant factor given that we have not seen any reason or evidential basis to
depart from the specific guidance given in AA (unattended children) Afghanistan CG [2012] UKUT 00016,
which was supported in evidence before us as to greater risk to or vulnerability of minors. There is no
bright line rule at the age of 18 when a person in the United Kingdom is considered to be an adult (there
are different views as to becoming an adult and in particular as to achieving manhood in Afghan society
which is not specifically linked to age but more to marital status) where such issues fall away overnight but
are more likely to gradually diminish.

232. We also consider the age at which a person left Afghanistan to be relevant as to whether this
included their formative years. It is reasonable to infer that the older a person is when they leave, the more
likely they are to be familiar with, for example, employment opportunities and living independently.

233. Although we find that it is reasonable for a person without a support network or specific connections
in Kabul or elsewhere in Afghanistan to internally relocate to Kabul a person will be in a more


-----

advantageous position if they do have such connections depending on where they are, the financial
resources of such people and their status/connections. We have in mind that the availability of a support
network may counter a particular vulnerability of an individual on return.

234. In our conclusions, we refer throughout to a single male in good health as this is the primary group of
people under consideration in this appeal and reflects the position of this particular Appellant. It is
uncontroversial that a person who is in good health or fit and able is likely to have better employment
prospects, particularly given the availability of low or unskilled jobs involving manual labour in Kabul. We
were not provided with any specific evidence of the likely impact of poor physical or mental health on the
safety or reasonableness of internal relocation to Kabul but consider it reasonable to infer that this could be
relevant to the issue and the specific situation of the individual would need to be carefully considered.

235. Finally, it is also reasonable to infer that a person who speaks a local language in Kabul would be in
a stronger position than a person who does not, and that educational and vocational skills would also
strengthen a person's ability to support himself in Kabul with better employment prospects.

**Previous Country Guidance**

236. Given the very specific question posed for country guidance in the present case, whether the current
situation in Kabul is such that the guidance given in AK needs revision in the context of consideration of
internal relocation, it is necessary for us to specify what effects, if any, our decision has on AK and on other
country guidance pertaining to Afghanistan.

237. Ms Naik invited us to find that the guidance on whether the Article 15(c) threshold is met in Kabul
contained in AK is no longer binding and until further country guidance is given on the matter, Tribunals
should decide this point on a case-by-case basis on the evidence before them. The submission relied
upon (i) paragraphs 12.2 and 12.4 of the Practice Directions of the Immigration and Asylum Chambers of
the First-Tier Tribunal and the Upper Tribunal (issued by Lord Justice Carnwath, Senior President of the
Tribunals in February 2010 and amended by Sir Jeremy Sullivan in the same capacity in November 2014);
(ii) the significant passage of time since AK; and (iii) the limitation of the issues in this appeal to internal
relocation only which is distinct from the separate legal question as to eligibility for subsidiary protection
under the Qualification Directive.

238. We do not accept Ms Naik's submission. The mere fact of a passage of time does not of itself render
country guidance no longer applicable and the fact that in the case before us, the Appellant chose not to
rely on Article 15(c) of the Qualification Directive as a reason why he could not return to Kabul (despite this
being the main thrust of his application for permission to appeal and the error of law decision which
followed) means that we have not been expressly addressed on the point by the Appellant to support any
change to the guidance given in AK on this point. To the contrary, the evidence that was before us which
may be relevant to the separate legal question of the eligibility of subsidiary protection, was consistent with
the findings and country guidance given in AK that the level of indiscriminate violence in Kabul is not at
such a high level as to mean that, within the meaning of Article 15(c) of the Qualification Directive, a
civilian, solely by being present in the country, faces a real risk which threatens his life or person. In any
event, in accordance with the Practice Directions referred to above, a Tribunal may depart from country
guidance if there is sufficient credible fresh evidence before it relevant to the issue to be determined that
was not considered.

239. The qualification in AK in relation to certain categories of women when considering the question of
internal relocation also remains, as the evidence before us focused on single males and not the position of
women. In any event, this continues to be the Respondent's position as set out in her “Country Policy and
Information Note – Afghanistan: Security and Humanitarian Situation” (August 2017), which itself refers to
the Respondent's “Impact on women and children and the country policy and information note on
Afghanistan: Women fearing gender-based/violence)” to the same effect.

240. Similarly, we have not seen any reason or evidential basis to depart from the specific guidance given
in AA (unattended children) Afghanistan CG [2012] UKUT 00016.


-----

**Summary of general conclusions**

241. We set out below in summary, the country guidance from the general conclusions set out above.

Risk on return to Kabul from the Taliban

(i) A person who is of lower-level interest for the Taliban (i.e. not a senior government or security services
official, or a spy) is not at real risk of persecution from the Taliban in Kabul.

Internal relocation to Kabul

(ii) Having regard to the security and humanitarian situation in Kabul as well as the difficulties faced by the
population living there (primarily the urban poor but also IDPs and other returnees, which are not dissimilar
to the conditions faced throughout may other parts of Afghanistan); it will not, in general be unreasonable
or unduly harsh for a single adult male in good health to relocate to Kabul even if he does not have any
specific connections or support network in Kabul.

(iii) However, the particular circumstances of an individual applicant must be taken into account in the
context of conditions in the place of relocation, including a person's age, nature and quality of support
network/connections with Kabul/Afghanistan, their physical and mental health, and their language,
education and vocational skills when determining whether a person falls within the general position set out
above.

(iv) A person with a support network or specific connections in Kabul is likely to be in a more
advantageous position on return, which may counter a particular vulnerability of an individual on return.

(v) Although Kabul suffered the highest number of civilian casualties (in the latest UNAMA figures from
2017) and the number of security incidents is increasing, the proportion of the population directly affected
by the security situation is tiny. The current security situation in Kabul is not at such a level as to render
internal relocation unreasonable or unduly harsh.

Previous Country Guidance

(vi) The country guidance in AK (Article 15(c)) Afghanistan CG [2012] UKUT 163 (IAC) in relation to Article
15(c) of the Qualification Directive remains unaffected by this decision.

(vii) The country guidance in AK (Article 15(c)) Afghanistan CG [2012] UKUT 163 (IAC) in relation to the
(un)reasonableness of internal relocation to Kabul (and other potential places of internal relocation) for
certain categories of women remains unaffected by this decision.

(viii) The country guidance in AA (unattended children) Afghanistan CG _[2012] UKUT 00016 (IAC) also_
remains unaffected by this decision.

**Findings and reasons on the Appellant's claim**

242. The Appellant was accepted by the First-tier Tribunal to be at risk in his home area from the Taliban
following events in 2006/2007 and his primary case on risk of return now (as opposed to on internal
relocation which does not arise if he is at risk in Kabul) is fear of the Taliban in Kabul.

243. In terms of this Appellant, Dr Giustozzi concluded in his written report that if it is accepted that he was
wanted by the Taliban, that risk would be in his home area and in Kabul and that the risk of him being
targeted would depend on how exposed he would be (for example by giving information about himself for
the purposes of obtaining references for employment and accommodation). As the Taliban are not
authorised by their own rules to kill relatives of people they had previously targeted, Dr Giustozzi
considered that the only basis on which the Appellant could have been included on the blacklist is as a
deserter. It was assumed that there would be a concern by the Taliban that the Appellant would be hostile
to them because they had killed his father and brother (to seek revenge in accordance with the traditions of
blood feuds) and had sought to conscript him into the Taliban as a ruse to lay the conditions for him to flee
and become a deserter.


-----

244. However, in oral evidence, Dr Giustozzi stated both that the local Taliban would no longer have any
interest in the Appellant in his home area (although there may be some continuing interest in him on the
blacklist as a deserter) and that the Appellant would only be of negligible importance to the Taliban outside
of his home village. Neither conclusion provides any support for the Appellant's claim that he would be at
risk on return now and are wholly inconsistent with the written conclusions in Dr Giustozzi's report. We find
his oral evidence, following much more detailed examination of his position and reasons for it, to be the
true opinion which we attach weight to.

245. In any event, as to the possibility that the Appellant may be of interest as a deserter, Dr Giustozzi did
not know whether the Appellant was on the blacklist (assuming the blacklist does exist) and did not know
whether he had been sentenced or was or considered to be a deserter. There is nothing in the Appellant's
claim or evidence from his screening interview, asylum interview, written statements or oral evidence
before the First-tier Tribunal which lends any weight to Dr Giustozzi's theory that he was essentially set up
as a deserter as a reason to make him a legitimate target.

246. The Appellant's claim is that after his father and brother were killed, he was kidnapped by the Taliban
and was held by them as part of a group of about 20 people. After an attack on the Taliban where he was
being held, he managed, with others, to escape and then ultimately to flee Afghanistan with the assistance
of his uncle (whom the Taliban visited twice looking for the Appellant, but it has never been suggested that
this was anything more than a search for him). It has never been claimed that the Taliban sought to
conscript the Appellant, sent him any warnings, letters or any sentence for failure to comply with the same
or in fact any sentence on any other basis, despite knowing the addresses where the Appellant and his
uncle lived. On his own account and in accordance with Dr Giustozzi's evidence, the Appellant would not
obviously be a target for the Taliban at all and would not fit the criteria for inclusion on the blacklist (even if
it existed).

247. In the alternative, even if the Appellant has been identified as a target (whether or not by inclusion on
the blacklist if it exists) by the Taliban, at most he is a low-level target at the bottom end of the list of
priorities for the Taliban whose only motive for pursuing him as such would be as one of a number of kills
rather than because of his identity or risk posed to the Taliban per se. For the reasons set out above in the
general findings, that does not give rise to any real risk to the Appellant from the Taliban in Kabul.

248. The Appellant also claims in the alternative that he would be at risk on return to Kabul as a member
of a particular social group, a person who has been 'Westernised', however for the reasons set out above
in the general findings, there is no real risk to the Appellant as such. Nor is there any other reason why the
Appellant would be at risk from anyone else in Kabul, either the state authorities (as found by First-tier
Tribunal Bradshaw whose findings on this point have not been challenged and stand) or AGEs (either
directly or through any kind of forced recruitment by them).

249. The next issue is then whether it is reasonable for the Appellant to internally relocate to Kabul. The
Appellant is a healthy adult male who has spent the majority of his life in Afghanistan, going to school there
and arriving in the United Kingdom at the age of 22. He speaks Pashto and has no specific or identified
vulnerabilities. He has been out of Afghanistan now for nine and a half years but left when he was an
adult. The Appellant states that he has no contact with his family in Afghanistan (mother, brother or uncle)
and it is unknown as to whether he would be able to re-establish contact with them on return if he chose to
do so. In these circumstances, based on our general conclusions set out above, we do not find that it
would be unreasonable or unduly harsh for the Appellant to internally relocate to Kabul. He would be
returning to living and humanitarian conditions in Kabul which affect the majority of the population and
where he could live a relatively normal life without undue hardship. Whilst we accept that conditions and
prospects in Kabul, and also in Afghanistan generally, are very poor, there is no reason that this Appellant
would be any less able than any other to bear those conditions, even taking into account past treatment in
his home area. The current security situation in Kabul is not such as to render internal relocation there
unreasonably or unduly harsh.

250. The Appellant's appeal is therefore dismissed on asylum and humanitarian protection grounds and
also on human rights grounds under Articles 2 and 3 of the European Convention on Human Rights.


-----

_Article 8_

251. Immediately prior to the final day of hearing in this appeal, the Appellant sought to submit that his
removal to Kabul would be unlawful under section 6 of the Human Rights Act 1998, being a
disproportionate interference with his right to respect for private life contrary to Article 8 of the ECHR.
Further, he specifically relied on paragraph 276ADE of the Immigration Rules, that there would be “very
significant obstacles to his integration” in Kabul. However, although Article 8 of the ECHR was raised in
the Appellant's original grounds of appeal to the First-tier Tribunal and the appeal on this basis dismissed,
no permission to appeal was sought on these grounds either to the First-tier Tribunal, nor to the Upper
Tribunal and permission to appeal was not granted on such grounds. In fact, the Appellant expressly did
not rely on private life under the Immigration Rules or under Article 8 of the ECHR at any point before the
Upper Tribunal. Only when prompted at the oral hearing did Counsel for the Appellant accept this and then
indicated that the Appellant would need to make an application for permission to amend grounds of appeal
to enable this to be argued.

252. We refused to grant permission to allow the Appellant to amend his grounds of appeal on a new
human rights ground at this very late stage of proceedings, where no proper basis was made out for such a
late request and where the Respondent had had no opportunity to consider or respond.

**Notice of Decision**

The making of the decision of the First-tier Tribunal did involve the making of a material error of law for the reasons
set out in the decision of UTJ O'Connor following the hearing on 27 April 2017 (Appendix C). As such it was
necessary for him to set aside the decision.

The decision is re-made. The Appellant's appeal is dismissed on asylum, humanitarian protection and human
rights grounds.

**Direction Regarding Anonymity – Rule 14 of the Tribunal Procedure (Upper Tribunal)**
**Rules 2008**

Unless and until a Tribunal or court directs otherwise, the appellant is granted anonymity. No report of these
proceedings shall directly or indirectly identify him or any member of his family. This direction applies both to the
appellant and to the respondent. Failure to comply with this direction could lead to contempt of court proceedings.

Signed    Date  19th March 2018

IMAGE NOT AVAILABLE

Upper Tribunal Judge Jackson

**APPENDIX A - SCHEDULE OF BACKGROUND AND EXPERT EVIDENCE**

**Documents before the Upper Tribunal**

**Source** **Document (including hyperlink where** **Date**

|Source|Document (including hyperlink where available)|Date|
|---|---|---|
|European Asylum Support Office (EASO)|Country of Origin Information Report, Afghanistan – Security Situation|22 December 2017|
|European Asylum Support Office (EASO)|Country of Origin Information Report, Afghanistan – Individuals targeted by armed actors in the conflict|12 December 2017|
|European Asylum Support Office (EASO)|Country of Origin Information Report, Afghanistan – Individuals targeted under societal and legal norms|12 December 2017|
|United Nations Office for the Coordination of Humanitarian Affairs (UNOCHA)|Humanitarian Needs Overview 2018, Afghanistan|December 2017|


-----

|Col1|AS (Safety of Kabul) (CG)|Page 45 of 58|
|---|---|---|
|TOLO News|Five Civilians Wounded in Kabul Suicide Attack|17 November 2017|
|TOLO News|Three killed in IED Blast in Kabul|17 November 2017|
|Khaama Press Afghan News Agency|Suicide attack in Kabul city leaves several dead, wounded|16 November 2017|
|UNAMA|UNAMA condemns killing of civilians in Kabul suicide attack|16 November 2017|
|Khaama Press Afghan News Agency|Attack on TV shows Taliban, ISIS opposition to freedom of speech: Dostum|8 November 2017|
|Khaama Press Afghan News Agency|Coordinated suicide attack on TV Station in Kabul, causalities feared|7 November 2017|
|Khaama Press Afghan News Agency|Ghani orders probe as deadly suicide attack hits diplomatic part of Kabul|1 November 2017|
|Khaama Press Afghan News Agency|Several feared dead, wounded as suicide attack rocks Kabul|31 October 2017|
|Khaama Press Afghan News Agency|15 Army cadets killed in Kabul suicide attack|21 October 2017|
|Khaama Press Afghan News Agency|Dostum slams security officials for failures after deadly mosque bombings|21 October 2017|
|Khaama Press Afghan News Agency|No casualties reported in Kabul rocket attack|21 October 2017|
|Pajhwok Afghan News|Blast near University in Kabul|21 October 2017|
|Pajhwok Afghan News|Kabul mosque bombing: Death toll shoots to 85|21 October 2017|
|UN Assistance Mission in Afghanistan (UNAMA)|Statement of the Secretary-General's Special Representative for Afghanistan on Fridays mosque attacks|21 October 2017|
|Khaama Press Afghan News Agency|Over 30 killed as suicide bomber attacks mosque in Kabul city|20 October 2017|
|IRIN|Six charts that show Afghanistan's deepening insecurity|18 October 2017|
|Khaama Press Afghan News Agency|1 Killed, 3 wounded in grenade attacks in Kabul city|18 October 2017|
|Khaama Press Afghan News Agency|Explosion leaves driver a vehicle dead in Kabul city|17 October 2017|
|Khaama Press Afghan News Agency|ACJC police officer shot dead by gunmen in Kabul City|16 October 2017|
|Khaama Press Afghan News Agency|Explosion target police vehicle in Kabul City, causalities feared|14 October 2017|
|UN Assistance Mission in Afghanistan (UNAMA)|UN Assistance Mission in Afghanistan (UNAMA), Quarterly report on the protection of civilians in armed conflict|12 October 2017|
|Amnesty International|Forced back to danger: Asylum-seekers returned from Europe to Afghanistan|5 October 2017|
|Afghan News|5 Killed, 20 injured in Kabul mosque attack|29 September 2017|
|Khaama Press Afghan News Agency|Explosion leaves 19 dead, wounded in Kabul City|28 September 2017|
|Khaama Press Afghan News Agency|Malfunctioning US missile caused causalities in the airstrike during Kabul Attack|28 September 2017|
|Afghanistan USA|4 killed, 11 injured in Kabul Airport attack during Mattis official visit|27 September 2017|


Khaama Press Afghan News Several rockets land near Kabul international airport 27 September 2017


-----

|Col1|AS (Safety of Kabul) (CG)|Page 46 of 58|
|---|---|---|
|Agency|||
|Pajhwok Afghan News|3 Taliban men firing rockets at Kabul airport killed|27 September 2017|
|Khaama Press Afghan News Agency|Suicide attack in Kabul city leaves civilians wounded|24 September 2017|
|GOV.UK|Get help to return home if you're a migrant in the UK|21 September 2017|
|Khaama Press Afghan News Agency|Taliban rejects groups involvement in explosion near Kabul Stadium|14 September 2017|
|Khaama Press Afghan News Agency|Explosion near cricket board in Kabul|13 September 2017|
|Khaama Press Afghan News Agency|2 held as deadly clash leaves 7 dead, wounded in Kabul city|10 September 2017|
|Asylos|Afghanistan: Situation of young male 'Westernised' returnees to Kabul|8 September 2017|
|United Nations Office for the Coordination of Humanitarian Affairs (UNOCHA)|Afghanistan - Conflict Induced Displacements in 2017, as of 03 September 2017|3 September 2017|
|Khaama Press Afghan News Agency|Khaama press Afghan News Agency MoI confirms involvement of Ulema Council chiefs son in deadly Kabul wedding clash|1 September 2017|
|National Returns Command|Voluntary Returns Service (internal)|September 2017|
|Khaama Press Afghan News Agency|Suicide attack inflicts casualties in Kabul City|29 August 2017|
|The Independent|Kabul explosion Suicide bombing kills at least five in blast near US Embassy in Afghanistan's capital|29 August 2017|
|Khaama Press Afghan News Agency|Kabul mosque attack death toll rises to over 30, more than 40 wounded|26 August 2017|
|UN Assistance Mission in Afghanistan (UNAMA)|UNAMA condemns killing of civilians in Kabul mosque attack|26 August 2017|
|Pajhwok Afghan News|Pajhwok Afghan News Five people hurt in Kabul magnetic bomb blast|25 August 2017|
|Khaama Press Afghan News Agency|Explosion in Kabul City leaves one wounded|24 August 2017|
|Khaama Press Afghan News Agency|Grenade attack in Kabul City leaves at least 7 wounded|23 August 2017|
|Pajhwok Afghan News|Blast leaves 3 injured in Kabul|13 August 2017|
|Khaama Press Afghan News Agency|Suicide attack leaves one dead in Kabul city|9 August 2017|
|Pajhwok Afghan News|3 police injured in Kabul blast|9 August 2017|
|Khaama Press Afghan News Agency|Explosion targets security vehicle in Kabul city|7 August 2017|
|United Nations Office for the Coordination of Humanitarian Affairs (UNOCHA)|Afghanistan - Conflict Induced Displacements in 2017, as of 6 August 2017|6 August 2017|
|Khaama Press Afghan News Agency|Explosion targets civilian vehicle in Kabul City|4 August 2017|
|Khaama Press Afghan News Agency|Explosion inflicts causalities to civilians in Kabul city|3 August 2017|
|European Asylum Support Office (EASO)|Country of Origin Information Report Afghanistan Key socio-economic, and mobility in Kabul City, Mazar-e Sharif, and Herat City|August 2017|


Home Office Country Policy and Information Note – Afghanistan: August 2017


-----

|Col1|AS (Safety of Kabul) (CG)|Page 47 of 58|
|---|---|---|
||Security and humanitarian situation||
|Emily Winterbotham|Expert Report|31 July 2017|
|Khaama Press Afghan News Agency|Khaama Press Afghan News Agency clash among police forces and armed robbers in Kabul city|31 July 2017|
|UN Assistance Mission in Afghanistan (UNAMA)|UNAMA condemns attack on Iraqi embassy in Kabul|31 July 2017|
|Dr Schuster|Expert Report|26 July 2017|
|CNN|31 dead in Kabul car bomb attack claimed by Taliban|25 July 2017|
|BBC|Kabul suicide car bomb: 30 killed in Afghan capital|24 July 2017|
|Guardian,|Afghanistan: dozens dead in Kabul bombing targeting government workers|24 July 2017|
|Refworld Afghanistan:|UN condemns attack on civilians in Kabul|24 July 2017|
|Dr Giustozzi|Expert Report|20 July 2017|
|Khaama Press Afghan News Agency|Khaama Press Afghan News Agency Six rockets land near Sayyaf's residence in Kabul|20 July 2017|
|Khaama Press Afghan News Agency|Khaama Press Afghan News Agency Bride killed, 4 others wounded in Kabul firing involving Mohaqiq's guards|17 July 2017|
|International Organization for Migration (IOM)|Displacement Tracking Matrix Baseline Mobility Assessment, Summary Results Afghanistan June 2017|7 July 2017|
|Pajhwok Afghan News|Pajhwok, 2 civilians killed, 1 injured as rockets hit|5 July 2017|
|Khaama Press Afghan News Agency|Khaama Press Afghan News Agency Senior police officer killed in Kabul explosion|4 July 2017|
|UN Assistance Mission in Afghanistan (UNAMA)|Protection of civilians in armed conflict – Midyear report 2017|July 2017|
|United Nations Office for the Coordination of Humanitarian Affairs (UNOCHA)|Humanitarian Bulletin Afghanistan Issue 65|30 June 2017|
|The Guardian|'Before my brother died, I had dreams': the Kabul attack that unravelled a family|26 June 2017|
|Khaama Press Afghan News Agency|Explosion in Kabul city leaves one wounded|21 June 2017|
|BBC|Kabul blast: Protester killed near bomb site|20 June 2017|
|New York Times|7 US Soldiers Wounded in Insider Attack in Afghanistan|17 June 2017|
|Khaama Press Afghan News Agency|American national kidnapped in Kabul city|16 June 2017|
|Radio Free Europe|Four Killed In Attack On Shi'ite Mosque In Kabul Claimed By Islamic State|15 June 2017|
|Khaama Press Afghan News Agency|Clash in Kabul city leaves armed robber dead|14 June 2017|
|Khaama Press Afghan News Agency|Explosion targets vehicle in Kabul, no casualties reported: officials|14 June 2017|
|CNN|Kabul bombing: Death toll jumps to 150, one week after attack|6 June 2017|
|Khaama Press Afghan News Agency|No causalities or damage as rocket lands in Kabul city|6 June 2017|
|Afghanistan Analysts Network|A Black Week in Kabul: Terror and protests|4 June 2017|
|BBC|Kabul blast: Deadly explosions at protest victim's funeral|3 June 2017|
|BBC|Kabul bomb: Protesters shot dead at march in Afghan capital|2 June 2017|
|US Department of State|Trafficking in Persons Report 2017 (excerpt)|June 2017|


UN Assistance Mission in
Afghanistan (UNAMA)


UNAMA condemns indiscriminate killing in Afghan capital 31 May 2017


-----

|Col1|AS (Safety of Kabul) (CG)|Page 48 of 58|
|---|---|---|
|Khaama Press Afghan News Agency|Ex-Afghan MP wounded in an attack in Kabul City|24 May 2017|
|Pajhwok Afghan News|Situation in Afghanistan may deteriorate in 2018: Coats|24 May 2017|
|BBC|German woman killed and Afghan guard beheaded in Kabul|21 May 2017|
|Khaama Press Afghan News Agency|Militants launch coordinated attack on Kabul Bank in Gardez|20 May 2017|
|Bjelica and Rutting / Afghanistan Analysts Network|Voluntary and Forced Returns to Afghanistan in 2016/17- Trends, statistics and experiences|19 May 2017|
|TOLO News|Residents Protest Against 'Rise' In Crime In Kabul City|17 May 2017|
|Khaama Press Afghan News Agency|No Causalities reported in Kabul explosion: Danish|15 May 2017|
|BBC|Kabul bomb attack targeting NATO convoy kills eight|3 May 2017|
|NewsMax|Report: Hundreds of Millions being wasted in Afghanistan Fraud|21 April 2017|
|Khaama Press Afghan News Agency|No casualties reported in Kabul City explosion: MoI|20 April 2017|
|Khaama Press Afghan News Agency|2 people wounded in an explosion in Kabul city|17 April 2017|
|Al Jazeera|Suicide bomb attack in heart of Kabul kills five|12 April 2017|
|Radio Free Europe|IS Claims Suicide Bombing In Kabul, Five Dead|12 April 2017|
|Khaama Press Afghan News Agency|Afghan army soldier shot dead in Kabul city|11 April 2017|
|Pajhwok Afghan News|Sticky bomb on traffic police van goes off in Kabul|11 April 2017|
|Khaama Press Afghan News Agency|2 anti-corruption judicial centre employees shot dead in Kabul|10 April 2017|
|Afghanistan Times|262 police personal arrested on different charges including corruption|6 April 2017|
|UN Assistance Mission in Afghanistan (UNAMA)/ OHCHR|Treatment of Conflict-Related Detainees: Implementation of Afghanistan's National Plan on the Elimination of Torture|April 2017|
|Khaama Press Afghan News Agency|1 killed, 2 wounded in gunmen firing in Kabul City|18 March 2017|
|Khaama Press Afghan News Agency|2 policemen shot dead by unknown gunmen in Kabul city|14 March 2017|
|Euronews|Afghanistan blast: one dead and nearly 20 injured in deadly minibus explosion|13 March 2017|
|VOA News|Afghan Corruption Watchdog Warns of Graft's Consequences|11 March 2017|
|Radio Free Europe|Death Toll In Kabul Military Hospital Attack Rises To 49|9 March 2017|
|The Guardian|Isis militants disguised as doctors kill 38 in Kabul hospital attack|8 March 2017|
|Khaama Press Afghan News Agency|Explosion in Kabul leave one person dead|7 March 2017|
|Al Jazeera|Taliban claims deadly Kabul attacks|2 March 2017|
|AP News|Taliban suicide attacks, shootout kill 16 in Afghan|2 March 2017|
|Khaama Press Afghan News Agency|Kabul attacks causalities toll rise to 22 dead, 120 wounded|2 March 2017|
|International Organization for Migration (IOM)|Life After Return: Undocumented Returnees (from UNOCHA, Humanitarian Bulletin - Afghanistan, Issue 61, 01-28 February 17)|March 2017|


Pajhwok Afghan News Policeman guns down one civilian, wounds another 20 February 2017


-----

|Col1|AS (Safety of Kabul) (CG)|Page 49 of 58|
|---|---|---|
|Human Rights Watch|Pakistan coercion, UN complicity: The Mass Forced Return of Afghan Refugees|13 February 2017|
|Khaama Press Afghan News Agency|Explosion in defence ministry in Kabul, no causalities reported|11 February 2017|
|Foreign and Commonwealth Office|Human Rights Priority Country status report: July to December 2016|8 February 2017|
|UN Assistance Mission in Afghanistan (UNAMA)|UNAMA condemns attack outside Supreme Court in Kabul|8 February 2017|
|United Nations High Commissioner for Refugees (UNHCR)|Tough choices for Afghan refugees returning home after years in exile|3 February 2017|
|Washington Post|Afghan government controls just 57 percent of its territory, US|2 February 2017|
|UN Assistance Mission in Afghanistan (UNAMA)|Protection of civilians in armed conflict – Annual report 2016|February 2017|
|International Monetary Fund|Return of Afghan Refugees to Afghanistan Surges as Country Copes to Rebuild|26 January 2017|
|United Nations in Afghanistan|Population Movement Bulletin – issue 8|26 January 2017|
|DW News|Afghan migrant returns as a stranger to a deteriorating|25 January 2017|
|Transparency International|Corruption Perceptions Index 2016|25 January 2017|
|Pajhwok Afghan News|In harsh winter, Kabul's tent dwellers struggle to survive|24 January 2017|
|TOLO News|US Stops Salaries Of 30,000 Ghost Soldiers|20 January 2017|
|Pajhwok Afghan News|Sticky bomb injures 2 police officers in Kabul|18 January 2017|
|IRIN|Afghanistan now a 'continual emergency', as war drives record numbers from their homes|10 January 2017|
|Khaama Press Afghan News Agency|Gunmen open fire on cricketer Shapoor Zadran in Kabul|8 January 2017|
|Amnesty International|Afghanistan 2016/17|2017|
|Human Rights Watch|Afghanistan, Events of 2016|2017|
|US Department of State|Afghanistan 2016 Human Rights Report|2017|
|Pajhwok Afghan News|Wounded bride: All my dreams shattered|31 December 2016|
|Winterbotham and Quentin|Making the Case for Afghanistan: Why Now Is Not the Time to Abandon the Country|29 December 2016|
|Bjelica / Afghanistan Analysts Network|Over Half a Million Afghans Flee Conflict in 2016: A look at the IDP statistics|28 December 2016|
|Radio Free Europe|Afghan Lawmaker Injured In Kabul Bomb Attack|28 December 2016|
|Radio Free Europe|Gunmen Attack Ex-Taliban Official's Home In Kabul|24 December 2016|
|BBC|Afghanistan Taliban: Eight dead in attack on MP's house|22 December 2016|
|Reuters|Taliban claim attack on house of Afghan member of parliament|21 December 2016|
|Khaama Press Afghan News Agency|Shooting in Kabul airport leave a foreigner dead|14 December 2016|
|Asia Foundation|A Survey of the Afghan People - Afghanistan in 2016 (excerpts)|7 December 2016|
|Khaama Press Afghan News Agency|Magnetic bomb explosion leaves 3 wounded in Kabul City|2 December 2016|
|Home Office|Country Policy and Information Note – Afghanistan: Fear of anti-government elements (AGEs)|December 2016|
|Pajhwok Afghan News|Bomb attached to Lexus vehicle goes off in Kabul|23 November 2016|
|Pajhwok Afghan News|Social activist Omarkhel attacked, hospitalised|20 November 2016|
|The Seattle Times|Afghan officials: Suicide bomber kills 6 in Kabul|16 November 2016|
|Khaama Press Afghan News|Explosion in Kabul leaves 1 dead|15 November 2016|


-----

|Col1|AS (Safety of Kabul) (CG)|Page 50 of 58|
|---|---|---|
|Agency|||
|In These Times|Inside Afghanistan's Internally Displaced Person Camps|15 November 2016|
|Pajhwok Afghan News|Man killed another wounded in blast outside Kabul mosque|7 November 2016|
|New York Times|Afghanistan Itself Is Now Taking In the Most Afghan Migrants|4 November 2016|
|European Asylum Support Office (EASO)|Country of Origin Information Report: Afghanistan Security Situation (excerpts)|November 2016|
|United Nations Office for the Coordination of Humanitarian Affairs (UNOCHA)|Afghanistan: 2017 Humanitarian Needs Overview|November 2016|
|Bjelica / Afghanistan Analysts Network|Afghan Exodus: Can the Afghan government deal with more returnees from Europe?|31 October 2016|
|Khaama Press Afghan News Agency|Explosion in Kabul leaves 2 soldiers, 3 civilians wounded|29 October 2016|
|Pajhwok Afghan News|Driver wounded in bomb attack on ANA pick up|23 October 2016|
|World Justice Project|Rule of Law Index 2016|20 October 2016|
|BBC|Two Americans killed at military base in Afghanistan|19 October 2016|
|Khaama Press Afghan News Agency|Explosion in Taimani area of Kabul city|18 October 2016|
|Human Rights Watch|Afghanistan's Shia Hazara Suffer Latest Atrocity - Insurgents' Increasing Threat to Embattled Minority|13 October 2016|
|The Guardian|Gunmen kill 14 people in attack on Shia Muslim shrine in Kabul|11 October 2016|
|Reuters|US watchdog questions money spent on Afghan 'ghost' soldiers|7 October 2016|
|Khaama Press Afghan News Agency|Suicide attack in Kabul leaves at least 4 civilians wounded|5 October 2016|
|Pajhwok Afghan News|20 injured as suicide bomber hits mini bus in Kabul|5 October 2016|
|The Guardian|Afghan exodus from Pakistan could be 'catastrophic' without urgent aid|4 October 2016|
|International Crisis Group|The Economic Disaster Behind Afghanistan's Mounting Human Crisis|3 October 2016|
|Pajhwok Afghan News|1 killed, 2 wounded in Kabul explosion|3 October 2016|
|Pajhwok Afghan News|Suicide attack foiled in Kabul; bomber shot dead|26 September 2016|
|Khaama Press Afghan News Agency|Explosion in Kabul leaves one dead and another one wounded|14 September 2016|
|RahaPress|US embassy, NATO base in Kabul placed on brief lockdown|12 September 2016|
|Pajhwok Afghan News|Magnetic Bomb hits ANA vehicle: no causalities|9 September 2016|
|Daily Mail|Global charity attacked in deadly wave of Kabul violence|6 September 2016|
|Washington Post|Kabul shaken by attacks on international charity and Defence Ministry|6 September 2016|
|CNN|Third bomb strikes Kabul, Afghanistan|5 September 2016|
|New York Times|Coordinated Bombs in Kabul Kill Senior Afghan Officials at Defence Ministry|5 September 2016|
|European Asylum Support Office (EASO)|Afghanistan Recruitment by armed groups|September 2016|
|1TVNews|Afghan officials' collaboration with Taliban fuelling war in Helmand|31 August 2016|
|Mubarak, Wagner et al.|'Hygienic practices and diarrheal illness among persons living in at-risk settings in Kabul, Afghanistan: a cross- sectional study', BMC Infectious Diseases (2016)|31 August 2016|


-----

|Col1|AS (Safety of Kabul) (CG)|Page 51 of 58|
|---|---|---|
|Khaama Press Afghan News Agency|Explosion in Kabul leaves one wounded|27 August 2016|
|Pajhwok Afghan News|1 soldier killed, another wounded in Kabul blast|20 August 2016|
|Pajhwok Afghan News|ANA officer, civilian wounded in Kabul bomb attack|15 August 2016|
|Khaama Press Afghan News Agency|Explosion in Kabul leaves 1 dead, 3 others wounded|8 August 2016|
|Pajhwok Afghan News|1 ANA soldier killed, 3 wounded in Kabul bomb attack|8 August 2016|
|Daily Mail|Taliban truck bomb blasts hotel for foreigners|1 August 2016|
|Khaama Press Afghan News Agency|Ex-Afghan MP shot dead by unknown gunmen in Kabul city|31 July 2016|
|Ariana News|Two people killed, 2 injured in Kabul blast|30 July 2016|
|VOA News|Afghan IDPs Suffering Due to Government Inaction, Donor Fatigue|29 July 2016|
|Khaama Press Afghan News Agency|One wounded in Kabul magnetic bomb explosion|28 July 2016|
|Daily Outlook|Kabul Facing Severe Water Crisis|10 July 2016|
|Home Office|Country Information and Guidance - Afghanistan: Security and humanitarian situation|July 2016|
|Integrity Watch|Combating Corruption in Afghan Defence and Security Sector|July 2016|
|UN Assistance Mission in Afghanistan (UNAMA)|Protection of civilians in armed conflict – Midyear report 2016|July 2016|
|UN Assistance Mission in Afghanistan (UNAMA)|Statement by Tadamichi Yamamoto condemning the attack targeting Afghan National Police in Kabul|30 June 2016|
|Pajhwok Afghan News|Rashidan district court judge gunned down in Kabul|28 June 2016|
|Khaama Press Afghan News Agency|Explosion in Wazir Akbar Khan Area in Kabul, no causalities reported|23 June 2016|
|Reuters|Bomb attacks kill at least 22 in Afghanistan|20 June 2016|
|UN Assistance Mission in Afghanistan (UNAMA)|UNAMA condemns attacks in Kabul and Badakhshan|20 June 2016|
|BBC|Afghanistan: MP Sher Wali Wardak killed in Kabul bomb blast|5 June 2016|
|Pajhwok Afghan News|Kabul lawmaker killed, 11 hurt in landmine explosion|5 June 2016|
|TOLO News|Sharp Increase In Kidnappings Since Taliban Leadership Change|3 June 2016|
|Samuel Hall|Urban displaced youth in Kabul – Part 1. Mental Health Also Matters|June 2016|
|United Nations High Commissioner for Refugees (UNHCR)|Afghanistan Factsheet|June 2016|
|Pajhwok Afghan News|11 killed in Taliban suicide attack on court workers|25 May 2016|
|Radio Free Europe|Afghan Guard At UN Compound Kills Nepalese Colleague|20 May 2016|
|UN Assistance Mission in Afghanistan (UNAMA)|UNAMA Statement on shooting incident|20 May 2016|
|The Guardian|Afghanistan's 'ghost soldiers': thousands enlisted to fight Taliban don't exist|17 May 2016|
|GOV.UK|Against Corruption: a collection of essays|12 May 2016|
|The Guardian|Afghan civilian death toll 'much higher than the official estimate'|8 May 2016|
|Amnesty International|My children will die this winter - Afghanistan's Broken Promise to the Displaced|May 2016|
|New York Times|15 Ambulances and Hundreds of Victims: Kabul Attack Gives Service Grim Test|20 April 2016|


Pajhwok Afghan News Another blast heard in Kabul after deadly suicide attack 19 April 2016


-----

|Col1|AS (Safety of Kabul) (CG)|Page 52 of 58|
|---|---|---|
|Pajhwok Afghan News|64 dead, hundreds wounded in Kabul suicide attack|19 April 2016|
|UN Assistance Mission in Afghanistan (UNAMA)|UNAMA condemns Taliban attack in Kabul|19 April 2016|
|United Nations High Commissioner for Refugees (UNHCR)|Eligibility Guidelines for assessing the International Protection needs of asylum-seekers from Afghanistan|19 April 2016|
|Al Jazeera|Rockets hit Afghan capital after Kerry visit (9 April 2016)|9 April 2016|
|Refugee Support Network|After Return: documenting the experiences of young people forcibly removed to Afghanistan|1 April 2016|
|Pajhwok Afghan News|4 killed, 15 wounded in bomb attack on ex-senator|29 March 2016|
|Radio Free Europe|Rockets Fired At Afghan Parliament Building, No Casualties Reported|28 March 2016|
|Global Terrorism Database|Incident Summary|25 March 2016|
|Bloomberg|If Afghanistan survives 2016, UN will consider it a success|17 March 2016|
|Khaama Press Afghan News Agency|No causalities as suicide blast rocks Kabul City|9 March 2016|
|Al Jazeera|Suicide attacks kill dozens in Afghanistan|27 February 2016|
|Reuters|Dozens killed, wounded in Afghanistan suicide attacks|27 February 2016|
|TOLO News|16 Ministries Fire Experts To 'Hire Relatives'|22 February 2016|
|Pajhwok Afghan News|Explosion rocks Kabul; no info on casualties|9 February 2016|
|BBC|Afghanistan attack: Kabul suicide bomber kills 20|1 February 2016|
|The Guardian|Taliban suicide bomber in deadly attack on Kabul police base|1 February 2016|
|UN Assistance Mission in Afghanistan (UNAMA)|Protection of civilians in armed conflict – Annual report 2015|February 2016|
|UN Assistance Mission in Afghanistan (UNAMA)|UNAMA condemns suicide attack targeting media in Kabul|21 January 2016|
|TOLO News|Gunmen Kill Security Guard, Torch Girls School In Kabul|20 January 2016|
|Reuters|Rocket lands near Italian embassy in Afghan capital Kabul|17 January 2016|
|United States Institute of Peace|The Forced Return of Afghan Refugees and Implications for Stability|13 January 2016|
|O'Donnell|Afghan forces struggle as ranks thinned by 'ghost' soldiers|10 January 2016|
|Reuters|Bomb blast hits Afghan capital Kabul|6 January 2016|
|UN Assistance Mission in Afghanistan (UNAMA)|UNAMA condemns Taliban attacks in Kabul City that kill five and injure 56|6 January 2016|
|Pajhwok Afghan News|At least 30 injured in second Kabul suicide|4 January 2016|
|BBC|Kabul French restaurant rocked by 'car bomb attack'|1 January 2016|
|Afghanistan Justice Organization|Deradicalization, Disengagement and Reintegration of former Taliban|January 2016|
|European Asylum Support Office (EASO)|Country of Origin Information Report: Afghanistan Security Situation (excerpts)|January 2016|
|Integrity Watch Afghanistan / Transparency International|National Integrity System Assessment: Afghanistan 2015|2016|
|Centre for Security Governance|The Afghan National Police: A study on corruption and clientelism|3 November 2015|
|United Nations Office for the Coordination of Humanitarian Affairs (UNOCHA)|Afghanistan: 2016 Humanitarian Needs Overview|November 2015|
|Zaman and Khalid|Trends of radicalisation among the ranks of the Afghan police|November 2015|
|Royal United Service Institute|Drivers of Violent Extremism: Hypotheses and Literature Review|16 October 2015|
|Long War Journal|Taliban overruns district in southern Afghanistan|9 October 2015|


-----

|Col1|AS (Safety of Kabul) (CG)|Page 53 of 58|
|---|---|---|
|Fazli et al|Understanding and Countering Violent Extremism in Afghanistan|September 2015|
|United Nations High Commissioner for Refugees (UNHCR)|Afghanistan Factsheet|August 2015|
|BBC|The young people sent back to Afghanistan|17 July 2015|
|Bureau of Investigative Journalism|From Kent to Kabul: the former asylum seeking children sent back to Afghanistan|17 July 2015|
|Bureau of Investigative Journalism|Schooled in Britain, deported to danger: UK sends 600 former child asylum seekers back to Afghanistan|16 July 2015|
|Oeppen and Majidi|PRIO Policy Brief: Can Afghans Reintegrate after Assisted Return from Europe?|July 2015|
|Reuters|UN investigation finds corruption in Afghan police oversight division|19 April 2015|
|Human Rights Watch|“Today We Shall All Die” Afghanistan's Strongmen and the Legacy of Impunity|3 March 2015|
|UN Assistance Mission in Afghanistan (UNAMA)|The Stolen Lands of Afghanistan and its People 2 of 3|March 2015|
|Council on Foreign Relations|Police Corruption: A Threat to Afghan Stability, a Threat to Afghan Women|12 February 2015|
|UN Assistance Mission in Afghanistan (UNAMA)|Protection of civilians in armed conflict – Annual report 2014|February 2015|
|Al Jazeera|Afghanistan's $3.6 billion police problem: Broken systems and corruption|12 January 2015|
|The Guardian|Killing, not curing- deadly boom in counterfeit medicine in Afghanistan|7 January 2015|
|The Guardian|Kabul – the fifth fastest growing city in the world – is bursting at the seams|11 December 2014|
|Al Jazeera|Kabul police chief resigns after attacks|30 November 2014|
|United Nations Office for the Coordination of Humanitarian Affairs (UNOCHA)|Afghanistan: 2015 Humanitarian Needs Overview|November 2014|
|Foreign Policy|US Watchdog: UN Misspent Hundreds of Millions of Dollars in Afghanistan|6 October 2014|
|The Saturday Paper|Taliban tortures Abbott government deportee|4 October 2014|
|The Guardian|Sayed Habib Musawi 'tortured, killed by Taliban because he was Australian'|30 September 2014|
|Refugee Support Network|3 things you need to know about life for young returnees in Afghanistan|27 September 2014|
|UN Assistance Mission in Afghanistan (UNAMA)|The Stolen Lands of Afghanistan and its People 1 of 3|August 2014|
|Afghan People's Dialogue on Peace|Building the Foundations for an Inclusive Peace Process|10 June 2014|
|San Diego Union Tribune|Corruption enemy No. 1 for Afghan police|31 May 2014|
|Medicins Sans Frontieres|Between rhetoric and reality: The ongoing struggle to access healthcare in Afghanistan|February 2014|
|Norwegian Refugee Council and the Internal Displacement Monitoring Centre|Still at risk: Security of tenure and the forced eviction of IDPs and refugee returnees in urban Afghanistan|February 2014|
|UN Assistance Mission in Afghanistan (UNAMA)|Protection of civilians in armed conflict – Annual report 2013|February 2014|
|Human Rights Watch|Afghanistan Universal Periodic Review 2013|7 January 2014|
|Daily Outlook|Rise in Criminal Activities in Kabul|29 December 2013|


United Nations Office for the Afghanistan: 2014 Humanitarian Needs Overview November 2013


-----

|Col1|AS (Safety of Kabul) (CG)|Page 54 of 58|
|---|---|---|
|Coordination of Humanitarian Affairs (UNOCHA)|||
|Gladwell|No longer a child: from the UK to Afghanistan|September 2013|
|Washington Post|Brother of Afghan security adviser killed in Taliban attack|17 July 2013|
|Schuster and Majidi|What happens post-deportation? The experience of deported Afghans|8 May 2013|
|UN Assistance Mission in Afghanistan (UNAMA)|Protection of civilians in armed conflict – Annual report 2012|February 2013|
|Samuel Hall Consulting/ International Organization for Migration (IOM)|Old Practice, New Chains: Modern slavery in Afghanistan|2013|
|The Independent|Taliban preys on Afghanistan's corrupt police force|23 December 2012|
|European Asylum Support Office (EASO)|Insurgent strategies — intimidation and targeted violence against Afghans|December 2012|
|Institute for the Study of War|Afghanistan - Green-on-Blue Attacks in Context|31 October 2012|
|BBC|Afghanistan's 'green on blue' collapse of trust|7 October 2012|
|Rangelov and Theros|Abuse of power and conflict persistence in Afghanistan (abstract)|1 August 2012|
|UN Assistance Mission in Afghanistan (UNAMA)|Protection of civilians in armed conflict – Annual report 2011|February 2012|
|LandInfo|Afghanistan: Human Rights and Security Situation|September 2011|
|New York Times|Taliban Blamed in Death of Afghan Officer's 8-Year-Old Son|24 July 2011|
|Los Angeles Times|Afghan Taliban intelligence network embraces the new|13 April 2011|
|Harper and Strote|Afghanistan pharmaceutical sector development- problems and prospects|April 2011|
|United Nations High Commissioner for Refugees (UNHCR)|Eligibility Guidelines for assessing the international protection needs of asylum-seekers from Afghanistan|17 December 2010|
|Daily Mail|Taliban have spies everywhere, warns army expert after Cameron was almost shot down by insurgent rocket|27 August 2010|
|The Telegraph|Afghanistan police corruption is fuelling insurgency|3 June 2010|
|Cleveland.com|US trains reluctant Afghan police to fight Taliban|18 June 2009|
|Ladbury in collaboration with Cooperation for Peace and Unity, Kabul (report for the Department for International Development)|Testing hypotheses on radicalisation in Afghanistan: Why do men join the Taliban and Hizb-i Islami? How much do local communities support them?|14 August 2009|
|Foreign Policy Research Institute|Ineffective, Unprofessional, and Corrupt: The Afghan National Police Challenge|3 June 2009|
|The Globe and Mail|Afghan police unaware of basic rights laws|30 April 2009|
|New York Times|Taliban Kills Afghan Interpreters Working for US and Its Allies|4 July 2006|
|ecoi.net|Featured topic- General Security Situation in Afghanistan and Events in Kabul|Undated|
|ERIN|A joint approach to sustainable return|Undated|
|Prints|'Kabul Security Now' facebook page|Undated|
|Unknown|Reintegration Assistance in Afghanistan|Undated|


**APPENDIX B – EASO Country of Origin Information Report, Afghanistan: Security Situation”**
**(August 2017).**


-----

Map 1 – Security incidents per province from September 2016 to May 2017.

IMAGE NOT AVAILABLE

Map 2 – Security incidents compared to population per province from September 2016 to May 2017.

IMAGE NOT AVAILABLE

**APPENDIX C – Error of law decision**

IMAGE NOT AVAILABLE

**Upper Tribunal**

**(Immigration and Asylum Chamber) Appeal Number: AA/03491/ 2015**

**THE IMMIGRATION ACTS**

**Heard at: Field House, London**
**on 27 April 2017**

……………………………

**Before**

**UPPER TRIBUNAL JUDGE O'CONNOR**

**Between**

**AS**

[ANONYMITY DIRECTION MADE]

Appellant

-and
**SECRETARY OF STATE FOR THE HOME DEPARTMENT**

Respondent

**Representation**

For the Appellant:  Mr T Gaisford, instructed by J D Spicer Zeb solicitors

For the Respondent:  Mr I Jarvis, Senior Presenting Officer

**Anonymity Direction**

**I make an anonymity order, pursuant to Rule 14 of the Tribunal Procedure (Upper Tribunal) Rules**
**2008. Unless the Upper Tribunal or other appropriate Court or Tribunal orders otherwise, no report of these**
**proceedings or any form of publication thereof shall directly or indirectly identify the Appellant. This**
**prohibition applies to, amongst others, the parties and their representatives.**

**DECISION AND REASONS FOR**

**SETTING ASIDE THE FIRST-TIER TRIBUNAL'S DECISION**


-----

**Introduction**

1. The appellant is a national of Afghanistan, born in Kardai village, Laghman Province, in 1986. For the
purposes of this decision I need not set out the circumstances of the appellant's time in Afghanistan, save
to say that they are accurately reflected in paragraphs 2 to 7 of the grounds of appeal to the Upper
Tribunal.

2. The appellant arrived in United Kingdom on an unidentified date accepted to be _“towards the end of_
_2008”. He was detained by immigration officers on 24 January 2014 and claimed asylum five days later. In_
a decision of 12 February 2015 the respondent refused such application concluding, in the same decision
letter, that: (i) the appellant had not shown there to be substantial grounds for believing that he faces a real
risk of suffering serious harm upon return to Afghanistan such as to qualify for humanitarian protection;
and, (ii) the appellant's removal would not breach article 3 or article 8 ECHR. On the 13 February 2015 the
respondent made a decision to remove the appellant.

3. The appellant's subsequent appeal to the First-tier Tribunal was dismissed in a decision promulgated on
31 July 2015. The appellant now appeals to the Upper Tribunal with the permission of Upper Tribunal
Judge Taylor, granted on 2 October 2015.

**Decision and Reasons**

4. At the outset of the hearing before the Upper Tribunal, Mr Jarvis accepted that the First-tier Tribunal's
decision contains an error of law such that it should be set aside. Given this concession, I do no more
herein than summarise why I concur that it is appropriate to set aside the First-tier Tribunal's decision.

5. The First-tier Tribunal accepted, _inter alia, that there exists a real risk that the appellant would suffer_
persecutory treatment from the Taliban if he were to return to his home area in Afghanistan [27]. It
thereafter considered the issue of internal relocation, in the context of the Refugee Convention, at [33] of
its decision.

6. In both written and oral submissions made on behalf of the appellant to the First-tier Tribunal, albeit
made within the context of internal relocation viewed through the lens of Article 15(c) and not the Refugee
Convention, it was submitted to be of significance, when assessment was being given to the question
whether relocation of the appellant would be unduly harsh, that the _“assistance and reintegration”_
packages (“assistance packages”) previously provided to refused asylum seekers upon return to Kabul had
been withdrawn and would not be available to the instant appellant. Paragraph 224 of the country
guidance decision of AK (Afghanistan) [2012] UKUT 00163was prayed in aid of such submission.

7. This feature of the appellant's case is not explicitly addressed by the First-tier Tribunal, and it cannot be
ascertained from its decision whether its conclusion at [33] was correctly premised on the fact of the
appellant not having have access to such an assistance package.

8. Furthermore, in my conclusion it cannot be inferred from the fact that FtT found, in [36], that “there is
_nothing cogent or compelling before [it] to suggest that AK (sic) no longer valid and (sic) regarding removal_
_to Kabul”, that it was therein seeking to address the relevance of the withdrawal of assistance packages to_
the application of the guidance given in AK. In any event, such consideration was itself flawed by legal
error in that (i) the First-tier Tribunal failed to direct itself to, or lawfully apply the Upper Tribunal (IAC)
Practice Direction (paragraphs 12.2 and 12.4) and the Upper Tribunal (IAC) Guidance Note 2011 No. 2
(paragraphs 11 and 12); and, (ii) there is no indication in [36] that the First-tier Tribunal lawfully addressed
itself to the correct threshold applicable to a consideration of internal relocation under Article 15(c) of the
Qualification Directive.

**Decision**

9. For these reasons, I set aside the decision of the First-tier Tribunal.

10. The Decision on this appeal will be re-made by the Upper Tribunal. The findings of primary fact made
by the First-tier Tribunal have not been the subject of challenge and are preserved, as is the conclusion at

[27] that the appellant would be at risk of suffering persecutory treatment in his home area


-----

Signed:

IMAGE NOT AVAILABLE

Upper Tribunal Judge O'Connor

**APPENDIX D - Senior President's Practice Direction No 10 (2010)**

**Lord Justice Carnwath 10 February 2010, updated by Sir Jeremy Sullivan 13 November 2014**

10 Expert evidence

10.1 A party who instructs an expert must provide clear and precise instructions to the expert, together
with all relevant information concerning the nature of the appellant's case, including the appellant's
immigration history, the reasons why the appellant's claim or application has been refused by the
respondent and copies of any relevant previous reports prepared in respect of the appellant.

10.2 It is the duty of an expert to help the Tribunal on matters within the expert's own expertise. This duty
is paramount and overrides any obligation to the person from whom the expert has received instructions or
by whom the expert is paid.

10.3 Expert evidence should be the independent product of the expert uninfluenced by the pressures of
litigation.

10.4  An expert should asses the Tribunal by providing objective, unbiased opinion on matters within his or
her expertise, and should not assume the role of an advocate.

10.5 An expert should consider all material facts, including those which might detract from his or her
opinion.

10.6 An expert should make it clear:

(a) when a question or issue falls outside his or her expertise; and

(b) when the expert is not able to reach a definite opinion, for example because of insufficient information.

10.7 If, after producing a report, an expert changes his or her view on any material matter, that change of
view should be communicated to the parties without delay, and when appropriate to the Tribunal.

10.8 An expert's report should be addressed to the Tribunal and not to the party from whom the expert has
received instructions.

10.9 An expert's report must:

(a) give details of the expert's qualifications;

(b)  give details of any literature or other material which the expert has relied on in making the report;

(c) contain a statement setting out the substance of all facts and instructions given to the expert which are
material to the opinions expressed in the report or upon which those opinions expressed in the report or
upon which those opinions are based;

(d) make clear which of the facts stated in the report are within the expert's own knowledge;

(e) say who carried out any examination, measurement or other procedure which the expert has used for
the report, give the qualifications of that person, and say whether or not the procedure has been carried out
under the expert's supervision;

(f) where there is a range of opinion on matters dealt with in the report:

(i)  summarise the range of opinion, so far as reasonably practicable, and

(ii) give reasons for the expert's own opinion;

(g) contain a summary of the conclusions reached;


-----

(h) if the expert is not able to give an opinion without qualification, state the qualification; and

(j) contain a statement that the expert understands his or her duty to the Tribunal and has complied and
will continue to comply with that duty.

10.10 An expert's report must be verified by a Statement of Truth as well as containing the statements
required in paragraph 10.9(h) and (j).

10.11 The form of the Statement of Truth is as follows:

“I confirm that insofar as the facts stated in my report are within my own knowledge I have made clear
which they are and I believe them to be true, and that the opinions I have expressed represent my true and
complete professional opinion.”

10.12 The instructions referred to in paragraph 10.9(c) are not protected by privilege but crossexamination of the expert on the contents of the instructions will not be allowed unless the Tribunal permits
it (or unless the party who gave the instructions consents to it). Before it gives permission the Tribunal
must be satisfied that there are reasonable grounds to consider that the statement in the report or the
substance of the instructions is inaccurate or incomplete. If the Tribunal is so satisfied, it will allow the
cross-examination where it appears to be in the interests of justice to do so.

10.13 In this Practice Direction:

“appellant” means the party who is or was the appellant before the First-tier Tribunal; and

“respondent” means the party who is or was the respondent before the First-tier Tribunal.

**End of Document**


-----

