# R v Alexandru Lupu [2020] EWCA Crim 1490

CA, CRIMINAL DIVISION

201902530 B3 ; 201902531 B3

Simler LJ, Picken J, HHJ Menary

Friday, 16 October 2020

16/10/2020

LADY JUSTICE SIMLER:

Introduction

1 On 18 and 19 June 2019 in the Crown Court at Blackfriars before His Honour Judge Shetty QC and a jury, the
applicants, Grigore Lupu and Giorgian Valentin Lupu were convicted unanimously on three counts: conspiracy to
arrange or facilitate travel of persons within the United Kingdom with a view to exploitation, contrary to s.1 of the
_[Criminal Law Act 1977,count 2; conspiracy to arrange or facilitate the travel of persons within the United Kingdom](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BG90-TWPY-Y135-00000-00&context=1519360)_
with a view to exploitation, count 4, and conspiracy to convert criminal property, count 5. Alexandru Lupu was
convicted before the same judge and jury in the same trial on counts 2 and 5.

2 On 21 June 2019 the three applicants were sentenced as follows: Alexandru Lupu was sentenced to eight years
concurrent on each of the two counts; Grigore Lupu and Giorgian Valentin Lupu were sentenced to ten years each
on count 2 with concurrent sentences of seven and eight years respectively on counts 4 and 5. There were a

number of other co‑accused who were acquitted at the close of the Crown case on the direction of the judge.

Alexandru Lupu himself was acquitted on count 4, also on the judge's direction at the close of the Crown's case.

3 Alexandru Lupu renews his applications for leave to appeal both conviction and sentence, following refusal by the
single judge. He has been represented on both of those applications by Mr Karu QC, assisted by Mr James.
Grigore Lupu renews his application for leave to appeal against sentence and has been represented by Mr Vollans
of counsel, and Giorgian Valentin renews his application for leave to appeal against sentence and has been
represented by Mr Scobie QC. We are grateful to all counsel for their helpful, thoughtful and cogent submissions
on behalf of these applicants.

4 We shall refer to the applicants individually by their initials for ease of reference, and mean no disrespect by
doing that.

The Facts

5 In overview, the applicants and co‑accused are all members of the same family and all originate from Romania.

AL is the brother of GL and the uncle of GVL. It was alleged that over the course of about four years they deceived

dozens of fellow Romanians into travelling to this country on the promise of well‑paid construction and other work,

together with a better standard of living. On arrival, these individuals were given employment but most of their
wages were taken from them and they were forced to live in what can only be described as appalling conditions
controlled by members of the conspiracy. There was evidence of cockroach and vermin infestation, and of how


-----

their access to washing and toilet facility was restricted. On the prosecution case the conspiracies brought in a little
over £1.3 million in total.

6 On 29 March 2016 one of the properties used to house the worker victims, at 15 Bower House in West Ham, was
raided by police. Fifteen Romanian workers were found there. A number of members of the family, including VL,
were arrested for trafficking on this occasion. AL was arrested on 16 October 2018 and was interviewed on the
same day. He gave a prepared statement and answered questions. He said he had nothing to do with the offences
charged, and that what his brothers and other family members did had nothing to do with him.

7 The prosecution case was that there was a criminal agreement to traffic workers to this country from Romania
and to compel them to engage in forced or compulsory labour. Once here, their ID cards were removed and they
were put to work. Bogus construction skills certification scheme cards were obtained in order to facilitate
employment and to give the false impression that those individuals had been trained and tested in construction site
safety. The money they received for the work that they carried out was derisory, no more than £1.80 an hour, often
less, and the vast amount of the income derived from their labour went straight to the members of the conspiracy.
Efforts to control these workers and to ensure compliance included putting them into debt or wage bondage by
claiming that they owed the family money for rent and other items. Violence and the threat of violence were used in
the presence of others to ensure compliance.

8 From the opening of the trial the Crown's case against AL was that his involvement was less direct and more
subtle but no less crucial to the group's activities. He leased several properties which were used to house the
workers who were exploited. His finances were implicated and inferences could be drawn from the transactions in
his accounts that he was party to the conspiracies as charged. Particular reliance was placed on the evidence of
the workers of their treatment while working for the family. All of them described overcrowded and unsanitary living
conditions and of being underpaid or put into a position of debt bondage. Often their ID cards were not returned to
them and they were either threatened with or witnessed violence.

9 So far as properties used to accommodate the workers are concerned, the property 15 Bower House was a

three‑bedroomed property used by GVL to house a number of workers. The conditions there were described by

many witnesses as squalid, dirty, vermin infested and grossly overcrowded. When the police visited in March 2016,
there were 31 people living there. It was a property which AL had visited during the period of the indictment.
Following the police raid on this house, the family moved to another property, 196 Perth Road in Ilford, which was a
property leased by AL and rented to his brother Viorel Lupu and his family. There was evidence from a number of
witnesses that conditions in this property were overcrowded, dirty and infested with vermin. The property was used
by GVL to house workers after he left Bower House. In March 2016 GVL was arrested during a police visit to
Bower House. There was also a property at 20 Bathurst Road in Ilford, occupied by GL, and provided to him by AL.
Rent was paid by GL to AL for his use of that property. AL was, accordingly, the landlord of the two properties to
which we have referred. Many Romanians were housed there and one in particular, Mr Chirila, gave evidence
about the conditions and the treatment of the workers there. He recalled ten workers living in the house initially and
then another sixteen arriving. He said GL used the workers as slaves. The prosecution also relied on a notebook
found at AL's address containing details of a large number of Romanians with numbers against their names. It was
the prosecution case that those were tax references.

10 The defence case was that none of the complainants were required to perform forced or compulsory labour, and
thus, there was no conspiracy to require them to do so. The only real complaint that anyone could have was as to
the amount of money they received for the work that they performed. So far as AL in particular is concerned, he
denied any involvement at all or knowledge of these conspiracies, and contended there was no material capable of
being evidence against him.

11 At the close of the prosecution case there was a submission of no case to answer on behalf of all defendants in
the case. The judge heard submissions and gave a detailed ruling. He held that there was no case to answer

against a number of co‑accused, Viorel, Toader, Ionut, Victorita and Violetta Lupu.


-----

12 So far as AL was concerned, the defence relied primarily on the first limb of R v Galbraith [1981] 1 WLR 1, and
submitted on his behalf that there was no evidence from a single litigant that he was involved in forcing anyone to
work, in not paying wages, in holding ID cards or in restricting their movements. To the extent that it was said he
participated by acting as banker and thereby became a party to the conspiracies, the financial evidence was said to
be tenuous and circumstantial. It was said that none of the material showed any actual knowledge of offences
being committed on his part, nor that the proceeds were proceeds of crime. Accordingly no proper inference could
be drawn that was the case from any of the material available. The mere fact that sums were transferred to AL
from VL (just under £35,000, and GL £12,500 over a four year period) did not and could not explain where that
money came from. There was no evidence it was criminal funds or why those transfers took place. The Crown
could not infer conspiracy from the banking evidence, nor did any of it support a single global conspiracy. There
was no evidence of profit sharing by others with AL or the transferring of victims between others and AL.

13 The judge did not accept those submissions and ruled that there was a case for AL to answer. The judge relied
on the fact that he received rent at 25 Bathurst Road where GL lived and kept workers in poor, overcrowded
conditions. There was evidence that Ms Cojocaru and Mr Madin stayed at his house before being collected by
others and taken to Bower House. He was also the landlord of 196 Perth Road which was let to and occupied by
GVL after the move from Bower House. Moreover, AL received sums of money from GL and VL, during the
indictment period. Material was found at his address which appeared to relate to workers' details, bank accounts,
sort codes and tax information. All of these features of the evidence could, the judge held, create an inference that
he benefited from and participated in the conspiracy. There was therefore a case to answer in relation to counts 2
and 5.

14 The judge accepted that none of the workers were brought to this country against their will, but concluded that
the law was clear that the initial consent of the worker was not necessarily determinative of the questions which
needed to be answered. There was always a possibility that workers were enticed into a situation, following which
various conditions or a menace were imposed which effectively prevented their escape, and here there was
evidence of various devices or menaces, such as the taking of ID cards, control over wages which meant that they
were often not paid and were effectively placed in conditions of bondage. There were also threats of violence used
to overbear the will of workers. The judge took into account the fact that some workers did come and go and some
did return, but concluded that in a conspiracy allegation it is not necessarily the successful achievement of coercing
workers and forcing them to work that is key, but rather the criminal agreement to try and achieve that particular
aim.

15 So far as count 4 is concerned, the judge recorded the prosecution's concession that there was no direct
evidence of AL's involvement, and concluded that there was no case to answer in relation to that count.

16 The trial accordingly proceeded against three applicants. None of them gave evidence at the trial and the jury
unanimously convicted them of the counts to which we have already referred.

The conviction application

17 The ruling by the judge at the close of the prosecution's case is challenged by AL on this application. In writing
and developed orally before us, Mr Karu QC submits that the judge was in error in rejecting the submission of no
case to answer and ought to have stopped the case against him. Complaint is made that there was no evidence
from any victim implicating AL, nor did the financial and documentary evidence support the inferences drawn by the
judge.

18 Mr Karu dealt with each aspect of the evidence relied on by the judge as forming circumstantial evidence from
which, cumulatively, inferences could be drawn. He argued as he did below, that there was insufficient evidence to
reach the threshold of a case to answer. For example, so far as Cojocaru and Madin are concerned, although they
stayed with AL and ended up in Bower House, there was, no evidence as to how they came to end up there; no
evidence that it was AL who engineered that or that it was GL or VL who put them there. He points to the fact that

other co‑accused were discharged on the judge's direction, because in their cases knowledge was regarded as


-----

insufficient, and submits that the same approach should have applied to AL. At best there was knowledge,
although he does not even accept that, but there was no evidence otherwise.

19 We have considered those submissions and the submissions made in writing with care, but are not persuaded
that any arguable ground of appeal has been shown to demonstrate any error of approach by the judge or that he
erred in concluding that there was a case to answer. Our reasons are essentially the same as those given by the
single judge. As the prosecution made clear from the outset the case against AL was not based on overt or direct
oppression of Romanian workers, as was alleged against both GL and GVL. Rather, his involvement was more
subtle and involved the provision of property for housing workers trafficked from Romania. This was central to the
conspiracies and it was this feature that enabled workers to be isolated and supported for financial gain.

20 The judge heard evidence over a period of many weeks. It included evidence about the overnight
accommodation provided to Cojocaru and Madin before their transfer to Bower House. Bower House was, as we

have observed and the judge found, a three‑bedroomed house where the conditions were described as totally

squalid. The property was raided by police on 26 March 2016, and PC Overfield recounted the presence of
cockroaches crawling up the walls, the sound of vermin, dirty mattresses with few bedclothes. Others gave similar

descriptions. For instance, Laurentiu‑Constantin Badita arrived in London in October 2015 and was taken there.

The living conditions he described as, "despicable with cockroaches in every room". He described food "not being
stored properly, began to smell and go off to the point where it was inedible, and would commonly be fried food."
George Urlea recounted being, "under the control of the Lupu family", between October 2015 and January 2016.
On his arrival at Bower House he recounted, "how disgusted he was by the state of the property and sleeping
arrangements, the presence of cockroaches in the kitchen". Ms Cojocaru herself described the conditions that
greeted her and her partner Mr Madin at Bower House as being "of unimaginable squalor [...] mice and
cockroaches".

21 The property was also described at different points in time by many witnesses as being overcrowded. For

example, when police visited in March 2016, the three‑bedroomed house was occupied by 31 occupants. 22 men

were found sleeping on an assortment of mattresses or directly on the living room floor. On 10 October 2015, Mr
Badita recalled 22 people living in the property and Ms Cojocaru said in her statement that on her arrival she and
her partner had to share the living room with another couple and four men who slept on single mattresses on the
floor.

22 There was evidence that Bower House, in particular, was a property which AL had visited during the indictment
period. There was direct evidence from Mr Diacu, who saw him in the house after his arrival from Romania in the
autumn 2015. The judge held that his presence there, where victims of trafficking were housed, meant that he
would inevitably have been aware of the appalling conditions in that property that were obvious for anyone to see.
Moreover, the judge relied on the fact that AL rented properties to members of his family who used them for
housing victims of trafficking in the conditions which we have described: the house at 20 Bathurst Road occupied by
GL, and at 196 Perth Road occupied by GVL after he left Bower House, and notwithstanding his arrest.

23 There was also evidence of money transfers to AL by his brother and his nephew. Mr Karu complains that the
amount (£47,000) was very small seen in context of the overall conspiracy, but there are many other ways he could
have benefited from the conspiracy, and in our judgment that was evidence from which inferences could in any
event have been drawn.

24 There was other material found at properties associated with AL which appeared to relate to workers, and an
admission that £1,709 was paid to AL's company for work done by one of the workers who only received £800 for
himself, less than half of that sum. Mr Karu relies on the fact that he made no complaint about the sums he
received, but in our judgment, that does not detract from the force of the evidence when seen in the context of all
the other evidence in this case.

25 In our judgment, there was sufficient compelling, circumstantial evidence that entitled the judge to decide that a

jury properly directed could conclude that AL was a co‑conspirator and that the sums transferred were the proceeds


-----

of the operation of the conspiracy. There may of course have been alternative innocent explanations for any one of

those pieces of evidence, but the weight to be given to those aspects of the evidence was pre‑eminently a matter

for the jury to decide and in our judgment it is not arguable that AL's convictions are unsafe, whether because the
ruling was wrong or for any other reason at all.

The sentence applications

26 We turn, therefore, to the sentence applications made on each of their behalves. AL is aged 44, born on 23
December 1985 and is of previous good character. GL is now aged 40, born 29 June 1979. He had previous
convictions but the judge referred to these as dissimilar and disregarded them. GVL is now aged 27, born 1
October 1992 and is of previous good character.

[27 In his sentencing remarks the judge referred to the Modern Slavery Act 2015 which introduced sentences of up](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
to life imprisonment in respect of offences of this kind, and to the effect that was liable to have on the starting points
and ranges for sentences in the authorities to which he was referred. The judge said that he was particularly
assisted by the authority of _R v Zielinski [2017] EWCA Crim 758, which gave some guidance as to the level of_
sentences which should be imposed. He said, nonetheless, that he would not embark on a detailed comparison
between the features of that case and these.

28 He described all three applicants as being engaged in an enterprise which was designed to exploit people
coming to the United Kingdom from Romania. They systematically exploited vulnerable individuals who lived in dire
poverty in Romania, were uneducated, spoke little English, and who were effectively trapped upon arrival here. The
conspiracy ran for over three years, a significant period, on any view. The number of workers exploited was likely
to have been in the hundreds, given the period of time involved and the length of time individuals remained and the
numbers at each of the properties at any given time. The conditions in which they were kept were squalid. There
was violence or threats of violence, and the organisation required for this enterprise was significant, as was the
level of financial benefit obtained.

29 GL and GVL were in the judge's judgment very much at the heart of the conspiracy, and played similar roles.
GVL ran two houses over the indictment period. He continued in the enterprise despite the police stopping him in
his tracks with his arrest in March 2016. Following his release and with the knowledge that the police were

continuing their investigations, another start‑up house appeared within a week or so. That was financed by AL.

GVL received almost a quarter of £1 million over nearly a four year period. He was fully involved in organising the
houses and the exploitation of the victims. GL ran one house on a similar basis, and profited to a similar extent. AL
played a lesser role than the others and the judge said that would be reflected in the sentence he would pass.

30 On behalf of AL Mr Karu submits that the total sentence passed in his case was manifestly excessive, taking
into account the facts of the case, in particular that there was minimal physical violence done to the victims here,
and in light of the fact the conditions in which they were kept, although poor, were not the worst. Moreover, he
relies on his lesser involvement and personal circumstances and on the fact that he was of good character. He
submits that when all these features are factored in, it is plain that this sentence was manifestly excessive in all the
circumstances.

31 For GL in writing in his grounds and addendum grounds and developed orally, Mr Vollans emphasises the
difference between this case so far as his client GL is concerned and that of Zielinski's case. He accepts that GL
played a more serious role than Zielinski, but in comparison with the overall circumstances of that case and also
seen against the more serious role played by GVL, he submits that GL's sentence was also manifestly excessive.

He relies on the limited period of individual exploitation, on the absence of any long‑term harm suffered by any of

the victims, on the relatively low level of violence and the ability of workers to leave and the fact that they did so.
Though GL was seen by the judge as being at the heart of the conspiracy, there was evidence that indicated that he
was playing a lesser role than GVL. For example, he was called to enforce discipline on one occasion by GVL, and
there was limited complaint about the treatment of workers at his own address.  All in all, and having regard to the


-----

differences between this case and Zielinski's case, Mr Vollans submits that the sentence should have been much
closer to the sentence passed in Zielinski's case, albeit reflecting some aggravation in relation to role.

32 Finally, so far as GVL is concerned, in cogent written submissions produced by Mr Cockings QC, and
developed before us by Mr Scobie QC, it is submitted that in light of the authorities, including _R v Rooney,_ _R v_
_Connors and indeed R v Zielinski, and specifically in light of the particular circumstances of this case, ten years is_
simply too high. Mr Scobie commends many aspects of the judge' sentencing remarks but contends that there is
no good reason to be found in those remarks for the significant increase to ten years in GVL's case. He submits
that the conditions in which the workers were kept in these conspiracies and the levels of violence to which they
were exposed, both actual and threatened, were not as bad as in those other cases. A sentence of between six to
eight years would have been at the upper end, severe but not appealable, in the absence of the extreme
aggravating features that were omnipresent in those other cases. He submits that ten years represents the upper
end of sentences for the sort of forced compulsory labour that has been passed hitherto. For all these reasons and
in light of the factual matrix in this case, he submits that the sentence is manifestly excessive for GVL too.

Analysis

33 We have considered those submissions, both written and oral with care, but have concluded that none of these
applications is arguable.

34 There are as yet no guidelines in cases of this kind. In R v _Zielinski the court identified some of the significant_
factors to be considered when assessing culpability and harm. These include (i) the level of organisation and
planning; (ii) whether there is deception from the outset in persuading victims to travel to the United Kingdom; (iii)
the number of victims involved; (iv) the duration and persistency of the conspiracy; (v) the poor standard of
accommodation; (vi) the methods used to control victims; (vii) the level of vulnerability of the victim; (viii) the level of
harm caused and any lasting effect, and finally, (ix) the extent to which the offending was for financial gain. Each
case of course depends on its own facts and the circumstances of the offending and the harm that has been done.
These features must be assessed on an individual basis.

35 This conspiracy lasted longer than that in _R v Zielinski._ It was better organised and it was more profitable.
Moreover, as the judge observed, there were other features that made it particularly serious. For example, the
number of people exploited was very high, and over three years could be estimated at between 300 and 500
workers in total. People were exploited over periods of two to three months at a time, so that there was a high level
of turnover.

36 It is also significant, in our judgment, that in R v Zielinski the part played by Zielinski himself was described by
the judge as not a leading role but as the role of an able and willing participant who would profit no less than other
members of his family. Likewise, in terms of mitigation, in _R v Zielinski, the judge noted the effective good_
character of Zielinski, and the fact that he was a relatively young man. These features are not present in these
cases.

37 So far as each case is concerned, we are also cognizant of the fact that this was a judge who heard evidence

over a period of many weeks and was pre‑eminently well placed to determine the role of each applicant within the

conspiracy and to calibrate the evidence in terms of culpability and harm. It seems to us that he did that with
considerable care, recognising the aggravating and mitigating features.

38  In AL's case the judge recognised there was no evidence that he had used violence. Nonetheless, he was
entitled to conclude that otherwise he carried out the same sort of activity as the other applicants. He was entitled
to conclude that AL played a knowing role in assisting highly sophisticated criminal activity which took place over a
number of years and affected a large number of victims. His role in providing accommodation for the victims was
essential to the success of this conspiracy, and as the judge observed, meant that those people were detained or
kept in conditions properly described as horrendous. Although the evidence disclosed £47,000 received by AL,
there was a clear inference to be drawn from the length of the conspiracy and the hundreds of victims and the fact


-----

that £1.3 million went through the bank accounts of the other applicants during the indictment period, that this was a
fraction of the total.

39 The judge was also aware that the workers did not remain in the control of the conspiracy for as long as in other
cases cited to him, but nonetheless, AL was part of a conspiracy that was able to maximise the money made
through the turnaround of numerous people which was essential to obtaining high levels of profit from exploitation
and so was not seen as a mitigating factor. The judge did however take into account the absence of previous
convictions in AL's case.

40 Ultimately, this was serious offending. We are quite unable to say that the balance reached by the judge of
eight years for the two offences was arguably manifestly excessive or wrong in principle so that his application must
be and is accordingly refused.

41 So far as GL is concerned, the judge was entitled to distinguish this case from R v Zielinski by reference to the

highly sophisticated, long‑standing, well‑planned and lucrative operation that crossed international borders.

Moreover, in his case too, the judge was careful to assess and calibrate his role. It seems to us it was open to the
judge to sentence GL on the same basis as that on which he sentenced GVL, and for the reasons he gave. Both
were directly involved, both used violence to intimidate, both kept their victims under their control in what can only
be described as appalling conditions, and significantly, both were, as the judge found on the evidence, at the heart
of these conspiracies.

42 The judge very much took account of the fact the conspiracy used violence only occasionally, but he was
entitled to conclude that violence (used and threatened) was insidious and used carefully to frighten and to send
warnings to those who were exploited. The judge was entitled to take into account the conditions in which victims
were kept and the fact that it was a particular feature of the offending that large numbers of forged CSCS
documents were obtained and enabled victims to work on construction sites. By doing that, not only were the
victims exploited but they and other construction workers and members of the public were exposed to the dangers
which this registration scheme is designed to prevent. That was a feature the judge described as seriously
aggravating and dishonest, and we can see no error in his approach.

43 Finally, as in the case of AL, the judge had regard to the fact that victims did not remain in the control of the
conspiracy for as long as they did in other cases, but for the reasons we have just given, he was entitled to regard
that as not a decisive mitigating factor. The fact, moreover, that identification cards were returned when workers
wanted to leave was undermined by what the judge regarded as drip feeding of victims so that they actually
returned. We can see no error in his approach on that issue either.

44 In the result, we have concluded that the total sentence of ten years for these three offences cannot arguably be
described as manifestly excessive or wrong in principle, and this application too falls to be and is refused.

45 Finally, so far as GVL is concerned, we do not repeat the points that we have already made. Notwithstanding
the clear and cogent arguments advanced on behalf of GVL by Mr Scobie, we take the view that for all the same
reasons that we have just given his sentence too was not arguably manifestly excessive or wrong in principle. The
judge had regard to the features to which we have already referred. He was well aware of all the evidence and
calibrated culpability and harm in a manner that was open to him and well within the range of sentences available to
him. For all those reasons accordingly this application is also refused.

_________________

**End of Document**


-----

