# R v A [2023] EWCA Crim 1230

Court of Appeal, Criminal Division

William Davis LJ, Cutts J, Eady J

25 August 2023Judgment

MR M BUTT KC appeared on behalf of the Appellant

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

1. MRS JUSTICE EADY: On 17 August 2022, in the Crown Court at Basildon, the appellant (then aged

[an age]) pleaded guilty to wounding with intent, contrary to section 18 of the Offences Against the Person
Act 1861. On 14 April 2023, before the same judge and court, the appellant (who was then aged [an age])
was sentenced to what was stated to be 57 months' youth custody. As the appellant was aged [an age] at
the date of conviction (and in the absence of a finding that he was dangerous) the appropriate sentence
would in fact have been detention under section 250 of the Sentencing Code.

i. With the leave of the single judge, the appellant (who turned [an age] two days ago, on 23 August 2023)
appeals against that sentence on the following grounds:

(2) the Judge was wrong to find that this was an 1A offence under the applicable Sentencing Guideline
and adopted too high a starting point as a result;

(3) the Judge made insufficient reduction for the limited role the appellant played in the offence;

(4) there was insufficient reduction to reflect the appellant's youth and lack of developmental maturity
and/or to recognise the numerous mitigating features under the Sentencing Children and Young People
(SCYP) Guideline;

(5) the sentence was manifestly excessive.

2. The facts

(1) On the evening of Monday 28 February 2022, the complainant, Jake Smith, left his partner's address to
buy cannabis and was walking along Laindon Link in Basildon when, at 9.26 pm, the appellant and his

co‑defendant, Billy Alder (then aged 22), pulled up in a car. Mr Alder was the man the complainant had

intended to buy the cannabis from but he did not know his name. Mr Alder got out of the car, crouching
down before walking slowly forwards, pulling a machete out of his sleeve and hitting the complainant once
ith it Th l i t lth h h h d d t i i j


-----

(2) The CCTV footage showed the appellant and Mr Alder crossing the road and chasing the complainant
into a grassy area, which is where the cover for the machete was subsequently found. About 30 seconds
after Mr Alder first hit the complainant with the machete, however, the appellant left the scene, running
west along Laindon Link. As he did so, Mr Alder shouted to the appellant: "Get back now, A. Get back
now, A. I'm not letting you go."

(3) The complainant and Mr Alder then moved round to the north side of Laindon Link and an exchange
between them was picked up on a Ring doorbell, during which the complainant said: "Bruv, I'm dying." And
Mr Alder replied: "Do I care, bruv? I hope you die. I hope you sit here and die, bruv. Not letting you go
nowhere." Mr Alder then made the complainant take his trousers down and show the cheeks of his anus,
to check he was not hiding any drugs; it was said that Mr Alder believed that the complainant had taken

some £4,000‑worth of drugs. Mr Alder lashed out at the complainant on at least two further occasions with

the machete, chasing him and causing him to fall to the ground. While the complainant was on the ground,
Mr Alder aimed machete blows at his body but the complainant blocked them with his legs. The whole
incident lasted around five minutes and consisted of four separate assaults with the machete. It seems
that Mr Alder then ran off, having been disturbed by members of the public.

(4) When the police attended the location at 9.38pm, the complainant was sitting on the pavement and told
officers that he did not know the people who had attacked him. He said that he had arranged to buy
cannabis from one of the men who had attacked him; he told the officers that there had been three men,
aged between 18 and 20, but could not provide any further descriptions and refused to surrender his
'phone to be examined by officers. In his statement, the complainant said he remembered seeing the
appellant a few weeks before when the appellant had barged into him and told him he "stinks of beer". The
complainant said he had slapped the appellant around the face and suggested that could have been his
motivation for getting involved in the attack.

(5) Mr Alder was arrested on 5 March 2022; he gave a "no comment" interview. The appellant was
arrested on 10 March 2022. He was taken to Basildon Police Station where he said at the custody desk: "I
am being forced into a lot of things, child things." He was identified at a video identification parade by the
complainant. The appellant was interviewed and replied "no comment" to the questions he was asked.

(6) The complainant was taken to Basildon Hospital. He had two large slash wounds to each upper arm,
three large slash wounds and one smaller wound to his back. He also had a severe wound to his left knee,
which had severed the patella tendon, and a fracture to his right humerus. The complainant had two
operations to repair the patella tendon which were successful, but he did not follow medical advice and
suffered two further severances.

(7) On 4 November 2022, the complainant died as a result of a prescription drug overdose. The
pathologist's report before the Court concluded there was no evidence that the injuries sustained by the
complainant in February 2022 had played any role in his death. As the judge made clear, the sentences
passed in this matter were in relation to offences under section 18 of the Offences Against the Person Act;
she was not sentencing for the complainant's death.

3. Sentence

(1) Sentencing both the appellant and Mr Alder, the judge first considered the categorisation of the
offence, recording that there was:

i. "an acceptance of a high level of culpability in relation to this because of ... the use of a highly dangerous
weapon and also the leading role in a group activity for Mr Alder and the prolonged and persistent nature of

the assault." (Sentencing remarks page 5 A‑B)

(2) While it was correct that Category A culpability had been conceded in Mr Alder's case, in respect of the
appellant it was submitted that his lesser role fell within Category B culpability.

(3) As for harm, the judge recorded that there was a dispute in this regard, although it was accepted there
was a crossover between the top of Category 1 and the bottom of Category 2.


-----

(4) The judge referred to the complainant's victim impact statements and to the statements from the
complainant's girlfriend and father, which stated that he was unable to walk properly and had been unable
to return to work. She also referred to a streamlined forensic report produced by the prosecution from Dr

Grundlingh, who had advised that the complainant's injuries "could be considered to be life‑threatening", an

opinion based on the following reasoning:

i. "The above injuries, had medical attention not been provided, would have become infected, leading to
sepsis and death. There is also a likelihood that ongoing bleeding would have caused the patient to die."

4. On the material thus referred to, the judge concluded that:

i. "... the knee injury was permanent and it did mean that Mr Smith could not work, making it a category 1

offence." (Sentencing remarks page 5 F‑G)

(2) Seeing this as a Category 1A offence, with a starting point under the guideline of 12 years and a range
of 10 to 16 years, the judge considered that the relevant starting point was one of 11 years.

(3) Having regard to Mr Alder's personal mitigation and applying a 25 per cent reduction for his guilty plea,
the judge imposed a custodial term in his case of seven years. Although not set out in the judge's
sentencing remarks, that would suggest that Mr Alder's mitigation resulted in a reduction from the starting
point of 11 years to nine years four months, thus leading to a final sentence of seven years once 25 per
cent credit for plea was applied.

(4) Turning to the appellant, the judge noted it was conceded that he did not have a leading role and there
was only a matter of seconds between the first injury being inflicted on the complainant and when the
appellant left:

i. "... He was not there when the main injury was inflicted and, of course ... there needs to be an

adjustment made ... to reflect that." (Sentencing remarks page 6 E‑F)

(5) In terms of statutory aggravating features, the judge noted that the appellant had relevant previous
convictions. Indeed, at the date of conviction, the appellant had 15 previous convictions for 35 offences,
spanning from 9 August 2016 (when the appellant was only [an age]) to 22 February 2022. Those
convictions included four offences against the person and five offensive weapon offences; he was also on
bail for an offence of violent disorder (committed six days earlier) when he committed the index offence.
As the Judge observed, the appellant's antecedents suggested this incident was an escalation in both
seriousness and violence. In discussion with leading counsel, the judge noted:

i. "If he were an adult, he would be found dangerous within a heartbeat. ... but even though I think he
meets the criteria I have to be very slow to look at that ... where I have someone of his age. ... Were he
older, I would make that finding. But his age, as of today, tips me against making that finding today."

(Mitigation transcript pages 4G‑5B)

(6) Having referred to the appellant's age in the context of the question of dangerousness (albeit at one
stage she wrongly referred to him as being [an age] at the date of the offence (he was [an age]) and later

said he was [an age]), the judge also stated that she had expressly had regard to the pre‑sentence report,

which provided a detailed account of his unstable upbringing (something the judge noted was mentioned
within the SCYP Guideline), his low intellect and lack of victim empathy (observing that this was not
something that she weighed against him, rather it was evidence of his intellectual abilities). The judge also
had regard to the assessment from the Single Competent Authority, which had found there were
reasonable grounds to conclude that the appellant was a victim of modern slavery (we note the update
that Mr Butt has given us that there has since been a finding that the appellant is not a victim of modern
**_slavery, although that would also reflect the later date of the final conclusive grounds report). The judge_**
also referred to a community impact report from the police and to reports from Dr S (Chartered

Psychologist and Neuropsychologist), setting out the diagnosis of Post‑Traumatic Stress Disorder in the


-----

appellant's case, arising from an incident in which he was stabbed when he was 14 and explaining he had
a mild form of Intellectual Development Disorder.

(7) Having seen the relevant starting point in relation to this offence as 11 years, the judge explained:

i. "I then need to make the various adjustments ... for both aggravating and mitigating features, including
the role played by Mr A and the fact that he wasn't there when the injury caused ... in this offence to make
it a category 1 offence pushes it into that level. Notwithstanding this, it is accepted that it is a joint

responsibility case and he did know ‑ he did go there knowing a weapon was taken and was used in his

presence. He was [an age] at the time and in my ... view, although he was, in relation to this, almost [an

age], I do take into consideration both the pre‑sentence report and the community impact statement ... his

lack of maturity ... and the challenges he faces..." (Sentencing remarks page 7C‑E)

ii. Although not stated by the judge, it would seem that having regard to these mitigating features she
reduced the starting point in his case to something around eight years and 10 months (in working back to
this calculation, we are grateful to Mr Butt KC who has sought to carry out this exercise, working back from
the final term imposed).

iii. Referring to the Single Competent Authority's assessment, the appellant's age and maturity, the judge

took the view that the appropriate reduction in the appellant's case would be of one‑third. During mitigation

submissions, the judge had explained her approach in relation to the SCYP Guideline, as follows:

iv. "... he is entitled to a third. He is not entitled to a half. He is over that age where he would get half
discount." (Mitigation transcript page 5F)

(8) That reduction appears to have led to a term of around five years 11 months. Then applying 18 per
cent credit for plea, the judge finally arrived at a sentence of four years and nine months.

5. The appeal

(1) By the first ground of appeal, the appellant contends that the judge erred in her assessment of harm in
this case as falling within Category 1. A section 18 offence will very often involve really serious harm; not

every injury that would be life‑threatening if untreated will fall within Category 1 (see R v O'Bryan [2022] 1

Cr App R (S) 531).

(2) In this case, it is submitted that the judge erred in accepting what had been said in the victim impact
statements to the effect that the complainant was unable to walk unaided. That was contradicted by the

contemporaneous medical evidence and by footage from police body‑worn cameras from 17 August 2022

following an (unrelated) arrest of the complainant, which showed him walking without a knee brace,
struggling with arresting officers and jumping unaided out of a police van. As for the judge's reliance on Dr

G's report, that had fallen into the error identified in O'Bryan: "the phrase 'life‑threatening injury' did not

cover every wounding causing injury which, left untreated, might lead to death". More generally, the
evidence as to whether the complainant would have been able to return to work was inconclusive and,

even if the complainant might not have been able to return to his pre‑injury work as a roofer, that would not

be determinative of Category 1 harm.

(3) More generally, the appellant contends that the judge erred in her approach to the sentencing exercise
she had to undertake in this case. She had settled upon a starting point for both defendants before making
any reduction to reflect the lesser role played by the appellant. That, it is contended, led the judge into
error when categorising this offence under the guidelines. Given he had not carried a knife, had struck no
blow and had withdrawn from the incident after 30 seconds, the seriousness of the offence committed by
the appellant was not the same as in the case of Mr Alder. Moreover, considering the offence in which the
appellant had participated, it had not involved harm falling within Category 1: the single blow inflicted by the
machete during the first moments of the attack could not be said to have led to any injuries that could bring
this within Category 1. As for culpability, although the judge was entitled to have regard to the fact that a


-----

highly dangerous weapon was used at a stage when the appellant was still a participant in the attack, there
were no other features that would warrant treating his involvement as falling within Category A.

(4) It is yet further contended that the judge failed to properly apply the SCYP Guideline. Accepting that
the Judge had expressly referred to the guideline, it is nevertheless objective that she failed to give proper
regard to the emotional and developmental age and maturity of the appellant, in particular given the
evidence of his unstable upbringing, his learning difficulties and mental health issues, and the indication
that he was participating in this offence due to peer pressure, coercion or manipulation (consistent with the
Single Competent Authority's assessment).

6. Analysis and conclusions

(1) This was a serious, violent attack, initially involving two against one, in which a dangerous weapon was
used almost from the outset. The consequences were, however, not as significant as they might have

been, and ‑ seeing this through the prism of section 18 ‑ we do not consider that the impact upon the

complainant can properly be described as falling within the highest category under this guideline. As this
court made clear in O'Bryan, not every injury that might, if left untreated, lead to death will amount to a

'life‑threatening injury' for these purposes.

(2) In this case, we acknowledge that the judge's focus was on what she considered to be a permanent

injury ‑ an inability to walk unaided ‑ that would have had a substantial and long term effect on the

complainant's ability to carry out normal day‑to‑day activities or on his ability to work. The difficulty with

that finding, however, was that it was not supported by the objective evidence before the judge: the

contemporaneous medical evidence and the police body‑worn video footage of the complainant's apparent

mobility on 17 August 2022. As for the potential impact on the complainant's inability to work, we agree
with the appellant: even if this was accepted as the likely outcome, an inability to work as a roofer would

not necessarily be determinative of Category 1 harm. In our judgement, this was a case where ‑

notwithstanding the ferocity of the machete attack, and without minimising the injury suffered by the

complainant ‑ the evidence of impact placed this within Category 2 under the guideline.

(3) We also consider there is merit in the concerns raised as to the approach adopted by the judge in this
case in assessing the appellant's culpability. Determining the offence category must require the
sentencing judge to consider the particular offending behaviour of the individual defendant. The difficulty
with the approach adopted in this instance is that it failed to demonstrate any assessment of the appellant's
personal culpability when determining the appropriate category level under the guideline. That was not a
mitigating factor but a necessary part of the assessment of the seriousness of the offence in the appellant's
case. When focusing on the culpability of the appellant, the judge was entitled to have regard to the fact
that he had been part of the initial attack, present when Mr Alder cast the first blow with the machete. That
placed this within the higher culpability category under the guideline. That, however, had to be balanced

against the appellant's limited participation ‑ he fled the scene after the first 30 seconds ‑ and the evidence

of the lesser nature of his role. These were factors that we consider properly placed the appellant at the
lower end of Category A culpability.

(4) If viewed as an adult, we would thus find the appropriate categorisation of the appellant's offending
under the guideline was 2A, giving a starting point of seven years and a range of six to ten years. Given
our view as to the more limited nature of the appellant's role, we would assess the relevant starting point in
this case at six years.

(5) There were, of course, significant statutory aggravating features in the appellant's case given his
criminal record and the fact that he was on bail at the time of this offence. That said, these have to be
viewed in context: the appellant is a young man ([an age] at the time of the offence) with what is described

as an "unstable" background. As the author of the pre‑sentence report explains, the appellant has spent

time in and out of the care system, with social services being involved in his life effectively from birth; he
was made subject to child protection plans on two occasions under the category of neglect and was then


-----

removed from his mother's care under an interim care order. He was introduced to drugs from an early
age and when he was 13 he went missing and was not located for several months. We do not refer to this
background to excuse the appellant's appalling history of criminal behaviour, but it provides a context
which would lead us to increase the starting point by only a year to take account of the statutory
aggravating features in this case.

(6) Having thus considered the appropriate sentence as if the appellant were an adult, we then turn to the
SCYP Guideline. We acknowledge that the judge took this into account when determining to reduce the

appellant's sentence by one‑third (given his particular age), but this is never a purely mechanistic exercise,

with a particular level of reduction being relevant to the offender's age. We note the requirement that
regard be had to the emotional and developmental age and maturity of the child or young person
(something that is at least of equal importance as their chronological age). The evidence in this case (from

the pre‑sentence report and the cognitive report of Dr S) is that the appellant has suffered from mental

health issues, demonstrates learning difficulties and has a mild Intellectual Development Disorder which
leaves him with little adaptive ability. Taking into account both the appellant's chronological age and his
level of maturity, we consider the appropriate reduction pursuant to the SCYP Guideline would take the
sentence that would otherwise have been imposed down to four years. Allowing a further 18 per cent
reduction for plea, that would result in a sentence of three years three months' detention under section 250
of the Sentencing Code.

7. Disposal

i. For the reasons thus provided, we allow this appeal and quash the sentence of 57 months' youth
custody, substituting in its place a sentence of three years three months' detention.

8. MR BUTT: Can I raise the representation order? An order was granted for junior counsel only before
this court and I asked the Registrar whether I might be able to ask this court to vary that direction and was
told that I could make that request. The resident judge granted legal aid for King's counsel, rightly or
wrongly. Having completed the sentence I did not feel there was anything I could do but advise on appeal
and once leave was granted equally I thought it would be irresponsible to return it. There might be cases,
of course, where if there were two counsel junior counsel only might be appropriate but I wonder whether

in this case the court might grant ‑‑

9. LORD JUSTICE WILLIAM DAVIS: We grant a representation order for leading counsel.

10. MR BUTT: Thank you very much, my Lord.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

