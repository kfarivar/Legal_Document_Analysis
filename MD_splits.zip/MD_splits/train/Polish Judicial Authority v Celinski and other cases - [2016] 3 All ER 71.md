# Polish Judicial Authority v Celinski and other cases [2016] 3 All ER 71

[2015] EWHC 1274 (Admin)

QUEEN'S BENCH DIVISION (DIVISIONAL COURT)

LORD THOMAS CJ, RYDER LJ AND OUSELEY J

3 MARCH, 6 MAY 2015

**Extradition — Extradition order — Appeal — Convention rights — Right to respect for private and family life**
**— Proportionality — Proper approach to be taken at extradition hearing — Proper approach to be taken on**
**appeal — Whether requested persons should be extradited — Extradition Act 1989 — Human Rights Act**
**1998, Sch 1, Pt I, art 8 — Extradition Act 2003, Pt 1, s 21A.**

[The court heard together four appeals, under the Extradition Act 2003, either brought by judicial authorities seeking](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1C9-00000-00&context=1519360)
the extradition of defendants or by defendants resisting their extradition, as they raised common issues in relation to
art 8[a] of the European Convention for the Protection of Human Rights and Fundamental Freedoms 1950 (as set
out in Sch 1 to the Human Rights Act 1998), as applied by the judges at the extradition hearing and on appeal. It
[also heard an appeal in relation to s 21A[b] of the 2003 Act and a judicial review of a decision under the Extradition](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CHH0-TWPY-Y0CD-00000-00&context=1519360)
_[Act 1989 to extradite to Poland a Polish national resident in the Isle of Man, which raised an issue under art 8. The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CHH0-TWPY-Y0CD-00000-00&context=1519360)_
court considered: (i) the proper approach that should be taken at the extradition hearing by the district judge; (ii) the
proper approach on an appeal; and (iii) whether the requested persons should be extradited. Particular
consideration was given to the Supreme Court decisions Norris v Government of the United States of America (No
_2)_ _[[2010] 2 All ER 267 and HH v Deputy Prosecutor of the Italian Republic, Genoa](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7Y96-V3R0-Y96Y-G32V-00000-00&context=1519360)_ _[[2012] 4 All ER 539.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56WY-KBP1-DYBP-M4NC-00000-00&context=1519360)_

**Held – (1) The question raised under art 8 was whether the interference with private and family life of the person**
whose extradition had been sought was outweighed by the public interest in extradition. There was a constant and
weighty public interest in extradition that those accused of crimes should be brought to trial; that those convicted of
crimes should serve their sentences; that the United Kingdom should honour its international obligations and the UK
should not become a safe haven. That public interest would always carry great weight, but the weight varied
according to the nature and seriousness of the crime involved. It was important that the judge in the extradition
hearing bore in mind, when applying the principles set out in _Norris_ and _HH,_ a number of matters. First, _HH_
concerned three cases each of which had involved the interests of children and the judgments had to be read in
that context. Second, the public interest in ensuring that extradition arrangements were honoured was very high. So
too was the public interest in discouraging persons seeing the UK as a state willing to accept fugitives from justice.
A judge would be

1

expected to address those factors expressly in the reasoned judgment. Third, the decisions of the judicial authority
of a member state making a request should be accorded a proper degree of mutual confidence and respect. Fourth,
decisions on whether to prosecute an offender in England and Wales were, on constitutional principles, ordinarily

a Article 8 provides: 'Everyone has the right to respect for his private and family life, his home and his correspondence.'

b Section 21A, so far as material, is set out at [84], below.

**[*72]**


-----

matters for the independent decision of the prosecutor, save in circumstances set out in authorities. Challenges to
those decisions were generally only permissible in the pre-trial criminal proceedings or the trial itself. The
independence of prosecutorial decisions had to be borne in mind when considering issues under art 8. Fifth, factors
that mitigated the gravity of the offence or culpability would ordinarily be matters that the court in the requesting
state would take into account. Therefore, it was important in an accusation European arrest warrant for the judge at
the extradition hearing to bear that in mind. Although personal factors relating to family life would be factors to be
brought into the balance under art 8, the judge also had to take into account that those would also form part of the
matters considered by the court in the requesting state in the event of conviction. Sixth, in relation to conviction
appeals: the judge at the extradition hearing would seldom have the detailed knowledge of the proceedings, or the
background or previous offending history of the offender, which the sentencing judge had had before him; each
member state was entitled to set its own sentencing regime and levels of sentence and, provided it was in
accordance with the Convention, it was not for a UK judge to second guess that policy; and it would rarely be
appropriate for the court in the UK to consider whether the sentence had been very significantly different from what
a UK court would have imposed, let alone to approach extradition issues by substituting its own view of what the
appropriate sentence should have been. It was also clear that: the basic principles had not always been taken
properly into account at the extradition hearing; a structured approach had not always been applied to the balancing
of the factors under art 8, which was essential; and it should rarely, if ever, be necessary to cite to the court hearing
the extradition proceedings or on an appeal decisions on art 8 which were made in other cases, as they were
invariably fact specific and, in individual cases, judges of the Administrative Court were not laying down new
principles. It was not helpful to the proper conduct of extradition proceedings that the current practice of citation of
authorities other than Norris and HH was continued, either in the extradition hearing or on appeal. Further, it was
important that judges hearing cases where reliance was placed on art 8 adopted an approach which clearly set out
an analysis of the facts as found and contained, in succinct and clear terms, adequate reasoning for the conclusion
arrived at by balancing the necessary considerations. The approach should be one where the judge, after finding
the facts, ordinarily set out each of the 'pros' and 'cons' in a 'balance sheet'. The judge should then, having set out
the pros and cons in the balance sheet approach, set out his reasoned conclusions as to why extradition should be
ordered or the defendant discharged. It was hoped that the judge would list the factors that favoured extradition and
then the factors that militated against extradition. The judge would then, on the basis of the identification of the
relevant factors, set out his conclusion as the result of balancing those factors with reasoning to support that
[conclusion (see [6]–[17], below); Norris v Government of the United States of America (No 2) [2010] 2 All ER 267](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7Y96-V3R0-Y96Y-G32V-00000-00&context=1519360)
and _HH v Deputy Prosecutor of the Italian Republic, Genoa_ _[[2012] 4 All ER 539 applied;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56WY-KBP1-DYBP-M4NC-00000-00&context=1519360)_ _Re B-S (children)_
_(adoption: leave to oppose) [2013] 3 FCR 481 considered._
**[*73]**

(2) The single question for the appellate court was whether or not the district judge had made the wrong decision. It
was only if it concluded that the decision had been wrong, that the appeal could be allowed. Findings of fact,
especially if evidence had been heard, ordinarily had to be respected. In answering the question whether the district
judge, in the light of those findings of fact, had been wrong to decide that extradition had or had not been
proportionate, the focus had to be on the outcome, namely, on the decision itself. Although the district judge's
reasons for the proportionality decision had to be considered with care, errors and omissions did not, of themselves,
necessarily show that the decision on proportionality itself had been wrong (see [24], below); Re B (a child) (care
_[order: proportionality: criterion for review) [2013] 3 All ER 929 and Dunham v Government of the USA [2014] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:597M-BFN1-DYBP-M4GV-00000-00&context=1519360)_
_[(D) 206 (Feb) applied; Re G (a child) (care proceedings: welfare balancing exercise: proportionality) [2013] 3 FCR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BKM-63S1-DYBP-N225-00000-00&context=1519360)_
293 considered.

(3) Applying those principles to the cases before the court, the appeals of two judicial authorities would be allowed
and the cases remitted. In one appeal by a requested person, the balance was strongly in favour of extradition, but
further submissions were sought on the short time, namely, only a day or two, that remained for the requested
person to spend in custody in Poland. In another appeal by a requested person, the appeal would be dismissed.
With respect to the renewed application for judicial review, there was no basis for interfering with the judge's
decision. With respect to the judicial authority's appeal concerning s 21A of the 2003 Act, the judge had taken into
account matters outside the scope of s 21A, particularly delay as relevant for reasons other than the matters set out
in s 21A(3), and the matter would be remitted (see [39], [50], [63], [64], [78], [85], [86], below).


-----

**Notes**

For extradition from the United Kingdom to another territory, see 27 Halsbury's Laws (5th edn) (2015) para 66.

For extradition from the United Kingdom to EU member states and Gibraltar ('category 1 territories'), extradition
from or to the Channel Islands, the Isle of Man and British overseas territories, conduct of extradition proceedings,
extradition appeals and judicial review, the duty to consider human rights of person requested for extradition, and
the right to respect for private and family life, see 47 Halsbury's Laws (5th edn) (2014) paras 603, 607, 616, 624,
643, 650.

[For the Human Rights Act 1998, Sch 1, Pt I, art 8, see 7(1) Halsbury's Statutes (4th edn) (2015 reissue) 895.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0GT-00000-00&context=1519360)

[For the Extradition Act 2003, Pt 1, s 21A, see 12(3) Halsbury's Statutes (4th edn) (2014 reissue) 1144, 1173.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5D53-9GB1-DYCN-C0HW-00000-00&context=1519360)
**Cases referred to**

_[B (a child) (care order: proportionality: criterion for review), Re [2013] UKSC 33, [2013] 3 All ER 929, [2013] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:597M-BFN1-DYBP-M4GV-00000-00&context=1519360)_
1911.

_[Belbin v The Regional Court of Lille, France [2015] EWHC 149 (Admin), [2015] All ER (D) 02 (Feb), DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F6R-V0V1-DYBP-N0JY-00000-00&context=1519360)_

_B-S (children) (adoption: leave to oppose), Re [2013] EWCA Civ 1146, [2013] 3 FCR 481, [2014] 1 WLR 563._

_[Dunham v Government of the USA [2014] EWHC 334 (Admin), [2014] All ER (D) 206 (Feb), DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BKM-63S1-DYBP-N225-00000-00&context=1519360)_

_G (a child) (care proceedings: welfare balancing exercise: proportionality), Re [2013] EWCA Civ 965, [2013] 3 FCR_
293.
**[*74]**

_HH v Deputy Prosecutor of the Italian Republic, Genoa [2012] UKSC 25,_ _[[2012] 4 All ER 539, [2013] 1 AC 338,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56WY-KBP1-DYBP-M4NC-00000-00&context=1519360)_

[2012] 3 WLR 90.

_Miraszewski v District Court in Torun, Poland; Kanigowski v District Court in Torun, Poland; Fluœniak v District_
_Court in Rzeszow, Poland [2014] EWHC 4261 (Admin), [2015] 1 WLR 3929, DC._

_[Norris v Government of the United States of America (No 2) [2010] UKSC 9, [2010] 2 All ER 267, [2010] 2 AC 487,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7Y96-V3R0-Y96Y-G32V-00000-00&context=1519360)_

[2010] 2 WLR 572.

_R v A [2012] EWCA Crim 434, [2012] 2 Cr App Rep 80._

_[Sobieraj v District Court in Wroclaw, Poland [2013] EWHC 2450 (Admin).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:592Y-CWH1-F0JY-C1FR-00000-00&context=1519360)_

_[Welke v Provincial Court of Bydgoszcz, Poland [2013] EWHC 320 (Admin), [2013] All ER (D) 346 (Feb).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57VT-KH41-DYBP-N2T2-00000-00&context=1519360)_
**Appeals and judicial reviewPolish Judicial Authority v Celinski**

A Polish judicial authority appealed against orders of District Judge Zani on 11 June 2014, discharging Adam
Celinski from extradition to Poland to serve a sentence for supply of cannabis. The facts are set out in the
judgment.
_Slovakian Judicial Authority v Cambal_

A Slovakian judicial authority appealed against orders of District Judge Snow on 11 December 2014, discharging
Pavol Cambal from extradition to Slovakia to serve a sentence for production and possession of narcotics, and
theft. The facts are set out in the judgment.
_Nida v Polish Judicial Authority_

Krzysztof Nida appealed against orders of District Judge Devas on 28 October 2014 for his extradition to Poland to
serve a sentence for attempted street robbery. The facts are set out in the judgment.


-----

_Ciemiega v Polish Judicial Authority_

Pawel Ciemiega appealed against orders of District Judge Tempia on 19 December 2014 for his extradition to
Poland to serve a sentence for theft. The facts are set out in the judgment.
_R (on the application of Inglot) v Secretary of State for the Home Department and another_

Piotr Inglot, resident on the Isle of Man, renewed his application for judicial review the decision of District Judge
[Evans made on 15 March 2014, under the Extradition Act 1989, to refer to the Secretary of State the decision on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CHH0-TWPY-Y0CD-00000-00&context=1519360)
extradition to Poland to serve a sentence for supplying small amounts of cannabis. The facts are set out in the
judgment.
_Polish Judicial Authority v Pawelec_

[A Polish judicial authority appealed, in relation to s 21A of the Extradition Act 2003, against the decision of District](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5D53-9GB1-DYCN-C0HW-00000-00&context=1519360)
Judge Devas on 17 November 2014, that it was not proportionate to extradite Konrad Pawelec to Poland to face
trial for forgery and fraud. The facts are set out in the judgment.

_Julian Knowles QC and Adam Payter (instructed by the Crown Prosecution Service) for the judicial authorities._

_Hugh Southey QC and Kate O'Raghallaigh (instructed by Lansbury Worthington Ltd) for Celinski._

_Nicholas Hearn (instructed by Gordon, Shine & Co) for Pawelec._

_Alun Jones QC and Natasha Draycott (instructed by Kaim Todner Solicitors Ltd) for Nida._

_Gavin Irwin (instructed by Edward Hayes LLP) for Ciemiega._

_Amelia Nice (instructed by Bullivant Law Ltd) for Cambal._

_Daniel Jones (instructed by Lansbury Worthington Ltd) for Inglot._

_Ben Lloyd (instructed by the Government Legal Department) for the Secretary of State in the Inglot case._

_Peter Caldwell (instructed by the Crown Prosecution Service) for the Government of Poland in the Inglot case._

_Judgment was reserved._

6 May 2015. The following judgment of the court was delivered.

**LORD THOMAS CJ.**

This is the judgment of the court.

**[1] It is clear that in the majority of cases in extradition proceedings under Pt I of the Extradition Act 2003 ('the 2003**
Act') defendants now seek to rely on art 8 of the European Convention for the Protection of Human Rights and
Fundamental Freedoms 1950 (as set out in Sch 1 to the Human Rights Act 1998) ('ECHR') to resist their extradition
to other states within the European Union. Out of 479 cases in which an extradition hearing was scheduled to take
place in the period of three months from 17 March 2015, all but 18 of these were requests by judicial authorities of
EU member states. Out of these 461 cases involving EU member states, reliance was clearly being placed on art 8
in 280 cases; it was likely that it would be relied on in further cases. It was the best estimate of the Chief Magistrate
(who kindly carried out the survey for the court) that art 8 would be relied on in between 350–400 cases over the
following three months. It was the view of the Chief Magistrate, based on his own experience and that of the judges
who conduct extradition hearings, that art 8 was relied on in about 120 cases a month. Appeals are very frequently
brought to this court in relation to such decisions. That frequency can be judged by the fact that it is ordinarily
necessary each week for a Divisional Court and 1–2 High Court judges sitting alone to hear appeals under the 2003
Act.

**[2] Prior to the decision of the Supreme Court in** _HH v Deputy Prosecutor of the Italian Republic, Genoa [2012]_
_[UKSC 25, [2012] 4 All ER 539, [2013] 1 AC 338, it was only in a rare case that reliance was placed on art 8: see the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56WY-KBP1-DYBP-M4NC-00000-00&context=1519360)_
judgment of Lord Wilson in _HH at [168]–[169]. In the period of just under three years, as the information set out_


-----

above indicates, the position in Westminster Magistrates' Court has very significantly changed. This change in the
practice is noted in the recent House of Lords select committee report Extradition: UK law and Practice (HL Paper
126) (10 March 2015).

**[3] We therefore heard together several appeals under the 2003 Act (either brought by judicial authorities seeking**
the extradition of defendants or by defendants resisting their extradition) as they raised common issues in relation
to art 8 as applied by the judges at the extradition hearing and on appeal to this court. We also heard an appeal in
relation to s 21A of the Extradition Act and
**[*76]**

[a judicial review of a decision under the Extradition Act 1989 to extradite to Poland a Polish national resident in the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CHH0-TWPY-Y0CD-00000-00&context=1519360)
Isle of Man which raised an issue under art 8.

**[4] Before setting out the facts and our conclusions in relation to the appeals, it is necessary first to consider the**
approach that should be taken at the extradition hearing by the district judge and then consider the proper approach
on an appeal.
**The approach of a court at the extradition hearing(a) The general principles in relation to art 8**

**[5] The general principles in relation to the application of art 8 in the context of extradition proceedings are set out in**
two decisions of the Supreme Court: Norris v Government of the United States of America (No 2) [2010] UKSC 9,

_[[2010] 2 All ER 267, [2010] 2 AC 487and HH.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7Y96-V3R0-Y96Y-G32V-00000-00&context=1519360)_

**[6] In HH Baroness Hale summarised (at [8]) the effect of the decision in Norris; in sub-paras (3), (4) and (5), she**
made clear that the question raised under art 8 was whether the interference with private and family life of the
person whose extradition was sought was outweighed by the public interest in extradition. There was a constant
and weighty public interest in extradition that those accused of crimes should be brought to trial; that those
convicted of crimes should serve their sentences; that the UK should honour its international obligations and the UK
should not become a safe haven. That public interest would always carry great weight, but the weight varied
according to the nature and seriousness of the crime involved. This was again emphasised by Baroness Hale at

[31], by Lord Judge at [111] (where he set out a number of passages to this effect from Norris) and [121], Lord Kerr
at [141] and Lord Wilson at [161]–[162] and [167].

**[7] It is clear from our consideration of these appeals that it is important that the judge in the extradition hearing**
bears in mind, when applying the principles set out in Norris and HH, a number of matters.

**[8] First, HH concerned three cases each of which involved the interests of children: see in particular the judgment**
of Baroness Hale at [9]–[15], [24]–[25], [33]–[34], [44]–[48], [67]–[79], [82]–[86]; Lord Mance at [98]–[101]; Lord
Judge at [113]–[117], [123]–[132]; Lord Kerr at [144]–[146]; Lord Wilson at [153]–[156] and [170]. The judgments
must be read in that context.

**[9] Second the public interest in ensuring that extradition arrangements are honoured is very high. So too is the**
public interest in discouraging persons seeing the UK as a state willing to accept fugitives from justice. We would
expect a judge to address these factors expressly in the reasoned judgment.

**[10] Third the decisions of the judicial authority of a member state making a request should be accorded a proper**
degree of mutual confidence and respect. Pt I of the 2003 Act gave effect to the Council Framework Decision
2002/584/JHA (on the European arrest warrant and the surrender procedures between Member States—
Statements made by certain Member States on the adoption of the Framework Decision) (OJ 2002 L190 p 1); it
replaced the system of requests for extradition by governments (of which the judicial review before the court in
respect of the Polish national is a surviving illustration). The arrangements under Pt I of the 2003 Act operate
between judicial authorities without any intervention of governments. In applying the principles to requests by
judicial authorities within the EU, it is essential therefore to bear in mind that the procedures under Pt I (reflecting
the
**[*77]**


-----

Framework Decision) are based on principles of mutual confidence and respect between the judicial authorities of
the member states of the EU. As the UK has been subject to the jurisdiction of the Court of Justice of the European
Union ('CJEU') since 1 December 2014, it is important for the courts of England and Wales to have regard to the
jurisprudence of that court on the Framework Decision and the importance of mutual confidence and respect.

**[11] Fourth, decisions on whether to prosecute an offender in England and Wales are on constitutional principles**
ordinarily matters for the independent decision of the prosecutor save in circumstances set out in authorities such
as _R v A [2012] EWCA Crim 434, [2012] 2 Cr App Rep 80; challenges to those decisions are generally only_
permissible in the pre-trial criminal proceedings or the trial itself. The independence of prosecutorial decisions must
be borne in mind when considering issues under art 8.

**[12] Fifth, factors that mitigate the gravity of the offence or culpability will ordinarily be matters that the court in the**
requesting state will take into account; it is therefore important in an accusation European Arrest Warrant ('EAW')
for the judge at the extradition hearing to bear that in mind. Although personal factors relating to family life will be
factors to be brought into the balance under art 8, the judge must also take into account that these will also form
part of the matters considered by the court in the requesting state in the event of conviction.

**[13] Sixth in relation to conviction appeals:**

(i)   The judge at the extradition hearing will seldom have the detailed knowledge of the proceedings or of
the background or previous offending history of the offender which the sentencing judge had before him.

(ii)   Each member state is entitled to set its own sentencing regime and levels of sentence. Provided it is
in accordance with the ECHR, it is not for a UK judge to second guess that policy. The prevalence and
significance of certain types of offending are matters for the requesting state and judiciary to decide;
currency conversions may tell little of the real monetary value of items stolen or of sums defrauded. For
example, if a state has a sentencing regime under which suspended sentences are passed on conditions
such as regular reporting and such a regime results in such sentences being passed much more readily
than the UK, then a court in the UK should respect the importance to courts in that state of seeking to
enforce non-compliance with the terms of a suspended sentence.

(iii)   It will therefore rarely be appropriate for the court in the UK to consider whether the sentence was
very significantly different from what a UK court would have imposed, let alone to approach extradition
issues by substituting its own view of what the appropriate sentence should have been. As Lord Hope said
in HH _[[2012] 4 All ER 539, [2013] 1 AC 338(at [95]) in relation to the appeal in the case of PH, a conviction](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56WY-KBP1-DYBP-M4NC-00000-00&context=1519360)_
EAW:

'But I have concluded that it is not open to us, as the requested court, to question the decision of the requesting
authorities to issue an arrest warrant at this stage. This is their case, not ours. Our duty is to give effect to the
procedure which they have decided to invoke and the proper place for leniency to be exercised, if there are
grounds for leniency, is Italy.'

Lord Judge made clear at [132], again when dealing with the position of children, that:
**[*78]**

'When resistance to extradition is advanced, as in effect it is in each of these appeals, on the basis of the art 8
entitlements of dependent children and the interests of society in their welfare, it should only be in very rare
cases that extradition may properly be avoided if, given the same broadly similar facts, and after making
proportionate allowance as we do for the interests of dependent children, the sentencing courts here would
nevertheless be likely to impose an immediate custodial sentence: any other approach would be inconsistent
with the principles of international comity. At the same time, we must exercise caution not to impose our views
about the seriousness of the offence or offences under consideration or the level of sentences or the
arrangements for prisoner release which we are informed are likely to operate in the country seeking
extradition. It certainly does not follow that extradition should be refused just because the sentencing court in
this country would not order an immediate custodial sentence: however it would become relevant to the
decision if the interests of a child or children might tip the sentencing scale here so as to reduce what would


-----

otherwise be an immediate custodial sentence in favour of a non-custodial sentence (including a suspended
sentence).'

**[14] It is also clear, as some of these appeals illustrate:**

(i)   The basic principles to which we have referred have not always been taken properly into account at
the extradition hearing.

(ii)   A structured approach has not always been applied to the balancing of the factors under art 8. This is
essential, because each case turns on the facts as found by the judge and the balancing of the
considerations set out in _Norris_ and _HH. We suggest at [15], below, an approach which would fulfil this_
requirement.

(iii)   Decisions of the Administrative Court in relation to art 8 are often cited to the court. It should, in our
view, rarely, if ever, be necessary to cite to the court hearing the extradition proceedings or on an appeal
decisions on art 8 which are made in other cases, as these are invariably fact specific and in individual
cases judges of the Administrative Court are not laying down new principles. Many such cases were
referred to in the skeleton arguments. We have referred to none of them in this judgment, as the principles
to be applied are those set out in Norris and HH. If further guidance on the application of the principles is
needed, such guidance will be given by a specially constituted Divisional Court or on appeal to the
Supreme Court. It is not helpful to the proper conduct of extradition proceedings that the current practice of
citation of authorities other than Norris and HH is continued either in the extradition hearing or on appeal.

_(b) Balancing of the considerations_

**[15] As we have indicated, it is important in our view that judges hearing cases where reliance is placed on art 8**
adopt an approach which clearly sets out an analysis of the facts as found and contains in succinct and clear terms
adequate reasoning for the conclusion arrived at by balancing the necessary considerations.

**[16] The approach should be one where the judge, after finding the facts, ordinarily sets out each of the 'pros' and**
'cons' in what has aptly been described as a 'balance sheet' in some of the cases concerning issues of art 8 which
have arisen in the context of care order or adoption: see the cases cited in Re B-S (children) (adoption: leave to
_oppose) [2013] EWCA Civ 1146, [2013]_
**[*79]**

3 FCR 481, [2014] 1 WLR 563(at [30]–[44]). The judge should then, having set out the 'pros' and 'cons' in the
'balance sheet' approach, set out his reasoned conclusions as to why extradition should be ordered or the
defendant discharged.

**[17] We would therefore hope that the judge would list the factors that favoured extradition and then the factors that**
militated against extradition. The judge would then, on the basis of the identification of the relevant factors, set out
his/her conclusion as the result of balancing those factors with reasoning to support that conclusion. As appeals in
these cases are, for the reasons we shall examine, common, such an approach is of the greatest assistance to an
appellate court.
**The approach of the court on appeal(a) The statutory provisions relating to an appeal**

**[18] The provisions governing an appeal under Pt I of the Act are set out in ss 26–29 of the 2003 Act. These are**
very specifically drafted provisions which set out the powers of a court in much more limited terms than those set
out in other provisions relating to appeals in criminal and civil matters. Furthermore, as the provisions of the
procedural rules applicable to extradition appeals are no longer the Civil Procedure Rules ('CPR'), but the Criminal
Procedure Rules ('Crim PR'), it follows that CPR 52.11(1) which specifically provides that 'Every appeal will be
limited to a review of the decision of the lower court …', is no longer applicable.
_(b) The role of an appellate court_

**[19] As we have observed, many decisions made by district judges on art 8 are now subject to appeal. This may be**
because, in cases where the requested person is remanded on bail, there is no disincentive to appeal. Where the
person is in custody, given the relatively benign regime of prison conditions in the UK in comparison to those in


-----

many other member states, there is an added incentive to appeal, as time spent in prison in the UK counts against
any sentence to be served.

**[20] The court has in these circumstances recently considered the approach to be adopted on appeal in relation to**
issues of proportionality under art 8.

(i)   In _Dunham v Government of the USA [2014] EWHC 334 (Admin),_ _[[2014] All ER (D) 206 (Feb),](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BKM-63S1-DYBP-N225-00000-00&context=1519360)_
Beatson LJ said (at [66]) in relation to an appeal in a Pt II case:

'When the time comes to resolve that tension, the fact that this court is exercising an appellate jurisdiction
[under s 103 of the Extradition Act 2003 Act may be relevant to the way it is done. In [Re B (a child) (care order:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DG0-TWPY-Y01M-00000-00&context=1519360)
_[proportionality: criterion for review) [2013] UKSC 33, [2013] 3 All ER 929, [2013] 1 WLR 1911] a majority of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:597M-BFN1-DYBP-M4GV-00000-00&context=1519360)_
Supreme Court held that an appellate court should treat the determination of the proportionality of an
interference with the rights protected by the ECHR as an appellate exercise and not a fresh determination of
necessity or proportionality, notwithstanding the duty of the court as a public body to consider human rights,
see in particular [35]–[36], [83]–[85] and [136]. Lady Hale and Lord Kerr dissented ibid, at [119], [121] and

[205].'

(ii)   That observation was then followed Belbin v The Regional Court of Lille, France [2015] EWHC 149
_[(Admin), [2015] All ER (D) 02 (Feb) (a Pt I](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F6R-V0V1-DYBP-N0JY-00000-00&context=1519360)_

**[*80]**

case) where Aikens LJ set out the view of the court as to how the Divisional Court should approach an
appeal in art 8 cases. After referring to the views of Beatson LJ and of Lord Wilson in Re B (a child) Aikens
LJ said (at [66]):

'If, as we believe, the correct approach on appeal is one of review, then we think this court should not interfere
simply because it takes a different view overall of the value-judgment that the district judge has made or even
the weight that he has attached to one or more individual factors which he took into account in reaching that
overall value-judgment. In our judgment, generally speaking and in cases where no question of “fresh
evidence” arises on an appeal on “proportionality”, a successful challenge can only be mounted if it is
demonstrated, on review, that the judge below; (i) misapplied the well-established legal principles, or (ii) made
a relevant finding of fact that no reasonable judge could have reached on the evidence, which had a material
effect on the value-judgment, or (iii) failed to take into account a relevant fact or factor, or took into account an
irrelevant fact or factor, or (iv) reached a conclusion overall that was irrational or perverse.'

**[21] In the argument before us, in addition to the argument in relation to paragraphs from Lord Wilson's judgment**
cited by Aikens LJ, we heard substantial argument on the passages in the judgment of Lord Neuberger in Re B (a
_[child) [2013] 3 All ER 929, [2013] 1 WLR 1911. Lord Neuberger set out the ways an appellate judge might consider](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:597M-BFN1-DYBP-M4GV-00000-00&context=1519360)_
a trial judge's conclusion on proportionality:

'[93] There is a danger in over-analysis, but I would add this. An appellate judge may conclude that the trial
judge's conclusion on proportionality was (i) the only possible view, (ii) a view which she considers was right,
(iii) a view on which she has doubts, but on balance considers was right, (iv) a view which she cannot say was
right or wrong, (v) a view on which she has doubts, but on balance considers was wrong, (vi) a view which she
considers was wrong, or (vii) a view which is unsupportable. The appeal must be dismissed if the appellate
judge's view is in category (i) to (iv) and allowed if it is in category (vi) or (vii).

[94] As to category (iv), there will be a number of cases where an appellate court may think that there is no
right answer, in the sense that reasonable judges could differ in their conclusions. As with many evaluative
assessments, cases raising an issue on proportionality will include those where the answer is in a grey area, as
well as those where the answer is in a black or a white area. An appellate court is much less likely to conclude
that category (iv) applies in cases where the trial judge's decision was not based on his assessment of the
witnesses' reliability or likely future conduct. So far as category (v) is concerned, the appellate judge should
think very carefully about the benefit the trial judge had in seeing the witnesses and hearing the evidence,
which are factors whose significance depends on the particular case However if after such anxious


-----

consideration, an appellate judge adheres to her view that the trial judge's decision was wrong, then I think that
she should allow the appeal.'

**[22] The approach of the Supreme Court was considered by the Court of Appeal in** _Re G (a child) (care_
_proceedings: welfare balancing exercise: proportionality)_
**[*81]**

_[2013] EWCA Civ 965, [2013] 3 FCR 293. The court, see particularly the judgment of McFarlane LJ at [32]–[43],_
made clear that its view of _Re B (a child)_ was that the appellate court was not required to undertake a fresh
determination on an art 8 issue. There was no need to reappraise the issue on proportionality but, as the
consideration on art 8 was not an exercise of discretion, the review of an appellate court had to be conducted to
determine whether the determination was 'wrong'. That approach was followed in Re B-S (children) (adoption: leave
_to oppose) [2013] EWCA Civ 1146, [2013] 3 FCR 481: see [75]–[83]._

**[23] In the light of the argument before us, we entirely endorse the general approach adopted by Beatson LJ and**
Aikens LJ, but consider that application of that approach by use of the analysis in the judgment of Lord Neuberger
is likely to achieve a more consistent approach that is compliant with art 8 and the provisions of the 2003 Act
dealing with appeals.

**[24] The single question therefore for the appellate court is whether or not the district judge made the wrong**
decision. It is only if the court concludes that the decision was wrong, applying what Lord Neuberger said, as set out
above, that the appeal can be allowed. Findings of fact, especially if evidence has been heard, must ordinarily be
respected. In answering the question whether the district judge, in the light of those findings of fact, was wrong to
decide that extradition was or was not proportionate, the focus must be on the outcome, that is on the decision
itself. Although the district judge's reasons for the proportionality decision must be considered with care, errors and
omissions do not of themselves necessarily show that the decision on proportionality itself was wrong.

**[25] We therefore turn to set out our conclusions on each of the appeals before us.**
**(1) Polish Judicial Authority v CelinskiThe EAWs**

**[26] Celinski was the subject of three EAWs. They covered offending during the period October 2008 and 2011. As**
Celinski was born on 23 July 1992 they covered his behaviour when he was between the ages of 16 and 19.

**[27] The first warrant was an accusation warrant in respect of:**

(i)   The supply of ten ecstasy pills between 1 and 31 August 2009 for financial gain. The maximum
penalty in Poland is ten years' imprisonment.

(ii)   The supply of one ecstasy pill between 1 and 22 September 2009 for no payment. The maximum
penalty in Poland is three years' imprisonment

That EAW ('EAW 1') was issued on 30 August 2012 in respect of an order of the court in Legionowo, Poland dated
23 March 2012. It was certified in the UK on 13 February 2013. After the initial hearing before the district judge,
Celinski was released on conditional bail.

**[28] The second EAW was another accusation warrant in respect of offences committed with four other people**
where the value of the stolen goods (which included power tools, building materials and a rowing boat) was about
£2,130:

(i)   Four offences of theft from houses under construction and one from a barn between October 2008
and February 2011.

(ii)   Three offences of dwelling house burglary in September 2010.

(iii)   One offence of theft between 2009 and 2011.

**[*82]**


-----

The second EAW ('EAW 2') had been issued on 23 January 2014 to enforce the order of the same court in
Legionowo, Poland dated 20 May 2013. It was certified in the UK on 1 February 2014. After the initial hearing
before the district judge, Celinski was released on conditional bail.

**[29] Celinski had been interviewed by the police in Poland about these offences in 2009 and again in 2011. He had**
been notified of his obligation to keep the Polish authorities informed of his address. He left for the UK in 2011
without informing the Polish authorities; they discovered his whereabouts in June 2012.

**[30] The third EAW ('EAW 3') was a conviction EAW to enforce an order of a court in Ostrolek, Poland dated 31**
August 2012 to implement a sentence of two years' imprisonment imposed after convictions for the supply of
cannabis on two occasions between July 2009 and February 2010. He had sold cannabis in small amounts for
financial gain to at least 8 minors and 12 adults on forty occasions in several Polish towns. The sentence of two
years' imprisonment had been suspended, but Celinski had left Poland three days after the sentence had been
imposed; he had failed to comply with the conditions of the suspended sentence (attendance at probation and
payment of a fine). The EAW was issued on 29 May 2014; it was certified in the UK on 3 June 2014. Celinski was
arrested under this EAW on 19 June 2014 after the hearing in respect of EAW 1 and EAW 2 in January, March and
June 2014 and the judgment given in relation to those EAWs on 11 June 2014. He was released on conditional bail.
_The hearing of EAW 1 and 2 before District Judge Zani_

**[31] The hearing on EAW 1 and 2 took place before District Judge Zani who made his findings in a judgment dated**
11 June 2014. He dismissed a challenge under s 2 of the 2003 Act. He heard evidence from Celinski and his
mother. The judge found that they both impressed him with their evidence. We take that to mean that he believed
them; it would have been clearer if he had said so expressly. His findings of fact were, as appears from his
judgment, in summary:

(i)   Celinski's grandmother died when he was nine or ten years of age; he had found her death one of the
most traumatic experiences of his life because he had taken the responsibility of caring for his grandmother
as his grandfather had left her for another person.

(ii)   When he was 14 years of age his father died within a month of being diagnosed with cancer.

(iii)   The loss of both his grandmother and his father had a negative impact and led him to associate with
'the wrong crowd'. He became involved in drugs. It was during that period he committed his offending
which in the case of EAW 1 and 2 spanned the period 2008–2011.

(iv)   He had been arrested and remanded in custody. He then left Poland and arrived in the UK in August
2011.

(v)   He had sorted out his previous drug dependency and found work.

(vi)   He had a caution for theft from a shop in the UK in November 2011.

(vii)   He lived with his mother and her partner and their two young children.

(viii)   He spent time with his family when he was not working and was a caring brother to his two young
step-siblings.

(ix)   He made a contribution to the family outgoings. Without that his mother, her partner and their two
children would have to move to other accommodation as they could not afford their current
accommodation.

**[*83]**

(x)   He was a hardworking member of society as well as an important member of the family, in both
financial and emotional terms.

**[32] The judge referred to the decisions in** _Norris and_ _HH. He then said that he took into account the fact that_
Celinski had spent two months in prison. He had been much younger when he began to commit the offences which
he had openly admitted. The judge had concerns as to the effect of imprisonment were he to return to Poland, as
he was likely to come into contact with more sophisticated criminals. Although the offences were serious he had to


-----

take into account the fact that Celinski had turned his life around. His reasons for his conclusion were set out in
three paragraphs:

'Albeit that the offences are serious, that is not the only factor to be taken into account (see, for example,

[[Welke v Provincial Court of Bydgoszcz, Poland [2013] EWHC 320 (Admin), [2013] All ER (D) 346 (Feb)] and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57VT-KH41-DYBP-N2T2-00000-00&context=1519360)
[the fact that [Celinski] has turned his life around is to be applauded (see Sobieraj v Poland [2013] EWHC 2450](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:592Y-CWH1-F0JY-C1FR-00000-00&context=1519360)
_[(Admin))](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:592Y-CWH1-F0JY-C1FR-00000-00&context=1519360)_

As has been repeatedly said in the past, each case where art 8 is raised is fact specific and therefore has to be
considered on its own merits and having considered the evidence and arguments advanced I am just
persuaded that this falls into the small number of cases where it would be art 8 disproportionate to order

[Celinski's] extradition.

I have carefully considered the submissions made by the parties to these proceedings and I accede to the
challenge based on art 8 ECHR presented on behalf of the requested person for reasons explained heretofore.'

**[33] He therefore discharged Celinski.**
_Proceedings before District Judge Devas on EAW 3_

**[34] On EAW 3 the hearing was before District Judge Devas on 19 January 2015; he gave a written judgment the**
same day. Judge Devas had before him the decision of District Judge Zani of 11 June 2014 and a further written
statement from Celinski.

**[35] Judge Devas decided that, although he was in no way bound by any decision made by District Judge Zani, he**
would proceed on the basis (as accepted by the advocates) of District Judge Zani's evaluation of the evidence
given by Celinski and his mother. He then said:

'I do not make any comment about the conclusions of the judge at that hearing and they appear to be both
sensible and understandable.'

The judge then proceeded to say that he considered there was a material difference as EAW 3 involved a number
of incidents of supply of admittedly small quantities of cannabis, but it was a conviction EAW and had resulted in a
significant sentence of imprisonment. Celinski had returned to the UK after the sentence imposed in August 2012
knowing he was not fulfilling his obligations following that sentence. After referring to the decision in Norris and HH,
although art 8 was engaged, the interference was both necessary and proportionate. He ordered his extradition.
_The arguments before us_

**[36] It was argued on behalf of the Polish Judicial Authority that whereas the decision of District Judge Devas was**
plainly correct, the same could not be said of the decision of District Judge Zani. He had made no proper analysis of
the position and had not set out his reasons.
**[*84] Our conclusion**

**[37] Applying the analysis of Lord Neuberger at [93] of Re B (a child)** _[[2013] 3 All ER 929, [2013] 1 WLR 1911, we](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:597M-BFN1-DYBP-M4GV-00000-00&context=1519360)_
consider District Judge Devas came to a view which was right on EAW 3. Celinski was a fugitive from justice facing
a significant period of imprisonment; there was great importance of giving effect to extradition arrangements. As
against that, although there would be some very limited interference with his family life based on the facts founds by
District Judge Zani, that interference was plainly proportionate. We dismiss that appeal.

**[38] In the light of our conclusion on EAW 3, Celinski will be extradited to Poland.**

**[39] The criticism of District Judge Zani's decision made by the Polish Judicial Authority was well founded. It did not**
set out a proper balancing exercise and contained no proper reasons. He substituted his own view of how the
Polish court should deal with Celinski. His view was clearly wrong. He should have recognised that the decision on
the punishment of Celinski was for the Polish court. The important public interests in upholding extradition
arrangements, and in preventing the UK being a safe haven for a fugitive as Celinski was found to be, would require


-----

very strong counter-balancing factors before extradition could be disproportionate. The offences of which Celinski
was accused included two dwelling house burglaries (which are not obviously minor offences) and five other
offences of dishonesty, as well as drug related offences. The counter-balancing factors in relation to his family life
now, his age and sad personal circumstances behind the alleged offending, and the way he had turned around is
life, are clearly insufficient. They are very much matters for the Polish court to consider in sentencing in the event of
a conviction. The appeal must be allowed, and we allow it regardless of the fact that he would be extradited anyway
on the third EAW. The appeal is therefore allowed, the decision quashed, and the case will be remitted to the
district judge with a s 29(5)(C) direction.
**(2) Slovakian Judicial Authority v Pavol Cambal**

**[40] Cambal's extradition is sought under a conviction EAW arising out of his conviction on 3 July 2006, when he**
was 29, at the District Court, Nitra, Slovakia of two offences:

(i)   Production and possession of narcotics. He was found in possession of three wraps of heroin on 8
May 2004 weighing about 0.29 grams.

(ii)   Theft of 11 television band stop filters between April and May 2004 from metal boxes belonging to a
cable TV company; this enabled viewers to extend the range of services that they could obtain from the TV
distributor without charge.

He attended the first hearing in Slovakia on 4 May 2005, but failed to attend the second hearing. He was declared a
fugitive. He was tried in absence, though his lawyer was present. He was convicted and sentenced to six years and
four months' imprisonment.

**[41] The conviction EAW was issued by the Slovakian Judicial Authority to enforce that sentence on 3 March 2009.**
It was not certified in the UK until February 2014. Cambal was arrested on 1 May 2014 and bailed on 9 May 2014.

**[42] It was Cambal's case that he had been drugged and trafficked into the UK by people he described as 'gypsies'**
in May 2005; attempts were made, he claimed to force him into prostitution and domestic service. He claimed to
have escaped in December 2005 and remained in the Peterborough area.
**[*85]**

**[43] On 11 December 2014, District Judge Snow gave his decision. He first set out his decision on issues other**
than art 8:

(i)   The judge found his evidence unimpressive. He concluded that he did not believe he was trafficked
and set out detailed reasons for that conclusion. He therefore held that Cambal could not rely on s 14 of
the 2003 Act.

(ii)   For similar reasons, the judge held that his absence from the court which convicted him was
voluntary. He therefore held that he could not rely on s 20 of the 2003 Act.

(iii)   There was no real risk of a breach of his art 4 rights were he to be extradited. The judge concluded,
having heard Cambal's evidence and that of his witnesses, that Cambal had not been trafficked. He was
satisfied, on the criminal standard and burden of proof, that Cambal was a fugitive. The district judge
commented on the fact that Cambal had referred himself to the National Referral Mechanism, and on the
increasing number of cases in which, potentially abusively, defendants were claiming to have been
trafficked. He would make no referral unless satisfied that there were reasonable grounds to believe that a
Requested Person had been trafficked. Where there had been a referral on reasonable grounds,
seemingly by the court, and so it did not apply here, he would not order extradition until ten days after the
conclusive decision. He does not say what he would do in consequence of a conclusive decision in favour
of a requested person.

**[44] In relation to art 8, the judge first set out the statutory provisions and then referred to Norris and HH. He then**
found the facts:

(i)   Cambal was a fugitive from justice and had lived in the UK under a false identity since 2005.


-----

(ii)   He had a number of previous convictions in the UK; the bulk were between October 2005 and March
2010. They were in fact largely shoplifting offences. He had one conviction since March 2010—possession
of cocaine in July 2013 for which he had received a conditional discharge.

(iii)   He had a partner with whom he did not live. The partner did benefit from the support of her children
in dealing with her own health issues; Cambal did provide her with emotional support.

(iv)   He had suffered for many years from addiction to class A drugs; this had led to his offending in
Slovakia and in the UK, but he had made a determined effort to rid himself of his addiction and had done
so. He had turned his life around. He had been successfully rehabilitated.

(v)   He had an offer of a job if not extradited.

**[45] He concluded that if Cambal was extradited, his ties in the UK which had supported his rehabilitation would be**
broken and he would return to the environment where his addiction arose with damaging consequences to him and
the community at large. Although this was not a case where the requested person had children, this was a case
where it is unlikely that he would have been given a custodial sentence in the UK, though that was not a decisive
factor (as he took into account what Lord Judge had said at [132] of HH). His fugitive status and his use of an alias
counted strongly against him, but in his favour was the fact that the offence occurred more than ten years ago, his
presence in the UK since 2005 and his relationship and employment prospects. What he regarded as tipping the
balance in his favour was the judge's finding that he had turned his life around. He therefore ordered his discharge.
**[*86]**

**[46] It was contended by the Slovakian Judicial Authority as appellants, that the judge was plainly wrong and has**
misapplied the principles set out in Norris and HH. His assessment of the seriousness of the offence was wrong.
The likely sentence in the UK was not relevant as he had been convicted. The judge had found Cambal to be a
fugitive from justice (as he clearly was); the judge had therefore wrongly taken into account the passage of time. He
had been wrong to take into account the delay in certifying the EAW as Cambal was living under a false name. He
had overlooked the fact that Cambal had not been punished.

**[47] It was contended on Cambal's behalf that there was no basis for interfering with the judge's decision on**
proportionality. Cambal had referred himself to the UK Human Trafficking Centre ('UKHTC') Competent Authority in
November 2014 and been recognised as a victim of trafficking by the UKHTC by a decision dated 5 February 2015.
Even though the decision contains no reasons, the decision should nonetheless have the effect that the issue as to
whether Cambal had been trafficked should be re-examined.
_Our conclusion_

**[48] We are satisfied that the decision of the judge misapplied the principles in Norris and HH, was wrong and must**
be set aside. His conduct of the balancing exercise failed to take into account:

(i)   The strong interest in upholding extradition arrangements.

(ii)   The fact that Cambal is a fugitive from justice and the strong interest in the UK not being a safe
haven for fugitives.

(iii)   The fact that the delay in extradition was attributable to his flight from Slovakia and his residence in
the UK under a false identity. This significantly reduces the weight that can be given to any private or family
life he acquired in the UK.

(iv)   The fact that the sentence had been imposed after conviction by a court of competent jurisdiction
following a trial attended by witnesses. The judge did not have the information (whether personal or
relating to the offence) which had led the court in Slovakia to impose the substantial custodial sentence.
The courts of England and Wales, in the absence of very cogent evidence, must assume that the sentence
reflected the gravity of the offending in all the circumstances as legitimately seen through the eyes of a
court which did have that knowledge. Where a sentence has been imposed following conviction in the
requesting state that is the approach which the courts of England and Wales should adopt. The judge
should not have considered in this context how the courts of England and Wales would have sentenced for
these offences even where there was a high degree of variance between the two approaches The


-----

**[*87]**


decision of the Slovakian court is entitled on principles of mutual confidence to proper respect. That, of
course, does not mean that the duration of the sentence during which the impact on family and private life
will be felt is irrelevant to the assessment of proportionality.

(v)   The family relationships were tenuous—he only provided emotional support to a partner with whom
he did not live.

(vi)   Thus far, there could be no doubt at all about how the balance should be struck. What tipped the
balance for the judge was the fact that Cambal had turned his life around, freeing himself from his drug
addiction, and that there was a risk that that good work would be undone,

and a greater risk in view of the length of sentence. This is a relevant consideration for art 8 purposes,
which the Slovak court could not have considered when passing sentence. But when put into the balance
against the factors to which we have referred, it simply cannot outweigh them, however much sympathy it
may arouse. The judge was therefore clearly wrong to reach the balance on those factors which he did.



**[49] The decision demonstrates the necessity of a judge setting out the 'pros' and 'cons' and adopting a 'balance**
sheet' approach.

**[50] The matter must therefore be remitted under the provisions of s 29 of the 2003 Act with a direction under s**
29(5)(C). Cambal can be admitted to bail on the same terms as he had been on bail.
_Position of the UKHTC Competent Authority_

**[51] In December 2008, the UK ratified the Council of Europe Convention on Action against Trafficking (2005)**
[(CETS no 197); it came into force on 1 April 2009; effect is given to several of its provisions by the Modern Slavery](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
_[Act 2015. The UK has also opted into European Parliament and Council Directive 2011/36/EU (on preventing and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
combating trafficking in human beings and protecting its victims, and replacing Council Framework Decision
2002/629/JHA) (OJ 2011 L101 p 1). Neither the Convention nor the Directive provides any bar to extradition. The
decision of the Competent Authority that a person has been trafficked is not in any way binding on a district judge.

**[52] A district judge, having heard the evidence, must therefore himself determine the issue as to whether the**
requested person has been trafficked, having been assisted by the Crown Prosecution Service and the UKHTC by
provision of the relevant evidence in their possession, subject to principles of public interest immunity from
disclosure. Judges should not normally adjourn hearings for a referral to the UK Competent Authority, nor defer the
effect of their extradition decisions pending a decision on a referral by the UK Competent Authority.

**[53] In the present case, therefore, the fact that the UKHTC has made the determination to which we have referred**
can make no difference. The judge has heard the evidence of Cambal and rejected it. Although the issue of his
fugitive status was a factor considered in the appeal, the findings of fact below must be respected.
**(3) Polish Judicial Authority v Krzysztof Nida**

**[54] On 11 July 2013 a conviction EAW was issued by the Military Garrison Court at Wroclaw, Poland to enforce a**
sentence of 18 months' imprisonment imposed on Nida on 13 September 2006; the sentence had been suspended
for three years but brought into effect in 2008. The sentence had been imposed on him whilst he was a conscript for
attempted street robbery of a mobile phone and a handbag on 6 July 2006 from an unnamed woman; the EAW set
out the circumstances—Nida had hit the woman in the face, pulled her clothes; he did not succeed in the robbery
because of the intervention of another person. The value of the goods he had attempted to obtain by robbery was
£53.90. He was under an obligation not to leave Poland during the three year period of the suspended sentence
which ran from the date of his conviction.

**[55] Nida's evidence was that he had pleaded guilty. The EAW stated that he had been convicted in absence; he**
had been personally notified of the hearing
**[*88]**


-----

but had failed to attend. The decision was personally served on him on 30 September 2006 notifying him of his right
to a re-trial or an appeal. He made no application for a re-trial and did not appeal.

**[56] In May 2008, Nida left Poland. On 17 July 2008, the Military Garrison Court at Wroclaw ordered the**
enforcement of the suspended sentence as Nida had committed another similar offence; that judgment became
final on 12 September 2008. On 23 November 2009, after repeated attempts to locate him, a warrant was issued in
Poland for his arrest.

**[57] In the meantime Nida was extradited to Poland in January 2012 on a different EAW in respect of an offence**
committed in 2007; after his extradition, he was imprisoned in Poland for that offence. He was asked in August
2012 if he would agree to be dealt with for the sentence imposed on 13 September 2006. He refused, as was his
right. He applied to the Polish court in November 2012 to delay the implementation of that sentence. That was
refused in March 2013. The conviction EAW was then issued. It was certified in the UK on 11 December 2013. Nida
was arrested on 8 August 2014 and has remained in custody since then.

**[58] The extradition hearing took place before District Judge Devas on 28 October 2014. Nida did not give oral**
evidence; his statement was treated as his evidence. He said in his statement that he left the army on 26 October
2006 and was under probation supervision for nine months when he was told it was over. He accepted, however, at
the extradition hearing that the information provided by the Polish Judicial Authority was correct and that he was a
fugitive from justice.

**[59] The judge gave an oral judgment. There is no transcript as HM Courts and Tribunals Service does not provide**
recording or transcription services for oral judgments for extradition decisions. This practice is far from satisfactory,
for although a note has been prepared by the advocates, it does not enable this court to see the judge's full
reasons. In a case involving art 8, this is not an acceptable practice. It is not fair to the judge, to the advocate, to the
defendant or to the requesting state to expect this court to carry out its examination of the judge's approach without
a full transcript of the judgment.

**[60] As appears from the note of the judgment, the judge held that the warrant was valid under s 2 of the 2003 Act.**
As there is no appeal on this issue, it is not necessary to refer to his reasons. As to the issue under art 8, the note
states that the judge had concluded that Nida had come nowhere near the very high factual threshold made clear in
_Norris and_ _HH. The offence was not a minor offence; suspended sentences were given in Poland for what the_
Polish courts regard as serious offences, ensuring that they strictly enforce the terms of those suspended
sentences.

**[61] Although the note does not mention his evidence in any detail, the evidence before the court was that Nida had**
obtained in the UK NVQ levels 1 and 2 and was employed as a chef. He worked with his cousin in the same
restaurant and shared shift work; he baby sat for his niece.

**[62] On behalf of Nida it was submitted by Mr Alun Jones QC that the judge was wrong. There had been an**
unexplained eight-and-a-half year delay in seeking his extradition; the offence was not a grave one; he had served
five-and-a-half months of his sentence and he had lived a blameless and positively good life in the UK.
**[*89] Our conclusion**

**[63] We consider that, as far as we can discern from the note of the judgment, the judge applied the correct**
principles, carefully weighed the pros and cons and arrived at a conclusion that was right. Although delay can be a
factor (see the judgments in HH at [46] and [91]) even when the defendant is a fugitive from justice and the offence
was not of the utmost seriousness, attempted street robbery was a serious offence. It is clear that the period of the
suspended sentence was three years; he had deliberately left Poland during its currency; he was in our view a
fugitive from justice on his original departure from Poland. There is strong public interest in upholding extradition
arrangements. On the other side of the balance sheet were his personal life as a chef working in the UK and his
participation in the life of his cousin's family. In our judgment and in agreement with the judge, the balance is
strongly in favour of extradition, given the tenuous nature of the factors against extradition.


-----

**[64] The position has, however, changed in one respect. Nida will by 7 May 2015 have spent nine months in**
custody and this will count against his sentence. Although ordinarily, even if a short time remained for a requested
person to spend in custody in Poland, he should be returned; that consideration cannot, however, apply where only
a day or two remain. We have asked for further submissions on this limited point.
**(4) Polish Judicial Authority v Ciemiega**

**[65] On 17 January 2012 a conviction EAW was issued for Ciemiega who had been convicted at the Provincial**
Court of Biala Pudlaska on 8 May 2008 for the theft of two mobile phones from a shop. He was sentenced to 12
months' imprisonment suspended for three years. On 16 March 2009, the court ordered the activation of the
suspended sentence. He served part of his sentence, but was conditionally released on 6 November 2009. The
conditional release was withdrawn on 5 April 2011, but he failed to report to prison to complete the remaining 5
months and 23 days of his sentence.

**[66] The EAW was certified in the UK on 3 September 2013. The extradition hearing took place before District**
Judge Tempia on 10 December 2014 where the sole issue was whether extradition would infringe Ciemiega's art 8
rights. The judge heard evidence from Ciemiega and his partner. In a judgment dated 19 December 2014, the judge
decided that his extradition would not be a disproportionate interference with his art 8 rights:

(i)   He left Poland knowing that he had to serve his sentence; he was a fugitive from justice.

(ii)   Although he lived with his partner and her children and helped with them, she had looked after the
children on her own before she came to the UK to join Ciemiega.

(iii)   His absence whilst serving the sentence would be short; his partner's father would be able to help
with the children.

(iv)   There was a weighty public interest in extradition.

**[67] Ciemiega appealed on the basis that the judge had failed to give sufficient weight to the responsibilities he had**
towards his step children.

**[68] The solicitors representing Ciemiega applied to come off the record, but that application was refused, as it was**
not made in good time, was not supported by proper grounds and did not confirm that there had been
**[*90]**

compliance with the orders of the court. Counsel attended the hearing, but made no submissions, having informed
the Polish Judicial Authority that no argument would be advanced on the appeal.

**[69] We have considered the judgment of the judge, the grounds of appeal and the evidence before the judge. We**
are satisfied that the judge's view on proportionality under art 8 was right and we dismiss the appeal.
**(5) R (Piotr Inglot) v Secretary of State for the Home Department and Westminster Magistrates' Court**

**[70] Inglot, a Polish National, is a resident of the Isle of Man; that island is not part of the United Kingdom for the**
purposes of membership of the EU. The request made by the Republic of Poland for his extradition from the Isle of
[Man is governed by the Extradition Act 1989: see para 5 of the Extradition Act 2003 (Commencement and Savings)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CHH0-TWPY-Y0CD-00000-00&context=1519360)
[Order 2003, SI 2003/3103. He seeks permission to challenge by way of judicial review the decision of District Judge](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-9DP0-TX08-H1NN-00000-00&context=1519360)
Evans made on 15 March 2014 and the consequent decision of the Secretary of State that he be extradited to
Poland. His application was refused by the single judge. On the renewal to this court, he no longer seeks to
challenge the decision of the Secretary of State.

**[71] He was convicted at the Wroclaw-Srodmiescie District Court, Poland on 21 January 2004 of supplying small**
amounts of cannabis in April 1997 and was sentenced to 12 months' imprisonment, suspended for two years,
subject to probation supervision. On 17 August 2005 he was found to be in breach and the sentence was activated;
he had committed another drugs related offence. He did not present himself at prison when required to do so on 27
March 2006. An arrest warrant was issued on 11 April 2007. His extradition was sought by the Republic of Poland
so that he could serve that sentence.


-----

**[72] Inglot came to the UK in 2005; he had met his wife in 2000 and they have two daughters (one born in August**
2006 and the other in July 2012); both were born on the Isle of Man. In July 2008 he was convicted in the Isle of
Man of supplying a class A drug and sentenced to five years' imprisonment.

**[73] The judge, who heard evidence from Inglot and his wife, set out a list of the 'pros' and 'cons'; in favour of**
extradition he found:

(i)   Inglot left Poland in order to avoid having to serve the sentence imposed on him, in the knowledge his
suspended sentence was about to be activated. He was a fugitive from justice.

(ii)   The importance of the UK honouring its extradition arrangements.

(iii)   The UK should not be seen as a safe haven for fugitives from justice.

(iv)   He had breached his suspended sentence by committing another offence.

(v)   He had been convicted in the Isle of Man of serious offending.

(vi)   He was not the primary carer of the children whose needs could be met by his wife during his
absence.

(vii)   He was not currently employed. His surrender would not have adverse financial consequences.

**[74] Against extradition were the following factors:**

(i)   Inglot was a family man with a wife and two children.

(ii)   His offending in Poland was nearly 17 years ago.

(iii)   His fugitive status was not fatal.

(iv)   His offending was of no great gravity.

**[*91]**

(v)   The street deals of which he was convicted would be unlikely to result in a custodial sentence for a
man then in his 20s with no previous convictions.

**[75] The judge had not found it an easy decision, particularly in the light of the age of the offending and the**
offences were not of great gravity. Nonetheless it was proportionate to order his extradition as he was a fugitive, it
would have been difficult to track him down and he committed a serious offence whilst a fugitive.

**[76] On 14 May 2014, the Secretary of State signed a surrender warrant. His grounds for applying for permission to**
bring proceedings for judicial review and his submission were that the judge's balancing exercise was flawed. The
single judge refused permission on the grounds that the judge had considered all the relevant matters and reached
a decision that was not unlawful.

**[77] It was submitted on behalf of Inglot that the judge's balancing was flawed as he had given insufficient weight to**
his family circumstances, to the delay of seven years in commencing the proceedings in Poland, to the fact that his
children would face another period of absence from their father and to the change in family circumstances. Inglot
had been employed at the time of the extradition hearing.
_Our conclusion_

**[78] We consider that the judge followed the correct principles, recorded the pros and cons in a balance sheet**
approach and reached a reasoned conclusion which was right. We can see no basis for interfering with the
decision.
**(6) Polish Judicial Authority v Pawelec**

**[79] Pawelec is sought under an accusation EAW issued by the District Court at Tarnobrzg, Poland accusing him of**
two offences of forging prescriptions on 6 and 10 July 2000 and an offence of fraud when in purporting to work for a
company, he obtained payment of 628 zloty (£109) for goods he never delivered.


-----

**[80] He was interviewed in Poland about the offences in 2004 and 2007; he claimed he signed the prescriptions on**
behalf of a treating physician when a medical student working in a hospital. As to the offence of fraud, he had
worked for the company when taking payment for the goods, but when the goods were not delivered, a refund had
been made to the customer.

**[81] He was bailed by the court in Poland, but failed to notify the prosecutor of his change of address and left for the**
UK in 2004. The EAW was issued on 24 July 2008, but it was not certified in the UK until 21 June 2014 as the UK
authorities could not identify any connections with the UK. He was arrested on 21 May 2014. He was admitted to
conditional bail on 7 July 2014.

**[82] The extradition proceedings were heard by District Judge Devas. In his judgment given on 17 November 2014,**
he found:

(i)   He was satisfied after hearing the evidence of Pawelec that he was a fugitive from justice, as he was
well aware of his obligations to notify changes of address and that he could not leave Poland. He could not
therefore rely on s 14 of the 2003 Act.

(ii)   Although extradition would interfere with his art 8 rights, the circumstances came nowhere near the
high threshold required.

(iii)   However, it was not proportionate to extradite him, applying the provisions of s 21A of the 2003 Act.
The offences fell within the table in Crim PR PD 17A. He concluded:

**[*92]**

'However I have to consider the exceptional circumstances in Pt 17A4 before deciding I must discharge. It is
possible as [the advocate for the Polish Judicial Authority] has urged, to say that there are multiple counts and
that extradition is required for more than one offence. However, in this case, bearing in mind the nature of the
offences and the likely penalty on conviction, the time spent in this jurisdiction by [Pawelec] without coming to
the attention of the authorities, and even allowing for the culpability of [Pawelec], the delay involved, with some
hesitation, I come to the conclusion that extradition would be disproportionate under s 21A(4)(b) …'

**[83] It was urged on us in turn on behalf of the Polish Judicial Authority that the judge had taken into account**
matters other than those specified in s 21A; he ought not therefore to have taken into account the passage of time
spent in the UK and his good record in the UK. The decision of this court in Miraszewski v District Court in Torun,
_Poland; Kanigowski v District Court in Torun, Poland; Fluœniak v District Court in Rzeszow, Poland [2014] EWHC_
_4261 (Admin), [2015] 1 WLR 3929had made that clear. An appellate court should apply the same standard of_
review as in art 8 cases. On behalf of Pawelec it was submitted that it was not necessary to apply the standard of
review on appeal in an art 8 case. The court should first determine whether the judge had taken into account an
immaterial matter and then decide whether the decision would have been different if that had not been done.
_Our conclusion_

**[84] The judge did not have the benefit of the decision in** _Miraszewski._ The judge was only entitled to take into
account the matters listed in s 21A(3)—the seriousness of the offence(s), the likely penalty if found guilty and the
possibility of the foreign authorities taking measures less coercive than extradition. The scope of s 21A is narrow,
but it is likely to be of substantial importance to the National Crime Agency as the certifying authority in the light of
the adherence of the UK to the Schengen Information System (second generation) ('SIS II') which took effect on 13
April 2015; SIS II provides in real time alerts in respect of EAWs (and other law enforcement orders) to authorities
(including border agencies) in other member states. In the light of difficulties in securing the application of
proportionality to the issue of an EAW in some member states, the terms of s 21A, even though narrow, should be
of real assistance.

**[85] However, the judge took into account matters outside the scope of s 21A, particularly delay, as relevant for**
reasons other than the matters set out in s 21A(3). The offences were not trivial—forging a doctor's signature is a
serious matter. There was no evidence before the judge as to the likely penalty, but the offences were punishable
by five and eight years respectively. There was no evidence from the defendant that less coercive measures might
be taken.


-----

**[86] The matter must be remitted in accordance with the provisions of s 29 of the 2003 Act with a direction under s**
29(5)(C).

Orders accordingly.

Karina Weller Solicitor (NSW) (non-practising).

**End of Document**


-----

