# R v AGM [2022] All ER (D) 23 (Jul)

[2022] EWCA Crim 920

Court of Appeal, Criminal Division

EnglandandWales

Males LJ, McGowan J and Judge Michael Chambers QC (Recorder of Wolverhampton)

5 July 2022

**CONVICTION – PRODUCTION OF CANNABIS – APPEAL AGAINST CONVICTION**
Abstract

_The Court of Appeal, Criminal Division, allowed the defendant's appeal and her conviction was quashed. The_
_defendant pleaded guilty to being concerned in the production of cannabis. She was sentenced to 18 months'_
_imprisonment. The ground of appeal was that the applicant's conviction on her own plea was unsafe because, if it_
_had been known that she was a victim of trafficking, either she would not have been prosecuted or the proceedings,_
_which took place before the passing of the_ **_[Modern Slavery Act 2015,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_** _would have been stayed as an abuse of_
_process. The court held, among other things, that the defendant was more likely than not to be a victim of_
_trafficking. However, there was not a direct causal nexus between the fact that she had previously been a victim of_
_slavery and exploitation and the commission of the offence. Therefore, the defence under s 45 of the Act was not_
_available. Turning to the abuse of process argument, the court concluded that whether it would have been in the_
_public interest to prosecute the defendant for that particular offence if the full circumstances had been known was_
_inevitably a fact sensitive question. On the facts, the court decided that it would or might well have been concluded_
_that prosecution was not in the public interest. Therefore, the defendant's conviction was unsafe._
Digest

The judgment is available at: [2022] EWCA Crim 920

**Background**

The defendant, a Vietnamese national then aged 40, pleaded guilty to being concerned in the production of
cannabis. She was sentenced to 18 months' imprisonment. Her application for an extension of time (2,514 days) in
which to seek leave to appeal against conviction and for leave to call fresh evidence was referred to the full court by
the Registrar of Criminal Appeals.

**Issues and decisions**

(1) Whether the court should grant the application for an extension of time in which to appeal.

Consideration was given to a conclusive grounds decision, dated 3 September 2018, in which the Home Office, as
the competent authority under the 2005 Council of Europe Convention on Action against Trafficking, had
determined that the defendant had been a victim of modern slavery. It appeared that she had not claimed to be a
victim of trafficking during the criminal proceedings and that that question had not been referred to the Home Office
for consideration until later.


-----

The court was prepared to grant the necessary extension of time, despite the length of time involved. It was
understandable that the present application could not have been made until after the positive conclusive grounds
decision made in September 2018, at which time immigration and asylum proceedings had still been continuing.
The defendant's current solicitors had not been instructed until May 2020, after which there had been much work to
be done and matters had proceeded with reasonable dispatch, but it was not altogether apparent why the present
application could not have been made earlier. Nevertheless, having regard to the issues involved, it was in the
interests of justice to grant the necessary extension of time (see [41] of the judgment).

(2) Whether the defendant should be allowed to adduce fresh evidence (see [42] of the judgment).

[The criteria for the admission of new evidence on appeal were set out in s 23 of the Criminal Appeal Act 1968 (CAA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1KR-00000-00&context=1519360)
_[1968). The test was whether it was necessary or expedient in the interests of justice to receive such evidence. In](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1P8-00000-00&context=1519360)_
considering that evidence, it was necessary to have regard to whether: (i) the evidence appeared to be capable of
belief; (ii) it appeared that it might afford any ground for allowing the appeal; (iii) it would have been admissible in
the proceedings below; and (iv) there was a reasonable explanation for the failure to adduce the evidence below. In
the context of trafficking cases, it was established that a conclusive grounds decision was admissible on appeal
(always assuming that it was necessary or expedient to receive such evidence), notwithstanding that such a
decision would not be admissible at trial. In some cases, the account given by an appellant might require testing by
way of appropriate questioning (see [43]-[45] of the judgment).

In the present case, it was necessary to admit the new evidence. Understandably, the prosecution had not sought
to cross examine the defendant on the account given in her latest statements. The prosecution did not necessarily
accept all of what was said, but broadly speaking, the statements appeared to be capable of belief. They told a
story which, although horrifying, was sadly all too familiar (see [46] of the judgment).

_R v Brecani_ _[[2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62R7-7X53-GXFD-802D-00000-00&context=1519360)_

_R v AAJ_ _[[2021] EWCA Crim 1278 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_

_R v AAD and others_ _[[2022] EWCA Crim 106 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_

(3) Whether the defendant's conviction, on her own plea, was unsafe because, if it had been known that she had
been a victim of trafficking, either she would not have been prosecuted or the proceedings (which had taken place
[before the passing of the Modern Slavery Act 2015 (MSA 2015)) would have been stayed as an abuse of process.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

_[MSA 2015 s 45 came into force with effect from 31 July 2015. It provided a substantive defence for victims of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_
slavery or trafficking who committed certain offences under compulsion attributable to slavery or relevant
exploitation. Before the coming into force of that section, the UK had sought to comply with its obligations under the
Convention in cases where the common law defence of duress was not available by a combination of: (i) Crown
Prosecution Service guidance as to the circumstances in which victims of trafficking should be prosecuted; and (ii)
the court's power to stay a prosecution as an abuse of process. It was settled law that, under s 45, it was not
enough that a defendant was a victim of trafficking. It had also to be shown (or more accurately, an issue had to be
raised, which it was then for the prosecution to disprove that an adult defendant had been compelled to do the act
which constituted the offence and that that compulsion had been attributable to (i.e. directly caused by) slavery or
relevant exploitation. That was in part the result of interpreting the statutory language, which expressly referred to
compulsion, but was also held to coincide with the UK's international obligations under (among other things) the
2005 Convention. Consistently with that view, CPS guidance and the pre-Act cases referred to the need for
'compulsion arising from the trafficking' and for 'a nexus of compulsion' (see [5], [6] of the judgment).

When dealing with victims of trafficking, the existence and extent of any nexus between the offence in question and
the trafficking and exploitation to which the defendant had been subject would always be an important
consideration. However, if the prosecution authorities had applied their minds to the relevant questions in
accordance with the applicable CPS guidance, it would not, generally, be an abuse of process to prosecute, unless
the decision to do so was clearly flawed. The courts would be reluctant to intervene in such circumstances as the


-----

decision whether to prosecute was for the CPS, and not the court. Conversely, if the question whether a defendant
was a victim of trafficking had not been considered by the prosecution at all, the courts would be readier to
intervene. Again, the existence and extent of any nexus between the offence and the trafficking and exploitation in
question would be an important consideration, albeit not necessarily decisive in every case. Depending on the facts,
it might be necessary to consider broader questions, such as whether it was in the public interest to prosecute that
particular defendant for that particular crime. Much might depend on the circumstances and history of the defendant
and the seriousness of the defendant's participation in the crime in question. It was, therefore, possible to envisage
[circumstances where an abuse of process argument in a pre-MSA 2015 case might succeed even though, if MSA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
_[2015 had applied, a defence under s 45 would have failed for insufficient evidence of compulsion directly caused by](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
slavery or exploitation, as required by the section. Authority expressly recognised the continuing existence of the
abuse of process jurisdiction even in a case to which s 45 applied. That the prosecution was an abuse of process
was one of the categories of case in which it was no bar to a successful appeal that the defendant had pleaded
guilty (see [9]-[15] of the judgment).

The CPS Guidance on human trafficking, smuggling and slavery as at 9 September 2011 drew attention to the
frequency of trafficking in (among other cases) cultivation of cannabis plants. If evidence or information obtained
supported the fact that the suspect had been trafficked and committed the offence while they were coerced,
prosecutors were instructed to consider whether it was in the public interest to continue prosecution. The guidance
emphasised the duty of the prosecutor to be proactive in causing enquiries to be made (see [16] of the judgment).

Having considered the applicant's evidence, and following the approach described, and approved, in the authorities,
the defendant was more likely than not to have been a victim of trafficking. That, however, was only the first step.

(see [50] of the judgment).

It remained to be considered whether, or to what extent, the defendant had been acting under compulsion when
she had carried out the conduct which constituted the offence of being concerned in the production of cannabis
and, if so, whether there had been a sufficient nexus between that conduct and the slavery or exploitation to which
she had been subjected (see [51] of the judgment).

[Considering the evidence before the court, as a whole, if MSA 2015 had applied, the defendant would have been](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
unable to make good (or strictly, the prosecution would have been able to disprove) any defence under s 45. On the
facts of the case, that defence would not have been available unless the defendant had been acting under
compulsion which had been (in the terms of sub-s (3)(b)) 'a direct consequence' of having been a victim of slavery
or relevant exploitation. That had not been the position in the present case. It appeared that the defendant had
been tricked and exploited by her boyfriend, but there had not been a direct causal nexus between the fact that she
[had previously been a victim of slavery and exploitation and the commission of the offence. The fact that MSA 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
would not have afforded the defendant a defence was not necessarily critical, because it did not apply. However, it
was a relevant consideration when applying the criteria for an abuse of process argument (see [52]-[54] of the
judgment).

_R v O_ _[[2008] EWCA Crim 2835, [2008] All ER (D) 07 (Sep) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P3GR-00000-00&context=1519360)_

_R v L_ _[[2013] EWCA Crim 991, [2014] 1 All ER 113, [2014] 3 LRC 1, [2013] All ER (D) 216 (Jun) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_

_R v Joseph_ _[[2017] EWCA Crim 36, [2017] 1 WLR 3153, [2017] All ER (D) 100 (Feb) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_

_R v L (2017)_ _[[2017] EWCA Crim 2129 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_

_R v MK (also known as D); R v Gega (also known as Maione)_ _[[2018] EWCA Crim 667, [2019] QB 86, [2018] 3 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SWS-B301-DYBP-M1GG-00000-00&context=1519360)_
_[ER 566, [2018] 3 WLR 895, [2018] All ER (D) 10 (Apr) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SWS-B301-DYBP-M1GG-00000-00&context=1519360)_

_R v GS_ _[[2018] EWCA Crim 1824, [2018] 4 WLR 167, [2018] All ER (D) 90 (Aug) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_


-----

_R v AAD and others_ _[[2022] EWCA Crim 106 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_

(4) Whether prosecution of the defendant would be in the public interest or an abuse of process.

There was no 'blanket immunity' for victims of trafficking. Rather, there was an obligation on the prosecuting
authority to apply its mind conscientiously to 'the question whether public policy called for a prosecution and
punishment when the defendant was a trafficked victim and the crime had been committed when he or she was in
some manner compelled (in the broad sense) to commit it'. In accordance with well established principles, there
might be cases where it was not in the public interest for a prosecution to take place even where the evidence
against the defendant was strong, so that there would be good prospects of securing a conviction; and those
principles might apply in trafficking cases (see [7], [8] of the judgment).

In the present case, the question whether it would have been in the public interest to prosecute the defendant if
what was currently known had been known at the time had to be approached on the basis that, if the defendant
were to be prosecuted, she would, in all probability, be convicted as her offending was not directly attributable to
her previous abuse, albeit that (as the judge had found) she had been subject to 'some degree of pressure' when
looking after the cannabis plants (see [55] of the judgment).

It appeared that the question whether the defendant had been a victim of trafficking and, if so, how that had
affected the further question whether it was in the public interest to prosecute her for the present offence, had not
been not considered. If it had been considered at all, there had been no referral to the Home Office under the
national referral mechanism and any consideration had been without the benefit of what was currently known about
the defendant's history, the abuse to which she had been subjected and the effect which it had had on her.
Accordingly, it was open to the present court to consider the public interest question without trespassing on ground
which had appropriately been considered by the prosecution authorities (see [56] of the judgment).

Even though the defendant's position as a victim of trafficking, including the sexual slavery and physical violence to
which she had been subjected over a period of years, would not have afforded her a substantive defence, it was a
highly relevant consideration. She was a woman who had been subjected to horrific abuse over a period of years,
who had been severely traumatised by her experiences, and who was suffering from PTSD and Major Depressive
Disorder. Inevitably, she had been extremely vulnerable to further exploitation and that vulnerability had been
exploited. She spoke no English and she had, therefore, been isolated, with limited if any realistic options for
seeking help. Her family was still vulnerable to the threats of their creditors in Vietnam and her debts had not gone
away. In those circumstances, if the question of compulsion was considered 'in the broad sense', the conclusion
that there was 'a reasonable nexus' between the crime and the trafficking was almost inevitable. That went a
considerable way to diminish, if not to extinguish, the defendant's culpability (see [7], [9], [57] of the judgment).

The offence, being concerned in the production of cannabis, was a serious matter and it had been production on a
large scale, but the defendant had played only a limited role, and for a short time. She had no previous convictions
and there was no evidence of any previous unlawful activity (see [58] of the judgment).

Whether it would have been in the public interest to prosecute the defendant for the present particular offence if the
full circumstances had been known was inevitably a fact sensitive question. It needed to be approached 'with the
greatest sensitivity'. On the facts, it would, or might well, have been concluded that prosecution was not in the
public interest (see [59] of the judgment).

Accordingly, applying settled principles, the defendant's conviction was unsafe. Leave to appeal would be granted,
the appeal would be allowed and the conviction would be quashed (see [60] of the judgment).

_R v LM_ _[[2010] EWCA Crim 2327, [2010] All ER (D) 202 (Oct) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_

_R v N; R v E_ _[[2012] EWCA Crim 189, [2012] 3 WLR 1159, [2012] All ER (D) 128 (Feb) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5513-TB01-DYBP-N1F7-00000-00&context=1519360)_

_R v T_ _[[2022] EWCA Crim 108, [2022] 4 WLR 62 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_


-----

Benjamin Newton (instructed by Birds Solicitors) for the defendant.

Andrew Johnson (instructed by the Crown Prosecution Service) for the Crown.
Carla Dougan-Bacchus Barrister.

**End of Document**


-----

