# R (on the application of JB (Ghana)) v Secretary of State for the Home
 Department

## [2022] EWCA Civ 1392, [2022] All ER (D) 73 (Oct)

 Court: Court of Appeal, Civil Division Judgment Date: 25/10/2022

# Catchwords & Digest

## IMMIGRATION - FINANCIAL SUPPORT – CLAIMANT BOTH AN ASYLUM SEEKER AND A VICTIM OF MODERN SLAVERY

 The Court of Appeal, Civil Division, dismissed the Secretary of State’s appeal against the Administrative Court’s decision that, as both an asylum seeker and a victim of modern slavery, the respondent had been entitled to £65 per week, pursuant to para 15.37 of a Home Office document entitled ‘Modern Slavery Act 2015 – Statutory Guidance for England and Wales’ (the MSAG), regardless of the fact that during the period in question he had also been provided with temporary support under s 95 of the Immigration and Asylum Act 1999 and temporary asylum accommodation on a full board basis. The court held that para 15.37 of the MSAG had categorically set out the above conclusion and had made no distinction between self-catered and catered accommodation, nor had it said anything about any offset for the value of meals which had bee provided by the latter. It was not clear that, as submitted by the defendant, the drafter of para 15.37 had made an ‘obvious error’ in that they had not intended for someone in the claimant’s position to receive a top-up to bring his total payments to £65. The court’s construction of para 15.37 of the MSGA was consistent with the terms of the Victim Care Contract, between the Home Office and the Salvation Army, and the answers given in a ‘Frequently Asked Questions’ document which had been sent by the Home Office to the Salvation Army.

# Case History


R (on the application of JB (Ghana)) v Secretary of State for the Home Department

_[[2022] EWCA Civ 1392, [2022] All ER (D) 73 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66PS-0Y43-CGX8-037G-00000-00&context=1519360)_
—

R (on the application of JB) v Secretary of State for the Home Department

_[[2021] EWHC 3417 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64B0-MGX3-GXF6-83VK-00000-00&context=1519360)_
Affirming


25/10/2022

CACivD

17/12/2021

AdminCt


-----

# Cases referring to this case

R (on the application of Care North East) v Northumberland County Council

_[[2024] EWHC 1370 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6C69-TFB3-RRSM-V1CP-00000-00&context=1519360)_
Considered

R (on the application of Medical Justice) v Secretary of State for the Home Department

_[[2024] EWHC 38 (Admin), [2024] All ER (D) 54 (Jan)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6B48-FJK3-RS1B-F495-00000-00&context=1519360)_
Applied

R (on the application of PM) v Secretary of State for the Home Department

_[[2023] EWHC 1551 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68HW-W0W3-RRMB-313B-00000-00&context=1519360)_
Applied

R (on the application of Kaur (acting by her litigation friend)) v Adjudicator's Office and
another

_[[2023] EWHC 1052 (Admin), [2023] 1 WLR 3855, [2023] All ER (D) 67 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6888-2G53-RRNV-9004-00000-00&context=1519360)_
Considered

# Cases considered by this case

MD and another v Secretary of State for the Home Department

_[[2022] EWCA Civ 336, [2022] PTSR 1182, [2022] All ER (D) 71 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-HXX3-CGX8-004D-00000-00&context=1519360)_
Distinguished

JM v Secretary of State for the Home Department

_[[2021] EWHC 2514 (Admin), [2022] PTSR 260, [2021] All ER (D) 59 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63WD-VJP3-GXF6-8443-00000-00&context=1519360)_
Considered

R (on the application of K and another) v Secretary of State for the Home Department

_[[2018] EWHC 2951 (Admin), [2019] 4 WLR 92, [2018] All ER (D) 50 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TPV-5BX1-DYBP-N303-00000-00&context=1519360)_
Considered

R (on the application of EM) v Secretary of State for the Home Department

_[[2018] EWCA Civ 1070, [2018] 1 WLR 4386, [2018] All ER (D) 113 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SCR-C3C1-DYBP-N2GW-00000-00&context=1519360)_
Considered

R (on the application of JK) v Secretary of State for the Home Department

_[[2017] EWCA Civ 433, [2017] 1 WLR 4567, [2017] All ER (D) 166 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NX0-TXV1-DYBP-N12H-00000-00&context=1519360)_
Considered

R (on the application of Ghulam and others) v Secretary of State for the Home
Department

_[[2016] EWHC 2639 (Admin), [2016] All ER (D) 06 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2T-YN91-DYBP-N3B8-00000-00&context=1519360)_
Considered

Tesco Stores Ltd v Dundee City Council

_[2012] UKSC 13, [2012] PTSR 983, [2012] 13 EG 91, 2012 SC (UKSC) 278, 2012 SLT_
[739, [2012] All ER (D) 163 (Mar), 2012 Scot (D) 17/3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:557G-YC61-DYBP-N3CC-00000-00&context=1519360)
Applied


06/06/2024

AdminCt

12/01/2024

AdminCt

23/06/2023

AdminCt

05/05/2023

AdminCt

16/03/2022

CACivD

04/10/2021

AdminCt

08/11/2018

AdminCt

15/05/2018

CACivD

22/06/2017

CACivD

24/10/2016

AdminCt

21/03/2012

SC


Mahad (previously referred to as AM) (Ethiopia) v Entry Clearance Officer 16/12/2009


-----

_[[2009] UKSC 16, [2010] 2 All ER 535, [2010] 1 WLR 48, [2010] INLR 268, (2009)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YF1-VH60-Y96Y-G05J-00000-00&context=1519360)_
[Times, 21 December, [2009] All ER (D) 156 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XB5-CNX0-Y96Y-H145-00000-00&context=1519360)
Applied

Odelola v Secretary of State for the Home Department

_[[2009] UKHL 25, [2009] 3 All ER 1061, [2009] 1 WLR 1230, [2009] INLR 401, (2009)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7WJ6-3MX0-Y96Y-G09X-00000-00&context=1519360)_
[Times, 22 May, [2009] All ER (D) 180 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7VRJ-B1D0-Y96Y-H1V3-00000-00&context=1519360)
Considered

R (on the application of Raissi) v Secretary of State for the Home Department

_[[2008] EWCA Civ 72, [2008] QB 836, [2008] 2 All ER 1023, [2008] 3 WLR 375, (2008)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SN8-84C0-TWP1-61HP-00000-00&context=1519360)_
[Times, 22 February, [2008] All ER (D) 215 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4RV7-5VJ0-TWP1-70Y4-00000-00&context=1519360)
Applied

McFarland, Re

_[[2004] UKHL 17, [2004] NI 380, [2004] 1 WLR 1289, (2004) Times, 30 April, [2004] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4GNK-H680-TWYV-M1BP-00000-00&context=1519360)_
_[ER (D) 329 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N1CR-00000-00&context=1519360)_
Considered

Inco Europe Ltd v First Choice Distribution (a firm)

_[[2000] 2 All ER 109, [2000] 1 WLR 586, [2000] 1 All ER (Comm) 674, 74 ConLR 55,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-6089-00000-00&context=1519360)_
[(2000) Times, 10 March, [2000] Lexis Citation 2604, [2000] All ER (D) 305](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG81-DYBP-P3YX-00000-00&context=1519360)
Distinguished

**End of Document**


SC

20/05/2009

HL

14/02/2008

CACivD

29/04/2004

HL

09/03/2000

HL


-----

