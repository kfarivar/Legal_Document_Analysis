# R v GS [2018] EWCA Crim 1824

CA, CRIMINAL DIVISION

201703514 C2

LORD JUSTICE GROSS

31 July 2018

31/07/2018

REPORTING RESTRICTIONS APPLY

LORD JUSTICE GROSS : INTRODUCTION

1. Huge strides have been made, domestically and internationally, in recognising the evil of human trafficking, in
protecting victims of trafficking (“VOTs”) and, where appropriate, shielding VOTs from prosecution or penalties.
However, as repeatedly made clear, where crimes have been committed by VOTs, even arising from their own
trafficking, there is no blanket immunity. Decisions are necessarily fact sensitive, taking into account the public
interest both in prosecuting alleged offenders and in protecting VOTs. The present application gives rise to such
considerations, made somewhat more complex by (put neutrally for the moment) material developments in the law
and practice since the time of the original trial and the very lengthy Extension of Time (“EOT”) sought.

2. On 30[th] November, 2007, in the Crown Court at Isleworth, before HHJ Colgan, the Applicant was convicted of
Being Knowingly Concerned in the Fraudulent Evasion of the Prohibition on the Importation of a Controlled Drug of
Class A (Cocaine).

3. On the same date, the Applicant was sentenced to seven years imprisonment and recommended for
deportation.

4. The Applicant's application for an EOT of approximately 9 years and 7 months, for leave to appeal conviction
and to rely on fresh evidence, pursuant to s.23 of the Criminal Appeal Act 1968 (“the 1968 Act”), has been referred
to the Court by the Single Judge.

5. The Applicant, through Mr Fitzgibbon QC has sought anonymity for these proceedings and Mr Douglas-Jones
QC for the Crown (“the Respondent”) does not oppose it. We have considered this matter anxiously and echo the
concerns expressed in _R v L; R v N_ _[[2017] EWCA Crim 2129, at [9] and following, with regard to anonymity in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
criminal proceedings. No media representatives were present at the hearing, so we did not have the benefit of any
representations from the media. However, given the extent of our consideration of the matter, we are satisfied that
no point was missed which might have been raised on behalf of the media. Insofar as the application for anonymity
was based on poor mental health and low cognitive function, we would have refused it. That said, there were other
particular features of the case which, we are persuaded, renders an anonymity order strictly necessary.
Accordingly, we grant the application for anonymity, while underlining that any such application should always be
closely scrutinised and should not be granted unless strictly necessary.

6. As to the EOT application, the matter did not progress until the Applicant instructed fresh representatives in late
2015. It is said on her behalf that she was not in a position to have identified the possibility of an appeal without
such assistance It was first formally acknowledged that the Applicant had been trafficked in a decision of the First


-----

Tier Tribunal (“FTT”) in August 2015. Thereafter time was taken obtaining documents, including a delay attributable
to the Home Office, counsel was instructed and Grounds were ultimately settled in June 2017 and the appeal
lodged soon thereafter.

7. It may be noted that one of the consequences of the age of the case is that no transcripts are available.

THE FACTS

8. _(1) The facts of the offence:_ In short summary as to the facts of the offence, the Applicant was a Jamaican
national. On 9[th] February, 2007, she arrived at London Heathrow airport (“LHR”) on a flight from Trinidad. She was
travelling using a British passport in a false name. She was stopped by Customs Officers. She informed them that
she was a student, resident in the United Kingdom (“UK”) and that she had been away for a week. She told the
officers that she had packed her own bag and denied that she was carrying anything for anyone else. She
consented to being x-rayed.

9. The x-ray revealed that she had foreign objects inside her body. She was arrested. A second x-ray and a
medical examination confirmed the findings. In due course, 23 packages were recovered from her; 22 of those
packages contained cocaine with a gross weight of 253 grams (221 grams at 100% purity). The drugs had a streetlevel value of £37,578.40.

10. A forensic medical examiner saw the Applicant in custody and noted cuts to her left forearm, which she said
she had inflicted with a plastic knife. She told him that she was HIV positive and had a child aged seven. She was
tearful throughout the examination. The doctor concluded that she was depressed but not suicidal.

11. Examination of the Applicant's mobile phone showed that she had received a missed call from a number
thought to belong to a man to whom we shall refer as B.

12. Another person intercepted importing drugs alleged that the offence had been committed as a result of threats
being made. B was believed to have made those threats and was also believed to have access to firearms and the
capacity to use them. Law enforcement agencies had information as to B's identity.

13. The Applicant's medical records showed that she had attended her GP, both with a complaint of assault
resulting in an injury to her left ear and, on a separate occasion, after having been involved in a road traffic accident
(“RTA”).

14. In interview, the Applicant made no comment in answer to the questions put to her.

15. In the absence of transcripts, it is surmised that the Prosecution case was that the Applicant had been found in
possession of drugs she had smuggled into the country and the jury could be sure that she was not acting under
duress.

16. The Defence case was that at all relevant times the Applicant was acting under duress, involving the threat of
serious injury or death to her and/or her young son, in the event that she had refused to comply with the demand
from another that she smuggle drugs.

17. As is apparent, the Applicant's defence of duress was rejected by the jury and she was convicted.

18. (2) The Applicant's evidence at trial: In a little more detail, the Applicant's evidence was to this effect. At the
time of the trial, she was 29. She first came to the UK to attend a nursing course which she did not complete. She
worked in a hotel. Her son was born in August 2000 and had come to the UK with his paternal grandmother with
whom he lived. His father (“G”) lived in Miami.

19. The Applicant had lived with her cousin (“W”) in Birmingham for a period of about 4 months. W's partner was a
Jamaican man, to whom we have already referred as B. Her cousin, B and B's brother (“D”) were all involved in
drug dealing. She alleged that D had assaulted her in 2003, after accusing her of informing on his (D's) girlfriend
for using a cloned credit card.


-----

20. In December 2004, W was arrested. B blamed the Applicant for W's arrest and claimed that she owed him
money. He told her she had to go to the Bahamas and obtained a false passport for her to do so – in the event, the
same false passport that she used on her 2007 flight to the UK from Trinidad when she was arrested. B purchased
a flight ticket for the Applicant and she travelled to the Bahamas with a female associate of B (“L”). B told her that
she had to bring back drugs hidden in bags of coffee. The Applicant, however, used her own money to escape,
with L, from the Bahamas to Miami, where she had an uncle. She stayed in Miami until December 2006, at which
point she said that she had to return to the UK for medical treatment for HIV, which she could not obtain in the USA.

21. In the event and subsequent to her return, she encountered B and one of his associates in Birmingham city
centre. He told her to walk with him and that she could not go anywhere because he knew where her son lived.
She was taken to a house overnight and kept under constant observation. A ticket to Trinidad was purchased for a
flight leaving the next day. She claimed that she saw B had a firearm and believed what he had said about her
son's life being in danger.

22. The next day she was taken to LHR. Both B and an associate (“F”) travelled on the flight with her. On arrival in
Trinidad, she was taken to a house where she was again kept under observation. She was ordered to swallow a
large number of drugs packages. She could not manage to swallow them all and so placed one inside her vagina
and one under her breast. F travelled back to the UK with her. She was due to be collected by another of B's
associates at LHR but was arrested on arrival.

23. _(3) Events post-conviction:_ According to submissions made on the Applicant's behalf in subsequent
immigration proceedings following her conviction, she gave assistance to the police as a result of which four other
people were prosecuted for drug importation offences, of whom two were convicted. It was an agreed fact at that
trial that B was behind the use of three British girls to import cocaine from the Bahamas, hidden in bags of coffee.

24. Following her release from prison in August 2010, the Applicant applied for asylum in the UK in October 2010.
The Secretary of State (“the SSHD”) refused the application but later withdrew the decision. On 7[th] February, 2014,
the SSHD made a second refusal decision, which the Applicant appealed. The basis of the appeal was that when
she entered the UK in February 2007, she was being trafficked by B and his associates – and that if she was
returned to Jamaica her life would be at risk from them. She relied upon the reports of two expert psychologists, Dr.
Egnal and Ms Robertson.

25. On the 3[rd] August, 2015, the First Tier Tribunal (“the FTT”) allowed her appeal against the decision of the
SSHD refusing her claim for asylum. The FTT made a finding of fact that the Applicant had been trafficked on the
occasion when she entered the UK carrying the drugs.

26. Following a referral by the Salvation Army, on 16[th] September, 2015, the Competent Authority (“the CA”)
decided that, on the balance of probabilities, the Applicant was a VOT for the purposes of forced criminality. It was
decided that she did not require Discretionary Leave to Remain, as she had already been granted asylum. The
Applicant was informed of this decision by way of a letter from the Home Office, dated 17[th] December, 2015.

27. (4) The recollections of trial counsel: In accordance with the procedure laid down by R v McCook _[[2014] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C0P-34W1-F0JY-C187-00000-00&context=1519360)_
_[Crim 734, trial counsel was approached for her recollections of the matter. I would pay tribute to the very measured](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C0P-34W1-F0JY-C187-00000-00&context=1519360)_
and balanced response in her letter to the Registrar, dated 3[rd] October, 2017, despite the understandable loss of
her trial notes. Counsel remembered the Applicant wishing to advance the defence of duress but there being an
issue between the Applicant and the prosecution as to whether the Applicant had lied as to having a son. Details
were sought from the Applicant with a view to tracing her son. As counsel put it, the Applicant:

“…did not display…the distress that one might expect to see from a mother who had concerns about her son's
welfare, she was nonetheless insistent that he existed and had been threatened.”

Details were supplied but the son could not be traced.

28. Counsel further observed that the Applicant at no point disclosed that she was a victim of trafficking – and
indeed we would not have expected her to refer to herself in that way - though she did maintain that she had been


-----

forced to carry the drugs into the UK. During the Applicant's evidence at trial, Counsel had “struggled to adduce
from her that she [had] feared for her and her son's life.

THE APPLICATION TO ADDUCE FRESH EVIDENCE

29. Integral to the Applicant's case before this Court is an application for the introduction of fresh evidence (“the
fresh evidence application”). The fresh evidence application falls into two parts:

i) The first part (“the first part”) goes to the conclusion that the Applicant was a VOT and contains the Decision and
Reasons of the FTT, dated 3[rd] August, 2015 (“the FTT Decision”), the Conclusive Grounds Consideration Minute of
the CA, undated (“the CA Minute”) and the Home Office letter dated 17[th] December, 2015 (“the Home Office letter”).

ii) The second part goes to the Applicant's mental state and is comprised of a Report by Dr Egnal, a Consultant
Clinical Psychologist, dated 5 December, 2014, a Report by Ms Mary Robertson, a Chartered and Consultant
Clinical Psychologist, dated 5[th] June, 2015, a letter from Dr Egnal, dated 9[th] July, 2016, an email from Ms
Robertson, dated 22[nd] July, 2016 and, finally, letters from Ms Robertson and Dr Egnal, dated 27[th] October, 2017
and 31[st] October, 2017 respectively (collectively, “the medical evidence”).

30. The well-known test for the admissibility of fresh evidence is contained in s.23 of the 1968 Act and provides (so
far as material) as follows:

“(1) For the purposes of an appeal, or an application for leave to appeal, under this Part of this Act the Court of
Appeal may, if they think it necessary or expedient in the interests of justice –

(c) receive any evidence which was not adduced in the proceedings from which the appeal lies.

(2) The Court of Appeal shall, in considering whether to receive any evidence, have regard in particular to –

(a) whether the evidence appears to the Court to be capable of belief;

(b) whether it appears to the Court that the evidence may afford any ground for allowing the appeal;

(c) whether the evidence would have been admissible in the proceedings from which the appeal lies on an issue
which is the subject of the appeal; and

(d) whether there is a reasonable explanation for the failure to adduce the evidence in those proceedings.”

31. (1) The first part: It is convenient at this point, de bene esse, to summarise, briefly, the fresh evidence sought to
be adduced by the Applicant, beginning with the materials leading to the conclusion that the Applicant was a VOT.

32. _The FTT Decision:_ Before the FTT, the Applicant appealed against the refusal by the SSHD to grant her
asylum. She claimed to be a refugee, alternatively that she was entitled to humanitarian protection and also
contended that her removal from this country would be in breach of the UK's Human Rights' obligations under the
Convention (“the ECHR”). The Applicant claimed that she was a VOT. It may be noted that, by agreement, the
Applicant did not give her evidence orally, for medical reasons and the FTT Judge treated her as a vulnerable
witness.

33. The Applicant's evidence to the FTT (in 2015) was broadly similar to that given by her at trial (in 2007) and
included that she had been raped by a Jamaican gang member in 2003, had an abortion and was diagnosed with
HIV later that year – though she did not know how she had contracted it.  She recounted her travel to Bahamas,
escape to Miami and subsequent return to the UK. More detail was set out of the assistance she had given to the
police in respect of other proceedings. She learnt, it would seem while in prison, that G had been shot dead in
Jamaica in 2008. Other prisoners said that this was because she had been a “grass”. She believed that either she
or her son would be killed if she returned to Jamaica. Her son had been living with G's mother, in the USA, from
2007.  In 2013, the Applicant had been charged with a further drugs offence but was found not guilty at trial.


-----

34. In support of her case to the FTT, the Applicant introduced the Reports of Dr Egnal and Ms Robertson, forming
part of the medical evidence, as already described.

35. The Applicant's claims were opposed by the SSHD, though it is not readily apparent what materials were relied
upon in support of the SSHD's case.

36. On the basis of the materials before him, the FTT Judge, held that the Applicant had discharged the burden of
proof to establish that she was entitled to the grant of asylum. She was, accordingly, a refugee and therefore was
not entitled to Humanitarian Protection. Furthermore, the Judge allowed the Applicant's appeal under Art. 3, ECHR.

37. The kernel of the Judge's reasoning appears from the following paragraphs of his judgment:

“80. …..I am satisfied that this vulnerable appellant was at risk from gang members, who used and exploited her for
their advantage including the forced use of her as a drugs mule. I therefore am satisfied that she is a victim of
trafficking. Whilst she was convicted of a serious criminal offence…..she is someone who in my view, based on the
medical evidence, would have found it impossible to resist the pressure and coercion of gang members with whom
she became involved.

81. I further accept and acknowledge that she provided information to prosecution authorities in the UK….. Such
actions would place her at risk of reprisals from gang members whom she said, and I accept, fled to Jamaica to
evade justice. ”

38. The CA Minute: The CA Minute, though undated, plainly comes after the FTT Decision.  The Minute records
that the information assessed in coming to its Conclusive Grounds Decision was comprised of (1) the National
Referral Mechanism (“NRM”) form completed by the Salvation Army, dated 10[th] September, 2015; (2) Documents
contained within the Potential Victim's (“PV's”) Home Office files; (3) Information from Home Office Databases; (4)
the FTT Decision.  It is readily apparent that the narrative closely follows the FTT Decision.

39. The essence of the decision embodied in the CA Minute is to be found in the opening, summary, paragraph:

“ ….the Competent Authority has concluded that on the 'balance of probabilities' the PV has been trafficked and is,
therefore, a victim of trafficking as per the Council of Europe.

Additionally, the Competent Authority has concluded that on the 'balance of probabilities' the PV is a victim of
slavery, servitude and forced/compulsory labour as per the Competent Authority guidance….”

40. As the Applicant had been granted asylum, she did not require a period of Discretionary Leave.

41. _The Home Office Letter: This document recorded and summarised the conclusion in the CA Minute._
Discretionary Leave was not required, given that the Applicant had been granted asylum.

42. (2) The medical evidence: In his 2014 Report, Dr Egnal spoke of the Applicant as appearing to be “moderately
depressed” occasioned by “her experiences in the UK, rape, contracting HIV and having to have a termination of
pregnancy as well as the circumstances which led to her imprisonment and the death of the father of her son in
Jamaica”.  Dr Egnal recorded that the Applicant had two head injuries, one in the USA in 1999, following a Road
Traffic Accident (“RTA”) and one in the UK in 2006, when she was hit on the head with a brick. Pausing there,
given the time spent by the Applicant in Miami after fleeing from the Bahamas, it is not entirely clear where or when
this second injury was sustained – but there was no dispute before us that she had suffered such an injury. In Dr
Egnal's opinion, the Applicant displayed “an intellectual and cognitive decline” following these incidents. He went
on to say that the Applicant's “vulnerable personality”, coupled with her lowered intellect, accounted “for her lack of
judgment and acquiescence in being manipulated into committing the offence”. The Applicant was of “borderline
intelligence” and “overly compliant”. She had been traumatised by her experiences; her lowered intellect and
“current emotional state” made her “vulnerable to exploitation by her more able peers”.

43. In his July 2016 letter, Dr Egnal dealt with a number of questions posed by the Applicant's solicitors. Dr Egnal
began by summarising his earlier (2014) views. Asked whether it was “possible and/or probable” that his 2014


-----

findings “could have applied to …[the Applicant]…in 2007 when she was arrested and convicted of cocaine
trafficking”, Dr Egnal said this:

“In my opinion, any or all of the above incidents [namely, the RTA, contracting HIV, the head injury following the
assault with a brick] could have contributed to a cognitive decline which was assessed by myself in 2014. It is
however, difficult to accurately postulate retrospectively about this.”

44. A further question put to Dr Egnal was whether the Applicant “belonged to a category of persons less able to
resist pressure than people not within that category due to recognised mental illness or psychiatric condition, such
as post-traumatic stress disorder leading to learnt helplessness at the time of her offence in February 2007”. While
we have distinct reservations as to the wording of the question and the need to “unpick” it, we nonetheless record
Dr Egnal's answer:

“ She was….following my assessment of her, a person of low intellect, with an over-compliant personality, limited
judgment, and with an ability to be easily led and influenced by more dominant others. She also appears to be a
traumatised individual. These factors could have led to her having been coerced into committing the offence in
February 2007. ”

45. Ms Robertson's 2015 Report concluded that the Applicant met the full criteria for a diagnosis of PTSD. She
was severely depressed. Ms Robertson was of the opinion that the Applicant “is highly vulnerable to a suggested
course of events”.  It is said that “she may agree …to please them and feel a sense of being liked and belonging”.
The Applicant would have limited capacity to understand and participate in the FTT proceedings; she was not fit to
give evidence in Court.

46. In 2016, the Applicant's solicitors put the same questions to Ms Robertson as had been put to Dr Egnal. Ms
Robertson thought it “highly probable” that the findings from her assessment in 2015 applied to the Applicant in
2007. Moreover, according to Ms Robertson, the Applicant was “very likely to have been vulnerable to exploitation
and less able to resist pressure as a result of her complex PTSD and her cognitive impairment”.

47. As to trial counsel's recollections, Dr Egnal and Ms Robertson's 2017 letters broadly ascribe the Applicant's
seemingly detached behaviour in Court to her underlying PTSD and vulnerability, together with her cognitive and
neuro-psychological impairments.

THE PRINCIPAL ISSUES

48. As it seems to us, the principal Issues are these:

i) Is this a change in law case, so that the grant of leave requires substantial injustice to be shown?  (“Issue I: A
change in law case”)

ii) Is the fresh evidence, or any part of it, admissible?  (“Issue II: Fresh evidence”)

iii) Was the Applicant's conviction unsafe? (“Issue III: Safety of the conviction”)

We shall deal with those Issues in turn but, before doing so, we outline the rival cases in very brief terms.

THE RIVAL CASES

49. We were most grateful to both Mr Fitzgibbon QC, for the Applicant and Mr Douglas-Jones QC, for the
Respondent, for the quality of their assistance.

50. Mr Fitzgibbon submitted that, on the facts as now known, the law should protect the Applicant rather than
subjecting her to a criminal conviction. The FTT Decision had been carefully reasoned and the CA Minute, itself
reasoned, went beyond merely adopting the FTT's findings. The CA Minute was conclusive as to the Applicant
being a VOT – a fact now accepted by the Respondent but not appreciated at the time of her trial in 2007. Although
the medical evidence could have been available at her trial, no one had thought of it; that feature should not itself


-----

serve as a bar to admitting the medical evidence now. Though late, the medical evidence was sufficiently grounded
in pre-existing events. The high point was that the Applicant had been “overly compliant” and less capable of
resisting pressure. She had at the time been under real pressure from dedicated organised criminals. The medical
evidence captured her vulnerability to such pressure and would likely have had a considerable impact at her trial.
That the jury had rejected her defence of duress, did not rule out the need now to consider the impact both of her
being a VOT and the medical evidence. On all the fresh evidence, there was a clear nexus: she was a drugs mule
_because she was a VOT. So far as concerns the chronology, she had been able to escape temporarily but had_
only gone to family members. Subsequently, she fell prey to the same people again, who resumed their hold on
her. The jury knew that – but not her vulnerability.  There was a sufficient explanation of the delay to justify an
EOT.  Looked at in the round, the conviction was unsafe. Leave to appeal should be granted; if this was a change
in law case, then the Applicant did show a substantial injustice: namely, that arising from the enduring and serious
impact of her conviction and sentence to more than 4 years' imprisonment on her immigration and refugee status.
Furthermore, the appeal should be allowed. It was highly unlikely that the Applicant would be prosecuted if she
were arrested today in the same circumstances as in 2007. The policy underlying the developing law and guidance
in this area was to protect VOTs.

51. Mr Douglas-Jones, on behalf of the Respondent, accepted that the Applicant had been a VOT. However, both
the FTT Decision and the CA Minute had their limitations, based essentially, as they were, on the assertions of the
Applicant and untested evidence. Moreover, being a VOT was not itself sufficient for the Applicant's purpose on
this application – and, in any event, she had not been a VOT “in a vacuum”. The context included the chronology.
The Applicant had the state of mind and strength of character to escape from the Bahamas, most probably very
shortly after arriving there in December 2004 and fly to Miami. There she remained, before returning to the UK,
knowing the risk of associating again with the “gangsters” (as Mr Fitzgibbon had described B and the others). At no
stage had the Applicant gone to the authorities – though later of course, she did so. Overall, the Applicant's
position was not materially distinguishable from almost all female drug couriers from the Caribbean, though Mr
Douglas-Jones accepted (rightly) that our decision must be fact-specific. So far as concerned the medical
evidence, Mr Douglas-Jones contended that the Applicant's experience of prison had proved more traumatic than
her experience of the traffickers. Furthermore, the medical evidence, prepared years after the Applicant's
conviction, was irrelevant and inadmissible; alternatively it was of negligible weight.  This was a change in law
case, so that a substantial injustice needed to be shown. But even if it was, this was not a case where either (1) the
dominant force of compulsion, in the context of a very serious offence, was sufficient to reduce the Applicant's
criminality or culpability to or below a point where it was not in the Public Interest for her to be prosecuted; or (2) the
Applicant would or might well not have been prosecuted in the Public Interest. Leave to appeal should be refused; if
granted, the appeal should be dismissed.

ISSUE I: A CHANGE IN LAW CASE

52. (1) The test and its rationale: It is now well-established that where leave to appeal is sought out of time in a
case where the law as it then stood was correctly applied, so that any appeal hinges on a change in the law, leave
is characterised as “exceptional” and will only be granted if substantial injustice can be shown: R v Jogee _[2016]_
_UKPC 7; [2017] AC 387, at [100];_ _R v Johnson_ _[2016] EWCA Crim 1613; [2017] 1 Cr App R 12, at [10] and_
following. The requirement that substantial injustice be demonstrated comprises an additional hurdle for an
applicant to overcome. The rationale for this more stringent approach in such a case was, with respect, succinctly
explained by Geoffrey Lane LJ (as he then was), in R v Mitchell (1977) 65 Cr App R 185, at p. 189, as follows:

“It should be clearly understood, and this court wants to make it even more abundantly clear, that the fact that there
has been an apparent change in the law or, to put it more precisely, that previous misconceptions about the
meaning of a statute have been put right, does not afford a proper ground for allowing an extension of time in which
to appeal against conviction.”

As observed in Jogee (ibid), “alarming consequences” would otherwise flow.

53. For completeness, it may be observed that while demonstrating “substantial injustice” is thus an additional
requirement for the grant of leave in a change in law case, those seeking an EOT (especially a lengthy EOT) – in


-----

cases where no change in law is involved – will in any event be required to give cogent reasons and an explanation
for the delay; time limits are there for good reason and in the interests of justice: R v Roberts _[[2016] EWCA Crim](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JMY-BP51-F0JY-C0N9-00000-00&context=1519360)_
_[71; [2016] 1 WLR 3249, at [36] – [39].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JMY-BP51-F0JY-C0N9-00000-00&context=1519360)_

54. (2) A change in the law? We are very grateful to the Criminal Appeal Office for the most helpful Note to the
Court and the Parties (dated 29[th] June, 2018), raising the question as to whether this was indeed a change in law
case. Having carefully considered that Note, we are nonetheless satisfied that it is such a case, as explained in the
paragraphs which follow.

55. The Protocol to Prevent, Suppress and Punish Trafficking in Persons, Especially Women and Children,
supplementing the United Nations Convention against Transnational Organised Crime, Adopted and opened for
signature, ratification and accession by General Assembly resolution 55/25 of 15 November 2000 (“the Palermo
Protocol”), entered into force on the 25[th] December, 2003. The Palermo Protocol provided for the prevention and
criminalisation of trafficking and furnished various measures for the protection of VOTs. Furthermore, Art 4 of the
ECHR was then in force and outlawed slavery, servitude and forced labour.

56. In this jurisdiction, the judgment of Laws LJ in this Court in _R v O_ _[[2008] EWCA Crim 2835, including the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P3GR-00000-00&context=1519360)_
observation, at [26], as to the “shameful set of circumstances” pertaining to a 17 year old VOT, heralded the
beginnings of a sea change.

57. On the 17[th] December, 2008, the Council of Europe Convention on Action against Trafficking in Human Beings,
Warsaw 16.5.2005 (“ECAT”) was ratified by the UK.  For present purposes, the provisions of Art. 26 of ECAT
should be underlined:

“ Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of not
imposing penalties on victims for their involvement in unlawful activities, to the extent that they have been
compelled to do so.”

58. On the 6[th] April, 2013, Directive 2011/36/EU of the European Parliament and of the Council of 5 April 2011 on
preventing and combating trafficking in human beings and protecting its victims (“the Directive”), came into force in
the UK. Art. 8 of the Directive provides as follows:

“ Non-prosecution or non-application of penalties to the victim

Member States shall, in accordance with the basic principles of their legal systems, take the necessary measures to
ensure that competent national authorities are entitled not to prosecute or impose penalties on victims of trafficking
in human beings for their involvement in criminal activities which they have been compelled to commit as a direct
consequence of being subjected to …[trafficking]….”

59. These provisions of ECAT and the Directive, demonstrating a very significant change in approach to VOTs has
been reflected in a series of decisions of this Court (to which we shall come when dealing with Issue III),
underlining the Court's power to protect VOTs in respect of offences they have been compelled to commit: (1) by
staying a prosecution; or (2) if identification of a person as a VOT does not take place until after conviction,
quashing a conviction as an abuse of process. Plainly too, the provisions of s.143 of the Criminal Justice Act 2003,
entitling and obliging the Court when sentencing to have regard to the offender's culpability, are likewise relevant
here. Most recently, s.45 of the **_Modern Slavery Act 2015 (“the 2015 Act”) provides an express (though not_**
retrospective) defence to VOTs compelled to commit an offence.

60. Meanwhile and in parallel, the CPS Guidance has changed very substantially with regard to VOTs. The first
Guidance to include a specific provision on the non-prosecution of VOTs was dated May 2007 and was current at
the time of the Applicant's trial (“the 2007 Guidance).  It provided as follows:

“ Prosecution of Defendants charged with offences who might be trafficked victims


-----

Offences include immigration offences and for young defendants – cultivation of cannabis and pickpocketing in
organised gangs.

Victims of human trafficking may commit offences whilst they are being coerced by another: When reviewing such a
case, it may come to the notice of the prosecutor that the suspect is a 'credible' trafficked victim. For these
purposes, 'credible' means that the investigating officers have reason to believe that the person has been trafficked.
In these circumstances prosecutors must consider whether the public interest is best served in continuing the
prosecution in respect of the offence. Where there is evidence that a suspect is a credible trafficked victim,
prosecutors should consider the public interest in proceeding. Where there is clear evidence that the defendant has
a credible defence of duress, the case should be discontinued on evidential grounds.”

61. The final CPS Guidance, before the coming into force of the 2015 Act, was dated 29[th] August, 2013 (“the 2013
Guidance”). The 2013 Guidance provides a detailed and structured approach, in clear contrast to the embryonic
(though valuable) observations in the 2007 Guidance.

62. The 2013 Guidance highlights that prosecutors should be alert to the indicators of trafficking. It underlines the
prosecutor's obligations in terms of Art. 4, ECHR, Art. 26 of ECAT and Art. 8 of the Directive. It calls for a “threestage approach” to the prosecution decision:

“In addition to applying the Full Code Test in the Code for Crown Prosecutors, prosecutors should adopt the
following three stage assessment:

(1) is there a reason to believe that the person has been trafficked? if so,

(2) if there is clear evidence of a credible common law defence of duress, the case should be discontinued on
evidential grounds; but

(3) even where there is not clear evidence of duress, but the offence has been committed as a result of compulsion
arising from trafficking, prosecutors should consider the public interest in proceeding to prosecute.”

63. With a view to identifying whether a suspect might be a VOT, the 2013 Guidance requires the prosecutor to
make proper inquiries and to utilise the National Referral Mechanism (“NRM”).  A referral through the NRM will lead
to a decision by the Competent Authority (“CA”, to which we have already referred), of which prosecutors should
take account. The 2013 Guidance continues by working its way through the three-stage approach.  With regard to
compulsion falling short of duress, it says this:

“The means of trafficking used in an individual case may not be sufficient to give rise to a defence of duress, but
how the person was trafficked will be relevant when considering whether the public interest is met in deciding to
prosecute or proceed with a prosecution.

In assessing whether the victim was compelled to commit the offence, prosecutors should consider whether:

(1) the offence committed was a direct consequence of, or in the course of trafficking and

(2) whether the criminality is significantly diminished or effectively extinguished because no realistic alternative was
available but to comply with the dominant force of another.

Where a victim has been compelled to commit the offence, but not to a degree where duress is made out, it will
**generally not be in the public interest to prosecute unless the offence is so serious or there are other**
aggravating factors. ”

64. Pulling the threads together and considering substance rather than form, we are entirely satisfied that this is a
change of law case – even putting to one side the changes introduced by the 2015 Act, which are not relevant here.
First, there has been a material change in the legal recognition of the rights of VOTs between 2007 and now. In
2007, whatever the position ought to have been, there was only very limited awareness of such rights. Secondly,
the detailed provisions of Art. 26 of ECAT and Art. 8 of the Directive were not in force in this jurisdiction in 2007.


-----

Thirdly, to the extent that CPS Guidance is relevant, the contrast between the 2007 and 2013 Guidance is stark.
What has emerged is more than simply a development in the existing law relating to VOTs. It could not seriously be
argued that on the law and practice as understood in 2007, it was an abuse of process for the prosecution of the
Applicant to proceed. Her application (and any appeal) thus depend on a change in law. It follows that to obtain
exceptional leave, it must be shown that to refuse leave would occasion substantial injustice.

65. (3) Applying the change in law test: For our part, this question can be taken shortly. If but only if, the Applicant
can demonstrate an arguable case as to the unsafety of the conviction, the subject of Issue III below, we would not
preclude the Applicant from challenging the conviction. The reason is that, as is not or not seriously in dispute, the
Applicant's conviction and sentence to a term of seven years imprisonment impacts on her immigration status. As a
refugee, she has been granted Leave to Remain in the UK for 5 years running until late 2020. At that point in time,
the Applicant's refugee status and any grant of further Leave to Remain would be at risk by reason of her conviction
and sentence of imprisonment for at least 4 years: see Section 32 of the UK Borders Act 2007, and paragraphs
338A, 339AC and 339R of the Immigration Rules. In our judgment, _if the Applicant is otherwise capable of_
demonstrating an arguable case as to the unsafety of her conviction, she ought not to fail at the hurdle of obtaining
exceptional leave. The risk to her immigration status would constitute a substantial injustice if, in such
circumstances, she was precluded from challenging her conviction by reason of the requirement to obtain
exceptional leave. For completeness, the facts of the present case are clearly distinguishable from those pertaining
in R v Ordu _[[2017] EWCA Crim 4; [2017] 1 Cr App R 21, where the quashing of the conviction would have had no](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MNW-82J1-F0JY-C4M8-00000-00&context=1519360)_
practical consequences. Finally, if the Applicant is otherwise able to obtain leave to appeal, then (on balance) we
would be satisfied that, in all the circumstances, there has been a sufficient explanation of the delay to warrant an
EOT.

ISSUE II: FRESH EVIDENCE

66. We have already outlined the fresh evidence which the Applicant seeks to adduce, divided into that which we
have termed the First Part and the Medical Evidence. We have also considered all the fresh evidence, _de bene_
_esse. We now express our conclusions._

67. (1) The first part: We have no real hesitation in granting the application to admit in evidence the FTT Decision,
the CA Minute and, for that matter, the Home Office Letter. Any analysis of this material and the weight to be
accorded to it are dealt with under Issue III.

68. Applying s.23 of the 1968 Act, the receipt of this material is expedient in the interests of justice. Its essence is
the recognition, essentially undisputed by the Respondent, that the Applicant was a VOT. It would not be in the
interests of justice to proceed with the application (and any appeal) without having regard to the FTT Decision and
the CA Minute to this effect.  The evidence is capable of belief; it may afford a ground for allowing the appeal; it
post-dates the trial and so could not have been adduced at trial.

69. Before us, no question arises as to the admissibility of these materials as such. That is not the case as to their
admissibility at trial, where, to put it no higher, the admissibility of both the decisions in question and the underlying
reasoning must be regarded as unlikely on what may be broadly (if very loosely) described as _Hollington v_
_Hewthorn [1943] KB 587grounds. That said:_

i) Had the FTT Decision and the CA Minute been available at the time of trial, we regard it as overwhelmingly likely
that, in the interests of justice and fairness, the Crown would have been required to make admissions as to their
recognition of the Applicant as a VOT – so that, in practical terms, any admissibility difficulties at trial would have
been resolved.

ii) Whatever the difficulties of admissibility at trial, we would not regard them as outweighing our conclusion, on the
basis of all the other relevant factors for the purposes of s.23, that the materials comprising the First Part should be
admissible before us. We proceed accordingly.

70. _(2) The medical evidence:_ We take a different view as to the medical evidence and decline to admit it into
evidence on the application (and any appeal).  Our reasons follow.


-----

71. First, there is no good reason why evidence of this nature could not have been obtained for use at trial. Duress
was the central issue at trial, so the Applicant's vulnerability, susceptibility to pressure and any cognitive or other
impairments would plainly have merited consideration – had there then been a sensible foundation for doing so.  It
is to be emphasised that the potential relevance of such evidence did not turn on a recognition or developed
recognition, lacking in 2007, of the rights of VOTs. Accordingly, this is a factor telling against the admissibility of the
medical evidence now, though we do not rest our decision upon it alone.

72. Secondly, there must be very real concern that the conclusions of the Psychologists go beyond the proper
remit of expert witnesses and stray into the province of the jury.  This concern is acute with regard to the questions
from the Applicant's solicitors and the answers from the experts in 2015-2016, set out above and going (in short) to
the Applicant's levels of compliance and suggestibility. As it seems to us, the experts' conclusions would have been
largely inadmissible at trial, albeit that their assessments of the Applicant would have been admissible, at least to
some extent. On this footing, the impact of the medical evidence as presented to us falls necessarily to be reduced.

73. Thirdly, we have real misgivings that the evidence might afford any ground for allowing the appeal. Over and
above the need to confine the experts to their proper province, the medical evidence was obtained some 7 – 10
years after the trial. Though different shades of opinion appear from the medical evidence, we are struck by Dr
Egnal's observation in 2016 that it was “…difficult to accurately postulate retrospectively….”. To us, that is no more
than common sense; it is difficult to apply a 2014-2017 assessment of the Applicant to her condition in late 2007.
Moreover and even assuming that aspects of the Applicant's condition as assessed by the experts in 2014 – 2017
were of long-standing, pre-dating 2007, it is also a reality that by the time of her assessment she had experienced a
substantial period of imprisonment. It certainly cannot be excluded that the experience of imprisonment would have
impacted on her condition when subsequently seen by the experts – but would of course not have been present at
the time of trial and prior to her experience of custody.

74. For all these reasons, especially when considered cumulatively, we do not think that the reception of the
medical evidence would be necessary or expedient in the interests of justice and we decline to admit it into
evidence on the application (or any appeal).

ISSUE III: SAFETY OF THE CONVICTION

75. (1) The legal framework: The starting point is to clear the decks. First, as is plain, this is a case where there
was no credible common law defence of duress (or necessity). Secondly, this is not a case concerning a defendant
under 18 years of age. Thirdly, the defence provided by s.45 of the 2015 Act is inapplicable. Fourthly, this is a
case where the FTT and CA have concluded that the Applicant is a VOT.

76. Against this background, we venture to summarise below the relevant principles (for present purposes) in the
light of the decisions and guidance of this Court in R v M(L) and others _[2010] EWCA Crim 2327; [2011] 1 Cr App R_
12; R v N(A) and others _[2012] EWCA Crim 189; [2012] 1 Cr App R 35; R v L(C) and others [2013] EWCA Crim_
_991; [2013] 2 Cr App R 23; R v Joseph (Verna) and others_ _[2017] EWCA Crim 36; [2017] 1 Cr App R 33._

i) Neither Art. 26 of ECAT nor Art. 8 of the Directive confers a blanket immunity from prosecution on VOTs.

ii) Instead, the UK's international obligations require the careful and fact sensitive exercise by prosecutors of their
discretion as to whether it is in the public interest to prosecute a VOT.  That discretion is vested in the prosecutor,
not the Court.

iii) The decisions of the FTT and CA as to whether an individual is a VOT do not bind prosecutors or the Court but
will be respected (subject to submissions as to their basis or limitations) unless there is a good reason not to follow
them.

iv) There is no closed list of factors bearing on the prosecutor's discretion to proceed against a VOT.
Generalisation is best avoided. That said, factors obviously impacting on the discretion to prosecute go to the
nexus between the crime committed by the defendant and the trafficking.  If there is no reasonable nexus between
the offence and the trafficking then, generally, there is no reason why (on trafficking grounds) the prosecution


-----

should not proceed. If there is a nexus, in some cases the levels of compulsion will be such that it will not be in the
public interest for the prosecution to proceed. In other cases, it will be necessary to consider whether the
compulsion was continuing and what, if any, reasonable alternatives were available to the VOT. There will be
cases where a decision to prosecute will be justified but due allowance can be made for mitigating factors at the
sentencing stage.  The matter was most helpfully summarised by Lord Judge CJ, in LC, at [33], as follows:

“ …the distinct question for decision, once it is found that the defendant is a victim of trafficking is the extent to
which the offences with which he is charged, or of which he has been found guilty are integral to or consequent on
the exploitation of which he was the victim. We cannot be prescriptive. In some cases the facts will indeed show
that he was under levels of compulsion which mean that, in reality, culpability was extinguished. If so, when such
cases are prosecuted, an abuse of process submission is likely to succeed…… In other cases….culpability may be
diminished but nevertheless be significant. For these individuals prosecution may well be appropriate, with due
allowance to be made in the sentencing decision for their diminished culpability. In yet other cases, the fact that the
defendant was a victim of trafficking will provide no more than a colourable excuse for criminality which is
unconnected to and does provide no more than a colourable excuse for criminality which is unconnected to and
does not arise from their victimisation. In such cases an abuse of process submission would fail.”

v) As always, the question for this Court goes to the safety of the conviction. However, in the present context, that
inquiry translates into a question of whether in the light of the law as it now is (this being a rare change in law case)
and the facts now known as to the Applicant (having regard to the admission of fresh evidence) the trial court
should have stayed the proceedings as an abuse of process had an application been made. This question can be
formulated indistinguishably in one of two ways which emerge from the authorities: was this a case where either: (1)
the dominant force of compulsion, in the context of a very serious offence, was sufficient to reduce the Applicant's
criminality or culpability to or below a point where it was not in the Public Interest for her to be prosecuted? or (2)
the Applicant would or might well not have been prosecuted in the Public Interest?  If yes, then the proper course
would be to quash the conviction. As explained in Joseph (Verna) at [20 iii)], the Court's power to stay is “a power to
ensure that the State complied with its international obligations and properly applied its mind to the possibility of not
imposing penalties on victims”.

77. (2) Applying the law to the facts: Having regard to the change in the law and the fresh evidence admitted, we
now answer the question which arises for this Court. We conclude that the conviction of the Applicant was not,
even arguably, unsafe. This was a case where, in the context of the importation of Class A drugs, it cannot be said
that the Applicant was under such a level of compulsion that her criminality or culpability was reduced to or below a
point where it was not in the Public Interest for her to be prosecuted. In short, even on the law as it now is (leaving
s.45 of the 2015 Act out of account and on which we express no view), provided only that a prosecutor properly
considered the Applicant's position as a VOT in accordance with the law and Guidance to which we have referred,
we are unable to conclude that it would be an abuse for the Applicant to be prosecuted. Our reasons follow.

78. First, making every allowance for the Applicant being no more than a “drugs mule”, she committed a serious
offence. Its gravity should not be minimised.

79. Secondly, the Applicant's essential factual account was tested before the jury, by way of her defence of duress

- and rejected. It is correct that the jury's verdict means no more than that they were sure that the common law
defence of duress was not available to her and so her conviction cannot exclude the possibility that what she did
was done under some lesser form of compulsion. That said, on the one occasion when the Applicant's account
was challenged, it was found wanting.

80. Thirdly, we accept the FTT Decision and the CA Minute and do not go behind their conclusion that the
Applicant was a VOT. However, that conclusion is of limited assistance in assessing the true levels of compulsion
affecting the Applicant. On the material available to us, the Applicant's account to the FTT was essentially untested
and, though the CA Minute was reasoned, the reasoning does not go beyond the FTT Decision (even accepting, as
we do, that it was not at all a rubber stamp). Moreover, the fact that the Applicant was a VOT does not of itself
suffice to render her conviction unsafe. It is instead the starting point for considering whether it was.


-----

81. Fourthly, the chronology of events serves to provide context. As already recounted, after being trafficked to the
Bahamas, the Applicant made her own way to Miami, escaping from her traffickers. Thereafter, she stayed in the
USA for a considerable period of time, before, cognisant of the risk, she returned to the UK and resumed contact
with those whom she knew were involved in the drugs trade. That there were or may have been health issues
prompting her return to the UK does not bear on the resumption of contact with those who had, on her own account,
already trafficked her to the Bahamas. Later and after her conviction, to her considerable credit, she assisted the
authorities. In our judgment, these features of the history, speak volumes as to the Applicant's true resilience and
cast a contemporaneous light on her reaction to the compulsion she was under. It simply cannot be said that there
were no reasonable alternatives available to the Applicant to escape from that compulsion; indeed, on two
occasions (one before the incident resulting in her conviction and one subsequent to her conviction) that is precisely
what she did.

82. Fifthly, in all the circumstances outlined, we are unable to conclude, even arguably, that the Applicant's
culpability was extinguished such that a prosecutor, properly applying the law as it now is (let alone the law in
2007), would or might not proceed with a prosecution in the Public Interest. It follows that we refuse the application
for leave to appeal and, as any EOT would thus be futile, we refuse an EOT.

83. Though our decision is to refuse leave to appeal, we have dealt fully with the matter and, accordingly, this
judgment can be cited.

**End of Document**


-----

