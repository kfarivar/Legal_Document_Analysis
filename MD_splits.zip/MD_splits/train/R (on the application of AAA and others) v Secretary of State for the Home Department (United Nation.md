Commissioner for Refugees intervening) and other case....

# R (on the application of AAA and others) v Secretary of State for the Home Department (United Nations High Commissioner for Refugees intervening)
 and other cases [2022] EWHC 3230 (Admin)

King's Bench Division (Divisional Court)

Lewis LJ and Swift J

19 December 2022Judgment

**Charlotte Kilroy KC, Michelle Knorr, Harry Adamson, and Sarah Dobbie (instructed by Leigh Day) for**
the Claimant

**Edward Brown KC and Jack Anderson** (instructed by **Government Legal Department) for the**
**Defendant**

Hearing dates: 5 – 9 September 2022, and 12 – 14 October 2022

- - - - - - - - - - - - - - - - - - - - 
**JUDGMENT APPROVED SUBJECT TO EDITORIAL CORRECTIONS**

**LORD JUSTICE LEWIS and MR JUSTICE SWIFT handed down the following judgment of the court:**

A.  Introduction

(1)  General

1. These claims challenge decisions made by the Home Secretary that asylum claims made in the United
Kingdom should not be determined here and that instead the persons who have made those claims should
be removed to Rwanda to have their asylum claims determined there. Removal from the United Kingdom
in these circumstances involves two decisions: first, a decision that the asylum claim is inadmissible – i.e.,
that the asylum claim should not be decided on its merits in the United Kingdom; and second a decision to
remove the asylum claimant to a safe third country which in these cases is Rwanda. For any asylum claim
made on or before 27 June 2022, the power to make these inadmissibility and removal decisions is in
paragraph 345A to 345D of the Immigration Rules1.

2. Paragraphs 345A – D of the Immigration Rules set out conditions that must be met before the Home
Secretary can decide that an asylum claim is inadmissible in the United Kingdom and whether she can
remove the person who has made the asylum claim to a safe third country. For present purposes (putting
the matter in very general terms), the relevant condition for an inadmissibility decision is whether, before
making the asylum claim in the United Kingdom, the asylum claimant had the opportunity to claim asylum
in a safe third country but did not do so. If the Home Secretary decides that an asylum claim is
inadmissible, she is permitted to remove the person who has made the claim either to the safe third
country where the opportunity to make the asylum claim arose, or to any other safe third country that
agrees to accept the asylum claimant.

3. The inadmissibility and removal decisions before the court in these proceedings were taken by the then
Home Secretary in pursuance of criteria contained in guidance published by her in May 2022. Among other


-----

Commissioner for Refugees intervening) and other case....

matters, those criteria explain how arrangements made between the governments of the United Kingdom
and the Republic of Rwanda for the transfer of asylum claimants would be used. Those arrangements are
the Migration and Economic Development Partnership (“the MEDP”). The arrangements provide for
transfer of asylum claimants from the United Kingdom to Rwanda, the determination of asylum claims by
the Rwandan authorities, and related matters. The premise of these decisions has been that by reason of
the arrangements made in the MEDP, Rwanda is a safe third country to which asylum claimants may be
removed. One set of inadmissibility and removal decisions was taken in late May and early June 2022. On
5 July 2022, following further representations and consideration of evidence filed in these proceedings
(which were all commenced on or after 8 June

2022), the Home Secretary made further inadmissibility and removal decisions for each of the individual
Claimants now before us.

4. The claims raise many grounds of challenge to these decisions. Some matters raised are generic; they
do not depend on the facts of any individual case but are instead to the effect that the Home Secretary's
decisions are flawed for reasons that will apply whenever it is proposed to decide that an asylum claim is
inadmissible and/or to remove the asylum claimant to Rwanda. Other grounds of challenge raised depend
on the facts of the individual cases and how the Home Secretary has addressed those facts when taking
her decisions. The Claimants also challenge further decisions taken by the Home Secretary on claims they
have made that their removal from the United Kingdom would be in breach of their rights derived from the
European Convention on the Protection of Human Rights and Fundamental Freedoms (“the ECHR”). The
Home Secretary has rejected these claims and concluded that these human rights claims were clearly
unfounded.

5. The government's proposal to relocate asylum seekers to Rwanda has been the subject of considerable
public debate. It is, therefore, important to have the role of the court well in mind. In judicial review claims
the court resolves questions of law. Judicial review is the means of ensuring that public bodies act within
the limits of their legal powers and in accordance with the legal principles governing the exercise of their
decision-making functions. In addition, Parliament requires that public bodies act consistently with the
rights and freedoms guaranteed by the ECHR: see section 6 of the Human Rights Act 1998). The court is
not responsible for making political, social or economic choices – for example to determine how best to
respond to the challenges presented by asylum seekers seeking to cross the Channel in small boats or by
other means. Those decisions, and those choices, are ones that Parliament has entrusted to ministers.
The approach of ministers is a matter of legitimate public interest and debate and, in this instance, has
stirred public controversy about whether the relocation of asylum seekers to a third country such as
Rwanda is an appropriate response to the problems that the government has identified. But those matters
are not for the court. The role of the court is only to ensure that the law is properly understood and
observed, and that the rights guaranteed by Parliament are respected

(2)  A short history of the proceedings

6. In late May and early June 2022, the Home Secretary took 47 decisions declaring asylum claims made
in the United Kingdom to be inadmissible and deciding that the claimants should be removed to Rwanda.
Her intention was that those concerned would be removed to Rwanda by charter flight on 14 June 2022.
Each inadmissibility and removal decision came with removal directions to that effect. The decisions
prompted more than 20 claims, filed between 8 June 2022 14 June 20222. Claim CO/2032/2022 was
issued on 8 June 2022. On 10 June 2022 the Administrative Court heard and refused an application for an
interim injunction to prevent the individual Claimants in that claim being removed on the charter flight. On
13 June 2022 the Court of Appeal dismissed an appeal against that decision. On 14 June 2022 the
Supreme Court dismissed an application for permission to appeal against the decision of the Court of

Appeal. On 13 and 14 June 2022 further applications for interim relief in other claims were heard and
refused by the Administrative Court. The cases considered then were CO/2103/2022, CO/2111/2022,
CO/2112/2022, CO/2113/2022, CO/2125/2022, CO/2126/2022, and CO/2129/2022. The litigation caused


-----

Commissioner for Refugees intervening) and other case....

the Home Secretary to reconsider some of the decisions she had taken. This led to the cancellation of
some removal directions.

7. On 14 June 2022 three Claimants made applications to the European Court of Human Rights for interim
measures. On the application of NSK, one of the Claimants in CO/2032/2022, the European Court of
Human Rights granted an interim measure preventing him from being removed to Rwanda “until 3 weeks
after delivery of the final domestic decision in [the] ongoing judicial review proceedings”. In the two other
applications (RM, the Claimant in CO/2077/2022; and _HTN, the Claimant in CO/2104/2022), the Court_
granted an interim measure preventing removal until 20 June 2022. The practical consequence of the grant
of interim measures has been that no removals to Rwanda have taken place either on 14 June 2022 or
since.

8. The order made at the 10 June 2022 hearing for interim relief also gave directions in case
CO/2032/2022 with a view to a rolled-up hearing at the end of July 2022 so that permission to apply for
judicial review would be considered at the same hearing as the substantive challenges. Since 14 June
2022, all the claims before the Administrative Court have been the subject of extensive case management
to ensure that they were heard together and as soon as reasonably possible given the need to ensure
fairness for all the parties. The original directions envisaged that the claims would be heard in week
commencing 18 July 2022. Those directions were revised when, on 5 July 2022, the Home Secretary retook the inadmissibility and removal decisions and some of the decisions on the human rights claims. It
was clear that fairness to the Claimants required that they be given the opportunity to respond to the new
decisions. At a directions hearing 20 July 2022, the court fixed the hearing of some claims for week
commencing 5 September 2022 and others for week commencing 10 October 2022. Yet further claims
were stayed. Annex A to this judgment lists the claims filed with the court challenging admissibility
decisions and the status of each claim.

9. This judgment is in respect of all the cases heard in September and October, i.e., claims
CO/2023/2022; CO/2104/2022; CO/2077/2022; CO/2080/2022; CO/2098/2022; CO/2072/2022;
CO/2094/222; and CO/2056/2022. Most of the Claimants are persons who have made asylum claims that
the Home Secretary has decided are inadmissible. In addition, some Claimants have claimed that removal
would involve a breach of their rights derived from the ECHR and challenged decisions certifying their
human rights claims as manifestly unfounded. The Claimants were (save in one case) the subject of
removal directions. There are 11 individual claimants: AAA, AHA, AT, AAM, and NSK, all parties to claim
CO/2032/2022; _HTN, claim CO/2104/2022;_ _RM, claim CO/2077/2022;_ _ASM, claim CO/2080/2022;_ _AS,_
claim CO/2098/2022; _AB, claim CO/2072/2022; and_ _SAA, claim CO/2094/2022. Four organisations also_
bring claims: the Public and Commercial Services Union, Detention Action, and Care4Calais (all in claim
CO/2032/2022), and Asylum Aid (in claim CO/2056/2022).

10. By the order made following the interim relief hearing on 10 June 2022, the court permitted the United
Nations High Commissioner for Refugees to intervene in case CO/2032/2022. The High Commissioner
has filed evidence in the form of witness statements made by Lawrence Bottinick, the High Commissioner's
Senior Legal

Officer in the United Kingdom; has filed written observations settled by leading counsel; and has
supplemented those observations orally at the hearing.

(3)  Legal framework

11. The inadmissibility and removal decisions were made in the exercise of the power in paragraphs 345A
to 345D of the Immigration Rules:

“Inadmissibility of non-EU applications for asylum

345A. An asylum application may be treated as inadmissible and not substantively considered if the
Secretary of State determines that:


-----

Commissioner for Refugees intervening) and other case....

(i) the applicant has been recognised as a refugee in a safe third country and they can still avail
themselves of that protection; or

(ii) the applicant otherwise enjoys sufficient protection in a safe third country, including benefiting from the
principle of non-refoulement; or

(iii) the applicant could enjoy sufficient protection in a safe third country, including benefiting from the
principle of nonrefoulement because:

(a) they have already made an application for protection to that country; or

(b) they could have made an application for protection to that country but did not do so and there were no
exceptional circumstances preventing such an application being made, or

(c) they have a connection to that country, such that it would be reasonable for them to go there to obtain
protection.

**Safe Third Country of Asylum**

345B. A country is a safe third country for a particular applicant, if:

(i) the applicant's life and liberty will not be threatened on account of race, religion, nationality,
membership of a particular social group or political opinion in that country;

(ii) the principle of non-refoulement will be respected in that country in accordance with the Refugee
Convention;

(iii) the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman, or
degrading treatment as laid down in international law, is respected in that country; and

(iv) the possibility exists to request refugee status and, if found to be a refugee, to receive protection in
accordance with the Refugee Convention in that country.

345C. When an application is treated as inadmissible, the Secretary of State will attempt to remove the
applicant to the safe third country in which they were previously present or to which they have a
connection, or to any other safe third country which may agree to their entry.

**Exceptions for admission of inadmissible claims to UK asylum process**

345D. When an application has been treated as inadmissible and either

(i) removal to a safe third country within a reasonable period of time is unlikely; or

(ii) upon consideration of a claimant's particular circumstances the Secretary of State determines that
removal to a safe third country is inappropriate

the Secretary of State will admit the applicant for consideration of the claim in the UK.”

For the purposes of the cases before the court the following points are material. First, that to treat a claim
as inadmissible the Home Secretary had to decide that the requirements at paragraph 345A(iii)(b) were
met, including that the country in which the opportunity to make a protection claim arose was a safe third
country as defined at paragraph 345B. _Second, that if an inadmissibility decision was made, the Home_
Secretary could decide the remove the asylum claimant to Rwanda only if she could decide that Rwanda
was a safe third country, again as defined at paragraph 345B3.

12. When taking the inadmissibility and removal decisions, the Home Secretary also certified the claims in
exercise of the power at paragraph 17 in Part 5 of Schedule 3 to the Asylum and Immigration (Treatment of
Claimants etc) Act 2004 (“the 2004 Act”).  Paragraph 17 is as follows:

“17. This Part applies to a person who has made an asylum claim if the Secretary of State certifies that–

(a) it is proposed to remove the person to a specified State,

(b) in the Secretary of State's opinion the person is not a national or citizen of the specified State and


-----

Commissioner for Refugees intervening) and other case....

(c) in the Secretary of State's opinion, the specified State is a place –

(i) where the person's life and liberty will not be threatened by reason of his race, religion, nationality,
membership of a particular social group or political opinion, and

(ii) from which the person will not be sent to another State otherwise than in accordance with the Refugee
Convention.”

Certification under paragraph 17 is an integral part of the Home Secretary's decisions to remove asylum
claimants to Rwanda. If a certificate is made, paragraph 18 of Schedule 3 applies with the consequence
that the prohibition in section 77 of the 2002 Act on removing persons with extant asylum claims from the
United Kingdom is disapplied.

13. Further, if a claim is certified, the restriction on appeal rights at paragraph 19 of Schedule 4 will also
apply. Since 8 June 2022 paragraph 19 has been in the following terms:

“19.  Where this Part applies to a person–

(b) he may not bring an immigration appeal in reliance on an asylum claim which asserts that to remove
the person to the State specified under paragraph 17 would breach the United Kingdom's obligations under
the Refugee Convention,

(c) he may not bring an immigration appeal in reliance on a human rights claim if the Secretary of State
certifies that the claim is clearly unfounded.”

14. In addition, many of those who were the subject of inadmissibility and removal decisions further
contended that removal to Rwanda would be in breach of their ECHR

rights. By section 94 of the Nationality, Immigration and Asylum Act 2002 (“the 2002 Act”) the Home
Secretary may certify a human-rights claim as “clearly unfounded” if

(7) …

(a) it is proposed to remove the person to a country of which he is not a national or citizen, and

(b) there is no reason to believe that the person's rights under the Human Rights Convention will be
breached in that country.

(8) In determining whether a person in relation to whom a certificate has been issued under subsection (7)
may be removed from the United Kingdom, the country specified in the certificate is to be regarded as—

(a) a place where a person's life and liberty is not threatened by reason of his race, religion, nationality,
membership of a particular social group, or political opinion, and

(b) a place from which a person will not be sent to another country otherwise than in accordance with the
Refugee Convention or with the United Kingdom's obligations in relation to persons eligible for a grant of
humanitarian protection.”

Certification removes the claimant's rights of appeal through the Tribunal system. The decision to certify
may be challenged in judicial review proceedings.

(4)  The Home Secretary's policy

15. The Home Secretary's policy on use of the power to make inadmissibility decisions is apparent from
guidance to Home Office case workers published on 9 May 2022: “Inadmissibility: safe third country cases,
_version 6.0” (“the Inadmissibility Guidance”). On 28 June 2022 the Home Secretary published version 7.0_
of this guidance. Version 7.0 takes account of the new sections 80B and 80C of the 2002 Act and applies
only to asylum claims made on or after 28 June 2022. While it is common ground between all counsel in
these proceedings that there are no differences between version 6.0 and version 7.0 that are material to
the issues in these cases, for the purposes of the decisions in issue before this court version 6.0 of the
inadmissibility guidance remains the operative document.


-----

Commissioner for Refugees intervening) and other case....

16. The Home Secretary's policy on use of the power to make inadmissibility decisions is to the following
effect. The purpose pursued is to encourage “… asylum seekers to claim asylum in the first safe country
_they reach and [to deter] them from making unnecessary and dangerous onward journeys to the UK”. The_
guidance goes on to state _“… removals of individuals from the UK in accordance with the MEDP are_
_intended to deter people from making dangerous journeys to the UK to claim asylum, which are facilitated_
_by criminal smugglers, when they have already travelled through safe third countries. In particular, but not_
_exclusively, this is aimed at deterring arrivals by small boats.” The policy excludes certain categories of_
asylum claimant: inadmissibility decisions are not to be made in respect of claims made by unaccompanied
children; the policy does not apply to families – they are to be treated in accordance with the Home
Secretary's guidance on family returns; and decisions are

not to be made in respect of EU nationals – because they too are the subject of different provisions.

17. The final aspect to the policy is the possibility that a person whose claim has been held to be
inadmissible may be removed to Rwanda. The material part of the Inadmissibility Guidance states as
follows:

“If a case assessed as suitable for inadmissibility action appears to stand a greater chance of being
promptly removed if referred to Rwanda (a country with which the UK has a Migration and Economic
Development Partnership (MEDP), rather than to the country to which they have a connection, TCU should
consider referring the case to Rwanda. An asylum claimant may be eligible for removal to Rwanda if their
claim is inadmissible under this policy and (a) that claimant's journey to the UK can be described as having
been dangerous and (b) was made on or after 1 January 2022. A dangerous journey is one able or likely to
cause harm or injury.

…

Those progressed for consideration for relocation to Rwanda under the MEDP will be taken from the
detained and nondetained cohort and be identified in line with processing capacity. Priority will be given to
those who arrived in the UK after 9 May 2022.

…

Decision makers must take into account country information of the potential country/countries to where
removal may occur in deciding whether referral into a particular route is appropriate in the particular
circumstances of that claimant.”

In this judgment, for sake of convenience, we will refer to the policy as “the Rwanda policy”.

(5)  The Migration and Economic Development Partnership

18. The MEDP made between the United Kingdom and the Republic of Rwanda is set out in a
Memorandum of Understanding made on 13 April 2022 (“the MOU”) and two _Notes Verbales that_
supplement the MOU. Unless the parties agree otherwise, the MOU will remain in force for 5 years, and
may be renewed. The first Note Verbale is “… on guarantees of the Government of Rwanda regarding the
asylum process of transferred individuals” (“the Asylum Process NV”); the second is “… on guarantees of
the Government of Rwanda regarding the reception and accommodation of transferred individuals” (“the
Support NV”). So far as the Home Secretary is concerned, the MOU and the Notes Verbales are important
underpinning for a conclusion that Rwanda is a safe third country for the purposes of paragraph 345B of
the Immigration Rules.

19. Paragraph 2 of the MOU sets out the objectives of the arrangements:

“2.1 The objective of this Arrangement is to create a mechanism for the relocation of asylum seekers who's
claims are not being considered by the United Kingdom, to Rwanda, which will process their claims and
settle or remove (as appropriate) individuals after their claim is decided, in accordance with Rwanda
domestic law, the Refugee Convention, current international standards, including in accordance with
international human rights law and including the assurances given under this Arrangement.


-----

Commissioner for Refugees intervening) and other case....

2.2 For the avoidance of doubt, the commitments set out in this Memorandum are made by the United
Kingdom to Rwanda and vice versa and do not create or confer any right on any individual, nor shall
compliance with this Arrangement be justiciable in any court of law by third parties or individuals.”

20. The arrangements then set out in MOU are, in summary, to the following effect. A person may be
transferred to Rwanda only with the agreement of the Government of Rwanda. In reaching such agreement
account will be taken of Rwanda's “capacity to receive” persons and “administrative needs associated with
their transfer”. When a transfer request is made, the United Kingdom agrees to provide certain information
on the person it is proposed will transfer (the information to be provided is listed at paragraph 5 of the
MOU). Rwanda agrees to “give access to its territory … in accordance with its international commitments
and asylum and immigration laws” to all persons transferred under the MOU. Persons transferred will also
be provided with accommodation and support “… adequate to ensure [their] health, security and wellbeing
…” (MOU at paragraph 8). Paragraph 14 of the MOU further provides “Rwanda will have regard for
information provided about a Relocated Individual relating to any special needs that may arise as a result
of their being a victim of modern slavery and human trafficking and will take all necessary steps to ensure
these needs are accommodated.”

21. Paragraph 9 of the MOU sets out the arrangements made for processing asylum claims raised in
Rwanda:

“9.1  Rwanda will ensure that:

9.1.1 At all times it will treat each Relocated Individual, and process their claim for asylum, in accordance
with the Refugee Convention, Rwandan immigration laws and international and Rwandan standards,
including under international and Rwandan human rights law, and including but not limited to ensuring their
protection from inhuman and degrading treatment and refoulement;

9.1.2 Each Relocated Individual will have access to an interpreter and to procedural or legal assistance at
every stage of their asylum claim, including if they wish to appeal a decision made on their case;

9.1.3 If a Relocated Individual's claim for asylum is refused, that Relocated Individual will have access to
independent and impartial due process of appeal in accordance with Rwandan laws.

9.1.4 If a Relocated Individual does not apply for asylum, Rwanda will access the individual's resident
status on other grounds in accordance with Rwandan immigration laws.”

If a person is recognised as a refugee, he will receive support and accommodation at the same level as
while his claim was pending and “… will be treated in accordance with the Refugee Convention and
International and Rwandan standards” (MOU, paragraph 12). Provision is also made for persons whose
asylum claims are refused.

“10.2 For those who are not recognised as refugees Rwanda will consider whether the Relocated
Individual has another humanitarian protection need, such that return to their country of origin would result
in a real risk of their being subject to inhuman, degrading treatment or torture or a real risk to their life.
Where such a protection needs exists, Rwanda will provide treatment consistent with that offered to those
as refugees … and permission to remain in Rwanda. Such persons shall be awarded equivalent rights and
treatment to those recognised as refugees and will be treated in accordance with international and
Rwandan standards.

10.3 For those Relocated Individuals who are neither recognised as refugees nor to have protection needs
in accordance with paragraph 10.2, Rwanda will:

10.3.1 Offer an opportunity for Relocated Individual to apply for permission to remain in Rwanda on any
other basis in accordance with its domestic immigration laws and ensure the Relocated Individual is
provided with the relevant information needed to make such an application:

10.3.2 Provide adequate support and accommodation for the Relocated Individual's health and security
until such time as their status is regularised or they leave or are removed from Rwanda.


-----

Commissioner for Refugees intervening) and other case....

10.4 For those Relocated Individuals who are neither recognised as refugees nor to have a protection
need or other basis upon which to remain in Rwanda, Rwanda only remove such a person to a country in
which they have a right to reside. If there is no prospect of such removal occurring for any reason Rwanda
will regularise that person's immigration status in Rwanda.

10.5 Relocated Individuals who have been refused asylum and do not have a humanitarian protection
need will have the same rights as other individuals making an application under Rwandan immigration
laws.”

Paragraph 17 of the MOU provides, that as far as concerns any person transferred, the obligations arising
under the MOU will remain in force even after the expiry or termination of the MOU.

22. By paragraph 21 of the MOU, a Joint Committee of representatives of the United Kingdom government
and the Rwandan government is to be formed. The Joint Committee is to meet at least every six months.
The remit of the Joint Committee is as follows:

“21.2  The role of the Joint Committee will be to:

21.2.1 Monitor and review the application and implementation of this Arrangement and to make nonbinding recommendations in respect there of; and

21.2.2 Provide a forum for the Participants to exchange information, discuss best practise including
relevant guidance from external state holders, and resolve issues of a technical or administrative
character.”

23. The governments also agree to establish a Monitoring Committee comprising persons independent of
the two governments. It is intended that the Monitoring Committee will “monitor the entire relocation
_process from the beginning …”; report on conditions in Rwanda including reception conditions,_
accommodation, how asylum claims are processed, the treatment and support and given to those who are
transferred, and generally, on the implementation of the terms of the MOU: see generally, paragraph 15 of
the MOU.

24. Under the terms of the MOU the United Kingdom has agreed that “a proportion of Rwanda's most
_vulnerable refugees” will be settled in the United Kingdom (see paragraph 16)._

25. Financial arrangements have also been made between the two governments. These are referred to
but not set out, at paragraph 19 of the MOU. In a statement made for these proceedings, Kristian
Armstrong, Head of the Third Countries Asylum Partnerships Task Force at the Home Office states that the
United Kingdom paid £20 million to Rwanda on 29 April 2022 in respect to preparations to receive the first
group of asylum claimants. He states that under the terms referred to in the MOU the United Kingdom will
also make payments to meet the costs of processing claims, ensuring the safety and wellbeing of
claimants while their claims are pending, and to meet the cost of longterm welfare and integration needs of
all those who stay in Rwanda. For those who are granted refugee status or who qualify for humanitarian
protection the funding will be for 5 years. For those who do not so qualify but who remain in Rwanda the
funding will cover a 3-year period.

26. Mr Armstrong also states that in April 2022 the United Kingdom paid £120 million as an initial
contribution to an Economic Transformation and Integration Fund that intended to promote economic
development in Rwanda. Further payments to this fund are conditional on Rwanda's compliance with the
terms of the MOU.

27. The MOU also makes provision for management and protection of personal data transferred between
the governments during the operation of MOU: see at Annex A to the MOU.

(6)  The Home Secretary's assessment of Rwanda

28. On 9 May 2022 the Home Secretary published four documents comprising her “Review of Asylum
Processing” in Rwanda. The Home Secretary's overall assessment of the situation was set out in the
document “Rwanda: assessment” The conclusions in this document were supported by information in the


-----

Commissioner for Refugees intervening) and other case....

further documents: “Rwanda: Country Information on the Asylum System”; and “Rwanda: Country
Information on General Human Rights in Rwanda”. The fourth document “Rwanda: Interview Notes
(Annex

A) contained notes made by Home Office officials during two visits to Rwanda in January 2022 and March
2022. The Home Secretary also relies on these documents for the purposes of any decision that Rwanda
is a safe third country as defined at paragraph 345B of the Immigration Rules.

(7)  An outline of the decision-making process

29. In each of the claims before us the sequence of events has been similar and has followed the Home
Secretary's general approach to taking decisions under paragraphs 345A – D of the Immigration Rules,
and Schedule 3 to the 2004 Act, set out in the Inadmissibility Guidance.

30. Each Claimant was detained shortly after arrival in the United Kingdom, and was subject to the usual
steps applied to all newly-detained persons as described in the Home Secretary's guidance “Detention:
general instructions” (version 2.0, January 2022), and Detention Services Order 06/2013 (as revised in
August 2021). Among other matters, each person detained is: (a) subject to an assessment of his
language skills to determine proficiency in English; (b) assessed by healthcare staff (with a view to
deciding if further healthcare provision is required; (c) issued with a mobile phone and given information
about IT facilities at the detention centre; (d) given information about the centre's welfare officer; and (e)
given information on how to obtain legal representation, if he does not already have it, including information
on the free duty solicitor scheme.

31. Each Claimant made an asylum claim. Shortly after the claim was made (usually within a day or so),
each Claimant attended an asylum screening interview. Every asylum claimant attends such an interview.
The purpose of the interview is to obtain basic information about the claimant, his personal circumstances,
where he comes from, whether he has any particular health or other special needs, whether he has been
subject to forms of exploitation (such as forced work), how he came to the United Kingdom, and to give the
claimant an initial opportunity to explain the reasons why he cannot return to his home country. Every
asylum screening interview is conducted by reference

to a standard script. The questions put and the answers given are recorded on the standard form. Once
completed, a copy of the completed form is given to the asylum claimant.

32. Each case was then considered by the Home Office National Asylum Allocations Unit (“the NAAU”).
The Inadmissibility Guidance provides that if the NAAU suspects that the claimant “… may [in the course of
travelling to the United Kingdom] have spent time in or have a connection to a safe third country …” the
case must be referred to the Third Country Unit (“the TCU”) for consideration of whether an inadmissibility
decision should be taken. In the present cases, each Claimant's asylum claim was referred to the TCU.
The TCU then reviewed claims referred to it to determine whether they “… [appear] to satisfy paragraphs
345A and 345B of the Immigration Rules”. If a case falls into this category, the TCU issues the asylum
claimant with a Notice of Intent.

33. The Inadmissibility Guidance sets out a standard form of the Notice of Intent. The standard wording
includes the following”

“We have evidence that before you claimed asylum in the United Kingdom, you were present in or had a
connection to [name the safe country or countries]. This may have consequences for whether your claim is
admitted to the UK asylum system.

We will review your particular circumstances and the evidence in your case, and consider whether it is
reasonable to have expected you to have claimed protection in [country or countries] (or to have remained
there if you had already claimed or been granted protection), and whether we should consider removing
you there or elsewhere.

If your claim is declared inadmissible, we will not ask you about your reasons for claiming protection or
make a decision on the facts of your protection claim


-----

Commissioner for Refugees intervening) and other case....

We may, if inadmissibility action appears appropriate, make enquiries with one or more of the safe
countries mentioned above to verify evidence or to ask if, in principle, they would admit you.

(Optional paragraph below, to be used only if case is in scope for possible removal to Rwanda; remove
brackets if including paragraph:

We may also ask Rwanda, another country we consider to be safe, whether it would admit you, under the
terms of the Migration and Economic Development Partnership between Rwanda and the UK.)”

Each of the individual Claimants in these proceedings was issued with a Notice of Intent. In most cases,
this notice was served on them very shortly after the asylum screening interview (within a day or so of the
interview). The Notice of Intent also gives the asylum claimant the opportunity to make representations.
The standard wording (in the Inadmissibility Guidance) is in the following terms

“If you wish to submit reasons not already notified to the Home Office why your protection claim should not
be treated as inadmissible, or why you should not be required to leave the UK and be removed to the
country or countries we may ask to admit you (as mentioned above), you should provide those reasons in
writing within 7 calendar days [for detained cases] or 14 calendar days [for non-detained cases] of the date
of this letter. After this period ends, we may make an inadmissibility decision on your case, based on the
evidence available to us at that time.”

34. After the 7- or 14-day period (which the Home Secretary has stated could, in her discretion, be
extended on request) the Home Secretary then proceeded to take decisions on inadmissibility (under
§345A of the Immigration Rules), on removal (under §345C of the Rules), and on certification under
paragraph 17 of Schedule 3 to the 2004 Act. Those decisions were made on the Home Secretary's behalf
by the TCU. If representations made by an asylum claimant raised further matters, for example, that
removal from the United Kingdom would involve a breach of ECHR Convention rights, those claims were
also considered. The Home Secretary's practice was to issue two decision letters: one setting out the
decision on inadmissibility and removal; the other setting out the decision on any ECHR rights claim,
including on whether such claim had been certified in exercise of the power at paragraph 19(c) of Schedule
3 to the 2004 Act. The different decisions were taken by different Home Office teams: the TCU (based in
Glasgow) took the inadmissibility removal decisions; while the Detained Barrier Casework Team (based in
Croydon) took decisions on the human rights claims. The Home Secretary's practice was, at or around the
same time as the decision letters, also to issue removal directions. In the present cases, those directions
provided that unless the Claimant left the United Kingdom voluntarily he would be removed to Rwanda on
14 June 2022 (by plane to Kigali Airport).

35. As events turned out, there were two rounds of decisions. The first round of inadmissibility and
removal and human rights decisions were made at the end of May and beginning of June 2022. However,
after the commencement of these proceedings, the Home Secretary (of her own motion) decided to
reconsider each case, to take account of further representations received since the May/June 2022
decisions, and matters contained in the witness statements filed in these proceedings by the United
Nations High Commissioner for Refugees. These further decisions (on inadmissibility, removal and on the
human rights claims) were set out in decision letters dated 5 July 2022.

(8)  The issues

36. The pleadings in these proceedings are not models of good practice. Practice Direction 54A requires
Statements of Facts and Grounds to be clear and concise. None of the pleadings meets this requirement,
even though many if not all have been revised one or more times since the proceedings were issued. On
the Claimants' side the pleading in claim CO/2032/2022 (AAA and others) has taken pole position, setting
out various generic grounds of challenge as well as grounds specific to the facts of the cases of the
individual claimants in that case. Seven generic grounds of challenge are pleaded (Grounds 1, 1A – 1C,
2A and 3-6). However, these grounds tend to overlap or circle back on one another. Other claims brought
by other Claimants have adopted these generic grounds of challenge or formulated variations on them, as
well as pleading complaints based on their own circumstances. The pleading in CO/2056/2022 (the


-----

Commissioner for Refugees intervening) and other case....

_Asylum Aid case) raises complaints about the Home Secretary's decision-making procedure. What is said_
about procedural fairness in this case largely overlap with the complaints on procedural fairness raised in
CO/2023/2022 and other claims. Asylum Aid contends that these matters demonstrate there is systemic
unfairness in the procedure adopted to deal with the inadmissibility and removal decisions. The Home
Secretary pleading is a response in kind. The Amended Detailed Grounds of Defence (to all claims) runs
to some 215 pages.

37. At the court's request the parties prepared an agreed list of issues. However, that exercise failed to
simplify the position: the list identifies 29 generic issues, many of which are repetitive or overlapping; and
many more issues specific to each claim.

38. The same approach has been repeated in the Skeleton Arguments. Mention should be made of the
Skeleton Argument in CO/2032/2022 and CO/2104/2022 (262 pages), and the Skeleton Argument in
CO/2094/2022 (63 pages). Each comfortably exceeds the maximum length permitted by Practice Direction
54A (25 pages). Permission to file skeleton arguments longer than the maximum permitted was not
requested in advance; each document was presented to the court as a fait accompli. The length of these
documents has not served to clarify the way in which the various complaints are put. The documents
meander and repeat themselves. We have no doubt that these failings made it significantly more difficult
for counsel to present their cases clearly and effectively. Overall, it has become very easy to miss the
wood for the trees.

39. As we see it, on a fair reading of the claim forms, the written skeleton arguments and the oral
submissions the generic issues raised in these proceedings come to this.

(1) The Home Secretary's conclusion that Rwanda is a safe third country is legally flawed. The Claimants'
primary contention is that this assessment is contrary to article 3 of the ECHR. This rests on: (a) the
decision of the European Court of Human Rights in Ilias and Ahmed v Hungary (2020) 71 EHRR 6 that a
state cannot remove an individual asylum-seeker without determining his asylum claim unless it has
established that there are adequate procedures in place in the country to which he is to be removed which
will ensure that the individual's asylum claim is properly determined and he does not face a risk of
refoulment to his country of origin; (b) the submission that removal of the individual Claimants to Rwanda
will put them at real risk of article 3 ill-treatment (in breach of the principle recognised in _Soering:_ see
judgment of the European Court of Human Rights (1989) 11 EHRR 439) and (c) the contention that,
systemically, it is inevitable that the policy to remove asylum claimants to Rwanda will lead to occasions
when a person will be subjected to article 3 ill-treatment. Essentially the same submission is also put on
the basis that the conclusion that Rwanda is a safe third country has not taken account of relevant matters,
is the result of insufficient enquiry, rests on material errors of fact, and/or is irrational.

(2) One matter that is central to the Claimants' case, regardless of the legal basis on which the claim is
put, is the contention that the asylum claims of those relocated to Rwanda will not be determined
effectively in Rwanda thereby running the risk that asylum seekers will be refouled from Rwanda – i.e.,
removed from Rwanda either directly to their country of origin (the place where they allege they were and
would be the subject of treatment contrary to the Refugee Convention), or removed from Rwanda to some
other country from where they could be removed to the country of origin. A range of criticisms is made of
the scope of protection available under Rwandan law which is said not to be consistent with the
requirements of the Refugee Convention, of the practices of the Rwandan authorities dealing with asylum
claims, and the capacity of the Rwandan authorities (including the Rwandan courts) to decide asylum
claims in accordance with the requirements of the Refugee Convention. In addition, complaint is made of
the way in which asylum seekers relocated to Rwanda will be treated. Overall, the Claimants contend that
the Home Secretary is not entitled to have confidence that the Rwandan government will honour its
obligations under the MOU and the Notes Verbales which would ensure proper consideration of an asylum
claim and which would prevent such treatment occurring. That submission is supported by the High
Commissioner.


-----

Commissioner for Refugees intervening) and other case....

(3) The Home Secretary has used the power of certification under paragraph 17 of Schedule 3 to the 2004
Act improperly. That power was only intended to be used on an ad hoc basis in individual cases. It is not
appropriate to use paragraph 17 in support of a general scheme such as the Rwanda policy. Rather than
use paragraph 17 (which is in Part 5 of Schedule 3 to the 2004 Act), the Home Secretary should have had
resort to Part 2 of the Schedule, with the consequence that her policy of removal to Rwanda would have
required Parliamentary consideration and approval.

(4) The inadmissibility decisions rest on a misunderstanding or misapplication of the Immigration Rules
because the requirements in paragraph 345A of the Immigration Rules are only met if an asylum seeker
had a relevant connection with the safe third country to which he is being returned, in this case Rwanda.
Removal to Rwanda cannot be the consequence of failure to make an asylum claim in another safe third
country such as France or another European country whilst on the way to the United Kingdom. Further, the
Home Secretary's practice of seeking Rwanda's agreement to a transfer before making decisions under
paragraph 345A is in breach of paragraph 345C of the Immigration Rules.;

(5) The Home Secretary's Inadmissibility Guidance is unlawful because: (a) it does not include guidance
for decision-makers on how to exercise the discretion to treat a claim as inadmissible; and/or (b) because it
contains rules that on a proper application of section 3 of the Immigration Act 1971, should have formed
part of the Immigration Rules and be approved by Parliament. The Claimants also contend that the
Inadmissibility Guidance is not complete such that, at least in part, the Home Secretary's inadmissibility
decisions have been taken in furtherance of an “unpublished policy”;

(6) The decisions to remove asylum claimants to Rwanda are contrary to retained EU law, specifically, the
provisions in Directive 205/85/EC “On minimum standards on procedures in Member States for granting
and withdrawing refugee status”.

(7) Removal of an asylum seeker to Rwanda is inconsistent with article 33, or constitutes the imposition of
a penalty contrary to article 31, of the Refugee Convention and so would involve a breach of section 2 of
the Asylum and Immigration Appeals Act 1993 (“1993 Act”). Further, it is said that is inherent in article 33 of
the Refugee Convention that the United Kingdom must determine a claim for asylum made in the United
Kingdom and cannot relocate an asylum seeker to a third country for that country to determine his asylum
claim. Generally, the Claimants submit that the Home Secretary's use of powers under the Immigration
Rules to give effect to the Rwanda policy amounts to a breach of the obligation in section 2 of the 1993 Act
not to adopt any practice in the Immigration Rules that is contrary to the Refugee Convention.

(8) In the course of deciding whether to remove persons to Rwanda, the Home Secretary has acted
[contrary to the Data Protection Act 2018 and the UK GDPR.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)

(9) The Inadmissibility Guidance is the cause of discrimination on grounds of nationality, age, sex, and
disability. It also promotes discrimination against persons who make claims for asylum, as opposed to
those who seek leave to enter the United Kingdom on other grounds.

(10) The Home Secretary's decision to adopt the Inadmissibility Guidance was irrational because she
ought first to have sought either (a) parliamentary approval for the policy; and/or (b) the approval of HM
Treasury.

(11) When formulating her Rwanda policy, the Home Secretary failed to comply with the requirements of
section 149(1) of the Equality Act 2010 (“the 2010 Act”) (the public sector equality duty).

(12) The process by which inadmissibility decisions are taken is unfair. The principal target of this
complaint is that the Notice of Intent served by the Home Secretary before any inadmissibility or removal
decision is taken, allows only seven days for representations to be made that no such decision should be
made. Other complaints are also made about the procedure followed when decisions are taken.

The Home Secretary disputes each of the grounds of challenge. She further contends that the
organisations that are Claimants in CO/2032/2022, i.e., the PCSU, Care4Calais and Detention Action, do


-----

Commissioner for Refugees intervening) and other case....

not have standing to bring the challenges raised in that case. All these issues are addressed in the next
section of the judgment save for issue (12) which is considered in Section D of the judgment.

40. Further, each of the Claimants who has been the subject of decisions and removal directions,
challenges those decisions by reference to his own facts and circumstances. These matters are addressed
at Section C of this judgment, together with the further claims (made by some of the individual Claimants)
that the Home Secretary acted unlawfully in refusing their human rights claims and certifying those claims
as clearly unfounded.

_(9)                        Which decisions are operative decisions?_

41. During the hearing questions arose as to which decisions were or ought to be the subject of the
Claimants' challenges and the court's consideration. We do not consider this is an issue that affects any
question going to the legality of decisions taken by the Home Secretary. Rather, it goes only to the correct
analysis of the sequence of decisions going back to May 2022. There are two matters to consider. The
first concerns the documents published by the Home Secretary on 9 May 2022: the four Rwanda
assessment documents and the Inadmissibility Guidance. The former four documents contain
assessments relevant to the Home Secretary's conclusion that Rwanda is a safe third country; the latter
one contains statements of the Home Secretary's approach to use of the powers under the Immigration
Rules to declare asylum claims inadmissible and remove asylum claimants to safe third countries, and also
a statement of the procedure to be used to take decisions on inadmissibility. Ought any issue that goes to
the legality of decisions contained in any of these documents be assessed as at the date of publication or
at the date of the inadmissibility decisions? We consider the latter approach is correct. As at the date they
were published, no decision contained in any of these documents affected any of the Claimants. The May
2022 Rwanda assessment documents set out the Home Secretary's opinion on a range of matters relevant
to whether Rwanda is a safe third country. They were, and are, matters the Home Secretary intended to
rely on when taking decisions under the Immigration Rules, specifically any decision under paragraph
345C. However, these matters were preparatory. Any decision under paragraph 345C of the Immigration
Rules to remove a person to Rwanda would require consideration of both general matters (such as those
at paragraph 345B(ii) to (iv)) and matters specific to the person concerned (see paragraph 345B(i)), and
those matters whether general or specific would have to be addressed by the Home Secretary at the time
of the decisions to remove to Rwanda. Thus, nothing is to be gained by considering the May 2022
documents in isolation from the use to which they were put when the decisions under the Immigration
Rules were taken.

42. The second matter concerns the inadmissibility and removal decisions. There were two rounds of
decisions, the first at the end of May and beginning of June, the second on 5 July 2022. Do the July 2022
decisions supersede the May and June decisions? Each of the July decision letters states that it is “… to
be read in conjunction with …” the earlier decision letter. We do not consider that this form of words
requires us to assess the legality of the May and June decisions discreetly from the July decisions. The
form of words was probably included out of an abundance of caution. In all other respects it is apparent
that the July decision letters are free-standing and are intended to be comprehensive statements of the
Home Secretary's reasons for the decisions concerned. All this being so, the correct focus is on the July
2022 decision letters. Below, in Section C of this judgment where the challenges specific to the facts of
each of the individual Claimants are addressed, we have considered both the earlier (May and June 2022)
decisions and the 5 July 2022 decisions. In claims where we have decided to quash the 5 July 2022
decision we have also quashed the earlier decision. But that is simply to make it clear that in those cases
the Home Secretary must consider afresh all decisions (whether under the Immigration Rules, or the 2004
Act, or decisions on human rights claims).

B.  Decision on the generic grounds of challenge

_(1) The first and second issues. Was the assessment that Rwanda is a safe third country legally flawed?_


-----

Commissioner for Refugees intervening) and other case....

43. The Claimants' primary submission is that the Home Secretary's decisions under paragraph 345C of
the Immigration Rules to remove the individual Claimants to Rwanda were unlawful because the
conclusion that Rwanda is a “safe third country” (as defined in paragraph 345B of the Rules) is legally
flawed. This same contention is put in a number of different ways: that the conclusion that Rwanda meets
the criteria at 345B: (a) amounts to a breach of article 3 of the ECHR for the reasons explained by the
European Court of Human Rights in Ilias and Ahmed v Hungary (2020) 71 EHRR 6 namely that the asylum
claims of those relocated to Rwanda would not be effectively determined in Rwanda and the asylum
claimants run a risk that they will be refouled directly or indirectly to the country where they experienced
treatment contrary to the Refugee Convention ; (b) rests on material errors of fact, or a failure to comply
with the obligation in _Tameside v Secretary of State for Education and Science [1977] AC 1014(the_
obligation to ensure the decision rests on a sufficient factual basis by taking reasonable steps to obtain
relevant information); (c) is an irrational conclusion; and/or (d) is part of a policy which is unlawful in the
sense explained in Gillick v West Norfolk and Wisbech AHA [1986] AC 997in that it positively authorises or
approves removals that would be in breach of article 3 of the ECHR (i.e. exposes persons to a real risk of
article 3 ill-treatment)..

44. For the purposes of these submissions, the relevant decision is one which concerns whether,
generally, Rwanda (a) complies with its obligations under the Refugee Convention of non-refoulement (the
criterion at paragraph 345B(ii)); (b) will meet the related requirement (at paragraph 345B(iii)) not to remove
persons if that would put them at risk of ill-treatment contrary to ECHR article 3; and (c) would permit the
person the Home Secretary wishes to remove, to make a claim for asylum, effectively to determine that
claim, and provide protection as required by the Refugee Convention if the claim is upheld (the criterion at
paragraph 345B (iv)). The Claimants also submit that removal to Rwanda would be in breach of article 3 of
the ECHR in the sense of the Soering principle because there are reasonable grounds for believing that if a
person is removed to Rwanda that will expose him to a real risk of article 3 ill-treatment because of the
conditions in Rwanda

45. Although the legal argument is put on various different bases, all converge on two issues: the first is
whether the Home Secretary's conclusion, absent considerations of any matter arising from the particular
circumstances of a specific claimant, that Rwanda meets the criteria for being a “safe third country” as
defined at paragraph 345B(ii) to (iv) of the Immigration Rules, was a conclusion based on sufficient
evidence and thorough assessment; the second is whether the Home Secretary could lawfully reach the
conclusion that the arrangements governing relocation to Rwanda would not give rise to a real risk of
refoulment or other ill-treatment contrary to article 3 of the ECHR. Thorough Examination and Reasonable
_Inquiries_

46. The information available to the Home Secretary for this purpose has expanded during the life of this
litigation. As at the time of the original removal decisions (May and June 2022), the information available to
the Home Secretary was set out in the Rwanda assessment documents published on 9 May 2022, referred
to at paragraph 28 above (“the 9 May assessment documents”). Those documents rested on a range of
sources including information obtained by Home Office officials during visits to Rwanda in January and
March 2022, and information published by the US State Department, the UNHCR, the Committee against
Torture (the committee established under article 17 of the UN Convention against Torture and other
Inhuman or Degrading Treatment or Punishment – “UNCAT”), and non-governmental organisations such
as Human Rights Watch.

47. The United Nations High Commissioner for Refugees (“the UNHCR”) has filed three witness
statements. For present purposes the most significant is the statement of Lawrence Bottinick made on 26
June 2022. That sets out, in some detail, the UNHCR's evidence and opinion on the asylum system in
Rwanda. The information in that statement both goes beyond, and is a little different from, information
previously published by the UNHCR on Rwanda (for example in its “Universal Periodic Review” document
on Rwanda dated July 2020). Generally, Mr Bottinick is critical of the scope of Rwandan law, and the
competence and the capacity of the Rwandan asylum system effectively to determine asylum claims.
Further, we have seen documents prepared by the Rwandan authorities that respond to the matters raised


-----

Commissioner for Refugees intervening) and other case....

by Mr Bottinick. All this additional information was considered by Home Office officials for the purposes of
the further removal decisions made for each of the individual Claimants on 5 July 2022.

48. The Claimants' submission rested heavily on the judgment of the European Court of Human Rights in
_Ilias and Ahmed v Hungary. As we see it, Ilias is an example of the application of the principle in Soering_
in the context of a decision to remove an asylum claimant whose asylum claim has not been determined on
its merits. In _Ilias the circumstances were as follows. In July 2015 the Hungarian asylum authority_
determined in exercise of powers under Hungarian law that, presumptively, Serbia was a “safe third
country”. In September 2015, the claimants, who were nationals of Bangladesh, entered Hungary via
Serbia. They remained in a transit zone on the border between the two countries. They claimed asylum in
Hungary, but those claims were rejected as inadmissible because the claimants had arrived in Hungary
from Serbia. On 8 October they were escorted back to Serbia.

49. The European Court of Human Rights concluded the removal decisions were in breach of article 3.
The Court stated that removal of an asylum claimant whose claim had not been determined on its merits,
would amount to a breach of article 3 if “adequate asylum procedures protecting [the claimant] against
refoulement” were not in place in the receiving state (see the judgment at paragraph 134). The Court
further concluded that if a state wished, consistently with article 3 of the ECHR, to remove an asylum
claimant without first determining his asylum claim on its merits, it should “examine thoroughly whether [the
receiving country's] asylum system could deal adequately with those claims. At paragraph 139 – 141 the
court said as follows:

“139. … On the basis of the well-established principles underlying its case-law under art.3 of the
Convention in relation to expulsion of asylum-seekers, the Court considers that the above-mentioned duty
requires from the national authorities apply the “safe third country” concept to conduct a thorough
examination of the relevant conditions in the third country concerned and, in particular the accessibility and
reliability of its asylum system.

…

140. Furthermore, a number of the principles developed in the Court's case-law regarding the assessment
of risks in the asylum-seeker's country of origin also apply, mutatis mutandis, to the national authorities'
examination of the question whether a third country from which the asylum-seeker came is “safe”.

141. In particular, while it is for the persons seeking asylum to rely on and to substantiate their individual
circumstances that the national authorities cannot be aware of, those authorities must carry out of their
own motion an up-to-date assessment, notably, the of the accessibility and functioning of the receiving
country's asylum system and the safeguards it affords in practice. The assessment must be conducted
primarily with reference to the facts which were known to the national authorities at the time of expulsion,
but it is the duty of those authorities to seek all relevant generally available information to that effect.
Generally, deficiencies well documented in authoritative reports, notably of the UNHCR, Council of Europe
and EU bodies, are in principle considered to have been known. The expelling state cannot merely
assume that the asylum-seeker will be treated in the receiving third country in conformity with the
Convention standards but, on the contrary, must first verify how authorities of that country apply their
legislation on asylum in practice.”

The court accepted that its task was to consider whether as the claimants contended, there were “clear
indications that [persons removed] would not have access in Serbia to an adequate asylum procedure
capable of protecting them against refoulment” (see the judgment at paragraph 144).

50. On the facts of that case, the Court concluded that the July 2015 decision that Serbia was,
presumptively, a safe third country, had not rested on the required thorough assessment.

“153. The presumption at issue in the present case was put in place in July 2015, when Hungary changed
its previous decision and declared Serbia to be a safe third country. The Government's submissions before
the Grand Chamber appeared to confirm that the grounds for this change consisted exclusively of the
following: Serbia was bound by the relevant national conventions; as a candidate to become an EU


-----

Commissioner for Refugees intervening) and other case....

Member State it benefitted from assistance in improving its asylum system; and there was an
unprecedented wave of migration and measures had to be taken.

154. The Court notes, however, that in their submission to the Court the respondent Government have not
mentioned any facts demonstrating that the decision-making process leading to the adoption of the
presumption in 2015 involved a thorough assessment of the risk of lack of effective access to asylum
proceedings in Serbia, including the risk of refoulement.

…

158. The Court is not convinced, however, by the respondent Government's argument that the
administrative authorities and national court thoroughly examined the available general information
concerning the risk of the applicants' automatic removal from Serbia without effective access to an asylum
procedure. In particular, it does not appear that the authorities took sufficient account of consistent general
information that at the relevant time asylum-seekers returned to Serbia ran a real risk of summary removal
the Republic of North Macedonia and then to Greece and therefore, of being subjected to conditions
incompatible with Art.3 in Greece.”

Thus, held the Court, there was an insufficient basis for the decision to establish a general presumption
that Serbia was a safe third country (see the judgment at paragraph 163).

51. For present purposes, a relatively brief description of the Rwandan asylum procedure will suffice.
Rwanda is a signatory to the Refugee Convention. Rwanda has a significant history of providing asylum to
refugees fleeing local conflict. In July 2020, the UNHCR reported that since 1990, Rwanda had maintained
a “open door” policy to refugees from neighbouring countries, and that there were nearly 149,000 refugees
in Rwanda. The overwhelming majority were from the Democratic Republic of Congo and the Republic of
Burundi. Rwanda has also supported the UNHCR “emergency transport mechanism” which, since 2019,
has assisted a little over 1,000 asylum seekers to be removed from Libya to Rwanda. Once in Rwanda,
their claims are processed by the UNHCR and claimants have, to date, been resettled by the UNHCR in
third countries. Mr Bottinick's evidence was that at present, some 440 asylum claimants are in Rwanda
under this scheme.

52. Persons who have fled to Rwanda from neighbouring countries have been permitted to remain in
Rwanda without going through any formal asylum determination process. The Rwandan system for
determining asylum claims has only been used to determine claims made by those coming from further
afield. This is a small number of cases. The UNHCR estimated that in the last 3 years there have been
approximately 300 cases. Asylum claims must be registered with the Directorate General of Immigration
and Emigration (“the DGIE”). The DGIE will interview the claimant, issue him with a residence permit and
forward the case to the Refugee Status Determination Committee (“the RSDC”). The RSDC comprises 11
members drawn from 11 ministries and government departments. Each holds his position ex-officio;
membership of the RSDC will be only one part of the person's overall responsibilities. The RSDC
determines the asylum claim. There is a right of appeal to the Minister for the Ministry in Charge of
Emergency Management, the government department with responsibility for, among other matters, refugee
affairs. There is a further appeal from the Minister to the High Court of Rwanda. That is an appeal in the
way of re-hearing.

53. The Claimants' submission as to the position in Rwanda relies heavily on the information contained in
the statements made by Mr Bottinick. The Claimants contend as follows.

(1) There are instances where the Rwandan authorities have refused to register claims for asylum. To the
UNHCR's knowledge there have been 5 occasions (involving claimants from Libya, Syria and Afghanistan)
where a person has made an asylum claim to the DGIE, but the DGIE refused to accept the claim as a
valid claim. Those claims were made at Kigali Airport in Rwanda and the asylum claimants were refused
entry to and, ultimately were removed from Rwanda. Generally, Mr Bottinick is critical of the DGIE not just
in terms of its approach to registering asylum claims but also when it comes to interviewing asylum
claimants. He says the airport cases are an indication that the DGIE discriminates against those who are


-----

Commissioner for Refugees intervening) and other case....

not nationals of neighbouring states and, especially, against persons from middle eastern countries. He
says the DGIE has on other occasions refused to interview asylum claimants. He suggests the DGIE may
discriminate against asylum claimants who are lesbian, gay, bisexual, trans-sexual or inter-sex. He says
the UNHCR is aware of two such cases. Mr Bottinick also says that when the DGIE refuses to refer a
claim to the RSDC it does not give reasons for its decision. When interviews do occur, he says no record
of the interview is provided to the asylum claimant.

(2) Mr Bottinick also considers the process before the RSDC is inadequate. The members of the RSDC
are not expert or trained in asylum law. He gives examples of three occasions when the RSDC refused to
see the asylum claimant. When hearings have taken place, they are too short to give claimants a fair
chance to make their case, and hearings tend to lack focus because of the size of the RSDC. There are no
interpreters at RSDC hearings which significantly prejudices claimants who speak neither French nor
English. The RSDC does not allow claimants to be represented by lawyers. The RSDC does not provide
proper reasons for decisions; decisions tend to be all in a standard form that simply informs the claimant of
the outcome.

(3) Mr Bottinick is sceptical about the value of the appeal to the Minister. He says the UNHCR is not
aware of any case where the Minister has reversed a decision of the RSDC. He also points out that legal
representatives are not available for appeals to the Minister. Ministerial decisions are also in standard form
and are not properly reasoned.

(4) Mr Bottinick also says that the lack of reasoned decisions from the RSDC and the Minister impedes
effective use of the right of appeal to the High Court. This right of appeal was introduced in 2018. There is
no evidence that such appeals have been filed with or heard by the High Court.

(5) Rwandan asylum law is said to be defective. Mr Bottinick refers to a

“protection gap”. He says that the definition of “political opinion” in article 7 of Rwanda's 2014 Law on
Asylum does not cover the possibility of protection against persecution on grounds of imputed political
opinion or from the risk of ill treatment by non-state actors.

(6) Mr Bottinick's opinion is that the Rwandan asylum system lacks the capacity and expertise necessary
to deal effectively with asylum claims. This is material in two ways. Important aspects of asylum law may
not be properly understood and properly applied. As an example, Mr Bottinick says that “it can be difficult
for decision-makers to understand” that asylum claims should not be denied on the premise that the
claimant could hide a characteristic protected under the Refugee Convention, such as his political opinion
or sexual orientation. Further, the Rwandan system will not be able to cope with the volume of claims
generated by the MEDP. Mr Bottinick comments that claimants in the Rwandan asylum system have
insufficient access to legal assistance and interpretation services are not available. He also raises a
concern that details of asylum claimants and their claims may not have been treated as confidential and
information may have been passed to the asylum claimants' countries of origin.

54. The overall submission made by all Claimants is that the Rwandan asylum system is not adequate to
prevent the risk of refoulement. In this context, refoulement is the term the Claimants use to cover a range
of different scenarios. One example is that Mr Bottinick referred to the 5 cases where the DGIE refused to
register claims made at airports as “airport refoulement”. The use of the same word to describe so many
different matters risks confusion. But, however the term is used, the point of substance is the contention
that asylum claims raised in Rwanda either will not be considered at all, or will not be properly determined
on their merits. Either scenario raises the risk that an asylum claimant who ought to receive protection
from Rwanda, will not do so, and that even though Rwanda is a signatory to the Refugee Convention it will
not ensure there will be no breach of article 33 of the Refugee Convention, whether directly or indirectly, in
any case.

55. In her response, the Home Secretary takes issue with the details in Mr Bottinick's statement. Much of
what he says is disputed by the Rwandan authorities. It is not necessary for the purposes of this judgment
to address every such point. We note only two matters. The first concerns the state of Rwandan asylum


-----

Commissioner for Refugees intervening) and other case....

law. The Home Secretary observes that in the July 2020 “Universal Periodic Review” the UNHCR
described the 2014 Law relating to Refugees” as “fully compliant with international standards”. There was
no suggestion of any “protection gap”. Further, as enacted, article 7 of the 2014 Law exactly follows the
language of article 1 of the Refugee Convention. The protections given in respect of matters such as
imputed opinion or persecution at the hands of non-state actors, have all been derived from article 1 of the
Refugee Convention and there is no reason to think that article 7 of the Rwandan Law is not and will not be
interpreted and applied to the same effect. Forensically (by reference to the UNHCR July 2020 document),
and as a matter of language (comparing article 1 of the Refugee Convention and article 7 of the Rwandan
Law) that submission is correct. However, since no party advanced evidence on Rwandan law the matter
cannot be taken any further.

56. The other point concerns whether the Rwandan authorities have maintained the confidentiality of
asylum claimants and their claims. This arose from one of the responses provided by the Rwandan
authorities in response to Mr Bottinick's evidence.

One email refers to the fact that when considering an asylum claim, the RSDC may seek information
“about a specific event/situation in the asylum seeker's country of origin”. Considered in context, we are
satisfied this is a reference to the RSDC asking the relevant Rwandan embassy or High Commission
abroad for information, and not a reference to questions being asked with the authorities in the asylum
seeker's country of origin.

57. The Home Secretary's primary response to this part of the claim and to the legal issues referred at
paragraph 43 above is reliance on the MOU and the Notes Verbales made under it. We have referred to
these already at paragraph 18 – 27 above. For present purposes the material matters arising are as
follows:

(1) The purpose of the MOU is to establish a mechanism for the asylum claims to be decided in Rwanda
(MOU, paragraph 2.1).

(2) The numbers of persons to be removed to Rwanda under the terms of MOU is to be agreed and will
take account of Rwanda's capacity to receive them and comply with the obligations under the MOU in
respect of that group (MOU, paragraph 3.3).

(3) Rwanda has agreed to give persons transferred access to its territory “in accordance with its
international commitments and Rwandan asylum and immigration laws” (MOU, paragraph 7.1).

(4) Rwanda has agreed to process the asylum claims in accordance with the Refugee Convention and
Rwandan national law and in accordance with international human rights standards (MOU, paragraph
9.1.1); and has agreed claimants will have access to “independent and impartial due process of appeal” in
accordance with Rwandan law (MOU, paragraph 9.1.3).

(5) Rwanda has agreed to provide support to transferred asylum claimants both before and after their
claims are decided (MOU, paragraph 5; and MOU, paragraph 20), and the Support NV including to those
whose asylum claims are refused.

(6) The Asylum Process NV contains a range of further promises on access to the asylum process
(paragraph 3); that decisions will be taken within a reasonable time by decision makers who are
appropriately trained and who have appropriate support of officials or “external experts if necessary”
(paragraph 4.2); that claimants will be appropriately interviewed so as to establish their claims (paragraph
4.3); that interpretation services will be provided and a record made of the interview (paragraph 4.4); that
claims will be decided on their merits (paragraph 4.5 and 4.6); that decisions will be recorded and
supported by reasons (paragraph 4.7 and 4.9); that on appeal to the Minister, written and oral submissions
may be made, and legal representatives will have the opportunity to make representations (paragraph 5.1
to 5.2); that appeals to the High Court will be by way of “full re-examination” and will permit representations
to be made by the asylum claimant and their legal representatives (paragraph 5.4 and 5.5); that
interpretation services will be provided free of charge both at all stages of the process and to permit


-----

Commissioner for Refugees intervening) and other case....

claimants to communicate with their legal representatives (paragraph 9); and that claimants will be
permitted access to

legal advice at each stage of the asylum process and, for appeals to the High Court, will be provided with
legal assistance free of charge (paragraph 8).

58. The Home Secretary's submission is that the provision made by the MOU and the Notes Verbales is
sufficient, when taken together with the steps that she took to investigate the matters covered in the 9 May
2022 Rwanda assessment documents, for the purposes of the obligation identified by the European Court
of Human Rights in _Ilias; is sufficient for the purposes of discharging the_ _Tameside_ obligation; and
permitted her rationally to conclude that Rwanda does meet the criteria at paragraph 345B(ii) to (iv) of the
Immigration Rules to be a safe third country.

59. We accept that the Home Secretary did comply with the obligations identified in Ilias. The 9 May 2022
assessment documents are a “thorough examination” of “all relevant generally available information” of the
type envisaged by the European Court of Human Rights in that case. The Claimants submitted that the 9
May 2022 assessment documents had been subject to adverse comment by the Asylum Research Centre
which had reviewed the documents at the request of the Independent Advisory Group of Country
Information. That report is dated July 2022. The Independent Advisory Group provides advice to the Chief
Inspector of the UK Border Agency to allow him to discharge his obligation under section 48(2)(j) of the UK
Borders Act 2007, to make recommendations to the Home Secretary on “the content of information on
conditions outside the United Kingdom which the [Home Secretary] compiles and makes available for
purposes connected with immigration and asylum to immigration officers and other officials”.  The 9 May
2022 assessment documents comprise such information. The July 2022 report is part of the process which
will, in due course, enable the Chief Inspector to make such recommendations in respect of the 9 May
2022 assessment documents as he considers appropriate. That process is not yet complete; the Chief
Inspector is yet to decide which aspects of the July 2022 report should form part of his recommendations.
Be that as is may, we do not consider that any of the matters highlighted by the July 2022 report (whether
considered individually or in the round) are sufficient to demonstrate any breach of the Ilias obligation. For
example, several of the comments highlighted by the Claimants referred to a lack of explanation of the
terms of the MOU and the _Notes Verbales in the 9 May assessment documents. Even assuming those_
comments are warranted, they are not relevant to compliance with the _Ilias_ obligation since it is beyond
argument that the MOU and _Notes Verbales were considered, together with the 9 May assessment_
documents, at the time the removal decisions were made.

60. Further, in compliance with the Ilias duty, when making the 5 July 2022 removal decisions the Home
Secretary also considered the information by then filed in these proceedings by the UNHCR.

61. Next, we are satisfied that the same matters show that the Home Secretary complied with the duty in
the Tameside case. That duty was formulated by Lord Diplock as follows: “… the question for the court is
did the Secretary of State ask himself the right question and take reasonable steps to acquaint himself with
the relevant information to enable him to answer it correctly?” (see [1977] AC 1014at page 1065A to B,
emphasis added). It is for the public body to determine the manner and intensity of the inquired to be
undertaken, subject to judicial review on public law principles (see R (Khatun) v Newham London Borough
_Council [2005] QB 37esp. at paragraph 35). If anything, that obligation, which is an aspect of Wednesbury_
principles, is a less onerous obligation

than the Ilias obligation. However, in any event and in this case, the exercise of compiling the 9 May 2022
assessment documents, negotiating the MOU and the _Notes Verbales, and consideration of the further_
information that became available from the UNHCR and the Rwandan authorities after these proceedings
had been commenced, is sufficient to meet the Tameside obligation.

Adequacy of Asylum System

62. Next we consider whether the Home Secretary was entitled to conclude that there were sufficient
guarantees to ensure that asylum-seekers relocated to Rwanda would have their asylum claims properly


-----

Commissioner for Refugees intervening) and other case....

determined there and did not run a risk of refoulment in accordance with the obligations in _Ilias_ and that
Rwanda was a safe third country in accordance with the criteria in paragraph 345B(ii) to (iv) of the
Immigration Rules. That raises the question of whether she was entitled to place the reliance that she did
on the assurances provided by the Rwandan government in the MOU and the Notes Verbales. On their
face, the obligations arising from those documents address all significant concerns raised in the UNHCR's
evidence including the possibility that asylum claims would not be registered by the DGIE or would not be
progressed by the DGIE and the RSDC; and concerns raised as to the nature and conduct of proceedings
before the RSDC, the availability of interpretation services, access to legal advice, and provision of
reasoned decisions.

63. The Claimants rely on the approach set out by the European Court of Human Rights in _Othman v_
_United Kingdom (2012) 55 EHRR 1. There, the Court considered the sufficiency of assurances given by_
the Kingdom of Jordan to the United Kingdom in the context of a contention that deporting Mr Othman to
Jordan would put him at real risk of article 3 ill-treatment. At paragraphs 188 to 189 the Court stated as
follows:

“188. In assessing the practical aspect of assurances and determining what weight is to be given to them,
the preliminary question is whether the general human-rights situation in the receiving state excludes
accepting any assurances whatsoever. However, it will only be in rare cases that the general situation in a
country will mean that no weight at all can be given to assurances.

189. More usually, the Court will assess first, the quality of assurances given and, second, whether, in light
of the receiving state's, practices they can be relied upon. In doing so, the Court will have regard inter alia
to the following factors:

(1) Whether the terms of the assurances have been

disclosed to the Court;

(2) Whether the assurances are specific or are general and vague;

(3) Who has given the assurances and whether that person can bind the receiving state;

(4) If the assurances have been issued by the central government of the receiving state, whether local
authorities can be expected to abide by them;

(5) Whether the assurances concerns treatment that is

legal or illegal in the receiving state;

(6) Whether they have been given by a Contracting State;

(7) The length and strength of bilateral relations between the sending and receiving states, including the
receiving state's record in abiding by similar assurances;

(8) Whether compliance with assurances can be objectively verified through diplomatic or other monitoring
mechanisms, including providing

unfettered access to the applicant's lawyers;

(9) Whether there is an effective system of protection against torture in the receiving state, including
whether it is willing to co-operate with international monitoring mechanisms (including international humanrights NGOs), and whether it is willing to investigate allegations of torture and to punish those responsible;

(10) Whether the applicant has previously been ill-treated in the receiving state;

(11) Whether the reliability of the assurances has been examined by the domestic courts of the

sending/Contracting State.”

The Court's list was not intended to be either prescriptive or exhaustive. Rather it is intended to indicate
that when (as in the present proceedings) what is in issue is the risk of article 3 ill-treatment, the court's


-----

Commissioner for Refugees intervening) and other case....

approach must be rigorous and pragmatic notwithstanding that ultimately it is an assessment to be
undertaken recognising that the court must afford weight to the Home Secretary's evaluation of the matter.
That approach will rest on a recognition of the expertise that resides in the executive to evaluate the worth
of promises made by a friendly foreign state.

64. In the present case we consider the Home Secretary is entitled to rely on the assurances contained in
the MOU and Notes Verbales, for the following reasons. The United Kingdom and the Republic of Rwanda
have a well-established relationship. This is explained in the witness statement of Simon Mustard, the
Director, Africa (East and Central) at the Foreign, Commonwealth and Development Office. This has
comprised a development partnership set out in various agreements (referred to as Development
Partnership Agreements) since 1998. The relationship is kept under review. In 2012 it was suspended by
the United Kingdom government in response to Rwanda's involvement in the so-called “M23 Rebellion” in
the Democratic Republic of Congo, and in 2014 the relationship was further reviewed in response to the
assassination in South Africa of a Rwandan dissident. Since then, the United Kingdom has continued to
provide Rwanda with financial aid, but this has been tied to specific activities. Thus, while there is a
significant history of the two governments working together, the Rwandan government has reason to know
that the United Kingdom government places importance on Rwanda's compliance in good faith with the
terms on which the relationship is conducted.

65. The terms of the MOU and Notes Verbales are specific and detailed. The obligations that Rwanda has
undertaken are clear. All, in one sense or another, concern Rwanda's compliance with obligations it
already accepts as a signatory to the Refugee Convention. The Claimants have placed particular
emphasis on whether the Rwandan asylum system will have the capacity to handle asylum claims made by
those who are transferred under the terms of MOU. It is a fair point that, to date, the number of claims
handled by the Rwandan asylum system has been small. It is also fair to point out, as Mr Bottinick has,
that it will take time and resources to develop the capacity of the Rwandan asylum system. However,
significant resources are to be provided under the MEDP, and by paragraph 3.3 of the MOU the number of
persons that will be transferred will depend on the consent of the Rwandan government, taking account of
its capacity to deal with persons in the way required under the MOU and the Notes Verbales. The MOU
also contains monitoring mechanisms in the form of the Joint Committee (paragraph 21 of the MOU) and
the Monitoring Committee (paragraph 15 of the MOU). For now, at least, there is no reason to believe that
these bodies will not prove to be effective. Lastly, the MOU makes provision for significant financial
assistance to Rwanda. That is a clear and significant incentive towards compliance with the terms of the
arrangement.

66. Moreover, Mr Mustard explains that HM Government is satisfied that Rwanda will honour its
obligations. At paragraph 20 of his statement, he says this:

“The British High Commission in Kigali led initial conversations with the [Government of Rwanda] regarding
the [MEDP] and participated in negotiations in support of the Home Office. Since these negotiations began,
there has been a renewed focus on our bilateral relationship with an increase in contact at an official and
ministerial level. Prior to signing the agreement, Home Office officials visited the Rwanda on many
occasions, meeting government and non-governmental interlocutors, and carried out further discussions
virtually. The Rwandan Permanent Secretary to the Ministry of Foreign Affairs also led a delegation to
London for further talks. These negotiations have been conducted transparently and in good faith
throughout. In light of the considerations described in this witness statement, and the manner in which the
negotiations [with] our Rwandan counterparts were conducted, we are confident that Rwanda will honour
its commitments under the MEDP.”

We consider that we could go behind this opinion only if there were compelling evidence to the contrary.
We do not consider such evidence exists.

67. The UNHCR relied on two matters. The first was the experience of an agreement made between the
State of Israel and Rwanda in 2013. We have not been provided with definitive evidence on the nature and
terms of that agreement, but we do not consider that is critical for our purposes. It appears that, with the


-----

Commissioner for Refugees intervening) and other case....

agreement of the Rwandan government, the Israeli government offered asylum seekers in Israel a choice
between detention in Israel or removal to Rwanda together with a payment of $3,500 and the opportunity to
make an asylum claim in Rwanda. The UNHCR's evidence was that those who were transferred were not
provided with support. It appears that many who were transferred soon left Rwanda. The UNHCR also
states that some who were transferred to Rwanda were then removed by the Rwandan authorities to
Uganda.

68. There is no evidence that during its negotiations with the Rwandan government, the United Kingdom
government sought to investigate either the terms of the

Rwanda/Israel agreement or the way it had worked in practice. It is also apparent from Mr Mustard's
statement that the merits of the MOU and Notes Verbales have been assessed on their own terms, not by
way of comparison with the Rwanda/Israel agreement. This was a permissible approach; we do not
consider it discloses any error of law.

69. The second point advanced by the UNHCR was its own opinion of the likelihood that Rwanda will
comply with its obligations under the MOU and the Notes Verbales. This was not set out in either of Mr
Bottinick's witness statements. Rather, in the course of submissions, and on instructions from Mr Bottinick,
Miss Dubinsky KC, counsel appearing for the UNHCR, stated that the UNHCR's opinion was that, in the
light of history of refoulment and of defects in its asylum system, Rwanda could not be relied on to comply
with its obligations under that Convention and, by extension, would fail to comply with the obligations it had
assumed under the MOU and Notes Verbales.

70. It was surprising that this opinion was stated through counsel at the hearing rather than in any of the
witness statements. For what it is worth, we do not think that the opinion now expressed sits particularly
easily with the UNHCR's previously published views: for example, in the July 2020 Universal Periodic
Review document. That document did contain some criticism of the Rwandan government and the asylum
system and set out specific recommendations for future action. But there is no hint in that document of any
concern of the order that might prompt the conclusion that Rwanda could not be relied on to comply with its
obligations under the Refugee Convention. Further, although Mr Bottinick's statements deal both with
matters that occurred before July 2020 and matters occurring since then, the cumulative effect of his
evidence does not readily support a conclusion that circumstances in Rwanda have changed so
dramatically since July 2020 as to make it clear that errors, if they have occurred, are indicative of systemic
(or for that matter wilful) failure to comply with these international obligations. However, be that as it may,
that is not the question we must address. The question is whether, notwithstanding the opinion the
UNHCR has now expressed, the Home Secretary was entitled to hold the contrary opinion, as set out in Mr
Mustard's witness statement.

71. There are several authorities that have considered the weight to be attached to evidence and
conclusions of fact set out in UNHCR reports and other materials. Those authorities speak with one voice:
that evidence carries no special weight, it is to be evaluated in the same manner and against the same
principles of any other evidence: see for example per Elias LJ in _HF (Iraq) v Secretary of State for the_
_Home Department [2014] 1 WLR_

1329 at paragraphs 42 to 47; and per Davis LJ in AS (Afghanistan) _[[2021] EWCA Civ 195 at paragraphs 17](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:621K-TH23-GXFD-83SK-00000-00&context=1519360)_
to 23. The context here is different, but if anything, that renders the conclusion clearer still. As explained
by Mr Mustard, the conclusion that Rwanda will act in accordance with the terms of the MOU and the
_Notes Verbales rests on HM Government's experience of bilateral relations extending over almost 25_
years, and the specific experience of negotiating the MOU over a number of months in 2022. The opinion
of the UNHCR now expressed on instructions from Mr Bottinick carries no overriding weight. We must
consider it together with all the evidence before us and decide whether, on the totality of that evidence, the
Home Secretary's opinion is undermined to the extent it can be said to be legally flawed. For the reasons
we have already given, the Home Secretary did not act unlawfully when reaching the conclusion that the
assurances provided Rwanda in the MOU and _Notes Verbales could be relied on. That being so, the_
conclusion that, for the purposes of the criteria at paragraph 345B(ii) to (iv) of the Immigration Rules,


-----

Commissioner for Refugees intervening) and other case....

Rwanda is a safe third country, was neither irrational, nor a breach of article 3 of the ECHR in the sense
explained in Ilias.

The Gillick Issue

72. The next matter under this heading is the Claimants' submission that the policy by which persons
whose asylum claims are held to be inadmissible may be returned to Rwanda, is _Gillick_ unlawful. The
meaning of the judgment of the House of Lords in _Gillick has been considered recently by the Supreme_
Court in R(A) v Secretary of State for the Home Department [2021] 1WLR 3931(see below at paragraphs
418 to 420). The Supreme Court emphasised that the relevant question is whether the policy under
consideration positively authorises or approves unlawful conduct (in the present context, a removal
decision in breach of ECHR article 3). Against this standard the Inadmissibility Policy, which includes the
possibility of removal to a safe third country, is not unlawful. Removal decisions depend on the application
of paragraph 345B of the Immigration Rules, and the conclusion reached against the criteria in that
paragraph that the country concerned is a “safe third country for the particular applicant”. If the relevant
criteria are met (see above at paragraph 11), removal to that country will not, applying the principles in Ilias
(themselves, a particular application of the principle in _Soering), give rise to a breach of article 3 of the_
ECHR. Even if the scope of the policy for this purpose is extended to cover the general conclusion in the 9
May 2022 assessment documents and the conclusion reached following consideration of the further
evidence filed in these proceedings by the UNHCR, the position remains the same. The conclusion, based
on all that material, that generally, asylum claims made in Rwanda by persons transferred pursuant to the
terms of the MOU would be entertained and effectively determined was a lawful conclusion. And, in any
event the final decision on removal would also have to take account of the asylum claimant's personal
circumstances – i.e., the criterion at paragraph 345B(i) of the Immigration Rules.

Conditions in Rwanda generally

73. The final matter to consider in respect of these grounds of challenge is the wider Soering submission,
that persons removed to Rwanda under the terms of the MEDP (i.e., the MOU and the Notes Verbales) are
exposed to a real risk of article 3 ill-treatment not for any reason connected with the handing of their
asylum claim but by reason of conditions in Rwanda, generally. The Claimants point, in particular, to
evidence to the effect that the Rwandan authorities are intolerant of criticism. Were any person removed to
Rwanda to be critical of their conditions or treatment afforded to them in Rwanda, the response might be
an extreme one. The Claimants rely on what happened in 2018 when refugees from neighbouring
countries at Kiziba refugee camp protested at the conditions in the camp. It has been reported (for
example, by Human Rights Watch) that the police who entered the camp in response to the protests used
excessive force. They fired on the refugees and some were killed. The Claimants also point more generally
to limits in Rwanda on the freedom to express political opinion if that opinion is critical of the Rwandan
authorities.

74. We do not consider that any direct inference can be drawn from the events at Kiziba refugee camp in
2018. The circumstances that led to those protests are unlikely to be repeated for any person transferred to
Rwanda under the MEDP. The treatment of transferred persons, both prior to and after determination of
their asylum claims is provided for in the MOU (at paragraphs 8 and 10) and in the Support NV. For the
reasons already given, we consider the Rwandan authorities will abide by the terms set out in those
documents. The Claimants AHA and HTN point to their actions when each was detained at IRC Colnbrook.
AHA twice protested at being detained. On one occasion, HTN refused to move from his room. We do not
consider that much weight attaches to these matters, per se. If transferred to Rwanda, neither AHA or HTN
would be detained. The expectation is that each would be treated in accordance with the terms of the MOU
and the Support NV. The Support NV includes (at paragraph 17) that a mechanism is to be established to
allow complaints about accommodation and support provided under the MOU to be raised and addressed.
Provision for those arrangements is strong support for the conclusion that the possibility of complaint on
such matters, made by persons transferred under the MEDP does not give rise to any real risk that the
consequence of complaint will be article 3 ill-treatment.


-----

Commissioner for Refugees intervening) and other case....

75. This still leaves open the wider submission as to whether those transferred to Rwanda under the terms
of the MEDP are at real risk of article 3 ill-treatment because of the way the Rwandan authorities might
respond to expressions of opinion adverse to them, or acts of political protest. The Claimants refer to AT's
record of political activity in Iran – see below at paragraph 240.

76. There is no suggestion that any of the individual Claimants (even AT) holds any political or other
opinion that is adverse to the Rwandan authorities. If there were such evidence it would fall to considered
under paragraph 345B(i) of the Immigration Rules. A proper application of that criterion would be sufficient
to ensure that were a person to face a real risk of article 3 ill-treatment, he would not be transferred. That
being so, the Claimants' case comes to the proposition that, following removal to Rwanda, it is possible
that one or more of those transferred might come to hold opinions critical of the Rwandan authorities, and
that possibility means that now, the Soering threshold is passed.

77. There is evidence that opportunities for political opposition in Rwanda are very limited and closely
regulated. The position is set out in the “General Human Rights in Rwanda” assessment document, one of
the documents published by the Home Secretary on 9 May 2022. There are restrictions on the right of
peaceful assembly, freedom of the press and freedom of speech. The Claimants submitted that this state
of affairs might mean that any transfer to Rwanda would entail a breach of article 15 of the Refugee
Convention (which provides that refugees must be accorded the most favourable treatment accorded to
nationals in respect of non-political and non-profit-making associations and trade unions). However, we do
not consider there is any force in this submission at all. Putting to one side the fact that article 15 does not
extend to all rights of association, it is, in any event, a non-discrimination provision – i.e., persons protected
under the Refugee Convention must not be less favourably treated than the receiving country's own
citizens. There is no evidence to that effect in this case. Returning to the material covered in the Home
Secretary's assessment document, there is also evidence (from a US State Department report of 2020)
that political opponents have been detained in “unofficial” detention centres and that persons so detained
have been subjected to torture and article 3 ill-treatment short of torture. Further, there is evidence that
prisons in Rwanda are over-crowded and the conditions are very poor. Nevertheless, the Claimants'
submission is speculative. It does not rest on any evidence of any presently-held opinion. There is no
suggestion that any of the individual Claimants would be required to conceal presently-held political or
other views. The Claimants' submission also assumes that the response of the Rwandan authorities to any
opinion that may in future be held by any transferred person would (or might) involve article 3 ill-treatment.
Given that the person concerned would have been transferred under the terms of the MEDP that possibility
is not a real risk. It is to be expected that the treatment to be afforded to those transferred will be kept
under the review by the Monitoring Committee and the Joint Committee (each established under the
MOU). Further, the advantages that accrue to the Rwandan authorities from the MEDP provide a real
incentive against any mis-treatment (whether or not reaching the standard of article 3 ill-treatment) of any
transferred person.

_(2) The third issue. Has the Home Secretary used the power of certification at paragraph 17 of Schedule 3_
_to the 2004 Act for an improper purpose?_

78. The Claimants' submission is that on a proper construction of the 2004 Act the certification power at
paragraph 17 of Schedule 3 (in Part 5 of that Schedule) is intended for use only on an ad hoc basis, for
individual cases. The power is not to be used in conjunction with or on the premise that there is any form
of presumption on the matters to be certified under paragraph 17(c)(i) and (ii) (set out above, at paragraph
12). The Claimants' case is that the Rwanda assessment documents comprise a form of presumption.
They contend that relying on such an assessment for the purpose of making a certificate under paragraph
17 amounts to circumventing provisions in Schedule 3 which would otherwise apply, namely those in Parts
2, 3 and 4 of Schedule 3, each of which requires some form of Parliamentary oversight. The Claimants
contend that it is only by relying one or other of Parts 2, 3 or 4 of Schedule 3 that the Home Secretary
could avoid the prohibition at section 77 of the 2002 Act which prevents removal from the United Kingdom
of any person who has a pending asylum claim.


-----

Commissioner for Refugees intervening) and other case....

79. We do not accept this submission. The distinction between the application of Parts 2 to 5 of Schedule
3 does not depend on whether certification is ad hoc or part of some general approach or policy maintained
by the Home Secretary. Rather, the distinction between each Part reflects a hierarchy of assumptions
relating to compliance with the Refugee Convention and respect for rights derived from the ECHR, and
different provisions on the approach the Home Secretary is to take when deciding whether to certify any
human rights claim and thereby limiting the right of appeal in relation to that claim.

80. Part 2 of Schedule 3 (paragraphs 2 to 6 of the Schedule) applies to the list of countries at paragraph 2
of the Schedule. That list comprises EU and EEA states. Other states (such as Rwanda) could only be
added by amendment to the 2004 Act. Part 3 of

Schedule 3 (paragraphs 7 to 11 of the Schedule) and Part 4 of the Schedule (paragraphs 12 to 16), apply
to any state specified in an order made by statutory instrument and approved by resolution of each House
of Parliament. Rwanda has not been specified either in an order under Part 3 or in one made under Part 4.

81. For states listed in Part 2 there is a rebuttable presumption that no person removed to a Part 2 state
will either be subject to ill-treatment contrary to article 3 or be removed from such a state in breach of other
rights derived from the ECHR. Further, there is an irrebuttable presumption that any person removed to
such a state would not be at risk of ill-treatment contrary to the Refugee Convention or of removal to any
other state other than in accordance with the requirements of the Refugee Convention. Each presumption
applies to all persons, across the board. There is no requirement to look at the circumstances, person by
person. Lastly, so far as concerns Part 2, the Home Secretary is required to certify any human rights claim
raised “unless satisfied that the claim is not clearly unfounded”.

82. For Part 3 states, the position is different. These are states specified in an order made by the
Secretary of State. The irrebuttable presumption concerning the Refugee Convention applies and here too
that presumption applies across the board, and the requirement to certify human rights claims is in the
same form as for Part 2 cases, but there is no presumption relating to ECHR rights. For Part 4 states the
position is different again to the extent that there is no requirement on the Home Secretary to certify human
rights claims unless satisfied that the claim is not clearly unfounded. Instead, the Home Secretary has a
power to certify a human rights claim if it is clearly unfounded.

83. The primary distinction between Parts 2 to 4, and Part 5 of Schedule 3 to the 2004 Act is that a
certification under paragraph 17 requires the Home Secretary to be of the opinion both that “the person's
…” life or liberty will not be threatened by reason of any of the characteristics specified in the Refugee
Convention, and that “the person” will not be further removed from that state other than in accordance with
the Refugee Convention (emphasis added each time). Thus, in a Part 5 case the Home Secretary must, for
this purpose, consider the circumstances of each person whose claim is to be certified. This requirement
does not prevent the Home Secretary taking account of general information about the state concerned. It
only prevents her from relying only on general information; all relevant individual circumstances must also
be considered before any certification is made.

84. For these reasons, the Claimants' submission rests on a false analysis of the provisions in Schedule 3
to the 2004 Act. There is no requirement arising from Schedule 3 that the Home Secretary seek
Parliamentary approval for a conclusion that Rwanda meets the criteria at paragraph 17(c)(i) and (ii) of the
Schedule. The Claimants' assertion that the general assessment that the Home Secretary has made has
established a “rebuttable presumption” is wrong. The assessment documents may (and no doubt do) set
out matters the Home Secretary will consider when deciding if the paragraph 17(c) criteria are met, but that
approach does not change the nature of the paragraph 17 exercise. Put another way, the Home
Secretary's general assessment is a means to an end (i.e. part of the process for reaching a conclusion
that the conditions for certification under paragraph 17 are met), not any form of end in itself. Rather, the
Home Secretary's decision to proceed under Part 5 of the Schedule rather than, for example under either
Part 3 or Part 4, only demonstrates her acceptance that decisions on certification are to be made case by
case.


-----

Commissioner for Refugees intervening) and other case....

_(3) The fourth issue. Has there been a misunderstanding of the Immigration Rules, or misapplication of_
_those Rules?_

85. This submission was made by the Claimant, SAA (CO/2094/2022). It is in two parts. The first
concerns the meaning and effect of paragraph 345A of the Immigration Rules. The submission is that if the
Home Secretary wishes to make an inadmissibly decision relying on paragraph 345A(iii)(b) she must be
satisfied both that the asylum claimant could have made an asylum claim in a safe third country at some
time before the asylum claim was made in the United Kingdom, and that the asylum claimant could still
enjoy protection in that same safe third country. SAA is from Sudan. He left Sudan in 2018 and travelled
overland to Chad where he stayed 5 days before continuing to Libya. He stayed in Libya for 3 years. In
April 2021 he travelled by boat to Italy where he stayed for 2 months. He then travelled by lorry to France
and stayed in France for 11 months before travelling (again by lorry) to the United Kingdom, arriving on 23
May 2022. All this information was provided by SAA during an asylum screening interview that took place
on 25 May 2022. SAA's asylum claim was considered by the Home Secretary with a view as to whether it
should be treated as inadmissible. On 27 May 2022 the Home Secretary sent a Notice of Intent to the
effect that she was considering making an inadmissibility decision because “before [SAA] claimed asylum
in the United Kingdom, [he was] present or had a connection to Italy and France”. In fact, the Home
Secretary has not decided whether SAA's claim should be treated as inadmissible. SAA's case was
referred to the National Referral Mechanism, the framework for identifying potential victims of **_modern_**
**_slavery; on 7 July 2022 a positive reasonable grounds decision was taken – i.e., a decision that there were_**
reasonable grounds to believe that SAA may be a victim of **_modern slavery. As a result of the positive_**
reasonable grounds decision consideration of whether his asylum claim is inadmissible was put on hold.

86. Nevertheless, it is SAA's case that the Home Secretary could only treat his asylum claim as
inadmissible if she concluded that SAA could now obtain protection under the Refugee Convention in
either Italy or France. SAA submits no such conclusion could be reached because there is no evidence
that either Italy or France would now admit him to make a claim for asylum.

87. We reject this submission. Although the language used in paragraph 345A(iii) is somewhat awkward,
the meaning of paragraph 345A, overall, is entirely clear: an asylum claim may be treated as inadmissible if
any of the three conditions at (i) to (iii) is met. There is nothing linguistically awkward about either the first
or third conditions. The former is that “the applicant could enjoy sufficient protection … because … [he
has] already made an application for protection to that country”, the latter is that “the applicant could enjoy
sufficient protection … because … [he has] a connection to that country such that it would be reasonable
for [him] to go there and obtain protection”. Condition (b) is awkwardly formulated because of the use of
the word “could” in subparagraph (iii) and then the use of “could have” in condition (b) itself.  Read
together, this produces the following:

“The applicant could enjoy sufficient protection in a safe country … because:

(b) [he] could have made an application for protection to that country but did not do so and there were no
exceptional circumstances preventing such an application being made.”

If correct, SAA's submission has the consequence that paragraph 345A(iii)(b) would comprise two discrete
conditions: first that a claim for protection could have been made (i.e., in paragraph 345A(iii) read with (b));
and second that the claimant could now (at the time of the Home Secretary's decision) enjoy protection in
the state where the claim could have been made (i.e. paragraph 345A(iii) read alone). This is incorrect
because it fails to give importance to the word “because” at the end of 345A(iii). This makes clear that the
Rules intend that the failure to make the claim elsewhere is to be an operative premise for a decision to
treat a claim as inadmissible. What is material for the purpose of (b), is that the asylum claimant had the
chance there described to make an asylum claim on an earlier occasion. Paragraph 345A might have been
clearer if, for the purposes of reading (b), the word “could” in paragraph 345A(iii) had been replaced by the
words “had the opportunity to”. However, even as formulated, the meaning is obvious. This reading of the
provision makes sense of (b) when it is read as a piece with (a) and (c). This reading also avoids creating
an overlap between paragraph 345A(iii)(b) and paragraph 345C. On SAA's reading, the further decision


-----

Commissioner for Refugees intervening) and other case....

identified in paragraph 345C “… whether to remove the applicant to the safe third country in which they
were previously present … or to any other safe third country which may agree to their entry” would be preempted by the decision already made under paragraph 345A(iii)(b), because for the purpose of that
decision the Home Secretary would already have had to conclude that the asylum claimant could be
removed to the country he had been in previously. Overall, therefore, SAA's submission does not make
sense of the run of provisions between paragraph 345A and paragraph 345D of the Immigration Rules, all
of which relate to inadmissibility decisions.

88. The second part of SAA's submission is that paragraphs 345A and 345C assume a sequence of
decision-making: first, a decision whether to treat the claim as inadmissible (paragraph 345A); and only
then, a decision on whether to remove (paragraph 345C). SAA contends that this means that the Home
Secretary cannot take steps relevant to a possible decision under 345C until she has decided (under
paragraph 345A) to treat the claim as inadmissible. Thus, in SAA's case the Home Secretary acted
unlawfully when on 30 May 2022, she sent information about SAA to the Rwandan authorities with a view
to obtaining their agreement under the MOU to SAA's relocation to Rwanda. As at that time, no
inadmissibility decision had been taken. For that matter too, the period for SAA to make representations in
response to the Notice of Intent had not expired. This sequence of events in SAA's case was not out of the
ordinary. The Inadmissibility Guidance anticipates that enquires with safe third countries on whether any
would agree to admit an asylum claimant could be made when a decision on whether to treat the claim as
inadmissible was still to be taken. On this basis, SAA further submits that this

part of the Inadmissibility Guidance is inconsistent with the Immigration Rules, and unlawful.

89. We reject these submissions too. While it is correct that the Immigration Rules provide for a sequence
of decisions – a decision on inadmissibility followed by a decision on whether or not to remove from the
United Kingdom – and while it is also correct that a decision under 345C rests on the premise that a
decision has been taken under paragraph 345A to treat the claim as inadmissible, there is nothing in the
Rules to prevent the Home Secretary from taking steps preparatory to a possible decision on removal
under paragraph 345C at the time when the decision on inadmissibility under paragraph 345A remains
under consideration. By taking such a course of action, the Home Secretary may run the risk that work
(concerning a possible decision under paragraph 345C) is undertaken unnecessarily, but that is not a
matter going to legality.

_(4) The fifth issue. Is the Inadmissibility Guidance unlawful; has the Home Secretary relied on unpublished_
_guidance?_

90. The Claimants' case on the legality of Inadmissibility Guidance is in three parts. The first part is that in
one respect the Inadmissibility Guidance goes too far.  It is submitted that the passage in the Guidance on
the use of paragraph 345C of the Immigration Rules that identifies the types of case that “may be eligible
for removal to Rwanda” cannot lawfully be the subject of a statement of policy because such a statement is
a matter falling within section 3(2) of the Immigration Act 1971 that must be included in the Immigration
Rules and, as required under the 1971 Act, must be subject to Parliamentary approval. The second part of
the Claimants' case is that in a different respect, the Inadmissibility Guidance does not go far enough. The
Claimants contend that the Guidance is inadequate because, while stating that decisions under paragraph
345C to remove a person to a safe third country (whether Rwanda, or elsewhere) must take account of “…
the particular circumstances of [the] claimant”, there is no further indication of either what circumstances
may be material, or of the significance that may attach to them. The third part of the case is that the Home
Secretary has relied on unpublished guidance to determine which claims that are inadmissible should be
considered for further action under paragraph 345C of the Immigration Rules.

91. The submission based on section 3(2) of the Immigration Act 1971(“the 1971 Act”) is directed to the
following part of the passage in the Inadmissibility Guidance (set out in context at paragraph 17 above).

“An asylum claimant may be eligible for removal to Rwanda if their claim is inadmissible under this policy
and (a) that claimant's journey to the UK can be described as having been dangerous and (b) and was
made on or after 1 January 2022 A dangerous journey is one able or likely to cause harm or injury ”


-----

Commissioner for Refugees intervening) and other case....

The particular focus of the submission is the criterion at (a) above – the so-called dangerous journey
criterion.

92. Section 3(2) of the 1971 Act, so far as material, provides as follows:

“(2)  The Secretary of State shall from time to time (and as soon as may be) lay before Parliament
statements of the rules, or of any changes in the rules, laid down by him as to the practice to be followed in
the administration of this Act for regulating the entry into and stay in the United Kingdom of persons
required by this Act to have leave to enter, including any rules as to the period for which leave is to be
given and the conditions to be attached in different circumstances … If a statement laid before either
House of Parliament under this subsection is disapproved by a resolution of that House passed within the
period of forty days beginning with the date of laying (and exclusive of any period during which Parliament
is dissolved or prorogued or during which both Houses are adjourned for more than four days), then the
Secretary of State shall as soon as may be make such changes or further changes in the rules as appear
to him to be required in the circumstances, so that the statement of those changes be laid before
Parliament at latest by the end of the period of forty days beginning with the date of the resolution (but
exclusive as aforesaid).”

The Claimants' submission is that the dangerous journey criterion is a “rule … as to the practice to be
followed in the administration of [the 1971 Act] for regulating the entry into and stay in the United Kingdom
…”, which should have been included in the Immigration Rules and made using the Parliamentary
procedure prescribed by section 3(2) of the 1971 Act. Since this has not happened, any reliance on the
dangerous journey criterion to decide which cases are subjected to action under paragraph 345C of the
Immigration Rules is unlawful.

93. The legal premise for the submission is in the judgments of the Supreme Court in _R (Munir) v_
_Secretary of State for the Home Department [2012] 1 WLR 2192and R (Alvi) v Secretary of State for the_
_Home Department [2012] 1 WLR 2208. These cases, which were heard together, concerned the reach of_
the requirement under section 3(2) of the 1971 Act to make rules. In _Munir, the Home Secretary had_
withdrawn a policy known as the “seven-year child concession” which concerned the circumstances in
which he would not exercise deportation powers against families with children. The submission made in
that case was that removal of the seven-year child concession had been ineffective because that change
had not been made using the procedure required by section 3(2) of the 1971 Act. That submission failed.
_Alvi concerned the points-based system for non-EEA nationals who wish to work in the United Kingdom._
Admission to work in the United Kingdom depends on scoring a specified level of points against criteria in
the Immigration Rules. Points are awarded against various attributes. One such attribute was the job the
applicant proposed to do: certain occupations scored points, others did not. The Rules stated that no
points would be awarded unless the job appeared on a list of skilled occupations. The list was published
but was not part of the Immigration Rules as made under section 3(2) of the 1971 Act. The issue for the
court was whether the list fell within the scope of the section such that it could not be relied on unless it had
been laid before Parliament. Mr Alvi succeeded. The court concluded that the list of skilled occupations fell
within the scope of section 3(2) of the 1971 Act and that the Home Secretary could not rely on the list as it
had not been laid before Parliament.

94. The primary significance of the judgments in these two cases is that the Supreme Court accepted that
the 1971 Act represented a sea-change to the extent that it transformed all previous common law or
prerogative powers governing entry and leave to remain in the United Kingdom into statutory powers.
Thus, there was no power to make rules other than the power referred to in section 3(2) of the 1971 Act. At
paragraph 33 of his judgment in Alvi, Lord Hope put the matter in this way.

“… As Lord Hoffmann said in the MO(Nigeria) case, para 6, the rules are not subordinate legislation. They
are therefore to be seen as statements by the Secretary of State as to how she proposes to control
immigration. But the scope of that duty is now defined by the statute. The obligation under section 3(2) of
the 1971 Act to lay statements of the rules, and any changes in the rules, cannot be modified or qualified in


-----

Commissioner for Refugees intervening) and other case....

any way by reference to the common law prerogative. It excludes the possibility of exercising prerogative
powers to restrict or control immigration in ways that are not disclosed by the rules.”

As to the scope of section 3(2) of the 1971 Act, Lord Hope said this, at paragraph 57 of his judgment.

“… I agree with Lord Dyson JSC (see para 94, below) that any requirement which, if not satisfied, will lead
to an application for leave to enter or to remain being refused is a rule within the meaning of section 3(2). A
provision which is of that character is a rule within the ordinary meaning of that word. So, a fair reading of
section 3(2) requires that it be laid before Parliament. The problem is how to apply that simple test to the
material that is before us in this case.”

while Lord Dyson put the matter in this way.

“94 … a rule is any requirement which a migrant must satisfy as a condition of being given leave to enter or
leave to remain, as well as any provision “as to the period for which leave is to be given and the conditions
to be attached in different circumstances” (there can be no doubt about the latter since it is expressly
provided for in section 3(2)). I would exclude from the definition any procedural requirements which do not
have to be satisfied as a condition of the grant of leave to enter or remain. But it seems to me that any
requirement which, if not satisfied by the migrant, will lead to an application for leave to enter or remain
being refused is a rule within the meaning of section 3(2). That is what Parliament was interested in when it
enacted section 3(2). It wanted to have a say in the rules which set out the basis on which these
applications were to be determined.”

95. In Munir, Lord Dyson went on to say this in the context of the seven-year child concession, addressing
both the source of the power to make or withdraw the concession and the issue of whether it amounted to
a rule.

“44.  In my view, it is the 1971 Act itself which is the source of the Secretary of State's power to grant
leave to enter or remain outside the immigration rules. The Secretary of State is given a wide discretion
under sections 3, 3A, 3B and 3C to control the grant and refusal of leave to enter or to remain: see paras
4–6 above. The language of these provisions, especially section 3(1)(b) and (c), could not be wider. They
provide clearly and without qualification that, where a person is not a British citizen, he may be given leave
to enter or limited or indefinite leave to remain in the United Kingdom. They authorise the Secretary of
State to grant leave to enter or remain even where leave would not be given under the immigration rules.

45.  The question remains whether [the seven-year child concession] was a statement of practice within
the meaning of section 3(2). If a concessionary policy statement says that the applicable rule will always be
relaxed in specified circumstances, it may be difficult to avoid the conclusion that the statement is itself a
rule “as to the practice to be followed” within the meaning of section 3(2) which should be laid before
Parliament. But if the statement says that the rule may be relaxed if certain conditions are satisfied, but that
whether it will be relaxed depends on all the circumstances of the case, then in my view it does not fall
within the scope of section 3(2). Such a statement does no more than say when a rule or statutory
provision may be relaxed. I have referred to [the seven-year child concession] at para 9 above. It was not a
statement of practice within the meaning of section 3(2). It made clear that it was important that each case
had to be considered on its merits and that certain specified factors might (not would) be of particular
relevance in reaching a decision. It was not a statement as to the circumstances in which overstayers
would be allowed to stay. It did not have to be laid before Parliament.”

96. We do not consider that the principles emerging from the judgments in _Munir and_ _Alvi support the_
Claimants' submission in this case. Both Lord Hope and Lord Dyson identified the scope of section 3(2) of
the 1971 Act: it applies to provisions that, as a matter of ordinary language, can be described as rules. It is
also apparent that it is not the case that anything that is guidance on the exercise of a power on the
Immigration Rules will, for these purposes, be a rule. In the present case, the starting point is paragraph
345C itself. This requires the Home Secretary, when an application has been treated as inadmissible, to
attempt to remove the applicant to a safe third country. That is, self-evidently, a rule. By contrast, the
passage in the Inadmissibility Guidance is addressing a matter of discretion. Persons within the class


-----

Commissioner for Refugees intervening) and other case....

identified “may be eligible for removal to Rwanda”; whether a removal decision will be made will depend on
consideration of each applicant's circumstances. While these matters provide structure to the way in which
the Home Secretary will approach the task, under paragraph 345C, of attempting “to remove the applicant
… to any other safe third country which may agree to [his] entry”, they are provisions on prioritisation and
process, not rules in the sense described by Lord Hope and Lord Dyson.

97. The next part of the Claimants' submission is that the Inadmissibility Guidance is inadequate so far as
it concerns decisions under paragraph 345C of the Immigration Rules. Two linked points are made. The
first (advanced by the Claimants in AAA, CO/2032/2022) is that the passage in the guidance that:

“Decision makers must take into account country information of the potential country/countries to where
removal may occur deciding whether referral into a particular route is appropriate in the particular
circumstances of the claimant.”

is insufficient. The Claimants further rely on the following statement made by the Home Secretary in preaction correspondence.

“…. certain claims may require a more intensive scrutiny than others. In particular it is evident from the
Home Office's Country Policy Information Team ('CPIT') reports that claimants with certain characteristics
will need particularly careful consideration before a decision can be made that Rwanda is a safe country for
them.”

The Claimants then submit that there should be guidance on which characteristics give rise to a need for a
“more intensive scrutiny”; and what such scrutiny should entail.

98. This submission requires careful handling, not least because the bulk of the submission is directed not
to the Inadmissibility Guidance but to the sufficiency of statements made by the Home Secretary in preaction correspondence. It cannot be sufficient for a claimant merely to contend that further or more
elaborate guidance could have been given. No doubt such forensic points could be made by any advocate
in respect of any document, however formulated. The issue must and can only be whether the Home
Secretary was subject to some legal obligation to issue guidance in the form claimed.

99. There is no relevant legal obligation in this case. The Claimants rely on the well-known passage in the
judgment of Lord Dyson in R (Lumba) v Secretary of State for the Home Department [2012] 1 AC 245, at
paragraphs 33 – 35. However, so far as material for present purposes, that requires only that if a
Secretary of State adopts a policy for the purposes of explaining how a discretionary power will be
exercised, the policy as adopted must be a “lawful exercise of the discretion deferred by the statute”. That
position is confirmed at paragraphs 63 – 64 of the judgment of Lord Sales JSC and Lord Burnett CJ in R
_(BF (Eritrea)) v Secretary of State for the Home Department [2021]_

UKSC 38, [2021] 1 WLR 3967(a judgment with which all other members of the Supreme Court agreed).
Applied to the present case, this says nothing going to the existence of an obligation on the Home
Secretary to publish policy in the form for which the Claimants contend.

100. The Claimants then submit that the requirement for a legal obligation is made good by “the duty of
transparency”. The existence of such a general duty is not generally recognised. The notion of a legal duty
of transparency is so protean that for it to exist at all, in any case, it would need to be firmly tethered to the
facts under consideration. Our preferred view remains the one we stated in our judgment in R (Manchester
_Airports Holdings Limited) v Secretary of State for Transport [2021] 1 WLR 6190– the duty does not exist in_
any general form (see that judgment at paragraph 39 – 45, in particular at paragraph 44). The extent to
which law may dictate the scope of a policy can go no further than was stated by Lord Dyson at paragraph
38 of his judgment in Lumba when he put the matter in terms of what is necessary to permit those affected
by the operation of the policy to make “informed and meaningful” representations.

101. In this case, that standard is met by the Inadmissibility Guidance as published. The passage already
set out makes clear that any decision on use of the power at paragraph 345C of the Immigration Rules
must consider the circumstances of the individual as they may be affected by country information about the


-----

Commissioner for Refugees intervening) and other case....

third country to which removal is proposed. This is at page 13 of 30 of the Inadmissibility Guidance. This
point is then further explained in sections headed “Is the country of connection safe?” and “If
return/removal will be to a different country to the country of connection is it also safe?” (at pages 20 – 21
of 30 of the Guidance). Read in the round, the Inadmissibility Guidance is, in legal terms, sufficient.

102. The second submission on this point, made by the Claimant AB (CO/2072/2022), is to the effect that
the Inadmissibility Guidance should, but does not, explain how the power at paragraph 345C of the
Immigration Rules will be exercised taking account of the protected characteristics specified at section 4 of
the Equality Act 2010. The premise for this submission is an Equality Impact Assessment of the
Inadmissibility Policy prepared by the Home Secretary as part of his compliance with the public sector
equality duty (i.e., section 149 of the Equality Act 2010, the obligation, applicable to all public authorities, to
have due regard to prescribed matters when exercising any function). That premise is incorrect. The
Equality Impact Assessment document (“the EIA”) is not part of the Home Secretary's policy. Rather, it is a
document prepared during the development of that policy, aimed at identifying how the policy measures up
against the matters to which section 149 of the 2010 Act requires due regard to be had. Moreover, any
EIA will not address all matters potentially relevant to a decision under paragraph 345C of the Immigration
Rules. It will focus on matters relevant to the protected characteristics at section 4 of the 2010 Act.

103. Be that as it may, the answer to _AB's submission is materially the same as the answer to the_
submission made by the _AAA claimants. Taking account of the range of matters in the Inadmissibility_
Guidance that concerns decisions under paragraph 345C of the Immigration Rules that guidance is not, in
law, in error.

104. The final issue concerning policy is the contention that what is said in the Inadmissibility Guidance as
to the circumstances in which removal to Rwanda will be considered (i.e., the passage set out above at
paragraph 17) is incomplete, and that the Home Secretary is, in addition, applying a further unpublished
policy.

105. This point has also emerged from the EIA document. The position has been explained in a witness
statement dated 5 July 2022 made by Ruaridh MacAskill, the Acting Head of the Home Office's Third
Country Unit.

“17. A further concern that has been raised about the EIA is that it indicates unpublished secret criteria
about who is or is not eligible for relocation to Rwanda under the MEDP. An objective throughout the
design of MEDP has been to avoid people pretending to possess certain characteristics to make their
transfer to Rwanda less likely, and to avoid the people smuggling gangs who control cross-Channel
journeys from selecting or encouraging people with certain characteristics from making such journeys.
References to not publishing “exact criteria” in the introduction section and analysis of limb 3 (fostering
good relations) were I understand intended to avoid flagging up what was already evident from the EIA and
the County Policy Information Notes read as a whole: there are factors which decision makers have to
carefully consider before deciding that a person is suitable for inadmissibility and transfer to Rwanda. The
drafter responsible for EIA has explained to me that in several cases the word “eligibility” was used when
what was really meant was “suitability”, in that while the eligibility criteria are broad … the case by case
assessment considers a person's suitability with regards to their characteristics. For example, the EIA at
section 3a “consideration of limb 1: Advance equality of opportunity” makes this point in the introduction
and under the assessments of the characteristics of sexual orientation, gender reassignment, and
disability. Those characteristics may, when considered in individual cases, make transfer to Rwanda less
likely. The objective is to avoid smugglers selecting people for a dangerous journey and avoid people
pretending to have those characteristics. For this reason, those drafting the policy guidance were reticent
about drawing attention to them.

18. When this issue was brought to light in pre-action correspondence on the MEDP we noted the concern
that the EIA could be read as suggesting that there are unpublished exact criteria that set out who and who
is not eligible for transfer. We have updated the EIA to clarify the absence of exact eligibility criteria and to
clarify that it is a person's suitability for transfer to Rwanda that is accessed.


-----

Commissioner for Refugees intervening) and other case....

19. At present, as set out above, the policy applies to those who make a claim for asylum, having arrived
by a dangerous journey since 1 January 2022. The vast majority of such arrivals do claim asylum and the
policy's stated aim is to deter people from making such journeys. The operational process reflects this. If
in future the scope of the policy were to be widened, to include for example those who do not claim asylum,
then the operational process could be adapted.”

Considering this explanation, which we accept, the unpublished policy submission falls away. It was not a
matter pursued by the Claimants at the hearing of these claims.

_(5)                        The sixth issue. Is removal to Rwanda contrary to retained EU_
_law?_

106. The submission made by Claimant ASM (CO/2080/2022) is (a) that removal to Rwanda in exercise of
the powers at paragraphs 345A to D of the Immigration Rules is contrary to requirements in articles 25 and
27 of Council Directive 2005/85/EU “On minimum standards on procedures in Member States for granting
and withdrawing refugee status” (“the Asylum Procedures Directive”); and (b) that the Asylum Procedures
Directive is retained EU law.

107. Provisions in the _[European Union (Withdrawal) Act 2018 (“the 2018 Act”) repealed the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SNC-4N71-DYCN-C32Y-00000-00&context=1519360)_ _[European](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVT0-TWPY-Y0DD-00000-00&context=1519360)_
_[Communities Act 1972 (the statute which had given effect to EU law in the United Kingdom) but also](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVT0-TWPY-Y0DD-00000-00&context=1519360)_
retained specified categories of EU law-derived rights, transposing them into a free-standing body of
domestic law, referred to as “retained EU law” (see the definition at section 6 (7) of the 2018 Act). All this
took effect from the “implementation period completion day” i.e., 31 December 2020 (see the definition at
section 39 of the European Union (Withdrawal Agreement) Act 2020. The Claimant relies on section 4 of
the 2018 Act.

“4 Saving for rights etc. under section 2(1) of the ECA

(1) Any rights, powers, liabilities, obligations, restrictions, remedies and procedures which, immediately
before IP completion day —

(a) are recognised and available in domestic law by virtue of section 2(1) of the European Communities
Act 1972, and

(b) are enforced, allowed and followed accordingly,

continue on and after IP completion day to be recognised and available in domestic law (and to be
enforced, allowed and followed accordingly).

(2) Subsection (1) does not apply to any rights, powers, liabilities, obligations, restrictions, remedies or
procedures so far as they—

(a) form part of domestic law by virtue of section 3 …

(aa) are, or are to be, recognised and available in domestic law (and enforced, allowed and followed
accordingly) by virtue of section 7A or 7B, or

(b) arise under an EU directive (including as applied by the EEA agreement) and are not of a kind
recognised by the European Court or any court or tribunal in the United Kingdom in a case decided before
IP completion day (whether or not as an essential part of the decision in the case).”

Specifically, the Claimant contends that the Asylum Procedures Directive is retained EU law because its
provisions fall within section 4(1) of the 2018 Act and outside the exclusion at section 4(2)(b) of the Act.

108. Articles 25 and 27 of the Asylum Procedures Directive are, so far as material, as follows.

“Article 25

**Inadmissible applications**


-----

Commissioner for Refugees intervening) and other case....

(1) … Member States are not required to examine whether the applicant qualifies as a refugee in
accordance with Directive 2004/83/EC where an application is considered inadmissible pursuant to this
Article.

(2) Member States may consider an application for asylum as inadmissible pursuant to this Article if:

(a) another Member State has granted refugee status;

(b) a country which is not a Member State is considered as a first country of asylum for the applicant,
pursuant to Article 26;

(c) a country which is not a Member State is considered as a safe third country for the applicant, pursuant
to Article 27;

(d) the applicant is allowed to remain in the Member State concerned on some other grounds and as result
of this he/she has been granted a status equivalent to the rights and benefits of the refugee status by virtue
of Directive 2004/83/EC;

(e) the applicant is allowed to remain in the territory of the Member State concerned on some other
grounds which protect him/her against refoulement pending the outcome of a procedure for the
determination of status pursuant to point (d);

(f) the applicant has lodged an identical application after a final decision;

(g) a dependant of the applicant lodges an application, after he/she has in accordance with Article 6(3)
consented to have his/her case be part of an application made on his/her behalf, and there are no facts
relating to the dependant's situation, which justify a separate application.

…

_Article 27_

**The safe third country concept**

1. Member States may apply the safe third country concept only where the competent authorities are
satisfied that a person seeking asylum will be treated in accordance with the following principles in the third
country concerned:

(a) life and liberty are not threatened on account of race, religion, nationality, membership of a particular
social group or political opinion;

(b) the principle of non-refoulement in accordance with the Geneva Convention is respected;

(c) the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman or
degrading treatment as laid down in international law, is respected; and

(d) the possibility exists to request refugee status and, if found to be a refugee, to receive protection in
accordance with the Geneva Convention.

2. The application of the safe third country concept shall be subject to rules laid down in national
legislation, including:

(a) rules requiring a connection between the person seeking asylum and the third country concerned on
the basis of which it would be reasonable for that person to go to that country;

(b) rules on the methodology by which the competent authorities satisfy themselves that the safe third
country concept may be applied to a particular country or to a particular applicant. Such methodology shall
include caseby-case consideration of the safety of the country for a particular applicant and/or national
designation of countries considered to be generally safe;

(c) rules in accordance with international law, allowing an individual examination of whether the third
country concerned is safe for a particular applicant which, as a minimum, shall permit the applicant to


-----

Commissioner for Refugees intervening) and other case....

challenge the application of the safe third country concept on the grounds that he/she would be subjected
to torture, cruel, inhuman or degrading treatment or punishment.”

Article 25 identifies the circumstances in which an asylum claim may be treated as inadmissible. Article
25(2)(c) is the material part for present purposes. Article 27 defines the “safe third country concept”. Article
27(1) is in the same terms as paragraph 345B of the Immigration Rules. However, the Claimant submits
that paragraph 345A – 345D of the Immigration Rules do not comply with article 27(2) in that: (a) they are
not “rules laid down in national legislation”; (b) the final words of paragraph 345C go further than permitted
by article 27(2)(a) by permitting removal to “any … safe country” which will agree to accept a claimant; and
(c) the Immigration Rules do not contain “rules on the methodology [by which]… the safe third country
concept may be applied to a particular country or to a particular applicant”, as required by article 27(2)(b).

109. The Home Secretary has not made submissions on the compatibility of paragraphs 345A – 345D of
the Immigration Rules with the requirements in article 27(2). Her submission is simply that by reason of
section 1 of and Schedule 1 to the Immigration and Social Security Co-ordination (EU Withdrawal) Act
2020 (“the 2020 Act”) the Asylum Procedures Directive is not retained EU law.

110. The material provisions of the 2020 Act are section 1 and paragraph 6 of Schedule 1.

These provide as follows

“1 Repeal of the main retained EU law relating to free movement etc.

Schedule 1 makes provision to—

(a) end rights to free movement of persons under retained EU law, including by repealing the main
provisions of retained EU law relating to free movement, and

(b) end other EU-derived rights, and repeal other retained EU law, relating to immigration.

…

**Schedule 1**

…

**6**

(1) Any other EU-derived rights, powers, liabilities, obligations, restrictions, remedies and procedures
cease to be recognised and available in domestic law so far as—

(a) they are inconsistent with, or are otherwise capable of affecting the interpretation, application or
operation of, any provision made by or under the Immigration Acts (including, and as amended by, this
Act), or

(b) they are otherwise capable of affecting the exercise of functions in connection with immigration.

(2) The reference in sub-paragraph (1) to any other EU-derived rights, powers, liabilities, obligations,
restrictions, remedies and procedures is a reference to any rights, powers, liabilities, obligations,
restrictions, remedies and procedures which—

(a) continue to be recognised and available in domestic law by virtue of section 4 of the European Union
(Withdrawal) Act 2018 (including as they are modified by domestic law from time to time), and

(b) are not those described in paragraph 5 of this Schedule.

(3) The reference in sub-paragraph (1) to provision made by or under the Immigration Acts includes
provision made after that sub-paragraph comes into force.

The reference in paragraph 6(2)(b) of Schedule 1 to paragraph 5 of the Schedule is not material to present
purposes: it refers only to matters arising under an agreement on the free movement of persons between
the EU and the Swiss Confederation. The term “the Immigration Acts” in paragraph 6(1)(a) carries the
meaning at section 61(2) of the UK Borders Act 2007 and therefore includes 1971 Act


-----

Commissioner for Refugees intervening) and other case....

111. The Claimant's submission in response is that the provisions in the 2020 Act do not concern asylum
applications but only immigration applications based on provisions governing the EU rules on freedom of
movement. The submission relies on the proper construction of the 2020 Act and on the judgment of the
Supreme Court in G v G [2022] AC 544.

112. In G v G the claim arose after a mother removed her child from South Africa to England and applied
for asylum, naming the child as a dependent in that claim. The father (in South Africa) applied under the
Hague Convention for an order returning the child to South Africa. The question was whether the Hague
Convention procedure should be stayed pending determination of the asylum claim. In addressing this
issue both the Court of Appeal and the Supreme Court assumed that the Asylum Procedures Directive
remained in force. So far as concerns the Court of Appeal proceedings, that assumption was correct. The
hearing before the Court of Appeal took place in August 2020 and judgment was handed down on 15
September 2020 – well before 31 December 2020, the implementation period completion day. The
Supreme Court hearing took place in January and March 2021. Nevertheless, at that hearing, the Home
Secretary accepted that the Asylum Procedures Directive remained retained EU law. Lord Stephens gave
the judgment with which the other members of the court agreed. He stated (at paragraph 84) that he
agreed that the Directive was retained EU law. No reasons were given for that conclusion. Later in his
judgment, Lord Stephens relied on article 7 of the Asylum Procedures Directive to construe section 77 of
the 2002 Act, relying on the principle in Marleasing. It does not appear that the court's attention was drawn
to the provisions of the 2020 Act referred to above, which had come into force on 31 December 2020.

113. As a matter of ordinary language, the effect of paragraph 6 of Schedule 1 to the 2020 Act is that the
Asylum Procedures Directive ceased to be retained EU law with effect

from 31 December 2020. During submissions, we were referred to a number of matters. In support of his
submission that the amendments to retained EU law made by the 2020 Act were intended only to affect
free movement rights, Mr Drabble KC drew attention to the side heading above section 1 of the 2020 Act,
the long title of the 2020 Act, and the Explanatory Notes published at the time the 2020 Act was introduced
in parliament as a Bill. We accept that in principle, we can have regard to these materials. Ordinarily, side
headings and long titles are permissible aids to construction of ambiguous matters; Explanatory Notes can
be taken as indicative of the Government's intention when legislation is introduced. However, we do not
consider any of these matters materially assists, not least because we do not consider that §6 of Schedule
1 to the 2020 Act is in any respect ambiguous or unclear.

114. The long title states that the 2020 Act is:

“An Act to make provision to end rights to free movement of persons under retained EU law and to repeal
other retained EU law relating to immigration to confer power to modify retained direct EU legislation
relating to social security co-ordination and for connected purposes.”

This does not suggest that the scope of the 2020 Act is restricted to removing free movement rights. Nor is
this suggested by the side heading to section 1 – “Repeal of the main retained EU law relating to free
movement etc”. The “etcetera” is important, and in any event section 1 itself makes clear that the
provisions in Schedule 1 are not limited to removal of free movement rights.  The relevant part of the
Explanatory Notes is paragraph 68 which says:

“Paragraph 6 ensures any directive rights that will have been saved by EUWA 2018 and would, in the
absence of this paragraph, be retained, cease to apply in so far as they are inconsistent with, or are
otherwise capable of affecting the interpretation, application or operation of, immigration legislation or
functions. For example, the residence rights that are derived from Articles 20 and 21 of the TFEU (rights of
citizenship and free movement) will be retained EU law and, unless they are disapplied, would provide a
right to reside in the UK for certain groups, for example “CHEN” carers who are primary carers of an EU
citizen child who is in the UK and is self-sufficient. However, the rights derived from Articles 20 and 21
would continue to apply in non-immigration contexts unless disapplied.”

There is nothing in this paragraph that illuminates the language of paragraph 6 of Schedule 1, as enacted.


-----

Commissioner for Refugees intervening) and other case....

115. Overall, in this case, each of these sources is peripheral at best. None affects the ordinary meaning
of the words used. Paragraph 6(1)(a) and (b) are couched in broad terms. Provisions made by or under
the Immigration Acts (which includes the 1971 Act, and in consequence, the Immigration Rules) are
released from the confines arising from EU-derived rights etc. EU law ceases to be recognised as retained
EU law to the extent that it is either “inconsistent” with any such provision or is capable of “affecting

the interpretation, application, or operation” of the same. The submission that articles 25 and 27 of the
Asylum Procedures Directive takes precedence over paragraphs 345A – 345D of the Immigration Rules
cannot withstand the ordinary meaning and effect of paragraph 6 of Schedule 1 to the 2020 Act.

116. Mr Drabble's fall-back submission was that the reference to provisions on immigration did not include
provisions concerning asylum. We do not accept that submission. In the context of the 2020 Act it is
impossible to discern any purpose that would be served by such a distinction. In any event, paragraph
6(1)(a) of Schedule 1 does not depend on any putative distinction between immigration and asylum.

117. We maintain our conclusion on the effect of paragraph 6 of Schedule 1 to the 2020 Act as a matter of
ordinary language notwithstanding the judgment of the Supreme Court in G v G. In that case the Supreme
Court heard no argument on the effect on the 2020 Act; there is no reference to that Act anywhere in the
judgment. Since paragraph 6 of

Schedule 1 to the 2020 Act came into force between the judgment of the Court of Appeal and the hearing
in the Supreme Court, the most likely explanation is that the parties simply did not turn their minds to the
matter at all. Mr Drabble draws attention to the judgment of the Supreme Court in Robinson (Jamaica) v
_Secretary of State for the Home Department_ [2022] AC 659. This judgment was handed down on 16
December 2020 following a hearing on 16 November 2020. Lord Stephens gave the judgment (with which
all other justices agreed). At paragraphs 29 and 30 of his judgment, which concerned the Home
Secretary's power to deport a Jamaican national who was the mother of a British national, Lord Stephens
said this.

“29. As to the position after “IP completion day” the current position is that the Immigration (European
Economic Area) Regulations 2016 … and relevant provisions of the FEU Treaty to the extent that they are
not implemented in domestic law, would continue to have effect as retained EU law pursuant to sections 2
and 4 of the 2018 Act. However, this is subject to the

_[Immigration and Social Security Co-ordination (EU Withdrawal) Act 2020as well as secondary legislation](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:619H-Y6C3-CGXG-019X-00000-00&context=1519360)_
made under it. This Act provides for repeal of the main retained EU law relating to free movement.

30. The present position is that the United Kingdom's withdrawal from the EU has no impact on this appeal
but the legal principles to be applied may change after 31 December 2020 at 11pm.”

Mr Drabble's submission is that this shows that when he gave judgment in _G v G (in March 2021), Lord_
Stephens must have had the existence of the 2020 Act well in mind and must have been of the opinion that
that Act only affected free movement rights. We consider this to be a significant over-reading of these
paragraphs. It is difficult to infer that a judge who has been referred to a statute or authority in one case
will have the same matter at the front of his mind when deciding another case, months later. Moreover, the
reference in paragraph 29 of Robinson to free movement rights is readily explicable since those rights were
in issue in that case (see paragraph 1 of Lord Stephens' judgment).

118. We are satisfied that the better conclusion is the one we have already stated: in G v G the parties did
not draw the effect of the 2020 Act to the court's attention, and for that reason the court did not deal with
the matter. Nothing we have said either does or should be thought to cast doubt on the decision reached in
_G v G. However, the judgment in that case does not contain any authoritative conclusion on the effect of_
paragraph 6 of Schedule 1 to the 2020 Act. For these reasons, we maintain the conclusion reached as a
matter of statutory construction, that by reason of paragraph 6 of Schedule 1 to the 2020 Act, articles 25 27 of the Asylum Procedures Directive ceased to be retained EU law. The submission that the decisions
taken under paragraphs 345A – 345D of the Immigration Rules were made in breach of retained EU law,
fails


-----

Commissioner for Refugees intervening) and other case....

_(6) The seventh issue. Are decisions under paragraphs 345A and/or 345C of the Immigration Rules_
_removing asylum claimants to Rwanda contrary to articles 33 or 31 of the Refugee Convention? Are the_
_[Immigration Rules in breach of section 2 of the Asylum and Immigration Appeals Act 1993?](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YH0-TWPY-Y01J-00000-00&context=1519360)_

119. Section 2 of the 1993 Act states that “nothing in the Immigration Rules (within the meaning of the
1971 Act) shall lay down any practice which would be contrary to the [Refugee] Convention”. Article 31 of
the Refugee Convention provides.

“Article 31

**Refugees unlawfully in the country of refugee**

1. The Contracting States shall not impose penalties, on account of their illegal entry or presence, on
refugees who, coming directly from a territory where their life or freedom was threatened in the sense of
article 1, enter or are present in their territory without authorization, provided they present themselves
without delay to the authorities and show good cause for their illegal entry or presence.

2. The Contracting States shall not apply to the movements of such refugees restrictions other than those
which are necessary and such restrictions shall only be applied until their status in the country is
regularized or they obtain admission into another country. The Contracting States shall allow such
refugees a reasonable period and all the necessary facilities to obtain admission into another country.”

Article 33 of the Refugee Convention is also material for the purposes of this ground of challenge.

“Article 33

**Prohibition of expulsion or return (“refoulement”)**

1. No Contracting State shall expel or return (“refouler”) a refugee in any manner whatsoever to the
frontiers of territories where his life or freedom would be threatened on account of his race, religion,
nationality, membership of a particular social group or political opinion.

2. The benefit of the present provision may not, however, be claimed by a refugee whom there are
reasonable grounds for regarding as a danger to the security of the country in which he is, or who, having
been convicted by a final judgment of a particularly serious crime, constitutes a danger to the community of
that country.”

120. The Claimants' submissions were made primarily by the Claimants in _AAA (CO/2032/2022),_ _RM_
CO/2077/3033) and _ASM (CO/2080/2022. They submit that the fact that inadmissibility decisions under_
paragraph 345A and removal decisions under paragraph 345C taken by the Home Secretary in furtherance
of her Rwanda policy, which have the consequence that asylum claimants are removed from the United
Kingdom without consideration of the substantive merits of their asylum claim, involves laying down a
“practice” which is contrary to the Refugee Convention and so is prohibited by section 2 of the 1993 Act.
Further, they submit that removing a person from the United Kingdom without having his asylum claim
determined here amounts to a penalty for the purposes of article 31 of the Refugee Convention.

121. Mr Drabble KC submitted that the Refugee Convention imposes an obligation on contracting states to
determine all asylum claims made, on their merits. We disagree. There is no such obligation on the face
of the Convention. The obligation that is imposed is the one at article 33, not to expel or return a refugee to
a place where his life or freedom would be threatened by reason of any of the characteristics that the
convention protects. Mr Drabble's submission was that an obligation to determine asylum claims would be
consistent with the spirit and purpose of the Convention and could therefore reasonably be assumed.
Again, we disagree. Obligations in international treaties are formulated with considerable care. They
reflect balances struck following detailed negotiations between states parties. An obligation to determine
every asylum claim on its merits would be a significant addition to the Refugee Convention. There is no
reason to infer the existence of an obligation of that order; to do so would go well beyond the limits of any
notion of judicial construction of an international agreement; and the protection that is necessary if the
purpose of the Convention is to be met, is provided by article 33.


-----

Commissioner for Refugees intervening) and other case....

122. Likewise, paragraph 345C of the Immigration Rules does not set out any practice of removal to
Rwanda, only a practice that where a claim has been treated as inadmissible, the asylum claimant may be
removed to any safe third country that agrees to his entry. That, of itself, is consistent with the Refugee
Convention. Removal to a safe third country, one that meets the standard at paragraph 345B of the
Immigration Rules, is consistent with article 33. Furthermore, a “practice” of removal to Rwanda emerges
only when the Immigration Rules are read together with the Inadmissibility Guidance. Section 2 of the 1993
Act is directed only to ensuring consistency between the Immigration Rules and the Refugee Convention.
We doubt that the situation here would amount to a breach of section 2 of the 1993 Act but we do not
dismiss this part of the Claimant's case for that reason.

123. So far as concerns article 31 of the Refugee Convention, the Claimants' case is that the
Inadmissibility Guidance makes clear that the Home Secretary intends to remove claimants to Rwanda to
deter others from making dangerous journeys (such as across the Channel by small boat) to claim asylum
in the United Kingdom. This deterrent aim shows that removal to Rwanda is intended to be a penalty. The
Claimants initially contended that removal to Rwanda was certainly a form of penalty because none of
them wishes to make an asylum claim in Rwanda. Each wish to claim asylum in the United Kingdom and
each has travelled hundreds or thousands of miles to get here. We understood the Claimants' oral
submissions to step back from this position; they accepted that simple denial of a subjective preference to
make an asylum claim in one country rather than another would not amount to a penalty. This concession
was made to accommodate the United Kingdom's former practice of removal under the Dublin Convention.
However, the Claimants maintained that removal under the Dublin Convention was action of a different
order to removal to Rwanda, and that the latter did comprise a penalty for the purposes of article 31 of the
Refugee Convention.  The Claimants' submission also emphasised that what amounted to a penalty for
the purposes of article 31 was not synonymous with a criminal penalty.

124. It is not necessary for the purposes of the decision in these cases to state any general conclusion on
what can comprise a penalty for the purposes of article 31 of the Refugee Convention. The issue for us is
more limited: is an inadmissibility decision _per se, a penalty for these purposes, or is an inadmissibility_
decision followed by a removal decision a penalty? Counsel for the Home Secretary has referred us to
academic commentary on the Refugee Convention. First, the commentary on the Convention edited by
Andreas Zimmermann. At paragraph 75 of the Commentary, he states as follows:

“Are certain measures never penalties in the 1951 Convention sense? The drafters have emphasised that
_expulsion does not fall under the prohibition of penalty's Art. 31, para. 1. Given that the provision is situated_
in the context of immigration control, this caveat is hardly surprising. The same conclusion follows from a
contextual analysis drawing on Art.31, para. 2. That provision assumes that the contracting State in
question might wish to remove the refugee in question.”

This conclusion coincides with the one stated by James Hathaway in the second edition of “The Rights of
Refugees Under International Law” at paragraph 4.2.3

“There are two exceptions to the general rule that Art.31 bars the imposition of penalties on refugees or
illegal entry or presence. First, Art.31 in no way constrains a state's prerogative to expel an unauthorised
refugee from its territory.

…

It may seem ironic that an asylum country which is generally prohibited from imposing penalties on
refugees may none the less expel them. The drafters were, however, unambiguous on this point, with
Colombia going so far as to suggest an amendment that would have formally disavowed any duty to grant
territorial asylum to refugees. The Canadian representative successfully argued that no modification of the
text was required, since “the consensus of opinion was that the right [to expel refugees who illegally enter a
state's territory] would not be prejudiced by the adoption of Article [31].” His suggestion that “he would
even regard silence on the part of the Conference as endorsement of his point of view” led Colombia to
withdraw its amendment. Indeed, the Netherlands representative remarked that “in view of the Canadian
representative's statement that he would interpret the silence of representatives as tacit approval of the


-----

Commissioner for Refugees intervening) and other case....

Canadian Government's interpretation of article [31], he would remain silent.” As such, the Irish Court of
Appeal's worry that Art. 31 might interfere with the operation of an orderly system to accommodate asylum
responsibilities is in fact answered by that article itself: a “first country of arrival” rule cannot be successfully
attacked under Art. 31, as the sanction imposed under such systems is precisely expulsion to another nonpersecutory state.

The potentially devastating impact of the clear decision not to preclude expulsion under Art. 31 is mitigated
by two key factors. First, whatever rights governments have to expel refugees is constrained by Art. 33's
duty of _non-refoulement. Any expulsion of a refugee must therefore not expose the refugee, directly or_
indirectly to a risk of being persecuted.”

Finally, Dr Paul Weis in his analysis and commentary on the _Travaux Preparatoires to the Refugee_
Convention, states.

“Paragraph 1 [of article 31] does not impose an obligation to regularise the situation of the refugee nor
does it prevent the Contracting States from imposing and expulsion order on him. However, a refugee may
not be expelled if no other country is willing to admit him; he may not be put over the 'green border'.”

125. There is, therefore, a clear consensus. Article 31 does not prevent a state expelling a refugee.
States must not act in breach of article 33; removal that is not contrary to article 33 is not a penalty for the
purposes of article 31. On this basis, neither decisions on inadmissibility under paragraph 345A of the
Immigration Rules, nor decisions under paragraph 345C on removal to Rwanda are contrary to the
Refugee Convention. The latter because one premise of a paragraph 345C decision is that the country
concerned is a safe third country, as defined at paragraph 345B of the Immigration Rules. The deterrent
purpose that the Home Secretary pursues in relation to removals to Rwanda

does not, of itself, render removal to Rwanda contrary to article 31, let alone article 33 of the Refugee
Convention. Further, the simple fact of removal to Rwanda is not sufficient to make good the Claimants'
submission that removal is a penalty contrary to article 31. That submission would succeed only when
removal amounts to a breach of article 33. Looked at on this basis, the Claimants' article 31 submission
merges with their submission on whether Rwanda is a safe third country. If it is a safe third country,
decisions taken in exercise of the powers in paragraphs 345A – 345D of the Immigration Rules are not in
breach of article 31; if, however, Rwanda is not a safe third country, removal would be both contrary to
paragraph 345C of the Immigration Rules and to both article 31 and article 33 of the Refugee Convention.

126. In the premises the submission made by reference to section 2 of the 1993 Act must fail. Even
assuming the Immigration Rules contain a practice of removal to Rwanda, circumstances when removal
would be contrary to the Refugee Convention would also be ones amounting to a breach of the
Immigration Rules. The purpose of section 2 of the 1993 Act is to ensure consistency between the
Immigration Rules and the Refugee Convention. So far as concerns the matters in issue in this litigation
that consistency is present.

_[(7)                              The eighth issue. Have there been breaches of the Data](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y13M-00000-00&context=1519360)_
_[Protection Act 1998 and/or the UK General Data Protection Regulation in the implementation of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y13M-00000-00&context=1519360)_
_Rwanda policy? Do such breaches invalidate decisions taking under either paragraph 345A or 345C of the_
_Immigration Rules?_

127. The MEDP contains provisions for the processing of personal data relating to persons who are to be
removed from the United Kingdom to Rwanda. Paragraph 18 of the MOU makes provision as follows.

“18 General

18.1 Pursuant to this Arrangement, the Participants will securely share information, including personal
information, for the purposes of being able to accurately identify a Relocated Individual and take decisions
about that individual for the purpose of the objective set out in Paragraph 2 and in accordance with their
respective laws and international law.

18.2 In sharing information for these purposes, the


-----

Commissioner for Refugees intervening) and other case....

Participants commit to adhere to the principles set out in Annex A of this Arrangement.”

Annex A contains detailed provisions, including on: (a) the purpose for which personal data may be
processed (only the purpose identified at paragraph 18.1 of the MOU); (b) restrictions on any further
transmission of personal data (in particular such information is not to be provided to any “government,
authority or person” of any third country if the data subject has obtained or is seeking protection from that
country under the Refugee Convention, the UN Convention Against Torture, or the International

Covenant on Civil and Political Rights); (c) restrictions on the use and handling in Rwanda of personal data
provided by the Home Office; and (d) provision concerning the time for which data transferred under the
terms of the MOU may be retained.

128. SAA's journey to the United Kingdom is described above at paragraph 85. He arrived in the United
Kingdom on 23 May 2022. His asylum screening interview took place on 25 May 2022. On 27 May 2022
he was served with a Notice of Intent to the effect that his asylum claim might be held inadmissible and
that, in that event, he could be removed to Rwanda. The Notice of Intent included the following.

“In order to make this decision we may share your personal data, make enquires with one or more of the
safe countries above to verify evidence or to ask if, in principle, they would admit you. We may also share
your personal data with Rwanda in order to ask Rwanda, another country we consider to be safe, whether
it would admit you, under the terms of the Migration and Economic Development Partnership between
Rwanda and the UK.”

129. On 30 May 2022 the Home Office provided the Rwandan authorities with details of SAA's name, date
of birth, sex, nationality, and the date he made his asylum claim in the United Kingdom. A photograph of
SAA was sent. No further personal data was provided at that time, and none has been provided since
because the Home Secretary's consideration of SAA's case was put on hold following the decision of the
NRM on 7 July 2022 that there were positive reasonable grounds to believe SAA had been a victim of
**_modern slavery._**

130. The sequence of events in SAA's case - a transfer of personal data following the Notice of Intent - is
common to the cases of all the individual Claimants before us, and consistent with the Home Secretary's
general operation of her Rwanda policy. Although the submissions on data protection have been made by
Mr Gill KC, leading counsel for SAA, the issues are common to all claims.

131. The matters raised are as follows. First, that transfer of personal data to Rwanda on the terms set
out in the MOU is contrary to the requirements in Chapter V of Retained European Parliament and Council
Regulation (2016/679/EU), better known as the United Kingdom General Data Protection Regulation (“the
UK GDPR”). Chapter V makes provision regulating the transfer of personal data to third countries.
_Second, that the Home Secretary has failed to comply with article 13 of the UK GDPR, which requires a_
data controller when obtaining personal data from a data subject to provide information, for example on the
purposes for which the data obtained will be processed. Third, that the data protection impact assessment
prepared by the Home Secretary in respect of the MEDP, to meet the requirements of article 35 UK GDPR,
is defective.

132. There is, however, one logically prior issue. Even assuming that SAA is correct on any or all of his
submission on compliance with the UK GDPR, does that affect the legality of any decision the Home
Secretary has taken under paragraph 345A or 345C of the Immigration Rules such that it would be
appropriate to quash that decision for that reason?

133. The submission for SAA is to the effect that the power to make decisions under the Immigration
Rules (i.e., decisions under paragraph 345A and 345C) depended on compliance with whatever
[requirements might arise either under the UK GDPR or under its counterpart, the Data Protection Act 2018](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)
(“the 2018 Act”). In consequence, failure to comply with data protection law would require the conclusion
that the immigration decisions were unlawful and should be quashed.


-----

Commissioner for Refugees intervening) and other case....

134. We do not accept this submission. As a matter of principle, it cannot be that any breach of any rule
on the part of a public authority or for which that authority is responsible, occurring in the context of either
making or executing a public law decision will necessarily affect the validity of that public law decision. To
take an obvious example, if a person being removed from the United Kingdom was assaulted by a Home
Office official on his way to the airport, that assault would be unlawful but would not in itself compromise
the legality of the immigration decision that was the reason for removal. On its facts, this example is some
way distant from the cases now before us. However, on the facts that are before us, the same conclusion
should be reached.

135. The alleged breach of the UK GDPR that was first in time is the breach of article 35:

the submission that the Home Secretary did not properly undertake the required data protection impact
assessment. The assessment that was performed was directed to the MEDP.  We do not consider that
the validity either of a decision under paragraph 345A of the Immigration Rules or under paragraph 345C
can plausibly be said to be conditional on compliance with the article 35 obligation to assess the “… impact
of the envisaged [data] processing operations on the protection of personal data”. The legal requirement to
undertake that assessment is not a matter that is integral to the validity of the decisions (to be taken in the
future) under the Immigration Rules. At its highest, the Claimants' case is to the effect that the MEDP was
entered into in the expectation that relevant decisions under the Immigration Rules would be made. We do
not consider that circumstance is sufficient to require the conclusion that failure to assess the impact of the
data processing required by the MEDP goes to the validity, in public law terms, of immigration decisions
taken later within the context of the MEDP. Looking at the same matter from the perspective of public law
remedies, it would not be appropriate to quash decisions taken under the Immigration Rules albeit within
the context of the MEDP, for that reason.

136. The matter next in time is the alleged breach of the article 13 of the UK GDPR: the failure when
collecting personal data from each asylum claimant, to provide the information specified in that article
concerning the identity etc. of the data controller, the purposes for which the data would be processed, the
legitimate interest giving rise to the need to process data, and other matters. On the facts of SAA's case, if
there was such a breach it occurred at or shortly after the asylum screening interview on 25 May 2022.
Information obtained at that interview was used when taking the decision to issue the Notice of Intent. In
his case no decision was taken under either paragraph 345A or 345C of the Immigration Rules. However,
in other cases those decisions have been taken, and each will have been informed by information obtained
at the relevant asylum screening interview.

137. If there was a failure to comply with article 13 that gives rise to the possibility of a complaint under the
UK GDPR and the 2018 Act, either to the Information Commissioner (article 77 read with section 165) or to
a court (article 78 read with sections 167 and 180). It does not go any further. We do not consider that the
validity

of subsequent immigration decisions does or should depend on whether information relied on was
collected in circumstances that complied with article 13 of the UK GDPR. There is no relevant connection
between a breach of article 13, the consequences of the breach, and any standard going to the validity of
the public law decision. Nor should any such failing give rise to the possibility of a public law remedy. The
remedies available for breach of the UK GDPR are those provided in the 2018 Act: compliance orders
and/or an award of damages (see sections 167 and 168, which concern claims to a court).

138. Lastly, there is the alleged breach of Chapter V of the UK GDPR by the transfer of data to Rwanda.
_SAA contends that the transfer of personal data provided for by the MEDP required either an adequacy_
decision under article 45, or appropriate safeguards as specified under article 46. The Home Secretary's
position is that neither was necessary and that article 49 of the UK GDPR provides a permissible legal
basis for transfer of personal data from the United Kingdom to the Republic of Rwanda.

139. No part of any inadmissibility decision under 345A of the Immigration Rules rested on the transfer of
personal data to Rwanda. As a simple matter of fact, failure to comply with Chapter V of the UK GDPR
had no bearing on any such decision


-----

Commissioner for Refugees intervening) and other case....

140. Removal decisions under paragraph 345C of the Immigration Rules do depend on Rwanda's consent
to admit each relevant asylum claimant. Personal data was processed for that purpose – i.e., it was sent to
the Rwandan authorities pursuant to paragraph 5.2 of the MOU and subject to the handling requirements
at paragraph 18 of and Annex A to the MOU. The Claimant's case is that the way in which the consent
required for the paragraph 345C decision was obtained involved an unlawful processing of personal data.
Even assuming this to be so, we do not consider that prevented the Home Secretary from relying on the
consent that had been given; it did not mean that the removal decision was unlawful.

141. A public law decision-maker has latitude to decide not only, the matters that are relevant to the
decision but also what information relevant to those matters should be considered (subject always to any
restriction arising in or from the powers being exercised). We do not rule out the possibility that in some
circumstances a decision-maker may be entitled to conclude that information that is otherwise relevant
ought not to be considered because of the way in which it has be obtained. There may be some situations
in which a decision-maker may be required to take that course. But the present situation is not such a
situation. Even if the consent of the Rwandan authorities under the MOU was obtained consequent to data
processing that had taken place without compliance with Chapter V of the UK GDPR, the Home Secretary
was entitled to rely on that consent for the purposes of a decision under paragraph 345C of the
Immigration Rules. Reliance on that consent did not render her decision unlawful as a matter of public law.

142. This conclusion is supported by the remedies available under the UK GDPR and the 2018 Act on a
complaint that data has been processed in contravention of the requirements of Chapter V. The UK GDPR
provides a right of complaint to the Information Commissioner. On such a complaint the powers under
article 58(1) to investigate, and the powers to correct under article 58(2), are available to the
Commissioner. There is also the right of complaint to a court. If a complaint is made, the court may make
a compliance order and/or award compensation. The tenor of these remedies is that either the
Commissioner or the court may award compensation for past breaches and may make orders specifying
what the data controller must do to ensure future compliance with data protection law. Neither the UK
GDPR nor the 2018 Act provides, for example, that past transactions which have relied on data processed
in breach of data protection law, are to be undone or for that reason treated as void. This supports the
conclusion that, in these cases, the validity of the decisions taken under the Immigration Rules should
depend on ordinary public law principles. Data protection law does not require any different approach.

143. All this being so, the data protection law submissions in this case are not capable of producing the
conclusion that the Home Secretary's decisions under Immigration Rules are unlawful. For this reason, it is
not necessary to address the specific submissions on article 13, article 35 and Chapter V of the UK GDPR
in detail. That is doubly so since those complaints ought not to have been made in these proceedings.
While section 180 of the 2018 Act gives the High Court jurisdiction over complaints such as these, Part 53
of the Civil Procedure Rules states that claims in “data protection law” must be issued in the Media and
Communications List: see CPR 53.1(3)(b). This does not rule out the possibility that a claim issued as
required by Part 53, may then be then transferred from the Media and Communication List, for example to
the Administrative Court. But there would have to be good reason for such transfer. Since, for the reasons
above, the breaches of the UK GDPR alleged in these proceedings do not go to the legality of the Home
Secretary's decisions under the Immigration Rules, there is no sufficient reason for the substance of these
complaints to be addressed in judicial review proceedings. We therefore confine ourselves to the following
brief observations on the breaches of the UK GDPR alleged.

144. We accept the Home Secretary's submission that that it is open to her to comply with the
requirements of Chapter V of the UK GDPR through compliance with article 49. Other routes to the
compliance with the Chapter are available: i.e., articles 45, 46 and 47. But, contrary to the Claimants'
submission, there is no hierarchy within Chapter V and no other assumption that article 49 can only be
used if the data controller is able to show that routes under other articles could not have been used. The
side heading to article 49 is “Derogations for specific situations”. That does not prevent the Home
Secretary from relying on article 49 in aid of the Rwanda policy. It would not be correct to infer from that
side heading that article 49 applies only to one-off data transfers.


-----

Commissioner for Refugees intervening) and other case....

145. We also accept that in this case, the conditions within article 49 are met. The submissions on this
point focused on article 49(1)(d) and 49(4). Reliance on article 49 depends on demonstrating that one of
the conditions in article 49(1) is met. In this case the Home Secretary relies on article 49(1)(d): that the
transfer is necessary for important reasons of public interest”. Article 49(4) then provides that:

“The public interest referred to in point (d) of the first subparagraph of paragraph 1 must be public interest
that is recognised in domestic law (whether in regulations under section 18(1) of the 2018 Act or
otherwise).”

The Claimants' submission is that there is no relevant public interest “recognised in law”, and that in any
event, transfer of the personal data is “not necessary” because it

is not proportionate. We do not agree with this submission. The public interest in immigration control in
accordance with the Immigration Rules is recognised by the court and is long-established. The court
regularly proceeds on that premise. Transfer of personal data subject to the safeguards provided in
paragraph 18 of and Annex A to the MOU is a reasonable and proportionate way to give effect to this
public interest.

146. So far as concerns article 13, we are concerned that the Home Secretary's practice may not meet
what is required. Some of the information required by article 13 is provided at the asylum screening
interview. These interviews are conducted on the basis of a standard script. One part of the script is as
follows:

“Your information may be shared with other UK government departments or agencies including the
National Health Service, local authorities, asylum authorities of other countries, international organisations,
and other bodies. Any information sharing is to enable us and other organisations to carry out functions,
including the prevention and detection of crime.”

This information goes towards meeting the requirements at article 13(1)(c) to (f). This part of the script is
read at the beginning of each asylum screening interview and translated for the asylum claimant as
necessary. For the purposes of compliance with article 13 the Home Secretary also relies on a Privacy
Notice. This is referred to at the end of the screening interview script. The copy of the completed interview
script provided to each asylum claimant includes the internet address where the Privacy Notice can be
found. However, we are unclear as to the extent that asylum claimants who are detained have internet
access, and in any event, we are told that the Privacy Notice is available only in English. This may not
meet the requirement under article 12 UK GDPR that information required to be provided under article 13
is provided in a form that is intelligible and easily accessible.

147. We have seen the data protection impact assessment relied on by way of compliance with the
requirements at article 35. Put briefly, the obligation to assess under that article arises in respect of data
processing “… likely to result in a high risk to the rights and freedoms of natural persons”; and the
obligation is to assess the impact on the protection of personal data of the processing that is envisaged.
The Claimants' oral submissions focussed on two matters. The first was whether the assessment had
been conducted in accordance with the Home Secretary's own policy on assessment, specifically whether
matters raised by the assessment should have been considered by the Home Office Data Board. The
suggestion that some matters should be brought to the Board's attention was made by Amanda Hillman,
Deputy Data Protection Officer, and Head of Engagement, in an email dated 3 May 2022. These matters
were not referred to the Board. We do not consider that anything turns on this. It was open to Ms Hillman
to decide for herself whether to refer the matter; that she did not do so, having raised the possibility of a
referral, suggests that her final conclusion was that referral to the Data Board was not warranted.

148. The second matter was that the detail and scope of the assessment undertaken was insufficient. It is
fair to say that at first sight, the assessment document does not appear a particularly impressive document.
It is in large part a tick-box process. There is some opportunity for a narrative explanation but on many
occasions the narrative provided is


-----

Commissioner for Refugees intervening) and other case....

brief. Mr Gill's submission was that the assessment required in this case was of the order identified by the
CJEU in _Schrems v Data Protection Commissioner [2016] QB 52, and_ _Data Protection Commissioner v_
_Facebook Ireland Limited [2021] 1 WLR 751when that court considered the application of Commission_
Decision 2010/87/EU on standard contractual clauses for transfer of data to third countries, to data
transfers to the United States. We do not consider this to be the appropriate yardstick for the assessment
required in this case. Data transfer pursuant to the MEDP is a much more limited exercise. Given our
primary conclusion on the data protection submissions, we have not reviewed the assessment document in
detail. On the review we have undertaken we consider it likely that this assessment does meet the
requirements of article 35.

149. In his skeleton argument, Mr Gill attempted to raise a range of matters he had not pleaded. These
are summarised in the Home Secretary's Skeleton Argument at paragraph 7.2. They form no part of the
case before the court, and we do not address them.

(8)  The ninth issue. Discrimination

150. Three Claimants make claims of discrimination.

151. SAA (CO/2094/2022) relies on article 14 of the ECHR. The premise for the claim is the provision in
the Inadmissibility Guidance as to the circumstances to which a person who has made an asylum claim
determined to be inadmissible could be removed to Rwanda:

“An asylum claimant may be eligible for removal to Rwanda if the claim is inadmissible under the policy
and (a) that claimant's journey to the UK can be described as having been dangerous and (b) was made
on or after 1 January 2022. A dangerous journey is one able or likely to cause harm or injury. For
example, this would include those that travel via small boat, or clandestinely in lorries.”

SAA contends this provision results in indirect discrimination on grounds of age, sex and nationality
because those crossing the English Channel in small boats tend to be young and male, and prior to the
hearing, have predominantly been from Iraq, Iran, Syria, Sudan or Afghanistan. All these factual premises
are borne out by the information in the Home Secretary's EIA document. Separately from this, SAA also
contends that the dangerous journey criterion has not be applied consistently because it has not been
applied to those who, since February 2022, have fled from Ukraine following the Russian invasion of that
country.

152. This latter contention does not give rise to any viable claim of unlawful discrimination because it rests
on a flawed comparison. The part of the Inadmissibility Guidance set out above applies only to persons
who have made asylum claims which have been held to be inadmissible. Those persons are in a
materially different position to those who have, since February 2022, come to the United Kingdom from
Ukraine. That group has

entered the United Kingdom under the terms of one or other of two Home Office Schemes: the Ukraine
Family Scheme, and the Ukraine Sponsorship Scheme (Homes for Ukraine). It was not unlawful for the
Home Secretary to make special provision for persons coming from Ukraine. Eligibility under these
schemes does not rest on meeting the conditions for making a claim for asylum.

153. As for the first part of SAA's discrimination claim, even assuming all other requirements for a viable
article 14 claim are satisfied, the Home Secretary's dangerous journey criterion is justified.

154. It pursues a legitimate objective: to protect refugees from exploitation by criminal gangs who, for
example, organise the small boat crossings. The Inadmissibility Guidance does not limit the possibility of
removal to Rwanda to young men. The Inadmissibility Guidance does rule out the possibility that
unaccompanied asylumseeking children could be removed (to any safe third country). That exclusion is
justified for obvious reasons of general welfare. The Home Secretary has stated, that for now, families will
be removed to Rwanda only with their consent. We consider, again as a matter of generality, that the
circumstances of families are materially different to those of lone adults, and that given that the Rwanda
policy is a new departure, the Home Secretary has, for the purposes of any discrimination claim, good


-----

Commissioner for Refugees intervening) and other case....

reason to treat families differently. The Inadmissibility Guidance does not specifically restrict the possibility
of removal to Rwanda to men (rather than women), or to the young. It is true that with one exception, the
Claimants before us are young men and, we are also prepared to assume that at least in the short term,
the category of young men is the most likely to be the subject of removal decisions. Nevertheless, and
even assuming that impact, we are satisfied the criterion is justified.

155. The dangerous journey criterion is not specifically directed to young men. It is not a criterion that
they meet by reason of any inherent characteristic. Rather, it applies to them by reason of choices they
have made: (a) not to make asylum claims before arriving in the United Kingdom (the premise here must
be inadmissibility decisions have been correctly and lawfully made); and (b) to travel to the United Kingdom
by unauthorised and clandestine means. Moreover, for the purposes of this discrimination claim we must
also assume that any decision to remove to Rwanda will be consistent with article 33 of the Refugee
Convention, and with a person's ECHR rights. All this being so, the dangerous journey criterion is
proportionate to the objective the Home Secretary pursues through the inadmissibility policy.

156. AB (CO/2072/2022) also pursues an article 14 claim. The starting point for this claim is that being an
asylum claimant is a relevant “other status” for the purposes of an article 14 claim. This is not disputed by
the Home Secretary. AB contends that it is discriminatory to apply the policy only to persons who have
claimed asylum and not also to those who have claimed that their removal from the United Kingdom would
be in breach of their ECHR rights, but have not claimed protection under the Refugee Convention.

157. The Home Secretary's response is two-fold. First, it is submitted that the distinction AB suggests
between persons that make claims for asylum and those who make only human rights claims is not a
significant practical distinction. The Home Secretary submits that any claim to the effect that removal from
the United Kingdom would give

rise to a real risk of either article 2 or article 3 ill-treatment would, under the Immigration Rules, be treated
as a claim for humanitarian protection (this point is made by reference to paragraph 327EA and 339CA of
the Immigration Rules). She then relies on paragraph 327EC of the Immigration Rules.

“If someone makes a claim for humanitarian protection, they will be deemed to be an asylum applicant and
to have made an application for asylum for the purposes of these Rules. The claim will be recorded,
subject to meeting the requirement of Rule 327AB (i) to (iv), as an application for asylum and will be
assessed under paragraph 334 for refugee status in the first instance. If the application for refugee status
is refused, then the Secretary of State will go on to consider the claim as a claim for humanitarian
protection.”

By paragraph 327 of the Immigration Rules the definition of “asylum applicant” includes a person deemed,
pursuant to paragraph 327EC, to have made a claim.

158. Thus, says the Home Secretary, the difference in treatment AB suggests will not arise in practice
because persons who have made claims akin to asylum claims are treated under the Immigration Rules as
having made asylum claims and, as such, do fall within the scope of the Inadmissibility Guidance. Other
human rights claims, which do not fall to be treated as asylum claims, are, says the Home Secretary,
claims of a different nature such that the difference in treatment does not comprise unlawful discrimination.

159. We accept the Home Secretary's submissions on these points. The Home Secretary also relies on
the fact that, in practice, persons who arrive in the United Kingdom having travelled through safe third
countries and then to the UK via a dangerous journey, do claim asylum rather that making any other form
of claim. She submits that, in those circumstances, she is entitled to formulate the Inadmissibility
Guidance and the MEDP to meet what happens in practice, and that were the position to change such that
the same class of persons ceased to make asylum claims but claimed leave to enter the United Kingdom
for other reasons, she would consider adapting the MEDP and the Inadmissibility Guidance to meet those
circumstances. Although we say nothing about the latter point, we do accept that it is not contrary to article
14 for the Home Secretary to formulate her policy on removal to Rwanda to meet the problem that actually
exists rather than to address matters that are, for now, hypothetical.


-----

Commissioner for Refugees intervening) and other case....

160. ASM (CO/2080/2022) relies both on article 14, and section 19 of the 2010 Act, contending that “the
MEDP scheme” entails indirect discrimination on grounds of “race/nationality” and disability. Here too, we
assume that the focus of the complaint is the possibility of removal to Rwanda.

161. We do not consider that a claim for indirect discrimination based on nationality can be pursued under
the 2010 Act. Neither section 19 nor section 20 of the 2010 Act gives rise to any free-standing claim of
discrimination. Each is a definitional provision; the operative provisions which state when discrimination is
unlawful, are elsewhere in the 2010 Act. Neither ASM's statement of Facts and Grounds, nor his Skeleton
Argument identifies the operative provision relied on. We have however, assumed the relevant provision to
be section 29(6) in Part 3 of the 2010 Act, which prohibits discrimination by persons acting “in the exercise
of a public function that is not the provision of a service to the public or a section of the public”. If that is
correct (and we can see no other route for the Claimant), the claim under the 2010 Act is met by paragraph
1 of Schedule 23 to the 2010 Act, which sets out a relevant exception to the application of the provisions of
part 3 of the 2010 Act. By paragraph 1(1), no contravention of Part 3 occurs if the act said to comprise
discrimination is:

“(a) in pursuance of an enactment;

(b) in pursuance of an instrument made by a member of the executive under an enactment;

(c) to comply with a requirement composed … by a member of the executive by virtue of an enactment;

(d) in pursuance of arrangements made … by or with the approval of, or for the time being approved by, a
Minister of the Crown;

(e) to comply with a condition imposed … by a Minister of the

Crown.”

if it is done because of a person's nationality: see paragraph 1(2) of Schedule 23

162. However, so far as concerns the remainder of the claim, whether under article 14 or under the 2010
Act, we consider that any indirectly discriminatory impact is justified. The claim does not go further than
the claims to similar effect made by SAA and AB. It fails for the same reasons. ASM contends that the
Home Secretary is not pursuing any lawful purpose. He submits the removal provisions within the
Inadmissibility Guidance represent a departure from the requirements of the Refugee Convention. For the
reasons given above we do not accept that submission. For the present purposes we accept that the Home
Secretary's Inadmissibility Guidance does pursue a legitimate objective: that of protecting persons coming
to the UK from exploitation by the criminal groups that organise these irregular routes to the United
Kingdom.

163. The premise of the claim of disability discrimination is that persons claiming asylum having travelled
across Europe and reached the United Kingdom by a dangerous journey are more likely to have mental
illnesses amounting to a disability than those reaching the United Kingdom by different means. There is no
evidence to that effect, but for present purposes we will assume this contention is made out. Even on that
assumption, this claim does not succeed. We do not consider that a person who suffers from mental
illness will be prejudiced as the Claimant suggests. Any relevant prejudice will arise from a lack of
appropriate care. One premise of removal to Rwanda under the MEDP is that appropriate medical care
will be available: see paragraph 6 of the Support NV. If appropriate care were not available in Rwanda it is
to be expected that the person's claim to remain in the United Kingdom on human rights grounds would
succeed.

164. For these reasons the claims for unlawful discrimination all fail.

(9)  The tenth issue. Irrationality

165. This submission was made by Mr Gill KC on behalf of SAA (CO/2094/2022). In one part, the
submission rehearses the contention that it was irrational to conclude that Rwanda is “a safe third country”


-----

Commissioner for Refugees intervening) and other case....

or to reach that conclusion without further investigation. We have addressed those matters above and do
not need to add anything to what we have said.

166. The second part of the submission concerns whether the Home Secretary acted lawfully using the
powers available to her under the Immigration Rules and the 2004 Act. In substance, it is a variation on
arguments considered above: (a) on whether aspects of the Inadmissibility Guidance ought to have been
included within the Immigration Rules; and (b) whether the powers under Part 5 of Schedule 3 to the 2004
Act were used for a proper purpose. Mr Gill submits that the Rwanda Policy is “far reaching” and
“fundamentally changes the asylum system in the UK”, and that in those circumstances the Home
Secretary should have sought parliamentary approval to take the decision that asylum claims made in the
United Kingdom should not be decided here, and that instead the persons who made them should be
removed to Rwanda with the opportunity to make their asylum claim in that country.

167. We do not accept this submission. The powers that the Home Secretary used, under the Immigration
Rules and under the 2004 Act, were available to her and were (and are) capable of being used to take the
decisions legally required to give effect to her Rwanda policy. That being so, there was no legal
requirement on the Home Secretary to seek further powers from Parliament or otherwise, seek
parliamentary approval of her policy.

168. The third part of this submission is that the Home Secretary acted unlawfully by failing to seek
Treasury approval for the Rwanda policy. Mr Gill relies on a letter dated 13 April 2022 from Matthew
Rycroft, the Permanent Secretary at the Home Office, to the Home Secretary. In that letter Mr Rycroft sets
out his assessment of the MEDP in his capacity as the Responsible Accounting Officer for the Home
Office. He concluded there was insufficient evidence that “… the policy will have a deterrent effect [i.e.
deterring people from entering the United Kingdom illegally] significant enough to make the policy value for
money”. In those circumstances he requested (in accordance with ordinary practice) that the Home
Secretary give a written direction that the policy should be pursued. Later the same day the Home
Secretary gave that direction.

169. Mr Gill's submission is that this sequence of events shows that the Home Secretary should, before
proceeding, have sought the agreement of HM Treasury. He refers to the HM Treasury document
“Managing Public Money” (a document of long-standing most recently published in March 2022),
specifically paragraph 7.11 which states as follows:

“7.11  Innovative structures

7.11.1 Sometimes central government departments have objectives which more easily fit into bespoke
structures suited to the business in hand, or to longer-range plans for the future of the business. Such
structures might for example, include various types of mutual or partnership.

7.11.2 Proposals of this kind are by definition novel and thus require explicit Treasury consent. In each
case, proposals are judged on their merits against the standard public sector principles after examining the
alternatives, taking account of any relevant experience. The Treasury will always need to understand why
one of the existing structures will not serve: e.g.

the NDPB format has considerable elasticity in practice. …”

This, contends Mr Gill, means that the Home Secretary ought not to have pursued her policy without the
consent of the Treasury.

170. This submission also fails. A point of detail is that paragraph 7.11 of the “Managing Public Money”
document has no application to the Home Secretary's decision to pursue her Rwanda policy. Chapter 7 of
Managing Public Money is titled “Working with others” and concerns situations where a public body
decides to work with some other organisation, for example a commercial company or a non-governmental
organisation. The wider reason this submission fails is that it does not touch on any legal obligation
affecting the Home Secretary. Mr Gill contended that the MOU provides for the United Kingdom to provide
significant funds to the Rwandan government. That does appear to be the case. However, there is no


-----

Commissioner for Refugees intervening) and other case....

challenge to the decision to enter into the MOU, and in any event, no challenge to that decision to the
effect that the agreement should have been reached on different terms, or one that would have any
likelihood of success.

(10)  The eleventh issue. Public Sector Equality duty

171. The Home Secretary relies on the Equality Impact Assessment document dated 9 May 2022 (“the
EIA”) as evidence of compliance with the obligation at section 149 of the Equality Act 2010 (the public
sector equality duty). That obligation is as follows:

“149 Public sector equality duty

(1) A public authority must, in the exercise of its functions, have due regard to the need to—

(a) eliminate discrimination, harassment, victimisation and any other conduct that is prohibited by or under
this Act;

(b) advance equality of opportunity between persons who share a relevant protected characteristic and
persons who do not share it;

(c) foster good relations between persons who share a relevant protected characteristic and persons who
do not share it.

(2) A person who is not a public authority but who exercises public functions must, in the exercise of those
functions, have due regard to the matters mentioned in subsection (1).

(3) Having due regard to the need to advance equality of opportunity between persons who share a
relevant protected characteristic and persons who do not share it involves having due regard, in particular,
to the need to—

(a) remove or minimise disadvantages suffered by persons who share a relevant protected characteristic
that are connected to that characteristic;

(b) take steps to meet the needs of persons who share a relevant protected characteristic that are different
from the needs of persons who do not share it;

(c) encourage persons who share a relevant protected characteristic to participate in public life or in any
other activity in which participation by such persons is disproportionately low.

(4) The steps involved in meeting the needs of disabled persons that are different from the needs of
persons who are not disabled include, in particular, steps to take account of disabled persons' disabilities.

(5) Having due regard to the need to foster good relations between persons who share a relevant
protected characteristic and persons who do not share it involves having due regard, in particular, to the
need to— (a) tackle prejudice, and

(b) promote understanding.

(6) Compliance with the duties in this section may involve treating some persons more favourably than
others; but that is not to be taken as permitting conduct that would otherwise be prohibited by or under this
Act.

(7) The relevant protected characteristics are— age; disability; gender reassignment; pregnancy and
maternity; race;

religion or belief; sex; sexual orientation.”

172. The submission made by ASM (CO/2080/2022) is that the Home Secretary failed to comply with the
section 149 duty: (a) because the EIA does not sufficiently address concerns in the Home Secretary's May
2022 Rwanda assessment documents that the rejection rate for asylum claims made by applicants from
middle-eastern countries appeared to be higher than claims being made for others, and that, even if their
asylum claim was successful, persons removed to Rwanda may find it difficult to integrate into Rwandan


-----

Commissioner for Refugees intervening) and other case....

society; (b) because the EIA focused on what might happen once a person had been removed to Rwanda
and did not consider the impact of the removal process, particularly on those suffering from mental illness
amounting to disability; and (c) because the EIA post-dated the MOU and _Notes Verbales which are the_
core elements of the MEDP and as such evidences only a “rear guard action”, not genuine compliance with
the section 149 obligation.

173. The parties did not disagree on the general effect of section 149 of the 2010 Act. A decision-maker
must consider the likely consequences of the action or decision under consideration by reference to the
framework set by section 149.

174. We do not consider that the timing of the EIA shows any failure to meet the requirements of section
149(1) of the 2010 Act. The EIA was published at the same time as the Home Secretary's Rwanda
assessment documents and her Inadmissibility Guidance. This explains the date on the face of the
document. Mr Armstrong's evidence

(witness statement dated 5 July 2022) explains that work on the EIA commenced in February 2022 and
continued in tandem with the negotiation of the MOU (the MOU was signed on 13 April 2022.) He states
that the EIA served to inform the substance of the terms that were sought during the negotiations. We
accept this evidence, and conclude from it that in the course of formulating what became the Rwanda
policy, the Home Secretary did have due regard to the section 149(1) criteria.

175. Nor do we consider that the other two criticisms of the EIA are sufficient to reach the conclusion that
the Home Secretary failed to comply with section 149 of the 2010 Act. The section 149 obligation is not an
obligation of exhaustive consideration of all possible matters. Overall, the EIA evidences that there was
thorough consideration of how removal to Rwanda might affect persons with protected characteristics.

176. The focus of consideration was on the position in Rwanda; the document did not specifically address
the process of removal from the United Kingdom: i.e. transport to an airport, transfer to a plane, and the
arrangements for the flight. However, those exercises would be undertaken in the usual way, applied to
any removal to any country. There is no suggestion that the process to removal to Rwanda gave rise to
any unique considerations.

177. The remaining matter concerns the consideration given to how the system in Rwanda for dealing with
asylum claims might work. In this regard, the EIA is evidence that the

Home Secretary attached particular significance to the terms of the MOU on arrangements for monitoring
compliance with, amongst other matters, the obligations assumed by the Rwandan authorities to ensure
access to the system for deciding asylum claims and the arrangements to be in place to decide asylum
claims made by persons who were going to be transferred under the MOU. The EIA also emphasises that
the monitoring arrangements would permit the Home Secretary the opportunity over the duration of the
MOU, to continue to monitor the “equality impacts” on removal to Rwanda. We are satisfied, considered in
the round, that on this matter also the Home Secretary acted as required by section 149(1) of the 2010 Act.

**C.                        Decision on the issues in the individual claims**

(1)  General points

178. In these claims, the individual Claimants' challenges are directed to decisions under paragraph 345A
and 345C of the Immigration Rules (which, unless required otherwise by context, we have described,
compendiously, as inadmissibility decisions), and (save for AHA, the second claimant in CO/2032/2022),
the decisions that removal to Rwanda would not be in breach of their ECHR rights (referred to as “human
rights claims”), and decisions certifying those human rights claims under paragraph 19(c) of Schedule 3 to
the 2004 Act (thereby removing rights of appeal). As stated above, these decisions are, for the purposes of
the legal analysis, the premises of the Home Secretary's Rwanda policy.

179. A number of the grounds of challenge raise issues said to apply to all claims and these have been
considered above. For the reasons given above, none of those generic grounds establishes any illegality in


-----

Commissioner for Refugees intervening) and other case....

relation to the inadmissibility decisions (or decisions refusing human rights claims and certifying the claims
as clearly unfounded).

180. The Claimants also, however, allege specific grounds of challenge in respect of the decisions taken
in their individual cases. In this section, we set out the material facts, or alleged facts, so far as they appear
from the material before us and consider these specific challenges. We have already considered, at length,
the provisions under which the inadmissibility and removal decisions were taken (i.e., paragraphs 345A – D
of the Immigration Rules). So far as concerns the decisions to certify the human rights claims, all parties
agree that the correct approach is the one explained in R(ZT (Kosovo)) v Secretary of State for the Home
_Department [2009] 1 WLR 348and in_ _R (SP (Albania)) v Secretary of State for the Home Department_

_[2019] EWCA Civ 951. For the reasons set out below many of these decisions do stand to be quashed and_
the individual cases will need to be looked at again. In some instances, this is because the Home
Secretary has accepted that one or more pieces of information provided before a decision was taken was
not considered. In those cases, she accepts that the decision should be revisited taking account of that
information. In two instances, inadmissibility decisions fall to be quashed because in the course of
decision-making, the facts of the cases were accidentally transposed.

181. In yet other cases, decisions fail because of the way decision-making was allocated within the Home
Office. Ordinarily, a court will have little to say about the way a Secretary of State chooses to allocate
decision-making among her officials. Such decisions rarely go to the legality of any matter. However, in this
case, the way in which decision-making was organised became material. In most (but not all) cases, the
claimants challenged both the decisions made under paragraphs 345A and 345C of the Immigration Rules,
and the decision that removal to Rwanda would not entail breach of his ECHR rights. As noted above, the
Home Secretary allocated decisions on the paragraph 345A and 345C claims to the Third Country Unit in
Glasgow, and the decisions on the human rights claims to the Detained Barrier Casework Unit in Croydon.
While that allocation was entirely a matter for the Home Secretary, it did mean that care then had to be
taken to ensure that representations made on the different types of claim had to be directed for
consideration to the correct officials. In this regard, errors occurred. The one reoccurring problem was that
representations relevant both to the decisions being taken in Glasgow and those being taken in Croydon
were considered by officials in the former, but not the latter. A number of the decisions on the human rights
claims have failed for this reason: see below.

182. As explained below, Claimant by Claimant, we have considered each decision on its own merits. The
submissions to the effect that decisions were taken in a way that was procedurally unfair are addressed in
the next section of this judgment.

183. During the hearing, the Claimants made a new suggestion (not developed in any of the Skeleton
Arguments) as to how the issues in this litigation should be managed. This was to the effect that this court
should first decide the legality of the decisions under paragraph 19(c)of Schedule 3 to the 2004 Act to
certify the human rights claims as “clearly unfounded”; that if any such decision was held to be unlawful,
the hearing of all other aspects of these judicial review proceedings (including the inadmissibility decisions
taken under paragraphs 345A and 345C of the Immigration Rules) should be stayed pending consideration
by the First-tier Tribunal of the appeals against the human rights decisions; and only once those appeals
(and any subsequent appeals arising) had been determined should this court decide the other grounds of
challenge. The premise for this suggestion was that the First-tier tribunal, not this court, was the
appropriate forum to decide if removal of any of the Claimants to Rwanda would be in breach of their
Convention rights.

184. We did not consider that that course of action to be appropriate. This court is seized of a number of
judicial review claims which (among other matters) contend that inadmissibility and removal decisions are
unlawful because those decisions are incompatible with a claimant's rights under article 3 of the ECHR.
The court should, therefore, deal with those claims and should not leave them undetermined. Further, in
one case, AHA, no human rights decision has been taken and the only challenge at present is to the
inadmissibility decision.


-----

Commissioner for Refugees intervening) and other case....

185. Ultimately, while the Claimants raised this suggestion, no claimant applied to stay, or withdraw his
individual claim. We are satisfied that this court should deal with all matters before it, and, so far as
concerns the challenges to the human rights decisions, is capable of dealing fairly and adequately with the
issues that have been raised.

(2)  AAA (Syria) (Claimant 1, CO/2032/2022)

186. AAA was born in Derik, in Syria, in 2000. He is of Kurdish origin. In his witness statement, AAA says
he lived in the north eastern area of Syria which was controlled by a group known as the Kurdish YPG. He
says that the group wanted him to join the

YPG forces and fight the Syrians, but neither he nor his father wanted him to. He says that his father and
brother paid someone $20,000 to enable him to leave Syria. AAA says he left Syria on about 2 September
2021, crossed into Turkey and travelled to France.

(i) Arrival and detention in the United Kingdom

187. On 9 May 2022, AAA arrived in the UK having travelled in a small boat from Dunkirk in France. He
was intercepted by Border Force officials and detained at an immigration detention centre at Yarl's Wood.

188. On 10 May 2022, AAA claimed asylum. On 11 May 2022, he had a screening interview with
immigration officials. The record of the interview notes that AAA gave his main language as KurdishKurmanji but that he spoke some Kurdish Badhini and was content to continue in Kurdish Badhini for the
screening interview. An interpreter interpreted by telephone. He was asked to outline his journey to the
United Kingdom. He said that he left Syria on 3 September 2021 going to Turkey on foot where he stayed
for one month. He said that he travelled to an unknown country by lorry and then by train to France and
stayed in France for 7 to 8 months. He travelled to the UK by boat arriving on 9 May 2022. The record
notes that AAA said that he had understood all of the questions asked.

(ii) The notice of intent

189. On 13 May 2022, AAA was provided with a document headed “Notice of intent – this is not a decision
_letter”. That letter stated that before AAA claimed asylum in the United Kingdom he had been present in, or_
had a connection with, France and that could have consequences for whether his asylum claim was
considered in the UK. The notice was in the form explained above at paragraph 33 and stated that the
Home Office would review his particular circumstances to determine whether it was reasonable to have
expected him to claim asylum in France. It indicated that, amongst other things, the Home Office might ask
Rwanda, another country considered to be safe, if it would in principle be prepared to admit AAA. The
notice said that it was important that these inquiries be completed promptly. It said that:

“If you wish to submit reasons not already notified to the Home Office why your protection claim should not
be treated as inadmissible, or why you should not be required to leave the UK and be removed to the
country or countries we may ask to admit you (as mentioned above), you should provide those reasons in
writing within 7 calendar days of the date of this letter. After this period ends, we may make an
inadmissibility decision on your case based on the evidence available to us at that time”

190. In his later witness statement, AAA says that he had a copy of the notice but did not understand it. He
says that the Home Office called him using an interpreter who spoke Kurdish Sorani and he understood
that they were saying that he might be taken to Rwanda and that he had seven days and needed to speak
to a solicitor.

191. On 14 May 2022, AAA was transferred to IRC Brook House. The documentation records he
underwent an induction session at Brook House. It records that the duty solicitor scheme had been
explained to AAA including the times of surgeries and the initial appointment. The documentation noted
that AAA wanted a solicitor and one had been booked for 17 May 2022. It noted that AAA needed
interpretation into Kumanji. The documentation noted AAA had been provided with a mobile phone. No
welfare concerns were noted and none were recorded as having been raised by AAA.


-----

Commissioner for Refugees intervening) and other case....

(iii) The inadmissibility decision

192. On 31 May 2022, AAA was issued with a letter headed “Inadmissibility of Asylum Claim and Removal
from the United Kingdom”. This was a decision under Paragraph 345A of the Immigrations Rules. The
letter noted that, on the evidence provided, the Home Secretary was satisfied that AAA could have enjoyed
sufficient protection in a safe third country, France, basing that conclusion on the fact that he travelled to
France and stayed there for 7 or 8 months before arriving in the UK by boat on 9 May 2022. The letter also
considered removal to Rwanda and stated:

“It is proposed to remove you to Rwanda (a possibility notified to you in the Notice of Intent, issued
previously). It is considered that Rwanda is a place where your life and liberty will not be threatened by
reasons of your race, religion, nationality, membership of a particular social group or opinion; and a place
from which you will not be sent to another State otherwise than in accordance with the Refugee
Convention or otherwise than in accordance with Article 3 of the European Convention on Human Rights.
Rwanda is also considered to be a country with an effective asylum system, which can be expected to
properly meet your protection needs”.

The letter also contained a decision under paragraph 17 of Part 5 of Schedule 3 to the 2004 Act, certifying
AAA's asylum claim. Certification had the effect of preventing AAA from bringing an appeal on grounds
inconsistent with the opinion leading to the certification decision (see paragraph 19 of Schedule 3, as then
in force).

193. On 31 May 2022, AAA was also served with a notice of liability to removal and removal directions
which provided for his to Rwanda at 22.30 on 14 June 2022. Those removal directions were cancelled on 9
June 2022.

(iv) The representations

194. On 1 June 2022, AAA says he contacted Care4Calais, a charity that works with asylum seekers. He
provided them with copies of the documents he had including the notice of intent. Care4Calais referred him
to Duncan Lewis, a firm of solicitors. On 4 June 2022 AAA met a solicitor from Duncan Lewis; a Kurdish
Kumanji interpreter was present. On 6 June 2022, solicitors acting for AAA made written representations to
the Home Secretary. Those representations alleged that the process for inviting representations were
unfair. They contended that AAA's claim should not be treated as inadmissible as AAA had been told that
members and supporters of the YPG group lived in France and he feared that, if he remained there, he
would be discovered by the YPG and would be in trouble for refusing to join him. The representations
stated that AAA was not suitable for transfer to Rwanda as: (1) he was illiterate which would hinder his
ability to engage with the asylum process; (2) he had a significant and unassessed mental health condition

and had expressed suicidal ideation; and (3) he did not speak English or any of the other major languages
spoken in Rwanda. The letter further stated that the representations included a human rights claim (i.e., a
claim that removal to Rwanda would be incompatible with AAA's Convention rights). The solicitors sought
an extension of time to make further representations.

195. On 7 June 2022, AAA made a witness statement. He repeated his account of travelling from Syria via
Turkey to France and spending 7 or 8 months in France. He says that he spoke by phone to a friend living
in the UK and the friend advised him not to stay in France because there were YPG supporters there and it
would not be safe for him. AAA says that he spoke to his uncle by phone, and that he told him there were
YPG supporters in neighbouring countries and advised him that he would be safer if he went to the UK.
AAA says that he did not claim asylum in France because he was scared that if he stayed in France the
YPG supporters would find him and he would be in trouble. He says that he was scared that the YPG
supporters would kill him.

(v) The claim for judicial review

196. On 8 June 2022, AAA and other claimants issued a claim for judicial review (CO/2032/2022). Among
other matters, that claim challenged the inadmissibility decision of 31 May 2022. AAA was subsequently


-----

Commissioner for Refugees intervening) and other case....

granted permission to include a challenge to a subsequent inadmissibility decision dated 5 July 2022, and
the decision to refuse his human rights claim and to certify it as manifestly unfounded also made on 5 July
2022. Those decisions are described below.

(vi) Subsequent representations

197. On 27 June 2022, Dr Komolafe wrote to the Healthcare Team at Brook House stating he had
assessed AAA as having symptoms of depression and anxiety, and panic attacks. He said that AAA had
disclosed suicidal thoughts. On 7 July 2022 he made a fuller report. On 1 July 2022, solicitors for AAA
made further detailed written representations.

(vii) The 5 July 2022 inadmissibility decision.

198. On 5 July 2022, the Home Secretary provided a letter, again headed “Inadmissibility of Asylum Claim
_and Removal from the United Kingdom”. The letter explained that following receipt of representations,_
consideration had been given as to whether Rwanda was a safe country to which AAA could return. The
letter explained that it was to be read in conjunction with the previous decision letter (of 31 May 2022). The
letter stated that the Home Secretary had reviewed all material in AAA's case including: material provided
by the UNHCR as evidence in the judicial review proceedings; the representations of 6 June 2022; and
AAA's witness statement of 7 June 2022.

199. The letter stated that the decision stated that the conclusions previously reached on rule 345A(iii)(b)
had been reviewed (i.e., whether AAA could have claimed protection in France and whether there were
exceptional circumstances preventing such an application being made). The letter continued:

“You have stated in your witness statement that you did not claim asylum in France as you felt it was not
safe there. It is noted in your screening interview when you were asked why you did not claim asylum
before coming to the UK you stated that you did not claim because you have family in the UK and wanted
to come to the UK to be with your family rather than raising any concerns about your safety in France. It is
further noted by your own admission that were able to make phone calls to both your friend and uncle and
as such it is considered that you had the opportunity to claim in France. You now claim that you did not do
so because you were told it was unsafe in France. However, even if there are YPG supporters in France,
there is no reason why France would not have provided protection for you. It is considered that there were
no exceptional circumstances which prevented you from claiming asylum in France”.

200. The decision of 5 July 2022 also dealt with the question of whether Rwanda was a safe country for
AAA. The conclusion reached by the Home Secretary was there was no risk either that AAA would be
refused entry on arrival, or that his claim would not be passed to the relevant authorities for consideration.
AAA's alleged vulnerabilities arising out of significant and unassessed mental health conditions were also
considered. The decision was that these issues could be addressed in Rwanda and they would not impact
on AAA's ability to engage with the asylum process in Rwanda.

201. The letter then dealt with several other specific topics including whether there was a gap in the
protection system in Rwanda, appeals in Rwanda, refoulment from the airport, risk of bias, the risk of nonreferral of the asylum claim, accommodation and support in Rwanda, the evidence of the UNHCR and the
ability of Rwanda to comply with the assurances in the MOU and the notes verbales, and other matters.

202. The letter set out the conclusion that Rwanda was a safe country for AAA in his particular
circumstances, and stated that the decision on paragraphs 345B(i), (ii) and (iv) “is maintained”. The
decision to certify the asylum claim under Part 5 of the 2004 Act was also maintained.

(viii) The human rights decision

203. A further letter, also dated 5 July 2022, but prepared by a different Home Office official, working in a
different team, set out the decision on AAA's human rights claim. This decision considered the
representations made by AAA's solicitors dated 6 June 2022 and 1 July 2022. The decision did not,
however, take account of the material filed by the UNHCR in the judicial review claim. We have been told


-----

Commissioner for Refugees intervening) and other case....

that the official who took the human rights decision had not seen the inadmissibility decision, and viceversa.

204. The decision on the human rights claim was that removal to Rwanda would not be incompatible with
AAA's Convention rights. Further, the human rights claim was certified under paragraph 19(c) of Schedule
3 to the 2004 Act as clearly unfounded, thus preventing any appeal against the decision (see the version of
paragraph 19(c) in force with effect from 28 June 2022).

(ix) The challenges raised by AAA specific to his own circumstances

205. AAA makes the following specific challenges to the decision that AAA was not prevented by
exceptional circumstances from making a claim for asylum in France:

(1) the Home Secretary did not consider the 1 July 2022 representations when reaching the inadmissibility
decision;

(2) the Home Secretary acted on the basis of a mistake of fact when taking the inadmissibility decision.
She thought that AAA had said in his screening interview that he had not claimed asylum in France
because he had family in England. That was not so. The Home Secretary had mixed up the facts of AAA's
case with the facts of a different case (brought by the claimant AHA);

(3) the Home Secretary failed to provide adequate reasons for the conclusion;

(4) the Home Secretary had had regard only to objective circumstances and failed to consider, as she was
required to do on a proper interpretation of rule 345A(iii)(b), AAA's subjective state of mind; and/or that that
decision was irrational or failed to have regard to his state of mind; and

(5) it was irrational for the Home Secretary to maintain reliance on her previous conclusions set out in the
31 May 2022 letter.

206. Mr Dunlop KC, on behalf of the Home Secretary made the following submissions. First, he accepted
that the inadmissibility decision had been taken without regard to the 1 July 2022 representations.
However, he submitted that the 1 July 2022 representations had been considered when the human rights
decision was made and the decisions should be read together. _Second, he accepted that the_
inadmissibility decision had confused AAA's evidence with the evidence given by AHA, and that AAA had
not said that he had not claimed asylum in France because he had family in the United Kingdom.
Nevertheless, he submitted that the error was not material as the inadmissibility decision had addressed
the question of whether AAA's fears over safety prevented him from claiming asylum in France. He further
submitted on this point that it was highly likely that the outcome for AAA would have been the same even if
that error had not occurred so that a remedy ought to be refused pursuant to section 31(2A) of the Senior
Courts Act 1981. Third, Mr Dunlop accepted that the letter dated 27 June 2022 from Dr Komolafe had not
been considered when the inadmissibility decision was taken. However, he submitted that the decisionmaker had considered the pleadings in the judicial review claim which raised mental health conditions
similar to those raised by Dr Komolafe. Further, the doctor had made a further report after the 5 July 2022
admissibility decision, and that would have to be considered. He submitted that because the Home
Secretary had agreed to consider this later report, no purpose would be served by granting any remedy in
respect of any failure to have regard to the earlier letter. Fourth, he submitted that when the inadmissibility
decision was taken, regard had been had to the objective facts and AAA's subjective state of mind, arising
out of what he had been told. However, the conclusion reached was that they did not amount to
exceptional circumstances preventing AAA from claiming asylum in France.

(x) Conclusions

207. There are a number of flaws in the reasoning contained in the 5 July 2022 inadmissibility decision.
The decision took account of the wrong facts. It is clear that


-----

Commissioner for Refugees intervening) and other case....

the decision that AAA had not been prevented from making an asylum claim in France was materially
influenced by the erroneous belief that AAA had originally said he had family in the UK and wanted to
come here rather than claim asylum in France.

208. This was not an immaterial error. The decision begins by noting that AAA had said in his witness
statement that he did not claim asylum in France because he did not feel safe there. Then in the next
sentence, the decision notes (wrongly) that AAA had initially claimed that he had family in England. Later,
the decision letter notes that AAA “now” claimed that he did not claim asylum in France because he felt
unsafe. The decision letter then refers to the possibility of protection in France. The final conclusion was
that there were no exceptional circumstances which prevented AAA from claiming asylum in France. Thus
the (erroneous) view that AAA had said he wanted to come to England where he had family, and what he
later said about not feeling safe in France, were taken together, part and parcel within the decision. That
decision was materially influenced by the erroneous belief about the original basis for not claiming asylum
in France.

209. Further, there are two other matters the Home Secretary did not consider when taking the
inadmissibility decision of 5 July 2022 – the representations made on 1 July 2022 and the 27 June 2022
letter from the doctor. We do not accept that it was sufficient that a different official, taking a different
decision (the human rights decision) considered those documents. It is for the Home Secretary to decide
how and by whom different decisions will be taken within her department. If she decides that different
decisions are to be taken by different teams, she must ensure that the different teams have the material
relevant to their decision (or, as a minimum, an adequate summary of that material) available to them when
they come to take their decision. In the present case, that did not happen: the inadmissibility decision was
taken without access to or consideration of relevant material. It is not sufficient that all the material was – in
a general sense – known to the Home Office; there is no reverse _Carltona principle: see_ _R (National_
_Association of Health Stores) v Secretary of State for Health_ _[2005] EWCA Civ 154 per Sedley LJ at §§24_
– 38. Nor, in this instance, was it sufficient merely to consider AAA's pleadings in these proceedings. The
pleadings refer in general terms to the need to assess mental health conditions for five Claimants
(including AAA). That falls far short of consideration of the material in the 27 June 2022 letter from the
doctor.

210. Given that the decision of 5 July 2022 was materially influenced by an erroneous belief as to the
reasons why AAA did not claim asylum in France, and given also the failure to have regard to relevant
representations and evidence, the decision is legally flawed. We cannot say whether it is highly likely that
the outcome would be substantially the same for AAA if those errors had not been made. We simply do not
know. There is no evidence that the Home Secretary would have come to the same decision if these errors
had not occurred.

211. We consider, on the facts of this case, that the reasoning in the inadmissibility decision of 5 July 2022
superseded the reasoning in the earlier decision of 31 May 2022. The reality is that the issues raised under
paragraph 345A were considered afresh, in the light of further evidence and further representations, and
the conclusion was reached that AAA's claim was inadmissible. The Home Secretary therefore maintained
the decision reached in the 31 May 2022 letter for the reasons given in the 5 July 2022 letter. Given that
the reasoning in the 5 July 2022 letter is flawed, that decision must be quashed. As the 31 May 2022
decision was maintained only because of that flawed reasoning, we consider that the sensible course is
(for the avoidance of any doubt) also to quash that decision. That will enable the Home Secretary to
consider afresh, and reach a determination on, the question of whether or not AAA's claim is inadmissible
under paragraph 345A of the Immigration Rules, and whether it is appropriate to remove him to Rwanda.
That consideration will be based on all the material available at that time. In the light of that conclusion, we
make only the following observations on the remaining grounds of challenge that are specific to AAA's
circumstances.

212. On the question of objective and subjective circumstances, it was said in AAA's case that, whilst
objectively there was nothing to prevent him from claiming asylum in France, subjectively he was
concerned for his safety in France and was scared that he would be killed by YPG supporters It is said


-----

Commissioner for Refugees intervening) and other case....

that the Home Secretary had to consider whether AAA's subjective belief amounted to exceptional
circumstances for the purposes of paragraph 345A(iii)(b) of the Immigration Rules. As that matter is to be
considered by the Home Secretary, it would not be appropriate to express a definitive view on that issue.
We do, however, make the following general observations.

213. The relevant question under paragraph 345A(iii)(b) is whether there were “exceptional circumstances
preventing” the individual from applying for asylum in the country concerned. First, we would not rule out
the possibility that there may be circumstances where an individual had a genuine belief that he would not
be safe in a particular country and so did not claim asylum in that country. The fact that there were no
reasonable grounds for such belief may be one factor relevant to assessing whether the belief was
genuinely held. Secondly, the Home Secretary will have to consider, in each such case, whether any belief
held amounts to exceptional circumstances “preventing” that individual from claiming asylum in that
country. It would not be sufficient if they were merely circumstances which provided a reason, or even a
reasonable excuse, for not making an asylum claim in the third country. It may well be open to the Home
Secretary to conclude that a genuine belief explained why the individual did not claim asylum in a particular
country, but also to conclude that the belief did not prevent him from doing so. Thirdly, the Home Secretary
accepted the possibility that there may be cases where psychological reasons existed which prevented a
person from claiming asylum in a particular country (although she considered that such cases would be
likely to be exceptional). For present purposes, we simply note that in this case it will be for her to consider,
on all the relevant material, whether AAA really had a genuine and honest belief that he would not be safe
in France and if so, whether that belief did prevent him from claiming asylum in France.

214. On the question of consideration of Dr Komolafe's report of 8 July 2022, that was provided to the
Home Secretary after the decision of 5 July 2022. As such, she could not have considered it at the time
that she reached her inadmissibility decision and made no legal error by not having regard to it. Now that
the matter is to be considered afresh, the Home Secretary will need to consider all relevant material
including the report of 8 July 2022.

215. We do not consider it necessary to express a view on the adequacy of the reasons in the 5 July 2022
inadmissibility decision. The decision rested on one error and did not consider certain matters. Those are
the flaws leading to the decision being quashed. The failure to give reasons in relation to erroneous
matters or matters that were not considered does not materially add anything to the challenge.

216. We turn next to the decision to refuse the human rights claim and to certify that claim as clearly
unfounded. This decision was not taken having regard to material that was potentially relevant to that
decision – i.e., the material that, by 5 July 2022, had been filed and served by the UNHCR in these
proceedings. It is no answer to that criticism to say that in a different decision (the inadmissibility decision)
regard was had to that material and that the two decisions must be “read together”. That would be a fiction
too far. The person who took the human rights claim on behalf of the Home Secretary did not have
available relevant material (or a summary of it) and did not even have a copy of the inadmissibility decision
which did consider that material. Furthermore, in certifying the human rights claim as clearly unfounded, a
different legal question had to be addressed: whether an appeal to a tribunal, properly directing itself on the
law and the evidence, would be bound to fail. The person taking the inadmissibility decision did not have to
address that question and did not express a view on it. Given that the human rights decision-maker did not
consider material that was potentially relevant to the certification question, it is no answer to say that his
decision should be read with a different decision which did not consider that question at all. The 5 July
2022 human rights decision, and the certification of that claim as manifestly unfounded must therefore be
quashed.

(3)  AHA (Syria) (Claimant 2, CO/2032/2022)

217. AHA was born in September 2000. He is a Syrian national. He says that he left Syria as he feared
being required to undertake military service in Syria.

(i) Arrival and detention in the United Kingdom


-----

Commissioner for Refugees intervening) and other case....

218. On 20 May 2022, AHA crossed from France to the United Kingdom by small boat. The boat was seen
by the UK Coast Guard while still at sea and AHA and the other occupants of the boat were brought to the
United Kingdom. He was detained and taken to IRC Yarl's Wood. He claimed asylum.

219. On 22 May 2022, he had a screening interview. An interpreter interpreted by phone. The record of
the interview notes that AHA said that he was fit and well and was not taking medication. He was asked to
describe his journey to the United Kingdom. The record states he said that he left Syria in July 2018 and
crossed the border on foot to Turkey where he stayed for four years before leaving for Greece. He
described a journey from Greece to Albania and then to Serbia. The record says that he travelled to
Cornwall where he stayed for about two days. That appears to be a mis-transcription and (according to
AHA's later witness statement) should record that he travelled from Serbia to Hungary. AHA then travelled
to Austria by foot and stayed 10 days there. He then travelled by car to France and stayed 3 days there
before travelling by rubber dinghy to the United Kingdom.

220. Asked why he had not claimed asylum on his way to the United Kingdom, the record says that AHA
said “Because I close family in the UK I want to stay there”. Asked if there was any reason why AHA could
not be returned to one of the countries he had travelled through, AHA is recorded as saying “I wanted to
_come here because my brother lives here”._

(ii) The notice of intent and the representations

221. On 23 May 2020, AHA was provided with a document headed “Notice of intent – this is not a decision
_letter”. That letter stated that before AHA claimed asylum in the United Kingdom he had been present in, or_
had a connection with, France, Greece, Hungary and Austria and noted that might have consequences as
to whether his asylum claim would be admitted to the UK asylum system and could mean that he might be
removed either to one of the countries names, or the United Kingdom might ask Rwanda to admit him.

222. The letter invited AHA to submit written reasons within seven days of the date of the letter why the
claim should not be treated as inadmissible or why he should not be removed from the UK to one of the
countries mentioned, or Rwanda. The letter stated that, after the period for representations had expired, a
decision on whether the asylum claim was inadmissible would be made, based on the evidence available
at that time.

223. The letter was given to AHA by an official at IRC Yarl's Wood. The official explained that AHA needed
to tell the Home Office within seven days why he should not be sent to another country or to Rwanda and
that he should contact a lawyer.

224. On 26 May 2022, AHA instructed Duncan Lewis, a firm of solicitors, although AHA says it took some
days, until 29 May 2022, for relevant documents to be signed authorising the solicitors to represent him.
On 30 May 2022, Duncan Lewis submitted written representations to the Home Office, running to
approximately 10 pages, making submissions about the process by which representations had been
invited, giving reasons as to why AHA had not claimed asylum in Greece, Hungary, Austria or France, and
why he should not be removed to Rwanda: namely that AHA had significant unassessed mental health
conditions; did not speak English or any major language spoken in Rwanda; and had close family
connections with the UK as he had a brother in the UK. The representations also made a human rights
claim, contending that removal to Rwanda would be a breach of his rights under articles 3 and 8 of the
Convention because of AHA's mental health, family connections in the UK and a concern that he would be
unable to access protection (i.e. make an asylum claim) in Rwanda. The representations also sought an
extension of time to make further representations.

(iii) The inadmissibility decision of 1 June 2022.

225. By letter dated 1 June 2022, the Home Secretary decided that AHA's claim for asylum was
inadmissible. The letter stated that she had not received any representations from AHA. This was incorrect.
The Home Secretary had received the representations dated 30 May 2022 summarised above. In terms of
substance, the decision letter stated that the Home Secretary was satisfied that Austria and France were
safe third countries for AHA She proposed to remove AHA to Rwanda as that was a place where AHA's


-----

Commissioner for Refugees intervening) and other case....

life and liberty would not be threatened by reasons of his race, religion, nationality, membership of a
particular social group or political opinion, and where he would not be sent to another state otherwise than
in accordance with the Refugee Convention and article 3 of the Convention.

226. On the same day, the Home Secretary issued removal directions for AHA to be removed to Rwanda
on 14 June 2022. Those directions were cancelled on 9 June 2022.

(iv) The claim for judicial review

227. On 8 June 2022, AHA filed a claim for judicial review seeking to challenge the inadmissibility decision
of 1 June 2022 (claim CO/2032/2022). Subsequently, he was granted permission to amend the claim to
challenge a later inadmissibility decision of 5 July 2022 described below.

228. AHA made a witness statement in these proceedings, dated 8 June 2022. In that witness statement,
he says that he spent only two days in Austria. He says that he was detained by authorities on arrival and
his belongings were confiscated. He says that when released he was scared of being detained again and
wanted to leave Austria as soon as possible. He says he did not view Austria as a safe country. He says
that he travelled directly from Austria to Calais in France and stayed there for four days sleeping under a
bridge with group of other people. He says that the police came each morning and took all their belongings.
He said the police were horrible towards the refugees in the area and he did not feel safe.

(v) Subsequent representations and evidence

229. AHA was seen by a doctor at the detention centre. The doctor provided a report dated 1 June 2022
under Rule 35 of the Detention Centre Rules 2001. The report recorded AHA's account including his claim
that he was trafficked via Albania and Serbia, that the mafia took all his possessions, that in Greece he
was made to take his clothes off and put in the cold, and was beaten and pushed (the report does not
record who or which authorities in which country are said to have beaten and pushed AHA). The doctor
noted that AHA did not have any scars on his body. The report noted that AHA's “narration of events [is]
_consistent with torture and would need to be looked into further”._

230. By letter dated 1 July 2022, solicitors for AHA made further detailed submissions on, amongst other
things, why the inadmissibility decision of 1 June 2022 should be withdrawn and why AHA's asylum claim
should not be declared inadmissible under paragraph 345A of the Immigration Rules. The letter included,
amongst other things, the Rule 35 report.

(vi) The 5 July 2022 inadmissibility decision

231. The decision letter of 5 July 2022 referred to the inadmissibility decision letter dated 1 June 2022
(although it mis-dated the earlier letter as a letter of 4 June 2022). It said that the 5 July 2022 letter should
be read in conjunction with the June letter. The 5 July 2022 letter made it clear that the decision-maker had
had regard to the representations of 30 May 2022, the Rule 35 report and the material filed by the UNHCR
in the judicial review proceedings.

232. The decision letter stated that AHA had said in his witness statement that he did not claim asylum in
France as he felt it was not safe there. It noted that by his own evidence he had regularly had contact with
the police in France and he had the opportunity to claim asylum in France while he now claimed that he did
not do so “because you were told that it was unsafe in France”. The conclusion stated in the letter was that
there were no exceptional circumstances which prevented AHA claiming asylum in France, and maintained
the earlier decision in that regard. The letter does not refer to Austria. The letter further stated that AHA
would be removed to Rwanda and dealt with a number of

issues related to that question, again maintaining the conclusion stated previously in the June 2022 letter.
Lastly, the 5 July 2022 letter (as had the June letter) contained a decision to certify the asylum claim under
paragraph 17 of Schedule 3 to the 2004 Act.

233. The inadmissibility decision expressly stated that it was not a decision on AHA's human rights claim,
which would be dealt with separately following conclusion of consideration of whether AHA was a victim of


-----

Commissioner for Refugees intervening) and other case....

trafficking. To date, no decision has been taken on AHA's human rights claim. AHA cannot be removed
from the UK until that claim is determined and either all appeals are exhausted or the claim is certified as
manifestly unfounded.

(vii) The challenges raised by AHA specific to his own circumstances

234. AHA makes the following specific challenges to the decision that he was not prevented by
exceptional circumstances from claiming asylum in France:

(1) The 5 July 2022 inadmissibility decision was made without consideration of the 1 July 2022
representations;

(2) The inadmissibility decision rested on a mistake of fact because the Home Secretary had confused the
facts of AHA's case with the facts of AAA's case. The decision rested on the premise that AHA had said he
had not claimed asylum in France because he had been told it was unsafe, but that was what AAA had
said. AHA had said that he had not made a claim because he had been mistreated by the French police;

(3) No adequate reasons were provided for the inadmissibility decision;

(4) When applying rule 345A of the Immigration Rules, the Home Secretary had regard only to objective
circumstances and failed to consider AHA's subjective state of mind; and/or failed to have regard to his
state of mind; and/or reached an irrational conclusion; and

(5) It was irrational for the Home Secretary to maintain reliance on her previous conclusions set out in the
1 June 2022 letter.

235. Mr Dunlop accepted that the decision letter wrongly referred to AHA saying that he had been told that
it was unsafe to remain in France and accepted that that was what AAA had said in his interview. He
submitted, however, that the error was not material and, in any event, no remedy was required as the
Home Secretary had already stated that she intended to take a fresh inadmissibility decision in order to
consider further evidence that had been provided on 7 July 2022. Mr Dunlop accepted that there was no
evidence that regard had been had to the 1 July 2022 representations, but submitted those representations
added nothing of substance. He submitted that when the inadmissibility decision reflected consideration
both of objective and subjective features (i.e., what AHA said about his state of mind).

(viii) Conclusions

236. There are several flaws in the 5 July 2022 inadmissibility decision. First, the decision did rest on a
mistake of fact – the accidental transposition of AAA's evidence into the decision made on AHA's case.
The Home Secretary has not, therefore, properly considered AHA's case on the application of paragraph
345A of the Immigration Rules – which is based on the ill-treatment he says was afforded to him by the
French police. In the premises, the inadmissibility issue has not been properly determined. _Secondly, on_
the evidence before this court, it appears the Home Secretary did not consider the written representations
of 1 July 2022. That is not remedied by the fact that some of the points made in those representations were
in fact considered by the decision-maker. Other matters set out in the representations, such as the claim
that AHA was prevented by claiming asylum by the alleged abusive treatment of the French authorities
were not considered. Further, we would regard the decision-letter as inadequately reasoned as it does not
address the principal reason given by AHA for not claiming asylum in France.

237. Given the errors in the 5 July 2022 inadmissibility decision that decision must be quashed. We are
not persuaded by the argument that there is no need to grant a remedy because the Home Secretary
proposes to take a fresh decision. The decision of 5 July 2022 is legally flawed and has not been
withdrawn. Therefore, it should be quashed.

238. As for the 1 June 2022 decision, the conclusion and reasons set out in AAA's case apply here too.
The 5 July 2022 decision effectively superseded the 1 June 2022 decision; the 5 July 2022 letter purported
to maintain the June decision for the reasons in the 5 July decision. Since the 1 June 2022 decision was
maintained only because of the flawed reasoning in the 5 July 2022 letter, that letter too should, for sake of


-----

Commissioner for Refugees intervening) and other case....

completeness, also be quashed. In any event, the 1 June 2022 decision was, on its own terms, flawed
because it failed to have regard to the representations made on 30 May 2022. Had that decision remained
an operative decision, it would fall to be quashed for that reason.

239. In these circumstances, it is not necessary to consider the question of objective and subjective
reasons why AHA did not claim asylum. We have set out our general observations on that issue above.
The matter will be remitted to the Home Secretary so that she may consider, on the basis of all the material
and representations available at the time of that decision, whether exceptional circumstance prevented
AHA from claiming asylum in a safe country such as France, or Austria, or any other safe country.

(5)  AT (Iran) (Claimant 4, CO/2032/2022)

240. AT is an Iranian national of Kurdish ethnicity. He was born in March 1998. He says that he distributed
leaflets for a Kurdish political party, which is illegal in Iran. He says that he fears that he would be killed or
tortured in Iran.

(i) Arrival and detention in the United Kingdom

241. On 17 May 2022, AT arrived in the United Kingdom having travelled from France in a small boat. He
was detained at IRC Yarl's Wood. He claimed asylum.

242. On 18 May 2022, AT attended a screening interview. He said his main language was Kurdish Sorani,
and an interpreter interpreted by phone. He was asked to describe his journey to the United Kingdom. He
said that he had left Iran 3 months earlier and travelled to Turkey where he stayed for 2 months. He then
travelled by lorry to an unknown country (close to Italy) where he stayed for 2 days. He then was taken by
lorry

to the beach, then travelled to the UK by boat. He said an agent was used; AT's mother had paid the agent
€13,000. AT was asked why he had not claimed asylum on his way to the United Kingdom and said, “I did
not know the countries I was travelling through”.

(ii) Notice of Intent

243. On 20 May 2020, AT was provided with a document headed “Notice of intent – this is not a decision
_letter”. That letter noted that before AT claimed asylum in the United Kingdom he had been present in, or_
had a connection with, France and Italy, and stated that that may have consequences as to whether his
asylum claim would be admitted to the UK asylum system. The letter continued in the form we have
already described above: referring to the possibility of an inadmissibility decision, a decision to remove AT
either to France or Italy or some other safe third country, the possibility of removal to Rwanda; inviting AT,
within seven days, to make representations on why the claim should not be treated as inadmissible, or why
(if the claim was inadmissible) he should not be removed either to France or Italy or Rwanda. In a witness
statement prepared for these proceedings, AT says he was not given a translation of the notice of intent
but that a brief call with an interpreter was arranged who gave what AT describes as a “vague explanation”.
The interpreter suggested that AT get a lawyer.

(iii) Representations

244. On 27 May 2022, AT, with the assistance of a Kurdish Sorani interpreter, spoke with a lawyer from
Duncan Lewis following a referral by the charity Care4Calais.

245. On the same day, the solicitors sent written representations to the Home Secretary. In the description
of the background, they say that AT was taken by lorry to an unknown country close to Italy, and then by
lorry and van to France where he was forced by agents into a boat. They said that at no point was AT safe
or free to claim before arriving in the United Kingdom; that AT was not aware of the countries he was
passing through; and that he was kept locked in the van and when let out was closely watched by the
agents; and that the agents threatened him and were violent towards him when they forced him into the
boat. The solicitors criticised the process by which representations were invited. They made
representations on whether AT's asylum claim was inadmissible. They said that AT had not been in Italy at


-----

Commissioner for Refugees intervening) and other case....

any point but had been in a country a couple of hours from Italy; that AT had been the victim of
mistreatment at the hands of agents in France and was fearful of being forced to interact with these
individuals again; and that while under the control of agents, AT could not have made any application for
protection in any of the countries through which he passed. The solicitors also made representations as to
why AT was not suitable for transfer to Rwanda: that he had been the victim of torture; had suffered abuse
and violence at the hands of traffickers; suffered from significant and unassessed mental health conditions
and might have significant and unassessed physical health issues arising from being shot in Iran; and that
he did not speak English, or any other major language spoken in Rwanda.

246. The representations also made a human rights claim, that relocation to Rwanda would be a breach of
articles 3, 4 and 8 of the Convention as a result of the physical injuries and trauma arising out of being shot
in Iran, the likelihood that AT would be destitute and the subject of mistreatment and trafficking in Rwanda,
would not be able to access protection in Rwanda, and might be returned to Iran. The representations
sought an extension of time to make further representations.

(iv) The inadmissibility decision of 4 June 2022

247. On 4 June 2022, AT was provided with a decision that his asylum claim was inadmissible and he
would be removed to Rwanda. The decision came from the Third Country Unit of the Home Office. The
letter referred to and summarised the representations of 27 May 2022. The decision letter concluded that
AT could have enjoyed sufficient protection in France and there were no exceptional circumstances
preventing him from claiming protection in that country. The reasons given were, in effect, a recitation of
what AT had said in his screening interview: that he travelled by lorry to a country near to Italy, then to the
beach and then to the UK; and his mother had paid an agent €13,000. The letter does not address the
points raised in the representations that he had, throughout his journey to the United Kingdom, been
watched by agents who threatened him and were violent (for example, when forcing him into the boat).

248. The letter then dealt with why France was a safe third country for AT. Next, the letter stated that AT
could be removed to Rwanda, a place where AT would not be threatened by reason of his race, religion,
nationality, membership of a particular social group or political opinion, or from which he would be sent to
another state otherwise than in accordance with the Refugee Convention and the ECHR. However, the
letter stated that the specific concerns about Rwanda raised by AT (including the risk of being returned to
Iran) had not been considered in the inadmissibility decision but had been considered in the human rights
decision letter dated 4 June 2022. It said that the conclusions in that other letter that Rwanda was a safe
place for AT, and he would not be removed from there to a place of danger, stood for the conclusions in
the inadmissibility decision. The decision was certified under paragraph 17 of Part 5 of Schedule 32 to the
2004 Act. We have some difficulty in understanding parts of the letter. The reference to a human rights
decision letter dated 4 June 2022 appears to be wrong as that letter was dated 5 June 2022. We have
some difficulty also in understanding how the decision-maker on 4 June 2022 could be relying on a
decision by another civil servant which had not yet been taken. There is no evidence that the maker of the
inadmissibility decision saw an earlier draft of the 5 June 2022 letter and it would be speculation to assume
that.

(v)          The human rights decision of 5 June 2022

249. AT's human rights claim was refused in a letter dated 5 June 2002. This decision was taken by a
member of the Home Office “Detained Barrier Casework” team. That letter considered the adequacy of the
asylum arrangements in Rwanda and the risk that AT might, directly or indirectly, be returned to Iran. The
conclusion was that there was no risk either that AT's asylum claim would not be considered in Rwanda, or
that he would be returned to Iran; or that he would be ill-treated in Rwanda, or that removal to Rwanda
would put AT's health at risk. AT's human rights claim was certified as clearly unfounded.

(vi) The claim for judicial review


-----

Commissioner for Refugees intervening) and other case....

250. AT's claim for judicial review was filed on 8 June 2022. He challenged the inadmissibility decision and
the human rights decision of 4 June 2022. Later, he obtained permission to amend the claim to challenge
the inadmissibility and human rights decisions of 5 July 2022, described below.

251. AT's witness statement was made on 7 June 2022. AT said that he was put in the back of a lorry with
others leaving Turkey and kept there for many days, he thought seven days. He said he was occasionally
allowed out of the lorry to go to the bathroom. Whenever the lorry stopped, it was not near civilisation and
there was nowhere to run to or escape the smugglers. The smugglers watched them and warned them not
to create trouble or they would create trouble for the people in the group. AT said that at one stage, they
stopped for two days before changing lorries, but he says he does not know where this was. He said that
when he was told to get out of the van they were in a jungle near the sea. He said that the next day the
smugglers grabbed him and pushed into a boat. He says that during the screening interview he did have a
Kurdish Sorani interpreter on the phone but, he says, the whole process was rushed, he has learning
difficulties and only two years of primary education and was confused.

252. There is a rule 35 report, dated 8 June 2022, prepared by a doctor who saw AT in the detention
centre. He noted that AT said that he was shot at by policemen when delivering leaflets in Iran two years
ago. AT reported that the attack had lasted a few minutes and he collapsed; and that he was treated at a
hospital for a broken leg. The report says that on examination AT “has scars, which may be due to the
history given”. On 6 July 2022 (after the inadmissibility and human rights decisions were taken), AT
submitted a medical report from a Dr Galappathie.

(vii) The 5 July 2022 inadmissibility decision

253. On 5 July 2022 the Home Secretary issued a further decision on whether AT's asylum claim was
inadmissible. The letter stated that this, second, decision on inadmissibility should be read with the first
one, in the letter of 4 June 2022. The 5 July decision letter recorded that regard had been had to the
material filed by the UNHCR in the judicial review proceedings, AT's witness statement, and the
representations of 27 May 2022. The conclusion on the application of paragraph 345A of the Immigration
Rules, was as follows:

“You claimed that paragraph 345(iii)(b) is not applicable in your case because you were under the control
of agents and therefore unable to claim asylum in France. Further details were given in your witness
statement.

During your screening interview you were asked why you did not claim asylum on route to the UK and you
stated that you did not know which countries you travelled through on route to the UK. You also now claim
in your witness statement that you couldn't claim asylum as you were under the control of agents and did
not know what countries you travelled through. It is noted that in your screening interviews you stated that
you left Iran 3 months prior to entering the UK and stayed in Turkey for 2 months entering the UK. Leaving
an unspecified time between leaving Turkey and entering the UK. It is considered that in this period you
would have had the opportunity on your journey to claim asylum. We have taken into account your claim
that you are illiterate and have learning difficulties. However, by your own admission you were politically
active in Iran and therefore it is considered reasonable to assume that you are aware of the possibility of
claiming asylum and capable of doing so, furthermore as you have claimed asylum in the UK it is
considered you were aware of how to claim asylum and capable of doing so. You have provided little detail
about how or why the agent controlled you and prevented you from claiming asylum. Therefore, for the
reasons given above it is not accepted that there were exceptional circumstances which prevented you
from claiming asylum in France.

The previous conclusions relating to paragraph 345A of the immigration rules are maintained”.

254. The letter then addressed other matters before concluding (a) that Rwanda was a safe country for
AT, and (b) that the decision to certify under paragraph 17 of Schedule 3 to the 2004 Act should be
maintained.

(viii) The human rights decision of 5 July 2022


-----

Commissioner for Refugees intervening) and other case....

255. The decision of 5 July 2022 on AT's human rights claim was made by the Detained Barrier Casework
Team. The decision letter does not refer either to the material provided by the UNHCR in the judicial review
claim, or AT's witness statement. The letter concludes that in the light of “all the circumstances in our letter
dated 5 June 2022” the evidence and claims did not demonstrate a real risk that Rwanda would fail to
comply with the arrangements in the MOU and the Refugee Convention, or that and removal to Rwanda
would result in AT being treated in breach of Convention rights. The decision to certify the human rights
claim, previously set out in the 5 June 2022 decision, was maintained.

(ix) The challenges raised by AT specific to his own circumstances

256. AT makes the following specific challenges to the decision that he was not prevented by exceptional
circumstances from claiming asylum in France:

(1) it was irrational to draw adverse inferences from any inconsistency between the screening interview
and his witness statement;

(2) it was irrational to consider that he could have claimed asylum simply because he had been politically
active in Iran (and as such should be taken to be aware that asylum claims could be made);

(3) the decision not to accept AT's account that he was under the control of agents throughout his journey
to the United Kingdom was irrational and/or the reasoning was illogical.

AT challenged the human rights decision on the basis that the decision had been made without
consideration of the UNHCR material filed in the judicial review proceedings after the initial 5 June 2022
decision. He further submitted that the Home Secretary acted unlawfully by giving no warning that a
second decision was to be taken on the human rights claim. This had meant that the decision was taken
without a chance to consider a report by Dr Galappathie, sent to the Home Secretary on 6 July 2022.

257. Mr Dunlop submitted that the Home Secretary had not drawn adverse inferences from differences
between what AT said in the screening interview and in his witness statement. Rather, the conclusion on
the application of paragraph 345A of the Immigration Rules turned on the fact that AT had “provided little
detail about how or why the agent controlled you and prevented you from claiming asylum”. Further, he
submitted that the Home Secretary was entitled to take account of the fact that AT had been politically
active in Iran and had claimed asylum in the United Kingdom, as those matters were relevant to whether
AT had sufficient knowledge about asylum claims to claim in France to make such a claim in France. He
submitted that the 5 July 2022 human rights decision simply withdrew erroneous statements about the
UNHCR, and that it was not necessary for the UNHCR material to be considered in the human rights
decision because it had been considered in the inadmissibility decision, and both decisions had been taken
on the same day and should be read together. Dr Galappathie's report came after the decisions and there
was no error on the part of the decision-makers in not having regard to it.

(x) Conclusions

258. We deal first with the inadmissibility decision. So far as concerns the reference to AT's political
activity in Iran, the Home Secretary made no error. She was entitled to consider that AT's previous political
activity and the fact that he claimed asylum in the United Kingdom were relevant to whether he had
sufficient knowledge to be able to make an asylum claim in France. The sentence referring to these
matters comes after a reference to the fact that AT says that he is illiterate and has learning difficulties. The
Home Secretary was entitled to conclude that these circumstances did not prevent AT claiming asylum,
and to rely on the fact of his previous political activity and his later claim for asylum as indicating that
neither illiteracy nor learning difficulties had prevented AT from making a claim for asylum in France. The
Home Secretary made no error by not considering the report from Dr Galappathie. That report was not
provided to her (or indeed, written) until after the decisions and, that being so, she could not have taken it
into account.

259. The real issue in this case concerns the application of paragraph 345A(iii)(b) of the Immigration
Rules: the requirement that the asylum claimant “could have made an application for protection in a safe


-----

Commissioner for Refugees intervening) and other case....

third country” and there were “no exceptional circumstances preventing such an application being made”.
The reasoning in the 5 July 2022 decision is two-fold: first that there was a period of 1 month between
leaving Turkey and arriving in the United Kingdom and during that time AT could have made an asylum
claim during his journey; secondly, that AT provided little detail about how or why the agent controlled him
and prevented him from claiming asylum earlier.

260. The reasons for a decision that the requirements of paragraph 345A(iii)(b) are met can be stated
briefly. The Home Secretary may, in appropriate cases, draw inferences from matters such as the period
likely to have been spent in safe countries, and a failure to give adequate explanation in screening
interviews, witness statements or other representations as to why the claimant could not claim asylum.

261. In the present case, the Home Secretary was entitled to conclude that AT knew about the possibility
of claiming asylum and before arriving in the United Kingdom and had spent a sufficient time in safe third
countries (including France) to have had the opportunity to make a claim for asylum. Thus, the Home
Secretary was entitled to conclude that in this instance, the requirement in the first part of paragraph
345A(iii)(b) was satisfied. The real question, however, is whether she gave adequate reasons for
concluding that there were no exceptional circumstances that prevented AT from claiming asylum. AT's
representations and witness statement were that throughout the journey he was either locked up in a lorry
or, when the lorry stopped, it was “not near civilisation”, that he had no freedom to run or escape, and that
the smugglers would watch him and the others in the group. He said that all he knew was that his mother
had tried for him to arrange to get somewhere safe, but he was not sure what was happening or where he
was going and that he feared the smugglers and was unwilling to ask questions. AT did say that at one
stage the lorry stopped for two days. So far as France is concerned, AT said that he arrived, and the next
day was told to get into the boat and was grabbed and pushed into the boat.

262. On balance, we are not satisfied that the reasons in the 5 July 2022 letter adequately address the
points made by AT. We do recognise that there is a lack of detail in relation to the journey from Turkey to
France. If that is the period that the Home Secretary considers establishes that the second part of
paragraph 345A(iii)(b) was met, she would have needed to explain why that was the case. Similarly, in
relation to the time spent in France, if that is the period relied upon, the Home Secretary needs to provide
some reasoning as to why she considered that the circumstances were not exceptional and did not prevent
AT making an asylum claim. From the reasons given, is unclear whether the Home Secretary concluded
that the account given by AT, carefully analysed, did not demonstrate exceptional circumstances
preventing him from making a claim in France (i.e., AT could have refused to get into the boat and contact
authorities but did not do so, and that was more likely to be the result of a willingness to go along with the
smugglers whom his mother had paid rather than any exceptional circumstances preventing him from
making a claim in France). Or the Home Secretary may simply have dis-believed AT's account; or she
might conclude that the circumstances were not exceptional circumstances in the context in which those
words are used in paragraph 345A – i.e., that as a matter of principle, on a correct interpretation of the
Immigration

Rules a person who pays smugglers to transport him through safe countries to the United Kingdom, does
not comprise exceptional circumstances because any restriction on that person's ability to make a claim
arises from the decision to pay smugglers to transport him to the United Kingdom. Or there may be some
other reason. We do not consider that the 5 July 2022 decision letter adequately explains the reasons why,
in this case, the Home Secretary concluded the requirements of paragraph 345A(iii)(b) were met. For this
reason (only) we will quash the 5 July 2022 inadmissibility decision and remit the matter to the Home
Secretary for reconsideration. The Home Secretary will need to consider the matter afresh, and properly
explain her conclusion.

263. As the reasoning in the 5 July decision was essentially intended to be the reasons for maintaining the
earlier 4 June 2022 decision, and as the reasoning is not adequate, it is sensible also to quash the earlier 4
June 2022 decision (for the reasons given above in relation to AAA and AHA). That will enable the Home
Secretary to consider the matter afresh, taking account of all relevant material.


-----

Commissioner for Refugees intervening) and other case....

264. We consider that the 5 July 2022 decision refusing the human rights claim and certifying that claim as
unfounded should also be quashed. The decision did not consider the evidence put forward. It is no answer
to say that the inadmissibility decision and the human rights decision must be read together. As we have
explained,

each decision was taken by a different person in a different team. There is no indication in the human
rights decision letter, and no evidence before this court, that the person who took the human rights
decision first read the inadmissibility decision. In any event, the question of certifying the human rights
claim as clearly unfounded is a different issue. It would not have been considered by the person who took
the inadmissibility decision. The person who took the human rights decision would have to consider the
evidence (or an adequate summary of it) to determine whether the evidence was such that no tribunal
properly directing itself could allow an appeal. That has not happened in this case. Since the 5 July 2022
human rights decision replaced the 5 June 2022 decision, and its reasoning was intended to provide the
reasoning for the refusal of the human rights claim and certification of it as clearly unfounded, the 5 June
2022 decision should also be quashed.

(6)  AAM (Syria) (Claimant 8, CO/2032/2022)

265. AAM was born in Damascus in 2001 and is a Syrian national. He says that he left Syria as he would
have been imprisoned or killed because of refusal to join the military.

(i)          Arrival and detention in the United Kingdom

266. On 16 May 2022 he arrived in the United Kingdom, having travelled by small boat from France. He
was detained, first at IRC Yarl's Wood and then at IRC Colnbrook.

267. On 18 May 2022 he attended a screening interview. Asked why he had come to the United Kingdom
he is recorded as saying “Claim Asylum”. He was asked about his journey to the United Kingdom and is
recorded as saying: that he left Syria on 31 July 2021 and travelled to Libya by air and stayed there for 9
months; that he then travelled by boat to Italy and stayed for 10 days there; and that he then went to
France by train and stayed there for 10 days. He said the travel was organised by his family who paid
$6,000 to a smuggler to take him to the United Kingdom.

(ii)          The notice of intent

268. On 19 May 2022, AAM was provided with a document headed “Notice of intent – this is not a decision
_letter”. That letter noted that before AAM claimed asylum in the United Kingdom he had been present in, or_
had a connection with, Italy and France, and stated that could mean that his asylum claim would not be
admitted to the UK asylum system. The letter further stated that AAM might be removed either to Italy or
France, or that the United Kingdom might ask Rwanda if it was prepared, in principle, to admit him. The
letter invited AAM to make written representations within seven days of the date of the letter on why his
claim should not be treated as inadmissible, and why he should not be removed from the UK either to
France or Italy, or to Rwanda. The notice said that, after that period, an inadmissibility decision could be
made based on the evidence then available.

(iii) Representations

269. On 24 May 2022, Care4Calais referred AAM to Duncan Lewis. AAM spoke by phone with a case
worker, gave details of his case, and formally instructed Duncan Lewis to

make representations on why his asylum claim should be considered in the United Kingdom.

270. On 26 May 2022, Duncan Lewis (a) sent a letter setting out written representations; and (b) sent a
pre-action protocol letter to the Home Secretary. The representations said that AAM had travelled to Libya,
stayed there for 9 months and summarised alleged mistreatment he had undergone in Libya; that AAM
subsequently travelled by boat to Italy where he stayed for 10 days and then to France where he also
stayed for 10 days before travelling by boat to the United Kingdom. It was said that AAM recalled racist
treatment in both countries but especially in France and did not seek protection there as he had not felt


-----

Commissioner for Refugees intervening) and other case....

safe and lacked language skills and family ties. The representations stated that AAM “instructs that it was
always his plan to travel to the UK to claim asylum” but that “he also did not feel safe in any of the
countries that he was forced to spend time in”. Next, it was contended that AAM should not be removed to
Rwanda because he displayed symptoms of stress, depression, and anxiety, and of an as yet unassessed
mental health issues, and had expressed suicidal ideation. The representations further contended that
removal would be incompatible with AAM's Convention rights. The representations requested an extension
of time to make further representations. Similar points were made in a pre-action protocol letter.

(iv) The inadmissibility decision letter of 6 June 2022

271. The decision on admissibility was set out in a letter dated 6 June 2022. The decision referred to
representations having been made in the pre-action letter but did not refer to the written representations
provided separately the same day. The Home Secretary concluded that AAM's asylum claim was
inadmissible because AAM could have enjoyed protection in a safe third country but did not do so, and
there were no exceptional circumstances preventing an asylum claim being made before AAM arrived in
the United Kingdom. The Home Secretary relied on what AAM had said in his screening interview – that he
had travelled to Italy by boat and stayed there for 10 days and then travelled to France by train and stayed
there for 10 days. The letter did not expressly refer to the part of the written representations or pre-action
protocol letters that had stated that AAM had always planned to travel to the United Kingdom to claim
asylum, or to his claim that he felt unsafe in Italy and France. The Home Secretary made a certificate
under paragraph 17 of Schedule 3 to the 2004 Act.

272. On 6 June 2022, AAM was also served with directions for his removal to Rwanda on 14 June 2022.
Those directions were cancelled on 10 June 2022.

(v)          The claim for judicial review

273. On 9 June 2022, AAM was added as a claimant in case CO/2032/2022. He challenged the 6 June
2022 inadmissibility decision. Subsequently AAM was granted permission to add a challenge to decisions
taken on 5 July 2022 (a) that his asylum claim was inadmissible; (b) that removal from the United Kingdom
would not be a breach of his Convention rights; and (c) to certify his human rights claim. Those decisions
are described below.

(vi) Further representations and evidence

274. On 9 June 2022, AAM made a witness statement. AAM said that he travelled by boat to Italy with
about 420 other men; that he arrived at an island where Italian border guards helped him out of the boat
and took his fingerprints, but that this was not part of an asylum application; he stayed in Italy for ten days,
five days in quarantine and five days sleeping on the street. He said, “I did not claim asylum in Italy
_because I did not have any family or friends there and I had always intended to go to the UK to claim_
_asylum there”. He also said, “I did not want to be alone in a place where I did not speak the language or_
_have any community to join”. AAM said that he travelled to France and spent time in a migrant camp in_
Calais, and that the camp was attacked by gangs. He said, “I did not claim asylum in France due to my
_experiences in the migrant camp, because I knew that France was discriminatory to Muslims, and I am a_
_Muslim, and because I had always intended to claim asylum in the UK. I also did not have any friends or_
_family in France”. He said he has several cousins in the United Kingdom._

275. On 1 July 2022, Duncan Lewis made further written representations on behalf of AAM. They referred
to the racism, gang violence, and street homelessness which he experienced in France or Italy as
amounting to exceptional circumstances that prevented him from claiming asylum in either country. Further
representations were made in relation to the human rights claim.

276. Further, on 11 June 2022 a doctor prepared a report under rule 35 of the Detention Centre Rules.
That records AAM's account of going to Libya in 2021, being detained by the militia and being tortured by
being beaten on his feet with a stick. The report recorded that there were no scars on AAM's feet or body.
The report stated that AAM's claim of imprisonment and beating in Libya is consistent with torture and
would need to be looked into further For sake of completeness we note that on 7 July 2022 (after the


-----

Commissioner for Refugees intervening) and other case....

Home Secretary's decisions on 5 July 2022) AAM's solicitors sent the Home Secretary a copy of a report
(dated 6 July 2022) from Dr Galappathie.

(vi) The inadmissibility decision of 5 July 2022

277. Like the letters described in the other claims, the inadmissibility decision of 5 July 2022 sent to AAM
stated that it was to be read in conjunction with the earlier inadmissibility decision (which in his case had
been dated 6 June 2022). The letter stated that the material provided by the UNHCR in the judicial review
proceedings, AAM's witness statement, the representations dated 26 May 2022 and certain paragraphs of
the judicial review claim form had all been considered. The decision did not refer to the representations of
1 July 2022.

278. The decision letter does not deal at all with the application to AAM of paragraph 345A(iii)(b) of the
Immigration Rules. The letter only deals with the decision under paragraph 345C of the Immigration Rules.
In these proceedings, the Home Secretary has provided no witness statement to explain why the decision
letter did not address whether AAM's claim was inadmissible.

(vii) The human rights decision of 5 July 2022

279. The decision on the human rights claim was set out in a different letter, also dated 5 July 2022. As in
the other cases referred to above, the human rights and inadmissibility decisions were taken by different
persons working in different units in the Home Office. The human rights decision does not mention the
material filed by the UNHCR in the judicial review claims. Rather, the decision letter considered the other
evidence available, concluding that there was no risk that if in Rwanda, AAM would be treated otherwise
than in accordance with the MOU and the Refugee Convention, and that AAM would be safe and would be
able to pursue his asylum application and access adequate support in Rwanda. The decision considered
AAM's personal circumstances and concluded that there would be no risk to his health given the terms of
the MOU and the Home Secretary's assessment in May 2022 of the healthcare available in Rwanda. The
letter further concluded that there was adequate medical treatment in Rwanda to address his care and
treatment on arrival. The decision also contained the conclusion that removal to Rwanda would not entail
unjustified interference with AAM's right to respect for family and private life as guaranteed by Article 8 of
the Convention. The human rights claim was certified as clearly unfounded.

(viii) The challenges raised by AAM specific to his own circumstances

280. AAM makes the following specific challenges to the inadmissibility decisions of 6 June 2022 and 5
July 2022:

(1) the 5 July 2022 decision failed to have regard to the representations made on 1 July 2022;

(2) the 6 June 2022 decision was irrational or failed to consider relevant evidence as it did not deal with his
specific reasons for not claiming asylum in Italy or France; and

(3) it was irrational for the Home Secretary to maintain reliance on her previous conclusions set out in the
6 June 2022 letter.

281. AAM challenged the human rights decision on the grounds that the Home Secretary did not have
regard to the material filed in the judicial review proceedings by the UNHCR. He further submitted that the
Home Secretary had applied the wrong test in terms of assessing the risk that he would commit suicide if
removed to Rwanda; had given little or no weight to the rule 35 report and the evidence of Dr Galappathie;
and had relied on the MOU and the availability of health care treatment in Rwanda when only limited
weight ought to have been given to those assurances. In those circumstances, he submitted that removal
would be a breach of Articles 3 and 8 of the Convention.

282. Mr Dunlop accepts that the 5 July 2022 inadmissibility decision does not address the application of
paragraph 345A(iii)(b) of the Immigration Rules, and was taken without regard to the written
representations dated 1 July 2022. His submission was that there was no need for the court to intervene
because the Home Secretary proposes to take a fresh decision on inadmissibility. So far as concerns the


-----

Commissioner for Refugees intervening) and other case....

human rights decision, his submission was that the Home Secretary had properly assessed the suicide risk
and the position of AAM in relation to Article 8 of the Convention.

(viii) Conclusions

283. The 5 July 2022 inadmissibility decision is flawed and must be quashed. _First, the representations_
made on 1 July 2022 were not considered. Secondly, the decision does

not in fact contain any assessment of whether the requirements of paragraph 345(iii)(b) are met. There is
no assessment of whether AAM could have claimed asylum in Italy or France and why it is considered that
there were no exceptional circumstances preventing AAM making a claim.

284. For completeness, the decision of 5 June 2022 should also be quashed. Had that letter stood alone,
it would just have been sufficient to demonstrate why the Home Secretary considered that the
requirements of paragraph 345A(iii)(b) were met. AAM had spent 10 days in France and then 10 days in
Italy and there were no exceptional circumstances preventing him from claiming for asylum. It might have
been better had that letter included a slightly fuller explanation. But that is as may be. However, after that
letter, the Home Secretary purported to reconsider the application of paragraph 345A(iii)(b) following
further representations and AAM's witness statement. As we have explained, that reconsideration was
entirely ineffective; the 5 July 2022 letter contains no reasons to explain why the 6 June 2022 decision on
paragraph 345A(iii)(b) was maintained. In the premises, the preferable course of action is to quash the
decisions of 6 June 2022 and 5 July 2022. This will permit the Home Secretary to reconsider the matter
afresh in the light of all the representations and evidence. The Home Secretary accepts that she is
proposing to take this course, but that is no reason, in this case, to refuse to grant relief. Neither the June
nor the July decision has been withdrawn.

285. The decisions on the human rights claim and to certify it as clearly unfounded must be quashed
because relevant evidence was not considered – i.e. the material filed by the UNHCR in the judicial review
proceedings. That was available to the Home Secretary before she took the 5 July 2022 human rights
decision. In large part, the conclusions on the human rights claim rests on the premise that Rwanda will
meet the obligations under the MOU, and generally on an assessment of the position in Rwanda. Those
matters were addressed in the UNHCR evidence and the Home Secretary should have considered that
material. The decision will be quashed and the defendant will have to consider the human rights claim, and
the question of certification, in the light of all the relevant material including, if considered appropriate, the
court's conclusions on the UNHCR evidence.

(7)  NSK (Iraq) (Claimant 10, CO/2032/2022)

286. NSK was born in 1986 in Iraq. He is Kurdish and speaks Kurdish Sorani. He says that he worked as
a security guard in a prison in Tikrit in 2004, alongside British and American military forces. Since then he
says that he worked as a security guard working for the government of Iraq and the Kurdish regional
government. He says that he lived with his wife and children. One day, he found his wife in bed with
another man who then chased him and shot at him. He says that man was the body guard for his
brotherin-law who is the head of intelligence for a Kurdish political party. He says that when he reported the
incident to the police, his brother-in-law arranged for him to be kidnapped and he was attacked with a knife
and sustained knife wounds to his hands. He says his brother-in-law arranged on a second occasion to
kidnap him. He says that he fled Iraq. His senior officer gave him $3,000 and lent him a further $9,000. He
used this money to pay an agent to enable him to leave Iraq. NSK says that he cannot read or write.

(i)          Arrival and detention in the United Kingdom

287. NSK arrived by small boat from France on 17 May 2022. He was detained, initially at IRC Yarl's
Wood and then at IRC Brook House from about 22 May 2022. He claimed asylum. He attended a
screening interview on 18 May 2022, and was assisted by a Kurdish Sorani-speaking interpreter. The
information provided by NSK to the court includes part of the record of the screening interview but not the
whole of it. The sections dealing with his journey, and the reasons why he did not claim in another country,


-----

Commissioner for Refugees intervening) and other case....

were not included. However, it is possible to work out what it was likely that NSK said from other
documentation.

288. The detention records show that at Brook House NSK was told about the duty solicitor scheme as
part of his induction on about 23 May 2022 (an interpreter was present on that occasion). In a witness
statement made about 9 June 2022, NSK confirms that about two weeks earlier, he was given a card by
staff at Brook House and told that a lawyer would contact him. He did not in fact speak to his solicitors,
Duncan Lewis, until 8 June 2022.

(ii)          The notice of intent

289. On 24 May 2022, NSK was provided with a document headed “Notice of intent – this is not a decision
_letter”. That letter noted that before NSK claimed asylum in the United Kingdom he had been present in, or_
had a connection with, France. It said that may have consequences as to whether his asylum claim would
be admitted to the UK asylum system, and stated that he could be removed to France, or the United
Kingdom might ask Rwanda if it was prepared in principle to admit him. The letter invited NSK, within
seven days of the date of the letter, to submit written representations on why his asylum claim should not
be treated as inadmissible, and why he should not be removed from the UK to France, or to Rwanda. The
notice said that, after that period, the Home Office could make an inadmissibility decision based on the
evidence available to it.

(iii) Further material

290. On 27 May 2022, an “Immigration Request Form” was completed on NSK's behalf. The form stated
that NSK wanted to claim asylum because he was a victim of torture. It said that he was trafficked through
Turkey to Dunkirk. It says that six months previously NSK had been tortured by a person “… who is now a
_British Citizen” and that he wanted “legal justice”. It referred to NSK's torture scars._

291. A rule 35 report dated 27 May 2022 was prepared by a doctor at the immigration detention centre
where NSK was being detained. The report noted NSK's account that he had been tortured in his house;
that a knife was used to his right eye; and that he had defended himself with his right hand. The report
noted that there was a scar under NSK's right eye and on the fingers and wrist of his right hand. The report
stated that the account may be consistent with torture; that NSK appeared to have been attacked without
means of escape; and that NSK reported been psychologically affected by his attack and feared for his life
if returned to Iraq. The report noted that NSK was currently stable in detention.

(iv) The inadmissibility decision of 6 June 2022 and the letter of 13 June 2022

292. The decision on whether NSK's asylum claim was admissible is in a letter dated 6 June 2022. The
letter concluded that the claim was inadmissible because NSK could enjoy protection in a safe third country
and there had been no exceptional circumstances that prevented him from making an asylum claim before
arriving in the United Kingdom.

293. The letter recorded that that conclusion was supported by the following evidence:

“On 18 May 2022, Home Office Officials observed when undertaking your initial contact and asylum
registration questionnaire you stated that you left Iraq 1 month prior to encounter in the UK, using your
official passport and travelled to Turkey, staying for approximately 5 days. You then stated that you
travelled through unknown counties [sic] by car and foot before you ended up in Dunkirk, France You
arrived in the UK by boat.”

294. The form of the decision letter (a form seen in other cases too), is not helpful. It simply states the
conclusion and then recites what was said at the screening interview. It does not relate the information
received to the decision taken. Nevertheless, the implication is that the decision-maker considered that
NSK had had sufficient time in a safe third country to make an asylum claim, and that there was nothing to
indicate that there had been exceptional circumstances that prevented NSK from claiming asylum during
the course of his journey to the United Kingdom. The letter stated that it had been decided to remove NSK
to Rwanda which was a safe third country for him. The decision was certified under paragraph 17 of


-----

Commissioner for Refugees intervening) and other case....

Schedule 3 to the 2004 Act. Removal directions were issued for the removal of NSK to Rwanda on 14 June
2022. Those directions were ultimately cancelled following a decision by the European Court of Human
Rights granting an interim measure under rule 39 of its Rules that he should not be removed to Rwanda.

295. On 8 June 2022, NSK instructed solicitors to act for him. They wrote to the Home Secretary on that
date. A first witness statement was made by NSK on about 9 June 2022. By letter dated 11 June 2022, the
solicitors provided a copy of the statement to the Home Secretary, stating that the witness statement
demonstrated that NSK's asylum claim was not inadmissible as there were exceptional circumstances that
had prevented him from claiming asylum in a safe third country. In the witness statement NSK stated that
he left Iraq on about 17 April 2022, and travelled to Turkey where stayed for approximately 10 to 15 days.
He says he left Turkey in the back of a lorry. He says that throughout the journey he was under the control
of the agent to whom he had paid $12,000. In paragraph 11 of his statement, he said that he was unable to
ask questions or discuss the journey and “I decided that I would keep my head down and do what I was
_told to do”. In paragraph 12, he said that between Turkey and Dunkirk, they stopped at one place for_
approximately seven days and he and the others were provided with food, drink and accommodation by a
charity. He said he did not know where that was (although in a later statement he said he suspected, but
was not sure, it was in Italy). He said that, ultimately, he was taken by train and a van to Dunkirk, where he
stayed for one day at a camp he called the jungle. He said he walked for 12 hours to the beach and
boarded a boat, sailed for 2½ hours until someone on the boat contacted the coastguard who rescued
them. He said that throughout the journey, he was under the control and

acting on the instructions of the agent, and that he had no idea where he was most of the time “other than
_the fact that I wanted to get to the UK to claim asylum and protection”._

296. On 13 June 2022, the Home Secretary provided a further letter responding to NSK's witness
statement, and to a rule 35 report. This was, in substance, a further decision on whether NSK's asylum
claim was inadmissible. The letter noted that NSK had said that he stopped in a place for seven days
where he was provided with food, drink and accommodation by a charity. The letter concluded that NSK
was not under the control of the agent for the entire journey. It noted that NSK had failed to give any
reasonable explanation as to why he could not approach the charity for assistance in making an asylum
application. The decision that the asylum claim was inadmissible was maintained.

(v)          The claim for judicial review

297. On 10 June 2022, NSK was added as a claimant to claim CO/2032/2022. He challenged the Home
Secretary's decisions that his asylum claim was inadmissible and that he should be removed to Rwanda.

(vi) Further representations

298. On 13 June 2022, solicitors for NSK sent a letter before action. A second witness statement was
made by NSK on about 14 June 2022. In that, NSK asserted that it was incorrect to say that because he
received charity support, he was not under the control of the agent for the entire journey. He stated that the
agents were present the whole time when he was with the charity, and said “essentially we received the
_support through the agents”. He said that he was unable to talk to anyone, and that he was threatened by_
an agent and told that if he spoke to anyone he would be killed, and he was told that he would be stabbed.

299. The Home Secretary was provided with two further documents. One was a four-page document
dated 14 June 2022 provided by Steven Harvey, a former police officer of many years-experience who
describes himself as an expert in international human trafficking and people smuggling. He commented,
based on the account given by NSK in his first statement, on whether NSK's reliance on charity support for
a seven-day period amounted to a break in control by the agent. In particular, he commented on
paragraph 12 of that statement. Mr. Harvey stated that the account was consistent with what he described
as the “general people smuggling narrative”. He said it was his experience that migrants had no say in the
process from the point that the fee was agreed to the point of arrival at their end destination. He further
expressed the view that smugglers make use of legitimate services (such as the charity which provided


-----

Commissioner for Refugees intervening) and other case....

food and accommodation). He said it was highly likely that what NSK described had been an example of
this.

300. The second document, dated 14 June 2022, was prepared by Dr Aidan McQuade, the director of an
organisation called Anti-Slavery International. He had been asked to comment on whether NSK's ability to
access charity demonstrated that he was not under the control of an agent. Dr McQuade based his view on
correspondence between NSK's lawyers and the Home Secretary, NSK's first witness statement, and a
bundle of papers the contents of which are not identified. It does not appear that he met or

spoke to NSK. The bulk of the report is, essentially, Dr McQuade's comments or assessment of what NSK
said in his statement, measured against a book written by Dr McQuade and a United Nations guidance
note. Dr McQuade expressed the view that social pressures from peers or from perceived authority figures,
and also being in unfamiliar settings, can influence individuals and constrain how they act. He concluded
that NSK's account described an example of what he called “constrained agency”. Dr McQuade also
commented on what he assessed to be vulnerability on the part of NSK because of what he calls his
“situational vulnerability” (NSK being in fear of his life from his brother-in-law's henchmen), and
“circumstantial vulnerability” because he had paid $12,000 to the agent to get him to the United Kingdom.
He concluded that the circumstances would have led NSK to have a psychological dependency on the
agent. He concluded that NSK described a set of circumstances which, in **_modern slavery guidelines,_**
were reasons for assuming that a person remains under the control of an agent even when they apparently
have an opportunity to escape. He concluded that the fact that NSK had access to a charity for a period at
some point along his journey did not mean that, at the same time, he remained under the control of the
agent.

301. On 1 July 2022, NSK's solicitors made further representations. These invited the Home Secretary to
consider a range of documents including: the request of 27 May 2022; the rule 35 report; the reports of Mr
Harvey and Dr McQuade; the submissions made by NSK on 11 June and 14 June 2022; and the
arguments advanced in the judicial review proceedings. Read carefully and as a whole, the 1 July 2022
representations repeated the essence what had been said in NSK's first and second witness statement, in
the opinions of Mr Harvey and Dr McQuade and in the earlier written representations. The representations
contended that NSK displayed signs of undiagnosed anxiety and depression, and that the rule 35 report
had stated that his account was consistent with him having been tortured. The representations said that
these vulnerabilities put him at risk of harm if he were to be removed from the UK. The representations
contended that the inadmissibility decision was unlawful.

(vii) The inadmissibility decision of 5 July 2022

302. The Home Secretary's further inadmissibility decision is dated 5 July 2022. Like the other decision
letters of that date, this one said that it should be read in conjunction with the Home Secretary's first
decision letter (dated 6 June 2022). The letter records that regard had been had of the material filed by the
UNHCR in the judicial review proceedings, the rule 35 report, NSK's witness statement of 14 June 2022,
the request of 27 May 2022 and the submissions of 11 and 14 June 2002, and arguments in the judicial
review proceedings. The letter did not refer to the 1 July 2022 representations.

303. In relation to paragraph 345A of the Immigration Rules, the letter said this:

“Your witness statement states that you travelled from Turkey to France in the back of 3 or 4 lorries, on foot
and in a cargo train and in a van. It says that you stopped in an unidentified country for approximately 7
days where you were provided with food drink, and accommodation by a charity organisation, and stayed
in the “Jungle” in Dunkirk for approximately 1 day. You have claimed that paragraph 345A(iii)(b) is not
applicable in your case because were not able to claim in asylum in France as you were under the control
of an agent. You have provided two reports from Dr Aidan McQuade and Steve Harvey challenging the
assertions in our letter dated 13 June 2022 wherein it was deemed that there were no exceptional
circumstances preventing you from claiming asylum prior to coming to the UK.


-----

Commissioner for Refugees intervening) and other case....

Your evidence now asserts that you were in a situation of “constrained agency” and had developed a
dependency on your smugglers. You assert that your lack of knowledge of your environment and your
rights subsequently prevented you from claiming asylum prior to arriving in the UK. It is noted that the
reports of Dr Aidan McQuade and Steve Harvey were concluded on written evidence of your account only.
While this new evidence is noted it is considered that for the reasons given in the letter of 13 June 2022,
there were no exceptional circumstances preventing you from claiming asylum on route to the UK.

Therefore, the previous conclusions drawn relating to paragraph 345A of the immigration rules are
maintained.”

304. The letter dealt with other matters, including the state of NSK's mental health, which had been said to
be associated with his experience of torture, and concluded that there would be suitable health care and
support available in Rwanda. The inadmissibility decision was maintained as was the decision to remove
NSK to Rwanda. The certification of the decision was also maintained.

(viii) The human rights decision of 5 July 2022

305. On 5 July 2022, the Home Secretary provided a separate decision on NSK's contention that removal
from the United Kingdom would be in breach of his Convention rights. As in the other cases, the human
rights and inadmissibility decisions were taken by different officials in different Home Office units. The
human rights decision in this case referred to the letter of 11 June 2022, and to NSK's first witness
statement. The decision did not refer to the material filed by the UNHCR in the judicial review proceedings;
we were told that the official who took the decision had not seen that material. The conclusion in the 5 July
2022 letter was that the removal of NSK to Rwanda would not be incompatible with his Convention rights.
The human rights claim was certified as clearly unfounded.

(ix) The challenges raised by NSK specific to his own circumstances

306. NSK makes the following specific challenges to the decision that he was not prevented by
exceptional circumstances from claiming asylum in a safe third country:

(1) the Home Secretary only had regard to his objective circumstances and did not consider his subjective
state of mind;

(2) the Home Secretary dismissed the reports from Mr Harvey and Dr McQuade on the basis that their
conclusions were reached on the basis of written evidence only, and did not address the substance of the
reports;

(3) the Home Secretary failed to give adequate reasons for her conclusion; and

(4) if NSK's evidence that he was under the control of an agent throughout his entire journey is credible,
then the Home Secretary could not rationally conclude that the asylum claim was inadmissible as there
would exceptional circumstances preventing him from claiming asylum;

NSK challenged the human rights decision on the basis that the evidence filed by the UNHCR in the
judicial review proceedings, which was provided after the initial 6 June 2022 decision, had not been
considered.

(x)          Conclusions

307. The Home Secretary did not provide adequate reasons for her conclusion that NSK's asylum was
inadmissible. As we have already observed, reasons need not be elaborate, they can be briefly stated, and
in all cases, it will be open to the Home Secretary to draw inferences from such primary circumstances as
she accepts have prevailed.

308. In the present case, the key issue was the claim by NSK that he was in the control of the agents
throughout his journey to the United Kingdom and whether that amounted to exceptional circumstances
that prevented him from claiming asylum. One aspect of that is the significance to be attached to the seven
days when NSK and the others with him were provided with accommodation and food and drink by a
charit We ha e referred abo e to NSK's e idence on this point


-----

Commissioner for Refugees intervening) and other case....

309. Overall, the Home Secretary needed to explain why she concluded that the conditions in paragraph
345A(iii)(b) were met. It is unclear whether the Home Secretary decided not to believe NSK's account. It
may be that having considered his evidence as a whole, she did not believe that he was unable to ask the
charity for help in claiming asylum if he had wanted to, or unable to board the boat in Dunkirk. She may
have concluded that NSK did not claim asylum before reaching the United Kingdom simply because he
wanted to come here to claim asylum. Or the Home Secretary may not have believed NSK. Or she may
have concluded that the circumstances he described were not exceptional circumstances in the context in
which those words are used in paragraph 345A: see the point we have made above at paragraph 262. Or
there may be some other reason. On balance, we are satisfied that the 5 July 2022 decision letter does not
adequately explain the reasons why, on the particular facts of this case, the Home Secretary concluded
that the requirements of paragraph 345A(iii)(b) were met and the asylum claim was inadmissible.

310. We are unpersuaded that the Home Secretary acted irrationally in not accepting the conclusions
stated by Mr Harvey and Dr McQuade. Each was asked to comment on a particular question: did he
consider that the time spent with the charity meant that NSK was not under the control of the agent? That
was an aspect of the question which, ultimately, the Home Secretary had to decide. The responsibility for
that decision could not be usurped. The Home Secretary had to reach a conclusion on what had happened
(both Mr Harvey and Dr McQuade based their views on the assumption that NSK's account was correct,
albeit that they assessed it by what they say is their experience in matters of trafficking, smuggling and
**_modern slavery); she was also entitled to form her own opinion on the significance (for the purposes of_**
the application of paragraph 345A of the Immigration Rules) of what had happened (the question she had
to address – were there exceptional circumstances which prevented NSK from making a claim for

asylum before coming to the United Kingdom – is a different and broader question from that addressed by
either Mr Harvey or Dr McQuade).

311. We do not consider that the Home Secretary failed to consider questions of subjective intent. Nor, on
the particular circumstances of this case, would we have regarded the failure to have regard to the 1 July
2022 representations as a factor which would invalidate the inadmissibility decision of 5 July 2022. On a
fair reading of those representations, they only made points that were already set out in the other material
provided to the Home Secretary which she did consider. In the present case, we quash the inadmissibility
decision of 5 July 2022 because we are satisfied that the reasons given are not adequate. As the 5 July
2022 decision was essentially the reasons for maintaining the earlier 6 June 2022 decision, and as the
reasoning is not adequate, it is sensible also to quash the earlier 6 June decision (for the same reasons as
those given in relation to AAA, AHA and AT). We do not consider that the 13 June 2022 letter contains a
free-standing decision. Rather it contains supplemental reasons dealing with the representations made on
11 June 2022 and the Rule 35 report.

312. The 5 July 2022 decision refusing the human rights claim and certifying the claim as unfounded
should also be quashed. The decision simply did not consider the evidence put forward. As we have said
above, it is no answer to say that the inadmissibility decision and the human rights decision should be read
together. They were taken by different individuals in different teams. There is no indication in the human
rights decision letter, and no evidence before this court, that the decision-maker read the inadmissibility
decision before taking the human rights decision. In any event, whether the human rights claim should be
certified as clearly unfounded is a different issue. It would not have been considered by the official taking
the inadmissibility decision. The official who took the human rights decision would have to consider the
evidence (or an adequate summary of it) to determine whether the evidence was such that no tribunal
properly directing itself could allow an appeal. That has not happened in this case.

(8)  HTN (Vietnam) (CO/2104/2022)

313. HTN is a Vietnamese national born in January 1986. He says that he borrowed money to buy land in
Vietnam. He says that, when he tried to sell the land, he discovered that he had been deceived and he did
not in fact own the land. He says the people he had borrowed from asked for the money plus interest and


-----

Commissioner for Refugees intervening) and other case....

threatened to kill him when he said he could not pay. He said he left Vietnam and took a fishing boat and
ended up in Ukraine shortly before the war there began.

(i)          Arrival in the United Kingdom, and detention

314. On 9 May 2022, HTN travelled by small boat from France to England. He was detained at IRC Yarl's
Wood and then IRC Colnbrook. He claimed asylum. He had a screening interview on 11 May 2022. An
interpreter was used by telephone but HTN says that the interpreter spoke a different way from the way he
was used to, and his accent and the words he used were different and HTN found him hard to understand.
In the record of his interview, HTN is recorded as saying he had no medical issues; that he left Vietnam
three and a half months earlier and travelled to Ukraine and stayed there for 3 months; that he then
travelled through unknown countries by train, car and foot but did not recognise where he was until he got
to France; and that he then travelled to the United Kingdom on 9 May 2022. Asked why he did not claim
asylum on his way to the United

Kingdom he is recorded as saying “I don't know anything; I was just following people”.

(ii)          The notice of intent

315. On 12 May 2022, HTN was provided with a document headed “Notice of intent – this is not a decision
_letter”. That letter noted that before NSK claimed asylum in the United Kingdom he had been present in, or_
had a connection with, France, and stated that could have consequences as to whether his asylum claim
would be admitted to the UK asylum system. The notice continued that if the claim was held to be
inadmissible he could be removed to France, or the United Kingdom may ask Rwanda if it was prepared in
principle to admit him. The letter invited HTN, within seven days, to submit written reasons why his asylum
claim should not be treated as inadmissible or why he should not be removed either to France or to
Rwanda. The notice said that, after that period, the Home Office could make an inadmissibility decision
based on the evidence then available.

316. Evidence from two Home Office officials confirms that when the notice was served on HTN, he had
assistance from an interpreter who spoke Vietnamese. An officer was asked to assist HTN to arrange an
appointment with the welfare officer. HTN requested a solicitor and interpreter. In a witness statement
dated 10 June 2022, HTN said that no interpreter was present when he was given the notice of intent and
said the contents of the letter was not explained to him. In a later witness statement, he confirmed that he
meant that an interpreter was not present in the room but was available on the telephone, but HTN then
said that he could not understand the interpreter enough to understand what he was told as the interpreter
was speaking in a different accent or dialect from his and the interpreter used words he did not know. HTN
said that he had been told he could get help to find a solicitor at the welfare office. He went there and
asked for a solicitor and his details were given to a solicitor. The solicitor called twice, once to sign a
consent form and once to take a statement. The first call lasted 20-30 minutes, the second about an hour
and a half. After the second call, the solicitors did not contact him again. He spoke to the welfare office and
said he needed a new solicitor.

(iii) The inadmissibility decision of 1 June 2022

317. The first inadmissibility decision was dated 1 June 2022. The evidence from the two Home Office
officials is that when the letter and other documents were given to HTN, an interpreter explained what they
were. The records indicate that HTN said that he had legal representation and was in contact with his
lawyers.

318. The decision letter was in similar form to the letters in the other cases described above. So far as
concerns the application of paragraph 345A of the Immigration Rules, the letter stated that HTN could
enjoy protection in a safe third country and that no exceptional circumstances had prevented an asylum
claim being made before HTN arrived in the United Kingdom. The letter continued as follows:

“On 11/05/2022, Home Office Officials observed when undertaking your initial contact and asylum
registration questionnaire you stated that you left Vietnam three and a half months prior to being


-----

Commissioner for Refugees intervening) and other case....

encountered in the UK and travelled to Ukraine by car, train and walking, where you stayed for 3 months.
You then stated you travelled through unknown countries by train, car and foot but couldn't recognise
where you were until you arrived in France. You then stated you arrived in the UK on 09/05/2022 by boat.”

The letter explained why removal to Rwanda was safe for HTN. It certified the decision under paragraph
17of Schedule 3 to the 2004 Act. Directions were fixed for the removal of HTN to Rwanda on 14 June
2022, directions subsequently cancelled on 14 June 2022.

(iv) Further representations

319. HTN was put in touch with new solicitors (Duncan Lewis) by a charity and he instructed them on 9
June 2022. They wrote to the Home Secretary on 9 June 2022 seeking cancellation of the removal
directions. On 10 June 2022, HTN made his first witness statement. In that he said the witness statement
was prepared with his lawyer who took instructions over a number of lengthy phone calls, using a
Vietnamese-speaking interpreter. HTN set out his account of why he left Vietnam. He said when he arrived
in Ukraine he decided to get a job there. He worked for about a week and then war broke out. He said that
he followed Ukrainians who were leaving the country. He said he followed them for about a week and then
got on a train and then a bus. He says that he was tired and slept for most of the bus journey. He got off
the bus in France and walked through some forest and stayed in France for about a day. He then got on
the boat.

320. On 27 June 2022, Dr Galappathie, a consultant forensic psychiatrist, prepared a report on HTN. He
expressed the view that HTN was suffering from a severe episode of depression, generalised anxiety
disorder, and post-traumatic stress disorder. He expressed the view that those conditions affect decisionmaking; that HTN did not present clinically as having a learning difficulty but he appeared to have difficulty
understanding concepts such as asylum and removal and would need a lot of help in litigation.

321. Representations were made on 27 June 2022. They contended (at paragraph 18) that there were
exceptional circumstances which prevented HTN claiming asylum in France: (a) the mental health
conditions diagnosed by Dr Galappathie had a direct bearing at the time of HTN's journey through France
such that he would have been less likely to seek out information and would make use of fewer resources
and would be more risk-adverse; and (b) the circumstances of HTN's journey, fleeing the outbreak of war in
Ukraine, without any knowledge of where he was going and unable to speak the language, meant he would
not have been able to seek out the French authorities, present himself and claim asylum. The
representations also attached a report from a Vietnamese linguistic expert.

322. On 1 July 2022, HTN's solicitors wrote again in connection with an application for bail. Attached to
this letter were Dr Galappathie's report of 27 June 2022, the report from a Vietnamese linguistic expert, a
witness statement provided by a case worker at Duncan Lewis and further material. In the written
representations, the solicitors referred to paragraphs 8 to 18 of the earlier written representations which
had set out the basis on

which it was contended that there had been exceptional circumstances that had prevented HTN claiming
asylum before his arrival in the United Kingdom.

(v)          The inadmissibility decision of 5 July 2022

323. In this case too, the Home Secretary made further inadmissibility decision on 5 July 2022. The
decision letter contained reference to the evidence filed by the UNHCR in the judicial review proceedings.
It did not refer to the letter of 1 July 2022, or the attached documents, which had included Dr Galappathie's
report, the report of the Vietnamese linguistic expert, and the statement from the caseworker at Duncan
Lewis. The letter stated it was to be read in conjunction with the letter of 1 June 2022. The letter
maintained the decision that the asylum claim was inadmissible. The letter stated that HTN had said in his
witness statement that he was in France for one day and one night and, while he claimed that he could not
have claimed asylum as he was just following people, that did not amount to exceptional circumstances
preventing him from claiming asylum. The certification decision of 1 June 2022 was also maintained.


-----

Commissioner for Refugees intervening) and other case....

(vi) The human rights decision letter of 5 July 2022

324. The Home Secretary treated HTN's representations as raising a human rights claim. By letter dated 5
July 2022, she refused that claim and certified it as clearly unfounded. The decision included consideration
of Dr Galappathie's report but did not consider the UNHCR material filed in the judicial review claim. As in
the other cases, these human rights and inadmissibility decisions were taken by different officials in
different Home Office units.

(vii) The challenges raised by HTN specific to his own circumstances

325. HTN's application for judicial review was filed on 13 June 2022 (CO/2104/2022). In that claim HTN
submits that the inadmissibility decision of 5 July 2022 was unlawful as the Home Secretary did not have
regard to the representations in the 1 July 2022 letter or Dr Galappathie's report of 27 June 2022. He
further submits that the refusal of the human rights claim, and certification of that claim as clearly
unfounded was unlawful because those decisions had not been reached on consideration of the evidence
filed by the UNHCR in the judicial review claim.

326. Mr Dunlop accepted that neither the representations of 1 July 2022 nor the medical report was
considered when the inadmissibility decision was made. He said that the Home Secretary intended to take
a fresh inadmissibility decision and a further decision on the human rights claim.

(viii) Conclusions

327. The inadmissibility decision dated 5 July 2022 is flawed and must be quashed. Representations were
made on behalf of HTN and a medical report produced which, it was said, explained what were the
exceptional circumstances that prevented HTN from claiming asylum in France. That material should (as
the Home Secretary accepts) have been considered (together with all other material relevant to determine
whether or not she accepts that that exceptional circumstance prevented HTN from claiming asylum). If the
inadmissibility decision of 1 June 2022 had stood alone, we would not have quashed it. However, it is clear
that the reasoning in the 5 July 2022 letter was intended

to replace the reasoning justifying the decision in the 1 June 2022 letter. As that reasoning is flawed, the
sensible course is to quash the 1 June 2022 inadmissibility decision as well.

328. The 5 July 2022 decision refusing the human rights claim and certifying that claim as clearly
unfounded must also be quashed. In this case, as in the cases above, information relevant to the decision
was not considered because, in error, it was thought relevant only to the inadmissibility decision. Since the
human rights and inadmissibility decisions were taken by different officials there is no scope for any
argument that what was known for the purpose of one decision must be taken to have been known for the
purposes of the other.

(9)  RM (Iran) (CO/2077/2022)

329. RM is a national of Iran born in 1996. He seeks to challenge three decisions: (1) inadmissibility
decisions to the effect that he could have claimed asylum in a safe third country and there were no
exceptional circumstances preventing him from doing so; (2) decisions refusing his human rights claim and
certifying it as clearly unfounded; and (3) a decision of 15 July 2022 deciding that there were no
reasonable grounds for concluding that RM was the victim of modern slavery.

(i)          Travel to the United Kingdom and detention

330. RM left Iran and travelled to France. He then travelled to the United Kingdom on 14 May 2022. He
was detained. He claimed asylum. On 15 May 2022, he attended a screening interview. In that interview he
was recorded as saying that he left Iran about 40 days before, and travelled by car, on foot, and by lorry.
He said that his uncle paid an agent. Having arrived in France he was put on a boat and travelled to the
United Kingdom. Asked why he had not claimed asylum on route, he said that he followed the agent.

(ii)          The notice of intent


-----

Commissioner for Refugees intervening) and other case....

331. On 16 May 2022, RM was provided with a document headed “Notice of intent – this is not a decision
_letter”. That letter noted that before RM claimed asylum in the United Kingdom he had been present in, or_
had a connection with, France, and stated that may have consequences as to whether his asylum claim
would be admitted to the UK asylum system. The letter stated that if the claim was inadmissible he could
be removed to France, or the United Kingdom might ask Rwanda if it was prepared in principle to admit
him. The letter invited RM to submit written reasons within seven days of the date of the letter on why his
claim should not be treated as inadmissible and why, if the claim was inadmissible, he should not be
removed from the UK to France or to Rwanda. The notice said that, after that period, the Home Office may
make an inadmissibility decision based on the evidence available to it.

332. By 23 May 2022, RM had instructed solicitors. On that day, they requested that the time for
responding to the Notice of Intent be extended to 8 June 2022. An extension of time was granted. The
solicitors were told this would be until 30 June 2022, but in an email

sent on 31 May 2022 that was corrected and RM's solicitors were told that the extension had been for 7
days and had expired on 30 May 2022.

333. On 31 May 2022, RM's solicitors provided an initial response to the Notice of Intent. They explained
that they had met their client on 24 May and 26 May 2022 with an interpreter. The letter set out further
details of RM's journey to the UK. It stated that RM thought he was in France for about four days, and that
RM had said that the agent used to say that all the people in his group had to help the agents or they
would be killed or hurt. The letter stated that RM said that he saw lots of agents and they were carrying
guns and a knife which they used to threaten the people in the group, and that in France, he had been told
to help carry the boat that he and others were to travel on, but did not actually help and only pretended to
help. The letter also made a claim that removal to Rwanda would breach RM's rights under Articles 3 and 8
of the Convention and also Article 4 as RM had been subject to exploitation and ill-treatment by smugglers.

334. On about 5 June 2022, a referral was made to the Home Secretary's Immigration and Enforcement
Competent Authority to consider whether RM was a victim of modern slavery.

(iii) The inadmissibility, human rights and trafficking decisions of 6 June 2022

335. The Home Secretary's first inadmissibility decision was taken on 6 June 2022. The letter summarised
the representations from the solicitors. It summarised the decision as one where RM's asylum claim was
inadmissible and, subject to resolution of any other claims, RM would be removed to Rwanda as it was a
safe third country for RM. The decision was certified under paragraph 17 of Schedule 3 to the 2004 Act. In
relation to paragraph 345A of the Immigration Rules, the letter concluded that RM could have claimed
asylum in a safe third country and there were no exceptional circumstances preventing him from doing so.
It said this:

“This decision is supported by the following evidence and reasoning.

On 9 May 2022 you were detected by the Home Office at the juxtaposed control zone in Coquelles,
France, while attempting to enter the UK clandestinely concealed in an HGV. You were detained and then
removed from the control zone into the care of the French authorities, when you had the opportunity to
seek protection.

On 15/5/2022, Home Office officials observed when undertaking your initial contact and asylum registration
questionnaire you stated that you left Iran about 40 days ago, by car and on foot. You then by 2-3 lorries
through unknown countries where you then travelled to the UK by boat on14/05/2022 from France”.

336. In a further letter dated 6 June 2022, the Home Secretary determined RM's claim that removal to
Rwanda would be a breach of RM's Convention rights. The claim was rejected and was certified as clearly
unfounded.

337. By a further letter dated 6 June 2022, the Home Secretary decided that there were currently no
grounds for concluding that RM was a victim of modern slavery. The Home Secretary accepted that RM
had been transported or transferred or harboured by


-----

Commissioner for Refugees intervening) and other case....

means of threat or the use of force or other coercion. RM had said that he was told by the smugglers that
the money paid for the journey did not include food, and if he carried boxes and did certain tasks, he would
be paid, but only money, not food, was given for this and he had been made to carry the boat that
transported him and others to the United Kingdom. RM had said that he was never told to commit any
crimes or forced into any form of sexual exploitation. In summary, the Home Secretary took the view that
RM undertook the tasks as a way of earning money from the smugglers and a matter of economic
necessity rather than because he was being subjected to forced labour or exploitation consistent with the
definition of **_modern slavery. RM had entered the situation voluntarily as a way to travel to the United_**
Kingdom and the situation was dissimilar to a situation of forced labour. In addition, the defendant noted
that RM had not actually participated in forced labour as he said that he did not carry the boat but only
pretended to.

338. Removal directions were issued for the removal of RM to Rwanda on 14 June 2022. These were
subsequently cancelled.

(iv) Further representations

339. On 11 June 2022, a report under rule 35 of the Detention Centre Rules was prepared by a doctor at
the immigration detention centre where RM was detained. It noted RM's claim that he had been in a fight
four years ago and sustained a cut to the top of the right eye and noted a scar was there. It also noted that
RM claimed he had been tortured by traffickers, verbally abused, beaten, slapped and kicked in the place
where he stayed in France (referred to as the Jungle). The doctor said that RM's injuries and narration of
events was consistent with torture and would need to be investigated. The report noted that RM claimed
that he had flashbacks and nightmares, and that the doctor had referred him to the mental health team for
assessment.

340. On 13 June 2022, RM's solicitors wrote indicating that a preliminary psychological report on RM
indicated he should not be removed to Rwanda. The report was prepared by Dr Curry who had carried out
a phone assessment for RM, but had not read his medical records, had not met him and had never been
involved in his clinical care. Dr Curry was not in a position to complete a full diagnostic assessment. Her
provisional opinion was that it was too early to determine if RM met the criteria for post-traumatic stress
disorder as a result of his treatment by smugglers. She said that RM was in a state which he considered
life-threatening.

341. The Home Secretary treated the material as amounting to fresh representations on RM's human
rights claim, and on 13 June 2022, gave further reasons for refusing the human rights claim which
addressed, in detail, the points made by Dr Curry. The conclusion was that removal of RM to Rwanda
would not amount to a breach of Article 3 of the Convention, and raised no further issue under Article 8 of
the Convention. The Home Secretary considered that the material did not amount to a fresh human rights
claim; she did not refer to the rule 35 report.

(v)          The inadmissibility and human rights decisions of 5 July 2022

342. By letter dated 5 July 2022 the Home Secretary maintained the earlier (6 June 2022) inadmissibility
decision. As in all other cases, the 5 July 2022 letter stated it was to be read in conjunction with the earlier
decision letter. The letter noted the Home Secretary

had considered the material filed by the UNHCR in the judicial review claim, the rule 35 report, and the
preliminary psychology report of Dr Curry of 13 June 2022.

343. Surprisingly, the 5 July 2022 letter does not deal with the application of paragraph 345A(iii)(b) of the
Immigration Rules, or why the Home Secretary concluded the exceptional circumstances proviso did not
apply. The letter did explain that the report of Dr Curry had been considered, and that the conclusion
reached was that appropriate medical care would be available for RM in Rwanda. The letter also dealt with
other matters.


-----

Commissioner for Refugees intervening) and other case....

344. In a further letter of the same date, a further decision was made on the human rights. In this case too,
the human rights claim and inadmissibility decisions were taken by different Home Office officials from
different units. This letter corrected one error in the 6 June 2022 letter (the erroneous implication that the
UNHCR was working in Rwanda with the Home Office). It did not consider the material the UNHCR had
filed in the judicial review proceedings. It did consider the evidence from Dr Curry. It stated that no
concerns had been identified by immigration staff at the immigration detention centre. The conclusion was
that the evidence did not demonstrate a real risk of a breach of a Convention right.

(vi) Further representations

345. On 9 July 2022, RM made a witness statement for the purposes of the judicial review claim that he
had issued on 10 June 2022 (CO/2077/2022). In that statement, RM said that when in France he was put
in a vehicle; and that the vehicle was stopped by police who passed him on to other police wearing
different uniforms. RM said that he realised they were police but did not know what government they were
representing. He said he was initially happy when he went with the second set of policemen as he thought
they would protect him. However, they took him and a friend in a car back to the “jungle” (the camp where
he had been staying). Later in the statement, he said he was asked why he had not claimed asylum in
France or elsewhere and said he did not know where he was, and that he was under the control of the
smugglers and was not allowed to do anything. He also said that he did not know what asylum was, or
what a refugee was, or how to claim. He said it was only when he was in the immigration detention centre
in the United Kingdom that he was given knowledge about the asylum process and how claiming asylum
status would lead to refugee status. On 10 July 2022, Dr Katy Robjant provided another medical report.

(vii) The trafficking decision of 15 July 2022

346. On 15 July 2022, a second letter was sent dealing with the trafficking claim which considered RM's
witness statement and the medical report. The conclusion was that RM had, in essence, been transported
by means of threat or force but had not been transported for the purpose of exploitation. The letter included
the following:

“The smugglers advised you that the money paid by your uncle was for the journey only and therefore you
owed them money for the food they were providing you with. You state within your account that you did not
experience any force or threat in relation to the work you completed or that you worked under any menace
of penalty. As you did not experience any force or threat when completing these tasks, it indicates that you
did not work under any menace of penalty and completed these jobs as a way to earn money to purchase
food from the smugglers. It is the view of the ICEA that you accepted this role due to pure economic
necessity and a requirement for survival. The situation you describe is dissimilar to forced labour or any
type of exploitation within the modern slavery definition.

You also stated within your NRM referral that you were forced to carry a dinghy; however, you go on to
confirm that you did not carry the dinghy, you only pretended to and attempted to sabotage the arranged
journey.

…

Your uncle paid the people smugglers as a way to get you to the UK for your own safety. The actions that
you state you were forced to do were part of the activities that were required as part of your journey to the
UK which had previously been agreed. As mentioned above the International Labour Organisation (ILO)
definition of forced work is 'All work or service which is enacted under the menace of any penalty and for
which the person has not offered himself voluntarily'. As you entered this situation voluntarily as a way to
travel to the UK this account is dissimilar”.

(viii) The challenges raised by RM specific to his own circumstances

347. RM challenges the inadmissibility decision, human rights decision, and trafficking decision. Put
broadly, he relies upon the generic challenges as to why Rwanda is not a safe country for him and that
relocation to Rwanda would breach his ECHR rights (Grounds 2 to 7 of the Re-amended Claim Form).


-----

Commissioner for Refugees intervening) and other case....

Those grounds are not established for the reasons given above. The inadmissibility decision is not
therefore flawed by reason of the matters referred to in those grounds. We deal below with procedural
unfairness (Ground 1 and part of Grounds 8 and 12), including specific points raised by individual
Claimants.

348. Mr Drabble KC made the following specific challenges. First, that the trafficking decision was unlawful
as it failed to take account of RM's account of events, misdirected itself when considering whether RM's
experiences involved forced labour and failed to have regard to policy. (This is Ground 9 of the claim.)
Further, in the skeleton argument, it was submitted that the Home Secretary had erred in considering that
RM had not been subject to forced labour because he had not actually carried the boat but only pretended
to do so.

349. Secondly, Mr Drabble submitted that in her further reasons for the human rights decision dated 13
June 2022 or otherwise, the Home Secretary had failed to consider RM's eligibility to be transferred to
Rwanda considering the medical evidence (Ground 11). That included the report of Dr Curry and the rule
35 report. Further, although the decision of 5 July 2022 said that there were no concerns identified by
immigration detention healthcare staff, this must have overlooked the rule 35 report.

350. In relation to the human rights decision, Mr Drabble submitted that the process was procedurally
unfair (see below), and that the Home Secretary could not rationally or lawfully consider that the asylum
process in Rwanda was effective, and that she failed properly to consider whether RM could access mental
health treatment in Rwanda (Ground 8).

351. In relation to both the inadmissibility decision and the human rights decision, he submitted that RM
could not lawfully be transferred to Rwanda because, on the medical evidence, the Home Secretary could
not reasonably consider that he was not vulnerable, or that she failed to take reasonable steps to
investigate or to allow RM to obtain definitive medical evidence (Ground 12).

352. Mr Dunlop submitted that the Home Secretary was entitled to conclude that what RM described did
not amount to transportation for the purposes of exploitation, and there was no proper basis for considering
that the trafficking decision was wrong. He submitted that proper consideration had been given to Dr
Curry's report, and that the rule 35 report did not add anything. He accepted that the Home Secretary had
not, when dealing with the human rights decision, considered the evidence filed by the UNHCR in the
judicial review proceedings but, he said, that information had been considered when the inadmissibility
decision was taken.

(ix) Conclusions

353. The trafficking decision did not fail to have regard either to RM's account of events or to any relevant
policy. Nor did it rest on any error of law. The Home Secretary was fully entitled to reach the conclusion
she did. The third element of the definition of modern slavery concerns whether the individual was being
transported for the purpose of exploitation. That looks to the purpose for which the individual is being
transported to the United Kingdom. It is primarily concerned with what will happen to the individual after he
arrives in the United Kingdom. The Home Secretary was entitled to conclude that there was nothing to
suggest that RM was transported in order to be exploited after he arrived in the United Kingdom. He was
transported here because his uncle had paid for him to be taken to the United Kingdom.

354. So far as events on the journey are concerned, the Home Secretary was fully entitled to conclude
that RM being told that he would be paid, or given food, if he completed certain tasks did not involve forced
labour. Similarly, she was entitled to conclude that when he was told to help carry the boat which was to
take him and others to the United Kingdom, that did not involve RM being transported for the purposes of
exploitation and did not involve forced labour. The reality is that this was part and parcel of the journey to
the United Kingdom that his uncle had paid the agents to arrange, not any form of exploitation of RM by the
agents. There is no flaw in the reasoning underlying the decision that there were no reasonable grounds
for concluding that RM was trafficked. The claim in relation to that decision (Ground 9 of the claim) is
refused.


-----

Commissioner for Refugees intervening) and other case....

355. The human rights decision of 5 July 2022 suffers from the same deficiency that arises in relation to
consideration of the evidence filed the UNHCR in the other cases and will be quashed for this reason. The
person who decided to maintain the refusal of the human rights claim and certify it as clearly unfounded did
not consider relevant material. The fact that a different decision maker, considering different issues, had
regard to the material does not avoid the fact that the decision maker dealing with the human rights claim
did not consider it. The human rights decision of 5 July 2022 will therefore be quashed. For sake of
completeness, we were satisfied that the Home Secretary had, in

her letter of 13 June 2022, adequately considered and addressed the matters arising out of Dr Curry's
report.

356. The earlier decisions on the human rights claim (and to certify that claim) should also be quashed.
The reasoning in the 5 July 2022 letter was intended to supersede the reasons in the 6 June 2022 letter
and the 13 June 2022 letter. It would make no sense for those decisions to stand when the 5 July 2022
decision has fallen. The Home Secretary should now reconsider the matter taking account of all relevant
available material then available including, for example, Dr Curry's report and the rule 35 report.

357. The inadmissibility decision was not unlawful. The position is as follows. Save for the procedural
fairness issue, the only specific ground of challenge was that the Home Secretary had failed to consider
the medical evidence and RM's vulnerability. We do not consider that the policy documents establish that a
person will not be relocated to Rwanda if he can establish that he is vulnerable. It will be a question for the
Home Secretary to consider, case by case. In this case the Home Secretary did consider the medical
evidence available at the time of the decision on 5 July 2022, including the rule 35 report and Dr Curry's
report. She did not act unreasonably in not making further inquiries. The grounds of claim in relation to the
5 July 2022 inadmissibility decision, therefore, fail.

358. We note that the 5 July 2022 inadmissibility decision did not specifically address paragraph
345A(iii)(b) of the Immigration Rules, i.e., whether RM could have claimed asylum in a safe country, and
whether there were exceptional circumstances preventing him from doing. However, there is no ground of
challenge to the decision on that ground (and RM was granted permission to amend the claim specifically
to raise any alleged illegality in relation to the 5 July 2022 decision). Further, the position was dealt with in
the decision of 6 June 2022. After that, no further substantive representations on that issue appear to have
been made before the 5 July 2022 decision. Thus, we do not regard the 5 July 2022 inadmissibility
decision flawed for this reason. It may be that the witness statement of 9 July 2022 raises new points (as
RM provides explanation of why he did not claim in France). If RM wishes to make further representations
on this matter, he will need to make them to the Home Secretary.

(11)  AS (Iran) (CO/2098/2022)

359. AS is a national of Iran who was born in July 1976. He has a son, and two daughters born in 2001.
AS says he converted to Christianity and he and his son left Iran. AS and his son went to Greece, where,
they say, they applied for and were granted asylum. They then went to Germany and claimed asylum
there, but left before decisions were made: AS's son went to the United Kingdom; and about a month later,
AS travelled to France.

(i)          Arrival in the United Kingdom, and detention

360. AS arrived by boat in the United Kingdom on 9 May 2022. He claimed asylum. He was detained at an
immigration centre. In his screening interview, he was asked if he had claimed asylum elsewhere. He said
he had claimed in Greece and Germany; that his claim had been accepted in Greece, and he had been
issued with a passport and ID card.

He is recorded as saying that he did not wait to be interviewed in Germany so he left. He said that he spent
about two years in Greece and about five or six months in Germany. He travelled by train to France and
spent seven days there. He said that he wanted to come to the United Kingdom because it was easier to
bring his family there.


-----

Commissioner for Refugees intervening) and other case....

(ii)          The notice of intent, and representations

361. On 13 May 2022, AS was provided with a document headed “Notice of intent – this is not a decision
_letter”. That letter noted that before he had claimed asylum in the United Kingdom AS had been present in,_
or had a connection with, all of Greece, Germany and France. The letter stated that that could have
consequences on whether his asylum claim would be admitted to the UK asylum system. The letter also
stated that AS could be removed to one of those countries, or the United Kingdom might ask Rwanda if it
was prepared in principle to admit him. The letter invited AS to submit written reasons within seven days of
the date of the letter on why the claim should not be treated as inadmissible and why he should not be
removed from the UK, either to any of Greece, Germany or France, or to Rwanda. The notice said that,
after that period, the Home Office may make an inadmissibility decision based on the evidence available to
it at that time.

362. On 17 May 2022 AS instructed solicitors. On 20 May 2022 they made written representations and
sent various documents including a witness statement from AS. They sought an extension of time to make
further representations. They said that the Greek authorities granted asylum to AS and his son but did not
provide further support, making it difficult for AS to consider a family reunion application. He went to
Germany with his son and claimed asylum there. He began to experience low mood. His son went to
France and made his way to the UK. AS subsequently did the same. The representations said that AS was
experiencing significant mental health problems in detention, and that his son was in the UK and AS was
emotionally reliant and attached to him. They said that removal to Rwanda would be unlawful as AS was
severely vulnerable, had his son in the United Kingdom, and may face treatment in Rwanda and in the
reception system such that removal there would breach his rights under Article 3 of the ECHR.

363. In his witness statement dated 18 May 2022, AS said his claim in Greece was processed but took
two years to get to a decision. Whilst he was waiting, the Greek authorities did not help him find work or
provide shelter but did provide him and his son with €140 to provide for themselves. He described his time
in Athens. He was granted refugee status, but having seen how difficult life in Greece was, and the
difficulty in bringing his remaining family from to Iran to Greece, he decided to leave. He moved to
Germany one week after he obtained his Greek refugee status. He stayed in Germany for about five to six
months and claimed asylum. His said his son went to France. AS went to France and stayed there for
seven days before travelling to the United Kingdom. For completeness, it is clear from the witness
statement of AS's son that he had left France and arrived in the United Kingdom on around 13 April 2022.
He was already in the United Kingdom before his father left Germany.

364. On 28 May 2022, a report under rule 35 of the Detention Centre Rules was completed by a doctor at
the immigration detention centre. The report noted that AS claimed he had been in a camp in Greece
where he was threatened with a knife and abused from 2019 to 2020. He said he saw people being
stabbed there. No scars were noted on AS.

The doctor said that AS's narration of events was consistent with mental torture and would need to be
investigated. He said that AS claimed to have flashbacks and nightmares and he had been referred to the
mental health team for further assessment. That report was sent by e-mail to the Third Country Unit of the
Home Office on the evening of 1 June 2022. The Unit stated that it would be considered and a response
sent.

(iii) The inadmissibility and human rights decisions of 2 June 2022

365. By a letter dated 2 June 2022, AS was informed that his claim for asylum had been declared
inadmissible and certified under paragraph 17 of Schedule 3 to the 2004 Act. The conclusion reached was
that AS could have claimed asylum in a safe third country, and there had been no exceptional reasons
preventing him from doing so. The letter pointed out that he had been granted asylum in Greece, and had
claimed asylum in Germany, and had been in France for seven days and no exceptional reasons were
provided as to why he could not have claimed asylum there. The letter stated the conclusion that there was
no reason to believe that AS would, if removed to Rwanda, suffer inhuman or degrading treatment or that
his asylum claim would not be properly processed The letter considered AS's evidence of vulnerability and


-----

Commissioner for Refugees intervening) and other case....

emotional reliance on his son, but concluded that Rwanda was a safe place for him and that it was
appropriate to remove him there.

366. By a further letter of the same date AS's human rights claim was refused and certified as clearly
unfounded. As in all the cases before us, the human rights and inadmissibility decisions were taken by
different officials from different teams. The decision on the human rights claim was that there was no basis
to conclude there was a real risk AS would be ill-treated in Rwanda (whether by reason of his asserted
vulnerability, or otherwise). The reasons for that conclusion were set out. This letter stated that AS had
said that he had been provided with an appointment to see a doctor on arrival at the detention centre “and
the detention centre has not notified us of any concerns about your health”. It appears that the Third
Country Unit had not passed on the rule 35 report to the NRC Detained Barrier Casework Team that made
the human rights decision. The decision accepted that many people in AS's position would, to an extent,
show indicators of vulnerability, but concluded that AS had shown considerable resilience and
assertiveness by travelling through various European countries where he had sought asylum and
supported himself not always with the assistance of the authorities. The conclusion was that AS had not
established he was exceptionally vulnerable such that, if removed to Rwanda, he faced a risk of treatment
contrary to Article 3 of the Convention. The decision included the further conclusion that AS had not
demonstrated he had an established family or private life in the United Kingdom falling within Article 8 of
the Convention but, that even if such a family or private life did exist, interference with it consequent on
removal to Rwanda would be justified as a necessary and proportionate means of ensuring the public
interest in the effective maintenance of immigration controls.

367. Removal directions were issued for the removal of AS to Rwanda on 14 June 2022, but these were
subsequently cancelled.

(iv) Further representations, and consideration of them

368. Further representations were made by AS's lawyers on 8 June 2022. Various material was provided,
including the rule 35 report of 28 May 2022. The representations made express reference to this
document. On or about 9 June 2022, AS's solicitors also provided a psychological report on AS prepared
by Dr Olowookere. He stated that AS was suffering from a depressive disorder to a moderate degree, and
post-traumatic stress disorder. The nature of the mental disorder was chronic, relapsing and remitting with
a moderate degree. Dr Olowookere said that AS had described suicidal ideation which had become worse
lately but he had not attempted suicide as he talked to a priest and because of his religious faith.

369. By letter dated 12 June 2022, the Home Secretary said that AS's further representations in relation to
his human rights claim had been “unsuccessful”. The letter considered the representations and the rule 35
report which were said to show that AS was highly vulnerable. It considered the report by Dr Olowookere in
detail, noting that his opinion was that AS was suffering from a depressive disorder of a moderate degree
and posttraumatic stress disorder. The letter considered generally the position in Rwanda and whether it
would be a safe country for AS. It considered his claim to private life. The conclusion was that the
representations did not amount to a fresh claim as the further material did not give rise to a realistic
prospect of success before an immigration judge. Consequently, the certification of the original refusal
remained in place such that AS could only appeal the human rights decision from outside the United
Kingdom.

370. On 12 June 2022, AS's son made a witness statement. He explained that he was with his father in
Greece and described the problems that he said they had there. He described how life was in Germany
and how he decided to travel to the United Kingdom. He said that he told his father he would go first and if
it was safe his father could follow him. He went to France and had travelled to the United Kingdom before
his father came to France. On 14 June 2022 AS made a second witness statement saying how close he
and his son were and how they went through the dangerous journey from Iran together.

(v) The inadmissibility and human rights decisions of 5 July 2022


-----

Commissioner for Refugees intervening) and other case....

371. On 5 July 2022, the Home Secretary issued a new inadmissibility decision in which she considered
the material filed by the UNHCR in the judicial review proceedings, the representations of 8 June 2022, the
rule 35 report, the report of Dr Olowookere, and the witness statement of AS's son. The decision
maintained her previous conclusion that the asylum claim was inadmissible, and the certification of that
decision. The letter pointed out that AS had not been prevented from claiming asylum, and had done so in
Greece. It considered AS's vulnerabilities, as identified in the rule 35 and the medical report, and
concluded that they would not impact on AS's ability to engage with the asylum system in Rwanda, and
that he would be able to access healthcare to address those needs in Rwanda. It also considered other
matters.

372. By a letter dated 5 July 2022, the Home Secretary took a second decision on AS's human rights
claim. As before, the human rights claim was considered by the NRC Detained Barrier Casework Team.
This letter corrected an error in the earlier decision

(concerning the fact that the UNHCR did not in fact work with the Home Office in Rwanda), but did not
consider the material the UNHCR had filed in the judicial review claim.

(vi) The challenges raised by AS specific to his own circumstances

373. By a Claim Form filed on 13 June 2022, and amended subsequently, AS challenged the decision to
certify the human rights claim as clearly unfounded and the decision to reject the further submissions as
not amounting to a fresh claim. He contended the Home Secretary had not properly considered his mental
health condition, or the interference with his/his son's right to family and private life. Ms Naik KC, for AS,
submitted that the heart of the claim was the proposition that it would be reasonably open to a Firsttier
Tribunal judge to conclude that on the facts of this case, taken at its highest, AS had established his
human rights claim. Thus, she submitted, the human rights claim ought not to have been certified.

374. AS also challenged the determination in the inadmissibility decision that Rwanda was a safe country
for AS by reference to the generic issues concerning Rwanda and contended that neither decision had
been taken fairly.

375. Mr Dunlop submits as follows: (a) the report of Dr Olowookere post-dated the decision on 2 June
2022 to certify the human rights claim; (b) in any event, neither that report nor the rule 35 report were
capable of justifying a view that a First-tier Tribunal might reach a contrary decision because the evidence
was not capable of demonstrating substantial grounds for believing that he faced a real risk of subjection to
inhuman or degrading treatment in Rwanda; (c) AS was wrong to submit that this was a case where the
mental condition arose out of actions for which the state was responsible, rather it was a naturally
occurring illness; (d) a properly directed tribunal judge would be bound to conclude that the care available
for AS in Rwanda would be adequate; and (e) on the article 8 claim, that the evidence of AS's son had not
been before the decision-maker when the human rights claim was certified as clearly unfounded. All this
notwithstanding, he accepted that AS's son's witness statement had not been considered in the context of
the human rights decision and a further decision would need to be taken.

(vii) Conclusions

376. The 5 July 2022 decision maintaining the refusal of the human rights claims and certification as
clearly unfounded is unlawful because it failed to consider the 12 June 2022 witness statement of AS's son
as to the relationship between them. The Home Secretary has recognised that she must consider the
matter again, but has not withdrawn her decision. Further, although not raised as a ground of claim in AS's
case, the Home Secretary did not, for the purposes of the decision, consider the UNHCR material filed in
the judicial review proceedings. That too, was in error. In the premises, the better course of action is to
quash the 5 July 2022 decision.

377. The 2 June 2022 human rights decision should also be quashed. The Home Secretary had been
provided with the rule 35 report but it was not considered for the purposes of this decision. Rather, the
letter suggests the absence of any concerns about AS from the detention centre. Thus, and although not
put in this way the Home Secretary did fail to have regard to potentially relevant material Whether or not


-----

Commissioner for Refugees intervening) and other case....

that material would have made a difference is a matter that the Home Secretary should properly have
considered It follows from the above, that the certification decision of 2 June 2022 was also flawed.

378. We have considered whether it would be appropriate on the particular facts of AS's case to conclude
that it is highly likely that the outcome for him would have been substantially the same even if the rule 35
report had been considered. The Home Secretary did consider that report as part of the further
submissions on 13 June 2022, concluding that the representations did not amount to a fresh claim.
However, we do not refuse relief on that basis in this case. The fact is that the supplemental reasons
started from the premise that there was a valid refusal of the human rights claim which had been properly
certified, whereas that was not the case as the 2 June 2022 decision had reached a conclusion without
consideration of relevant material. In these circumstances the 2 June 2022 decisions should be quashed,
together with the 13 June 2022 decision that fresh representations did not amount to a fresh claim, and the
5 July 2022 decisions which maintained the 2 June 2022 decisions.

379. Subject to the issue of procedural fairness, which we consider below, the grounds for challenging the
lawfulness of the inadmissibility decision are the generic ones discussed above and they are not made out
and those grounds do not invalidate the inadmissibility decision.

D.  Decision on procedural fairness

380. To give effect to her Rwanda policy, the Home Secretary took a series of decisions (a) under
paragraph 345A of the Immigration Rules (on inadmissibility); (b) under paragraph 345C of the Immigration
Rules (to remove each Claimant to Rwanda having decided that Rwanda was a safe third country as
defined at paragraph 345B of the Immigration Rules); and (c) to make a certification decision under
paragraph 17 of Schedule 3 to the 2004 Act (on the basis that she holds the opinions specified at
subparagraph (b) and (c)).

381. The Claimants submit that there were breaches of procedural fairness in their cases which rendered
unlawful either the inadmissibility decisions or the decisions to refuse and certify the human rights claims,
or both. For convenience, the complaints can be divided broadly into two categories. One of set complaints
is that there was procedural unfairness at different stages such as the screening interview or the giving of
the notice of intent. A second set complaints concerns whether, before decisions were taken, the
Claimants were given a fair opportunity to make representations. Here, the points raised concern the time
permitted for representations to be made, the information that ought to have been provided by the Home
Secretary to permit a fair opportunity to make representations, and whether there was sufficient access to
legal advice (again, for the purposes of permitting representations to be made). These complaints were
pursued both by the individual Claimants, and also, in a separate claim (CO/2056/2022) by Asylum Aid, a
charity that, among other things, provides legal representation to asylum seekers. Asylum Aid's overall
submission was that the approach taken by the Home Secretary to taking the decisions required under the
Immigration Rules and the 2004 Act was unfair because it was systemically flawed. The Claimants in all
other claims adopted this submission. We will address this latter set of complaints first, since these matters
provide the context for considering the complaints that are specific to each Claimant.

_(1)                        Was there a fair opportunity to make representations?_

382. The complaints rest on the decision-making process as described above at paragraphs 29 – 34: an
asylum screening interview conducted a day or so after the claim for asylum had been made; a Notice of
Intent, ordinarily issued shortly after the screening interview which requested representations within 7 days;
decision letters (on inadmissibility and removal to Rwanda) issued shortly following the expiry of the period
permitted for representations; and directions for removal to Rwanda issued at the same time as the
decision letters. This sequence of steps can be gleaned from the Inadmissibility Guidance. The timetable
for the steps is not set out in that policy, save that the 7-day period for representations is in the standard
form Notice of Intent which is part of the Inadmissibility Policy document. However, a short timetable, as
described above, was applied in practice for each of the individual Claimants: see the narratives for each
Claimant in Section C of this judgment.


-----

Commissioner for Refugees intervening) and other case....

383. There is no dispute on the general principles. A duty to act fairly may be implied into a statutory
framework. That depends upon the context, the nature of the decision and its impact on the individual, and
other relevant factors. Promises made by the decisionmaker and practices they adopt may give rise to a
legitimate expectation that a decision will be taken in a particular way. Procedural fairness may often
require that a person who may be significantly adversely affected by a decision will have the opportunity to
make representations before the decision is taken. If an opportunity to make representations is to be
effective the decision-maker may need to provide that person with information on “the gist of the case
which he has to answer”. See generally R v Secretary of State for the Home Department ex parte Doody

[1994] 1 AC 531, per Lord

Mustill at page 560; Bank Mellat v HM Treasury (No. 2) [2014] AC 700per Lord Neuberger PSC at §179; R
_(Citizens UK) v Secretary of State for the Home Department [2018] 4 WLR 123per Singh LJ at §§68 – 71;_
and _R (Balajigari) v Secretary of State for the Home Department [2019] 1 WLR 4647per Underhill LJ at_
§§45 and 59 – 60.

384. The focus of the Claimants' submission was the inadmissibility decision under paragraph 345A of the
Immigration Rules, and the certification decision under paragraph 17 of Schedule 3 to the 2004 Act, and
the decision taken in each case for the purposes of the removal decision under paragraph 345C of the
Immigration Rules that Rwanda is a safe third country, as defined at paragraph 345B of those Rules. For
the purposes of the decision under paragraph 17 of Schedule 3 to the 2004 Act the Home Secretary must
be of the opinion that the State to which she proposes to remove the asylum claimant

“… is a place –

(i) where the person's life and liberty will not be threatened by reason of his race, religion, nationality,
membership of a particular social group or political opinion, and

(ii) from which the person will not be sent to another State otherwise than in accordance with the Refugee

Convention.”

(see sub-paragraph (c)). Under paragraph 345B of the Immigration Rules a country is a safe third country
“for a particular applicant” if

“(i) the applicant's life and liberty will not be threatened on account of race, religion, nationality,
membership of a particular social group or political opinion in that country;

(ii) the principle of non-refoulement will be respected in that country in accordance with the Refugee
Convention;

(iii) the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman, or
degrading treatment as laid down in international law, is respected in that country; and (iv) the possibility
exists to request refugee status and, if found to be a refugee, to receive protection in accordance with the
Refugee Convention in that country.”

385. The submissions for the Claimants were to the following effect.

(1) The procedure adopted by the Home Secretary, which provides for a short timetable for the decisionmaking process, is inappropriate for decisions under paragraph 17 in Part 5 of Schedule 3 to the 2004 Act.
Decisions under Part 5 do not (unlike decisions under Parts 2 – 4 of Schedule 3) rest on any presumption
that the State concerned will comply with the Refugee Convention. Rather, in each case where a decision
is made under paragraph 17, that matter must be considered afresh.

(2) For the purposes of making representations in respect of proposed decisions under paragraph 17 of
Schedule 3 and/or paragraph 345C of the Immigration Rules the person subject to the decision must have
an opportunity to make representations on the criteria in paragraph 17(c) and in paragraph 345B. For that
opportunity to be effective, the Home Secretary must provide the person with all the material she has relied
on to decide that Rwanda is a safe third country (including the material she relied on to reach the
conclusion that Rwanda would abide by its obligations under the MOU and the notes verbales).


-----

Commissioner for Refugees intervening) and other case....

(3) A 7-day period to make representations (the period referred to in the Notice of Intent) is far too short –
that period could never be sufficient to prepare and submit representations on the matters at (2) above.
Further, the Home Secretary's policy (as set out in the Inadmissibility Guidance) provides no flexibility – it
says nothing as to the possibility that time permitted for representations could be extended.

(4) Representations on the matters required cannot sensibly be made unless each person has access to
lawyers to help him prepare the representations.

(5) The consequence of the unfair procedures at (1) – (4) above is that any use of standard removal
directions (which assumed a minimum of 5-days' notice of removal) would impede access to court.
Insufficient time for representations

having been permitted before decisions were made will mean that it will take longer to prepare applications
for judicial review.

386. The Home Secretary accepted that procedural fairness required an opportunity to make
representations. Her submission was that each of the individual Claimants had, by the time of the 5 July
2022 decisions, had a fair opportunity to make representations, and each had made representations. As to
the position in principle, the Home Secretary's submission was initially summarised in a note dated 13
September 2022 provided (with our permission) after the hearing of the first set of cases. The material part
was as follows

“7. As to what procedural fairness requires in this context … the Secretary of State should inform the
Claimant of, and allow him or her an opportunity to make representations on, the following matters:

(1) The Secretary of State is considering whether the Claimant was previously present in or had a
connection to one or more safe third States and what the name of each such State was.

(2) The Secretary of State is considering whether to declare the asylum claim inadmissible and to remove
the Claimant to Rwanda.

(3) The Secretary of State considers that Rwanda is a safe country.

(4) The Secretary of State will consider whether there is any reason specific to the Claimant why Rwanda
would not be a safe third country in the individual circumstances of the Claimant.”

Other parties filed written submissions in response to this Note. Those submissions accepted the premises
quoted above, but contended that the Home Secretary had failed to meet that standard.

387. During the hearing of the Asylum Aid claim in October 2022, and following questions from the court,
the Home Secretary revised her position: she no longer accepted that fairness required the opportunity to
make representations on the matter at (3) above – i.e. on her conclusion that “Rwanda is a safe country”.
This change of position came towards the end of the hearing, and we permitted all parties (those who were
present at the October hearing, and those who had been present at the September hearing) to file written
submissions in response to the Home Secretary's revised position: see the Order made on 17 October
2022. In their written submissions, AS (CO/2098/2022) and the AAA claimants (CO/2032/2022) contended
that it had been unfair to permit the Home Secretary to change her position at a hearing which they had not
attended. We disagree. We note that, in fact, counsel for these Claimants were present at the hearing of
the Asylum Aid claim. Those counsel did not attend in person, instead they had applied (and been
permitted) to attend remotely, but that was a matter of choice for them and their clients. More importantly,
those Claimants have had and have taken the opportunity to make written submissions in response to the
Home Secretary's change of position.

388. In these cases, the overall decision affecting any of the Claimants covered, broadly, two areas. There
was the decision on whether the Claimant's asylum claim was inadmissible because he could have
enjoyed sufficient protection in a safe third country (i.e. the decision under paragraph 345A(iii)(b) of the
Immigration Rules). In practice, in the present cases, that involved consideration of whether the Claimant
could have claimed asylum in one of the countries he passed through on his way to the United Kingdom


-----

Commissioner for Refugees intervening) and other case....

and if so, whether there were exceptional circumstances which prevented him from making an asylum
claim. Then there was the decision to remove the individual Claimant to Rwanda (paragraph 345C of the
Immigration Rules), and to make the certificate under paragraph 17 of Schedule 3 to the 2004 Act. Each of
these decisions required the Home Secretary to consider whether generally, Rwanda would meet its
obligations under the Refugee Convention (see paragraph 345B(ii) – (iii) of the Immigration Rules) and,
specifically whether it would treat the Claimant in accordance with the requirements of that Convention
(see paragraph 345B(i) of the Immigration Rules, and paragraph 17(c)(i) – (ii) of Schedule 3 to the 2004
Act).

389. Against that background, the core of the procedural fairness obligation is two-fold. First, it is to enable
the Claimant to have an opportunity to explain why his asylum claim should not be treated as inadmissible.
In each of the present cases that meant giving the Claimant the opportunity to explain why he had not
claimed asylum in the safe third countries (i.e. the various EU Member States) each passed through _en_
_route to the United Kingdom. Once representations on that matter had been provided the matter of whether_
those representations amounted to “exceptional circumstances preventing an [asylum claim] being made”,
was a matter for the Home Secretary's assessment. Contrary to the submission made by some of the
Claimants, fairness did not require that the Claimants have the opportunity to make representations in
response to some form of provisional view that such circumstances existed. What fairness requires in the
context of a decision under paragraph 345A(iii)(b) of the Immigration Rules is an opportunity for the
Claimant to provide any explanation he has for not making an asylum claim before reaching the United
Kingdom. Fairness did not require the opportunity to make representations in response to the Home
Secretary's evaluation (or provisional evaluation) of that explanation.

390. Secondly, procedural fairness requires a Claimant to have the opportunity to explain why, in his case,
his right to life and liberty would be threatened if he were removed to Rwanda. That must be an opportunity
for him to put forward reasons why his specific situation is such that he should not be removed to Rwanda.
In the present cases, the Notices of Intent given to each Claimant requested representations on each of
these matters (see the “standard form” Notice of Intent, in the Inadmissibility Policy at paragraph 33
above). Therefore, in the present context: (a) fairness did not require the Home Secretary to provide each
Claimant with all the information she relied on to form her general opinion on Rwanda – for example that
Rwanda meets the criteria at paragraph 345B(ii) – (iv) of the Immigration Rules; and (b) fairness did not
require that each Claimant have the opportunity to make representations on those matters.

391. The Claimants have made several submissions to the contrary, but none is compelling. The primary
point made is to the effect that, so far as concerns the paragraph 345C decision on removal taken by
reference to the notion at paragraph 345B of what is a “safe third country”, there is no material distinction
between paragraph 345B(i) on the one hand, and paragraph 345B(ii) – (iv) on the other. This point has
been put in a number of ways, either disputing that any real distinction exists between generic matters
affecting the whole country (i.e. criteria (ii) – (iv)) and matters particular to a claimant (criterion (i)) or, on
the assumption the distinction does exist, disputing that the distinction is material because any generic
failing (i.e. the country fails to meet any of criteria (ii) – (iv)) would inevitably prevent a removal decision
under paragraph 345C, and so is a matter on which a claimant ought to be permitted to make
representations. The further submission made by the Claimants rests on the Home Secretary's use of the
power at Part 5 of Schedule 3 to the 2004 Act. As stated above, use of the power to certify under
paragraph 17 of Schedule 3 to the 2004 Act is an essential component of the Home Secretary's Rwanda
policy: see at paragraph 12 above. Absent such certification, a person who has made an asylum claim in
the United Kingdom cannot be removed until the claim (and any appeal arising from it) has been
determined. The submission here is consequent on the generic submission that in these cases the Home
Secretary has used the paragraph 17 power for an improper purpose, and use of the paragraph 17 power
requires a case by case decision on the criteria at paragraph 17(c) and therefore, each time the power is
used there must be a fresh decision on whether, generally, Rwanda meets its obligations under the
Refugee Convention. The Claimants contend this means that each Claimant must have the opportunity to
make representations on the general position on Rwanda, not simply on matters relating to him that may
affect his treatment were he to be removed there The AAA Claimants go so far as to submit that if fairness


-----

Commissioner for Refugees intervening) and other case....

does not require an opportunity to make representations on the general issue (either by reason of their
submission on Schedule 3 to the 2004 Act, or on a proper application of paragraphs 345B and C of the
Immigration Rules) that would “create a legal black hole”.

392. A distinction does exist between the criteria at paragraph 345B of the Immigration Rules. Criterion (i)
is formulated by reference to the asylum applicant's own circumstances and characteristics, criteria (ii) –
(iv) are framed by reference to the general position in the country in question. The real issue is whether
that distinction is material for the purposes of setting what is required by law for fair exercise of the
paragraph 345C power to remove to a safe third country. Our conclusion is that the distinction between
what an asylum claimant may be able to say about his own circumstances and how those might be
relevant to whether he is removed to a particular country, and whether that country, generally, complies
with its obligations under the Refugee Convention does determine the extent of the legal requirement of
procedural fairness in this context. Procedural fairness requires that an asylum claimant should have the
opportunity to make representations on matters within the criterion at paragraphs 345B(i) of the
Immigration Rules. Those are matters relevant to any decision to remove (self-evidently) and matters the
asylum claimant is uniquely placed to consider and explain. Matters known to the asylum claimant may be
a relevant consideration; the Home Secretary must take it into account; and the duty to act fairly must
apply to require the claimant to have an opportunity to make representations. The same applies to the
criteria at paragraph 17(c) of Schedule 3 to the 2004 Act which are also directed to the specific position of
the asylum claimant. Criteria (ii) – (iv) within paragraph 345B of the Immigration Rules are different, and
require evaluation of whether, generally, the relevant country complies with its obligations under the
Refugee Convention. Those matters will go well beyond the circumstances of any one asylum claimant;
they are also criteria which the Home Secretary, given the resources available to her, is well-placed to
assess. We do not consider that the duty that the Home Secretary act fairly in exercise of the power at
paragraph 345C of the Immigration Rules requires

an asylum claimant to have the opportunity to make representations on these matters. It is not enough to
say that criteria (ii) – (iv) are relevant to the decision to remove and since the asylum claimant is the
subject of that decision he must have a legal right to comment on those matters before the decision is
made. That is a non-sequitur. The scope of the obligation to act fairly is measured in specifics. This is not
to say that any individual faced with the possibility of removal to a third safe country could not seek to
persuade the Home Secretary that one or other of criteria (ii) – (iv) was not met, and that if such
representations were made, the Home Secretary should have regard to them. But such representations
would not be made in exercise of any legal right arising out of an obligation to ensure procedural fairness.
Further, to the extent that an asylum claimant may wish to make such representations he has sufficient
information about what such representations must be directed to, by reason of paragraph 345B itself. That
explains the matters the Home Secretary must consider. The legal duty to act fairly does not require the
Home Secretary provide him with all the material available to her; the legal duty to act fairly does not in the
present context require that an asylum claimant be put in the position to second-guess the Home
Secretary's evaluation on criteria (ii) – (iv).

393. The further submission, made by reference to paragraph 17 of Schedule 3 to the 2004 Act adds
nothing. As explained above, the submission that the Home Secretary, when exercising her power under
paragraph 17, may not resort to prior general assessment, rests on a false premise. That is not the point of
distinction between the powers in Part 5 of Schedule 3 and those in Parts 2 – 4 of that Schedule. Nor does
our conclusion on the scope of application of the duty to act fairly establish any “legal black hole”. The
decisions taken in exercise of paragraph 345C of the Immigration Rules are subject to challenge on an
application for judicial review on all the usual public law grounds.

394. The conclusion on the scope of the right to make representations also addresses the other general
complaints of procedural unfairness. For the purposes of taking a decision under paragraph 345B of the
Immigration Rules (or any decision under paragraph 17 of Schedule 3 to the 2004 Act) the Home Secretary
is not, as a matter of law, required to provide each Claimant with all material she has relied on to conclude
that, generally, Rwanda will comply with its obligations under the Refugee Convention. The Claimants'


-----

Commissioner for Refugees intervening) and other case....

submissions (a) that in no case could 7 days be a permissible period within which to require
representations to be made; and (b) that effective representations could be made only with the assistance
of a lawyer, both rested on the premise that the duty to act fairly required that claimants be given the
opportunity to make representations on Rwanda's general compliance with Refugee Convention
obligations and for that purpose had to be provided with all material available to the Home Secretary.
When that premise falls away, as we have concluded it does, those submissions fall away with it.

395. Furthermore, it is also right to note for the future that the generic issues raised by the Claimants as to
why relocation to Rwanda would be unlawful have now been determined by this court (subject to any
appeal) and subject to any relevant new information emerging. Any issue of procedural fairness in future
cases will necessarily be addressed to the facts of those cases and the reasons why the individual could
not claim asylum on route to the United Kingdom and why removal to Rwanda would not be appropriate for
that individual.

(2)  Other procedural failures raised by the individual Claimants

396. The Claimants make several criticisms of some of the questions asked at the screening interview.
They also complain about matters such as the lack of legal advice in advance of the interview or complain
that the interview was rushed, or they did not understand the interpreter.

(i)          Screening interviews.

397. The Claimants were people who had claimed asylum. They attended a screening interview. There
was nothing unfair in them being asked questions about their journey to the United Kingdom and why they
did not claim asylum before reaching the United Kingdom. Those were questions of fact which did not
require legal advice to answer.

398. Necessarily, screening interviews occurred before the relevant team in the Home Office addressed
the question of whether the asylum claim might be inadmissible – as explained in the Inadmissibility
Guidance one purpose of the screening interview was to obtain information relevant to whether the claim
might be inadmissible. There was nothing procedurally unfair in the information provided in the screening
interview then being used to determine whether or not to send a Notice of Intent indicating that the
individual's asylum claim might be declared inadmissible or that they might be removed to another country.

(ii)          The notices of intent.

399. The Claimants complain about the use of the Notices of Intent. We do not consider that there is
anything procedurally unfair about the fact that the claimants in these cases did not have legal advice
before the notice of intent was issued. Nor do we consider that the information in notices provided was
inadequate to permit relevant representations to be made, consistent with the Home Secretary's duty to act
fairly. Each Claimant was told that he was a person who it was thought might have been able to claim
asylum in a specific named country or countries, and that the Home Secretary was considering removing
him to the named countries or to Rwanda. The information on which countries they had passed through
was information that largely came from the Claimants themselves.

400. The sequence of events in each case is set out above (in Section C). AS (CO/2098/2022)
complained about lack of disclosure, including not being provided with a record of the screening interview.
We do not consider that there was any sort of procedural shortcoming; AS, who had already been granted
asylum in Greece and had claimed it in Germany, was well-able to address the relevant factual matters,
and indeed his lawyers made representations on his behalf.

(iii)          Interpretation facilities

401. Some Claimants have criticised the interpretation facilities available, at the screening interviews, and
when the Notices of Intent were given to Claimants (the evidence on these claims is disputed). This, it is
said, impeded the ability to provide information and make representations. However, as set out above,
each Claimant was, at some stage, told that he might be removed to Rwanda and either needed to see a
solicitor or give reasons as to why he should not be removed there Ultimately each Claimant did make


-----

Commissioner for Refugees intervening) and other case....

representations (both in relation to the decisions on inadmissibility and removal and in support of any
human rights claims that were raised), and did so effectively. Even if it is correct that some interpreters
provided for some Claimants did not speak the correct dialect, such errors by the Home Secretary (if that is
what they were) were not material, looking at the decision-making process in each case in the round.

402. Claimants also complained about the limited time available to make representations. We are satisfied
that, given the nature of the representations that the duty to act fairly requires that the Claimants have the
opportunity to make, a period of seven days to make representations was adequate. Claimants can seek
further time (and can continue to make representations and submit evidence until the decision is taken).
We do not consider that any of the Claimants has established any procedural unfairness in this regard.

(iv)          Access to legal advice.

403. There have been criticisms of the lack of access to legal advice. Given the scope of the right to make
representations in this context, we do not consider that procedural fairness requires that a person who is at
risk of action under the Inadmissibility Guidance be provided with legal representation for the right to make
representations to be an effective right. It is essentially a matter of fact as to why he did not claim asylum in
a third country on route to the United Kingdom. It is essentially a matter of fact for him to give his reasons
why he should not be removed to Rwanda.

404. We have, however, heard submissions on this issue. In deference to those submissions we make the
following additional observations relevant to the circumstances of the individual Claimants.

405. The evidence is that each asylum claimant, as part of his induction when he arrives at an immigration
detention centre, is informed of the duty solicitor advice scheme. In addition, there is evidence in some
cases that welfare officers within the detention centres advised individual Claimants how to obtain access
to a lawyer. On the facts of the individual Claimants in this case, five of the eight whose cases have been
considered did have access to legal advice, and made representations before the expiry of the seven days
for submissions expired or, in any event, before the decision was taken: see above in relation to AHA, AT,
AAM, RM and AS. There is no basis in these cases for considering that there could have been any
procedural unfairness arising out of the time limits for making representations or any issues with lawyers.

406. So far as concerns the other three, AAA was told that he might be taken to Rwanda and that he
should contact a solicitor and the duty solicitor scheme was explained to him. NSK was told about the duty
solicitor scheme. HTN complains about the lack of legal representation and says that if he had such
representation he could have been referred for a medico-legal report. He accepts, however, that he was
told he could get help to find a solicitor at the welfare office. He went there and asked for a solicitor and his
details were given to a solicitor and he received two calls but after that there was no further contact. He
told the welfare officer he needed a new solicitor.

407. AAA and NSK did not have legal representation to start with and did not make representations until
after the inadmissibility decisions had been notified to them, respectively. HTN had had access to a lawyer
but that lawyer had not made representations for him and he had to seek a new lawyer. In all three cases,
after the inadmissibility decision was taken, representations were then made with the assistance of
lawyers. Nonetheless, we do not consider on all the evidence that there was any procedural unfairness in
relation to the arrangements relating to the provision of the notice of intent or the arrangements relating to
obtaining legal advice in the case of AAA, NSK or HTN. In each case steps were taken to inform each of
them of the contents of the notice of intent, including with the use of interpreters, and they were told about
means of obtaining legal representation. In any event, the inadmissibility decisions are to be quashed for
other reasons. AAA, NSK and HTN have had lawyers instructed for some time and have made detailed
representations on their cases. Those representations, and all other potentially relevant material, will need
to be considered by the defendant. In all the circumstances, we do not consider that there has been any
procedural unfairness and, in any event, we do not consider as a matter of discretion, that any remedy is
called for in that regard.

(v)          Should decisions have been delayed?


-----

Commissioner for Refugees intervening) and other case....

408. AAA submits that the Home Secretary should have delayed taking the decisions of 5 July 2022 to
give him further time to obtain a further psychological report. Given that, for the reasons in Section C of this
judgment, those decisions will be quashed it is not necessary to express a conclusion on this complaint.

409. AT submits that the Home Secretary should have informed him that she was proposing to take the 5
July 2022 decision and, if she had done so, he would have asked her to delay any decision to allow him to
provide a psychological report that was in the process of being finalised.

410. We do not consider the Home Secretary was obliged to inform AT that a decision was about to be
taken. The Notice of Intent had informed him that a decision could be taken after the period for
representations had expired. That was sufficient warning.

411. In AAM's case, representations had been made and a Rule 35 report provided to the Home
Secretary. In the representations made on 1 July 2022, at paragraph 27, AAM's solicitors stated that they
were putting the Home Secretary “on notice” that they were working to obtain further evidence from a
medical expert and hoped to have that available by 5 July 2022. However, it was not incumbent on the
Home Secretary to wait for any further evidence that might (or might not) be produced.

412. In NSK's case, representations, and a rule 35 report had been received, and reports on trafficking
from Mr Harvey and Dr McQuade. In a letter of 1 July 2022, the solicitors indicated that “further evidence
will shortly be forthcoming” and referred to a scarring report, a psychiatric report, and potentially further
reports from Mr Harvey and Dr McQuade. Here too, it was not incumbent on the Home Secretary to wait to
see what, if any, further evidence might be produced.

413. The same applies in relation to RM. He had submitted medical evidence and there was no
requirement to wait to see if further evidence would be submitted.

(3)  The complaint that the Home Secretary's policy was “systemically” unfair

414. Asylum Aid's claim is that the procedure followed by the Home Secretary to take the decisions under
the Immigration Rules and the 2004 Act was systemically unfair. The focus of that complaint is the 7-day
period to make representations in response to the possibility of inadmissibility and removal decisions (14
days if the asylum claimant is not in detention). In substance the case put by Asylum Aid follows the
complaints made by the individual Claimants in CO/2032/2022: see above at paragraph 385.

415. Ms Kilroy KC submitted that on analysis the arrangements involved six decisions concerning a range
of factual and legal issues and the decision-making process was complex. The first three decisions
involved whether the individual passed through a country or countries on route to the United Kingdom and
could have claimed asylum there, whether that country or countries were safe and whether the journey to
the United Kingdom was a dangerous one made after 1 January 2022. The fourth decision concerned the
question of whether Rwanda was safe for the individual. The fifth and six decisions concerned decisions on
any human rights claim and any certification that that claim was clearly unfounded.

416. Ms Kilroy submitted that the fourth decision involved, in each individual case, considering all the
evidence about the general safety of Rwanda and the individual's own circumstances and submitted that
the individual must have the opportunity of, amongst other things, obtaining expert evidence about
conditions in Rwanda. The Home Secretary would have to provide all the information relevant to the
assessment of the conditions and general safety in Rwanda. Where, as here, she relied on assurances
such as those in the MOU or the Notes Verbales, the Home Secretary would need to provide all relevant
information and the individual would have to have the opportunity to challenge the evidence before a
decision on inadmissibility or removal was made. The individual would need to have the benefit of expert
evidence to test whether there was a sound basis for believing that assurances would be fulfilled. As Ms
Kilroy concisely summarised her submissions in oral argument, in relation to the fourth decision, the Home
Secretary must provide to the individual everything on which she relied to demonstrate that Rwanda was
safe and information on key matters that undermined that conclusion. Furthermore, that obligation
continued in each individual case irrespective of what the court might rule in this case.


-----

Commissioner for Refugees intervening) and other case....

417. The premise underlying Ms Kilroy's submission was that the duty to act fairly required the Home
Secretary to permit representations on all the criteria in paragraph 345B of the Immigration Rules and, so
that effective representations could be made, required the Home Secretary to provide each Claimant with
all material she relied on to reach the conclusion that, generally, Rwanda would comply with its obligations
under the Refugee Convention and the MOU.  Given the breadth of the information that needed to be
provided, the issues that would arise would, she submitted, need expert evidence and legal
representations, Ms Kilroy submitted the 7-day period to make representations was plainly inadequate,
such that the Inadmissibility Policy (which includes the standard form Notice of Intent referring to the 7-day
period to make representations) was unlawful. In addition, she submitted that the lack of time for
representations prior to the decisions being made meant that standard form removal directions, allowing
five days' warning of removal, would amount to unlawful obstruction of access to a court. Since there was
so little time to make representations in advance of the decisions the warning period prior to removal had
to be longer to

permit a proper opportunity for legal challenges (for example, seeking interim relief) to be formulated and
filed.

418. The question of the lawfulness of policies or practices was considered, and the existing case law
reviewed, by the Supreme Court in _R(A) v Secretary of State for the Home Department [2021] 1 WLR_
3931. That case concerned guidance for disclosing information about child sex offenders. The material part
of the policy provided that if an application for disclosure raised concerns, police should consider if
representations should be sought from the subject of the disclosure to ensure that the police had all
necessary information to take a decision on disclosure. The argument was, amongst others, that the
guidance created an unacceptable risk of unfairness (see paragraph 23 of the judgment of Lord Sales and
Lord Burnett CJ with whom the other Justices agreed).

419. The Supreme Court considered that the test was whether the policy in question positively authorised
or approved unlawful conduct by others. If the policy directed them to act in a way which contradicted the
law, it was unlawful. That called for a comparison of what the relevant law requires and what a policy
statement says officials should do. See generally, paragraphs 38 and 41 of the judgment. That approach
applied where it was said that a policy gave rise to unfairness: see paragraph 65. If it were established in a
particular case that there had been a breach of the duty of fairness in that individual's case, that would be
unlawful. Where the question was whether a policy was unlawful, as is clear from paragraph 63 of the
judgment:

“… that issue must be addressed by looking at whether the policy can be operated in a lawful way or
whether it imposes requirements which mean that it can be seen from the outset that a material and
identifiable number of cases will be dealt with in an unlawful way.”

The Supreme Court accepted that the approach set out by Lord Dyson MR at paragraph 27 of his
judgment in R (Detention Action) v First Tier Tribunal (Immigration and Asylum Chamber) [2015] 1 WLR
5341, summarised the principles in a way that was consistent with the approach identified in its judgment.
Lord Dyson had said this:

“27. I would accept Mr Eadie's summary of the general principles that can be derived from these
authorities: (i) in considering whether a system is fair, one must look at the full run of cases that go through
the system; (ii) a successful challenge to a system on grounds of unfairness must show more than the
possibility of aberrant decisions and unfairness in individual cases; (iii) a system will only be unlawful on
grounds of unfairness if the unfairness is inherent in the system itself; (iv) the threshold of showing
unfairness is a high one; (v) the core question is whether the system has the capacity to react appropriately
to ensure fairness (in particular where the challenge is directed to the tightness of time limits, whether there
is sufficient flexibility in the system to avoid unfairness); and (vi) whether the irreducible minimum of
fairness is respected by the system and therefore lawful is ultimately a matter for the courts. I would enter a
note of caution in relation to (iv). I accept that in most contexts the threshold of showing inherent unfairness


-----

Commissioner for Refugees intervening) and other case....

is a high one. But this should not be taken to dilute the importance of the principle that only the highest
standards of fairness will suffice in the context of asylum appeals.”

As the Supreme Court in A noted, however, the core question was whether the system had the capacity to
react appropriately to ensure fairness (see paragraph 68).

420. So far as the principle of access to justice is concerned, the principle and its operation is described in
_R (Unison) v Lord Chancellor (Equality and Human Rights Commission intervening) (Nos. 1 and 2) [2020]_
AC 869, and A at paragraphs 80 to 83. One point to note in the present case is that the access to court
submission is parasitic on the unfair system submission. Ms Kilroy accepted that if the period permitted for
representations before the decisions was lawful, then removal directions within the standard form would be
lawful.

421. We have, above, stated our conclusion that in these cases the obligation to act fairly did not require
the opportunity to make representations on the criteria at paragraphs 345B(ii) – (iv) of the Immigration
Rules or provision by the Home Secretary of the material she relied on to conclude, generally, that Rwanda
would meet its international law obligations (whether under the Refugee Convention or under the MOU).
That removes the premise for Ms Kilroy's unfair system submission. In consequence, the premise for the
access to court submission also falls away. So far as may be relevant, we note that the individual
Claimants in these cases were able to seek judicial review. We also note, in passing, that of the 50
individuals referred to in evidence filed on behalf of Asylum Aid, 20 had brought claims (which includes at
least some of the claimants in the linked cases before us), the position in relation to eight was not known,
and 22 had not brought claims. We do not rely upon those figures for our conclusion. But that evidence
does not appear to us to demonstrate that the arrangements prevent access to justice.

422. Since the above is sufficient to dispose of Asylum Aid's claim, we need make only the following brief
observations on further matters raised by Ms Kilroy during her submissions.

423. One part of that submission was that it should have been stated on the face of the Inadmissibility
Policy that the 7-day period provided in the Notice of Intent to make representations could be extended.
One part of the Home Secretary's submission was that extension of time could be requested and, as a
matter of discretion, granted. On the facts of the various cases before us we have seen examples both of
occasions when extensions of time were sought and granted, and of occasions when such requests were
made but were refused. Clearly, it would have been preferable, purely from the perspective of practice, for
the possibility of an extension of time to be expressly mentioned somewhere in the policy. However, the
lack of such a statement is not sufficient to render the policy unlawful. Most importantly there is nothing in
the policy that prohibits an extension of time in an appropriate case; the question is whether the system
has the capacity to react appropriately to ensure fairness. In this case, the system does have such a
capacity; a point demonstrated by the extensions of time that were granted in some of the cases before us.
Further, whilst it might as we have said, have been preferable as matter of practice for something to be
said on the face of the policy, that is not in this case a condition of legality. Drafting perfection or
something close to it is not the benchmark for the legality of the policy.

424. The next matter concerns the approach to evidence when the challenge, like the Asylum Aid
challenge, is brought by an NGO, not by one or more persons directly affected by the operation of a policy.
Ms Kilroy's submission was that because the complaint was a complaint of systemic unfairness, evidence
of occasions when the system had not operated unfairly was irrelevant to the merits of her case. She
based this submission on the judgment of the Court of Appeal in R(FB) v Secretary of State for the Home
_Department [2022] QB 185. That submission rests on a misunderstanding of the issues in that case._

425. FB was a challenge to the lawfulness of the Home Secretary's guidance document “Judicial Review
_and Injunctions” which, among other things, contained provisions on the process for removing persons_
without the right to enter or remain in the United Kingdom. In broad terms, the system provided: (a) for
service of a removal notice with reasons for that decision; which (b) triggered a short notice period during
which removal could not occur; followed by (c) a removal window within which the person could be
removed at any time without further notice The Court of Appeal considered two appeals one from the


-----

Commissioner for Refugees intervening) and other case....

Upper Tribunal, the other from the Administrative Court. The Court of Appeal identified a fundamental flaw
in the policy. Once the person subject to immigration control was within the removal window he could be
removed at any time. The very short notice period (either 72 hours or 5 days, depending on the type of
case), meant that any representations that the person sought to make to prevent removal during the notice
period would not, realistically, be the subject of a decision until the removal window was running and the
person subject to immigration control was at risk of immediate removal. That, concluded the Court, was an
error on the face of the policy. The combination of the short notice period followed by the removal window
meant that there was “a real risk” that the right of access to a court would be impeded. All members of the
Court emphasised that the finding of unlawfulness rested on an inherent defect on the face of the policy.
The combination of the short time frame and the operation of the removal window inevitably created an
impediment to access to a court. Thus, the conclusion reached by the Court of Appeal rested on that
defect in the policy not, specifically, evidence of how the policy had operated in practice. In the context of
that case evidence that in some instances the policy had not operated to permit removal when
representations made remained outstanding did not address the inherent defect the court identified.

426. That conclusion, in the circumstances of that case, is no general prescription that a court must
approach a systemic challenge without reference to evidence of what happens in practice. The significance
attaching to such evidence will depend on the nature of the systemic failing alleged. It would be odd
indeed if such evidence were to be disregarded in all cases, as a matter of course, particularly since
system challenges are routinely made based on what are referred to as “case studies” – i.e. accounts by
third parties, often solicitors, of problems they say their clients have faced. If such evidence is capable of
supporting a systemic challenge, evidence of occasions when the system has worked without difficulty
must, in principle, be capable of being relevant to rebut the claim of systemic failing. All will depend on the
nature of the systemic failing alleged, and how, in light of the principle set out by the Supreme Court in R
_(A) v Secretary of State for the Home Department (above) that failing should be evaluated. At times, Ms_
Kilroy's submission appeared to be the effect that while “case study” evidence will always be capable of
supporting a systemic challenge, evidence of occasions where the system had not resulted in error was, in
all instances, irrelevant.

That is wrong. The approach in FB rests entirely on the nature of the systemic error in that case.

427. The final matter concerns the need for the present claim, brought by Asylum Aid. One striking
feature of the present litigation is that there was no argument advanced by Asylum Aid that either could not
or was not also advanced by one or more of the individual Claimants. But not only that. Following
questions raised by the court it became apparent that a large proportion of the “case study” evidence
concerned the circumstances of persons who were individual Claimants before the court, or who had
commenced claims that had been stayed pending resolution of these proceedings, or had been
discontinued for pragmatic reasons.

428. Although there may be occasions when organisations such as Asylum Aid may appropriately
advance systemic challenges relying on “case study evidence”, the present occasion is not one of them. A
large number of those who have been the subject of inadmissibility and removal decisions have
commenced proceedings. Difficult issues such as those raised in this case, will always be better decided
in claims brought by persons directly affected by the decisions taken. The facts of their cases will, to the
extent necessary, be properly established and provide a solid foundation for conclusions on the legal
issues. The “case study” approach will in our view always be second best. The circumstances of the case
studies can rarely be tested, often because the studies have been anonymised. That was a feature of
Asylum Aid's evidence in these proceedings and it was only in response to questions raised by the court
that it became apparent that many of those who were the subject of the case studies were Claimants in
other cases filed with the court.

429. In the circumstances of these proceedings, Asylum Aid's claim was unnecessary. While in the period
immediately following the Home Secretary's decisions to remove asylum claimants to Rwanda, it may have
been appropriate for Asylum Aid to file its claim, once it became apparent that claims covering the same
ground had been filed by Claimants who were the subject of those decisions it ceased to be appropriate for


-----

Commissioner for Refugees intervening) and other case....

Asylum Aid to continue to pursue this claim. The mere fact that these decisions are matters of intense
public controversy is not sufficient reason for organisations not directly affected by those decisions to
present themselves as claimants.

E.  Decision on standing

430. The Home Secretary contests the standing of three of the Claimants in CO/2032/2022:

the Public and Commercial Services Union (“the PCSU”); Detention Action; and Care4Calais. None of
[these Claimants suggests it has standing to pursue either the complaints made under the Human Rights](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
_[Act 1998 (none is a “victim” for the purposes of section 7 of that Act), or any of the complaints that are](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
specific to the facts of the cases of any of the individual Claimants. However, each contends that it does
have standing to pursue all the remaining generic complaints, including the complaint that the Home
Secretary's general approach when taking the inadmissibility and removal decisions, was procedurally
unfair. All parties made their submissions on this issue by reference to the general statements of principle
set out in the judgment of the Divisional Court in R (Good Law Project and others) v Prime Minister and
_others_ _[2022] EWHC 298 (Admin) at paragraphs 16 – 29._

431. The PCSU is a trade union recognised to represent Home Office officials working in the Third
Country Unit and the Detained Barrier Casework Team. The submission for the PCSU was that it had
“associational” standing; its members include the civil servants who take inadmissibility and removal
decisions on behalf of the Home Secretary. The PCSU submitted that its members were “directly affected”
by the Home Secretary's Rwanda policy, and/or that the requirement, as part of their day-to-day duties as
civil servants, that they take decisions on the application of the policy, had a “real impact on their working
conditions and well-being”.

432. These matters do not suffice to give the PCSU standing to challenge the decisions in issue in this
case. The typical example of associational standing is when an organisation sues on behalf of its members
who do, individually, have standing. For example, in a case where the claimant is a trade union, the
challenge might be to a policy affecting its members' terms and conditions of work: see/compare, the facts
in R v London Borough of Hammersmith and Fulham ex parte NALGO _[[1991] IRLR 249, per Nolan LJ at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W3R7-00000-00&context=1519360)_
paragraphs 25 – 28. That is not this case. The PCSU's members are not “directly affected” by the Rwanda
policy in any sense relevant for the purposes of bringing a claim for judicial review. Ordinarily, the persons
“directly affected” by the decisions of public authorities are those who are the subject of such decisions (in
these proceedings, the individual Claimants), not those such as the members of the PCSU, who take the
decisions. On any analysis, PCSU's submission on standing amounts to the submission that any person
working for a public authority has sufficient interest to challenge any decision taken by that public authority
if she had some role in taking the decision. This would provide the PCSU (or any other trade union
representing persons employed by a public authority) a roving mandate to commence judicial review
proceedings directed to any decision of which at least some of its members disapproved. The submission
was put in terms of the “well-being” of the PCSU's members, but the substance of the matter is
disagreement with the Home Secretary's policy. It would not be uncommon for those who work in the public
sector to disagree with one or more of their employer's policies; the stranger thing would be if no such
disagreement existed. However, the PCSU's members do not, by reason of their place of work or duties,
have any greater standing, in the legal sense of the words, than any other member of the public. As their
representative body, the PCSU can be no betterplaced. Furthermore, the individual claimants in
CO/2032/2022 are able to, and have, raised all the grounds of challenge that the PCSU sought to raise.
They claimed that those grounds, along with the other grounds specific to their individual cases, rendered
the decisions in their cases unlawful. Those claimants are far better placed than the PCSU to bring such a
claim. For that separate, and additional reason, we find that the PCSU does not have standing in case
CO/2032/2022: see, generally, paragraph 62 of the judgment in R (Good Law Project Limited) v Secretary
_of State for Health and Social Care_ _[2021] EWHC 346 (Admin), [2021] PTSR 1251, paragraph 62 of_ _R_
_(Jones) Commissioner of Police of the Metropolis [2019] EWHC 2957 (Admin),_

[20120] 0120] 1 WLR 519 and paragraph 28 of the judgment in the Good Law Project case.


-----

Commissioner for Refugees intervening) and other case....

433. The submission for Detention Action and Care4Calais is that each has surrogate standing – i.e., each
has sufficient interest because they represent the interests of others who are not themselves well-placed to
bring the action. In the circumstances of the present litigation, that submission is undermined by the
presence (in the same claim, CO/2032/2022) of the individual Claimants. In this instance, the Home
Secretary's inadmissibility and removal decisions were directed to a discrete group – i.e., the 47

men who were the subject of the original decisions, and who were given removal directions for Rwanda for
14 June 2022. We doubt, therefore, that the present context is one in which surrogate standing classically
arises. Compare the example given by the Divisional Court at paragraph 20 of the judgment in the Good
_Law Project case, when organisations such as the Child Poverty Action Group have challenged changes to_
the rules on social security or other benefits, when the change is of universal application. In a context such
as that, a notion of surrogate standing makes absolute sense, and is entirely consistent with the substance
and purpose of section 31(3) of the Senior Courts Act 1981. While the class of persons affected by a
decision of that type could in principle be identified, that class would be very wide, membership of the class
might ebb and flow, and the practical impact of the decision on any single member of the class might not
provide sufficient practical incentive for that person to start proceedings. The present context is very
different. Each member of the affected class is the subject of separate decisions which in part rest on the
merits of that person's own circumstances. Each member of the class stands to be significantly affected by
those decisions. There is no argument raised in this case that cannot properly be pursued by any or all of
the individual Claimants. A significant number have commenced claims for judicial review – either as
claimants in CO/2032/2022 or as a claimant in any of the other claims now before us, or stayed pending
these proceedings. We have no doubt that, on the facts of this case, where there are individual claimants
raising all the grounds of challenge that those two organisations wish to bring, along with the other grounds
specific to their individual cases, those claimants are better placed to bring this claim in the light of the case
law referred to in paragraph 432 above. For that reason, neither Detention Action nor Care4Calais has
standing to pursue the generic grounds. We do not need to deal with the question of whether they have
standing on public interest grounds as they state at paragraph 727 of their written submissions that they do
not fall within the category of public interest claimants.

434. One practical matter that Detention Action and Care4Calais pray in aid is that any claim commenced
by a person who was subject of decisions by the Home Secretary could be frustrated if the Home
Secretary either withdrew her decisions or withdrew removal directions issued consequent on such
decisions. The risk that removal directions might be withdrawn is not to the point. Such withdrawal would
affect any claim for interim relief (as was the position in this litigation – a number of the individual claimants
now parties to CO/2032/2022 were added after the Home Secretary withdrew removal directions issued in
respect of persons originally named as claimants in the case), but would not affect a claimant's ability to
challenge the Home Secretary's substantive decisions. A decision by the Home Secretary to withdraw her
substantive decisions (something which did not happen in this case, even when the 5 July 2022 decisions
were made the May and June decisions were not withdrawn) would go to the suitability of that person to
continue as a claimant – the court will often set its face against determination of complaints that, having
been overtaken by events, have become academic. But even if that is so, that would not mean that in
those circumstances, an organisation such as Detention Action or Care4Calais was a suitable claimant for
the purposes of determining those same legal issues particularly where there were, or would be likely to be
other, individual claimants better able to raise all the potential grounds of challenge.

435. Nothing that we have said should be understood as suggesting that the work of organisations such
as Detention Action or Care4Calais is anything other than important. It is also admirable that such
organisations provide practical and financial support for persons who are subject to immigration control and
wish to challenge decisions the Home Secretary has taken. Our only conclusion is that for the purposes of
these proceedings, neither organisation has the standing to pursue matters as a claimant.

F.  Disposal


-----

Commissioner for Refugees intervening) and other case....

436. All claims came before us as rolled-up hearings. We have heard full argument on them, and we grant
permission to apply for judicial review on all grounds of the claims for all Claimants, save (a) where
particular grounds in relation to particular Claimants have been stayed) and (b) where we have concluded
that Claimants lack standing to pursue claims for judicial review (i.e., the PCSU, Detention Action, and
Care4 Calais, all in CO/2032/2022).

437. The inadmissibility and removal decisions were not unlawful by reason of any of the generic grounds
of challenge or by the general claims of procedural unfairness (i.e., the matters considered at Sections B
and D of this judgment).

438. However, the way in which the Home Secretary went about the implementation of her policy in a
number of the individual cases before us, was flawed. For the reasons above, primarily in Section C of this
judgment, the following decisions (specifically identified in section C above) taken in relation to the
following individual Claimants were flawed and will be quashed:

(1) AAA (CO/2032/2022), the decisions on inadmissibility and removal, and the human rights decision;

(2) AHA (CO/2032/2022), the decisions on inadmissibility and removal;

(3) AT (CO/2032/2022), the decisions on inadmissibility and removal, and the human rights decision;

(4) AAM (CO/2032/2022), the decisions on inadmissibility and removal, and the human rights decision;

(5) NSK (CO/2032/2022), the decisions on inadmissibility and removal, and the human rights decision;

(6) HTN (CO/2104/2022), the decisions on inadmissibility and removal, and the human rights decision;

(7) RM (CO/2077/2022), the human rights decision; and

(8) AS (CO/2098/2022), the human rights decision.

To this extent (only) the claims for judicial review succeed. If the Home Secretary wishes to apply her
policy to any of these Claimants, she must first reconsider the decisions in all these cases.

Stayedxiv

**ANNEX A**

**Claim No.** **Claimant** **Date filed**


CO/2032/2022


AAA and others


8-Jun-22


CO/2072/2023 AB 10-Jun-22

CO/2077/2024 RM 10-Jun-22

CO/2080/2025 ASM 13-Jun-22

CO/2098/2026 AS 13-Jun-22


**Status**

MOM/MYM stayedi; JM stayed.
Remainder determined

Part stayedii part determined

Part stayediii part determined

Part stayediv part determined

Part stayedv part determined


CO/2104/2027 HTN 13-Jun-22 Determined

CO/2056/2028 ASYLUM AID 9-Jun-22 Determined

CO/2094/2029 SAA 13-Jun-22 Part stayedvi

CO/2095/2030 NA 13-Jun-22 Part stayedvii

CO/1371/2031 MB 19 Apr 22


-----

Commissioner for Refugees intervening) and other case....

CO/1588/2032 F 3-May-22

CO/2353/2034 BAH 1-Jul-22 Stayed by consent

CO/2541/2035 A 14-Jul-22

CO/2103/2036 AB 13-Jun-22 Stayedviii

CO/2111/2037 AND 13-Jun-22

Part stayed, part transferred to KBDix

CO/2112/2038 APY 13-Jun-22

Part stayed, part transferred to KBDx

CO/2113/2039 ADS 13-Jun-22

Part stayed, part transferred to KBDxi

CO/2125/2040 AAHR 14-Jun-22 Stayedxii

CO/2126/2041 OC 14-Jun-22 Stayedxiii

CO/2129/2042 AC 14-Jun-22

CO/2213/2043 A 20-Jun-22

CO/2197/2044 O 20-Jun-22 Application to stay

CO/2346/2045 A 1-Jul-22 Stayed by consent

CO/2351/2046 A 1-Jul-22 Application to stay

CO/2507/2022 H 12-Jul-22 Application to stay

CO/2779/2022 J 2-Aug-22 Application to stay

CO/2814/2022 M 4-Aug-22 Application to stay

CO/2880/2022 A 8-Aug-22 Application to stay

CO/2987/2022 AAX 7-Aug-22 Application to stay

CO/3025/2022 A 19-Aug-22 Application to stay

CO/3044/2022 S 19-Aug-22 Stayed by consent

i

Order 3 August 2022 at §3

ii

Order 3 August 2022 at §5

iii

Unlawful detention claim stayed: Order 3 August 2022

iv

Order 3 August 2022 at §5. Unlawful detention claim also stayed

v  Unlawful detention claim stayed: Order 3 August 2022

vi

Order 3 August 2022 at §5. Unlawful detention claim also stayed

vii

Unlawful detention claim stayed: Order 3 August 2022

viii

Order 28 June 2022

ix


-----

Commissioner for Refugees intervening) and other case....

Stay, Order 24 June 2022; transfer, Order 20 July 2022

x  Stay, Order 24 June 2022; transfer, Order 20 July 2022

xi

Stay, Order 24 June 2022; transfer, Order 20 July 2022

xii

Order 15 July 2022

xiii

Order 15 July 2022

xiv

Order 15 July 2022

**End of Document**


-----

Commissioner for Refugees intervening) and other case....

# R (on the application of AAA and others) v Secretary of State for the Home Department (United Nations High Commissioner for Refugees intervening)
 and other cases [2023] EWCA Civ 745

Court of Appeal, Civil Division

The Lord Burnett of Maldon Lord Chief Justice of England and Wales, Sir Geoffrey Vos Master of the Rolls and
Lord Justice Underhill Vice-President of the Court of Appeal (Civil Division)

28 June 2023Judgment

Raza Husain KC, Phillippa Kaufmann KC, Sam Grodzinski KC, Christopher Knight, Paul Luckhurst, Tim Johnston,
Jason Pobjoy, Emma Mockford, Anirudh Mathur, Allan Cerim, Emmeline Plews, Will Bordell, and Rayan Fakhoury
(instructed by Duncan Lewis Solicitors) for the Appellants in AAA and others and HTN (Vietnam)

Richard Drabble KC, Alasdair Mackenzie, David Sellwood, and Rosa Polaschek (instructed by Wilsons Solicitors
LLP) for the Appellant in RM (Iran)

Richard Drabble KC, Leonie Hirst and Angelina Nicolaou (instructed by Wilsons Solicitors LLP) for the Appellant in
_ASM (Iraq)_

Sonali Naik KC, Adrian Berry, Mark Symes, Eva Doerr, and Isaac Ricca-Richardson (instructed by Barnes Harrild &
Dyer) for the Appellant in AS (Iraq)

Manjit S Gill KC, Ramby de Mello, Tony Muman and Harjot Singh, solicitor advocate (instructed by Twinwood Law
Practice) for the Appellant in SAA (Sudan)

Charlotte Kilroy KC, Michelle Knorr, and Sarah Dobbie (instructed by Leigh Day) for Asylum Aid

Lord Pannick KC, Sir James Eadie KC, Neil Sheldon KC, Edward Brown KC, Mark Vinall, Jack Anderson, Sian
Reeves, Robin Hopkins, and Natasha Barnes (instructed by Government Legal Department) for the Respondent

Angus McCullough KC, Laura Dubinsky KC, David Chirico, Jennifer MacLeod, Agata Patyna, Aarushi Sahore and
Joshua Pemberton (instructed by Baker McKenzie LLP) for the United Nations High Commissioner for Refugees

**Tim Buley KC, Nikolaus Grubeck, and Julianne Kerr Morrison (instructed by Freshfields**
**Bruckhaus Deringer LLP) for Freedom from Torture (written submissions only)**

**Adam Straw KC, Catherine Meredith, Zoe Harper and Michael Spencer (instructed by Allen & Overy**
**LLP) for the United Nations Special Rapporteur on Trafficking in Persons (written submissions only)**

Hearing dates: 24 - 27 April 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**


-----

Commissioner for Refugees intervening) and other case....

This judgment was handed down in court shortly after 10.00am on Thursday 29 June 2023 and thereafter released
to the National Archives. It was expressed to be subject to minor editorial corrections. This version, which was
sent to the parties and released to the National Archives at 13:20 on Thursday 13 July 2023, incorporates various
such corrections and is intended to be final.

.............................

**TABLE OF CONTENTS**

**[1]-[119]**

**THE MASTER OF THE**
**ROLLS**

**Essential** [16]-[28]
**factual background**


**Essential legal**
**background**



[29]-[34]

Authorities            [29]-[32]


Relevant
immigration rules

**The reasoning** [35]-[52]
**of the Divisional Court**

(i) Thorough
examination and reasonable
inquiries

(ii) Adequacy
of asylum system

(iii) The Gillick
issue

(iv)
Conditions in Rwanda
generally

**The issues** [53]-[72]
The safety of
Rwanda issues

The
remaining issues



[33]-[34]

[40]-[44]

[45]-[47]

[48]

[49]-[52]

[57]-[67]

[68]-[72]


**Discussion of**
**the issues**



[73]-[118]


**Conclusions** [119]

**[120]-[455]**

**LORD JUSTICE UNDERHILL**

**Introduction** [120]


**A. Safety of**
**Rwanda**



**[121]-[302]**


The
Background Law

The Shape of
the Case

The Rwandan
Asylum System

Criticisms of
Particular Stages of the
Process



[121]-[125]

[126]-[132]

[133]-[144]

[145]-[223]

Access to the RSD Process [145]
[157]


-----

Commissioner for Refugees intervening) and other case....

Stage (1): DGIE [158]
[174]

Stage (2): Eligibility Officer [175]
[180]

Stage (3): the RSDC [181]
[206]

Stage (4): Appeal to MINEMA [207]
[210]

Stage (5): Appeal to the High Court [211]
[223]


Criticisms
Common to the System as a
Whole



[224]-[260]

Legal Assistance/Representation [224]
[240]

Interpreters [241]
[244]

Training [245]
[260]


Conclusion on [261]-[272]
the Adequacy of the
Rwandan Asylum System


Risk of
Refoulement



[273]-[286]


Article 3 Risks [287]-[292]
Other Than Refoulement

Conclusion on [293]-[295]
the Safety of Rwanda Issue


Issue 10:
_Gillick_

Issue 11:
Certification



[296]-[301]

[302]


**B. The**
**Remaining Issues**



**[303]-[457]**


Issue 12:
Breach of the Refugee
Convention

Issue 13:
Retained EU Law

Issue 14:
Circumvention of Schedule 3
to the 2004 Act

Issue 15:
Data Protection



[304]-[339]

[340]-[367]

[368]-[377]

[378]-[400]


Issue 16: [401]-[455]
Procedural Fairness

Introduction [401]
[402]

The Procedure [403]
[412]

The Grounds: Overview [413]
[416]

Ground 15: Scope of Representations [417]
[424]

Ground 16: Access to Legal Advice [425]
[430]

Ground 17: Seven Days [431]


-----

Commissioner for Refugees intervening) and other case....

Ground 18: Disclosure of Provisional
Conclusions



[445]

[446]
[450]


Ground 19: Access to Justice [451]
[453]


Ground 20: Construction of the
Immigration Rules

Conclusion on Asylum Aid's Appeal
RM's Ground on Fairness

**[458]-[527]**

**THE LORD CHIEF JUSTICE**



[454]

[455]

[456]
[457]


**The Issues on**
**the Appeal**

**Summary of**
**Conclusions**

**The Divisional**
**Court's Judgment on the**
**Article 3 and Allied Public**
**Law Issues**



[477]

[478]-[480]

[481]-[493]


**Safety of** [494]-[517]
**Rwanda: The asylum system**
**and refoulement issue**


**Safety of**
**Rwanda: conditions in**
**Rwanda**



[518]-[520]


**The** [521]-[524]
**procedural questions**

**Gillick** [525]-[526]

**Conclusion** [527]

**SIR GEOFFREY VOS, MASTER OF THE ROLLS:**

1. The Divisional Court (Lewis LJ and Swift J) decided, in essence, to reject all the generic challenges
made in these proceedings to the policy of the Secretary of State for the Home Department (SSHD) to
relocate certain asylum seekers to Rwanda. The 10 individual appellants and Asylum Aid have been given
permission to argue some 22 grounds of appeal in this court, and seek permission to argue one more. We
have been provided with thousands of pages of documents and authorities and heard 4 days of
concentrated argument.

2. Yet, at its foundation, the issue we have to decide is short. It is, at its most basic, whether the Divisional
Court was right to decide, if that is what it did decide, one fairly straightforward issue, bearing in mind the
guarantees and assurances that the Government of Rwanda had given to the UK Government. The SSHD
submits that the Divisional Court decided, in effect, that there were no substantial grounds for thinking that:
(a) Rwanda was not a safe third country, (b) there were real risks of refoulement (asylum seekers being
sent back to their home countries) or breaches of article 3 (article 3) of the European Convention on
Human Rights (ECHR), and (c) there were real risks that asylum claims would not be properly and fairly
determined in Rwanda. The question is whether that was right. There are, of course, other issues but that
is the central one. Article 3 provides that “[n]o one shall be subjected to torture or to inhuman or degrading
treatment or punishment”.

3. On 14 April 2022, the then Prime Minister announced the Migration and Economic Development
Partnership (MEDP) with Rwanda, which he said would mean that anyone entering the UK illegally might
be relocated to Rwanda. He said that “[t]he deal we have done is uncapped and Rwanda will have the


-----

Commissioner for Refugees intervening) and other case....

capacity to resettle tens of thousands of people in the years ahead”. The MEDP comprises a Memorandum
of Understanding of 13 April 2022 (MoU) and three Notes Verbales. The MoU has an initial term of 5 years.
The Notes Verbales disclosed in these proceedings provide the guarantees of the Government of Rwanda
regarding “the asylum process of transferred individuals”, and “the reception and accommodation of
transferred individuals”.

4. The MEDP was developed to deter people from risking their lives in making dangerous journeys to the
UK to claim asylum. These journeys are typically made by crossing the English Channel in small boats.
They are often facilitated by people smugglers and criminal gangs, to whom asylum seekers pay
considerable sums of money. The policy is a politically sensitive one which has attracted significant public
and media attention. Notwithstanding that position, the case must be determined on the basis of the
evidence and of accepted and familiar principles of public law. Nothing in this judgment should be
construed as supporting or opposing any political view of the issues.

5. The appellants complain that the Divisional Court adopted the wrong tests, concentrating too much on
whether the SSHD was entitled to reach the conclusions she did about the safety of Rwanda on the basis
of four assessment documents which she published on 9 May 2022. On the same day, the SSHD had
published her Inadmissibility Guidance to Home Office case workers outlining the powers available and the
procedures to be followed to declare asylum claims inadmissible and remove asylum claimants to safe
third countries. In this context, the appellants contend that the SSHD failed (a) to undertake a “thorough
examination” of “all relevant generally available information” as required by the principles explained by the
European Court of Human Rights (ECtHR) in Ilias v. Hungary (2020) 71 E.H.R.R. 6 (Ilias) at [137]-[141],
and (b) to ask herself the right question and take reasonable steps to acquaint herself with the relevant
information to enable her to answer it correctly as explained in _Secretary of State for Education and_
_Science v. Tameside Metropolitan Borough Council [1977] AC 1014 at 1064-1065 (Tameside). Specifically,_
the appellants submit that the SSHD took no or no proper account of (i) the fact that there was no
independent judiciary in Rwanda, (ii) the collapse of a similar scheme entered into between the State of
Israel and Rwanda, (iii) the Rwandan Government's misunderstanding of the meaning of refoulement, and
(iv) 15 areas of inadequacy in Rwanda's current asylum process identified by the United Nations High
Commission for Refugees (UNHCR). The appellants also contend that the Divisional Court failed properly
to apply the test adumbrated in _Soering v. United Kingdom (1989) 11 E.H.R.R. 439 (Soering) at [88] by_
asking, as it should have done, whether there were substantial grounds for believing that the asylum
seekers sent to Rwanda would face real risks of article 3 mistreatment. In doing so, they submit that the
Divisional Court failed to consider the guarantees and assurances given by the Rwandan Government in
accordance with the principles established in Othman v. United Kingdom (2012) 55 E.H.R.R. 1 (Othman) at

[186]-[189]. It failed, it is said, to assess the quality of the assurances, and whether, in the light of
Rwanda's existing practices those assurances could be relied upon, having regard to the 11 factors listed
at [189] in Othman, or equivalent factors applicable in this case.

6. The UNHCR submitted that it had issued a rare unequivocal warning that there should be no transfers
of asylum seekers to Rwanda, because of its clear view that the arrangement was incompatible with the
UK's obligations under the 1951 Convention on the Status of Refugees (the Refugee Convention). A Home
Office memorandum of 22 February 2022 recognised the UNHCR's expertise in relation to Rwanda. An 8
March 2022 Home Office email reported that the UNHCR was a critical part of assessing Rwanda's safety,
and that Rwanda depended heavily on the UNHCR for delivering its domestic asylum and refugee
processes. Yet, the UNHCR submits that it was not consulted on the final terms of the MEDP and not
involved in the formulation of the assurances given to the UK Government. The UNHCR submitted that
_MSS v. Belgium and Greece (2011) 53 EHRR 2 (MSS) at [349], and Lord Kerr in R (EM (Eritrea)) v. SSHD_

_[2014] UKSC 12, [2014] AC 1321(EM (Eritrea)) at [71]-[74], confirmed that special regard should be paid to_
the views of the UNHCR where it has special expertise and the subject matter is within its remit (see also R
_(Tabrizagh) v. SSHD_ _[[2014] EWCA Civ 1398 (Tabrizagh) at [18]-[20]). That principle applied in this case.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DG8-5KD1-F0JY-C3Y6-00000-00&context=1519360)_

7. The UNHCR's institutional conclusion was as follows:


-----

Commissioner for Refugees intervening) and other case....

I believe that Rwanda's RSD [Refugee Status Determination] process is marked by acute unfairness and
arbitrariness, some of which is structurally inbuilt; and by serious safeguard and capacity shortfalls, some
of which can be remedied only by structural changes and long-term capacity building. I believe that asylum
seekers transferred to Rwanda are at serious risk of both direct and indirect refoulement and will not have
access to fair and efficient asylum procedures, adequate standards of treatment or durable solutions, in
line with the requirements set out in international refugee law.

8. The UNHCR submitted that, unless a current evaluation of Rwanda's asylum system was irrelevant, the
Divisional Court's judgment could not stand.

9. The SSHD submitted, in effect, that that was precisely the position. She said that the MoU and the
_Notes Verbales did provide all the assurances that were required. There was no basis to doubt the good_
faith of the Rwandan Government's assurances. The Divisional Court had been right to conclude that ex
_facie_ those assurances would be sufficient to avoid any risk of a breach of article 3. The MEDP was an
entirely new arrangement. The existing systems and past bad practices were irrelevant to an evaluation of
the reliability of these new assurances. The UK and Rwandan Governments had very strong vested
interests in making the MEDP work in a way that was lawful and complied with the Refugee Convention
and with the ECHR. Rwanda was a sovereign state signatory to the Refugee Convention, the 1984 United
Nations Convention Against Torture and Other Cruel, Inhuman or Degrading Treatment or Punishment
(UNCAT) and was a member of the Commonwealth. There was no risk of refoulement where the Rwandan
Government had specifically to consent in advance to each asylum seeker being sent to Rwanda.
Moreover, the scheme would be carefully and independently monitored by the Joint Committee of the UK
and Rwandan Governments and a Monitoring Committee comprised of people independent of the two
Governments and the UNHCR itself. If things went wrong, they would come to light. It was a scheme that
had been considered with unparalleled care and thoroughness by the UK Government. The fact finding by
the Divisional Court was to be respected by this court (see _DB v. Chief Constable of Police Service of_
_Northern Ireland_ _[[2017] UKSC 7, [2017] 3 LRC 252 (DB) at [78]-[80] per Lord Kerr and R (Z) v. Hackney](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P21-1S91-DYJ0-83W7-00000-00&context=1519360)_
_LBC_ _[2020] UKSC 40, [2020] 1 WLR 4327(Hackney) per Lord Sales at [56], [67] and [74])._

10. The appellants also made a connected submission that the SSHD had unlawfully certified Rwanda as
safe for individuals under [17(c)] (paragraph 17(c)) of Part 5 of Schedule 3 to the Asylum and Immigration
(Treatment of Claimants etc.) Act 2004 (the 2004 Act). The SSHD had, it was argued, created a
presumption that Rwanda was safe in her assessment documents, and had, by certifying the asylum
seeker's claim to be clearly unfounded under [19(c)] of Part 5 of Schedule 3 to the 2004 Act, prevented
them from appealing to the First-tier Tribunal (Immigration and Asylum), circumventing the statutory
scheme. To make that certification, the SSHD had to form the opinion under [17(c)] that Rwanda was a
place where the person's life and liberty **would not be threatened by reason of his race, religion,**
nationality, membership of a particular social group or political opinion, and from which the person would
not be refouled. In the course of oral argument, the court asked whether that was a stricter test than the
one mentioned at [2] above, namely that there were no substantial grounds for thinking there were real
risks of ECHR breaches in Rwanda. I will return to that point. I note at this stage that section 94 of the
Nationality, Immigration and Asylum Act 2002 allows the SSHD also to make that certification if she
concludes under section 94(7)(b) that there is **no reason to believe that the person's rights under the**
ECHR would be breached in a third country.

11. The appellants also made four further main submissions that can be summarised as follows:
i) Violation of the Refugee Convention: The Divisional Court ought to have concluded that removal of
asylum seekers to Rwanda under the MEDP was inconsistent with article 33 of the Refugee Convention
(article 33), and/or constituted the imposition of a penalty contrary to article 31 of the Refugee Convention
(article 31) and was, therefore, a breach of section 2 of the Asylum and Immigration Appeals Act 1993 (the
1993 Act), which provides that nothing in the Immigration Rules shall lay down any practice contrary to the
Refugee Convention.


-----

Commissioner for Refugees intervening) and other case....

ii) Violation of Retained EU Asylum law: The Divisional Court ought to have concluded that articles 25
and 27 (article 27) of the Council Directive 2005/85/EC of 1 December 2005 on minimum standards in
member states for granting and withdrawing refugee status (the Procedures Directive) made the MEDP
unlawful because it required by article 27(2)(a) that there be a connection between the person seeking
asylum and the third country concerned on the basis of which it would be reasonable to send that person
there. The MEDP obviously envisaged sending to Rwanda asylum seekers with no such prior connection.
The Divisional Court had wrongly held, according to the appellants, that the Procedures Directive had
ceased to be retained EU law under section 1 and Schedule 1 to the Immigration and Social Security Coordination (EU Withdrawal) Act 2020.

iii) Data Protection: The Divisional Court ought to have decided that the SSHD's alleged breaches of the
UK General Data Protection Regulation (UK GDPR) would, if established, invalidate the SSHD's decisions
under the MEDP. This was the ground of appeal for which the appellants sought permission to appeal from
us.

iv) Procedural unfairness: The Divisional Court ought to have held that each of the three decisions taken
by the SSHD in respect of every asylum seeker was rendered unlawful by procedural unfairness. The three
decisions were (a) to treat the asylum application as inadmissible under [345A] of the Immigration Rules
([345A]); (b) to decide to remove the asylum seeker to Rwanda under [345C] of the Immigration Rules
([345C]), having decided that Rwanda was a safe third country under [345B] of the Immigration Rules
([345B]); and (c) to make a certification decision under [17(c)] to the effect that Rwanda was a safe country
for the asylum seeker. The main allegations of procedural unfairness relied upon were: (a) not allowing the
asylum seeker to make general submissions as to the safety of Rwanda, (b) not providing sufficient access
to lawyers, (c) allowing the asylum seeker only 7 days to make representations, (d) failing to provide the
asylum seeker with provisional conclusions, and (e) allowing the asylum seeker only 5 days to apply to the
court.

12. The SSHD submitted that each of these four submissions was unfounded and the Divisional Court had
been right on each of them for the reasons it gave.

13. On the crucial safety of Rwanda issues, I have determined that:

i) The Divisional Court did not universally apply the correct test to the issues relating to the safety of
Rwanda.

ii) The Divisional Court ought to have asked itself whether or not there were substantial grounds for
thinking that: (a) Rwanda was not a safe third country, (b) there were real risks of refoulement or breaches
of article 3, and (c) there were real risks that asylum claims would not be properly and fairly determined in
Rwanda.

iii) Accordingly, it falls to this court to consider the “safety of Rwanda issues” afresh. In deciding those
issues, special regard should be paid by the court to the views of the UNHCR on the grounds of its special
expertise and the fact that the subject matter is within its remit.

iv) On that basis there were substantial grounds for thinking that there were real risks that the asylum
seekers that the SSHD decided to send to Rwanda in May 2022 would be refouled or subject to breaches
of article 3, or that their asylum claims would not be properly or fairly determined in Rwanda.

v) There is, in these circumstances, no need to decide whether the SSHD breached either (a) her _Ilias_
duty to undertake a thorough examination of all relevant generally available information, or (b) her
_Tameside_ duty to ask herself the right questions and take reasonable steps to acquaint herself with the
relevant information to enable her to answer them correctly.

vi) For the same reasons as those mentioned above, the SSHD's certification under [19(c)] was unlawful,
because the asylum seekers' ECHR claims were not clearly unfounded. It was at least arguable that the
asylum seekers' article 3 rights would be infringed and that they might be refouled. They ought, therefore,


-----

Commissioner for Refugees intervening) and other case....

anyway to have been given an opportunity to raise such claims in the usual way through the First-tier
Tribunal.

14. On the other issues, I have concluded in broad terms that the Divisional Court was right for the
reasons given by Lord Justice Underhill.

15. I will now deal with the issues in the following order: essential factual background, the essential legal
background, the reasoning of the Divisional Court, the issues, the discussion of those issues, and my
conclusions.

Essential factual background

16. This summary of the factual background is a brief summary of [6]-[11], and [15]-[35] of the Divisional
Court's judgment. Reference to those paragraphs should be made for the detail.

17. The SSHD declared the claims of some 47 asylum seekers to be inadmissible in May and June 2022,
intending that they should be removed to Rwanda by charter flight on 14 June 2022. Some 32 claims for
judicial review had been issued by the time of the Divisional Court's judgment. On 10 June 2022, the
Administrative Court refused an application for an interim injunction to prevent removal. The Court of
Appeal dismissed an appeal, and the Supreme Court dismissed an application for permission to appeal.
On 14 June 2022, three Claimants made applications to the ECtHR for interim measures. NSK, RM and
HTN were granted that relief. The practical consequence was that no removals to Rwanda have yet taken
place.

18. On 5 July 2022, the SSHD re-took all the inadmissibility, removal and some ECHR claims decisions
affecting these appellants.

19. The UNHCR, as intervener, filed three witness statements of Mr Lawrence Bottinick, the High
Commissioner's Senior Legal Officer in the UK (Mr Bottinick). Both the SSHD and the Government of
Rwanda were able to respond to that evidence.

20. It was agreed below that version 6.0 of the SSHD's Inadmissibility Guidance of 9 May 2022 was the
operative policy document. The purpose pursued is to encourage “… asylum seekers to claim asylum in
the first safe country they reach and [to deter] them from making unnecessary and dangerous onward
journeys to the UK”. The policy explained in the Inadmissibility Guidance excludes claims made by
unaccompanied children, families and EU nationals. Its material part provides as follows:

If a case assessed as suitable for inadmissibility action appears to stand a greater chance of being
promptly removed if referred to Rwanda (a country with which the UK has a [MEDP]), rather than to the
country to which they have a connection, [the Third Country Unit] should consider referring the case to
Rwanda. An asylum claimant may be eligible for removal to Rwanda if their claim is inadmissible under this
policy and (a) that claimant's journey to the UK can be described as having been dangerous and (b) was
made on or after 1 January 2022. A dangerous journey is one able or likely to cause harm or injury.

21. The SSHD considers that the MoU and the Notes Verbales underpin her conclusion that Rwanda is a
safe third country for the purposes of [345B]. [2] of the MoU sets out the objectives as follows:

The objective … is to create a mechanism for the relocation of asylum seekers whose claims are not being
considered by the United Kingdom, to Rwanda, which will process their claims and settle or remove (as
appropriate) individuals after their claim is decided, in accordance with Rwanda domestic law, the Refugee
Convention, current international standards, including in accordance with international human rights law
and including the assurances given under this Arrangement.

22. The MoU provides that a person may only be transferred to Rwanda with the agreement of the
Government of Rwanda. Account will be taken of Rwanda's capacity to receive persons and the
administrative needs associated with their transfer. The UK provides the Rwandan Government with
information on the persons it proposes to transfer. If it agrees, the Rwandan Government gives “access to
its territory … in accordance with its international commitments and asylum and immigration laws”. Persons


-----

Commissioner for Refugees intervening) and other case....

transferred are to be provided with accommodation and support “… adequate to ensure [their] health,
security and wellbeing …”. Moreover, the Rwandan Government will have regard to information concerning
(and accommodate) the special needs of a person transferred as a victim of modern slavery and human
trafficking.

23. The MoU provides that the Rwandan Government will ensure that each person transferred will be
treated and each asylum claim will be processed “in accordance with the Refugee Convention, Rwandan
immigration laws and international and Rwandan standards, including under international and Rwandan
human rights law, and including but not limited to ensuring their protection from inhuman and degrading
treatment and refoulement”. Specific provisions are made in the MoU for access to interpreters, procedural
or legal assistance at every stage of their asylum claim including on appeals, and access to an
“independent and impartial due process of appeal in accordance with Rwandan laws”. The MoU makes
specific provision as to the treatment of those granted and refused asylum, including the prevention of
refoulement. Adequate support and accommodation are to be provided “until such time as their status is
regularised or they leave or are removed from Rwanda”. The obligations under the MoU will survive its
termination as regards those transferred under it.

24. The MoU provides for the Joint Committee to monitor and review the MEDP and to make non-binding
recommendations, and for the Monitoring Committee to monitor the entire relocation process, and to report
on conditions in Rwanda, the processing of asylum claims and the treatment and support provided to those
transferred.

25. As regards the financial arrangements, the UK paid £20 million to the Rwandan Government on 29
April 2022 in respect of preparations to receive the first group of asylum claimants. Also in April 2022, the
UK paid a further £120 million as an initial contribution to a fund intended to promote economic
development in Rwanda. The UK will make further payments for the costs of processing claims, to ensure
the safety and wellbeing of claimants, and for the costs for 5 years of welfare and integration for those who
stay, and for 3 years for those who do not qualify for refugee status or humanitarian protection. The Note
_Verbale concerning these financial issues has not been disclosed. Finally, the MoU makes provision for_
management and protection of personal data transferred between the governments.

26. The four assessment documents published by the SSHD on 9 May 2022 contain her assessment of
the safety of Rwanda as a safe third country for the purposes of [345B].

27. Each asylum seeker in these cases was detained upon arrival in the UK. Their English language skills
and health were assessed. They were issued with a mobile phone, and given IT, welfare and legal
representation information, including information on the free duty solicitor scheme. Each asylum seeker
made an asylum claim, attended an asylum screening interview conducted by reference to a standard
script and recorded on a standard form, a copy of which record was provided to the asylum seeker. The
Home Office National Asylum Allocations Unit suspected in each case that the asylum seeker had spent
time in a safe third country on their way to the UK, and referred their case to the Third Country Unit. That
Unit considered an inadmissibility decision under [345A] and [345B], and issued each asylum seeker with a
Notice of Intent. The Notice of Intent explained that they were being considered for removal to Rwanda,
and sought their representations within 7 days for those detained.

28. After that period expired, the Third Country Unit (in Glasgow) and the Detained Barrier Casework
Team (in Croydon) took the decisions in respect of the asylum seekers on behalf of the SSHD. They each
issued a decision letter. The first dealt with inadmissibility, removal and certification under [17(c)]. The
second dealt with ECHR claims. Removal directions also provided that, unless the asylum seeker left the
UK voluntarily, they would be removed by plane to Kigali Airport.

Essential legal background

_Authorities_

29. In Soering, the ECtHR identified, in an extradition case, the test that the court should apply where it
as remo ing a person to another state here it as alleged their article 3 rights o ld be iolated


-----

Commissioner for Refugees intervening) and other case....

_Soering is widely taken as establishing the well-known test that the court should ask itself whether there_
were substantial grounds for believing that the persons being removed would face real risks of article 3
mistreatment. The ECtHR said this at [88]:

It would hardly be compatible with the underlying values of the Convention, that 'common heritage of
political traditions, ideals, freedom and the rule of law' to which the Preamble refers, were a Contracting
State knowingly to surrender a fugitive to another State **where there were substantial grounds for**
**believing that he would be in danger of being subjected to torture, however heinous the crime**
allegedly committed. Extradition in such circumstances, while not explicitly referred to in the brief and
general wording of Article 3, would plainly be contrary to the spirit and intendment of the Article, and in the
Court's view this inherent obligation not to extradite also extends to cases in which the fugitive would be
**faced in the receiving State by a real risk of exposure to inhuman or degrading treatment or**
punishment proscribed by that Article [emphasis added].

30. In Ilias, the ECtHR explained the procedural duty of states considering the removal of asylum seekers
to third countries without considering the merits of their asylum application. The case concerned the
decision by Hungary to return to Serbia Bangladeshi asylum seekers who had arrived in Hungary from
Serbia. _Ilias has been widely understood as establishing that the removing state should undertake a_
thorough examination of all relevant generally available information before deciding whether to remove
such a person. The ECtHR said this at [137]-[141]:

137. Where a Contracting State removes asylum seekers to a third country without examining the merits of
their asylum applications, however, it is important not to lose sight of the fact that in such a situation it
cannot be known whether the persons to be expelled risk treatment contrary to art. 3 in their country of
origin or are simply economic migrants. It is only by means of a **legal procedure resulting in a legal**
**decision that a finding on this issue can be made and relied upon. In the absence of such a finding,**
removal to a third country must be preceded by **thorough examination of the question whether the**
**receiving third country's asylum procedure affords sufficient guarantees to avoid an asylum-seeker**
**being removed, directly or indirectly, to his country of origin without a proper evaluation of the risks he**
faces from the standpoint of art. 3 of the Convention. Contrary to the position of the respondent
Government, a post-factum finding that the asylum seeker did not run a risk in his or her country of origin, if
made in national or international proceedings, cannot serve to absolve the state retrospectively of the
procedural duty described above. **If it were otherwise, asylum-seekers facing deadly danger in their**
**country of origin could be lawfully and summarily removed to “unsafe” third countries. Such an**
approach would in practice render meaningless the prohibition of ill-treatment in cases of expulsion of
asylum seekers.

138. While the Court acknowledges the respondent Government's contention that there are cases of abuse
by persons who are not in need of protection in their country of origin, it considers that states can deal with
this problem without dismantling the guarantees against ill-treatment enshrined in art. 3. It suffices in that
**regard, if they opt for removal to a third safe country without examination of the asylum claims on**
**the merits, to examine thoroughly whether that country's asylum system could deal adequately**
**with those claims. In the alternative, as stated above, the authorities can also opt for dismissing**
unfounded asylum requests after examination on the merits, where no relevant risks in the country of origin
are established.

(c) Nature and content of the duty to ensure that the third country is “safe”

139. On the basis of the well-established principles underlying its case-law under art. 3 of the Convention
in relation to expulsion of asylum-seekers, **the Court considers that the above-mentioned duty**
**requires from the national authorities applying the “safe third country” concept to conduct a**
**thorough examination of the relevant conditions in the third country concerned and, in particular,**
**the accessibility and reliability of its asylum system. …**


-----

Commissioner for Refugees intervening) and other case....

140. Furthermore, a number of the principles developed in the Court's case-law regarding the assessment
of risks in the asylum-seeker's country of origin also apply, mutatis mutandis, to the national authorities'
examination of the question whether a third country from which the asylum seeker came is “safe”.

141. In particular, while it is for the persons seeking asylum to rely on and to substantiate their individual
circumstances that the national authorities cannot be aware of, those authorities must carry out of their
own motion an up-to-date assessment, notably, of the accessibility and functioning of the receiving
country's asylum system and the safeguards it affords in practice. The assessment must be conducted
primarily with reference to the facts which were known to the national authorities at the time of expulsion
but it is the duty of those authorities to seek all relevant generally available information to that effect.
**General deficiencies well documented in authoritative reports, notably of the UNHCR, Council of**
**Europe and EU bodies are in principle considered to have been known. The expelling state cannot**
**merely assume that the asylum-seeker will be treated in the receiving third country in conformity**
**with the Convention standards but, on the contrary, must first verify how the authorities of that**
**country apply their legislation on asylum in practice [emphasis added].**

31. In _Tameside at pages 1064-1065, the House of Lords established that a public body has a duty to_
carry out a sufficient inquiry prior to making its decision. Lord Diplock said at pages 1065A-B that “the
question for the court is did the Secretary of State ask himself the right question and take reasonable steps
to acquaint himself with the relevant information to enable him to answer it correctly?” (see the Divisional
Court in R (Plantagenet Alliance Ltd) v. Secretary of State for Justice _[[2014] EWHC 1662 (Admin), [2015] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G9F-G361-DYBP-M106-00000-00&context=1519360)_
_[All ER 261 at [100] and [139], and the Court of Appeal in R (CAAT) v. International Trade Secretary](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G9F-G361-DYBP-M106-00000-00&context=1519360)_ _[2019]_
_EWCA Civ 1020, [2019] 1 WLR 5765 at [35] and in R (Friends of the Earth Ltd) v Secretary of State for_
_International Trade/UK Export Finance (UKEF)_ _[2023] EWCA Civ 14 at [57])._

32. Finally, the ECtHR considered in Othman how the court should deal with assurances received from a
foreign Government as to the article 3 rights of someone considered for deportation to that foreign state.
The case concerned the intended removal of Abu Qatada to Jordan, the circumstances of which were
completely different from the present case. It is nonetheless useful to consider the guidance provided as
follows at [186]-[189] of the ECtHR's judgment:

186 … Before turning to the facts of the applicant's case, it is therefore convenient to set out the approach
the Court has taken to assurances in art. 3 expulsion cases.

187 In any examination of **whether an applicant faces a real risk of ill-treatment in the country to**
**which he is to be removed, the Court will consider both the general human-rights situation in that**
**country and the particular characteristics of the applicant. In a case where assurances have been**
provided by the receiving state, those assurances constitute a further relevant factor which the Court will
consider. **However, assurances are not in themselves sufficient to ensure adequate protection**
**against the risk of ill-treatment. There is an obligation to examine whether assurances provide, in their**
practical application, a sufficient guarantee that the applicant will be protected against the risk of illtreatment. The weight to be given to assurances from the receiving state depends, in each case, on the
circumstances prevailing at the material time.

188 In assessing the practical application of assurances and determining what weight is to be given to
them, the preliminary question is whether the general human-rights situation in the receiving state excludes
accepting any assurances whatsoever. However, it will only be in rare cases that the general situation in a
country will mean that no weight at all can be given to assurances.

189 More usually, the Court will assess first, the quality of assurances given and, second, whether,
**in light of the receiving state's practices they can be relied upon. In doing so, the Court will have**
**regard, inter alia, to the following factors: (1) whether the terms of the assurances have been disclosed**
to the Court; (2) whether the assurances are specific or are general and vague; (3) who has given the
assurances and whether that person can bind the receiving State; (4) if the assurances have been issued
by the central government of the receiving state, whether local authorities can be expected to abide by
them; (5) whether the assurances concerns treatment which is legal or illegal in the receiving state; (6)


-----

Commissioner for Refugees intervening) and other case....

whether they have been given by a Contracting State; (7) the length and strength of bilateral relations
between the sending and receiving states, including the receiving state's record in abiding by similar
assurances; (8) whether compliance with the assurances can be objectively verified through diplomatic or
other monitoring mechanisms, including providing unfettered access to the applicant's lawyers; (9) whether
there is an effective system of protection against torture in the receiving state, including whether it is willing
to co-operate with international monitoring mechanisms (including international human-rights NGOs), and
whether it is willing to investigate allegations of torture and to punish those responsible; (10) whether the
applicant has previously been ill-treated in the receiving state; and (11) whether the reliability of the
assurances has been examined by the domestic courts of the sending/Contracting State [emphasis
added].

_Relevant immigration rules_

33. The inadmissibility and removal decisions were made in the exercise of the powers in [345A] to

[345D]:

**Inadmissibility of non-EU applications for asylum**

345A. An asylum application may be treated as inadmissible and not substantively considered if the
Secretary of State determines that:

(i)  the applicant has been recognised as a refugee in a safe third country and they can still avail
themselves of that protection; or

(ii)  the applicant otherwise enjoys sufficient protection in a safe third country, including benefiting from the
principle of non-refoulement; or

(iii)  the applicant could enjoy sufficient protection in a safe third country, including benefiting from the
principle of non-refoulement because:

(a)  they have already made an application for protection to that country; or

(b)  they could have made an application for protection to that country but did not do so and there were no
exceptional circumstances preventing such an application being made, or

(c)  they have a connection to that country, such that it would be reasonable for them to go there to obtain
protection.

**Safe Third Country of Asylum**

345B. A country is a safe third country for a particular applicant, if:

(i)  the applicant's life and liberty will not be threatened on account of race, religion, nationality,
membership of a particular social group or political opinion in that country;

(ii)  the principle of non-refoulement will be respected in that country in accordance with the Refugee
Convention;

(iii)  the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman, or
degrading treatment as laid down in international law, is respected in that country; and

(iv)  the possibility exists to request refugee status and, if found to be a refugee, to receive protection in
accordance with the Refugee Convention in that country.

345C. When an application is treated as inadmissible, the Secretary of State will attempt to remove the
applicant to the safe third country in which they were previously present or to which they have a
connection, or to any other safe third country which may agree to their entry.

**Exceptions for admission of inadmissible claims to UK asylum process**

345D. When an application has been treated as inadmissible and either

(i) removal to a safe third country within a reasonable period of time is unlikely; or


-----

Commissioner for Refugees intervening) and other case....

(ii) upon consideration of a claimant's particular circumstances the Secretary of State determines that
removal to a safe third country is inappropriate the Secretary of State will admit the applicant for
consideration of the claim in the UK.

34. [17] and [19] of Part 5 of Schedule 3 the 2004 Act provide as follows:

17 This Part applies to a person who has made an asylum claim if the Secretary of State certifies that—

(a) it is proposed to remove the person to a specified State,

(b) in the Secretary of State's opinion the person is not a national or citizen of the specified State, and

(c) in the Secretary of State's opinion the specified State is a place—

(i) where the person's life and liberty will not be threatened by reason of his race, religion, nationality,
membership of a particular social group or political opinion, and

(ii) from which the person will not be sent to another State otherwise than in accordance with the Refugee
Convention.

19 Where this Part applies to a person — …

(b) he may not bring an immigration appeal from within the United Kingdom in reliance on an asylum claim
which asserts that to remove the person to the State specified under paragraph 17 would breach the
United Kingdom's obligations under the Refugee Convention,

(c) he may not bring an immigration appeal from within the United Kingdom in reliance on a human rights
claim if the Secretary of State certifies that the claim is clearly unfounded, and

(d) he may not while outside the United Kingdom bring an immigration appeal on any ground that is
inconsistent with the opinion certified under paragraph 17(c).

The reasoning of the Divisional Court

35. I should record first our thanks to the Divisional Court for producing an impressive, comprehensive and
carefully organised judgment at great speed. At [39], the Divisional Court summarised the generic issues
that it had to decide. In the light of the submission that the Divisional Court applied the wrong test to its
consideration of the safety of Rwanda, it is important to look at what it said about those issues. It described
the appellants' submission at [39(1)] as being that the SSHD's conclusion that Rwanda was a safe third
country was legally flawed. Their primary contention was that the SSHD's assessment was contrary to
article 3, based on (a) _Ilias, (b) the fact that the asylum seekers would face a real risk of article 3 ill-_
treatment in breach of the Soering principle, and (c) the fact that it was inevitable that the policy would lead
to occasional article 3 ill-treatment. Put another way, the Divisional Court described the submission as
being that the conclusion that Rwanda was a safe third country had not taken account of relevant matters,
was the result of insufficient enquiry, and rested on material errors of fact and was irrational. At [39(2)], the
Divisional Court said that it was central to the appellants' case that the asylum claims would not be
determined effectively in Rwanda, running the risk that they would be refouled. The SSHD was not entitled
to have confidence that the Rwandan Government would honour the MoU and the Notes Verbales.

36. At [41]-[42], the Divisional Court held (i) that any issue that went to the legality of decisions contained
in the SSHD's four assessments and the Inadmissibility Guidance was to be assessed as at the date of the
inadmissibility decisions, and (ii) the correct focus was on the SSHD's replacement decisions issued on 5
July 2022 rather than the earlier decisions made in May and June 2022. These decisions are not
challenged in this court.

37. At [43]-[61], the Divisional Court dealt with the question of “whether the assessment that Rwanda [was]
a safe third country [was] legally flawed”. At [43], the primary submission was described as being that the
SSHD's removal decisions under [345C] were unlawful because the conclusion that Rwanda was a safe
third country under [345B] was legally flawed. The primary submission was said to be put in different ways
on the basis that “the conclusion that Rwanda [met] the criteria at 345B”: (a) amounted to a breach of


-----

Commissioner for Refugees intervening) and other case....

article 3 for the reasons explained in Ilias, (b) rested on material errors of fact or a failure to comply with
_Tameside obligations, (c) was an irrational conclusion, and (d) was part of a policy which was unlawful in_
the sense explained in Gillick v. West Norfolk and Wisbech AHA [1986] AC 112(Gillick) in that it authorised
removals in breach of article 3. It will be observed at once that this description of the submissions places
the emphasis on the challenge to the conclusion reached by the SSHD as to the safety of Rwanda.

38. At [44], however, the Divisional Court recorded that it was also submitted that removal to Rwanda
would be in breach of article 3 “in the sense of the Soering principle because there are reasonable grounds
for believing that if a person is removed to Rwanda that will expose him to a real risk of article 3 illtreatment because of the conditions in Rwanda”. It then said, importantly, at [45] that the legal arguments
converged on two issues as follows:
i) whether the SSHD's conclusion that Rwanda met the criteria for being a “safe third country” as defined
at [345B(ii) to (iv)], was a conclusion based on sufficient evidence and thorough assessment; and

ii) whether the SSHD could lawfully reach the conclusion that the arrangements governing relocation to
Rwanda would not give rise to a real risk of refoulement or other ill-treatment contrary to article 3.

39. The Divisional Court gave its answers to these questions under four headings: (i) thorough
examination and reasonable inquiries, (ii) adequacy of asylum system, (iii) the _Gillick_ issue, and (iv)
conditions in Rwanda generally.

_(i) Thorough examination and reasonable inquiries_

40. The Divisional Court dealt first at [46]-[47] with the sources of information available to the SSHD
including the UNHCR. It then dealt with Ilias, describing it as “an example of the application of the principle
in Soering”, and gave a “relatively brief description of the Rwandan asylum procedure”. The description is
not controversial and was as follows:

Rwanda has a significant history of providing asylum to refugees fleeing local conflict. In July 2020, the
UNHCR reported that since 1990, Rwanda had maintained “an open door policy” to refugees from
neighbouring countries, and that there were nearly 149,000 refugees in Rwanda. The overwhelming
majority were from the Democratic Republic of Congo and the Republic of Burundi. Rwanda has also
supported the UNHCR “emergency transport mechanism” which, since 2019, has assisted a little over
1,000 asylum seekers to be removed from Libya to Rwanda. Once in Rwanda, their claims are processed
by the UNHCR and claimants have, to date, been resettled by the UNHCR in third countries. Mr Bottinick's
evidence was that at present, some 440 asylum claimants are in Rwanda under this scheme.

Persons who have fled to Rwanda from neighbouring countries have been permitted to remain in Rwanda
without going through any formal asylum determination process. The Rwandan system for determining
asylum claims has only been used to determine claims made by those coming from further afield. This is a
small number of cases. The UNHCR estimated that in the last 3 years there have been approximately 300
cases. Asylum claims must be registered with the Directorate General of Immigration and Emigration
(DGIE). The DGIE will interview the claimant, issue him with a residence permit and forward the case to
the Refugee Status Determination Committee (RSDC). The RSDC comprises 11 members drawn from 11
ministries and government departments. Each holds his position ex-officio; membership of the RSDC will
be only one part of the person's overall responsibilities. The RSDC determines the asylum claim. There is
a right of appeal to the Minister for the Ministry in Charge of Emergency Management, the government
department with responsibility for, among other matters, refugee affairs. There is a further appeal from the
Minister to the High Court of Rwanda. That is an appeal in the way of re-hearing.

41. The Divisional Court then summarised at [53]-[54] the appellants' submission that the Rwandan
asylum system was not adequate to prevent the risk of refoulement, derived from Mr Bottinick's evidence
as follows. The summary is controversial before us, but it is nonetheless important to recite it:

(1)  There are instances where the Rwandan authorities have refused to register claims for asylum. To the
UNHCR's knowledge there have been 5 occasions (involving claimants from Libya, Syria and Afghanistan)


-----

Commissioner for Refugees intervening) and other case....

where a person has made an asylum claim to the DGIE, but the DGIE refused to accept the claim as a
valid claim. Those claims were made at Kigali Airport in Rwanda and the asylum claimants were refused
entry to and, ultimately were removed from Rwanda. Generally, Mr Bottinick is critical of the DGIE not just
in terms of its approach to registering asylum claims but also when it comes to interviewing asylum
claimants. He says the airport cases are an indication that the DGIE discriminates against those who are
not nationals of neighbouring states and, especially, against persons from Middle Eastern countries. He
says the DGIE has on other occasions refused to interview asylum claimants. He suggests the DGIE may
discriminate against asylum claimants who are lesbian, gay, bisexual, trans-sexual or inter-sex. He says
the UNHCR is aware of two such cases. Mr Bottinick also says that when the DGIE refuses to refer a claim
to the RSDC it does not give reasons for its decision. When interviews do occur, he says no record of the
interview is provided to the asylum claimant.

(2)  Mr Bottinick also considers the process before the RSDC is inadequate. The members of the RSDC
are not expert or trained in asylum law. He gives examples of three occasions when the RSDC refused to
see the asylum claimant. When hearings have taken place, they are too short to give claimants a fair
chance to make their case, and hearings tend to lack focus because of the size of the RSDC. There are no
interpreters at RSDC hearings which significantly prejudices claimants who speak neither French nor
English. The RSDC does not allow claimants to be represented by lawyers. The RSDC does not provide
proper reasons for decisions; decisions tend to be all in a standard form that simply informs the claimant of
the outcome.

(3)  Mr Bottinick is sceptical about the value of the appeal to the Minister. He says the UNHCR is not
aware of any case where the Minister has reversed a decision of the RSDC. He also points out that legal
representatives are not available for appeals to the Minister. Ministerial decisions are also in standard form
and are not properly reasoned.

(4)  Mr Bottinick also says that the lack of reasoned decisions from the RSDC and the Minister impedes
effective use of the right of appeal to the High Court. This right of appeal was introduced in 2018. There is
no evidence that any such appeals have been filed with or heard by the High Court.

(5)  Rwandan asylum law is said to be defective. Mr Bottinick refers to a “protection gap”. He says that the
definition of “political opinion” in article 7 of Rwanda's 2014 Law on Asylum does not cover the possibility of
protection against persecution on grounds of imputed political opinion or from the risk of ill treatment by
non-state actors.

(6)  Mr Bottinick's opinion is that the Rwandan asylum system lacks the capacity and expertise necessary
to deal effectively with asylum claims. This is material in two ways. Important aspects of asylum law may
not be properly understood and properly applied. As an example, Mr Bottinick says that “it can be difficult
for decision-makers to understand” that asylum claims should not be denied on the premise that the
claimant could hide a characteristic protected under the Refugee Convention, such as his political opinion
or sexual orientation. Further, the Rwandan system will not be able to cope with the volume of claims
generated by the MEDP. Mr Bottinick comments that claimants in the Rwandan asylum system have
insufficient access to legal assistance and interpretation services are not available. He also raises a
concern that details of asylum claimants and their claims may not have been treated as confidential and
information may have been passed to the asylum claimants' countries of origin.

42. The Divisional Court then recorded at [55]-[56] that the SSHD and the Rwandan Government disputed
much of Mr Bottinick's evidence, noting only that: (i) the UNHCR had described the 2014 Law relating to
Refugees in its July 2020 _Universal Periodic Review as “fully compliant with international standards”, (ii)_
article 7 of the 2014 Law exactly followed the language of article 1 of the Refugee Convention, and (iii) as
to whether Rwandan authorities had maintained the confidentiality of asylum seekers, it was satisfied that
the RSDC had sought information from Rwandan embassies abroad, rather than countries of origin.

43. The Divisional Court went on to record at [57]-[58] that the SSHD's primary reliance was on the
detailed contents and assurances in the MoU and the Notes Verbales (summarised at [21]-[25] above and
in [18]-[27] of the Divisional Court) Those together with the steps she had taken to investigate the matters


-----

Commissioner for Refugees intervening) and other case....

in the assessment documents, were sufficient to satisfy her Ilias and Tameside duties, “and permitted her
rationally to conclude that Rwanda does meet the criteria at [345B(ii) to (iv)] to be a safe third country”.

44. At [59]-[60], the Divisional Court concluded that the SSHD had complied with her Ilias obligations. The
assessment documents were a thorough examination of all relevant generally available information,
including that emanating from the UNHCR. At [61], the Divisional Court concluded that the SSHD had
complied with her Tameside obligations.

_(ii) Adequacy of asylum system_

45. The Divisional Court described the next question at [62] as being “whether the [SSHD] was entitled to
conclude that there were sufficient guarantees” to ensure proper determination of asylum claims, the
absence of a risk of refoulement, and that Rwanda was a safe third country within [345B(ii)-(iv)]. That, it
said, raised “the question of whether she was entitled” to rely on the assurances provided by the Rwandan
Government.

46. The Divisional Court began by noting that, on their face, the assurances addressed all the UNHCR's
significant concerns. It then dealt with Othman, noting that the ECtHR's list of criteria at [189] was intended
to be neither prescriptive nor exhaustive. Rather, when the risk of article 3 ill-treatment was in issue, “the
court's approach must be rigorous and pragmatic notwithstanding that ultimately it is an assessment to be
undertaken recognising that the court must afford weight to the [SSHD's] evaluation of the matter. That
approach will rest on a recognition of the expertise that resides in the executive to evaluate the worth of
promises made by a friendly foreign state”.

47. The Divisional Court then said at [64] that it had concluded that the SSHD “was entitled to rely on the
assurances contained in the MoU and _Notes Verbales” for the reasons given at [64]-[71], which I can_
summarise as follows:

i) The UK and Rwanda had a well-established and long-standing relationship, as explained by Mr Simon
Mustard, the Director, Africa (East and Central) at the Foreign, Commonwealth and Development Office.
The development partnership was suspended by the UK in 2012 in response to Rwanda's involvement in
the M23 Rebellion in the Democratic Republic of Congo, and further reviewed in 2014 in response to the
assassination in South Africa of a Rwandan dissident. The Rwandan Government knew that the UK
placed importance on its compliance in good faith with the terms on which the relationship was conducted.

ii) The terms of the MoU and Notes Verbales reflected Rwanda's obligations as a signatory to the Refugee
Convention, and were specific and detailed.

iii) Whilst it was fair to say that (a) only a small number of claims had, thus far, been handled by the
Rwandan asylum system, and (b) it would take time and resources to develop its capacity, significant
resources were to be provided under the MEDP, the Rwandan Government could control the flow of
asylum seekers and there were monitoring mechanisms. The Divisional Court concluded at [65] that there
was, for now at least, no reason to believe that they would not prove effective. Rwanda had a financial
incentive to comply.

iv) After significant contacts and visits, HM Government was satisfied that Rwanda would honour its
obligations under the MEDP. The Divisional Court considered that it “could go behind this opinion only if
there were compelling evidence to the contrary”, which there was not.

v) The Divisional Court did not consider that the UNHCR's evidence about the experience of the
Israel/Rwanda agreement in 2013 was critical for its purposes. Israel offered asylum seekers a choice
between detention in Israel or removal to Rwanda together with $3,500 and the opportunity to claim asylum
there. The UNHCR said they were not provided with support and many soon left Rwanda, and some were
sent to Uganda. The UK Government had not investigated the Israel/Rwanda scheme or the way it had
worked. It had been legally permissible for the UK Government to have assessed the MEDP on its own
terms and without comparing it to the Israel/Rwanda scheme.


-----

Commissioner for Refugees intervening) and other case....

vi) The UNHCR's opinion that, in the light of the history of refoulement and of defects in its asylum system,
Rwanda could not be relied on to comply with its obligations had come late in submissions and was not in
Mr Bottinick's statements. That opinion did not sit easily with the UNHCR's previously published views, for
example in the July 2020 Universal Periodic Review. But anyway, the question that the Divisional Court
said it had to address at [70] was “whether, notwithstanding the opinion [of] the UNHCR, the [SSHD] was
entitled to hold the contrary opinion”.

vii) The authorities showed that no special weight was to be accorded to the UNHCR's evidence (R (HF
_(Iraq)) v. SSHD_ _[2013] EWCA Civ 1276, [2014] 1 WLR 1329(HF (Iraq)) at [42]-[47] per Elias LJ, and R (AS_
_(Afghanistan)) v. SSHD_ _[[2021] EWCA Civ 195 at [17]-[23] per Davis LJ).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:621K-TH23-GXFD-83SK-00000-00&context=1519360)_

viii) The conclusion that Rwanda would act in accordance with the terms of the MEDP rested on 25 years
of bilateral governmental relations and months of negotiation:

We must consider it together with all the evidence before us and decide whether, on the totality of that
evidence, the [SSHD's] opinion is undermined to the extent it can be said to be legally flawed. For the
reasons we have already given, the [SSHD] did not act unlawfully when reaching the conclusion that the
assurances provided by Rwanda … could be relied on. That being so, the conclusion that, for the purposes
of the criteria at [345B(ii) to (iv)], Rwanda is a safe third country, was neither irrational, nor a breach of
article 3 of the ECHR in the sense explained in Ilias.

_(iii) The Gillick Issue_

48. The Divisional Court relied on R (A) v. SSHD _[2021] UKSC 37, [2021] 1 WLR 3931for the proposition_
that the relevant question was whether the Inadmissibility Guidance positively authorised or approved
unlawful conduct. It did not, because the SSHD could lawfully conclude that Rwanda was a safe third
country and that asylum claims made in Rwanda would be effectively determined.

_(iv) Conditions in Rwanda generally_

49. The Divisional Court said at [73] that it would consider “the wider _Soering submission, that persons_
removed to Rwanda under the terms of the MEDP [were] exposed to a real risk of article 3 ill-treatment …
by reason of conditions in Rwanda, generally”. It dealt with the arguments that the Rwandan authorities
were intolerant of criticism, and that there might be an extreme response to criticism of the asylum seekers'
conditions or treatment, or to opposing political opinion.

50. The Divisional Court did not think that any direct inference could be drawn from the events at Kiziba
refugee camp in 2018, where protesters were killed, because the circumstances were unlikely to be
repeated for persons transferred under the MEDP, and the Rwandan authorities would abide by the terms
of the MEDP. There was no evidence that any individual appellant held political opinions opposed to the
Rwandan Government. If they did, that would be considered under [345B(i)].

51. At [77], the Divisional Court said that there was no force at all in the submission that there might be a
breach of article 15 of the Refugee Convention regarding rights of association. The appellants' reliance on
various facts as to the repressive nature of the Rwandan Government was speculative, when the terms of
the MEDP had been agreed and could be expected to be complied with. This overbore evidence that: (i)
opportunities for political opposition in Rwanda were very limited and closely regulated, (ii) there were
restrictions on the right of peaceful assembly, freedom of the press and freedom of speech, (iii) from a US
State Department report of 2020, political opponents have been detained in “unofficial” detention centres
and that persons so detained have been subjected to torture and article 3 ill-treatment short of torture, and
(iv) prisons in Rwanda are over-crowded and the conditions are very poor. The terms of the MEDP meant
that there was no real risk of these things affecting the individuals sent to Rwanda under the partnership.

52. I refer to the judgment of Underhill LJ for a summary of the Divisional Court's conclusions on the four
further submissions identified at [11] above.

The issues


-----

Commissioner for Refugees intervening) and other case....

53. It was common ground between the parties to the appeal that the central issue as to the safety of
Rwanda was whether, bearing in mind the guarantees and assurances that the Government of Rwanda
had given to the UK Government, there were no substantial grounds for thinking that: (a) Rwanda was not
a safe third country, (b) there were real risks of refoulement or breaches of article 3, and (c) there were real
risks that asylum claims would not be properly and fairly determined in Rwanda.

54. Before I answer that question, however, it is necessary to decide whether the Divisional Court actually
determined that question or a different one. On one analysis, the Divisional Court seems, from some of the
language it used, to have asked itself whether the SSHD was entitled to accept the assurances from the
Rwandan Government or was entitled to conclude on the evidence that there were no article 3 risks for
asylum seekers sent to Rwanda.

55. Accordingly, in my judgment, the first issue for this court is whether the Divisional Court asked itself
the correct question as to the safety of Rwanda. If it did, as the SSHD submits it did, this court would only
be entitled to interfere if it made some other error of law (see DB and Hackney referred to at [9] above).

56. I propose therefore to identify the following issues in two parts: (i) as to the safety of Rwanda and (ii)
as to the remaining issues.

_The safety of Rwanda issues_

57. Issue 1: Whether the Divisional Court addressed the right question as to the safety of Rwanda.

58. Issue 2: Whether the Divisional Court was right to decide at [66] that it could only go behind the
SSHD's opinion that Rwanda would honour its obligations if there were compelling evidence to the
contrary. If not, how should the court evaluate the reliability of guarantees and assurances given by one
sovereign government to another?

59. Issue 3: Whether the Divisional Court was right to decide at [67]-[71] and [73]-[74] that (a) the
evidence of the UNHCR generally, (b) what occurred when Israel and Rwanda made a similar agreement
in 2013, (c) what occurred at the Kiziba refugee camp in 2018, and (d) Rwanda's history of refoulement
and of defects in its asylum system, did not undermine the SSHD's opinion that Rwanda would honour its
obligations.

60. Issue 4: Whether the Divisional Court was right to conclude at [73]-[77] that there was no real risk that
the response of the Rwandan authorities to hostile political opinions expressed by asylum seekers in the
future might subject them to article 3 ill-treatment?

61. Issue 5: Bearing in mind the correct test, whether the Divisional Court was right to decide at [64] that
the SSHD was entitled to rely on the assurances contained in the MoU and Notes Verbales.

62. Issue 6: Whether there were in fact substantial grounds for thinking, bearing in mind the guarantees
and assurances, that (a) Rwanda was not a safe third country, (b) there were real risks of refoulement or
article 3 breaches, and (c) there were real risks that asylum claims would not be properly determined.

63. Issue 7: Whether the Divisional Court was right to conclude at [71] that the SSHD's decision that, for
the purposes of the criteria at [345B(ii) to (iv)], Rwanda was a safe third country, was neither irrational, nor
a breach of article 3.

64. Issue 8: Whether the Divisional Court was right to accept at [59] that the SSHD complied with the
obligations identified in _Ilias, namely to undertake a “thorough examination” of “all relevant generally_
available information”.

65. Issue 9: Whether the Divisional Court was right to accept at [61] that the SSHD complied with her
_Tameside duty to ask herself the right question and take reasonable steps to acquaint herself with the_
relevant information to enable her to answer it correctly.

66. Issue 10: Whether the Divisional Court was right at [72] to decide that the Inadmissibility Policy,
including the possibility of removal to a safe third country, was not Gillick unlawful.


-----

Commissioner for Refugees intervening) and other case....

67. Issue 11: Whether the SSHD's certification under [17(c)] was unlawful, because the asylum seekers'
ECHR claims were not clearly unfounded under [19(c)].

_The remaining issues_

68. Issue 12: Whether the Divisional Court ought to have concluded that removal of asylum seekers to
Rwanda under the MEDP was inconsistent with article 33 and/or constituted the imposition of a penalty
contrary to article 31 and was, therefore, a breach of section 2 of the 1993 Act.

69. Issue 13: Whether the Divisional Court ought to have concluded that articles 25 and 27 of the
Procedures Directive made the MEDP unlawful because they were still retained EU law.

70. Issue 14: Whether the Divisional Court ought to have decided that the SSHD had created a
presumption that Rwanda was safe in her assessment documents, thereby circumventing the statutory
scheme under Schedule 3 to the 2004 Act.

71. Issue 15: Whether the Divisional Court ought to have decided that the SSHD's alleged breaches of the
UK GDPR would, if established, invalidate the SSHD's decisions under the MEDP.

72. Issue 16: Whether the Divisional Court ought to have decided that the decisions to treat the asylum
application as inadmissible under [345A], to remove the asylum seeker to Rwanda under [345C] (having
decided that Rwanda was a safe third country under [345B]), and to make a certification decision under

[17(c)] to the effect that Rwanda was a safe country for the asylum seeker, were rendered unlawful by
procedural unfairness.

Discussion of the issues

Issue 1: Did the Divisional Court address the right question as to the safety of Rwanda?

73. It was submitted by the SSHD that it would be remarkable if such an experienced Divisional Court had,
in fact, addressed the wrong question. It is also clear from the material parts of the Divisional Court's
judgment that it understood that the _Soering test required the court to decide whether there were_
substantial grounds for believing that the asylum seekers sent to Rwanda would face real risks of article 3
mistreatment (see [39(1)], [44] and [73]). The issue is not, in my judgment, whether we might think that the
Divisional Court understood the test it had to apply, but whether an objective reading of its judgment shows
that it did.

74. Moreover, in considering the process adopted by the Divisional Court, I bear closely in mind the
SSHD's powerful submission that the Divisional Court had itself said, when it refused permission to appeal,
that the ground of appeal was “based on a misreading of the judgment and a reference to one sentence
not read in context”. The point that it and the SSHD made was that one of the two central questions posed
by the Divisional Court at [45] was whether the SSHD could lawfully reach the conclusion that the
arrangements governing relocation to Rwanda would not give rise to a real risk of refoulement or other
article 3 ill-treatment. The Divisional Court said in its permission judgment, and the SSHD now submits,
that the SSHD could only lawfully do that if there would be no risk of refoulement, and that that was the
issue the court then considered at [46]-[71].

75. On analysis, however, it seems to me that the Divisional Court only considered the _Soering_ test in
relation to conditions in Rwanda generally at [73]-[77]. In relation to other matters, such as the asylum
system in Rwanda and the likelihood of the Rwandan Government's assurances being realised, it asked
itself whether the SSHD had been entitled to reach the conclusions she did. It is obvious, I think, that the
question of whether the SSHD was entitled (within a margin of appreciation) to reach a particular
conclusion is a different question from whether the court assesses that there were in fact substantial
grounds for thinking there was a real risk of article 3 mistreatment.

76. It is also not appropriate to express the Soering question as being whether the SSHD could lawfully
reach the conclusion that there was a real risk of article 3 mistreatment, even if it is true that she could only
lawfully reach that conclusion if she assessed there was no such real risk The difference is between the


-----

Commissioner for Refugees intervening) and other case....

court's assessment of the SSHD's decision (which is a normal judicial review question) and the _Soering_
question, which requires the court to reach its own conclusion.

77. I can explain my reasoning as to the detail by reference to the text of the Divisional Court's judgment,
which I have already summarised at [35]-[51] above:

i) It described the appellants' primary contention at [39(1)] as being that the SSHD's assessment was
contrary to article 3, based on Ilias and Soering. The problem was that the Soering submission was, in fact,
that the court should decide whether there were substantial grounds for believing that asylum seekers sent
to Rwanda would face real risks of article 3 mistreatment. It was not just that the SSHD's assessment fell
foul of article 3.

ii) At [39(2)], the Divisional Court again explained that the appellants' case was that the SSHD was not
entitled to have confidence that asylum claims would not be determined effectively in Rwanda.

iii) At [43], the primary submission was described as being that the SSHD's conclusion that Rwanda was a
safe third country was legally flawed. As I observed at [37] above, the description of the submissions
placed emphasis on the challenge to the conclusions reached by the SSHD.

iv) At [44], the Divisional Court recorded the correct _Soering_ test, but then said at [45] that all the legal
arguments converged on two issues. Those two issues concentrated exclusively on the **SSHD's**
**conclusions that (i) Rwanda met the criteria for being a safe third country, and (ii) the arrangements**
governing relocation to Rwanda would not give rise to a real risk of refoulement or other article 3 illtreatment. I have already dealt at [74]-[75] with the reasons why it is not applying the Soering test to ask
whether the SSHD could lawfully have reached the conclusion she did.

v) It may be that the way the Divisional Court divided up its treatment of the issues at [45] did not help,
because it concentrated in the first section on the procedural questions raised by _Ilias_ as to whether the
SSHD had made a thorough examination, rather than on the substantive question of whether there were
substantial grounds for believing that asylum seekers sent to Rwanda would face real risks of article 3
mistreatment.

vi) The Divisional Court's conclusion at [57]-[59] was that the SSHD's reliance on the assurances and the
steps taken to investigate the matters in the assessment documents were sufficient to satisfy her Ilias and
_Tameside duties. It was that which “permitted [the SSHD] rationally to conclude that Rwanda does meet_
the criteria at [345B(ii) to (iv)] to be a safe third country”. That was a permissible answer to the Ilias and
_Tameside questions (which I consider separately later), but not to the Soering question._

vii) At [62], the Divisional Court asked whether the SSHD was entitled to conclude that there were
sufficient guarantees to ensure proper determination of asylum claims, the absence of a risk of
refoulement, and that Rwanda was a safe third country. The approach to reliance on assurances (which I
deal with below) was a separate question from the question of whether there were substantial grounds for
believing that asylum seekers sent to Rwanda would face real risks of article 3 mistreatment.

viii) At [64], the Divisional Court concluded that the SSHD had been entitled to rely on the assurances
contained in the MoU and Notes Verbales. That may have been the correct question as to assurances (as
to which see below) but did not, in itself, answer the Soering question as to the adequacy of the asylum
system (which was the section of the judgment in which it appeared).

ix) When it came to consider Soering at [73], the Divisional Court stated the question correctly as being
whether persons removed to Rwanda under the terms of the MEDP were exposed to a real risk of article 3
ill-treatment, but did so only in relation to conditions in Rwanda generally. It also answered the correct
question when it concluded at [77] “[g]iven that the person concerned would have been transferred under
the terms of the MEDP that possibility [the risk of article 3 mistreatment] is not a real risk”.

78. Accordingly, I conclude that as to the asylum system and everything except the general situation in
Rwanda at [73]-[77], the Divisional Court did not ask the correct Soering question, namely whether there
were substantial grounds for thinking that asylum seekers sent to Rwanda under the MEDP wouldface a


-----

Commissioner for Refugees intervening) and other case....

real risk of article 3 mistreatment. I note at this stage that I have reached the same substantive conclusion
as Underhill LJ at [129] of his judgment on this point.

79. This conclusion means that this court must look again at the Soering question. Whilst proper respect
must be given to [73]-[77], the question is not a compartmentalised one. Accordingly, this court must, as it
seems to me, look at the situation in Rwanda for asylum seekers sent there in the round, against the
backdrop, of course, of the governmental assurances received and the terms of the MEDP itself. I turn then
to deal with the approach that the court should adopt to such assurances.

Issue 2: Was the Divisional Court right to decide at [66] that it could only go behind the SSHD's opinion
that Rwanda would honour its obligations if there were compelling evidence to the contrary? If not, how should the
court evaluate the reliability of guarantees and assurances given by one sovereign government to another?

80. I have already summarised the approach that the Divisional Court adopted to these questions at [45]
[47] above. Since the court is going to have to consider the _Soering question for itself, it may not be_
necessary to deal with this issue at length. The approach that the court must adopt towards assurances is
set out in detail in the passage I have already cited at [32] above from Othman. In summary, the ECtHR
made clear that whilst “assurances are not in themselves sufficient to ensure adequate protection against
the risk of ill-treatment … [t]here is an obligation to examine whether assurances provide, in their practical
application, a sufficient guarantee”. It is critical to note, in my opinion, that the ECtHR emphasised that
“[t]he weight to be given to assurances from the receiving state depends, in each case, on the
circumstances prevailing at the material time”. It will, as the ECtHR also said, “only be in rare cases that
the general situation in a country will mean that no weight at all can be given to assurances”. This, in my
judgment, is one of the more usual cases referred to by the ECtHR where the court should “assess first,
the quality of assurances given and, second, whether, in light of the receiving state's practices they can be
relied upon”.

81. I do not find any great assistance from all of the 11 factors listed out in _Othman and cited at [32]_
above. As the SSHD submitted and the Divisional Court said the factors were neither exhaustive nor
prescriptive. Moreover they were directed specifically to the unusual circumstances of Othman, which are
different to those in this case. That being said, some of the factors, particularly 7-11, have been useful to
consider, by analogy with the present case, as a form of cross-check with my assessment.

82. It is, however, important, as the SSHD submitted, for the court to bear closely in mind the injunction of
Lord Bingham in R v. SSHD ex p Yogathas [2002] UKHL 36, [2003] 1 AC 920 at [9] where he said “The
first [important consideration] is that the Home Secretary and the courts should not readily infer that a
friendly sovereign state which is party to the Geneva Convention will not perform the obligations it has
solemnly undertaken”.

83. Considering that this court is deciding the Soering question afresh, it is not strictly necessary for us to
consider whether the Divisional Court was right to decide at [66] that it could only go behind the SSHD's
opinion that Rwanda would honour its obligations if there were compelling evidence to the contrary: we
have taken into account all the relevant material in reaching our judgments. Since the Divisional Court was
right to regard the UK Government's evaluation of the reliability of assurances as an important factor, it
would certainly have needed clear evidence to “go behind” that opinion. The UK Government has, of
course, huge experience of diplomatic relations with the Government of Rwanda. I will, in the light of my
earlier conclusions, however, have to “assess first, the quality of assurances given and, second, whether,
in light of the receiving state's practices they can be relied upon” (Othman at [189]). In the first stage of that
process, due weight must be given to the UK Government's view of the diplomatic assurances it was
receiving.

84. In this case, it is not suggested that the Rwandan Government's detailed guarantees and assurances,
contained in the MEDP, were not given in good faith. In those circumstances, it can be assumed that the
Rwandan Government intended to comply with them. The question is only whether, in the light of the
events on the ground, it was or was not likely that the assurances would be complied with. Put another


-----

Commissioner for Refugees intervening) and other case....

way, that is the heart of the _Soering question: assuming that the UK Government had received detailed_
and fulsome guarantees and assurances given in good faith by a foreign sovereign Government with whom
relations were long-standing and friendly, were there substantial grounds for thinking there was a real risk
that asylum seekers would face article 3 ill-treatment?

Issue 3: Was the Divisional Court right to decide at [67]-[71] and [73]-[74] that (a) the evidence of the
UNHCR generally, (b) what occurred when Israel and Rwanda made a similar agreement in 2013, (c) what
occurred at the Kiziba refugee camp in 2018, and (d) Rwanda's history of refoulement and of defects in its asylum
system, did not undermine the SSHD's opinion that Rwanda would honour its obligations?

85. In many ways, this question encapsulates the core of the appeal. I shall deal first with the question of
what weight the court should give to evidence from the UNHCR in answering the _Soering question. The_
SSHD submits that the Divisional Court was right to say at [71] that the UNHCR's opinion as expressed in
Mr Bottinick's statements and on instructions carried no overriding or pre-eminent weight.

86. I shall consider each of the main authorities that has been referred to in chronological order:

i) First, _MSS_ (2011) concerned an asylum seeker who had entered the EU through Greece and then
applied for asylum in Belgium. It dealt with the balance between the generally known situation in Greece
and the approach to assurances given as to the Greek asylum system (see [H32] and [352]-[354] and

[358]). At [347]-[349], the ECtHR attached “critical importance” to the UNHCR's opinion, which contained
an unequivocal plea for the suspension of transfers to Greece. It said that the reports and materials, based
on field surveys, all agreed as to the practical difficulties involved in the application of the Dublin system in
Greece, the deficiencies of the asylum procedure and the practice of direct or indirect refoulement. The
materials were authored by the UNHCR and the Council of Europe's Commissioner for Human Rights, and
international non-governmental organisations.

ii) In EM (Eritrea) (2014), the Supreme Court explained the approach to evidence from the UNHCR in the
context of the risks of returning asylum seekers to Italy. At [71]-[74], Lord Kerr (with whom the other
members of the court agreed) approved the statement of Sir Stephen Sedley at [41] in the Court of Appeal
recognising that “particular importance should attach to the views of UNHCR”. At [74], in the circumstances
of that case, Lord Kerr explained that “[w]hile, because of their more muted contents, [the UNHCR's reports
did] not partake of the “pre-eminent and possibly decisive” quality of the reports on Greece, they
nevertheless contain useful information which the court will wish to judiciously consider. … The UNHCR
material should form part of the overall examination of the particular circumstances of each of the
appellant's cases, no more and no less”.

iii) In _Tabrizagh (2014), Underhill LJ explained at [20] that in_ _EM (Eritrea) Lord Kerr had approved_
passages specifically asserting the legitimacy of paying “special regard both to the facts which the High
Commissioner reports and to the value judgments he arrives at within his remit”.

iv) In _HF (Iraq) (2014) at [42]-[47], Elias LJ rejected the submission that the court was bound by the_
considered guidance issued by the UNHCR unless it could point to flaws in the analysis or there was fresh
evidence providing a proper basis for departing from that guidance. He dealt in detail with the previous
judgments I have mentioned concluding that “the authorities which demonstrate the considerable respect
which the courts afford to UNHCR material are entirely consistent with the conventional view that questions
of weight are for the court”.

v) In AS (Afghanistan) (2021) at [17]-[23], Davis LJ reinforced, in effect, the summary of the position in HF
_(Iraq)._

87. In my view, these authorities demonstrate that particular importance should be attached to the
evidence and opinions from the UNHCR, even though that evidence is not necessarily decisive nor preeminent. It is obvious that the UNHCR's evidence will be of greater weight when it relates to matters within
its particular remit or where it has special expertise in the subject matter.


-----

Commissioner for Refugees intervening) and other case....

88. The Divisional Court said at [71] that the UNHCR's opinion carried no overriding weight and had to be
considered together with all the other evidence to decide whether, on the totality of that evidence, the
SSHD's opinion was undermined to the extent it can be said to be legally flawed. In my judgment, this view
was in error insofar as the Soering test was concerned, since the focus there was not on any legal flaws in
the SSHD's decision, but on whether, on the basis of all available evidence, there were substantial grounds
for thinking that asylum seekers would face real risks of article 3 ill-treatment in Rwanda. As I have
explained, the two things are not the same.

89. Against that background, I turn to the question of whether (a) the evidence of the UNHCR, (b) what
occurred under the Israel/Rwanda agreement, (c) what occurred at the Kiziba refugee camp in 2018, and
(d) Rwanda's history of refoulement and of defects in its asylum system, undermined the UK Government's
good faith opinion that Rwanda would honour its obligations.

90. The SSHD submitted to us, in effect, that, in the light of the detailed guarantees and assurances in the
MEDP and the UK's longstanding relationship with Rwanda and its financial and other incentives to
perform on its obligations, what happened in the past was of limited, if any, real significance. This was a
key submission, because the UNHCR's evidence was all directed to what had happened in the past and
what was happening at the current time. The SSHD said that a predictive evaluation was needed, and that
in such an exercise, it was not significant that things had been less than ideal in the past.

91. I do not accept that the past and the present can either be ignored or side-lined as the SSHD
suggests. Of course, a predictive evaluation is required, and of course great weight will be given to the
guarantees and assurances of the Rwandan Government. But the likelihood of promises being performed
must, anyway in part, be judged by reference to what has happened in the past and the capacity and
capability of the entity making the promises to keep them. The SSHD acknowledges, in effect, that the
Rwandan asylum system has some way to go if it is to perform according to the MoU and the _Notes_
_Verbales. But she submits that its capacity can and will be built and that Rwanda will not accept more_
asylum seekers than it can handle in strict accordance with the MEDP.

92. The balancing exercise that the court needs to undertake in making the Soering assessment I have
described is multi-factorial and complex. I confess to having vacillated within the decision-making process.
Ultimately, however, I have concluded that there were substantial grounds for thinking that asylum seekers
sent to Rwanda under the MEDP, as at the date of the SSHD's decision-making in these cases in July
2022, faced real risks of article 3 mistreatment. That is the consequence of the historical record described
by the UNHCR, the significant concerns of the UNHCR itself, and the factual realities of the current asylum
process in Rwanda. In practice, Rwanda can only deliver on its good faith assurances if it has control
mechanisms and systems in place to enable it to do so. Both history and the current situation demonstrate
that those mechanisms have not yet been delivered. They may in the future be delivered but they are not,
on the evidence, there now. I have read Underhill LJ's impressive and comprehensive judgment on these
points and broadly agree with it. As it seems to me, it supports the conclusions I have reached.

93. In identifying some of the most important features of the evidence in the following paragraphs, I should
not be taken as having excluded any parts of the massive body of evidence from my evaluation. It is, as I
have said, a multi-factorial exercise giving due weight to the Rwandan Government's assurances, coming
as they do from a party to Refugee Convention, the SSHD's opinion that the assurances will be realised,
and the evidence from other quarters, notably the UNHCR.

94. So far as the UNHCR is concerned, it is not disputed that it was entrusted in 1950 by the UN with the
mandate to supervise the application of the Refugee Convention. The UNHCR has been present in
Rwanda since 1993 and had at the time of its evidence 332 staff there. It plays no official role in Rwanda's
asylum system, and has been denied observer status at RSDC sessions. It does, however, fund and train
non-governmental organisations working with the Rwandan asylum system. As the appellants submitted, a
Home Office memorandum of 22 February 2022 recognised the UNHCR's expertise in relation to Rwanda,
and an 8 March 2022 Home Office email said that the UNHCR was a critical part of assessing Rwanda's
safety.


-----

Commissioner for Refugees intervening) and other case....

95. The UNHCR's evidence was that Rwanda's asylum process is “marked by acute arbitrariness and
unfairness, some of which is structurally inbuilt, and by serious safeguard and capacity shortfalls, some of
which can be remedied only by structural changes and long-term capacity building”. The DGIE plays the
role of gatekeeper to the entire system. Although the DGIE is not authorised in law to reject asylum claims,
and despite Rwandan Government denials, it summarily rejected without reasons 8% of the 319 asylum
claims of which the UNHCR was aware between 2020 and June 2022. There are serious deficiencies in
the rights of an asylum seeker to be heard after a perfunctory 20-30 minute interview with the DGIE, from
which lawyers and representatives are excluded. The process at all levels, before the DGIE, the RSDC and
the Minister, is marked by an absence of representation, interpretation and written reasons. Where reasons
are provided, they are often perfunctory and inadequate: the Court was shown evidence of RSDC decision
letters, including several issued after the conclusion of the MEDP, which rejected asylum claims either
without reasons, or with very slim reasons. For example, a standard response from the RSDC was that
“Refugee Status requested was not granted because you don't meet the eligibility criteria, and the reasons
you provided during the interview were not pertinent”. There has not yet been an appeal to the court and
there are concerns as to the willingness of the judiciary to find against the Rwandan Government. The
same processes of DGIE, RSDC, and the Minister, as have proved defective in the past, are envisaged
under the MEDP. In this respect, I agree with, and adopt, Underhill LJ's analysis at [158]-[223], where he
breaks down the stages of the Rwandan RSD process and explains why the UNHCR's criticisms of that
process merit more consideration than was given to them by the Divisional Court.

96. The UNHCR's evidence shows 100% rejection rates at RSDC level for nationals of Afghanistan,
Yemen and Syria, from which asylum seekers under the MEDP may well emanate (I note here that my
conclusion is the same as Underhill LJ at [200]). The overall rejection rate for the 156 cases covered by the
figures is 77%. Of the 34 recent asylum seekers from a country with close bilateral relations with Rwanda,
three were peremptorily rejected by the DGIE, three were forcibly expelled to the Tanzanian border, two
were instructed to leave Rwanda within days, and two more were threatened with direct expulsion to their
country of origin. In addition, there have been 5 recent cases of expulsion of those arriving at Kigali airport:
two Libyans removed from Kigali airport in February 2021, two Afghans chain refouled to Afghanistan on
24 March 2022, and one Syrian chain refouled to Syria on 19 April 2022. The cases of airport refoulement
do not themselves demonstrate that there would be a real risk of identical methods of refoulement under
the MEDP, since those asylum seekers arriving in Rwanda would have been pre-approved by the
Government of Rwanda and would arrive on planned flights. These instances nonetheless illustrate, as
described by Underhill LJ at [156], “a culture of, at best, insufficient appreciation by DGIE officials of
Rwanda's obligations under the Refugee Convention, and at worst a deliberate disregard for those
obligations”. The Divisional Court was provided with a table of instances of at least 100 allegations of
refoulement and threatened refoulement cited in the UNHCR's evidence and in notes of meetings with the
SSHD. The UNHCR does not accept that the guarantees will be sufficient to prevent the risk of these
events occurring to those accepted by Rwanda under the MEDP.

97. The Rwandan Government's responses to these contentions demonstrate its misunderstanding of the
meaning of the concept of refoulement. The UNHCR says that its responses are “indicative of fundamental
misunderstandings … of its obligations under the Refugee Convention and give no reason to believe that
such practices will change”. In essence, the Rwandan Government suggests that it can reject asylum
claims and expel people where they seek asylum using forged documents (as many do), or have not been
granted an entry visa, or where domestic immigration law allows. The UNHCR informed the UK
Government in the weeks prior to a meeting in Kigali on 25 April 2022 about three recent cases of the
refoulement of two Afghans and one Syrian who were denied asylum and put on flights out of Rwanda. The
Rwandan Government's response to this claim was a demonstration of its misunderstanding of the
meaning of refoulement. It said that deceitful travellers attempting to abuse its border openness are
routinely intercepted, but if the immigrant invokes an asylum claim “as an alternative reason after failing to
satisfy immigration entry requirements”, deportation will continue whenever necessary. Whilst it also says
that such things will not happen under the MEDP, the concern of the UNHCR is as to what happens to
those sent to Rwanda under that scheme, whose asylum claims are rejected.


-----

Commissioner for Refugees intervening) and other case....

98. The detailed monitoring mechanisms are likely to come too late to affect the risk of these initial asylum
seekers facing article 3 mistreatment. Moreover, it is unclear that these monitoring mechanisms would
account sufficiently for the approach to the granting of asylum taken up to now by the Rwandan
Government, which I have outlined in the previous paragraph.

99. The same can be said for the training of those making asylum decisions in Rwanda. At the time of the
Divisional Court hearing, and on the evidence before this court, there was simply insufficient evidence to
demonstrate that officials would be trained adequately to make sound, reasoned, decisions. In this respect,
I agree with Underhill LJ at [245]-[260].

100. The ultimate reliability of the safeguards in the Rwandan asylum system will depend on the promised
ability of asylum seekers to appeal to the court. That is not to ignore the fact that the bulk of the claims will
be determined by non-judicial means, but to reassert that access to the courts is a core component of the
right of access to justice. The Divisional Court in Government of Rwanda v. Nteziryayo _[2017] EWHC 1912_
_(Admin) considered the independence of the Rwandan judiciary in an admittedly different context, but at_
some considerable length. It concluded at [234]-[240] and [372]-[374] that “the evidence points to some
risk, depending on the evidence before them and the safeguards in play, that judges might yield to
pressure from the Rwandan authorities” (see also the findings below in that case recorded at [149]). An
FCDO (Foreign, Commonwealth and Development Office) comment on an FCDO draft document entitled
“review of asylum processing: Rwanda” from April 2022 said that Rwanda was: “… the country of
contradictions. For these cases I agree the legal support is likely to be independent … unless it gets
political. Which may be farther down the road when refugees are in a process [of] settlement and make
demands on certain things. The Rwandan legal system is not independent, is regularly interfered with and
is politicised. Opposition/political cases do not receive a fair trial or support”.

101. The SSHD submitted that the UNHCR's evidence as to the Israel/Rwanda agreement was irrelevant.
I do not agree. Mr Bottinick explained that it was illustrative of the “danger and suffering that are, in
UNHCR's view, liable to arise from the UK's externalisation plan”. The UNHCR gathered the information it
provided from interviews between 2015 and 2017 with those who had been sent to Rwanda. Arrivals under
that arrangement were “routinely moved clandestinely to Uganda even if they were willing to stay in
Rwanda”. Mr Bottinick concluded that the “UNHCR considers that the UK-Rwanda Agreement creates
serious risks of (a) increased people smuggling, and (b) an increase in asylum seekers being exposed to
dangerous journeys and life-threatening conditions”.

102. The UNHCR drew our attention to the decision of the Israeli Supreme Court in Sagitta v. Ministry of
_Interior Administrative Appeal 8101/15. We were provided with an unofficial translation. It is clear from [87]_
of that judgment that the court held that the agreement between Israel and Rwanda (which we have not
seen) was “specific” insofar as it related to the rights granted to the deportees and included “an explicit
undertaking of [Rwanda] according to which the deportees will enjoy human rights and freedoms and that
the principle of non-refoulement shall be complied with”. Accordingly, this constituted some evidence that
the breaches mentioned by the UNHCR occurred notwithstanding Rwandan Government assurances to
the contrary. The Rwandan Government's response to the allegations lacked substance. It merely said that
Rwanda had entered into other transfer arrangements for the international protection of refugees that
differed from the Israel/Rwanda scheme.

103. As regards the events at Kiziba camp in Rwanda, the UNHCR's evidence was that in February 2018,
about 700 Congolese refugees resident there had marched towards Karongi town and camped outside the
UNHCR Karongi Field Office. The refugees were protesting against a 25% cut in food rations. Two days
later, the Rwandan police fired live ammunition on protesting refugees killing at least 12 people. Between
February and May 2018, 66 refugees were arrested, and many were charged with a range of offences
including “spreading false information with intent to create a hostile international opinion against the
Rwandan state” (article 451 of the Penal Code), “inciting insurrection or trouble amongst the population”
(article 463 Penal Code), and participating in an illegal demonstration or public gathering (article 685 Penal
Code). Human Rights Watch's investigation found that the refugees were unarmed and that the Rwandan
police had used excessive force Although Rwanda's National Commission for Human Rights expressed


-----

Commissioner for Refugees intervening) and other case....

the view that the police responded as a last resort to a violent attack, the UNHCR has grave concerns that
asylum seekers relocated under the MEDP would be at significant risk of harm and detention if they
expressed dissatisfaction through protests in Rwanda.

104. In my judgment, the problem with uncritical acceptance of the SSHD's view that the unequivocal
assurances in the MEDP can wipe away all real risk of article 3 violations is that the structural institutions
that gave rise to past violations remain in Rwanda today. The DGIE will still be responsible for asylum
seekers arriving from the UK. It may have had some more training (though Mr Bottinick describes that as
being at “an extremely basic level”), but it is the same institution. The RSDC will still decide asylum claims
without the applicants being legally represented. The members of the RSDC may have learnt something
since past violations, but it is impossible to be sure that they will be fair, when their processes are not
attended by third parties. The appeals to the Minister and to the court are largely or, in the case of the
court, completely untested. Rwanda is still, as the UK Government acknowledges, a one-party state which
reacts unfavourably to dissent (see also Human Rights Watch's public letter to the SSHD dated 11 June
2022, expressing its concerns about likely article 3 breaches). It is not an answer to say that Rwanda will
have accepted the people sent under the MEDP, because the advanced information they will have about
them will be limited and they may form adverse political opinions once there.

105. The application of the _Soering test requires the court to find there are “substantial grounds” for_
thinking there is a real risk of article 3 breaches. I have concluded that the matters I have mentioned,
weighed against the Rwandan assurances and the SSHD's view, giving appropriate but not overriding
weight to the evidence of the UNHCR, means that such substantial grounds existed as at July 2022. I am
conscious that Underhill LJ has expressed the view at [132] that the correct date for our consideration of
the generic issues was September and October 2022 when the hearing took place before the Divisional
Court. I understand his reasoning, but it seems to me that this is an appeal from the generic decisions
made by the Divisional Court which were taken in respect of the position as at July 2022. That said, I do
not think that there was any material difference between the position as at the two dates, and I would make
the same decision whichever of those dates was being considered.

Issue 4: Was the Divisional Court right to conclude at [73]-[77] that there was no real risk that the
response of the Rwandan authorities to hostile political opinions expressed by asylum seekers in the future might
subject them to article 3 ill-treatment?

106. In effect, this question has already been answered under the previous issue. I do not think that the
Divisional Court was right to compartmentalise the Soering test. It would have been better if it had asked
itself whether, having regard to all the Rwandan Government's guarantees and assurances, the SSHD's
view that they would be complied with, and all the evidence including the evidence of the UNHCR, there
were substantial grounds for thinking that asylum seekers sent to Rwanda under the MEDP would face any
real risk of article 3 mistreatment. I also adopt Underhill LJ's comments at [290]-[291].

107. Accordingly, in my view, the events at Kiziba, to which the Divisional Court referred at [74], were
something that ought to have been taken into account generally in relation to the Soering test, rather than
specifically in relation to the conditions in Rwanda generally.

Issue 5: Bearing in mind the correct test, was the Divisional Court right to decide at [64] that the SSHD
was entitled to rely on the assurances contained in the MoU and Notes Verbales?

108. I can fully understand why the SSHD might have thought in good faith that she could rely on the
Rwandan Government's assurances in the MEDP. The court has, however, now made an objective
evaluation of the Soering test on the basis of evidence that either was or ought to have been available to
her. On that basis, the SSHD ought not reasonably to have relied on the assurances in the MEDP.

Issue 6: Were there **in fact substantial grounds for thinking, bearing in mind the guarantees and**
assurances, that (a) Rwanda was not a safe third country, (b) there were real risks of refoulement or article 3
breaches, and (c) there were real risks that asylum claims would not be properly determined?


-----

Commissioner for Refugees intervening) and other case....

109. The answer to this issue is now also clear. There were substantial grounds for thinking, bearing in
mind the guarantees and assurances, that (a) Rwanda was not a safe third country, (b) there were real
risks of refoulement or article 3 breaches, and (c) there were real risks that asylum claims would not be
properly determined. I refer specifically to [273]-[286] of the judgment of Underhill LJ for his analysis of how
the risk of refoulement may eventuate.

110. It is important to understand how the conditions on the ground justify the conclusion that Rwanda was
not a safe third country for the purposes of refoulement and article 3. In effect, that is because where a
country's domestic asylum processes are deficient to the extent set out above, and in Underhill LJ's
judgment, that will provide an insufficient safeguard, in particular for asylum seekers whose claims are
rejected. Those asylum seekers risk being returned either directly to their country of origin or indirectly
through a third country. They will thereby face real risks, in circumstances where they should not have
been returned at all. A robust and effective asylum process in the receiving state is a necessary bulwark to
mitigate against the risk of refoulement and related ill-treatment.

Issue 7: Was the Divisional Court right to conclude at [71] that the SSHD's decision that, for the purposes
of the criteria at [345B(ii) to (iv)], Rwanda was a safe third country, was neither irrational, nor a breach of article 3?

111. It does not necessarily follow from what I have already said that the SSHD's decision to accept the
Rwandan Government's assurances was either irrational or itself a breach of article 3, although it gives rise
at least to a real risk of such a breach. In the light of the answer I have given to the Soering question, it is
not necessary for the court to reach a conclusion on this issue and I would prefer not to do so.

Issue 8: Was the Divisional Court right to accept at [59] that the SSHD complied with the obligations
identified in Ilias, namely to undertake a “thorough examination” of “all relevant generally available information”.

112. The Divisional Court spent much time examining the _Ilias question of whether the SSHD made a_
thorough examination of all relevant generally available information. As explained in Ilias itself, the duty to
undertake a thorough examination is primarily a procedural one. Having determined the substantive
question, I do not think it is necessary to decide the procedural one, which looks in detail at the process
that the SSHD undertook, rather than the substantive issue that had to be resolved. Underhill LJ takes the
same approach at [266]. The SSHD undoubtedly considered much of the material available to the court.

Issue 9: Was the Divisional Court right to accept at [61] that the SSHD complied with her Tameside duty to
ask herself the right question and take reasonable steps to acquaint herself with the relevant information to enable
her to answer it correctly?

113. The Divisional Court also spent much time examining the Tameside question of whether the SSHD
asked herself the right question and took reasonable steps to acquaint herself with the relevant information
to enable her to answer it correctly. Again, like Underhill LJ (at [266]), I do not think that, in the light of the
conclusions I have reached on the substantive question, it is necessary to answer this question.

Issue 10: Was the Divisional Court right at [72] to decide that the Inadmissibility Policy, including the
possibility of removal to a safe third country, was not Gillick unlawful?

114. The Divisional Court asked itself whether the Inadmissibility Guidance positively authorised or
approved unlawful conduct. It held it did not, because the SSHD could have lawfully concluded that
Rwanda was a safe third country, and that asylum claims would be effectively determined. In the light of
the answer to the Soering question, it is not necessary to determine whether the Inadmissibility Guidance
itself was also unlawful. If I had thought it necessary to decide the Gillick issue, I would have agreed with

[296]-[301] of the judgment of Underhill LJ.

Issue 11: Were the SSHD's certifications under [17(c)] and/or [19(c)] unlawful, because the asylum
seekers' ECHR claims were not clearly unfounded?


-----

Commissioner for Refugees intervening) and other case....

115. The SSHD, in fact, certified (i) under [17(c)] that in her opinion Rwanda was a place where the
asylum seekers' “life and liberty will not be threatened by reason of [their] race, religion, nationality,
membership of a particular social group or political opinion”, and “from which the person will not be sent to
another State otherwise than in accordance with the Refugee Convention”, and (ii) under [19(c)] that the
asylum seekers' human rights claims were clearly unfounded, meaning that they could not bring an
immigration appeal from within the United Kingdom in reliance on those claims.

116. It follows from what I have already said that the court could not endorse the SSHD's opinion under

[17(c)] that Rwanda was a place where the asylum seekers would not be subjected to the risk of ECHR
breaches or refoulement. In that respect, I agree with Underhill LJ at [302]. It also follows that I do not
agree with the SSHD's certification under [19(c)] that the asylum seekers' ECHR claims were clearly
unfounded.

117. As suggested at [10] above, the “clearly unfounded” test is a stricter one than the Soering test which
asks whether there are substantial grounds for thinking there are real risks of article 3 mistreatment. In
these circumstances, the SSHD ought not to have certified the appellants' ECHR claims under [19(c)]. The
result is that the claims ought to have been permitted to be pursued in the usual way through the Tribunals
process.

The remaining issues

118. I agree with the judgment of Underhill LJ as to the answers to the remaining five issues, namely:

i) Issue 12: Should the Divisional Court have concluded that removal of asylum seekers to Rwanda under
the MEDP was inconsistent with article 33, or constituted the imposition of a penalty contrary to article 31?
(See the judgment of Underhill LJ at [304]-[339].)

ii) Issue 13: Should the Divisional Court have concluded that articles 25 and 27 of the Procedures
Directive made the MEDP unlawful because it was still retained EU law? (See the judgment of Underhill LJ
at [340]-[367].)

iii) Issue 14: Should the Divisional Court have decided that the SSHD had created a presumption that
Rwanda was safe in her assessment documents, thereby circumventing the statutory scheme? (See the
judgment of Underhill LJ at [368]-[377].)

iv) Issue 15: Should the Divisional Court have decided that the SSHD's alleged breaches of the UK GDPR
would, if established, invalidate the SSHD's decisions under the MEDP? (See the judgment of Underhill LJ
at [378]-[400].)

v) Issue 16: Should the Divisional Court have decided that the three decisions to treat the asylum
application as inadmissible under [345A], to decide to remove the asylum seeker to Rwanda under [345C],
having decided that Rwanda was a safe third country under [345B], and to make a certification decision
under [17(c)] to the effect that Rwanda was a safe country for the asylum seeker, were rendered unlawful
by procedural unfairness? (See the judgment of Underhill LJ at [401]-[455].)

Conclusions

119. I would, as I have said, allow the appeal on the Soering issue. The Lord Chief Justice, for the reasons
he gives, would dismiss the appeal. Since Underhill LJ agrees with me on the Soering issue, the appeal
will be allowed. We will invite the parties to agree an appropriate order to reflect this judgment and that of
Underhill LJ.

**LORD JUSTICE UNDERHILL:**

**INTRODUCTION**

120. I have read the judgment of the Master of the Rolls. I gratefully adopt his summary of the
background facts and issues, although I will occasionally repeat matters to save the need for crossreference I will use the term “Claimants” to refer to the individual Appellants (i e apart from Asylum Aid)


-----

Commissioner for Refugees intervening) and other case....

collectively. Like the Master of the Rolls, I will take first the issues relating to the safety of Rwanda, on
which the Claimants' submissions were advanced by Mr Raza Husain KC and the Secretary of State's by
Sir James Eadie KC.

**A.                        SAFETY OF RWANDA**

THE BACKGROUND LAW

121. It has been established since the decision of the European Court of Human Rights (“the ECtHR”) in
_Soering v United Kingdom 14038/88 [1989] ECHR 14 that it is a breach of article 3 of the European_
Convention on Human Rights (“the ECHR”) for a contracting state to remove an individual to a third country
(whether or not itself a contracting state) where there are substantial grounds for believing that they will be
at real risk of being treated contrary to the standards required by that article – this is the so-called “Soering
test”. The position is helpfully summarised at para. 126 of the judgment of the Grand Chamber of the
ECtHR in Ilias and Ahmed v Hungary 47287/15 (2020) 71 EHRR 6, as follows:

“Deportation, extradition or any other measure to remove an alien may give rise to an issue under Article 3,
however, and hence engage the responsibility of the Contracting State under the Convention, where
substantial grounds have been shown for believing that the person in question, if removed, would face a
real risk of being subjected to treatment contrary to Article 3 in the receiving country. In such
circumstances, Article 3 implies an obligation not to remove the individual to that country … .”

122. That principle was applied in the context of asylum-seekers in MSS v Belgium and Greece 30696/09

[2011] ECHR 108, in which the ECtHR held that Belgium was in breach of article 3 by returning asylumseekers under the Dublin regime to Greece where (as it held separately) there were substantial grounds for
believing that there was a real risk that their article 3 rights would be breached. In such a case the risk
may take the form of serious ill-treatment in the country to which they are returned, but it may also take the
form of the risk of refoulement (direct or indirect) to their country of origin where they have a well-founded
fear of persecution: in _MSS both risks were in fact found to be present. References in this context to_
whether the third country is “safe” cover both aspects.

123. As regards the latter risk – that is to say, the risk of direct or indirect refoulement – the Grand
Chamber in Ilias observes, at para. 131, that “the main issue … is whether or not the individual will have
access to an adequate asylum procedure in the receiving third country”. The reason is obvious: if the
asylum-seeker does not have access to such a procedure there will prima facie be a real risk of their being
refouled, either because their claim is not entertained at all or because it is not determined properly and
fairly. As it says at para. 137:

“Where a Contracting State removes asylum seekers to a third country without examining the merits of
their asylum applications, however, it is important not to lose sight of the fact that in such a situation it
cannot be known whether the persons to be expelled risk treatment contrary to Article 3 in their country of
origin or are simply economic migrants. It is only by means of a legal procedure resulting in a legal decision
that a finding on this issue can be made and relied upon. In the absence of such a finding, removal to a
third country must be preceded by thorough examination of the question whether the receiving third
country's asylum procedure affords sufficient guarantees to avoid an asylum-seeker being removed,
directly or indirectly, to his country of origin without a proper evaluation of the risks he faces from the
standpoint of Article 3 of the Convention.”

It follows, as it goes on to say at para. 139, that:

“On the basis of the well-established principles underlying its case‑law under Article 3 of the Convention in

relation to expulsion of asylum‑seekers, the Court considers that the above-mentioned duty requires from

the national authorities applying the 'safe third country' concept to conduct a thorough examination of the
relevant conditions in the third country concerned and, in particular, the accessibility and reliability of its
asylum system.”


-----

Commissioner for Refugees intervening) and other case....

124. Where the safety of the third country depends on assurances given by its government about the
treatment which the individual will receive on return, it is necessary to consider the reliability of those
assurances in accordance with the guidance given by the ECtHR in _Othman v United Kingdom 8139/09_

[2012] ECHR 56, as set out at para. 32 of the judgment of the Master of the Rolls. But the underlying
question remains whether there are substantial grounds for believing that there is a real risk of a breach of
article 3.

125. If the relocation of asylum-seekers to Rwanda under the MEDP involves a breach of their article 3
rights it would of course be unlawful as a result of section 6 of the Human Rights Act 1998.

THE SHAPE OF THE CASE

126. The Claimants contend that Rwanda is “unsafe” in both the respects identified above – that is to say
both because of the risk of serious ill-treatment in Rwanda itself and because of the risk of refoulement as
a result of the inadequacies of its asylum system. However, in their submissions before us – as indeed, as
I understand it, they did in the Divisional Court – they have concentrated mainly on the latter risk. I will
accordingly focus on the question identified in Ilias, namely “whether or not the individual will have access
to an adequate asylum procedure in the receiving third country”. I consider the question of other potential
ill-treatment in Rwanda at paras. 287-291 below.

127. Before proceeding further I need to deal with three preliminary matters.

128. First, the Claimants contend that in the part of its judgment in which the Divisional Court considered
the adequacy of the asylum system, at paras. 62-71, it proceeded on the basis that its task was not to
decide that question for itself but only to decide whether the Secretary of State was entitled to conclude
that the system was adequate. The Master of the Rolls considers that contention as his Issue 1 and
concludes that the criticism is well-founded. The Lord Chief Justice has reached the opposite conclusion.

129. For me the issue is not of crucial importance, since, for reasons which will appear, I believe that even
if the Court asked itself the right question its answer was wrong. However, if it were necessary I would,
albeit with hesitation, accept the Claimants' submission. Like the Lord Chief Justice, I do not accept for a
moment that this experienced Court failed to appreciate the difference between the approaches required to
determining a claim for judicial review and a claim of a breach of the ECHR, and I agree with him that its
initial statement of the article 3 issue, at para. 39 of its judgment, was unimpeachable. But I think, with
respect, that in its attempt to bring order to the confusing way in which the issues were presented it created
a problem for itself by addressing the Claimants' case under article 3 and their conventional judicial review
claim under a single heading. That made it difficult to keep the different approaches distinct. At a number
of points in the relevant passage, it uses what is unambiguously the language of judicial review when
addressing the particular issues that are determinative of its overall conclusion on the adequacy of the
Rwandan asylum system. In summary:

(1) It begins its consideration, at para. 62, by characterising the question which it had to consider as being
“whether the Home Secretary was entitled to conclude that there were sufficient guarantees to ensure that
asylum seekers relocated to Rwanda would have their asylum claims properly determined there and did
not run a risk of refoulement … and that Rwanda was a safe third country …”. Although I give weight to
what the Lord Chief Justice says at para. 489 of his judgment, it seems to me clear that the whole
sentence, including the words which I have italicised, is governed by the phrase “entitled to conclude”
(which I also note that the Court uses again later in the same paragraph).

(2) The Court states its conclusion, at the beginning of para. 64, as being that “the Home Secretary is
_entitled to rely on the assurances contained in the MoU and Notes Verbales”._

(3) In para. 66 of its judgment, which I quote in full at para. 269 below, it places considerable weight on the
evidence of Mr Simon Mustard, the Director, Africa (East and Central) at the FCDO, stating that it could
only go behind his opinion if there were compelling evidence to the contrary. That in itself may be
consistent with the correct test, but at para. 68 it describes an approach taken by him to part of the
e idence as “permissible” obser ing that it did not “consider it discloses an error of la ”


-----

Commissioner for Refugees intervening) and other case....

(4) At para. 70, it records the opinion of UNHCR that, in effect, the assurances given by the Government
of Rwanda (“the GoR”) could not be relied on, but observes that

“ … [T]hat is not the question we must address. The question is whether, notwithstanding the opinion the
UNHCR has now expressed, the Home Secretary was entitled to hold the contrary opinion.”

At para. 71 it says that its task is to decide whether on the totality of the evidence “the Home Secretary's
opinion is undermined to the extent it can be said to be legally flawed”.

Despite my reluctance to believe that the Court really fell into the error alleged, we must proceed by
reference to the language which it has used unless it is clear that it does not reflect its true reasoning; and I
cannot say that that is the case.

130. Second, Mr Husain sought at one stage in his submissions to argue that because the Secretary of
State had certified the human rights claims made by (most of) the individual Claimants under paragraph 19
of Schedule 3 to the Asylum and Immigration (Treatment of Claimants etc) Act 2004 (with which I deal
more fully in connection with Issue 14 below) the Divisional Court should have been concerned only with
whether their claims based on article 3 were “clearly unfounded” and not sought itself to determine those
claims: see in particular para. 43 of the AAA Claimants' skeleton argument. With respect, that is a
confusion. Although the human rights claims in question were indeed certified, the Claimants' challenge to
that certification is not before us because it succeeded in the Divisional Court (albeit, as the Court made
clear at para. 179 of its judgment, on procedural grounds rather than on the substance of the article 3
claims); and the Secretary of State has not appealed. Accordingly, we are concerned only with the
separate “generic” challenge advanced by the Claimants to the lawfulness of (in shorthand) “the Rwanda
policy”, and the challenges to the lawfulness of the individual certification decisions are an irrelevance.

131. Having said that, I cannot help noting that the fact that the safety of Rwanda issue arises in the
context both of the generic challenge to the Rwanda policy and of the challenges to the certification of the
individual claims potentially creates a procedural conundrum about which challenge should be prioritised.
If the only challenge had been to the certification of the human rights claims in the individual cases, the
question for the Divisional Court would have been whether an appeal to the First-tier Tribunal (“the FTT”)
against the refusal of those claims had a realistic chance of success. If the Court had held that it did, the
judicial review proceedings would have achieved their aim and an appeal to the FTT would have
proceeded. It is not clear to me that the position should necessarily be different where, as here, claimants
plead a distinct challenge to the policy underlying the individual decisions. It is at least arguable that in
such a case the better course is for the court to determine the challenge to the certification first, and, if it
succeeds, to decline to consider the generic challenge on the basis that the FTT was the more appropriate
forum, both because of its specialist expertise and because it would normally hear oral evidence.[1]
However, that question no longer arises in this case, if it ever did, and I mention it only in case it is relevant
to future cases.

132. Third, the fact that we are on this appeal concerned with a challenge to the lawfulness of the policy
means that we are not required to focus on the dates of the decisions in the individual cases (i.e. 5 July
2022). In substance, we are concerned with the lawfulness of the policy as at the date of the hearings
before the Divisional Court in September and October: I note that the Master of the Rolls takes a different
view (see para. 105 above) but I agree with him that the point makes no difference in practice. Another
consequence is that we are not concerned with the risk of refoulement in the case of all or any of the
individual claimants. Rather, we are concerned with the risk to the group as a whole to whom the asylum
policy is intended to be applied.

THE RWANDAN ASYLUM SYSTEM

133. Section 9 of the MoU reads:

“Asylum processing arrangement

9.1 Rwanda will ensure that:


-----

Commissioner for Refugees intervening) and other case....

9.1.1 at all times it will treat each Relocated Individual, and process their claim for asylum, in accordance
with the Refugee Convention, Rwandan immigration laws and international and Rwandan standards,
including under international and Rwandan human rights law, and including, but not limited to ensuring
their protection from inhuman and degrading treatment and refoulement;

9.1.2 each Relocated Individual will have access to an interpreter and to procedural or legal assistance, at
every stage of their asylum claim, including if they wish to appeal a decision made on their case; and

9.1.3 if a Relocated Individual's claim for asylum is refused, that Relocated Individual will have access to
independent and impartial due process of appeal in accordance with Rwandan laws.

9.1.4 If a Relocated Individual does not apply for asylum, Rwanda will assess the individual's residence
status on other grounds in accordance with Rwandan immigration laws.”

(The term “Relocated Individuals” – or RIs, as it appears in some Home Office documents – has a rather
de-personalising tone, but I will sometimes use it for convenience.)  More detailed guarantees are given in
the Asylum Process Note Verbale (“the APNV”). I will refer to its particular provisions later as relevant.

134. I should summarise in outline the Rwandan process for determining individual asylum claims,
described as the “refugee status determination”, or “RSD”, process. The basis of the process is a law
passed in 2014, in some respects supplemented by subsequent Prime Ministerial Orders. Unfortunately,
not all its details are clear, but I will defer consideration of the points of difficulty. The relevant stages are
as follows:

(1) A claim for asylum must be made in writing and registered with the Directorate General of Immigration
and Emigration (“DGIE”), which is an entity within the National Intelligence and Security Service. DGIE will
interview the claimant following receipt of the written claim and should within fifteen days forward the file,
including a record of the interview, to the Refugee Status Determination Committee (“the RSDC”), which
operates under the auspices of the Ministry in Charge of Emergency Management (“MINEMA”). It should
also issue a temporary residence permit.

(2) Before a case is considered by the RSDC it is reviewed by a MINEMA “Eligibility Officer”. There is
some uncertainty about the nature and extent of their responsibility; but in broad terms it is to see that the
case is in a fit state to be determined by the RSDC. This may involve obtaining additional information,
including by conducting a further interview with the claimant.

(3) The RSDC is the primary decision-maker. It comprises eleven members, being senior officials (at
Director or Director General level) from the Prime Minister's Office, the ministries in charge of refugees (i.e.
MINEMA itself), foreign affairs, local government, justice, defence forces, natural resources, internal
security, and health, the National Intelligence and Security Service and the National Commission for
Human Rights. Membership goes with a particular post in each body and changes when that individual
changes jobs. Membership is not a full-time role: members will have other time-consuming responsibilities.
It is not therefore a specialist body, though some of the members may have some relevant expertise from
their other roles. It determines claims at regular meetings, their frequency depending on how many claims
require determination: many claims may be determined at each meeting. There is a quorum of seven. The
committee may decide the case on the basis of the file alone or ask the asylum-seeker to attend to be
questioned, referred to as an “interview”: there is an issue as to whether RIs will in all cases have an
interview and if so what its nature is.

(4) There is a right of appeal to the MINEMA Minister.

(5) A further appeal lies from the Minister to the High Court of Rwanda. In its current form this right was
introduced in 2018.

The GoR refers to stages (1)-(4) as the “administrative” phase of the RSD, in contrast to stage (5), which is
judicial.


-----

Commissioner for Refugees intervening) and other case....

135. The Claimants' case that that system is seriously defective is supported by UNHCR as intervener and
is largely based on the evidence adduced by it[2]. The evidence in question consists of three witness
statements from Lawrence Bottinick, the UNHCR Senior Legal Officer in the United Kingdom, dated 9
June, 26 June and 27 July 2022, to which I refer as “LB 1-3”. LB 2 is the most substantial: it runs to some
148 paragraphs, with numerous exhibits. Those exhibits include previous statements by UNHCR about its
concerns about the asylum system in Rwanda, notably a seven-page Note dated 8 June 2022 headed
“UNHCR Analysis of the Legality and Appropriateness of the Transfer of Asylum-Seekers under the UKRwanda Arrangement” (“the UNHCR Note”). Mr Bottinick's evidence represents the institutional view of
UNHCR, and I will sometimes refer to it as the UNHCR evidence.

136. The Master of the Rolls has already quoted the conclusion to LB 2, in which Mr Bottinick expresses
UNHCR's conclusion about the deficiencies in the Rwandan asylum system: see para. 7 above. I have
read what he says at paras. 85-88 about the weight to be given to UNHCR's opinion, and I respectfully
agree with it. As he notes at para. 94, UNHCR has a large and active presence in Rwanda. It is true that
the main focus of its activities is in the large camps housing refugees from neighbouring countries, and on
the “ETM” project under which vulnerable migrants stranded in Libya are relocated to Rwanda on a
temporary basis pending resettlement elsewhere; and Mr Bottinick complains about the limited extent to
which the Rwandan government has allowed it to be engaged in the RSD process. Nevertheless it is clear
that UNHCR's staff in Kigali, and its partner organisations, have had extensive dealings with asylumseekers who have been through, or sought to go through, that process. Mr Bottinick's witness statements
have been evidently carefully prepared by reference to that experience, with as much detail and
identification of sources as practicable. There is no good reason not to accept what they say on matters of
fact except where there is cogent evidence to the contrary.

137. The Secretary of State responded to LB 2 in witness statements from Kristian Armstrong, the Head of
the Third Country Asylum Partnerships unit in the Home Office (“TCAP”), dated 5, 7 and 22 July 2022. The
responses are, inevitably, dependent on information supplied by the GoR. That information is mainly
contained in four exhibits to Mr Armstrong's witness statements, as follows:

(a) a nine-page formal Statement dated 2 July from the MINEMA Minister responding to UNHCR's
concerns (“the GoR Statement”) – this is directed primarily to the UNHCR Note;

(b) an undated seven-page response by the GoR to the criticisms made in a number of identified
paragraphs in LB 2 (“the primary GoR response”);

(c) a table dated 5 July sent in an e-mail from the Chief Technical Adviser to the Minister of Justice
headed “Information required from GoR” responding to 37 numbered questions from the Home Office (“the
tabular response”);

(d) an e-mail dated 19 July 2022 from the Chief Technical Adviser giving additional information on the
processing of claims by the DGIE and the RSDC (“the GoR supplementary e-mail”).

Those responses were required at fairly short notice, and I do not underestimate the difficulties in obtaining
information remotely. But I have to say that they are not very satisfactory. It is not stated from which
departments or other sources the statements in them are derived and they are at several points unclear,
lacking in detail or inconsistent.

138. The Secretary of State also relies on the witness statement of Chris Williams dated 5 July 2022. Mr
Williams is an Assistant Director Country Returns and Projects Immigration Enforcement, who was
deployed to Rwanda in mid-May 2022 in order to support the operational aspects of the first relocations,
then anticipated for 14 June. That involved ensuring that the various assurances in the MoU and the NVs
could be fulfilled. His witness statement gives details of what he and his colleagues were told in a number
of meetings and discussions with GoR officials, including a presentation on 25 May from, among others,
someone he describes as “the DGIE Director”. Similar, but in some respects fuller, information deriving
from the same exercise appears in a Home Office document of the same date called “MEDP PreDeparture Assurance” (“the PDA”) exhibited by Mr Armstrong.


-----

Commissioner for Refugees intervening) and other case....

139. I should also mention the suite of “Country Policy and Information Notes” (“CPINs”) published by the
Home Office in May 2022, all with the general title “Review of asylum processing”. These comprise a
general CPIN headed “Rwanda: assessment” (“the Assessment CPIN”) and two CPINs dealing more fully
with specific aspects – “Rwanda: country information on the asylum system” (“the Asylum System CPIN”)
and “Rwanda: country information on general human rights” (“the Human Rights CPIN”) – to which the
Assessment CPIN regularly cross-refers. The Asylum System CPIN contains an account of the system
based on what the CPIT team were told by Rwandan officials on visits in January and March 2022. Full
notes of the interviews which they conducted on those visits are published separately as “Annex A”. The
CPINs are important for the purpose of Issue 13, with which I deal below, but on the issue of the safety of
Rwanda it is necessary to proceed by reference to the evidence in the proceedings, as identified above.

140. The Claimants' criticisms of the Rwandan system are summarised under fourteen headings in paras.
92-170 of the AAA Claimants' skeleton argument below. (The skeleton argument before us refers back to
those submissions but is less directly helpful because it is structured by reference to the criticisms which
the Claimants make of the reasoning of the Divisional Court.) UNHCR makes substantially the same
criticisms under fifteen heads in para. 18 of its Written Observations in the Divisional Court.

141. I propose to consider the Claimants' and UNHCR's criticisms of the Rwandan asylum system in two
parts. First, I will consider the criticisms directed at particular stages, including the question of whether
asylum-seekers can reliably gain access to the system at all. I will then address three issues which are
common to the process as a whole, namely access to legal assistance/representation; availability of
interpreter services; and training. I should make three points by way of preliminary.

142. First, UNHCR's evidence is, necessarily, based on its experience of the system as it operated in the
period up to the date of LB 2, i.e. 26 June 2022 (with the exception of a few matters added in LB 3). It is a
central part of the Secretary of State's case that that past experience is not a reliable guide to how those
relocated to Rwanda under the MEDP will be treated, both because the GoR's assurances involve specific
improvements in the system as it may have operated previously and because it will operate in a wholly
different context than before. Accordingly, in what follows I will have to consider not only how the system
has operated up to now but the nature of any proposed changes (including, but not limited to, assurances
given in the MoU and the APNV) and the likelihood that they will be implemented.

143. Second, it is important to appreciate that, despite having now been in place for some time, the RSD
process has in practice been comparatively little used: UNHCR has described it as “nascent”. Rwanda has
for many years had a very creditable record of granting asylum to large numbers of refugees from
neighbouring countries, most of whom are accommodated in camps where UNHCR has an active role; but
until August 2020 asylum was granted on a “prima facie basis”, i.e. without individual assessment of the
claimants. The first individual assessments made by the RSDC were made in 2018 and the numbers
remain small: see paras. 195-197 below. There have been comparatively few appeals to MINEMA and
none to the High Court. Although the Divisional Court at paras. 55 and 70 of its judgment drew attention to
a review published by UNHCR in July 2020 which was complimentary about Rwanda's compliance with the
Refugee Convention (albeit also expressing some criticisms), that statement was not directed to the RSD
process.

144. Third, as will appear, the GoR disputes the factual basis of many of UNHCR's criticisms. The
Divisional Court says at para. 55 of its judgment that it did not believe that it was necessary to resolve most
of those disputes, and in fact it considered only two of them: see paras. 202 and 203 below. I agree that in
order to reach a conclusion on the adequacy of the Rwandan asylum system it is unnecessary, even if it
were possible, to make definitive findings on each of the disputed matters of fact. The ultimate question is
always whether there are substantial grounds to believe that there is a real risk of a breach of article 3
rights; and for that purpose what is required is an overview of the totality of the evidence (cf. the
observations of Lord Hoffmann in an analogous context at paras. 45-49 of his speech in Secretary of State
_for the Home Department v Rehman_ _[2001] UKHL 47, [2003] AC 153). But it remains necessary at least to_
review the evidence relating to the more important of UNHCR's criticisms and so far as possible to form a
view as to the reliability of their factual basis


-----

Commissioner for Refugees intervening) and other case....

CRITICISMS OF PARTICULAR STAGES OF THE PROCESS

Access to the RSD Process

145. UNHCR asserts that there have in the recent past been a number of instances where individuals
seeking asylum in Rwanda have been denied the opportunity to make asylum claims at all. The evidence
is of three kinds.

146. First, UNHCR relies on four instances of “airport refoulement”[3] between February 2021 and April
2022, in which six people – two Libyans, two Afghans, one Syrian and one Yemeni – who had claimed
asylum at Kigali airport on arrival were denied entry by DGIE staff and returned to the countries from which
they had flown. The two Afghans and the Syrian are believed by UNHCR to have been returned from
those countries to their countries of origin, i.e. refouled; it was able by rapid intervention to prevent a similar
outcome for the two Libyans and the Yemeni. Evidence about these incidents is given in LB 2 and LB 3,
but they are also referred to in the UNHCR Note, and were the subject of two Notes Verbales from UNHCR
to the GoR – the first, dated 3 February 2021, relating to the Libyans and the second, dated 21 April 2022,
relating to the Afghans and the Syrian. DGIE's conduct is said not only to show an arbitrary disregard for
the requirements of the Refugee Convention but also to be evidence of a prejudice against claimants from
the Middle East and Afghanistan.

147. The GoR accepts that the individuals in question were denied entry and sent back as alleged, but it
disputes UNHCR's account of the circumstances. Its response appears not only in the primary and the
tabular responses but also in a MINEMA “Feedback” document dated 11 May 2022 responding to
UNHCR's Note Verbale of 21 April. These are not entirely consistent as regards details (and, confusingly,
the primary response refers to five Syrians rather than the single case raised by UNHCR), but the GoR's
essential case is that each of the individuals in question initially claimed entry on other grounds which
proved false (e.g. possession of forged passports or inability to substantiate their claim to be travelling for
business) and only at that point claimed asylum.

148. There are two points made by the GoR in this context which the Claimants say show serious
misunderstandings of refugee law:

(1) In the Feedback document MINEMA says:

“… an asylum seeker is required to present his/her need for protection immediately upon arrival at the
airport/entry point but not to invoke asylum claim as an alternative reason after failing to satisfy immigration
entry requirements”.

(There is a similar statement in the tabular response in the answer to qu. 34.) The Claimants point out that
it is not the case that an asylum claim must be made immediately.

(2) The answer to qu. 27 in the tabular response says (among other things):

“Cases referred to by UNHCR are not recognised as refoulement because all those cases are foreigners
who have been refused entry visa because they were using forged documents and thus, not meeting
immigration entry requirements.”

The Claimants point out that use of forged documents is not a reason for refusing to consider an asylum
claim.

149. The Divisional Court adverts to these cases (except for that of the asylum-seeker from Yemen) at
paras. 53 (1) and 55 of its judgment but it makes no findings about what occurred or what conclusions can
be drawn from them. In my view the GoR's responses do not satisfactorily answer the allegation that it
acted in breach of the Refugee Convention by declining to consider the asylum claims made and that its
expulsion of the claimants led to their (indirect) refoulement in some of the cases and risked it in the others;
and they do indeed show an imperfect understanding of the requirements of the Convention.


-----

Commissioner for Refugees intervening) and other case....

150. It is UNHCR's case that these episodes are very unlikely to be the only instances of airport
refoulement. It has no presence at the airport, and it will only get to hear of such episodes if the claimants
themselves, or other interested persons, are able to contact it, which would not always be the case.

151. Second, paras. 112-113 of LB 2 refer to three incidents, involving two families and an individual,
where access to the asylum process was denied to persons who were already in the country. The
claimants were all nationals of a non-African country with which Rwanda has particularly close relations
(“country X”). They made asylum claims, but DGIE did not refer them to the RSDC. Instead, it gave the
claimants a short period of notice to leave the country, and in fact thereafter simply transported them to the
border (in one case Uganda and in the other Tanzania). It is Mr Bottinick's evidence that they would have
been indirectly refouled to country X if UNHCR had not been able to intervene and find other countries
willing to accept them. He relies on these episodes not simply as instances of DGIE disregarding
claimants' Convention rights but of their doing so in the interests of their relationship with a foreign
government. These incidents are not addressed in the GoR's responses or therefore in the Secretary of
State's evidence.

152. Third, it relies on the experience of individuals who had sought asylum in Israel but had agreed to be
relocated to Rwanda under the terms of an agreement between Israel and the GoR. The agreement was
in place between 2013 and 2018. There is no dispute that those who accepted relocation under the
agreement suffered serious breaches of their rights under the Refugee Convention. I can adopt the
summary of Mr Bottinick's evidence on this from para. 15 of the AAA Claimants' skeleton argument:

“(i)  Many of those relocated were 'not permitted to lodge their [asylum] claims' and reported 'arrests for
lack of documentation', 'threats of deportation from unknown agents, following which eight disappeared'
and 'continuous, random overnight visits by unknown agents at their accommodations'. All 'feared for their
personal safety, and feared refoulement to their country of nationality'. Further asylum-seekers later
became known to UNHCR, of whom another seven 'went missing'. Relocated asylum-seekers were
'routinely moved clandestinely to Uganda even if they were willing to stay in Rwanda'. Dozens of asylumseekers reported that 'their documents were confiscated' on arrival, 'and they were taken to a house in
Kigali where they were kept under guard', before being 'smuggled to Uganda'.

(ii) UNHCR's interviews with 80 Eritrean and Sudanese asylum-seekers in Italy who had been relocated
under this arrangement revealed that, 'feeling they had no other choice, they travelled many hundreds of
_kilometres through conflict zones' and had 'suffered abuse, torture and extortion before risking their lives_
_once again by crossing the Mediterranean to Italy'. Some reported that those travelling with them had died_
_en route to Libya. UNHCR is aware of two individuals who were transferred from Israel to Rwanda and who_
(as of 2022) still have no formal status in Rwanda despite claiming asylum several years ago. UNHCR has
identified at least 50 cases of _refoulement_ or threatened _refoulement_ under the Israel-Rwanda
arrangement.”

That evidence goes beyond the particular question of denial of access to the asylum process and also
illustrates arbitrary and oppressive behaviour by Rwandan state agents, presumably DGIE.

153. Although the Secretary of State was aware of the Israel-Rwanda agreement and of the problems
about it, she did not as part of the process leading to the MEDP seek to investigate why it had failed,
whether by enquiring with the GoR or otherwise. Among other things, she did not attempt to obtain
information about the terms of the agreement or what assurances the GoR had given about the treatment
of asylum-seekers relocated under it.[4] As the Master of the Rolls explains at para. 101 of his judgment, her
position in the Divisional Court, and before us, was that what had happened under a different agreement,
made under different circumstances some years previously, could shed no light on whether the GoR could
be relied on to comply with its assurances under the MEDP. She has accordingly not sought to adduce
evidence contradicting or qualifying Mr Bottinick's account of a wholesale failure by the GoR to respect the
Convention rights of those returned under the agreement.

154. I would thus accept UNHCR's evidence about all three episodes. But it is necessary to be clear what
conclusions do and do not follow


-----

Commissioner for Refugees intervening) and other case....

155. On the one hand, I do not accept that the evidence in question justifies the conclusion that there is a
real risk that individuals relocated under the MEDP will be subject to airport refoulement or otherwise
denied access to the asylum process. Their situation is clearly different from that of unheralded individual
asylum-seekers, and also from that of the in-country nationals of country X. The GoR will have been
supplied with their details in advance and will have expressly agreed to accept them under the terms of the
MEDP. Their flight will be expected and arrangements put in place for their reception and accommodation.
In those circumstances it is in my view inconceivable that DGIE would deny them entry to the country or
would refuse them the opportunity to make an asylum claim as expressly promised in the MoU and the
APNV. The case of those returned under the Israel-Rwanda agreement may seem rather closer to the
present, but the available evidence does not establish that the circumstances in which they were unable to
access the asylum system in Rwanda are comparable to those which will obtain under the MEDP.

156. On the other hand, I do not accept that these episodes are of no relevance. They are evidence of a
culture of, at best, insufficient appreciation by DGIE officials of Rwanda's obligations under the Refugee
Convention, and at worst a deliberate disregard for those obligations, together with at least a suggestion of
prejudice against asylum-seekers from the Middle East and Afghanistan and a willingness to take into
account political considerations. Those factors are capable of impacting on the treatment of asylumseekers even if they are admitted to the process, particularly given the responsibility of DGIE for the first
stage of that process. I will return in due course to the question whether the MEDP eliminates, or
sufficiently mitigates, that risk.

157. I should mention one other issue. Para. 41 (i) of LB 2 records that UNHCR has since 2017 received
reports that DGIE has refused to register claims made by claimants claiming fear of persecution on the
basis of sexual orientation or gender identity. Mr Bottinick accepts that more recently two such claims
have been permitted to progress, although he also reports a very recent episode where a LGBTQI+
asylum-seeker was submitted to very hostile questioning in his asylum interview. Similar concerns were
raised by UNHCR at its meeting with Home Office officials in March 2022. The primary GoR response
says:

“LGBTIQ+ not able to register. This is demonstrably untrue. The RSDC has received applications from
LGBTIQ+ and has granted refugee status to those who have been determined as having a well-founded
fear of persecution on the basis of their sexual orientation.”

The tabular response instances a particular case where an asylum-seeker of Egyptian origin was found to
have a well-founded fear of persecution on the basis of his transgender status: see the answer to qu. 28.
In LB 3 Mr Bottinick points out that that response is not inconsistent with his original evidence. However,
even if there have been cases of the kind alleged in LB 2, for similar reasons to those given at para. 155
above I do not believe that there is a real risk that RIs claiming to fear persecution on the grounds of their
sexual orientation will be denied access to the RSD process.

Stage (1): DGIE

_Alleged “gatekeeper role”_

158. The first stage of the process is the responsibility of DGIE. As a matter of Rwandan law, its role is
simply to do the necessary preparatory work, primarily by conducting the asylum interview. But UNHCR
says that DGIE also performs a substantive screening or gatekeeper role which means that it may refuse
to process claims, or delay them indefinitely, so that they never proceed to the RSDC (and a residence
permit is not issued): see LB 2 paras. 38-39. Where this occurs there is no written decision, still less
written reasons; but claimants have sometimes been given reasons orally which are inconsistent with the
Convention. Those decisions are not appealable, and although the RSDC has power to consider a claim
which DGIE has failed to refer timeously (under article 8 of a Prime Ministerial order) UNHCR has no
experience of this ever occurring. The evidence relied on in support of the allegation that DGIE plays this
gatekeeper role is identified at para. 39 of LB 2 as being the airport refoulement and in-country refusal
cases discussed above, together with


-----

Commissioner for Refugees intervening) and other case....

“… several cases in 2021 and 2022 where individuals were told by the DGIE that their cases would not be
referred to the RSDC solely because they had come to Rwanda on a work permit or tourist visas ... [and] ...
were told by the DGIE to make an application only once their permit expires”.

159. The GoR denies that DGIE acts as a gatekeeper in the way described: see the primary response to
para. 38 of LB 2. But the denial goes no further than re-stating the statutory position that DGIE is obliged
to refer claims to the RSDC. There is a suggestion that UNHCR's evidence is based on a
misunderstanding of article 8 of the Prime Ministerial Order, but it is in my view clear that Mr Bottinick is
reporting the actual experience of UNHCR staff in Rwanda.

160. I have already expressed my view about the airport refoulement and in-country denial episodes. As
for the cases where claimants were told to re-present their claims only when their current residence
permits expire, I do not believe that the GoR's general denial justifies the rejection of Mr Bottinick's
evidence. I accept, however, that that conduct falls short of expulsion or a definitive refusal to entertain the
claim.

161. Para. 4.7.3 of the Asylum System CPIN records that DGIE provides “a preliminary analysis of the
application”.  Mr Bottinick says that UNHCR staff have on several occasions been told by DGIE officials
that following the asylum interview DGIE makes a recommendation to the RSDC as to the outcome of the
claim (LB 2, para. 40), but the claimant is not given a copy of that recommendation. A “recommendation”
is not quite the same as a “preliminary analysis” but both would involve DGIE giving the RSDC the benefit
of its views on the substance of the application.

162. The GoR's response to LB 2 (primary response at para. 40) reads:

“DGIE's role in the RSD process consists of preparing files to be submitted to the RSDC for consideration.
These files include information gathered about the asylum seeker. DGIE does not make any
recommendation that may influence outcome of the RSDC decision. The RSDC takes decisions based on
the information contained in the file and the additional information provided by the Eligibility Officer.”

Mr Bottinick confirms in LB 3 (para. 24 (d)) that that is inconsistent with what UNHCR staff have repeatedly
been told.

163. I note that what the response denies is that DGIE makes “any recommendation that may influence
_outcome of the RSDC decision”. That is not inconsistent with “the information contained in the file” giving a_
statement of the views of the DGIE officer.  Nor would it be surprising that the officer should express such
views, given that they will have interviewed the claimant and should have relevant expertise to form a view;
and given also that DGIE is an agency of the National Intelligence and Security Service which is one of the
bodies which contributes a member to the RSDC. To the extent that any such analysis or recommendation
is given, it is not satisfactory that the claimant is not shown it.

_The conduct of the asylum interview_

164. It will be appreciated that the asylum interview is of central importance because it may (subject to
paras. 184-185 below) be the only opportunity which a claimant has to present their case orally.  Paras.
4.3 and 4.4 of the APNV read:

“4.3  A decision whether a Relocated Individual is recognised as having a refugee protection need will
only be taken following an appropriate examination that will, amongst other things, provide the Relocated
Individual with the opportunity to:

4.3.1 make a written application and provide evidence in support;

4.3.2 attend an interview to explain their application and answer any questions the decision maker may
have;

4.3.3  to further explain their claim, including any elements that may be missing from their written
application or after the interviewer's question.


-----

Commissioner for Refugees intervening) and other case....

4.4   The asylum interview will:

4.4.1 be transcribed or electronically recorded in full. If the interview is transcribed, the Relocated
Individual will be given the opportunity to review and, if necessary, correct the transcript; and

4.4.2 be conducted under conditions which allow the Relocation Individual to present the grounds for their
application in a comprehensive manner. In particular;

4.4.2.1 the person who conducts the interview will be competent to take account of the personal and
general circumstances surrounding the application, including the applicant's cultural origin, gender, sexual
orientation, gender identity or vulnerability;

4.4.2.2 wherever possible, the interview with the Relocated Individual will be conducted by a person of the
same sex if the Relocated Individual so requests, unless there is reason to believe that such a request is
based on grounds which are not related to difficulties on the part of the Relocated Individual to present the
grounds of his or her application in a comprehensive manner;

4.4.2.3 be in the presence of an interpreter who is able to ensure appropriate communication between the
Relocated Individual and the person who conducts the interview. The communication shall take place in
the language preferred by the applicant unless there is another language which he or she understands and
in which he or she is able to communicate clearly.”

It is clear that some of those provisions were included in response to criticisms of the conduct of the
asylum interview which had already emerged in the course of the two visits to Rwanda by Home Office
officials and/or in their discussions with UNHCR.

165. I turn to consider UNHCR's criticisms of the asylum interview. UNHCR is not generally permitted to
attend asylum interviews but its staff in Kigali speak to asylum-seekers about their experience of them.

166. First, it is said at para. 41 (a) of LB 2 that the interview with DGIE is brief and perfunctory, lasting only
about 20-30 minutes, and that it does not give the claimant a fair opportunity to explain the basis on which
they are claiming asylum. That is particularly serious since DGIE is said (LB 2 para. 34) to encourage
claimants not to exceed one or two pages in their initial applications or to submit lengthy documents, such
as country information reports, in support so that there may be much that has to be amplified or explained
at the interview. Mr Bottinick also says that claimants are not given an opportunity in the interview to
address “adverse points” or to submit further information following it in order to address points which have
arisen during it (LB 2, paras. 38 (c) and 41 (b)).

167. The GoR's primary response to para. 41 (a) reads:

“This is not true. The interview takes as much time as necessary for the applicant [to] explain clearly his or
her case. The interview guiding questions are set in way that provides the applicant the possibility to
provide all information to support their application. Applicants can be invited for more interviews if
necessary.”

No copy of “the interview guiding questions” is supplied, and the source of the information is not stated.
That general and unsourced denial does not justify a wholesale rejection of UNHCR's evidence.

168. The question then is whether the position will be different as a result of the MEDP. Para. 4.3.1 of the
APNV expressly says that claimants will have the right to provide supporting evidence as part of the initial
claim, and para. 4.3.3 allows them to further explain their claim following the interview. The APNV does
not prescribe a minimum length for the interview, but the intention is evidently that it will be long enough to
allow the claimant to explain their asylum claim and answer questions about it; and clearly in many cases
thirty minutes would be inadequate for that purpose, particularly since usually both questions and answers
will have to be translated.

169. I do not believe that it will be a straightforward matter for DGIE officials to change the way in which
they have been accustomed to conduct interviews. No doubt it can be done, but it requires an appreciation
that their previous approach was inadequate and effective training and monitoring. The response quoted


-----

Commissioner for Refugees intervening) and other case....

above suggests that GoR does not accept that there is a problem which requires to be addressed. I return
to the issue of training below.

170. Second, it is said that no transcript or other record of the interview is provided to the claimant: LB 2,
para. 41 (e), LB 3 para. 29 (a). This is a point of obvious importance since the facts elicited at interview will
form a crucial part of the file which goes to the RSDC.

171. It is not entirely clear whether the GoR accepts that this is not part of its current practice. The
supplementary GoR e-mail says:

“Records of the DGIE interview: The DGIE conducts interviews with the asylum seeker in the initial stages
of the asylum process with a view to submit the information to the RSDC and to grant the asylum seeker a
temporary residence permit. The DGIE interviews consist of the asylum seeker describing their reasons for
seeking asylum in Rwanda. The interview is recorded electronically and at the end of the interview, the
asylum seeker is presented with a written record of the interview. The asylum seeker verifies the
information and can confirm the record with a signature or can amend the record by correcting the
information or providing more information. A copy of the DGIE record of interview as verified by the asylum
seeker will be made available to the asylum seeker. The legal representative retained by the asylum
seeker can assist with reviewing the records of the interviews.”

That passage starts by using the present tense but changes to the future tense.

172. I do not believe that that evidence is an adequate basis for rejecting UNHCR's evidence as to past
practice, and it is more likely that it reflects the intended post-MEDP system: as we have seen, provision of
a transcript, with the opportunity to approve it, is specifically addressed by para. 4.4.1 of the APNV. As to
that, I should add that the PDA comments on this obligation as follows:

“Ability for Relocated Individual to review transcription

RIs will have the ability to review the transcript and correct the record immediately after the interview
process. The transcript can be printed there and then. After the interview is conducted and information
recorded by DGIE on their digital system, it will be reviewed again to confirm the transcript is correct,
including where relevant, that translations are correct as transcribed by the interpreter. Once all parties are
content the document will be signed.”

It is clear from para. 34 of Mr Williams' witness statement that this information derives from the DGIE
Director.

173. The real question thus is whether the requirements of the APNV will be complied with.  We are here
concerned with a specific procedural requirement rather than one involving the exercise of judgment, such
as the conduct of the interview as considered above. I see no reason to suppose that DGIE will
deliberately disregard the explicit requirement of the APNV, confirmed and amplified in the statements of
the DGIE Director, that it should supply claimants with a copy of the transcript of the asylum interview in
their own language. However, the process described in the APNV is not straightforward, and training will
be required to ensure that it can be accomplished in practice. Again, I return to this below.

174. Third, Mr Bottinick says (LB 2, para. 41 (c); LB 3 para. 28 (a)) that claimants are not permitted at the
asylum interview to be accompanied by a lawyer. The evidence about this, or in any event about whether
it will continue to be the case under the MEDP, is not clear. Because the same question arises in relation
to stages (3) and (4) I address it separately below. As will appear, my conclusion is that legal
representatives are certainly not permitted at present but it appears to be intended that henceforward they
will be. (It is accordingly unnecessary to consider whether that is in all cases necessary in the interests of
fairness: I will only say that it is very likely that in some circumstances it will be.) However, it is not clear
what consideration has been given to the role that legal representatives can play at the interview.

Stage (2): Eligibility Officer


-----

Commissioner for Refugees intervening) and other case....

175. Mr Bottinick addresses the role of the Eligibility Officer at paras. 42-47 of LB 2. He points out that it is
potentially very important because the additional information which the Eligibility Officer may obtain, and
the notes of any interview that they conduct with the claimant, will presumably go before the RSDC; but he
complains that there is no transparency about this stage of the process. It is not clear on what basis
claimants may be selected for interview nor is any record of the interview shared. Nor is it clear what the
file compiled for the RSDC consists of, including what country information, UNHCR guidance, or summary
of legal principles it may contain. He also says that there is at present only one Eligibility Officer, which is
unsatisfactory given the nature and importance of the role (and also because the current incumbent does
not speak English).

176. The GoR responses do not comprehensively address these criticisms. The GoR statement appears
to say that the Eligibility Officer interviews every claimant (para. 4); but the statement is in very general
terms. As for numbers, the answer to qu. 24 in the tabular response states that there are now two
Eligibility Officers and that MINEMA is recruiting three more and plans to recruit others in future. The
answer to qu. 36 is similar but not identical. It says:

“There is currently one Eligibility Officer which is adequate for the usual volume of claims received. (ToR of
an Eligibility Officer are attached below). MINEMA is actively recruiting more Eligibility Officer to cater for
the expected increase in asylum claims under this partnership.”

177. The “attached ToR” would seem to be the job description for the role as advertised (apparently now
to be described as “Eligibility and Protection Specialist”) exhibited by Mr Armstrong to his witness
statement dated 2 July 2022. This reads:

“JOB PURPOSE

The Eligibility and Protection Specialist will be in charge of checking, record keeping, filing, and advocating
on behalf of migrant families. He/She will determine whether or not migrant families' various needs are met
and propose corrective measures.

DUTIES AND RESPONSIBILITIES

Under the direct supervision of the Program Manager, the Eligibility Specialist will perform the following
duties:

- Assist in the monitoring and analysis of statistics related to migrant case processing in order to identify

and respond to developments or issues affecting decision‐making quality, and to propose corrective

measures.

- Ensure the reception of migrants and asylum seekers and assist them in providing feedback on
individual cases.

- Conduct Migrants, asylum seekers' interviews and draft their Assessments in accordance with set
guidelines.

- Conduct research on country of origin information and legal issues concerning migrants and asylum
seekers, and assist in the maintenance of a local database of relevant information.

- Maintain accurate and up‐to date records and data related to all work on individual cases.”

The reference in the third bullet to conducting interviews and drafting assessments cannot, I think, be to
any involvement at the DGIE stage but to the Eligibility Officer's own interview (though it is not clear
whether this will occur in every case) and assessment carried out for the benefit of the RSDC.

178. Mr Armstrong also says, at para. 46, that in the course of the negotiation of the MEDP

“… Rwandan officials explained that individuals will be supported throughout the process by a caseworker
from the Eligibility and Protection Office in Ministry of Emergency Management (MINEMA) who will collate


-----

Commissioner for Refugees intervening) and other case....

information related to an individual's case and submit it to the National Refugee Status Determination
Committee for decision.”

179. I see no reason to doubt that the intention of the GoR is that there will be a sufficient number of
Eligibility Officers to deal with the increase in asylum-seekers going through the RSD process as a result of
the MEDP; or that they will have for the future the functions and responsibilities described in the job
description, whether or not they precisely correspond to what their role has been in the past. I need not
therefore reach a conclusion about UNHCR's criticisms of the current position. However, it is clear that the
role as envisaged is important and valuable: given the part-time and non-specialist nature of the RSDC, it
is in truth essential that it be serviced by full-time officials who can provide it with necessary information,
materials and technical advice. That being so, it is essential that the Eligibility Officers be properly trained:
I return to this below.

180. Finally, I should note that it is not clear from the APNV, or any of the other evidence, whether any
interview conducted by the Eligibility Officer will be subject to the requirements specified in para. 4.4 – i.e.
that it will be conducted through a qualified interpreter and the claimant will have the opportunity to address
the record.

Stage (3): the RSDC

181. As regards the substantive determination of an RI's asylum claim – that is, the decision by the RSDC
– the APNV provides as follows:

“4.5 For the purpose of taking decisions on asylum claims, decision makers will obtain up-to-date
information as to the general situation prevailing in the countries of origin of the Relocated Individual. This
information will be available to decision-makers, and they will have appropriate resources to further
research and access expertise where needed.

4.6  A decision on a Relocated Individual's asylum application will:

4.6.1 be taken on the merits of the individual application; and

4.6.2 will be objective and impartial.

4.7  Arrangements will be made to ensure that the decisions taken on individual claims are recorded.

4.8  Relocated Individuals will be notified in writing of the decision that has been taken on their asylum
claim.

4.9  A decision will:

4.9.1 be in one of the official languages of Rwanda and, if needed for understanding, it will be translated in
writing by an interpreter into a language that the Relocated Individual understands, free of charge;

4.9.2 include the reasons for the decision in both fact and law; and

4.9.3 a decision that is a refusal of the asylum claim will notify a Relocated Individual that they will be able
to appeal the decision on their asylum claim and provide an explanation of how to do this.”

182. Paras. 48-65 of LB 2 advance a number of criticisms of the RSDC stage of the process. I consider
them under the following heads.

_Process_

183. Mr Bottinick's evidence is that in the majority of cases the RSDC takes its decision at a meeting
which the claimant does not attend (and which indeed they will not know has taken place until they receive
the decision) and thus without receiving any submissions from him or her: see paras. 56 and 59 of LB 2.
This means that in such cases the quality of the information before the Committee, at least as regards the
claimant's individual circumstances, is dependent on the quality of the asylum interview conducted by
DGIE, and any further interview conducted by the Eligibility Officer, and the records of such interviews.


-----

Commissioner for Refugees intervening) and other case....

The claimant has no access to those records and so is in no position to correct any errors or clarify any
misunderstandings. More generally, as he says in para. 65 (d), they have

“no opportunity … to present their claim in full, or address provisional adverse findings (eg to address a
credibility concern that has arisen in the view of the decision-maker(s), including through a lawyer).”

If that is a fair summary of the procedure followed it clearly has the potential for serious unfairness.

184. The GoR responses do not directly address this part of Mr Bottinick's evidence (although para. 4.4.1
of the APNV provides for them to receive a copy of the transcript of the asylum interview). However, at
para. 36 of his witness statement Mr Williams says that the DGIE director told him that

“… following their asylum interview and receipt of their translated interview transcript, relocated individuals
will be given the opportunity to make oral and written representations directly to the RSDC and that the
RSDC may request further information from relocated individuals if required for the purposes of reaching a
decision on their claim”.

This is the only reference in the evidence to an RI being given the opportunity to make “oral and written
representations” directly to the RSDC. Nothing is said about when any written representations would be
expected to be lodged or considered. The reference to oral representations is presumably to
representations made by the claimant at the meeting at which the Committee makes its decision: a
separate “hearing” would be a radical departure from its practices which I would expect to have seen fully
explained.  In that case there might not be much difference between the right to make oral representations
and the “interview” referred to by Mr Bottinick: the important point would be that there would be an
interview in every case.

185. If that is indeed what the DGIE Director intended to convey, it appears inconsistent with the
understanding of the Chief Technical Adviser to the Ministry of Justice, since the passage from the
supplementary e-mail quoted at para. 230 below carefully refers to “any interview at the RSDC”. It is also
inconsistent with what the Home Office officials understood from their meetings in January and March
2022: para. 4.7.3 of the Asylum System CPIN says that “RSDC can [my underlining] request to meet the
applicant to verify information (in a 20-40 min interview)”. It is very unsatisfactory not to have a clear and
consistent account of how the RSDC will proceed in determining the RIs' cases.

186. Mr Bottinick complains, on the basis of accounts from individual asylum-seekers and others who
have been present, that where the RSDC interviews the claimant the interview is short (cf the CPIN
reference to 20-40 minutes) and often conducted unprofessionally (e.g. by preventing claimants giving
proper answers or submitting further information or by hostile questioning) or in a way that appears to show
a poor knowledge of the file and/or a failure to appreciate the requirements of refugee law (e.g. by a focus
not on the claimed fear of persecution but on why the claimant has not sought asylum “closer to home”):
see para. 60 of LB 2. In addition, he says that professional interpreters are rarely employed. These
complaints are not addressed in the GoR's response.

187. Mr Bottinick also complains that where the RSDC has conducted an interview no transcript is made
available to the claimant. That criticism is not addressed directly by the GoR, but its supplementary e-mail
says:

“The refugee status determination by the RSDC is an administrative process wherein minutes of the
decision-making process are recorded. These minutes will be made available to the relocated individual
attached to their notification of decision by the RSDC.”

Whether that is a complete answer depends on what procedure is followed in the case in question. If the
RSDC proceeds to a decision immediately after the interview the only value to the claimant of having a
transcript would be in case what they had said was relevant to an appeal; and in those circumstances the
promised minute might be adequate, depending how full it was. But if the decision is deferred to a later
occasion it might be of real importance for the claimant to have a record, both so that any errors could be
corrected and as the basis for any submissions that they might wish to make (subject to the point I have to


-----

Commissioner for Refugees intervening) and other case....

consider next). The APNV says nothing about the agreement of a transcript in this situation. This
uncertainty is unsatisfactory.

188. Finally, and most importantly, Mr Bottinick complains that claimants are not entitled to make
submissions to the RSDC through a lawyer. Para. 60 (j) of LB 2 reads:

“There is no opportunity for asylum seekers (whether or not interviewed) to make submissions (in person
or through a lawyer) to the RSDC. Lawyers are not permitted at the RSDC stage. UNHCR and its legal aid
partners have been told repeatedly that if a person was telling the truth, they had no need for a lawyer.
Over the years, when legal aid partners have inquired about the possibility of legal representation, they
have been told that as the relevant national refugee law does not specifically refer to provision of legal
representation, it cannot be permitted.”

189. That evidence, so far as concerns representations by a lawyer, is not challenged by the GoR. As
appears at para. 230 below, it does now say that a claimant may be accompanied by their lawyer if the
RSDC conducts an interview, but it has not changed its position that it will not entertain submissions from
them: Sir James Eadie confirmed this in the course of his oral submissions. In my view this is a serious
defect in the process. Any representations will in most cases only be effective if made by a lawyer
because typically RIs will have neither the knowledge nor the articulacy to present their case to a nonspecialist body, and still less where they will be having to do so through an interpreter. It is true that in
many, perhaps most, asylum claims the determinative issue will be whether the claimant is telling the truth,
and that what they say in their interview(s) will be of central importance. But even on that issue there may
be points to be made beyond the bare narrative; and sometimes there will be important issues about
matters outside the claimant's knowledge, such as developments in their country of origin or issues of law.
It is also important to bear in mind that many RIs are likely to be especially vulnerable as a result of their
experiences, which may include a history of torture. The need to have a lawyer to present their claim will
be particularly important in such cases.

_Country information_

190. Para. 4.5.1 of the APNV acknowledges the need for decision-makers – in practice, the RSDC – to
have access to up-to-date country information. Mr Bottinick observes that because claimants do not see
the contents of their files it is impossible to know what information is in fact provided to the Committee. In
its tabular response (at qu. 10) the GoR says that the RSDC is provided with “country information reports
from ministry of foreign affairs and other open sources country information reports”. That is not very
specific, though I note that the duties of the Eligibility Officer will apparently include maintaining a relevant
database (see para. 177 above). On any view it will be particularly important for RSDC members to have
access to good objective information about the kinds of country from which most RIs are likely to come, of
which they will have had little previous experience.

_Reasons_

191. Para. 4.9.2 of the APNV requires that a written decision will “include the reasons for the decision in
both fact and law”. That is particularly important where a claim is refused. The intention is plainly that
decisions should not be “stereotyped” but should address the particular factual case advanced by the
individual claimant and identify the legal basis for the decision.

192. Para. 61 of LB 2 deals with the reasons given by the RSDC for decisions refusing an asylum claim.
Mr Bottinick says that UNHCR has seen the reasons given in 116 cases and that in none of them were the
reasons in sufficient detail to allow the claimant to understand why their claim had been rejected. In 36 out
of 50 such refusals in the previous year (of which he reproduces the relevant parts in a table) the reasons
given amounted to no more than some such formula as “because you don't meet the eligibility criteria and
the reasons you provided during the interview are not pertinent”. On the occasions where something more
is said it remains cursory in the extreme. UNHCR makes the further point that decisions in this form are
not only inadequate in themselves but indicate a poor quality of decision-making.


-----

Commissioner for Refugees intervening) and other case....

193. In its primary response to para. 69 of LB 2 the GoR states that:

“The reasons are briefly provided in the notification and more detailed reasons are communicated to the
applicant in person. Templates are being adjusted to provide detailed reasons on the notification.”[5]

That tacitly acknowledges that reasons in the form previously given are inadequate; and in any event Sir
James accepted that before us. No examples have been produced of more detailed reasons given in
recent cases before the RSDC.

194. I see no reason to reject the GoR's statement that it intends that the RSDC will henceforth give more
detailed reasons for its decisions. But the giving of proper written reasons, particularly where this has not
been the practice to date, is not a straightforward matter, and it is not possible to be confident that it will
occur unless those drafting them receive proper training.

_Outcomes and bias_

195. Para. 63 of LB 2 contains a table headed “Overview of cases processed by RSDC as known by
UNHCR for 2020 to 2022 (as of 21 June 2022)”. Mr Bottinick accepts that the table may be incomplete
because the GoR does not share statistics with UNHCR, but he explains the sources from which it is
derived. The table shows a total of 156 cases in the relevant period, with an overall rejection rate of 77%.

196. Mr Bottinick draws attention to the fact that the table shows three asylum claimants from Syria, three
from Yemen and two from Afghanistan, and that all of their claims were rejected. He also refers to
eighteen claims from Eritrea, of which ten were rejected. He says that the situation in the countries in
question, and the profiles of the individual claimants, are such that all their claims are very likely to have
been well-founded and that the numbers who were in fact rejected casts doubt on the quality of the
RSDC's decision-making. More particularly, as regards the former group he suggests at para. 114 of LB 2
that the reason for the rejection of their claims is likely to be a bias against asylum seekers from the Middle
East and Afghanistan. As to that, he relies not only on the figures in the table but on the cases of airport
refoulement discussed at para. 146 above. He also relies on statements which he says that UNHCR's staff
have heard senior government officials make to the effect that asylum-seekers from the Middle East and
Afghanistan should claim asylum in their own region. The latter allegation was not made for the first time in
his evidence: it has been made in UNHCR's meetings with Home Office officials in both March and April
2022.

197. The GoR has provided a different table, covering substantially the same period. This shows a total of
108 claimants, including only one from each of Syria, Yemen and Afghanistan, all of whose claims were
rejected, and twenty from Eritrea, fourteen of whose claims were rejected. It has also provided short notes
on the reasons for the rejections in question, rebutting any suggestion of prejudice, but without more detail
it is not possible objectively to assess their validity.

198. In LB 3 Mr Bottinick addresses the differences in the numbers as regards the claimants from Syria,
Yemen and Afghanistan and confirms that he is confident in the accuracy of his figures. He suggests that
the discrepancy may arise, at least in part, from the GoR treating linked cases as a single entry.

199. It is not possible definitively to resolve the difference between the two tables, but I believe we should
proceed on the basis of UNHCR's figures, both because they are carefully explained and defended in both
LB 2 and LB 3 and because we should take a “substantive grounds/real risk” approach. In my view the
surprisingly high rejection rate of claimants from known conflict zones, where UNHCR recommends
against returns, does indeed suggest a poor quality of decision-making.

200. As regards the more particular allegation of a bias against claimants from the Middle East and
Afghanistan, UNHCR's figures are of course statistically frail. But I do not believe they can be disregarded,
particularly when taken with its evidence about the views expressed by senior GoR officials that they
should have sought asylum nearer to home. Such views are not uncommon generally, and they are
consistent with questions reported to have been asked by RSDC members in cases where the claimants
have been interviewed (see para. 186 above); they would also be a plausible explanation for the airport


-----

Commissioner for Refugees intervening) and other case....

refoulement cases. They constitute evidence that RSDC members may hold such views and that they may
influence its decision-making.

201. I accept that the changes associated with the introduction of the MEDP may improve the quality of
decision-making and help to eliminate prejudices of the kind which UNHCR alleges are operative. But the
extent to which it will do so will depend on the effectiveness of the training which DGIE and RSDC officials
receive.

_Confidentiality_

202. Para. 41 (h) of LB 2 suggests various grounds for believing that DGIE may seek information about
asylum-seekers from the authorities in their countries of origin or their embassies in Rwanda. The GoR's
primary response is to the effect that it is standard practice for the Ministry of Foreign Affairs to “liaise with
Embassies to gather background information on the applicant and/or to gather country information”. That
is ambiguous, but in the GoR supplementary e-mail it is explained that the reference is to the Rwandan
embassies (or High Commissions) in the country of origin, to which application may be made if information
is required about a “specific event/situation”. The e-mail states in terms that “the DGIE and RSDC do not
share the personal data of an asylum seeker with any third party during the processing of the asylum
seeker's application”. This is one of the two criticisms on which the Divisional Court made a finding: at
para. 56 of its judgment it said that it was satisfied with the GoR's explanation. I find it difficult to reach a
concluded view, and for the reason given at para. 144 above I do not believe it is necessary to do so.

_Protection gaps_

203. The Claimants allege that the drafting of article 7 (1) of Law no. 13, which governs eligibility for
asylum in Rwanda, fails properly to implement the Refugee Convention because it does not cover
persecution for imputed political opinion or by non-state actors. That criticism is adopted by Mr Bottinick in
LB 2 (para. 82). As the Divisional Court points out at para. 55 of its judgment, it is impossible to form a
view about whether that is in fact how article 7 would be interpreted by a Rwandan court without expert
evidence of Rwandan law. The AAA Claimants' skeleton argument said that the absence of such evidence
was itself a breach of the Ilias duty, but Mr Husain did not develop the point in his oral submissions.

204. At paras. 83-88 of LB 2 Mr Bottinick expresses a number of concerns about the ability of
inexperienced Rwandan decision-makers to understand some of the more subtle important concepts of
substantive asylum law, such as the principle established in _HJ (Iran) v Secretary of State for the Home_
_Department_ _[2010] UKSC 31, [2011] 1 AC 596. This, however, is more relevant to the issue of training,_
which I consider separately below.

_The composition of the RSDC_

205. Under head (9) of its Written Observations UNHCR says:

“UNHCR has observed a lack of training or sufficient knowledge at all stages of the Rwandan RSD system.
The changing, part-time and non-specialist composition of what is in principle the main decision-making
body on asylum claims, the RSDC, in UNHCR's view compromises the quality and integrity of the
Rwandan RSD procedure. The RSDC's members are high level functionaries from an array of ministries,
whose primary responsibilities lie elsewhere and many of whose portfolios do not otherwise include
matters relevant to the asylum procedure. UNHCR's repeated offers to provide training to the Rwandan
RSD authorities have only been taken up on two occasions, with a gap of three years in between and
those trainings were short and basic.”

The passage goes on to develop the criticism in relation to training.

206. I would not accept – if UNHCR intends to go this far – that a body with the composition of the RSDC
is inherently incapable of making proper decisions on asylum claims, provided always that its members
approach their task conscientiously, and that they are provided with full information, including
representations from or on behalf of the claimant, and proper specialist support. Para. 4.5 of the APNV


-----

Commissioner for Refugees intervening) and other case....

recognises this, and it seems that it is intended that the support and information there referred to will be
provided by the Eligibility Officers. However, the main focus of UNHCR's criticism appears to relate to the
absence of training. I agree that this is fundamental, and I return to it below.

Stage (4): Appeal to MINEMA

207. Mr Bottinick addresses the right of appeal to MINEMA at paras. 66-75 of LB 2. In short his criticisms
are: that claimants whose claims are rejected by the RSDC are not notified in writing of their right of appeal
and only sometimes notified orally; that the right of appeal is ineffective because in the absence of a
reasoned decision from RSDC it is impossible to address the basis on which the claim was rejected; that it
is unclear whether the appeal is (adopting English terminology) by way of review or re-hearing; that
MINEMA is not independent, because its Permanent Secretary is the Secretary to RSDC; that free legal
advice is not available; and that MINEMA does not give reasons for its decisions. He also observes that
UNHCR is unaware of any cases where an appeal to MINEMA has succeeded.

208. Those criticisms are only partly addressed in the GoR's primary response. It appears to say that
claimants are informed by the Eligibility Officer of the reasons for MINEMA's decision and of their right of
appeal; but in fact I think the reference may be to the decision of the RSDC. It also says that two out of the
five appeals to MINEMA in 2021 succeeded.

209. Paras. 5.1-5.2 of the APNV read:

“5.1 A Relocated Individual may appeal a refusal of their asylum application to the Minister responsible for
considering such appeals.

5.2  A Relocated Individual who wishes to appeal to the Minister will have the opportunity to make oral and
or written representations. Any legal representative engaged by the Relocated Individual will have the
opportunity to make submissions when appropriate before the end of the process of appeal to the
minister.”

That makes clear that, whatever may have been the position in the past, MINEMA will consider
representations from the claimant's lawyer.

210. It will be seen that the evidence about the right of appeal to MINEMA is very limited. That makes it
difficult to assess its effectiveness as a safeguard against wrong decisions by the RSDC. I find it hard to
believe that following the MEDP claimants will be left unaware of their right of appeal or that fuller reasons
for a refusal by MINEMA will not be given (as is intended with the RSDC). But it is impossible to form a
useful view about the quality or independence of its decisions. The issue may not be central since the
ultimate safeguard should be the appeal to the High Court, to which I now turn.

Stage (5): Appeal to the High Court

211. The various problems identified above about the administrative stage of the RSD process make it
particularly important that there be a right of appeal to an independent judicial tribunal which can examine
the claim afresh. Para. 9.1.3 of the MoU provides:

“If a Relocated Individual's claim for asylum is refused, that Relocated Individual will have access to
independent and impartial due process of appeal in accordance with Rwandan laws.”

That commitment is amplified by paras. 5.3-5.5 of the APNV, which read:

“5.3 A Relocated Individual whose appeal has been refused by the Minister will be permitted to appeal that
decision to the High Court of Rwanda.

5.4 The court will be able to conduct a full re-examination of the Relocated Individual's claim in fact and
law in accordance with Rwanda rules of court procedure.

5.5 A Relocated Individual and their representative will have the opportunity to make full representations
as to fact and law at their appeal in accordance with Rwandan rules of court procedure.”


-----

Commissioner for Refugees intervening) and other case....

212. That does not give details of the “independent and impartial due process of appeal” afforded by
Rwandan law, but article 47 of “Law 30/2018 of 02/06/2018 determining the jurisdiction of courts” provides
that “the High Court also adjudicates cases relating to the applications for asylum”. It is common ground
that that provision gives an asylum-seeker whose claim has been rejected by the RSDC and MINEMA
what is in practice a right of appeal to the High Court. It is also common ground that no appeal under
article 47 has been brought since it became available five years ago, and there is no evidence about how it
would work in practice.

213. At para. 143 of LB 2 Mr Bottinick says:

“Even if the safeguards of representation and High Court appeal are now put in place for UK-Rwanda
arrangements, judges and lawyers do not have relevant experience. This raises a serious question about
the effectiveness of any appeal. In any event, UNHCR does not consider that the possibility of an appeal to
the High Court provides a sufficient safeguard against a decision-making process which is flawed from the
outset.”

He also repeats in this context his points that claimants are not reliably notified of the right of appeal, in this
case to the High Court, and that an appeal will be difficult in the absence of proper reasons from the RSDC
and/or MINEMA.

214. In the tabular response the GoR gives further information about the right of appeal to the High Court
in answer to two questions.

215. First, qu. 11 asked some questions about the procedural aspects of the appeal. The response reads:

“Individuals are allowed to appeal to high court to request a judicial review of the decision given by the
Minister.

- The High Court tries cases by a bench of one (1) or three (3) judges assisted by a Court Registrar. The
President of the court determines the appropriate number of the sitting judges depending on the
importance of the case.

- Evidence admissible under the rules of evidence can take the form of testimony, documents,
photographs, videos, voice recordings, DNA testing, or other tangible objects.

- High Court judgments can be appealed to the Appeal Court.”

That information is useful as far as it goes, but it does not appear to be specific to asylum appeals. If the
term “judicial review” is being used in its English sense it would appear inconsistent with the reference in
para. 5.4 of the APNV to “a full re-examination of the Relocated Individual's claim in fact and law”; but the
GoR is not consistent in its usage (see below).

216. Second, qu. 31 asked whether there had been provision for appeals to the High Court prior to the
2018 law and whether it was the case that there had indeed been no appeals so far, concluding “Can you
provide any information that will reassure our courts that anyone refused asylum will have access to this
system?”. The response says that other routes of challenge been available under different legislation prior
to 2014 and had been used on four recorded occasions. It says that there is no statutory impediment to
asylum seekers appealing under the 2018 law and that “there are currently 44 asylum seekers who were
refused refugee status after their appeal to the Minister who are within their right [to] get an appeal/judicial
review of this decision at the High Court”. This is not, of course, a statement that any of the 44 have in fact
done so.

217. The Claimants advanced a distinct challenge to the effectiveness of the right of appeal based on the
lack of independence of the judiciary. A submission that the Rwandan judiciary were not independent of
the government was first made at paras. 219-223 of the AAA Claimants' skeleton argument before the
Divisional Court. It was not specifically related to the effectiveness of the right of appeal against the refusal
of an asylum claim but was part of a general submission about human rights in Rwanda. Perhaps for that
reason, it was not addressed in the Divisional Court's judgment. However, in the AAA Claimants' skeleton


-----

Commissioner for Refugees intervening) and other case....

argument before us the submission was deployed in this context (see paras. 9 and 18), and it was fully
developed in Mr Husain's oral submissions.

218. The Claimants relied primarily on the decision of the Divisional Court (Irwin LJ and Foskett J) in
_Government of Rwanda v Nteziryayo_ _[2017] EWHC 1912 (Admin), in which the Court upheld the refusal of_
Senior District Judge Arbuthnot to order the extradition of five Rwandan nationals on charges relating to
the genocide on the basis that there was a real risk they might suffer a flagrant breach of their rights to a
fair trial if extradited. At para. 234 of its judgment the Court said:

“We reject firmly the submission of the GoR that the judge should unequivocally have stated the judiciary
was independent and that there was no risk of bias or interference in these cases, because they are not
'political'. The clearly authoritarian nature of the regime; the long and continuing history of the influence of
political will over the justice system where the case is perceived to matter; the evidence of Gahima [a
Rwandan lawyer and activist] and others; the evidence of threats arising from criticisms of the regime, not
in a political context but in the context of the justice system; the 'Osman' warnings [warnings given to
Rwandan exiles in London that they were at risk from the GoR]; the experiences of witnesses who gave
evidence in genocide cases unfavourable to the prosecution, whether in Rwanda or abroad: all these point
to a high level of risk of pressure within the system.”

At para. 373 it said:

“The evidence suggests that judges are not appointed unless they have party membership of the RPF [i.e.
the governing party]. Their appointments have moved from being indefinite to appointment for definite
terms. The Rwandan executive can achieve the dismissal of serving judges: it has done so in recent times
in respect of around 40 individual judges. We are not in a position to say whether the suggested
misconduct or corruption was established in these cases: it may be so. But the capacity of the executive to
get rid of judges is established. In such circumstances, there can be little doubt that judges will feel
exposed.”

219. The Claimants also place reliance on three other matters:

(1) On 11 June 2022 the London office of Human Rights Watch wrote to the Home Secretary expressing
the view that “Rwanda cannot be considered a safe third country to send asylum seekers to”. In the
context of criminal trials it said:

“The Rwandan judiciary suffers from a lack of independence, due to government manipulation of the justice
system, and fair trial standards are routinely flouted, particularly in politically sensitive cases.”

(2) The Home Office invited comments from the FCDO on a draft of the Asylum System CPIN. Against
the paragraph dealing with the availability of “independent legal support” its reviewer noted:

“Again the country of contradictions. For these cases I agree the legal support is likely to be independent ...
unless it gets political. Which may be farther down the road when refugees are in a process to settlement
and make demands on certain things. The Rwandan legal system is not independent, is regularly interfered
with and is politicised. Opposition/political cases do not receive a fair trial or support.”

(The first part of that comment is directed to the separate question of legal representation, but I include it
because it shows the context.)

(3) Reference is made to the recent trial for terrorism of Paul Rusesabagina, an opposition human rights
activist, which was described by the American Bar Association Centre for Human Rights as grossly unfair.

220. In his submissions before us Sir James Eadie did not dispute that the conclusions in Nteziryayo and
the evidence relied on by the Claimants gave, at the least, real grounds to believe that the Rwandan
judiciary was susceptible to political pressure. But he pointed out that the context in each of those
instances was the trial of political opponents. The context in the case of asylum appeals would be
completely different. The GoR would have no political interest in the outcome of particular appeals and
would have no reason to seek to manipulate them. In so far as judges might nevertheless wish to


-----

Commissioner for Refugees intervening) and other case....

determine appeals in accordance with what they understood to be government policy, the GoR's declared
policy was to ensure compliance with the MoU, which promised an independent and impartial appeal.

221. There is force in those points. However, I do not believe that they afford a complete answer. In the
first place, on an appeal under article 47 of the 2018 Law the High Court is being asked to overturn the
decision of a Government Minister and, indirectly, the decision of a Committee comprised of senior
representatives of the principal government bodies and agencies, including the Prime Minister's Office and
the National Intelligence and Security Service. Given what the Divisional Court in _Nteziryayo calls “the_
influence of political will over the justice system where the case is perceived to matter”, and the insecurity
of the position of Rwandan judges, there must be a real risk that they will be generally reluctant to allow
appeals against decisions of such bodies even in the absence of any specific pressure. Further, I do not
think it can be assumed that the GoR will never have an interest in the outcome of particular asylum
appeals: the willingness to deny access to the asylum process for nationals of “country X” (see para. 151
above) suggests that in particular circumstances it may well have an interest in denying asylum to RIs of
particular nationalities.

222. These concerns could in principle be met if there were evidence of how the appeal system has
worked in practice. But since not a single appeal has so far been brought there is no such evidence.

223. There are distinct issues about legal representation and training, but I address these separately
below.

CRITICISMS COMMON TO THE SYSTEM AS A WHOLE

Legal Assistance/Representation

224. As we have seen, para. 9.1.2 of the MoU guarantees RIs “access to procedural or legal assistance,
at every stage of their asylum claim”. What “legal assistance” amounts to is amplified in paras. 7 and 8 of
the APNV as follows:

“7.   Procedural and Legal Assistance

7.1 A Relocated Individual will be provided with orientation that includes details of the asylum process and
support that is available to them free of charge.

7.2 Each Transferee will be permitted to seek legal advice or other counsel from any non-governmental or
multilateral organisation, at any stage of the asylum application process at their own expense including
from an organisation providing that support free of charge.

7.3 The legal representative or other counsel engaged by a Relocated Individual in accordance with 7.2
above will be permitted to provide legal assistance at every stage of the claim, in accordance with
Rwandan law.

8. Legal assistance at appeal

8.1 Should a Relocated Individual wish to appeal their decision to the court of Rwanda they will be
provided with legal assistance and representation from a legal professional qualified to advise and
represent in matters of asylum, free of charge. This shall include, at least, the preparation of the required
procedural documents and participation in the hearing before the appeal court on behalf of the applicant.

8.2 Rwanda shall provide the legal advisor access to the information provided by the applicant's file upon
the basis of which a decision is or will be made. Rwanda may make an exception where disclosure of
information or sources would jeopardise national security, the security of the organisations or person(s)
providing the information or the security of the person(s) to whom the information relates or where the
investigative interests relating to the examination of applications for international protection by the
competent authorities of Rwanda or the international relations of Rwanda would be compromised.”

225. Although the phrase “legal assistance” is used in the heading to both paragraphs, the text clearly
distinguishes between legal assistance simpliciter (para. 7) and legal assistance and representation (see


-----

Commissioner for Refugees intervening) and other case....

para. 8.1). At the administrative stages of the RSD process the asylum-seeker will be “permitted” to obtain
legal assistance, at their own cost or from a pro bono organisation, but a right to representation (which will
be free) is only assured for any High Court appeal.

226. The assurances in the APNV give rise to two questions:

(1) Does the right to “legal assistance” at the administrative stage of the process mean that a claimant will
be entitled to be accompanied by a lawyer at any interview and/or that their lawyer will be permitted to
make submissions, oral or in writing, to a decision-making body (i.e. the RSDC or MINEMA)?

(2) How accessible in practice will legal assistance and/or representation be?

_(1)          Legal Assistance_

227. There is no reason to doubt the assurance at para. 7.1 of the APNV that RIs will be given information
about how to access legal assistance or to suppose that any obstacles will be put in the way of their doing
so (subject to the issue about its availability). The issue here is what role the lawyers will be able to play
over and above giving advice and assistance with documents.

228. The UNHCR evidence is that current practice is that lawyers are not permitted to accompany
claimants to DGIE interviews or to make any submissions to the RSDC: see paras. 174 and 183 above.
That evidence is consistent with the Asylum System CPIN, paras. 4.8.2-3 of which read (so far as
material):

“4.8.2 During the meeting with the Rwandan Government on 18 January 2022, HO officials asked about
the availability of legal advice and support for asylum seekers during the RSD process. The Director of
Response and Recovery Unit at MINEMA explained:

'Legal assistance is provided for the 2nd level claim [referral to minister for review]. Up to now there have
been no cases of an asylum seeker having a lawyer before the RSDC decision because the initial
decisions are based on analysis of facts and explanations provided by the asylum seeker …'

4.8.3 HO officials asked whether claimants were allowed to have a legal adviser for the first level claim if
they wanted one and the Director explained: 'No, only at the level where a case goes before the court. ...'”

(That passage appears to contain an internal contradiction about whether legal assistance is available for
the appeal to MINEMA; I return to this below.)

229. The GoR's response documents initially appeared to confirm that lawyers would not be entitled to
accompany claimants to interviews or to make any submissions to the RSDC. Para. 22 of the GoR
statement says that legal advice is available during “the administrative phase of the RSD process” but that
legal _representation is only available if an appeal is made to the High Court. Likewise the primary_
response says:

“… the Rwandan RSD process is an administrative process with the possibility of appeal at the High Court.
During the administrative phase of the process lawyers' role is limited: they can assist applicants in
preparing their submissions to the RSDC but they cannot attend the RSDC sessions. At the High Court
level, the RSDC lawyers are permitted to represent the asylum seekers in accordance with the law.”

230. However, a rather different account is given in the GoR supplementary e-mail, which says:

“In accordance with their constitutional right to due process, the relocated individual/asylum seeker has the
right to retain the services of a lawyer at any stage of the asylum process. The legal representative of the
asylum seeker is permitted to attend the interviews at DGIE level and any interview at the RSDC.”

Similarly, Mr Williams says at para. 34 of his witness statement that he was told by the DGIE Director that
RIs would be permitted to be accompanied by a lawyer at their asylum interview. That evidence does not
contradict the GoR's previous position that a claimant's lawyers may not make submissions to the RSDC;
but it is clearly a departure from what it had previously said about attendance at interviews.


-----

Commissioner for Refugees intervening) and other case....

231. The evidence is clear that under the pre-MEDP practice claimants were not permitted to be
accompanied by their lawyers at any interviews: although the supplementary e-mail uses the present
tense, it is only reconcilable with the other evidence if it is taken as stating the GoR's post-MEDP
intentions. I am prepared to proceed on the basis that that is now what is intended, though it is very
unsatisfactory that it is unacknowledged in the evidence that this is a major change in the process. But it is
another matter how easy it will be to introduce a significant change of practice of this kind. There are
bound to be questions both about its administrative implementation and about defining the role that the
lawyer should be permitted to play in an interview at each level. On any view there will be a need for
planning and training of a kind which it is very unlikely has occurred in view of the late emergence of this
evidence and which is not likely to be straightforward.

232. There is some support for that view in an e-mail dated 31 March 2022 from Finnlo Crellin, part of the
Home Office team based in Kigali, reporting a meeting with his counterparts in the Rwandan Ministry of
Justice. This reads (so far as material):

“The main purpose was to talk them through, and get their initial views on, the latest draught of the Asylum
Process NV ... A few key points:

…

     - As expected, 7.2 and 7.3 were the biggest sticking points. They felt that this brought us back to the same
issues we discussed last week, particularly in terms of compatibility with, and potential impacts on, their
immigration system – including the risk of creating 2 asylum systems. I emphasised this was a red line for
us …. Ultimately they agreed to keep the wording as it is but, in Providence's [evidently a member of the
GoR team] words, “we'll see how it works in practice” …”

It is not necessary to understand the nuances: I refer to this passage only to illustrate that the assurances
about legal assistance (the subject of paras. 7.2 and 7.3 of the APNV) were regarded by the relevant GoR
officials as likely to be difficult to implement.

233. The position as regards the appeals to MINEMA is rather different. We are not in this context
concerned (at least generally) with the presence of a lawyer at an interview but with whether they are
entitled to make submissions to the Minister. As to that, the evidence tends to suggest that that was not
permitted pre-MEDP; but para. 5.2 of the APNV appears to confirm that it will be the case in future. I see
no reason to doubt that it is intended that that assurance will be complied with, but again adjusting to a
change of this kind will not be straightforward.

_(2)    Accessibility of legal assistance/representation_

234. It is unrealistic to suppose that RIs will be in a position to pay for legal assistance at the
administrative stage of the RSD process. They will accordingly be dependent on _pro bono assistance._
The GoR says that such assistance will be available from one of two NGOs in Rwanda, the Prison
Fellowship (“PFR”) and the Legal Aid Forum (“LAF”).

235. Mr Bottinick gives evidence about the assistance available from these two NGOs at para. 100 of LB
2. In summary, he says that PFR has only a single legal officer who regularly provides assistance in the
RSD process, as part of a number of other duties: she is not a qualified lawyer, though she has a law
degree. When she is not available, there is another lawyer at PFR who can act as backup, though this is
not part of his regular work. (PFR also has some legal officers who are engaged in the etm project referred
to above but these are not available to work on RSD cases.) As for LAF, this primarily operates in camps
and urban centres outside Kigali. Mr Bottinick says that his colleagues in Kigali have spoken to LAF for the
purpose of his statement and have been told that four of its lawyers have some previous experience in
assisting in the RSD process but that they currently do so very rarely: it routinely refers its RSD cases to
PFR. He says that it was unfortunate that in its assessment visits the Home Office team had met LAF but
not PFR.

236. The GoR's response appears in several places:


-----

Commissioner for Refugees intervening) and other case....

(1)  The GoR statement says, at para. 22:

“The Government of Rwanda … intends to ensure access to legal advice to asylum seekers during the
administrative phase of the RSD process. The Government of Rwanda is building on existing partnership
agreements with partner organizations such as the Legal Aid Forum, the Prison Fellowship and the
Rwanda Bar Association to provide more funding aimed at increasing the partner organizations' capacity to
provide free legal aid to asylum seekers.”

(2) The primary response when addressing para. 100 of LB 2 begins by stating that “LAF informed us that
it currently has 34 Advocates and over 20 legal officers on refugee protection and asylum procedures”.
The rest of the answer is directed to the availability of lawyers to represent RIs in the High Court and is not
relevant for present purposes.

(3) Qu. 6 of the tabular response asks about arrangements for “access to legal advice … at the initial
stage”. The answer reads:

“There is a tripartite agreement between the government of Rwanda, Legal Aid Forum and Prison
Fellowship (nongovernmental organizations) to provide legal services and legal assistance in regards to
refugee protection.

In addition, the ministry of justice has a standing agreement with Rwanda Bar Association to provide legal
aid services free of charge such pro-bono lawyers and free legal advice.”

(4) Qu. 8 of the tabular response refers to UNHCR having suggested that “there is only 1 lawyer who is
adequately trained in Rwanda to assist” and asks if that is correct and for further information about training.
The reference appears to be to para. 100 of LB 2, though if so it is not very accurate. The first part of the
answer refers to numbers at the Rwandan bar generally and to their training. But it continues:

“The Legal Aid Forum has at 36 lawyers trained to provide legal assistance on matters relating to the
asylum process and migration law. The LAF lawyers have received training on Refugee protection and
migration from in-house programs and UNHCR programs.”

That statement differs from what is said in the primary response.

237. I should also refer to para. 8.1 of the PDA, which states:

“During the initial application process RIs can seek legal assistance at their own cost for private advice or
through NGOs during the initial stage. Two NGOs, the Legal Aid Forum and Prison Fellowship, have
confirmed to the GoR they will provide advice at no cost if RIs ask for it at the initial stage. The GoR does
not have a formal agreement with them for this.”

238. The GoR's statements on this aspect are unsatisfactory. It is in my view clear from UNHCR's
evidence that the NGOs with which the GoR says it has a “partnership” – i.e. PFR and LAF – would not
with their present resources be able to provide legal assistance in the administrative stage of the RSD to
any substantial further number of asylum-seekers relocated to Rwanda under the MEDP. The statements
quoted at (2) and (4) above give general (though in fact different) numbers for the lawyers/legal officers
qualified to give advice in this field, but it does not follow that they would be available to advise RIs, and the
effect of Mr Bottinick's evidence is that they are in fact engaged on other work. It is true that the answer to
qu. (6) also refers to a “standing agreement with Rwanda Bar Association”, but no details are given of the
agreement and it is far from clear that the agreement is relevant to legal assistance of the kind with which
we are concerned here. It is also true that in the statement quoted at (1) the GoR speaks of “building on”
its existing partnerships and funding the organisations in question so as to increase their capacity. But that
is extremely unspecific, and it appears from the PDA that there are in fact no formal agreements in place. I
believe I should accept the UNHCR evidence as stating the current position.

239. I turn to the question of legal representation for RIs on any appeal to the High Court, as promised in
para. 8.1 of the APNV. The only concern expressed by UNHCR about this commitment is whether there
are a significant number of qualified lawyers in Rwanda with the expertise to conduct such appeals, given


-----

Commissioner for Refugees intervening) and other case....

that none have so far been brought. Figures supplied by the GoR in the tabular response (see qu. 9) show
that there are over a thousand “senior registered lawyers” in Rwanda and a further 300 “intern advocates”.
Refugee law will have been part of the curriculum in their original training and the Ministry of Justice has
agreed with the Institute of Legal Practice and Development for courses to be run on refugee law.

240. Mr Bottinick does not in LB 3 respond to that evidence. In my view the most that can be said is that
lawyers conducting the first appeals in the High Court are likely to have a steep learning curve, but it does
not follow that they will be unable to give proper representation.

Interpreters

241. The great majority of asylum-seekers relocated to Rwanda under the MEDP will not be fluent in any
of its official languages (English, French and Kinyarwanda). They will therefore need the services of an
interpreter (a) to make their initial claim; (b) in their interview with DGIE; (c) in any subsequent interview
required by the Eligibility Officer or the RSDC; (d) for the purposes of any appeal to the Minister or to the
High Court; and (e) in any dealings with lawyers or other advisers.

242. That need is recognised in the APNV. Para. 9 reads:

“Interpreter

9.1 If a Relocated Individual requires it, an interpreter will be provided, free of charge, whenever the
Relocated Individual meets with a legal representative provided to them free of charge in accordance with
8.1 above or a representative or employee of the Government directly involved in the Relocated
Individual's asylum application.

9.2 All written correspondence and information that a Relocated Individual receives concerning their claim
and the asylum process will be translated by an appropriate interpreter, free of charge, if they require it to
understand.

9.3 A Relocated Individual who has the opportunity to consider a written transcript of their interview will
have the assistance of an interpreter, free of charge, if needed for understanding.”

(I note that para. 9.1 does not provide for access to an interpreter in making the initial claim; but that is
unlikely to matter in practice if the claimant has access to a lawyer for that purpose.)

243. It appears from para. 9 of the PDA that although the GoR has contracted for the provision for RIs of
interpreters in a number of languages, including Arabic, it has not been able to do so for a number of other
languages, including Kurdish, Vietnamese and Albanian (all languages spoken by the Claimants in this
case) and also Pashto (which will be relevant to many Afghan nationals). The PDA says:

“To mitigate this, they have agreed to use the virtual interpretation facilities the Home Office have offered
to them through the Home Office contract with The Big Word (TBW). They have opted for telephone
interpreting, face to face interpreting by way of an online platform and translation services (for the SOPS,
orientation pack and other written documents where necessary). They intend to use TBW only where
necessary and when their current contractors cannot provide a service. This was set up ahead of the
scheduled charter flight on 14/6 and has been tested to ensure the service is functioning. Longer term,
GoR will look to negotiate their own separate contract with the TBW with assistance from the dedicated HO
team.”

It appears from Mr Williams' witness statement that this difficulty only emerged in a meeting with the DGIE
Director on 26 May.

244. In para. 35 of LB 3 Mr Bottinick expresses concerns about this arrangement, on the basis that not all
officials involved in the process speak fluent English. An interpreter based in Rwanda could assist such
officials by using Kinyarwanda where necessary, and interpreting anything said in Kinyarwanda to the
asylum-seeker, which a remote interpreter could not do. I understand the concern, and remote
interpretation is no doubt sub-optimal; but there is no reason to suppose that a DGIE official who was not
fluent in English would be asked to conduct an interview in which English was the medium of interpretation


-----

Commissioner for Refugees intervening) and other case....

This problem by itself may not undermine the fairness or effectiveness of the system, but it reinforces the
need for those conducting an interview to have the skills and experience to cope professionally with
difficulties of this kind.

Training

245. It is obvious, and undisputed, that officials making asylum decisions, or otherwise contributing to the
process, need to be properly trained. That is recognised in the APNV, para. 4.2 of which reads:

“Asylum decisions will be taken by decision-makers who are appropriately trained to take a decision on an
asylum claim in accordance with the Refugee Convention and are able to seek advice from senior officials
or external experts if necessary.”

However, there are two particular reasons why proper training is essential in the circumstances of this
case.

246. First, as noted above, Rwanda has comparatively little experience of assessing and determining
individual asylum claims, and still less claims from claimants with the nationalities that are likely to be
typical of those relocated under the MEDP. On its own figures the total number of claims determined by
the RSDC between 2019 and June 2022 is 152, of whom 115 were from DRC and Burundi, and another 20
from Eritrea. It has determined no claims requiring consideration of conditions in the countries from which
the Claimants originate – that is, Syria, Iraq, Iran (most of these being ethnic Kurds), Vietnam, Sudan or
Albania. These Claimants are likely to be broadly representative of the cohort of asylum-seekers liable to
be relocated under the MEDP, except that they include no-one from Afghanistan (from which the RSDC
has so far determined only one claim). A table exhibited to LB 3 gives figures, on the basis of the
information available to the UNHCR (which it accepts may be incomplete), of all cases in the process over
the relevant period, including those not yet determined: although that shows a handful of cases from Syria,
Sudan and Afghanistan, the proportionate picture is the same. The RSDC, together with DGIE and the
Eligibility Officers in so far as their work feeds into its decisions, will be effectively starting from scratch in
acquiring an understanding of the situations in those countries.

247. Second, the system in place at the date of the conclusion of the MEDC had the serious deficiencies
identified in the earlier discussion, which need to be addressed by effective training.

248. In those circumstances particularly thorough and effective training is required in order that the
relevant institutions and individuals can deal properly with RIs. Para. 18 (i) of the UNHCR Note reads:

“There is a need for an objective assessment of the fairness and efficiency of the asylum procedures,
followed by a range of capacity development interventions including, but not limited to, sustained capacity
building and training for all actors working in the Rwandan national asylum system [my emphasis].”

I agree.

249. The question of the current level of training of those operating the system is addressed at paras. 8998 of LB 2. Mr Bottinick summarises his evidence in para. 89 as follows:

“UNHCR has observed serious shortcomings in knowledge and training regarding RSD among relevant
officials at all levels. UNHCR considers that this lack of training gives rise to a serious risk that refugees
will be refused recognition by the Rwandan Government and refouled.”

He goes on to say that UNHCR provided a three-day training course to officials in June 2017 but that,
although it had repeatedly offered further training, the offers had not been taken up until December 2021
when it was invited to co-facilitate, together with MINEMA, the Rwanda Law Reform Committee and the
University of Rwanda, a workshop for DGIE and RSDC staff and officials. The workshop was intended to
last four and a half days but in fact lasted just over three because of the unavailability of the intended
attendees. Paras. 93-97 of LB 2 read as follows:

“93. The training was attended by only 15 participants. Out of 11 RSDC members at the time, eight
attended but even some of those could only attend partially because of their conflicting professional


-----

Commissioner for Refugees intervening) and other case....

schedules and ministerial commitments (and one attended for only two days). The RSDC chair (who was
new to the process at the time and had not yet attended any RSD-related adjudication) and secretary
missed at least the first day of the training which covered basic principles of refugee law.

94. At the time of the training, most RSDC members were new, had no prior exposure to RSD and had not
attended RSDC deliberations. One of the officials remarked that he did not understand why he was
required to undertake RSD given that his departmental role was not connected to asylum.

95. The training was targeted at an extremely basic level. It included, in the main, general principles of
refugee law, in addition to brief and basic training on assessing individual claims and interviewing
techniques. My colleagues felt that the basic knowledge of the attendees did not allow them to cover
crucial areas such as how to deal with claims based on membership of a particular social group.

96. The participants' lack of relevant knowledge and skills was particularly apparent during a simulation of
RSDC interviews and decision making. Observations from UNHCR's trainers noted that the participants
lacked interviews skills and had very limited or no understanding of how to assess refugee status. In a
simulation involving a husband and wife, the 'couple' were interviewed together and the husband was
allowed to answer for the wife. In addition, there was no opportunity for the 'asylum seeker' to express
relevant gender-based violence related elements of her claim. It was also noted that elaborate leading
questions were asked by participants and that the 'asylum seeker' was not given an opportunity to respond
in full to questions, nor were they alerted to adverse credibility points. When making their assessments of
the cases, participants were unable to demonstrate knowledge of how to assess credibility and COI; or of
key concepts in refugee law. This is not surprising given that the participants are senior civil servants with
no background in RSD.

97. In UNHCR's view, this short (and truncated) one-off workshop cannot be considered adequate training
to ensure fair RSD decision making, especially for training participants with little or no prior knowledge and
experience of refugee law. RSDC members still at the end of the training lacked by some distance the
requisite knowledge and skills to make fair, reliable RSC decisions. RSDC members require significant
further in-depth on-the-job training and shadowing of appropriate procedures. However, in UNHCR's view,
while that is necessary to rectify some of the problems in the RSDC process, it would be far from sufficient:
the non-specialist composition of the RSDC is inimical to fair, reliable RSD decision-making. UNHCR was
further concerned by attitudes expressed by Rwandan authorities during this training that DGIE are within
their rights to deny access to its territory or to RSDC procedures if they consider the profile of an individual
applicant unpalatable, including on unspecified grounds of national security. The Rwandan staff and
officials present at UNHCR's December 2021 training did not appear to consider such 'screened out'
persons as asylum seekers or consider that their deportation would constitute refoulement.”

He says at para. 91 that he is unaware of any other outside body providing training for participants in the
process.

250. The GoR's response to that evidence appears in a number of places and cannot readily be
summarised.

251. I start with the GoR statement. Para. 23 says:

“The Government of Rwanda has … taken measures to build the expertise of persons involved in
processing the claims of asylum seekers. The Rwanda Institute of Legal Practice and Development (ILPD)
will be providing bloc courses, periodic trainings and workshops on refugee law and other related laws to
Eligibility Officers, RSDC Members, lawyers, and high court judges.”

252. The primary GoR response cross-refers on this aspect to the tabular response. This has several
answers referring to training.

253. First, qu. 4 asked what training “interviewing officers” – i.e. the DGIE officers who conduct the asylum
interview – receive. The answer is:


-----

Commissioner for Refugees intervening) and other case....

“The interviewing officers at DGIE have received different trainings on international protection of refugees,
international law of refugees, rights-based approach to migration law, national laws relating to refugees
and migrants, interview skills, etc. - These various trainings were provided through:

1. Rwanda Institute of legal practice and development (ILPD).

2. The International Institute of Humanitarian Law/San Remo, Italy.”

254. Second, qu. 7 asked various questions about the RSD Committee, including what training they have
received. The answer is:

“They have received training on refugee status determination. … In addition to the periodic
training/workshops on international refugee law and asylum process offered by UNHCR (the latest
trainings by UNHCR were offered in 2018 and 2021). UNHCR also offered training to RSDC members at
International Institute of Humanitarian Law/San Remo, Italy. The members also bring on board
complementary expertise from their respective specialized institutions. The diverse expertise which is
uniquely relevant to the work the committee ranges from human rights perspective, diplomacy & global
trends, refugee management, security and migration matters, etc. So, RSDC is purposely comprised of
members with varying knowledge and expertise that enables objective consideration of asylum claims.”

255. Third, qu. 26 asked if there was “any record of how many people attended the UNHCR training for
the RSD”. The answer is:

“Two Eligibility Officers and one RSDC members were trained at San-Remo. 9 out of the 11 RSDC
members participated in the training co-organized by MINEMA and UNHCR in December 2021 and 10 out
of 11 in the one organized by MINEMA in December 2018. Two RSD members completed online training in
eligibility and RSD process. These training normally serves to harmonize on principles that guide the
decision making. In addition, each of the RSDC members has completed training in her/his area (human
right, humanitarian protection, international justice, migration, socio economic inclusion, etc) that build
analytical skills for the member to contribute efficiently during the committee sessions.”

256. The primary GoR response adds two further points. First, it disputes Mr Bottinick's account that not
everyone attended the whole of the December 2021 workshop, saying that “the figures provided [in the
tabular response] are accurate to our knowledge”. Second, the response to para. 144 of Bottinick 2 says:

“A training for RSD members is also being organized and shall be facilitated by local learning institutions
(University of Rwanda and Institute of Legal Practice and Development) but also by institutions concerned
by the RSD process including MINEMA, MINIJUST, NCHR, DGIE, MINAFFET.”

257. Finally, Mr Williams says at para. 44 of his witness statement, amplifying what appears in the relevant
part of the PDA:

“The DGIE Director informed me that all DGIE Immigration Officers are trained on asylum and international
protection, including how to register asylum applications, conduct asylum interviews, and write reports for
the Refugee Status Determination Committee (RSDC). The Director informed me on 17 June 2022 that
DGIE Immigration Officers undergo a minimum of six months training at a dedicated training college
followed by on-the-job training once they commence their duties. The Director also told me on 17 June that
most of the training is in-house but DGIE Immigration Officers have received training from international
organisations including the International Organization for Migration (IOM) and international partner
countries.”

258. The Secretary of State's evidence is responded to in para. 34 of LB 3. I need not reproduce it in full.
In short:

(1) Mr Bottinick maintains his evidence about the partial attendance at the UNHCR workshop in December
2021.

(2) He identifies “San Remo”, as referred to in the tabular response, as the International Institute of
Humanitarian Law in San Remo. He says that he has established from enquiries with the Institute that only


-----

Commissioner for Refugees intervening) and other case....

four individuals from the DGIE had attended training there between 2017-2022, of whom only one attended
training in refugee law.

(3) He says that the Rwandan Institute of Legal Practice and Development referred to in the GoR
Statement and the tabular response does not at present offer training or programmes on refugee law and
that the University of Rwanda does not offer a module on refugee law.

(4) He exhibits an email from the International Organisation for Migration referred to in Mr Williams'
evidence confirming that it has never provided any training on refugee determination in Rwanda.

259. In my judgment, Mr Bottinick's evidence raises a clear case to answer that the level of training made
available to the key players in the asylum process – the DGIE officials who conduct the interviews, the
Eligibility Officers, the members of the RSDC, the MINEMA Minister or the officials who advise him or her
on appeals – is not sufficient to equip them to perform their functions properly. I do not believe that the
Secretary of State's evidence, based on the information obtained from the GoR, provides a satisfactory
answer. In particular:

     - As regards the training of DGIE officials, the answer in the tabular response is at a very general level and
is contradicted by Mr Bottinick, on the basis of the enquiries which he specifies. As for Mr Williams'
evidence, what he was told by the Director General was in the most general terms and unsupported by any
kind of documentary evidence or records: on the one point where he is more specific (training by the IoM)
his evidence is contradicted by the e-mail produced by Mr Bottinick.

    - As regards members of the RSDC, I take the GoR's point that many of them have backgrounds which
may be relevant to some aspects of the questions that they have to determine. But that must be
supplemented by a sound training in the basics of refugee law, together with support from specialist
advisers (presumably the Eligibility Officers) where points of difficulty arise. The GoR's references to
courses and workshops from outside bodies are in very general terms and are also to some extent
contradicted by the evidence from or about the bodies in question obtained by Mr Bottinick. As regards
UNHCR's own training, his evidence about the problems experienced in the December 2021 workshop is
compelling.

260. It is not ideal that this important point should turn on the Court's assessment of hearsay evidence
from the GoR produced at short notice in response to the evidence of Mr Bottinick. But in truth the nature
and extent of the training of officials involved in the asylum process should have been assessed in depth,
with reference to documents and records so far as available, as part of the investigations carried out when
the MEDP was still in gestation.

CONCLUSION ON THE ADEQUACY OF THE RWANDAN ASYLUM SYSTEM

261. I start by acknowledging that there is nothing in the evidence that would justify the conclusion that the
GoR has entered into the commitments in the MoU and the APNV in bad faith. There is no reason to
suppose that it does not wish to ensure that RIs have their asylum claims determined fairly and effectively.
But aspiration and reality do not necessarily coincide. As we have seen, the RSD process is a recent
creation and it has so far had little experience of dealing with asylum-seekers with the characteristics of
those liable to be relocated under the MEDP. The UNHCR evidence in my view clearly shows that there
are important respects in which it has not so far reliably operated to international standards. It is its case,
and the Claimants', that even if there is a will to make the necessary changes they cannot be achieved in
the short term and certainly have not been achieved yet. At paras. 143-144 of LB 2 Mr Bottinick says:

“143. Rwanda's serious capacity issues cannot be addressed within a short space of time.  …

144. Moreover, at the time of making this statement, UNHCR is unaware of any steps being initiated that
might, after a sustained period of capacity building, eventually permit certain of the commitments in the
Notes Verbales and MOU to be fulfilled. UNHCR is not, for example, aware of interpreters, lawyers or
decision makers being hired or trained by the Rwandan Government at present.”


-----

Commissioner for Refugees intervening) and other case....

I should say that when Mr Bottinick refers to “capacity” it is clear from the context that he is not referring
primarily to ability to cope with numbers but to skills and experience more generally. It is not, therefore, an
answer to say that the GoR can decline to accept more RIs than the RSD process can cope with in the
early stages of the MEDP.

262. The essential question is thus to my mind whether the changes necessary to ensure compliance with
the GoR's assurances had been, or in any event would be, implemented before relocations under the
MEDP began to take place: that was of course initially intended to be on 14 June 2022 (only two months
after the conclusion of the MEDP), although as I have said the position should now be judged as at the
dates of the hearing in the Divisional Court.

263. I have not found it entirely straightforward to answer that question. The evidence is not as complete
as could be wished; and, as already noted, we have not had the advantage of the kind of detailed
examination, with the benefit of expert evidence and cross-examination, that would have been possible in
the FTT if the Secretary of State had not certified the Claimants' human rights claims. In the end, however,
I have reached the conclusion that the Rwandan system for refugee status determination was not, as at the
relevant date, reliably fair and effective.

264. In reaching that conclusion I have taken into account the totality of the defects identified in the
discussion above. Those which have weighed with me particularly, not least because they are not clearly
addressed in the APNV, are:

(1) the evidence of the way in which asylum interviews are conducted by DGIE – see paras. 164-166
above;

(2) the absence of any opportunity for a claimant to present their case to the RSDC through a lawyer –
para. 189;

(3) the evidence that the RSDC does not have sufficient skills and experience to make reliable decisions in
claims of the kind with which we are concerned; the evidence in question includes not only its character
and composition but also the evidence about its conduct of interviews, the limited support available to it
and the evidence of apparently aberrant outcomes – see paras. 181-201 and 205-206;

(4) the evidence that the NGOs who it is said can provide legal assistance to RIs during the administrative
stage of the RSD are unlikely to have sufficient capacity to do so – see paras. 234-238;

(5) the fact that the appeal process to the High Court is wholly untested, coupled with grounds for concern
about whether the culture of the Rwandan judiciary will mean that judges are reluctant to reverse the
decisions of the Minister and the RSDC – see paras. 218-221.

But I repeat that the defects of the system must be regarded as a whole, and there are several other areas
of concern identified above.

265. Those problems could be resolved by making further changes to the process (e.g. allowing lawyers to
make representations to the RSDC); by “capacity building” (e.g. as regards provision of legal assistance);
and, importantly, by effective training of all those involved in the process (as noted at several points
above). But the evidence is that those steps have not yet been taken or in any event not to the extent
necessary to ensure the present fairness and reliability of the system: see in particular paras. 245-260.

266. Like the Master of the Rolls (see his Issues 8 and 9), I believe that that conclusion means that it is
unnecessary to consider separately the issues relating to the adequacy of the inquiries conducted by the
Secretary of State, whether by reference to Ilias or to Tameside. I would only make two observations.

267. On the one hand, I would accept that this is not a case where the Home Office was merely going
through the motions of assessing the adequacy of the Rwandan asylum system. There were evidently
dedicated civil servants genuinely trying to establish how the RSD process worked and to obtain
assurances that addressed the perceived problems.


-----

Commissioner for Refugees intervening) and other case....

268. On the other hand, however, perhaps as the result of the pressure of the timetable to which they
were required to work, I believe that the officials in question were too ready to accept assurances which
were unparticularised or unevidenced or the details of which were unexplored: the late emergence of the
problem about interpreters is an illustration of this. We were referred by Mr Husain to a review of the
Rwanda CPINs which was undertaken in July 2022 for the Independent Advisory Group on Country
Information (“IAGCI”). IAGCI acts on the instructions of the Independent Chief Inspector of Borders and
Immigration, to whom it provides advice to the Chief Inspector of the UK Border Agency to allow him to
[discharge his obligation under section 48 (2) (j) of the UK Borders Act 2007. The researcher responsible](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y0HC-00000-00&context=1519360)
for the review criticised various aspects of the way in which the Asylum System CPIN was prepared,
including “very limited critical information on the Rwandan asylum system” and “fundamental gaps of
information and unanswered questions with regards to procedural practicalities and implications”, together
with more specific methodological criticisms of the conduct of the interviews contained in the Annex A
CPIN. As the Divisional Court pointed out at para. 59 of its judgment, and as Sir James emphasised in his
oral submissions, the Chief Inspector has not himself made any recommendations, and it is not known
whether or to what extent he will endorse those criticisms. But I note that they are consistent with my own
conclusion. I should also say in this connection that I believe that it is unfortunate that officials did not
engage with UNHCR on their first visit to Rwanda in January 2022. Their initial intention was to do so; but
it seems that, for reasons that are unclear, they did not receive the necessary clearance from the Secretary
of State.

269. I have not so far addressed the reasoning of the Divisional Court. It says, at paras. 64-66:

“64. In the present case we consider the Home Secretary is entitled to rely on the assurances contained in
the MOU and Notes Verbales, for the following reasons. The United Kingdom and the Republic of Rwanda
have a well-established relationship. This is explained in the witness statement of Simon Mustard, the
Director, Africa (East and Central) at the Foreign, Commonwealth and Development Office. This has
comprised a development partnership set out in various agreements (referred to as Development
Partnership Agreements) since 1998. The relationship is kept under review. In 2012 it was suspended by
the United Kingdom government in response to Rwanda's involvement in the so-called 'M23 Rebellion' in
the Democratic Republic of Congo, and in 2014 the relationship was further reviewed in response to the
assassination in South Africa of a Rwandan dissident. Since then, the United Kingdom has continued to
provide Rwanda with financial aid, but this has been tied to specific activities. Thus, while there is a
significant history of the two governments working together, the Rwandan government has reason to know
that the United Kingdom government places importance on Rwanda's compliance in good faith with the
terms on which the relationship is conducted.

65. The terms of the MOU and Notes Verbales are specific and detailed. The obligations that Rwanda has
undertaken are clear. All, in one sense or another, concern Rwanda's compliance with obligations it
already accepts as a signatory to the Refugee Convention. The Claimants have placed particular
emphasis on whether the Rwandan asylum system will have the capacity to handle asylum claims made by
those who are transferred under the terms of MOU. It is a fair point that, to date, the number of claims
handled by the Rwandan asylum system has been small. It is also fair to point out, as Mr Bottinick has,
that it will take time and resources to develop the capacity of the Rwandan asylum system. However,
significant resources are to be provided under the MEDP, and by paragraph 3.3 of the MOU the number of
persons that will be transferred will depend on the consent of the Rwandan government, taking account of
its capacity to deal with persons in the way required under the MOU and the Notes Verbales. The MOU
also contains monitoring mechanisms in the form of the Joint Committee (paragraph 21 of the MOU) and
the Monitoring Committee (paragraph 15 of the MOU). For now, at least, there is no reason to believe that
these bodies will not prove to be effective. Lastly, the MOU makes provision for significant financial
assistance to Rwanda. That is a clear and significant incentive towards compliance with the terms of the
arrangement.

66. Moreover, Mr Mustard explains that HM Government is satisfied that Rwanda will honour its
obligations. At paragraph 20 of his statement, he says this:


-----

Commissioner for Refugees intervening) and other case....

'The British High Commission in Kigali led initial conversations with the [Government of Rwanda] regarding
the [MEDP] and participated in negotiations in support of the Home Office. Since these negotiations began,
there has been a renewed focus on our bilateral relationship with an increase in contact at an official and
ministerial level. Prior to signing the agreement, Home Office officials visited the Rwanda on many
occasions, meeting government and non-governmental interlocutors, and carried out further discussions
virtually. The Rwandan Permanent Secretary to the Ministry of Foreign Affairs also led a delegation to
London for further talks. These negotiations have been conducted transparently and in good faith
throughout. In light of the considerations described in this witness statement, and the manner in which the
negotiations [with] our Rwandan counterparts were conducted, we are confident that Rwanda will honour
its commitments under the MEDP.'

We consider that we could go behind this opinion only if there were compelling evidence to the contrary.
We do not consider such evidence exists.”

270. As discussed at paras. 128-129 above, it seems from that passage that the Divisional Court erred by
approaching its task in this part of its judgment as one of review rather than seeking to reach its own
conclusion. But even if I am wrong about that, I do not believe that its reasoning can be supported. It did
not seek to engage with the details of UNHCR's criticisms of the RSD process. As I read it, the principal
reason why it thought that this was unnecessary was the weight that it attached to Mr Mustard's
assessment, representing the view of the UK Government, that the GoR would honour its commitments
under the MEDP. As to that, I would accept that great weight should indeed be given to the Government's
assessment that the GoR negotiated the MEDP in good faith and with a genuine willingness to comply with
its obligations under it, for the reasons which the Court gives at paras. 64-65 of its judgment. I agree that
there is no reason to doubt the genuineness of the GoR's intentions: it is for that reason that I have found
that there is no risk of RIs being denied access to the RSD process (see para. 155 above). But the real
issue here is not the good faith of the GoR at the political level but its ability to deliver on its assurances in
the light of the present state of the Rwandan asylum system.

271. The Divisional Court does in fact in para. 65 acknowledge that “it will take time and resources to
develop the capacity of the Rwandan asylum system”; but it believes that that concern is sufficiently
answered by the facts that significant resources are to be provided to the GoR under the MEDP and that it
has the right to control the numbers of RIs admitted so that they do not exceed the capacity of the RSD
process at any given time. However, the provision of resources does not mean that the problems in the
Rwandan system can be resolved in the immediate term; and even if the flow of RIs is restricted for the
time being in order for improvements to take effect that does not justify the denial of a fair and effective
asylum system to the earlier arrivals.

272. In short, the relocation of asylum-seekers to Rwanda under the MEDP would involve their claims
being determined under a system which, on the evidence, has up to now had serious deficiencies, and at
the date of the hearing in the Divisional Court those deficiencies had not been corrected and were not likely
to be in the short term.

RISK OF REFOULEMENT

273. The result of my conclusion in the preceding section is that there are substantial grounds for believing
that there is a real risk that the asylum claims of RIs may be wrongly refused. On the face of it, it would
appear to follow that there was a real risk of them being refouled. Where an asylum-seeker's claim is
rejected the country in question will typically require them to leave the country (in the absence of any other
basis on which they might claim residence), and since they will have been found to be at no risk in their
country of origin, there is no reason why they should not be returned there; and even if they are in the first
instance returned to some other country that does not exclude the possibility of indirect refoulement. The
reason why the ECtHR in Ilias insisted on the need to establish that there was an adequate asylum system
in the country of return is that the existence of such a system is regarded as an essential protection against
the risk of refoulement.


-----

Commissioner for Refugees intervening) and other case....

274. It may be, however, that the Secretary of State wishes to submit that a finding that the Rwandan
asylum system is inadequate would not in the circumstances of this case mean that there is a real risk of
refoulement. At the start of the part of her skeleton argument dealing with the safety of Rwanda she
advances five “overarching submissions”. The fifth, which appears at para. 8 of the skeleton, is that the
Court should not seek to interpret Rwandan asylum law or predict how it might apply in particular cases
because it was sufficient to rely on para. 9.1.1 of the MoU. The paragraph continues:

“Furthermore, even if some deficiency in Rwandan asylum law were identified ... it would not give rise to a
risk of refoulement or Article 3 ill treatment unless there were to be evidence of intention to send the
asylum seeker back to their country of origin”.

A footnote reads:

“Rwanda has no returns agreement with any of the countries in question ... The MOU provides, at para
10.3, for relocated individuals to apply for residence even if refused asylum.”

275. The statements made in the footnote are referenced to passages in the witness statements of Mr
Williams and Mr Armstrong. It is sufficient to refer to the latter. Mr Armstrong says, at para. 85:

“The statement of Chris Williams sets out what he was told by DGIE officials about what would happen to
relocated individuals who are refused asylum. Senior officials from DGIE in Rwanda confirmed that if an
individual who was relocated to Rwanda under the MEDP had their asylum claim refused and all their
appeal rights were exhausted, they would be eligible to be issued a Resident Card. They said that they
envisaged that all relocated individuals would be permitted to remain in Rwanda and that no relocated
individuals would be forcibly returned to their country of origin. They also explained that the Government of
Rwanda did not have returns agreements or arrangements in place with any country with the exception of
neighbouring countries.”

The statements there attributed to the DGIE officials are consistent with statements made in the GoR
statement (see para. 5) and the tabular response (answers to qus. (12) and (22)).

276. Para. 10.3 of the MoU, also referenced in the footnote, reads:

“10.3 For those Relocated Individuals who are neither recognised as refugees nor to have protection need
in accordance with paragraph 10.2, Rwanda will:

10.3.1 offer an opportunity for the Relocated Individual to apply for permission to remain in Rwanda on any
other basis in accordance with its domestic immigration laws and ensure the Relocated Individual is
provided with the relevant information needed to make such an application;

10.3.2 provide adequate support and accommodation for the Relocated Individual's health and security
until such a time as their status is regularised or they leave or are removed from Rwanda.”

Reference should also, I think, be made to para. 10.4, which reads:

“For those Relocated Individuals who are neither recognised as refugees nor to have a protection need or
other basis upon which to remain in Rwanda, Rwanda will only remove such a person to a country in which
they have a right to reside. If there is no prospect of such removal occurring for any reason Rwanda will
regularise that person's immigration status in Rwanda.”

277. Although the submission which I have quoted from the skeleton argument is ostensibly addressed
only to a situation where there is “some deficiency in Rwandan asylum law”, the logic of the point might be
thought to apply to a situation where the asylum system as a whole was inadequate and thus liable to
produce wrong outcomes: that is, it might be said that its inadequacy did not matter “unless there were to
be evidence of intention to send the asylum seeker back to their country of origin”.

278. The issue was not addressed by the Divisional Court, since in the light of its conclusion on the
adequacy of the Rwandan asylum system it did not arise.


-----

Commissioner for Refugees intervening) and other case....

279. The submission in question was not developed in the hearing before us. In his opening submissions
Mr Husain referred to it but only to contend that the point was not open to the Secretary of State because it
had not been pleaded in a Respondent's Notice. He said that it was in any event bad but that he would
address it in his reply if necessary. In the event, Sir James Eadie made no oral submissions on this point
and Mr Husain did not revert to it.

280. Mr Husain is right to say that this submission should have been raised in a Respondent's Notice.
With some hesitation, however, I think that I should consider it, although in the absence of oral argument I
can and should only deal with it briefly.

281. I start by setting out what is said in the GoR statement and the tabular response as referred to above:

(1) Para. 5 of the GoR statement reads:

“Practice shows that a number of asylum applications are made by individuals looking for the right to work
and reside in Rwanda and not necessarily in need of international protection under the Refugee
Convention and the national laws relating to refugees. As mentioned above, the RSD process is
nonadversarial and actively seeks provide durable solutions to all individuals claiming asylum. To this
effect, it is the Government of Rwanda's policy to not conduct deportations of persons whose asylum
claims are rejected. The DGIE endeavors to provide legal residence to persons residing in Rwanda. A
significant portion of asylum applicants are granted legal residence in Rwanda on other grounds such as
work/business permits and dependent/relatives permits.”

(2) Qu.12 in the tabular response asks how many of those who are refused asylum are forcibly removed
from Rwanda. The answer is:

“None. Rwanda has a policy of no deportation. Most of those whose refugee status are not accepted are
granted legal residence permit on other grounds. Others leave voluntarily.”

(3) Qu. 22 of the tabular response reads:

“Relocated individuals who are refused asylum and are not grated another leave status in Rwanda. We
understand that at present there are no returns agreements with the main countries of origin for those likely
to come to you under the arrangements. Do you intend to reach out to these countries to negotiate these
and if not would you otherwise remove these individuals and if so how?”

The answer is:

“There are no intentions to conclude return agreements with countries at the moment. the relocated
individuals will be issued with resident permits which will allow them to have resident travel document in
case they want to return to their country of origin: a resident travel document issued to a foreigner legally
residing in Rwanda who is not a refugee and who is unable to acquire any other travel document. it should
be noted that under this arrangement and in respect of domestic laws and all other international
conventions on refugees and human rights that Rwanda has signed, no relocated individual will be
removed or sent back to a country where he/she may face danger or persecution. If any individual needs to
be removed from the country, formal consultations through the available diplomatic channels will be done
to effect the removal.”

282. In my view none of those statements can be treated as a reliable assurance that an RI whose asylum
claim is refused will be permitted to remain in Rwanda and enjoy basic rights equivalent to those granted
by the Refugee Convention. I would make three points.

283. First, as to the possibility of the RI being granted legal residence on other grounds, it is –
unsurprisingly – not said that this occurs in every case (the tabular response says “most”, but the GoR
statement says “a significant portion”). It is in fact easy to see how the grant of “work/business permits”
and “dependent/relatives permits” may be appropriate for migrants from neighbouring countries, who have
historically constituted the great majority of asylum-seekers in Rwanda; but the circumstances of RIs will


-----

Commissioner for Refugees intervening) and other case....

be wholly different. Whether or not some RIs may be granted legal residence on another basis, the
question remains of what will happen to those who are not, who are likely to be the great majority.

284. Second, para. 10.3.2 refers in terms to the removal of RIs whose asylum claims fail and who do not
qualify for a right to remain on any other basis. Para. 10.4 provides that they will only be removed to a
country where they have the right to reside, but that would of course include their country of origin, in which
the GoR would (ex hypothesi wrongly) have decided that they did not face a risk of persecution or other illtreatment.

285. Third, while there is no reason to doubt the statement that Rwanda has at present no return
agreements with the countries of which RIs are likely to be nationals, and no intention “at the moment” to
conclude any such agreement, that falls well short of a guarantee that it will not do so in future. In any
event direct return is not the only way that refoulement can occur, as the cases referred to at para. 146
illustrate.

286. In short, even if the Secretary of State is seeking to advance the (prima facie surprising) argument
that it does not matter if Rwanda's asylum system is inadequate because RIs whose claims are wrongly
refused will in every case be allowed to stay I would not accept that argument.

ARTICLE 3 RISKS OTHER THAN REFOULEMENT

287. As noted above, the Claimants also allege that the repressive nature of the Rwandan regime means
that asylum-seekers and refugees will be at risk of inhuman and degrading treatment within the meaning of
article 3 if they engage in protests against or other criticisms of the GoR. The Master of the Rolls sets out
the nature of the case in rather more detail at para. 103 of his judgment.

288. This aspect of the case is addressed in the judgment of the Divisional Court at paras. 73-77 under
the heading “Conditions in Rwanda generally”. It acknowledges that there is clear evidence that the GoR
is intolerant of dissent; that there are restrictions on the right of peaceful assembly, freedom of the press
and freedom of speech; and that political opponents have been detained in unofficial detention centres and
have been subjected to torture and article 3 ill-treatment short of torture. However, it concludes that there
is no real risk that persons returned under the MEDP would be ill-treated even if they expressed dissent or
protest (whether about their own treatment or on other issues). Para. 77 concludes:

“… [T]he Claimants' submission is speculative. It does not rest on any evidence of any presently-held
opinion. There is no suggestion that any of the individual Claimants would be required to conceal
presently-held political or other views. The Claimants' submission also assumes that the response of the
Rwandan authorities to any opinion that may in future be held by any transferred person would (or might)
involve article 3 ill-treatment. Given that the person concerned would have been transferred under the
terms of the MEDP that possibility is not a real risk. It is to be expected that the treatment to be afforded to
those transferred will be kept under the review by the Monitoring Committee and the Joint Committee
(each established under the MOU). Further, the advantages that accrue to the Rwandan authorities from
the MEDP provide a real incentive against any mis-treatment (whether or not reaching the standard of
article 3 ill-treatment) of any transferred person.”

289. In the light of the conclusion that I have reached on the refoulement issue I do not need to decide
whether the Divisional Court's conclusion was correct, and I prefer not to do so since we heard only very
limited oral submissions about it. I confine myself to two observations.

290. First, I respectfully doubt whether it is relevant that the Claimants themselves have not been shown
to hold any opinions of a kind which are likely to attract adverse attention from the GoR.[6] We are, as I
have said, concerned with a generic challenge, and the question must be whether there is a real risk that
RIs generally may suffer serious ill-treatment in Rwanda if they engage in any protest or express dissent.

291. Second, while I see the force of the point made by the Divisional Court that the GoR is likely to be
very chary about any ill-treatment of RIs, it is right to note that documents produced by the Secretary of
State show officials expressing concern about this very aspect: an FCDO official reviewing the draft CPIN


-----

Commissioner for Refugees intervening) and other case....

noted that asylum-seekers “would need to be 100% compliant and subservient to very stringent top-down
rules in Rwanda”.

292. I note the Master of the Rolls' observation at para. 106 above that it would have been better if the
Divisional Court had dealt with this aspect as an undifferentiated part of the Soering test. For myself, I see
some advantages in analysing it separately because the nature of the article 3 risk is different. But I agree
that they are not wholly distinct. The nature of the Rwandan government is a relevant background
consideration in considering some aspects of the RSD process.

CONCLUSION ON THE SAFETY OF RWANDA ISSUE

293. For the reasons given above, I believe that the evidence before the Divisional Court established that
there were substantial grounds to believe that asylum-seekers relocated to Rwanda under the MEDP were
at real risk of refoulement, and that accordingly such relocation would constitute a breach of article 3 of the
ECHR and contravene section 6 of the 1998 Act.

294. I have thus reached the same conclusion as the Master of the Rolls about the overall safety of
Rwanda issue. The Lord Chief Justice has reached the opposite conclusion. It will be sufficiently apparent
from my reasoning above why I respectfully take a different view from him.

295. I have not found it necessary to address separately each of the eleven issues identified by the Master
of the Rolls under this heading, though I have in substance covered most of them in my analysis.
However, I should say something more about his Issues 10 and 11.

ISSUE 10: GILLICK

296. The effect of my conclusions thus far is that a decision to remove an asylum-seeker to Rwanda would
be unlawful because it would involve a breach of their article 3 rights. It follows that a published policy
which positively authorised or approved such removals would also be unlawful: the relevant principles
derive from the decision of the House of Lords in Gillick v West Norfolk and Wisbech Area Health Authority

[1986] AC 112 and have recently been restated by the Supreme Court in R (A) v Secretary of State for the
_Home Department_ _[2021] UKSC 37, [2021] 1 WLR 3931._

297. The question then is whether the Secretary of State has promulgated such a policy. On 9 May 2022
she published version 6 of Guidance to case-workers headed “Inadmissibility: safe third country cases”
(“the Inadmissibility Guidance”).[7] As regards relocation to Rwanda, the Guidance says:

“If a case assessed as suitable for inadmissibility action appears to stand a greater chance of being
promptly removed if referred to Rwanda (a country with which the UK has a Migration and Economic
Development Partnership (MEDP), rather than to the country to which they have a connection, TCU should
consider referring the case to Rwanda. An asylum claimant may be eligible for removal to Rwanda if their
claim is inadmissible under this policy and (a) that claimant's journey to the UK can be described as having
been dangerous and (b) was made on or after 1 January 2022. A dangerous journey is one able or likely to
cause harm or injury.

...

Those progressed for consideration for relocation to Rwanda under the MEDP will be taken from the
detained and non-detained cohort and be identified in line with processing capacity. Priority will be given to
those who arrived in the UK after 9 May 2022.

...

Decision makers must take into account country information of the potential country/countries to where
removal may occur in deciding whether referral into a particular route is appropriate in the particular
circumstances of that claimant.”

Country information relating to Rwanda was published on the same day in the form of the CPINs identified
at para. 139 above. Consistently with the guidance that decisions must be taken by reference to the


-----

Commissioner for Refugees intervening) and other case....

particular circumstances of each claimant, these do not purport to reach a definitive conclusion on whether
Rwanda is a safe third country. However, they state the views of the CPIT on a number of issues relevant
to that question, the most important of which are summarised as “key judgments” in the Assessment CPIN.
These include, under the heading “refoulement”, the judgment that:

“There are not substantial grounds for believing that a person, if relocated, would face a real risk of being
subjected to treatment that is likely to be contrary to Article 3 ECHR by virtue of being refouled or returned
to a place where they have a well-founded fear of persecution.”

298. The Master of the Rolls considers that in view of his conclusion on the substantive issue of the safety
of Rwanda it is unnecessary to decide whether the Inadmissibility Guidance is unlawful: see para. 114 of
his judgment. However, I think I should say that I believe that the Guidance and the Assessment CPIN,
taken together, do constitute policy guidance which, in the light of the conclusions reached above, is
indeed unlawful.

299. The Divisional Court held that the Inadmissibility Guidance was lawful: see para. 72 of its judgment.
But that simply reflects its substantive decision on the issue of the safety of Rwanda.

300. Ground 6 of the consolidated grounds of appeal, advanced before us by Ms Sonali Naik KC, reads:

“The Court was wrong to conclude that R's inadmissibility policy on removals to Rwanda was not unlawful
either under the conventional _Gillick test or under a_ _Gillick test necessarily modified in cases involving a_
real risk of Article 3 ECHR breach.”

301. Since for the reasons which I have given I would hold that the policy was indeed unlawful on what I
believe to be a conventional basis, I see no advantage in considering the alternative submission that “the
_Gillick test” requires modification in cases based on article 3, though I feel bound to say that I had some_
difficulty in understanding it.

ISSUE 11: CERTIFICATION

302. I have already made the point that we are not in this appeal concerned with the challenge to the
Secretary of State's decision to certify the human rights claims made by (most of) the Claimants under
paragraph 19 of Schedule 3 to the 2004 Act: see para. 130 above. However, I agree with the Master of the
Rolls that it follows that the Secretary of State's decisions certifying the individual human rights claims
could not be sustained on this ground, as well as on the grounds on which they were in fact quashed by
the Divisional Court: see para. 116. As to whether it would also have followed, if the Court had reached
the same conclusion, that the appeal to the FTT would have proceeded in priority to the generic challenge
(see his para. 117), I refer to what I say at para. 131 above.

**B.    THE REMAINING ISSUES**

303. Although our conclusion on the safety of Rwanda issue means that the Rwanda policy must be
declared unlawful, it is necessary to consider the remaining issues raised by the Claimants' grounds of
appeal, not only in case of an appeal to the Supreme Court but also because they will remain relevant if
the defects in the Rwandan asylum system are in due course resolved.  I gratefully adopt the Master of the
Rolls' categorisation of the remaining issues, and I take them in turn. Responsibility for arguing these
issues on behalf of the Claimants was divided between different counsel; they were argued on behalf of the
Secretary of State by Lord Pannick KC.

ISSUE 12: BREACH OF THE REFUGEE CONVENTION

Introduction

304. Section 2 of the Asylum and Immigration Appeals Act 1993 is headed “Primacy of the Convention”
and reads:

“Nothing in the Immigration Rules (within the meaning of the 1971 Act) shall lay down any practice which
would be contrary to the Convention”


-----

Commissioner for Refugees intervening) and other case....

(“The Convention” is defined in section 1 as the Refugee Convention.)

305. In R (European Roma Rights Centre) v Immigration Officer at Prague Airport _[2004] UKHL 55, [2005]_
2 AC 1, Lord Steyn said, at para. 41 of his opinion:

“It is necessarily implicit in section 2 that no administrative practice or procedure may be adopted which
would be contrary to the Convention. After all, it would be bizarre to provide that formal immigration rules
must be consistent with the Convention but that informally adopted practices need not be consistent with
the Convention. The reach of section 2 of the 1993 Act is therefore comprehensive.”

Although in the Secretary of State's skeleton argument that statement is described as _obiter it is not_
suggested, nor did Lord Pannick submit, that we should not follow it. It seems that the Divisional Court
may have had some doubts about its correctness because at para. 122 of its judgment it observed that
“section 2 of the 1993 Act is directed only to ensuring consistency between the Immigration Rules and the
Refugee Convention” and questioned whether the “practice” challenged in these cases fell within the terms
of the section because paragraphs 345A-345D said nothing about removal of asylum-seekers to Rwanda;
but it went on to say that it would not dismiss this part of the case on that basis. Lord Steyn's statement
has been quoted with approval in at least two subsequent decisions of this Court – EN (Serbia) v Secretary
_of State for the Home Department_ _[2009] EWCA Civ 630, [2010] QB 633, (per Stanley Burnton LJ at para._
58); and Secretary of State for the Home Department v RH _[2020] EWCA Civ 1001 (per Baker LJ at para._
12). I proceed on the basis that it is correct.

306. It is the Claimants' case that the removal of asylum-seekers to Rwanda on the basis of paragraphs
345A-345D of the Immigration Rules and the Inadmissibility Guidance constitutes a practice which is
contrary to the Convention and accordingly unlawful under section 2. That case is formulated in four
distinct grounds of appeal, namely grounds 9-12 in the consolidated grounds. These read:

“9.  The Court erred in failing to address the question of whether asylum-seekers removed to Rwanda
would be accorded their rights under the Refugee Convention as a matter of vires as opposed to
rationality.

10. The Court erred in concluding at [126] that the MEDP Scheme as set out in paragraphs 345A-D of the
Immigration Rules was consistent with the Refugee Convention and therefore not ultra vires s2 of the 1993
Act.

11. The Court erred in finding that inadmissibility and/or removal to Rwanda did not constitute a penalty for
the purposes of Article 31 of the Refugee Convention.

12. The Court was wrong to find, for the purposes of Article 31 of the Refugee Convention, that the
removal of RM, before his asylum claim would have been considered, to a third country with which he has
no prior connection, with the avowed aim of deterring them or others from seeking asylum in the UK after
arriving by unlawful means, did not constitute a penalty and therefore was consistent with s.2 of the Asylum
and Immigration Appeals Act 1993.”

307. Grounds 9 and 11 were pleaded in AAA and were advanced by Mr Husain; grounds 10 and 12 were
pleaded in ASM and RM respectively and were advanced by Mr Richard Drabble KC. As will appear, there
is some overlap between the grounds, but I will take them as my structure in addressing this issue. I will
consider ground 10 first, then grounds 11 and 12 together, and finally ground 9.

308. For the purpose of grounds 10-12 the relevant provisions of the Convention are articles 31 and 33,
and it will be convenient to set them out now. Article 31 reads:

“Refugees unlawfully in the country of refuge

1.  The Contracting States shall not impose penalties, on account of their illegal entry or presence, on
refugees who, coming directly from a territory where their life or freedom was threatened in the sense of
article 1, enter or are present in their territory without authorization, provided they present themselves
without delay to the authorities and show good cause for their illegal entry or presence.


-----

Commissioner for Refugees intervening) and other case....

2. The Contracting States shall not apply to the movements of such refugees restrictions other than those
which are necessary and such restrictions shall only be applied until their status in the country is
regularized or they obtain admission into another country. The Contracting States shall allow such
refugees a reasonable period and all the necessary facilities to obtain admission into another country.”

Article 33 reads:

“Prohibition of expulsion or return ('refoulement')

1. No Contracting State shall expel or return ('refouler') a refugee in any manner whatsoever to the
frontiers of territories where his life or freedom would be threatened on account of his race, religion,
nationality, membership of a particular social group or political opinion.

2. The benefit of the present provision may not, however, be claimed by a refugee whom there are
reasonable grounds for regarding as a danger to the security of the country in which he is, or who, having
been convicted by a final judgment of a particularly serious crime, constitutes a danger to the community of
that country.”

Ground 10

309. This ground is pleaded in very general terms. However, Mr Drabble's primary submission, as
formulated at para. 58 of ASM's skeleton argument, is that “there is an implied obligation on a receiving
state, inherent in the basic structure of the Convention, to process a claim for asylum made by a refugee
physically present in its territory”. It would follow that it was a breach of the Convention for a state to
remove a person who has made an asylum claim to another country, however safe, without determining
their claim and according them the rights of a refugee under the Convention if the claim is established.

310. The factors relied on in support of that primary submission are identified in the same paragraph of the
skeleton argument as follows:

“That implied obligation arises as a combination of the declaratory nature of refugee status (which requires
investigation of the individual's circumstances and the nature of his claim) and Convention provisions,
including the prohibition on _refoulement_ (Article 33), the prohibition on penalties for illegal entry or
presence (Article 31), the duty to afford refugees the same treatment as 'aliens' (Article 7), the prohibition
on discrimination on grounds of country of origin and the right of access to courts (Article 16). Even Article
9, which permits provisional measures against an individual where 'essential to national security', does so
only 'pending a determination by the Contracting State that that person is in fact a refugee'.”

(It is unnecessary to set out the full terms of articles 7, 9 and 16 as there referred to: their effect is
adequately summarised.)

311. In support of the submission that the obligation in question could be implied from the terms of the
Convention the skeleton argument refers to the following provisions of article 31.1 of the Vienna
Convention on the Law of Treaties 1969 (“General rule of interpretation”), which reads:

“1.  A treaty shall be interpreted in good faith in accordance with the ordinary meaning to be given to the
terms of the treaty in their context and in the light of its object and purpose.”

2.  …

3.  There shall be taken into account, together with the context:

(a) …;

(b) any subsequent practice in the application of the treaty which establishes the agreement of the parties
regarding its interpretation;

(c) … .”

312. That submission is contrary to the practice which has prevailed in the European Union since the
coming into force of the “Dublin system” in 1997 (initially in the form of the Dublin Convention but since


-----

Commissioner for Refugees intervening) and other case....

succeeded by the Dublin II and III Regulations), which permits member states to decline to entertain
asylum applications from claimants who had previously applied to another member state. It is also
contrary to articles 25-27 of EU Council Directive 2005/85/EC “on minimum standards on procedures in
Member States for granting and withdrawing refugee status” (“the Procedures Directive”), which explicitly
recognise the legitimacy of treating an asylum application as inadmissible, and refusing to consider it, if a
country other than a member state “is considered as a safe third country for the applicant” (article 25.2 (c)).
The “safe third country concept” is defined in article 27, which reads:

“1.  Member States may apply the safe third country concept only where the competent authorities are
satisfied that a person seeking asylum will be treated in accordance with the following principles in the third
country concerned:

(a) life and liberty are not threatened on account of race, religion, nationality, membership of a particular
social group or political opinion;

(b) the principle of non-refoulement in accordance with the Geneva Convention is respected;

(c) the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman or
degrading treatment as laid down in international law, is respected; and

(d) the possibility exists to request refugee status and, if found to be a refugee, to receive protection in
accordance with the Geneva Convention.

2.   The application of the safe third country concept shall be subject to rules laid down in national
legislation, including:

(a)  rules requiring a connection between the person seeking asylum and the third country concerned on
the basis of which it would be reasonable for that person to go to that country;

(b)  rules on the methodology by which the competent authorities satisfy themselves that the safe third
country concept may be applied to a particular country or to a particular applicant. Such methodology shall
include case-by-case consideration of the safety of the country for a particular applicant and/or national
designation of countries considered to be generally safe;

(c)  rules in accordance with international law, allowing an individual examination of whether the third
country concerned is safe for a particular applicant which, as a minimum, shall permit the applicant to
challenge the application of the safe third country concept on the grounds that he/she would be subjected
to torture, cruel, inhuman or degrading treatment or punishment.

3.    When implementing a decision solely based on this Article, Member States shall:

(a)  inform the applicant accordingly; and

(b)  provide him/her with a document informing the authorities of the third country, in the language of that
country, that the application has not been examined in substance.

4.    Where the third country does not permit the applicant for asylum to enter its territory, Member
States shall ensure that access to a procedure is given in accordance with the basic principles and
guarantees described in Chapter II.

5.    Member States shall inform the Commission periodically of the countries to which this concept is
applied in accordance with the provisions of this Article.”

Both the Dublin system and the Procedures Directive are parts of the “Common European Asylum
System”, and the Dublin system proceeds on the basis that member states are safe third countries.

313. In tacit recognition of that difficulty, the skeleton argument advances what appears to be an
alternative to the primary submission. Para. 63 reads:


-----

Commissioner for Refugees intervening) and other case....

“The operation of the Dublin III scheme indicates that a constrained application of the 'safe third country'
concept, with clear procedures and a robust protective legal framework, may be consistent with the
Convention.”

As I understand it, that alternative proceeds on the basis that, although the Convention itself says nothing
about contracting states being entitled to decline to entertain an asylum application where the applicant
could go to a safe third country, such a right, if sufficiently “constrained”, might be capable of being implied
in the light of its object and purpose and by reference to subsequent practice. It refers only to the Dublin
system, and it does not explicitly extend to the safe third country concept as defined in the Procedures
Directive, which goes beyond the Dublin regime in as much as it applies to non-EU states; but the
reasoning behind the alternative would seem to apply in the case of removal to any safe third country.

314. Mr Drabble contended that that alternative reading of the Convention does not assist the Secretary of
State because the MEDP is not sufficiently “constrained”. Para. 73 of ASM's skeleton argument reads:

“The MEDP scheme represents a significant departure from the Dublin III framework and an extension of
the 'safe third country' concept beyond that permitted by the Convention. Rwanda is not a country included
in Parts 2-4 of Schedule 3 [to the Asylum and Immigration (Treatment of Claimants, etc.) Act 2004], and is
therefore not subject to the statutory presumption of safety; there has been no Parliamentary scrutiny of
the Secretary of State's decision to treat Rwanda as a safe country. Rwanda is, obviously, not bound by
EU standards nor the Common European Asylum System …; it is not a signatory of the [European
Convention on Human Rights]; it is not subject to the jurisdiction of the [Court of Justice of the European
Union] or the European Court of Human Rights. The MEDP scheme is underpinned not by statutory
provisions, but by the Rwandan MOU and accompanying Notes Verbales …, paragraphs 345A-C of the
Immigration Rules and relevant policy guidance.”

315. Mr Drabble advanced three further arguments under this ground:

(1) that the targeting of the MEDP Scheme on asylum-seekers who arrive in the UK by irregular means “is
contrary to the recognition, inherent within the protection framework of the convention and in article 31 in
particular, that refugees may need to undertake journeys by irregular or criminal means in order to reach
safety” – see R v Asfaw _[2008] UKHL 31, [2008] 1 AC 1061(ASM skeleton argument paras. 66-67);_

(2) that “the stated purpose of the MEDP scheme ... to deter refugees from undertaking 'irregular and
dangerous' journeys to the UK ... is entirely inconsistent with the spirit and purpose of the Convention”,
particularly given the absence of available regular and safe means (ASM skeleton argument para. 68); and

(3) that “the deterrent purpose of the MEDP scheme is inconsistent with the prohibition on 'penalties' for
illegal entry or presence imposed by article 31 of the Refugee Convention” (ASM skeleton argument para.
69).

The third of those arguments is the subject of grounds 11 and 12, and I deal with it in that context.

316. The starting-point in considering those submissions is that it is in my view settled law that the
Refugee Convention does not prohibit a receiving state from declining to entertain an asylum claim where it
can and will remove the claimant to another non-persecutory state. That was clearly stated by Lord Bridge
in R v Secretary of State for the Home Department, ex p Bugdaycay [1987] AC 514. That decision in fact
covers four distinct cases. The relevant case for our purposes is _Musisi, where the applicant was a_
Ugandan national who had arrived in the UK from Kenya and claimed that he was at risk of persecution in
Uganda. The Home Secretary proposed to return him to Kenya. That decision was quashed in the High
Court, whose decision was upheld by the Court of Appeal, on the basis that the Home Secretary had not
considered his claim that he would be refouled from Kenya to Uganda.  Although the House of Lords
upheld the Court of Appeal's decision, Lord Bridge began his analysis by saying (at p. 532 B-C):

“… I can well see that if a person arrives in the United Kingdom from country A claiming to be a refugee
from country B, where country A is itself a party to the Convention, there can in the ordinary case be no
obligation on the immigration authorities here to investigate the matter. If the person is refused leave to


-----

Commissioner for Refugees intervening) and other case....

enter the United Kingdom, he will be returned to country A, whose responsibility it will be to investigate his
claim to refugee status and, if it is established, to respect it. This is, I take it, in accordance with the
'international practice' [referred to in the evidence].  The practice must rest upon the assumption that all
countries which adhere to the Convention may be trusted to respect their obligations under it. Upon that
hypothesis, it is an obviously sensible practice and nothing I say is intended to question it.”

He goes on to say that where that assumption was shown to be unsafe return to country A would be
contrary to the prohibition on refoulement (in that case indirect refoulement) in article 33; but what matters
for our purposes is his statement of the position where there is no such risk.

317. Lord Bridge's statement is consistent with the academic commentary. The discussion of article 31 in
Professor James Hathaway's The Rights of Refugees under International Law (2[nd] ed, 2021) is particularly
useful because it considers the _travaux préparatoires. He says, at p. 519, that “Art. 31 in no way_
constrains a state's prerogative to expel an unauthorized refugee from its territory”. He observes that it
might seem ironic that an asylum country which is generally prohibited from imposing penalties on
refugees may nonetheless expel them; but he goes on at pp. 519-520 to demonstrate, by reference to the
statements made on behalf of the original signatories in the course of the Conference which led to the
Convention, that that was indeed the intention. The position was most clearly stated by the argument of
the Canadian representative that no modification of the text as regards this issue was required, since “the
consensus of opinion was that the right [to expel refugees who illegally enter a state's territory] would not
be prejudiced by adoption of Article [31]”. He goes on to point out that what he calls the “potentially
devastating impact” of that decision is mitigated by the duty of non-refoulement in article 33: “any expulsion
of a refugee must therefore not expose the refugee, directly or indirectly, to a risk of being persecuted”.

318. To the same effect, in his analysis and commentary on the _Travaux Préparatoires to the Refugee_
_Convention Dr Paul Weis says at pp. 302-303:_

“Article 31 refers to 'penalties'. It is clear from the travaux préparatoires that this refers to administrative or
judicial convictions on account of illegal entry or presence, not to expulsion ...

Paragraph 1 does not impose an obligation to regularise the situation of the refugee nor does it prevent the
Contracting States from imposing an expulsion order on him. However, a refugee may not be expelled if
no other country is willing to admit him …”

See also Goodwin-Gill and McAdam, The Refugee in International Law (4[th] ed, 2021), at p. 278.

319. Against that background, I see no room for the kinds of implied obligation contended for by Mr
Drabble. Specifically, there is no warrant for implying a prohibition on removal except where the third
country satisfies the particular requirements either of the Dublin system or of article 27 of the Procedures
Directive (including the requirement that the application have a connection with that country). The
straightforward question, so far as the Convention is concerned, is whether the third country is safe for the
applicant in the sense that there is no real risk of their being refouled (directly or indirectly). Nor can any
limitations be implied on the state's right to take into account, when deciding whether to remove an asylumseeker to a safe third country, the fact that they arrived in the UK irregularly, even in circumstances where
there was no regular means to do so, or that their removal may have a deterrent effect. The state's
motivation is irrelevant to the object and purpose of the Convention: if the asylum-seeker will not face
persecution or refoulement in the country to which they are returned they will have received the protection
which the Convention is intended to afford them. (This conclusion is subject to the ostensibly distinct
“penalty” issue discussed under grounds 11 and 12.)

320. My conclusion is reinforced by the observations of Lord Bingham at para. 18 of his opinion in the
_Roma Rights_ case. The case involved, in part, the interpretation of the Refugee Convention. Lord
Bingham accepted counsel's submission that the Convention “should be given a generous and purposive
interpretation, bearing in mind its humanitarian objects and purpose”, but he continued:

“But I would make an important caveat. However generous and purposive its approach to interpretation,
the court's task remains one of interpreting the written document to which the contracting states have


-----

Commissioner for Refugees intervening) and other case....

committed themselves. It must interpret what they have agreed. It has no warrant to give effect to what
they might, or in an ideal world would, have agreed. This would violate the rule, … expressed in article
31(1) of the Vienna Convention, that a treaty should be interpreted in accordance with the ordinary
meaning to be given to the terms of the treaty in their context. It is also noteworthy that article 31(4) of the
Vienna Convention requires a special meaning to be given to a term if it is established that the parties so
intended. … It is in principle possible for a court to imply terms even into an international convention. But
this calls for great circumspection since, as was said in Brown v Stott [2003] 1 AC 681, 703,

'it is generally to be assumed that the parties have included the terms which they wished to include and on
which they were able to agree, omitting other terms which they did not wish to include or on which they
were not able to agree,'

and caution is needed

'if the risk is to be averted that the contracting parties may, by judicial interpretation, become bound by
obligations which they did not expressly accept and might not have been willing to accept'.”

321. The pleaded challenge is to para. 126 of the Divisional Court's judgment. However, that merely
expresses its overall conclusions on the issue of compatibility with the Refugee Convention. Its essential
reasoning as regards this aspect appears in para. 121 of its judgment, where it said:

“Mr Drabble KC submitted that the Refugee Convention imposes an obligation on contracting states to
determine all asylum claims made, on their merits. We disagree. There is no such obligation on the face of
the Convention. The obligation that is imposed is the one at article 33, not to expel or return a refugee to a
place where his life or freedom would be threatened by reason of any of the characteristics that the
convention protects. Mr Drabble's submission was that an obligation to determine asylum claims would be
consistent with the spirit and purpose of the Convention and could therefore reasonably be assumed.
Again, we disagree. Obligations in international treaties are formulated with considerable care. They reflect
balances struck following detailed negotiations between states parties. An obligation to determine every
asylum claim on its merits would be a significant addition to the Refugee Convention. There is no reason to
infer the existence of an obligation of that order; to do so would go well beyond the limits of any notion of
judicial construction of an international agreement; and the protection that is necessary if the purpose of
the Convention is to be met, is provided by article 33.”

I agree.

Grounds 11 & 12

322. In both these grounds the contention is that the removal of asylum-seekers to Rwanda under the
MEDP constitutes a “penalty” within the meaning of article 31 (1). They differ from ground 10 because they
depend on the meaning of the word “penalty” and thus do not depend on the implication of any term.
However the underlying issue is in fact in my view the same, and I can take them fairly shortly.

323. It follows from my reasoning in relation to ground 10 that the removal of an asylum-seeker to a safe
third country without their claim being determined is not in itself a penalty: indeed the passages from the
academic commentators which I have quoted are all in the context of article 31 (1). However, Mr Husain
and Mr Drabble submitted that expulsion may become a penalty within the meaning of the article
depending on the facts of a particular case. I summarise their submissions in turn.

324. Mr Husain contended (see para. 64 (ii) of the AAA Claimants' skeleton argument) that “the reasons
why, and the conditions to which, a person is being removed are highly relevant and may convert a
removal which is lawful _per se into an impermissible penalty”. As for the “reasons” element in that_
formulation, he relied on the fact that the asylum-seekers who were liable to relocation to Rwanda under
the MEDP were being removed “for the purposes of imposing a detriment on them and deterring others
from arriving in the same way”. He relies on an observation in a commentary on the term “criminal offence”
in the International Covenant on Civil and Political Rights, adopted by Professor Guy Goodwin-Gill in a
paper on article 31 commissioned by UNHCR, to the effect that “every sanction that has not only a


-----

Commissioner for Refugees intervening) and other case....

preventative but also a retributive and/or deterrent character is ... to be termed a penalty”. As for the
“conditions to which [the Claimants would be] removed”, he relied on the fact that they would be being
removed to “significantly inferior processes and human rights protection”.

325. Mr Drabble submitted that the term “penalty” required a broad and purposive construction in line with
the humanitarian purpose of the Convention: as we have seen, that was accepted by Lord Bingham in the
_Roma Rights case. Adopting that approach, he submitted that expulsion could constitute a penalty if it was_
detrimental to the applicant in some specific way such as separation from family members or a supportive
community. He also relied on the deterrent purpose of the MEDP.

326. Both counsel relied on the decision of the Supreme Court of Canada in B010 v Canada [2015] 3 SCR
704. The case concerned a Canadian statutory provision – section 37 (1) of the Immigration and Refugee
Protection Act 2001 – which rendered a person “inadmissible”, which effectively denied them access to
refugee determination procedures, if they had engaged in “in the context of transnational crime, activities
such as people smuggling”. The issue was whether on its true construction that provision applied to illegal
migrants who had assisted other illegal migrants but had not done so in return for any financial or other
benefit. The Court held that it did not. As part of her reasoning in support of that construction McLachlin
CJ, delivering the judgment of the Court, held that “omitting a financial or other benefit limitation” would be
inconsistent with article 31 (1) of the Convention: see para. 62 of her judgment. At para. 57 she sets out
article 31 (1) and adopts a statement in a textbook that:

“an individual cannot be denied refugee status – or, most important, the opportunity to make a claim for
such status through fair assessment procedures – solely because of the way in which that person sought
or secured entry into the country of destination”

and that

“[o]bstructed or delayed access to the refugee process is a 'penalty' within the meaning of art. 31(1) …”.

At para. 63 she says:

“The respondents contend that art. 31(1) of the Refugee Convention refers only to criminal penalties. This
interpretation runs counter to the purpose of art. 31(1) and the weight of academic commentary: J. C.
Hathaway, The Rights of Refugees Under International Law (2005), at pp. 409-12; Gallagher and David, at
pp. 164-68; G. S. Goodwin-Gill and J. McAdam, _The Refugee in International Law_ (3rd ed. 2007), at p.
266. The generally accepted view is that denying a person access to the refugee claim process on account
_of his illegal entry, or for aiding others to enter illegally in their collective flight to safety, is a 'penalty' within_
_the meaning of art. 31(1). The law recognizes the reality that refugees often flee in groups and work_
together to enter a country illegally. Article 31(1) thus does not permit a state to deny refugee protection (or
refugee determination procedures) to refugees solely because they have aided others to enter illegally in
an unremunerated, collective flight to safety. Rather, it targets those who assist in obtaining illegal entry for
financial or other material benefit.”

327. Mr Husain relied on the words that I have italicised and submitted that they were directly applicable to
the present case. He acknowledged that the Court in B10 was not concerned with a situation where the
migrant would be being removed to a safe third country, but he submitted that that was immaterial. I do not
agree. In my view it is a crucial distinction. The views endorsed by McLachlin CJ in paras. 57 and 63 of
her judgment are concerned with denial of, or obstructions or delay to, access to the refugee determination
process for a migrant who is in the country. They are not concerned with expulsion, as to which, as I have
sought to show in connection with ground 10, the Convention imposes no restrictions save for the duty of
non-refoulement imposed by article 33.

328. The same point applies to Professor Goodwin-Gill's wide definition of “penalty” (see para. 324
above). I have no difficulty with the proposition that the term is not confined to sanctions of a criminal
character; but the issue here is whether it extends to expulsion.


-----

Commissioner for Refugees intervening) and other case....

329. In short, it is in my view inconsistent with the well-recognised scheme of the Convention that the
expulsion of a migrant to a safe third country should be treated as a penalty within the meaning of article
31 (1), whatever the reasons for taking that course may be and however unwelcome it may be to the
migrant in question.

330. The Divisional Court addressed the effect of article 31 (1) at paras. 123-125 of its judgment. At para.
125 it says:

“There is, therefore, a clear consensus. Article 31 does not prevent a state expelling a refugee. States
must not act in breach of article 33; removal that is not contrary to article 33 is not a penalty for the
purposes of article 31. On this basis, neither decisions on inadmissibility under paragraph 345A of the
Immigration Rules, nor decisions under paragraph 345C on removal to Rwanda are contrary to the
Refugee Convention. The latter because one premise of a paragraph 345C decision is that the country
concerned is a safe third country, as defined at paragraph 345B of the Immigration Rules. The deterrent
purpose that the Home Secretary pursues in relation to removals to Rwanda does not, of itself, render
removal to Rwanda contrary to article 31, let alone article 33 of the Refugee Convention. Further, the
simple fact of removal to Rwanda is not sufficient to make good the Claimants' submission that removal is
a penalty contrary to article 31. That submission would succeed only when removal amounts to a breach of
article 33. Looked at on this basis, the Claimants' article 31 submission merges with their submission on
whether Rwanda is a safe third country. If it is a safe third country, decisions taken in exercise of the
powers in paragraphs 345A - 345D of the Immigration Rules are not in breach of article 31; if, however,
Rwanda is not a safe third country, removal would be both contrary to paragraph 345C of the Immigration
Rules and to both article 31 and article 33 of the Refugee Convention.”

Again, I agree.

Ground 9

331. As pleaded this ground is decidedly opaque. However, as developed at paras. 53-58 of the AAA
Claimants' skeleton argument it appears to comprise four points.

332. First, it is contended that the Divisional Court's error in approaching the question of whether Rwanda
was a safe third country on a review basis rather than reaching its own conclusion infected its reasoning
also on the Refugee Convention issues. I do not agree. Its dispositive reasoning, which I have set out at
paras. 321 and 330 above, does not depend on its assessment of the safety of Rwanda. Even if it did the
point would go nowhere since I believe that its conclusion on the Refugee Convention issues which it
considered was correct in any event.

333. The second and third points appear to go together. The Claimants had argued in the Divisional Court
that Rwandan law was incompatible with two articles of the Refugee Convention, as follows:

(1) Article 1C (a) of the Convention provides for refugee status to lapse where a refugee “has voluntarily
re-availed himself of the protection of the country of his nationality”. We were not referred to the terms of
the relevant Rwandan legislation, nor was there any expert evidence of Rwandan law, but in their skeleton
argument in the Divisional Court (see para. 390) the AAA Claimants relied on para. 10.5.1 of the Asylum
System CPIN. This states that “[a] refugee who returns to their country of origin loses his/her refugee
status and will be required to submit a new asylum claim to the authorities if he/she returns to Rwanda”:
there is a footnote reference to a Ministerial Instruction dated 1 June 2016 (no. 02/2016).  That is said to
mean that a refugee will lose protection if they return to their country of nationality, however temporarily or
for whatever reason, e.g. to see a dying relative.

(2) Article 1F (b) disapplies the Convention in the case of persons who have “committed a serious nonpolitical crime outside the country of refuge prior to [their] admission to that country as a refugee”. The
AAA Claimants' skeleton argument in the Divisional Court states at para. 394 that “an asylum-seeker who
has been prosecuted for any non-political felony will automatically be excluded from refugee status”: no
reference is given to the statutory provision relied on, but it seems from the rest of the paragraph that the
e cl sion onl applies to an as l m seeker ho has been s ccessf ll prosec ted


-----

Commissioner for Refugees intervening) and other case....

334. The Claimants complain that the Divisional Court failed to address those points.  I accept that it did
not expressly consider them, though the omission is venial in view of the plethora of arguments with which
it was faced. But I do not believe that the points are good in any event. The material relied on falls well
short of establishing that Rwandan law fails to give effect to either article 1C or article 1F. As we have
seen, the MoU contains an express provision that RIs will be treated in accordance with the Refugee
Convention (see para. 9.1.1). We do not have the text of either of the domestic instruments relied on, still
less any expert evidence. Even if they are accurately reproduced, we do not know whether under
Rwandan law the requirements of the Convention would trump any contrary provision of the domestic
legislation (or in any event any ministerial instruction). But even if that is not the case, it would be
surprising if a Court seeking to construe domestic law in accordance with Rwanda's obligations under the
Convention were unable to do so. It is for the Claimants to establish that the Rwanda policy contravenes
section 2, and I do not believe that (in this respect) they have done so.

335. The fourth point is based on article 15 of the Convention (“Right of Association”), which obliges
contracting states, as regards “non-political and non-profit-making associations and trade unions”, to
“accord to refugees lawfully staying in their territory the most favourable treatment accorded to nationals of
a foreign country, in the same circumstances”. (Article 7 (1) contains a more general non-discrimination
provision, but that adds nothing to the argument.) At paras. 386-389 of their skeleton argument in the
Divisional Court the AAA Claimants had relied on various materials in support of a submission that article
15 would not be complied with as regards RIs. Some of the materials simply showed that there were
serious restrictions on freedom of speech and freedom of assembly in Rwanda, and at para. 77 of its
judgment the Divisional Court held that that did not demonstrate any discrimination against refugees as
opposed to other foreign nationals, which is the subject of article 15. However, the Claimants complain
that that rebuttal fails to address one of the materials relied on, which was para. 3.8.3 of the Human Rights
CPIN, which reads:

“In 2016, the Rwandan Government's Ministry in Charge of Emergency Management (MINEMA), published
Ministerial instructions determining the management of refugees and refugee camps. Article 2 refer to
'Prohibited acts and behaviors for refugees' and states that 'Political activities' and 'Gatherings based on
ethnicity, nationality, or any other sectarian ground' and participating in, or inciting others into unlawful riots
are prohibited.”

(The Ministerial Instruction seems to be the same as that referred to at para. 333 (1) above.) That
Instruction does appear to impose specific restrictions on refugees. The Claimants complain that the
Divisional Court failed to deal with it and submit that it shows that the article 15 rights of RIs would not be
respected. In her submissions resisting the grant of permission to appeal the Secretary of State drew
attention to article 12 of the Ministerial Instruction, which provides for refugees to enjoy (in effect) the full
rights accorded by the Convention, including “membership to association of forums with non-political
orientation”; but the Claimants contend that that is in very general terms, and article 2 is plainly a
derogation from it.

336. I would reject the Claimants' submission. I do not believe that the terms of article 2 of the Ministerial
Instruction establish that the article 15 rights of RIs would not be recognised. Despite the distinction
between “political activities” and “gatherings based on ethnicity, nationality, or any other sectarian ground”,
I am not satisfied that the latter class of activities would qualify as “non-political” under article 15: on a
purposive construction it seems very unlikely that a purely social, or other non-political, meeting of, say,
Kurdish or Albanian refugees would be held to be caught by article 2 because it was a “gathering based on
ethnicity [or] nationality”. It is also far from clear that the same restrictions would not apply to other nonnationals. In the absence of any authoritative expert evidence on these points I do not consider that the
Claimants' submission is made out.

337. I should add that other arguments were relied on by the Secretary of State, and the Divisional Court,
in response to the Claimants' points on Rwandan law; but the foregoing is sufficient for me to reject them.

Conclusion


-----

Commissioner for Refugees intervening) and other case....

338. For the reasons given, I would reject grounds of appeal 9-12.

339. It may in fact be arguable that the effect of my earlier conclusion that RIs would be at risk of
refoulement from Rwanda because of the inadequacy of its asylum system is that relocation there would
constitute a practice which contravened article 33 and would thus be unlawful under section 2 on a
different basis; but the case was not put that way and I need not consider it here.

ISSUE 13: RETAINED EU LAW

Introduction

340. This issue concerns whether paragraph 345C of the Immigration Rules is compatible with retained
EU law. Paragraphs 345A-345D of the Rules were introduced by Statement of Changes HC 1043, dated
10 December 2020, to take effect at 23.00 on 31 December 2020, i.e. at the moment of “IP Completion” as
[defined in the European Union (Withdrawal Agreement) Act 2020. For convenience I will set out paragraph](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5Y26-JS33-CGXG-0486-00000-00&context=1519360)
345C again here:

“When an application is treated as inadmissible, the Secretary of State will attempt to remove the applicant
to the safe third country in which they were previously present or to which they have a connection, or to
_any other safe third country which may agree to their entry [my italics].”_

The point to note for our purposes is that the italicised words explicitly contemplate the removal of an
asylum-seeker to a safe third country with which they have no connection.[8]

341. The retained EU law which paragraph 345C is said to contravene is the Procedures Directive, to
which I have already referred in connection with Issue 12. The Directive came into force in the UK, by
virtue of section 2 of the European Communities Act 1972, on 2 January 2006. (I should also mention,
because it is part of the wider picture, that a separate Directive relating to aspects of substantive asylum
law – the “Qualification Directive” (2004/83/EU) – came into force shortly afterwards.)

342. The Procedures Directive imposes a number of requirements on member states as regards the
procedure for determining applications for asylum, including (by article 6.2) a requirement that all adults
with legal capacity should have the right to make an application for asylum and (by article 8) that any such
application should be appropriately examined. So far as relevant for our purposes, article 25 allows
member states to treat an asylum application as “inadmissible”, and accordingly not to examine it, in a
number of particular situations identified in paragraph 2. These include, at (c), where “a country which is
not a Member State is considered as a safe third country for the applicant, pursuant to Article 27”. I have
already set out article 27 in full at para. 312 above. For present purposes I need only note that paragraph
2 (a) requires member states to implement “rules requiring a connection between the person seeking
asylum and the third country concerned on the basis of which it would be reasonable for that person to go
to that country”: I will refer to that as “the connection requirement”.

343. It is the Claimants' case that the Procedures Directive remains part of UK law by reason of section 4
of the European Union (Withdrawal) Act 2018, which preserves the force, as “retained EU law”, of EU
legislation given effect by the 1972 Act. On that basis, they submit, paragraph 345C of the Immigration
Rules is unlawful, because, contrary to article 27.2 (a), it permits removal to a country with which the
applicant has no connection.

344. The Secretary of State does not challenge the proposition that paragraph 345C is inconsistent with
the requirements of article 27.2 (a) of the Directive. However it is her case that those requirements no
[longer form part of UK law. She relies on the effect of the Immigration and Social Security Co-ordination](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:619H-Y6C3-CGXG-019X-00000-00&context=1519360)
_[(EU Withdrawal) Act 2020 (“ISSCA”), which received the Royal Assent on 11 November 2020. I need to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:619H-Y6C3-CGXG-019X-00000-00&context=1519360)_
set out the structure of the Act and the relevant provisions in some detail.

_ISSCA               : the Act and the Parties' Submissions_

345. The long title of ISSCA is as follows:


-----

Commissioner for Refugees intervening) and other case....

“An Act to make provision to end rights to free movement of persons under retained EU law and to repeal
other retained EU law relating to immigration; to confer power to modify retained direct EU legislation
relating to social security co-ordination; and for connected purposes.”

As foreshadowed by the long title, the Act has two substantive Parts. Part 1 is headed “Measures relating
to ending free movement”, and Part 2 “Social security co-ordination”. We are concerned with Part 1, which
came into force on 31 December 2020, i.e. coinciding with IP Completion Day.

346. Part 1 of ISSCA comprises sections 1-5. The principal substantive section is section 1, which gives
effect to Schedule 1 to the Act. It reads:

“Repeal of the main retained EU law relating to free movement etc.

Schedule 1 makes provision to—

(a) end rights to free movement of persons under retained EU law, including by repealing the main
provisions of retained EU law relating to free movement, and

(b) end other EU-derived rights, and repeal other retained EU law, relating to immigration.”

The other substantive sections are sections 2-3. Both address particular issues related to the ending of
free movement. In summary:

- Section 2 preserves the rights of Irish citizens under the long-standing common travel area
arrangements.

- Section 3 requires the Secretary of State to formulate a policy covering “legal routes from the EU and
family reunion” for protection claimants, or potential protection claimants, who wish to enter the UK from a
member state.

Sections 4 and 5 are ancillary.

347. Schedule 1, which as we have seen is given effect by section 1, is headed “Repeal of the main
retained EU law relating to free movement etc.”. It comprises three Parts. Part 1 is headed “EU-derived
domestic legislation” and revokes certain specified provisions of primary legislation and statutory
instruments. Part 2 is headed “Retained Direct EU Legislation” and repeals the Workers Regulation
(Regulation (EU) No 492/2011), which is the EU provision conferring the right of freedom of movement for
workers within the EU.

348. We are concerned with Part 3 of the Schedule, which is headed “EU-derived rights etc”: it is thus
concerned with rights other than those conferred directly by domestic or EU legislation, which are the
subjects of Parts 1 and 2. It comprises paragraphs 5 and 6. Paragraph 5 is concerned with rights derived
from a free movement agreement made between the European Union and the Swiss Confederation.
Paragraph 6 reads (so far as relevant):

“(1) Any other EU-derived rights, powers, liabilities, obligations, restrictions, remedies and procedures
cease to be recognised and available in domestic law so far as—

(a) they are inconsistent with, or are otherwise capable of affecting the interpretation, application or
operation of, any provision made by or under the Immigration Acts (including, and as amended by, this
Act), or

(b) they are otherwise capable of affecting the exercise of functions in connection with immigration.

(2)    The reference in sub-paragraph (1) to any other EU-derived rights, powers, liabilities, obligations,
restrictions, remedies and procedures is a reference to any rights, powers, liabilities, obligations,
restrictions, remedies and procedures which—

(a) continue to be recognised and available in domestic law by virtue of section 4 of the European Union
(Withdrawal) Act 2018 (including as they are modified by domestic law from time to time), and

(b) are not those described in paragraph 5 of this Schedule


-----

Commissioner for Refugees intervening) and other case....

(3)   ...”

(“EU-derived” is not a defined term, but it is obvious, and not disputed, that as a matter of language it
would apply to the obligations imposed on the UK Government by the Procedures Directive.)

349. The effect of paragraph 6 (1) of Schedule 1 to ISSCA (to which I will refer simply as “paragraph 6
(1)”) is thus to disapply EU-derived rights to the extent that they are inconsistent with any provision made
by or under “the Immigration Acts”. That term is defined by section 61 (2) of the _[UK Borders Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y0HC-00000-00&context=1519360)_
_[2007,which provides that “[a] reference (in any enactment, including one passed or made before this Act)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y0HC-00000-00&context=1519360)_
to 'the Immigration Acts'” is to a specified list of statutes. For our purposes what matters is that those
[statutes include the Immigration Act 1971,but for reasons which will appear I should give the rest of the list:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

[“(a)  the Immigration Act 1971,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

[(b)   the Immigration Act 1988,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61G0-TWPY-Y03P-00000-00&context=1519360)

[(c)    the Asylum and Immigration Appeals Act 1993,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YG0-TWPY-Y0BK-00000-00&context=1519360)

[(d)   the Asylum and Immigration Act 1996,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y1FP-00000-00&context=1519360)

[(e)    the Immigration and Asylum Act 1999,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)

[(f)    the Nationality, Immigration and Asylum Act 2002,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)

(g) the Asylum and Immigration (Treatment of Claimants, etc.) Act 2004,

[(h)    the Immigration, Asylum and Nationality Act 2006,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y01F-00000-00&context=1519360)

(i)    this Act,

[(j)    the Immigration Act 2014,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)

[(k)    the Immigration Act 2016,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)

(l) Part 1 of the Immigration and Social Security Co-ordination (EU Withdrawal) Act 2020 (and Part 3 so far
as relating to that Part), and

[(m)  the Nationality and Borders Act 2022.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)

(Item (l) was added by section 4 (1) of ISSCA.)

[350. Section 3 (2) of the Immigration Act 1971 provides, so far as relevant, that:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

“The Secretary of State shall from time to time … lay before Parliament statements of the rules, or of any
changes in the rules, laid down by him as to the practice to be followed in the administration of this Act for
regulating the entry into and stay in the United Kingdom of persons required by this Act to have leave to
enter.”

The Immigration Rules are made pursuant to that provision, and although their precise legal status is
notoriously anomalous, it is not in issue before us that for the purposes of paragraph 6 (1) they are to be
regarded as made “under” the 1971 Act. Part 11 of the Rules regulates applications for asylum:
paragraphs 345A-345D fall under that Part.

351. It is the Secretary of State's case that paragraph 27.2 (a) of the Directive is “inconsistent with, or …
otherwise capable of affecting the … operation of” paragraphs 345A-345D of the Immigration Rules
because it imposes a connection requirement which they do not; and that accordingly, by virtue of
paragraph 6 (1), it ceases to that extent to be recognised and available in domestic law”. It follows that
those paragraphs cannot be impugned on the basis that they fail to give effect to the connection
requirement


-----

Commissioner for Refugees intervening) and other case....

352. The Claimants' answer to the Secretary of State's case was advanced by Mr Drabble. He submitted
that if paragraph 6 (1) is read in the context of the Act as a whole it is clear that the reference to provisions
of “the Immigration Acts” is intended to be only to those provisions which are concerned with immigration
as opposed to asylum, which I will call “immigration in the narrower sense”: immigration and asylum are
distinct legal subject-matters, with very different origins and characters. He pointed out that the primary
purpose of the Act as defined in the long title (ignoring its social security co-ordination aspect) is to end
free movement, and that that is all that the heading to Part 1 refers to: free movement is wholly concerned
with immigration and has nothing to do with asylum. He accepted that the long title and section 1 refer not
only to ending rights to free movement but also to repealing “other retained EU law relating to immigration”;
and that that additional element is reflected in the phrase “free movement etc” in the headings to section 1
and Schedule 1. But he submitted that the phrase “relating to immigration” takes its colour from the
primary purpose and can only be read as referring to immigration in the narrower sense; and that the same
goes for the “etc”. That being so, the reference to provisions of “the Immigration Acts” must be similarly
limited so as to apply only to provisions relating to immigration as opposed to asylum.

353. Mr Drabble sought to reinforce that submission by referring to the Immigration, Nationality and
Asylum (EU Exit) Regulations 2019, which were made under powers conferred by section 8 of the 2018
Act to correct “deficiencies in retained EU law” and which revoked a number of community instruments. He
relied in particular on the fact that Schedule 1, which contains the relevant revocations, is divided into two
Parts – Part 1 being headed “Revocations related to immigration and nationality” and Part 2 “Revocations
related to asylum” (the latter including the Dublin Convention and the Dublin III Regulation). He submitted
that that dichotomy illustrated how “immigration” and “asylum” were treated as distinct subject areas in the
context of Brexit-related legislation, itself reflecting the fact that they are regarded as distinct concepts in
EU law which are subject to entirely separate legal frameworks.

354. To the same effect, but more generally, Mr Drabble referred to the list of statutes in section 62 (1) of
the 2007 Act and pointed out that the long titles, of which he handed in a schedule, are drafted on the basis
that “immigration” and “asylum” are distinct: that is, if the statute contains provisions relating to asylum as
[well as immigration the long title always refers to both. For example, the long title of the Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
_[2016 begins “An Act to make provision about the law on immigration and asylum”.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_

355. Mr Drabble also referred to the Explanatory Notes to ISSCA. It is well established that Explanatory
Notes are admissible aids to construction insofar as they “cast light on the objective setting or contextual
scene of the statute, and the mischief at which it is aimed”: see _Westminster City Council v National_
_Asylum Support Service_ _[2002] UKHL 38, [2002] 1 WLR 2956, per Lord Steyn at para. 5. Para. 1 of the_
Notes give a very full “Overview of the Act”. It focuses wholly (leaving aside the social security coordination aspect) on the need to end free movement between the EU and the UK and makes no mention
of asylum. Paras. 70-71 of the Commentary on the particular provisions of the Act read as follows:

“70.  Paragraph 6 ensures any directly effective rights that will have been saved by the EUWA 2018 and
would, in the absence of this paragraph, be retained, cease to apply insofar as they are inconsistent with,
or are otherwise capable of affecting the interpretation, application or operation of, specified domestic
immigration legislation or functions. For example, the residence rights that are derived from Articles 20 and
21 of the TFEU (rights of citizenship and free movement) will be retained EU law and, unless they are
disapplied would provide a right to reside in the UK for certain groups, for example 'Chen' carers who are
primary carers of an EU citizen child who is in the UK and is self-sufficient. However, the rights derived
from Articles 20 and 21 would continue to apply in non-immigration contexts unless disapplied.

71.  The following is a non-exhaustive list of the directly effective rights relevant to this Paragraph. …”.

The list is in the form of a table which identifies seven treaties (broadly, the various EU and
EEA/Switzerland treaties and the Association Agreements with Turkey) and some thirty particular
provisions of those treaties. The subject area of each provision is identified. Several of the subject areas
are identified in terms as “free movement”, either of workers or of services, but the remainder are also
concerned with aspects of the free movement rights (such as discrimination on grounds of nationality or


-----

Commissioner for Refugees intervening) and other case....

rights of family members of those exercising such rights). The Procedures Directive does not appear on
the list and none of the subject matters has anything to do with asylum.

356. Mr Drabble submitted that the passages from the Explanatory Notes quoted above confirm, what was
in any event clear from the language of the Act itself, that Part 1 of ISSCA is concerned only with
“immigration” in the narrower sense and was not intended to have any effect on asylum law. He made
what was substantially the same point by reference to various other Parliamentary materials relating to
what became ISSCA, none of which refer to any impact on asylum law. I need not refer to them in detail,
but they are the report of the House of Lords Delegated Powers and Regulatory Reform Committee (HL
Paper 118, 25.8.20); the Delegated Powers Memorandum dated 24 July 2020, supplied to the Committee
by the Home Office; the Government response to the Committee's report (HL Paper 141, 14.10.20 – see
Annex 1); and the report of the House of Lords Select Committee on the Constitution (HL Paper 120,
2.9.20).

357. Finally, Mr Drabble referred us to two recent decisions of the Supreme Court, Robinson v Secretary
_of State for the Home Department_ _[2020] UKSC 53, [2022] AC 659, and G v G_ _[2021] UKSC 9, [2022] AC_
544. In fact it is the latter which is the more directly relevant for our purposes, and I take it first. A father
resident in South Africa had brought proceedings under the Hague Convention for the return of his child
who had been brought by the mother to England. The mother had claimed asylum for herself and her
child. The High Court had imposed a stay on the Convention proceedings pending the determination of the
asylum claim. The issue in the Supreme Court was whether it had been right to do so. The Home
Secretary was an intervener in the appeal. The Court handed down its decision on 19 March 2021. The
only judgment was given by Lord Stephens. For the purpose of his review of “the legal landscape
governing asylum applications” he said, at paras. 83-84:

“83. In so far as applicable to the United Kingdom the principal EU measures are (i) the Qualification
Directive and (ii) the Procedures Directive (together, 'the Directives').

84. The Secretary of State accepts, for the purposes of this appeal, and I agree, that the relevant
provisions of the Directives are directly effective and remain extant in domestic law as 'retained EU law'
after the United Kingdom's withdrawal from the EU.”

He went on to summarise a number of the provisions of both Directives. Mr Drabble did not contend that
Lord Stephens' statement that the Directives remained law following the UK's withdrawal from the EU was
binding on us: it was debatable whether it formed part of the ratio but even if it did the point had not been
the subject of any argument. He submitted that it was nevertheless weighty support for his proposition that
not only the Court but the Secretary of State understood the position in the same way. He pointed out that
although the Court was not addressed about the effect of ISSCA Lord Stephens was certainly aware of it,
since in _Robinson, which concerned_ _Zambrano rights and in which he had delivered a judgment in_
December 2020, he had referred to the possibility that the law as declared in that case might change
following IP Completion Day as a result of ISSCA, which he described as providing for “repeal of the main
retained EU law relating to free movement” (see paras. 29-30).

Discussion and Conclusion

358. The starting-point must be that on a straightforward reading of the statutory language paragraphs
345A-345D of the Immigration Rules are “provisions made … under the Immigration Acts”, with the
consequence that paragraph 6 (1) has effect to disapply any inconsistent provision of retained EU law.

359. I accept, however, that it is necessary to construe the statute purposively, which means having
regard not simply to the literal meaning of the words in question but to the legislative purpose, to be
gleaned from the entirety of the provisions of the Act (in practice Part 1) and any admissible contextual
materials. Both Mr Drabble and Lord Pannick referred us to paras. 29-31 of the judgment of Lord Hodge in
_R (O) v Secretary of State for the Home Department_ _[2022] UKSC 3, [2023] AC 255(the so-called “BritCits”_
case). I need not set the passage out _in extenso, but the essential point is that the primary source for_
ascertaining the intention of Parliament must be the words used read in the context of the statute as a


-----

Commissioner for Refugees intervening) and other case....

whole (para. 29). External aids to interpretation, such as Explanatory Notes, can only play a secondary
role (para. 30).

360. Accordingly I start with what can be learnt about the purpose of Part 1 from the statute itself. It is
clear from the long title, as well the language and structure of its provisions, that the main purpose is to end
the right to free movement and to repeal legislation related to it; and I accept that that is a purpose that has
nothing to do with asylum. However that is not the only purpose. Section 1 (1) (b) says in terms that
Schedule 1 makes provision to “end other EU-derived rights, and repeal other retained EU law, relating to
immigration”; “other” must mean other than related to free movement.

361. The question then is whether the phrase “relating to immigration” defines that secondary purpose in a
way which excludes EU-derived rights relating to asylum. I do not believe that this is clear. Mr Drabble is
right that in some legislative contexts “immigration” and “asylum” are treated as distinct subject-matters.
But I am not persuaded that there is any settled practice. There are instances in the legislative context of
the term “immigration” being used to cover both immigration, in the narrower sense, and asylum. One
[example is the Immigration Act 2016: although Mr Drabble relies on the fact that the long title refers to both](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
asylum and immigration, it is also significant that the short title does not. Equally, the “Immigration Rules”
include the entirety of the UK's rules governing the determination of asylum claims (see Part 11) and are of
[course made under the Immigration Act 1971. (It may also be pertinent to note, though strictly it is outside](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
the legislative context, that the leading textbook, Macdonald's Immigration Law and Practice, treats asylum
law as an integral part of its subject.) That broader use is not loose or illogical: the effect of a grant of
asylum is to confer on the beneficiary the right to remain in the UK notwithstanding that they do not have
British nationality, or other right of abode, and the relevant law can perfectly naturally be regarded as an
aspect of immigration law.

362. If the use of the term “immigration” itself does not clearly connote an “asylum-exclusive purpose”, I
see nothing else in the statute that does so. The fact that the primary purpose of Part 1 is to end free
movement is in my view neutral: it does not follow that the “other” EU-derived rights relating to immigration
law need be in some sense akin to freedom of movement rights or otherwise relate to immigration in the
narrower sense. The only overall purpose of Part 1 that can be discerned from the Act itself is to remove
or qualify EU-derived rights which are inconsistent with domestic immigration legislation, including the
Immigration Rules: there is no a priori reason why the rights in question should not relate to asylum.

363. The upshot of that discussion is that there is nothing in the other provisions of the Act to suggest a
legislative purpose that would justify departing from the literal language of paragraph 6 (1).

364. I turn to the extraneous materials relied on by Mr Drabble. I accept that the Parliamentary materials
referred to strongly suggest that the Government, as the promoter of what became ISSCA, did not at the
time that the bill was going through Parliament have any specific intention that the EU-derived rights
affected by paragraph 6 (1) would include rights of asylum-seekers: if it did, it is hard to think that the
responsible Home Office officials would not have referred to it in the Explanatory Notes and in the
Government's response to the relevant committee reports in the House of Lords. That is consistent with
the Secretary of State's stance in G v G (though it should be noted that her concession referred only to “the
relevant provisions” of the Directives).

365. That has given me some pause. But it does not follow from the fact that the promoters of a statute
have not foreseen all the particular consequences of its provisions that such consequences must be
treated as falling outside its purpose so as to justify departing from their otherwise clear meaning. What
matters in this case is not whether the Government specifically intended that “asylum rights” should fall
within the scope of paragraph 6 (1) but whether it is clear that it specifically intended that they should fall
_outside its scope._

366. I do not believe that that is established. That is not simply because of the secondary role that
extraneous materials of this kind play in the construction exercise. It is also because it is not clear that
there was any reason at the time that the bill was going through Parliament for the Government to have
considered the question of its impact on asylum rights one way or the other When the Qualification and


-----

Commissioner for Refugees intervening) and other case....

Procedure Directives first came into force Part 11 of the Immigration Rules was re-drafted so as to give
effect to their provisions. There was accordingly no general reason to suppose that there was any
inconsistency on which paragraph 6 (1) would operate: the Directives would simply remain in effect as
retained EU law following IP Completion Day, as the Secretary of State accepted in G v G. It is true that in
the particular case of paragraph 345C such an inconsistency has emerged, but paragraphs 345A-345D
were only added to the Rules on 10 December 2020, after ISSCA had received Royal Assent. We do not
know for how long it had been intended to introduce a rule which allowed removal to a safe third country
with which the applicant had no connection; or whether it had been appreciated that such a rule would be
inconsistent with article 27.2 (a); or, if so, whether it was intended that paragraph 6 (1) would or might
provide the answer. But what matters for present purposes is that it is not clear that at any relevant time
the Government anticipated an inconsistency between the Immigration Rules and retained EU law. That
being so, it is not possible to draw any inference about the intended scope of paragraph 6 (1) from what
was or was not said in the Explanatory Notes or other Parliamentary materials. It is necessary simply to
apply the statutory language, which, as I have said, on its natural meaning applies to any provision made
under the Immigration Rules.

367. I would accordingly uphold the Divisional Court's conclusion on this issue. I have not found it
necessary to refer to its reasoning, which is at paras. 106-118 of its judgment; but I do not detect any
substantial difference between it and my own.

ISSUE 14: CIRCUMVENTION OF SCHEDULE 3 TO THE 2004 ACT

368. Section 33 (1) of the Asylum and Immigration (Treatment of Claimants etc) Act 2004 reads:

“Schedule 3 (which concerns the removal of persons claiming asylum to countries known to protect
refugees and to respect human rights) shall have effect.”

369. Schedule 3, which is headed “Removal of Asylum Seeker to Safe Country”, is in five Parts, but Part 1
is introductory and we are concerned with the relationship between Parts 2-4 on the one hand and Part 5
on the other.

370. Parts 2-4 provide for, respectively, three “Lists of Safe Countries”. Part 2 sets out a list of countries
which are regarded as safe for the purpose of both the Refugee Convention and the ECHR: they are all EU
or EEA states. Parts 3 and 4 make provision for the Secretary of State to list, by order in the form of a
statutory instrument, other states which are to be regarded as safe for the purposes of, in the case of Part
3, both the Refugee Convention and the ECHR and, in the case of Part 4, the Refugee Convention only.
The statutory instrument requires the approval of both Houses of Parliament. The consequences of such
listing vary between the different Parts. In short:

     - For states listed in Part 2 there is, for the purpose of any decision to remove a person to a country of
which they are not a national or of any legal challenge to such decision, (a) an irrebuttable presumption
that any person removed to such a state would not be at risk of ill-treatment contrary to the Refugee
Convention or of removal to any other state other than in accordance with the requirements of the Refugee
Convention (“the Refugee Convention presumption”) and (b) a rebuttable presumption that no person
removed to such a state will either be subject to ill-treatment contrary to article 3 or be removed from it in
breach of their ECHR rights (“the human rights presumption”): both presumptions appear in paragraph 3.
Paragraph 5 provides, consistently with those presumptions, that where the Secretary of State certifies that
it is proposed to remove a person to a state of which they are not a citizen, there shall be (a) an absolute
bar on a person whom it is proposed to remove to a Part 2 state bringing an immigration appeal based
their Refugee Convention rights and (b) a bar on their bringing such an appeal based on a human rights
claim if the Secretary of State certifies that the claim is clearly unfounded – the Secretary of State being
obliged so to certify unless satisfied that it is not clearly unfounded.

    - For Part 3 states, the (irrebuttable) Refugee Convention presumption applies (paragraph 8), and the
corresponding bar on bringing an immigration appeal on Refugee Convention grounds (paragraph 10 (3)).


-----

Commissioner for Refugees intervening) and other case....

There is no human rights presumption but there is a bar on bringing an immigration appeal based on
human rights claims in the same terms as under Part 2 (paragraph 10 (4)).

- For Part 4 states, the position is the same as under Part 3 save that (the relevant paragraphs being 13
and 15), although the Secretary of State has a power to bar an appeal based on a human rights claim by
making a “clearly unfounded” certificate she is not obliged to do so.

It should be noted that where the presumptions apply they are general in character: that is, the
presumption of safety applies to everyone proposed to be removed to the country in question.

371. Part 5 is headed “Countries Certified as Safe for Individuals”. Paragraph 17 provides:

“This Part applies to a person who has made an asylum claim if the Secretary of State certifies that—

(a) it is proposed to remove the person to a specified State,

(b) in the Secretary of State's opinion the person is not a national or citizen of the specified State, and

(c) in the Secretary of State's opinion the specified State is a place—

(i) where the person's life and liberty will not be threatened by reason of his race, religion, nationality,
membership of a particular social group or political opinion, and

(ii) from which the person will not be sent to another State otherwise than in accordance with the Refugee
Convention.”

Paragraph 19 provides:

“Where this Part applies to a person—

(a) …

(b) he may not bring an immigration appeal in reliance on an asylum claim which asserts that to remove
the person to the State specified under paragraph 17 would breach the United Kingdom's obligations under
the Refugee Convention,

(c) he may not bring an immigration appeal in reliance on a human rights claim if the Secretary of State
certifies that the claim is clearly unfounded, and

(d) …”

There is accordingly no presumption of the kinds provided for in Parts 2-4. Part 5 is concerned only with a
bar on the bringing of immigration appeals. The relevant certifications – under paragraphs 17 (c) and 19
(c) – necessarily require an assessment of the risk to the particular individual.

372. Rwanda is not listed in Part 2 and has not been specified in an order made under Part 3 or Part 4.
The Secretary of State has, however, in the case of each of the Claimants certified under paragraph 17 (c)
that Rwanda is a place where their life and liberty will not be threatened on any of the specified grounds
and from which they will not be refouled – in short, that it is safe. (She has also, as we have seen, certified
their human rights claims as clearly unfounded under paragraph 19 (c); but that is not the material
certification for the purpose of this issue.) The decision letters in each case, which are in this respect in
standard form, say that the decision is based in part on the judgment in the Asylum System CPIN.

373. The Claimants' case as regards this issue can be summarised as follows:

(1) It is implicit in the structure of Schedule 3 that the statutory intention is that any general presumption as
to the safety of a country must be effected by including it in a List under one of Parts 2-4, which requires
the approval of Parliament.

(2) The effect of the assessments contained in the CPINs is in substance to create a general presumption
that Rwanda is a safe country.


-----

Commissioner for Refugees intervening) and other case....

(3) Accordingly the making of a certificate under paragraph 17 based on those assessments circumvents
the statutory scheme by applying a presumption which has not received Parliamentary approval and is
therefore unlawful.

374. I do not believe that that case is well-founded. Specifically, I do not accept that the assessments
contained in the CPINs constitute presumptions of the same kind as those enacted in parts 2-4 of
Schedule 3: they are of an essentially different character. The Preface to the Assessment CPIN begins, in
what is evidently standard language for CPINs, by describing their purpose and nature generally. The
fourth paragraph reads:

“In addition to background information obtained from a range of sources, [CPINs] also include relevant
caselaw and our (CPIT's) general assessment of the key aspects of the refugee status determination
process (that is risk, availability of protection, possibility of internal relocation, and whether the claim is
likely to be certified as 'clearly unfounded').”

It continues:

“This note provides an assessment of Rwanda's asylum system, support provisions, integration
opportunities as well as some of the general, related human rights issues for use by Home Office decision
makers handling particular types of protection and human rights claims.

It is not intended to be an exhaustive survey of a particular subject or theme.

It analyses the evidence relevant to this note – that is: information in the contained in the separate country
information reports (see below); refugee/human rights laws and policies, in particular paragraph 345B of
the immigration rules which sets out when a country is a 'safe third country of asylum'; and applicable
caselaw – describes this and its inter-relationships, and provides an assessment of whether, in general,
there are substantial grounds for believing that a person, if relocated to Rwanda, would face a real risk of
being subjected to treatment contrary to Article 3 of the European Convention on Human Rights (ECHR).”

After referring to the other CPINs which I have identified at para. 138 above, it concludes:

“Decision makers must, however, still consider all claims on an individual basis, taking into account each
case's specific facts [emphasis in original].”

375. That approach recognises that the exercise for which CPINs are required is one of taking decisions
on a case-by-case basis: that is stated in terms in the final sentence but is in fact clear from the entirety of
the passage. The assessments contained in the CPIN will of course be general in character, but that is not
inconsistent with individualised decision-making. As Lord Kerr observed at para. 70 of his judgment in R
_(EM (Eritrea)) v Secretary of State for the Home Department_ _[2014] UKSC 12, [2014] AC 1321, “[t]he court_
must examine the foreseeable consequences of sending a claimant to the receiving country bearing in
mind both the general situation there and the claimant's personal circumstances [my emphasis]”. As
regards the first element, it is not only legitimate but inevitable that caseworkers will have regard to general
assessments of the kind contained in CPINs. As the Secretary of State observes at para. 91 of her
skeleton argument,

“The notion of a completely 'ad hoc' or 'one-off' assessment is unreal: it is inevitable that recurring issues
will arise in relation to particular countries which it is desirable to resolve on a consistent basis.”

I accept that some of the assessments contained in the CPINs are likely in practice to be treated as
definitive of the particular question which they address – see, for example, the assessment about the risk
of refoulement quoted at para. 297 above. But that does not mean that the nature of the exercise under
Part 5, which requires individualised decision-making, can be equated with the application of a
presumption under Parts 2-4.

376. That being so, the Secretary of State cannot in my view be regarded as circumventing Parliament's
intention by choosing in these cases to make use of her individual certification powers under Part 5 rather
than seeking to have Rwanda listed as a generally safe country under Part 3 or 4. The provisions of the


-----

Commissioner for Refugees intervening) and other case....

various Parts offer different possible mechanisms for limiting claimants' rights to challenge safe third
country decisions. Each mechanism will to some extent involve the Secretary of State making a general
assessment of matters relevant to the safety of the country in question, and to that extent there is a degree
of overlap between them. Nevertheless, each has its different characteristics and its different advantages
and disadvantages. Parts 3 and 4 give the Secretary of State the advantage of being able to apply a
general presumption of safety, without having to make an individualised assessment, but they involve the
no doubt cumbersome exercise of enacting secondary legislation and obtaining Parliamentary approval. I
can see no basis for implying into the statute an obligation to use the Parts 2-4 mechanism in every case
where the Secretary of State makes a “general” assessment of some kind. Indeed, given the fact that, as I
have said, there will be an element of such assessment in every individual decision, it is hard to see how
such an implication would be workable.

377. I would accordingly uphold the Divisional Court's conclusion on this issue also. Again, I have not
found it necessary to set out its reasoning, which is at paras. 78-84 of its judgment; but it is to the same
effect as mine.

ISSUE 15: DATA PROTECTION

378. The eighth issue considered by the Divisional Court was defined by it as follows:

“Have there been breaches of the _[Data Protection Act 1998 and/or the UK General Data Protection](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y13M-00000-00&context=1519360)_
Regulation in the implementation of the Rwanda policy? Do such breaches invalidate decisions taking
under either paragraph 345A or 345C of the Immigration Rules?”

That issue arose from grounds of challenge pleaded by SAA and argued before the Divisional Court, as
also before us, by Mr Manjit Gill KC. I will refer to them as “the data protection grounds”.

379. The Divisional Court dismissed the data protection grounds and refused permission to appeal. In my
judgment dated 14 March 2023 considering the outstanding applications for permission to appeal I directed
that the application be adjourned to the hearing of the appeal on the other issues, on a “rolled-up” basis. In
the event we heard oral submissions from Mr Gill directed simply to the issue of permission.

380. For the reasons I give below I would refuse permission to appeal. That being so, it is unnecessary
that I set out the factual and legal background, which are fully set out in the judgment of the Divisional
Court.

381. The Court addressed the data protection grounds at paras. 127-149 of its judgment. It explains at
paras. 127-130 that, pursuant to the terms of the MoU, once SAA had been served with a Notice of Intent
to relocate him to Rwanda the Home Office provided the Rwandan authorities with details of SAA's name,
date of birth, sex, nationality, and the date he made his asylum claim in the United Kingdom, together with
a photograph. At para. 131 it summarised SAA's case as follows:

“First, that transfer of personal data to Rwanda on the terms set out in the MOU is contrary to the
requirements in Chapter V of Retained European Parliament and Council Regulation (2016/679/EU), better
known as the United Kingdom General Data Protection Regulation ('the UK GDPR'). Chapter V makes
provision regulating the transfer of personal data to third countries. Second, that the Home Secretary has
failed to comply with article 13 of the UK GDPR, which requires a data controller when obtaining personal
data from a data subject to provide information, for example on the purposes for which the data obtained
will be processed. Third, that the data protection impact assessment prepared by the Home Secretary in
respect of the MEDP, to meet the requirements of article 35 UK GDPR, is defective.”

382. The Divisional Court did not, however, decide any of those issues. Instead, at para. 132, it pointed
out that there was what it called a “logically prior issue”, namely:

“Even assuming that SAA is correct on any or all of his submission on compliance with the UK GDPR,
does that affect the legality of any decision the Home Secretary has taken under paragraph 345A or 345C
of the Immigration Rules such that it would be appropriate to quash that decision for that reason?”


-----

Commissioner for Refugees intervening) and other case....

As to that, it recorded Mr Gill's case as follows (para. 133):

“The submission for SAA is to the effect that the power to make decisions under the Immigration Rules
(i.e., decisions under paragraph 345A and 345C) depended on compliance with whatever requirements
might arise either under the UK GDPR or under its counterpart, the _[Data Protection Act 2018 … In](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)_
consequence, failure to comply with data protection law would require the conclusion that the immigration
decisions were unlawful and should be quashed.”

383. The Divisional Court did not accept that submission. Between paras. 135 and 142 it considered each
of the three complaints identified in para. 131 and concluded that even if each was made out it would not
have the consequence that the decision to relocate SAA should be quashed. In short:

(1) As regards the alleged failure to carry out a proper data protection impact assessment (“DPIA”)
pursuant to article 35 of the UK GDPR, it held that “[t]he legal requirement to undertake that assessment is
not a matter that is integral to the validity of the decisions (to be taken in the future) under the Immigration
Rules” (para. 135).

(2) As regards the alleged breach of the obligation to provide SAA with sufficient information about the
processing of his data, pursuant to article 13, it held that there was “no relevant connection between a
breach of article 13, the consequences of the breach, and any standard going to the validity of the public
law decision” (para. 137). It pointed out that SAA had free-standing remedies under the UK GDPR and the
2018 Act.

(3) As regards compliance with the requirements of Chapter V of the UK GDPR, it accepted that the
Secretary of State's decision to remove SAA to Rwanda depended on the consent of the GoR to receive
him and that the personal data sent to Rwandan authorities as noted at para. 381 above was sent for the
purpose of obtaining that consent. But it held that it did not follow that any non-compliance with the
conditions imposed by Chapter V for transfer of personal data to third countries meant that the GoR's
consent was ineffective or therefore that the removal decision was invalid (para. 141). It noted that that
conclusion, reached on public law principles, was reinforced by the fact that neither the UK GDPR nor the
2018 Act provided that past transactions relying on data processed in breach of data protection law are
thereby invalidated (para. 142).

384. Having performed that exercise, it concluded, at para. 143:

“All this being so, the data protection law submissions in this case are not capable of producing the
conclusion that the Home Secretary's decisions under Immigration Rules are unlawful.”

It went on at paras. 144-148 to express some views on the substance of SAA's complaints but on an
expressly obiter basis.

385. SAA now advances a single ground of appeal, ground 23 in the consolidated grounds, which reads:

“The court erred in holding that the Appellant's data protection arguments were not relevant to any public
law decision, and it erred in not addressing the Appellant's data protection arguments lawfully, or
adequately, or at all.”

386. That challenges the basis on which the Divisional Court decided the eighth issue, but in order to
identify the reasoning behind the challenge it is necessary to look at the skeleton argument. This makes
thirteen points, at paras. 32-47. I will consider those points in turn. I should say that Mr Gill did not seek to
develop them in his oral submissions, which were addressed to broader questions which I have to say did
not appear to me to bear on the Divisional Court's dispositive reasoning.

387. The first point is that the Divisional Court's “logically prior issue” had not been raised by the Secretary
of State but was instead raised by the court itself in the course of oral submissions. Even if that is correct, it
goes nowhere if the point is in fact good.


-----

Commissioner for Refugees intervening) and other case....

388. The second point is that the Divisional Court “did not address the relevant public law decisions ... or
consider how the data arguments related to them”. I do not accept that. On the contrary, it is precisely the
exercise which the Court carried out between paras. 135 and 142 of its judgment.

389. The third point arises from para. 134 of the Divisional Court's judgment, where it said:

“As a matter of principle, it cannot be that any breach of any rule on the part of a public authority or for
which that authority is responsible, occurring in the context of either making or executing a public law
decision will necessarily affect the validity of that public law decision. To take an obvious example, if a
person being removed from the United Kingdom was assaulted by a Home Office official on his way to the
airport, that assault would be unlawful but would not in itself compromise the legality of the immigration
decision that was the reason for removal. On its facts, this example is some way distant from the cases
now before us. However, on the facts that are before us, the same conclusion should be reached.”

It is said that the assault example is not analogous with the circumstances of the present case. But the
Court expressly acknowledged that. The example was simply offered as a vivid example of the general
principle. The relationship between the alleged breaches of data protection law and the public law
decisions taken in SAA's case was carefully considered in the paragraphs to which I have referred.

[390. The fourth point is that “compliance with the SSHD's obligations under DPA 2018 and UK GDPR is a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)
necessary prerequisite or a sine qua non in practice of a removal decision under para. 345C”. That may
be correct, but it does not follow that non-compliance invalidates the decision.

391. The fifth point is that the decision whether Rwanda was a safe third country within the meaning of
para. 345B required a consideration of whether its data protection regime was adequate. Mr Gill
contended that there was a wealth of evidence that that was not the case and that the Secretary of State
had failed to assess the relevant risks by carrying out a properly comprehensive DPIA. But a case of that
kind does not fall within the eighth issue as defined by the Divisional Court, which is the subject of the
ground of appeal. (It does not in fact appear that the Court believed that such a case was before it at all,
and I have not been able to identify it in SAA's original grounds of judicial review.)

392. The sixth point is that a DPIA had to be carried out before a decision was reached to transfer the
personal data in question or under paragraphs 345B and 345C. That may be so, but it does not address
the Divisional Court's point that the carrying out of the DPIA was not integral to the removal decisions
taken.

393. The seventh and eight points are, respectively, that “the burden was on SSHD to carry out such an
inquiry and to undertake such a DPIA” and that a DPIA was necessary not only by reference to article 35
itself but also because it was required by article 71 of “the Withdrawal Agreement 2020”. But again, neither
point addresses the question whether its carrying out was integral to the removal decisions.

394. The ninth point is that the scope of the DPIA should conform to the guidance given in the case-law of
the Court of Justice of the European Communities in such cases as _Schrems v Data Protection_
_Commissioner_ _C-362/14, [2016] QB 527, and_ _Data Protection Commissioner v Facebook Ireland Ltd_ _C-_
_311/18, [2021] 1 WLR 751. The Divisional Court had in the obiter section of its judgment said that those_
cases did not provide the appropriate yardstick, and that point is challenged in the skeleton argument. But
none of this goes anywhere if the Divisional Court's logically prior point is good.

395. The tenth point develops the argument that the Secretary of State failed to comply with the
requirements of article 13 of the UK GDPR, noting that the Divisional Court had in the obiter part of its
judgment appeared to accept that that was so. But that only serves to emphasise that the issue here is not
whether there was a breach but whether it impacted on “the validity of the public law decision” (see para.
383 (2) above). That question is not addressed.

396. The eleventh point is that “all such enquiries” – which I take to be a reference to the DPIA but
perhaps also to the requirements of Chapter V of the UK GDPR – had to be made prior to the transfer of


-----

Commissioner for Refugees intervening) and other case....

the data, which was itself required by the GoR prior to any relocation decision.  But the answer is the
same as to the fourth point: it does not follow that non-compliance invalidates the decision.

397. The twelfth point is that

“… the SSHD would have to investigate and inquire if there are any other risks in Rwanda to the essence
of the asylum seekers correlated human rights under the ECHR, including to his rights to data protection
under Art 8 ECHR, such as to make a removal decision under para 345C inappropriate”.

As with the fifth point, a case that paragraph 345C had not been complied with because of a risk of data
protection breaches in Rwanda that would impact on SAA's privacy is not within the scope of the eighth
issue (nor have I been able to identify it in the original grounds of judicial review).

398. The thirteenth point appears to be that the Secretary of State is relying on the MEDP, which is a
treaty taking effect at the level of international law, in order to justify a breach of domestic data protection
law. That bears no relation to the basis on which the Divisional Court decided the eighth issue – or, so far
as I can see, to any argument advanced by the Secretary of State.

399. Although I have thought it right to go through each of the points in the skeleton argument, the simple
fact is that neither there nor in Mr Gill's oral submissions has SAA advanced any response to the Divisional
Court's dispositive reasoning that has any real prospect of success.

400. I would accordingly refuse permission to appeal on ground 7.

ISSUE 16: PROCEDURAL FAIRNESS

Introduction

401. In addition to the seven claims brought by individual Claimants, on 9 June 2022 the charity Asylum
Aid brought judicial review proceedings seeking to challenge

“… [t]he procedure and arrangements (including the Inadmissibility Guidance …) adopted by the SSHD in
respect of forced removals to Rwanda made pursuant to the Migration and Economic Development
Partnership announced on 14 April 2022”.

As developed, its challenge was specifically to the fairness of the procedure leading up to the decision in
the case of any individual that they should be relocated to Rwanda – or, more accurately, the several
decisions which lead to that outcome. The challenge is to the overall fairness of the system and is generic
in character: it is not concerned with the fairness of the decisions taken in the cases of any individual
Claimants. That challenge is considered at paras. 380-429 of the Divisional Court's judgment, together
with some related challenges to the fairness of the procedure advanced by individual Claimants. It was
dismissed.

402. Permission to appeal was given by the Divisional Court on six grounds, to which I will return below:
they were originally numbered 1-6 but they have been re-numbered 15-20. Those grounds were advanced
before us by Ms Charlotte Kilroy KC. The AAA Claimants and RM also have permission to advance
grounds on procedural fairness (grounds 21 and 22 respectively). The AAA Claimants do not raise any
point not advanced by Asylum Aid; I address RM's ground at para. # below. The charity Freedom from
Torture and the United Nations Special Rapporteur on Trafficking in Persons were given permission to
intervene by written submissions. I have read their submissions and bear them in mind in considering the
issues raised by Asylum Aid's grounds.

The Procedure

403. For ease of reference, I repeat here the terms of paragraphs 345A-345D of the Immigration Rules:

_“Inadmissibility of non-EU applications for asylum_

345A. An asylum application may be treated as inadmissible and not substantively considered if the
Secretary of State determines that:


-----

Commissioner for Refugees intervening) and other case....

(i) the applicant has been recognised as a refugee in a safe third country and they can still avail
themselves of that protection; or

(ii) the applicant otherwise enjoys sufficient protection in a safe third country, including benefiting from the
principle of non-refoulement; or

(iii) the applicant could enjoy sufficient protection in a safe third country, including benefiting from the
principle of non-refoulement because:

(a)  they have already made an application for protection to that country; or

(b)  they could have made an application for protection to that country but did not do so and there were no
exceptional circumstances preventing such an application being made, or

(c)  they have a connection to that country, such that it would be reasonable for them to go there to obtain
protection.

_Safe Third Country of Asylum_

345B. A country is a safe third country for a particular applicant, if:

(i) the applicant's life and liberty will not be threatened on account of race, religion, nationality,
membership of a particular social group or political opinion in that country;

(ii)  the principle of non-refoulement will be respected in that country in accordance with the Refugee
Convention;

(iii)  the prohibition of removal, in violation of the right to freedom from torture and cruel, inhuman, or
degrading treatment as laid down in international law, is respected in that country; and

(iv)  the possibility exists to request refugee status and, if found to be a refugee, to receive protection in
accordance with the Refugee Convention in that country.

345C.  When an application is treated as inadmissible, the Secretary of State will attempt to remove the
applicant to the safe third country in which they were previously present or to which they have a
connection, or to any other safe third country which may agree to their entry.

_Exceptions for admission of inadmissible claims to UK asylum process_

345D. When an application has been treated as inadmissible and either

(i)  removal to a safe third country within a reasonable period of time is unlikely; or

(ii)  upon consideration of a claimant's particular circumstances the Secretary of State determines that
removal to a safe third country is inappropriate

the Secretary of State will admit the applicant for consideration of the claim in the UK.”

404. The decision-making process followed in the cases of the individual Claimants is fully set out at
paras. 29-35 of the Divisional Court's judgment. It was common ground that the same process was
intended to be followed in all cases involving removal to Rwanda under the MEDP. I will gratefully
reproduce the Court's account, though in slightly edited and abbreviated form.

405. Persons considered as potentially appropriate for relocation to Rwanda would have been detained
shortly after arrival in the United Kingdom, and would be subject to the usual steps applied to all newlydetained persons. Among other matters, each person detained was to be:

(a)  subject to an assessment of his language skills to determine proficiency in English;

(b)  assessed by healthcare staff with a view to deciding if further healthcare provision is required;

(c)  issued with a mobile phone and given information about IT facilities at the detention centre;

(d)  given information about the centre's welfare officer; and


-----

Commissioner for Refugees intervening) and other case....

(e)  given information on how to obtain legal representation, if he did not already have it, including
information on the free duty solicitor scheme.

406. If they made an asylum claim, as all the Claimants did, shortly after the claim was made (usually
within a day or so) they would attend an asylum screening interview.

407. Each claim was then considered by the Home Office National Asylum Allocations Unit (“the NAAU”).
The Inadmissibility Guidance provided that if the NAAU suspects that the claimant “... may [in the course of
travelling to the United Kingdom] have spent time in or have a connection to a safe third country ...” the
case must be referred to the Third Country Unit (“the TCU”) for consideration of whether an inadmissibility
decision should be taken. The TCU then reviewed claims referred to it to determine whether they “...

[appear] to satisfy paragraphs 345A and 345B of the Immigration Rules”. If a case fell into this category,
the TCU would issue the claimant with a standard-form Notice of Intent.

408. I need not set out the full terms of the Notice of Intent, but it begins as follows:

“We have evidence that before you claimed asylum in the United Kingdom, you were present in or had a
connection to [name the safe country or countries]. This may have consequences for whether your claim is
admitted to the UK asylum system.

We will review your particular circumstances and the evidence in your case, and consider whether it is
reasonable to have expected you to have claimed protection in [country or countries] (or to have remained
there if you had already claimed or been granted protection), and whether we should consider removing
you there or elsewhere.”

It goes on to inform the recipient that if inadmissibility action appears appropriate a safe third country,
including Rwanda, may be asked if it will admit him or her. The Notice includes the following statement:

“If you wish to submit reasons not already notified to the Home Office why your protection claim should not
be treated as inadmissible, or why you should not be required to leave the UK and be removed to the
country or countries we may ask to admit you (as mentioned above), you should provide those reasons in
writing within 7 calendar days [for detained cases] or 14 calendar days [for non-detained cases] of the date
of this letter. After this period ends, we may make an inadmissibility decision on your case, based on the
evidence available to us at that time.”

Since in cases of the kind with which we are concerned the claimant will be in detention, the relevant
period for the provision of such reasons would be seven days. It was the Secretary of State's evidence,
although this is not stated in the Notice of Intent, that that period can, as a matter of discretion, be
extended on request: see para. 434 below.

409. Following the expiry of the seven-day period the Secretary of State proceeds to take the relevant
decisions, being:

- a decision that the claim is inadmissible, applying paragraph 345A of the Immigration Rules;

- the decision on removal to Rwanda, applying paragraph 345C (and paragraph 345D where necessary);

- a decision on certification under paragraph 17 of Schedule 3 to the 2004 Act; and

- where a human rights claim has been made, a decision on certification under paragraph 19 (c) of
Schedule 3.

410. Although that fourfold break-down of the relevant decisions appears to reflect the structure of the
decision letters, Ms Kilroy submitted that in substance the Secretary of State was obliged to make at least
six decisions, identified at paras. 43-50 of Asylum Aid's skeleton argument. It is unnecessary to go through
her analysis because the decisions in question can be broken down in various ways: what matters is her
overall point, which I accept, that the decision-making process may involve numerous questions and that
that will be reflected in the matters on which claimants may wish to make representations. I note, because
our focus so far has been on issues relating to the safety of Rwanda, that one issue that may arise under


-----

Commissioner for Refugees intervening) and other case....

paragraph 345A is whether there were exceptional circumstances preventing a claimant from making an
application for asylum in any safe third country through which they may have passed: see head (iii) (b).

411. Removal directions can be issued as soon as those decisions are communicated. In the case of the
Claimants, removal directions were issued only a few days after the initial decisions in late May/early June
2022. In accordance with normal practice governing removal directions, there would be an interval of at
least five days between the date of the direction and the proposed date of removal.

412. I should mention one other point about the structure of paragraphs 345A-345D. A claimant may
make representations which do not go either to the issue of inadmissibility under paragraph 345A or to
whether Rwanda is a safe third country under paragraph 345C (which brings in the criteria in paragraph
345B). Specifically:

(1) As Lord Pannick confirmed when asked by the Court, paragraph 345B does not address the risk of
serious ill-treatment within the country in question: head (iii) as drafted is concerned only with ill-treatment
in any country to which the third country might remove the claimant. Removal to a third country where
there was such a risk would involve a breach of article 3 in accordance with the Soering principle.

(2) Neither paragraph requires consideration of other personal matters which a claimant might wish to
advance as reasons why they should not be removed to a safe third country, for example medical issues or
the presence of other family members in the UK: paragraph 345A is concerned entirely with inadmissibility,
and paragraph 345C simply states the consequence of inadmissibility, namely removability to a safe third
country.

The Secretary of State does not dispute that any such representations would have to be considered by her,
but it is not entirely clear where they fit into the formal analysis. Lord Pannick said that they did not fall for
consideration under any specific provision of the Rules, but that in taking a removal decision under section
345C the Secretary of State would be obliged by section 6 of the Human Rights Act to decide whether
removal would breach the person's Convention rights. The latter proposition is no doubt correct, but in
principle a claimant is not confined to representations based on Convention rights. My provisional view is
that representations relating to all matters other than inadmissibility would in fact go to whether removal is
“inappropriate” under paragraph 345D (ii); but it is unnecessary to reach a final conclusion.

The Grounds: Overview

413. Asylum Aid's primary case, as Ms Kilroy confirmed, is that the seven-day period allowed for the
making of representations following the service of a Notice of Intent will in virtually every case be too short
to allow for the making of any effective representations. Its ground 17 challenges the Divisional Court's
rejection of that case.

414. The length of time reasonably required will of course depend on a number of factors, including (a) the
scope of the matters on which representations may be made, (b) whether the claimants will need legal
advice and (c) whether they need further information from the Secretary of State in order to be able to
make effective representations. The Divisional Court made findings on those questions, and they are the
subject of the challenges in grounds 15-16 and 18. Grounds 19 and 20 are of a rather different character.
Although it might be more logical to re-order the grounds, I have found it simpler to take them in the order
that they are advanced.

415. In the light of our decision on the issue of the safety of Rwanda no removals under the MEDP will be
proceeding for some time. To that extent, the generic challenge to the system for taking decisions for such
removals has become academic. That does not mean that we should not determine Asylum Aid's appeal,
because removals may resume in due course, whether as a result of a successful appeal or because the
defects in the Rwandan asylum system are effectively addressed. However, we should confine ourselves
to deciding the specific issues raised by the grounds, and should eschew offering any wider guidance
about what procedural fairness might entail in future cases of this kind, where the circumstances may be
different. In any event, the hearing before us did not afford an opportunity for a general review of the
proced re adopted


-----

Commissioner for Refugees intervening) and other case....

416. There was no dispute before us as to the fundamental requirements of common law fairness. They
are classically stated by the House of Lords in _R v Secretary of State for the Home Department, ex p_
_Doody [1994] 1 AC 531, but we were referred also to the judgment of this Court in Balajigari v Secretary of_
_State for the Home Department_ _[2019] EWCA Civ 673, [2019] 1 WLR 4647, at paras. 45-61. It is well-_
recognised that procedural fairness is a matter of peculiar importance in asylum cases: see, e.g., the
observations of Bingham LJ in Secretary of State for the Home Department v Thirukumar [1989] Imm AR
402, at p. 414. The application of those principles in a given case depends on the particular circumstances
of that case, and I do not propose to burden this judgment with further citation of authority.

Ground 15: Scope of Representations

417. Ground 15 begins with a general averment that the Divisional Court was wrong to reject Asylum Aid's
case that the Rwanda policy was systemically unfair. However, that general pleading is followed by the
specific criticism – introduced by the word “including” – of the Court's finding that “procedural fairness did
not require the provision of information relating to, or the opportunity to make representations on, the
matters set out in §345B (ii)-(iv) …”; and the skeleton argument is directed only to that criticism. The issue
raised by this ground is whether fairness required that asylum claimants served with a Notice of Intent
should be able to make effective representations about the safety of Rwanda generally (i.e., broadly, the
matters covered by heads (ii)-(iv) under paragraph 345B of the Immigration Rules) – “the general safety
question” – or only about why it was unsafe for the particular claimant (broadly, head (i) under paragraph
345B) – “the specific safety question”. Ms Kilroy submitted that that dichotomy is artificial and breaks down
when it has to be applied in practice. I have sympathy with that submission: see Lord Kerr's observations
in EM (Eritrea) referred to at para. 375 above. But the distinction plays an important part in the reasoning
of the Divisional Court, and I will accept it for present purposes.

418. In the Divisional Court the Secretary of State's initial position was that fairness required that claimants
be entitled to make effective representations on the question whether “Rwanda is a safe country”
simpliciter. But in the course of the October hearing, she changed her position as a result of questions
from the Court. Her revised position was that fairness only required that claimants should be entitled to
make representations about “whether there is any reason specific to the Claimant why Rwanda would not
be a safe third country in the individual circumstances of the Claimant”. The Court permitted her to
advance that revised case, but it was not possible to hear submissions about it at the hearing, and the
issue was resolved on the basis of written representations lodged subsequently: more details can be found
at paras. 386-387 of the judgment.

419. The Divisional Court accepted the Secretary of State's revised submission. Its reasons appear at
paras. 388-395. The relevant passage for our purposes starts with para. 390. The drafting is complicated
by the fact that the Court was considering both this issue and the related issue of whether the Secretary of
State should be expected to provide further information; but the gist of its conclusion was that fairness
required that they be entitled to make representations on the specific but not the general safety question.
At para. 391 the Court summarises Asylum Aid's submissions to the contrary, which included the
submission that it was impossible in practice to distinguish between the two questions. At para. 392 it
responds to those submissions as follows:

“A distinction does exist between the criteria at paragraph 345B of the Immigration Rules. Criterion (i) is
formulated by reference to the asylum applicant's own circumstances and characteristics, criteria (ii) - (iv)
are framed by reference to the general position in the country in question. The real issue is whether that
distinction is material for the purposes of setting what is required by law for fair exercise of the paragraph
345C power to remove to a safe third country. Our conclusion is that the distinction between what an
asylum claimant may be able to say about his own circumstances and how those might be relevant to
whether he is removed to a particular country, and whether that country, generally, complies with its
obligations under the Refugee Convention does determine the extent of the legal requirement of
procedural fairness in this context. Procedural fairness requires that an asylum claimant should have the
opportunity to make representations on matters within the criterion at paragraphs 345B(i) of the


-----

Commissioner for Refugees intervening) and other case....

Immigration Rules. Those are matters relevant to any decision to remove (self-evidently) and matters the
asylum claimant is uniquely placed to consider and explain. Matters known to the asylum claimant may be
a relevant consideration; the Home Secretary must take it into account; and the duty to act fairly must
apply to require the claimant to have an opportunity to make representations. The same applies to the
criteria at paragraph 17(c) of Schedule 3 to the 2004 Act which are also directed to the specific position of
the asylum claimant. _Criteria (ii) - (iv) within paragraph 345B of the Immigration Rules are different, and_
_require evaluation of whether, generally, the relevant country complies with its obligations under the_
_Refugee Convention. Those matters will go well beyond the circumstances of any one asylum claimant;_
they are also criteria which the Home Secretary, given the resources available to her, is well-placed to
assess. _We do not consider that the duty that the Home Secretary act fairly in exercise of the power at_
_paragraph 345C of the Immigration Rules requires an asylum claimant to have the opportunity to make_
_representations on these matters. It is not enough to say that criteria (ii) - (iv) are relevant to the decision to_
remove and since the asylum claimant is the subject of that decision he must have a legal right to comment
on those matters before the decision is made. That is a non-sequitur. The scope of the obligation to act
fairly is measured in specifics. This is not to say that any individual faced with the possibility of removal to a
third safe country could not seek to persuade the Home Secretary that one or other of criteria (ii) - (iv) was
not met, and that if such representations were made, the Home Secretary should have regard to them. But
such representations would not be made in exercise of any legal right arising out of an obligation to ensure
procedural fairness. Further, to the extent that an asylum claimant may wish to make such representations
he has sufficient information about what such representations must be directed to, by reason of paragraph
345B itself. That explains the matters the Home Secretary must consider. The legal duty to act fairly does
not require the Home Secretary provide him with all the material available to her; the legal duty to act fairly
does not in the present context require that an asylum claimant be put in the position to second-guess the
Home Secretary's evaluation on criteria (ii) - (iv).”

420. I have italicised the parts of the passage which decide as a matter of principle the scope of the
matters on which fairness requires that claimants should be entitled to make representations. It is true that
the Court goes on to acknowledge that the Secretary of State might have to consider representations made
otherwise than by way of legal right, but I need not for present purposes try to unpack that proposition, and
I will focus on the italicised words. The last three sentences are concerned with the separate issue of
whether the Secretary of State was obliged to provide asylum-seekers whom she proposed to relocate to
Rwanda with “all the material she has relied on to decide that Rwanda is a safe third country (including the
material she relied on to reach the conclusion that Rwanda would abide by its obligations under the MOU
and the notes verbales)” (see para. 385 (2) of the judgment); but the issues are clearly related, and the
Court's reasoning clearly reflects its reasoning on the issue of the scope of the representations which they
were legally entitled to make.

421. In the circumstances of the present case the Divisional Court's conclusion in para. 390 of its
judgment, amplified in para. 392, was in my respectful view wrong. As Ms Kilroy submitted, as a matter of
principle a person should be permitted to make representations about any matter relevant to an adverse
decision about their case, and it is no answer to say that they might not be as “well-placed” as the decisionmaker to make the decision itself. I accept that there may in some cases be matters contributing to the
decision about which representations would for some objective reason be pointless. But that is not the
case here. An individual asylum-seeker may not personally know anything about Rwanda, but they are
entitled to rely on the research or expertise of people or institutions representing their interests. The
position might be different if there had already been a decision of the Court (or perhaps some other
authoritative independent body). In that case fairness might indeed not require that claimants have the
opportunity to seek to persuade the Secretary of State to go behind that decision (at least unless they
could provide compelling evidence of a relevant change of circumstances[9]). The Divisional Court made
this very point at para. 395 of its judgment, where it said:

“… [F]or the future … the generic issues raised by the Claimants as to why relocation to Rwanda would be
unlawful have now been determined by this court (subject to any appeal) and subject to any relevant new
information emerging ”


-----

Commissioner for Refugees intervening) and other case....

But those were not the circumstances here. There had been at the date of the removal decisions no
determination by the Court; and fairness required that the Claimants have the opportunity to try to
persuade the Secretary of State that her conclusion on the general safety issue was wrong.

422. I should say that the Secretary of State did not make any substantive submissions in support of the
impugned statement. Rather, Lord Pannick's submission to us was that the issue was academic because
the Secretary of State had in fact undertaken to consider all submissions, whether on the general or on the
specific safety question. Whether or not that is so, the point is important in principle.

423. I should record that the Secretary of State filed a Respondent's Notice in relation to this ground,
contending that if there was in fact “a common law obligation to invite representations on the general safety
of Rwanda, it was sufficient that the Secretary of State gave notice that she considered Rwanda to be a
safe country and invited representations as to whether there was any reason the person should not be
removed from the UK to Rwanda”. I am inclined to think that that is correct, but even if it is it does not
affect the substance of Asylum Aid's challenge.

424. In summary, I believe the point raised by ground 15 is good, but it does not necessarily impugn the
Divisional Court's overall conclusion.

Ground 16: Access to Legal Advice

425. At para. 403 of its judgment, in the section addressing procedural failures alleged by individual
Claimants, the Divisional Court said:

“There have been criticisms of the lack of access to legal advice. Given the scope of the right to make
representations in this context, we do not consider that procedural fairness requires that a person who is at
_risk of action under the Inadmissibility Guidance be provided with legal representation for the right to make_
_representations to be an effective right [my italics]. It is essentially a matter of fact as to why he did not_
claim asylum in a third country on route to the United Kingdom. It is essentially a matter of fact for him to
give his reasons why he should not be removed to Rwanda.”

Notwithstanding that general conclusion, it went on briefly to consider what access to legal advice the
individual Claimants had in fact had and it found that the process was in that regard fair.

426. Asylum Aid's challenge is only to the statement which I have italicised. Even if the Claimants in these
cases did in fact all have access to legal advice, if that statement is wrong it is capable of leading to
injustice if relied on in other cases, and I believe we should address it.

427. The impugned statement proceeds on the basis that fairness only requires that claimants should be
entitled to make representations on circumstances arising from their specific factual histories, so it would in
any event have to be reconsidered in the light of my conclusion on ground 15. But Ms Kilroy submitted
that, even on the basis on which the Court proceeded, the statement cannot be defended. She submitted
that the right to make representations must be effective, and that that went beyond a right simply to supply
relevant facts to the decision-maker. It was unrealistic to believe that asylum-seekers who had just arrived
in the UK and (usually) spoke no English could make effective representations, even on the specific safety
question, without legal assistance, let alone understand the relevant law – and all the more so in the light of
the scope and complexity of the decision-making scheme governing removals to Rwanda under the MEDP.
She also pointed out that the Secretary of State's decisions in the present cases show that she insists on
the provision of documentary materials, such as medical reports, by way of supporting evidence, and that
asylum-seekers in the Claimants' situation would plainly be unable to comply with those requirements
without professional assistance.

428. As with ground 15, the Secretary of State did not, either in her skeleton argument or in Lord Pannick's
submissions before us, advance any substantial submissions in support of the impugned statement,
pointing out that in the Divisional Court she had sought to resist this part of Asylum Aid's challenge on the
factual basis that claimants were provided with access to state-funded legal advice.


-----

Commissioner for Refugees intervening) and other case....

429. In my view it is impossible, for essentially the reasons given by Ms Kilroy, to support a general
proposition (if this is really what the Court intended) that procedural fairness will never require that an
asylum-seeker who is at risk of removal to Rwanda under the MEDP be provided with legal assistance to
make representations before the removal decision is taken, even if they are not addressing the general
safety question. There may be cases where a decision is fair even where there has been no access to
legal assistance, but they are likely to be exceptional. As we have seen, the Secretary of State does not
contend otherwise and it is her policy to ensure that legal assistance is indeed available.

430. I therefore believe the point raised by ground 16 is good, but, again, it does not necessarily impugn
the Divisional Court's overall conclusion.

Ground 17: Seven Days

431. It is, as I have said, Asylum Aid's case that seven days was simply too short a period for claimants to
prepare effective representations in response to a Notice of Intent to remove them to Rwanda. The
Divisional Court rejected that submission on the basis that its finding that fairness did not require that
claimants have an opportunity to make representations about the general safety question meant that seven
days were adequate: see para. 421 of the judgment. That reasoning is undermined by my conclusion on
ground 15. In any event, Ms Kilroy did not accept that even on that basis seven days would be adequate.
In those circumstances, I will focus directly on the parties' submissions before us rather than considering
the issue through the lens of the judgment.

432. I start with the applicable legal principles. At para. 27 of his judgment in Lord Chancellor v Detention
_Action [2015] EWCA Civ 840, [2015] 1 WLR 5341, another case involving the adequacy of procedural_
timetables, albeit in a different context, Sir John Dyson MR reviewed the relevant authorities and accepted
counsel's summary of their effect, as follows:

“… (i) [I]n considering whether a system is fair, one must look at the full run of cases that go through the
system; (ii) a successful challenge to a system on grounds of unfairness must show more than the
possibility of aberrant decisions and unfairness in individual cases; (iii) a system will only be unlawful on
grounds of unfairness if the unfairness is inherent in the system itself; (iv) the threshold of showing
unfairness is a high one; (v) the core question is whether the system has the capacity to react appropriately
to ensure fairness (in particular where the challenge is directed to the tightness of time limits, whether there
is sufficient flexibility in the system to avoid unfairness); and (vi) whether the irreducible minimum of
fairness is respected by the system and therefore lawful is ultimately a matter for the courts. I would enter a
note of caution in relation to (iv). I accept that in most contexts the threshold of showing inherent unfairness
is a high one. But this should not be taken to dilute the importance of the principle that only the highest
standards of fairness will suffice in the context of asylum appeals.”

That summary was approved by the Supreme Court in A: see para. 68 of the judgment of Lord Sales and
Lord Burnett. Point (v) is of particular relevance for our purposes. I return to the actual decision in
_Detention Action at para. 439 below._

433. Ms Kilroy referred us to a wealth of evidence identifying the difficulties faced by claimants, even if
they have good legal assistance. It is simplest if I reproduce verbatim, with some minor editing, the
summary of that evidence at paras. 23-25 of her skeleton argument.

“23. First, there are a wide range of relevant issues that may be specific to an individual, such as mental or
physical health, family ties in UK, or the need for family reunion once recognised as a refugee, which
require instructions and evidence. Particular difficulties meeting the tight time limits may arise where there
is a history of trauma, including torture, trafficking, and/or sexual or gender-based violence, which makes it
difficult to take full instructions at speed. In addition to inadmissibility and safe third country issues,
investigations and representations must be conducted on more standard issues, such as lawfulness of
detention, applications for bail, trafficking indicators, and NRM referrals, and any age dispute issues.

24. Second, Asylum Aid's evidence [from Toufique Hussain, a solicitor at Duncan Lewis with extensive
e perience in this field] as that it as generall not possible to prepare itness statements addressing


-----

Commissioner for Refugees intervening) and other case....

even individualised matters relevant to inadmissibility and removal to Rwanda within the seven-day period.
As shown in [tables produced to us showing the timetables for the representations made in these cases], in
only one case was a witness statement served in advance of the initial decisions, and that had to be
supplemented later with further instructions. In all other cases, witness evidence providing relevant
individualised information was produced after removal directions had been set.

25.  The Court has recognised the relevance of medical evidence to the decisions in individual cases.
Again, Asylum Aid's evidence showed that it was not possible to obtain medical evidence within a sevenday timescale. In all the Claimants' cases where medical evidence was produced by the individual (and all
but one when it was produced through a rule 35 report) it was only obtained after removal directions were
set.”

434. Lord Pannick did not seek to address the details of that evidence. As he put it in his submissions,
“seven days may or may not be adequate: it depends on the case”. His essential point was that claimants
were entitled to ask for an extension if they needed more time, and that it was the Secretary of State's
policy to grant an extension if reasonable grounds were shown. He pointed out that such extensions had in
fact been granted in several of the Claimants' cases and that if one was unreasonably refused they were
entitled to seek judicial review. He acknowledged that the Notice of Intent makes no reference to the right
to seek an extension, nor does it appear in any guidance to caseworkers. He referred us, however, to para.
23 of the witness statement of Mr Ruaridh McAskill, the Acting Head of the TCU in Glasgow, which reads:

“Where individuals request an extension of time to respond to an NOI these requests are considered on a
case-by-case basis taking into account the reasons requested for the extension, how long they have had to
respond, their access to legal representation and whether it would be reasonable to have expected
reasons to have been submitted prior to the extension request. There are no fixed criteria for an extension
to be granted or refused. Factors weighing in favour of an extension of time include if someone has not had
access to adequate legal advice, if they provide good reasons why they have not been able to make
representations (such as illness, trauma or electronic communication failures); factors weighing against
include if they had the opportunity to instruct legal representatives and chose not to do so. Discretion has
been used in most cases to extend the time period to respond to the NOI. If an extension is refused further
representations are generally considered.”

Lord Pannick drew attention to the final sentence. The seven-day period did not represent an absolute cutoff, even where an extension was not sought.

435. Lord Pannick submitted that the existence of that policy meant that the process was sufficiently
flexible to avoid systemic unfairness and accordingly could not itself be said to be unfair or unlawful. He
submitted that there were good reasons why “the standard period should be as short as seven days”. It
was in the public interest that removal decisions should be made without delay: indeed that was in the
claimant's interest also, particularly if they were in detention.

436. In support of his submissions Lord Pannick relied on the decision of this Court in R (Refugee Legal
_Centre) v Secretary of State for the Home Department_ _[2004] EWCA Civ 1481, [2005] 1 WLR 2219. That_
case, which is one of the decisions on which Sir John Dyson drew in his summary of the relevant principles
in Detention Action, involved a challenge to the fast-track system for adjudication of asylum claims which
the Secretary of State believed to be clearly unfounded. Under that system the entire process from initial
interview to final decision was compressed into a period of three days, with no opportunity for the claimant
to put in further representations following the interview. The basis of the challenge was that that timetable
was quite inadequate for the preparation of the claimant's case, including in particular any medical or other
evidence that might need to be obtained. A central part of the Secretary of State's answer, as here, was
that the system was operated flexibly, so that if it became clear that a case could not be dealt with fairly
within that timetable caseworkers would remove it from the fast track. This Court believed that the system
was defective in the absence of what it described (see para. 18 of the judgment of the Court given by
Sedley LJ) as “a clearly stated procedure – in public law, a policy – which recognises that it will be unfair
not to enlarge the standard timetable in a variety of instances”. It continued, at para. 19:


-----

Commissioner for Refugees intervening) and other case....

“To assert, without any real evidence to support it, that a general principle of flexibility is 'deeply ingrained'
is not good enough. Putting the relevant issues in writing - and we assume without question that what is
put in writing will be made public - is not simply a bureaucratic reflex. It will concentrate official minds on
the proper ingredients of fair procedure; it will enable applicants and their legal representatives to know
what these ingredients are taken to be; and if anything is included in or omitted from them which renders
the process legally unfair, the courts will be in a position to say so.”

However, it declined to hold that that defect meant that the policy itself should be declared to be unlawful.
As it put it at para. 23:

“… [P]rovided that it is operated in a way that recognises the variety of circumstances in which fairness will
require an enlargement of the standard timetable - that is to say lawfully operated - the … system itself is
not inherently unfair. A written flexibility policy to which officials and representatives alike can work will
afford a necessary assurance that the three-day timetable is in truth a guide and not a straitjacket.”

437. The significance of the Refugee Legal Centre decision does not depend on comparing the lengths of
the periods in that case and this, or other details of the two systems. But Lord Pannick relied on it as
demonstrating that there was nothing unlawful in the Secretary of State adopting a standard procedural
timetable which would in some cases not give asylum claimants a fair opportunity to make representations
provided that it was also her policy to allow for departures from the timetable where that was necessary in
the interests of fairness. He also noted that the Court did not regard a failure to promulgate that policy in
writing as rendering the system inherently unfair and thus unlawful.

438. It was put to Lord Pannick in the course of oral submissions that, notwithstanding the Court's ultimate
conclusion in the _Refugee Legal Centre, it evidently expected that the Secretary of State would develop_
and publish its flexibility policy: it said at para. 25 that it had “indicated what in our view needs to be done to
obviate [the risk of injustice]”. He was asked whether he accepted that the Secretary of State ought now to
publish as a policy the approach which was said by Mr McAskill to operate in practice, and to refer to it in
the Notice of Intent. He was not prepared to accept that proposition in those terms, arguing that published
policies specifying detailed criteria were sometimes positively disadvantageous as encouraging a tick-box
approach; the most that he would say was that when there had been some more experience of the system
the Secretary of State might think it desirable to publish some guidance about the basis on which
extensions should be granted.

439. Ms Kilroy in her reply submitted that the practice of granting extensions could not justify a standard
timetable which on the evidence was too short in every case. She countered Lord Pannick's reliance on
the _Refugee Legal Centre case by referring us to the decision in_ _Detention Action. That case raised a_
challenge to the fairness of the Fast Track Rules introduced in the Immigration and Asylum Chamber of the
First-tier Tribunal, which required asylum-seekers to prepare and present their appeals within seven days
of the refusal of their claim. The Court found that that timetable was so tight that it was inevitable that a
significant number of appellants would be denied a fair opportunity to present their cases. The response of
the Lord Chancellor, as the rule-maker, was that rule 14 of the Fast-Track Rules provided that if the
Tribunal was satisfied that the case could not justly be decided within those timescales it must disapply
those Rules. The Court did not accept that that was an adequate safeguard, essentially because the
procedural structure created constraints which would make it very difficult in practice for appellants to make
an application under rule 14 or for the Tribunal to accede to it: see paras. 42-44 of the judgment of Sir John
Dyson.

440. I have not found this issue entirely easy, but in the end I have concluded that the seven-day period
specified in the Notice of Intent does not render the decision-making process “structurally unfair and
unjust”, to adopt the language of Sir John Dyson in _Detention Action; and I would accordingly dismiss_
ground 17. My reasons are as follows.

441. The evidence clearly establishes, and it is in any event obvious as a matter of common sense and
experience, that in many cases it will indeed be impossible for claimants to submit effective representations
within seven days of receipt of a Notice of Intent even if they have ready access to legal assistance and


-----

Commissioner for Refugees intervening) and other case....

only wish to make representations on matters specific to their particular circumstances. But I do not
believe that it establishes that it will be impossible in every case. Not every case, for example, will require
the submission of medical evidence; nor in every case will there be a factual basis for a claim of
exceptional circumstances under paragraph 345A (b) (ii). It cannot be assumed that the Claimants' cases
are representative of the range of cases in which Notices of Intent in relation to relocation to Rwanda might
be served: quite apart from the possibility of selection bias in those who brought proceedings and whose
cases were heard by the Divisional Court, the process of identifying issues and gathering evidence is likely
to be more uncertain and require more consideration when dealing with a newly-applied policy. Even if –
as I accept may well be the case – the limit is too short in the majority of cases, it is impossible to assess
the relative proportions. In short, I agree with Lord Pannick's laconic summary that seven days may or
may not be adequate.

442. That being so, I see nothing wrong in principle in the Secretary of State imposing a “base-line”
timetable which is realistic at least in the most straightforward cases and allows those cases to be decided
promptly, provided that she is ready and willing to grant extensions in those cases where more time is
reasonably required. I do not believe that it is inherently unfair to employ a model where there is a
minimum period available to all claimants to make representations, together with consideration of what
longer period may be required in particular cases. There is, as Lord Pannick submitted, an important
public interest in decisions on removals under the MEDP being made – one way or the other – as
expeditiously as is consistent with fairness. Seven days is no doubt the shortest realistic period, but a
deadline of, say, fourteen or twenty-one days would very likely still require extensions in some cases and
would mean that decisions were delayed in others for a longer period than was necessary or desirable.

443. That puts the focus on the Secretary of State's policy of flexibility. For the reasons given by Sedley
LJ in the _Refugee Legal Centre case, I do not think it is good enough that that policy is not formally_
published in the form of guidance to caseworkers nor referred to in the Notice of Intent. Claimants and
their advisers need to know that the seven-day timetable can be extended where that is shown to be
necessary in the interests of fairness. I do not accept Lord Pannick's submission that publication of formal
guidance may do more harm than good: there should be no risk of a tick-box approach if the guidance
(which need not be elaborate) is expressed in appropriately flexible terms. It is also in my opinion
important that the guidance makes it clear that the seven-day period should not be treated as a norm and
that the grant of extensions is not necessarily exceptional. It may be that if experience shows that
extensions are required in a very large number of cases, the Secretary of State might wish to consider
providing for a rather longer base-line period; but that must be a matter for her.

444. I should make it clear that I should not be taken to be endorsing the Secretary of State's current
policy in the precise terms given by Mr McAskill, which were not the subject of submissions before us,
beyond recording an observation by Ms Kilroy that they contained no specific reference to the overriding
requirement of fairness. It must ultimately be a matter for the Secretary of State how she chooses to
formulate any guidance which she may give.

445. Although for that reason I believe that this aspect of the decision-making process requires
improvement, it follows from the approach of this Court in the Refugee Legal Centre case that that does
not justify a declaration that the process is unlawful. I do not believe that that conclusion is inconsistent
with _Detention Action. The crucial feature in that case was that the power ostensibly available to the_
Tribunal under rule 14 was in reality highly constrained.

Ground 18: Disclosure of Provisional Conclusions

446. At para. 389 of its judgment the Divisional Court said:

“Contrary to the submission made by some of the Claimants, fairness did not require that the Claimants
have the opportunity to make representations in response to some form of provisional view that such
circumstances existed. What fairness requires in the context of a decision under paragraph 345A(iii)(b) of
the Immigration Rules is an opportunity for the Claimant to provide any explanation he has for not making


-----

Commissioner for Refugees intervening) and other case....

an asylum claim before reaching the United Kingdom. Fairness did not require the opportunity to make
representations in response to the Home Secretary's evaluation (or provisional evaluation) of that
explanation.”

447. Ground 18 reads:

“The court is wrong to conclude that the common law does not require individuals to have access to the
SSHD's provisional conclusions against them.”

In its skeleton argument Asylum Aid makes clear that the challenge in ground 18 is to para. 389 of the
Divisional Court's judgment, as quoted above. It refers to various authorities which establish, as Lord
Mustill put it in Doody (p. 563 F-H), that “the right to make representations is of little value unless the maker
has knowledge in advance of the considerations which, unless effectively challenged, will or may lead to an
adverse decision”.

448. In her skeleton argument in response the Secretary of State pointed out that the Notice of Intent
informed claimants that she was considering whether it was reasonable to expect them to have claimed
protection in the specified countries through which they had passed and that put them sufficiently on notice
of the need, if they could, to advance reasons why that was not the case.

449. In her oral submissions Ms Kilroy made it clear that because of the pressure of time she largely relied
on the contents of Asylum Aid's skeleton argument; such short points as she did make did not substantially
develop what appears there. Lord Pannick did not make any oral submissions. That being so, I need only
say that I accept the Secretary of State's submission and would dismiss this ground.

450. I should clarify one related point. I have concluded that ground 15 is well-founded. We did not,
however, hear any submissions on the specific question of what, if any, information over and above what
the Secretary of State published in the MoU and the CPINs she was obliged to provide in order to give the
Claimants a fair opportunity to make representations on the safety of Rwanda; and I accordingly say
nothing about that question. I would, however, observe that the materials which were in fact disclosed in
these proceedings appear sufficient to satisfy any such obligation as there may have been.

Ground 19: Access to Justice

451. It was part of Asylum Aid's case that the inadequacy of the time given for representations had a
knock-on effect on the adequacy of the standard five-day notice given in removal directions: see para. 385
(5) of the Divisional Court's judgment. The Court addressed that submission at para. 420 of its judgment,
where it said:

“One point to note in the present case is that the access to court submission is parasitic on the unfair
system submission. Ms Kilroy accepted that if the period permitted for representations before the decisions
was lawful, then removal directions within the standard form would be lawful.”

452. Ms Kilroy told us that that did not accurately reflect what she had said to the Court; but, irrespective
of whether in fact she made the concession attributed to her it seems to us to be plainly right. At paras. 2932 of its skeleton argument (which Ms Kilroy did not, again for reasons of time, significantly amplify in her
oral submissions) Asylum Aid argues that the dismissal of its case on the other grounds makes ground 19
unanswerable because if there has been inadequate opportunity to make representations prior to the
removal decision claimants will need longer than five days to issue Court proceedings. But that depends
on the basis on which the other grounds failed. If, for example, I had accepted the Divisional Court's
statement that it was unnecessary for claimants to have access to legal advice prior to a decision on
removal under the MEDP, there would be force in the point that five days was an inadequate time to find
and instruct a lawyer from scratch and to bring legal proceedings. But my conclusion on ground 17 means
that the system has sufficient flexibility to ensure that claimants will in fact have adequate time to make
effective representations (ignoring aberrant decisions, which can only be addressed on a case-by-case
basis). If that is the case, the claim based on a systemic denial of access to justice does indeed fall away.

453 I would accordingly dismiss ground 19


-----

Commissioner for Refugees intervening) and other case....

Ground 20: Construction of the Immigration Rules

454. Ground 20 reads:

“The Court's analysis of the Immigration Rules and para. 17 of Schedule 3 to the 2004 Act is flawed.”

Asylum Aid's essential contention is that the distinction drawn by the Divisional Court, in connection with
the “Scope of Representations” issue, between head (i) and heads (ii)-(iv) under paragraph 345B does not
properly reflect the requirements of the Refugee Convention and is inconsistent with the approach required
of the Secretary of State in making a certificate under paragraph 17 of Schedule 3. It is thus not a distinct
ground but a further argument in support of ground 15. Since I have accepted Ms Kilroy's point on ground
15 for other reasons I need say no more about it.

Conclusion on Asylum Aid's Appeal

455. I do not accept all aspects of the reasoning of the Divisional Court on the issue of whether the
decision-making process was inherently unfair, as is reflected in my conclusions on grounds 15 and 16.
But, as I have said, the determinative ground from the point of view of the fairness of the process is ground
17. Since I would dismiss that ground I believe that the Court was right to reject the claim of inherent
unfairness, and I would dismiss Asylum Aid's appeal.

RM's Ground on Fairness

456. Ground 22, which is pleaded in some detail, raises both a general challenge to the fairness of the
Secretary of State's decision-making process as regards relocation to Rwanda and a specific challenge to
its conclusion that in his particular case (unlike those of most of the other Appellants) the inadmissibility
decision did not fall to be quashed. The pleaded criticisms were developed at paras. 11-36 of RM's
skeleton argument, but in his oral submissions Mr Drabble (who was also under some pressure of time) did
no more than refer us to the fact that the skeleton argument contained a procedural chronology of his
particular case which he invited us to read as illustrating with particularity why seven days would almost
never give enough time for proper submissions to be made.

457. In the version of this judgment handed down (subject to editorial correction) on 29 June, I did not
refer specifically to ground 22, and in post-judgment submissions counsel have asked for clarification as to
whether the intention was that it should be dismissed. I should confirm that that is indeed the Court's
intention. RM's general challenge raises no points that I have not considered in relation to Asylum Aid's
appeal. As regards the decision in his particular case, the Divisional Court gave reasons at paras. 357-358
of its judgment why the inadmissibility decision of 5 July 2022 was not unfair. That specific reasoning is
not addressed either in ground 22 itself or in RM's skeleton argument, and I can identify no error of law in
it. I should note that RM did in fact make further submissions on 9 July, addressed to the question why he
had not claimed asylum in France: those will no doubt be carefully considered by the Secretary of State if
the issue of relocation to Rwanda becomes live in his case.

**LORD BURNETT OF MALDON, CJ:**

458. These appeals concern the lawfulness of the Home Secretary's decisions to remove to Rwanda a
cohort of people who arrived irregularly in the United Kingdom by small boats across the English Channel
and then claimed asylum. There are ten individual appellants, all single men, whose countries of origin are
Syria, Iran, Iraq, Vietnam, Sudan and Albania. To qualify for removal, it must have been reasonable for
them to have claimed asylum in a safe country on the way. All arriving by small boats across the Channel
have necessarily been in a safe third country but it may not be reasonable for all to claim asylum there.
The claimants would be free to claim asylum in Rwanda. We are not concerned with the political merits of
the underlying policy.

459. The appeals relate to generic claims which contend, for a variety of reasons, that it would be unlawful
for the Home Secretary to remove anyone from the United Kingdom to Rwanda. The individual
circumstances of the claimants play no part in their arguments. Before the Divisional Court of the High


-----

Commissioner for Refugees intervening) and other case....

Court the individual appellants (and others) also raised challenges based upon the circumstances in which
their individual cases were considered by the Home Office. Many were successful in those challenges with
the consequence that new decisions will need to be taken on the individual cases whatever the outcome of
these appeals on generic issues. The proceedings were issued between 8 and 14 June 2022. The
evidence upon which the Divisional Court decided the issues was filed over the course of the summer of
2022. We have considered the appeal on the same evidence which, in consequence, is now out of date.

460. Asylum Aid was also a claimant for judicial review before the Divisional Court. Its core submission is
that the procedures surrounding the decision making and proposed removals are unfair and thus unlawful.
It appeals the Divisional Court's dismissal of its claim.

461. The judgment of the Divisional Court was handed down on 19 December 2022 following hearings in
September and early October: Lewis LJ and Swift J [2022] EWHC 3230 (Admin). By its orders the court
dismissed the generic claims for judicial review. There has been no appeal by the Home Secretary in
respect of the individual decisions.

462. At the heart of the claims for judicial review is the proposition that it would be unlawful to remove
anyone to Rwanda because there are “substantial grounds for believing that they would be at real risk” of
treatment in Rwanda contrary to article 3 of the European Convention on Human Rights (“ECHR”). That is
the well-known test first articulated by the Strasbourg Court in Soering v. United Kingdom (1989) 11 EHRR
439 at [88] et seq in the context of an extradition case. It was soon applied to removal cases generally. The
_Soering argument in these appeals has two components which make up the “safe country” issue. First, the_
appellants submit that the conditions that they would face in Rwanda would give rise to the relevant risk.
Secondly, they submit that defects in Rwanda's consideration of asylum claims would give rise to a risk of
good claims being refused and the further risk that Rwanda would return individuals (refoule in the
language of the 1951 Refugee Convention) to the countries from which they claimed protection.

463. The principal decision of the Strasbourg Court dealing with that test in cases of removal of asylum
seekers by an ECHR state to another state it considers safe is Ilias v. Hungary (2020) 71 EHRR 6.

464. It is the second aspect of the article 3 issue that was the focus of argument before us. On that second
aspect the task of the Divisional Court was to determine whether deficiencies in the Rwandan system for
dealing with asylum applications are such that there are substantial grounds for believing that they would
face a real risk of being returned to their countries of origin despite having a valid claim for asylum.

465. The claimants, supported by the United Nations High Commissioner for Refugees (“UNHCR”), submit
that such grounds remain despite the bespoke agreement reached between the Government of the United
Kingdom and the Government of Rwanda, known as the Migration and Economic Development
Partnership (“the agreement”). The agreement is contained in a Memorandum of Understanding (“MoU”)
dated 14 April 2022 and diplomatic _Notes Verbales which provide guarantees by Rwanda regarding “the_
asylum process of transferred individuals” and “the reception and accommodation of transferred
individuals” respectively. The position of the claimants and the UNHCR is that the system for dealing with
asylum claims in Rwanda is such that the aspirations set out in these documents are undeliverable for any
person seeking asylum there, including the 11 claimants involved in this appeal. It also entails the
proposition that the proposed monitoring arrangements which are designed to ensure that Rwanda deals
with asylum applicants appropriately with no relevant risk of refoulement for those with valid claims are
likely to be ineffective.

466. It is the opinion of His Majesty's Government that Rwanda will comply with the terms of the
agreements and abide by the assurances it has given. The intense scrutiny upon those who would be sent
to Rwanda coupled with the monitoring mechanisms contained in the agreement and those of the British
High Commission in Kigali, with embedded Home Office officials, provide additional and necessary
safeguards. The UNHCR disagrees, believing that the asylum system in Rwanda does not have the
capacity to deliver consistently accurate and fair asylum decisions and that there is a concomitant risk that
some refugees will not be recognised as such and will be subject to refoulement. Capacity in this sense is


-----

Commissioner for Refugees intervening) and other case....

not concerned only with the number of asylum seekers who arrive in Rwanda but the ability of the various
parts of the system there to deliver reliable decisions on their applications.

467. The evidence in support of the claims for judicial review was largely provided by the UNHCR through
Lawrence Bottinick, Senior Legal Officer and Acting Representative for the UNHCR in London, expressing
an institutional view. The evolution of the evidence was unusual in that it joined issue with the British
Government point by point, with exchanges of evidence. The UNHCR, an interested party in these
proceedings, assumed the mantle of claimant. That is not to criticise it but to draw attention to the unusual
nature of its engagement in these claims. Moreover, the UNHCR made clear that it is opposed as an
institution to any attempt “to offshore” asylum claims in the manner contemplated by the agreement in
question. It has an institutional interest in the outcome of these claims for judicial review. It nonetheless
has unrivalled practical experience of the working of the asylum system in Rwanda through long years of
engagement.

468. Rwanda is a country which has emerged from one of the most shocking and destructive periods of
violence in recent history. Ethnic rivalry led to genocide in 1994 when over 500,000 Tutsi were murdered
by Hutu. Many Hutu were also murdered and estimates of the total death toll are much greater. There was
protracted violence thereafter before stability was restored. The ethnic violence in Rwanda had a long
history and erupted repeatedly in the second half of the twentieth century. This is not the place for even a
short description. Following the 1994 genocide the International Criminal Tribunal for Rwanda was
established. It gave a relatively short account of the genocide in its first judgment delivered on 2
September 1998 (Akeyescu ICTR 96-04) to which reference might be made. The government which
emerged after the genocide has been the subject of much criticism for its human rights record. The region
has been unstable for decades with large population movements. Rwanda has received hundreds of
thousands of refugees from the Democratic Republic of Congo and Burundi (according them refugee
status prima facie, rather than considering individual circumstances) and has worked with the UNHCR to
house and support those refugees. It has also worked with the UNHCR to provide sanctuary for over 500
refugees from Libya while the UNHCR decides their asylum claims and seeks to resettle them. For all this
the UNHCR gives the Government of Rwanda credit. But it is critical of the way in which individual asylum
claims have been dealt with hitherto and considers that the aspirations in the agreement between the two
governments are unachievable at present. They will require, in particular, changes in attitude and training
which are not yet in place.

469. The UNHCR does not question the good faith of the Government of Rwanda. In my view, there is
nothing in the materials before the Divisional Court which credibly questions that good faith or the genuine
determination of Rwanda to deliver its side of the agreement reached with the British Government.
Similarly, there is no suggestion that the British Government will do other than seek to ensure that Rwanda
will deliver on the agreement.

470.  At the heart of this issue, therefore, is whether despite the efforts of both Governments and the
protections built into the agreement, the relevant risk of bad decision making and subsequent refoulement
remains. This calls for an evaluative exercise where past relevant events inform the evaluation and must
be coupled with judgements about good faith, intentions to deliver, the capacity of the system to deliver
and the effect of monitoring. Good faith and intentions to deliver fall squarely within an assessment of the
value of these diplomatic assurances. Capacity issues are perhaps hybrid, falling within diplomatic
assessment and also more straightforward questions of fact. There are questions about whether the will of
the central Government of Rwanda will be effective in dictating the approach and conduct of officials down
the chain. There must also be consideration of the practicalities of removing someone from Rwanda to
their home country (assuming a “wrong” asylum decision). None of the appellants has a passport and
Rwanda has no arrangements in place for returns to the countries from which any of these appellants hails.
If sent to Rwanda each will travel on a British document for that purpose alone.

471. The Divisional Court has been criticised for saying that it would need “compelling” evidence to differ
from the evaluation of the British Government. I think that description is apt to describe the approach of a
court to the evaluation of a diplomatic assurance The worth of a diplomatic assurance calls for an exercise


-----

Commissioner for Refugees intervening) and other case....

of judgement in which the government has expertise and access to advice which a court does not have. A
court is not institutionally well-equipped to make such a judgement. The situation is analogous to
assessments of risks to national security where a court is slow to differ from the assessment of the
government: _Secretary of State for the Home Department v Rehman [2003] 1 AC 153, [50];_ _R (on the_
_application of Begum) v Special Immigration Appeals Commission [2021] AC 765, [70] to [71]. But where_
the assessment of future conduct engages practical considerations which arise from past conduct the
position is not as stark. In this case there is very detailed evidence of the way in which the Rwandan
asylum system has operated when considering individual claims before the summer of 2022. There were
undoubted deficiencies. Whether they are capable of being made good is not an issue on which the
government has special institutional expertise.

472. This evaluative exercise of assessing future risk does not require the resolution of all conflicts of
evidence between the Government of Rwanda and the UNHCR in the sense of deciding on the balance of
probability whether something did or did not happen. That is in any event impractical in the context of this
litigation for at least two reasons. There is material before the court from Rwanda provided to the British
Government in answer to questions designed to counter concerns raised by the UNHCR. The Government
of Rwanda is not a party to these proceedings nor, diplomatically, could it be expected to engage as if it
were a litigant. Moreover, there is no practical way to test the evidence in these proceedings, still less to
explore ambiguities in language and the like which were drawn to our attention. But it would not be the
correct approach when evaluating a future risk of this nature.

473. The approach to evaluating the ultimate relevant future risk, which is of refoulement, is analogous,
but not identical, to the evaluation of the risk under consideration in _Rehman. That case concerned the_
evaluation of whether a person's presence in the United Kingdom constituted a risk to national security.
Such an evaluation did not depend upon a point-by-point consideration of past events by reference to a
standard of proof: Lord Hoffmann at [55].

474. Before turning to the issues which arise in this appeal it is, in my view, necessary to consider what
the Divisional Court (and in turn this court) was being asked to determine on the “safe country” issue. Mr
Husain KC, who appeared as the principal advocate for the appellants on this issue, recognised that the
proposition being advanced on their behalf was that it was not safe for anybody to be sent to Rwanda. All
would face the relevant risks irrespective of the number removed or their personal makeup. But the
arguments both before us and the Divisional Court at times became confused by the introduction of issues
which were hypothetical and moved far from the consideration of a single generic case or the concrete
cases represented by these appellants. For example, in much of the political hyperbole which surrounded
the announcement of the Rwanda policy there was talk of Rwanda, within a few years, being a destination
for thousands of asylum seekers who arrived irregularly in the United Kingdom. The UNHCR evidence
questions whether Rwanda can cope with the volumes apparently contemplated. Yet the evidence before
the Divisional Court was that the physical capacity for housing asylum seekers in Rwanda was limited to
100; that of the 47 originally identified for removal the Home Office expected in fact to remove about 10;
and that the starting point for any removal under the agreement was for the two governments to agree who
would be sent to Rwanda. That would be determined by the capacity of the Government of Rwanda to
receive and process the individuals concerned. It also gave the Government of Rwanda complete control
so that they might reject any proposed name.

475. The Divisional Court was not considering whether it is “safe” for Rwanda immediately to receive
substantial numbers. Similarly, the voluminous papers in this case identify hypothetical special problems it
is said that some groups of people would face. But we are not considering whether it would be “safe” for
every conceivable type of person to be sent to Rwanda. For example, the UNHCR have provided evidence
which suggests that were nationals of an unnamed country with which Rwanda has close relations to seek
asylum it is unlikely they would ever receive it. It is not difficult to deduce the identity of that country. Were
the British Government unwise enough to seek to remove any such nationals to Rwanda, and were
Rwanda improbably to agree to accept them, they would have strong legal grounds to resist. The UNHCR
also raised concerns about gay and lesbian asylum seekers in Rwanda. We are not concerned, and nor


-----

Commissioner for Refugees intervening) and other case....

was the Divisional Court, to determine whether, hypothetically, there may be individuals bearing particular
characteristics who would face the relevant risks in Rwanda.

476. The argument of the appellants before the Divisional Court was, that in respect of each of them, there
were substantial grounds for believing that there was a real risk that they would be returned to their home
countries after a wrong refusal of asylum in Rwanda. They also suggest a relevant risk of article 3 illtreatment in Rwanda itself. They submit that the same risks would attach to anyone sent to Rwanda
irrespective of any personal characteristics. That encapsulates the core safety issue in these proceedings.

The Issues on the Appeal

477. There is a multitude of grounds of appeal on which permission to appeal has been granted and one
(concerning data protection) where the Divisional Court's refusal to grant permission to apply for judicial
review is the subject of an application for permission to appeal. They break down into the following
categories:

(i) Did the Divisional Court apply the right test when deciding the article 3 issues (answering for itself
whether the relevant substantial grounds existed) or did it apply a domestic public law approach by asking
whether the Home Secretary was entitled to conclude that article 3 would not be breached by the
claimants' removal to Rwanda? (Master of the Rolls issue 1)

(ii) Was the Divisional Court wrong to reject the contention that there are substantial grounds to believe
that there is a real risk that the claimants would be refouled from Rwanda despite being genuine refugees?
(Master of the Rolls issues 2 to 7)

(iii) Was the Divisional Court wrong to reject the contention that there are substantial grounds to believe
that the claimants are at real risk of facing treatment contrary to article 3 while in Rwanda? (Master of the
Rolls issues 2 to 7)

(iv) Was the Divisional Court wrong to conclude that the British Government has sufficiently explored the
likelihood of refoulement from Rwanda both in terms of ECHR law (Ilias) and domestic law (Tameside v.
_Secretary of State for Education and Science [1977] AC 1044)? (Master of the Rolls issues 8 and 9)_

(v) Was the Home Secretary's policy unlawful when viewed against the test identified in the Supreme Court
in R(A) v. Secretary of State for the Home Department [2021] 1 WLR 3931applying Gillick v. West Norfolk
_and Wisbech AHA [1986] AC 997? (Master of the Rolls issue 10)_

(vi) Was the Divisional Court wrong to conclude that the Home Secretary acted lawfully in using the power
in paragraph 17 of Part 5 of Schedule 3 to the Asylum and Immigration (Treatment of Claimants etc.) Act
2004 to certify Rwanda as a safe third country, because she was entitled to conclude that persons would
not be subjected to treatment in Rwanda prohibited by the Refugee Convention or refouled if they were
indeed refugees? A second argument advanced by the appellants is that the power is inapt to create a
presumption that a country is safe and that the Home Secretary should have sought Parliamentary
approval by laying a Statutory Instrument as provided for by that Act. (Master of the Rolls issues 11 and
14)

(vii) Was the Divisional Court wrong to conclude that the Home Secretary was entitled to certify the
individual human rights claims as clearly unfounded on the basis that Rwanda is a safe third country?
(Master of the Rolls issue 11)

(viii) Was the Divisional Court wrong in finding that the Home Secretary's policy did not breach the
prohibition on refoulement under article 33 of the Refugee Convention? (Master of the Rolls issue 12)

(ix) Was the Divisional Court wrong to conclude that the removal of individuals to Rwanda did not
constitute a penalty for the purposes of article 31 of the Refugee Convention? (Master of the Rolls issue
12)

(x) Was the Divisional Court wrong to conclude that Council Directive 2005/85/EU on minimum standards
in member states for granting and withdrawing refugee status (“the Procedures Directive”) was not part of


-----

Commissioner for Refugees intervening) and other case....

retained EU Law? Article 27(2)(a) of that directive requires there to be a connection between a person
seeking asylum and a safe third country to which it is proposed to send him. None of the claimants has a
connection with Rwanda. (Master of the Rolls issue 13)

(xi)  Was the Divisional Court wrong to reject the argument that procedures surrounding the identification
of individuals for removal to Rwanda, in particular the seven-day time limit for making representations as to
why removal to Rwanda would be inappropriate, is systemically unfair and thus unlawful? (Master of the
Rolls issue 16)

(xii)  Was the Divisional Court wrong to refuse permission to apply for judicial review on the basis that the
scheme necessarily breaches data protection law? (Master of the Rolls issue 15)

**Summary of Conclusions**

478. I have had the advantage of reading in draft the judgment of Underhill LJ and agree, for the reasons
he gives, in respect of issues (vi) and (viii) to (xii) as I have identified them above. I shall not burden this
judgment with any further discussion of those issues. On several issues, however, it is my misfortune to
differ in my conclusion from both the Master of the Rolls and Underhill LJ.

479. First, on whether the Divisional Court applied the wrong test when considering the safety of Rwanda
on the refoulement issue. Secondly, on whether there are substantial grounds for believing that an asylum
seeker sent to Rwanda would face a real risk of refoulement following a flawed decision. Thirdly, with the
Master of the Rolls, on whether there are substantial grounds for believing that a removed asylum seeker
would be at real risk of article 3 ill-treatment in Rwanda. In my view, the Divisional Court did not err in the
way suggested and the relevant risks are not established on the evidence. It follows that I do not consider
that the underlying policy is unlawful in a Gillick sense. Moreover, I agree with the Divisional Court that the
posited removals, and the underlying policy, are not unlawful for want of investigation either in accordance
with Ilias or Tameside.

480. On issue (vii), the Master of the Rolls and Underhill LJ have concluded that the Secretary of State
was wrong to certify the individual claims on the basis that Rwanda is a safe third county. Their conclusion
followed inevitably from their ruling that Rwanda is not a safe third country. Despite having reached the
contrary conclusion on the central issue of safety I nonetheless agree that these claims should not have
been certified. The whole question of safety, as our judgments demonstrate, is contestable. For the
reasons given by Underhill LJ at [130] I agree that this conclusion does not affect the outcome of these
appeals.

**The Divisional Court's Judgment on the Article 3 and Allied Public Law Issues**

481. The first issue arises from grounds of appeal that suggest that the Divisional Court made a
fundamental error in its approach to the article 3 ECHR question. It failed to appreciate that it was for the
court to make the judgement about whether there are substantial grounds for believing that the claimants
would be at real risk of treatment contrary to article 3 through being returned to their countries of origin
having been wrongly refused asylum. Instead, it is argued that the court applied the conventional domestic
public law test by asking whether the Home Secretary was entitled to come to the conclusion that Rwanda
was safe for these purposes. As Lewis LJ observed when the point was raised at the hearing which dealt
with permission to appeal:

“…paragraph 45 of the judgment said that the issue was whether the [Home Secretary] could lawfully
reach the conclusion that the arrangements governing relation to Rwanda would not give rise to a risk of
refoulement. The [Home Secretary] could only do that if there was no risk. That is the issue the court then
considered from paragraphs 46 to 71.”

In that passage Lewis LJ was using “risk of refoulement” as shorthand for “substantial grounds for believing
there is a real risk”.


-----

Commissioner for Refugees intervening) and other case....

482. It would indeed be remarkable if the Divisional Court failed to appreciate that its function, when
considering article 3 risks (both arising from refoulement and conditions in Rwanda itself), was to make an
assessment for itself. It could properly be described as the most basic of errors in an ECHR based claim.
It would be all the more remarkable given the composition of the court. In my view, a reading of the
judgment dealing with these issues as a whole demonstrates that no such error was made.

483. In the introductory section of its judgment at [4] the court referred to section 6 of the Human Rights
Act 1998. That requires public authorities to act compatibly with the ECHR. It is axiomatic that where
section 6(1) of the Human Rights Act applies, it is unlawful for the Home Secretary to act in a way which is
incompatible with an ECHR right. In judicial review proceedings challenging a removal decision on the
basis that it is contrary to section 6 because the claimant will be subjected to a violation of his article 3
ECHR rights, it is for the court to determine whether or not the decision would result in such a violation.
The court will have due regard to the evaluation of the decision maker and be sensitive to matters such as
institutional competence in making evaluative judgements about the future where that feature is present.
The reference to section 6 suggests that the Divisional Court was approaching the issue on the correct
basis.

484. Having set out the factual and legal background the court sought to identify the issues it was required
to determine. It was faced with a plethora of disparate and overlong pleadings and skeleton arguments.
The parties had themselves been unable to agree a coherent list of issues. At [39] the court distilled the
issues to 12. The first issue began:

“The Home Secretary's conclusion that Rwanda is a safe third country is legally flawed. The Claimants'
primary contention is that this assessment is contrary to article 3 of the ECHR. This rests on: (a) the
decision of the [Strasbourg Court] in [Ilias] that a state cannot remove an individual asylum-seeker without
determining his asylum claim unless it is established that there are adequate procedures in place in the
country to which he is to be removed that will ensure that the individual's asylum claim is properly
determined and he does not face a risk of refoulement to his country of origin; (b) the submission that the
removal of the individual Claimants to Rwanda will put them at real risk of article 3 ill-treatment (in breach
of the principle recognised in Soering…) and (c) the contention that, systemically, it is inevitable that the
policy to remove asylum claimants will lead to occasions when a person will be subjected to article 3 illtreatment.”

The article 3 issue is correctly stated in points (a) and (b). The third point is the Gillick issue. The court then
added that the same points were argued on conventional judicial review grounds. It continued, in
summarising issue 2, to note that the central contention was that the asylum claims would not be
determined effectively thereby running the risk of refoulement, directly or indirectly. It recorded the way in
which the case was put, namely that the Home Secretary could not have confidence that Rwanda would
comply with the agreement reached or abide by its assurances.

485. The court returned to these issues at [43] to [45]. At [43] it repeated the claimants' primary
submission that the Home Secretary's conclusion that Rwanda is a safe country was legally flawed. That
was put by the claimants in several ways. First, it “amounts to a breach of article 3 … for the reasons
explained” in Ilias “namely that the asylum claims … would not be effectively determined in Rwanda and
the asylum claimants run a risk that they will be refouled directly or indirectly…”; secondly, that the Home
Secretary failed to comply with the Tameside duty and made her decision on material errors of fact; thirdly
that the decision to treat Rwanda as a safe third country was irrational; and fourthly that the Rwanda policy
was unlawful in the sense explained in _Gillick_ “in that it positively authorises or approves removals that
would be in breach of article 3 … (i.e. exposes persons to a real risk of article 3 ill-treatment).”

486. In this paragraph the court is referring to two different types of argument - one relying upon article 3
and the other upon conventional public law principles. In [44] the court noted that it was also argued that
the claimants would face a real risk of ill-treatment in Rwanda and that to remove them there “would be in
breach of article 3 … in the sense of the _Soering_ principle because there are reasonable grounds for
believing that if a person is removed to Rwanda that will expose him to a real risk of article 3 ill-treatment


-----

Commissioner for Refugees intervening) and other case....

because of the conditions in Rwanda.” In [45] the court repeated the formula whether the “Home Secretary
could lawfully reach the conclusion that the arrangement governing relocation to Rwanda would not give
rise to a real risk of refoulement or other ill-treatment contrary to article 3.”

487. The way in which the case was argued before the Divisional Court, as indeed it was before us,
focused on Ilias not simply for the proposition that if there were substantial grounds for believing that there
would be a real risk of refoulement then removal to Rwanda would breach article 3. Ilias is also relied upon
to support the submission that there is a free-standing procedural obligation of investigation under article 3
ECHR which, if not satisfied, would render removal unlawful in article 3 terms even if it could be shown that
such reasonable grounds for belief did not in fact exist.

488. The court dealt with questions of investigation, whether under article 3 or _Tameside, risk of_
_refoulement and adequacy of the Rwandan asylum system (in the light of the Migration and Economic_
Development Partnership) under a single heading: Was the assessment that Rwanda is a safe third
country legally flawed? That entailed resolving issues both by reference to the ECHR and section 6 of the
Human Rights Act as well as applying conventional public law principles. Having considered the question
of investigation and inquiries ([46] to [61]) the court turned to the adequacy of the Rwandan asylum
system. The first sentence in [62] is criticised:

“Next we consider whether the Home Secretary was entitled to conclude that there were sufficient
guarantees to ensure that asylum seekers relocated to Rwanda would have their asylum claims properly
determined there and did not run a risk of refoulement in accordance with the obligations in Ilias and that
Rwanda was a safe third country in accordance with the criteria in paragraph 345B (ii) to (iv) of the
Immigration Rules.”

489. That long sentence is capable of being read in different ways with the words “entitled to conclude”
governing all that follows or only part of it. Additional punctuation would have assisted. But the obligations
on the state identified in Ilias do not depend upon a Government forming a tenable view, but a correct view.
They have an objective element. Moreover, Rule 345B, which is designed to ensure compliance with the
ECHR and Refugee Convention, is couched in terms of the objective establishment of various criteria, and
not qualified by “if the Secretary of State is of the opinion” or similar words. In reading this part of the
judgment it should not be forgotten that the court was considering both article 3 and conventional public
law challenges in tandem because that is the way they were argued. The term “legally flawed” covered
both. Moreover, this paragraph must be read in the context of what has gone before. The Divisional Court
then stated its conclusion at [71]. The court discussed the status of evidence from the UNHCR and
continued:

“We must consider it together with all the evidence before us and decide whether, on the totality of that
evidence, the Home Secretary's opinion is undermined to the extent that it can be said to be legally flawed.
For the reasons we have already given, the Home Secretary did not act unlawfully when reaching the
conclusion that the assurances provided by Rwanda in the MOU and Notes Verbales could be relied on.
That being so the conclusion that, for the purposes of the criteria at paragraph 345B (ii) to (iv) of the
Immigration Rules, Rwanda is a safe third country, was neither irrational nor a breach of article 3 of the
ECHR in the sense explained in Ilias.”

490. The relevance of the assurances (along with monitoring arrangements) was that they were said by
the Home Secretary to mitigate such risk as there was that there might be refoulement. Her case was that
substantial grounds for believing that there was a real risk were not present. The adequacy of the
assurances was attacked by the claimants and the UNHCR. Her conclusion would be legally flawed if such
a real risk was present despite the assurances. The criteria in rule 345B referred to in [71] are: (ii) that the
principle of non-refoulement will be respected in accordance with the Refugee Convention; (iii) that the
prohibition on removal, in violation of the right to freedom from torture and cruel, inhuman, or degrading
treatment … is respected in that country; and (iv) that the possibility exists to request refugee status and to
receive protection in accordance with the Refugee Convention. The breach of article 3 explained in _Ilias_
was removal to a third country in which there were substantial grounds for believing that the asylum seeker


-----

Commissioner for Refugees intervening) and other case....

would face a real risk of ill-treatment or of being subjected to _refoulement. There would be a breach of_
article 3 if either real risk existed on the evidence. The Divisional Court had identified the relevant
_refoulement risk at [9] of its own judgment and referred to [134] in the judgment of the Strasbourg Court in_
_Ilias:_

“The Court would add that in all cases of removal of an asylum seeker from a Contracting State to a third
intermediary country without examination of the asylum requests on the merits, regardless of whether the
receiving third country is an EU Member State or not or whether it is a State Party to the Convention or not,
it is the duty of the removing State to examine thoroughly the question whether or not there is a real risk of
the asylum seeker being denied access, in the receiving third country, to an adequate asylum procedure,
protecting him or her against refoulement. If it is established that the existing guarantees in this regard are
insufficient, Article 3 implies a duty that the asylum seekers should not be removed to the third country
concerned.”

491. The Home Secretary's decision could only be lawful if such a real risk did not exist. I would add that
in [72], when dealing with the Gillick issue, the Divisional Court added that if the relevant criteria under rule
345A to C were met “removal to that country will not, applying the principles in _Ilias_ (themselves a
particular application of the principle in Soering), give rise to a breach of article 3 of the ECHR.”

492. The court went on to consider “conditions in Rwanda generally” from [73] which it described as the
“wider Soering submissions, that persons removed to Rwanda … are exposed to a real risk of article 3 illtreatment not for any reason connected with the handling of their asylum claim but by reason of conditions
in Rwanda, generally.” This part of the judgment straightforwardly considers the evidence and competing
arguments and concludes that there is no such real risk. That approach reinforces the reality that in
considering the central article 3 issue, both by reference to the risk of refoulement and treatment in
Rwanda itself, the Divisional Court applied the right test. With respect to the Divisional Court, I accept that
its use of language (“entitled to conclude” etc. e.g. in [64]) in a discussion of issues that raise both ECHR
and public law points of law has generated some confusion but when read as a whole, I am not persuaded
that this criticism of the judgment is made out.

493. This issue is more than a technical one. It feeds into the role of an appellate court in a case where
the first instance court has made an assessment on the basis of all the evidence on the question of
whether the action under scrutiny would breach the ECHR and be unlawful by virtue of section 6 of the
Human Rights Act 1998. We have been presented with thousands of pages of materials (leaving aside the
superabundance of authorities – most not referred to) said to be of relevance to the question whether
Rwanda is a safe third country for article 3 purposes. If the Divisional Court applied the wrong test, it would
be open to this court to allow the appeal on that basis and remit the matter for fresh consideration at first
instance. Alternatively, this court could undertake the evaluation. I have the misfortune to disagree with the
Master of the Rolls and Underhill LJ on this issue. Inordinate delay would be caused by remitting the
_refoulement article 3 issue to the High Court and so I shall proceed to consider the issue as if sitting at first_
instance, having considered for myself all the evidence. I am grateful to Underhill LJ for his comprehensive
review of the evidence which informs this issue and will express my conclusions relatively briefly.

**Safety of Rwanda: The asylum system and refoulement issue**

494. The Strasbourg Court has explained that when considering whether substantial grounds have been
shown that an individual would face a real risk of treatment contrary to article 3 that the analysis of the
evidence said to support that conclusion must be “rigorous”: see e.g. Chahal v. United Kingdom (1997) 23
EHRR 413 at [96]; Saadi v. Italy (2009) 49 EHRR 30 at [128]; Sufi v. United Kingdom (2012) 54 EHRR 9 at

[214]. For example, in cases where the argument rests on assertions of general violence in a country the
court has made clear that not every situation of general violence will give rise to such a risk. A general
situation of violence would only be of sufficient intensity to create such a risk “in the most extreme cases”
where there was a real risk of ill-treatment simply by virtue of an individual being exposed to such violence
on return: _NA v. United Kingdom_ (2009) 48 E.H.R.R. 15 at [115]. The assessment of risk in an article 3


-----

Commissioner for Refugees intervening) and other case....

exercise requires careful consideration of all the evidence in the context of the position in which removed
persons will find themselves.

495. _Ilias_ establishes that in cases where an ECHR state removes an asylum seeker to another state
without considering the merits of an application, the removing state has a duty to examine thoroughly the
adequacy of the procedures in the receiving country to determine whether they protect against
_refoulement. The Strasbourg Court was concerned to determine whether the applicant was adequately_
protected against removal, directly or indirectly, to his or her country of origin in circumstances where
article 3 risks had not been properly evaluated: see [130] to [138].

496. The article 3 question boils down to whether substantial grounds have been shown for believing that
there is a real risk of _refoulement, directly or indirectly, to a country in which the applicant in fact needs_
protection, because of deficiencies in the asylum processes in the third country, here Rwanda.

497. To answer that question, it is helpful to consider what would happen to individuals identified for
removal by the Home Office and accepted by Rwanda. There is no reason to suppose that the practical
and purely administrative steps agreed between the governments will not be followed.

498. Those removed will arrive at Kigali and be accommodated at the Hope Hostel where they will be free
to come and go. That has a capacity of 100. The evidence describes plans for further sites to be identified.
According to the reception and accommodation Note Verbale they will be provided with mobile telephones
with internet access. They will be given a temporary residence permit for three months on arrival. That will
be extended if the asylum claim is not completed within three months. Those removed to Rwanda will be
provided with financial support by the British Government in Rwanda at the same level they would receive
in the United Kingdom during the asylum process, and thereafter, for a total of five years if granted asylum
and up to three years if not. Those who make an asylum claim will be interviewed by the Directorate
General of Immigration and Emigration (“DGIE”). The asylum claim would then be considered by the
Refugee Status Determination Committee (“RSDC”). If the claim is refused there is a right of appeal to the
relevant ministry (“MINEMA”). If that appeal fails, there is a further right of appeal to the High Court and
from there to the Appeal Court. Only on the hypothesis that an asylum claim has failed at all four stages
will the question of removal arise.

499. In the event of a refusal of protection under the 1951 Convention the agreement requires Rwanda to
consider whether there are other humanitarian grounds which preclude removal to the person's country of
origin. It also requires Rwanda to consider any application from a failed asylum seeker to remain in
Rwanda on any other basis. Only then does removal become a possibility.

500. Para 10.4 of the MoU provides that “Rwanda will only remove such a person to a country in which
they have a right to reside. If there is no prospect of such removal occurring for any reason Rwanda will
regularise that person's immigration status in Rwanda.” These are important provisions which significantly
reduce the prospects of refoulement. There is other evidence about the prospects of removal. In practical
terms forcible removal from Rwanda to a failed asylum seeker's country of origin is possible only if that
country is willing to accept such returns. Therein lies a difficulty for all governments. The unequivocal
evidence is that Rwanda has no agreements for return with any country material for these purposes. There
is other evidence suggesting that removal is unlikely which is set out in the judgment of Underhill LJ. I do
not ignore the evidence from the UNHCR that there have been instances of “airport refoulement” (which is
not a risk in these cases). Rwanda immediately returned a Syrian to Turkey and an Afghan to Dubai. The
evidence suggests that from there they were sent to their countries of origin. Nor do I overlook the
evidence that, in different contexts, people have been pushed over the border by the DGIE into Tanzania
or Uganda. The circumstances were very different.

501. Objection is taken that the practical likelihood of refoulement was not addressed as a separate issue
by the Divisional Court and referred to before us only in the skeleton argument of the respondent without
oral elaboration by Sir James Eadie KC. The way in which it was dealt with by the court below and in
argument should not lead to the conclusion that a relevant consideration in the overall evaluation of the risk
of refoulement should artificially be left to one side In the scheme of determining whether a proposed


-----

Commissioner for Refugees intervening) and other case....

course of action amounts to a breach of section 6 of the Human Rights Act (and therefore the ECHR itself)
the court making the decision must consider all the evidence before it. The Divisional Court reposed
confidence in the MoU (it quoted para 10.4) and the monitoring arrangements. The evidence of the
practicality of removal, with which para 10.4 is concerned, was before it. Part of the Secretary of State's
case before the Divisional Court was that there will be little practical chance of removal in any of these
cases. In agreement with Underhill LJ, I would not ignore this evidence despite there being no respondent's
notice in respect of it. My conclusion, having regard to all the evidence, is that the risk of refoulement of a
failed asylum seeker sent by the United Kingdom to Rwanda is low and that the assessment of this
evidence is relevant to determining the overall evaluation of whether substantial grounds for believing there
is a real risk of refoulement have been established.

502. The UNHCR has provided cogent evidence that various individuals or groups of people have been
denied access to the Rwandan asylum process at the entry stage. Individuals have been turned away at
the airport; families in Rwanda have been denied the opportunity to make a claim; and large numbers who
travelled from Israel to Rwanda under an agreement (the details of which are unknown) did not have their
claims properly assessed. They were either pushed across the border into neighbouring countries or left
Rwanda and travelled to Europe. None of this, troubling though it is, suggests that anyone sent from the
United Kingdom to Rwanda is at real risk of similar treatment. The passage of each individual would be
agreed in advance. They would be met on arrival at Kigali and would be expected to make asylum claims.
Their journey through the asylum process and beyond would be monitored. Underhill LJ has analysed the
evidence relating to the nature of the interview that can be expected to be conducted by the DGIE, the
involvement of an eligibility officer and the early stages of engagement in the asylum process in Rwanda.
The RSDC acting on the fruits of the interview, further country information and possibly personal
appearance of the person in question will make its decision. I share the concerns identified by the UNHCR
about whether those involved in the RSDC have sufficient training and expertise to deal appropriately with
asylum claims and also whether what are reported as ingrained attitudes of scepticism towards claims
made by Middle Eastern nationals will be influential. There is certainly evidence of poor practice. There will,
no doubt, be changes in respect of those considered under the agreement with the United Kingdom. But
the question is whether the system as a whole can be relied upon to deliver appropriate outcomes.

503. To my mind an important factor in answering that question is whether the monitoring arrangements,
both formal and informal, provide sufficient protection to drive good decision making and thus to reduce the
risk of refoulement below the level that would give rise to a breach of article 3 by the United Kingdom in
sending people to Rwanda.

504. The Strasbourg Court has recognised the importance of effective monitoring arrangements when
considering assurances in support of the removal of a named individual to a country where, in the absence
of the assurances, there is every reason to suppose that article 3 standards will not be met there. The
principles were drawn together in _Othman v. United Kingdom_ (2012) 55 EHRR 1 at [89]. Othman (Abu
Qatada) had been convicted of terrorism in Jordan _in absentia and was to be removed to Jordan on the_
strength of assurances from the Jordanian Government that he would not be ill-treated and would get a fair
retrial. The approach of the court does not read over precisely to generic, rather than person-specific,
assurances. Nonetheless, the purpose of the list of factors set out by the Strasbourg Court was to focus
attention on whether the assurances would be effective. Monitoring compliance with the agreement is an
important factor.

505. It is reasonable to assume that individuals who find themselves in Rwanda would be familiar with the
agreement reached between the governments. With the assistance of lawyers in England, those unwilling
to be removed to Rwanda would have been engaged in resisting on all available grounds. In referring to
“informal” monitoring I have in mind the reality that anyone removed to Rwanda, with their internet
connected mobile phone, will be in a strong position to raise any personal concerns that they are not being
treated in accordance with the agreement. It is probable that they will be in contact with family and friends,
their English lawyers, the British High Commission and, indeed, the UNHCR in Rwanda. The UNHCR
would be expected to pay close attention to what was happening on the ground despite having no formal


-----

Commissioner for Refugees intervening) and other case....

role in the monitoring arrangements. It has done that in respect of refugees generally in Rwanda beyond
the aspects where it has its own agreements with the government. Those sent from the United Kingdom
will be housed with other asylum seekers. One way or another, shortcomings in the provision of interviews,
transcripts, interpreters, lawyers, reasons for decisions etc. in accordance with the agreement would
readily come to light with a good chance of their being dealt with.

506. Importantly, the formal monitoring provided both by the agreement and by arrangements put in place
in the British High Commission in Kigali would also do so.

507. The first formal part of the monitoring arrangements involves the British High Commission in Kigali
with Home Office officials embedded there to monitor compliance with the agreement. Finnlo Crellin was
posted to the High Commission in Kigali as Home Office liaison officer. The role, which will be a permanent
one for the duration of the agreement, involves developing relationships with players in all parts of the
system in Rwanda to flag concerns and to make the agreement work. As he puts it, “the extent of these
relationships between the respective Governments is key to the strength and collaborative nature of the

[agreement], allowing both sides to assess progress, discuss specific issues or flag any concerns –
including around implementation of the assurances in the MoU and [Notes Verbale] – and to resolve these
effectively.” Kristian Armstrong, a senior Home Office official, explains that the Home Office officials in
Kigali have the right under the MoU to observe any stage of the asylum process. This enables the United
Kingdom to monitor, on a constant basis, that the assurances are being met and the system in Rwanda is
working. It also provides accountability by the Government of Rwanda to the United Kingdom for the
assurances given under the agreement. He adds that there is an agreement that Rwanda will provide a
quarterly report to the United Kingdom on the outcome of each asylum claim and appeal, the status of
each relocated individual in Rwanda and details of anyone who has left or been removed from Rwanda.
The agreement makes provision for complaints which adds another safeguard.

508. The agreement also makes provision for independent monitoring. The MoU provides for an
independent Monitoring Committee to which each government nominates four members, operating
independently of the governments. Those nominations were made and the Terms of Reference of the
Monitoring Committee agreed. The MoU ensures unfettered access by the Monitoring Committee to
relevant records, officials and facilities. The Monitoring Committee is designed to ensure that there are
frequent independent and authoritative reports on how all parts of the system are performing in Rwanda. It
will provide reassurance to the British Government that relocation of individuals to Rwanda is compatible
with the 1951 Convention and the ECHR. In my view this monitoring arrangement will provide significant
assurance that the agreement is being abided by, pick up problems and enable any that develop to be
dealt with.

509. The next level of monitoring which the agreement establishes is the Joint Committee. The MoU
provides for the agreement to be closely managed. The Joint Committee is made up of senior officials from
the United Kingdom and Rwanda. It first met in Kigali on 31 May 2022 to discuss preparations for the initial
flight and the work to ensure that assurances contained in the agreement are implemented. Its role is to
provide direction and manage the implementation of the commitments set out in the MoU. The United
Kingdom representatives on this committee are the British High Commissioner in Rwanda, a Senior
Operational Director from Immigration Enforcement, a senior member of Home Office Legal Advisors and
Mr Armstrong. The Rwandan members include members from the DGIE, MINEMA and the Foreign
Ministry. Its terms of reference have been agreed.

510.  A function of the Joint Committee is to discuss plans for the number of individuals to be relocated to
Rwanda over the forthcoming year, with a particular focus on the immediately following quarter. This plan
will be a joint effort produced with a view to ensuring that the numbers are realistic on both sides having
regard to capacity to deal with the individuals and asylum claims in accordance with the agreement.

511. These multiple levels of protective monitoring provide powerful reassurance that the terms of the
agreement will be honoured and that if there are problems they will be picked up and ameliorated. I
understand the concerns of UNHCR but do not consider that the organisation is giving sufficient weight in


-----

Commissioner for Refugees intervening) and other case....

its assessment to the strong interest of both governments to make this arrangement work, the detailed
monitoring arrangements which will pick up any problems and the ability to sort them out if they arise. If
significant problems arose giving rise to the relevant risk of refoulement the British Government would be
unable to continue lawfully to send people to Rwanda. The reputation of Rwanda in this very high-profile
public agreement is at stake. More prosaically, there are powerful financial incentives at work, described in
general terms by Mr Armstrong. Not only is every cost associated with the reception and processing of
asylum seekers being met by the United Kingdom and those removed to Rwanda provided with an income,
but substantial sums of future aid support depend upon Rwanda's compliance with the agreement. These
factors operate in an environment of a deepening relationship between the United Kingdom and Rwanda in
recent years explained in the evidence from Simon Mustard of the Foreign Commonwealth and
Development Office. He does not seek to avoid confronting some of the profound human rights concerns
that remain, particularly concerning the lack of tolerance for political opposition to the government of
President Kagame. He expresses the confidence of the Foreign Office that the Government of Rwanda will
honour its commitments.

512. The focus of concern of the UNHCR set out in Mr Bottinick's evidence is on the administrative stages
of the asylum process: DGIE interview; RSDC consideration of the claim and then the appeal to MINEMA.
Those concerns arise particularly if Rwanda deals with substantial numbers of claims. He says very little
about the Rwandan Courts beyond observing that the right of appeal to the High Court, introduced some
years ago, does not yet appear to have been utilised and, so far as the UNHCR are concerned, the
jurisdiction and procedures that will be applied are unclear.

513. The Note Verbale records that “the court will be able to conduct a full re-examination of the Relocated
Individual's claim in fact and law in accordance with Rwandan rules of court procedure.” There will be legal
representation. Proceedings will be in public and an adverse decision may be appealed. The UNHCR does
not suggest that the judges of the High Court and Appeal Court in Rwanda will not deal with cases that
reach the courts properly. Before the Divisional Court the appellants had developed a nascent argument
that the Rwandan Courts generally lack independence which was expanded before us. The submission, in
short, is that the Rwandan judiciary cannot be expected to disagree with the conclusion of MINEMA, a
government department.

514. Mr Husain relied upon the decision of the Divisional Court (Irwin LJ and Foskett J) in Government of
_Rwanda v. Nteziryayo [2017] EWHC 1912 (Admin) which concerned a request for extradition of a Hutu for_
genocide arising out of the events of 1994. The request was made in 2013, an earlier request from 2006
eventually having been unsuccessful in April 2009. The argument before the District Judge was that the
requested person would not get a fair trial in Rwanda. The judgments of both the Senior District Judge at
first instance and the Divisional Court explored in detail questions of judicial independence in Rwanda.
They expressed concerns of a lack of independence in some types of politically charged case.
Nonetheless, their conclusions did not rest on the simple proposition that the judiciary was not independent
and would thus deliver a result desired by the government: see [365] to [384] of the judgment of the
Divisional Court and Annex 3 citing from the judgment of the Senior District Judge. The pivotal issue was
the effectiveness of the legal profession in criminal cases of that sort.

“377 …The closer we have read the evidence in this case, the firmer has become our agreement with the
judge below that defence capacity is the vital element, the capstone, of the case. Whilst in the context of
our court system adequate representation is of course important, other safeguards in the system such as
responsible unbiased prosecution, witness protection, unchallenged and complete judicial independence
taken together, mean that inadequate defence may be compensated for and a reasonable quality of justice
delivered overall. Even in that context, it is well established that miscarriages of justice will occur, where
defence representation is inadequate. However, in the context of Rwanda, with the difficulties and
weaknesses we have identified, the presence or absence of effective defence is absolutely central. We are
completely of one mind with the judge below on that point.”

515. The lack of independence of the Rwandan judiciary in “politically sensitive cases” was also called into
question by Human Rights Watch in a letter dated 11 June 2022 to the Home Secretary a view essentially


-----

Commissioner for Refugees intervening) and other case....

accepted by the Foreign Office. The question, as it seems to me, is whether the government would put
pressure on the courts to adhere to the administrative view and whether the courts would be influenced by
that pressure or, it might be said, themselves go along with the decision come what may, without any
pressure being exerted. That question must be answered in the context of the agreement between the
governments which rests upon a desire, indeed determination, of Rwanda to demonstrate the integrity of
its asylum system including the independence and efficacy of its High Court and Court of Appeal. The
Rwandan judiciary, on the hypothesis that appeals reach the High Court or beyond, will be under detailed
scrutiny, indeed international scrutiny.

516. Sir James Eadie KC submitted that the context of these possible appeals is very far removed from
prosecutions in which the state has an interest in securing a conviction for genocide or for offences alleged
against political opponents. A particular terrorism trial was referred to in evidence. He submitted that an
asylum appeal against an administrative decision is of a different character and bears no obvious political
dimension which would give rise to the risk of manipulation. Those are points well-made. He also referred
to what I would regard as a circularity at the heart of the appellants' submission on this point. The
Government of Rwanda had entered into a solemn agreement to abide by all its legal obligations regarding
asylum claims, putting in place special features not hitherto available to other asylum applicants, and relies
positively on the safeguard of an independent judicial process after the completion of the administrative
determination of asylum claims. There is an obvious need for the judiciary of Rwanda in the High Court and
Appeal Court to show its independence. One would expect it to do so.

517. I have indicated my conclusion (see [501] above) that the risk of _refoulement_ at the end of the
process (including administrative and legal appeals) in cases involving individuals sent to Rwanda from the
United Kingdom pursuant to the agreement is low. I am also satisfied that the terms of the agreement, the
strong incentives on the Government of Rwanda to deliver its side of the bargain, the general scrutiny
under which all decisions will be made and the strong monitoring arrangements in place lead to a
conclusion that the risks of wrong or perverse decisions are also low. My evaluation of all the evidence,
only a part of which has been referred to in the three judgments we are delivering, results in the conclusion
that substantial grounds for believing that there is a real risk that deficiencies in the asylum system will lead
to wrong decisions and refoulement have not been established.

Safety of Rwanda: conditions in Rwanda

518. The Divisional Court dealt with this issue between [73] and [79]. It identified two bases upon which it
was suggested that persons removed to Rwanda would face a real risk of treatment prohibited by article 3
ECHR. The first relates to a general intolerance of political criticism and the second to events which
occurred in Kiziba refugee camp in 2018 when protests about the conditions in the camp resulted in
disturbances which were violently supressed by the Rwandan police and resulted in deaths. As to the
second, the Divisional Court, correctly in my view, considered that it was unlikely anything similar could
happen to those sent to Rwanda under the agreement. They will not be in a refugee camp. As it said at

[74]:

“the treatment of transferred persons, both prior to and after determination of their asylum claims is
provided for in the MoU … and in the Support NV. For the reasons already given, we consider the
Rwandan authorities will abide by the terms set out in these documents … The Support NV includes (at
paragraph 17) that a mechanism is to be established to allow complaints about accommodation and
support provided under the MoU to be raised and addressed. Provision for those arrangements is strong
support for the conclusion that the possibility of complaint on such matters, made by persons transferred
under the [agreement] does not give rise to any real risk that the consequence of complaint will be Article 3
ill treatment.”

519. The court dealt with the wider submission concerning whether those transferred to Rwanda would be
at real risk of article 3 ill-treatment because of the way the Rwandan authorities might respond to
expressions of opinion adverse to them or acts of political protest. Between paragraphs [76] and [77] the
Divisional Court rejected that submission for reasons with which I agree:


-----

Commissioner for Refugees intervening) and other case....

"76. There is no suggestion that any of the individual Claimants … holds any political or other opinion that
is adverse to the Rwandan authorities. If there were such evidence it would fall to considered under
paragraph 345B(i) of the Immigration Rules. A proper application of that criterion would be sufficient to
ensure that were a person to face a real risk of article 3 ill-treatment, he would not be transferred. That
being so, the Claimants' case comes to the proposition that, following removal to Rwanda, it is possible
that one or more of those transferred might come to hold opinions critical of the Rwandan authorities, and
that possibility means that now, the Soering threshold is passed.

77. There is evidence that opportunities for political opposition in Rwanda are very limited and closely
regulated. The position is set out in the "General Human Rights in Rwanda" assessment document, one of
the documents published by the Home Secretary on 9 May 2022. There are restrictions on the right of
peaceful assembly, freedom of the press and freedom of speech. The Claimants submitted that this state
of affairs might mean that any transfer to Rwanda would entail a breach of article 15 of the Refugee
Convention (which provides that refugees must be accorded the most favourable treatment accorded to
nationals in respect of non-political and non-profit-making associations and trade unions). However, we do
not consider there is any force in this submission at all. Putting to one side the fact that article 15 does not
extend to all rights of association, it is, in any event, a non-discrimination provision - i.e., persons protected
under the Refugee Convention must not be less favourably treated than the receiving country's own
citizens. There is no evidence to that effect in this case. Returning to the material covered in the Home
Secretary's assessment document, there is also evidence (from a US State Department report of 2020)
that political opponents have been detained in "unofficial" detention centres and that persons so detained
have been subjected to torture and article 3 ill-treatment short of torture. Further, there is evidence that
prisons in Rwanda are over-crowded and the conditions are very poor. Nevertheless, the Claimants'
submission is speculative. It does not rest on any evidence of any presently-held opinion. There is no
suggestion that any of the individual Claimants would be required to conceal presently-held political or
other views. The Claimants' submission also assumes that the response of the Rwandan authorities to any
opinion that may in future be held by any transferred person would (or might) involve article 3 ill-treatment.
Given that the person concerned would have been transferred under the terms of the [agreement] that
possibility is not a real risk. It is to be expected that the treatment to be afforded to those transferred will be
kept under the review by the Monitoring Committee and the Joint Committee (each established under the
MOU). Further, the advantages that accrue to the Rwandan authorities from the [agreement] provide a real
incentive against any mis-treatment (whether or not reaching the standard of article 3 ill-treatment) of any
transferred person.”

520. In my view the appellants fall short of establishing that there are substantial grounds for believing that
there is a real risk that they will face treatment prohibited by article 3 ECHR in Rwanda.

**The procedural questions**

521. Ilias concerned the removal of two asylum seekers by Hungary to Serbia without any examination of
the merits of the claims. Serbia was deemed by Hungarian law to be a “safe third country” on the basis that
it was a candidate member to join the European Union and was required to satisfy EU standards when
considering asylum applications. The Hungarian authorities did not explore the realities of the position at all
and had no special arrangements with the Serbian authorities. Between [139] and [141] the court explained
that a state applying the “safe third country” concept must conduct a thorough examination of the relevant
conditions and reliability of the asylum system in the third country concerned. It must carry out of its own
motion an up-to-date assessment of the accessibility and functioning of the receiving country's asylum
system and the safeguards it affords in practice. The expelling State cannot merely assume that the
asylum seeker will be treated in the receiving third country in conformity with the Convention standards but
must first verify how the authorities of that country apply their legislation on asylum in practice: M.S.S. v.
_Belgium and Greece (App. no. 30696/09) at [359]._

522. These paragraphs were relied upon by the appellants in support of the submission that in safe third
country cases there is a free-standing procedural obligation to examine the receiving state's asylum


-----

Commissioner for Refugees intervening) and other case....

system, which the Home Secretary failed adequately to do. In consequence, submits Mr Husain KC, the
proposed removals are unlawful in article 3 terms on procedural grounds.

523. Like the Divisional Court I accept that this case bears little resemblance to the circumstances which
obtained in _Ilias_ where the Hungarian authorities made no investigations at all into the systems to which
the applicants would be exposed in Serbia. On the contrary, the British Government has explored
extensively the realities for asylum seekers on the ground in Rwanda. To the extent that deficiencies in the
general system of considering asylum claims have been identified, the agreement between the
governments has sought to remedy them. It was submitted that further inquiries of various sorts should
have been made and, in particular, the British Government should have explored the terms and
effectiveness of an agreement between the Governments of Rwanda and Israel by which individuals were
moved from Israel to Rwanda over a number of years.

524. Even if further inquiries might have been made on this or other matters, there is no question here of
the British authorities simply assuming that the Rwandan asylum system was adequate. On the contrary,
the realities were explored and perceived difficulties addressed. I agree with the Divisional Court the Ilias
investigative duty was complied with. It is unnecessary to consider whether the Strasbourg Court was
creating a truly free-standing investigative or procedural duty. Moreover, I agree with the Divisional Court
that the Tameside duty was complied with essentially for the reasons it gave.

**Gillick**

525. I indicated at [479] that because my conclusion is that Rwanda is a “safe third country” for article 3
purposes it follows that the various policies that enable the Home Secretary to send migrants there are not
unlawful in Gillick terms. That was the view taken by the Divisional Court. At [72] the court set out how that
conclusion runs against each of the various policy documents which make up the Rwanda policy:

“The next matter under this heading is the Claimants' submission that the policy by which persons whose
asylum claims are held to be inadmissible may be returned to Rwanda, is Gillick unlawful. The meaning of
the judgment of the House of Lords in Gillick has been considered recently by the Supreme Court in R(A) v
_Secretary of State for the Home Department [2021] 1 WLR 3931. The Supreme Court emphasised that the_
relevant question is whether the policy under consideration positively authorises or approves unlawful
conduct (in the present context, a removal decision in breach of ECHR article 3). Against this standard the
Inadmissibility Policy, which includes the possibility of removal to a safe third country, is not unlawful.
Removal decisions depend on the application of paragraph 345B of the Immigration Rules, and the
conclusion reached against the criteria in that paragraph that the country concerned is a "safe third country
for the particular applicant". If the relevant criteria are met (see above at paragraph 11), removal to that
country will not, applying the principles in _Ilias (themselves, a particular application of the principle in_
_Soering), give rise to a breach of article 3 of the ECHR. Even if the scope of the policy for this purpose is_
extended to cover the general conclusion in the 9 May 2022 assessment documents and the conclusion
reached following consideration of the further evidence filed in these proceedings by the UNHCR, the
position remains the same. The conclusion, based on all that material, that generally, asylum claims made
in Rwanda by persons transferred pursuant to the terms of the MOU would be entertained and effectively
determined was a lawful conclusion. And, in any event the final decision on removal would also have to
take account of the asylum claimant's personal circumstances - i.e., the criterion at paragraph 345B(i) of
the Immigration Rules.”

526. The _Gillick question, reaffirmed by the Supreme Court in the_ _A_ case referred to by the Divisional
Court, requires that where the question is whether a policy is unlawful, “that issue must be addressed
looking at whether the policy can be operated in a lawful way or whether it imposes requirements which
mean that it can be seen at the outset that a material and identifiable number of cases will be dealt with in
an unlawful way” (A at [63]). The policy (reflected in the materials to which the Divisional Court referred)
seeks to ensure that article 3 ECHR is not violated when individuals are removed to Rwanda. Taken as a
whole that is the aim of the policy. As Underhill LJ explains, if the policy in fact exposes individuals to the
material risk of ill-treatment it fails not only because the decisions taken under it would be unlawful for


-----

Commissioner for Refugees intervening) and other case....

article 3 reasons; it would also be unlawful in Gillick terms as (necessarily) authorising unlawful action. But
if I am right in my conclusion on the central issue that is not the case. For completeness I should add that
the decision of the House of Lords in R (Munjaz) v. Mersey Care NHS Trust [2006] 2 AC 148, to which Ms
Naik KC drew our attention, leads to no different conclusion: see the A case at [79].

**Conclusion**

527. The central question in these appeals is whether there are substantial grounds for believing that
removal of these appellants and any individual to Rwanda pursuant to the agreement with the Government
of Rwanda will give rise to a real risk of treatment contrary to article 3 ECHR either (a) as a result of
deficiencies in the asylum system with a consequent real risk of _refoulement_ or (b) in Rwanda itself. My
conclusion accords with that of the Divisional Court. The evidence taken as a whole does not support such
a real risk in either case. I agree with Underhill LJ and Sir Geoffrey Vos MR that the other grounds fail. Our
different conclusions on the central issue deliver a different conclusion on the _Gillick_ issue (which adds
nothing to the central question). I also agree with the Divisional Court on the procedural issues (Ilias and
_Tameside). In the result, I would dismiss the appeals._

**End of Document**


-----

