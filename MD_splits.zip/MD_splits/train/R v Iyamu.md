# R v Iyamu [2023] EWCA Crim 1658

Court of Appeal, Criminal Division

Popplewell LJ, Saini J, Foster J

31 October 2023Judgment

Mr C. Buckley appeared on behalf of the Applicant.

The Crown were not represented.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

LORD JUSTICE POPPLEWELL:

1 This is a renewed application for an extension of time of four days to appeal from the confiscation order
made by His Honour Judge Bond on 4 March 2022. The applicant had been convicted of trafficking five
Nigerian women into prostitution in England, contrary to section 2 of the Modern Slavery Act 2015, and of
perverting the course of justice by witness intimidation. She is currently serving a total sentence of 18
years' imprisonment for those offences. The judge made a confiscation order in the sum of £183,806.06,
which was the benefit figure, having concluded that the applicant had available assets in excess of that
sum.

2 Mr Buckley drafted grounds of appeal and appeared on the applicant's behalf before us although he did
not appear at the confiscation hearing. His grounds challenge three aspects of the benefit figure found by
the judge. The applicant also submitted an addendum, dated 6 October 2022, fashioned by herself raising
a number of further matters. Some of those involve the trial and her continued assertion of innocence, and
they do not affect the present application. Three of the matters, as it seems to us, raise concerns over
aspects of the confiscation order. Mr Buckley did not seek to address those grounds but we will deal with
them, as far as relevant, after addressing the grounds which Mr Buckley advanced.

3 We do not need to set out the judge's careful and detailed judgment on how the benefit figure was
determined, nor the other circumstances relevant to the appeal, all of which are set out in the Criminal
Appeal Office summary and are familiar to the applicant.

4 As is accepted on the applicant's behalf, the Judge was bound to treat the applicant as having a criminal
lifestyle and the assumptions set out in s. 10 of POCA 2002 were engaged. The first assumption is that set
out in s. 10(2) of POCA that any property transferred to the defendant after the relevant day (in this case
26 November 2011) was obtained by them as a result of their general criminal conduct. The second


-----

assumption set out in s. 10(3) of POCA is that any property held by the defendant at any time after the date
of conviction was obtained as a result of their general criminal conduct. The court must make such
assumptions unless the assumption is shown by the defendant to be incorrect or there would be a serious
risk of injustice if the assumption were made or questions of proportionality are engaged. The burden lies
on the defendant to rebut the assumption.

Ground 1

5 Ground 1 challenges the inclusion within the benefit figure of credits to the applicant's Barclays Bank
account in the total sum of £22,930. The financial investigator from the Regional Asset Recovery Team,
Mr Derek Tinsley, gave evidence on oath at the confiscation order hearing, as did the applicant herself. Mr
Tinsley confirmed, having been through the applicant's bank accounts and summarising all the deposits
made into her Barclays Bank account for the relevant period, that is to say 26 November 2011 to 4
December 2012, that they amounted in total to £82,194.12. Mr Tinsley then had regard to the explanations
given by the applicant in relation to those credits into her bank account and disregarded £59,264.12 of
those credits as adequately explained. That left the sum of £22,930 as being covered by the statutory
assumption that they were benefits from criminal conduct.

6 The bank statements show that the £22,930 was credited into her account by a large number of smaller
payments which were, in part, from cash deposits, in part the transfer of money from her husband and, in
one case, a payment from an F Jackson. The applicant had served a file which included an explanation for
those credits, item by item. In that document, the applicant's case was that many of those payments
related to the sale of clothes or hair extensions, gifts for her birthday and payments from her husband for
bills or upkeep. There were a variety of other explanations for other payments.

7 In his written judgment, at paragraph 44, the judge recorded that the applicant hardly addressed this
issue at all during the confiscation hearing. She was not asked any questions about those deposits by her

barrister. She was, however, cross‑examined by the Crown and questioned as to how she could recall the

source of cash deposits of such small amounts for as long ago as 2011 to 2012. The applicant provided
no documentary or corroborative evidence to support the explanations for the credits totalling £22,930.

8 The judge rejected her evidence on these receipts. Having heard her cross‑examined about them, he

was entitled to do so for the reasons he gave, namely that he did not accept that she was either honest or
reliable purporting to remember such details so long ago, for which there was no supporting
documentation. Mr Buckley submitted that the payments included some £9,925 from her husband, and
that because her husband had not been convicted of any criminal offence these could not be the proceeds
of crime and, accordingly, the assumption was rebutted. That is simply a non sequitur. Proceeds of crime
may pass to a person through the hands of one or more others who are not themselves complicit in the
criminal conduct.

Ground 2

9 Grounds 2 and 3 related to a property at 20 Imureze Street, Benin City, Nigeria ("the property"). The
property was valued at £171,368.09 in a report from C.O. Akpabor & Co, estate surveyors and valuers
from Benin City. At the confiscation hearing, the applicant's evidence was that the property did not belong

to her save to the extent of the $2,000 gift to her from her ex‑husband put towards the purchase of the

land. The judge rejected this evidence in the light of a body of evidence to the contrary which he
summarised at paragraph 50. It included not only statements from others which reflected on her ownership
of the property but also statements which the applicant had herself made, in evidence at trial and in
documents, in which she had said the property was hers. At the confiscation hearing she produced a
document called an "Irrevocable Living Trust Agreement" in support of a case that she had not owned
property. The judge rejected this as a clearly fabricated document for the cogent reasons which he gave.
He was entitled to conclude on the evidence that she gave that she was, indeed, the owner of the property.

10 The judge went on to find that the land on which the property was built had been purchased some 20

years earlier. That pre‑dated the offending which constituted the specific criminal conduct of which she


-----

had been convicted. The judge found that it would give rise to a risk of serious injustice to conclude that
the land itself was obtained by her as a result of her general criminal conduct because there was no
evidence that her criminal offending went back so far in time.

11 The judge then recorded that there was no evidence as to when the house was built on the land. It
was, it seems, a substantial building. It was no doubt described in the report which was before the judge
although that document is not before this court. The applicant described it in her evidence at trial as
having five bedrooms and a living room and further staff quarters. The victims at trial described it as a
large property. The judge concluded that as it had been built after the plot was acquired at some stage
and as the applicant's evidence as to her legitimate income and her tax return to HMRC was insufficient to
account for the costs of building, she had failed to rebut the assumption in respect of the building itself.
He, therefore, found that the assumption applied, that the building was financed through the applicant's
general criminal conduct and constituted a criminal benefit derived therefrom. That was a conclusion
which was open to him on the evidence.

12 Mr Buckley submits, essentially, that the judge was bound to treat the building in the same way as he
had treated the land. This is misconceived. There was clear evidence about when the land was acquired,
it seems, in 1998. And given its antiquity, the judge properly considered whether applying the assumption
gave rise to a risk of injustice. So far as concerns the building element, the applicant chose to advance no
evidence about when it was built but rather to take her stance on the false position that it did not belong to
her. She had, therefore, failed to displace the assumption that it was built at a time when she was
engaged in criminal conduct and the evidence showed that her declared legitimate income could not have
financed the cost. Accordingly, the judge was entitled to treat the building itself as the proceeds of criminal
conduct.

13 The judge was then faced with having to assess what part of the value to attribute to the land and what
part to the building. There was no evidence available on that question. The judge applied his own
judgement which was that 25 per cent was attributable to the land and 75 per cent to the building. Mr
Buckley submits that in the absence of evidence as to apportionment, the judge was not entitled to make
that apportionment which, Mr Buckley submits, was simply arbitrary. He suggests that the National Crime
Agency had procured the valuation report and it would have been possible for those valuers to have
addressed the question of apportionment. In a respondent's notice, the Crown suggest that it would have
been possible for the applicant to do so, but instead she continually and consistently lied about her interest
in that property.

14 It is important in our view to recognise that the exercise in which the judge was engaged was not a

hard‑edged question of apportionment of property or land values. The applicant had failed to displace the

assumption as being incorrect under section 10(6)(a) of the Act in respect of either the land or the building.
However, the judge had treated the antiquity of the land purchase as something which would not make it

just to include the whole of the £171,000‑odd as proceeds of criminal conduct by the application of section

10(6)(b). He was, therefore, faced with the exercise of deciding the extent of that risk of injustice. He was
not bound to treat the whole of the combined land and building value as falling outside the category of
proceeds of crime, and it would have been absurd, and contrary to the evidence, to do so. There was
evidence of a substantial building which would obviously make a major contribution to the value of the
property as a whole. He made an assessment that a 25 per cent reduction properly reflected the extent of
the risk of injustice in treating the whole of the value, including both the land and the building, as the

proceeds of crime. That was, inevitably, a broad‑brush assessment but cannot be regarded as an

unreasonable one. Indeed, it might have been thought generous to the applicant.

15 Accordingly, we reject grounds 2 and 3.

The applicant's addendum grounds.

16 The first additional ground raised by the applicant in her own addendum relates to ground 3. It is that

the Deed of Sale for the property evidences that at the time of purchase there was a pre‑existing building


-----

foundation on the land. This, she suggests, shows that the building was built shortly after the purchase.
The document on which she relies was not put before the court. I will assume that it shows what she
contends but if so this is in any event a false point. The existence of foundations at the time of purchase
tells one nothing about when the applicant subsequently built the house even if it be the case, which we

will also assume, that the pre‑existing foundations were used. The applicant also suggests that she could

now provide further evidence about when the house was built although she does not set out what that
evidence is or when it was that the house was built. However, it is far too late for her to do so. The time
for putting forward such evidence was when the confiscation proceedings were being conducted and
before they were concluded by His Honour Judge Bond.

17 The next additional ground advanced in the grounds fashioned by the applicant herself addresses the
sum of £21,387.38 which the judge held was the specific criminal benefit from the convicted offences,
being the total of the amounts paid by and received from the five victims. How that sum is made up as
between the five victims is set out clearly at paragraph 31 of the judgment. The judge explained in detail
how he had reached those figures based on the evidence which each victim had given at trial, in one case
reducing from the amount sought to be included by the National Crime Agency. The judge was best
placed to assess such evidence and was entitled to accept it. There is simply no basis for treating him as
having made any error in that regard.

18 The final additional ground with which we should deal challenges the judge's reliance on the Akpabor
valuation of the Benin City property. It is said that for various reasons Akpabor were not independent
valuers. However, none of the material on which that suggestion is made has been put before the court,
nor was it put before His Honour Judge Bond. The valuation was made by apparently professionally
qualified surveyors and there was no evidence to the contrary. Mr Buckley, in his submissions to us today,
described it as independent valuation evidence. The judge was entitled to treat it as an accurate valuation.

19 For all these reasons there is no merit in any of the grounds of appeal advanced, and an appeal would
have no prospect of success. For that reason, we refuse the renewed application for an extension of time.

__________________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge._**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

