# R v S [2020] EWCA Crim 765

Court of Appeal, Criminal Division

Singh LJ, Holgate J and Judge Lucraft QC (sitting as a judge of the Court of Appeal, Criminal Division)

17 June 2020Judgment

**Mr Bunty Batra (instructed by Wylie Kay Solicitors) for the Applicant**

**Mr Andrew Johnson (instructed by the Crown Prosecution Service) for the Respondent**

Hearing date : 5 June 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Reserved Judgment Protocol: This judgment will be handed down by the Judge remotely, by circulation**
to the parties' representatives by email and, if appropriate, by publishing on www.judiciary.uk and/or release to
Bailii. The date and time for hand down will be deemed to be 10:30 on 17 June 2020. The Court Order will be
provided to Preston Crown Court for entry onto the record.

**Lord Justice Singh :**

Introduction

1. On 4 December 2017, in the Crown Court at Preston, the Applicant pleaded guilty to Count 1 on the
indictment, which alleged an offence of producing a controlled drug of Class B (cannabis), contrary to
section 4 of the Misuse of Drugs Act 1971. He was sentenced by HHJ Brown, the Recorder of Preston, to
12 months' imprisonment, a sentence which he has now served. Count 2 (which alleged unlawful
abstraction of electricity) was ordered to remain on the file on the usual terms.

2. The Applicant seeks leave to appeal against his conviction out of time. That application has been
referred to the Full Court by the Registrar.

3. At the hearing on 5 June 2020, we were assisted by submissions from Mr Bunty Batra on behalf of the
Applicant and Mr Andrew Johnson on behalf of the Respondent. We are grateful to them both.

Factual Background

4. On 26 September 2017, police officers executed a search warrant at an address in Blackpool. As the
police approached the address, the Applicant ran out of the back of the property and attempted to climb
over a wall. The officers apprehended him.

5. The property was a three bedroom house; each room had been set up to grow cannabis with
hydroponics and lighting equipment. 203 plants were seized from the property and 36 bags of plant matter
cannabis were seized. The Applicant's fingerprints were found on the growing equipment.

6. In interview, the Applicant explained that he had been brought over from Vietnam in the back of a lorry,
and spent a short period of time in a different property before being moved to the three bedroom property
by two men. He said that he had been told that, if he stayed in the house for five months and assisted in


-----

the production of the cannabis, he would have paid off what he owed for his transport to this country. He
said that he was shown how to set up the rooms in the house and was then left to look after the plants. He
said the door was not locked but that he was too scared to leave because he was scared of the two men
and had nowhere else to go. He had been in the house approximately four and a half months.

Anonymity

7. The Applicant applies for an anonymity order, under section 11 of the Contempt of Court Act 1981. We
are very conscious of the importance of the principle of open justice and we bear in mind that an anonymity
order must be both necessary and proportionate.

8. At the start of the hearing before us on 5 June 2020, we made that order on an interim basis, since
there was reason to believe that the Applicant had been the victim of human trafficking; he had named the
two men who had compelled him to look after the cannabis plants; he would be at risk of intimidation or
reprisals were his identity to become known; and in order not to render the issue academic pending the
final judgment of this Court. Having considered the matter more fully, and in the light of the conclusion we
have reached on the underlying merits of this case, we now confirm that anonymity order, which will
continue indefinitely.

Fresh evidence

9. The Applicant seeks leave, pursuant to section 23 of the Criminal Appeal Act 1968 (“the 1968 Act”), to
introduce fresh evidence relating to his status as a victim of human trafficking from the “Competent
Authority”, which is an authority within the Home Office. The Applicant seeks, in particular, to refer to the
decision of that Authority dated 21 December 2018 to the effect that he was indeed the victim of trafficking.
In that letter the Competent Authority noted that, on 4 November 2017 (that appears to have been a
drafting error, as the date should have been 4 October 2017), it had decided that there were reasonable
grounds to believe that the Applicant was a victim of trafficking but that its eventual decision, dated 21
November 2017 (again this date appears to be wrong, as it was dated 4 November 2017), was that there
were insufficient grounds to believe that he was. We note that the decision of November 2017 was
described in its own terms as the “Conclusive Grounds Decision”: this terminology appears to have been
used by the Competent Authority to contrast it with the earlier decision, which was described as the
“Reasonable Grounds Decision”.

10. Section 23 of the 1968 Act, so far as material, provides:

E+W(1) For the purposes of an appeal, or an application for leave to appeal, under this Part of this Act the
Court of Appeal may, if they think it necessary or expedient in the interests of justice—

…

(c) receive any evidence which was not adduced in the proceedings from which the appeal lies.

…

(2) The Court of Appeal shall, in considering whether to receive any evidence, have regard in particular
to—

(a) whether the evidence appears to the Court to be capable of belief;

(b) whether it appears to the Court that the evidence may afford any ground for allowing the appeal;

(c) whether the evidence would have been admissible in the proceedings from which the appeal lies on an
issue which is the subject of the appeal; and

(d) whether there is a reasonable explanation for the failure to adduce the evidence in those proceedings.

11. The decision of the Competent Authority dated 21 December 2018, that the Applicant was the victim of
trafficking is clearly fresh evidence, since it did not exist at the time of the Applicant's guilty plea on 4
December 2017. It is also capable of belief, coming as it does from the official authority which deals with
human trafficking issues in this country and is independent of the Applicant. In the light of the view that we


-----

have taken about the merits of the underlying application for leave to appeal, we grant permission to
adduce that fresh evidence under section 23 of the 1968 Act.

Extension of time

12. The Applicant applies for an extension of time of approximately one year and four months. The
chronology of events can be summarised briefly for present purposes as follows.

13. The decision of 21 December 2018 was initially sent to Duncan Lewis, who were the solicitors acting
for the Applicant in relation to immigration matters. That decision was received by Wylie Kay, the solicitors
acting for the Applicant in these criminal proceedings, on 3 January 2019. On 24 January 2019 the
Applicant's solicitors wrote to the Crown Prosecution Service (“CPS”) asking if they would oppose an
application to vacate the plea. On 4 February 2019 the CPS replied to say that they would not oppose
vacation of the plea but would need to consider in more detail the rationale for the decision of 21
December 2018 before deciding whether to offer any evidence against the Applicant at any retrial. On 8
March 2019 the CPS stated that they had considered the material and would not seek to continue with the
proceedings in the case. It will be apparent therefore that, initially, the parties envisaged that the Crown
Court would set aside the conviction and there might be a retrial. It then became apparent that an
application for leave to appeal against conviction would have to be made to this Court. Counsel was
instructed to draft the application for leave on 13 March 2019.

14. The application for leave to appeal was filed in this Court on 30 May 2019. It is submitted that the
Applicant's lawyers acted expeditiously upon being informed of the change of position by the Competent
Authority and the CPS. Some might quibble with that but, in the circumstances of this case, we are
satisfied that the extension of time sought must be granted in order to do justice in this case, not least in
the light of the view we have reached about the merits of the underlying application for leave.

The Respondent's position

15. The Prosecution have lodged a comprehensive and helpful Respondent's Notice, dated 31 March
2020, drafted by Mr Johnson, in which they submitted:

(1) The Prosecution, having had sight of the relevant materials including the witness statement of the
solicitors with conduct, do not oppose the application (paras. 8 and 85).

(2) Whether the Applicant was a victim of trafficking had been identified at an early stage. The
Respondent had indicated that, if the Competent Authority concluded that the Applicant was a victim of
trafficking, it would offer no evidence. Accordingly, proceedings were adjourned to await the Competent
Authority's decision. The Competent Authority ultimately concluded that the Applicant was not a victim of
trafficking and thus that prosecution continued and the Applicant pleaded guilty (para. 4).

(3) However, the Applicant challenged the decision reached by the Competent Authority and further
material was provided. As a result, the Competent Authority concluded that the Applicant was a victim of
trafficking (para. 5).

(4) The Respondent had considered (a) the handwritten note of the endorsement the Applicant signed
prior to his arraignment, in which the Applicant continues to assert that his offending occurred as a result of
his “smuggling”; and (b) the witness statement of the Applicant's solicitor, dated 18 March 2020, in which
his solicitor indicates that he treated the decision of the Competent Authority “as conclusive”. The
Respondent respectfully considers that the Applicant's solicitor erred in his approach to section 45 of the
**_Modern Slavery Act 2015 (“the 2015 Act”).  The Competent Authority's decision was not conclusive, in_**
the sense of preventing a section 45 defence being advanced. The availability of the defence was not for
the Competent Authority to determine, but for the jury (paras. 70 and 71).

(5) The Respondent concedes that the Applicant is in a position to establish that a defence under section
45 would probably have succeeded and, in the Respondent's respectful submission, the Applicant did not
decide to enter a guilty plea on an informed basis.  His decision to plead guilty was made in circumstances


-----

where he was wrongly advised that the negative conclusive grounds decision was conclusive, which, for
the purposes of the criminal proceedings it was not (para. 84).

16. By the time of the hearing before us, matters had moved on to some extent. As we note later, further
witness statements were filed by the Applicant's solicitor on 2 June and 4 June 2020. However, at the
hearing before us, Mr Johnson in substance maintained the position which he had advanced in the
Respondent's Notice. He submitted that the application for leave turns ultimately on what view this Court
takes of the totality of that evidence.

[The Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

17. Section 45 of the 2015 Act provides as follows:

“(1) A person is not guilty of an offence if– (a) the person is aged 18 or over when the person does the act
which constitutes the offence, (b) the person does that act because the person is compelled to do it, (c) the
compulsion is attributable to slavery or to relevant exploitation, and (d) a reasonable person in the same
situation as the person and having the person's relevant characteristics would have no realistic alternative
to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if– (a) it is, or is part of, conduct
which constitutes an offence under section 1 or conduct which constitutes relevant exploitation, or (b) it is a
direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if– (a) the person is under the age of 18 when the person does the
act which constitutes the offence, (b) the person does that act as a direct consequence of the person
being, or having been, a victim of slavery or a victim of relevant exploitation, and (c) a reasonable person in
the same situation as the person and having the person's relevant characteristics would do that act.

(5) For the purposes of this section– 'relevant characteristics' means age, sex and any physical or mental
illness or disability; 'relevant exploitation' is exploitation (within the meaning of section 3) that is attributable
to the exploited person being, or having been, a victim of human tracking.

(6) In this section references to an act include an omission.

(7) Subsections (1) and (4) do not apply to an offence listed in Schedule 4.”

18. The background to the 2015 Act, including the wider context of international and European law, was
set out fully in _R v. Joseph_ _[2017] EWCA Crim 36; [2017] 1 WLR 3153, at paras. 9-22 (Lord Thomas of_
Cwmgiedd CJ).

19. As this Court explained in _Joseph, at paras. 15-16, the National Referral Mechanism (“NRM”) was_
established in 2009 in order to give effect to this country's international obligations in relation to trafficked
persons. As part of that mechanism, the Competent Authority was established in the Home Office. The
terminology used by the Competent Authority is of some significance because, as noted by this Court in
_Joseph at para. 16, it operates under guidance issued by the Home Office, which describes the process_
whereby the Competent Authority first makes a decision that there are reasonable grounds to believe that
a person may be the victim of trafficking; but later makes what is described as a “conclusive decision”.
That terminology may be the origin of some of the confusion that has arisen in the present case.

20. In any event, the decisions of the Competent Authority are not in truth conclusive if an issue arises in
the context of criminal proceedings. The question whether a person is the victim of human trafficking is
one on which the view of the Competent Authority is entitled to be borne in mind but it is not conclusive:
see Joseph, at para. 40, where Lord Thomas said:

“It is important to appreciate a court will bear the Competent Authority's conclusion very much in mind but
will examine the question of the cogency of the evidence on which the Competent Authority relied and
subject the evidence to thorough forensic examination. It does not follow from the fact that an individual 'fits


-----

the profile' of a victim of trafficking that they are necessarily the victim of trafficking. A careful analysis of
the facts is required including close examination of the individual's account and proper focus on the
evidence on the nexus between the trafficking and the offence with which they are charged.”

21. As this Court made clear in R v DS _[2020] EWCA Crim 285, at para. 40 (Lord Burnett of Maldon CJ),_
the result of the enactment of the 2015 Act and the section 45 statutory defence is that it is no longer
necessary for the courts to fill any perceived gaps by expanding the notion of abuse of process. The
question whether the section 45 defence is made out, or more accurately whether the prosecution have
proved that it is not made out (since the burden of proof rests on the prosecution), is a question of fact for
the jury to decide.

22. Furthermore, it is apparent from the words of section 45 that the statutory defence does not arise
automatically simply because a person was the victim of trafficking. In addition, there are other elements
of the defence, for example the need for compulsion which is attributable to slavery or a relevant act of
exploitation.

Applications to set aside a guilty plea

23. In R v Asiedu _[[2015] EWCA Crim 714; [2015] 2 Cr App R 8, at paras. 19-25 (Lord Hughes), this Court](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FW9-9W11-F0JY-C09M-00000-00&context=1519360)_
re-affirmed the principles on which a defendant may be permitted to go behind a plea of guilty. At para. 32,
this Court emphasised that the trial process is not a “tactical game”. A defendant who has admitted facts
which constitute an offence by an unambiguous and deliberately intended plea of guilty cannot ordinarily
appeal against conviction, since there is nothing unsafe about a conviction based on his own voluntary
confession in open court. The Court said that, leaving aside pleas which are equivocal or unintended,
there are two principal exceptions to this. The first is where the plea was compelled as a matter of law by
an adverse ruling by the trial judge which left no arguable defence to be put before the jury. The second is
where, even if on the admitted or assumed facts the defendant was guilty, there was a legal obstacle to his
being tried for the offence. This would apply where his prosecution would be stayed on the ground that it
was offensive to justice to bring him to trial.

24. Although those are the main exceptions, it is clear from earlier authority that the jurisdiction is a more
general one, derived ultimately from section 2(1) of the 1968 Act. The original version of that provision was
as follows:

“Except as provided by this Act, the Court of Appeal shall allow an appeal against conviction if they think—

(a) that the verdict of the jury should be set aside on the ground that under all the circumstances of the
case it is unsafe or unsatisfactory; or

(b) that the judgment of the court of trial should be set aside on the ground of a wrong decision of any
question of law; or

(c) that there was a material irregularity in the course of the trial,

and in any other case shall dismiss the appeal:

Provided that the Court may, notwithstanding that they are of opinion that the point raised in the appeal
might be decided in favour of the appellant, dismiss the appeal if they consider that no miscarriage of
justice has actually occurred.”

25. After its amendment in 1995, section 2(1) now provides:

“Subject to the provisions of this Act, the Court of Appeal—

(a) shall allow an appeal against conviction if they think that the conviction is unsafe; and

(b) shall dismiss such an appeal in any other case.”

26. Both parties before us referred us to the decision of this Court in R v Boal [1992] QB 591, which predates that amendment; it was not suggested that the amendment has made any material difference to the
issue in the present case. Boal does not appear to have been cited in Asiedu but we do not consider that


-----

there is any inconsistency between them. In Boal, at p. 599, Simon Brown J set out the following quotation
from the judgment of Ackner LJ in R v Lee (Bruce) [1984] 1 WLR 578, at p. 583:

“The fact that [Lee] was fit to plead; knew what he was doing; intended to make the pleas he did; pleaded
guilty without equivocation after receiving expert advice; although factors highly relevant to whether the
convictions on any of them were either unsafe or unsatisfactory, cannot of themselves deprive the court of
the jurisdiction to hear the applications.”

27. Simon Brown J then said the following, at pp. 599-600:

“In short, this court is not merely empowered but, by virtue of section 2(l)(a) of the Criminal Appeal Act
1968, duty bound to allow an appeal against conviction if in all the circumstances we think such conviction
unsafe or unsatisfactory. Accepting, as we do, that the appellant without fault on his part was deprived of
what was in all likelihood a good defence in law, that indeed is our conclusion in this case. It follows that
we allow this appeal. Had the prosecution desired it, we might in the result have ordered the appellant to
be retried. As it is, however, Mr. Pawlak tells us that his clients very sensibly desire no such thing.
Accordingly the conviction is quashed, the sentences set aside, and the matter rests there.

We add a short paragraph of warning. This decision must not be taken as a licence to appeal by anyone
who discovers that following conviction (still less where there has been a plea of guilty) some possible line
of defence has been overlooked. Only most exceptionally will this court be prepared to intervene in such a
situation. Only, in short, where it believes the defence would quite probably have succeeded and
concludes, therefore, that a clear injustice has been done. That is this case. It will not happen often.”

28. On behalf of the Respondent Mr Johnson made it clear that the Crown in this case accept that the
relevant principles are set out in those passages.

The application for leave to appeal in this case

29. In support of the present application the solicitor for the Applicant, John McLaren, has made no fewer
than four witness statements. The first was dated 17 June 2019. It was very brief and simply exhibited
relevant documents, including the decisions of the Competent Authority of November 2017 and December
2018. Mr McLaren was asked to file a fuller witness statement by the Registrar and did so.

30. The second statement by Mr McLaren was dated 18 March 2020. In it he stated that he initially
advised the Applicant as the duty solicitor at Blackpool Police Station on 26 September 2017 and
continued to advise until the hearing on 4 December 2017, when the Applicant pleaded guilty.

31. Mr McLaren went on to state that, on 1 December 2017, he had a conference with the Applicant at
Preston Prison. A handwritten note of that conference was produced as exhibit 'JM2'. The conference
was described at paras. 15-24 of his witness statement. At para. 21, Mr McLaren said:

“There was no defence of being a victim of modern slavery. His guilty plea discount was at that moment
preserved in full. He had both prosecution and defence stating how critical the Competence [sic]
Authority's decision would be. He accepted that he had been involved in the production of cannabis.”

32. At para. 25 Mr McLaren said:

“He pleaded guilty of his own volition. He was advised as to a defence under the **_Modern Slavery Act,_**
Section 45. …”

33. At para. 26, he said:

“When advising in these matters, the decision reached under the National Referral Mechanism was not
challenged by the defence. As I understood the situation, such decision lay with the Competent Authority.
I treated it as conclusive. There were no other defences. My advice to the Defendant was therefore to
preserve his guilty plea discount and plead guilty at the next opportunity, the adjourned hearing on the 4th
December 2017.”

34. Mr McLaren then exhibited as 'JM4' a copy of counsel's record of the hearing. This confirmed to the
Applicant that the “conclusive” finding of the NRM was that he had not been trafficked


-----

35. Shortly before the hearing of these applications, on 2 June 2020, Mr McLaren filed a third witness
statement, which was intended to replace in its entirety his statement of 18 March: see para. 2. Mr
McLaren again exhibited the note on the conference on 1 December 2017 as 'JM2' and counsel's note of
the hearing on 4 December as 'JM4'. At paras. 21-27, he said:

“21.  Both the Prosecution and the Defence accepted the critical importance of the Competent Authority's
decision. My view was that his Section 45 defence was unlikely to succeed. He accepted that he had been
involved in the production of cannabis.

22.  He took my advice that he could not maintain any defence of duress because he was in a position
after Mr Cung and Mr Anh had left, where he could have walked away.

23.  Our Client gave me clear instructions that he wished to plead guilty to the cultivation of cannabis. The
Defendant was cognisant of the Competent Authority's decision and accepted that he was cultivating
cannabis.

24.  He pleaded guilty of his own volition. His credit for guilty plea had been maintained. He was advised
as to his defence under Section 45 of the Modern Slavery Act. The defence of duress was fully explained
to him. He was aware that he would receive a lesser sentence of a guilty plea on the 4th December 2017
as his full credit for a guilty plea was available.

25.  The decision of the Competent Authority was a critical factor. Whilst [the Applicant] could have left all
matters including his Section 45 defence to the Jury, my advice was to preserve his guilty plea discount. I
enclose as 'JM3' a copy of my letter to the Crown Prosecution Service of the 1st December 2017. [The
Applicant] pleaded guilty at the next opportunity, the adjourned hearing on the 4th December 2017.

26.  I exhibit as 'JM4' a copy of Counsel's record of hearing confirming that the Defendant's plea of guilty
to cultivation of cannabis and not guilty to the extraction of electricity (not an issue in this appeal) was
acceptable to the prosecution and it was confirmed to [the Applicant] that the conclusive findings of the
National Referral Mechanism were that he had not been trafficked.

27.  I exhibit as 'JM5' a typed copy of my file note taken when I visited [the Applicant] at Preston Prison on
1st December 2017.”

36. Because of the difference in wording between the two witness statements of 18 March 2020 and 2
June 2020 counsel for the Respondent, Mr Johnson, filed a note on 3 June 2020 inviting clarification. In
particular Mr Johnson invited Mr McLaren to make it clear whether the Applicant was specifically advised
that it was open to him to leave the section 45 defence to the jury notwithstanding the negative conclusive
grounds decision of the Competent Authority: see para. 12 of the note.

37. That then prompted the fourth witness statement by Mr McLaren, on 4 June 2020, which is brief and
must be set out in full:

“1.  I make this statement further to the statements filed on the 18th March and 2nd June 2020.

2.  Firstly, let me apologise for the confusion caused by the two statements. I attempted in the 2nd
statement to clarify the wording, particularly in paragraphs 21 and 26 of the two statements. I used the
word conclusive in my first statement because of the importance that is attached to the Competent
Authority's negative decision.

3.  I have no independent recollection of these matters other than that at points 9 and 14 of the note of 1st
December 2017, exhibited at JM5 to the second statement of the 2nd June 2020.

4.  Given all of the matters of credibility that had already been reviewed through the National Referral
Mechanism and resulted in a negative decision, it was critical to convey to this man, the importance of it,
were he to continue his plea of not guilty to the offence of production of cannabis. I felt it was important to
advise him on the problems in his defence.

5.  My advice to him was that he should preserve his one third guilty plea discount when the matter next
appeared at Court on the next working day, Monday 4th December 2017. I discussed the matter of


-----

trafficking and enforced criminality with Client. I gave him clear and robust advice that he should plead
guilty in this matter. I prepared a basis of plea for him. He signed and dated it. I have no note to say that I
specifically reminded him that his right to trial was open despite the Competent Authority's decision.”

38. On the basis of that evidence, it is, to say the least, not clear to this Court that the Applicant fully
appreciated that he could mount his defence under section 45 before a jury notwithstanding the negative
view of the Competent Authority.

39. There is at the very least ambiguity about what was regarded as “conclusive”. The origin of the
confusion may lie in the description which the Competent Authority itself gives such decisions: they are
called “Conclusive Decisions” or “Conclusive Grounds Decisions” by way of contrast to the earlier stage of
the process, which leads to a “Reasonable Grounds Decision”. We also have to bear in mind that this
Applicant was unable to speak English and needed the benefit of an interpreter. Nuances about whether a
document which describes itself as a “Conclusive Grounds Decision” is indeed conclusive against a
defendant may be lost even on well-educated lay people in this country who are fluent in English, let alone
a recently arrived foreign national who is not familiar with the language and who (as we now know) has
been the victim of trafficking.

40. We are reinforced in our view by the fact that not only the defence team but the prosecution at that
time also regarded the view of the Competent Authority as being of critical importance. At the Pre-trial and
Preparation Hearing on 30 October 2017, the Crown had indicated in open court that, if the Conclusive
Grounds Decision was a positive one, the prosecution would be discontinued. As we have mentioned
earlier, the CPS confirmed on 8 March 2019 that, if the conviction were vacated, the prosecution would
offer no evidence.

41. In those highly unusual circumstances, we have reached the conclusion that this is one of those most
exceptional cases in which the Applicant's guilty plea cannot be allowed to stand. His conviction is unsafe
and an injustice would be done if it were allowed to stand. This was certainly not a case where, to use the
phrase used by Lord Hughes in _Asiedu, a defendant is seeking to treat the criminal justice system as a_
“tactical game”.

42. We emphasise, as this Court has done in earlier cases such as _Boal, that it is only in the most_
exceptional cases that such a course will be taken and that this should not be taken to be a licence to
others to seek to go behind a guilty plea.

43. Accordingly, we grant the application for leave to appeal against conviction and allow that appeal.

Conclusion

44. For the reasons we have given:

(1) We grant an extension of time.

(2) We grant leave to appeal against conviction.

(3) The appeal is allowed and the conviction quashed.

(4) The anonymity order made by the Court at the start of the hearing on 5 June 2020 will continue
indefinitely.

**End of Document**


-----

# R v S

_[[2020] EWCA Crim 765, [2020] 4 WLR 125, [2020] All ER (D) 107 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6066-9CT3-GXFD-83H5-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 17/06/2020**

# Catchwords & Digest

**CRIMINAL LAW - DEFENCE – VICTIM OF TRAFFICKING**

It was not clear that the defendant had fully appreciated that he could mount his defence under
**_Slavery Act 2015 before a jury notwithstanding the negative view of the Competent Authority. Accordingly, the_**
Court of Appeal, Criminal Division, admitted fresh evidence that the defendant had been a victim of trafficking and
held that his guilty plea to producing a controlled drug of class B (cannabis) could not be allowed to stand, as his
conviction was unsafe and an injustice would be done if it were allowed to stand.

# Cases referring to this case

R v AFU

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered

# Cases considered by this case

R v Boal

[[1992] QB 591, [1992] 3 All ER 177, [1992] 2 WLR 890, [1992] BCLC 872, [1992] IRLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-61MW-00000-00&context=1519360)
_[420, [1992] ICR 495, (1992) Times, 16 March](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W51J-00000-00&context=1519360)_
Applied

**End of Document**


20/01/2023

CACrimD

13/03/1992

CACrimD


-----

