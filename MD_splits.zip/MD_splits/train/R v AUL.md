# R v AUL [2022] EWCA Crim 1435

Court of Appeal, Criminal Division

Thirlwall, Spencer LJJ and Sir Nigel Davis

31 October 2022Judgment

**Daniel Bunting (instructed by Birds Solicitors) for the Applicant**

**Edward Hetherington (instructed by Crown Prosecution Service) for the Respondent**

Hearing dates : 19.07.2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 2:30pm on Monday, 31 October 2022 by circulation to the parties or
their representatives by e-mail and by release to the National Archives

.............................

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

Note: The court has ordered that the applicant is to remain anonymous.

**Lady Justice Thirlwall :**

1. The applicant, AUL, is 26. These are his renewed applications for leave to appeal out of time against
convictions in the Crown Court at Bournemouth and Bristol after refusal by the single judge. It is his case
that his convictions should be overturned notwithstanding the pleas of guilty he entered at the time
because i) he had a defence under section 45 of the Modern Slavery Act 2015 (MSA), which should have
been run in the Crown Court and would probably have succeeded and ii) the CPS should not have
proceeded against him as a victim of trafficking, alternatively that counsel should have applied to stay the
prosecution on the ground that it was an abuse of the process of the court.

2. At the end of the hearing of the renewed and other related applications we announced our decision to
refuse them all. These are our reasons.

**Background**

3. It is not in dispute that the applicant was trafficked from North Africa to Spain as a boy. Nor is it in
dispute that he travelled to the United Kingdom in the back of a lorry in 2011 at the age of 15 although the
precise circumstances are far from clear.  What is clear is that almost immediately after his arrival in the


-----

[UK he became a “looked after” child within the meaning of the Children Act 1989 and was placed by the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)
local authority with a foster family. Later he lived independently, with support from the local authority. He
attended college and gained qualifications. He was not involved in any criminal activity during those years.
In early 2016, at the age of 20, five years after his arrival in the UK, he left his accommodation, cut his ties
with social services, and went to Bournemouth. On his account this was because he had lost his appeal
against a refusal of asylum. He is gay and was afraid for his safety were he to return to Morocco.  He
says he was living for a short time on the streets, had begun to use drugs and had got into debt. He
became involved in drug dealing: storing and delivering packages for a man called Rashid Jbilou, to people
in different parts of Bournemouth. When he said he wanted to stop doing this he says he was threatened
and so continued to deal in drugs until he was arrested shortly afterwards, in the summer of 2016.

4. It is the applicant's case that his drug dealing was connected to being trafficked. In the Respondent's
notice the prosecution submitted, unsurprisingly, that there was no link between his experience of being
trafficked and the offending in 2016. It was only at the hearing of the applications that it became clear to
the Respondent that the applicant was asserting that the trafficking relied on was said to have occurred
within the UK. We consider this unarguable.

5. It is necessary to set out the background in some detail.

**The Convictions**

6. There were two sets of proceedings in 2016 and 2017 in the Crown Court at Bournemouth and Bristol
respectively. Both relate to offending in the Bournemouth area in the early part of 2016. On the 4th
August 2016 in the Crown Court at Bournemouth, the Applicant (then 20) pleaded guilty to three counts of
possession of class A drugs with intent to supply, and one count of possession of a class B drug with intent
to supply. These offences related to the 1st July 2016. On the same indictment there were 3 counts of
possessing ammunition without a firearms certificate to which he pleaded not guilty. A trial took place at
which he gave evidence and on 30th September 2016, he was acquitted of all three counts. He was
sentenced on the drugs counts (Class A offences) to 18 months' imprisonment, concurrent on all counts
and to 6 months' imprisonment concurrent on the class B count.

7. On the 2nd March 2017, in the Crown Court at Bristol, the Applicant (then 21) pleaded guilty to one
count of conspiracy to supply a class A drug. This offence related to an incident during the period between
the 10th June 2016 and the 25th June 2016, shortly before the Bournemouth matter. The applicant
collected 111.02 grams of heroin from Purbeck Road and delivered it to two people who had travelled from
Bristol to Bournemouth. On the 2nd June 2017, the Applicant was sentenced to 20 months' imprisonment.
It was accepted by the prosecution that he was acting on the instructions of Jbilou and that another man,
Wray, was above Jbilou in the chain of command.

**Extensions of time**

8. The Applicant applies for:

i) an extension of time (31 days, the Bournemouth matter) in which to renew his application for an
extension of time (1683 days) to apply for leave to appeal against conviction and

ii) leave to appeal out of time against conviction on the Bristol matter (1473 days) following refusal by the
Single Judge.

9. Before the Single Judge, there was a single ground of appeal: that the applicant had a defence under
s.45 of MSA which would probably have succeeded. After the Court of Appeal Office drew attention to the
[decision of this court in R v AAD and others [2022] EWCA Crim 106 [2022] 1 Cr App R 19, the second](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)
ground was added.

10. We grant the extension of time in which to renew his application for an extension of time for leave to
appeal on the Bournemouth matter. A single SJ form dealing with both applications was submitted to the
Court of Appeal Office. The notice of refusal in respect of both applications was also contained in a single
document. The applicant's representatives then sought to renew using a single renewal document, instead


-----

of the required two documents. The error was pointed out by the Court of Appeal Office and the position
was rectified within a short period. Both applications for renewal will be treated as within time.

**Other applications**

11. There is also before the court a form W and a witness statement from Ms Southwell, solicitor for the
applicant together with an application to adduce a very large volume of material as fresh evidence pursuant
to section 23 of the Crim App Act 1968. This included Home Office Decisions at the reasonable grounds
and conclusive grounds stage of the National Referral Mechanism that he was the victim of trafficking in
the United Kingdom. We considered all the evidence, which included psychiatric evidence, de bene esse.
We heard evidence from the applicant on the same basis.

**Facts**

12. The drugs operation was uncovered by a police operation in Bournemouth in June 2016.  The
applicant was stopped in the street (he had been seen by the police going to Christchurch Road in
preparation for the supply of drugs in the Bristol matter). He was in possession of keys for Christchurch
Road. His home was searched. Mobile phones, snap plastic bags, white powder and related drugs
equipment were found. Also found was a set of keys for Purbeck Road where drugs were found, along
with a suitcase which contained drugs and ammunition. It was not in dispute that the suitcase belonged to
the applicant. He denied that the ammunition was his. He told the jury that although the suitcase was his,
it had been given to him by Jbilou. He had been living in Purbeck Road. When he left that address, he did
not take the suitcase with him and did not know what was in it at the time of the police search. The
inference was that the ammunition belonged to Jbilou.

13. During the course of giving evidence the applicant said that he had been homeless as a child in
Morocco and was picked up by a man called Naswal who exploited him, including sexually. He then
trafficked him with other children to Spain where he was in children's homes for some years but was still,
he said, under the influence of Naswal. He eventually travelled to the UK in the back of a lorry, with other
boys, in 2011. Naswal was in a lorry travelling behind, he said, when the applicant arrived in the UK he
jumped out of the lorry and handed himself into the authorities. He was in foster care for a time. When his
immigration appeal was dismissed, he went to live on the streets in Bournemouth, which is where he met
Jbilou, he said. Jbilou offered him a place to stay (Purbeck Road) and help with money for immigration
solicitors. He later helped him to move to Christchurch Road.

14. He told the jury that in the early days when living at Purbeck Road he received £50 (and the flat) from
Jbilou who had also said he would pay for immigration solicitors. Later he received £300 per week from
him. He said he had paid £120 per week rent, £100 to the people who had brought him to the UK (this was
the first time they had been mentioned) and the rest of the money was for food and other essentials. He
said more or less the same thing to the probation officer who prepared the pre-sentence report.

15. The judge in Bournemouth in sentencing said, “I take into account you acted under the influence and
direction of a third party. Because at the time you were homeless and needed work and a roof over your
head, that puts you into a category properly regarded as vulnerable and easily exploited, but on the other
hand, you went into drug dealing with your eyes open.”

16. While the applicant was in prison and awaiting sentence on the Bristol matter, he reported to his
probation officer that he was afraid of his co-defendants who were angry with him for pleading guilty. He
wanted to be sent to a different prison from them. In the event they all pleaded guilty at the same hearing.
As in Bournemouth, the sentencing judge in Bristol had a detailed account of his history and took account
of it when sentencing. Both judges reduced the sentence on account of the fact that he had been
exploited.

17. The applicant served his sentences. An order for his deportation was served on him. At that point the
Salvation Army referred him under the National Referral Mechanism and a positive reasonable grounds
decision was made on 20 July 2018. His appeal against the decision to refuse asylum was eventually
heard on 13 September 2018. In allowing his appeal the Immigration Judge relied on the applicant's
evidence that he is homosexual homosexuality is illegal in Morocco and so he would be in danger The


-----

positive conclusive grounds decision accepted that the applicant was a victim of **_modern slavery in the_**
United Kingdom and was forced to sell drugs against his will. On behalf of the applicant Mr Bunting
submits that the conclusive grounds decision is a comprehensive analysis of the evidence and the
applicant's background and should be followed.

18. The conclusive grounds decision was admissible on the application – see the decision of this court in
**R v AAD. Whilst it would not have been admissible at first instance, as was decided by this court in R v**
**Brecani** **_[2021] EWCA Crim 731, [2021] 2 Cr App R 12,_** we accept Mr Bunting's submission that the
decision would have been provided to the CPS. He further submits that the CPS would have reviewed the
matter and stopped the prosecution, having consider the three questions in the version of CPS guidance
published in 2015, that guidance drawing on the decision in this court in R v L(C), N, N and T [2013] QB
**379. The three questions are conveniently set out in the judgment of Lord Thomas CJ in R v Joseph and**
**Others [2017] EWCA Crim 36 [2017] 1 Cr App R 33, as follows;**

i) Is there credible evidence that D falls within the definition of trafficking in the Palermo Protocol and the
Directive?

ii) Is there a nexus between the crime committed by the defendant and the trafficking?

iii) Is it in the public interest to prosecute?

We do not consider this arguable.

19. Alternatively, Mr Bunting submits that the prosecution would have been stayed as an abuse of the
process of the court. We do not consider this arguable.

20. As a further alternative Mr Bunting submits that the information upon which the conclusive grounds
decision was based would have been led before the jury. This court could not be satisfied that the jury
would have rejected the defence under section 45 of the MSA had counsel raised the issue. We do not
consider that submission arguable either, as we shall explain.

**The applicant's evidence**

21. We have set out a summary of the applicant's account of his early life including his evidence to the
jury. He gave oral evidence during the hearing before this court about events from the time he reached the
United Kingdom. We identify below some of the problems with his account.

22. We find it incredible that if the applicant had been brought to the UK by people who required payment,
those people (whoever they were) made no attempt to contact him between 2011 and 2016. In the light of
the number of inconsistencies in his account we do not accept that one or more of them (who, if they
existed at all, may or may not have included Naswal) materialised in early 2016, nor do we accept that the
applicant was told that he owed them £4000 or £8000 (both figures appear) for the trip to the UK.

23. The applicant explained the fact that he had not previously been pursued for the money he owed for
being brought to the UK by saying that the people who had brought him here were in Bournemouth and he
was in Poole. When asked by counsel for the prosecution why he had gone to Bournemouth when he ran
away from social services, he said that Bournemouth was all he knew.

24. At his trial on the ammunition charge in Bournemouth and to the Competent Authority the applicant
asserted that when working for Rashid, after the initial period when he received £50, he received £300 a
week, from which he was to pay the rent on the flat which was in his name, he also paid £100 to the people
who had brought him to the UK and the rest was for food. Before us he firmly and repeatedly denied ever
paying any money to the people who had brought him to the UK saying that he was not paid enough to be
able to do that. This was in direct contradiction to what he had previously said and what appears in detail
in the grounds of appeal which were prepared on his instructions.

25. His account of how he came to the UK has varied significantly (including whether or not he travelled
with Naswal) as did his account of who asked him for money for bringing him to the UK, his account of
what happened after he severed all ties with social services and even his account of his drug dealing. We


-----

have taken account of the medical evidence prepared for the NRM, but it does not lead us to ignore the
significant difficulties with the applicant's evidence.

26. We are prepared to accept for the purposes of considering whether this appeal is arguable that the
applicant moved from Poole and severed contact with social services because he feared he would be
deported. He was taking drugs, got into debt and for a very short period lived on the streets. He agreed to
sell drugs for Jbilou, who may have offered to help with money for immigration solicitors. There was no
compulsion involved, nor did he suggest there was. This is what might be described as a routine account
of how a person becomes involved in drug dealing. He chose to do so. His evidence about later being
threatened with violence when he said he wanted to stop was vague. He did not suggest he had ever
been the subject of violence. Dr Grant Peterkin, consultant psychiatrist who reported upon him in the
context of the NRM obtained more detail. He challenged the applicant as to why he had agreed to deal in
drugs, knowing it was illegal he said “[Jbilou] verbally abuse me, he say, “you do nothing”, he added “he do
me a favour so now I can't say no” This is not coercion. We are satisfied that the applicant was able to
abandon drug dealing had he wanted to. He was free to come and go as he pleased. He was well paid
and spent his money as he wished to. We acknowledge, as did the sentencing judge, that he was
vulnerable to exploitation but that falls far short of his being compelled to offend.

**The Conclusive Grounds decision**

27. We cannot accept that this document provides a comprehensive analysis of the evidence, as Mr
Bunting submitted, nor do we accept the conclusions expressed on behalf of the Competent Authority in
respect of his time in the UK. Those conclusions are not supported by the evidence and are reached
without reference to the provisions of the MSA. In particular, we do not accept the conclusion of the
unnamed writer of the conclusive grounds decision that the applicant was “forced to sell drugs against [his]
will”. It is not justified on the evidence.

28. We have made our observations about the applicant's credibility, in particular in respect of events in
2016. We accept that he is gay and fears for his life were he ever to return to Morocco.  We accept that
he was trafficked to Spain as a boy.

29. There is no finding in the conclusive grounds decision that he was trafficked to the United Kingdom.
That is unsurprising given that nothing in his account suggests that he was transported from Spain to the
UK for the purposes of exploitation. The absence of contact after his arrival supports that view. The report
writer considered that the applicant had “given a generally detailed, plausible and relatively consistent
account in relation to his claimed exploitation, furthermore it is noted that there are no significant credibility
concerns in regard to this account.” It is not apparent that his account was tested at all. We have
explained why we do not accept important parts of it. We note that in both the reasonable grounds and the
conclusive grounds decision it is recorded that the applicant had not seen Naswal since 2011.

30. The conclusive grounds decision is unsigned and undated. It deals with two incidents. The section
headed “First Incident” deals with the applicants' early life and his being trafficked to Spain. We say no
more about that.

31. The second incident is headed “Forced to sell drugs in Bournemouth in 2016 aged 20-21.” The
document records his arrival from Santander and the fact that he ran from the back of the lorry after it had
stopped in Poole, Dorset. He presented himself to the local fire station where social services were
contacted. He was placed in foster care until he was 16. Although the fact that he was provided with
accommodation between 16 and 19 was included in the reasonable grounds decision there is no reference
in the conclusive grounds to any event between the ages of 16 and 19. This is a significant omission.
There is no reference to the fact that he was living independently with support from social services nor to
the fact that he went to college in Poole and did well there. Nor is there any reference to the information
contained in the statement he gave to his solicitor about the fact that in 2011 a group of men offered to
lend him £4000 for solicitors' fees to help with his immigration status, or that he next heard from them in
2016. Whether that is because the applicant did not mention it or because the report writer did not note it,
we cannot tell.


-----

32. The conclusive grounds decision records that the applicant sought leave to remain in 2016 when he
was 19. This was refused and he was due to be deported, it records. “You were scared to return home, so
you absconded and slept rough in Bournemouth for a short while.” It continues, “You were approached by
a Moroccan man known as Rashid who offered to help you. He told you to sell drugs on his behalf.
Rashid rented a flat in your name where the drugs were stored and sold from and you were told to live
there. You were on call to provide drugs and were paid £300 per week to cover your food and rent. Your
rent was £120 per week and you paid £100 to the people who brought you to the UK.” These facts seem
to have been accepted without any questioning. In particular, there is no detail of who the people were
who had “brought him to the UK” and how they had done so. There is no explanation as to how these men
are said to have found him, how they had contacted him (given that he had not seen Naswal since 2011).
It seems to have been overlooked that he did not suggest any compulsion that caused him to agree to sell
drugs in the first place.

33. There then follows an observation that modern slavery occurs “in the places alleged” in reliance upon
a report from the USA Department of State Trafficking in Persons Report for 2020.

34. The report writer records the applicant's assertion that when he “tried to stop the situation “he was
threatened by Rashid with physical violence and verbal aggression”. We have already dealt with that. The
report then refers again to the USA trafficking report in respect of the UK, “As reported over the past five
years, human traffickers exploit domestic and foreign victims in the UK. Children in the care system and
unaccompanied migrant children are particularly at risk of trafficking. Youth trafficked by gangs are forced
to act as drug couriers from larger cities into rural areas across the UK”.  All of this is correct but none of it
is relevant to this applicant.

35. Nowhere in the decision is there reference to the provisions of the MSA. There are references to
“parts a, b and c” but the document does not reveal what that means. We were told that references to
parts a, b and c are to Home Office guidance on the internet. We understand that Part a is Human
Trafficking: Action. Part b is Human Trafficking: Means. Part c is Human Trafficking: Purpose. In the
reasonable grounds' decision, each section contains a number of boxes into which the report writer has
inserted crosses. We do not need to deal with the detail of them, save to say, that there are plain errors on
the face of that document.

36. In the conclusive grounds the following appears “overall, it is considered that you were recruited in the
UK by [Jbilou] and then harboured in a house in Bournemouth therefore you meet part a (presumably a
reference to Action – see above). The reference to being harboured is obviously wrong. He was offered a
place to stay, and a job and he took it.

37. The word “harbouring” appears in Section 2 of the MSA which defines the offence of Human trafficking
Section 2;

(1) A person commits an offence if the person arranges or facilitates the travel of another person (“V”) with
a view to V being exploited.

(2) It is irrelevant whether V consents to the travel (whether V is an adult or a child).

(3) A person may in particular arrange or facilitate V's travel by recruiting V, transporting or transferring V,
harbouring or receiving V, or transferring or exchanging control over V.

(4) A person arranges or facilitates V's travel with a view to V being exploited only if—

(a) the person intends to exploit V (in any part of the world) during or

after the travel, or

(b) the person knows or ought to know that another person is likely to  exploit V  (in any part of the world)
during or after the travel.

(5) “Travel” means—

(a) arriving in, or entering, any country,


-----

(b) departing from any country,

(c) travelling within any country.

38. Mr Bunting submitted (in reliance on the conclusive grounds decision) that the provision of the room by
Jbilou in Purbeck Road and, later, the flat in Christchurch Road came within the definition of “harbouring”
as set out in SS2(4). It does not. In the context in which it appears “harbouring” means keeping a victim in
a place so as to facilitate their travel. The applicant was not being kept in the flat. He chose to go there in
the circumstances we have explained. He was free to come and go as he chose. He was able to increase
the circle of drugs purchasers as his reputation spread. There was no travel.  Mr Bunting's further
submission that in arranging a second flat for the applicant to rent Jbilou was facilitating travel within the
meaning of the Act is also unarguable as is the suggestion that when giving the applicant addresses to
which he was to deliver drugs Jbilou was facilitating travel for the purposes of exploitation. This was not,
even arguably, trafficking. It was a drug dealer asking a willing drug user to carry out deliveries in
exchange for money.

39. The applicant was found to meet part b because his immigration status was precarious and so he was
vulnerable (which we do not doubt) – and he was subject to threats from Jbilou. We do not repeat our
views about that.

40. Finally, “It is considered that the applicant's case meets part c of the definition of human trafficking for
the purpose of sexual exploitation in Morocco and of forced labour within the UK as he has given an
account of not having freedom to secure his own employment.” The latter observation is wrong, as we
have shown. It continues “The forced labour and forced criminality was exacted through abuse of power
and position of vulnerability through threat of violence”. This is not sustainable on the evidence. It is the
same flawed approach to the same information as was relied on in respect of part b.

41. We are quite satisfied that the CPS would not have accepted that the conclusive grounds decision
should cause them to abandon the prosecution of the applicant. Nor is it arguable that the court would
have stayed the case as an abuse of the process, had such an application been made in the light of the
conclusive grounds' decision.

42. We turn to Section 45 MSA,

**S45Defence for slavery or trafficking victims who commit an offence**

(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which    constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant      exploitation, and

(d) a reasonable person in the same situation as the person and     having the person's relevant
characteristics would have no realistic    alternative to doing that act.

(2) A person may be compelled to do something by another person or by the  person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if—

(a) it is, or is part of, conduct which constitutes an offence under    section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a    victim of slavery or a victim of
relevant exploitation.

(5) For the purposes of this section—

“relevant characteristics” means age, sex and any physical or mental illness or  disability;

“relevant exploitation” is exploitation (within the meaning of section 3) that is  attributable to the exploited
person being, or having been, a victim of human  trafficking.


-----

43. For the reasons we have already set out we are satisfied that the applicant would have had no
prospect of establishing that he had acted as he did because he had been compelled to do so. There was
no compulsion. There was no slavery and no relevant exploitation as defined in Section 3(1) and (5).

44. Counsel and solicitors who appeared for the applicant in Bournemouth and Bristol were asked about
their approach to the applicant. Counsel and solicitors who appeared in Bournemouth knew of the
applicant's background in Morocco. They both commented on the fact that five years had elapsed since
the applicant had arrived in this country before he committed the offences. They also pointed out that the
question of duress had been specifically discussed. It was the applicant's case that he was short of money
for debts and immigration solicitors' fees. He did not suggest (even when asked directly) that he had been
coerced into drug dealing. Counsel who appeared at a PTR in Bristol took only brief instructions, which
were that the applicant intended to plead not guilty. Counsel obtained an extension of the date upon which
full credit for plea could be given. No one appeared at the PTPH at which the applicant pleaded guilty. At
the subsequent sentencing hearing the applicant said he had “been approached by a co-defendant who
offered support, accommodation and help with his immigration and in return he was to pass on a single
package of drugs.”

45. Mr Bunting did not seek to persuade us that there was the required nexus between the trafficking
before 2011 and the offending.  We agree with that approach. In the light of their instructions, we have no
difficulty in understanding why counsel did not seek to argue that the applicant had a defence under
section 45 and did not consider seeking a stay of prosecution on the grounds the applicant had been
trafficked in the UK. We have no doubt that had either matter been argued it would have failed.

46. Given our conclusions on the merits of both grounds of appeal we dismissed the renewed applications
for permission to appeal out of time and the applications to adduce further evidence. These convictions
are not arguably unsafe.

47. We deprecate the uncritical approach of the conclusive grounds' decision to the applicant's account of
his time in in the UK. The decision has led to prolonged and expensive proceedings before this court
which, on examination, had no prospect of success.

**Anonymity**

48. We maintained the applicants' anonymity during the course of the hearing. In We have considered the
applicable principles, as set out by **Hallett LJ, VP in** **R v L and N [2017] EwCA** Crim 2129. We have
considered whether our rejection of these applications should lead to a refusal of anonymity. Whilst we
reject the submission that he was trafficked within the United Kingdom we accept that he was trafficked
from Morocco to Spain as a child and was exploited there. He has been granted leave to remain in this
country for the reasons we have given. We are persuaded that we should continue the order.

**End of Document**


-----

