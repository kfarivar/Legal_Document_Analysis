# R (AB (By His Litigation Friend CD)) v Uxbridge Youth Court and Another 

 [2023] Costs LR 1731

[2023] EWHC 2951 (Admin)

High Court of Justice, King's Bench Division, Administrative Court

21 November 2023

Where the Director of Public Prosecutions (DPP) had agreed to withdraw his decision to prosecute the claimant and
to make a fresh decision on his case, and the claimant had in consequence agreed to withdraw his claim for judicial
review subject to the permission of the court, the court was required to decide whether the question of costs should
be determined under the criminal or civil costs regime, and whether an order for costs should be made against the
DPP.

The claimant argued that the question of costs should be determined under the civil costs regime, whereas the DPP
argued that costs should be determined under the criminal costs regime. Both parties agreed that should the court
decide that costs were to be determined under the civil regime, then costs should be awarded in the claimant's
favour.

In the event that the court decided costs should be determined under the criminal regime, the claimant argued that
a costs order should be awarded in his favour on the grounds that there was "an unnecessary or improper act or
[omission" by the DPP for the purposes of s 19(1) of the Prosecution of Offences Act 1985. The DPP argued that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y0H7-00000-00&context=1519360)
this section did not confer a power on the High Court to make an order for costs, and that, in any event, there had
been no impropriety in this case.

Held: Application for costs dismissed. The claim for judicial review had involved a routine prosecution and there was
nothing to take it out of the ordinary run of cases which come before the criminal court. The criminal costs regime
therefore applied. There was no power to order that the DPP pay the costs of the claim. All that had been conceded
by the DPP was that the matter should be reconsidered. This did not amount to an improper act or omission.

Cases Cited

_AG (Eritrea) v Secretary of State for the Home Department_ _[[2007] EWCA Civ 801; [2008] 2 All ER 28](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4S4J-FS60-TWP1-60GH-00000-00&context=1519360)_

_Asif v Ditta and Another_ _[2021] EWCA Crim 1091_

_Coll v Director of Public Prosecutions_ _[[2022] EWHC 2653 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66SM-NCV3-GXF6-83F1-00000-00&context=1519360)_

_Darroch and Another v Football Association Premier League Ltd_ _[2014] EWHC 4184 (Admin)_

_Darroch and Another v Football Association Premier League Ltd_ _[2016] EWCA Civ 1220_

_Director of Public Prosecutions v Denning [1991] 2 QB 532_

_Lord Howard of Lympne v Director of Public Prosecutions_ _[2018] EWHC 100 (Admin)_


-----

_M v Mayor and Burgesses of the London Borough of Croydon_ _[[2012] 4 Costs LR 689; [2012] EWCA Civ 595;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:585S-8D01-F152-J045-00000-00&context=1519360)_

[2012] 1 WLR 2607

_Murphy v Media Protection Services Ltd_ _[[2013] 1 Costs LR 16; [2012] EWHC 529 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:586V-D061-F152-J4B0-00000-00&context=1519360)_

_R (Bahbahani) v Ealing Magistrates Court [2019] EWHC (Admin) 1385_

_R (Belhaj) v Director of Public Prosecutions_ _[2018] UKSC 33; [2019] AC 593_

_R (E) v Governing Body of JFS and Others_ _[[2009] 4 Costs LR 695; [2009] UKSC 1; [2009] 1 WLR 2353](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:585S-8D21-F152-J3J3-00000-00&context=1519360)_

_R v Cornish and Maidstone Tunbridge Wells NHS Trust_ _[2016] EWHC 779 (QB)_

_R v Evans (No. 2) [2015] 1 WLR 3595_

_R v Greater Manchester Coroner ex parte Tal [1985] QB 67_

_Chris Buttler KC and Margo Munro Kerr were instructed by Duncan Lewis Solicitors for the claimant._

_Benjamin Douglas-Jones KC and Andrew Johnson were instructed by the Director of Public Prosecutions for_
the Interested Party (Director of Public Prosecutions).

**LINDEN J:**

**Introduction**

1. The parties to this claim for judicial review have agreed that the Director of Public Prosecutions ("the DPP") will
withdraw the decision to prosecute the claimant which is indirectly under challenge and will make a fresh decision
on his case. For his part, the claimant has therefore agreed to withdraw his claim subject to the permission of the
court.

2. There is, however, disagreement on the question of costs and this, therefore, was the claimant's application for
the costs of the claim. As the application was framed in writing, there were two issues for me to determine:

a. First, should the question of costs be determined under the criminal or the civil costs regime? The claimant
argues that it should be the latter but the DPP disagrees. I was told by Mr Buttler KC that there is no disagreement
that if it is the latter, costs should be awarded in the claimant's favour.

b. Second, if the claimant's application should be determined under the criminal costs regime, should an order for
costs be made against the DPP? The claimant argued that one should be, on the grounds that there was "an
unnecessary or improper act or omission by" the DPP for the purposes of _[s 19(1) Prosecution of Offences Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y0H7-00000-00&context=1519360)_
1985. The DPP argued that this section does not confer a power on the High Court to make such an order and that,
in any event, there was no impropriety in this case.

3. At the beginning of the hearing Mr Buttler said that he accepted that s 19(1) of the 1985 Act does not confer a
power on the High Court to award costs: under this section, the power is only conferred on magistrates' courts, the
Crown Court and the Court of Appeal. He said, however, that this made his case stronger on the first issue. He also
indicated that he would be submitting that, in any event, the conduct of the DPP in deciding to prosecute the
claimant was unnecessary or improper and that therefore this was the type of case in which an award of costs in
the claimant's favour would be appropriate pursuant to the civil costs regime, and consistent with what is
contemplated under the costs regime applicable to criminal causes.

4. I was also told at the beginning of the hearing that the DPP has now re-made his decision and has again
concluded that it is in the public interest to prosecute the claimant. The reasons for that decision were not available
to the claimant at the hearing and were not put before me or debated.


-----

**Context**

5. The underlying criminal proceedings relate to an alleged robbery of a 17-year-old boy on 18 March 2022. The
claimant and an accomplice are alleged to have jointly used force to steal the boy's mobile phone and to demand
his password or PIN. When the boy's mother became involved shortly after the robbery, the claimant is alleged to
have twisted her arm and pushed her to the ground whilst his accomplice punched the boy repeatedly in the head,
before both made good their escape.

6. The claimant was born on 8 September 2007, and was therefore 14 at the time of the offending. The Single
Competent Authority ("SCA") has made a conclusive grounds decision that he is a victim of trafficking on three
occasions, including on 25 November 2022 when it accepted that there was a nexus between the trafficking of the
claimant and the index offences. This, in summary, was that the claimant was selling drugs as part of a drug dealing
operation, that he owed the gang £1,700 and that he was told to steal the boy's phone. If the claimant did this his
debt would be cleared and, if he did not, he and his family would face torture. This account was accepted by the
SCA on the balance of probabilities.

7. The CPS decided that the claimant should be prosecuted for the robbery and also face two charges of battery.
That decision was reviewed by the DPP in the light of the 25 November 2022 decision of the SCA but it was
confirmed that the prosecution would proceed. At a hearing in the Youth Court on 3 March 2023, the claimant
therefore sought a stay of the criminal proceedings on the grounds that the reviewing lawyer for the prosecution had
not considered the public interest in deciding to proceed. The claimant's application was refused on the grounds
that the relevant guidance had been followed and the public interest in the prosecution had been considered.

8. On 19 April 2023, the claimant issued a claim for judicial review. Although in form the challenge was to the
decision of the Youth Court to refuse a stay, in substance the pleaded grounds for review indirectly challenged the
DPP's decision to prosecute. The DPP filed his Acknowledgment of Service and Summary Grounds for contesting
the claim on 3 May 2023 and, on 17 May 2023, Lavender J ordered a rolled up hearing.

9. Subsequently, Mr Buttler was instructed on behalf of the claimant and he advised that a request be made
pursuant to CPR Part 18 for clarification of the decision making process which led to the prosecution. This was
done on 9 June 2023 and the reply is dated 28 June 2023. In the light of this reply, on 3 August 2023 the claimant
applied to amend his Statement of Facts and Grounds to take a point which is now conceded by the DPP and which
resulted in the agreement that a fresh decision would be made and the claim for judicial review would therefore be
withdrawn.

10. That point is as follows. Whether or not a potential defendant in criminal proceedings would have a defence
under _[s 45 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_ **_Modern Slavery Act 2015, and the claimant would not have such a defence in relation to the_**
charge of robbery, prosecutors are required to consider whether it is in the public interest to prosecute a suspect
who is a victim of human trafficking. They do so in accordance with the CPS guidance on "Modern Slavery, Human
Trafficking and Smuggling" which requires the application of a four stage test. Stage 4 requires consideration of
whether it is in the public interest to prosecute. It requires the seriousness of the offence, the level of culpability of
the victim of trafficking, the harm caused to the victim of the offence and the age and maturity of the suspect to be
taken into account. In addition to this, where the suspect is an adult, the Guidance states that the prosecutors
should consider:

"• Whether there is a nexus between the trafficking/slavery or past trafficking/slavery and the alleged offending;
and, if so,

   - Whether the dominant force of compulsion from the trafficking/slavery or past trafficking/slavery acting on the
suspect is sufficient to extinguish their culpability/criminality or reduce their culpability/criminality to a point
where it is not it the public interest to prosecute them."

11. This will be referred to as "the dominant force of compulsion test".


-----

12. In the case of a suspect who is a child there is the same requirement to consider whether there is a nexus
between the trafficking and the offending, but the second question is as follows:

"• …; and, if so,

   - Whether the circumstances extinguish the child's culpability/criminality or reduce it to the point where it is not
in the public interest to prosecute them. If there was compulsion, then this will reduce the public interest, but it
is not a necessary element. As for an adult, the more serious the offence, the stronger the countervailing
factors will need to be before it is not in the public interest to prosecute."

13. So, in the case of a child, a broader range of circumstances than the dominant force of compulsion may lead to
the conclusion that they should not be prosecuted, provided that the circumstances extinguish the child's culpability
or criminality, or reduce it to a sufficient extent for it not to be in the public interest to prosecute. If there was
compulsion, this will support the argument that prosecution is not in the public interest, but compulsion is not a
prerequisite or the only circumstance which may satisfy the test.

14. The DPP now accepts that the caseworker in the claimant's case applied the second limb of the adult test rather
than the second limb of the test applicable to a child and that this was an error of approach. As noted above, he
therefore agreed to consider that public interest question again, applying the Guidance correctly.

**Legal Framework**

15. _[Section 51(1) of the Senior Courts Act 1981 provides that the costs of and incidental to all proceedings in,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y0VB-00000-00&context=1519360)_
amongst others, the High Court shall be in the discretion of the court. Section 51(5) provides that:

"Nothing in subsection (1) shall alter the practice in any criminal cause, or in bankruptcy."

16. As is well known, the CPR include various rules and practice directions which govern the exercise of the court's
discretion but it is not necessary for present purposes to set these out.

17. In Murphy v Media Protection Services Ltd _[2012] EWHC 529 (Admin); [2013] Costs LR 16 at [15] the Divisional_
Court held, as part of the ratio of the case, that:

"Clearly, save in exceptional cases, prosecutions and appeals in criminal cases should be and will be subject
to the criminal costs regime."

18. Again, it is not necessary to set out the details of "the criminal costs regime". This refers to _Part II of the_
Prosecution of Offences Act 1985 and the regulations, rules and guidance made pursuant to these provisions. As is
well known, Part II provides, in specified circumstances, for awards of costs out of central funds (ss 16–17), awards
of costs against the accused (s 18) and other awards of costs against a party, a legal representative and against a
third party (ss 19, 19A and 19B respectively), and for regulations to be made by the Lord Chancellor to carry these
provisions into effect (s 20).

19. _Murphy was followed by a Divisional Court at first instance in_ _Darroch and Another v_ _Football Association_
_Premier League Ltd_ _[2014] EWHC 4184 (Admin) where it was held that there was nothing exceptional about that_
case. The Court of Appeal in the Darroch case dismissed an appeal from the decision of the Divisional Court on the
grounds that it was an appeal in a criminal cause or matter and the Court of Appeal therefore did not have
jurisdiction. In the course of doing so, it also referred to the _Murphy principle without questioning its correctness_
[(see [2016] EWCA Civ 1220 e.g. at [35]–[38]) although it said, obiter, that there was no jurisdiction under s 51 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y0VB-00000-00&context=1519360)
Senior Courts Act 1981 to award the costs of the proceedings in the Crown Court or the magistrates' court as
opposed to the costs of the appeal to the High Court [26]. In Darroch, the Court of Appeal also held that there is no
difference in approach as between appeals by case stated and judicial review where the proceedings are in a
criminal cause or matter, and nor does the case lose its criminal character in relation to the issue of costs: [14] and

[18].


-----

20. The principle identified by the Divisional Court in Murphy was also applied by Divisional Courts in Lord Howard
_of Lympne v_ _Director of Public Prosecutions_ _[2018] EWHC 100 (Admin) and_ _R (Bahbahani) v_ _Ealing Magistrates_
_Court [2019] EWHC (Admin) 1385. And I note that in Bahbahani the Divisional Court rejected a submission that the_
_Murphy principle was inapplicable in proceedings for judicial review and/or had been undermined by the decision of_
the Court of Appeal in Darroch. At [100] the Divisional Court said:

"We are not persuaded … that the principle set out in Murphy is wrong or that we should not follow it. This is a
claim for judicial review in a criminal cause or matter, and the criminal costs scheme should apply unless there
are exceptional reasons to take a different course."

**The Claimant's Argument**

21. Mr Buttler does not dispute that his application for costs is made in the context of proceedings in a criminal
cause or matter: see, in relation to decisions whether to prosecute, _R (Belhaj) v_ _Director of Public Prosecutions_

_[2018] UKSC 33; [2019] AC 593. Nor did he directly challenge the correctness of the Murphy principle in his written_
submissions although he said, incorrectly as he conceded in his oral submissions, that what Stanley Burnton LJ
said at [15] of his judgment in Murphy was "a passing observation". Nor could Mr Buttler realistically challenge the
correctness of this principle before me given the authorities to which I have referred: see R v Greater Manchester
_Coroner ex parte Tal [1985] QB 67 at 81C/D. As I understood his argument he did maintain, however, that if Murphy_
is read as the Divisional Court holding that it did not have jurisdiction under s 51 of the 1981 Act or declining to
exercise, or surrendering, that jurisdiction, it was wrong. If, however, the court was making a choice of which of its
overlapping costs powers to exercise then he accepted that he could not challenge the correctness of the Murphy
principle.

22. Mr Buttler's argument was that, in any event, the Murphy principle should be approached with caution given, he
says, that it was an unreasoned statement and given that the Divisional Court did not explain what would amount to
an exceptional case, or what principles should be applied in identifying whether a criminal case was one to which
the civil costs regime should be applied. The Murphy principle was also stated in the context of an application which
included the costs of the proceedings in the criminal courts, so that the Divisional Court may have had in mind the
fact that it was a civil court dealing with costs incurred in the criminal courts. Here, the application is solely for the
costs of the claim for judicial review. Moreover, in Murphy there was a power under which costs might realistically
have been awarded under the criminal costs regime. In the present case it is now common ground that costs could
not be awarded in the claimant's favour under s 19(1) of the 1985 Act.

23. Mr Buttler went on to submit that exceptionality is not a test and he referred me to AG (Eritrea) v Secretary of
_State for the Home Department_ _[2007] EWCA Civ 801;_ _[[2008] 2 All ER 28 at [29]–[31] including the dictum of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4S4J-FS60-TWP1-60GH-00000-00&context=1519360)_
Sedley LJ that "No doubt … successful art 8 claims will be the exception rather than the rule; but to treat
exceptionality as the yardstick of success is to confuse effect with cause". Mr Buttler submitted that it is therefore
necessary to identify the principles to be applied in deciding, albeit as a matter of discretion, whether the civil law
approach to costs should be applied in a criminal case or whether costs should be determined under the criminal
costs regime.

24. Mr Buttler submitted that if a test of exceptionality applies it could be justified on the basis that once a
prosecution has been commenced the prosecutor is acting as a minister of justice: see R v Evans (No. 2) [2015] 1
WLR 3595 at [25], [29] and [121]. This function is inherently of a different character to decisions which are typically
amenable to judicial review. The costs rules in criminal proceedings, once proceedings have been commenced,
recognise that the prosecutor is acting in the public interest and they allow greater leeway to make decisions about
the conduct of the proceedings without undue concern as to consequences in costs. Hence, for example, costs will
only be awarded under s 19(1) of the 1985 Act if they are incurred as a result of an unnecessary or improper act or
omission.

25. In contrast, submits Mr Buttler, the prosecutor's decision as to whether there is a public interest in a prosecution
is similar in nature to the sort of decision which is typically considered in the context of a claim for judicial review.
Moreover, where a prosecutor makes an unlawful decision that it is in the public interest to prosecute then, ex


-----

hypothesi, s/he is not acting in the public interest and the rationale for reducing the prosecutor's exposure to costs
falls away. There is no greater justification for disapplying the principle that, for example, costs follow the event in
relation to an evaluative judgment on whether to prosecute than in relation to a wide range of evaluative judgments
that other public bodies make. A prosecutor should also be encouraged to make an early decision to concede a
challenge to such a decision in the same way as any other public body which concludes that it has acted unlawfully.
The rationale for the approach to awarding costs where judicial review proceedings are resolved by consent,
explained in R (M) v London Borough of Croydon [2012] 1 WLR 2607, at [61] in particular, therefore applies with
equal force. Mr Buttler also referred me to _In re Appeals by Governing Body of JFS and Others_ _[2009] UKSC 1;_

[2009] 1 WLR 2353 at [24]–[25] in support of the proposition that it is relevant to take into account the difficulties for
firms of solicitors which do legal aid work if they are not able to recover their costs in this type of case.

26. These contentions did not lead Mr Buttler to submit, as they might suggest, that therefore the Murphy principle
does not apply to judicial reviews of decisions about whether a prosecution is in the public interest. Rather, he said
that they increase the likelihood that a court will accept that a successful challenge to a decision to prosecute is an
exceptional case. They explain why the application of the civil costs regime is statistically or numerically exceptional
– challenges to prosecutorial decisions rarely succeed – and why they are what he called "conceptually
exceptional". They are conceptually exceptional because they relate to a decision which takes place outside the
process for determining criminal liability. In this connection, he relies on the summary of the reasoning of the
Divisional Court in _Belhaj (supra) which was given by Lord Sumption at [12] of his judgment when the matter_
reached the Supreme Court.

27. Here, submits Mr Buttler, the caseworker was acting as an ordinary administrative decision maker rather than
an officer of the court. There is therefore no principled reason why the civil law approach to costs should not apply.

28. As noted above, the provision relied on by Mr Buttler to support his argument that the DPP would have been
ordered to pay the costs if the application for a stay had succeeded in the Youth Court and ought, therefore, to be
[made in the proceedings for judicial review is s 19(1) Prosecution of Offences Act 1985. This provides as follows:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y0H7-00000-00&context=1519360)

"(1) The Lord Chancellor may by regulations make provision empowering magistrates' courts, the Crown Court
and the Court of Appeal, in any case _where the court is satisfied that one party to criminal proceedings has_
_incurred costs as a result of an unnecessary or improper act or omission by, or on behalf of, another party to_
_the proceedings, to make an order as to the payment of those costs." (emphasis added)_

29. He submits that the application of the adult test for whether the culpability or criminality of the suspect has been
extinguished, rather than the test applicable to children, was an unnecessary or improper act or omission. He
makes a comparison with the facts of Director of Public Prosecutions v Denning [1991] 2 QB 532where the test was
held to have been satisfied in a case where the charge before the justices was using or permitting a goods vehicle
to be used where the second axle weight of the vehicle exceeded the authorised limit contrary to s 40(5) of the
_[Road Traffic Act 1972. The witness statement in support of the charge referred to the front axle and the gross](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y0PW-00000-00&context=1519360)_
weight of the vehicle, but not the second axle. In holding that the justices had been entitled to make an order for
costs against the prosecution Nolan LJ said at 541C/D:

"In these circumstances, it seems to me impossible to maintain that there were no grounds upon which the
justices could reasonably conclude that there had been an improper omission on the part of the prosecution. I
would add in this connection that the word 'improper' in this context does not necessarily connote some grave
impropriety. Used, as it is, in conjunction with the word 'unnecessary', it is in my judgment intended to cover an
act or omission which would not have occurred if the party concerned had conducted his case properly."

30. Mr Buttler also submitted that the error on the present case was the sort of "clear and stark error" which was
contemplated in _Evans (No. 2) (supra) at [146]. In that case Hickinbottom J (as he then was) carried out a_
comprehensive analysis of the authorities including Denning. At [144] and [145] he emphasised that the test is one
of impropriety – failing to conform to prevailing standards of behaviour [119] – and not merely unreasonableness,
and that the courts should be careful not to impose too high a burden or standard on the prosecuting authority. The
s 19 jurisdiction is summary in nature so the conduct of the prosecution must be starkly improper, such that no


-----

great investigation into the facts or the decision making process is required. Bad faith will almost always suffice but
otherwise each case will turn on its own facts and context. At [146] Hickinbottom J said:

"146. … I consider that cases in which it will be appropriate to make (let alone grant) a s 19 application against
a public prosecutor will be very rare, and restricted to those exceptional cases where the prosecution has made
a clear and stark error as a result of which a defendant has incurred costs for which it is appropriate to
compensate him. For example, where it is alleged that the decision to prosecute or a similar prosecutorial
decision is the improper act on which a s 19 application is founded, it is difficult to conceive of circumstances in
which it could succeed unless the decision was shown to be unlawful in a public law sense, i.e. leaving aside
decisions unlawful because made in pursuance of an unlawful policy of the prosecutor (or made other than in
accordance with the prosecutor's own lawful policy), if the decision was one which no reasonable prosecutor
could have made. If it is a decision that a reasonable prosecutor could have made, then generally a s 19 costs
order will not be appropriate."

31. Mr Buttler appeared to submit that Hickinbottom J was therefore stating that any public law error would satisfy
the test or, at least, any clear public law error. But Mr Buttler also said that he did not need to identify the precise
boundaries in terms of the sorts of public law errors which would suffice because Hickinbottom J had specifically
included decisions made otherwise than in accordance with the prosecutor's own lawful policy.

32. Hence, submitted Mr Buttler, this is the sort of case in which costs would be awarded in the criminal courts. I
[should therefore make such an award in the exercise of the court's powers under s 51(1) of the Senior Courts Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y0VB-00000-00&context=1519360)
1981.

**Discussion and Conclusion**

33. Beguiling though Mr Buttler's submissions were, and skilfully made, I reject them. With respect to him, much of
his argument was in truth an attempt to challenge the correctness and authority of the Murphy principle. This flew in
the face of the decision of the Divisional Court in Bahbahani where arguments similar to some of Mr Buttler's were
considered and rejected and where, in any event, the application of the Murphy principle was affirmed. In my view,
the principle is well established.

34. As to the suggestion that in Murphy the Divisional Court may have been refusing to exercise jurisdiction etc, in
my view the court in _Murphy was saying no more than this: Parliament has enacted a framework for the_
determination of costs in civil cases and it has enacted a framework for the determination of costs in criminal cases.
Each identifies the orders which may be made and the statutory conditions which require to be satisfied if they are
to be made. Parliament intended that costs would only be awarded in a criminal cause or matter where such an
award is in accordance with the statutory provisions applicable to such causes or matters. The proceedings do not
lose their criminal character when they are the subject of an appeal or a claim for judicial review in the High Court,
and nor do they for the purposes of the determination of costs of such proceedings. So it would only be in
[exceptional circumstances that a court would use its powers under s 51(1) of the Senior Courts Act 1981 to make](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y0VB-00000-00&context=1519360)
an award of costs in a criminal case which would not be available under the provisions applicable to criminal cases.

35. The application of the Murphy principle flows from this. The acknowledgement by the Divisional Court that there
may be exceptional cases, where the application of the civil costs regime is appropriate, is not a statement of how
often, statistically, the civil costs regime will apply in this type of case. It is a reference to the sorts of reasons or
features of the case which will justify the application of that regime, as [100] of Bahbahani confirms, and to the need
for those reasons to justify a departure from the approach which Parliament intended in criminal cases. The
reasons for applying the civil costs regime must take the case out of the run of criminal cases and they must be
compelling.

36. Murphy was truly exceptional and it is a good illustration of the sort of case which may fall into this category. It
concerned a private prosecution of a publican under _[s 297(1) of the Copyright, Designs and Patents Act 1988 –](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YG0-TWPY-Y0VR-00000-00&context=1519360)_
dishonestly receiving a programme with intent to avoid payment – for screening Premier League Football matches
in her pub using her decoder card and equipment. The case was effectively brought as a test case which sought to


-----

protect a very substantial profit stream of the Football Association Premier League Limited. The question whether
the publican had committed an offence required a reference to the Court of Justice of the European Court on
complex, generally applicable, points of EC law. Ultimately, and at the risk of oversimplifying, it was held that
because she had paid for her decoder card she was not guilty of an offence under s 297 as a matter of law, and her
convictions were quashed. Because of the nature of the issues, and because it was a test case, the hearings were
conducted in a manner which was indistinguishable from a hearing in the Chancery Division or in the Civil Division
of the Court of Appeal. Stanley Burnton LJ described the appeal as being "unusual" and "very far from being a
typical appeal against conviction for a summary offence" (emphasis added).

37. In these circumstances the Divisional Court in _Murphy was prepared to apply the civil law approach to the_
determination of costs. But, even then, it is worth noting that in _Darroch the Divisional Court did not accept that_
prosecutions under s 297 based on essentially the same fact pattern should be regarded as exceptional in the
relevant sense. Murphy, it said, was truly a test case. Although points of law were raised in Darroch the matter was
conducted like many prosecutions. The fact that points of EU law were raised did not of itself make the case
exceptional and there was no reference to the European Court. _Darroch illustrates the point that the category of_
case in which there may be a departure from the criminal costs regime in a criminal cause or matter is very narrow
indeed.

38. If one then asks whether there is anything about the present case which took it out of the run of criminal causes
or matters, or which meant that it was very far from being a typical claim for judicial review of a decision of the
Youth Court, the answer is a resounding "No". The decision directly under challenge in this case was a decision to
refuse an application to stay the proceedings in the Youth Court. That was a routine decision in a routine criminal
case with which the criminal courts are well accustomed to dealing. Indeed, the case is so far from being
exceptional that it is not necessary to accept Mr Buttler's invitation to explore where the boundary may lie or what
principles might apply on different facts.

39. Even if the claim is analysed as a challenge to the decision of the DPP to prosecute, the important point about
_Belhaj for present purposes is that the Supreme Court, overruling the Divisional Court, held that a claim for judicial_
review of a decision not to prosecute did amount to "proceedings in a criminal cause or matter". Once it is accepted
that the present claim was also in a criminal cause or matter the _Murphy principle applies. To hold that,_
nevertheless, the fact that the decision under review is a decision that it was in the public interest to prosecute
should be regarded as an exceptional circumstance would seem to me to be contrary to principle and indeed,
contrary to any sensible application of the requirement that the case be exceptional. Nor, in my view, does the fact
that the decision was legally flawed, of itself, render the case an exceptional [one] in the relevant sense. The fact
that the claim is conceded may provide a basis for an award of costs if the civil costs regime is applicable, but it
does not answer the prior question whether that regime is applicable.

40. I do not agree that decisions about whether a prosecution is in the public interest are materially different in
nature to other decisions made by the prosecutor in the course of criminal proceedings. The decision to which
objection has been taken in the present case is the decision to prosecute and that decision was based on various
considerations, including the prospects of a conviction. It is artificial to slice it up into component parts for this
purpose.

41. Moreover, I do not accept that the rationale for giving the prosecutor greater leeway in relation to costs is
inapplicable or less powerful when the prosecutor is considering the public interest in a prosecution. It remains the
case that the prosecutor is operating in the field of criminal law enforcement and as a minister of justice. The limited
scope for challenges to decisions to prosecute or not to prosecute is well recognised (see e.g. [29] of the judgment
in Evans), and it is consistent with the rationale for this position that, when making this type of decision, prosecutors
should not feel inhibited by the risk of liability in costs provided they are not acting improperly or unnecessarily.
Moreover, subject to the same proviso, in carrying out this function they are acting in the public interest even if their
decision is subsequently accepted to be legally flawed.

42. As to Mr Buttler's argument that s 19(1) of the 1985 Act would have been satisfied in the Youth Court and that
this, in itself, provides a basis for concluding that the case is an exceptional one, again, this is flawed. The prior


-----

question is whether there are exceptional circumstances such that the civil costs regime should be applied to a
criminal cause or matter. If the conclusion is that there are not, the criminal regime applies and costs should be
awarded if it is in accordance with that regime to do so. If, as in the present case, the provisions of the criminal
costs regime on which an applicant would have wished to rely does not provide for an award of costs against a
party in the High Court it would be contrary to the intention of Parliament to treat this as an exceptional
[circumstance which justified awarding costs under s 51(1) Senior Courts Act 1981 given the terms of s 51(5) and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y0VB-00000-00&context=1519360)
given that s 19(1) reflects the intention of Parliament that costs should not be awarded against a party to a criminal
cause in the High Court.

43. As to whether, aside from this point, costs would have been awarded had the DPP's error surfaced in the Youth
Court, _Denning was a case on its facts. The justices had ordered that the prosecution pay the costs and the_
question for the Divisional Court was whether they could reasonably have concluded that the statutory test was
satisfied. The Divisional Court went no further than to hold that they were entitled to come to this conclusion. The
justices had not done so simply on the basis that the wrong axle was specified in the charge. A key defect in the
prosecution was the unreliability of the weighbridge which had been used to ascertain the weight of the vehicle and
there had been a series of failings by the prosecution to review the file and to take action in response to the defects
in the case. In the meantime, the defence had incurred considerable expense in commissioning expert evidence to
show that the weighbridge evidence was unreliable. Denning was also a case in which it was, in effect, admitted
that the defendants should never have been prosecuted and there was an application to discontinue the
proceedings.

44. As to the interpretation of [146] of the judgment in _Evans, there is a danger in treating this paragraph as if it_
replaces the terms of s 19(1) rather than focusing on the question whether the conduct of the DPP in this case was
"improper". What Hickinbottom J said was intended to impress on the reader the fact that the threshold is a very
high one. In my view he was not saying that any public law error, provided it is clear, will mean that the maker of the
error has acted improperly. Nor was he saying that a failure to apply a policy correctly or at all is necessarily
improper. The thrust of [146] is that generally, where there is no evidence of bad faith, the decision will need to be
one which no reasonable prosecutor could have made if the court is to hold that it was improper. This tends to be
confirmed by [148(vi)] where he said this in his summary of the principles which he had derived from the case law:

"Each case will be fact-dependent; but cases in which a s 19 application against a public prosecutor will be
appropriate will be very rare, and generally restricted to those exceptional cases where the prosecution has
acted in bad faith or made a clear and stark error as a result of which a defendant has incurred costs for which
it is appropriate to compensate him. The court will be slow to find that such an error has occurred. Generally, a
decision to prosecute or similar prosecutorial decision will only be an improper act by the prosecution for these
purposes if, in all the circumstances, no reasonable prosecutor could have come to that decision."

45. This analysis is also consistent with the summary of the principles provided by Coulson J (as he then was) in R
v Cornish and Maidstone Tunbridge Wells NHS Trust _[2016] EWHC 779 (QB) at [16] which was approved by the_
Court of Appeal in _Asif v_ _Ditta and Another_ _[2021] EWCA Crim 1091 and followed in_ _Coll v_ _Director of Public_
_Prosecutions_ _[[2022] EWHC 2653 (Admin) at [8] to which I was referred.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66SM-NCV3-GXF6-83F1-00000-00&context=1519360)_

46. This being so, I do not accept that costs would have been awarded in the Youth Court in the present case had
the error in the application of the Guidance emerged there. It seems to me that the relevant decision in this case
was the decision to prosecute the claimant. That is the step which led to costs being incurred by him and which he
would have to show was improper or unnecessary. However, all that has been established at this stage is that in
assessing the various factors which required to be assessed at stage 4 of the process of deciding whether to
prosecute, the case worker mistakenly took an overly narrow approach to the circumstances which might lead to
the conclusion that it was not in the public interest to do so. She considered a number of circumstances of the case
but there may have been others which went to the issue of the public interest. There is no suggestion of bad faith
and it has not been established that the decision that it was in the public interest to prosecute the claimant was one
which no reasonable prosecutor could have taken. Indeed, all that has been conceded is that the matter should be
reconsidered. This is not a case, like Denning, where it is accepted that the case should never have been brought.


-----

47. As Mr Douglas-Jones KC pointed out, without contradiction from Mr Buttler, the information sought in the judicial
review proceedings pursuant to CPR Part 18 could have been sought in the Youth Court pursuant to _[s 8 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y13G-00000-00&context=1519360)_
Criminal Procedure and Investigations Act 1996. Had this step been taken, there would have been no need for a
claim for judicial review, either because the prosecution would have made its concession at that stage or because
the application for a stay would have succeeded. It would be surprising, then, if the fact that the information was
provided in the context of the claim for judicial review was a basis for awarding costs which would not have been
awarded in the Youth Court.

**Conclusion**

48. So for all of these reasons I accept Mr Douglas-Jones' submission that there are no exceptional features of this
case. The claim for judicial review concerned a routine prosecution brought by the relevant public authority. There
was nothing to take it out of the ordinary run of cases which come before the criminal courts. The criminal costs
regime therefore applies to the claimant's application and it is common ground that under that regime I do not have
a power to order that the DPP pay the costs of the claim.

49. I therefore permit the claimant to withdraw his claim but dismiss his application for costs.

**End of Document**


-----

