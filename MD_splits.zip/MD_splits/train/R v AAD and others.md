# R v AAD and others [2022] EWCA Crim 106

Court of Appeal, Criminal Division

Fulford LJ, Julian Knowles J and Sir Nigel Davis

3 February 2022Judgment

**Francis FitzGibbon QC (instructed by Philippa Southwell, Birds Solicitors) for the Appellant AAD**

**Felicity Gerry QC (instructed by Philippa Southwell, Birds Solicitors) for the Appellant AAH**

**Stephen Knight (instructed by Wells Burcombe Solicitors) for the Appellant AAI**

**Parosha Chandran (instructed by Duncan Lewis Solicitors) for the UN Special Rapporteur on**
**Trafficking in Persons, especially Women and Children, as Intervener**

**Ben Douglas-Jones QC and Andrew Johnson (instructed by The Crown Prosecution Service) for the**
**Respondent**

Hearing dates: 17th - 18th November 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**LORD JUSTICE FULFORD VP:**

This is the judgment of the court to which all members have contributed.

**Introduction**

1. The Registrar has directed that these three cases are listed together in a “special court” with a view to
providing further guidance in cases involving victims of trafficking (“VOT/VOTs”). We grant leave to appeal
to AAI and AAH. As set out below, leave to appeal has already been granted to AAD (see [54] below).

**Anonymity**

2. In all three cases the appellants apply for an anonymity order under section 11 Contempt of Court Act
1981. The Registrar directed that they are to be listed anonymously, at least until the merits of these
discrete applications have been decided by the full court.

3. The principal authority relating to adults and anonymity in the present context in the Court of Appeal
(Criminal Division) is R v L; R v N _[[2017] EWCA Crim 2129. The court in that case heard evidence from](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
Philippa Southwell, a solicitor advocate specialising in modern slavery cases (who instructs Felicity Gerry
Q.C in the present case), as to the concern on the part of those who cooperate with the authorities that
reprisals, including to the individual's family, would occur if their identities and the assistance they had
provided were revealed. Bearing that evidence in mind, along with the need for consistency with other
courts such as the approach applied in the Court of Appeal (Civil Division) and the Upper Tribunal's
Guidance Note 2013 No 1: Anonymity Orders, it was accepted that it would, in principle, be desirable for
the Court of Appeal (Criminal Division) to follow the practice of providing anonymity protection to an


-----

appellant in cases raising asylum and international protection issues. The court also summarised the
United Kingdom's international obligations in this context. These derive from various instruments, including
the Council of Europe Convention on Action Against Trafficking in Human Beings 2005, ratified in
December 2008 (“the CE Convention”), and the EU Directive 2011/36 on Preventing and Combating
Trafficking in Human Beings (“the EU Directive”). The aim, in summary, is to safeguard the human rights of
victims, to avoid further victimisation and to encourage them to act as witnesses in criminal proceedings.

4. The court nonetheless expressed concern that other important issues will be at stake, such as the
principle of open justice in the context of criminal trials and appeals, and the court observed that anonymity
orders should only be granted when they are strictly necessary. The court, moreover, had not had the
benefit of representations from the press, which we note equally applies in the present appeals. The Vice
President (Hallett LJ) highlighted that questions may arise on criminal appeals in relation to the risk on
return; equally, the background facts relied upon may be different from those in any associated asylum
case. The court envisaged circumstances where there may be less restrictive means (short of an
anonymity order) of addressing the risk of harm. Therefore, rather than adopting a blanket approach or
attempting to provide general guidance, the court resolved the question of anonymity on the basis of the
particular facts of each of the individual appeals (see [14] and [15]). This is an approach we have adopted
and which, with respect, we commend. We have resolved the anonymity question individually in our
consideration of each appellant's case (see [170], [171], [177] and [184] below).

**AAI**

Background (AAI)

5. On 1 September 2008, in the Crown Court at Minshull Street, Manchester, before Judge Lewis and a
jury, the appellant (then aged 25, now aged 39) was convicted of one count of failing to take action as
required by the Secretary of State, contrary to section 35 of the Asylum and Immigration (Treatment of
Claimants etc.) Act 2004 (“section 35”).

6. On the same date he was sentenced to 18 months' imprisonment, and the judge ordered that, pursuant
to section 240 of the _[Criminal Justice Act 2003, 207 days spent on remand should count towards his](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)_
sentence.

7. Before this court, he applies for an extension of time of more than 12 years in which to apply for leave to
appeal against conviction and sentence following referral to the full court by the single judge. His
application for leave pursuant to section 23 of the Criminal Appeal Act 1968 (“section 23”) to introduce
fresh evidence concerning his suggested status as a VOT was likewise referred to the full court.

8. The parties agree that this is a “change of law” case, therefore requiring exceptional leave out of time
and thus it is for the appellant to demonstrate the suggested substantial injustice that would result if leave
to appeal is refused (see _R v GS [2018] EWCA Crim 1824 and_ _R v O [2019] EWCA Crim 1389). AAI_
contends that this is demonstrated by the adverse consequences to his mental health and his immigration
status should the court refuse his application. The appellant relies on the increased awareness, along with
the improvements regarding the protection, of VOTs in the United Kingdom since 2008 and the fact that for
a significant period he was, for psychiatric reasons, unable to disclose the details of his trafficking. The
respondent does not seek to argue that the appellant fails to meet the substantial injustice test if the court
decides that the appellant's substantive submissions justify an extension of time.

9. As to the facts, the appellant sets out that he was born in Sierra Leone in 1982. He was a victim of the
civil war in that country, and he suffered considerably at the hands of the Revolutionary United Front
(“RUF”) who abducted him and murdered his parents. He alleges he was raped by multiple men and was
seriously assaulted in other ways, from which he bears observable scars. He eventually escaped, and in
Freetown he met and went to work for an individual we refer to as “T" who promised to help him with
accommodation and education (which never materialised). The appellant claims he was in fear of T, who
organised his journey to the United Kingdom, in return for an understanding that the appellant would send
him money from Europe.


-----

10. On 20 May 2003, the appellant arrived in the United Kingdom from Sierra Leone and claimed asylum.
On 17 July 2003, his asylum claim was refused and his asylum appeal was dismissed on 17 December
2003. On 11 April 2005 the Sierra Leonean High Commission indicated that they had accepted the
appellant as a Sierra Leonean national and agreed to issue him with an Emergency Travel Document
(“ETD”).

11. The appellant thereafter ceased reporting as required. On 11 January 2007 he was encountered by
immigration officers in asylum accommodation provided to a friend of his, and he was arrested. There were
two unsuccessful attempts by the Secretary of State for the Home Department (“SSHD”) to remove the
appellant to Sierra Leone. On 15 February 2007, he was flown to Sierra Leone. The view was expressed
by the local authorities that he had not been interviewed for the ETD, and it was pointed out that it did not
contain a thumbprint or signature. The appellant, furthermore, claimed to be Sudanese (albeit he disputes
the accuracy of this latter contention). He was returned to the United Kingdom. On 19 February 2007 he
was again flown to Sierra Leone, but the authorities refused to admit him on the basis that they did not
accept he was a Sierra Leonean national.

12. On 4 December 2007, he was taken to the Sierra Leonean High Commission to attend an interview to
obtain an emergency ETD to facilitate his removal from the UK. The interview was terminated because, in
the view of the accompanying immigration official, he had refused to answer questions by stammering and
shaking. He again indicated he was not from Sierra Leone (either by shaking his head or verbally). On 28
December 2007, the appellant was served with a notice under section 35 Asylum and Immigration
(Treatment of Claimants etc.) Act 2004 by the SSHD, requiring him to attend an interview and answer
accurately and fully questions put to him at the Sierra Leonean High Commission, with a view to obtaining
an ETD. He failed to comply with the notice, stating that he was not willing to do so because he had
already attended the High Commission for an interview. He was subsequently charged with the offence
under section 35(3).

13. His case at trial was that he refused to be interviewed by the High Commission because he had
already been interviewed; he had been returned to Sierra Leone twice and been refused entry; and he
feared for his safety in Sierra Leone. He ran the defence of reasonable excuse. Due to the passage of
time, resulting in the loss of relevant transcripts, the full details of how the defence case was put at trial is
no longer available. It would appear that the appellant contemplated arguing that although his stated
reasons for non-cooperation in themselves did not amount to a reasonable excuse, the fear of the
consequences of deportation may have caused psychiatric illness with the result that he was unable to
comply with the notice. However, no psychiatric evidence was put before the jury.

14. As set out above, on 1 September 2008, the appellant was convicted and sentenced. On 27 October
2008 he was served with a notice of liability for automatic deportation. He did not submit any grounds for
exemption from automatic deportation within the 20 working days specified period. A Deportation Order
against the appellant was signed on 1 June 2009 and served on 19 June 2009. On 18 April 2013, the
appellant submitted further representations which constituted a fresh claim for asylum and an application to
revoke the deportation order. On 5 August 2014 the appellant appealed against the refusal to reconsider
the deportation decision. During December 2016, he was referred to the National Referral Mechanism
(“NRM”). On 22 February 2017, there was a Single Competent Authority (“SCA”) positive reasonable
grounds decision that the appellant is a victim of human trafficking or **_modern slavery, followed on 11_**
January 2019 with a SCA positive conclusive grounds decision.

15. On 2 November 2019, the appellant received negative advice on appeal from his previous
representatives. On 17 September 2020 the First-tier Tribunal allowed the appellant's immigration appeal
on asylum and human rights grounds. In August 2020 his current solicitors were instructed and the
Grounds of Appeal were lodged on 29 December 2020.

16. On 1 March 2021 the appellant was granted leave to remain in the United Kingdom until 2026.

The Appeal (AAI)


-----

17. The first ground of appeal is that it was an abuse of the process to prosecute the appellant because he
was a victim of trafficking at the time of the offence, there was a nexus between his exploitation as a victim
of trafficking and the commission of the alleged offence and the circumstances in which he came to commit
it were such that it was not in the public interest for him to be prosecuted.

18. The law in this area has been set out with completeness and clarity in a number of decisions of other
constitutions of this court, and it will not assist to rehearse it yet again in detail in this judgment. Suffice it to
[observe that the approach to be adopted in cases that preceded the Modern Slavery Act 2015,such as the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
present, is to be found in cases such as _R v Joseph and others (Anti-Slavery International intervening)_

_[2017] EWCA Crim 36; [2017] 1 WLR 3135; [2017] 1 Cr App R 33. The effect is to require of prosecutors a_
three-stage exercise of judgment: (1) is there a reason to believe that the person has been trafficked? If so,
then (2) if there is clear evidence of a credible common law defence (e.g. duress or necessity) the case will
be discontinued in the ordinary way on evidential grounds, but, importantly, (3) even where there is not, but
the offence may have been committed as a result of compulsion arising from the trafficking, prosecutors
should consider whether the public interest lies in proceeding to prosecute or not.

19. The second ground of appeal is that fresh evidence demonstrates that he had a reasonable excuse for
failing to comply with the direction under section 35. Psychiatric evidence now available shows that the
appellant was being subjected to extreme psychological suffering by the attempts to remove him to Sierra
Leone and he was, as a result, unable to comply with the section 35 notice. These factors, it is argued,
provided a reasonable excuse (see R v Tabnak [2007] EWCA Crim 380; [2007] 1 WLR 1317 at [20]). It is
suggested, furthermore, that the judge's direction to the jury was deficient in this context. The evidence
before this court on the latter contention is sketchy. Trial counsel for the appellant has provided the
following note:

“13. “Prosecution burden of proof. Standard of proof: sure. Judge's directions: 1-4 not in dispute.
_Prosecution to prove that defendant had no reasonable excuse. What may or not constitute reasonable_
_excuse? Defendant: did not want to go back to Sierra Leone. If what he meant that if returned to Sierra_
_Leone, his life would be in danger - not amount to reasonable excuse._

_14. “Law is not permitted to resurrect grounds of asylum in criminal case. Immigration proceedings have_
_been run to their conclusion._

_15. “There is no definition of 'reasonable excuse”: it must be decided on its own facts. If he feared for his_
_life that on any subsequent journey would be beaten up by escorting officers, that could be capable of_
_being reasonable excuse. If it was or may have been reasonable excuse - not guilty. But if sure that not not_
_reasonable excuse. Although at one point he did say, “I've been before, not going again” - whether that_
_reasonable excuse.”_

20. The appellant seeks leave to adduce fresh evidence under section 23 of the Criminal Appeal Act 1968.
First, there is an array of psychiatric evidence from Dr Alex Frank, Dr Tahira George, Dr Craig McNulty,
Professor Jacqueline Knorr and Professor Cornelius Katona. This is to the effect that that appellant has
reported nightmares, an inability to sleep and stress. He has been diagnosed as suffering from posttraumatic stress disorder (“PTSD”) of substantial severity, a depressive illness of at least moderate
severity, Phobic Avoidance Behaviour and possibly psychosis. He additionally suffers from significant
intellectual impairment. Second, there is diverse documentary evidence which is said to demonstrate his
status as a VOT from Brian Dikoff (legal organiser, Migrants Organise Limited) dated 7 December 2020,
Christine Oliver (manager of the Ex-Detainee Project) dated 17 December 2014, Imogen Townley
(immigration solicitor) dated 30 November 2020, Gavin Rose (current solicitor, consultant with Wells
Burcombe Solicitors) dated 4 February 2021 and Sally Montier (author of a Trafficking Assessment Report)
dated 12 October 2021.

21. In slightly greater detail, Professor Katona in his report dated 5 November 2019 set out both his own
conclusions and he summarised the conclusions reached by other medical professionals as to the mental
and physical circumstances of the appellant. This included reference to a report on 20 December 2010 by
Dr Stera to the effect that the appellant suffered nightmares, was unable to sleep and was stressed. There
is a record by Dr A Jalal dated 18 April 2012 that the appellant had been referred to the Hillingdon


-----

Assessment and Brief Treatment Team because of Post-Traumatic Stress Disorder, depression and
possible psychosis. The appellant reported that he had been raped in Sierra Leone during the civil war. On
25 June 2012 Dr Stera confirmed the diagnosis of PTSD.

22. Dr Alec Frank on 15 March 2013 set out some of the appellant's history as provided by the latter,
which included witnessing the murder of his parents by rebels, who thereafter abducted him. He had
witnessed numerous others being murdered, mutilated and raped. He was drugged, whipped with lengths
of flex and raped repeatedly by “up to eight men”. The appellant reported nightmares from which he awoke
sweating, screaming and terrified. He is convinced he is being constantly watched and has felt unable to
disclose the atrocities he witnessed. He has flashbacks of his mother being strangled and then shot. It was
noted that the appellant bore over 20 scars that reflect a history of torture and ill-treatment. It was
suggested that these corroborated his account of having been brutalised and tortured. Dr Frank concluded
that the appellant suffers from PTSD of very substantial severity and a depressive illness of at least
moderate severity.

23. Dr Tahira George, a consultant psychiatrist, added in a report dated 27 January 2017 that the
appellant had developed Phobic Avoidance Behaviour, which involves the appellant avoiding memories or
conversations concerning the trauma he suffered. Dr George was of the view that the appellant was at
significant risk of suicide if returned to Sierra Leone. Dr George completed further reports on 8 September
and 17 December 2017.

24. On 6 June 2018, Dr McNulty a clinical psychologist reported that the appellant performs at a level that
would be predicted of a seven-year-old. His full IQ is 58-66, which indicates a significant impairment of
intellectual ability. He concluded that the appellant was unlikely to be able effectively to give evidence or to
“respond reliably”.

25. There is a lengthy report dated 13 November 2019 from Professor Jacqueline Knorr on the suggested
risks facing the appellant if returned to Sierra Leone, on the basis that he had been trafficked as a child
soldier and the experiences he has described, along with the poor socio-economic conditions in Sierra
Leone.

26. There is an equally lengthy report from Sally Montier dated 12 October 2021 who is an “Independent
Consultant Human Trafficking and **_Modern Slavery” in which she arrives at the conclusion that the_**
appellant is particularly vulnerable to recruitment for exploitation by traffickers. She opines that the account
from the appellant of his recruitment and exploitation meets the “trafficking definition”. She expresses the
view that the appellant was transported to the United Kingdom through the means of abuse of a position of
vulnerability and coercion.

27. The respondent suggests that there may be utility in the court receiving the fresh evidence relied upon
by the appellant de bene esse. The respondent accepted in submissions that the appellant is a VOT. It is
submitted, however, that there was no significant nexus between his trafficking and the offending.
Accordingly, it is argued he was not compelled to commit the offence due to his status as a VOT.

28. It is highlighted by the respondent that the positive conclusive grounds decision was reached by the
SCA with considerable hesitation. There are said to be reasons to doubt the appellant's credibility, as
expressed by Mr Bisgrove (SEO SCW & Regional Modern Slavery Lead for Criminal casework (Leeds)),
the author of the positive grounds decision. The respondent therefore invites the court to consider whether
there are good reasons to depart from that decision. It is argued that that the necessary element of
compulsion has not been made out.

29. It is convenient to highlight at this stage the wholesale inconsistencies, as analysed by Mr Bisgrove,
that exist in the appellant's account as regards the man T. In his statement of May 2003, the appellant
described T as simply someone who organised his trip out of Sierra Leone, having provided him, via a
second individual, with a ticket and passport. He spoke of having been helped by people who took pity on
him. A similar explanation was given in his interview on 27 June 2003. Dr George was told of an agent who
approached the appellant and helped him get into a lorry to escape to the United Kingdom. There was no
mention of T or pressure of the kind now relied on by the appellant. In his statement made in March 2015


-----

he suggested that T accompanied him to Gambia in a lorry, from where he flew alone to the United
Kingdom. He said that T assisted him out of compassion and did not request any money in return for his
kindness. Although the precise circumstances were described differently, in the appellant's statement of 20
August 2015 he maintained the philanthropic description of T.

30. The appellant's representatives provided a letter on 19 December 2016 in which it is claimed that the
appellant washed T's feet and worked for him at the beach, assisting tourists. T disciplined other workers
who did not obey his instructions. In due course, T organised the appellant's trip to the United Kingdom,
suggesting that the appellant would send money back to him. Against this background, we note Mr
Bisgrove concluded:

“103. It is considered that your most recent claim that (T) sent you to Europe in order for you to send
money back to him lacks credibility given than no reception arrangements were made for you in the UK. It
is not accepted that this man would pay for you to travel to Europe and insist only that you telephone him in
Sierra Leone upon arrival.

104. Your legal representatives have stated that you have _“been under_ (T's) control since [you were] a
_child”. If we are to disregard your original account in which you met (T) in 2003 when you were 20 years of_
age, your most recent account would be that you worked for him from the age of 17 until you were 20. You
were a young adult and you claim that 'T' too was a young adult. It is not accepted that your age, and
“psychological control” explains why 'T' would have taken such a financial risk. This aspect of your claim
also lacks credibility.

105. In the absence of any other explanation for these discrepancies I have concluded that you have been
unable “to remain consistent throughout [your] written and oral accounts of past and current events”. Your
inability to do so in this instance and the others cited in this section of this letter have led me, as a
Competent Authority, to disbelieve your claim.”

31. However, he also concluded:

“Despite the large number of inconsistencies in (the appellant's) accounts, in light of the findings of Dr
McNulty when assessed against the guidance relating to 'Mitigating Circumstances', I am compelled to
accept that the individual is more likely than not to have been a victim of **_modern slavery i.e. to the_**
required standard of proof of “on the balance of probabilities”.”

32. In his judgment of 17 December 2020, First-Tier Tribunal Judge Neville (Immigration and Asylum
Chamber) described the factual circumstances that were accepted by the Home Office as follows:

“11. (g) T had simply relied on psychological control to obtain the (appellant's cooperation) in sending
money from the UK. It was only on arrival in the UK and upon being accommodated by the Home Office
that the appellant had questioned whether T did indeed know where he was. While the appellant was
unsure of how much power T had, or whether he would be able to find him as threatened, the appellant
decided in the end not to contact him. He nonetheless remained afraid of T and that he might one day be
located and face consequences.”

[…]

“36. I should add that the appellant has previously claimed a fear of persecution at the hands of the rebels
and their leadership, from others in reprisal for his perceived alignment with them, and from T. This is no
longer pursued by the appellant and I need not deal with whether this fear is well-founded. Nonetheless I
do find that this fear is subjectively experienced by the appellant and can be seen in the psychiatric
evidence to contribute to his vulnerability on return.”

33. It is suggested that the court is significantly hampered by the lack of a transcript of the summing up.
The respondent's contention is that there is no basis for criticism of the way the case was left to the jury,
given the absence of psychiatric evidence before the jury and the lack of anything to indicate that the
appellant was doing other than “exercising a power of choice” (R v Tabnak). In all the circumstances, it is
submitted the direction on reasonable excuse cannot be impeached. The fresh evidence does not arguably
change that position given the appellant is not within the exceptional case hypothesised by the court in R v


-----

_Tabnak, in that there is nothing to indicate that the appellant was unable to comply with the section 35_
notice.

**AAH**

Background (AAH)

34. On 15 March 2016 in the Crown Court at Snaresbrook before Judge Kennedy, the appellant (then
aged 32, now aged 38) pleaded guilty to a single count of possession of an identity document with
improper intention, to make a gain for herself or another (count 1). Count 2 (a charge of fraud) was ordered
to lie on the file in the usual terms.

35. On 1 November 2016, before the same court, the appellant was sentenced to 12 months'
imprisonment.

36. The appellant seeks an extension of time (viz. 1414 days) in which to apply for leave to appeal against
conviction, both applications having been referred to the Full Court by the single judge. The principal
reasons for the delay in lodging the application are what are said to be the necessary time taken by the
appellant's fresh representatives to receive and collate a full set of papers from the original trial
representatives and her immigration solicitors, and the process of taking instructions and providing the
appellant with advice. Furthermore, the new positive reasonable grounds decision was provided by the
SCA on 16 August 2017, coupled with a grant of 5 years' leave to remain.

37. In support of the application for leave to appeal, it is submitted that had the appellant's status been
known as someone who had been trafficked, she would not have been convicted for four principal reasons:
she would not have been prosecuted; she would successfully have applied for the proceedings to be
stayed; she would have been permitted to vacate her plea; and the jury would not have returned a guilty
verdict given she was compelled to commit the crime through exploitation and/or the crime was caused by
traffickers.

38. The appellant additionally seeks leave to introduce fresh evidence regarding her status as a VOT. This
material comprises the positive reasonable grounds determination dated 5 June 2016, along with the
accompanying minutes; the negative conclusive grounds determination dated 25 August 2016; the
determination of the First-tier Tribunal dated 11 July 2017; the positive conclusive grounds determination
dated 20 July 2017, again with the accompanying minutes; the transcript of the submissions in mitigation
and the judge's remarks from the sentencing hearing; letters from the Home Office dated 9 and 16 August
2017; the appellant's asylum decision; a chronology prepared by Duncan Lewis solicitors for the
immigration proceedings; statements of support from various key workers; evidence from the appellant;
evidence given in the immigration proceedings by Ejiro Ziregbe (a friend); evidence from Julie Barton (a
trafficking expert); and an expert report from Professor Katona (a psychiatrist).

39. It is submitted that this material amply demonstrates that the appellant committed the crime as a result
of being trafficked and her exploitation.

40. As to the facts, the appellant contends she is a Nigerian national from the Yoruba tribe. She escaped
from a proposed marriage that her father had arranged, and for this reason she left Nigeria in August 2007
with the help of an agent. The arrangement was that she would work to pay for her ticket, but she escaped
the house to where she had been taken. The agent contacted her in 2009, however, and threatened her
indicating he wanted his money returned. The appellant was introduced to another man who groomed her
for sexual exploitation. He found her a job in a care home and he took her wages.

41. On 28 May 2015, the appellant attended an interview for a job as a care worker with Care
Management Group Ltd. She provided the company with a French passport and a French ID card which
were not her own. She was subsequently offered the job.

42. Thereafter, the appellant worked for the company at a care home for approximately seven months.
However, following an enhanced Disclosure and Barring Service check, it became apparent that the
documents she had provided were false. The appellant was arrested at her workplace on 15 February


-----

2016. On arrest, she provided police with her address, where the police found her genuine Nigerian
passport confirming her true identity.

43. In interview, she declined to answer any questions and exercised her right of silence.

44. She pleaded guilty at the pre-trial and preparation hearing on 15 March 2016.

45. At the sentencing hearing on 1 November 2016, the judge set out the procedural background,
explaining that following her guilty plea, the sentence had been adjourned for the appellant to be referred
through the NRM system as a potential VOT. However, the SCA had provided a negative conclusive
grounds decision on 25 August 2016, stating that the appellant's account was not credible. The appellant's
representatives requested a further adjournment of the sentencing hearing to challenge that decision which
the judge refused, stating that a very detailed decision had been obtained from the SCA and whilst that
decision could be challenged, criminal cases had to be concluded within a reasonable time.

46. We note that First-Tier Tribunal Judge Real in a decision dated 20 July 2017 accepted the appellant's
account as to how she came to the United Kingdom and the events that occurred in this country following
her arrival. It was acknowledged that she fears returning to Nigeria, given she is a woman facing forced
marriage, gender-based violence and re-trafficking.

47. Following that decision, on 16 August 2017, the SCA accepted there were conclusive grounds to
believe that the appellant was a potential victim of human trafficking.

The Appeal (AAH)

48. The single ground of appeal is that the appellant's conviction is unsafe because she was a victim of
human trafficking when she committed the offence set out above and that she should have been protected,
not prosecuted and punished. It is submitted that the appellant's conviction is unsafe because her case
engages the United Kingdom's commitment to the “non - punishment principle” which removes liability for
[criminal offending by trafficked persons, either via the Modern Slavery Act 2015 or by way of decisions of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
the Court of Appeal. It is suggested this is not limited to the concept of compulsion as set out in the
**_[Modern Slavery Act 2015 but instead is based on principles of protection which can be applied in English](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
law via causation or a policy that requires appropriate protection for trafficked individuals.

49. It is argued that the authorities insufficiently enquired into her trafficked status, and, furthermore, that it
should have been established whether the individual preparing the conclusive grounds assessment was an
expert. Alternatively, an independent expert should have been instructed. This would have meant she
would not have been prosecuted; or she would successfully have applied for the proceedings to be stayed;
or she would not have pleaded guilty; or she would have been permitted to vacate her plea; or, if there had
been a trial, the jury would not have returned a guilty verdict given she was compelled to commit the crime
through exploitation and/or the crime was caused by traffickers (see [37] above). Put otherwise, the fresh
evidence, which should have been available in the Crown Court, demonstrates that if her trafficked status
been properly considered at the time she would not have been convicted either on her own guilty plea or
by a conviction of a jury.

50. Given it is contended that a suitably qualified expert should have prepared a conclusive grounds
assessment prior to the defendant entering a plea, it is additionally argued that until assessments of this
quality are available from individuals who are able to give evidence in the Magistrates' and Crown Court,
appropriate expert evidence should be commissioned by the Crown Prosecution Service in order to fulfil
the United Kingdom's obligation to protect victims of trafficking.

51. As with AAI, the respondent submits that there may be utility in the court receiving the fresh evidence
relied upon by the appellant _de bene esse. It is not accepted that the appellant is a VOT. It is argued,_
furthermore, that the appellant was not compelled to commit the offence in a way that means that her
culpability was significantly diminished or effectively extinguished. Accordingly, the respondent argues her
conviction is safe. It is contended that the approach of the trial representatives is not open to material
criticism. The appellant had given no instructions at the time of her plea to indicate that she was a VOT.


-----

When she did give those instructions, the proceedings were adjourned and she was referred through the
NRM.

52. It is accepted that if the court finds she was a VOT and that her culpability was significantly or
effectively diminished, it would not have been in the public interest to prosecute.

**AAD**

Background (AAD)

53. On 15 February 2018 in the Crown Court at Stoke-On-Trent before Mr Recorder Butterfield Q.C. the
appellant (then aged 37, now aged 40) pleaded guilty to producing a controlled drug of class B contrary to
section 4(2)(a) of the Misuse of Drugs Act 1971 and was sentenced to 8 months' imprisonment. His coaccused, Quang Van Hoang, pleaded guilty to a like charge and was sentenced to a 12-month conditional
discharge.

54. He appeals against conviction by leave of the Full Court (Singh LJ, William Davis and Ellenbogen JJ)
on 25 March 2021, and the necessary extension of time (712 days) was granted.

55. The appellant additionally seeks leave pursuant to section 23 of the _[Criminal Appeal Act 1968 to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1P8-00000-00&context=1519360)_
introduce fresh evidence regarding his status as a VOT, including a referral letter dated 4 June 2018 from
his solicitors and a report by Dr Mary Anderson dated 14 January 2019. Dr Anderson, who identified scars
that are said to be consistent with his account of violent abuse as a child and during the period whilst he
was trafficked, has observed that the appellant:

“[…] is a vulnerable individual. He has experienced a spectrum of traumatic events: ill- treatment in
childhood; physical injury by police in Vietnam; ill-treatment by his employers in Laos; ill-treatment with
threats; and physical assault by his captors in UK; prolonged Immigration Detention. He feels desperate as
a result of his inability to convince the UK authorities that they had mistaken his identity. He feels helpless
as to his position and as a result remains more liable to victimisation and the possibility of exploitation in
the future.”

56. Additionally, the appellant seeks to introduce his witness statement dated 16 January 2019 and the
conclusive grounds decision issued by the Secretary of State on 1 February 2019. The accompanying
minute sets out a summary of the circumstances of his departure from Vietnam through to his arrest.

57. In the witness statement of 16 January 2019, the appellant provided his summary of the relevant
events. He left Vietnam in 2002, having been persecuted by the authorities, and he lived in Laos until 2016,
during which time he obtained employment. He returned to Vietnam for short visits.

58. He was offered the opportunity to leave Laos with the prospect of a better life and employment. He
was introduced to an agent, and he paid $16,000 with a view to being relocated to Germany. He raised
$2,000 from the sale of certain property and the balance was obtained by his family from a “loan shark”.
He flew from Laos to Hong Kong, and then on to Russia. He was required to pay an additional $9000 to be
transported, in a lorry, to the United Kingdom, arriving in November 2016. He was beaten up on arrival and
told he owed an additional $700 which his family were required to raise. He was then taken to London,
given a mobile telephone and abandoned by his traffickers.

59. He made the acquaintance of a man called Binh who found him casual employment for some seven
months at several restaurants. When this work ended, another male called A Tu found employment for the
appellant on a construction site in Liverpool. When the appellant complained, A Tu took him to an address
in Stoke on Trent where the appellant believed he would be offered cleaning work. Instead, having moved
some electrical equipment, he was given instructions to tend cannabis plants. He did not want to undertake
this work. He suggests he was told he would be killed if he left or told the police about what was
happening. He was not locked in; indeed, he had a key to the front door. On one occasion he left the
premises, but he returned having failed to find other people from Vietnam. He suggests he was afraid to go
to the police then or at another time because he did not have any papers. He claims that when he returned
to the house, he was attacked by the “owners” of the house, who knocked out some of his teeth. Checks
i di ll d hi


-----

60. On 3 October 2017, the appellant together with his co-defendant were seen approaching this property,
which was in Middleport, by police officers who had been watching the house because the electricity was
being abstracted. They entered the premises. Inside, at varying degrees of maturity, were 353 cannabis
plants. The plants were in the three rooms on the first floor and within the loft space. The electricity used
for this operation had been abstracted at the meter. The appellant was found to be in possession of three
mobile telephones, one of which was an iPhone.

61. He was arrested and interviewed on 4 October 2017. He was represented by the duty solicitor and
accompanied by a Vietnamese interpreter. He accepted his involvement in tending the plants and
explained the circumstances in which he had been brought to the United Kingdom. His personal telephone
was interrogated and revealed conversations in which he had taken part that contained references to him
going out, including dancing in Leeds (e.g. “when you come out then we can go dancing for fun”).

62. He told the officers that one of the mobile telephones was his, and the owners of the cannabis gave
him the other two in order to receive their instructions. He suggested he had been told what to do. In
addition, an official from the Home Office spoke with the appellant on 4 October 2017.

63. During mitigation, his counsel set out, inter alia, the following:

“[…] Mr Nguyen was trafficked to this country. He came with the expectation and promise of working in the
construction industry. He had worked in the construction industry both at home and in Russia in the past,
and it was something of a surprise to him when he was put into the position of having to act as the
gardener in these premises in Middleport, but he accepts of course that by doing so, he renders himself
guilty of the offence and hence his guilty plea here today.

He did not initially want to avail himself of the help that was offered via the human slavery and trafficking
aspect of the case, he did review that decision but has taken on board what has been said both by the
prosecution so far as the phone calls are concerned and perhaps I take on board what [is said about]
greater freedom than one would have expected in cases of this type. And also the fact that there does not
appear to be somebody there present at all times or in the background restricting liberty and with
immediate threats of violence should he not have been prepared to do what he was asked to do.”

64. Accordingly, the appellant decided not to rely on the statutory defence set out in section 45 of the
**_Modern Slavery Act 2015 (“section 45”). As just described, it was acknowledged on his behalf that the_**
recovered telephone messages indicated that he had some freedom, his liberty was not restricted and he
was not threatened with immediate violence. Section 45 provides:

“Defence for slavery or trafficking victims who commit an offence

(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if—

(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if—

(a) the person is under the age of 18 when the person does the act which constitutes the offence


-----

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.

(5) For the purposes of this section—

_“relevant characteristics” means age, sex and any physical or mental illness or disability;_

_“relevant exploitation”_ is exploitation (within the meaning of section 3) that is attributable to the exploited
person being, or having been, a victim of human trafficking.

(6) In this section references to an act include an omission.

(7) Subsections (1) and (4) do not apply to an offence listed in Schedule 4.

(8) The Secretary of State may by regulations amend Schedule 4.”

65. In passing sentence the judge observed that the offending had a strong causal link with trafficking and
he took the view that this affected the appellant's culpability. The judge noted that there was an absence of
a formal determination that the appellant was a victim of trafficking and he had not been oppressed in the
way that was often the case.

66. The appellant claimed asylum on the 8 March 2018 whilst in immigration detention. On 4 June 2018 he
requested a reference to the NRM as a victim of trafficking. On 2 July 2018 a positive reasonable grounds
decision was issued, which was confirmed in a conclusive grounds decision on 1 February 2019. The
accompanying minutes set out the reasons for finding that the appellant was a victim of human trafficking,
specifically forced labour, forced criminality and domestic servitude, and that he had been subjected to
physical and psychological coercion.

67. He applied for judicial review following the refusal to grant him discretionary leave as a victim of
trafficking, pending determination of his asylum claim.

68. In response to this appeal, trial counsel asserts that the appellant did not seek a determination of his
status, even though the opportunity to do so clearly existed. In his view there was no prospect of avoiding a
prosecution and there was no defence.

The Appeal (AAD)

69. The overarching contention is that the appellant's conviction for the offence of cultivating cannabis is
unsafe because he was acting under compulsion as a VOT and he had a viable defence under section 45
(see [64] above). It is submitted the appellant's status as a VOT following the Secretary of State's
conclusive decision on 1 February 2019 means that the appellant should not and, if the circumstances had
then been known, would not have been prosecuted, given there is evidence of a “reasonable nexus of
_compulsion” between the offence and the circumstances of exploitation, as defined in_ _R v L(C) & Ors_

[2013] EWCA 991; [2013] 2 Cr App R 23. At [33] the court observed:

“As we have already explained, the distinct question for decision, once it is found that the defendant is a
victim of trafficking, is the extent to which the offences with which he is charged, or of which he has been
found guilty, are integral to or consequent on the exploitation of which he was the victim. We cannot be
prescriptive. In some cases the facts will indeed show that he was under levels of compulsion which mean
that, in reality, culpability was extinguished. If so, when such cases are prosecuted, an abuse of process
submission is likely to succeed.”

70. It is argued that the advice the appellant received and his decision to plead guilty were misconceived
and he should have had the opportunity to challenge the negative decision, or, alternatively, to run a
defence under section 45. The evidence showed that he had been trafficked for the purpose of exploitation
and re-trafficked in the United Kingdom. In those circumstances the authorities should have been alerted
as to the possibility that he had been trafficked, in order for a determination to be made. The previous
representatives are criticised for failing to demonstrate a proper understanding of the “nuanced reality of


-----

_being a victim of trafficking”. It is submitted that the offence was committed as a direct result of trafficking_
for the purposes of exploitation.

71. It is suggested the delay in establishing his true status as a VOT was the responsibility of the
authorities and various errors that were made during this process are highlighted. It is argued that had his
status been correctly identified at the right time, it is unlikely that a prosecution would have been
considered evidentially viable, or as being in the public interest. It is submitted the failure to identify the
appellant as a VOT constitutes a breach of Article 4 of the European Convention on Human Rights.

72. In light of the decision of the European Court of Human Rights on the 16 February 2021 in VCL & AN v
_United Kingdom [application nos 77587/12 and 74603/12], confirmed as final on 5 July 2021, it is submitted_
that in the absence of a “trafficking assessment made by a qualified person” the prosecution was flawed ab
_initio and the conviction is unsafe because the decision-making process that led to it was inadequate. At_

[199] in VCL & AN the court observed:

“[…] In the context of Article 4 of the Convention, it is the State which is under a positive obligation both to
protect victims of trafficking and to investigate situations of potential trafficking and that positive obligation
is triggered by the existence of circumstances giving rise to a credible suspicion that an individual has been
trafficked and not by a complaint made by or on behalf of the potential victim […]. The State cannot,
therefore, rely on any failings by a legal representative or indeed by the failure of a defendant […] to tell the
police or his legal representative that he was a victim of trafficking.”

73. The argument is advanced that had there been a conclusive NRM decision it could have founded a
defence based on section 45.

74. In light of the decision in _M v DPP_ [2020] EWHC 3422 (Admin), it is contended the NRM decision
could have been admitted in evidence as an “agreed fact” or under section 10 of the Criminal Justice Act
1967, in order to provide a foundation for the section 45 defence. Similarly, it is submitted it is receivable
pursuant to section 23 of the Criminal Appeal Act 1968.

75. The appellant argues his right to a fair trial under Article 6 of the European Convention on Human
Rights was breached because the guilty plea was entered based on defective advice and when no enquiry
had been made as to his status as a VOT.

76. The respondent suggests that the finding by the Secretary of State does not mean that the defence
would necessarily have succeeded. There must be a nexus between the appellant's status as a VOT and
the commission of the offence. Whilst the appellant may not have had advance knowledge of the
operation, he chose to work for the man instructing him. He was not constrained physically and the
telephone traffic revealed he had contact with his family and there were discussions about socialising.

77. Therefore, although the prosecution had been aware that he was trafficked into the United Kingdom,
the present offence was not compelled by his trafficking such that a defence of duress or a defence under
section 45 was made out. In the circumstances, it is submitted by the Crown that there is an absence of a
sufficient connection between the trafficking and the commission of the offence; in particular, the
appellant's freedom of movement means that a section 45 defence had no more than a remote prospect of
success. It is contended by the respondent that the conclusive grounds decision of 1 February 2019 does
not amount to new evidence which renders the conviction unsafe. It is emphasised that a deliberate
decision was taken by the appellant at the relevant time not to pursue a section 45 defence. It is argued
that the current Crown Prosecution Service (“CPS”) guidance would still support the decision to prosecute.

**Potential Areas for Guidance by the Court**

78. Against the background of the various grounds of appeal advanced by the appellants, as summarised
above, the Registrar has invited the Court to consider giving guidance on nine issues that have general
and immediate relevance in the conduct of VOT cases. Although we have approached this invitation with
caution, the issues identified by the Registrar not only raise important questions as to how aspects of
cases in this context are to be handled at first instance and on appeal, but – save for the second and fourth
questions – they are directly relevant to the determination of the three appeals. In the circumstances we


-----

have considered it appropriate to address these generic issues, including the second and fourth questions
which are said to involve areas of immediate importance as regards the conduct of a significant number of
pending trials. We are grateful to the Registrar for her formulation of the nine questions. We observe that
although our comments as regards the second and fourth questions are obiter dicta, they were fully argued
before us.

I. Is an SCA conclusive grounds decision admissible on appeal?

79. This question has already been conclusively and clearly answered in earlier decisions. There are
numerous examples of cases in which conclusive grounds decisions and other relevant material have been
[received by this court, see: R v L(C) and others at [34]; R v T(O) [2013] EWCA Crim 2405 at [13]; R v Y](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B45-M9J1-F0JY-C0J1-00000-00&context=1519360)

_[[2015] EWCA Crim 123 at [8] and [12]; R v L,; R v N [2017] EWCA Crim 2129 at [31], [44] and [51]; R v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FBC-JDN1-F0JY-C2KG-00000-00&context=1519360)_
_Joseph [2017] 1 Cr App R 17 at [157] and [160]; R v EK_ _[[2018] EWCA Crim 2961 at [27] and [45]; R v GS](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-V2S2-8T41-D4NJ-00000-00&context=1519360)_

_[2018] EWCA Crim 1824; [2019] 1 Cr App R at [67];_ _R v GB_ [2020] EWCA Crim 2 at [35]; _R v S [2020]_
_EWCA Crim 765 at [11];_ _R v AAJ_ _[[2021] EWCA Crim 1278 at [27] and [28]. We note that the approach](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_
taken in these cases coincides with a recommendation in a 2013 report by the Organization for Security
and Co-operation in Europe (“OSCE”) (the Office of the Special Representative and Co-ordinator for
Combating Trafficking in Human Beings), entitled “Policy and legislative recommendations towards the
effective implementation of the non-punishment provision with regard to victims of trafficking”:

“26. The right to non-punishment must also be protected in bringing an appeal. Fresh evidence which
supports a finding that the victim was trafficked and that the crime was committed in the course of their
being trafficked or as a consequence of their having been trafficked should be admissible on appeal,
subject to national rules of evidence and procedure.”

80. We emphasise the decisions in three additional cases in this regard. In R v S(G) _[2018] EWCA Crim_
_1824; [2019] 1 Cr App R 7, Gross LJ explained, in our respectful view correctly, that a decision of the First-_
Tier Tribunal, a minute from the SCA and a letter from the Home Office could all be admitted applying the
test for fresh evidence in section 23 (see [81] below). This court in Brecani _[2021] EWCA Crim 731; [2021]_
1 WLR 5851; [2021] 2 Cr App R 12 expressly referred to this decision in R v S(G) and did not doubt the
correctness of the approach that had been taken (see [41]). In the subsequent case of _R v AAJ_ _[[2021]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_
_[EWCA Crim 1278, the appellant had pleaded guilty on 2 November 2015 to two counts of possession with](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_
intent to supply class A drugs (crack cocaine and heroin). On 18 January 2016 he pleaded guilty to two
further counts of possession with intent to supply class A drugs (crack cocaine and heroin). When
convicted and sentenced it had not been recognised that at the material time he may have been a victim of
trafficking. A conclusive grounds decision to this effect was reached on 25 February 2019. The SCA
accepted that he had been forced into criminality by being given Class A drugs to carry by individuals who
had recruited him. The appellant appealed to this court and applied to adduce fresh evidence, namely
certain social services records, the positive reasonable grounds decision, the positive conclusive grounds
decisions and a clinical psychological report. The court determined this application as follows:

“28. We grant leave to adduce this fresh evidence. It is necessary and expedient in the interests of justice
to do so. To admit the positive reasonable grounds and positive conclusive grounds decisions is not
inconsistent with the recent judgment of this court in R v Brecani [2021] EWCA Crim 731. Such material
can be used as a tool to assess the safety of a person's convictions: see [40] in particular. It is perfectly
proper to admit it in evidence as relevant material on this basis. It is not a question of admitting the
evidence for the purpose of trial.”

81. In our judgment, although the context and the issues will determine whether a conclusive grounds
decision should be received in evidence in the CACD, there is no doubt that such decisions can potentially
be adduced on an application for leave or an appeal. Section 23 provides the court with considerable
flexibility in this regard:

“(1) For the purposes of an appeal, or an application for leave to appeal, under this Part of this Act the
Court of Appeal may, if they think it necessary or expedient in the interests of justice—


-----

(a) order the production of any document, exhibit or other thing connected with the proceedings, the
production of which appears to them necessary for the determination of the case;

(b) order any witness to attend for examination and be examined before the Court, (whether or not he was
called in the proceedings from which the appeal lies); and

(c) receive any evidence which was not adduced in the proceedings from which the appeal lies.

(1A) The power conferred by subsection (1)(a) may be exercised so as to require the production of any
document, exhibit or other thing mentioned in that subsection to—

(a) the Court;

(b) the appellant;

(c) the respondent.

(2) The Court of Appeal shall, in considering whether to receive any evidence, have regard in particular
to—

(a) whether the evidence appears to the Court to be capable of belief;

(b) whether it appears to the Court that the evidence may afford any ground for allowing the appeal;

(c) whether the evidence would have been admissible in the proceedings from which the appeal lies on an
issue which is the subject of the appeal; and

(d) whether there is a reasonable explanation for the failure to adduce the evidence in those proceedings.

(3) Subsection (1)(c) above applies to any evidence of a witness (including the appellant) who is competent
but not compellable. …

[…]”

82. Although the CACD will “have regard to” whether the evidence would have been admissible in the
Crown Court, this is only one of the factors to be taken into consideration. We observe, moreover, that if
the question of the individual's status as a victim of trafficking was a live issue in the Crown Court, this
contention will, in all likelihood, have been properly explored in evidence during the trial. In contrast, on an
appeal to the CACD if this defence was not investigated properly or at all in the court below, the CACD will
need to determine how best to resolve the merits of any application or appeal in this regard. The court may
require oral evidence to be given, including from the applicant/appellant in order to substantiate, for
instance, the history relied on, and it may order the production of any relevant documents, including reports
and the conclusive grounds decision, if in existence. This will be a highly fact-specific judgment and it
would be unhelpful to attempt to lay down any guidance as to the circumstances in which the court will
resolve an application or appeal solely on the basis of written reports, decisions by bodies such as the SCA
and other relevant materials and, conversely, when it will (additionally) require oral evidence.

83. The court in R v AAJ observed in this context at [39]:

“vii) The decision of the competent authority as to whether or not a person has been trafficked for the
purpose of exploitation is not binding on the court, but, unless there is evidence to contradict it or
significant evidence that has not been considered, it is likely that the courts will respect the decision;”

84. This approach mirrored similar observations in R v L(C) at [28] and R v Joseph at [20(vii)]. We do not
disagree with this statement of general approach, but we emphasise that there may be cases when the
court will consider that the account given by the applicant/appellant requires testing by way of appropriate
questioning. This is necessary to deal, for instance, with reports or decisions that are based on
“controversial accounts” (see Brecani at [45] and R v Turner [1975] QB 834, 840 E to F).

85. It is to be noted in this context that the submissions on behalf of AAD include the contention that the
court in _Brecani gave a global ruling as to the admissibility of conclusive grounds decisions and the_
accompanying minutes, rendering them in all circumstances inadmissible at trial. Whilst that may well be


-----

the practical effect of the decision, absent particular circumstances, it is critical nonetheless to have in mind
the salient conclusions reached in Brecani in this context, namely that:

i) Non-expert opinion evidence is inadmissible in a criminal trial, save for limited purposes (see [44]);

ii) Expert opinion evidence is admissible in criminal proceedings if a) it is relevant to a matter in issue in
the proceedings; b) the witness is competent to give that opinion; and c) it is needed to provide the court
with information outside the court's own knowledge and experience (see [44]) (but see also Clare [1995] 2
[Cr App R 333 and RT [2020] EWCA Crim 1343; [2021] 1 Cr App R 14 at [29);](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:613K-0TH3-CGXG-0071-00000-00&context=1519360)

iii) It is necessary to follow the provisions of Part 19 of the Criminal Procedure Rules and the Practice
Direction which govern the admissibility of expert evidence (see [46]);

iv) Case workers in the SCA, who are junior civil servants performing an administrative function, are not
experts in human trafficking or modern slavery and cannot give opinion evidence in a trial on the question
of whether an individual was trafficked or exploited (see [54]); (We would add that they may have gained
experience, but they are not experts in the sense understood in domestic criminal procedure.)

v) Expert evidence may be relevant to the questions that arise under the 2015 Act, “which are outside the
_knowledge of the jury, particularly to provide context of a cultural nature”, but_

“The evidence would have to be truly expert and not a vehicle to enable the expert to stray into the territory
of the jury by expressing his or her personal opinion about whether an account is credible or
inconsistencies (are) immaterial. […] the conclusion on whether the prosecution has disproved the section
45 defence will call for an assessment of all the relevant evidence which the jury is well-placed to make. In
the right case that evidence might include expert evidence of societal and contextual factors outside the
ordinary experience of the jury” (see [58]).

vi) Insofar as the conclusive grounds decision is dependent on the various accounts of the defendant,
including his or her explanations of inconsistencies, this is hearsay evidence for which a hearsay
application would be necessary and – certainly in _Brecani – such an application would not have been_
successful (see [61]).

vii) The decision of the jury as to whether the prosecution had negatived the section 45 defence requires
the jurors to be sure that the account given by the appellant in his or her evidence in chief (and thus the
core account on which the case worker proceeded) was not true. That was not an issue on which the
evidence of the case worker could give them any assistance. The jury were well placed (certainly in
_Brecani, given the nature of the evidence in that case) to form their own conclusions without help from the_
case worker (see [62]).

86. We would add that it does not matter that the members of the jury have not shared the suggested
experiences described by the defendant in a human trafficking or **_modern slavery case. Indeed, this_**
applies in all criminal trials regardless of the nature of the charge. Few jurors will have been subjected, for
instance, to duress leading to their participation in an armed robbery or will have found themselves caught
up or involved in a city centre riot. This lack of first-hand experience of the circumstances of offences such
as these does not require a witness (a case worker or otherwise) to express a view as to whether the
account of the defendant is consistent with how someone would behave if placed under duress to commit
armed robbery or if caught up in a riot. The jurors will be well placed to form their own conclusions on these
questions. It follows that we reject Mr Knight's submission that a trafficking expert can express an opinion
in evidence before the jury as to the plausibility and consistency of the defendant's account. Similarly, we
disagree with the suggestion that a trafficking expert during a trial can comment on the vulnerability of the
defendant. It is equally impermissible for an expert in a trafficking trial to express a view as to whether a
given set of facts meets the legal definition of trafficking, acting thereby as an expert on the law of England
and Wales. None of these situations come within the well-known exceptions, such as with diminished
responsibility, when an expert is permitted to give evidence on the “ultimate issue” (see _DPP v A & B_
_Chewing Gum [1968] 1 QB 159 at 164). As observed by the editors of Phipson on Evidence (Nineteenth_
Edition) at [33-12], this is because the expert's opinion is valueless, even unintelligible, if he or she is
prohibited from expressing their view merely because the trier of fact will be called upon to decide the


-----

same question. In a similar vein, the secondary transfer of cellular material in the context of DNA evidence
is an example of when it is necessary for the expert to know and comment on the factual circumstances in
question, to enable him or her to give relevant evidence.

87. This is not, we emphasise, to overlook those instances in trafficking cases when there may be discrete
issues that properly require explanation by way of expert evidence, for instance as to the defendant's
psychiatric or psychological state or the detailed mores of people trafficking gangs operating in countries
that are outside the court's own knowledge and experience. We stress that in the latter instance, this does
not require any comment by the expert as to the consistency of the account given by the defendant,
whereas in the former the psychiatrist or psychologist may express a view as to the detail and content of
the defendant's account as a necessary step to reaching a diagnosis.

88. We highlight, furthermore, that the process of resolving an appeal is not to be equated with a criminal
trial, and the comments of the court in _R v O [2019] EWCA Crim 1389 at [17] were directed at the_
determination of an appeal as opposed to the issue of the admissibility of evidence before a jury (the court
referred without demur to the fact that an expert had commented that the experiences of the appellant
were, “not at all unusual, and given the particular area of Nigeria from which she comes, regrettably very
_usual”)._

89. Finally, we reject a linked argument, advanced on behalf of AAH, that the limitation imposed by
_Brecani relates solely to evidence in this context that is not provided by experts. It is suggested that “the_
_problem” addressed in_ _Brecani can be resolved by instructing an appropriately qualified expert. To the_
contrary, admissibility is to be resolved by reference to the three-part test set out above at [85 (ii)] for
expert evidence, viz. a) is the evidence relevant to a matter in issue in the proceedings; b) is the witness is
competent to give that opinion; and c) is it needed to provide the court with information outside the court's
own knowledge and experience?

1.

II.

II. Is the decision in Brecani consistent with previous authorities of the CACD?

90. In this regard, the court's attention is particularly directed at _JXP [2019] EWCA Crim 1280. It is_
suggested by Mr Fitzgibbon Q.C. on behalf of AAD that the decision in _Brecani is inconsistent with the_
decision in JXP, in which latter case the court observed at [54] that the competent authority is “a specialist
_authority with particular expertise and knowledge in this area of trafficking”. JXP was not cited in Brecani._
In our judgment, this submission is ill-founded. In _Brecani, as we have set out above, this court was_
principally concerned with the admissibility of certain material at trial (particularly, the conclusive grounds
decision and the evidence of Mr Barlow (a forensic social worker and criminologist)). However, as we have
already set out above at [80], the court did not criticise or seek to depart from the decision in _R v S(G)_
admitting on an appeal a decision of the First-Tier Tribunal, a minute from the SCA and a letter from the
Home Office, applying the test for fresh evidence in section 23. The decision in JXP did not concern the
admissibility of evidence at trial, but instead the Court of Appeal felt able to place reliance on the decision
of the SCA because, inter alia:

“54. There is no evidence to contradict what the applicant said. Further, we take account of the fact that the
Competent Authority is a specialist authority with particular expertise and knowledge in this area of
trafficking. The Minute sets out in considerable detail the applicant's account. It clearly analysed whether
that account met the retirements of trafficking and concluded that it did. We accord weight to the decision
of this specialist authority.”

91. The court additionally attached weight “to the evidence of an independent psychiatrist and to entries in
_the applicant's medical records, both as to the development of a depressive illness, symptoms of PTSD_
_and the conditions of hepatitis B and C, which are stated to be consistent with the alleged sexual activity_
_and the taking of heroin. A psychologist in January 2013 reported that the applicant was describing_
_flashbacks regarding his detention and torture in Vietnam. He was experiencing nightmares two or three_
_days a week He was described as being hypervigilant unable to trust others and suffering from insomnia_


-----

_The psychologist concluded that there were evident features of PTSD and severe depression” (see [55])._
There was other extensive medical evidence.

92. In those circumstances, the CACD was able to reach the conclusion that the appellant had been a
VOT and the appeal was allowed, without, we note, the need to hear oral evidence during the appeal. That
decision is not in any sense in conflict with Brecani.

93. Mr Knight on behalf of AAI sought to suggest that the decision in _Brecani_ is in conflict with an
observation at the end of [28] in the decision of this court in R v L(C) _[2013] EWCA Crim 991; [2013] 2 Cr_
App R 23:

“Whether the concluded decision of the competent authority is favourable or adverse to the individual it will
have been made by an authority vested with the responsibility for investigating these issues, and although
the court is not bound by the decision, unless there is evidence to contradict it, or significant evidence that
was not considered, it is likely that the criminal courts will abide by it.”

94. We are unpersuaded by this argument. We have already touched on this issue at [79] above. The
court in L(C) was not focussing on the admissibility of conclusive grounds decisions during a trial. Instead,
[in a decision reached before the implementation of the Modern Slavery Act 2015,the court addressed the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
level of protection from prosecution or punishment for trafficked victims who have been compelled to
commit criminal offences, in the context of a prosecutorial decision to proceed with the trial. At the time of
the decision in _L(C),_ that protection was provided, in the main, by the exercise of the abuse of process
jurisdiction. Critically, the court in L(C) explained that the judge will reach his or her decision on this issue
on the basis of the material advanced by both sides, to the extent that it is relevant to such questions as
age, trafficking and exploitation. It did not, conversely, address whether the same material was admissible
before the jury.

95. We were equally unpersuaded by Mr Knight's submission that only **positive conclusive grounds**
decisions are admissible during the trial and that, since the burden of proof rests on the prosecution,
**negative decisions should always be excluded. If, contrary to our view, conclusive grounds decisions are**
admissible, both positive and negative determinations would simply form part of the evidence on which the
jury would make their decision, with the legal burden of proof resting on the Crown and the evidential
burden of proof resting with the defendant. There is no basis in the law of evidence, or indeed in logic, to
exclude otherwise admissible evidence in this context simply because it favours one side rather than the
other.

96. Mr Knight suggested that the decision in _Brecani was in error because the court focussed on the_
caseworkers as experts and failed to take into consideration the guidance given by the relevant authority
which “bestowed” expertise, particularly when combined with the authority's statutory role. In this context,
he argued that the decision in Brecani is contrary to the decision of the Court of Appeal (Civil Division) in
_Rogers v Hoyle [2014] EWCA (Civ) 257; [2015] QB 265. We disagree. An individual does not become an_
expert simply because he or she is employed by a particular organisation. As set out in _Brecani at [52],_
“The classic statement of the test of admissibility of expert evidence, which has been followed in England
_and Wales, is found in R v Bonython (1984) 38 S.A.S.R. 45, a decision of the South Australian Supreme_
_Court. King CJ observed:_

“The […] question is whether the witness has acquired by study or experience sufficient knowledge of the
subject to render his opinion of value in resolving the issues before the court”.”

97. It is not the organisation that is the expert but the proposed witness.

98. The decision in _Rogers v Hoyle_ concerned the admissibility of a report by the Air Accident
Investigation Branch of the Department of Transport (“the AAIB”) which contained evidence of the opinions
of experts on technical matters. As explained in the judgments of Leggatt J (at first instance) and Clarke LJ
(on appeal), the AAIB use in-house and third-party experts in fields which include aeronautical engineering,
wreckage analysis, meteorology, pathology, analysis of flight data and the piloting of aircraft. The opinions
of such experts are incorporated in the report. Sometimes the expert's description, without his or her name,
was given; sometimes it was not stated that the opinion on an issue was that of an expert although it was


-----

to be inferred that the opinion would have been that of one or more experienced experts. The conclusions
as to the probable causes of the accident were reached on the basis of the AAIB's considerable qualified
expertise and experience in investigating such events. Against that background, Clarke LJ observed:

“51. […] It is open to an expert, that is to say someone who has the appropriate special expertise, to
express an opinion based on the facts as he understands, or assumes, them to be, if and in so far as his
conclusion is informed by, or a reflection of, that expertise. This includes matters such as the causation of
an accident. […]

52. It is not, however, the function of an expert to express opinions on disputed issues of fact which do not
require any expert knowledge to evaluate.”

99. We therefore agree with the observation in Brecani that:

“54. […] (t)he position of these decision-makers (viz. trafficking experts) is far removed, for example, from
experts who produce reports into air crashes for the Air Accident Investigation Branch of the Department of
Transport which are admissible in evidence in civil proceedings: see Rogers v Hoyle […].”

100. Rogers v Hoyle nonetheless serves to highlight one of the substantial differences between civil and
criminal proceedings, given a professional judge can readily distinguish between weight and admissibility in
a manner that would be far more difficult for a jury (see Rogers v Hoyle at [52]).

III. Is the decision in Brecani consistent with the UK's international obligations and European case law with
regard to the protection of VOTs?

101. In this regard the court is particularly invited to consider VCL & AN (cited at [72] above).

102. The court in Brecani gave some detailed consideration to VCL & AN, particularly as follows:

“64. The Strasbourg Court is not generally concerned with rules of evidence but, in any event, the issues
considered by the court (in VCL) were different. The first issue was whether there was a breach of article 4
of the European Convention on Human Rights (“ECHR”) (the anti-slavery provision) by reason of the way
the Vietnamese applicants had been prosecuted for involvement in cannabis farming. The issue for the
court arose from the difference of view taken by the CPS from that of the Competent Authority on the
question of trafficking in a context where both applicants had originally pleaded guilty but subsequently
sought to appeal: [113]. At [156] the court summarised the positive obligations that arise under article 4:

“It follows from the above that the general framework of positive obligations under Article 4 includes: (1) the
duty to put in place a legislative and administrative framework to prohibit and punish trafficking; (2) the
duty, in certain circumstances, to take operational measures to protect victims, or potential victims, of
trafficking; and (3) a procedural obligation to investigate situations of potential trafficking. In general, the
first two aspects of the positive obligations can be denoted as substantive, whereas the third aspect
designates the States' (positive) procedural obligation (see S.M. v. Croatia, cited above, § 306).”

65. It continued by emphasising the need for assessments to be made about the question whether
someone has been trafficked and, in a passage to which we have already referred, said that a prosecuting
authority must consider the conclusions that flowed from those assessments, that the prosecuting authority
was not bound by them but needed a good reason to disagree [162]. The Strasbourg Court went on to hold
that there had been a breach of the state's positive obligations under article 4 in both cases before it. The
critical feature was that the CPS had disagreed with the conclusion of the Competent Authority but for no
substantial reason. The court went on to consider various aspects of article 6 and the overall fairness of the
relevant proceedings and found them wanting on the factual circumstances that had developed.”

103. On behalf of AAH, Ms Gerry submitted that a consequence of the decision in _Brecani is that the_
Crown Prosecution Service is failing to instruct suitably qualified individuals (“experts”) to prepare a
conclusive grounds assessment whenever the issue is raised that the accused is a victim or a potential
victim of trafficking. As the court in VCL & AN put the matter:

“162. […] It follows that, as soon as the authorities are aware, or ought to be aware, of circumstances
giving rise to a credible suspicion that an individual suspected of having committed a criminal offence may


-----

have been trafficked or exploited, he or she should be assessed promptly by individuals trained and
qualified to deal with victims of trafficking […].”

104. This submission is, in our judgment, misconceived. We repeat that Brecani was concerned with the
admissibility of conclusive grounds assessments at trial, and the particular requirement that opinion
evidence should not be provided by non-experts. It was not concerned with, and it did not address, the
adequacy of such reports as part of the process whereby the prosecution decides whether to prosecute,
and whether the individual making the assessment for that specific purpose is suitably qualified. The
material that is admissible for the purposes of a criminal trial is not to be equated with information to which
the Crown Prosecution Service should have regard when deciding whether to bring a charge. Indeed, the
potential adequacy of properly prepared conclusive grounds decisions for purposes other than the
proceedings before the jury is demonstrated by cases such as R v AAJ when such a decision formed an
important element in the decision to quash the conviction, viz. “There is no proper basis on which to depart
_from the Competent Authority's findings, including that the trafficking was for the purpose of being forced to_
_engage in the supply of controlled drugs. The appellant's offending was a direct consequence of the_
_trafficking” (see [41])._

IV. Is the court able to give further guidance vis-à-vis the observation in _Brecani_ (at [58]) that expert
evidence on the question of trafficking and exploitation may be admissible at trial, “particularly to provide
_context of a cultural nature [...]” or “of societal and contextual factors outside the ordinary experience of the_
_jury”_

105. It is submitted by Mr Fitzgibbon on behalf of AAD that it would be helpful for the court to “explain” the
reference in Brecani to “societal and contextual factors”. Moreover, it is suggested that the control methods
used by traffickers, and the experience of being trafficked, are bound to be outside the knowledge of
members of a jury.

106. We have addressed this issue above, particularly in [86] and [87].

v) When on an appeal might it be appropriate or necessary for witnesses (appellant, expert, trial
representative etc.) to be required to attend to give evidence relating to whether the appellant was
trafficked in VOT cases?

107. Ms Gerry suggests that AAH is a “very vulnerable adult” and that the court should not “strain to call
_upon her as a trafficked person to be subjected to cross-examination”. Indeed, it is suggested that to call_
her to give evidence would be contrary to the “purpose of protection”. It is submitted there is ample
evidence to reach a conclusion as to whether the appellant was trafficked.

108. We have already addressed this issue, at [82] – [84]. We stress that R v AAJ demonstrates that there
will be appeals when it will be wholly unnecessary for oral evidence to be adduced. However, if the
suggested trafficking is based, for instance, on unsatisfactory and untested hearsay evidence from the
appellant, the court may express the view that it would be preferable for the appellant to give evidence for
the proper resolution of the issues on the appeal, thereby enabling his or her account to be appropriately
tested.

vi) When the parties disagree, to what extent and at what stage might the court properly be involved in the
question of whether live evidence is to be called?

109. Although the court will pay due regard to the submissions of the parties as to the course the appeal
should take, including as to the need for oral evidence to be given, section 23 makes it clear that these are
ultimately decisions solely for the court, depending on the view that is reached as to what is “necessary or
_expedient in the interests of justice” (see [81] and [82] above). In particular, the court “may order any_
_witness to attend for examination and be examined before the court”. Whether it will do so, or when, will_
depend on all the circumstances of the case. Where the parties are agreed that no oral evidence is
needed, they should in good time inform the Criminal Appeal Office accordingly. This will then be notified to
the Vice- President or presiding Lord Justice, who can confirm or reject their position. If the parties are not
agreed on whether there is to be oral evidence, this likewise should in good time be referred to the Office
so that the Vice- President or presiding Lord Justice can give appropriate directions


-----

vii) Is it still possible to argue on appeal that prosecution of a VOT was an abuse of process

110. Does it remain possible, therefore, following the introduction into law of the defence under section 45
(see [64] above), for a defendant to argue (whether at trial before the judge in the absence of the jury or on
appeal) that the prosecution was an abuse of process by reason of a failure on the part of the prosecution
to apply its own policy guidance.

111. The existence of such an abuse jurisdiction prior to the introduction of the 2015 Act in the context of
VOT cases is clearly acknowledged in the authorities, the usual basis relied on being that of the second
limb of the jurisdiction expounded in cases such as _R v Horseferry Road Magistrates Court ex parte_
_Bennett [1994] 1 AC 42: to the broad effect that it is unfair and oppressive that a defendant should be tried._

112. Thus, in R v M(L) _[[2011] EWCA Crim 2327; [2011] 1 Cr App R 12, Hughes LJ, giving the judgment of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:542M-MGR1-F0JY-C214-00000-00&context=1519360)_
the court, and following a full review of the 2005 Convention and of the then applicable CPS Guidance
issued to prosecutors in Human Trafficking and Smuggling cases, said this at [10]:

“10. The effect of that is to require of prosecutors a three-stage exercise of judgment. The first is: (1) is
there a reason to believe that the person has been trafficked? If so, then (2) if there is clear evidence of a
credible common law defence the case will be discontinued in the ordinary way on evidential grounds, but,
importantly, (3) even where there is not, but the offence may have been committed as a result of
compulsion arising from the trafficking, prosecutors should consider whether the public interest lies in
proceeding to prosecute or not.”

And at [14] he said:

“14. It follows that the application of art.26 is fact-sensitive in every case. We attempt no exhaustive
analysis of the factual scenarios which may arise in future. Some general propositions can perhaps be
ventured:

(i) if there is evidence on which a common law defence of duress or necessity is likely to succeed, the
case will no doubt not be proceeded with on ordinary evidential grounds independent of the Convention,
but additionally there are likely to be public policy grounds under the Convention leading to the same
conclusion;

(ii) but cases in which it is not in the public interest to prosecute are not limited to these: see above;

(iii) it may be reasonable to prosecute if the defendant's assertion that she was trafficked meets the
reasonable grounds test, but has been properly considered and rejected by the Crown for good evidential
reason. The fact that a person passes the threshold test as a person of whom there are reasonable
grounds to believe she has been trafficked is not conclusive that she has. Conversely, it may well be that in
other cases that the real possibility of trafficking and a nexus of compulsion (in the broad sense) means
that public policy points against prosecution;

(iv) there is normally no reason not to prosecute, even if the defendant has previously been a trafficked
victim, if the offence appears to have been committed outwith any reasonable nexus of compulsion (in the
broad sense) occasioned by the trafficking, and hence is outside art.26;

(v) a more difficult judgment is involved if the victim has been a trafficked victim and retains some nexus
with the trafficking, but has committed an offence which arguably calls, in the public interest, for
prosecution in court. Some of these may be cases of a cycle of abuse. It is well known that one tool of
those in charge of trafficking operations is to turn those who were trafficked and exploited in the past into
assistants in the exploitation of others. Such a cycle of abuse is not uncommon in this field, as in other
fields, for example that of abuse of children. In such a case, the question which must be actively confronted
by the prosecutor is whether or not the offence committed is serious enough, despite any nexus with
trafficking, to call for prosecution. That will depend on all the circumstances of the case, and normally no
doubt particularly on the gravity of the offence alleged, the degree of continuing compulsion, and the
alternatives reasonably available to the defendant. The case of Mihai and others, which we consider below,
is an example.”


-----

113. Having so stated, Hughes LJ then turned specifically to the issue of stay on the ground of abuse. He
observed:

“15. The availability of the ultimate sanction of a stay of proceedings on grounds of abuse was common
ground before us, and is thus accepted by the Director of Public Prosecutions. We do not disagree that it
is, in certain limited circumstances, available, but the limitations upon the jurisdiction must be understood.
Criminal courts in England and Wales do not decide whether a person ought to be prosecuted or not. They
decide whether an offence has been committed. They may, however, also have to decide whether a legal
process to which a person is entitled, or to which he has a legitimate expectation, has been neglected to
his disadvantage.

[…]

“18. It is to be noted that the treaty obligation under the Convention in question in these two cases was an
obligation to give immunity (in respect of certain kinds of offence and on certain conditions). The treaty
obligation which we are considering under art.26 is not an obligation to grant immunity, but rather an
obligation to put in place a means by which active consideration is given to whether it is in the public
interest to prosecute. We accept that the power to stay for “abuse” exists as a safety net to ensure that this
obligation is not wrongly neglected in an individual case to the disadvantage of the defendant.

19. We make it clear that the occasions for the exercise of this jurisdiction to stay ought to be very limited
once the provisions of the Convention are generally known, as by now they should be becoming known.
Moreover, the jurisdiction to stay does not mean that the court is entitled to substitute its own view for that
of the prosecutor upon the assessment of the public policy question whether a prosecution is justified or
not. The power to stay is a power to ensure that the Convention obligation under art.26 is met. The
Convention obligation is to provide for the possibility of not imposing penalties on victims for their
involvement in unlawful activities to the extent that they have been compelled to do so. Thus the
Convention obligation is that a prosecuting authority must apply its mind conscientiously to the question of
public policy and reach an informed decision. If it follows the advice in the earlier version of the guidance,
set out above, then it will do so. If however this exercise of judgment has not properly been carried out and
would or might well have resulted in a decision not to prosecute, then there will be a breach of the
Convention and hence grounds for a stay. Likewise, if a decision has been reached at which no reasonable
prosecutor could arrive, there will be grounds for a stay. Thus in effect the role of the court is one of review.
The test is akin to that upon judicial review. To the extent that Mr Blaxland QC submitted that there was a
different test, derived from the proportionality test to be applied where there is an infringement of the
primary requirements of one of the qualified articles of the European Convention on Human Rights ( _R._
_(Daly) v Secretary of State for the Home Department [2001] UKHL 26; [2001] 2 A.C. 532 ), we disagree_
since the question here is not of proportionality in that special sense, but as Lord Steyn observed in that
case (at [27]) the two tests will in most cases yield the same result.”

114. This approach was endorsed in N and L [2012] EWCA Crim 189; [2013] QB 379where Lord Judge
CJ, giving the judgment of the court, stated at [21]:

“Summarising the essential principles, the implementation of the UK's Convention obligation is normally
achieved by the proper exercise of the long established prosecutorial discretion which enables the CPS,
however strong the evidence may be, to decide that it would be inappropriate to proceed or to continue
with the prosecution of a defendant who is unable to advance duress as a defence but who falls within the
protective ambit of article 26. This requires a judgment to be made by the CPS in the individual case in the
light of all the available evidence. That responsibility is vested not in the court but in the prosecuting
authority. The court may intervene in an individual case if its process is abused by using the “ultimate
sanction” of a stay of the proceedings. The burden of showing that the process is being or has been
abused on the basis of the improper exercise of the prosecutorial discretion rests on the defendant. The
limitations on this jurisdiction are clearly underlined in R v M (L). The fact that it arises for consideration in
the context of the proper implementation of the UK's Convention obligation does not involve the creation of
new principles. Rather, well established principles apply in the specific context of the article 26 obligation,
no more, and no less. Apart from the specific jurisdiction to stay proceedings where the process is abused,


-----

the court may also, if it thinks appropriate in the exercise of its sentencing responsibilities implement the
article 26 obligation in the language of the article itself, by dealing with the defendant in a way which does
not constitute punishment, by ordering an absolute or a conditional discharge.”

Likewise, in _R v L(C) Lord Judge said this, among other things, and following a review of the 2011_
Directive, at [16]:

“In any case where it is necessary to do so, whether issues of trafficking or other questions arise, the court
reviews the decision to prosecute through the exercise of the jurisdiction to stay. The court protects the
right of the victim of trafficking by overseeing the decision of the prosecutor and refuses to countenance
any prosecution which fails to acknowledge and address the victim's subservient situation, and the
international obligations to which the United Kingdom is party […].”

He went on at [17]:

'It may be that the submissions advanced in erroneous reliance on Waya stem from a fear that the court
will do no more than review the prosecutor's decision on traditional _Wednesbury grounds (Associated_
_Provincial Picture Houses Ltd v Wednesbury Corp [1948] 1 K.B. 223) and decline to interfere, even though_
its own conclusion would be that the offences were a manifestation of the exploitation of a victim of
trafficking. For the reasons we have already given, no such danger exists. In the context of an abuse of
process argument on behalf of an alleged victim of trafficking, the court will reach its own decision on the
basis of the material advanced in support of and against the continuation of the prosecution. Where a court
considers issues relevant to age, trafficking and exploitation, the prosecution will be stayed if the court
disagrees with the decision to prosecute. The fears that the exercise of the jurisdiction to stay will be
inadequate are groundless.”

The availability of a stay jurisdiction for pre-2015 Act cases was further approved by constitutions of this
court in Joseph (Verna) [2017] EWCA Crim 36; [2017] 1 Cr App R 33 and S(G) [2018] EWCA Crim 1824;

[2019] 1 Cr App R 7.

115. The question, therefore, is whether this residual jurisdiction (in practice only to be exercised in very
limited circumstances, as all the authorities indicate) survives the introduction of the 2015 Act.

116. At first sight, and absent authority to the contrary, it is difficult to see why it should not. Clearly the
2015 Act was designed to improve the position of VOTs (or those claiming to be VOTs) by providing for the
opportunity, in certain kinds of cases, to raise a substantive defence: which, if raised on a sufficient
evidential basis, it would then be for the prosecution to disprove to the criminal standard. There is, on the
face of it, no incompatibility in such a defence being available and there also being available the potential
(in an exceptional case) for advancing the abuse of process jurisdiction with regard to a decision to
prosecute and pursue to trial. Indeed, to retain the availability of the abuse of process jurisdiction for this
purpose would seem better to preserve the obligations in the Convention and Directive, which extend not
only to VOTs not being punished but also, in appropriate cases, to not being prosecuted.

117. Moreover, although the abuse of process jurisdiction in this context has sometimes been described
as “special” or “unusual” that is, in our judgment, only really so, in substance, just because of the context.
(We say this subject to our comments below at [137] on [17] of _L(C)). After all, any abuse of process_
argument has to take into account the context: and here such context necessarily includes the international
obligations relating to VOTs and to the very sensitive issues arising with regard to VOTs.

118. Such a view in no way would, in our judgment, subvert the provisions of or purpose of the 2015 Act.
Rather, it would complement them and supplement them. Nor does the availability of the abuse of process
jurisdiction give alleged VOTs carte blanche to circumvent a prosecution. We emphasise: a decision to
prosecute is for the CPS, not for the courts. Further, where the facts are in dispute then it is for a jury to
determine those facts. It thus will be fruitless for a defendant to seek to avoid prosecution by alleging
(truthfully or not) status as a VOT or (even where such status of VOT is admitted) by disputing the asserted
lack of nexus between that status and the criminality in question. It will be fruitless just because those
matters will be jury matters.


-----

119. It would therefore follow that where the CPS has taken into account the relevant prosecutorial
guidance and has taken into account any conclusive grounds decision (and has a rational basis for
departing from a conclusive grounds decision if it has been favourable to the prospective defendant) there
is simply no basis for an abuse of process challenge at all: since mere asserted disagreement with a
decision to prosecute will never of itself suffice. Indeed, it has long been established that a judge may not
order a stay of a prosecution simply because the judge personally would not have prosecuted: see, for
example, Connelly v DPP [1964] AC 1254. Any attempts, therefore, to seek a stay in such circumstances
before a Crown Court will be met with short shrift: if needs be, reinforced by a wasted costs order in an
appropriate case. As Mr Douglas-Jones also pointed out, citing a number of authorities in support,
successful applications to the Administrative Court for a review of a CPS prosecution decision are only
entertained in very rare circumstances. The same applies, in our judgment, to any attempt to raise an
analogous argument in the Crown Court in a VOT case on an abuse of process application.

120. But what if the CPS has failed unjustifiably to take into account the CPS Guidance or what if it has no
rational basis for departing from a favourable conclusive grounds decision? That of course, given the
terms of the current CPS guidance and given the much greater awareness nowadays of the situation
concerning VOTs generally, is, or should be, nowadays a highly improbable scenario. But in principle such
a scenario would, on ordinary public law grounds, seem to operate to vitiate that prosecution decision:
whether by reason of a failure to take a material matter (viz. the CPS prosecution guidance) into account or
by making a decision to prosecute which is properly to be styled as irrational. Consequently, such a
prosecution may, in an appropriate case, be stayed. This aligns with the principle, summarised helpfully in
Blackstone's Criminal Practice 2022 at [D2.22] that, generally speaking, a decision to prosecute is not
susceptible to judicial review in the Administrative Court because it may be challenged during the trial
process itself, most particularly by an application to stay the proceedings on the grounds of abuse of
process. As the editors observe, arguments relating to abuse of process may and should be raised in the
course of the criminal trial itself save in wholly exceptional circumstances. In _R (Pepushi) v CPS [2004]_
_EWHC 798 (Admin) Thomas LJ observed:_

“49. In view of the frequency of applications seeking to challenge decisions to prosecute, we wish to make
it clear and, in particular, clear to the Legal Services Commission (which funds applications of this kind
which seek to challenge the bringing of criminal proceedings), that, save in wholly exceptional
circumstances, applications in respect of pending prosecutions that seek to challenge the decision to
prosecute should not be made to (the Administrative Court). The proper course to follow, as should have
been followed in this case, is to take the point in accordance with the procedures of the Criminal Courts. In
the Crown Court that would ordinarily be by way of defence in the Crown Court and if necessary on appeal
to the Court of Appeal Criminal Division. The circumstances in which a challenge is made to the bringing of
a prosecution should be very rare indeed as the speeches in Kebilene ([2002] 2 AC 326) make clear.”

121. We were, however, referred to the decisions of constitutions in this court in DS [2020] EWCA Crim
_285; [2021] 1 WLR 303and_ _A_ [2020] EWCA Crim 1408. It is said on behalf of the Crown that those
decisions provide binding authority to the effect that no “special” category of abuse of process jurisdiction
exists in this context following the introduction of the 2015 Act.

122. DS was an unusual case on its facts. The decision to prosecute the defendant, a minor at the time,
for drugs offences was made before any conclusive grounds decision had been made under the National
Referral Mechanism. Subsequently, after charges had been brought, such a decision was made. It was
favourable to the defendant. On review, the CPS had regard to the prosecution guidance. It concluded
that, notwithstanding the favourable conclusive grounds decision, the case should continue. The Crown
Court judge was nevertheless invited to stay the proceedings as an abuse. He did so, in effect exercising
his own judgment as to the evidence. In such circumstances the Court of Appeal unsurprisingly allowed
the appeal. It said this:

“40. In our judgment, the result of the enactment of the 2015 Act and the section 45 statutory defence is
that the responsibility for deciding the facts relevant to the status of DS as a victim of trafficking is
unquestionably that of the jury. Formerly, there was a lacuna in that regard, which the courts sought to fill
by expanding somewhat the notion of abuse of process which required the judge to make relevant


-----

decisions of fact. That is no longer necessary, and cases to which the 2015 Act applies should proceed on
the basis that they will be stayed if, but only if, an abuse of process as conventionally defined is found. By
way of summary only, this involves two categories of abuse, as is well known. The first is that a fair trial is
not possible and the second is that it would be wrong to try the defendant because of some misconduct by
the state in bringing about the prosecution. Neither of these species of abuse affected this case, and it
should not therefore have been stayed.

123. Having so held, the court went on to make some further observations on (as we read the judgment)
an obiter basis. Among other things, it stated (uncontroversially in our view) in the course of paragraph 41
that “if [the CPS guidance] is properly applied the CPS will comply with its legal obligations”. But having so
stated, the court went on at [42] of the judgment:

“Under the 2015 Act, the prosecutor is entitled to challenge that conclusive grounds decision before the
jury in seeking to rebut the statutory defence and to invite the jury to come to a different decision. If there is
a sound evidential basis on which to do this, it will not be an abuse of process to try. If there is not, it will
still not be an abuse of process, but the judge will consider any submission that there is no case to answer.
Whether or not a child is in fact a victim of trafficking is a matter which the jury is required to consider under
section 45(4)(b). This is an issue which they will have to consider on all properly admissible evidence,
which may include the evidence of the defendant or, if he does not give evidence, may, if appropriate,
include an adverse inference.”

124. The court further went on to say, at [44], that its decision in a case to which the 2015 Act applies was
that a judge “has no reason to attempt to evaluate a decision by of (sic) the Authority (sic), at least in the
_absence of some arguable abuse of process properly so called […].” It also stated that there “was no_
_room, in the light of s.45 of the 2015 Act, for the abuse of process of jurisdiction to “immunise” the_
_respondent from prosecution”._

125. We have to say, however, that we are, with respect, rather puzzled by some of the observations in

[42] of the judgment. We wholly agree with the proposition that if there is a sound evidential basis for the
CPS to depart from a conclusive grounds decision, it will not be an abuse of process for the case to be
tried. Indeed so. What we find altogether more difficult is the following proposition that “if there is not, it
_will still not be an abuse of process but the judge will consider any submission that there is no case to_
_answer.” But there is no necessary logical connection between an application to stay on the basis of limb_
two abuse and a submission of no case to answer. Indeed, the application for a stay is essentially on the
basis that it is unfair and oppressive for the defendant to be prosecuted and tried at all.

126. Moreover, this dictum does not seem fully to reflect the preceding statement (cited above) in [41] of
the judgment in DS to the effect that if CPS guidance is properly applied the CPS will comply with its legal
obligations. The implied corollary surely then must be that if the CPS guidance in a VOT case is _not_
properly applied it will not comply with its legal obligations. And if that is indeed the scenario, legal redress,
in the form of an opportunity at least to make an application for a stay, should be available: which a Crown
Court judge can then appraise by way of review on public law grounds. Moreover, so to conclude does not
in any way involve a Crown Court judge entering into the arena of making improperly decisions of fact or
usurping the functions of CPS and jury.

127. We are also a little wary of the reference in [44] of the judgment in _DS to an arguable abuse of_
process “properly so called”. We accept that abuse of process applications of the kind made in M(L), L(C)
and _N and L have their own features. But, as will be gathered, we consider that is essentially so just_
because of the special context and features of VOT cases and of the international obligations relating to
VOTs. The underpinning, however, for such an application to stay remains that of unfairness and
oppression and illegality: which is a conventional underpinning for any typical limb two abuse application.
And if there has been an unjustified and material failure to have regard to CPS guidance in this kind of
context or an irrational and perverse departure from a conclusive grounds decision in this kind of context
then an arguable case of unfairness and oppression and illegality would potentially be there. Indeed, in his
written arguments Mr Douglas-Jones very fairly accepted that a failure to apply the safeguard of the CPS
guidance could give rise to a limb two abuse of process application.


-----

128. We also think that the dictum in [42] of _DS does not sit at all well with the subsequent decision in_
2021 of the ECHR (of which the court in DS necessarily could not have been aware) in the case of VCL &
_AN (see above at [72], [101] - [103]). Those applications in fact derive from cases conjoined with the_
domestic _Joseph appeals (cited above). The European Court of Human Rights dealt very fully with the_
VOT points arising in these cases.

129. The court in VCL & AN accepted that the prosecution of a VOT was not prohibited under the 2005
Convention or any other international instrument. But the court went on at [159]:

“Nevertheless, the court considers that the prosecution of victims, or potential victims, of trafficking may, in
certain circumstance, be at odds with the state's duty to take operational measures to protect them where
they are aware, or ought to be aware, of circumstances giving rise to a credible suspicion that an individual
has been trafficked.”

The Court further went on to say this at [162] (already cited in part above at [103]):

“Once a trafficking assessment has been made by a qualified person, any subsequent prosecutorial
decision would have to take that assessment into account. While the prosecutor might not be bound by the
findings made in the course of such a trafficking assessment, the prosecutor would need to have clear
reasons which are consistent with the definition of trafficking contained in the Palermo Protocol and the
Anti-Trafficking Convention for disagreeing with it.”

130. In the actual result, the ECHR allowed the applications, taking the view on the facts (which included
the fact that both appellants were minors at the time) that the CPS had had no sufficient reason for
departure from the favourable conclusive grounds decisions in each case. But in terms of general
approach we consider that the decision of the ECHR is broadly consistent with the approach taken in M(L),
_Joseph and other such cases: to the effect that a prosecution of a VOT will not be allowed to proceed if_
there is no rational basis (which we would equate with the ECHR's “clear reasons”) for departure from a
favourable conclusive grounds decision. It is true that the case of VCL & AN ante-dated the 2015 Act, to
which the ECHR made no reference. But, as we read the judgment, the European Court of Human Rights
was talking in entirely general terms in respect of VOT cases. Accordingly, the decision in VCL & AN is not
really consistent with the dictum in DS to which we have referred above.

131. Mr Douglas-Jones, however, placed particular reliance on the decision of a constitution of this court
in _A (cited at [121] above): albeit that too was decided before, and therefore without reference to, the_
decision of the European Court of Human Rights in VCL & AN.

132. In that case, the defendant (18 at the time) had been charged with aggravated burglary. A conclusive
grounds decision had, albeit subsequent to his conviction on his plea of guilty, been made in his favour. It
was ultimately accepted that he had been a VOT.  It was argued on appeal, when fresh evidence to this
effect was sought to be advanced, that it had been an abuse of process for him to be prosecuted and that
had the CPS guidance been properly applied, on a true appreciation of his status as a VOT, he would not
and should not have been prosecuted for aggravated burglary. It was a feature of the case, we observe,
that aggravated burglary is an offence listed in Schedule 4 to the 2015 Act; and consequently, by reason of
section 45(7), no defence under section 45 would have been available.

133. It was argued on behalf of the appellant in _A that the abuse of process jurisdiction, as outlined in_
cases such as M(L) and Joseph, remained available following the 2015 Act and was particularly important
by way of “safety net” where (as in that case) section 45 did not provide a defence at all. On behalf of the
Crown it was argued, in reliance on DS, that a VOT was in no different position (following the 2015 Act)
from any other criminal appellant and there was no “special category” of abuse of process available in VOT
cases following the introduction of the 2015 Act: which was, it was said, Parliament's response to the
situation of VOTs and to international obligations.

134. In rejecting the appeal, the court among other things said this:

“61. We start with our conclusion that the 2015 Act has changed the legal landscape in relation to the
protection available to victims of trafficking who commit criminal offences. The reason for the development


-----

of a special abuse of process jurisdiction in cases of this kind was because there was a lacuna in domestic
law in relation to the UK's international obligations owed to victims of trafficking. However, Parliament has
now considered the position and determined how those obligations in relation to criminal law should be
implemented. It has done so by enacting the 2015 Act. In other words, the lacuna has been filled by
legislation the scope of which cannot be circumvented.

62. Parliament's decision to legislate by Schedule 4 of the 2015 Act to limit the scope of the s.45 defence
(by excluding its application to serious sexual and violent offences) reflects the balance struck by
Parliament between preventing perpetrators of serious criminal offences from evading justice and
protecting genuine victims of trafficking from prosecution. An absolute defence for all offences was not
required by the UK's international obligations and was not adopted in the domestic legislation introduced.
The CPS must, as a prosecution service independent of the executive, apply the domestic law enacted by
Parliament and there can be no abuse of process when it does that.

63. In DS the LCJ made clear that the abuse of process jurisdiction is no longer necessary in light of the
enactment of the 2015 Act, recognising that there are offences to which the statutory defence in s.45 will
not apply. For the reasons we have given, we respectfully agree.

64. It seems to us that just as this court held in LM (at a time well before the enactment of the 2015 Act)
that the UK's international obligations were capable of being (and were) fulfilled by non-legislative means
that included the then CPS guidance, the same remains true. In serious criminal cases to which Schedule
4 of the 2015 Act applies, the common law defence of duress/necessity and the four stage approach to
prosecution decisions set out in the Guidance (that has express regard at stage four for the public interest)
provide appropriate safeguards. Cases in which duress and the s.45 defence are not available, but where it
would not be in the public interest to prosecute on the basis of a victim of trafficking's status will, we think,
be rare. The seriousness of the offence will in such circumstances require an even greater degree of
continuing compulsion and the absence of any reasonably available alternatives to the defendant before it
is likely to be in the public interest not to prosecute an individual suspected of an offence regarded by
Parliament as serious enough to be included in Schedule 4.”

135. The court then went on to consider whether, on the facts by then known, in the light of the fresh
evidence, the decision to prosecute might have been different in that particular case, given that at the time
there had been “an absence of any consideration of the indicators that the appellant was a victim of
_trafficking”. It decided that it would not have been, given the facts. We entirely agree in this respect with_
the observations of the court in _A that there is no requirement to provide “blanket immunity” from_
prosecution for VOTs who commit criminal offences (reflecting the remarks in DS that there is no room for
the abuse of process jurisdiction to “immunise” the respondent from prosecution).

136. The court in A was also however clearly disinclined, in line with DS, to accept that there was now,
following the 2015 Act, need for the development of a “special” abuse of process jurisdiction by reason of
any perceived lacuna in the law. Counsel before us rather struggled, however, to identify what was meant
by reference to a “special” abuse of process jurisdiction. As we have already outlined, the jurisdiction is
founded on the conventional limb two abuse approach. It is only “special” given the particular context of
trafficking and the general background of international obligations. But the core elements of fairness and
oppression and illegality inherent in any such abuse of process application remain.

137. Mr Knight suggested that the “special” jurisdiction derived from what was said by the court at
paragraph 17 of L(C). We do not agree. It is a clear inference, from the remarks of the court in DS itself in

[44], that that court had not viewed [17] of L(C) as of itself giving rise to a "special" jurisdiction. Moreover,
paragraph 17 of _L(C) does not seem to us to fit well with the court's prior rejection in that case of the_
argument that the Crown Court had an independent and primary role in assessing the proportionality of a
charging decision in a VOT case or with the court's acceptance (clearly correct) that the decision to
prosecute was for the CPS. Nor do some of the remarks in [17] of L(C) fit well with what is immediately
thereafter said in paragraph 18 of the judgment and in the endorsement of cases such as _M(L). In our_
view, the required approach is by reference to public law principles, akin to judicial review, in the context of
appraising the decision to prosecute in a VOT case where an abuse of process application is made. We


-----

note that a similar approach applies to prosecutions under section 31(1) of the Immigration and Asylum Act
1999, as amended: see in particular the discussion in _ML_ [2011] 1 Cr. App. R. 12, at [15] - [19] of the
judgment.

138. We also note that the court in A had itself expressly, and uncontroversially, stated that the CPS must
apply the domestic law as enacted by Parliament and that there could be no abuse of process if it did so.
But likewise, as a matter of domestic law, the CPS must apply its own published guidance in its
prosecutorial decision-making process in VOT cases. If it does then there can be no abuse of process.
But, by parity of reasoning, if without justification it does _not then there may, depending on the_
circumstances, be an abuse of process justifying a stay.

139. Moreover, in A, there could have been no abuse of process at the time the CPS made and pursued
its charging decision in the Crown Court: for at that time it had no factual basis before it to give rise to a
belief or credible suspicion that the defendant may have been a VOT. That only emerged following his
conviction on his own plea. Even so, it is noteworthy that the Court of Appeal then fully considered the
issue of whether the decision to prosecute might have been different had his true status as a VOT been
known at the time, in assessing whether or not his conviction, on his plea, was safe.

140. Overall, therefore, we do not, with respect, accept the dictum in DS to the effect that there can be no
abuse of process even where there is no sound evidential (that is, rational) basis for a prosecutorial
departure from a conclusive grounds decision favourable to a defendant. We further consider that the
decision in A is distinguishable and was not directly concerned with the point raised before us. Further, if it
could be said (contrary to our own view) that DS and A were otherwise potentially binding in this particular
respect as to the lack of availability of the abuse of process jurisdiction then we would in any event depart
from that aspect of those decisions, in the light of the subsequent decision of the European Courts of
Human Rights in VCL & AN: see (RJM) v Secretary of State for Work and Pensions [2009] 1 AC 311 at

[66] of the speech of Lord Neuberger.

141. As a matter of procedure, on an application to stay the proceedings, for instance on the basis that the
Crown had unjustifiably failed to take into account the CPS Guidance when deciding to prosecute, one
option available to the judge prior to making a decision would be to adjourn the application to afford the
CPS the opportunity to reconsider/remake its decision in light of its own guidance. This approach may be
less appropriate, however, if the contention is that the decision was simply unsustainable or perverse.

142. We draw the threads together. Our conclusions on this ground are as follows:

(1) The limb two abuse of process jurisdiction remains available in principle in all VOT cases following the
2015 Act, and whether or not they are Schedule 4 cases.

(2) Such jurisdiction is "special" only in the sense that it falls to be exercised in the context of a particular
sensitivity required to be applied to VOT prosecutions, having regard to international obligations and
specific CPS guidance. The core requirements of unfairness and oppression and illegality (inherent in
almost every limb two case) remain central to applications for a stay in a VOT context.

(3) Mere disagreement with a decision to prosecute, following due regard given by the prosecution to the
CPS guidance and to any conclusive grounds decision, gives no basis whatsoever for an application for a
stay. Decisions to prosecute are for the CPS. Decisions on disputed facts or evaluations of fact are for the
jury.

(4) If (in what will be likely to be a most exceptional case) there has been a failure to have due regard to
CPS guidance or if there has been a lack of rational basis for departure by the prosecution from a
conclusive grounds decision then a stay application may be available. It will then be assessed by the
court, by way of review on grounds corresponding to public law grounds.

143. Finally, on this issue, we add this. We were told that what became section 45 of the 2015 Act only
emerged at committee stage. We were also told that that section was intended to provide further and
enhanced protection for VOTs. At all events, nothing in the language of the 2015 Act and nothing in the
other materials drawn to our attention gives any indication that the previously established availability of an


-----

abuse of process jurisdiction in this context was designed to be removed or significantly curtailed by the
2015 Act. For the reasons we have given, that jurisdiction remains an available additional safeguard, given
appropriately exceptional facts. Equally, for the reasons we have given, such a conclusion should give rise
to no flood-gates consequences: cases of abuse of process will be (as they always should have been)
very rare in this context and can arise in only very limited circumstances.

viii) Is the definition of “compulsion” as set out in _VSJ [2017] EWCA Crim 36 at [21] and_ _[section 45](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_
**_Modern Slavery Act 2015 too narrow?_**

144. In essence this question is whether the necessary approach ought to be that of “causation” rather
than “compulsion”. Ms Gerry on behalf of AAH argues that restricting the protection to “compulsion” as a
critical element of the defence in section 45 (see [64] above), even when the burden lies on the
prosecution, provides the defendant with insufficient protection. It is suggested that the defendant is
nonetheless required to raise evidence of exploitation, thereby “putting that person at risk of harm through
_state processes because, given the risks, the dominant strategy is to remain silent”. Based in part on the_
analysis of Bijan Hoshi in “The Trafficking Defence: A Proposed Model for the Non-Criminalisation of
_Trafficked Persons in International Law” (2013) 1(2) Groningen Journal of International Law 54, it is_
argued, therefore, that the question should be whether the offence was caused by the traffickers, and that
the test of compulsion should be interpreted accordingly. It is suggested that this is to ensure that it is the
trafficker who “holds criminal responsibility”.

145. We are unable to accept this argument. The starting point is the statutory language which is entirely
clear: the terms of the section 45 defence require that the person was “compelled” to do the act, that the
“compulsion” is attributable to slavery or to relevant exploitation and that a reasonable person in the same
situation would have had no realistic alternative. The intention of Parliament could not have been clearer:
compulsion and causation self-evidently have entirely different meanings and the legislature decided to
adopt the approach of the former. Not only is this the express domestic legislative requirement but it
coincides with United Kingdom's international obligations. In brief, in 2001, following the UN General
Assembly Resolution 55/25 of 15 November 2000, the UN Convention against Transnational Organised
Crime was agreed at Palermo in December 2000. Annex II to the Convention was the Protocol to prevent,
suppress and punish trafficking in persons, especially women and children, usually called the Palermo
Protocol. It was ratified by the UK on 9 February 2006.

146. The Palermo Protocol was complemented by the European Union Framework Decision
(2002/629/JHA) ([2002] OJ L203/1) on combatting trafficking in human beings and a Council of Europe
Convention on Action against Trafficking in Human Beings (“ECAT”), agreed in Warsaw in May 2005. The
Convention on Action was ratified by the United Kingdom on 17 December 2008 and came into force
domestically on 1 April 2009. It adopted in article 4 the same definition of trafficking in human beings as the
Palermo Protocol. Article 26 entitled “Non-punishment provision” provided:

“Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
**been compelled to do so.” (emphasis added)**

147. The Framework Decision [2002] OJ L203/1 was replaced by the 5 April 2011 European Union
Directive 2011/36 ([2011] OJ L101/1) on preventing and combatting trafficking in human beings, which had
direct effect from 6 April 2013. Recital 14 of the Directive provided:

“Victims of trafficking in human beings should, in accordance with the basic principles of the legal systems
of the relevant Member States, be protected from prosecution or punishment for criminal activities such as
the use of false documents, or offences under legislation on prostitution or immigration, that they have
been compelled to commit as a direct consequence of being subject to trafficking. The aim of such
protection is to safeguard the human rights of victims, to avoid further victimisation and to encourage them
to act as witnesses in criminal proceedings against the perpetrators. This safeguard should not exclude
**prosecution or punishment for offences that a person has voluntarily committed or participated in.”**
(emphasis added)


-----

148. Article 2 paragraphs 1 – 4 are in the following terms:

**“Offences concerning trafficking in human beings**

1. Member States shall take the necessary measures to ensure that the following intentional acts are
punishable:

The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or
transfer of control over those persons, by means of the threat or use of force or other forms of coercion, of
abduction, of fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or
receiving of payments or benefits to achieve the consent of a person having control over another person,
for the purpose of exploitation.

2. **A position of vulnerability means a situation in which the person concerned has no real or**
**acceptable alternative but to submit to the abuse involved.**

3. Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of
sexual exploitation, forced labour or services, including begging, slavery or practices similar to slavery,
servitude, or the exploitation of criminal activities, or the removal of organs.

4. The consent of the victim of trafficking in human beings to the exploitation, whether intended or actual,
shall be irrelevant where any of the means set forth in paragraph 1 has been used.” (emphasis added)

149. Article 8 of the Directive is in the following terms:

**“Non-prosecution or non-application of penalties to the victim**

Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties
on victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2.”

150. On 1 April 2009, when the Council of Europe Convention came into force, the United Kingdom
Government set up the National Referral Mechanism: Competent Authorities were given the responsibility
for making what are described as conclusive decisions as to whether someone been trafficked for the
purposes of exploitation. The Competent Authorities were a unit within the National Crime Agency and
units or hubs within the Home Office Immigration and Visa Section. There is now one Single Competent
Authority.

151. In 2010 the Strasbourg Court decided in Rantsev v Cyprus (2010) 51 EHHR 1 that Article 4 of the
European Convention on Human Rights (the ECHR) contained a procedural obligation similar to that in
respect of Article 2 and therefore required effective measures be in place in States to provide practical and
effective protection of the rights of victims of trafficking (see [282]–[289]). The Crown Prosecution Service
has developed and amended over time its policy to give effect to these international obligations.
Simultaneously, the Court of Appeal (Criminal Division) has developed a significant jurisprudence that has
protected trafficked individuals in this particular context, both before and after the coming into force of the
**_[Modern Slavery Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**

152. One of the foundation stones of Ms Gerry' submissions is the suggested trafficking offence as
advocated by Bijan Hoshi in his 2013 article (therefore written prior to the implementation of 45 of the
**_[Modern Slavery Act 2015), as referred to at [144] above. This suggested defence would be “a complete](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
_defence against criminal liability. In order to establish the defence, it is proposed that the trafficked person_
_would need to establish: first, that they are (or were) a trafficked person; and, secondly, that the offence_
**_was committed as a direct consequence of the trafficking situation. If both elements were established,_**
_then the trafficked person would have a complete defence”. (emphasis added)_

153. Given the clear terms of section 45 which aptly reflect the United Kingdom's international obligations
in this context (as summarised above), there is no sustainable foundation for the submission that this
legislative provision should be reformulated in the manner suggested, substituting the “compulsion”
element of the defence with that of “causation”. That would involve the wholesale rewriting of a statutory


-----

defence without any, or any material, justification. At least since the Council of Europe Convention came
into force domestically on 1 April 2009, the United Kingdom has subscribed to and implemented a binding
international approach, now reflected in section 45, which provides a defence to certain crimes for
trafficked individuals if the prosecution is unable to make the court sure the “compulsion” defence does not
apply. As established in R v MK _[2018] EWCA Crim 667:_

“45.[…] The burden on a defendant is evidential. It is for the defendant to raise evidence of each of those
elements and for the prosecution to disprove one or more of them to the criminal standard in the usual
way.”

154. This in our view provides appropriate protection for trafficked individuals, with the legal burden resting
on the prosecution.

ix) Can a VOT seek to argue that a conviction following a guilty plea is unsafe?

155. The essence of this issue is whether an appellant who pleaded guilty but was subsequently found to
have been a VOT can nonetheless appeal against conviction. In this context, our attention is drawn
particularly to Kakaei [2021] EWCA Crim 503. This court has recently and extensively considered this issue
in _R v Tredget[2022] EWCA Crim 108._ The court determined that there are three categories of case,
albeit this is not a closed list, when a conviction can be overturned following a guilty plea. The first category
is as follows:

“154. First, there may be a variety of circumstances in which the guilty plea is vitiated. An obvious one is
where an equivocal or an unintended plea was entered. Similarly, in _R v Swain_ 1986 Crim L.R. 480 the
appellant's conviction was quashed on the basis of evidence that there was a very real risk that he had
been affected by delusion caused by L.S.D. at the time he changed his plea to guilty, and for a short time
thereafter. In those circumstances, the court held that the conviction was unsafe and unsatisfactory.

155. Equally, an appeal may be allowed when “the plea of guilty was compelled as a matter of law by an
_adverse (and, we add, wrong) ruling by the trial judge which left no arguable defence to be put before the_
_jury” (see Asiedu at paragraph 20, as endorsed in R v Fouad Kakaei_ _[2021] EWCA Crim 503 at paragraph_
75). This situation is, however, to be contrasted with the position when there is an adverse ruling by the
judge which renders the defence being advanced more difficult, even to the point of being near hopeless,
as distinct from unarguable: “A change of plea to guilty in such circumstance would normally be regarded
_as an acknowledgment of the truth of the facts constituting the offence charged” (per_ Auld LJ in _R. v_
_Chalkley [1998] 2 Cr. App. R. 79; [1998] Q.B. 848, at 94 and 864, and see Asiedu at paragraph 20). In_
such a situation a defendant who contests his guilt can plead not guilty and challenge the disputed adverse
ruling on appeal, whereas the defendant who has no defence left to put to the jury cannot.

156. Similarly, a guilty plea might be vitiated by improper pressure, for instance from the judge. In _R v_
_Nightingale_ _[[2013] EWCA Crim 405; [2013] 2 Cr App R 7, Lord Judge CJ at paragraph 16 observed,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:584X-GG21-F0JY-C0H4-00000-00&context=1519360)_

“The question is whether (the intervention) by the judge, and its consequent impact on the defendant after
considering the advice given to him by his legal advisers on the basis of their professional understanding of
the effect of what the judge has said, had created inappropriate additional pressures on the defendant and
narrowed the proper ambit of his freedom of choice.”

The court determined that the plea of guilty was, in effect, a nullity. And in R v Inns (1974) 60 Cr App R
231, Lawton LJ suggested at page 233 that,

“When the accused is making a plea of guilty under pressure and threats, he does not make a free plea
and the trial starts without there being a proper plea at all. All that follows thereafter […] is a nullity.”

157. If it is established that incorrect legal advice had been given, this too can result in the conviction being
quashed/treated as a nullity, certainly in the restricted circumstances described by Scott Baker LJ in R v
_Saik [2004] EWCA Crim 2936:_

“57. For an appeal against conviction to succeed on the basis that the plea was tendered following
erroneous advice it seems to us that the facts must be so strong as to show that the plea of guilty was not


-----

a true acknowledgment of guilt. The advice must go to the heart of the plea, so that […] the plea would not
be a free plea and what followed would be a nullity.”

158. An appeal can, however, succeed if vitiated by erroneous legal advice or a failure to advise as to a
possible defence, even where the advice may not have been so fundamental as to have rendered the plea
a nullity, if its effect was to deprive the defendant of a defence which would probably have succeeded. In
_R v Boal [1992] QB 591, it was decided that if a possible line of defence is overlooked, exceptionally the_
court will be prepared to intervene, although only if the defence would quite probably have succeeded and
the court concludes, therefore, that a clear injustice has been done (see pages 599 and 600). This
approach was endorsed in R v Mohamed (Abdalla) and others _[2010] EWCA Crim 2400; [2011] 1 Cr. App._
R. 35 (a case in which a defence under section 31 of the Immigration and Asylum Act 1999 had been
overlooked) and in _R v McCarthy [2015] EWCA Crim 1185. In the latter case, the court was “far from_
_confident that when the applicant pleaded guilty to the offence of wounding with intent he had a proper_
_understanding of the elements of the offence” (see [81]). Similarly, in R v Whatmore [1999] Crim. L.R. 87_
the court quashed the appellant's convictions on the basis that he had received misleading advice on which
he relied, rendering the convictions unsafe (he had pleaded guilty to two counts of sexual offences against
his daughter, having been led erroneously to understand that those allegations would not, as a
consequence, feature as part of the evidence during another trial). Here the pleas were in effect induced by
misleading legal advice. Waller LJ indicated at page 9:

“[…] the defendant had not admitted his guilt and was pleading on the basis that if he pleaded, the
daughter's allegations would never become part of the case at all and he was content, in effect, to take a
sentence which he had already served in return for pleading to something which he did not admit. In those
circumstances, as it seems to us, it cannot be said that the conviction on those pleas are safe.”

159. In _R v PK_ _[[2017] EWCA Crim 486 Sir Brian Leveson P. emphasised the approach just described,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NHG-R6Y1-F0JY-C538-00000-00&context=1519360)_
namely that the Court of Appeal would only intervene on the basis that the conviction was unsafe when it
believed the defendant had been deprived of what was in all likelihood a good defence in law, which would
quite probably have succeeded and, as a result, a clear injustice had been done.”

156. The second category is as follows:

“160.There is a distinct category of cases which do not depend on the circumstances in which the plea was
entered or indeed upon whether the accused is innocent or guilty, but instead arise when “there (is) a legal
_obstacle to his being tried for the offence, for instance because the prosecution would be stayed on the_
_grounds that it is offensive to justice to bring him to trial. Such cases are generally described, conveniently_
_if not entirely accurately, as cases of “abuse of process”; in these circumstances “a conviction upon a plea_
_of guilty is as unsafe as one following trial” (see Asiedu at paragraph 21). By way of example, entrapment,_
if made out, can amount to unfairness which would render it an abuse of process to try the defendant (see
_Asiedu_ at paragraph 25). So, one example of a case coming withing this second category is when an
abuse of process is established such that renders it unfair to try the defendant at all. As Lord Woolf CJ
observed in R v Togher & others [2001] 1 Cr App R 33 at paragraph 31,

“Certainly, if it would be right to stop a prosecution on the basis that it was an abuse of process, this Court
would be most unlikely to conclude that if there was a conviction despite this fact, the conviction should not
be set aside”.

The court in _Togher_ at page 161 G approved what it described as the “broad” approach adopted in _R v_
_Mullen [1999] 2 Cr App R 143; [2000] QB 520, per Rose LJ:_

"... for a conviction to be safe, it must be lawful; and if it results from a trial which should never have taken
place, it can hardly be regarded as safe. Indeed the Oxford Dictionary gives the legal meaning of 'unsafe'
as 'likely to constitute a miscarriage of justice'.”

161.A further type of case within this category is when there is a fundamental breach of the accused's right
under article 6 of the European Convention on Human Rights to a fair and public hearing by an
independent and impartial tribunal. It is unnecessary for the defendant to establish prejudice in this context
[(see R v Ilyas Hanif [2014] EWCA Crim 1678 and R v Abdroikov R v Green R v Williamson [2007] UKHL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J6F-YWD1-F0JY-C334-00000-00&context=1519360)


-----

_37, in which latter case Lord Bingham observed at paragraph 27 that “[…]_ _even a guilty defendant is_
_entitled to be tried by an impartial tribunal […]”).”_

157. As to the third category, the court determined:

“162. In the case of category 1, the ordinary consequences of the public admission of the facts which is
constituted by the plea of guilty are displaced by the fact that the plea was vitiated, whether in fact or by
reliance on error of law. In the case of category 2, the ordinary consequences of the public plea are
irrelevant, because the defendant ought not to have been subjected to the trial process (or to that form of
trial process) at all. But ordinarily, the plea of guilty, by a defendant who knows what he did or did not do,
amounts to a public admission of the facts which itself establishes the safety of the conviction. There
remains, however, a small residual third category where this cannot be said. That is where it is established
that the appellant did not commit the offence, in other words that the admission made by the plea is a false
one.”

**The Individual Appeals**

AAI CONVICTION

158. As set out above, there are two grounds of appeal. First, Mr Knight argues that the appellant was a
victim of trafficking and should not have been prosecuted. To rehearse, the offence of which he was
convicted is that he failed to comply with a notice served on him on 28 December 2007 under section 35
Asylum and Immigration (Treatment of Claimants etc.) Act 2004 requiring him to attend an interview and
answer accurately and fully questions put to him at the Sierra Leonean High Commission, with a view to
obtaining an ETD. It is contended that the nexus between his exploitation as a victim of trafficking and the
commission of the alleged offence has been made out and given the circumstances in which he committed
the offence it was not in the public interest to prosecute him.

159. We consider this contention to be unsustainable. His defence at trial was straightforward: that he was
not willing to comply because he had already attended the High Commission for an interview and there had
been two failed attempts to return him to Sierra Leone, which is a country to where he is fearful of
returning. As described above, the appellant's account of being trafficked is beset with credibility problems.
It has varied extensively over time and has frequently included descriptions of T as someone who treated
him charitably, with kindness and without any form of exploitation or coercion. In the appellant's
immigration witness statement, for instance, although he sets out devastating atrocities committed by the
SLA rebels, in contrast his description of T and another man associated with him was that they acted
entirely philanthropically. We accept in this regard the criticisms made by Mr Bisgrove of the appellant's
accounts. Not only are there fundamental inconsistencies as to what the appellant has said about T, but
there is also the rank implausibility of his trafficker sending him to England under compulsion having failed
to put in place any reception arrangements or any method for monies to be remitted to Sierra Leone. It is
improbable in the extreme that T would have paid for the appellant to travel to Europe and to insist only
that the appellant telephoned him in Sierra Leone upon arrival. In the circumstances, no sustainable nexus
has been established between his suggested exploitation as a VOT and the instant offence. Any
suggestion that when he was served with the notice on 28 December 2007 he was in fear of potential
reprisals from T is simply not credible. These factors, along with the lack of any contact with T, or anyone
on his behalf, since his arrival in the United Kingdom mean that we are satisfied that this first ground of
appeal fails. There is no basis for the suggestion that this material indicates that the appellant should not
have been prosecuted. This conclusion does not in any sense undermine the appellant's contention that he
will face multiple risks on his return to Sierra Leone; this, however, is an entirely separate consideration
from whether there is a sustainable link between human trafficking and the commission of the present
offence.

160. Second, it is averred that fresh evidence demonstrates that the appellant had a reasonable excuse
for failing to comply with the direction under section 35. The appellant contends that the psychiatric
evidence now available shows that he was being subjected to extreme psychological suffering by the
attempts to remove him to Sierra Leone and he was, as a result, unable to comply with the section 35


-----

notice. These factors, it is argued, provided a reasonable excuse. There are numerous difficulties with this
contention. It was not the appellant's case at trial that he was “unable” to participate in the process; it was,
instead, that he was “unwilling” to do so. He signed a defence statement which contained the following:

“8. In essence the defendant's case for refusing to be interviewed is that he had already been interviewed
by the High Commission, he had been sent back twice and returned and he feared for his safety if
deported to Sierra Leone.

[9. In light of the authority of R v Tabnak [2007] EWCA Crim 380; [2007] 1 WLR 1317, it is accepted that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFT1-DYBP-P232-00000-00&context=1519360)
this unwillingness would not amount to a reasonable excuse.

8. However, the defendant's fear of return to Sierra Leone and unwillingness to cooperate may amount to
an inability to do so if in fact he is suffering (from) a psychiatric illness.

9. The defence have therefore instructed a psychiatrist to ascertain whether or not this is the case.

10. The defence would therefore respectfully request any secondary disclosure that may assist in that
regard […].”

161. In this context, we are directed on the appellant's behalf to a passage in R v Tabnak, as follows:

“20. […] It is possible to envisage a situation in which a defendant would, because of apprehension for the
consequences of deportation, suffer some psychiatric illness which would prevent compliance. That might
be capable of constituting a reasonable excuse for non-compliance, […].”

162. The appellant in R v Tabnak stated that he would rather suffer the consequences of not completing a
travel document than be sent home to Iran, because his life and freedom would be at risk. In those the
circumstances it is helpful to set out the entirety of [20], in which Lord Philips C.J. said:

“The “reasonable excuse” that the appellant sought to advance in the present case was not an explanation
for his inability to comply with the Secretary of State's requirement. It was an explanation for his
unwillingness to do so. As a matter of law, reasons why a defendant is unwilling to comply with a section
35 requirement with which he is perfectly able to comply cannot constitute a reasonable excuse for noncompliance. When this proposition was put to Mr Benson, he submitted that unwillingness could become
inability. The consequences of complying with the requirement might be so dire as to overbear the will of
the defendant so that he would be unable to comply and in such circumstances his inability would be a
reasonable excuse. It is possible to envisage a situation in which a defendant would, because of
apprehension for the consequences of deportation, suffer some psychiatric illness which would prevent
compliance. That might be capable of constituting a reasonable excuse for non-compliance, but no such
case has been made in this instance. It has been made quite plain that the appellant was exercising a
power of choice when he refused to comply with the requirements of the Secretary of State.”

163. It is quite clear from the defence statement that the decision of the appellant in the instant case not to
cooperate was a matter of his free choice, irrespective of his post-traumatic stress disorder, possible
depressive illness and his unwillingness to participate. Although Professor Katona in his report of 5
November 2019 described how the appellant might have “great difficulty in giving a full account of himself”
in giving evidence in the immigration proceedings, leading to the recommendation that special measures
should be put in place for those purposes, there is no suggestion in the four principal psychiatric reports
that the appellant would not have been able to exercise free choice as to whether to cooperate in an
interview at the Sierra Leonean Embassy. His instructions to his lawyers were not that his will had been
overborne such that he was unable to comply: as we have already rehearsed, it was expressly that he was
unwilling to do so. He was not, therefore, in the words of Lord Philips C.J. “(suffering) some psychiatric
_illness which would prevent compliance”. That is not to ignore, undermine or belittle the consistent_
diagnosis of post-traumatic stress disorder and the reference to a possible depressive illness.

164. Furthermore, although given the gap in time we do not have details of the precise steps that were
taken by the defence in this context, it is clear from the passage in the defence statement set out above
that his then lawyers were acutely alive to this issue and that psychiatric evidence was being explored. In
the event no expert evidence was introduced We consider that it is right to infer in those circumstances


-----

that there was no psychiatric evidence available to the effect that he had been suffering from a psychiatric
illness that would have prevented him from complying.

165. As to the criticism of the judge's direction, no complaint was made at the time or on appeal by trial
counsel and this matter is now incapable of adjudication. We are dependent on an inadequate note made
by trial counsel, as set out at [19] above. It is impossible to have confidence that this necessarily reflects
what was said by the judge during the summing up. Moreover, given the absence of medical evidence as
well as the summing up, we are unable to identify with any confidence what were the live issues in the
case at the end of the trial. An insufficient basis has been advanced, therefore, for this aspect of the
ground of appeal.

166. We grant leave to appeal to appeal against conviction out of time, given these points were properly
arguable, and we dismiss the appeal.

167. We granted leave to introduce the evidence on which the appellant sought to rely, including the
conclusive grounds decision (to which the first question relates). We note that we attached no weight to the
part of the report of Sally Montier of 12 October 2021 (the “Independent Consultant Human Trafficking and
**_Modern Slavery”) in which she expressed her opinion that the account from the appellant of his_**
recruitment and exploitation meets the “trafficking definition”. We reiterate that the burden of her report
would not have been admissible during a trial.

AAI SENTENCE

168. As helpfully summarised by the editors of Archbold Criminal Pleading Evidence and Practice 2022 at

[7-139]:

“The court will always scrutinise with great care cases where an appellant seeks to rely on psychiatric
evidence directed to his mental state at the date of sentence that was not advanced at the time and the
decision will be fact specific in each case. Following the admission of such evidence, the court has the
power to substitute the sentence which it considers is (and always was) appropriate (Beatty [2006] EWCA
_[Crim 2359, Cleland [2020] EWCA Crim 906).”](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60C9-0GS3-GXFD-82J0-00000-00&context=1519360)_

169. We have no doubt that if the judge had been aware of the full factual background along with the
contents of the various reports that we have summarised above, especially as regards the appellant's
experiences in Sierra Leone and the psychiatric diagnosis, he would have passed a lesser sentence. In our
judgment, given the mitigation now available to the appellant based on the psychiatric material, the
sentence of 18 months' imprisonment was manifestly excessive, following a trial. We therefore grant leave
to appeal against sentence and allow the appeal, in that we quash the term of 18 months' imprisonment
and substitute a term of 12 months' imprisonment.

AAI ANONYMITY

170. On 17 September 2020 an anonymity direction was made in respect of the appellant's immigration
appeal, under Rule 13 of the Tribunal Procedure (First-tier Tribunal) (Immigration and Asylum Chamber)
Rules 2014.

171. We have borne in mind the importance of the principle of open justice. We have concluded that such
an order should be made as being both necessary and proportionate. In reaching that conclusion we have
regard to the appellant's current circumstances as someone who is at risk of trafficking in the future should
he return to Sierra Leone and to his ongoing immigration matters which have led to the grant of anonymity
in immigration proceedings. Having regard to the considerations identified in the authorities we have
concluded that it is necessary in the interests of justice for anonymity to be maintained in all the
circumstances of this case.

AAH CONVICTION

172. As we have already described, the appellant's plea to a single count of possession on 28 May 2015
of false identity documents with intent to make a gain for herself or another relates to her possession of a


-----

French passport and a French Identification document, neither of which bore her details, in order to obtain
work in a care home. It is submitted that the relevant background is that she had been forced to work in
this role by her traffickers and that previously she had been forced to provide sexual services to her
traffickers as payment. Therefore, her offending was in consequence of and compelled by the trafficking.

173. Applying, _inter alia, our conclusions on the first question, we grant leave to adduce, first, the fresh_
evidence of the decision of First-Tier Tribunal Judge Real dated 20 July 2017 in which he accepted the
appellant's account as to how she came to the United Kingdom and the events that occurred in this country
following her arrival. It was acknowledged that she fears returning to Nigeria, given she is a woman facing
forced marriage, gender-based violence and re-trafficking. Second, we give leave to adduce the decision,
of 16 August 2017 in which the SCA accepted there were conclusive grounds to believe that the appellant
was a potential victim of human trafficking. In our view it is necessary and expedient in the interests of
justice to admit this evidence. We did not, applying our decisions on questions five and six, consider it
necessary for any oral evidence, including from the appellant, to be given.

174. In light of this material, it is clear the appellant's conviction is unsafe and the appeal must be allowed.
There is no proper basis on which to depart from the Competent Authority's findings or that of the First-Tier
Tribunal. The judge determined that the appellant was trafficked into the United Kingdom; her offending
was a direct consequence of the trafficking; and she was acting under compulsion: he found that she was
coerced by reason of her vulnerability, along with her traffickers' insistence that she owed a large sum of
money, into sexual exploitation and forced labour (see [29]). We are confident that if these two decisions
had been available to the prosecution, in light of our answer to the third question, a decision would have
been taken not to prosecute the appellant; alternatively, the appellant would have been able to mount a
successful submission of abuse of process on the basis that there are no substantive grounds to dispute
that the appellant is a victim of trafficking, that there was sufficient nexus between that status and the
offending and that there is uncontradicted evidence of real compulsion (see the answer to the eighth
question).

175. As regards the ninth question, we have applied the guidance given in _R v Tredget concerning the_
circumstances when an appeal against conviction can be allowed following a guilty plea, and this case
comes within the categories when an appeal is possible.

176. In all the circumstances, the appellant's conviction is unsafe, notwithstanding her guilty plea. We
grant leave to appeal out of time and we quash the appellant's conviction. It would be against the interests
of justice to order a retrial.

AAH ANONYMITY

177. The same broad considerations apply to AAH as they did to AAI, in terms of the anonymity order
imposed by the First-Tier Tribunal and the evident risks to the appellant.

AAD CONVICTION

178. The appellant and his co-accused were charged that on 3 October 2017 they produced cannabis, a
controlled drug of Class B, in contravention of section 4(1) of the Misuse of Drugs Act 1971. He pleaded
guilty, it being accepted by him in the Crown Court that he did not want to rely on the section 45 defence
because he accepted that the telephone calls and the arrangements at the house meant that the element
of compulsion necessary for that defence were absent.

179. The central contention advanced now on the appellant's behalf is that his conviction for the offence of
cultivating cannabis is unsafe because he was acting under compulsion as a VOT and had a viable
defence under section 45. It is submitted that his status as a VOT following the Secretary of State's
conclusive decision on 1 February 2019 means that the appellant should not and, if the circumstances had
then been known, would not have been prosecuted, given there is evidence of a “reasonable nexus of
_compulsion” between the offence and the circumstances of exploitation._

180. It is argued that the advice the appellant received and his decision to plead guilty were misconceived
and he should have had the opportunity to challenge the negative decision or alternatively to run a


-----

defence under section 45. The evidence showed that he had been trafficked for the purpose of exploitation
and re-trafficked in the United Kingdom. In those circumstances the authorities should have been alerted
as to the possibility that he had been trafficked, in order for a determination to be made. The previous
representatives are criticised for failing to demonstrate a proper understanding of the “nuanced reality of
_being a victim of trafficking”. It is submitted that the offence was committed as a direct result of trafficking_
for the purposes of exploitation.

181. We are unable to accept these contentions. In accordance with our decision on question one, we
have considered the conclusive grounds decision. Although the author determined that the appellant had
been subjected to forced labour and forced criminality, and that he was unable to leave the house where
the cannabis was being grown, we are unpersuaded by critical aspects of those conclusions. Having
arrived in London and having been given a mobile telephone, he was then abandoned by those he
suggests had trafficked him to this country. It is accepted that he was then, on his own account, at liberty.
He claims that at some stage thereafter he made the acquaintance of two Vietnamese men, Binh and A
Tu, who in turn organised work for him, which on one occasion was varied when he decided he did not like
it (viz. building work). Although he suggests he was forced to tend the cannabis plants, he was able to
leave the premises (he had a key) and, having decided permanently to leave the property, he did so and
only returned because he could not find other people from Vietnam in the locality. He was able to go to the
police but decided not to seek their help because he did not have any papers. He was clearly free to make
arrangements to go out, and one of the options under discussion in one of the exchanges of messages
was a dancing outing in Leeds at a night club. Indeed, the entire contents of the significant number of
discussions on Facebook Messenger contradict the suggestion that the appellant was being forced to work
against his will. He was able communicate freely with members of his family or friends in Vietnam, without
any complaint about his situation.

182.  As set out at [145] above, the terms of the section 45 defence require that the person was
“compelled” to do the act, that the “compulsion” is attributable to slavery or to relevant exploitation and that
a reasonable person in the same situation would have had no realistic alternative. We refer back to our
conclusions on question eight. We are confident that the CPS would have decided to prosecute
notwithstanding the conclusive grounds decision, given the lack of a nexus between the offence and the
trafficking, along with the indications of a lack of compulsion even bearing in mind the conclusive grounds
decision (in this regard, see our approach to question three); similarly, any abuse of process application
against the CPS decision, provided the conclusive grounds decision was properly taken into account,
would almost certainly have failed (in this regard, see our approach to question seven). It follows we reject
the criticisms made of the appellant's legal team in the Crown Court. We did not, applying our conclusions
on questions five and six, consider it necessary for any oral evidence, including from the appellant, to be
given. The test in accordance with R v Tredget following a guilty plea has not been met, by some margin
(see [155] et seq above).

183. Leave has already been granted to appeal the appellant's conviction out of time. We dismiss the
appeal. There is no appeal against sentence.

AAD ANONYMITY

184. As with the other two appellants, we have borne in mind the importance of the principle of open
justice. We have concluded that an anonymity order should be made as being both necessary and
proportionate. In reaching that conclusion we have regard to the risk of trafficking in the future and to the
fact that the appellant is currently subject to deportation proceedings and has an outstanding protection
claim under which full consideration will be given to the risks facing him on his return to his home country,
taking account of the finding that he is a victim of modern slavery.

**End of Document**


-----

