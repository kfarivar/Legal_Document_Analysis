# R (on the application of Adesanya) v Secretary of State for the Home
 Department [2016] All ER (D) 14 (Jun)

[2016] EWHC 1165 (Admin)

Queen's Bench Division, Administrative Court (London)

EnglandandWales

Judge Jarman QC (Sitting as a Deputy Judge of the High Court)

20 May 2016

**Immigration – Detention – Unlawful detention – Claimant seeking judicial review of defendant Secretary of**
**State's decisions detaining and deporting him, and certifying human rights claim – Whether defendant**
**erring – Human Rights Act 1998, s 6 – Nationality, Immigration and Asylum Act 2002, s 94B.**
Abstract

_Immigration – Detention. The Administrative Court dismissed the claimant Nigerian national's application for judicial_
_review of the defendant Secretary of State's decisions to detain and deport him, and to certify his human rights_
_claim. The Secretary of State had been entitled to detain the claimant on public order grounds, even though there_
_were reasonable grounds to believe that he had been a victim of trafficking and she had been entitled to decide to_
_deport him on the information then available._
Digest

The judgment is available at: [2016] EWHC 1165 (Admin)

The claimant Nigerian national sought judicial review of the defendant Secretary of State's decision to detain him
from 17 June 2015, after having been released from prison where he had been remanded on an offence of assault,
until November 2015, after permission was given to bring the present claim. He also challenged the Secretary of
State's decisions to deport him and to certify his human rights claim, under _[s 94B of the Nationality, Immigration](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5CP9-GSM1-DYCN-C0JY-00000-00&context=1519360)_
and Asylum Act 2002, on the basis that, although the appeals process for that claim had not been exhausted, his
[removal to Nigeria pending the outcome of the appeal would not be lawful, under s 6 of the Human Rights Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)

The claimant contended, first, that the Secretary of State's decision dated 17 September 2015, that there were
reasonable grounds to believe that he had been a victim of trafficking should have been made earlier in June 2015
and that, consequently, he should have been released from prison and not detained in a removal centre at all. He
contended that, pursuant to Ch 55.10 of the Enforcement Instructions and Guidance (the guidance), it was only in
exceptional circumstances that a person who was potentially a victim of modern slavery should be detained and
none existed in the present case, so that the detention was unlawful. Second, the Secretary of State had erred in
her decision to deport. Third, the claimant accepted that the challenge to the Secretary of State's certification stood
or fell with the submission on the date on which the reasonable grounds decision should have been made.
Consideration was given to the Convention on Action against Trafficking in Human Beings.

The application would be dismissed.

The guidance was tolerably clear. Chapter 55.10 referred to persons identified as victims of trafficking. That was a
different category to persons in respect of whom there were reasonable grounds to believe were victims, and that


-----

distinction came out clearly in the Convention and in the guidance. The reference to persons identified as victims of
trafficking meant persons who had gone through all three stages of the process and had been conclusively decided
to be such victims. It was those persons to whom the exceptionality test for detention had to be applied (see [43] of
the judgment).

In having decided to detain the claimant, the Secretary of State had applied the right test. The Secretary of State's
conclusions as to whether there had been public order grounds which had justified continued detention had been
conclusions which had been open to her. Even if referral to the national referral mechanism for potential adult
victims of trafficking had been earlier, that would not have led to the claimant's release before November 2015. The
Secretary of State had been entitled to detain him on public order grounds and had done so until permission had
been given to proceed, at which time it had no longer appeared that deportation would be achieved within a
reasonable time. Referral should not have been made earlier. When it had been and when the reasonable ground
decision had been made, the Secretary of State had, nevertheless, been entitled to continue to detain the claimant
on public order grounds. Further, the Secretary of State's decisions to deport had not been decisions which she had
not been entitled to make on the information then available. Furthermore, as the claimant's submission with respect
to the date on which the reasonable grounds decision should have been made failed, the third ground of challenge
also had to fail (see [46], [52], [56], [58], [69], [70] of the judgment).

Rowena Moffatt (instructed by Duncan Lewis (Solicitors) Ltd) for the claimant.

Natasha Barnes (instructed by the Government Legal Department) for the Secretary of State.
Karina Weller Solicitor (NSW) (non-practising).

**End of Document**


-----

