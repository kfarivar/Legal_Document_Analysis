577

# R (on the application of A and another) v Criminal Injuries Compensation
 Authority and another [2022] 1 All ER 577

[2021] UKSC 27

SUPREME COURT

LORD LLOYD-JONES, LADY ARDEN, LORD HAMBLEN, LORD BURROWS AND LORD STEPHENS JJSC

11 NOVEMBER 2020, 9 JULY 2021

**Compensation — Criminal injuries — Entitlement to compensation — Exceptions — Persons with unspent**
**convictions resulting in custodial sentence — Victims of human trafficking — Whether application of**
**exception to victims of human trafficking amounting to unlawful discrimination — Human Rights Act 1998,**
**Sch 1, Pt I, arts 4, 14 — Criminal Injuries Compensation Scheme, para 26, Annex D, para 3.**

The claimants, both Lithuanian nationals, were trafficked in 2013 from Lithuania to the United Kingdom and
subjected to labour exploitation and abuse. Their treatment constituted criminal offences for which the traffickers
responsible were convicted. Prior and unrelated to their being trafficked to the UK, the claimants had both been
convicted in Lithuania of dishonesty offences for which they had received custodial sentences. The claimants
applied for compensation under the Criminal Injuries Compensation Scheme ('CICS') in relation to the treatment
they suffered as victims of trafficking. That application was refused by the first defendant Criminal Injuries
Compensation Authority on the basis of para 26[a] of, and para 3 of Annex D[b] to, the CICS, on the basis that they
each had an unspent conviction that had resulted in a custodial sentence. The claimants sought judicial review of
that decision. The judge held, inter alia, assuming that a person having a relevant unspent conviction had an 'other
status' for the purposes of the non-discrimination provision in art 14[c] of the European Convention for the Protection
of Human Rights and Fundamental Freedoms 1950 (as set out in Sch 1 to the Human Rights Act 1998), that the
exclusionary rule did not constitute discrimination contrary to art 14 taken in conjunction with the prohibition on
slavery and forced labour in art 4[d] against victims of crimes of violence who had unspent convictions. The Court of
Appeal dismissed the claimants' appeal. The claimants made a further appeal.

**Held – The appeal would be dismissed. The refusal to grant the claimants compensation did not amount to unlawful**
discrimination under art 14 of the Convention taken in conjunction with art 4. Article 4 did not create a general duty
to compensate victims of trafficking perpetrated by private third parties. Nonetheless, in applying the CICS to
victims of trafficking, the UK had chosen to confer a degree of protection to promote their interests which had a
more than tenuous connection with the core value of the protection of victims of

1

a Paragraph 26 is set out at [14], below.

b Annex D, so far as material, is set out at [14], below.

c Article 14 is set out at [21], below.

d Article 4 is set out at [21], below.

**[*578]**


-----

577

trafficking under art 4. The rights voluntarily conferred in that way under the CICS on victims of trafficking fell within
the general scope of art 4 and had, therefore, to be made available without discrimination. The applicants came
within the category of 'other status' (having regard to the generous interpretation now taken of that term) so as to
bring them within the scope of art 14, both on account of being victims of trafficking and as persons with unspent
convictions that resulted in a custodial sentence. However, there was no reason why victims of trafficking should be
treated differently from the victims of other crimes who also fell within the exclusionary rule. People trafficking was a
particularly grave crime and its victims, who were often vulnerable, could suffer grievously; however, many other
crimes were no less serious, their victims equally vulnerable and the consequences they suffered at least as
grievous. Although people trafficking was recognised by a number of international instruments and fell within the art
4 prohibition, none of those instruments required more favourable treatment to be accorded to victims of trafficking
so far as compensation by the state was concerned. Even assuming that it was arguable that victims of people
trafficking who had committed criminal offences in connection with their being trafficked (so-called 'nexus
offenders') were entitled to be treated differently in certain respects from other offenders, such nexus offenders
formed a sub-group of victims of trafficking who had unspent convictions into which the claimants did not fall. The
claimants' convictions related to offences committed long before they became victims of trafficking and were totally
unconnected with their being victims of trafficking. The fact that some victims of trafficking who had committed
offences would be nexus offenders could not provide a basis for requiring differential treatment for all victims of
trafficking who had committed offences, including those who, like the claimants, were not nexus offenders. In any
event, the difference in treatment on grounds of other status resulting from the exclusionary rule was justified, as
was having a bright-line rule. The rule was concerned with an area of policy in which a considerable degree of
latitude was accorded to the legislator as to the form and scope of the CICS. The object of the CICS, namely the
allocation of limited resources to deserving victims of crime as an expression of public sympathy, was such that the
legislator was entitled to adopt a scheme that operated by clearly defined rules. In particular, it was appropriate to
lay down rules as to the seriousness of offences that would disqualify possible claimants as opposed to allowing a
general discretion to be applied in individual cases by claims officers. It was also significant that the CICS had been
approved by Parliament following an extensive process of consultation (see [23], [29]–[33], [39], [46], [57], [67], [71],

[[73], [78], [83]–[85], [90]–[93], below); R v Docherty [2017] 4 All ER 263 distinguished; R (on the application of Clift)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PN2-YC81-DYBP-M2J5-00000-00&context=1519360)
_v Secretary of State for the Home Dept, R (on the application of Hindawi) v Secretary of State for the Home Dept_

_[[2007] 2 All ER 1, Rantsev v Cyprus (App no 25965/04) (2010) 28 BHRC 313, Clift v UK (App no 7205/07) [2010]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NBY-MTM0-TWP1-60SN-00000-00&context=1519360)_
_[ECHR 7205/07,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1CR-00000-00&context=1519360)_ _R (on the application of Stott) v Secretary for State for Justice_ _[[2019] 2 All ER 351 and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)_ _SM v_
_[Croatia (App no 60561/14) (2020) 49 BHRC 1 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60YX-6V73-CGXG-04PY-00000-00&context=1519360)_

[Decision of the Court of Appeal [2018] All ER (D) 17 (Jul) affirmed.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SPW-2N41-DYBP-N18D-00000-00&context=1519360)
**Notes**

For the scope of eligibility for criminal injuries compensation, see Halsbury's Laws CRIMINAL PROCEDURE vol 28
(2021) para 898.
**[*579]**

[For the Human Rights Act 1998, Sch 1, Pt I, arts 4, 14, see Halsbury's Statutes vol 7(1) (2019 reissue) 886, 889.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0GT-00000-00&context=1519360)
**Cases referred to**

_Abdulaziz v UK_ _[(1985) 7 EHRR 471, [1985] ECHR 9214/80, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0M8-00000-00&context=1519360)_

_[Artico v Italy (App no 6694/74) (1980) 3 EHRR 1, [1980] ECHR 6694/74, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1KB-00000-00&context=1519360)_

_[Bah v UK (App no 56328/07) (2011) 31 BHRC 609, (2011) 54 EHRR 773, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2W4-00000-00&context=1519360)_

_Bank Mellat v HM Treasury (No 2)_ _[[2013] UKSC 39, [2013] 4 All ER 533, [2014] AC 700, [2013] 3 WLR 179.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_

_Berezovskiy v Ukraine (App no 70908/01) (admissibility decision, 15 June 2004), ECtHR._

_[Carson v UK (App no 42184/05) (2010) 29 BHRC 22, (2010) 51 EHRR 369, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W109-00000-00&context=1519360)_


-----

577

_Chowdury v Greece (App no 21884/15) (judgment, 30 March 2017), ECtHR._

_[Clift v UK (App no 7205/07) [2010] ECHR 7205/07, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1CR-00000-00&context=1519360)_

_[Cudak v Lithuania (App no 15869/02) (2010) 30 BHRC 157, (2010) 51 EHRR 418, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W183-00000-00&context=1519360)_

_[Engel v Netherlands (App nos 5100/71, 5101/71, 5102/71) (1976) 1 EHRR 647, [1976] ECHR 5100/71, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1TH-00000-00&context=1519360)_

_[Fábián v Hungary (App no 78117/13) (2017) 44 BHRC 224, (2017) 66 EHRR 938, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SCW-MSS1-DYBP-W0FF-00000-00&context=1519360)_

_[Gerger v Turkey (App no 24919/94) [1999] ECHR 24919/94, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7R1-DYBP-X4SR-00000-00&context=1519360)_

_[K v Secretary of State for the Home Dept, Fornah v Secretary of State for the Home Dept [2006] UKHL 46, [2007] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4N1S-TYH0-TWP1-60X2-00000-00&context=1519360)_
_[All ER 671, [2007] 1 AC 412, [2007] 4 LRC 401, [2006] 3 WLR 733.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4N1S-TYH0-TWP1-60X2-00000-00&context=1519360)_

_[Kjeldsen v Denmark (App nos 5095/71, 5920/72 and 5926/72) (1976) 1 EHRR 711, [1976] ECHR 5095/71, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1T9-00000-00&context=1519360)_

_[Maktouf v Bosnia and Herzegovina (App nos 2312/08 and 34179/08) (2013) 58 EHRR 331, [2013] ECHR 2312/08,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X13K-00000-00&context=1519360)_
ECtHR.

_[Mathieson v Secretary of State for Work and Pensions [2015] UKSC 47, [2016] 1 All ER 779, [2015] 1 WLR 3250,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J5P-0TS1-DYBP-M47G-00000-00&context=1519360)_
[(2015) 146 BMLR 1.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HG8-F3D1-DYJ0-B2GX-00000-00&context=1519360)

_[Mayor and Burgesses of the London Borough of Haringey v Simawi [2019] EWCA Civ 1770, [2020] 2 All ER 701,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YX3-1X23-CGXG-03WY-00000-00&context=1519360)_

[2020] PTSR 702.

_McLaughlin's Application for Judicial Review (Northern Ireland), Re_ _[[2018] UKSC 48, [2019] 1 All ER 471, [2018] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TR3-9KC2-8T41-D42W-00000-00&context=1519360)_
[WLR 4250, [2019] NI 66, (2018) 46 BHRC 268.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W6F-T212-D6MY-P0CH-00000-00&context=1519360)

_National Union of Belgian Police v Belgium (App no 4464/70) (1976) 1 EHRR 578, ECtHR._

_[Okpisz v Germany (App no 59140/00) (2005) 42 EHRR 671, [2005] ECHR 59140/00, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1BC-00000-00&context=1519360)_

_[Petrovic v Austria (App no 20458/92) (1998) 4 BHRC 232, (1998) 33 EHRR 307, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R1J-9531-DYBP-W04M-00000-00&context=1519360)_

_[Pine Valley Developments Ltd v Ireland (App no 12742/87) (1991) 14 EHRR 319, [1991] ECHR 12742/87, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4PN-00000-00&context=1519360)_

_R (on the application of Animal Defenders International) v Secretary of State for Culture, Media and Sport [2008]_
_[UKHL 15, [2008] 3 All ER 193, [2008] 1 AC 1312, [2008] 5 LRC 687, [2008] 2 WLR 781.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SW6-XF50-TWP1-602H-00000-00&context=1519360)_

_R (on the application of Clift) v Secretary of State for the Home Dept, R (on the application of Hindawi) v Secretary_
_[of State for the Home Dept [2006] UKHL 54, [2007] 2 All ER 1, [2007] 1 AC 484, (2006) 21 BHRC 704, [2007] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NBY-MTM0-TWP1-60SN-00000-00&context=1519360)_
WLR 24.

_R (on the application of DA) v Secretary of State for Work and Pensions, R (on the_
**[*580]**

_[application of DS) v Secretary of State for Work and Pensions [2019] UKSC 21, [2020] 1 All ER 573, [2019] PTSR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y55-TKT3-GXFD-830S-00000-00&context=1519360)_
1072, [2019] 1 WLR 3289.

_[R (on the application of Haney) v Secretary of State for Justice [2014] UKSC 66, [2015] 2 All ER 822, [2015] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G0G-M5W1-DYBP-M2GS-00000-00&context=1519360)_
[1344, (2014) 38 BHRC 313, [2015] 2 WLR 76.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W3B7-00000-00&context=1519360)


-----

577

_[R (on the application of RJM) v Secretary of State for Work and Pensions [2008] UKHL 63, [2009] 2 All ER 556,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W6K-CMW0-Y96Y-G0D2-00000-00&context=1519360)_

[[2009] AC 311, (2008) 26 BHRC 587, [2008] 3 WLR 1023.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W0FC-00000-00&context=1519360)

_[R (on the application of Stott) v Secretary for State for Justice [2018] UKSC 59, [2019] 2 All ER 351, [2020] AC 51,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)_

[2018] 3 WLR 1831.

_[R (on the application of Tigere) v Secretary of State for Business, Innovation and Skills [2015] UKSC 57, [2016] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_
_[All ER 191, [2015] 1 WLR 3820, (2015) 40 BHRC 19.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_

_[R (SC) v Secretary of State for Work and Pensions [2021] UKSC 26, [2021] 3 WLR 428, [2021] All ER (D) 34 (Jul);](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:633N-TVF3-GXFD-82VG-00000-00&context=1519360)_
_affg_ _[[2019] EWCA Civ 615, [2019] 4 All ER 787, [2019] 1 WLR 5687.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XFS-06T3-GXFD-803H-00000-00&context=1519360)_

_[R (Tirkey) v Director of Legal Aid Casework [2017] EWHC 3403 (Admin), [2018] 1 WLR 2112, [2018] All ER (D) 18](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RCT-77N1-DYBP-N1X0-00000-00&context=1519360)_
_[(Jan).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RCT-77N1-DYBP-N1X0-00000-00&context=1519360)_

_[R v Docherty [2016] UKSC 62, [2017] 4 All ER 263, [2017] 1 WLR 181.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PN2-YC81-DYBP-M2J5-00000-00&context=1519360)_

_[R v Joseph [2017] EWCA Crim 36, [2017] 1 WLR 3153, [2017] All ER (D) 100 (Feb).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_

_[R v L [2013] EWCA Crim 991, [2014] 1 All ER 113, [2014] 3 LRC 1.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_

_[Rantsev v Cyprus (App no 25965/04) (2010) 28 BHRC 313, (2010) 51 EHRR 1, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

_[Schmidt v Sweden (App no 5589/72) (1976) 1 EHRR 632, [1976] ECHR 5589/72, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X107-00000-00&context=1519360)_

_[Shelley v UK (App no 23800/06) (2008) 46 EHRR SE16, [2008] Lexis Citation 4870, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4RTV-8D20-TWYV-N1CC-00000-00&context=1519360)_

_[SM v Croatia (App no 60561/14) (2020) 49 BHRC 1, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60YX-6V73-CGXG-04PY-00000-00&context=1519360)_

_[Smith v Lancashire Teaching Hospitals NHS Foundation Trust [2017] EWCA Civ 1916, (2017) 162 BMLR 1, [2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T1K-J9C1-DYJ0-B0HB-00000-00&context=1519360)_
QB 804, [2018] 2 WLR 1063.

_[Stec v UK (App nos 65731/01 and 65900/01) (2006) 20 BHRC 348, (2006) 43 EHRR 1017, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W399-00000-00&context=1519360)_

_Stuart v UK (App no 41903/98) (admissibility decision, 6 July 1999), ECtHR._

_[Thlimmenos v Greece (App no 34369/97) (2000) 9 BHRC 12, (2000) 31 EHRR 411, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3V5-00000-00&context=1519360)_

_[Zarb Adami v Malta (App no 17209/02) (2006) 20 BHRC 703, (2006) 44 EHRR 49, ECtHR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1PC-00000-00&context=1519360)_
**Appeal**

The claimants, A and B, appealed with permission from the judgment of the Court of Appeal (Gross, Sharp and
[Flaux LJJ) of 3 July 2018 ([2018] EWCA Civ 1534, [2018] 1 WLR 5361, [2018] All ER (D) 17 (Jul)) dismissing their](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SPW-2N41-DYBP-N18D-00000-00&context=1519360)
appeal from the judgment of Wilkie J of 12 January 2017 ([2017] EWHC 2 (Admin), [2017] All ER (D) 66 (Jan))
dismissing their claim for judicial review of the decision of the first defendant, the Criminal Injuries Compensation
Authority, dismissing their claim for compensation under the Criminal Injuries Compensation Scheme as victims of
trafficking, on the grounds of their previous criminal convictions. The Secretary of State for Justice was the second
defendant. The Anti Trafficking and Labour Exploitation Unit appeared as an intervener.

_Phillippa Kaufmann QC and Shu Shin Luh (instructed by Leigh Day) for the appellants._

_Ben Collins QC and Robert Moretto (instructed by the Government Legal Department) for the respondents._

_Karon Monaghan QC, James Robottom and Admas Habteslasie (instructed by Freshfields Bruckhaus Deringer_
_LLP) for the intervener (written submissions only)._


-----

577


_Judgment was reserved._

9 July 2021. The following judgment was delivered.

THE COURT ORDERED that no one shall publish or reveal the names or addresses of the Appellants who are the
subject of these proceedings or publish or reveal any information which would be likely to lead to the identification
of the Appellants or of any members of their family in connection with these proceedings.

**LORD LLOYD-JONES**

(with whom Lady Arden, Lord Hamblen, Lord Burrows and Lord Stephens agree).

**[1] The Supreme Court is asked to decide whether excluding the appellants, A and B, who are victims of human**
trafficking, from compensation under the 2012 iteration of the Criminal Injuries Compensation Scheme ('the CICS')
on the ground of their previous criminal convictions unjustifiably discriminates against them, in breach of art 14
taken with art 4 of the European Convention on Human Rights ('ECHR').

**[2] The appellants are twin brothers and Lithuanian nationals who grew up in State care in Lithuania. The first**
appellant, A, was convicted of burglary in June 2010 by a Lithuanian court and was sentenced to a three-year
custodial sentence. The second appellant, B, was convicted of theft in December 2011 by a Lithuanian court and
was sentenced to an 11-month custodial sentence. In 2013 they were trafficked from Lithuania to the United
Kingdom and subjected to labour exploitation and abuse. Their treatment between 1 June 2013 and 30 October
2013 constituted criminal offences for which, on 22 January 2016, the traffickers responsible were convicted and
were each sentenced to a custodial term of three and a half years. Slavery and trafficking prevention orders were
[made under the Modern Slavery Act 2015. The appellants' status as victims of trafficking and modern slavery is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
not disputed and is confirmed in decisions made by the National Crime Agency on 25 and 26 November 2013.

**[3] On 16 June 2016 the appellants applied to the first respondent, the Criminal Injuries Compensation Authority, for**
compensation under the CICS but on 7 July 2016 they were refused an award pursuant to the exclusionary rule
contained in para 26 and Annex D, para 3 of the CICS ('the exclusionary rule'), as they each had an unspent
conviction which resulted in a custodial sentence. Under the _[Rehabilitation of Offenders Act 1974 neither of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
appellants' convictions in Lithuania was spent at the time of their applications for compensation. A's conviction for
burglary became spent in June 2020. B's conviction for theft became spent on 11 November 2016. The effect of the
exclusionary rule was, therefore, that the appellants were automatically disqualified from receiving an award under
the CICS.

**[4] On 7 October 2016 the appellants brought judicial review proceedings to challenge the lawfulness of the**
exclusionary rule disqualifying them from receiving an award of compensation by virtue of the existence of unspent
convictions which resulted in a custodial sentence or a community order.
**[*582]**

**[5] The substantive judicial review application was heard by Wilkie J on 13 and 14 December 2016. It was heard at**
the same time as an application by Mr McNiece which also challenged the exclusionary rule. Mr McNiece, who was
not a victim of trafficking, challenged the rule as a breach of art 1 Protocol 1 ECHR and as discrimination in violation
of art 14 ECHR when read with art 1 Protocol 1. The appellants raised the same general grounds but also argued
that the exclusionary rule was incompatible with the State's obligations towards victims of trafficking (1) under art 17
[of European Parliament and Council Directive 2011/36/EU of 5 April 2011 on preventing and combating trafficking](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)
in human beings and protecting its victims ('the EU Directive') and (2) under art 1 Protocol 1 ECHR read with art 4
ECHR.

**[6] Wilkie J delivered his judgment on 12 January 2017 [2017] EWHC 2 (Admin), [2017] All ER (D) 66 (Jan). He**
accepted for the purposes of argument that the right to compensation as a victim of a crime of violence fell within
the ambit of art 1 Protocol 1 and that a person having a relevant unspent conviction had an 'other status' for the
purposes of art 14 ECHR. However, he dismissed the claim that the exclusionary rule constituted discrimination


-----

577

contrary to art 14 against victims of crimes of violence who had unspent convictions. He also dismissed the claim
that the exclusionary rule was a breach of art 1 Protocol 1 or art 4 ECHR. In addition, the appellants' claim that the
CICS constituted a violation of the EU Directive was also dismissed. He granted permission to appeal to the Court
of Appeal. Only the appellants pursued an appeal. Mr McNiece did not do so.

**[7] Before the Court of Appeal, the appellants' amended grounds of appeal raised two grounds. First, they**
maintained that the CICS is incompatible with art 17 of the EU Directive because it mandatorily excludes some
victims of trafficking from an award by virtue of their unspent convictions. Secondly, they maintained that such a
rule constituted discrimination contrary to art 14 read with art 4 ECHR. On 3 July 2018, the Court of Appeal (Gross,
[Sharp and Flaux LJJ) dismissed the appeal on both grounds [2018] EWCA Civ 1534, [2018] 1 WLR 5361, [2018] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SPW-2N41-DYBP-N18D-00000-00&context=1519360)
_[ER (D) 17 (Jul). In relation to the ground alleging discrimination contrary to art 14 the Court of Appeal found it](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SPW-2N41-DYBP-N18D-00000-00&context=1519360)_
unnecessary to reach a final conclusion as to whether the terms of access to the CICS fell within the ambit of art 4
ECHR, but proceeded on the assumption that they do. The Court of Appeal held that the appellants, by reason of
their unspent convictions of the relevant kind, enjoyed an 'other status' for the purposes of art 14 ECHR. However,
the Court of Appeal held that the discriminatory effect of the exclusionary rule was justified with the result that there
was no violation of art 14 ECHR. The Court of Appeal also dismissed the claim that the CICS constituted a violation
of the EU Directive.

**[8] On 6 November 2019 the Supreme Court granted the appellants permission to appeal on the ground that the**
exclusionary rule constitutes unjustified discrimination in breach of art 14 read with art 4 ECHR.
**Legal provisionsCriminal Injuries Compensation Scheme**

**[9] The CICS is a statutory scheme made by the second respondent, the Secretary of State for Justice, pursuant to**
the _[Criminal Injuries Compensation Act 1995 ('the 1995 Act'). The 1995 Act was passed following the United](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61G0-TWPY-Y0WD-00000-00&context=1519360)_
Kingdom's ratification of and the entry into force of the European Convention on the Compensation of Victims of
Violent Crimes 1983. By art 1 contracting
**[*583]**

states undertake to take the necessary steps to give effect to the principles set out in Pt I of that Convention
including the following set out in art 2:

'1. When compensation is not fully available from other sources the State shall contribute to compensate:

a. those who have sustained serious bodily injury or impairment of health directly attributable to an intentional
crime of violence;

b. the dependants of persons who have died as a result of such crime.

2. Compensation shall be awarded in the above cases even if the offender cannot be prosecuted or punished.'

Article 8 recognises that the State may reduce or refuse compensation in certain cases. It provides that:

'1. Compensation may be reduced or refused on account of the victim's or the applicant's conduct before,
during or after the crime, or in relation to the injury or death.

2. Compensation may also be reduced or refused on account of the victim's or the applicant's involvement in
organised crime or his membership of an organisation which engages in crimes of violence.

3. Compensation may also be reduced or refused if an award or a full award would be contrary to a sense of
justice or to public policy (ordre public).'

**[10] Section 1(1) of the 1995 Act sets out the duties of the Secretary of State in respect of arrangements for a**
compensation scheme. It provides that the Secretary of State:


-----

577

'shall make arrangements for the payment of compensation to, or in respect of, persons who have sustained
one or more criminal injuries.'

By s 1(2):

'Any such arrangements shall include the making of a scheme providing, in particular, for—

(a) the circumstances in which awards may be made; and

(b) the categories of person to whom awards may be made.'

Section 3(1)(a) of the 1995 Act provides that the compensation scheme may, in particular, include provision 'as to
the circumstances in which an award may be withheld or the amount of compensation reduced'.

**[11] Section 11 of the 1995 Act provides:**

'(1) Before making the Scheme, the Secretary of State shall lay a draft of it before Parliament.

(2) The Secretary of State shall not make the Scheme unless the draft has been approved by a resolution of
each House.'

The CICS was made in accordance with this procedure, following a consultation in 2012. It came into force in
November 2012.

**[12] Compensation may be awarded to victims of trafficking who have suffered a criminal injury directly attributable**
to a crime of violence in accordance with the terms of the CICS. The CICS provides in relevant part:

'10. A person is eligible for an award under this Scheme only if:

[…]

**[*584]**

(c) one of the conditions in paragraph 13 is satisfied in relation to them on the date of their application under
this Scheme.

[…]

13. The conditions referred to in paragraph 10(c) are that the person has:

(a) been referred to a competent authority as a potential victim of trafficking in human beings; or

[(b) made an application for asylum under Immigration Rules made under section 3(2) of the Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y09P-00000-00&context=1519360)
1971.

[…]

16. In paragraphs 13 and 15:

(a) a person is conclusively identified as a victim of trafficking in human beings when, on completion of the
identification process required by Article 10 of the Council of Europe Convention against Trafficking in Human
Beings (CETS No.197, 2005), a competent authority concludes that the person is such a victim;

(b) “competent authority” means a person who is a competent authority of the United Kingdom for the purpose
of that Convention; and

(c) “victim of trafficking in human beings” has the same meaning as under that Convention.'


-----

577

**[13] Paragraph 87 of the CICS provides that claims for compensation must be made 'as soon as reasonably**
practicable after the incident giving rise to the criminal injury to which it relates, and in any event within two years
after the date of that incident.' However, under para 89, a claims officer has discretion to extend the two-year time
limit where the officer is satisfied that: (a) due to exceptional circumstances the applicant could not have applied
earlier; and (b) the evidence presented in support of the application means that it can be determined without further
extensive enquiries.

**[14] The exclusionary rule which excluded the appellants from receiving an award is to be found in para 26 and**
Annex D of the CICS. Paragraph 26 provides:

'Annex D sets out the circumstances in which an award under this Scheme will be withheld or reduced because
the applicant to whom an award would otherwise be made has unspent convictions.'

Annex D provides in relevant part:

'2. Paragraphs 3 to 6 do not apply to a spent conviction. “Conviction”, “service disciplinary proceedings”, and
“sentence” have the same meaning as under the _[Rehabilitation of Offenders Act 1974,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_ and whether a
conviction is spent, or a sentence is excluded from rehabilitation, will be determined in accordance with that
Act.

3. An award will not be made to an applicant who on the date of their application has a conviction for an
offence which resulted in:

(a) a sentence excluded from rehabilitation;

(b) a custodial sentence;

(c) a sentence of service detention;

(d) removal from Her Majesty's service;

(e) a community order;

(f) a youth rehabilitation order; or

**[*585]**

(g) a sentence equivalent to a sentence under sub-paragraphs (a) to (f) imposed under the law of Northern
Ireland or a member state of the European Union, or such a sentence properly imposed in a country outside
the European Union.

4. An award will be withheld or reduced where, on the date of their application, the applicant has a conviction
for an offence in respect of which a sentence other than a sentence specified in paragraph 3 was imposed
unless there are exceptional reasons not to withhold or reduce it.

5. Paragraph 4 does not apply to a conviction for which the only penalty imposed was one or more of an
endorsement, penalty points or a fine under Schedule 2 to the Road Traffic Offenders Act 1988.

6. Paragraphs 3 and 4 do not apply in relation to a sentence under the law of a country outside the United
Kingdom for conduct which on the date of conviction did not constitute a criminal offence under the law of any
part of the United Kingdom.'

_Council of Europe Convention on Action against Trafficking in Human Beings_

**[15] The Council of Europe Convention on Action against Trafficking in Human Beings, Warsaw, 16 May 2005**
('ECAT') sets out the purposes of ECAT in art 1, as follows:

'a to prevent and combat trafficking in human beings while guaranteeing gender equality;


-----

577

b. to protect the human rights of the victims of trafficking, design a comprehensive framework for the protection
and assistance of victims and witnesses, while guaranteeing gender equality, as well as to ensure effective
investigation and prosecution;

c. to promote international cooperation on action against trafficking in human beings.'

Article 2 confirms that ECAT 'shall apply to all forms of trafficking in human beings, whether national or
transnational, whether or not connected with organised crime'. Article 3 sets out the non-discrimination principle. It
provides that:

'The implementation of the provisions of [ECAT] by Parties, in particular the enjoyment of measures to protect
and promote the rights of victims, shall be secured without discrimination on any ground such as sex, race,
colour, language, religion, political or other opinion, national or social origin, association with a national
minority, property, birth or other status.'

**[16] Article 15 of ECAT addresses compensation and legal redress. It provides in relevant part:**

'3. Each Party shall provide, in its internal law, for the right of victims to compensation from the perpetrators.

4. Each Party shall adopt such legislative or other measures as may be necessary to guarantee compensation
for victims in accordance with the conditions under its internal law, for instance through the establishment of a
fund for victim compensation or measures or programmes aimed at social assistance and social integration of
victims, which could be funded by the assets resulting from the application of measures provided in Article 23.'

**[*586]**

Article 23 addresses sanctions and other measures.

**[17] Article 26 is headed 'Non-punishment provision' and provides:**

'Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of not
imposing penalties on victims for their involvement in unlawful activities, to the extent that they have been
compelled to do so.'

**[18] Article 40(1) provides that ECAT 'shall not affect the rights and obligations derived from other international**
instruments to which Parties to [ECAT] are Parties or shall become Parties and which contain provisions on matters
governed by [ECAT] and which ensure greater protection and assistance for victims of trafficking.'

_[EU Directive 2011/36/EU of the European Parliament and of the Council of 5 April 2011 on preventing and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_
_combating trafficking in human beings and protecting its victims_

**[19] In April 2011, the European Union adopted the EU Directive, which builds on the obligations set out in ECAT to**
provide an EU framework for protecting and promoting the rights of victims of trafficking. Recital (1) records, inter
alia, that human trafficking is a serious crime, a gross violation of fundamental rights and that combating trafficking
is a priority for the European Union and its member states. Recital (7) notes that the EU Directive adopts 'an
integrated, holistic, and human rights approach' to the fight against human trafficking. Recital (18) emphasises that
it is necessary for victims of human trafficking to be able to exercise their rights 'effectively':

'Therefore assistance and support should be available to them before, during and for an appropriate time after
criminal proceedings. Member States should provide for resources to support victim assistance, support and
protection. …'

Recital (19) provides that victims of trafficking should be given access without delay to legal counselling and, in
accordance with the role of victims in the relevant justice systems, to legal representation, including for the purpose
of claiming compensation.


-----

577

**[20] Article 8 (Non-prosecution or non-application of penalties to the victim) provides that:**

'Member states shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties on
victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2 [ie
trafficking offences].'

Article 17 (Compensation to victims) provides:

'Member States shall ensure that victims of trafficking in human beings have access to existing schemes of
compensation to victims of violent crimes of intent.'

_European Convention on Human Rights_

**[21] The appellants claim that the exclusionary rule constitutes unjustified discrimination contrary to arts 4 and 14**
ECHR, which provide respectively:
**[*587]**

Article 4 (Prohibition of slavery and forced labour):

'1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.'

Article 14 (Prohibition of discrimination):

'The enjoyment of the rights and freedoms set forth in this Convention shall be secured without discrimination
on any ground such as sex, race, colour, language, religion, political or other opinion, national or social origin,
association with a national minority, property, birth or other status.'

**Discrimination under article 14 ECHR**

**[[22] In R (on the application of DA) v Secretary of State for Work and Pensions [2019] UKSC 21, [2020] 1 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y55-TKT3-GXFD-830S-00000-00&context=1519360)**
_[573, [2019] PTSR 1072Lady Hale helpfully set out (at para [136]) the four questions which arise in connection with](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y55-TKT3-GXFD-830S-00000-00&context=1519360)_
a complaint of discrimination under art 14 ECHR:

'… In deciding complaints under art 14, four questions arise: (i) Does the subject matter of the complaint fall
within the ambit of one of the substantive Convention rights? (ii) Does the ground upon which the complainants
have been treated differently from others constitute a “status”? (iii) Have they been treated differently from
other people not sharing that status who are similarly situated or, alternatively, have they been treated in the
same way as other people not sharing that status whose situation is relevantly different from theirs? (iv) Does
that difference or similarity in treatment have an objective and reasonable justification, in other words, does it
pursue a legitimate aim and do the means employed bear “a reasonable relationship of proportionality” to the
aims sought to be realised (see _Stec v UK (App no 65731/01)_ _[(2006) 20 BHRC 348, (2006) 43 EHRR 1017](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W399-00000-00&context=1519360)_
(para 51))?'

**Ambit**

**[23] Article 14 ECHR is not a freestanding prohibition of discriminatory treatment. It prohibits discrimination only in**
the context of the enjoyment of the rights and freedoms set out in the ECHR. As a result, it is necessary to
determine whether the subject matter of the complaint is sufficiently closely connected with one of the substantive
ECHR rights so as to fall within its ambit or scope. In the present case the appellants maintain that the exclusionary
rule set out in para 26 and Annex D para 3 of the CICS constitutes unjustified discrimination against them contrary
to art 14 when read in conjunction with art 4 ECHR. In order to satisfy this requirement, they do not need to
establish that the measure violates or interferes with their rights under art 4. They need only establish that it is
sufficiently closely linked to art 4 to bring art 14 into play (Mathieson v Secretary of State for Work and Pensions

_[[2015] UKSC 47, [2016] 1 All ER 779, [2015] 1 WLR 3250(para [17]) per Lord Wilson).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J5P-0TS1-DYBP-M47G-00000-00&context=1519360)_


-----

577

**[24] On behalf of the appellants Ms Phillippa Kaufmann QC submits that the present case falls within the ambit of**
art 4 on the following grounds. First, she says that art 4 imposes on states a duty to make provision for
compensation of victims of trafficking. Secondly, she submits in the alternative that discrimination in the enjoyment
of the guarantees conferred by the CICS falls within the ambit of art 4. Here she submits that even if art 4 does not
impose a duty on states to make provision for compensation for victims of trafficking, the respondent has
nonetheless chosen to confer the benefits of the CICS on
**[*588]**

victims of trafficking and, as a result, discrimination in respect of the enjoyment of the guarantees under the CICS
falls within the ambit of art 4.

**[25] Mr Ben Collins QC on behalf of the respondents founds his response on** _Stuart v UK (App no 41903/98)_
(admissibility decision, 6 July 1999), an admissibility decision of the European Court of Human Rights ('the ECtHR').
There the applicant, who had many years earlier been a victim of child sex abuse, complained that under an earlier
version of the CICS she was excluded from obtaining compensation because the injury was suffered before 1
October 1979 and the victim and assailant were living together at the time as members of the same family. The
ECtHR held that the state's positive obligation under arts 3 and 8 ECHR could not be interpreted as requiring a
state to provide compensation to the victims of ill-treatment administered by private individuals. Furthermore, it held,
with regard to a complaint of discrimination under art 14 taken in conjunction with arts 3, 8 and 13, that since the
scope of the positive obligation under arts 3 and 8 did not extend to the payment by the state of compensation for
injuries caused by the criminal acts of private persons, it followed that arts 13 and 14 were not, therefore applicable.
This was because there could be no room for their application unless the facts at issue fell within the ambit of one
or more of the other rights and freedoms protected under the ECHR. The respondents submit that this provides a
complete answer to both limbs of the appellants' case on ambit and that the appellants' case therefore fails at the
first hurdle.

**[26] It is necessary to consider the way in which the Strasbourg jurisprudence in this area has developed in the two**
decades since the decision in Stuart. The two limbs of the appellants' case will be considered in turn.
_A duty on States to make provision for compensation for victims of trafficking_

**[27]** _[Rantsev v Cyprus (App no 25965/04) (2010) 28 BHRC 313, (2010) 51 EHRR 1 is significant in that it was the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_
first occasion on which the ECtHR acknowledged that trafficking falls within the scope of art 4. Having referred to
the threat that trafficking presents to the human dignity and fundamental freedoms of its victims and having referred
to the obligation to interpret the ECHR in the light of present-day conditions, the Court did not consider it necessary
to identify whether such treatment constituted slavery, servitude or forced and compulsory labour. Instead it simply
concluded (at para 282) that trafficking itself fell within the scope of art 4. The Court then went on to set out general
principles in relation to art 4. It emphasised (at paras 284–285) that the spectrum of safeguards set out in national
legislation must be adequate to ensure the practical and effective protection of the rights of victims or potential
victims of trafficking. The Court reiterated that art 4 entails a specific positive obligation to penalise and prosecute
effectively any act aimed at maintaining a person in a situation contrary to art 4. It observed that the Protocol to
Prevent, Suppress and Punish Trafficking in Persons, especially Women and Children, supplementing the United
Nations Convention against Transnational Organised Crime 2000 ('the Palermo Protocol') and ECAT referred to the
need for a comprehensive approach to combat trafficking which includes measures to prevent trafficking and to
protect victims, in addition to measures to punish traffickers. It considered that it was clear from the provisions of
those two instruments that only a combination of measures addressing all three aspects could be effective in the
fight against trafficking. The extent of the positive obligations arising under art 4 was required to be
**[*589]**

considered within this broader context. The judgment in _Rantsev does not, however, provide any support for the_
proposition that states are under an obligation to provide compensation to the victims of trafficking perpetrated by
private third parties.


-----

577

**[28]** _Chowdury v Greece (App no 21884/15) (judgment, 30 March 2017) concerned the treatment of Bangladeshi_
migrants working without work permits on a strawberry farm in Greece. When they asked for their wages, the Greek
farmers fired on them, seriously injuring a number of them. The ECtHR (First Section) (at paras 86–89) reiterated
that states have positive obligations, in particular to prevent human trafficking and protect the victims thereof and to
adopt criminal law provisions which penalise such practices. It identified three strands. First, states are required to
adopt a comprehensive approach and to put in place, in addition to the measures aimed at punishing the traffickers,
measures to prevent trafficking and to protect the victims. Secondly, in certain circumstances, the state will be
under an obligation to take operational measures to protect actual or potential victims of treatment contrary to art 4.
Thirdly, art 4 imposes a procedural obligation to investigate potential trafficking situations. On behalf of the
appellants Ms Kaufmann draws attention to the following passage in the judgment of the Court at para 126:

'Lastly, the Court finds that, even though T.A. and one of the armed guards were found guilty of grievous bodily
harm, the Assize Court only ordered them to pay compensation of EUR 1,500, i.e. EUR 43 per injured worker
… However, Article 15 of the Council of Europe's Anti-Trafficking Convention obliges Contracting States,
including Greece, to provide in their domestic law for the right of victims to receive compensation from the
perpetrators of the offence, and to take steps to, inter alia, establish a victim compensation fund.'

Ms Kaufmann places particular emphasis on the closing words which, she submits, are a recognition by the ECtHR
that there is an obligation on states to provide compensation to victims of trafficking.

**[29] I am unable to accept this submission. It is made clear by the heading to the section of the judgment in which**
this passage appears that it is concerned with the State's positive obligations in relation to the effectiveness of the
investigation and judicial proceedings. As William Davis J explained in R (Tirkey) v Director of Legal Aid Casework

_[2017] EWHC 3403 (Admin), [2018] 1 WLR 2112(para [43]), in Chowdury the Court was addressing the failure of_
the police to investigate and the failure of the judicial system to reach appropriate findings in relation to the status of
the victims. In the passage on which particular reliance is placed, the Court added the observation that this level of
compensation for such serious injuries did not meet the requirements of art 15 of ECAT. The Court was not
addressing any obligation on the state to pay compensation to victims of trafficking but the obligations of the
perpetrators of trafficking to pay compensation and the state's obligation to secure effective judicial remedies for the
vindication of the rights of victims against perpetrators. Moreover, it is highly significant that in the earlier section of
its judgment, in which it set out certain general principles relating to art 4 (at paras 86–89), the Court made no
reference to a general duty on states to compensate victims of trafficking perpetrated by private third parties. Had it
been the Court's intention to recognise such a duty, such a development in the law would undoubtedly have been
given considerable prominence.
**[*590]**

**[[30] In SM v Croatia (App no 60561/14) (2020) 49 BHRC 1 a Grand Chamber of the ECtHR stated (at para 305)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60YX-6V73-CGXG-04PY-00000-00&context=1519360)**
that the nature and scope of the positive obligations under art 4 ECHR were set out comprehensively in Rantsev.
The Grand Chamber then set out paras 283 to 288 of Rantsev and concluded at para 306:

'It follows from the above that the general framework of positive obligations under art 4 includes: (1) the duty to
put in place a legislative and administrative framework to prohibit and punish trafficking; (2) the duty, in certain
circumstances, to take operational measures to protect victims, or potential victims, of trafficking; and (3) a
procedural obligation to investigate situations of potential trafficking. In general, the first two aspects of the
positive obligations can be denoted as substantive, whereas the third aspect designates the States' (positive)
procedural obligation.'

Once again, there is nothing here to support the existence of a general duty to compensate victims of trafficking
perpetrated by private third parties for which the appellants contend.

**[31] On behalf of the appellants it is further submitted that the state's positive obligations under art 4 must be**
construed in the light of ECAT and that, as a result of art 15(4) of ECAT, art 4 imposes on states a positive
obligation to provide compensation to the victims of trafficking. It is submitted that this conclusion is supported by
the position of art 15 in Ch III of ECAT the title of which makes clear that it is directed at measures to protect and


-----

577

promote the rights of victims. It is correct that the ECtHR has had regard to the provisions of ECAT in its
consideration of art 4 ECHR as applicable to trafficking (see, for example, Rantsev at paras 285–286; Chowdury at
paras 104, 126; _SM v Croatia at para 295) and that, as a result, ECAT has influenced the development of art 4_
ECHR in certain respects. Nevertheless, there are several difficulties in the path of this submission on behalf of the
appellants.

**[32] First, art 15(4) ECAT does not impose on contracting states a general obligation of the kind for which the**
appellants contend. It provides that each party 'shall adopt such legislative or other measures as may be necessary
to guarantee compensation for victims in accordance with the conditions under its internal law'. It then goes on to
give examples, stating that this may be achieved 'through the establishment of a fund for victim compensation or
measures or programmes aimed at social assistance and social integration of victims'. The Explanatory Report to
ECAT makes clear (at para 198) that the setting up of a compensation fund is a suggestion and not an obligation. It
is one option open to a contracting state. Other options, it seems, would not involve the payment of compensation
but programmes of social assistance and social integration.

**[33] Secondly, although the United Kingdom is a party to ECAT and its provisions are binding on the United**
Kingdom in international law, they have not been incorporated into domestic law within the United Kingdom. The
provisions of ECAT are, therefore, not directly applicable in this jurisdiction. They have effect here only to the extent
that they are adopted and given effect by art 4 ECHR. The approach adopted by the ECtHR has not involved a
wholesale adoption of the provisions of ECAT. On the contrary, the Court made clear in Rantsev (at para 274) that
it was necessary to take account of any relevant rules and principles of international law applicable between the
contracting parties and that the ECHR should so far as possible be interpreted in harmony with other rules of
international law of which it forms part.
**[*591]**

Similarly, in Chowdury (at para 104) and SM v Croatia (at para 295) the Court considered that the member states'
positive obligations under art 4 must be construed in the light of ECAT. It does not follow that, as a result, the
obligations undertaken by contracting states in art 4 ECHR are necessarily co-extensive with those under ECAT or
that obligations under ECAT may simply be read across. In this instance, I am not persuaded that the ECtHR has
yet gone so far as to accept that art 4 ECHR imposes an obligation on contracting states to provide financial
compensation to victims of trafficking perpetrated by private third parties. However, it is not necessary to express a
concluded view on this issue because of the conclusion to which I have come on the appellants' alternative case.
_Discrimination in the enjoyment of the scheme: modalities_

**[34] The appellants submit that even if the United Kingdom is not required under art 4 ECHR to extend its**
compensation scheme to the victims of trafficking, the fact that the respondents have chosen to guarantee the
rights under the CICS for the benefit of trafficking victims is sufficient to bring their complaint within the ambit of art
4. The United Kingdom has chosen by the application of the CICS to confer a form of protection to promote the
rights of victims of trafficking and in doing so it is applying a measure that has a sufficient connection with the core
values protected by art 4.

**[[35] In Petrovic v Austria (App no 20458/92) (1998) 4 BHRC 232, (1998) 33 EHRR 307 Mr Petrovic complained that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R1J-9531-DYBP-W04M-00000-00&context=1519360)**
the refusal of the Austrian authorities to grant him parental leave allowance, on the ground that the allowance was
only available to mothers, amounted to discrimination against him on grounds of sex. The ECtHR considered that
the refusal could not amount to a failure to respect family life, since art 8 did not impose any positive obligation on
states to provide such financial assistance. Nevertheless, the allowance paid by the state was intended to promote
family life:

'The court has said on many occasions that art 14 comes into play whenever “the subject-matter of the
disadvantage … constitutes one of the modalities of the exercise of a right guaranteed” (see National Union of
_Belgian Police v Belgium (1975) 1 EHRR 578 at 592–593 (para 45)) or the measures complained of are “linked_
to the exercise of a right guaranteed” (see Schmidt v Sweden 1 EHRR 632 at 645 (para 39)).' (Paragraph 28.)


-----

577

The Court considered (at para 29) that by granting parental leave allowance states are able to demonstrate their
respect for family life within the meaning of art 8. The allowance therefore came within the scope of that provision
and it followed that art 14 taken with art 8 was applicable. Similarly, in Okpisz v Germany (App no 59140/00) (2005)
42 EHRR 671, _[[2005] ECHR 59140/00 the ECtHR held that, although there was no entitlement under art 8 to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1BC-00000-00&context=1519360)_
receive child benefits, by granting such benefits states were able to demonstrate their respect for family life within
art 8 and such benefits accordingly came within the scope of that provision.

**[[36] In Smith v Lancashire Teaching Hospitals NHS Foundation Trust [2017] EWCA Civ 1916, (2017) 162 BMLR 1,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T1K-J9C1-DYJ0-B0HB-00000-00&context=1519360)**

[2018] QB 804Sir Terence Etherton MR cited the relevant passages from _Petrovic at para [42] and continued at_
para [55]:

'… The claim is capable of falling within art 14 even though there has been no infringement of art 8. If the state
has brought into existence a positive measure which, even though not required by art 8, is a modality of the
exercise of the rights guaranteed by art 8, the state will be in breach of

**[*592]**

art 14 if the measure has more than a tenuous connection with the core values protected by art 8 and is
discriminatory and not justified. It is not necessary that the measure has any adverse impact on the
complainant in a positive modality case other than the fact that the complainant is not entitled to the benefit of
the positive measure in question.'

In Re McLaughlin's Application for Judicial Review (Northern Ireland) _[[2018] UKSC 48, [2019] 1 All ER 471, [2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TR3-9KC2-8T41-D42W-00000-00&context=1519360)_
1 WLR 4250Lady Hale observed (at para [22]) that this may turn out to be too restrictive a test, pointing out that
'core values' is a concept derived from the domestic rather than the Strasbourg jurisprudence.

**[37] In this regard, Mr Collins submits with some force on behalf of the respondents that** _Stuart prevents the_
application of such an approach to the voluntary extension of the benefit of the compensation scheme. He resists
the suggestion that the law has significantly moved on since _Stuart was decided in July 1999. In particular, the_
approach followed in Petrovic, was plainly well understood at the time Stuart was decided and Petrovic was based
on earlier authority, as appears from para 28, cited above. Furthermore, although the Strasbourg jurisprudence on
positive obligations has certainly developed since _Stuart was decided in 1999, the Court in that case recognised_
positive obligations on the state to protect individuals from, in the context of Stuart, torture or inhuman or degrading
treatment, or grave interferences with private life.

**[38] Nevertheless, it is apparent that this is an area where the law has moved on and the attitude of the ECtHR has**
changed. While 'the English courts have made rather heavy weather of the ambit point' (Re McLaughlin, para [20]
per Lady Hale) the ECtHR has taken a much more relaxed approach to the issue. This is apparent from Zarb Adami
_[v Malta (App no 17209/02) (2006) 20 BHRC 703, (2006) 44 EHRR 49. Mr Adami complained of discrimination on](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1PC-00000-00&context=1519360)_
grounds of sex in respect of his call for compulsory jury service. He relied, inter alia, on art 4 in conjunction with art
14. The ECtHR held that although art 4(3)(d) excludes 'any work or service which forms part of normal civic
obligations' from the prohibition in art 4(2) on 'forced or compulsory labour', the fact that a situation corresponded to
a normal civic obligation did not preclude the applicability of art 4 in conjunction with art 14. The concurring
judgment of the President, Judge Sir Nicolas Bratza, is particularly illuminating. He observed (at para 7):

'The central question which arises is what constitutes “the ambit” of one of the substantive Articles, in this case
art 4. It has been argued that “even the most tenuous links with another provision in the convention will suffice”
for art 14 to be engaged (see Grosz, Beatson and Duffy The 1998 Act and the European Convention …, para
C14–10). Even if this may be seen as going too far, it is indisputable that a wide interpretation has consistently
been given by the court to the term “within the ambit”. Thus, according to the constant case law of the court,
the application of art 14 not only does not presuppose the violation of one of the substantive convention rights
or a direct interference with the exercise of such right, but it does not even require that the discriminatory
treatment of which complaint is made falls within the four corners of the individual rights guaranteed by the
article. This is best illustrated by the fact that art 14 has been held to cover not only the enjoyment of the rights


-----

577

that states are obliged to safeguard under the convention but also those rights and freedoms that a state has
chosen

**[*593]**

to guarantee, even if in doing so it goes beyond the requirements of the convention (see eg Case Relating to
_Certain Aspects of the Laws on the Use of Languages in Education in Belgium_ _[[1968] ECHR 1474/62 at para 9;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X20R-00000-00&context=1519360)_
_Abdulaziz v UK … at para 71). This would indicate in my view that the “ambit” of an article for this purpose_
must be given a significantly wider meaning than the “scope” of the particular rights defined in the article itself.
Thus, in the specific context of art 4 of the convention, the fact that work or service falling within the definition of
“normal civic obligations” in para 3 are expressly excluded from the scope of the right guaranteed by para 2 of
that article, in no sense means that they are also excluded from the ambit of the article seen as a whole.'

**[39] In the present case, while the CICS is not limited to victims of trafficking, it extends its benefits to them. In the**
preparation of the scheme specific attention was paid to its application to victims of trafficking and provisions
included in order to accommodate them. (See paras 10(c), 13–16 of the CICS.) The United Kingdom, in applying
the scheme to victims of trafficking, has chosen to confer a degree of protection to promote their interests. I
consider that in doing so it is applying a measure which has a more than tenuous connection with the core value of
the protection of victims of trafficking under art 4. The rights voluntarily conferred in this way under the scheme on
victims of trafficking fall within the general scope of art 4 and must, therefore, be made available without
discrimination.
**Status**

**[40] Article 14 ECHR provides that the enjoyment of the rights and freedoms set out in the Convention shall be**
secured 'without discrimination on any ground such as sex, race, colour, language, religion, political or other
opinion, national or social origin, association with a national minority, property, birth or other status'. It provides a list
of grounds on which discrimination is prohibited. The list is non-exhaustive as appears from the words 'on any
ground such as' and the inclusion of 'other status'. Nevertheless, the provision is clearly not intended to cover
differential treatment on any ground whatsoever, because this would make the list of grounds in art 14 otiose. In the
present case, the treatment of which the appellants complain does not fall within any of the specific grounds listed
in art 14 and they must, therefore, demonstrate that they enjoy some 'other status' for the purpose of art 14.

**[41] The concept of status in art 14 has developed through the jurisprudence of the ECtHR. In Clift v UK (App no**
[7205/07) [2010] ECHR 7205/07 the ECtHR, Fourth Section observed at para 55:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1CR-00000-00&context=1519360)

'Article 14 does not prohibit all differences in treatment but only those differences based on an identifiable,
objective or personal characteristic, or “status”, by which persons or groups of persons are distinguishable from
one another (see _Kjeldsen Busk Madsen and Pedersen, …, para 56;_ _Berezovskiy v Ukraine [2004] ECHR_
70908/01, 15 June 2004; and Carson, …, paras 61 and 70). Article 14 lists specific grounds which constitute
“status” including, _inter alia, sex, race and property. However, the list set out in art 14 is illustrative and not_
exhaustive, as is shown by the words “any ground such as” (in French “notamment”) (see Engel, …, para 72;
and Carson, …, para 70) and the inclusion in the list of the phrase “any other status” (in French “toute autre
_situation”). …'_

**[*594]**

**[42] In that case the ECtHR gave a broad meaning to 'any other status' in art 14. In particular, it rejected (at para**
56) earlier notions that 'any other status' must relate to innate or inherent characteristics:

'The Court recalls that the words “other status” (and a fortiori the French “toute autre situation”) have generally
been given a wide meaning (see _Carson, cited above, para 70). The Government have argued for a more_
limited interpretation, calling in particular for the words to be construed _ejusdem generis with the specific_
examples listed in art 14. The Court observes at the outset that while a number of the specific examples relate
to characteristics which can be said to be “personal” in the sense that they are innate characteristics or


-----

577

inherently linked to the identity or the personality of the individual, such as sex, race and religion, not all of the
grounds listed can be thus characterised. …'

In this regard the Court drew attention to the inclusion in art 14 of property as a prohibited ground of discrimination
and the fact that this ground had been broadly construed by the Court. With regard to 'other status' it considered it
unsurprising that this had been held to include innate or inherent characteristics such as sexual orientation or
physical disabilities, but went on to point out that in finding violations of art 14 in a number of other cases the Court
had accepted that status existed where the distinction could not be said to involve a characteristic which was innate
or inherent. The examples it gave included military rank (Engel v Netherlands (App nos 5100/71, 5101/71, 5102/71)
_[(1976) 1 EHRR 647, [1976] ECHR 5100/71), the possession of planning permission (Pine Valley Developments Ltd](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1TH-00000-00&context=1519360)_
_[v Ireland (App no 12742/87) (1991) 14 EHRR 319, [1991] ECHR 12742/87) or being a convicted prisoner (Shelley v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4PN-00000-00&context=1519360)_
_UK (App no 23800/06) (2008) 46 EHRR SE16). The Court then went on (at para 60) to address the issue of status_
in terms which, at the very least, suggest disapproval of an over-technical approach.

'… The question whether there is a difference of treatment based on a personal or identifiable characteristic in
any given case is a matter to be assessed taking into consideration all of the circumstances of the case and
bearing in mind that the aim of the Convention is to guarantee not rights that are theoretical or illusory but
rights that are practical and effective (see Artico v Italy _[[1980] ECHR 6694/74, para 33; and Cudak v Lithuania](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1KB-00000-00&context=1519360)_

_[[2010] ECHR 15869/02, para 36, 23 March 2010). It should be recalled in this regards that the general purpose](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X3HY-00000-00&context=1519360)_
of art 14 is to ensure that where a state provides for rights falling within the ambit of the Convention which go
beyond the minimum guarantees set out therein, those supplementary rights are applied fairly and consistently
to all those within its jurisdiction unless a difference of treatment is objectively justified.'

**[[43] In R (on the application of Haney) v Secretary of State for Justice [2014] UKSC 66, [2015] 2 All ER 822, [2015]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G0G-M5W1-DYBP-M2GS-00000-00&context=1519360)**
AC 1344(para [52]), Lord Mance and Lord Hughes observed of this passage that, if read literally, it might eliminate
any consideration of status. However, in Mathieson v Secretary of State for Work and Pensions the Supreme Court
accepted this aspect of the judgment in Clift v UK. (See further R (on the application of Stott) v Secretary for State
_[for Justice [2018] UKSC 59, [2019] 2 All ER 351, [2020] AC 51(para [185]) per Lord Hodge.) Lord Wilson observed](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)_
(at para [22]) that, following _Clift v UK, it was 'clear that, if the alleged discrimination falls within the scope of a_
Convention right, the ECtHR is reluctant to conclude that nevertheless the applicant has no relevant status, with the
result that the inquiry into discrimination cannot proceed'.
**[*595]**

**[44] Before us Ms Kaufmann submits that the grounds for the difference in treatment in the appellants' case can be**
characterised in two ways depending upon who are the comparators:

(1)   As against other victims of crime who, like them have unspent custodial or community sentences,
their status is that they are victims of trafficking.

(2)   As against other victims of trafficking, their status is that they have unspent custodial or community
sentences.

In the course of oral submissions, Ms Kaufmann explained that on the first basis the complaint is that the position of
victims of trafficking is materially different from that of other victims of crime and that as a result they should not be
caught by the provisions of para 3 of Annex D. In these circumstances, she submitted, the state must justify why it
is not treating victims of trafficking differently from other victims of crime. This, she maintained, was the essential
basis of the appellants' claim. So far as the second basis is concerned, she explained that among victims of
trafficking those falling within para 3 of Annex D are treated differently from those falling within para 4 of Annex D
(where a residual discretionary power is capable of being exercised) and that as a result it is necessary to justify
this difference in treatment. To my mind, very different consequences flow from these two different ways of putting
the appellants' case and it is necessary to consider each in turn.
_Victims of trafficking_


-----

577

**[45] On behalf of the respondents Mr Collins draws attention to the observation of Lord Neuberger (with whom**
Lords Hope, Rodger, Walker and Mance agreed) in the House of Lords in R (on the application of RJM) v Secretary
_[of State for Work and Pensions [2008] UKHL 63, [2009] 2 All ER 556, [2009] AC 311(para [45]) that:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W6K-CMW0-Y96Y-G0D2-00000-00&context=1519360)_

'the concept of “personal characteristic” (not surprisingly, like the concept of status) generally requires one to
concentrate on what somebody is, rather than what he is doing or what is being done to him. …'

[(See also Maktouf v Bosnia and Herzegovina (App nos 2312/08 and 34179/08) (2013) 58 EHRR 331, [2013] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X13K-00000-00&context=1519360)
_[2312/08 (paras 40, 83); Gerger v Turkey (App no 24919/94) [1999] ECHR 24919/94 (para 69).) Mr Collins submits](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X13K-00000-00&context=1519360)_
that to seek to define an 'other status' by reference to being a victim of crime can only be a reference to what is
being or has been done to the individual concerned. However, this observation by Lord Neuberger needs to be
considered in the context of RJM where it was held (at paras [45]–[47]) that homelessness is an 'other status' within
art 14, even if adopted by choice. (In this regard, I note that in R (on the application of Tigere) v Secretary of State
_[for Business, Innovation and Skills [2015] UKSC 57, [2016] 1 All ER 191, [2015] 1 WLR 3820it was conceded that](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360)_
immigration status was an 'other status' within art 14: see Lady Hale at para [26]. This is consistent with the
[decision of the ECtHR in Bah v UK (App no 56328/07) (2011) 31 BHRC 609, (2011) 54 EHRR 773.) Furthermore,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2W4-00000-00&context=1519360)
_RJM was decided before the decision of the ECtHR in Clift v UK indicated a relaxation of the requirement of status_
for this purpose which has been reflected in more recent decisions of the Supreme Court.

**[46] In the light of this more generous approach to status, I have no doubt that being a victim of trafficking does**
constitute a status for this purpose.
**[*596]**

Although it is an acquired characteristic resulting from something done as opposed to being inherent or innate, it is
plainly a personal identifiable characteristic to which many important legal consequences attach.
_Persons with a relevant unspent conviction_

**[47] The question whether the appellants have status for the purposes of art 14 by virtue of being persons with**
relevant unspent convictions gives rise to distinct issues.

**[48] The first issue for consideration is whether being subject to a relevant unspent conviction can be an 'other**
status' within art 14. The respondents submit that the fact that a person has, in the past, committed an offence and
received a particular type of sentence cannot create a personal characteristic which distinguishes that person from
others.

**[49] In the national proceedings in Clift (R (on the application of Clift) v Secretary of State for the Home Dept [2006]**
_[UKHL 54, [2007] 2 All ER 1, [2007] 1 AC 484) which concerned art 14 in conjunction with art 5, the House of Lords](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NBY-MTM0-TWP1-60SN-00000-00&context=1519360)_
held that the classification of the claimant as a long-term prisoner serving a determinate sentence of 15 years or
more, in contrast to life sentence prisoners or long-term prisoners serving less than 15 years, had not been
recognised by ECHR jurisprudence as an 'other status' within art 14. Lord Bingham stated that he came to this
conclusion with some reluctance, observing at para [28]:

'… Is his classification as a prisoner serving a determinate sentence of 15 years or more (but less than life) a
personal characteristic? I find it difficult to apply so elusive a test. But I would incline to regard a life sentence
as an acquired personal characteristic and a lifer as having an “other status”, and it is hard to see why the
classification of Mr Clift, based on the length of his sentence and not the nature of his offences, should be
differently regarded. …'

He was, however, influenced by the consideration that a domestic court should hesitate to apply the ECHR in a
manner not explicitly or impliedly authorised by the Strasbourg jurisprudence. Similarly, Lord Hope observed that it
was 'possible to regard what he has done, rather than who or what he is, as the true reason for the difference of
treatment in Mr Clift's case' (para [49]). As the ECtHR had not yet addressed this question, he also considered that
a measure of self-restraint was needed since the duty of national courts is to keep pace with the Strasbourg
jurisprudence as it evolves over time.


-----

577

**[50] When the case reached Strasbourg, in Clift v UK, the ECtHR (at para 61) took a different view:**

'… In the present case the applicant does not allege a difference of treatment based on the gravity of the
offence he committed, but one based on his position as a prisoner serving a determinate sentence of more
than fifteen years. While sentence length bears some relationship to the perceived gravity of the offence, a
number of other factors may also be relevant, including the sentencing judge's assessment of the risk posed by
the applicant to the public.'

The Court observed that there was a need for careful scrutiny of differences of treatment within the ambit of art 5
ECHR and concluded that the applicant did enjoy an 'other status' for the purposes of art 14.
**[*597]**

**[51] In** _R (on the application of Haney) v Secretary of State for Justice one of the claimants, a serving prisoner,_
invoked art 14 claiming that he had been discriminated against by the prison authorities in that they prioritised the
movement to open prisons of prisoners whose tariff periods had already expired, as opposed to those prisoners
whose tariff periods had not. Lord Mance and Lord Hughes, with whom the other members of the Supreme Court
agreed, noted the different views taken on the issue of status by the House of Lords in R (Clift) and by the ECtHR in
_Clift v UK. They observed (at para [53]) that in light of the ECtHR decision, they saw 'some force in the submission_
that the difference between pre and post-tariff prisoners should now be taken to represent a relevant difference in
status.' However, they did not need to decide the point because the difference in treatment was justified.

**[[52] More recently, in R (on the application of Stott) v Secretary for State for Justice [2019] 2 All ER 351, [2020] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)**
51the Supreme Court considered the rule that an offender serving an extended determinate sentence only became
eligible for release on parole after serving two thirds of the appropriate custodial term whereas other prisoners
serving determinate sentences became eligible after serving half of their sentence. It held, Lord Carnwath
dissenting, that the difference in treatment of prisoners with extended determinate sentences was a difference on
the ground of 'other status' within art 14.

**[53] Lady Black considered (at para [70]) that, in the light of the decision of the ECtHR in Clift v UK, the Supreme**
Court should depart from the determination in _R (Clift) that different treatment on the basis that a prisoner was_
serving imprisonment of 15 years or more could not be said to be on the ground of 'other status'. She also
addressed directly the suggestion that where a distinction is based on the gravity of the offence rather than any
characteristic of the individual it is not based on an 'other status' within art 14. It had been submitted on behalf of
the Secretary of State that Clift v UK was distinguishable as the complaint in Stott was not based on the length of
the sentence imposed but on his particular sentencing regime which was dictated by the seriousness of what he did
and the risk he posed. Lady Black observed at para [77]:

'… True it is that an extended determinate sentence will only be imposed where there is a particular
combination of gravity of offence and risk, but within the category of those serving extended determinate
sentences, there will be various types of offence of varying seriousness. Putting it another way, what Mr Stott
did has led to him receiving an extended determinate sentence, but, once imposed, that extended determinate
sentence exists independently of what he did. If a life sentence is capable of constituting an “acquired personal
status”, as Lord Bingham was understandably disposed to think it was (para [28] of R (Clift)), and a determinate
term of 15 years is also (Clift v UK), it is difficult to see why an extended determinate sentence should be
viewed differently.'

**[54] Lord Hodge, at paras [184]–[185], was satisfied that Mr Stott had the requisite status for the following reasons.**
First, the opening words of the relevant phrase, 'on any ground such as' were clearly indicative of a broad approach
to status. Secondly there was ample authority in the ECtHR, the House of Lords and the Supreme Court to support
the view that the words 'any other status' should not be interpreted narrowly. Thirdly, the Supreme Court in
_Mathieson, para [22], had accepted the judgment in_ _Clift v UK. As a result, he was persuaded that the weight of_
authority supported the view that
**[*598]**


-----

577

Mr Stott had the required status under art 14 because he had been sentenced to a particular sentence of
imprisonment, namely an extended determinate sentence.

**[55] Lady Hale referred (at para [209]) to the fact that the ECtHR in Clift v UK had adopted a very broad approach**
to the question of status. In particular it had pointed out (giving property as an example) that not all the qualities
listed in art 14 were personal characteristics and it had declined to give an ejusdem generis interpretation to 'other
status'. She had no difficulty in accepting (at para [212]) the ECtHR's holding (at para 60, cited at para [42] above)
that the question whether there was a difference of treatment based on a personal or identifiable characteristic was
a matter to be assessed taking into consideration all of the circumstances of the case and bearing in mind that the
aim of the ECHR was to guarantee rights that are practical and effective. She concluded (at para [212]) that
prisoners subject to extended determinate sentences could be identified as a distinct group. They were defined by
much more than the particular early release regime to which they were subjected. She considered the case much
clearer than Clift which was simply concerned with different lengths of determinate sentence. If further support for
that conclusion were required it could be found in the criteria for the imposition of an extended determinate
sentence, which concentrated upon the dangerousness of the offender, itself a personal characteristic.

**[56] Lord Mance considered (at paras [235], [236]) that art 14 addresses discrimination, whether deliberate or**
unconscious, having a 'systematic' nature in the sense that it occurs on the ground of a characteristic or
characteristics in some sense attributed to the victim, whether innately or as a matter of choice or against their will.
He concluded without hesitation that Mr Stott possessed a relevant status. He was subject to an extended
determinate sentence which was a sentence distinct from and which had characteristics differing from those of any
ordinary determinate or indeterminate sentence. In his opinion (para [237]) the Supreme Court should depart from
_R (Clift) and follow the clear guidance given by the ECtHR in Clift v UK._

**[57] The recent jurisprudence in Strasbourg and in the Supreme Court has shown a significant shift towards taking**
a broad view of status under art 14 and, as a result, the concept of 'other status' must now be generously
interpreted. In this context, it seems to me artificial to attempt any longer to distinguish between the gravity of an
offence and the characteristics of an individual offender. In this regard, I find compelling the reasoning of Lady
Black at para [77] of Stott. No doubt, what an offender has done has led to a particular sentence being imposed
which reflects the culpability of the offender's conduct, but once imposed the sentence has a significance
independent of what the offender has done. This applies with equal force to a custodial sentence and to a
community sentence, each of which has its own incidents and consequences. In my view, having an unspent
conviction is an identifiable, personal characteristic. Even when the custodial sentence has been served or the
community sentence completed, the sentence continues to have significance. As long as a conviction remains
unspent it has incidents and consequences, in particular obligations of disclosure, which continue to have farreaching implications for those who have been convicted.

**[58] There is, however, a second issue in relation to status which must be addressed in this context. This has been**
termed 'the individual existence condition'. In the present case the respondents submit that the status founded on
unspent convictions for which the appellants contend exists solely by
**[*599]**

reference to the terms of the legislation which they are challenging. They submit that it has no independent
character so as to form any identifiable group of people, as distinct from those who are excluded by the terms of the
CICS itself.

**[59] Article 14 prohibits, within the ambit of the rights and freedoms guaranteed by the ECHR, discrimination which**
is founded on one or more of the personal characteristics it lists 'or other status'. The objection now advanced by
the respondents was summed up by Lord Bingham in R (Clift) v Secretary of State for the Home Dept, at para [28],
in the following terms:

'I do not think that a personal characteristic can be defined by the differential treatment of which a person
complains. …'


-----

577

In other words, the basis of the discrimination of which complaint is made must have an existence independent of
the measure under attack. The same point was made by Lord Hope in R (Clift), paras [45]–[47]. In his view each of
the specific grounds of discrimination listed in art 14 shares one feature in common, namely that they exist
independently of the treatment of which complaint is made. In that sense they are personal to the complainant. He
noted that the category of long-term prisoners into which Mr Clift's case fell would not have been recognised as a
separate category had it not been for the Order which treated prisoners in his group differently from others. This, he
considered, raised the question whether the distinguishing feature or characteristic which enables a person or a
group of persons to be singled out for separate treatment must have been identified as a personal characteristic
before it is used for this purpose by the discriminator.

**[60] When the matter came before the ECtHR in Clift v UK, that court was dismissive of the point stating at para 60:**

'Further, the Court is not persuaded that the Government's argument that the treatment of which the applicant
complains must exist independently of the “other status” upon which it is based finds any clear support in its
case-law. …'

It then went on to explain, in a passage cited at para [42] above, that the question whether there is a difference of
treatment based on a personal or identifiable characteristic is a matter to be assessed taking into consideration all
of the circumstances of the case and bearing in mind that the objective of the Convention is to guarantee practical
and effective rights.

**[61] The issue is nevertheless one of importance and since** _Clift v UK it has reappeared frequently in domestic_
cases. The language of art 14 requires that discrimination should be on the basis of one of a number of identified
grounds 'or other status'. If status can be defined solely by the difference in treatment complained of, the words 'on
any ground such as …' would add nothing to art 14. (See R (Clift), para [27] per Lord Bingham; Stott, para [210] per
Lady Hale.) As a result, notwithstanding the judgment of the ECtHR in _Clift v UK, the position before domestic_
courts in this jurisdiction remains far from clear.

**[[62] The question arose for consideration in R v Docherty [2016] UKSC 62, [2017] 4 All ER 263, [2017] 1 WLR 181.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PN2-YC81-DYBP-M2J5-00000-00&context=1519360)**
[Legislation repealing the provisions of the Criminal Justice Act 2003 which provided for sentences of imprisonment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)
for public protection was brought into force with effect from 3 December 2012. However, the Commencement Order
stated that the provision was of no effect in relation to a person convicted before that date. The appellant, who had
pleaded guilty to two offences on 13 November 2012, was sentenced on
**[*600]**

20 December 2012 to an indeterminate sentence of imprisonment for public protection. He appealed inter alia on
the ground that the discrimination between him and a person convicted of identical offences after 3 December 2012
was unlawful under art 14 read with art 5. He submitted, inter alia, that this discriminated objectionably against him
on grounds of 'other status', namely his status as a prisoner who is subject to an indeterminate sentence. Lord
Hughes, with whom the other members of the Supreme Court agreed, considered (at para [63]) that, assuming that
status as a prisoner subject to a particular regime could in some circumstances amount to sufficient status to bring
art 14 into question, it could not do so if the suggested status is defined entirely by the alleged discrimination. In his
view, that was not the case in _Clift. The mere imposition of an indeterminate sentence under the appropriate_
sentencing regime could not give Mr Docherty a different status. (See further, Lord Mance in Stott at para [230].)
Lord Hughes left open, however, the possibility that he had a different status on the ground that he had been
convicted before and not after 3 December 2012.

**[63] The issue arose once again in Stott where three members of the Supreme Court in the majority considered that**
Mr Stott satisfied the independent existence condition. (See Lady Black at para [75], Lady Hale at para [212] and
Lord Mance at para [236]. Lord Hodge agreed that Mr Stott had the required status but he did not discuss the
independent existence condition.) However, different views were expressed in relation to it. Lady Black (at paras

[72]–[74]) drew attention to three difficulties with the independent existence condition. The first was its
'uncompromising rejection' by the ECtHR in _Clift v UK. The second was that it made its appearance in_ _R (Clift)_


-----

577

unsupported by much, if anything, by way of explanation or supportive authority. The third was that it was 'not at all
easy to grasp'. She concluded at para [75]:

'In all these circumstances, I would be cautious about spending too much time on an analysis of whether the
proposed status has an independent existence, as opposed to considering the situation as a whole, as
encouraged by the ECtHR in Clift v UK …'

Lady Hale considered (at paras [210]–[212]) that the true principle is that the 'status' must not be defined solely by
the difference in treatment complained of, for otherwise the words 'on any ground such as …' would add nothing to
art 14. She drew a useful analogy with the United Nations Convention relating to the Status of Refugees (1951)
(Cmd 9171). To be recognised as a refugee, a person has to have a well founded fear of persecution on one of the
Convention grounds, one of which is membership of a particular social group. She drew attention to the decision of
the House of Lords in K v Secretary of State for the Home Dept, Fornah v Secretary of State for the Home Dept

_[[2006] UKHL 46, [2007] 1 All ER 671, [2007] 1 AC 412which affirms the principle that a particular social group must](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4N1S-TYH0-TWP1-60X2-00000-00&context=1519360)_
exist independently of the persecution to which the group is subject, by which was meant that the group was not
defined solely by the persecution it feared. Nevertheless, she had no difficulty in accepting the approach identified
by the ECtHR at para 60 of Clift v UK, cited above at para [42]. Lord Mance accepted (at para [228]) the importance
of status as an independent question and drew attention to the fact that there would be no point in language which
requires discrimination on a particular ground if the only question were whether there had been discrimination. He
continued at para [231]:
**[*601]**

'That a mere difference in treatment does not by itself constitute a difference in status is a proposition which is
difficult to fault in the light of Gerger and what I have already said. But problems have arisen from attempts to
extend the application of such a proposition to cases beyond its scope. This is, I think, the root of the third
difficulty expressed by Lady Black … [that the independent existence condition is not at all easy to grasp].
There is no reason why a person may not be identified as having a particular status when the or an aim is to
discriminate against him in some respect on the ground of that status.'

**[64] More recently, Docherty was applied by the Court of Appeal in Mayor and Burgesses of the London Borough of**
_[Haringey v Simawi [2019] EWCA Civ 1770, [2020] 2 All ER 701, [2020] PTSR 702, a case concerning succession](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YX3-1X23-CGXG-03WY-00000-00&context=1519360)_
to a secure tenancy. Although Lewison LJ, with whom the other members of the Court agreed, considered (at para

[41]) that the observations of the majority on this issue in Stott were obiter, he also considered that, as Lady Black
had observed in Stott (at para [63]), the independent existence condition lived on in Docherty. The decision that Mr
Docherty did not have an 'other status' because 'the suggested status is defined entirely by the alleged
discrimination' was part of the ratio decidendi of that case. The Supreme Court in _Stott had not departed from_
_Docherty in that respect and_ _Docherty was therefore binding on the Court of Appeal. Mr Simawi was therefore_
entitled to rely on a status provided that it was not defined entirely by the alleged discrimination.

**[65] In the present appeal the Supreme Court has not been invited to depart from its earlier decision in Docherty. In**
my view, however, it is not necessary to resolve the issue in the present appeal because _Docherty is_
distinguishable in this regard. In the present case, to employ the wording of Lord Hope in R (Clift) at paras [67]–[68],
the distinguishing feature or characteristic which enables persons with an unspent conviction which resulted in a
custodial or community sentence to be singled out for separate treatment had been identified as a personal
characteristic before it was used for this purpose in the CICS. The distinction drawn by the CICS is between two
groups of persons with unspent convictions. That distinction is defined by paras 3 and 4 of Annex D but it does not
derive entirely from that provision. There are other consequences of being an offender with an unspent conviction
under para 3 which derive from the _[Rehabilitation of Offenders Act 1974 and other statutes which set out the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
differing implications of various unspent convictions. As Ms Kaufmann put it in argument, having an unspent
conviction within para 3 has significance independent of the CICS. The CICS simply adds a new consequence.

**[66] I should add, however, that I agree with the observations of Lord Reed on the independent existence issue in**
his judgment in R (SC) v Secretary of State for Work and Pensions [2021] UKSC 26, [2021] 3 WLR 428(paras [69]–


-----

577

[71]) in which he adopted the reasoning of Leggatt LJ in the Court of Appeal in that case: [2019] EWCA Civ 615,

_[[2019] 4 All ER 787, [2019] 1 WLR 5687. Article 14 draws a distinction between relevant status and difference in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XFS-06T3-GXFD-803H-00000-00&context=1519360)_
treatment and the former cannot be defined solely by the latter. There must be a ground for the difference of
treatment in terms of a characteristic which is something more than a mere description of the difference in
treatment. In the present case the status of the appellants as persons with unspent relevant convictions does, in my
view, have a significance independent of the CICS. However, I agree with
**[*602]**

Lord Reed that there is no requirement that the status should have legal or social significance for other purposes or
in contexts other than the difference in treatment of which complaint is made.

**[67] For the reasons set out above, I consider that having an unspent conviction which resulted in a custodial or**
community sentence is a status for the purposes of art 14 considered in conjunction with art 4.
**Difference of treatment**

**[68] The appellants' case on difference of treatment is put in two ways reflecting their case on status.**

(1)   First, they submit that by treating victims of trafficking with an unspent conviction resulting in a
custodial or community sentence in the same way as other victims of crime with an unspent conviction
resulting in a custodial or community sentence, the CICS applies to them a rule that is not suited to their
different circumstances.

(2)   Secondly, they submit that in excluding from the CICS victims of trafficking with an unspent
conviction resulting in a custodial or community sentence but not other victims of trafficking, it discriminates
on grounds of other status.

_Victims of trafficking_

**[69] Discrimination may arise where the state fails to treat differently persons whose situations are significantly**
different. In _Thlimmenos v Greece (App no 34369/97)_ _[(2000) 9 BHRC 12, (2000) 31 EHRR 411 the ECtHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3V5-00000-00&context=1519360)_
explained at para 44:

'The court has so far considered that the right under art 14 not to be discriminated against in the enjoyment of
the rights guaranteed under the convention is violated when states treat differently persons in analogous
situations without providing an objective and reasonable justification … However, the court considers that this
is not the only facet of the prohibition of discrimination in art 14. The right not to be discriminated against in the
enjoyment of the rights guaranteed under the convention is also violated when states without an objective and
reasonable justification fail to treat differently persons whose situations are significantly different.'

The appellants say that, as victims of trafficking with relevant unspent convictions, they must be treated differently
from victims of other crimes who have relevant unspent convictions.

**[70] The appellants argue that victims of trafficking must be treated differently from other victims of crime because**
they are not in an analogous position. They submit that victims of trafficking form a special and distinct group as
victims of crime and that differences between them and other victims of crime require any distinction drawn
amongst them as a group or any failure to treat them differently from other victims of crime to be justified. They
submit that in the context of the CICS, a scheme which is intended to aid blameless victims of crime in their
recovery, there is a need to afford more generous treatment to victims of trafficking than to other victims of crime,
with respect to an exclusionary rule based on the commission of offences, because of the particular status and
vulnerability of victims of trafficking.

**[71] I readily accept that people trafficking is a particularly grave crime and that its victims, who are often**
vulnerable, can suffer grievously. However, many other crimes are no less serious, their victims equally vulnerable
and the
**[*603]**


-----

577

consequences they suffer at least as grievous. I am unable to identify any feature of the offence of people trafficking
which could require preferential treatment to be accorded in the present context to victims of trafficking over victims
of other serious crime. It is, of course, the case that the crime of people trafficking is recognised by a number of
international instruments including ECAT and the EU Directive. Furthermore, it has now been accepted that it falls
within the prohibition in art 4 ECHR. However, none of these instruments requires more favourable treatment to be
accorded to victims of trafficking so far as compensation by the state is concerned. As indicated earlier in this
judgment, the ECtHR has not yet accepted that art 4 confers on victims of trafficking any right to compensation from
the state. To the extent that art 15(4) ECAT may require a contracting state to provide a compensation scheme for
victims of trafficking, it is to be 'in accordance with the conditions under its internal law'. Moreover, there is nothing
in EU law which affords to victims of trafficking a more favourable entitlement to compensation for criminal injuries
than that granted to other victims of crime. Article 17 of the EU Directive requires member states to ensure that
victims of trafficking 'have access to existing schemes of compensation to victims of violent crimes of intent'. As
Gross LJ explained in the Court of Appeal in the present proceedings (at para [41]), neither ECAT nor EU law calls
for victims of trafficking to enjoy rights under national compensation schemes free of any limiting or exclusionary
terms and not enjoyed by other potential applicants for compensation who are not victims of trafficking.

**[72] At this stage of the argument, the appellants' submissions shift into a rather different point. They draw attention**
to the fact that victims of people trafficking are themselves liable to commit crimes arising from their own trafficking
for which they are blameless. For example, a victim of trafficking may be forced to commit immigration offences, to
work in a cannabis farm or to use false documentation in order to work. The appellants point to the fact that, in
recognition of the injustice of punishing victims of trafficking for crimes committed arising from their trafficking,
states are obliged to provide for the possibility of not imposing penalties on victims of trafficking for their
involvement in unlawful activities, to the extent that they have been compelled to do so as a result of their
trafficking. (See art 26 of ECAT and art 8 of the EU Directive.) They also draw attention to the fact that here no
distinction is drawn on the basis of the gravity of the offences which the victim of trafficking might have committed.

**[73] In this important respect, victims of trafficking are treated differently from others who commit criminal offences.**
Domestic law in this jurisdiction does provide safeguards intended to ensure that victims of trafficking are not
punished for their involvement in unlawful activities which they were compelled to carry out. _[Section 45 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_
**_Modern Slavery Act 2015 provides a defence to trafficking victims compelled to commit an offence. The Crown_**
Prosecution Service has a discretion not to prosecute. Furthermore, the court has power to protect victims of
trafficking in respect of offences which they have been compelled to commit by staying a prosecution or, if a person
is identified as a victim of trafficking only after conviction, by quashing a conviction as an abuse of process. (See,
[for example, R v L [2013] EWCA Crim 991, [2014] 1 All ER 113, [2014] 3 LRC 1; R v Joseph [2017] EWCA Crim 36,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)

[2017] 1 WLR 3153.)

**[74] The appellants accept that these non-punishment provisions provide vital safeguards for victims of trafficking**
and may ensure that some who have
**[*604]**

committed offences connected to their having been trafficked may avoid a criminal penalty or may have a penalty
quashed with the result that they are able to access the CICS. However, they point to certain alleged practical
deficiencies or limitations in the non-punishment arrangements. In particular, they observe that the operation of
these provisions is dependent on the correct identification of the victim of trafficking as such and the victim's status
being known to the prosecuting authorities and the court. They state that there are practical obstacles in the path of
overturning on appeal a conviction of a victim of trafficking. Furthermore, they point out that these protections apply
only to offences committed in the United Kingdom; victims of trafficking who are convicted abroad in connection
with their trafficking may find it impossible to have their convictions overturned. They submit, therefore, that the
protection afforded by these measures may not be sufficient for every victim of trafficking with the result that victims
of trafficking should be treated for the purpose of the CICS more favourably than victims of other serious crimes.

**[75] For present purposes, I am willing to assume that it is arguable that victims of people trafficking who have**
committed criminal offences in connection with their being trafficked – who might be termed 'nexus offenders' – are


-----

577

entitled to be treated differently in certain respects from other offenders. However, the difficulty faced by the
appellants in the present case is that nexus offenders form a sub-group of victims of trafficking who have unspent
convictions, and the appellants do not fall within that sub-group. The relevant conviction of each of the appellants
relates to an offence committed long before the appellant became a victim of trafficking. Each had been convicted
and had completed his prison sentence before being trafficked. The offending on the part of these appellants is
totally unconnected with their being victims of trafficking. As a result, their arguments as to the alleged inadequacies
of the non-punishment provisions applicable to nexus offenders have no application to their case. Whatever
inadequacies in that regime there might be, they cannot say that it puts them in a different position from a nontrafficked offender, because that regime did not and could not apply to their earlier offending. The fact that some
victims of trafficking who have committed offences will be nexus offenders cannot provide a basis for requiring
differential treatment for all victims of trafficking who have committed offences, including those who like the
appellants are not nexus offenders. To my mind, this is a complete answer to the appellants' case that they have
been subjected to discrimination founded on their status as victims of people trafficking.

**[76] It is relevant to point out that, in the courts below, the case in relation to discrimination was put on the basis of**
the impact of the exclusionary rule on victims of trafficking generally. Although submissions were made in relation to
the position of nexus offenders and although both Wilkie J (at para [131]) and the Court of Appeal (at paras [40]–

[44], [94]–[102]) addressed this specific issue, the evidence did not focus on this issue in any detail. In particular,
there was no evidence before the court as to the effectiveness of the anti-punishment measures. In the Court of
Appeal the appellants argued that blameless nexus offenders would have been prevented from claiming
compensation under the CICS because of the exclusionary rule, while the respondents argued that nexus offenders
would have been protected by the existing non-prosecution measures and so would not have been caught by the
exclusionary rule. There was no clear evidence on the point either way. Before this court, the interveners made
submissions on the issue in support of the appellants, but the
**[*605]**

court refused an application by the interveners to adduce evidence on this issue, on the ground that it was
inappropriate to introduce such evidence at this stage of the proceedings and that, in any event, A and B did not fall
within the category of nexus offenders.

**[77] In these circumstances, it is not necessary to address the observations of Gross LJ in the Court of Appeal (at**
para [95]), criticised by Ms Kaufmann in her submissions, to the effect that if a victim of trafficking was for some
reason unable to benefit from any of the non-punishment protections, the circumstances of the offending would
likely be so divorced from the trafficking as to point to his or her not being a blameless victim of a crime of violence.
I express no view in relation to that. The efficacy of the non-punishment protections is not a question which arises in
the present case. I do note, however, that the appellants, when addressing justification in their written case, state
that '[g]iven the non-punishment provisions, it is inconceivable that the number of victims of trafficking caught by

[the exclusionary rule in] para 3 will be substantial in number, certainly not significant enough to make any
meaningful dent in the scheme'.

**[78] For these reasons, I consider that the appellants' case on unlawful discrimination founded on the fact that they**
are victims of people trafficking is not made out.
_Victims of trafficking with relevant unspent convictions_

**[79] On this alternative basis the appellants submit that in excluding from the CICS victims of trafficking with an**
unspent conviction which resulted in a custodial or community sentence, but not other victims of trafficking, the
scheme discriminates on grounds of other status. Clearly, there is a difference in treatment between those who
have relevant unspent convictions and who are therefore excluded from compensation, and those who do not and
are therefore not excluded from compensation. Insofar as both may be victims of crimes of violence and therefore
otherwise potentially eligible for compensation, the issue is whether the difference in treatment is justified.
**Justification**


-----

577

**[80] What requires to be justified is the difference in treatment arising from the provisions of Annex D. The issue for**
consideration is whether the exclusion from the CICS of victims of trafficking with an unspent conviction which
resulted in a custodial or community sentence, as opposed to other victims of trafficking, is justified.

**[81] In** _Stec v UK (App nos 65731/01 and 65900/01)_ _[(2006) 20 BHRC 348, (2006) 43 EHRR 1017 the ECtHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W399-00000-00&context=1519360)_
described justification in the following terms:

'51. … A difference of treatment is … discriminatory if it has no objective and reasonable justification; in other
words, if it does not pursue a legitimate aim or if there is not a reasonable relationship of proportionality
between the means employed and the aim sought to be realised. The contracting state enjoys a margin of
appreciation in assessing whether and to what extent differences in otherwise similar situations justify a
different treatment …

52. The scope of this margin will vary according to the circumstances, the subject matter and the background
… As a general rule, very weighty reasons would have to be put forward before the court could regard a
difference in treatment based exclusively on the ground of sex as compatible with the convention … On the
other hand, a wide margin is

**[*606]**

usually allowed to the state under the convention when it comes to general measures of economic or social
strategy … Because of their direct knowledge of their society and its needs, the national authorities are in
principle better placed than the international judge to appreciate what is in the public interest on social or
economic grounds, and the court will generally respect the legislature's policy choice unless it is “manifestly
without reasonable foundation” …'

**[82] As Lord Reed has demonstrated in his judgment in R (SC) v Secretary of State for Work and Pensions (paras**

[98]–[142]) the ECtHR employs a flexible approach when deciding what standard is to be applied when considering
justification. In general, unless one factor is of overriding significance, it is necessary for the court to make a
balanced overall assessment. In the present case the appellants have accepted, correctly in my view, that the
applicable test here is whether the decision to adopt the measure under challenge (ie the CICS) was manifestly
without reasonable foundation. A number of features of this case strongly support this conclusion.

**[83] First, the CICS operates in the field of social welfare policy where courts should normally be slow to substitute**
their view for that of the decision maker (R (RJM) v Secretary of State for Work and Pensions at para [56]).
Furthermore, this is an area where the ECtHR usually accords a wide margin of appreciation to national courts as it
explained in _Stec, paras 51, 52, cited at para [81] above and in_ _Fábián v Hungary (App no 78117/13)_ _[(2017) 44](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SCW-MSS1-DYBP-W0FF-00000-00&context=1519360)_
_[BHRC 224, (2017) 66 EHRR 938 (paras 114, 115). The question whether and, if so to what extent, the state should](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SCW-MSS1-DYBP-W0FF-00000-00&context=1519360)_
pay compensation to victims of crimes of violence who have themselves committed crimes is essentially a question
of moral and political judgement. Furthermore, it requires the exercise of political judgement in relation to the
allocation of finite public resources. This is, therefore, a field in which the courts should accord a considerable
degree of respect to the decision maker.

**[84] Secondly, the reasons for judicial restraint are greater where, as in the present case, the statutory instrument**
has been reviewed by Parliament. In _Bank Mellat v HM Treasury (No 2)_ _[2013] UKSC 39,_ _[[2013] 4 All ER 533,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_

[2014] AC 700Lord Sumption expressed the matter in the following terms at para [44]:

'… [W]hen a statutory instrument has been reviewed by Parliament, respect for Parliament's constitutional
function calls for considerable caution before the courts will hold it to be unlawful on some ground (such as
irrationality) which is within the ambit of Parliament's review. This applies with special force to legislative
instruments founded on considerations of general policy. …'

**[85] Thirdly, the basis of the discriminatory treatment complained of is also relevant here. The ECtHR has identified**
a number of suspect grounds of differential treatment which are regarded as particularly serious, such as sex, race
or ethnic origin nationality or birth status and which will usually require very weighty reasons by way of justification


-----

577

unless outweighed by other relevant considerations. In general, the rationale is the link between the characteristic
on which differential treatment is founded and a history of stigmatisation, stereotyping and social exclusion.
However, in the present case the status relied upon, ie being a victim of trafficking with a relevant unspent
conviction, is not within the range of suspect reasons where discrimination is usually particularly difficult to justify.
Accordingly, to ask whether the measure is manifestly without reasonable foundation is an entirely appropriate test.
**[*607]**

**[86] The objective of the relevant provisions of the legislation appears from the process of consultation which**
preceded its adoption and which is helpfully summarised by Gross LJ (at paras [85]–[91]) in his judgment in the
Court of Appeal. The Consultation Document (Ministry of Justice Consultation Paper CP3/2012, January 2012,
'Getting it right for victims and witnesses' (Cm 8288)) stated at para 207:

'We acknowledge that our proposals in relation to the Scheme rules on unspent convictions, although a
development of the existing position, could impact in particular on those who have on their record relatively
minor unspent convictions. However, we consider that tougher rules are warranted. The Scheme is a taxpayerfunded expression of public sympathy and it is reasonable that there should be strict criteria around who is
deemed “blameless” for the purpose of determining who should receive a share of its limited funds. We
consider that, in principle, awards should only be made to those who have themselves obeyed the law and not
cost society money through their offending behaviour. Minor convictions will, under the _[Rehabilitation of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
_[Offenders Act 1974, become spent (and therefore no longer count for the purpose of the Scheme) so long as](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
the offender does not reoffend.'

**[87] This is clearly a legitimate aim. Article 8(3) of the European Convention on the Compensation of Victims of**
Violent Crimes 1983 provides that compensation may be reduced or refused if an award or a full award would be
contrary to a sense of justice or to public policy. Similarly, the Explanatory Report to the Convention (Explanatory
Report to the European Convention on the Compensation of Victims of Violent Crimes, Strasbourg, 24 November
1983, ETS No 116) states at para 36c in relation to this provision:

'States which introduce compensation schemes usually want to retain some discretion in awarding
compensation and to be able to refuse it in certain cases where it is clear that a gesture of solidarity would be
contrary to public feeling or interests or would be contrary to the basic principles of the legislation of the State
concerned. This being so, a known criminal who was the victim of a crime of violence could be refused
compensation even if the crime in question was unrelated to his criminal activities.'

As Gross LJ put it in the Court of Appeal at para [92], the moral element, underlying the exclusionary rule, is
internationally understood and is in any event a matter for national states.

**[88] The appellants do not dispute that seeking to ensure that limited funds should be directed towards those who**
are considered blameless and who have not inflicted loss on society through their offending behaviour is a
legitimate aim. Furthermore, they do not suggest that the provisions of Annex D are not rationally connected with
that aim. They do, however, complain that the exclusionary rule in para 3 of Annex D is not proportionate in that it
imposes a bright line rule without the possibility of the exercise of a discretion in favour of an applicant, which had
been a feature of earlier iterations of the CICS.

**[89] In approaching this submission, a convenient starting point is the observation of Lord Bingham in relation to the**
nature of legislation, made in a very different context in R (on the application of Animal Defenders International) v
_[Secretary of State for Culture, Media and Sport [2008] UKHL 15, [2008] 3 All ER 193, [2008] 1 AC 1312(para [33]):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SW6-XF50-TWP1-602H-00000-00&context=1519360)_
**[*608]**

'… [L]egislation cannot be framed so as to address particular cases. It must lay down general rules: … A
general rule means that a line must be drawn, and it is for Parliament to decide where. The drawing of a line
inevitably means that hard cases will arise falling on the wrong side of it, but that should not be held to
invalidate the rule if, judged in the round, it is beneficial.'


-----

577

The drawing of dividing lines between eligibility and non-eligibility is an inevitable feature of legislation in the field of
social welfare and compensation. In many cases there will be room for disagreement as to where a line should be
drawn but the courts will be slow to interfere. In RJM Lord Neuberger, accepting that the government was entitled to
adopt the policy at issue in relation to disability premium in income support, observed at para [57]:

'The fact that there are grounds for criticising, or disagreeing with, these views does not mean that they must
be rejected. Equally, the fact that the line may have been drawn imperfectly does not mean that the policy
cannot be justified. Of course, there will come a point where the justification for a policy is so weak, or the line
has been drawn in such an arbitrary position, that, even with the broad margin of appreciation accorded to the
state, the court will conclude that the policy is unjustifiable. However, this is not such a case, in my judgment.'

Similarly, in Mathieson v Secretary of State for Work and Pensions Lord Mance stated at para [51]:

'Courts should not be over-ready to criticise legislation in the area of social benefits which depends necessarily
upon lines drawn broadly between situations which can be distinguished relatively easily and objectively. …'

In this regard the courts have also acknowledged the advantages of clear rules which can be readily applied. In R
_(on the application of Tigere) v Secretary of State for Business, Innovation and Skills Lord Hughes stated at para_

[60], referring to rules of eligibility for student loans:

'… All such rules are both inclusionary and exclusionary; if one grafts onto them a residual discretion they
cease to be rules based on readily ascertainable facts and become rules based in part on an evaluative
exercise. The truth is that clear rules, based on readily ascertainable facts, which are simple to state, to
understand and to apply, have a merit of their own. …'

**[90] Can a bright line rule be justified in the context of this compensation scheme? In my view it clearly can. First,**
we are concerned with an area of policy in which a considerable degree of latitude is accorded to the legislator as to
the form and scope of the CICS. Secondly, the object of the CICS, namely the allocation of limited resources to
deserving victims of crime as an expression of public sympathy, is such that the legislator is entitled to adopt a
scheme which operates by clearly defined rules. In particular, it is appropriate to lay down rules as to the
seriousness of offences which will disqualify possible claimants as opposed to allowing a general discretion to be
applied in individual cases by claims officers. The chosen approach has the considerable advantages of clarity and
consistency. Thirdly, it is significant that the CICS was approved by Parliament following an extensive process of
consultation and an equality impact assessment. The government did consider the extent to which
**[*609]**

there should be a discretion exercisable in individual cases and decided to retain such a discretion in respect of
unspent convictions for minor offences within para 4 of Annex D but not in respect of more serious unspent
offences which resulted in a custodial or community sentence within para 3. I consider that it was perfectly entitled
to adopt such an approach.

**[91] In any event, the rules adopted in Annex D are, as both Wilkie J and the Court of Appeal pointed out, nuanced**
rules reflecting in various ways both the seriousness and the age of a claimant's previous conviction. The
exclusionary rule in para 3 applies only to unspent convictions which resulted in custodial or community sentences.
Unspent convictions resulting in lesser sentences fall within para 4 under which the claims officer retains some
discretion: an award will be withheld or reduced unless there are exceptional reasons not to withhold or reduce it. In
this way a distinction is drawn based on the seriousness of the offence, the circumstances in which it was
committed, the culpability of the offender and the availability of mitigation, as reflected in the sentence imposed.
The effect of para 5 of Annex D is to exclude altogether from the operation of paras 3 and 4, certain road traffic
offences which resulted in no more than an endorsement, penalty points or a fine. Furthermore, the provisions of
para 3 apply only in relation to unspent convictions. The legislation on rehabilitation of offenders provides for certain
convictions to become spent, depending on the gravity of the offence as reflected in the sentence imposed and the
passage of time since it was committed, conditional on subsequent good conduct. This introduces a further relative
scale into the operation of para 3 The more serious the offence and the more recently it was committed the more


-----

577

likely is the offender to be excluded from compensation. As Gross LJ expressed the matter in the Court of Appeal
(at para [99]), Annex D read as a whole provides a graduated approach to withholding or reducing awards of
compensation, hinging on the seriousness of the offending, the circumstances of the offender and applicable
mitigation, all reflected in the sentence passed and the time which has elapsed since the offending in question.

**[92] I consider, therefore, that the difference in treatment on grounds of other status resulting from Annex D is**
justified. The measure has the legitimate objective of limiting eligibility to compensation to those deserving of it.
Furthermore, the measure satisfies the requirement of proportionality. It is rationally connected to the objective. The
measure is no more intrusive than it requires to be and it strikes a fair balance between the competing interests.
Wilkie J and the Court of Appeal were clearly correct in concluding that it cannot be regarded as manifestly without
reasonable foundation.
**Conclusion**

**[93] For these reasons, I would dismiss this appeal.**

Appeal dismissed.

Aaron Turpin Barrister.

**End of Document**


-----

