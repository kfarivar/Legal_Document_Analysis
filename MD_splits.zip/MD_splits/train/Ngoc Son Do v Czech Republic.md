# Ngoc Son Do v Czech Republic [2024] EWHC 2345 (Admin)

King's Bench Division, Administrative Court (London)

Holgate J

9 May 2024Judgment

**MR DO appeared in person**

**MS C STEVENSON appeared on behalf of the Respondent.**

---------------------
JUDGMENT

(Approved)

---------------------
Digital Transcription by Epiq Europe Ltd,

Lower Ground, 46 Chancery Lane, London WC2A 1JE

Web: www.epiqglobal.com/en-gb/    Email: civil@epiqglobal.co.uk

(Official Shorthand Writers to the Court)

_This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance_
_with relevant licence or with the express consent of the Authority. All rights are reserved._

_This judgment was delivered in private. The judge has given leave for this version of the judgment to be_
_published on condition that (irrespective of what is contained in the judgment) in any published version of the_
_judgment the anonymity of the children and members of their family must be strictly preserved. All persons,_
_including representatives of the media, must ensure that this condition is strictly complied with. Failure to do so will_
_be a contempt of court._

1. MR JUSTICE HOLGATE: This is a renewed application for leave to appeal against an extradition order
made by District Judge Leake, on 22 September 2023. It concerns two conviction warrants. The first was
dated 29 June 2022, and related to bank frauds. A sentence of two years' imprisonment was imposed.
The second was issued on 2 July 2020 and related to offences in February 2017. They concerned theft,
damage to property and forgery. A sentence of twenty months imprisonment was imposed. Almost the
entire sentence remains to be served.

2. The applicant was arrested in relation to the first matter on 20 May 2017, and interviewed. He was
interviewed in relation to the second matter at a police station in the Czech Republic in June 2017. At that
stage, he was informed of the criminal prosecution. The judge found he left the Czech Republic only two
days later. In May 2018, he appointed a defence lawyer, who appealed the verdict on the second matter,
on 19 October 2018. The appeal was dismissed. There was no issue about the entitlement of the applicant
to a re-trial if he should be extradited on both warrants.


-----

3. At paragraph 32 of his judgment, the judge also referred to a recent conviction in this country for
dangerous driving, which resulted in a sentence of twelve months' imprisonment.

4. At the hearing, the applicant gave evidence:

“42. He said that he decided to leave Vietnam as there were few opportunities to earn a living there, and he
was trafficked by a Vietnamese gang through Russia to the Czech Republic where he was forced to work
to repay a debt of $7,000. This debt, he told me, remains unpaid and demands are still being made to his
family in Vietnam.

43. Whilst in the Czech Republic he learnt the Czech language reasonably well, but this meant that he was
asked to carry out illegal activities such as bank frauds. He tried to resit doing this, but was attacked on
several occasions, including with a sword. He said that he felt unable to contact the police in the Czech
Republic as he was scared for the safety of his daughter in Vietnam.

44. He told me that all of his convictions in the Czech Republic are the result of the actions of the
traffickers. In relation to the robbery offence, he said that he had been forced to drive another male to a
cannabis farm to steal from it. The gang blamed him for the robbery being unsuccessful and he was
assaulted by them.

45. He told me that he considered that there was a threat to his life from the gang or “something far more
serious would happen resulting in me losing my liberty” (which I understand him to mean being held
hostage by the traffickers). He said that he realised that the only way for him to bring the situation to an
end was to leave the Czech Republic. His family raised money for him to fly to the UK and he came here in
2017. He said that he has kept a low profile here and has tried to avoid contact with other Vietnamese
people to avoid his whereabouts becoming known to the traffickers. He feels relatively safe here.

…

48. […] He denied leaving the Czech Republic to avoid the prosecution and he said that the first time he
became aware that he had been convicted of the offences was when he had been given the warrant.

…

49. As to his life in the UK, he said that his parents and a brother live here in Watford. He has found work
in a restaurant and he has tried to build a life for himself here and provide for his daughter in Vietnam. He
has also tried to help his brother with his small business. He told me that he is now in a relationship with
Hanh Nguyen. They plan to marry and live together when his legal issues resolved. She has a 4-year-old
daughter who considers him to be her father. When he was cross-examined about this, he said that they
had lived together before he had been arrested in these proceedings. His partner and her daughter have
now moved. She works as a nail technician. He could not say if she received any benefits. He said that if
he was extradited, she would stay in the UK as she has no links to the Czech Republic.

50. As to his extradition, he said that he fears being harmed in the Czech Republic as the Vietnamese
gangs have a widespread network there.

…

5. The Judge reached these conclusions:

55. In my judgment, and in light of the very limited evidence I have heard, the requested person has
provided a cogent account of being a victim of slavery and trafficking to and within the Czech Republic. No
other evidence has placed before me on this topic by the judicial authority, and (for understandable
reasons) the requested person's account was not challenged in cross-examination. I cannot say that the
account he gave was manifestly false, and it follows on the very limited evidence and on a balance of
probabilities that the account he gave is more likely to be true than not.

…

76. In this case, I have found (on the very limited evidence and on a balance of probabilities) that the
requested person's account of being a victim of trafficking, slavery and physical assaults is more likely than


-----

not to be true. However, that conduct ended six years ago in 2017 and no evidence has been placed
before me to demonstrate the extent of any risk of that conduct starting again if the requested person was
returned to the Czech Republic. Furthermore, no evidence has been placed before to displace the
presumption that the Czech Republic would comply with its positive obligations under Articles 3 and 4 by
providing a reasonable level of protection to the requested person.”

6. The main ground of appeal before the judge concerned Article 8 of ECHR, the judge dealt with this at
paragraphs 79 to 91 of his judgment. At paragraph 86 he found that the applicant is a fugitive. That finding
is not challenged on appeal. At paragraph 87, the judge summarised the factors in favour of extradition. At
paragraph 88 he summarised the factors against extradition.

7. At paragraph 91 he returned to the subject of slavery and trafficking:

“91. That I have found (on the limited evidence before me) that the requested person has been a victim of
slavery and trafficking is also something carrying some weight in the balancing exercise. However, I have
not heard any evidence about the extent of any ongoing risk to the requested person if he was to be
returned. The significance, in my judgment, is that depending on the level of risk assessed by the Czech
authorities, the circumstances of the requested person's detention in prison in the Czech Republic may be
different than they might otherwise be. Any protective measures required would be likely, in my judgment,
to involve a more isolated form of detention.”

8. In paragraph 92 the judge set out his overall conclusions on the Celinski balance:

“92. Having considered all the factors in this case individually and cumulatively, I am satisfied that the
balance lies decisively in favour of extradition. The very recent conviction for dangerous driving and the
strong public interest in extradition carry the greatest weight in this case. There will be an impact of
extradition for the requested person, his family, including Hanh Nguyen and her child partner; but in my
judgment it will be no more than what Lord Mance described in Norris as the adverse consequences which
extradition has by its nature. I add that I would reach the same conclusions in this case whether or not the
requested person is to be regarded as a fugitive.”

9. Grounds of appeal were filed on 20 September 2023, drafted by counsel who had appeared before the
District Judge. They were said to be holding grounds, and no indication was given as to why the District
Judge was arguably wrong. The court has been told that new counsel were instructed to advise on an
appeal. He or she gave negative advice to the applicant, and so perfected grounds were not served.

10. On 7 February 2024, Sir Duncan Ouseley refused permission to appeal in the absence of any
perfected grounds. He added that he could see nothing arguably wrong in the decision of the judge. On
19 February 2024, the applicant applied for an extension of time for filing renewed grounds of appeal, until
1 March. Those grounds were drafted by new counsel, Ms Natasha Draycott. They referred to an alleged
significant decline in the applicant's mental health. The grounds said that he was a victim of **_modern_**
**_slavery and that he had been trafficked by a gang who caused him to become addicted to crystal meth,_**
and to commit the offences in the arrest warrants. I should make it clear that I am here referring to the
grounds upon which an extension of time was sought.

11. The application was made by the same solicitors as had appeared for the applicant at the extradition
hearing. They indicated that an NRM referral had been made. They also said that the renewal grounds
would contain an application for funding for a psychiatric report. The draft renewal grounds are dated 1
March. They were drafted, as I have said, by Natasha Draycott. They rely upon an additional proof of
evidence dated 12 January 2024, from the applicant, but unsigned. It gives an account in broadly similar
terms to his proof before the Magistrates Court, but with greater detail. I note that paragraph 2 says that
he owed the traffickers $22,000 for travel expenses to the Czech Republic. I also note that in paragraph 3
of his proof before the District Judge, and in the judgment at paragraph 42, the debt was said to have been
$7,000.

12. Paragraph 7 refers to mental health issues. No application was made for a psychiatric report, although
it was alleged in the renewal grounds at paragraph 5 that there had been a marked deterioration in mental
health in recent conferences It was also said that the medical notes had been requested It appears that


-----

the Salvation Army had been asked to refer the applicant to the NRM. They interviewed him on 1 May
2024. The medical notes have not been produced to the court, and no explanation has been given as to
why that has not been done.

13. To bring matters up to date, counsel saw the applicant in prison on 3 May 2024. Counsel and
solicitors then applied to the court to be removed from the record. The reasons were given in an email
dated 7 May, namely that advice was given to the applicant about the merits of his application, and that
there had been an irretrievable breakdown in professional relations. The applicant said he wished to
represent himself today with the aid of an interpreter.

14. There is no criticism of the way in which the judge dealt with the modern slavery issue as a factor in
the Article 8 balancing exercise. There is no suggestion that the issue could have been a freestanding bar
to extradition. There is no suggestion that the Czech Republic would not respect the Convention on
trafficking if the applicant were to be extradited. It is common ground that he has a right to a retrial. I refer
to what the District Judge said in paragraph 76 of his judgment, to which there is no challenge.

15. Putting to one side for the moment the new proof of evidence from the applicant, in my judgment, it is
not arguable that the judge was wrong in his application of Article 8.

16. Turning to the new material, I have regard to the case of Fenyvesi [2009] EWHC 231 (Admin). The
new material was available to the applicant at the time of the hearing. No good reason has been given for
this evidence not having been adduced at the hearing.

17. In any event, having considered that new material together with all the other material before the court,
I have reached the firm conclusion that it is not arguable that that new material would have resulted in the
judge deciding the Article 8 issue differently.

18. This morning in his oral submissions to the court, Mr Do has reiterated his fear that the traffickers have
a connection with the prison system in the Czech Republic. He points out that he has no relatives or family
in the Czech Republic, whereas he has a girlfriend and a brother in this country. These matters were taken
into account by the District Judge, I see no arguable basis upon which this court could say that they would
lead the court to conclude that his decision was arguably wrong.

19. For all these reasons, the renewed application for permission to appeal against the extradition order
must be refused.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 46 Chancery Lane, London WC2A 1JE

Email: civil@epiqglobal.co.uk

(This judgment has been approved by the judge)

**End of Document**


-----

