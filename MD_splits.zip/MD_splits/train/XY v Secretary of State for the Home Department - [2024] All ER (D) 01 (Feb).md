# XY v Secretary of State for the Home Department [2024] All ER (D) 01 (Feb)

[2024] EWHC 81 (Admin)

King's Bench Division, Administrative Court (London)

Mr Justice Lane

23 January 2024

**IMMIGRATION – ASYLUM SEEKER – MODERN SLAVERY**
Abstract

_The Administrative Court allowed the application for judicial review by the claimant Albanian national against the_
_defendant Secretary of State's refusal to consider his entitlement for leave to remain in the UK as a victim of_
**_modern slavery pending the determination of his asylum claim. Following the judgment in R (on the application of_**
_KTT) v Secretary of State for the Home Department [2021] EWHC 2722 (Admin) (KTT), the claimant had contended_
_that the Secretary of State had operated a secret policy, where its officials had been instructed not to render_
_decisions in cases where confirmed victims of_ **_modern slavery had sought asylum on the grounds of fear of re-_**
_trafficking. It fell to be determined, among other things, whether the Secretary of State had breached the duty of_
_candour in failing to have disclosed in its pre-action response, the existence of the unpublished policy. The court_
_held, among other things, that the Secretary of State had adopted a policy in the light of KTT, which had not been_
_given effect to by amending the published policy. Consequently, the Secretary of State had breached its duty of_
_candour for failure to have disclosed the existence of the unpublished policy and had taken two decisions regarding_
_the claimant's entitlement to modern slavery leave but had not served those decisions on the claimant._
Digest

The judgment is available at: [2024] EWHC 81 (Admin)

**Background**

The claimant was an Albanian national who had arrived in the UK and claimed asylum. The claimant was
diagnosed with post-traumatic stress disorder for which he underwent therapy which continued until the service was
terminated because of a lack of funding. In 2021, the Single Competent Authority promulgated a positive conclusive
grounds decision, accepting that the claimant had been subjected to modern slavery. The defendant Secretary of
State for the Home Department (Secretary of State) informed the claimant's solicitors that a provisional decision
had been made and that the decision regarding leave to remain under Council of Europe Convention on Action
against Trafficking in Human Beings 2005 (the Convention) was said to be going through internal checks. In 2022,
the claimant commenced the present judicial review proceedings which sought to challenge what was then the
ongoing refusal to make a decision on whether the claimant was entitled to leave to remain as a victim of modern
**_slavery. In 2022, the Secretary of State filed an acknowledgement of service. That contained the statement that the_**
Secretary of State had agreed to grant the claimant discretionary leave for a period of 12 months. On that basis, the
claimant was invited to withdraw his judicial review which he refused to do.

**Issues and decisions**

(1) Whether the Secretary of State's refusal to consider the claimant's entitlement to leave pursuant to the
Convention had been unlawful and contrary to the claimant's leave policy based on the Convention


-----

The claimant submitted, among other things, that the Secretary of State had operated what had been described as
a secret policy, which had been contrary to the rule of law, whereby the Secretary of State's officials had been
instructed to make decisions in cases where confirmed victims of **_modern slavery were seeking asylum on the_**
grounds of a fear of re-trafficking, but were told not to serve those decisions.

The declaration that had been contained in the order in R (on the application of KTT) v Secretary of State for the
_Home Department [2021] EWHC 2722 (Admin) (KTT) had represented the law and it had been an authoritative_
statement of what the Secretary of State's published policy had meant. It had been the Secretary of State's decision
to create a policy which had given effect to art 14 of the Convention. The Secretary of State could, therefore, have
decided that the policy should have been abrogated or amended if she had not wished to have accepted the
judgment in KTT but had not done so. While there might have been a political price to pay if, among other things,
the Secretary of State had merely amended the policy in order to have paused decision making, political
considerations of that kind could not have been allowed to have diluted the important rule of law principles
articulated in R (on the application of Lumba) v Secretary of State for the Home Department; R (on the application
_of Mighty) v same [2011] UKSC 12 and_ _R (on the application of Anufrijeva) v Secretary of State for the Home_
_Department [2003] UKHL 36 (see [53], [55], [58] of the judgment)._

Decisions in respect of the claimant including the refusal of leave to remain by reference to his medical needs, had
been made and then placed on file, rather than being communicated to him. The claimant had been given every
reason to think that his case had been progressed when, in reality, it had not. When judicial reviews had been
brought, the Secretary of State's reaction, upon being faced with such a judicial review, had been to have granted
discretionary leave to the person who had brought the proceedings. The Secretary of State's instructions to officials
meant that an individual would have received a discretionary grant of leave, notwithstanding KTT, if that had been
considered to have been necessary because of the individual's need for medical treatment. The claimant, however,
had originally been found by the Secretary of State not to have been entitled to leave in that regard. It had only
been when the Secretary of State had been supplied with further evidence at the pre-action stage of the present
proceedings that the Secretary of State apparently concluded that the claimant had been entitled to leave on that
ground. The effect of the secret policy had been to deny the claimant knowledge of the earlier negative decision on
that ground and the opportunity of challenging that decision at the stage when it would (but for the secret policy)
have been communicated to him (see [64], [68], [71], [72] of the judgment).

(2) Whether the Secretary of State's refusal to consider the claimant's entitlement to leave pursuant to the
Convention had breached his rights under art 4 and/or art 8 of the European Convention on Human Rights (the
Convention).

The Secretary of State submitted, among other things, that certain aspects of the claimant's witness statement had
been self-serving as he had claimed, among other things, that if his mental health had improved, he would try to
return to college. The claimant had also entertained the possibility of receiving additional benefits as a result of
being granted discretionary leave. In that regard, particular attention had been drawn to a pre-action protocol letter
which had shown that the claimant had been unable to work and that his anxiety had primarily been generated by
having to wait for an appeal in respect of his asylum claim.

Even if the Secretary of State's submissions had been right, it had not materially diminished the weight that had to
have been placed upon the claimant's witness statement. It had been understandable that an individual's main
focus might often have been on their asylum claim. That had not meant, however, that the person should have been
taken to have been indifferent towards the possibility of being granted leave to remain by reason of being a victim of
**_modern slavery. Art 8(1) of the Convention had been engaged in the claimant's case. The effect of the Secretary_**
of State's policy had been to materially impair the claimant's ability to have used judicial review to have challenged
that policy and obtain modern slavery leave to remain (see [87]-[89], [97] of the judgment).

(3) Whether the Secretary of State's decision to defer consideration of the claimant's entitlement to leave pursuant
to the Convention had breached his rights under art 14 of the Convention.


-----

There could have been no doubt that the claimant had had a relevant status within the meaning of art 14 of the
Convention. He had had the status as an asylum-seeking victim of **_modern slavery. Victims of_** **_modern slavery_**
who had claimed asylum had had the same need for **_modern slavery leave, pending the determination of their_**
asylum claim, as a victim of modern slavery who had not claimed asylum would have had. To have held otherwise
would have been inconsistent with the basic rationale of _KTT._ An individual who, as an asylum seeker, had not
gotten a negative decision in respect of their medical grounds case had accordingly been treated differently for no
reason other than that they had made an asylum claim and were therefore affected by the Secretary of State's
unlawful policy. The difference in treatment which had directly resulted from the operation of the unlawful policy had
not been justified (see [99], [100], [102], [103] of the judgment).

(4) Whether the Secretary of State had breached the duty of candour in failing, among other things, to have
disclosed in its pre-action response, the existence of the unpublished policy.

All the information which the claimant had had to drag out of the Secretary of State should have been disclosed by,
at latest, the stage when the Secretary of State first had filed detailed grounds of defence. It had been an approach
which, at almost every stage, involved revealing as little as possible, and only then in response to specific requests
from the other party (see [132] of the judgment).

_R (on the application of KTT) v Secretary of State for the Home Department_ _[[2021] EWHC 2722 (Admin), [2021] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6406-MM63-GXF6-850H-00000-00&context=1519360)_
_[ER (D) 05 (Nov), [2022] 1 WLR 1312 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6406-MM63-GXF6-850H-00000-00&context=1519360)_

_EOG v Secretary of State for the Home Department (AIRE Centre intervening); KTT v Secretary of State for the_
_Home Department_ _[[2022] EWCA Civ 307, [2022] All ER (D) 70 (Mar), [2022] 3 WLR 353 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6527-FDT3-CGX8-037K-00000-00&context=1519360)_

_R (on the application of Lumba) v Secretary of State for the Home Department; R (on the application of Mighty) v_
_same_ _[[2011] UKSC 12, [2011] 4 All ER 1, [2011] 2 WLR 671 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_

_R (on the application of Anufrijeva) v Secretary of State for the Home Department_ _[[2003] UKHL 36, [2003] 3 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6160-00000-00&context=1519360)_
_[827, [2003] 3 WLR 252 explained](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6160-00000-00&context=1519360)_

_R (on the application of PK (Ghana)) v Secretary of State for the Home Department_ _[[2018] EWCA Civ 98, [2018] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RP8-P361-DYBP-N228-00000-00&context=1519360)_
_[ER (D) 86 (Feb), [2018] 1 WLR 3955 explained](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RP8-P361-DYBP-N228-00000-00&context=1519360)_

_Malcolm v Ministry of Justice_ _[[2011] EWCA Civ 1538, [2011] All ER (D) 98 (Dec) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:54GS-P1T1-DYBP-N13B-00000-00&context=1519360)_

_Mendizabal v France (Application no. 514314/99) considered_

_R (on the application of Balajigari) v Secretary of State for the Home Department and other appeals_ _[2019] EWCA_
_[Civ 673, [2019] 4 All ER 998, [2019] 1 WLR 4647 explained](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XJR-HW73-GXFD-830J-00000-00&context=1519360)_

_R (on the application of JP) v Secretary of State for the Home Department; R (on the application of BS) v Secretary_
_of State for the Home Department_ _[2019] EWHC 3346 (Admin),_ _[[2020] All ER (D) 65 (Jan), [2020] 1 WLR 918](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y1K-3F63-CGXG-03S4-00000-00&context=1519360)_
considered

_G v Director of Legal Aid Casework (British Red Cross Society intervening)_ _[[2014] EWCA Civ 1622, [2015] 3 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GNX-7641-DYBP-M1YX-00000-00&context=1519360)_
_[827, [2015] 1 WLR 2247 explained](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GNX-7641-DYBP-M1YX-00000-00&context=1519360)_

_R (on the application of Kyeremeh) v The Secretary of State for the Home Department (2017)_ _[[2017] EWCA Civ](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5ND3-H9N1-F0JY-C02W-00000-00&context=1519360)_
_[213 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5ND3-H9N1-F0JY-C02W-00000-00&context=1519360)_

_R (on the application of IAB and others) v Secretary of State for the Home Department and another_ _[2023] EWHC_
_[2930 (Admin), [2023] All ER (D) 116 (Nov) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69PJ-2G73-RRY3-04JM-00000-00&context=1519360)_

Application allowed (see [142] of the judgment).


-----

C Buttler KC and Z McCallum (instructed by Asylum Aid) for the claimant.

C McGahey KC and W Irwin (instructed by Government Legal Department) for the Secretary of State.
Lucy Bredenkamp, Attorney.

**End of Document**


-----

