# R v MC and Others [2019] EWCA Crim 1026

CA, CRIMINAL DIVISION

2019 01312/01313/00994/01144/01147/01026 A2

LORD JUSTICE DAVIS

Thursday 16th May 2019

16/05/2019

Mr Louis Mably QC appeared on behalf of the Attorney‑General

Mr Martin McCarthy appeared on behalf of the Offender/Applicant MC

Mr Anwar Afzal appeared on behalf of the Offender/Applicant MB

**Mr Alex Rose appeared on behalf of the Applicant JP**

**Ms Claire Davies appeared on behalf of the Applicant JC**

J U D G M E N T

(Approved)

1. LORD JUSTICE DAVIS:

Introduction

2. As previously announced, reporting restrictions apply to this judgment until further order.

3. The Solicitor General in this case seeks to challenge sentences imposed in respect of two offenders on the
ground that those sentences are unduly lenient. Simultaneously, those same two offenders seek to challenge the

sentences imposed upon them on the ground that they are manifestly excessive. A further two other co‑accused

also seek to challenge the sentences imposed upon them likewise on the ground that, so it is said, they are
manifestly excessive. We will deal with all these various applications together.

4. We should make clear that all the offenders appearing before us have outstanding applications for leave to
appeal against conviction, upon which the Court has not yet ruled. Nothing that is said in the course of this
judgment should be taken as having any bearing upon the correct outcome for those applications with regard to
conviction.

Background Facts

5. The background facts can be taken from what is set out in the final Reference itself, which is in turn heavily
based upon the judge's own crystal clear exposition of the factual background made in the course of her sentencing
remarks.


-----

6. The two offenders who are the subject of this Reference are both Polish nationals. One, who may be styled
'MC', is now aged 30; the other, who may be styled 'MB', is now aged 50.

7. On 22nd February 2019, after a trial lasting several months in the Crown Court at Birmingham before Her

Honour Judge Stacey and a jury, the offenders, and certain co‑accused, were convicted of various offences relating

to human trafficking into the United Kingdom, human trafficking within the United Kingdom, labour exploitation and

money laundering. The co‑accused in the trial and who are involved in two instances in applying for leave to appeal

against sentence included a young woman, who may be styled 'JC', who is now aged 24, and another woman, who
may be styled 'JP', who is now aged 48.

8. There were seven counts on the indictment, each charging a conspiracy. The first six counts had in fact been
[split into pairs of counts to reflect the coming into force of the Modern Slavery Act 2015 on 31st July 2015, which](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
was during the period of the operation of the criminal scheme.

9. Thus, count 1 was a count of conspiracy to traffick persons into the United Kingdom for the purpose of labour
exploitation by reference to section 4(1)A of the Asylum and Immigration (Treatment of Claimants etc) Act 2004.
The period of the conspiracy as particularised in that count was between June 2012 and 31st July 2015.

10. Count 2 was a corresponding count of conspiracy to arrange or facilitate the travel of persons to the United
Kingdom with a view to exploitation by reference to section 2(1) of the Modern Slavery Act 2015. On this count the
particularised period of the conspiracy was between 1st August 2015 and 31st October 2017.

11. The like approach was adopted with regard to counts 3 and 4, which in essence involved trafficking within the
United Kingdom. Similarly also with regards to counts 5 and 6, which involved conspiracy, in effect, to require
another to perform forced or compulsory labour. Count 7, on the other hand, was a count of conspiracy to acquire
criminal property by reference to section 329(1) of the Proceeds of Crime Act 2002. That particular conspiracy was
particularised as lasting between 1st June 2012 and 31st October 2017.

12. When the judge came to pass sentence, she very sensibly decided to impose concurrent sentences on all
counts, making it clear that she “loaded” the lead counts so as to reflect the totality of the offending.

13. So far as MC was concerned, he was convicted on six of the seven counts of the indictment. The count
reflected in count 2 was not pursued against him. He received a total sentence of 11 years' imprisonment.

14. So far as MB was concerned, he was convicted on all seven counts and received a total sentence of 9 years'
imprisonment.

15. So far as JC is concerned, she was convicted on counts 5, 6 and 7 (the only counts on which she faced trial),
and received a total sentence of 7 years.

16. The co‑accused 'NZ' was convicted on six of the counts on the indictment (she was not convicted on count 2),

and received a total sentence of four‑and‑a‑half years' imprisonment.

17. So far as JP was concerned, she only faced trial on counts 5, 6 and 7. She received a total sentence of 8
years' imprisonment.

18. In addition, Slavery and Trafficking Prevention Orders were imposed with regard to each offender.

19. The offenders were part of an organised criminal gang involved in the large‑scale, sophisticated and extensive

trafficking of Polish nationals to and within the United Kingdom for the purposes of exploitation. The criminal
operation, which was essentially family run, was said to take place between June 2012 and October 2017.

20. At the trial (which, as we have said, lasted over many months) as many as 66 victims gave evidence.
However, there was other evidence in the case indicating that a significant number of other individuals had also


-----

been trafficked and controlled by the gang during the period of the conspiracy. The precise number is impossible to
say, but it may be that up to 200 were identified as potentially being involved in that regard. The victims were
mostly male, although sometimes female. The youngest was aged 17 and the oldest in their 60s. Some were
subjected to forced labour for a period in excess of two years.

21. The position was that recruiters had operated across north-eastern Poland, approaching vulnerable individuals
outside homeless shelters and other known gathering places, in particular for those with drug or alcohol issues.
Common characteristics of those approached included homelessness and financial desperation; and many had a
fragile state as mental health. In effect, the victims were induced to travel to the United Kingdom against the
promise of employment and wages of between £250 and £400 per week, as well as accommodation. Further, they
were pressured into making a quick decision. Those who decided to travel were taken to the United Kingdom by

coach or car or aeroplane, where they would be greeted at pick‑up points by English‑based members of the gang.

Sometimes they would be dropped off directly at one of the many houses that were used to accommodate the
arrivals.

22. The accommodation, as was established on the evidence, was in many cases squalid. The rooms were
overcrowded. There was often no hot water or heating or cooking facilities or furniture. Sometimes no bedding was
provided. There were instances of infestations of mice, bedbugs and other insects. In one of the properties there
were no working lavatories. In another property, victims were reduced to using water in the canal to wash. It is
right to say that the conditions in the houses controlled by MB did have hot water and bedding, and heating and
cooking facilities.

23. Few of those trafficked spoke English. Most had never been abroad before in their lives. They were vulnerable
and, in effect, wholly dependent upon the gang members.

24. Further, they would be escorted to various banks and made to open bank accounts, over which the gang then
exercised control. Benefits were claimed and loans were taken out in their names. In effect, as it was said, the
financial identity of the victims was stolen. The victims, moreover, were taken to employment agencies and job
centres to obtain National Insurance numbers and then provided with unskilled or low skilled jobs. These included
rubbish recycling, parcel sorting, vegetable harvesting, constructing fence panelling and construction work. They
would often be escorted to and from work, sometimes being driven several hours from home. Wages would
ordinarily be paid into the bank account that had been opened and would then be taken by the members of the
gang. The victims were paid only a small part each week of their actual wages and much less than they had been
promised. The judge was to find that, in typical cases, as much as £150 per week would be deducted by members
of the gang. Further, debts were manufactured and additional costs were imposed and in that way victims were
deprived of financial independence.

25. The control did not depend simply upon the vulnerability of the victims; it was also reinforced by fear and by
violence. Sometimes victims were moved at night from one house to another in order to unsettle them. They did
not know where they were or at what address they were living. On occasions, when victims challenged the gang in
relation to their living conditions or wages, they would be subjected to threatened or (on occasion) actual violence,
including sexual violence, and other forms of intimidation. Some were beaten. Others were told that retribution
would be visited on their families back home. Some were told that they could go home, but, if so, it would be
without one of their limbs. Several were told they would be taken to the woods and forced to dig their own grave.
One of the women involved was told that if she refused to work as directed she would be put to work as a prostitute.
There was encouragement to report on others, and those who were more compliant were sometimes given extra
privileges.

26. It was said that the value of the financial exploitation of the victims was in the region of £380,000, though when
the total value of the wages and bank accounts were taken into consideration, the criminal property generated by
the conspiracy involved some further £2 million.

27. It appears that the poverty to which some of the victims was subjected led to them relying on food banks and
soup kitchens to survive. As it happened, the organisers of one of the soup kitchens began to note complaints


-----

made to them by some of the victims, and in the event, and very commendably, they ultimately reported the matter
to the police. This then led to a detailed and thorough police investigation and ultimately the arrest of the offenders.

28. The position as advanced on the evidence was that the operation was centred around the 'B' family. It was and
is the prosecution position that the head of the operation was a member of the family who may be styled 'AB'. He,
along with others, as we gather, is currently in Poland awaiting extradition to the United Kingdom for trial.

29. So far as the accused in this particular case are concerned, MC was a family friend. He was described by the

judge as, in effect, AB's right‑hand man. He was assessed as playing a leading role in the offending from at least

2014. He concentrated his efforts particularly on trafficking within the United Kingdom and the financial exploitation
of the victims. He was, as the judge was to find, in a very senior management role, extremely active in the
operation and central to its success, albeit operating under the overall direction of AB himself. MC would meet new
arrivals and would be instrumental in opening of bank accounts. He was, as the judge was to assess, able to
present a "respectable face" to banks and employment agencies, and he had a good grasp of the benefits system.

He was also the main point of contact with a particular employment agency, where the co‑accused JC was working

on the inside. MC would liaise with AB in this regard.

30. MC did not engage himself directly in any violence, but, as the judge was to find, in effect relied upon others to
carry out any acts of violence or threats that may be needed. MC controlled the bankcards and, as was found,
directly controlled one of the houses where living conditions were particularly squalid.

31. During the course of the overall conspiracy, he was arrested twice, but he continued to participate in them even
when on police bail. After his second arres,t he returned to Poland in June 2015. It appears that his activities then
were on a somewhat lesser scale. Nevertheless, he still continued his involvement and continued to an extent to
coordinate activities in the United Kingdom, at least until the early part of 2016. The overall assessment of the
judge was that he continued to be involved at a strategic level.

32. So far as MB is concerned, he is AB's uncle. He was involved in the operation from at least 2014. As the
judge was to find, as a senior family member he had an influential and high-level significant role. He personally
recruited victims in Poland and trafficked them into the United Kingdom, both before and after 31st July 2015. He
put some of those trafficked to work in decorating his own home. He arranged work for some victims at a parcelsorting factory. He was also involved in distributing the meagre wages to many victims. He ran, as was found, an
"unsavoury" property, also controlling the financial correspondence that was sent there. He was not himself
personally violent to the victims, but, as was found, he knew that the victims were variously subjected to violence
and threats. He also had some involvement after 31st July 2015, although there was no specific evidence of any
involvement after the early part of 2016.

33. Turning then to the co‑accused, JC was involved in the offending from February to November 2015. At the age

of 19 she had been introduced into the conspiracy by MC, and she was involved for a relatively short time
compared to the others. Nevertheless, her role was assessed by the judge as significant and extraordinarily
productive during that short period. She worked for a particular employment agency and, together with MC,
organised jobs for the trafficked workers, she using her position to circumvent internal systems designed to detect
**_modern slavery. In effect, she had infiltrated the employment agency and she worked from the inside to advance_**
the criminal operation. She registered 24 trafficked workers with the agency, receiving a £100 fee for each. It had
also been arranged that she would receive some £20 per week from the wages of each worker, even if she did not
end up actually getting it. As the judge was to find, she was an enthusiastic participant, motivated by financial gain.
Although she was not personally cruel or hostile to the victim to their face, there was evidence that behind their
backs she was contemptuous towards them.

34. The co‑accused NZ had been the partner of MC for three years and involved until late 2014 and early 2015. It

was determined that she played a lesser role ‑ in fact she was considered the least involved of the five offenders ‑

and had no involvement in any strategic aspects. It was assessed that, to some extent, she had been used by MC
and by AB Nevertheless she had participated to an extent and had benefited She trafficked workers within the


-----

United Kingdom, taking them to job centres. She also had some of the trafficked workers living in her house, where
it seems they lived in relatively good conditions. Nevertheless, she took half their wages and controlled their bank
accounts.

35. JP is AB's mother. She was described as "the matriarch" of the family. It was assessed that she played a
significant role in the operation, albeit strategic decisions had been left to the men in the family. She permitted her
home to be used as, in effect, a head office for the operation. To her knowledge, bankcards were stored at the
house and new recruits were often taken there when they first arrived in the United Kingdom. On occasion, she
personally withdrew funds from the victims' bank accounts. There was no evidence that she had been personally
cruel to any of the victims, but it was assessed that she knew that they were being exploited and knew that their
living conditions were poor. She also on one particular occasion when a man died at one of the houses (he was not
a worker but had happened to be staying there at the time) had made arrangements that all relevant identity
documents be removed.

36. So far as previous convictions are concerned, MC has no previous convictions in England, but does have a
previous conviction for an offence of fraud committed in Poland in 2008. He has had a major heart condition, which
has required major surgery, and his health is fragile. He has a young child. MB has no relevant previous

convictions of any kind. Nor do the co‑accused JC and JP.

The judge's sentencing remarks

37. The judge is to be strongly commended for her very thorough, detailed and clear sentencing remarks. She sets
out the background facts, as we have already indicated, with crystal clarity. She made clear findings, where there
was a dispute on the evidence, with regard to the participation and roles of the respective accused, and she gave
her reasons as to why she assessed the respective culpabilities as she did. Mr Mably QC, appearing on behalf of
the Solicitor General, makes clear that he expresses no criticism whatsoever of the sentencing remarks in terms of
leaving out of account relevant matters, or taking into account irrelevant matters, or a misassessment of the legal
position and correct approach. His overall submission is that, so far as these two particular offenders the subject of
the Reference are concerned, the judge simply got it wrong in terms of the sentence ultimately selected.

38. At the outset of her sentencing remarks, the judge said this, in language which is entirely apposite:

"The reason why human trafficking and subjecting others to forced or compulsory labour is so abhorrent is because
it is a deliberate and wilful devaluation of the life of another human being through exploitation, subjecting them to a

demi‑life of misery and poverty by forcing them to work under threat or fear of punishment for others' profit. It robs

the victims or survivors of their autonomy, their dignity and their humanity without care or regard for the rights of the
individuals affected. The accounts of the complainants in this case, both in their victim personal statements and the
evidence they gave to the court about what happened to them, are powerful illustrations.

Any lingering complacency after the 2007 bicentenary celebrations of the abolition of the English Slave Trade was
misplaced. The hard truth is that the practice continues here in the UK, often hiding in plain sight. Abolition was
one thing. Stopping the enslavement and use of human beings as commodities for financial gain and bringing the
perpetrators to justice is quite another. Deterrent sentences are, therefore, required to reinforce the message that
the degradation of the worth of a fellow human being through labour exploitation, contrary to the Modern Slavery
Act and the predecessor legislation, is totally unacceptable."

39. The judge then summarised the facts in detail. The judge was to describe that what was involved was "the
most extensive, ambitious and prolific network of interlinked, overarching conspiracies to traffick large numbers ...
into the UK for the purposes of two forms of exploitation".

40. The judge described in graphic detail the squalid condition of some of the properties. She described in detail
how victims were made to disgorge monies in their bank accounts in respect of their own wages. She described
the occasions of threats and sometimes actual violence. She further found, as she was entitled to do, that the


-----

conspiracies extended significantly beyond the 66 complainants who had been identified and who gave evidence at
trial, describing the overall conspiracies as "It went much, much wider than the complainants".

41. The judge then reviewed various of the relevant authorities. But then made this important observation:

"Obviously here we are looking at forced labour and not serfdom or slavery."

42. The judge then turned to the respective roles. So far as MC was concerned, as we have indicated, the judge
found that he played a leading role in the conspiracy from at least 2014, occupying a very senior management
position, although not being at the very head of the operation. The judge set out further detailed matters with
regard to him.

43. So far as MB was concerned, the judge again made relevant findings in this regard, finding that he was not
purposefully violent but nevertheless knew what was going on. The judge accepted he had direct involvement with
fewer of the complainants than, for example, MC; but, as she found, he "participated in all aspects ... As an elderly
family member, he had an influential, high level significant role and has been involved in the conspiracies at least
since 2014."

44. Turning to JC, the judge found that she had a crucial and extraordinarily productive role in the short period in
which she was involved. The judge accepted that she had not been involved in the trafficking or accommodation
side of the operation, but nevertheless her inside role at the employment agency had been invaluable. The judge
took a very poor view of JC, having observed her give evidence at trial over a period of some days, describing her
as "grasping" and "motivated by gain". The judge also described her as an "enthusiastic participant", at the same
time being "clever, smart, manipulative and charming".

45. The judge then made certain observations with regard to NZ, as to which we do not need to say anything
further at this stage.

46. So far as JP was concerned, the judge accepted the prosecution description of her as the “matriarch” of the
family. The judge said:

"She played a significant and facilitating role in the conspiracy, although I accept that the strategic leading roles
were reserved for the men folk."

47. The judge then made findings along the lines we have already outlined, whereby she had permitted her home
to be used as a head office and her various involvement in taking payments of wages out of the bank. The judge
noted that a number of the complainants had in fact spoken well of her and she had not personally been unpleasant
to any of them. However, as the judge found, "she was complicit in the acts of others". It is right to add that JP has

very considerable on‑going health issues, both of a physical kind and of a psychological kind. She is suffering from

a major depressive disorder, and indeed she was not in a fit position to give actual evidence at trial.

48. The judge further noted that the various defendants had been on bail for a very extensive period, and she
explicitly deducted one year from her original starting point in respect of each of them to reflect such matters. The
judge then proceeded to impose the sentences we have indicated.

Disposal of reference

49. In approaching cases of this kind, there being no sentencing guideline as yet issued by the Sentencing Council

in this regard, it is usual to have regard to the observations of Lord Judge LCJ in the case of Attorney‑General's

Reference (Connors) [2013] 2 Cr App R (S) 71 at paragraph 10. Further, it is also usual to apply the criteria set out

in the case of Attorney‑General's Reference (Khan) [2011] 2 Cr App R (S) 31, as indicating relevant factors in

assessing the appropriate sentence in such cases of trafficking or false labour.


-----

50. This Court, as was the trial judge, was also referred to the case of Attorney‑General's Reference (Zielinski)

[2017] EWCA Crim 758. That was a case that had a certain broad similarity in type to the present case by
[reference to the Modern Slavery Act 2015. In that particular case, the conspiracy had lasted some nine months](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
and involved vulnerable Poles being trafficked from Poland into the United Kingdom. There were six specific
complainants, although it was assessed that there would have been more involved as well. As here, they were
miserably housed, subjected to violence and required to work for derisory wages. The defendant in that particular
case, after a trial, received a sentence of 4 years' imprisonment from the trial judge; but that sentence, on a
Reference, was increased by a constitution of this Court to one of 7 years' imprisonment. The defendant in

question was a 20‑year‑old, who had been described as a "lieutenant" in the whole operation. Overall the

conspiracy in that particular case was of a significantly lesser scale, in terms of organisation and volumes of those
trafficked, than the present case.

51. We were further referred to the very different case of Attorney‑General's Reference (Iyamu) [2019] 1 Cr App R

[(S) 16 and also to the recent case of Rooney [2019] EWCA Crim 689. We need not, however, discuss those cases](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VBJ-FT22-D6MY-P2PJ-00000-00&context=1519360)
further: because ultimately, and as Zielinski itself stresses, all these cases ultimately turn on their own particular
facts and circumstances. That said, all the cases are united in stressing the need for appropriately severe
sentencing for serious and exploitative criminality such as this.

52. In submitting that these sentences so far as these two offenders (that is to say, MC and MB) are concerned, Mr
Mably drew attention to the following particular features of this case. First, the offending involved a high level of

organisation and planning. Second, the operation had been extensive and "multi‑dimentional", covering the

trafficking of victims both to and within the United Kingdom, and requiring them to perform forced or compulsory
labour. Third, deception had been involved from the outset in persuading vulnerable victims to travel to the United
Kingdom. Fourth, a large number of victims was involved. Fifth, the criminal operation took place over a long
period of time and was persistent, and in MC's case continued after arrest and whilst he was on police bail. Sixth,
the victims were vulnerable individuals. Seventh, they were subjected to a high level of control, imposed, where
necessary, by various coercive methods, including actual or threatened violence. Eighth, the conditions in which
the victims lived were squalid for the most part. Ninth, significant harm was caused to the victims. Tenth, the
offending took place for significant financial gain.

53. As against that, it is said the mitigation available was relatively limited so far as these two offenders are
concerned. MC has his poor health conditions and MB had no relevant convictions. There could of course be no
credit for any plea because the trial had been contested.

54. But, overall, the essence of Mr Mably's submissions was to emphasise the scale, sophistication and
seriousness of the conspiracy involved, which mandated, he said, exceptionally long sentences.

55. It is perhaps a feature of this Reference that it is accepted that the sentences imposed might have been
considered appropriate had the maximum available been that of 14 years' imprisonment, which was the maximum
available up until 31st July 2015. But it is said that what makes the, or at all events a, difference here is that the
conspiracies specifically charged both antedated and postdated the 31st July 2015; and for the latter period there
was no limit in terms of the maximum sentence available.

56. That point is technically correct, as we see it. But it does not, with respect, have the force that perhaps Mr
Mably would ascribe to it. Looking at the position overall, this was in substance one conspiracy, which was
established at a time significantly antedating July 2015, albeit people joined and participated at various times. Had
the matter been charged as one conspiracy then the maximum sentence would indeed have been limited to 14
years' imprisonment: see Hobbs [2002] 2 Cr App R 3. Nevertheless, it is right that, entirely properly, the
conspiracies were separately charged and included conspiracies postdating 31st July 2015. Nevertheless, that
being said, it does appear that, so far as MC and MB were concerned, although their involvement in the
conspiracies continued, that does not necessarily seem to have been at the same level as before; and at all events
their involvement, on the evidence, seems to have ended in the very early part of 2016. Consequently, in the


-----

circumstances of this particular case, it is necessary to bear in mind that a very significant part of the offending

occurred when the 14‑year maximum applied.

57. In any event, given the judge's sentencing remarks, it is plain that she had taken a starting point in the case of
MC of around 12 to 13 years, before making deductions in respect of the delay and personal mitigation in the form

of health. It is clear overall that the judge had not regarded herself as fettered by any 14‑year maximum term. The

same considerations apply to her approach to the offender MB.

58. With regard to their roles, the judge made careful findings as to the extent of involvement and the respective
culpability of these offenders. This Court has no basis for interfering with the judge's assessment, the more so
when she set out her findings very clearly. Furthermore, she of course had been the trial judge conducting a trial
which had lasted several months and therefore, very importantly, would have had a very good grasp of the feel of
the overall case.

59. By reference to the judge's findings and by reference to the required approach, our finding is that it cannot be

said that these sentences were unduly lenient. This was a matter for the judge's assessment ‑ a judge, as we have

said, who had conducted the trial. We see no proper basis for this Court seeking to interfere in the sentences
imposed upon these two offenders on the ground that they were unduly lenient. In such circumstances, we refuse
leave to refer in each case.

Appeals against sentence

60. We turn then to the applications of the various defendants with regard to sentence on the ground that, as they
say, the sentences in each of their cases were manifestly excessive. We will take the cases of MC and MB first.

61. We can deal with MC very shortly. That is because this morning Mr McCarthy, counsel on behalf of MC and
having discussed it carefully and fully with his client, has conceded that he cannot pursue an argument that the
sentence of 11 years imposed by the judge was manifestly excessive. In such circumstances, we need say no
more about his particular application, save to say that we in fact think that Mr McCarthy's appraisal was wholly
realistic.

62. However, Mr Anwar does pursue the application for leave to appeal against sentence in the case of MB. In a
number of respects Mr Anwar has sought to challenge the judge's appraisal of the role and involvement of MB.
However, as we have already indicated, we can see no basis for interfering with the judge's carefully articulated
assessment. It is true that a number of points can be made in MB's favour. Nevertheless, overall, he knew what
was going on and had a significant role.

63. To the extent that Mr Anwar also sought to pray in aid certain observations made by the judge at an earlier
stage in the proceedings at the conclusion of the prosecution evidence that leads nowhere. What matters is the
judge's ultimate appraisal when she came to pass sentence in the light of the totality of the evidence adduced. As
the judge was to find, MB was "fully aware" of the scope of the conspiracy, and he had a "high level significant role"
at least since 2014 up to the beginning of 2016, and that remained so even if he had direct involvement with fewer
complainants. We see no basis for interfering with the judge's conclusion in this regard.

64. To the extent that Mr Anwar sought to say that on analysis this case was, so far as MB is concerned, less
serious than the case of Zielinski, we do not agree. The scale of this operation was far bigger than in Zielinski.
Moreover, it must be recalled that in Zielinski that was a case of an Attorney General's Reference and the Court's
conclusion was that the very least sentence appropriate was 7 years' imprisonment on the facts and circumstances
of that particular case. We refuse MB's application for leave to appeal against sentence.

65. We then turn to the applications of the two co‑accused JC and JP. We deal with JC first. We have to say that

we find the position with regard to each of these two accused far more difficult and we grant leave to appeal against
sentence in each case.


-----

66. So far as JC is concerned, it is clear from the judge's sentencing remarks (some of which we have already set
out) that the trial judge took a very poor view of her, describing her as grasping and manipulative and so on. We
have no reason to interfere with that particular assessment of the judge. Moreover, we have no reason to interfere
with the judge's assessment that in the period for which she was involved her role had been "crucial" and
"extraordinarily productive". The judge's assessment was that her role had been significant in the period in which
she was involved.

67. But all that said, and notwithstanding the seriousness of JC's conduct, there were other considerations. First

and very importantly, her involvement was limited to the period between February and November 2015 ‑ as the

judge herself noted, a relatively short time compared to some of the others. Indeed, she had very little active
involvement in what went on after July 2015, as Ms Davies pointed out.

68. Moreover, whilst she was aware of the overall scale of the operation, as was accepted, she played no part in
the actual trafficking into the United Kingdom, played no part of the trafficking within the United Kingdom and played
no part in the accommodation arrangements. Indeed, we gather that it was not put to her that she was positively
aware of threats of violence being made to complainants, even if she may have appreciated, because of her
comments about the dishevelled appearance of some them, that they were not living in particularly good conditions.
Thus, her general knowledge of the scale and method of operation of the conspiracies was relatively limited.
Furthermore, as Ms Davies also pointed out, the actual employment which she secured for the individuals involved
proper conditions of employment.

69. In essence, therefore, her role was one of dishonesty, in deceit of her employers, acting as an insider with a
view to gain both for the conspirators and for herself, albeit of course, and importantly, in the context of a
conspiracy to require others to perform forced or compulsory labour and in the context of a conspiracy to acquire
criminal property.

70. It is in this regard to be recalled and noted that she had only been charged on three counts on the indictment,
being counts 5, 6 and 7.

71. Furthermore, it seems to us to be a very important consideration that her involvement only started at the age of
19 and she was barely 20 (if indeed 20) at the time her involvement ceased. Yet, it is to be observed, her sentence

was only two years less than that of MB, who on any view had had a much longer‑standing and much more

significant and wider role than she did.

72. We do think, looking at matters in the round, that bad though her conduct was, her sentence of imprisonment
as imposed by the judge was too long. We quash the sentence. We take the view that the appropriate overall
sentence in her case is one of 5 years' imprisonment. We will substitute concurrent sentences of 5 years'
imprisonment on counts 5 and 6, and a further concurrent sentence of 4 years' imprisonment on count 7 to achieve
that overall result. Her appeal is allowed to that extent.

73. We now turn to the appeal of JP. We have to say that in her case too it seems most surprising that she should

receive a sentence of just one year less than that of MB, and indeed, on the other hand, three‑and‑a‑half years

more than that of the co‑accused NZ, who, although having limited involvement, had been convicted on six counts

on the indictment whereas JP was convicted only on counts 5, 6 and 7.

74. It is plain enough that she had a general knowledge, in general terms, of what was going on. But, on the
judge's findings, her active participation was relatively limited, even if she could be described as "the matriarch". In
effect, she had left strategic decisions to others and she personally had been kind to complainants; certainly some
of them had in evidence spoken out favourably of her. Clearly she must have had some awareness of the squalid
living conditions in which some of the complainants were living because she visited one or two of the properties,
and of course she had had various specific involvements in keeping of bank cards and obtaining money
withdrawals in some cases, and in concealing the identity of a deceased man who had been living in one of the
houses in one other specific instance. But overall, even on the judge's own finding, she does seem to have been


-----

very much lower down in the scheme of things as compared to others, such as MC and MB. We think that there is
real force in Mr Rose's complaint that the judge took too high a starting point in her particular case.

75. Moreover, in her case we think it important to give significant weight to her major health issues, both physical
and psychological. That was an important aspect of mitigation in her case.

76. We think that the judge was entitled overall to impose a somewhat greater sentence in her case than that
imposed on JC. But, even so, we consider that a sentence of 8 years' imprisonment in her case was too long. We

think that the appropriate sentence in her case should be one of 5‑and‑a‑half years' imprisonment. We imposed

such sentences concurrently on counts 5 and 6. We impose a concurrent sentence of 4 years' imprisonment on
count 7, thereby achieving that result. Her appeal is allowed to that extent.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

165 Fleet Street, London EC4A 2DY

Tel No: 020 7404 1400

Email: Rcj@epiqglobal.co.uk

**End of Document**


-----

