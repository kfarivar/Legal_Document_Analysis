Home Department

# EOG v Secretary of State for the Home Department (AIRE Centre
 intervening); KTT v Secretary of State for the Home Department [2022]
 EWCA Civ 307

Court of Appeal, Civil Division

Sir Geoffrey Vos MR, Underhill VP and Dingemans LJ

17 March 2022Judgment

**Amanda Weston QC and Miranda Butler (instructed by Duncan Lewis) for EOG**

**Chris Buttler QC and Zoe McCallum (instructed by Duncan Lewis) forKTT**

**Robin Tam QC,** **William Irwin (in** **_EOG) and_** **Emily Wilsdon (inKTT)** (instructed by the Treasury
**Solicitor) for the Appellant**

**Ayesha Christie (instructed by Freshfields Bruckhaus Deringer LLP) for the Intervener**

Hearing dates: 8, 9 & 10 February 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Underhill:**

**INTRODUCTION**

1. The Secretary of State for the Home Department appeals against two separate decisions that aspects
of her policy about the grant of leave to remain to victims of trafficking are unlawful. In bare outline:

(1) EOG, who is a national of New Zealand, was at the time to which her claim relates a “potential victim of
trafficking”: that is, a decision had been made that there were reasonable grounds to believe that she was
a victim of trafficking, but a final (“conclusive grounds”) decision had not been made (she has since
received a positive conclusive grounds decision). Her complaint is that the Secretary of State's policy does
not provide for the grant of leave to remain to potential victims of trafficking. By a judgment handed down
on 3 December 2020 Mostyn J upheld that complaint.

(2) KTT, who is a Vietnamese national, was at the relevant time a confirmed victim of trafficking: that is,
she had received a positive conclusive grounds decision. She had also made a claim for asylum on the
basis of the risk of being re-trafficked if she were returned to Vietnam. Her complaint is that the policy
should have provided for the grant of leave to remain pending a decision on her asylum claim. By a
judgment handed down on 12 October 2021 Linden J upheld that complaint.

In both cases the basis of the Judge's decision was that the Secretary of State's policy did not comply with
the requirements of the Council of Europe Convention on Action against Trafficking in Human Beings
(“ECAT”).


-----

Home Department

2. EOG was represented before us by Ms Amanda Weston QC, leading Ms Miranda Butler, and KTT by
Mr Chris Buttler QC, leading Ms Zoe McCallum. The Secretary of State was represented in both appeals
by Mr Robin Tam QC, leading Mr William Irwin in EOG and Ms Emily Wilsdon in KTT.

3. The AIRE Centre was given permission to intervene in EOG. It filed written submissions settled by Ms
Samantha Knights QC and Ms Ayesha Christie, and Ms Christie also advanced short oral submissions.

4. The appeal in EOG was in fact listed before this Court on 15 July last year, but it was adjourned on the
application of the Secretary of State in circumstances to which I shall have to return.

**THE LEGAL FRAMEWORK**

THE RELEVANT PROVISIONS OF ECAT

5. ECAT was adopted by the Council of Europe on 16 May 2005. It has ten chapters. We are only
concerned with chapter III, which is headed “Measures to protect and promote the rights of victims,
guaranteeing gender equality”. It comprises articles 10-17. The articles which are relevant for our
purposes are articles 10 and 12-14.

6. Article 10 is of a preliminary character, in that it provides for how state parties should identify the victims
to whom the substantive benefits provided for in the rest of the chapter should be accorded. It reads (so
far as relevant):

“Identification of the victims

1. Each Party shall provide its competent authorities with persons who are trained and qualified in
preventing and combating trafficking in human beings, in identifying and helping victims, including children,
and shall ensure that the different authorities collaborate with each other as well as with relevant support
organisations, so that victims can be identified in a procedure duly taking into account the special situation
of women and child victims … .

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in Article 18 of this Convention has been completed by the
competent authorities and shall likewise ensure that that person receives the assistance provided for in
Article 12, paragraphs 1 and 2.

3-4. …”

7. Article 10 thus provides for an interim period between a “reasonable grounds” decision and the end of
the “identification process”, i.e. a final decision that a person is a victim: I will call this “the identification
period”. During the identification period the potential victim (1) “shall not be removed” and (2) must receive
the assistance specified in paragraphs 1 and 2 of article 12.

8. Article 12 reads (so far as relevant):

“Assistance to victims

1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:

a standards of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

b access to emergency medical treatment;

c translation and interpretation services, when appropriate;


-----

Home Department

d counselling and information, in particular as regards their legal rights and the services available to them,
in a language that they can understand;

e assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

f access to education for children.

2. Each Party shall take due account of the victim's safety and protection needs.

3. In addition, each Party shall provide necessary medical or other assistance to victims lawfully resident
within its territory who do not have adequate resources and need such help.

4. Each Party shall adopt the rules under which victims lawfully resident within its territory shall be
authorised to have access to the labour market, to vocational training and education.

5-7. ..."

9. The assistance provided for under paragraphs 1 and 2 of article 12 (which are those referred to in
article 10.2) is less extensive than that under paragraphs 3 and 4: in _R (JP) v Secretary of State for the_
_Home Department_ _[2019] EWHC 3346 (Admin), [2020] 1 WLR 918, Murray J helpfully labelled the two_
levels of assistance as “basic” and “enhanced”. Enhanced assistance is only available to victims who are
“lawfully resident”.

10. Article 13 reads:

“Recovery and reflection period

1. Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be
sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the competent authorities. During this period it shall not be possible
to enforce any expulsion order against him or her. This provision is without prejudice to the activities
carried out by the competent authorities in all phases of the relevant national proceedings, and in particular
when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise
the persons concerned to stay in their territory.

2. During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures
contained in Article 12, paragraphs 1 and 2.

3. The Parties are not bound to observe this period if grounds of public order prevent it or if it is found that
victim status is being claimed improperly.”

11. There is a considerable overlap between article 10.2 on the one hand and paragraphs 1 and 2 of
article 13 on the other, inasmuch as both provide that during the periods referred to the victim must not be
removed/expelled and shall receive basic assistance. That no doubt reflects the fact that in practice the
recovery and reflection period will fall wholly or partly within the identification period.

12. Article 14 reads:

“Residence permit

1. Each Party shall issue a renewable residence permit to victims, in one or other of the two following
situations or in both:

a the competent authority considers that their stay is necessary owing to their personal situation;

b the competent authority considers that their stay is necessary for the purpose of their cooperation with
the competent authorities in investigation or criminal proceedings.

2. The residence permit for child victims, when legally necessary, shall be issued in accordance with the
best interests of the child and, where appropriate, renewed under the same conditions.


-----

Home Department

3. The non-renewal or withdrawal of a residence permit is subject to the conditions provided for by the
internal law of the Party.

4. If a victim submits an application for another kind of residence permit, the Party concerned shall take
into account that he or she holds, or has held, a residence permit in conformity with paragraph 1.

5.  Having regard to the obligations of Parties to which Article 40 of this Convention refers, each Party
shall ensure that granting of a permit according to this provision shall be without prejudice to the right to
seek and enjoy asylum.”

13. It was common ground before us that article 14 applies only to victims who have been confirmed as
such at the end of the identification process provided for under article 10.2 (“confirmed victims”). It was
also common ground that “residence permit” means the authorisation which renders a non-national
“lawfully resident”, in the sense in which that term is used in article 12. (To anticipate, the way in which
“lawful residence” is typically accorded to non-nationals in the UK is by the grant of leave to remain under
section 3 of the Immigration Act 1971.)

14. I need not set out the other articles under chapter III, but I should note that article 15 requires state
parties to ensure that victims can pursue claims for compensation against their traffickers.

15. ECAT was accompanied at the time of its adoption by an Explanatory Report, which included a
detailed commentary on the individual articles. It also provided for a monitoring mechanism, in the form of
regular reports from a “Group of Experts on Action against Trafficking in Human Beings” (“GRETA”).

16. Three other international instruments dealing with the treatment of victims of trafficking are mentioned
in EOG's submissions – namely the European Convention on Human Rights (“the ECHR”), article 4 of
which also imposes some positive obligations on state parties in this field, and two EU Directives
(2004/81/EC and 2011/36/EU). They are reviewed in some detail at paras. 43-69 of the judgment of this
Court in MN v Secretary of State for the Home Department _[2020] EWCA Civ 1746, [2021] 1 WLR 1956,_
but they do not add anything to the argument in these appeals: see para. 54 below.

THE RELEVANT DOMESTIC LAW

17. ECAT was ratified by the UK in December 2008 with effect, as a matter of international law, from 1
April 2009. The provisions of chapter III have not been embodied in UK legislation. Instead the
Government chose to implement its obligations by administrative measures set out in published guidance
(or policy). The issuing of such guidance now has a statutory underpinning, though that was not the case
originally. Section 49 of the Modern Slavery Act 20151, which came into force on 15 October 2015, reads
(so far as is relevant) as follows:

“(1) The Secretary of State must issue guidance to such public authorities and other persons as the
Secretary of State considers appropriate about —

(a) the sorts of things which indicate that a person may be a victim of slavery or human trafficking;

(b) arrangements for providing assistance and support to persons who there are reasonable grounds to
believe may be victims of slavery or human trafficking;

(c) arrangements for determining whether there are reasonable grounds to believe that a person may be a
victim of slavery or human trafficking.

(2) The Secretary of State may, from time to time, revise the guidance issued under subsection (1).

(3) The Secretary of State must arrange for any guidance issued or revised under this section to be
published in a way the Secretary of State considers appropriate.

(4) …”

Guidance for England and Wales has been issued pursuant to section 49 (1) under the title **_Modern_**
**_Slavery: Statutory Guidance (“the Statutory Guidance”)._**


-----

Home Department

18. The first Statutory Guidance (version 1) was promulgated in March 2020 and was current until January
2021: it is therefore the version which is relevant for our purposes.2 The Secretary of State had previously
issued non-statutory guidance, under various titles, setting out her policy as regards the treatment of
victims of trafficking: the earliest that was shown to us was issued in October 2010. Save where it is
necessary to be specific, I will refer to the Statutory Guidance and its non-statutory predecessors, including
any other guidance documents to which they refer, as “the Guidance”.

19. The Statutory Guidance provides for a wide range of measures under the general label of “the National
Referral Mechanism” (“the NRM”). These include: a two-stage “victim identification and support process”
corresponding to article 10 of ECAT; the provision by the Salvation Army, under a “Modern Slavery Victim
Care Contract” (“the MSVCC”), of a subsistence level of support to potential victims of trafficking (“VoT
support”), as required by article 12.1; and a 45-day recovery period reflecting article 13. Decisions under
the NRM are made by what is referred to as “the Competent Authority” (a phrase transposed somewhat
unimaginatively from ECAT): originally there were several designated competent authorities, but a unit
within the Home Office is now “the Single Competent Authority”.

20. The grant of leave to remain to victims who are not UK nationals (or, at the time with which we are
concerned, EEA nationals) and do not have any other leave is addressed in paras. 15.154-157 of version 1
of the Statutory Guidance, which are headed “Discretionary Leave to remain” and read:

“15.154. Non-EEA nationals will automatically be considered for a grant of Discretionary Leave if they do
not already have the right to remain. EEA nationals may apply for discretionary leave. Victims will need a
positive Conclusive Grounds decision to be considered for Discretionary Leave.

15.155. Discretionary Leave to remain may be available where a victim is assisting as a witness in a
criminal investigation.

15.156. Full guidance on when Discretionary Leave will be granted to victims of **_modern slavery is_**
contained in Discretionary Leave consideration for victims of modern slavery [the underlining indicates a
hyperlink].

15.157. The guidance explains the circumstances in which it may be appropriate to grant Discretionary
Leave to individuals confirmed as victims of **_modern slavery by the NRM, and the considerations that_**
must be made before such a decision is made. It also deals with extending Discretionary Leave or
curtailing leave as necessary.”

Discretionary leave granted to victims of **_modern slavery is generally referred to as “modern slavery_**
leave” (or “MSL”), though that term is not used in the guidance itself.

21. As appears in paragraph 15.156, those paragraphs are summary only, and full guidance on the grant
of leave to remain is contained in separate guidance called Discretionary leave considerations for victims
_of modern slavery. I will refer to this as “the MSL Guidance”. When version 1 of the Statutory Guidance_
was issued the current version of the MSL Guidance was version 2, dated 10 September 2018, although
there have since been other versions. “Discretionary Leave” refers to leave to enter or remain granted, in
the exercise of the Secretary of State's general discretion under section 3 of the 1971 Act, in
circumstances not covered by the Immigration Rules. The exercise of that discretion has for many years
been the subject of published guidance. The guidance initially covered a range of circumstances in which
the discretion might fall to be exercised; but separate guidance covering victims of trafficking was first
published in August 2018 in the form of version 1 of the MSL Guidance.

22. The relevant parts of the MSL Guidance for our purposes read as follows (paragraph numbers inserted
for ease of reference):

“When to consider a grant of discretionary leave

[1] A person will not qualify for discretionary leave (DL) solely because they have been identified as a
victim of modern slavery - there must be reasons based on their individual circumstances to justify a grant
of DL where they do not qualify for other leave such as asylum or humanitarian protection.


-----

Home Department

[2] …

[3] Discretionary leave may be considered where a Competent Authority has made a positive conclusive
grounds decision that an individual is a victim of modern slavery they are not eligible for any other form of
leave (such as asylum or humanitarian protection) and either:

- leave is necessary owing to personal circumstances

- leave is necessary to pursue compensation

- victims who are helping police with their enquiries

_Leave is necessary owing to personal circumstances_

[4] When deciding whether a grant of leave is necessary under this criterion an individualised human rights
and children safeguarding legislation-based approach should be adopted. The aim should be to protect
and assist the victim and to safeguard their human rights. In seeking to do so decision makers should
primarily:

- assess whether a grant of leave to a recognised victim is **necessary for the UK to meet its objective**
under the Trafficking Convention - to provide protection and assistance to that victim, owing to their
personal situation

[5] It is not possible to cover all the circumstances in which DL may be appropriate because this depends
on the totality of evidence available in individual cases. However, considerations when deciding if DL is
appropriate might include (the list is not intended to be exhaustive):

- whether the person may be eligible for a more advantageous form of leave, for instance, asylum or
humanitarian protection

- whether leave is necessary because there is a significant and real risk in light of objective evidence that
the person may be re-trafficked or become a victim of modern slavery again - in such cases consideration
should also be given as to whether the risk is greater in the UK or in the person's home country

- whether, if returned home, the person would face harm or ill-treatment from those who first brought them
to the UK, or exploited them in their home country

- whether on the objective information and evidence in a particular case the receiving state have the
willingness and ability to provide through its legal system a reasonable level of protection to the person, if
returned to their care (it would be rare for an individual to be able to rely on there being an absence of
sufficient protection for victims of modern slavery in an EU member state)

- whether DL is necessary for the person to seek compensation through the Courts or is assisting the
police with a criminal investigation or prosecution

[6] Additionally, a person may provide evidence from a healthcare professional that they need medical
treatment. In these cases, consider whether it is necessary for the treatment to be provided in the UK. In
terms of needing to stay in the UK to have such treatment, you may wish to note that the UK's international
obligations do not extend to a requirement that treatment must be provided by specialists in trafficking, or
that it be targeted towards one aspect of an individual's needs (the consequences of trafficking) as
opposed to his or her overall psychological needs as set out in the case of EM v SSHD. …

_Leave is necessary to pursue compensation_

...

_Victims who are helping police with their enquiries_

…”

23. I shall have to consider aspects of that guidance in more detail later. At this stage the only points to
note are:


-----

Home Department

(1) The policy requires the consideration of the grant of discretionary leave only after a positive conclusive
grounds decision, i.e. to confirmed victims of trafficking: see both para. [3] of the MSL Guidance and para.
15.154 of the Statutory Guidance. There is no suggestion that it could be granted to potential victims of
trafficking during what I have called the identification period. It is this feature which Mostyn J found to be
unlawful in EOG.

(2) The (sole) bullet point under para. [4] of the MSL Guidance identifies the primary question as being
whether “a grant of leave is necessary” for the specified purpose. In _KTT Linden J held that that_
formulation failed to give effect to the requirement of article 14.1 (a) of ECAT which asks, rather, whether
the victim's stay is necessary.

24. The guidance in those passages has a rather complicated history, and there have also been some
changes in later versions of the MSL Guidance (we are now up to version 5). I will have to consider some
aspects of that history later.

**PRELIMINARY: “JUSTICIABILITY”**

25. There have been a number of cases in which the terms of the Secretary of State's guidance about the
treatment of victims of trafficking have been challenged on the basis that they did not give proper effect to
the requirements of chapter III of ECAT. It has in all these cases been recognised that the claimants could
not rely on the provisions of chapter III as such since ECAT has not been incorporated in domestic
legislation: it is trite law that international treaties are not justiciable by the Courts, in the sense that they
create no enforceable rights, except to the extent that they are so incorporated – see the classic exposition
of Lord Oliver in J.H. Rayner (Mincing Lane) Ltd v Department of Trade and Industry [1990] 2 AC 418, at
pp. 499-500. Rather, the claimants have contended that the Secretary of State had declared that in
promulgating the Guidance it was her intention to give effect to the UK's relevant obligations under ECAT;
and that if, on the Court's construction of the relevant provisions, she had failed to do so, she had
misdirected herself as to a material consideration and was liable to judicial review on ordinary public law
principles. The Secretary of State has generally acknowledged that that was a proper approach. I need to
refer to five such decisions.

26. In R (Atamewan) v Secretary of State for the Home Department _[2013] EWHC 2727 (Admin), [2014] 1_
WLR 1959, the Divisional Court (Aikens LJ and Silber J) held that the version of the Guidance in force at
the material time contained guidance on the definition of “victim of trafficking” which was based on a
misinterpretation of ECAT and that a negative reasonable grounds decision (described as “the NRM
decision”) in reliance on that guidance was accordingly unlawful. At para. 55 of his judgment Aikens LJ
recorded the position of Mr James Eadie QC for the Secretary of State as follows:

“Mr Eadie submitted in relation to the NRM decision that the key question was whether the policy set out in
the Guidance … was sufficient to comply with the UK's international obligations under [ECAT]. He
accepted, at least in this court, that although [ECAT] had not been transposed into domestic law by
legislation and so did not have 'direct effect', insofar as the Guidance purported to give effect to the terms
of [ECAT] and failed to do so, that would be a justiciable error of law. He also accepted that to the extent
that the NRM Decision was itself based on the terms of the Guidance, if they were, in turn, based on an
erroneous interpretation of [ECAT], then the NRM Decision could be challenged by Judicial Review
because that decision would then have been based on a misdirection as to the legal basis for the relevant
wording of the Guidance.”

That has been referred to in the subsequent case-law as “the Atamewan concession”. There are in fact
two concessions, the first relating to the route by which non-compliance with ECAT would be justiciable
and the second accepting that a decision made pursuant to an unlawful policy would itself be flawed. The
second of those concessions is uncontentious. As to the first, it should be noted that the concession only
applied “insofar as the Guidance purported to give effect to the terms of [ECAT]”.

27. In _R (Galdikas) v Secretary of State for the Home Department_ _[2016] EWHC 942 (Admin), [2016] 1_
WLR 4031, Sir Stephen Silber, sitting as a High Court Judge, found that the approach taken by the


-----

Home Department

Guidance to support and assistance for victims of trafficking following a conclusive grounds decision was
unlawful because it failed to give effect to article 12 of ECAT. The Secretary of State took the position that
she was not bound by the _Atamewan concession and argued that the claimant could not rely on ECAT_
because it was an unincorporated treaty. However, at para. 66 of his judgment Sir Stephen found that it
was the Secretary of State's declared policy “to apply the approach in ECAT” in the relevant respect and
that she was obliged to follow that policy unless there was good reason not to do so.

28. In PK (Ghana) v Secretary of State for the Home Department [2018] Civ 98, [2018] 1 WLR 3955, this
Court held that the Guidance was unlawful because it failed properly to reflect the meaning of “necessary”
in article 14 (1) (a). At para. 34 of his judgment Hickinbottom LJ recorded the position of the Secretary of
State as follows:

“It was common ground before [the Judge] that the Secretary of State's policy guidance was intended to,
and purported to, give effect to [ECAT]; and that, if it failed to give effect to the Convention, then that would
be a justiciable error of law. Before us, after some consideration and after taking instructions, Miss
Bretherton, who also appeared for the Secretary of State below, confirmed that concession.”

That concession in fact has two elements (separated by the semi-colon). The second element is the same
as the first concession in Atamewan, but the first goes beyond it because it accepts that the guidance “was
intended to, and purported to, give effect to [ECAT]”. I return to that aspect later.

29. In _JP (to which I have already referred), which concerned a different aspect of article 14, Murray J_
recorded at para. 12 of his judgment that counsel for the Secretary of State accepted that she was
“constrained to follow” the concession in _PK (Ghana), which had in substance been repeated in the_
detailed grounds of defence, although “she reserves her position for the future”.

30. Finally, in MS (Pakistan) v Secretary of State for the Home Department _[2020] UKSC 9, [2020] 1 WLR_
1373, the Supreme Court considered the relationship between decisions of the Competent Authority about
whether someone was a victim of trafficking taken for the purposes of the NRM and a decision on the
same question taken by the First-tier Tribunal on an asylum appeal. The question of the justiciability of
ECAT did not directly arise. However, at para. 20 of her judgment Lady Hale noted that “ECAT as such
has not been incorporated into UK law” but went on to say:

“However, the Secretary of State has consistently accepted that the NRM should comply with ECAT. In R
_(Atamewan) v Secretary of State for the Home Department [2013] EWHC 2727; [2014] 2014] 1 WLR 1959,_
para 55, it was accepted that it would be a justiciable error of law if the NRM Guidance did not accurately
reflect the requirements of ECAT and a decision based on that error would accordingly be unlawful. The
same was common ground in R (PK (Ghana)) v Secretary of State for the Home Department [2018] EWCA
Civ 98; [2018] 2018] 1 WLR 3955.”

31. That was the state of the authorities when EOG was argued before Mostyn J. Without any objection
from the Secretary of State he proceeded on the basis articulated in _PK (Ghana) and_ _MS (Pakistan), to_
which he referred in para. 2 of his judgment. In her original grounds of appeal the Secretary of State did
not seek to challenge that approach. However, on the eve of the hearing of the appeal to this Court in July
2021 she applied for permission to amend her grounds of appeal in order to argue that the meaning of
ECAT was not justiciable and that Mostyn J had accordingly been wrong to rely on it as a basis for
impugning the Secretary of State's policy as expressed in the Guidance. She sought to justify her change
of position on the basis that in R (SC) v Secretary of State for Work and Pensions _[2021] UKSC 26, [2021]_
3 WLR 428, in which judgment had been handed down only a few days previously, the Supreme Court had
re-stated the relevant principles in a way which made it clear that the concessions in Atamewan and PK
_(Ghana) had been wrongly made: the passage relied on is at paras. 74-96 of the judgment of Lord Reed._
The Secretary of State was given permission to amend, but the appeal had to be adjourned in order to
allow the Claimant the opportunity fully to consider the point.

32. KTT was heard by Linden J the week after the adjournment of EOG. The Secretary of State took the
justiciability point. The parties did not seek a stay to await the decision of this Court in _EOG, and the_


-----

Home Department

question was fully argued. Linden J considered the issue with exemplary care and thoroughness at paras.
15-59 of his judgment. He first addressed the position without reference to _SC. His conclusion on that_
basis, at paras. 36-37, reads:

“36. Subject to the arguments about _SC, I would have little hesitation in holding that_ _Galdikas was_
correctly decided for the reasons which Sir Stephen Silber gave and that the concessions of law as to the
question of justiciability, referred to above, were correctly made by the Defendant and accepted by the
courts in those cases. The critical point in the PK (Ghana) line of cases is that the source of the public law
obligation contended for was the declared policy of the Defendant rather than ECAT itself. In each case it
was decided or conceded that, as a matter of fact - this was in fact the Defendant's policy - and
construction - this is what her policy documents said - the Defendant had committed to making the relevant
decision in accordance with the requirements of the relevant article(s) of the ECAT. It was therefore
permissible for the court, applying conventional public law principles, to consider what the requirements of
those articles were with a view to deciding whether the policy correctly stated their effect and whether a
given decision, taken in accordance with that policy, was lawful. This did not involve direct enforcement of
an unincorporated treaty as the treaty was not the source of the obligation contended for. Nor did it involve
the filling of lacunae, as Mr Tam submitted, given that the claimants in those cases relied on what was said
in the policy documents.

37. At the same time the other point made by Mr Eadie, and accepted by the Divisional Court in
_Atamewan, that an international treaty cannot be used to fill a lacuna in a statement of policy, is important._
This is an example of direct reliance on the international treaty, which is not permitted. I therefore also
agree with Sir Stephen Silber that for the Claimant to succeed in the present case she must also show that,
on its true construction, the MSL Policy was intended to commit the Defendant to making decisions as to
MSL in accordance with Article 14(1)(a), ECAT before going on to show that the Defendant has done so
incorrectly and that the decision in the Claimant's case is therefore in breach of the MSL Policy and
unlawful.”

Linden J then analysed what Lord Reed had said in SC and concluded, at para. 52:

“I do not accept that the decision in SC renders the question raised by Ground 1 [i.e. the contention that
the Guidance was inconsistent with article 14.1 (a)] non justiciable or even casts doubt on the correctness
of the principles which underpin the decisions in the PK (Ghana) line of cases. I agree with Mr Buttler that
_SC was a straightforward application of the Rayner principles in the context of a materially different legal_
issue to the present one.”

33. At ground 3 of her grounds of appeal in _KTT the Secretary of State, consistently with her amended_
grounds in EOG, contended that Linden J's analysis was wrong and maintained the justiciability objection.
That argument was fully developed in her combined skeleton argument for these appeals. However, in
opening his submissions at the hearing Mr Tam said that, having had the opportunity to reflect on Linden
J's judgment, the Secretary of State no longer wished to challenge his analysis in this Court (while
reserving her position should the case go further) and accepted that we were bound by PK (Ghana). The
Court was anxious to be clear exactly what was being conceded and, having had the opportunity to take
further instructions, Mr Tam made it clear that he accepted that if in the relevant respects the policy of the
Secretary of State was that the Guidance should comply with ECAT it was open to the Court to decide
whether it in fact did so and to hold that it was unlawful if it did not.

34. The upshot of all this is that in the end we did not have to hear submissions on the justiciability issue. I
should say, however, that I find Linden J's analysis convincing and that I entirely agree with his conclusions
quoted at para. 32 above. I would make two points by way of clarification.

35. First, the effect of the PK (Ghana) line of cases is not that the Government has no room at all to take
its own decisions about what support and assistance it provides to victims of trafficking. In the first place,
many of the obligations imposed by ECAT are in very general terms, and it is a matter for the Government
(subject to general public law constraints) in what manner it chooses to implement them. Further, it is
always open to the Government since ECAT is unincorporated to make it clear that it has chosen not to


-----

Home Department

give effect to it, whether generally or in some particular respect. As a matter of constitutional principle such
a decision could not be challenged in the domestic courts.

36. Second, although in the cases referred to above the result of the Court's conclusion as to the effect of
ECAT was that the Guidance was in the relevant respect unlawful, that is not the only possible outcome. If
the Guidance is ambiguous it may be enough for the Court to hold that a construction which complies with
ECAT should be preferred to one which did not. As this Court said in MN, at para. 85, “[s]ince the NRM is
avowedly intended to give effect to the UK's obligations under ECAT the Guidance must be construed so
far as possible to give effect to those obligations”.

37. There are thus in principle two questions in cases of this kind:

(1) whether the Guidance is in the relevant respects intended by the Secretary of State to give effect to the
requirements of ECAT; and

(2) whether it in fact does so.

I should note, however, that only the second of those issues is live in EOG.

**_EOG_**

THE FACTS

38. EOG was born in Russia but adopted from an orphanage at the age of three by a couple in New
Zealand. Her life there was troubled, for reasons which it is unnecessary to go into. In 2017, at the age of
25, she came to the UK on a tier 5 “Youth Mobility Scheme” visa, which gave her leave to remain, with the
entitlement to work, until 20 September 2019.

39. In April 2018 EOG came under the control of a trafficker who raped her and forced her to engage in
sex work. After several weeks she escaped his control, and in September 2018 she went to the police. On
11 September she was referred to the NRM. She received a positive reasonable grounds decision on 11
June 2019 (following an initial refusal) and a positive conclusive grounds decision on 28 April 2020. It is a
matter of serious concern that both decisions should have taken so long to reach: I shall say something
more about this later. Prior to the expiry of her leave she applied for an extension of her entitlement to
work but this was refused. Thereafter she was unable to work and was dependent on the subsistence
level of support available under the MSVCC.

40. In his judgment Mostyn J described EOG as being, following the expiry of her leave, subject to the socalled “hostile environment” to which non-nationals without leave to remain are subject. He referred to
para. 81 of the judgment of this Court in R (Balajigari) v Secretary of State for the Home Department _[2019]_
_EWCA Civ 673, [2019] 1 WLR 4647, where counsel's summary of the relevant measures is quoted. It is_
fair to say that not all those measures will always have a grave impact on victims of trafficking. For
example, although it is correct that it is an offence for a person to be in the UK if they require leave to
remain but do not have it, it is hardly conceivable that a potential victim of trafficking would be prosecuted,
and if they were they might have a defence under section 45 of the 2015 Act. Also, victims of trafficking
are entitled to a range of NHS services free of charge regardless of their immigration status (see paras.
15.54-70 of the current version of the Statutory Guidance); and although they cannot rent private
accommodation, hold a driving licence or have a bank account, those disabilities may not typically have a
significant impact in a situation where they are wholly dependent on VoT support. Nevertheless, it does
not take much imagination to appreciate that a prolonged period of uncertainty, during which a victim of
trafficking is living at subsistence level and unable to engage in gainful employment – what was referred to
before us as the “limbo period” – is liable to be profoundly demoralising and inimical to the social and
psychological recovery which chapter III of ECAT, and in particular articles 12 and 13, is designed to
promote. EOG's evidence was that that was indeed the effect on her of the delay following the expiry of
her leave.


-----

Home Department

41. I should mention for completeness that on 11 January 2021, i.e. subsequent to Mostyn J's decision,
EOG was granted twelve months' discretionary leave under para. [3] of the MSL Guidance on the basis
that she was helping the police with their enquiries into her trafficking.

MOSTYN J's DECISION

42. The present proceedings were commenced on 12 December 2019. Although they raised several
claims, in this appeal we are concerned only with a challenge to the Secretary of State's policy, as set out
in the Guidance, that only confirmed victims of trafficking would be considered for MSL. EOG was affected
by that policy between the expiry of her leave on 20 September 2019 and her positive conclusive grounds
decision on 28 April 2020. It is her case that the policy “undermines the purpose of identifying and
protecting victims of trafficking” and is thus “contrary to the policy and objects of ECAT, the Trafficking
Directive and Article 4 ECHR”.

43. Mostyn J upheld that challenge. His reasoning is at paras. 48-50 of his judgment, which read:

“48. … I agree with Ms Weston QC that there is an unlawful lacuna in the existing policy inasmuch as it
fails to implement the obligation in Article 10.2 formally to protect persons in receipt of a positive
reasonable grounds decision from removal from this country's national territory pending the conclusion of
the process. Suffering such persons to remain as overstayers, or as illegal immigrants, does not fulfil the
obligation. The defendant must formulate a policy that grants such persons interim discretionary leave on
_such terms and conditions as are appropriate both to their existing leave positions and to the likely delay_
_that they will face [my emphasis]. It is not for me to prescribe what such terms and conditions should be. I_
agree with Mr Tam QC that constitutionally that is a matter reserved to the defendant. However, the terms
and conditions must obviously be lawful and this would mean that someone in the position of the claimant,
who has a time-limited right to work, should not have the arbitrary adverse consequence of a removal of
that right meted out to her simply by virtue of the delays that she is likely to face.

49. What interim discretionary leave policy the defendant should formulate in relation to those potential
victims who have no leave of any type to be here will be a matter for her to decide.

50. I therefore will grant a declaration which incorporates my decision set out in para 48 above. I ask
counsel to seek to agree the terms of the declaration. If they cannot do so then I will rule on any disputed
wording.”

44. The declaration which was made in accordance with that reasoning reads:

“The defendant has unlawfully failed to implement her obligations under Article 10(2) of the European
Convention Against Trafficking to protect persons from removal from the territory of the United Kingdom
after she has decided that there are reasonable grounds to believe that they are victims of trafficking
because she does not have a specific policy concerning the circumstances in which, and the terms upon
which, appropriate grants of interim discretionary leave may be made to such persons if:

(a) They have leave to remain in the UK at the time they receive that reasonable grounds decision, but
that leave expires during the period whilst they are awaiting a decision on whether there are conclusive
grounds to believe that they are a victim of trafficking; or

(b) They do not have leave to remain in the UK at the time they receive that reasonable grounds decision.”

45. The terms of the declaration do not appear fully to reflect the language of para. 48 of the judgment.
The declaration on a literal reading requires simply that the Secretary of State must have a policy about the
grant of MSL to potential victims of trafficking. That might be thought to leave it entirely open to her what
that policy should be: it might, for example, be that such leave should never be granted, or only in
exceptional circumstances. But it is clear that that was not what Mostyn J intended. The sentence in para.
48 which I have italicised appears to prescribe that all potential victims must be granted discretionary leave
of some kind, albeit subject to “terms and conditions” which it was for the Secretary of State to decide. It
may be that he did not mean to go quite so far, but on any view it was clearly his intention that leave should
be granted in any case of “delay” in reaching a conclusive grounds decision It is unsatisfactory that there


-----

Home Department

should be a mismatch of this kind between the terms of the judgment and the declaration. It is the
responsibility of the Judge and counsel to ensure that any declaration accurately gives effect to the
reasoning of the judgment. It may of course be that the lack of coherence between the two reflects
problems in the underlying reasoning.

DISCUSSION AND CONCLUSION

46. I respectfully disagree with Mostyn J's decision. The essence of his reasoning is that article 10.2 of
ECAT imposes an obligation on the UK not merely to “suffer [potential victims] to remain as overstayers, or
as illegal immigrants” but to grant them leave to remain. In my view that is an unsustainable construction.
All that article 10.2 says is that during the identification period the potential victim “shall not be removed
from [the relevant state's] territory”. That is a purely negative obligation, and I do not believe that it can be
treated as requiring the state to grant any kind of immigration status (beyond irremovability) to potential
victims. There is a clear contrast with the language of article 14, which requires state parties to issue
“residence permits”, in the circumstances specified, to confirmed victims. In my view it is plain that ECAT
intends there to be a distinction between the positions of potential and confirmed victims, with the former
enjoying the minimum level of protection afforded by irremovability and basic assistance under paragraphs
1 and 2 of article 12, and the latter enjoying enhanced assistance, together with the possibility of formal
residence rights. That is a reasonable and coherent scheme. Unsatisfactory though it may be for victims
of trafficking to receive only a minimum level of protection and assistance while the identification process
(which was no doubt expected to be reasonably short in the typical case) takes place, it is understandable
that state parties would not be prepared to accord more than that minimum until the victim's status is
confirmed.

47. That reading is reinforced by two other points:

(1) Para. 131 of the Explanatory Report, which is part of its commentary on article 10, says:

“Many victims, however, are illegally present in the country where they are being exploited. Paragraph 2
seeks to avoid their being immediately removed from the country before they can be identified as victims.
Chapter III … secures various rights to people who are victims of trafficking in human beings. Those rights
would be purely theoretical and illusory if such people were removed from the country before identification
as victims was possible.”

That confirms that article 10.2 is concerned only with irremovability.

(2) Article 13.1, which is also concerned (at least typically) with potential victims, provides that during the
recovery and reflection period “it shall not be possible to enforce any expulsion order”. That necessarily
contemplates that the potential victim may otherwise have no right of residence. (There is a separate issue
about the final sentence of paragraph 1, to which I will return presently.)

48. I appreciate of course that in many cases, of which EOG's is one, the identification process takes far
longer than is likely to have been contemplated when ECAT was adopted by the Council of Europe or
when it was ratified by the UK, with the result that potential victims are in limbo for prolonged periods. That
is a serious problem, and I say something more about it at the end of this judgment. But it is not legitimate
to try to address that problem by treating article 10.2 as imposing an obligation which is flatly contrary to its
express terms, both on a literal reading and by reference to the structure of chapter III generally and the
Explanatory Memorandum.

49. Ms Weston's primary submission was that since, as I have acknowledged at para. 40 above, a
prolonged limbo period was likely to be inimical to victims' recovery, which is a primary purpose of chapter
III of ECAT, the Secretary of State was obliged to have a policy which allowed for the grant of discretionary
leave to potential victims of trafficking. She did not go as far as Mostyn J appears to have done and say
that the policy should require the grant of leave during the identification period in every case; but she
submitted that delays such as those suffered by EOG demonstrated why the grant of leave would be
necessary in many cases. This submission is in my view wrong in principle. It is not the effect of ECAT
that state parties are req ired to take an step that might be cond ci e to its o erall objecti es Its


-----

Home Department

provisions impose specific obligations, and, if the Secretary of State's policy is to comply with ECAT, she is
only required to adhere to those provisions. For the reasons given I do not regard article 10.2 (or indeed
any other provision of chapter III) as imposing the obligation contended for.

50. There was one further argument advanced by Ms Weston. Before Mostyn J she sought to rely, either
in support of her submissions about the effect of article 10.2 or in the alternative, on the final sentence of
article 13.1, which provides that “[d]uring this period, the Parties shall authorise the persons concerned to
stay in their territory”. Her case was that the phrase “in this period” referred to the immediately preceding
sentence and thus to the time taken to complete the “activities” there referred to, which she equated with
the identification process; and she contended that the “authorisation” required must equate, in the UK
system, to the grant of leave to remain.

51. Mostyn J rejected that argument. He said, at para. 41 of his judgment:

“Although the drafting is ambiguous it seems to me that the reference to 'this period' in the final sentence is
indeed to the recovery and reflection period. Article 13 is about the recovery and reflection period and
nothing else. Had the final sentence been referring to a different period it would have said 'that period' to
distinguish it from the period referred to in the heading of the Article and in its first three sentences.”

His conclusion is supported to some extent by para. 178 of the Explanatory Report, which appears under
the heading “Article 13 – Recovery and reflection period” and reads:

“The words 'it shall not be possible to enforce any expulsion order against him or her' mean that the victim
must not be removed from the Party's territory during the recovery and reflection period. Although free to
choose what method to employ, Parties are required to create a legal framework allowing the victim to
remain on their territory for the duration of the period. To meet this end, in accordance with national
legislation, each Party shall provide victims, without delay, with the relevant documents authorising them to
remain on its territory during the recovery and reflection period.”

The word “remain” in the Explanatory Report clearly does not connote “leave to remain” in the UK sense,
which, as I have said, is equivalent to what ECAT refers to as “residence”.

52. The Intervener, both in its written submissions and through Ms Christie, complained that the absence
of any formal documentation of the irremovability of potential victims constituted a breach of the UK's
obligations under ECAT and suggested that the lacuna could be filled by conferring on victims a half-way
house status equivalent to the old “temporary admission”. However, Ms Weston did not adopt the
Intervener's suggestion even as an alternative.3 Her submission remained squarely that the final sentence
of article 13.1 required the grant of residence status – i.e., in UK terms, discretionary leave to remain. I
cannot accept that. If it were right it would be inconsistent with article 10.2 and the scheme of chapter III
as discussed above, under which a right to a residence permit, and thus “lawful residence”, becomes
(potentially) available only once a victim has been conclusively identified.

53. In these circumstances, it does not seem to me necessary to decide what period is meant by the
words that “[d]uring this period” in the last sentence of article 13.1. Para. 178 of the Explanatory Report
does, however, appear to show that the reference to “authorise” in the last sentence of article 13.1 may be
to some kind of formal documentation of irremovability. Such documentation would clearly not confer a
positive right of residence, since that would be inconsistent with article 14; but it would record that the
victim was allowed “to remain on [the state's] territory”. It is easy to see why it might be important for a
victim of trafficking to have a document which confirmed both to them and to third parties (an obvious
example would be the police) that they were, in that limited sense, legally present in the UK. Mr Tam
confirmed that the Secretary of State at present issues no such document to potential victims of trafficking.
The Secretary of State may wish to consider her position in that regard.

54. As noted at para. 42 above, EOG's grounds of claim refer to “the policy and objects of ECAT, the
Trafficking Directive and Article 4 ECHR”. Mostyn J did not rely on article 4 or either of the two Directives,
but EOG referred to article 4 in her Respondent's Notice and Ms Weston referred us to the decision of the


-----

Home Department

European Court of Human Rights in VCL v United Kingdom, app. nos. 77587/12 and 74603/12, (2021) 73
EHRR 9, which at para. 150 reiterates that the effect of the Court's case-law is that:

“… Member States' positive obligations under art. 4 of the Convention must be construed in light of the
Council of Europe's Anti-Trafficking Convention and be seen as requiring not only prevention but also
victim protection and investigation. The Court is guided by the Anti-Trafficking Convention and the manner
in which it has been interpreted by GRETA.”

However, that cannot advance the argument. Even if the obligations under article 4 and ECAT may be coextensive, that goes nowhere if ECAT does not impose the obligation relied on.

55. Mr Tam advanced various other arguments aimed at mitigating the criticism that potential victims of
trafficking were liable to spend long periods in limbo. He pointed out that those who, like EOG, had limited
leave to remain of a kind which entitled them to work when they entered the NRM could in practice
preserve their position by making an application for further leave, which by virtue of section 3C of the 1971
Act would extend their existing leave pending a decision on that application. He also said that the
Secretary of State retained a general discretion to grant leave not only outside the Rules but outside the
terms of her published Guidance. I find it hard to see how either point could answer EOG's case if it were
otherwise good; but since I do not believe that to be the case I need not consider them further.

56. My conclusion as to the meaning of article 10.2 means that it is unnecessary to address the logically
prior question of whether the Secretary of State's policy was to give effect to its provisions. But Mostyn J
proceeded on the basis that it was, and that approach was not challenged in the Secretary of State's
grounds of appeal.

57. I would accordingly allow the appeal in EOG, set aside Mostyn J's order and dismiss the claim.

**_KTT_**

INTRODUCTION

58. KTT's history is complicated. The details can be found in an Appendix to Linden J's judgment, but I
will confine myself to the bare facts which give rise to the issues on this appeal.

59. KTT was born in Vietnam. She is now aged 33. After a period when she was forced to work as a
prostitute in Vinh City she was brought to this country by traffickers to work both as a prostitute and on a
cannabis farm. Unlike EOG, she has never had leave to enter or remain.

60. On 20 March 2018 she was referred into the NRM. A positive reasonable grounds decision was made
on 17 April 2018. A positive conclusive grounds decision was made, eighteen months later, on 31 October
2019. There may be an excuse for the delay because shortly after being referred to the NRM KTT fell back
under the control of her traffickers and lost contact with the authorities. She was subsequently convicted of
conspiracy to produce cannabis and sentenced to 28 months imprisonment. Following the expiry of her
term she was held in immigration detention until 14 November 2019, although her detention has since
been accepted by the Secretary of State to have been unlawful.

61. On 22 January 2019 KTT claimed asylum on the basis that she had a reasonable fear of being retrafficked if she was returned to Vietnam. Following the positive conclusive grounds decision in April she
was not immediately considered for MSL because the Secretary of State's then policy was not to do so
until a decision had been made on her asylum claim. However, in JP that policy was held to be unlawful,
and on 7 May 2020 the Secretary of State undertook to make a decision by 7 August 2020.

62. A decision refusing MSL was issued on 21 July 2020. The Secretary of State agreed to reconsider
that decision, but it was confirmed in a further decision dated 17 August 2020. In her decision letter she
referred to para. [3] of the MSL Guidance (see para. 22 above) and considered in turn whether the grant of
leave was necessary because KTT was assisting the police, or in order “to protect and assist [her]
recovery”, or on medical grounds, or to enable her to pursue compensation, or because she was at risk of


-----

Home Department

being re-trafficked on return. Each question was answered in the negative. No reference was made to her
pending asylum claim.

63. KTT's asylum claim was refused by the Secretary of State on 23 April 2021. She has appealed to the
First-tier Tribunal but her appeal has not yet been heard.

64. Following the positive reasonable grounds decision of 17 April 2019 KTT was, in accordance with the
Guidance (and reflecting article 10.2), irremovable pending a conclusive grounds decision and entitled to
VoT support – although in fact she was for most of the period in prison or immigration detention. Following
her release from detention she would have been entitled to VoT support or asylum-seeker support: I need
not give the details, but both were, broadly, at subsistence level. Having no leave to remain, she was not
entitled to work.

65. Since the decision below, on 23 December 2021 KTT was granted MSL leave for a period of six
months, albeit subject to review if circumstances change. It was not suggested that this meant that the
appeal should not proceed.

THE CLAIM AND THE ISSUE

66. On 30 September 2020 KTT issued the present proceedings challenging the Secretary of State's
refusal of 17 August 2020 to grant her MSL. As already noted, it was her case that article 14.1 (a) of ECAT
required that a victim of trafficking be given a residence permit if the competent authority considered that
“their stay is necessary owing to their personal situation”; that it was the Secretary of State's declared
policy to comply with that obligation; and that her [sc. KTT's] stay in the UK was “necessary owing to [her]
personal situation” because she needed to remain here in order to pursue her asylum claim, and the
Secretary of State could not reasonably have considered otherwise.

67. Before Linden J and before us both the issues identified at para. 37 above were live. The first is
broadly the subject of ground 2 of the Grounds of Appeal and the second is covered by ground 1. (There
were two further grounds, but ground 3 raised the justiciability issue and is no longer live, and ground 4
was simply a sweep-up.)

(1)          WAS IT THE SECRETARY OF STATE'S POLICY TO MAKE MSL DECISIONS IN
ACCORDANCE WITH ARTICLE 14.1 (a) ?

68. I start by recording that Mr Tam confirmed to us at the start of his submissions that, as one would
expect, the Government's position is that it intends to comply with its obligations under ECAT. It was,
however, his case that a general commitment of that kind was not enough to render a claimed noncompliance justiciable: there had to be a commitment to comply with the particular obligation in question –
in this case, article 14.1 (a).

69. I turn to the published guidance. The original guidance addressing the obligations imposed by chapter
III of ECAT is to be found in a document issued on 13 October 2010 headed “Guidance for the competent
authorities” (“the original Guidance”). In summary:

(1) The introduction (pp. 5-6) starts, under the heading “Council of Europe Convention”, with a summary of
the purposes of ECAT, describing the UK's ratification and implementation of it as “a milestone in our fight
against trafficking”. It goes on to explain that “as part of our implementation of [ECAT] we have created a
National Referral Mechanism”, described as “a victim identification and support process”.

(2) The original Guidance goes on to deal with a number of substantive matters, including provision for a
two-stage process for the identification of victims corresponding to that provided for in article 10 of ECAT
and a “45-day reflection period” of the kind required by article 13.

(3) Under the heading “Conclusive decision outcomes”, it sets out the matters requiring to be considered if
a positive conclusive grounds decision is made. This includes the grant of discretionary leave to remain.
Two kinds of cases where such leave may be required are identified (pp. 33-34) – “victims who are
assisting with police enquiries”, and “victims who qualify for another kind of leave”. The grant of leave in


-----

Home Department

the former situation is described as being “[d]ue to our obligations under [ECAT]” and is evidently based on
article 14 (1) (b). As to the latter, the text begins:

“Victims whose stay in the UK may be necessary due to their personal circumstances, such as family and
health needs, should be considered for Discretionary Leave (DL) in line with existing policy.”

Given the language used, and the explicit reference to ECAT in connection with assistance with “police
enquiries”, that is evidently intended to reflect article 14 (1) (a).

(4) There are other explicit references to ECAT. I need not set them out, but I note that at p. 35, in the
context of the absence of a right of appeal, the Guidance refers to ECAT “upon which our victim care
arrangements are based”.

70. There were a large number of revised versions of the original Guidance, with various titles and
differences in lay-out and detailed wording, until it was replaced in March 2020 by the Statutory Guidance.
I need refer only to the version published on 24 October 2013. This starts with a section headed “About
this guidance”, which includes the statement “this guidance is based on [ECAT]”: the same statement
appears as a running header throughout the following text. The grant of leave to remain to confirmed
victims is addressed at pp. 98-102. As with the first version, it is dealt with under two headings –
“Discretionary leave on the grounds of personal circumstances or to pursue compensation” and “Victims
who are assisting with police enquiries” – which plainly correspond to article 14 (1) (a) and (b) (although
the reference to leave for victims pursuing compensation reflects article 15, to which express reference is
made). It is equally plain that the intention is to give effect to article 14.1, as regards both head (a) and
head (b).

71. As regards “discretionary leave on the grounds of personal circumstances or to pursue compensation”,
I need, for reasons which will appear, to set out the relevant text which reads:

“When you make a conclusive decision and the person does not meet the criteria for any of the other leave
or protection categories, it may be appropriate to grant a victim of trafficking discretionary leave if their
personal circumstances are compelling. For example, to allow them to finish a course of medical treatment
that would not be readily available if they were to return home. This must be considered in line with the
discretionary leave policy (see related link).”

The “related link” was to an Asylum Policy Instruction (“API”) on Discretionary Leave (version 6.0) dated 24
June 2013. Para. 2.4 dealt with “Trafficking cases”. I need not quote it in full, but it used the same
language of “compelling” circumstances.

72. The Statutory Guidance with which we are concerned replaces the earlier forms of guidance but there
is no reason to doubt that its purpose was the same as regards the implementation of article 14.1 (a). As
we have seen, the relevant paragraphs cross-refer to the MSL Guidance. In the passage quoted at para.
22 above the language of “owing to personal circumstances” clearly derives from article 14.1 (a), and para.

[4] requires decision-makers to assess whether a grant of leave is necessary for the UK to meet “its
objective under the Trafficking Convention – to provide protection and assistance to that victim, owing to
_their personal situation [emphasis supplied]”. I note also the reference at para. [6] to “the UK's international_
obligations”, which in that context can only refer to article 14. Finally, the introductory page of the MSL
Guidance contains hyperlinks both to the report of PK (Ghana) and to the text of ECAT.

73. In EOG the Secretary of State filed a witness statement from Russell Bramley, a Policy Manager in the
Home Office Modern Slavery Unit, leading on NRM policy. At para. 12 of his witness statement dated 13
May 2020 he says:

“If the individual receives a positive CG decision they may in some circumstances be considered for a
grant of discretionary leave (DL) to remain in the UK based on the policy set out in “Discretionary leave
considerations for victims of modern slavery” (version 2 published September 2018). ... The policy exists
_to reflect the requirement in Article 14 (1) (a) of ECAT to consider whether a grant of discretionary leave is_
_necessary owing to the individual's personal situation [my emphasis].”_


-----

Home Department

Mr Tam submitted that that statement was evidence only in _EOG and not admissible in_ _KTT. I do not_
accept that: it is a formal public statement of the Government's purpose in making the relevant policy.

74. The decision of this Court in _PK (Ghana), to which I have already referred, was concerned with the_
version of the original Guidance quoted at para. 72 above. Both the Guidance itself and the API stated that
any personal circumstances relied on must be “compelling”. The claimant in that case was a confirmed
victim of trafficking who was refused discretionary leave because the Secretary of State, applying the terms
of the Guidance, concluded that the claimant's stay was not necessary owing to his personal
circumstances. His claim was that the term of the Guidance both failed to engage with the criteria
prescribed by article 14.1 (a) and also introduced a criterion of “compellingness” which article 14 required.
It was in that context that counsel for the Secretary of State made the concession that she did. That was
not only a concession about justiciability, as already discussed: it was also a concession that the Guidance
was in the relevant respect intended to give effect to ECAT. The Court upheld the claim.

75. There was some debate before us about whether the Secretary of State was bound by (the relevant
part of) the concession made in PK (Ghana) and about whether we were in any event bound by the Court's
decision. I do not need to resolve either question because in my view the concession was plainly correct. I
believe it is clear from the materials referred to at paras. 68-73 above that the Guidance has from the start
purported and been intended to give effect to the corresponding provisions of chapter III of ECAT, and that
that remains the case.

76. It follows that I would determine this issue in KTT's favour. The remaining issue is thus whether the
Guidance, as applied in her case, does indeed accord with the requirement of article 14.1 (a).

77. I have not found it necessary to refer to Linden J's discussion of this issue, but at paras. 60-80 of his
judgment he reached the same conclusion as I have, and for essentially the same reasons.

(2)          DOES THE GUIDANCE GIVE EFFECT TO ARTICLE 14.1 (a)?

78. KTT's case can be straightforwardly stated. The question which the Secretary of State is required by
article 14.1 (a) to consider is whether “[the victim's] stay is necessary owing to their personal situation”. Mr
Buttler accepts that that language has to be construed having regard to the purpose of chapter III, which
was characterised by Hickinbottom LJ in PK (Ghana) (see para. 50) as “the protection and assistance of
victims of trafficking”; and that accordingly the reference must be to the victim's situation _as a victim of_
_trafficking; but he submits that it is clear as a matter of language that it is the_ _stay, not the issue of the_
residence permit, which must be “necessary”. He says that KTT's asylum claim related to her situation as
a victim of trafficking because it was based on the risk of her being re-trafficked if she were returned to
Vietnam, and it was necessary for her to stay in the UK in order to pursue that claim. He says that that
conclusion plainly conforms to the purposes of ECAT because it means that a victim of trafficking awaiting
the outcome of a (trafficking-related) asylum claim will not be in the limbo described at para. 40 above, with
no immigration status and unable to work.

79. Mr Tam's principal argument in response, both before Linden J and before us, was that Mr Buttler's
reading involved an overly technical approach. He reminded us of the observations of the House of Lords
in Fothergill v Monarch Airlines Ltd [1980] AC 251, itself reflecting the principles of the Vienna Convention
on the Law of Treaties, to the effect that a purposive and not necessarily a literal approach should be
applied to the construction of an international treaty. He submitted that the essential concept underlying
article 14 was that a residence permit should only be granted where (in the view of the competent
authority) the relevant purpose under article 14.1 (a) (or (b)) could only be achieved if a residence permit
were issued.  He accepted that that would not be the case if an asylum-seeker were liable to be removed
pending the resolution of a trafficking-related asylum claim, but he pointed out that there was no risk of that
because sections 77 and 78 of the 2002 Act prohibit the removal of an asylum-seeker while their claim
(and any appeal) is pending. While confirmed victims of trafficking awaiting an asylum decision might not
be in as good a position as if they had leave to remain, they would be in no worse position than other
asylum-seekers, who receive a basic level of support and, in certain circumstances, a right to work (see
paragraphs 360-360E of the Immigration Rules which allow asylum-seekers whose claim has been


-----

Home Department

pending for more than a year to ask for permission to take employment in one of a limited list of “shortage
occupations”).

80. Linden J addressed that submission at paras. 89-104. Much of his discussion is directed to particular
arguments advanced by counsel which are not raised before us or are plainly marginal. But on the central
point he said this:

“89. … I prefer Mr Buttler's interpretation of Article 14 ECAT, which is based on an ordinary reading of the
text of the provision and, in my view, consistent with its purpose. The reality of Mr Tam's argument on
interpretation is that Article 14(1) should be read as if it says that the issuing of the residence permit must
be necessary, whereas the language of the provision clearly requires consideration of whether the stay is
necessary in which case the permit must be issued. Indeed, the requirement to consider whether 'their stay
_is necessary' leaves room for it to be the case that the victim is staying in any event. The provision then_
asks whether the stay is necessary for a particular reason or purpose, in which case a residence permit,
with attendant benefits and advantages, is required to be issued. The language does not appear to regard
the residence permit as solely for the purpose of facilitating a stay which would not otherwise be possible,
although this may be an important function of such a permit. Rather, the point of the residence permit is at
least in part to trigger additional advantages, as will be discussed below.

90. I do not consider that applying the language of Article 14 is an overly technical approach, or
inconsistent with the approach required by the Vienna Convention. Moreover, the approach suggested by
the language is consistent with the aims of ECAT including the aim of protecting and assisting the victims
of trafficking. Mr Tam's suggested interpretation of Article 14 is significantly less likely to further those aims
given that it has the consequence of reducing the likelihood that a residence permit will be issued, with the
beneficial consequences to which Mr Buttler refers.”

81. I cannot improve on that reasoning. I can see no basis for not giving the language of article 14.1 (a) its
natural meaning. I do not regard the fact that that meaning is more conducive to the overall objects of
chapter III as decisive; but it reinforces the conclusion to which I would in any event come.

82. I acknowledge that that construction puts confirmed victims of trafficking who are seeking asylum in a
better position than other asylum-seekers. That may not be wholly coherent, but it is the straightforward
consequence of the fact that the UK has chosen to ratify, and to implement, a Convention which gives
victims of trafficking some rights which international law does not require to be accorded to asylumseekers.

83. Before us Mr Tam advanced a further argument about the construction of article 14.1 (a) which does
not appear to have been raised before Linden J. He submitted that the word “stay” connoted what he
described in his skeleton argument as “longer-term residence” and not a mere “temporary permitted
presence”. KTT's case involved her pulling herself up by her own bootstraps: she was seeking a right to
leave to remain in order to pursue a claim for leave to remain.

84. I do not accept that argument. I do not believe that the term “stay” carries any particular connotation
about the length or character of the stay in question: it refers simply to the fact that the victim needs to be
present in the territory of the state party. The length of the stay will depend on the nature of the need relied
on. If it is temporary or contingent the residence permit can be limited accordingly. A residence permit
issued pending the resolution of an asylum claim would no doubt have different terms from one issued if
the claim were successful.

85. I am reinforced in that view by the fact that the same language is used in article 14.1 (b). The “stay” of
a victim assisting the authorities in “investigation or criminal proceedings” will of its nature be temporary
and contingent because the need for it will disappear when the investigation or prosecution are complete –
yet the issue of a residence permit is required.

86. Mr Tam submitted that Mr Buttler's “self-imposed limitation” to cases where the asylum claim was
trafficking-related was illogical because “the outcome sought in both trafficking-based and non-traffickingbased asylum claims is the same: asylum and the concomitant leave to remain” I cannot see that that


-----

Home Department

gives rise to any illogicality. The limitation derives from an acceptance that the “personal situation” referred
to in article 14.1 (a) must, on a purposive construction, refer to the victim's situation qua victim: Mr Buttler
accepted that article 14.1 (a) would not assist a confirmed victim of trafficking who sought leave to remain
pending a decision on, say, a claim for asylum based on the risk of political persecution. We do not in this
case need to decide whether the concession was necessary, but it is in principle entirely coherent. There
may possibly, as Mr Tam also submitted, be some cases where the true basis of an asylum claim is not
clear; but that does not render the distinction illogical.

87. Finally, Mr Tam advanced an argument of a different character which went, if I understood it correctly,
not so much to the meaning of article 14.1 (a) as to whether ECAT imposes an obligation to implement it at
all. He drew attention to the phrase at the start of paragraph 1 “in one or other of the two following
situations or in both” and submitted that the effect was that state parties were not required to grant
residence permits in both the situations covered by heads (a) and (b). He said that that reading was
supported by paras. 182-183 of the Explanatory Report, which read:

“182. The two requirements laid down in Article 14, paragraph 1, for issue of a residence permit are that
either the victim's stay be 'necessary owing to their personal situation' or that it be necessary 'for the
purpose of their cooperation with the competent authorities in investigation or criminal proceeding'. The aim
of these requirements is to allow Parties to choose between granting a residence permit in exchange for
cooperation with the law enforcement authorities and granting a residence permit on account of the victim's
needs, or indeed to adopt both simultaneously.

183. Thus, for the victim to be granted a residence permit, and depending on the approach the Party
adopts, either the victim's personal circumstances must be such that it would be unreasonable to compel
them to leave the national territory, or there has to be an investigation or prosecution with the victim cooperating with the authorities. Parties likewise have the possibility of issuing residence permits in both
situations.”

He also drew our attention to para. 158 of GRETA's 9th General Report which states that, out of the 42
state parties, “14 granted residence permits to victims of trafficking exclusively for the purpose of their
cooperation”, which in context appears to mean that they did not grant permits on the basis of “personal
situation”; and he pointed out that subsequent practice is an admissible aid to the interpretation of a treaty
(see article 31 (3) (b) of the Vienna Convention).

88. I am bound to say that I find Mr Tam's reading of article 14.1 rather surprising: if the grant of a
residence permit is regarded as conforming to the purposes of ECAT in the cases covered by both heads it
is hard to see why state parties should be entitled to grant a permit in the one case but not the other.
However, Mr Buttler told us that he did not dispute Mr Tam's construction: his case was simply that the
point went nowhere because the Secretary of State has in fact declared an intention to implement the
requirements of article 14.1 (a). Since I accept that submission it is unnecessary to consider the question
further.

89. For these reasons I would determine this issue too in KTT's favour. The result is that I would dismiss
the appeal.

**DISPOSAL AND CLOSING OBSERVATION**

90. For the reasons given above I would allow the Secretary of State's appeal in _EOG but dismiss her_
appeal in KTT.

91. The background to both these cases is the extraordinary length of time which it now takes for the
Secretary of State to reach both conclusive grounds decisions in the case of victims of trafficking and
decisions in asylum claims. If the conclusive grounds decision in EOG's case or the decision on KTT's
asylum claim had been reached in a reasonable time it is unlikely that either claim would have been
brought. In EOG Mostyn J referred to published figures that showed that in 2019 it took an average of 462
days for a person referred into the NRM and in whose case a reasonable grounds decision was made to
recei e a concl si e gro nds decision We do not ha e pdated fig res b t e ere not told that there


-----

Home Department

had been any improvement. It is likewise notorious that there are very long delays in the asylum system.
Mr Tam in his oral submissions frankly acknowledged these delays and made no attempt to suggest that
they were acceptable. But he urged us not to fall into the trap of distorting the meaning of ECAT in order to
provide a solution to a problem which its provisions were not designed to address. He said that there were
other and more appropriate legal routes potentially available to victims of trafficking who were adversely
affected by delay. He referred us to O and H v Secretary of State for the Home Department [2019] EWHC
(Admin) 148, in which the claimants' case was that the delays expressed by victims of trafficking awaiting
conclusive grounds decisions were so significant and widespread as to be unlawful, albeit that in that case
the claim failed on the facts.

92. Mr Tam was right that we should not allow our concern about the delays in the system to affect our
approach to establishing the meaning of the relevant provisions of ECAT, and I do not believe that I have
done so. But I am sure that the Secretary of State is aware that solving the problem of those delays would
clearly be in the interests of potential and confirmed victims of trafficking, asylum-seekers, the Home Office
and the Courts.

**Dingemans LJ:**

93. I agree.

**Sir Geoffrey Vos MR:**

94. I also agree.

**End of Document**


-----

