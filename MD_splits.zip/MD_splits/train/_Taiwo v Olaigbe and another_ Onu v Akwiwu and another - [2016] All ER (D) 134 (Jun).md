# *Taiwo v Olaigbe and another; Onu v Akwiwu and another [2016] All ER (D)
 134 (Jun)

[2016] UKSC 31

Supreme Court

Lady Hale DP, Lord Wilson, Lord Reed, Lord Hughes and Lord Toulson SCJJ

22 June 2016

**Employment – Discrimination – Discrimination on grounds of race – Immigration – Limited leave to remain**
**– Employees being Nigerian women working in United Kingdom on migrant domestic worker visas –**
**Employees issuing proceedings in employment tribunal alleging racial discrimination and harassment –**
**Employment Appeal Tribunal finding mistreatment of employees not direct result of immigration status**
**therefore no direct racial discrimination existing – Employees appealing – Whether discrimination on**
**grounds of immigration status amounting to discrimination on grounds of race – Race Relations Act 1976,**
**s 1, Equality Act 2010, s 13.**
Abstract

_Employment – Discrimination. The Supreme Court dismissed the appellant migrant domestic workers' appeals_
_against their race discrimination claims where their mistreatment by their employers had had nothing to do with their_
_nationality, but related to their vulnerability arising from their immigration status. Parliament had not included_
_[immigration status in the list of protected characteristics in the Equality Act 2010 and discrimination on account of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
_an employee's immigration status did not amount to discrimination on account of race, for the purposes of that Act._
Digest

The judgment is available at: [2016] UKSC 31

Employers who exploited the vulnerable status of migrant domestic workers might be liable for breaching the
worker's contract of employment or other employment rights. Such mistreatment might also amount to a tort, to the
offence of slavery or servitude or forced or compulsory labour, under _[s 1 of the Modern Slavery Act 2015, or to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C212-00000-00&context=1519360)_
human trafficking under s 2 of that Act. Remedies under the law of contract or tort did not provide compensation for
the humiliation, fear and distress which such treatment could cause. Such a remedy could be found if the
[employer's conduct amounted to race discrimination under the Equality Act 2010 (the 2010 Act) or its predecessor,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
[the Race Relations Act 1976 (the 1976 Act). In both the 1976 and the 2010 Acts, at the relevant times, the definition](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)
of race covered nationality and ethnic or national origins. The appellant in the first case (T), was a Nigerian national
who had been living in poverty in Nigeria. She had entered the United Kingdom lawfully with a migrant domestic
worker's visa obtained by her and her employers, the respondents in the first case (Mr and Mrs O). The
employment tribunal (the tribunal) upheld T's claims alleging: (i) the failure to pay her the minimum wage; (ii) the
failure to provide required rest periods; and (iii) the unlawful deduction from her wages. It found that she had been
mentally and physically abused by Mr and Mrs OL and Mr OL's mother, who had been living with them for some
time. It characterised T's situation as 'systematic and callous exploitation'. However, the employment tribunal
dismissed T's claims of direct and indirect race discrimination under the 2010 Act, holding that the reason for her
mistreatment had been because she was a vulnerable migrant worker who was reliant on Mr and Mrs OL for her
continued employment and residence in the UK and not because she was Nigerian. The Employment Appeal


-----

Tribunal (EAT) dismissed T's appeal. The appellant in the second case, O, was also a Nigerian national who had
entered the UK on a domestic worker's visa which had been obtained by her and her employers, Mr and Mrs A. She
had been required to work for 84 hours a week and had not been given the required rest periods or annual leave.
She fled the employers' home after allegedly suffering mistreatment and walked some eight miles to the home of a
Jehovah's Witness who put her in touch with a charity for trafficked migrant workers. O brought claims for
harassment and victimisation under the 2010 Act. The tribunal upheld the same claims as the tribunal in T's case
and also held that O had been constructively and unfairly dismissed. The tribunal further held that O's employers
had directly discriminated against her and had harassed her on grounds of race. The EAT allowed the employers'
appeal in respect of the discrimination claim, holding that their treatment of O had not been bound up with her race,
but rather with her subordinate and vulnerable position given the economic benefits of her work in the UK compared
with her life of poverty in Nigeria. The Court of Appeal, Civil Division, heard T and O's appeals together. It upheld
the dismissal of their discrimination claims and held, among other things, that 'immigration status' was not to be
equated with 'nationality' for the purpose of the 1976 and 2010 Acts. The appellants appealed.

The issue was whether discrimination on grounds of immigration status amounted to discrimination on grounds of
race or nationality, for the purposes of the 1976 and 2010 Acts. The question was whether immigration status was
so closely associated with nationality that they were indissociable for that purpose. Consideration was given to ss
9(1), 13(1) and 39(2) of the 2010 Act.

The appeals would be dismissed.

Under s 13(1) of the 2010 Act, a person, A, discriminated against another, B, if, because of a protected
characteristic, A treated B less favourably than A treated or would treat others. Race was a protected characteristic
and included: (i) colour; (ii) nationality; and (iii) ethnic or national origins (s 9). Under s 39(2), an employer had to
not discriminate against an employee of A's (B): (i) as to B's terms of employment; (ii) in the way A afforded B
access, or by not affording access, to opportunities for promotion, transfer or training or for receiving any other
benefit, facility or service; (iii) by dismissing B; or (iv) by subjecting B to any other detriment. Parliament could have
chosen to include immigration status in the list of protected characteristics, but it had not done so. Whilst
immigration status was a 'function' of nationality, there were a number of immigration statuses. British nationals
automatically had the right of abode in the UK. Non-British nationals, apart from Irish citizens, were subject to
immigration control. Some non-nationals entered illegally and had no status at all. Some were given temporary
admission which did not even count as leave to enter. Some were initially given limited leave to enter, but remained
in the UK without leave after that had expired. Some continued for several years with only limited leave to enter or
remain. Some were allowed to work and some are not. Some were given indefinite leave to remain, which brought
with it most of the features associated with citizenship (see [13], [22]-[24] of the judgment).

In the present cases, T and O had had limited leave to enter on domestic workers' visas, the terms of which had
made them particularly vulnerable to the mistreatment which they had suffered. They had been treated
disgracefully, in a way which employees who did not share their vulnerable immigration status would not have been
treated. There could be no doubt that the conduct of the employers would amount to unlawful direct discrimination if
it had been on racial grounds, under the 1976 Act, or because of race, under the 2010 Act, which included
nationality. However, as the employment tribunals had found, that conduct had been because of the vulnerability
associated with their immigration status. Such workers were usually dependent on their current employers for their
continued right to live and work in the UK. The reason why the employees had been treated so badly had been their
particular vulnerability arising, at least in part, from their particular immigration status. It had had nothing to do with
the fact they were Nigerians. The employers too were non-nationals, but they had not been vulnerable in the same
way. There were many non-British nationals living and working in the UK who did not share that vulnerability. That
was enough to dispose of the direct discrimination claim and was consistent with the approach in the authorities.
Further, the present was not a case of indirect discrimination under s 19 of the 2010 Act. There was no provision,
criterion or practice which the employers would have applied to all their employees, whether or not they had the
particular immigration status of the present employees. It was direct discrimination or nothing. The fact that the
cases could not be fitted into the concept of indirect discrimination was further support for the view that the
mistreatment in the present cases had not been because of the employees' race but for other reasons. It followed
that the appeals had to fail not because the appellants did not deserve a remedy for all the grievous harms they


-----

had suffered, but because the present law, although it could redress some of those harms, could not redress them
all (see [14], [24], [26], [27], [31], [32], [34] of the judgment).

_Patmalniece v Secretary of State for Work and Pensions_ _[[2011] All ER (D) 187 (Mar) followed;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52D6-BW51-DYBP-N3X5-00000-00&context=1519360)_ _Preddy v Bull_
_(Liberty intervening); Hall v same_ _[[2013] All ER (D) 307 (Nov) followed;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59XM-RTY1-DYBP-N2MP-00000-00&context=1519360)_ _A-G's Reference (No 4 of 2004), R v D_

_[[2005] All ER (D) 332 (Apr) considered; R (on the application of Morris) v Westminster City Council](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JST1-DYBP-N2Y4-00000-00&context=1519360)_ _[[2005] 1 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FF1-RR30-TWP1-617G-00000-00&context=1519360)_
_[351 considered; Hounga v Allen](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FF1-RR30-TWP1-617G-00000-00&context=1519360)_ _[[2014] 4 All ER 595 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DMS-8XS1-DYBP-M3G0-00000-00&context=1519360)_

Per curiam: 'Parliament may well wish to address its mind to whether the remedy provided by _[section 8 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C270-00000-00&context=1519360)_
**_Modern Slavery Act 2015 is too restrictive in its scope and whether an employment tribunal should have_**
jurisdiction to grant some recompense for the ill-treatment meted out to workers such as these, along with the other
remedies which it does have power to grant (see [34] of the judgment).'

[Decision of the Court of Appeal, Civil Division [2014] All ER (D) 132 (Mar) affirmed.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BSR-4MR1-DYBP-N2CN-00000-00&context=1519360)

Robin Allen QC and Christopher Milsom (instructed by Anti Trafficking and Labour Exploitation) for T.

Robin Allen QC and James Robottom (instructed by Anti Trafficking and Labour Exploitation) for O.

Thomas Linden QC and Sarah Hannett(Instructed by Lewis Silkin LLP (Oxford)) for Mr and Mrs OL.

Sami Rahman and David Mold (instructed by BH Solicitors) for Mr and Mrs A.
Carla Dougan-Bacchus Barrister.

**End of Document**


-----

