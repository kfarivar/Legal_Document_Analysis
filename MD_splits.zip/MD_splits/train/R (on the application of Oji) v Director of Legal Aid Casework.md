# R (on the application of Oji) v Director of Legal Aid Casework [2024] EWHC
 1281 (Admin)

King's Bench Division, Administrative Court (London)

Judge Bird (sitting as a High Court judge)

24 May 2024Judgment

**Chris Buttler KC, Grace Brown and Alex Schymyck** (instructed by Southwark Law Centre) for the
**Claimant**

**Malcolm Birdling and Aarushi Sahore (instructed by** **Government Legal Department) for the**
**Defendant**

Hearing dates: 20 February 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 24 May 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

HIS HONOUR JUDGE BIRD

**His Honour Judge Bird:**

**Introduction**

1. The Claimant is a victim of the Windrush scandal. She was born in Nigeria on 20 January 1985 and
entered the United Kingdom in 1988 to with her father who was settled in the UK and with her brother, to
join her parents here. As the Claimant grew up, she encountered various difficulties because she was
unable to prove her immigration status. They include not being able to secure work, being forced to live
through domestic violence because she was unable to secure homelessness assistance and an inability to
leave the country with the confidence that she could return.

2. She was granted indefinite leave to remain in 2007 but continued to encounter problems. In April 2019
she was granted a no time limit biometric permit under the Windrush Scheme and in May 2020 was
naturalised as a British Citizen.

3. Because of these issues, the Claimant decided to make a claim to the Windrush Compensation
Scheme (“WCS”). The application process is not straightforward, and she found that help and assistance
provided by “We are Digital” (“WAD”) made very little difference. She wanted lawyers to help with the
process. So, on 25 July 2022 with the help and support of her present legal team, she applied to the
Director of Legal Aid Casework (“the Director” or “the Defendant”) for the provision of legal aid by way of
exceptional case funding (“ECF”). The application was refused on 13 September 2022. The refusal was
confirmed on an internal review, and the final decision communicated on 31 October 2022.


-----

4. On 19 December 2022, without any legal funding but with the voluntary assistance of her present legal
team, she submitted a claim to the WCS (comprising a 44-page application form, 30 pages of submissions
and 307 pages of evidence). She sought compensation of a little over £127,000. The application required
some 40 hours' preparation. The application was refused.

5. By these proceedings, and with the permission of Sweeting J, the Claimant seeks a judicial review of
the Director's refusal to grant ECF. The claim was issued on 31 January 2023, the Acknowledgement of
Service was filed on 27 March 2023 followed by a Reply on 18 April 2023. A consent order proposing
amended grounds was approved on 17 October 2023. On 15 December 2023, the WCS application was
refused in its entirety. Thereafter, the Claimant submitted written evidence from Heidi Bancroft of Justice
and from her solicitor Van Ferguson. There is an issue as to how I should treat that evidence.

6. In summary, the Claimant argues that the Director wrongly concluded that the compensation process
did not engage her rights under Art.6 or Art.8 of the ECHR and wrongly failed to consider if the
circumstances of the case were such that ECF ought to have been granted. The Director submits that the
decision reached was lawful and proper so that there are no grounds to interfere with it.

**The WCS Scheme Generally**

7. The scheme was launched in April 2019 to compensate members of the Windrush generation and their
families for losses incurred as a result of not being able to demonstrate their lawful immigration status.

8. To be eligible for compensation an applicant must fall into one of six categories. The category an
applicant falls into will determine the period over which they may be entitled to compensation. It appears
that the categories are not mutually exclusive. Membership of a particular category does not guarantee
compensation, rather each claim has to be made out by a given applicant. There is no “entitlement” to
compensation until an award is accepted (see r.8.7). The scheme is not statutory but has its own rules and
its own guidance for decision makers. The rules note that there is no “single or consistent picture of the
loss suffered by those affected.” and emphasise that compensation is paid voluntarily.

9. To December 2022 there have been 5,080 applications and 3,025 decisions. Of the decisions 1,309
were awards of compensation. In 1,424 cases, no compensation was offered. Since inception over £71m
has been paid to Claimants (around £23k each).

10. The state provides some assistance to applicants to help them complete the application process. It is
time limited and, whilst I accept it is provided in good faith and with care, it appears from the evidence not
to have served the Claimant well.

**The Claimant's Involvement with the WCS**

11. The Secretary of State for the Home Department is responsible for the scheme but is not a party to
these proceedings. I have therefore heard no submissions from the Secretary of State about the scheme. I
accept (as the Windrush Justice Clinic preliminary research report in March 2022 concluded) that the
process of applying for compensation can fairly be described as complex. To understand what the criteria
for awarding compensation are, an applicant would need to familiarise themselves with the scheme rules
and in particular the 9 annexes (B to J) which outline the type of compensation that is available and what
needs to be established to qualify for it. The application process also refers to specific parts of guidance
issued to decision makers. For example, a claim for compensation for lost access to employment (annex
D) directs the applicant to 10 pages of the guidance.

12. The Defendant points out that the scheme rules require only core information for a claim to be
registered and progressed. Case workers are told that they should not expect claimants to provide
“detailed documentary evidence to support every aspect of their claim” and are required to conduct their
own research by, for example, reviewing Home Office records and asking for information from other
Government departments before approaching claimants. The Defendant submits that this supports the
view that legal advice is not needed at the initial claims stage.


-----

13. The Claimant made an appointment with WAD for a compensation support session to take place on 9
December 2021 (more than a year before her application). The Claimant was upset to learn at that meeting
that those providing assistance were employed by the Home Office. Her recollection is that she “could not
get [her] head round [the fact that] the people who had caused me huge problems …and [who had] done
damage to me and my family were now the ones saying they were going to help”. The Claimant was
unhappy with the support she received and made a complaint. Further appointments were made with the
Salvation Army (who are in fact a provider of WAD services) for 3 February 2022 and 24 February 2022.
The first appointment was cut short and only lasted an hour and the Claimant did not attend at the second
appointment. She felt that she was being “set up to fail”. Thereafter she consulted Southwark Law Centre.

14. The Claimant's application to the WCS has been refused. She says that she has been put into the
wrong category of applicant so that the period over which a claim for compensation can be made results in
her having no compensable loss. The rejection is now the subject of an internal appeal.

**The Statutory Basis for ECF**

15. The Director's powers are set out in sect. 10 of the Legal Aid Sentencing and Punishment of Offenders
Act 2012 (“LASPO”). Section 9 provides that legal aid for civil matters is generally available if those matters
are described in Part 1 of Schedule 1 of the Act and the applicant qualifies for assistance. Section 10
provides for the exceptional grant of legal aid for a matter not described in the schedule.

_Section 10 Exceptional Cases_

_(1) Civil legal services other than services described in Part 1 of Schedule 1 are to be available to an_
_individual under this Part if subsection (2) …. is satisfied._

_(2) This subsection is satisfied where the Director—_

_(a) has made an exceptional case determination in relation to the individual and the services, and_

_(b)…._

_(3) For the purposes of subsection (2), an exceptional case determination is a determination—_

_(a) that it is necessary to make the services available to the individual under this Part because failure to do_
_so would be a breach of—_

_[(i) the individual's Convention rights (within the meaning of the Human Rights Act 1998), or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_

_(ii)……., or_

_(b) that it is appropriate to do so, in the particular circumstances of the case, having regard to any risk that_
_failure to do so would be such a breach._

**Refusal of Exceptional Case Funding: The Decision Under Review**

16. The Claimant's application for ECF was refused on 13 September 2022. The refusal letter referred to
the criteria set out at sect.10(3)(a) and (b). It was found that neither Art.6 nor Art.8 was engaged so that the
(3)(a) criterion was not met. From an abundance of caution, the decision maker went on to conclude that
legal advice was not needed in order for the application process to be completed. This determination
addresses the necessity criterion in (3)(a). The letter ends with reference to the right of review of the
decision under reg.69 of the Civil Legal Aid (Procedure) Regulations 2012. It is common ground that the
refusal does not address the (3)(b) criterion.

17. The Claimant sought a review under reg.69 on 29 September 2022 and provided some evidence. The
review concluded that no A1P1 right was at stake (which is common ground) but went on to conclude that
there could therefore (because no A1P1 rights were at stake) be no engagement of Art.6. Because no
convention rights were engaged the review concluded (as did the initial decision) that it was unnecessary
“to go on to consider whether withholding of legal aid would mean [the Claimant] is unable to present her
case effectively or would lead to an obvious unfairness”. Again, the (3)(b) criterion was not addressed.


-----

18. Reg.69(3) makes it plain that the reviewer (the Director) may confirm the decision, amend it, or
substitute a new decision. The review decision itself does not specify which option has been adopted. I
note that the review begins with the words “The first question that I must consider is whether this
application involves the determination of a civil right or obligation”. There is then no reference at all to the
initial decision. I also note that the request for review makes it plain that the Claimant continues to rely on
the original application in respect of her Art.6 submissions and asks that they be “reconsidered”.

19. I accept the Claimant's submission that the review decision is the relevant decision. It seems to me
that the Claimant asked for a fresh reconsideration and that the reviewer undertook exactly that. In my view
the Defendant has confirmed the outcome of the first decision but has done so by making a new decision.

**The Evidence**

_Available to the Director at the Date of the Review_

20. A detailed witness statement was prepared for the Claimant and signed by her on 20 July 2022. It
paints a vivid and detailed picture over its 39 paragraphs. It details how the absence of a documented right
to be in the United Kingdom has impacted her life. The evidence forms the basis of the application for ECF
and is summarised in the application at paragraph 1.

_Further Evidence_

21. After the present judicial review proceedings were issued and long after the Director's decision to
refuse ECF had been made and communicated, further evidence from the Claimant's solicitor and from
Heidi Bancroft of Justice was filed.

22. The evidence of the Claimant's solicitor (Mr Van Ferguson) was filed in response to a factual assertion
made in the Grounds of Defence that it would be possible to participate effectively in the WCS without legal
advice.

23. The Claimant seeks permission to rely on the evidence of Mr Ferguson and Miss Bancroft.

_Relevant Convention Rights_

24. Article 6(1) of the European Convention on Human Rights provides:

_Right to a fair trial_

1.  In the determination of his civil rights and obligations …. everyone is entitled to a fair and public hearing
_within a reasonable time by an independent and impartial tribunal established by law. Judgment shall be_
_pronounced publicly but the press and public may be excluded from all or part of the trial in the interest of_
_morals, public order or national security in a democratic society, where the interests of juveniles or the_
_protection of the private life of the parties so require, or to the extent strictly necessary in the opinion of the_
_court in special circumstances where publicity would prejudice the interests of justice._

25. Article 8 provides:

_Right to respect for private and family life_

_1. Everyone has the right to respect for his private and family life, his home, and his correspondence._

_2. There shall be no interference by a public authority with the exercise of this right except such as is in_
_accordance with the law and is necessary in a democratic society in the interests of national security,_
_public safety or the economic well-being of the country, for the prevention of disorder or crime, for the_
_protection of health or morals, or for the protection of the rights and freedoms of others._

_Guidance_

26. There is no challenge to the lawfulness of the ECF guidance. I was not referred to it. It is clear that it is
derived from Gudanaviciene (see below). At paragraph 2.6 it is noted that the purpose of sect. 10(3) is to
enable Convention rights to be protected in the context of a civil legal aid scheme which aims to ensure
that “limited resources” are focussed “on the highest priority cases”.


-----

_Grounds_

27. Only 2 grounds are pursued: The Defendant misdirected herself as to the scope of Art.6 and the
decision breached the Claimant's Art.8 rights and was disproportionate and unjustified.

28. The Claimant asserts that the Director ought to have considered if a failure to provide ECF would
breach her convention rights and, if not, whether the discretion under sect.10(3)(b) should be exercised.

29. The parties agree that the first question (the applicability of sect.10(3)(a)) is a matter that I need to
determine. The outcome is not a matter of discretion. If I find that a discretion arises under sect.10(3)(b)
the exercise of that discretion should be remitted.

_Submissions_

30. The Claimant submits that the Defendant misdirected herself on the law. There are 3 gateways to the
grant of ECF: first, a finding that the compensation process engages Art.6, secondly, a finding that the
process engages Art.8, thirdly by an exercise of discretion under LASPO sect.10(3)(b).

31. The Defendant submits that none of these gateways is available and that there is no public law basis
on which to interfere with the Defendant's decision.

_Art.6_

32. As to Art.6, the Claimant accepts that the WCS does not give rise to any rights protected by A1P1 but
submits that that is not a bar to the engagement of Art.6. That proposition is not in dispute. The Claimant
submits that in order to determine if Art.6 is engaged, I should ask myself if the scheme is concerned with
civil rights. If it is, the Claimant submits that I need not be concerned about the existence of a dispute.

33. The Claimant cited 3 authorities:

a. In Moreira de Azevedo v Portugal (1990) 13 EHRR 721, the claimant had been injured in a shooting.
The shooter was prosecuted, and the claimant joined in the prosecution as an “assistente”. The Court held
that intervening in the criminal proceedings was (as a matter of domestic law) the equivalent of filing a
claim for compensation. The Claimant points out that at paragraph 66 of the decision, the Court finds it
necessary to give Art.6 a wide meaning so that the need for a dispute should not be construed too
technically. It goes on to cast doubt on the need for a dispute at all.

b. In _Perez v France (2004) 40 EHRR 39, the Grand Chamber (an 18-Judge Court) the claimant joined_
criminal proceedings as a civil party. The Court found (as in Moreira) that as a matter of domestic law, the
effect of joining in to criminal proceedings was
that Mrs Perez was to be treated as if she had brought a civil claim for damages (see paragraph 62). The
Claimant points out that Art.6 was held to cover the initial stages of the claim.

c. Bank Mellat v HM Treasury (no.2) [2012] QB 101. The Treasury made an order pursuant to a statutory
power effectively preventing any financial dealing with the Bank. The Bank challenged the order. The
challenge was rejected, and the matter came to the Court of Appeal. At first instance, Mitting J had
concluded that when the order was made there was no dispute. Maurice Kay LJ (with whom Pitchford LJ
agreed) found that Mitting J was right. Elias LJ expressed a different view and said that the real question is
not whether there is a dispute about rights, but whether a party who relies on Art.6 has a sufficiently direct
interest in the outcome “of a case” but concluded in any event that the engagement of Art.6, and the
consequences of engagement, were irrelevant. The Claimant submits she has a clear and direct interest in
the outcome of her claim for compensation.

34. The Claimant submitted that the decision in _Wos v Poland (2007) 45 EHRR 28 was decisive in her_
favour on the application of Art.6. In that case, the Court decided (see paragraph 75) that whether a right
was created was a matter for the Court and not for the domestic law of the state where the right was said
to have arisen. The domestic Court had found that no right was created.


-----

35. By reference to _Grzeda (see below), the Defendant submits that_ _Wos is (on this issue at least) no_
longer good law. The arbiter of questions about the nature of the right in question (and in particular whether
it gives rise to civil rights) is the domestic Court.

36. The Claimant accepts that rights that are dependent upon a series of evaluative judgments by the
provider as to whether relevant criteria are satisfied and how the need for it ought to be met (soft-edged
rights too far removed from an A1P1 right) will not engage Art.6 but submits that the rights in issue in the
WCS are sufficiently hard-edged. She cites 3 authorities to make good the proposition:

a. Salesi v Italy (1998) 26 EHRR 187 is a welfare benefits case. In order to qualify for the benefit, the state
had to conclude that the applicant was destitute and “more than two-thirds disabled”. The Court found that
the claimant was not impacted by the exercise of discretionary powers but was claiming a specific
economic right “from specific rules laid down in a statute”. In Ali, the Supreme Court noted (paragraph 43)
that in Salesi the substance of the relevant welfare rights was defined precisely.

b. Ali v Birmingham City Council [2010] 2 AC 39where the Supreme Court found that statutory obligations
owed to homeless people under sect. 193 of the _[Housing Act 1996 (to secure that accommodation is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)_
available) lacked precise definition and was expressed in terms of broad principle. Lord Hope found that
where the award of services or benefits in kind is not an individual right of which the applicant can consider
himself the holder but is dependent upon a series of evaluative judgments by the provider as to whether
the statutory criteria are satisfied and how the need for it ought to be met, Art.6 is not engaged. The
Claimant relies on Lord Collins' expressed view that the real reason that Art.6 does not apply is not the
evaluative nature of the determination but rather the fact that there was no interference with an individual
economic right. He noted (paragraph .61) that the mere fact that the judgment was evaluative was not
enough to bar engagement of Art.6.

c. The _Ali_ case went to the European Court who disagreed and found that Art.6 was engaged. The
Supreme Court's first opportunity to comment on the Strasbourg decision came in Poshteh v Kensington

[2017] AC 624. The Supreme Court declined to follow the Strasbourg decision not least because the Court
had failed to understand the discretionary nature of the rights.

37. The Director submits that the application for compensation does not concern the determination of civil
rights. She submits that for Art.6 to be engaged, there needs to be a dispute that is genuine and serious,
and the proceedings must be directly decisive of that dispute. The Director relies on paragraph 257 of the
decision of the 17-Judge Grand Chamber of the European Court of Human Rights in Grzeda v Poland 15
March 2022.

_Art.8_

38. As to Art.8, the crux of the Claimant's submission is that an action by the State which produces serious
personal and practical consequences is sufficient to engage Art.8. The Claimant relies on XY v Secretary
_of State for the Home Department_ _[2024] EWHC 81 (Admin). In that case the Defendant was found to have_
operated an unpublished, blanket policy which had the effect of delaying the processing of immigration
claims, including XY's claim. Part of the claim for Judicial Review was that the refusal to consider his
application was a breach of Art.8. Lane J found that Art.8 was engaged because the grant of residence
status would give XY access to higher state benefits and also relieve his anxiety. The Claimant invites me
to conclude that any state action which might alleviate mental anguish or allow access to better financial
resources engages Art.8.

39. The Defendant submits the challenge is unsustainable because the application for compensation
concerns historical wrongs. The Claimant's Art.8 rights (unlike in immigration or family proceedings) are not
at stake. If the Claimant has been sufficiently involved in the decision-making process that is enough.

_Section 10(3) (b)_

40. As to the sect.10(3)(b) point, the Claimant argues that the Defendant has a residual discretion to grant
ECF even if Convention rights are not engaged. Some guidance is set out by the Court of Appeal in _R_
_(Gudanaviciene) v Director of Legal Aid Casework [2015] 1 WLR 2247at paragraphs 29 to 32 In summary_


-----

Lord Dyson concluded that if the Director cannot conclude that a refusal of ECF would lead to a breach of
Convention rights, no duty under sect.10(3)(a) arises, and the Director must go on to consider if he should
award ECF under sect.10(3)(b). At that stage, the Director must take account of any risk of breach but
must also take account of all the circumstances of the case.

41. The Defendant submits that if the Director's conclusion that no Convention rights are engaged was
correct, there is no need to consider sect.10(3)(b). This approach is consistent with context and in
particular with the structure, aims and purposes of LASPO. In short, sect.10(3)(b) cannot be read as giving
a general discretion to the Director to grant ECF. The Defendant also suggests that if the Claimant is right
in this argument, there can be no doubt the Director would reach the same decision if the point was
remitted.

_Determination of the Legal Issues_

42. Before considering the authorities (the bulk of which deal with Convention rights) I bear in mind that
decisions involving such rights involve 2 questions: is the relevant article engaged and if so, is it breached?
Often the first question receives little, if any, attention because engagement is often obvious.

_Art.6_

43. As far as Art.6 is concerned, I accept Mr Birdling's submission that Grzeda provides authoritative and
recent guidance on the circumstances in which Art.6 is engaged. Indeed, it is plain that the Grand
Chamber felt its summary was uncontroversial. In summary (see paragraph 257) for Art.6 to be engaged,
there must be:

a. a dispute over a right,

b. the right must be (at least arguably) recognised under the domestic law of the state in which it is being
asserted. It need not be protected by A1P1.

c. The dispute may relate to the existence of the right, its scope, or the manner in which it might be
exercised. It must be a genuine and serious dispute.

d. The result of the proceedings must be directly decisive for the right.

_The Need for a Dispute_

44. At the time, the decision to refuse ECF was made, there was no dispute between the Claimant and the
WCS.

45. The Claimant relies on paragraph 66 of Moreira to support her position that the existence of a dispute
is not necessary for the engagement of Art.6:

_“In the Court's opinion, the right to a fair trial holds so prominent a place in a democratic society that there_
_can be no justification for interpreting Article 6(1) of the Convention restrictively. Conformity with the spirit_
_of the Convention requires that the word contestation should not be construed too technically and that it_
_should be given a substantive rather than a formal meaning. Besides, it has no counterpart in the English_
_text of Article 6(1).In so far as the French word contestation would appear to require the existence of a_
_dispute, if indeed it does so at all, the facts of the case show that there was one. In any event, the case_
_concerned the determination of a right; the result of the proceedings was decisive for that right.”_

46. _Perez and_ _Moreira are unusual. In each case, civil rights (the right to compensation for injury) were_
being asserted in criminal proceedings. Where a claimant in those circumstances has a choice of how to
claim compensation, it would be inappropriate to treat the choice as the factor that determined if Art.6
applied. The circumstances in which Perez and Moreira apply are clearly very limited and very far removed
from the present Claimant's case.

47. In my judgment the _Bank Mallat case is further clear authority for the proposition that a dispute is_
required before Art.6 can be engaged. The obiter and dissenting comments of Elias LJ are not in line with
the general thrust of the authorities and do nothing to detract from the clear position set out in Grzeda.


-----

_Is a civil right at stake?_

48. The next issue to consider (assuming, contrary to the conclusion I have reached, there is a dispute) is
whether a claim for compensation under the WCS gives rise to a civil right of the type protected by Art.6. It
is accepted that a “right” that is dependent on evaluative judgments by the provider (as to qualification or
amount) does not engage Art.6.

49. The authorities relied on by Mr Buttler KC are about the provision of one type of benefit or another.
The application of Art.6 to social benefits has been described (see Salesi at page 194 and the concurring
opinion on admissibility of Mr Sperduti) as “one of the most important of all the developments which have
_taken place over the decades in the case law of the institutions of the European Convention on human_
_rights”. Mr Buttler KC seeks to persuade me that WCS payments should be treated in the same way._

50. He referred to the cases of Salesi, Ali and Poshteh and posed the question: do the rights at stake in
the present case fall within what he called the Ali exception? In other words, are those rights “soft-edged”
and discretionary? In my view that question is not definitive. It starts from the assumption that WCS “rights”
engage Art.6 and proceeds to ask if the presumption can be displaced. The proper approach in my view is
to consider if the authorities shed any light on the correct classification of rights in this case.

51. In Salesi, the Court proceeded on the basis (paragraph 24) that the claimant had a (hard-edged) right
to the benefit. Further, the Supreme Court in Ali (at paragraph 43) described the benefits due to Mrs Salesi
as being defined precisely by domestic law. The argument against engagement of Art.6 was not that the
right was too “soft-edged” it was that the right was not a “civil” right but was rather a public law right. The
Court concluded that Art.6 applied nonetheless, because on analysis, Mrs Salesi's claim was based on
interference with an economic right created by specific rules laid down in a statute (see paragraph 19).
That was a basic, hard-edged right which required protection.

52. In Ali, the Supreme Court decided that the duty of a local housing authority to provide homelessness
assistance, unlike the _Salesi benefits, lacked precise definition and left “much to the discretionary_
_administrative judgment of the authority”. Lord Hope giving the leading speech (with which Baroness Hale_
and Lord Brown agreed) concluded that a claim to receive a service (not a payment), which would only be
granted after the exercise of broad evaluative judgments, “as to whether the statutory criteria are satisfied
_and how the need for it ought to be met” would not be a right covered by Art.6. Lord Collins agreed with_
Lord Hope's conclusion but for different reasons. He felt that the evaluative nature of the award was not
central, but the absence of any individual economic right was decisive.

53. Ali needs to be read in the light of Poshteh. The refusal of the Supreme Court to treat the provision of
housing assistance as a right covered by Art.6 was sent to Strasbourg where the Court came to the
opposite conclusion. _Poshteh was the Supreme Court's first opportunity to deal with the Strasbourg_
judgment. The Supreme Court was under a duty to “take account of” the Strasbourg decision and decided
for a number of reasons not to follow it. At paragraphs 34 and 35 of the judgment Lord Carnworth pointed
out that the Strasbourg court may not have “fully appreciated the width of the discretion given to the
_authority”. In referring back to the decision in Ali reference is made at paragraph 25 to Lord Collins' speech._
It is plain from the decision in Poshteh that the evaluative nature of the decision was in the Court's view
one of the reasons for concluding that the relevant rights were not “civil rights”.

_Wos_

54. In 1992, the Polish-German Reconciliation Foundation (“the Foundation”) was established in Poland
under the terms of the Foundations Act of 6 April 1984, a national statute (see paragraph 19 at page 666).
The Foundation's aim was to “render direct financial assistance to those victims of Nazi persecution whose
_health had been seriously damaged and who were in a difficult financial situation as a result of the_
_persecution” (paragraph 31)._

55. Mr Wos applied to the Foundation for compensation in respect of time he had spent as a forced
labourer between February 1941 and January 1945. He received a “primary” payment in 1994 and a


-----

“supplementary” payment in 2000. The primary payment covered the entirety of his claim, the second
payment covered only the time before his 16th birthday.

56. The state of Poland argued that the primary payment had not been made in accordance with the
statute that governed the scheme. It too ought to have been limited to the time before his 16th birthday.
The Court found that the body responsible for admitting claims had a broad discretion as to what claims it
accepted (see paragraph 73). Considering if a “civil right” arose, the Court likened the scheme to welfare or
benefit systems because compensation was awarded to alleviate financial suffering and damage to health
(paragraph 77) and Mr Wos's complaint was not about the administration of the scheme (he was not
“affected in his relations with the Foundation acting in the exercise of its discretionary powers”), instead:

_“He had suffered an interference with his means of subsistence and was claiming an individual, economic_
_right flowing from specific rules laid down in the Foundation's Statute and its byelaws”_

57. The Court was clear therefore that this was not a claim about the exercise of discretionary powers. It
appears that Mr Wos was always entitled to compensation once he had satisfied the Foundation that he
complied with the terms of the scheme (see paragraph 75 and see paragraph 84 of the Italian Interns'
Case below).

58. In Poland, both the Supreme Administrative Court and the civil courts had determined that the rights at
stake were not civil rights and so those courts had no jurisdiction to deal with the matter. Mr Wos relied on
Art.6(1) in support of a claim that he had been denied access to a court and claimed satisfaction under
Art.41. The key aspect of the case is the application of Art.6. At paragraphs 75 and 76 the Court ignored
the conclusion reached by the domestic courts and determined that the rights were civil rights.

59. Mr Birdling submitted that _Wos was unsafe in light of the observations of the Grand Chamber in_
_Grzeda at paragraph 259 (he described the decision as an outlier and said that the key reasoning was_
“demonstrably wrong”) that unless the national courts' interpretation of domestic legislation was “arbitrary
or manifestly unreasonable” that interpretation will be taken by Strasbourg.

60. In my judgment, _Wos is distinguishable from the present case. The decision rests on the Court's_
willingness to treat payments from the Foundation as welfare or benefit payments. An important part of that
conclusion was the fact that the Foundation was a creature of statute, and that the compensation was
about “subsistence”. In my judgment the same cannot be said of WCS payments. WCS is (importantly) not
a statutory scheme. Its payments are not related to “subsistence”, and it is difficult to pinpoint any similarity
between WCS and welfare benefits. Further, it is not clear that the Claimant has a right to compensation.
As things stand, she does not.

61. Further, I accept Mr Birdling's submission that, in light of the present state of the law, Wos is an outlier.
It represents an expansion of the types of claim covered by Art.6. There is nothing in Strasbourg or United
Kingdom domestic jurisprudence which suggests that the extension is anything other than limited and factbased. I do not accept that the decision is necessarily wrong. One of the reasons the case might be seen
as an outlier is that it may permit the engagement of Art.6 even if the rights involved are not “private” rights.
In his concurring opinion on admissibility in Salesi (see above at paragraph 49), Mr Sperduti notes that the
“gradual shift” to the engagement of Art.6 in benefits cases arises “even when the dispute concerns a right
_governed for the most part by the rules of public law”._

_Compensation Schemes and Welfare Claims_

62. Three further cases need mention before considering the welfare and compensation scheme cases as
a whole: Associazione Nazionale Reduci Dalla Prigionia Dall'Internamento e Dalla Guerra Di Liberazione v
_Germany (2008) 46 EHRR SE11 (“the Italian Interns' case”);_ _Stec v United Kingdom (2005) 41 EHRR_
SE18 and the domestic case of JT v First Tier Tribunal _[2018] EWCA Civ 1735. These cases were cited by_
the Defendant in the review decision.

63. The Italian Interns' case and JT support the view that Wos has not opened the door to an expansive
treatment of Art.6. These cases (like Wos) are compensation scheme cases. The former dealt with one-off
payments for specific historical wrongs, was set up on a voluntary basis and sat outside of the national


-----

social security scheme. In that case Art.6 was found not to be engaged. The latter deals with criminal injury
compensation. Art.6 rights were found to be engaged. Payments under that scheme do not relate to
specific historical wrongs and the scheme was set up to meet international obligations and operates on a
statutory basis. Stec concerned a welfare claim where regular payments made as part of a national social
security scheme were in issue.

64. Stec was an A1P1 case, not an Art.6 case. The reasoning in the case is not however wholly divorced
from Art.6 considerations. At paragraphs 47 and 48 the Court made it clear that the Convention should be
read as a whole and that A1P1 definitions should be interpreted in a way that is consistent with the concept
of “civil rights” under Art.6. It was held that the rights in question were A1P1 rights.

65. In JT, the Court of Appeal was concerned with the Criminal Injuries Compensation Scheme (“CICS”).
The claimant asserted that she had been a victim of discrimination and sought redress through Art.14. For
Art.14 to apply the right had to be protected by A1P1. Leggatt LJ (as he then was) gave the lead judgment
of the Court. He considered Stec, Ali, Poshteh, and the Italian Interns' case.

66. Lord Leggatt referred (paragraph 13 and paragraph 65) to the Convention on the Compensation of
Victims of Violent Crimes adopted by the Council of Europe in 1983 and ratified by the United Kingdom in
1990. Art.2 of the convention imposes an obligation in most circumstances on states to ensure that victims
of violent crime receive compensation. At paragraph 66 he noted that in the Italian Interns' case the Court
regarded the one-off payments as similar in nature to the payments in _Stec (non-contributory benefits_
partly funded by general taxation) but that _Stec was distinguished because the payments in the Italian_
Interns' case were made in respect of “particular historic events” and that the reparations scheme was “a
_special scheme set up to provide one-off payments of reparation for a particular historic event”. Lord_
Leggatt concluded that the CICS was not such a scheme.

67. At paragraph 56 Lord Leggatt emphasised the connection between A1P1 and Art.6 highlighted in Stec
and at paragraph 57 considered Ali and Poshteh (Art.6 cases). At paragraph 67 he noted that the CICS is
a statutory scheme, whereas its predecessor (the Criminal Injuries Compensation Board) was not.

68. These cases are instructive because they draw a clear distinction between the social security or social
welfare cases where benefits are payable as of right, under statute (JT paras. 54 to 58) and schemes
designed to provide reparations for a particular historic event or wrong (JT paras. 59 to 63).

69. In my judgment the WCS is very close to the scheme in the Italian Interns' case. It is a special scheme
set up to provide one-off payments as reparation for a particular historic wrong, namely the treatment of
those who came to the United Kingdom to assist it in its time of need but who subsequently suffered (as
the Home Secretary put it in 2020) “terrible injustices spurred by institutional failings”. If anything, the WCS
is a more obvious example of a scheme which does not give rise to a civil right in the sense understood in
Art.6; it has no statutory basis at all and the only means of enforcing any award would be through public
law proceedings as was accepted during the course of argument. In my view these points taken together
provide a firm basis for the conclusion that the rights created by the WCS are not protected by Art.6.

**_Conclusions on the Art.6 points_**

70. Even if there was a relevant dispute, I am satisfied that Art.6 does not apply. The WCS is non
statutory, it is not concerned with the relief of ill health or poverty (a qualifying claimant may receive
compensation even if well-off and in good health) and is designed to offer one-off compensation for specific
and proved losses suffered as a result of historic wrongs perpetrated by the state. It therefore has little in
common with _Wos (where there was a right to compensation once qualifying criteria were met and the_
scheme was rooted in statute), Salesi (where the payments were designed to assist the poor and unwell
and the scheme was statutory) and JT (where the scheme was not designed to compensate for historical
wrongs and was statutory). These factors point clearly away from the application of Art.6.

71. If the _Ali comparison must be made, then in my view the same outcome is arrived at. To award_
compensation under the WCS there needs to be an assessment of evidence. That process is not hardedged.


-----

_Art. 8_

72. I turn to the Art.8 question.

73. Mr Buttler KC relies principally on 3 decisions to support his submission that Art.8 is engaged as a
result of the serious personal consequences to the Claimant should her compensation claim not succeed:
_R (Gudanaviciene) v Director of Legal Aid Casework [2015] 1 WLR 2247,_ _R (Balijigari) v Secretary of_
_State for the Home Office [2019] 1 WLR 4647and XY v The Secretary of State for the Home Department_

[2024] EWHC 81.

74. Mr Birdling submits that Mr Buttler KC's approach (that any state action which has a sufficient effect on
the life of an affected person would result in the engagement of Art.8) would result in an uncalled for and
unprincipled widening of the ambit of Art.8. His position (with Miss Sahore) is that Art.8 is engaged only
when the decision maker is concerned with the application of those specific rights.

75. In Gudanaviciene the Court of Appeal was concerned with 6 joined immigration claims. In each case
the Director had refused to grant ECF. There were broadly 2 issues to consider: were Art.8 rights
engaged? And if so, was legal assistance required to ensure that each individual was “involved in the
_decision-making process, viewed as a whole, to a degree that is sufficient to provide them with the_
_requisite protection of their interests”? (See paragraph 71)._

76. To determine the second issue the Director (and the Court) needed to consider: the importance of the
issues at stake, the complexity of the procedural, legal and evidential issues and the ability of the individual
to represent themselves without legal assistance having regard to their age and mental capacity (see
paragraph 72 of the judgment).

77. The first issue (whether Art.8 rights were engaged) was taken for granted as obvious in most of the
cases. The only detailed discussion of engagement was in the case of B (see paragraphs 155 to 173 of the
judgment). The 6 claims were in brief:

a. Ms Gudanaviciene came to the United Kingdom in 2010. She had a 2-year-old daughter who was born
here. She applied for ECF for her appeal against deportation. The application was refused. Collins J noted
that she had a “very strong case” on the appeal. She had poor English and would obviously be
“emotionally involved” in the appeal so that she could not approach it objectively. The Court of Appeal
found the deportation appeal was of vital importance to her and her daughter and that without legal
representation she would be unable to present her case effectively. The refusal of ECF was overturned.
Deportation would have meant that Ms Gudanaviciene could not raise her daughter. Art.8 was clearly
engaged.

b. IS had lived in the United Kingdom for at least 13 years. He was blind, had cognitive impairment and
was unable to care for himself. ECF was sought to allow him to apply to regularise his immigration status
and so qualify for community care and health services. The judge at first instance quashed the Director's
decision to refuse ECF and remitted the matter. The appeal against the decision was not pursued. The
Court of Appeal said, “it is impossible to see how a man suffering from his disabilities could have any
_meaningful involvement in the decision-making process without the benefit of legal representation”. Art.8_
was clearly engaged (see paragraph 79 of the judgment).

c. LS arrived in the United Kingdom in 2004 having been trafficked. He was forced to work. He formed a
relationship and had 3 children. His partner and all 3 children have settled status. He applied for ECF to
among other things establish his status as a victim of trafficking. ECF was refused. The Court of Appeal
upheld the Director's refusal of ECF. Although Art.8 was engaged and although the issue of his status as a
victim of trafficking was “plainly of great importance” to him because it would impact on his right to remain
in the United Kingdom, he did not need legal representation to be involved in the process of establishing
his status.

d. Mr Reis entered the United Kingdom when he was 12 and was 28 years old at the time of the first
instance judgment. He was married with one child and his wife had a daughter from a previous
relationship. He had a number of convictions for increasingly serious criminal offences. Like Ms


-----

Gudanaviciene he sought ECF to allow him to appeal deportation. The Court of Appeal accepted that the
decision to deport him was “of immense significance” to him and his family (all of whom were British
citizens) and that the question before the Tribunal was “a particularly complex legal question”. Art.8 was
clearly engaged. The refusal of ECF was quashed.

e. B came to the United Kingdom in 2013 leaving her son and husband in Iran. She was granted refugee
status and given 5 years' leave to remain (“LTR”). She applied for family reunion. She spoke little English.
The Court of Appeal decided that Art.8 was engaged and accepted the issue of family reunion was of vital
importance to B. The procedure meant that B “did not have the first clue” so that without legal advice and
assistance it was impossible for her to have any effective involvement in the decision-making process. The
decision to refuse ECF was quashed.

f. Miss Edgehill came to the United Kingdom in 1998 as a visitor. She was granted LTR as a student until
2001. After expiry of that right she remained as an overstayer. After an application to regularise her
application was refused in 2012 she lodged an appeal without legal assistance. Her Art.8 claim was based
on the fact that all of her family (four children and a grandchild) were in the United Kingdom. The Upper
Tribunal refused her appeal but permission to appeal was granted by the Court of Appeal. A request for
ECF was made after the grant of permission to appeal but refused. The appeal went ahead (listed with a
similar appeal at which the Claimant was represented) and was successful. Miss Edgehill was also
represented. Collins J quashed the decision to refuse ECF. The Court of Appeal (in the present case)
accepted that the decision was of vital importance, but found, because the joined case required the point
on which she succeeded to be argued, that failure to grant ECF was not a breach of her Art.8 rights.

78. _Balijigari deals with the engagement of Art.8 in immigration cases. There were 4 joined appeals. In_
each case the applicants had sought (and been refused) indefinite leave to remain (“ILR”) as tier 1 general
migrants. Necessarily, in order to apply for ILR, each applicant had been in the United Kingdom for several
years (Mr Balajigari had arrived in the United Kingdom on 16 August 2007 and had applied for ILR on 1
June 2016). Whilst the time period alone may not be enough to establish Art.8 rights and each case would
need to be examined on its facts, the Court of Appeal agreed that it was “inescapable” that in such cases
the applicant was likely to have built up a sufficient private life for his removal to engage Art.8.

79. _XY was an immigration case. The Claimant was a victim of_ **_modern slavery in his home state of_**
Albania and had come to the United Kingdom in 2018 (when he was 17). Lane J accepted that he was a
“very vulnerable young man who had been struggling to manage his mental health over a number of
_years….it was unlikely that there would be any improvement in [his] …. wellbeing until such time as the_
_Claimant felt safe and stable in the United Kingdom”. The finding that the Claimant had been a victim of_
**_modern slavery was made in July 2021. He sought LTR on the basis of this finding, but the Secretary of_**
State declined to make a decision. Instead, in December 2022 he agreed to grant the Claimant
discretionary LTR for a period of 12 months. The Claimant also had an outstanding asylum application and
so could not be removed until at least that claim was determined. Lane J decided that the Secretary of
State had acted unlawfully and went on to decide if the denial of modern slavery LTR engaged Art.8. He
took account of the Claimant's evidence that a grant of **_modern slavery LTR would make him feel safe_**
and stable and concluded that it was engaged (so that the failure to do so was very significant). The
Claimant's particular vulnerability was clearly an important factor.

80. When considering the question of engagement, Lane J referred toMendizabal v France (Application
no. 514314/99). In that case, over a period of 14 years, the Claimant had been issued with a series of short
term (3 month) leaves to remain. That approach was found to contravene her Art.8 rights and had had a
“significant moral and financial impact” on her. Lane J accepted that XY had been granted an inferior 12month LTR when he was entitled to (superior) modern slavery LTR.

**_Conclusion on Art.8_**

81. In my view two questions arise from the authorities: are Art.8 rights at stake in the Claimant's case? If
so, do the procedural protections of Art.8 apply?


-----

82. The resolution of the first question is clearly a matter of degree. The answer is often so obvious that
there is no need for explanation. The cited cases provide a helpful guide. Where the consequences of a
state action would include the separation of families (see the Gudanaviciene deportation cases, the family
reunion case and the trafficking case) or interference with the private life rights built up over long periods of
lawful residence (see the Balijigari cases) Art.8 is very likely to be engaged. Equally if the state grants timelimited rights to remain when it ought to grant longer-term rights and the consequences on a given
individual are “significant” Art.8 will be engaged (see XY). Once Art.8 is engaged, the target of the state act
(the person to be deported, the mother who wanted to be reunited with her husband and child, the victim of
trafficking or the person who is granted inferior rights and suffers as a result) is entitled to meaningfully
participate in the decision making process.

83. I do not accept, and in my view the authorities do not support, Mr Buttler KC's submission that any
consequence which has an impact on the day-to-day life of an applicant is sufficient to engage Art.8. The
cases deal with interference that goes to the very essence of Art.8 rights.

84. In my judgment Art.8 is not engaged on the facts of the present case. The grant or refusal of WCS
compensation does not in my judgment engage Art.8. It is no coincidence that all of the cited cases are
concerned with immigration rights. Art.8 has been a particular focus in those cases because Art.6 has no
application and because it is common for immigration decisions to interfere with established rights
recognised under Art.8. Balijigari is a clear example. XY is an example of a decision having a “significant
_moral and financial impact” on the applicant. I do not accept Mr Buttler KC's attempts to classify XY as a_
case where the impacts were minimal.

85. In the Claimant's case the grant or refusal of compensation would not in my judgment have a
sufficiently significant impact on the essence of her private and family life to engage Art.8. The outcome of
her claim does not dictate if the Claimant would continue to enjoy a family life or a private life. I accept that
her life would be made materially better by a significant award, but in my judgment that is not enough.

86. It follows that the procedural rights that follow the engagement of Art.8 are not triggered. If they were
triggered, then applying the criteria explained in Gudanaviciene I would have concluded that the outcome
of the WCS application is important to the Claimant but that the level of importance would fall short of those
in the _Gudanaviciene cases. I accept that the application process is a complex one, but the level of_
complexity does not arise because of the need to argue complex points of law. On the issue of the
Claimant's ability to deal with matters without help I note that she has no language issues and no health
issues. I accept that she would find the process emotionally difficult not least because the WCS is
administered by the Home Office, the perpetrator of the acts she has just cause to complain about. Taking
these matters together, even if Art.8 was engaged, I would have found, taking into account the
characteristics of the WCS, that the Claimant could participate in the process in order to vindicate her Art.8
rights without the need for legal assistance.

_The Discretionary Question_

87. I then turn to the question that arises under sect.10(3)(b) LASPO. Is there a general discretion to grant
ECF or is the discretion limited?

88. In my view it is clear that there is no general discretion of the type argued for by Mr Buttler KC. I
accept that it is possible to read sect.10(3)(b) in isolation as giving rise to such a discretion. But that
approach is faulty. Seen in the context of LASPO as a whole, it is plain that there is no general discretion.

89. Further, the point was addressed in _Gudanaviciene in some detail at paragraphs 29 to 32 and in_
particular at paragraph 32. The analysis starts with sect.10(3)(a): “In short….if the Director concludes that a
_denial of ECF would be a breach of an individual's Convention or EU rights, he must make an exceptional_
_funding determination” but notes, because the question is not always “hard edged”:_

_“The Director may conclude that he cannot decide whether there would be a breach of the individual's_
_Convention or EU rights. In that event, he is not required by section 10(3)(a) to make a determination. He_
_must then go on to consider whether it is appropriate to make a determination under section 10(3)(b).”_


-----

90. In reaching this conclusion the Court accepted the submissions advanced by Mr Drabble QC that
“section 10(3)(b) caters for those cases where it is not possible to decide whether there would be a breach
_but there is a risk (“any risk”, not a substantial risk) of a breach” (at paragraph 28). On that basis, the Court_
found that the Lord Chancellor's guidance that the discretion in sect.10(3)(b) should only arise “in those
rare cases where it cannot be said with certainty whether the failure to fund would amount to a breach” was
misleading because it wrongly “severely circumscribed” the exercise of the discretion (limiting it to “rare
cases”) (see paragraph 44).

91. The Court of Appeal continued at paragraph 32:

_“In making that decision [under sect.10(3)(b), the Director] should have regard to any risk that failure to_
_make a determination would be a breach. These words mean exactly what they say. The greater he_
_assesses the risk to be, the more likely it is that he will consider it to be appropriate to make a_
_determination. That is because, if the risk eventuates, there will be a breach. But the seriousness of the_
_risk is only one of the factors that the Director may take into account in deciding whether it is appropriate to_
_make a determination. He should have regard to all the circumstances of the case.”_

92. Mr Buttler KC relied on the final sentence in support of his submission that the discretion was general.
But, in my view, the passage and the decision taken as a whole, make plain that the need to consider the
(3)(b) discretion only arises if no decision is made under (3)(a).

93. I therefore reject Mr Buttler KC's argument that the discretion is a wide one and find that it only arises if
no decision is made under (3)(a). If a decision is made that no convention right arises, it follows that no
discretion under (3)(b) arises.

_The approach to the review and conclusion_

94. I have found that neither Art.6 nor Art.8 rights are engaged in the WCS process. I have also found that
in those circumstances there was no need for the Director to consider the LASPO sect.10(3)(b) discretion.

95. My conclusion in respect of Art.6 does not depend on the absence of a dispute between the parties.
The fact that there is now a dispute (because the Claimant does not agree with the decision to grant her no
compensation) is therefore not material. If the existence of a dispute had been decisive (so that Art.6 would
then have been engaged) I would in any event have remitted the matter for the Defendant to consider if
ECF should be granted.

96. For these reasons, the claim is dismissed.

97. I am grateful to all counsel for their focused and helpful submissions.

**End of Document**


-----

