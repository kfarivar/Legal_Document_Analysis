# ADL and others v Secretary of State for the Home Department [2024] EWHC
 994 (Admin)

King's Bench Division, Administrative Court (London)

Mr Justice Lavender

15 May 2024Judgment

**Chris Buttler KC, Aidan Wills, Karen Staunton and Rosalind Comyn (instructed by Duncan Lewis) for**
the Claimants

**Mathew Gullick KC** and Mark Vinall (instructed by the Government Legal Department) for the
**Defendant**

Hearing dates: 5-7 December 2023

- - - - - - - - - - - - - - - - - - - - 
**JUDGMENT**

**Mr Justice Lavender:**

**(1) Introduction**

1. Each of the four claimants was detained by the Secretary of State and then released on immigration bail
subject to an electronic monitoring condition (“an EM condition”):

(1) The second claimant, Fabio Dos Reis, was subject to an EM condition from 7 March 2022 to 27
October 2022.

(2) The third claimant, BNE, was subject to an EM condition from 26 May 2022 to 7 November 2022.

(3) The first claimant, ADL, was subject to an EM condition from 14 July 2022 to 31 October 2022.

(4) The fourth claimant, PER, remains subject to an EM condition which was imposed when bail was
granted on 19 July 2022. The condition was varied on 26 October 2023, when it was changed from a
requirement to wear a “fitted” device to a requirement to use a “non-fitted” device.

2. Between them, the claimants challenge, or seek permission to challenge, a number of matters relating
to:

(1) the imposition of an EM condition in their case;

(2) the review of the EM condition in their case; and/or

(3) the retention of the data (“trail data”) gathered by reason of the operation of the EM condition in their
case,

although not every claimant seeks to challenge every one of these matters.

3. In the course of the three days of the hearing, counsel addressed many issues and many authorities. I
do not propose in this judgment to address every issue which was raised or every authority which was


-----

cited. I trust that what I say in this judgment will give an adequate explanation of the reasons for my
decisions on the issues which I have been asked to address.

4. There have been a number of developments since the hearing:

(1) For reasons which I will explain, I directed that the defendant could file a further witness statement
after the hearing and that the parties could exchange submissions in relation thereto. The last of these
submissions was filed on 21 December 2023.

(2) On 28 February 2024 the Information Commissioner issued an enforcement notice and a warning to
the defendant in respect of what the Information Commissioner considered to be actual and anticipated
breaches of the defendant's obligations under the _[Data Protection Act 2018. On 21 March 2024 the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)_
defendant stated that he was considering whether this gave rise to a need for further disclosure in this
case. On 27 March 2024 the claimants acknowledged that the Information Commissioner's findings do not
determine any of the legal issues in this case. On 18 April 2024 the defendant disclosed certain
documents. The parties exchanged submissions in this respect on 23 and 24 April 2024.

(3) On 11 March 2024 the Upper Tribunal handed down its decision and reasons in R (Nelson) v Secretary
_of State for the Home Department (2024) JR-2023-001472 (“Nelson”), which dealt with some of the issues_
which arise in the present case. I invited written submissions on Nelson and the last of those was received
on 27 March 2024.

**(2) The Nature of Electronic Monitoring**

**_(2)(a) GPS Devices_**

5. The following explanation of the technology concerned in this case is no doubt an over-simplification in
what I assume is a fast-changing area of technology. This case concerns two types of device which make
use of the Global Positioning System (“GPS”), which, as anyone who uses a satellite navigation device in
their car will be aware, is a global navigation system which uses satellites to track the location of GPSenabled devices (“GPS devices”). A GPS device receives transmissions from satellites to identify the
location of the device.

6. Provided that a signal is received and the device's battery is charged, the device captures its location
throughout the day and, at regular intervals, sends that information, via a mobile network, to the monitoring
centre operated by the Electronic Monitoring Service (“the EMS”), which delivers field and monitoring
services pursuant to a contract with the Ministry of Justice. The devices in this case were set to report their
location once a minute. The time and the location of the device are recorded, which constitutes the trail
data for the individual using the device. I will deal later with the retention and use of trail data.

7. As I have already mentioned, this case concerns fitted devices and non-fitted devices.

8. The EMS makes daily reports to the EM Hub, which is the Home Office team responsible for managing
the electronic monitoring process, of any non-compliance events in relation to a GPS device, including:

(1) any tampering with the device;

(2) a flat battery on a device; and

(3) an unsuccessful or failed verification of a non-fitted device.

_(2)(a)(i) Fitted GPS Devices_

9. A fitted device consists of a device which is attached to an individual's ankle by a strap. It is commonly
known as an ankle tag. Precautions are taken to avoid physical discomfort and inconvenience to the
individual wearing the fitted device: (a) the device is made from hypo-allergenic materials; (b) it has no
sharp edges, but rounded corners; (c) the strap is individually sized to fit the wearer; (d) the device is
waterproof; (e) the device is shockproof; and (f) EMS will investigate any difficulties in individual cases,
arranging visits if necessary and making such adjustments as may appear appropriate.

10. If the strap attaching the device to the individual's ankle is tampered with, the device will send an alert
t th it i t


-----

11. A fitted device has a battery which requires charging for at least two hours a day either from a mains
supply or by means of a portable charger.

_(2)(a)(ii) Non-Fitted GPS Devices_

12. A non-fitted device is a lightweight, handheld device which can be carried on the person. At random
times throughout the day the individual will receive requests from the device to verify their identity by
means of their fingerprint.

13. A non-fitted device has a battery which requires charging for at least an hour a day either from a mains
supply or by means of a portable charger.

14. Non-fitted devices have been in use since November 2022.

**_(2)(b) RF Devices_**

15. This case is not concerned with the devices (“RF devices”) which have been used for some time in the
context of bail granted by the criminal courts in order to enforce compliance with a curfew and which were
used by the defendant in relation to immigration bail until the beginning of 2021. RF devices, which may
also be GPS-enabled, are used in conjunction with a home monitoring unit (“HMU”) installed in the
individual's home. When in range of the HMU, the device sends a signal in radio frequency mode to the
HMU, which in turn sends a signal to the EMS's monitoring centre.

**_(2)(c) The Effect of EM Conditions on Individuals_**

16. 6,636 individuals were subject to EM conditions between 31 August 2021 and 7 September 2023. It is
not disputed that electronic monitoring constitutes an interference with an individual's right to privacy. The
constant recording of their movements is in itself such an interference and the knowledge that their
movements are being monitored and recorded can be a source of anxiety, especially for individuals who
have been subject to surveillance in the past, and particularly if that was combined with torture or
trafficking, and can deter individuals from moving about as freely as they might otherwise have done. The
claimants (or, in BNE's case, his mother) have given evidence as to the effect on them of having to comply
with an EM condition. Fitted devices can cause physical discomfort. There is also a potential stigma
attached to wearing such a device, which may also deter an individual from going to places where the
device might be seen. Concern about keeping a device charged is also a source of anxiety.

**(3) Schedule 10**

17. Paragraph 1 of Schedule 10 to the Immigration Act 2016 (“Schedule 10”) provides, inter alia, as
follows:

“(1)  The Secretary of State may grant a person bail if—

[(a)  the person is being detained under paragraph 16(1), (1A) or (2) of Schedule to the Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
_[1971 (detention of persons liable to examination or removal),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_

(b)  the person is being detained under paragraph 2(1), (2) or (3) of Schedule 3 to that Act (detention
pending deportation),

(c)  the person is being detained under section 62 of the Nationality, Immigration and Asylum Act 2002
(detention of persons liable to examination or removal), or

(d)  the person is being detained under section 36(1) of the UK Borders Act 2007 (detention pending
deportation).

(2)  The Secretary of State may grant a person bail if the person is liable to detention under a provision
mentioned in sub-paragraph (1).”

18. Sub-paragraph 1(3) of Schedule 10 provides that the First-tier Tribunal may grant bail to a person who
is being detained under any of the provisions listed in sub-paragraph 1(1).

19. Paragraph 2 of Schedule 10 provides, inter alia, as follows:


-----

“(1)  Subject to sub-paragraph (2), if immigration bail is granted to a person, it must be granted subject to
one or more of the following conditions—

(a)  a condition requiring the person to appear before the Secretary of State or the First-tier Tribunal at a
specified time and place;

(b)  a condition restricting the person's work, occupation or studies in the United Kingdom;

(c)  a condition about the person's residence;

(d)  a condition requiring the person to report to the Secretary of State or such other person as may be
specified;

(e)  an electronic monitoring condition (see paragraph 4);

(f)  such other conditions as the person granting the immigration bail thinks fit.

(2)  Sub-paragraph (3) applies in place of sub-paragraph (1) in relation to a person who is being detained
under a provision mentioned in paragraph 1(1)(b) or (d) or who is liable to detention under such a
provision.

(3)  If immigration bail is granted to such a person—

(a)  subject to sub-paragraphs (5) to (9), it must be granted subject to an electronic monitoring condition,

(b)  if, by virtue of sub-paragraph (5) or (7), it is not granted subject to an electronic monitoring condition, it
must be granted subject to one or more of the other conditions mentioned in sub-paragraph (1), and

(c)  if it is granted subject to an electronic monitoring condition, it may be granted subject to one or more of
those other conditions.”

“(5)  Sub-paragraph (3)(a) does not apply to a person who is granted immigration bail by the Secretary of
State if the Secretary of State considers that to impose an electronic monitoring condition on the person
would be—

(a)  impractical, or

(b)  contrary to the person's Convention rights.

(6)  Where sub-paragraph (5) applies, the Secretary of State must not grant immigration bail to the person
subject to an electronic monitoring condition.

(7)  Sub-paragraph (3)(a) does not apply to a person who is granted immigration bail by the First-tier
Tribunal if the Secretary of State informs the Tribunal that the Secretary of State considers that to impose
an electronic monitoring condition on the person would be—

(a)  impractical, or

(b)  contrary to the person's Convention rights.

(8)  Where sub-paragraph (7) applies, the First-tier Tribunal must not grant immigration bail to the person
subject to an electronic monitoring condition.

(9)  In considering for the purposes of this Schedule whether it would be impractical to impose an
electronic monitoring condition on a person, or would be impractical for a person to continue to be subject
to such a condition, the Secretary of State may in particular have regard to—

(a)  any obstacles to making arrangements of the kind mentioned in paragraph 4 in relation to the person,

(b)  the resources that are available for imposing electronic  monitoring conditions on persons to whom
sub-paragraph (2) applies and for managing the operation of such conditions in relation to such persons,

(c)  the need to give priority to the use of those resources in relation to particular categories of persons to
whom that sub-paragraph applies, and

(d) the matters listed in paragraph 3(2) as they apply to the person”


-----

20. It will be noted that paragraph 2 distinguishes between two categories of person who may be granted
immigration bail:

(1) Where immigration bail is granted to a person who is not being detained, and who is not liable to
detention, pending deportation, the Secretary of State or the First-tier Tribunal has a discretion under subparagraph 2(1)(e) whether to impose an EM condition unless the Secretary of State considers that to
impose an EM condition on the person would be: (a) impractical; or (b) contrary to the person's Convention
rights.

(2) Where immigration bail is granted to a person who is being detained, or who is liable to detention,
pending deportation, the Secretary of State or the First-tier Tribunal has a duty under sub-paragraph
2(3)(a) or 2(7) to impose an EM condition unless the Secretary of State considers that to impose an EM
condition on the person would be: (a) impractical; or (b) contrary to the person's Convention rights.

21. I will refer to these two categories as “non-deportation cases” and “deportation cases”. In either
category of case, if the Secretary of State considers that to impose an EM condition on the person would
be: (a) impractical; or (b) contrary to the person's Convention rights, then the Secretary of State or the
First-tier Tribunal has a duty under sub-paragraph 2(6) or 2(8) not to impose an EM condition.

22. Paragraph 3 of Schedule 10 addresses the question of how the Secretary of State and the First-tier
Tribunal should exercise their discretion, inter alia, to impose an EM condition when granting immigration
bail. Paragraph 3 provides, inter alia, as follows:

“(1)  The Secretary of State or the First-tier Tribunal must have regard to the matters listed in subparagraph (2) in determining—

(a)  whether to grant immigration bail to a person, and

(b)  the conditions to which a person's immigration bail is to be subject.

(2)  Those matters are—

(a)  the likelihood of the person failing to comply with a bail condition,

(b)  whether the person has been convicted of an offence (whether in or outside the United Kingdom or
before or after the coming into force of this paragraph),

(c)  the likelihood of a person committing an offence while on immigration bail,

(d)  the likelihood of the person's presence in the United Kingdom, while on immigration bail, causing a
danger to public health or being a threat to the maintenance of public order,

(e)  whether the person's detention is necessary in that person's interests or for the protection of any other
person,

(ea)  whether the person has failed without reasonable excuse to cooperate with any process—

(i)  for determining whether the person requires or should be granted leave to enter or remain in the United
Kingdom,

(ii)  for determining the period for which the person should be granted such leave and any conditions to
which it should be subject,

(iii)  for determining whether the person's leave to enter or remain in the United Kingdom should be varied,
curtailed, suspended or cancelled,

(iv)  for determining whether the person should be removed from the United Kingdom, or

(v)  for removing the person from the United Kingdom, and

(f)  such other matters as the Secretary of State or the First-tier Tribunal thinks relevant.”

“(5)  If the Secretary of State or the First-tier Tribunal decides to grant, or to refuse to grant, immigration
bail to a person, the Secretary of State or the Tribunal must give the person notice of the decision.”


-----

23. Paragraph 4 of Schedule 10 makes specific provision in relation to EM conditions. It provides as
follows:

“(1)  In this Schedule an “electronic monitoring condition” means a condition requiring the person on whom
it is imposed (“P”) to co-operate with such arrangements as the Secretary of State may specify for
detecting and recording by electronic means one or more of the following—

(a)  P's location at specified times, during specified periods of time or while the arrangements are in place;

(b)  P's presence in a location at specified times, during specified periods of time or while the
arrangements are in place;

(c)  P's absence from a location at specified times, during specified periods of time or while the
arrangements are in place.

(2)  The arrangements may in particular—

(a)  require P to wear a device;

(b)  require P to make specified use of a device;

(c)  require P to communicate in a specified manner and at specified times or during specified periods;

(d)  involve the exercise of functions by persons other than the Secretary of State or the First-tier Tribunal.

(3)  If the arrangements require P to wear, or make specified use of, a device they must—

(a)  prohibit P from causing or permitting damage to, or interference with the device, and

(b)  prohibit P from taking or permitting action that would or might prevent the effective operation of the
device.

(4)  In this paragraph “specified” means specified in the arrangements.

(5)  An electronic monitoring condition may not be imposed on a person unless the person is at least 18
years old.”

24. Paragraph 6 of Schedule 10 concerns the amendment, removal or addition of immigration bail
conditions. It provides as follows:

“(1)  Subject to this paragraph and to paragraphs 7 and 8, where a person is on immigration bail—

(a)  any of the conditions to which it is subject may be amended or removed, or

(b)  one or more new conditions of the kind mentioned in paragraph 2(1) or (4) may be imposed on the
person.

(2)  The power in sub-paragraph (1) is exercisable by the person who granted the immigration bail, subject
to sub-paragraphs (3) and (4).

(3)  The Secretary of State may exercise the power in sub-paragraph (1) in relation to a person to whom
immigration bail was granted by the First-tier Tribunal if the Tribunal so directs.

(4)  If the First-tier Tribunal gives a direction under sub-paragraph (3), the Tribunal may not exercise the
power in sub-paragraph (1) in relation to the person.

(5)  The First-tier Tribunal may not exercise the power in sub-paragraph (1)(a) so as to amend an
electronic monitoring condition.

(6)  If the Secretary of State or the First-tier Tribunal exercises, or refuses to exercise, the power in subparagraph (1), the Secretary of State or the Tribunal must give notice to the person who is on immigration
bail.

(7)  Where the First-tier Tribunal is required under sub-paragraph (6) to give notice to a person, it must
also give notice to the Secretary of State.”


-----

25. However, in relation to EM conditions, paragraph 6(1) of Schedule 10 is subject to paragraph 7, which
provides, inter alia, as follows:

“(1)  This paragraph applies to a person who—

(a)  is on immigration bail—

(i)  pursuant to a grant by the Secretary of State, or

(ii)  pursuant to a grant by the First-tier Tribunal in a case where the Tribunal has directed that the power
in paragraph 6(1) is exercisable by the Secretary of State, and

(b)  before the grant of immigration bail, was detained or liable to detention under a provision mentioned in
paragraph 1(1)(b) or (d).

(2)  Where the person is subject to an electronic monitoring condition, the Secretary of State—

(a)  must not exercise the power in paragraph 6(1) so as to remove the condition unless sub-paragraph (3)
applies, but

(b)  if that sub-paragraph applies, must exercise that power so as to remove the condition.

(3)  This sub-paragraph applies if the Secretary of State considers that—

(a)  it would be impractical for the person to continue to be subject to the condition, or

(b)  it would be contrary to that person's Convention rights for the person to continue to be subject to the
condition.”

26. The effect of sub-paragraph 7(1)(b) is that paragraph 7 only applies to deportation cases. Subparagraph 7(2) imposes two duties on the Secretary of State, namely:

(1) a duty to remove an EM condition if the Secretary of State considers that: (a) it would be impractical for
the person to continue to be subject to the EM condition; or (b) it would be contrary to that person's
Convention rights for the person to continue to be subject to the EM condition; and

(2) a duty not to remove the EM condition in any other circumstance.

27. Paragraph 8 of Schedule 10 makes equivalent provision for those cases in which the First-tier Tribunal
has granted immigration bail but has not directed that the power in sub-paragraph 6(1) is exercisable by
the Secretary of State.

28. Pursuant to The _[Immigration Act 2016 (Commencement No. 7 and Transitional Provisions)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
Regulations 2017, Schedule 10 came into force on 15 January 2018, except for sub-paragraphs 2(2), 2(3)
[and 2(5)-(10) and paragraphs 7, 8 and 25, which came into force on 31 August 2021: see The Immigration](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
_[Act 2016 (Commencement and Transitional Provisions No. 1) (England and Wales) Regulations 2021.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
Thus, the provisions of Schedule 10 which impose a duty on the Secretary of State to impose, or not to
impose, and to remove, or not to remove, an EM condition did not come into effect until 31 August 2021.

**(4) The Pilot Scheme**

29. On 15 June 2022 the defendant commenced a pilot scheme which extended the use of EM conditions
to asylum claimants who arrived in the United Kingdom by illegal and dangerous routes. According to
version 1.0 of guidance on “Immigration bail conditions: Electronic monitoring (EM) expansion pilot” (“the
Pilot Guidance”), which was published on 15 June 2022, the pilot scheme was intended to operate for 12
months and its purpose was to:

“test whether electronic monitoring (EM) is an effective means by which to improve and maintain regular
contact with asylum claimants who arrive in the UK via unnecessary and dangerous routes and more
effectively progress their claims toward conclusion.”

30. The pilot scheme was extended for a further 6 months, to 15 December 2023, when it ceased.
Version 2.0 of the Pilot Guidance, published on 23 June 2023, states that:


-----

“The data collected by the 12 month stage did not provide sufficient evidence to establish whether the use
of electronic monitoring is an effective tool for contact management or whether some cohorts are more
suited to this form of contact management.”

**(5) The Bail Guidance**

31. The defendant has published guidance for Home Office staff entitled Immigration Bail (“the Bail
Guidance”). I was shown version 16.0 of the Bail Guidance, published on 8 August 2023, pages 26 to 55
of which concern EM conditions. It was not suggested that there was any material difference between this
and earlier or later versions. This is subject to two exceptions, one of which was referred to in the hearing.
I will refer to that later. The second difference is that a section entitled “EM Devices” was inserted after
version 12.0, dated 28 June 2022, and by version 15.0, dated 27 January 2023, which stated that two
types of device, fitted and non-fitted, were available to the defendant. As I have said, non-fitted devices
were not used until November 2022.

32. There is no challenge in this case to the Bail Guidance itself. It follows that I need not address much
of the detail of the Bail Guidance. In relation to EM conditions, the Bail Guidance, inter alia:

(1) identifies factors which may be relevant to immigration bail decisions, including the risk factors and any
known vulnerabilities;

(2) sets out the procedures to be followed by Home Office staff, including the procedure for reviewing EM
conditions; and

(3) addresses the use of a “business support tool” to support decision-making.

**_(5)(a) Relevant Factors_**

33. On page 29, under the heading “Use of EM”, the Bail Guidance states:

“Electronic monitoring can apply to any person granted immigration bail if justified by the individual
circumstances of the case. Where the duty does not apply, EM is more likely to be appropriate as a
condition of bail where a person poses a high risk of harm to the public on the basis of criminality and/or in
cases concerning national security but is not limited to those cases. Where the duty does not apply EM is
less likely to be appropriate in any case where a person is granted immigration bail from a position of
liberty (for example, where the person has had a valid in-time, in-country application refused).”

34. On page 30 the Bail Guidance states:

“Individual business areas have additional criteria to assist in identifying suitable cases and these are
outlined in further detail below:

- whether there is strong independent medical evidence to suggest that an EM condition would cause
serious harm to a person's mental or physical health

- whether a claim of torture been accepted by the Home Office or a Court

- whether there has been a positive conclusive grounds decision in respect of a claim to be a victim of
**_modern slavery_**

- …

Meeting one or more criteria on the above list should prompt the decision maker to consider whether EM is
an appropriate course of action but does not in itself prohibit imposing such a condition. In many cases,
even where there is some evidence in favour of removing EM, on balance it may still be appropriate to
maintain EM due to the other factors present in the case. Where one or more of the above conditions apply
there must be a clear statement why EM is still considered suitable, and this must be agreed by at least an
Assistant Director.”

35. On pages 31 to 34 of the Bail Guidance there is a table, which is introduced by the following text,
under the heading “Vulnerability considerations”:


-----

“The table below sets out some considerations that may be required to establish whether there is a
disproportionate breach of a person's rights under Article 8 of ECHR either by the imposition of EM or the
type of device to be imposed. This must not be used at a stand-alone guide, and its use must be in
conjunction with the detailed guidance in Use of EM above. Neither the conditions nor the considerations
listed are exhaustive.”

36. The first rows in the table state as follows:

Condition/issue Evidence required Consideration required

EM condition would cause serious Medical evidence unless this is a long - expected impact - will there be physical
harm to the person's mental or lasting condition that the Home Office suffering caused by wearing the device

already holds evidence of and which is once the wearer is acclimatised to
unlikely to have improved wearing the device

                                        - does mitigation/
alternate remedy exist for example, can a
fitted device be worn on different leg or
(in extreme conditions) on the wrist

                                     - can a non-fitted device be employed

                                     - does the person have a medical
condition or disability which means that
they are unable to personally comply with
their bail conditions, for example, limited
mobility means they would need
assistance to charge their device

People whose claim to have been Medical evidence suggests that the use - what was the nature of torture in the
tortured has been accepted by the of EM would significantly impact on initial claim
Home Office or First-tier Tribunal mental or physical health - could wearing a fitted device replicate

the conditions of torture, for example,
manacled to a wall

                                         - is there evidence that the application of
EM irrespective of device type will have a
detrimental impact on those diagnosed
with PTSD

                                         - were there physical injuries as a result
of torture which have not healed which
would mean that a fitted device is
unsuitable

                                     - can a non-fitted device be employed

People whose claim to be a victim of Medical evidence suggests that the use - is there evidence that the application of
**_modern slavery has received a_** of EM would significantly impact on EM will have a detrimental impact on
positive conclusive grounds decision mental or physical health those diagnosed with PTSD irrespective

of device type

                                         - were there physical injuries as a result
of torture which have not healed which
would mean that a fitted device is
unsuitable

                                     - can a non-fitted device be employed

**_(5)(b) Procedures_**

37. The Bail Guidance states on page 36, under the heading “Representations”, as follows:

“Prior to a final decision to apply electronic monitoring as a condition of bail, with or without supplementary
conditions, representations must be invited from the person. The below sets out the representations
process, forms and timescales for different Scenarios.”

38. Then the Bail Guidance states on page 37 that:

|Condition/issue|Evidence required|Consideration required|
|---|---|---|
|EM condition would cause serious harm to the person's mental or physical health|Medical evidence unless this is a long lasting condition that the Home Office already holds evidence of and which is unlikely to have improved|• expected impact - will there be physical suffering caused by wearing the device once the wearer is acclimatised to wearing the device • does mitigation/ alternate remedy exist for example, can a fitted device be worn on different leg or (in extreme conditions) on the wrist • can a non-fitted device be employed • does the person have a medical condition or disability which means that they are unable to personally comply with their bail conditions, for example, limited mobility means they would need assistance to charge their device|
|People whose claim to have been tortured has been accepted by the Home Office or First-tier Tribunal|Medical evidence suggests that the use of EM would significantly impact on mental or physical health|• what was the nature of torture in the initial claim • could wearing a fitted device replicate the conditions of torture, for example, manacled to a wall • is there evidence that the application of EM irrespective of device type will have a detrimental impact on those diagnosed with PTSD • were there physical injuries as a result of torture which have not healed which would mean that a fitted device is unsuitable • can a non-fitted device be employed|
|People whose claim to be a victim of modern slavery has received a positive conclusive grounds decision|Medical evidence suggests that the use of EM would significantly impact on mental or physical health|• is there evidence that the application of EM will have a detrimental impact on those diagnosed with PTSD irrespective of device type • were there physical injuries as a result of torture which have not healed which would mean that a fitted device is unsuitable • can a non-fitted device be employed|


-----

“Representations should be invited using the following forms:

- BAIL 211 where a provisional decision has been made to grant bail to a detained person and apply a
particular GPS EM condition/supplementary to include a particular EM condition/supplementary conditions

…”

39. Bail 211 is a form of letter used in deportation cases. An amended version, Bail 211 B, is used in nondeportation cases. It will be necessary to consider in due course the evidence as to the nature, both
generally and in individual cases, of:

(1) the provisional decision taken before a letter in form Bail 211 or 211 B is sent; and

(2) any subsequent decision to grant immigration bail with an EM condition.

40. Bail 201 is the form used to notify an individual of the grant or variation of immigration bail. It gives
notice of the conditions imposed, including any EM condition, but it does not contain a space for setting out
the reasons for imposing those conditions.

41. Under the heading “Considering representations”, the Bail Guidance states on page 38 as follows:

“Any representations received within the response timeframe must be considered when making a final
decision regarding the imposition of EM or a supplementary condition. Decisions should be made based
on the information provided in addition to information already known about the person with the response
provided on a Bail 215. In all cases regard must be had to the matters set out in Exercising the power to
_grant immigration bail, and the guidance set out in Use of EM._

Representations must be considered and responded to in a timely manner prioritising cases where the
person is already subject to EM and there is an indication that there is an immediate physical danger to the
person followed by those whose release is imminent. Where representations were received within the
stated response timeframe and the person is already on immigration bail the decision should be notified to
the individual within 28 days of receipt of the representations.”

42. This section of the Bail Guidance was first introduced in version 13.0, which was published on 30
August 2023. However, earlier versions identified form Bail 215 as the “EM representations response
letter”. Bail 215 is a form of letter which includes space for reasons for rejecting representations against an
EM condition.

**_(5)(c) Reviews of EM Conditions_**

43. On page 45, under the heading “EM and linked Supplementary Conditions: review”, the Bail Guidance
states, inter alia, as follows:

“The use of EM and any linked supplementary conditions of curfews, inclusion zones or exclusion zones
require regular monitoring to ensure that they remain proportionate.”

The use of EM and all supplementary conditions to EM must be reviewed by a decision maker in any case
allocated to them:

- on a quarterly basis

- when they receive any representations on the matter, including requests to vary the condition, from the
individual or a person acting on their behalf

- when considering the response to a breach of immigration bail

- when a request is made by another decision maker

The purpose of the review is to ensure that the individual remains suitable for both EM and any
supplementary condition or conditions and any EM or conditions continue to be necessary and
proportionate in light of the facts at the date the review is undertaken. The review will also provide an
opportunity to consider whether the device type remains the most appropriate. In all cases regard must be
had to the matters set out in Exercising the power to grant immigration bail, and the guidance set out in


-----

Use of EM. It will be necessary to consider movement between devices in both directions such as from
fitted to non-fitted as well as non-fitted to fitted.

Factors to be taken into consideration will include, but are not limited to:

- the overall time spent on EM

- the time on the particular device type

- the risk of absconding

- the risk of harm posed to the public

- the risk of re-offending

- the expected time until removal

- any vulnerabilities

- compliance with immigration bail”

44. It was accepted on behalf of the Secretary of State that the statement in this passage that the use of
EM must be reviewed “on a quarterly basis” meant that an EM condition imposed on an individual must be
reviewed within 3 months of its imposition (which appears to have been understood as the date on which
the EM condition was implemented by fitting the fitted device to the individual's ankle) and, if it remained in
force, within 3 months of any review.

45. Reviews are conducted by administrative officers (“AOs”), subject to authorisation of the outcome by a
more senior officer. The Bail Guidance states on page 47 that:

“The outcome of the review of EM and of any supplementary condition or conditions, including the
consideration undertaken by the decision maker and any escalation to HEO or higher, should be recorded
in a comprehensive file minute and on Atlas.”

46. The parties proceeded on the basis that a review was not complete until the outcome had been
authorised. The standard form (“the review form”) used to record the outcome of reviews is designed to
encourage the person carrying out the review to set out the reasons for their decision. It contains sections
on risk of harm, risk of offending, risk of absconding and the “continued necessity of EM”. The final section
is headed “CONSIDERATION – including any current medical or vulnerability issues identified.”

47. There were many cases, including these four cases, in which quarterly reviews were not carried out in
time. In July 2022 the Independent Chief Inspector of Borders and Immigration (“the Chief Inspector”)
published a report on “An inspection of the global positioning system (GPS) electronic monitoring of foreign
national offenders March - April 2022”, in paragraph 5.78 of which he wrote as follows:

“The main limiting factor affecting Hub staff performance was the level of staff resource available to deal
with the volume of case work. Managers had ensured that the tagging of individuals on release was
prioritised in line with the Secretary of State's duty and that legal representations and challenges, preapplication protocol letters (PAPS) and judicial reviews (JRs) were responded to within specified
timescales. However, this resulted in a backlog in “other areas of case work.”

48. Then in paragraph 5.80 he wrote:

“… EM reviews of those already fitted with a tag, which should be undertaken at 3-monthly interviews,
were only being conducted when representations were received in respect of an individual.”

49. In paragraph 5.81 he said that, as at 28 February 2022, there was a backlog of 818 reviews out of
1,622 active EM cases. According to the defendant's evidence, there were over 1,000 overdue reviews by
November 2022 and 1,912 as at 6 February 2023. Starting in February 2023, action was taken to reduce
this backlog. There were 456 overdue reviews as at 11 May 2023 and 348 as at 22 May 2023, although
this figures had increased again to 970 as at 10 October 2023. The evidence of Adrian Duffy, deputy
director of the Home Office's Satellite Tracking Services unit, was that there were three reasons for the
build up of this backlog:


-----

(1) a shortage of staff, particularly AOs;

(2) a delay in introducing an IT system which was intended to assist EM Hub staff; and

(3) a mistake in the Bail Guidance as to the level of officer required to authorise the outcome of a review,
with the result that reviews which resulted in a decision to maintain the EM condition were being referred
for authorisation to a higher executive officer (“HEO”) rather than an executive officer (“EO”).

50. Mr Duffy also said in his statement dated 20 October 2023 that it was expected that the backlog would
be eliminated by the end of the financial year 2023/24, i.e. by the end of March 2024.

**_(5)(d) The Business Support Tool_**

51. No issue arose in this case as to the design or operation of the business support tool. Indeed, I was
not directed to any evidence that it was used in the case of any of the claimants.

**(6) Trail Data Retention and Use**

52. The defendant's policy in relation to the retention of trail data is set out in two data protection impact
assessments. Trail data is recorded on EMS's servers. It is not monitored “live”. The defendant's policy is
for the data to be retained for 6 years after it has ceased to be collected and to be provided by EMS to
Home Office staff:

(1) in the event of an actual or alleged breach of the subject's bail conditions;

(2) if contact with the individual is lost;

(3) where a request is made for access to specific data by an external law enforcement agency;

(4) in the event that the subject makes representations under Article 8 or further submissions; or

(5) in response to a subject access request or a legal challenge by the subject.

53. The defendant will consider requests for the deletion of trail data. In particular, the defendant will
delete the trail data in any case where he accepts that an EM condition was imposed or maintained
erroneously. It will be seen that the defendant has deleted all of ADL's trail data and some of Mr Dos Reis'
trail data. Moreover, the defendant accepted that, if I hold that any of the EM conditions in the present
case was unlawful for any period of time, the defendant will delete the relevant trail data for that period.

**(7) The Claimants**

54. I will set out the circumstances of each claimant's case, but it may be useful to flag up at the outset
some of the principal similarities and differences between the individual claimants' cases. As I have said,
each of the claimants was granted immigration bail subject to an EM condition:

(1) ADL's case was a non-deportation case. The other claimants' cases were all deportation cases, to
which the duties imposed by paragraph 2 of Schedule 10 applied.

(2) Bail was granted to Mr Dos Reis by the First-tier Tribunal. It was the defendant who granted bail to the
other three claimants.

(3) In ADL's case, the defendant did not consider the representations made on his behalf before granting
immigration bail subject to an EM condition.

(4) All of the claimants were subject to an EM condition which required them to wear a fitted device,
although PER has since 26 October 2023 been required to use a non-fitted device instead.

(5) The defendant was late in conducting at least one quarterly review of the EM condition in Mr Dos Reis',
BNE's and PER's cases.

(6) Mr Dos Reis and ADL are no longer on immigration bail. BNE and PER remain on immigration bail.
PER is the only claimant who is still on immigration bail with an EM condition.


-----

(7) The defendant has caused the deletion of all of ADL's trail data and some of Mr Dos Reis' trail data
(i.e. for the period from 1 October 2022). The remainder of Mr Dos Reis' trail data and the whole of BNE's
and PER's trail data is currently being retained.

**_(7)(a) Mr Dos Reis_**

55. Mr Dos Reis is a Portuguese national. He entered the United Kingdom as a baby in 1998. He is now
26. He has a number of criminal convictions and a caution, as follows:

(1) a caution on 2 October 2016 for attempted theft of a vehicle;

(2) a conviction on 19 October 2018 for being concerned in the supply of a class A drug, for which he
received a sentence of 3 years' imprisonment;

(3) a conviction in 2018 for possession of a bladed article and possession of cocaine, for which he
received a sentence of 4 months' imprisonment, suspended for 12 months; and

(4) a conviction on 12 July 2021 for possession of a bladed article and possession of a class B drug, for
which he was sentenced to 5 months and 7 days' imprisonment. This offence also resulted in Mr Dos Reis
being recalled to prison to serve the remainder of the 3 year sentence imposed in 2018.

56. The defendant made a deportation order on 12 May 2020. Mr Dos Reis was detained, but the Firsttier Tribunal granted him immigration bail with an EM condition on 4 March 2022, directing that the power
in sub-paragraph 6(1) of Schedule 10 was exercisable by the Secretary of State. A fitted device was fitted
on 7 March 2022. On 28 March 2022 the First-tier Tribunal allowed Mr Dos Reis' appeal against the
deportation order. The defendant applied to the First-tier Tribunal for permission to appeal. On 12 April
2022 the First-tier Tribunal refused permission to appeal. The defendant renewed the application for
permission to appeal to the Upper Tribunal.

57. The defendant should have reviewed the EM condition by 7 June 2022, but did not do so. On 15
August 2022 Mr Dos Reis' solicitors, Duncan Lewis, wrote to the defendant, expressing concern that the
EM condition might be in breach of his Convention rights and requesting copies of various documents.
The defendant did not consider that this letter amounted to representations. Nevertheless, the defendant
reviewed the EM condition, but decided not to remove it, for the reasons set out in a review form which
indicates that the review was both conducted and approved on 18 August 2022. The defendant did not
notify Mr Dos Reis of this decision or the reasons for it. In particular, the defendant did not refer to the
decision or the reasons for it in his letter of 23 August 2022 replying to Duncan Lewis' letter of 15 August
2022.

58. Meanwhile, the Upper Tribunal had refused the defendant permission to appeal against the First-tier
tribunal's decision. The Upper Tribunal's decision is dated 27 July 2022, but it was not communicated to
the parties until 12 September 2022. On 14 September 2022 Duncan Lewis wrote to the defendant
alleging that the EM condition was unlawful and giving notice of a potential claim for judicial review. Also
on 14 September 2022 the defendant decided not to seek any further permission to appeal. In his reply to
Duncan Lewis of 16 September 2022 the defendant maintained the position set out in his letter of 23
August 2022. On 29 September 2022 the defendant revoked the deportation order. However, the
defendant did not notify Mr Dos Reis of this.

59. On 19 October 2022 Duncan Lewis sent a letter before claim, alleging, inter alia, that the legal basis
for imposing an EM condition had ceased to apply and requesting the deletion of all of Mr Dos Reis' trail
data. A review form dated 25 October 2022 records both the defendant's decision that the EM condition
should be ceased immediately and the reasons for that decision.  On 26 October 2022 the defendant
responded to the letter before claim, informing Duncan Lewis of the decision that the EM condition be
ceased immediately and stating that EMS had been asked to visit Mr Dos Reis' address on 27 October
2022 to remove the fitted device, but declining to delete any of the trail data. It is not clear what, if
anything, happened on 27 October 2022, but on 28 October 2022 EMS informed Mr Dos Reis that he could
remove the fitted device himself.


-----

60. Following a further letter from Duncan Lewis dated 9 November 2022, the defendant wrote to Duncan
Lewis on 14 November 2022, maintaining his earlier position.

61. Mr Dos Reis has since been granted settled status as an EU national.

62. On 9 November 2022 Duncan Lewis wrote to the defendant to request the deletion of his trail data.
The defendant has refused to delete the trail data, except for the period from 1 to 27 October 2022, when it
is accepted that the EM condition was unlawful.

**_(7)(b) BNE_**

63. BNE is a Jamaican national. He was born in 1987. He entered the United Kingdom in 2000, when he
was 13. He was granted indefinite leave to remain in the United Kingdom in 2007. He is now 36.

64. BNE had learning difficulties and was assessed in 2005 as having an IQ in the range from 52 to 60.

65. BNE has the following convictions:

(1) In 2005 he was convicted of attempted robbery, for which he received a community order.

(2) In 2014 he was convicted of possession of a firearm with intent to endanger life, for which he was
sentenced to 7 years' imprisonment.

66. The defendant made a deportation order on 23 November 2016. BNE's appeal against the deportation
order was allowed by the First-tier Tribunal on 9 November 2017, but on 5 April 2018 the Upper Tribunal
allowed the defendant's appeal against the First-tier Tribunal's decision.

67. BNE was recalled to prison on 7 February 2019. On his release from prison on 26 September 2019 he
was detained pending deportation. He was granted immigration bail by the First-tier Tribunal on 27
November 2019.

68. BNE was detained again on 3 August 2021 with a view to his deportation. He was granted
immigration bail by the First-tier Tribunal on 31 August 2021, with conditions, which he complied with, to
reside at his mother's address and to report weekly to an immigration official.

69. On 4 May 2022 BNE was detained pending deportation. On 14 May 2022 a consultant forensic
psychologist, Lisa Davies, prepared a report on BNE, which was provided to the defendant on 16 May
2022. Ms Davies said that BNE was experiencing anxiety and depression, with associated suicidal
ideations, and that symptoms of PTSD were present, but she did not specifically address the potential
impact on BNE of an EM condition. BNE was assessed on 11 May 2022 and on 16 May 2022 it was
decided that there was level 3 evidence that BNE was an adult at risk for the purposes of the defendant's
guidance on “Adults at risk in immigration detention” (“the AAR Guidance”). At this stage BNE was
assessed as presenting a high risk of absconding, re-offending and causing harm.

70. BNE contended that he had been trafficked and on 18 May 2022 the Immigration Enforcement
Competent Authority (“the IECA”) decided that there were reasonable grounds to conclude that BNE was a
victim of modern slavery.

71. On 20 May 2022 the defendant sent a letter in form Bail 211 to BNE. On 23 May 2022 BNE's
solicitors, Duncan Lewis, sent a letter to the defendant, in which they said (emphasis in original):

“We oppose the use of electronic tagging for the reasons set out below, however, this please note should
**not be seen as an obstacle to our client's release or a cause of delay.”**

72. Duncan Lewis's representations referred, inter alia, to the assessment of BNE under the AAR
Guidance and to the IECA's decision and also to the reasons why it was contended that his risk of
absconding and re-offending was low, namely his compliance with his bail conditions between 31 August
2021 and 4 May 2022, his dependence on his mother, the fact that he would be living with and looking after
his 8-month old son and his contention that his offence was committed as a result of exploitation and
coercion. As to the effects of an EM condition on BNE, the letter merely stated that electronic tagging was
likely to be triggering and reminiscent of past experiences of having his movement controlled by others.


-----

73. The defendant replied on 24 May 2022, saying that:

“[BNE's] release has been granted by the Director with Electronic Monitoring as part of the condition of
release.  [BNE's] Adult at Risk has been reviewed and decision has been made to proceed with Electronic
Monitoring before he is released from detention. [BNE's] Electronic Monitoring will be subjected to review
should substantial evidence be submitted stating why Electronic Monitoring is detrimental to his physical
and/or mental health.”

74. On 26 May 2022 the defendant granted BNE immigration bail on condition that he: (a) reside at his
mother's address; (b) report weekly to an immigration officer; and (c) comply with an EM condition. The
defendant should have reviewed the EM condition by 26 August 2022, but did not do so.

75. On 25 August 2022, Ms Davies prepared an addendum report. In paragraph 8.0.16 of her addendum
report, Ms Davies said:

“Assessment indicates that there is the potential for a worsening of [BNE's] mental health functioning,
should he remain subject to tag. He describes feeling stressed and depressed at the thought of being
subject to monitoring and surveillance, and he feels ashamed of having to wear a tag during hot weather
when it is visible to others. He has a diagnosis of depression and describes frequent thoughts of suicide.
He fears being targeted by gangs, and he feels like he is being restricted to his house and has lost any
sense of freedom, since being released. Tagging can result in a feeling of being coerced and controlled by
monitoring and surveillance, and this has clear parallels with [BNE's] experience as a victim of trafficking. It
is highly likely that further deterioration in his mental health would result from being subject to constant
surveillance and in my opinion would likely impede his recovery as a victim of trafficking.”

76. Ms Davies also expressed the opinion that it was highly unlikely that BNE had the ability to comply
with the EM condition in the absence of his mother's support and direction.

77. On 5 September 2022 Duncan Lewis wrote to the defendant, attaching a copy of the addendum report
and expressing their concern that the EM condition may be in breach of BNE's Convention rights. On 14
September 2022 Duncan Lewis wrote to the defendant alleging that the EM condition was unlawful and
giving notice of a potential claim for judicial review. The defendant replied to these letters on 23
September 2022, saying, inter alia, that the letter of 5 September 2022 had been forwarded to the Foreign
National Offenders Return Command (“FNORC”) to consider and respond to BNE's representations.
However, the FNORC did not respond to the letter of 5 September 2022.

78. On 24 October 2022 Duncan Lewis sent a letter before claim, asking, inter alia, that the defendant
delete all of BNE's trail data. A review form records the defendant's decision, following a review conducted
on 4 November 2022 and approved on 7 November 2022, that BNE's EM condition should cease. The
defendant replied to Duncan Lewis on 7 November 2022 informing them of the decision to cease BNE's
EM condition, but declining to delete his trail data.

79. On 11 November 2022 Dr Nuwan Galapatthie, a consultant forensic psychiatrist, prepared a report in
which he expressed the opinion that BNE's depression and PTSD had deteriorated from moderate to
severe since Ms Davies prepared her addendum report and that it was likely that this deterioration was
caused by the EM condition.

80. Most recently, on 27 September 2023 the IECA decided that BNE was a victim of modern slavery.

**_(7)(c) ADL_**

81. ADL is a national of Sudan and is now 25. He says that he was detained in Khartoum by the security
forces for 4 months in early 2020 and tortured while in detention. He left Sudan in August 2020. He went
to Libya, where he was trafficked into forced labour. He made his way to Italy and then France. He arrived
in the United Kingdom on 14 May 2022 by small boat from France and was detained on the same day. He
claimed asylum and claimed that he was a victim of trafficking.

82. On 18 May 2022 the defendant served on ADL a notice of intent to remove him to France, Italy or
Rwanda.


-----

83. On 1 June 2022 ADL was assessed pursuant to rule 35(3) of the Detention Centre Rules 2001 and the
subsequent report concluded that he may be a victim of torture. On 9 June 2022 the defendant concluded
that the medical evidence met Level 2 of the defendant's AAR Guidance. On 29 June 2022 the IECA
decided that there were reasonable grounds to conclude that ADL was a victim of trafficking.

84. A form dated 7 July 2022 records the defendant's decision to grant immigration bail to ADL, but states
that his case was to be referred to the EM Hub for tagging consideration.

85. The defendant gave a letter dated 8 July 2022 to ADL in form Bail 211 B, which stated that it has been
provisionally decided that ADL should be released from detention on immigration bail subject to an EM
condition and invited representations from ADL.

86. On 13 July 2022 ADL's solicitors, Duncan Lewis, sent a letter containing representations to the
defendant. This letter was sent by email to the email address provided by the defendant in his letter of 8
July 2022, but that was an incorrect email address and the letter was not considered by the relevant
decision-maker. The defendant granted immigration bail to ADL on 14 July 2022, subject, inter alia, to an
EM condition and a condition requiring him to report to an immigration official twice a month, starting on 20
July 2022. He did not report on 20 July 2022. As Duncan Lewis explained an email sent to the defendant
on 22 July 2022, this was because ADL could not read the notice of bail, which was in English, and no
copy was sent to Duncan Lewis.

87. Dr Galappathie prepared a report on ADL on 25 July 2022 in which he expressed, inter alia, the
following opinion:

“In my opinion, his GPS tag has exacerbated his depression, anxiety and PTSD. Whilst the acute
symptoms of his condition appear to have reduced such as a reduction in suicidal thoughts and
nightmares, it is notable that he continues to suffer from other symptoms of depression, anxiety and PTSD
following his release to the community and these symptoms appear to have been exacerbated by his
electronic monitoring requirement and the need for a GPS tag. [ADL] outlined experiencing high levels of
distress as a result of electronic monitoring and having to wear a GPS tag. [ADL] feels that the tag has
made him feel like a criminal. He has found the tag has reminded him of his past experience of trauma. In
my opinion having a GPS tag attached his leg has reminded him of when he was detained and tortured
within Sudan and of being detained, controlled and forced into unpaid labour in Libya. He has also found
the tag to feel uncomfortable and has become distressed when the tag beeps. He is also fearful that the
tag will run out of charge and he will incur battery breaches and potentially risk being redetained or
removed to Rwanda due to failures with the GPS tag.”

88. In terms of the scale used in the Judicial College Guidelines, Dr Galappathie expressed the opinion
that ADL's depression, anxiety and PTSD had increased as a result of the EM condition from the lower
point of “Moderately severe” to the higher point of “Moderately severe”,

89. Dr Galappathie said that ADL was not currently receiving treatment for his mental health conditions.
He expressed the opinion that ADL required, and would benefit from, treatment in the form of medication
and therapy, but that he would need to have stable accommodation and not fear being removed to Rwanda
in order to meaningfully engage in the therapy that he required and that the removal of the EM condition
would allow him to take part in therapy. He also said that whilst on immigration bail in the UK ADL was
likely to have a good prognosis, provided that he was no longer subject to electronic monitoring, had stable
accommodation and was able to engage in the treatment he required.

90. Duncan Lewis sent a copy of this report to the defendant on 5 August 2022, together with a letter
making representations that the imposition or maintenance of the EM condition was contrary to ADL's
Convention rights. The defendant responded to these representations on 12 August 2022:

(1) The defendant stated that he had decided to retain the EM condition.

(2) In response to Dr Galappathie's opinion, the defendant said:

“However, Dr Galappathie's medical evidence does also make reference to an improvement in some of
your client's symptoms since his release from detention Dr Galappathie states that “the acute symptoms of


-----

his condition appear to have reduced such as a reduction in suicidal thoughts and nightmares”. Dr
Galappathie further makes clear that your client has not engaged in any treatment for his pre-existing
conditions, which more than any other factor would improve his condition. Your client makes reference to
not feeling “free” to do so, but the application of EM does not prevent your client seeking medical treatment
or support for his condition.”

(3) The defendant also said as follows:

“Nevertheless, your client's circumstances and representations have been taken into account and
considered in conjunction with the objectives of the pilot and the risk of absconding or failing to maintain
contact with the Home Office. Your client has shown considerable determination to travel to the UK
clandestinely. He has been informed that his asylum claim may be considered by a safe third country
rather than the UK. His adherence to the reporting restrictions which constitute part of his bail conditions is
inconsistent. While he reported in conjunction with his bail conditions on 3 August 2022, he failed to attend
his first reporting event on 20 July 2022. He did not provide an explanation for doing so”

(4) This last sentence was incorrect. An explanation for ADL's failure to report on 20 July 2022 was
provided in Duncan Lewis' email of 22 July 2022.

91. On 30 September 2022 Duncan Lewis sent a letter before claim, asking, inter alia, that the defendant
delete all of ADL's trail data. On 5 October 2022 Duncan Lewis sent to the defendant a copy of a second
report from Dr Galappathie, in which he expressed the opinion that ADL's depression, anxiety and PTSD
had worsened since 25 July 2022 and had done so as a result of the EM condition. Dr Galappathie also
said that:

“Whilst he had thoughts about self-harm and suicide when I previously assessed him, his thoughts about
self-harm and suicide have increased during the last week which appears secondary in his mental health
caused by his continued distress due to having a GPS tag.”

92. The defendant's substantive response to the letter before claim was dated 11 October 2022 and said
that:

“In light of the issues with providing your client an opportunity to make representations, we will vary your
client's bail conditions such as to remove the EM condition.”

93. I was not shown a copy of the notice of the amended bail conditions. It appears that, whenever the
EM condition was formally removed, the device remained fitted until 31 October 2022, when EMS told ADL
that he could remove the device himself. However, it also appears that EMS officers had attempted to
remove the device before that, attending ADL's address on 28 October 2022. On 4 November 2022 the
defendant wrote to Duncan Lewis and said that ADL could remove the device itself.

94. Dr Galappathie provided a further report dated 11 November 2022 in which he confirmed his earlier
findings.

95. On 12 May 2023 the defendant confirmed that ADL's trail data had been deleted. On 29 September
2023 the defendant confirmed that this decision had been taken because the EM condition had been
imposed without consideration of ADL's representations.

96. On 18 July 2023 ADL was granted humanitarian protection with leave to remain in the United Kingdom
for 5 years.

**_(7)(d) PER_**

97. PER is a Nigerian national. She was subjected to female genital mutilation as a child. She first
entered the United Kingdom in the 1980s, but returned to Nigeria after about 3 years.  She next entered
the United Kingdom after the birth of her daughter at the end of 1995. On 4 August 1999 she obtained a
United Kingdom passport in a false name. It was cancelled on 13 May 2011.

98. PER is now 59. She has four children, two of whom are British citizens. She has type-2 diabetes,
hypertension/high blood pressure, fibroids, eczema, depression and anxiety disorder.


-----

99. PER has a number of criminal convictions for fraud and offences for dishonesty, including:

(1) A conviction on 30 September 2007 or 2012 (different dates are given in different documents) for
possession of false identity documents, for which she received a sentence of 9 months' imprisonment,
suspended for 12 months.

(2) Convictions on 29 January 2014 for 13 offences of dishonesty, for which she was sentenced to a total
of 4 years' imprisonment.

100. The defendant made a deportation order on 6 October 2015. PER was detained on 22 June 2016.
The First-tier Tribunal granted immigration bail, subject to a reporting condition, on 18 July 2016. PER had
made asylum and human rights claims, which were refused in 2017. Her appeals were dismissed in 2019.
She made a further application for leave to remain and a human rights claim in 2022. These were refused
on 13 June 2022.

101. PER was detained again on 13 June 2022, when she reported to an immigration officer in compliance
with the condition of her immigration bail. On 23 June 2022 a report under rule 35(3) of the Detention
Centre Rules 2001 confirmed that PER had undergone female genital mutilation and had scars on her arm
and wrist.

102. On 28 June 2022 the IECA decided that there were reasonable grounds to conclude that PER was a
victim of trafficking as a result of her treatment in a factory in London between 2007 and 2012 and/or an
attempted forced marriage in Nigeria.

103. On 12 July 2022 the defendant wrote to PER, care of Duncan Lewis, stating that it had been
provisionally decided that PER should be released on immigration bail subject to an EM condition and
inviting representations. The letter referred to the coming into force of sub-paragraphs 2(2), 2(3) and 2(5)
to (10) of Schedule 10 and stated:

“This means that under law the Secretary of State must introduce electronic monitoring to maintain contact
with individuals granted immigration bail who are subject to a Deportation Order or deportation
proceedings, unless either it is not practical to do so, or it would be in breach of your rights (“convention
rights”) under the European Convention of Human Rights (ECHR).”

104. On 15 July 2022 PER's solicitors, Duncan Lewis, wrote to the defendant to set out representations
why an EM condition should not be imposed. Duncan Lewis stated as follows in paragraph 3 of their letter
(emphasis in original):

“. We seek to highlight at the outset that our client requires urgent release from immigration detention,
**as the ongoing decision to maintain detention is unlawful due to her extensive vulnerabilities as set**
**out in our Letter before Action dated 7 July and 14 July 2022. Should the SSHD refuse to withdraw**
**the EM condition, our client is willing to accept this as a temporary condition of her release.”**

105. Later on 15 July 2022 an officer at PER's Immigration Removal Centre made the following note of a
conversation with PER:

“I explained because her Legal reps had objected to Electronic monitoring, this needed considering, and
there was no timescale as to when this would be decided. [PER] said her solicitor had contacted her this
morning, but she was not aware that her solicitor had raised objections to her being electronically
monitored. She rang her solicitors to ask that they remove the objection as she just wants to be released,
and is ok with having a device fitted. …”

106. Later on 15 July 2022 Duncan Lewis sent an email to the defendant in which they said as follows
(emphasis in original):

**“Our client instructs that she wishes for these representations regarding electronic monitoring to**
**be withdrawn, provided she is released from detention without further delay.**


-----

**While we maintain the grounds set out in our presentations, we submit that our client's ongoing**
**detention is having a more detrimental impact on her than release with an EM condition would**
**have.”**

107. Duncan Lewis sent a further email on 18 July 2022 in which they said as follows (emphasis in
original):

“We write to request an urgent update regarding our client's bail matter. We confirmed on Friday, 15 July
2022 that our client seeks to withdraw her representations regarding electronic monitoring so that she may
be released on SSHD bail without further delay.

It is now 18 July 2022 and our client remains in detention although she has accepted electronic monitoring
conditions and has an approved address for release.

…

**Please ensure she is released on bail immediately or we will have no option but to issue an**
**application for judicial review without further notice.”**

108. PER was released on 19 July 2022 on immigration bail subject to an EM condition, although I have
not seen the notice of bail, nor any other record of the decision to impose an EM condition or the reasons
for it.

109. The representations of 15 July 2022 were re-submitted on 27 July and 9 August 2022.

110. On 22 August 2022 Dr Galappathie prepared a report in which he concluded that PER suffered from
recurrent depressive disorder (with the current episode being severe, but without psychotic symptoms),
generalised anxiety disorder and PTSD. He also said that:

“In my opinion, the GPS tag has caused an exacerbation of pre-existing psychiatric illness by way of
depression, anxiety and PTSD such that she now suffers from severe depression, anxiety and PTSD. This
would be indicated by her account of worsening depression, anxiety and PTSD symptoms. In addition, it is
likely that having to wear GPS tag will have exacerbated her mental health symptoms due to a number of
different factors.”

111. On 15 September 2022 Duncan Lewis wrote to the defendant, stating that they were concerned that
the EM condition may be a breach of PER's Convention rights and enclosing a copy of Dr Galappathie's
report. On 22 September 2022 Duncan Lewis wrote to the defendant alleging that the EM condition was
unlawful and giving notice of a potential claim for judicial review.

112. The defendant accepts that he should have reviewed PER's EM condition by 19 October 2022, but
he did not do so.

113. On 27 October 2022 Duncan Lewis sent a letter before claim. In addition to asserting that the EM
condition was unlawful, Duncan Lewis requested accommodation for PER and the deletion of PER's trail
data. The claim for accommodation became academic when accommodation was provided to PER
(although there remains an issue as to costs). In relation to her trail data, PER pursued the general claims
advanced by the other claimants, i.e. issues 5 and 6, but did not pursue a challenge to the proportionality
of the retention of her trail data, i.e. issue 7.

114. An internal email dated 18 November 2022 reveals that an assistant director in the FNORC reviewed
PER's EM condition (although no review form has been produced) and decided that it should be retained,
saying, inter alia, that there was little or no evidence to link her health problems to the EM condition. On 2
December 2022 the defendant replied to the letter before claim, stating that the EM condition would be
maintained.

115. A review form records the defendant's decision, following a review conducted on 18 January 2023,
but not approved until 7 March 2023, to maintain the EM condition. A further review form records a
decision to the same effect following a review conducted on 5 June 2023 and approved on 6 June 2023. A
further review form records a decision, following a review conducted on 18 September 2023, but not


-----

approved until 3 October 2023, to maintain the EM condition, but also a decision that it was appropriate for
PER to be transitioned to a non-fitted device when such devices became widely available. By a letter
dated 12 October 2023, the defendant notified PER of an appointment on 26 October 2023 for her to be
given a non-fitted device in place of her fitted device.

**(8) The Issues**

116. The parties helpfully agreed a list of issues, although they did not agree whether all of these issues
arose on the pleadings. I will address the issues in the order proposed by the parties, together with any
pleading issues.

117. The agreed list of issues is as follows:

(1) Is the Secretary of State required to make a conscious decision and give reasons for imposing GPS
monitoring? (I will treat this as two issues, concerning the alleged obligations: (a) to make a conscious
decision: this is an issue in the cases of ADL and PER; and (b) to give reasons: this is an issue the cases
of BNE, ADL and PER.)

(2) Is it lawful for the Secretary of State not to conduct quarterly reviews of GPS monitoring as required by
his published policy? (This is an issue in the cases of Mr Dos Reis, BNE and PER.)

(3) If the Secretary of State acts unlawfully as identified under issues 1 and/or 2, will he breach the
individual's rights under Article 8 of the Convention?

(4) Was GPS monitoring necessary and proportionate in ADL's and BNE's cases?

(5) Is the Secretary of State required to make individual decisions on whether to retain an individual's trail
data? (This is an issue in all of the claimants' cases.)

(6) Can the Secretary of State retain trail data for the purpose of informing future applications for leave to
remain in the UK? (This is an issue in all of the claimants' cases.)

(7) Was/is it necessary and proportionate to retain the claimants' trail data? (This is an issue in the case of
Mr Dos Reis, BNE and ADL.)

**(9) Issue 1(a): The Decision to Impose an EM Condition**

118. ADL and PER allege that the defendant did not make a conscious decision in their cases to impose
an EM condition. The defendant does not deny that it is incumbent on him to make a conscious decision
before imposing an EM condition. However, he contends:

(1) that the allegation that he did not make such a decision is not a pleaded allegation; and

(2) in any event, that he did make such a decision in each case.

119. It is clear that the defendant did take a decision in both ADL's and PER's case to impose an EM
condition. In ADL's case, that decision is recorded in the form Bail 201 which was issued to ADL and
which gave notice of the grant of immigration bail. The officer who took the decision on behalf of the
defendant is named in the form. In completing the form, that officer ticked the relevant box to indicate that
ADL would be subject to an EM condition. I see no reason to believe that that was anything other than a
deliberate and conscious act. As I have said, I have not seen the form Bail 201 issued to PER, but it was
not suggested that such a form was not completed and I see no reason to believe that its completion was
anything other than a deliberate and conscious act.

120. In my judgment, the real complaint made by ADL and PER is not that the defendant failed to make a
conscious decision to impose an EM condition, but that, in deciding to impose an EM condition on them,
the defendant failed to consider matters which he ought to have considered, namely the matters set out in
paragraph 3(2) of Schedule 10 and, in particular, the question whether the imposition of an EM condition
would be either impractical or contrary to the relevant claimant's Convention rights.

**_(9)(a) Developments during, and since, the Hearing_**


-----

121. In the alternative to his submission that this allegation was not pleaded, Mr Gullick submitted that the
defendant had not appreciated until shortly before the hearing that the claimants were contending that the
defendant had not made a conscious decision to impose an EM condition in any of these cases. In the
light of that submission, and in the light of certain things said in Mr Duffy's first witness statement, I directed
that the defendant could file a further witness statement after the hearing, with an exchange of submissions
in relation thereto.

122. When I made that direction, Mr Buttler made the understandable observation that evidence as to
what actually happened in the individual cases would be of more assistance to the court than evidence as
to what should have happened or what usually happened.

123. After the hearing, the defendant filed the witness statement of Stephen Murray, who is an area
director of the defendant's satellite tracking services department and the parties exchanged submissions in
relation to the significance of that statement.

124. I note that it was not suggested by the claimants that they needed to file evidence in response to Mr
Murray's statement. The claimants have had an opportunity to make submissions on the contents of that
statement, whose contents are capable of assisting the court with the issues which the claimants seek to
have decided in this case. In all the circumstances, I grant permission to the defendant to rely on Mr
Murray's statement (except for paragraph 18, which is outside the scope of the direction which I made and
which in any event I have not found to be of assistance on any issue).

**_(9)(b) Issue 1(a): The Pleading Issue_**

125. What I have termed issues 1(a) and (b) are said to be two aspects of ground 1B of the grounds for
seeking judicial review, which is in the following terms:

“The interference arising from GPS tracking is/was not in accordance with the law because, in breach of
the requirements of the _[Immigration Act 2016 and/or the common law, the Defendant did not make any](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
reasoned decision and/or give reasons for imposing the EM condition. …”

126. I do not consider that, in itself, this formulation adequately conveyed the case which Mr Buttler sought
to advance before me as issue 1(a). However, in ADL's case the claimants said as follows in paragraph 71
of the revised statement of facts and grounds (emphasis added):

“In Pilot Scheme cases, the Defendant must also consider whether imposing an EM condition would be
compatible with the proposed subject's Convention rights (under the Pilot Scheme Guidance and section 6
[of the Human Rights Act (“HRA 1998”)). Additionally, the Defendant must have regard to the statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
mandatory considerations set out in paragraph 3(2) of Schedule 10. Those matters include the likelihood of
a person “failing to comply with a bail condition” or “committing an offence while on immigration bail”. The
Defendant failed to consider those matters and failed to make any reasoned decision in C1's case.

127. In my judgment, the words emphasised were sufficient to entitle Mr Buttler to submit that issue 1(a)
had been adequately pleaded in ADL's case, although I can understand why the defendant did not
understand ground 1B to raise what is now issue 1(a). The position was less clear in PER's case, which
was dealt with in paragraph 70 of the revised statement of facts and grounds, but I consider that it is
appropriate to allow PER to advance issue 1(a), given that the issue was raised in ADL's case, it has been
fully argued in both cases, the defendant has had an opportunity to submit evidence in response to it and it
may be helpful for the court to make a decision which applies to both a deportation case and a nondeportation case.

**_(9)(b) Issue 1(a): The Substantive Issue_**

128. As I observed during the hearing, it is a curious feature of the procedures operated by the defendant
that, whereas the review form provided for the use of Home Office staff when conducting quarterly reviews
of EM conditions is structured so as to encourage the creation of a full record of the reasons for any
decision to maintain or remove an EM decision, there is no equivalent form for use in relation to the
decision to impose an EM condition when immigration bail is granted.


-----

129. Indeed, I was not directed to any evidence that the defendant has any system for recording the
reasons for decisions to impose EM conditions in cases where no representations have been received.
Where representations are received, there is supposed to be a response to the representations (if they are
considered, which did not happen in ADL's case) and such a response is capable of providing reasons for
a decision to reject the representations (although there is an issue whether the letter sent on 24 May 2022
in response to BNE's representations contained reasons, or adequate reasons, for rejecting those
representations).

130. The position is further complicated by the fact that the defendant operates a two-stage decisionmaking process. As I have said, before immigration bail is granted subject to an EM condition, a letter is
sent in form Bail 211 or 211 B. That letter states that a provisional decision has been made to grant
immigration bail subject to an EM condition, but it does not state the reasons for that decision. It does not
appear that any record is made of the reasons for the provisional decision in deportation cases. (There is
a document which was disclosed in ADL's case, a non-deportation case, to which I will return.) The letter
in form Bail 211 or 211 B invites representations before a final decision is made whether or not to impose
an EM condition, but, as I have said, there is no evidence that the defendant has any system for recording
the reasons for such a decision. At the hearing, there was some uncertainty whether, at least in cases
where no representations were made, it was the responsibility of: the officer making the provisional
decision; the officer making the final decision; or both, to consider, in particular, the question whether the
imposition of an EM condition on the individual would be either impractical or contrary to the individual's
Convention rights.

131. The source of this confusion was to be found in paragraphs 8 to 10 of Mr Duffy's first statement,
which were in the following terms:

“8.  If a person subject to the Duty is being granted bail, they are given the opportunity to provide
representations as to why they should not be subject to Electronic Monitoring in advance on their bail being
approved. For this purpose the Bail 211 is issued which invites them to submit representations. Once the
representations are received the decision maker will consider whether the representations indicate that the
application of EM would no longer be appropriate. As there is an expectation that EM will be applied in line
with the duty it is incumbent upon the service user to provide sufficient evidence to demonstrate that they
meet the threshold for the duty to not be applied. The Immigration Bail Policy provides guidance on
considering representations including if vulnerabilities are identified. Once the decision maker has
considered any representations, they will provide a response to the service user on a Bail 215 confirming
the decision.

9.  In cases where no representations are received and there is no known vulnerability or exemption
reason evident then it is incumbent on the SOS to apply the duty given the absence of identifiable reasons
not to do so. …

10.  Where EM is to be applied as part of the Expansion Pilot, the potential service user is informed of
such and provided an opportunity to make representations, through the issuing of a Bail 211 form. Where
representations are rejected, or none received, the service user is informed that they will be subject to EM
under the terms of the pilot through the issuing of a Bail 214 form.”

132. These paragraphs were open to the interpretation that the practice, at least in non-deportation cases,
was that no consideration was given by either the maker of the provisional decision or, if no
representations were received, by the maker of the final decision to the question whether it would contrary
to the individual's Convention rights to impose an EM condition. By contrast, the words “and there is no
known vulnerability or exemption reason evident” suggested that the practice in deportation cases was for
consideration to be given to that question by the maker of the final decision, even in the absence of
representations.

133. However, as I understand Mr Murray's witness statement, it describes a different practice, which is as
follows:


-----

(1) In deportation cases, the officer who makes the provisional decision will consider whether it would
contrary to the individual's Convention rights to impose an EM condition. If no representations are
received, then an EM condition will be imposed. This suggests that the officer who makes the final
decision does not, in the absence of representations, consider whether it would contrary to the individual's
Convention rights to impose an EM condition.

(2) In non-deportation cases, the officer who makes the provisional decision will consider whether the
individual is exempt from being subject to an EM condition (for instance, by reason of being under 18 or
pregnant), but will not consider whether it would contrary to the individual's Convention rights to impose an
EM condition. That question will be considered by the officer making the final decision, even if no
representations are received. A document disclosed by the defendant in ADL's case, entitled “GPS
Expansion Pilot Referral proforma”, provides support for the proposition that, in non-deportation cases, the
provisional decision involves only the limited consideration explained by Mr Murray.

134. I accept Mr Murray's evidence as to the standard practice. In his post-hearing submissions, Mr
Buttler made some critical observations about these practices, but those criticisms did not go to any of the
grounds for seeking judicial review and so I say nothing about them.

135. The preparation of Mr Murray's statement prompted some further disclosure by the defendant, who
applied for permission to redact the names of some civil servants from certain training materials which
related to the training of officers who make provisional decisions in non-deportation cases. I grant
permission to make those redactions, on the basis that the information redacted does not concern the
decision under challenge: see paragraph 22 of Swift J's judgment in R (IAB) v Secretary of State for the
_Home Department_ _[2023] EWHC 2930 (Admin)._

136. Mr Murray's statement dealt with the defendant's general practices, but his statement was less
informative about the individual cases:

(1) In relation to ADL, he said that (emphasis added):

“… if the ordinary procedures were followed in [ADL's] case, there would have been consideration by a
GPSEC caseworker of whether the exceptions applied even though no representations were received from
him.”

(2) In relation to PER, he said that he had spoken to Susan Quinn, who was a senior executive officer in
the FNORC and had been in charge of the team who decided to grant immigration bail to PER. However,
he did not say that she told him that consideration had been given in PER's case to the question whether it
would contrary to PER's Convention rights to impose an EM condition. Instead, he said (emphasis added)
that:

“I am informed by Susan Quinn that, in [PER's] case, FNORC had knowledge of some of [PER's] medical
conditions/vulnerabilities as these are what prompted the internal prompt for Secretary of State bail. They
were aware of the fact that [PER] was assessed as Adult At Risk Level 2 and that she had a positive
reasonable grounds NRM decision and had submitted a Rule 35 Claim, claiming to be a previous victim of
torture. Since the caseworker went on to issue a Bail 211, I therefore assume that the caseworker did not
believe any exemption thresholds were met on the material then available.”

137. Against that background, Mr Gullick invited me to infer that events in ADL's and PER's cases
proceeded in accordance with the usual practice described by Mr Murray. Mr Buttler, who relied on the
dicta of Fordham J in R (SA) v Secretary of State for the Home Department _[2023] EWHC 1787 (Admin),_
submitted that that would not be inference, but speculation, noting that the defendant has not served
evidence from the decision-maker in either case, nor has he served evidence explaining why he has not
filed evidence from the decision-maker. In reply, Mr Gullick also relied in PER's case on her withdrawal of
her representations, which he submitted amounted in effect to a request for the defendant to proceed on
the basis that none of the exceptions to the duty to impose an EM condition applied.

**_(9)(c) Issue 1(a): Decision_**


-----

138. Although the application for judicial review is brought by the claimants, I consider that on this issue
there is an evidential burden on the defendant, since the defendant's officers made the decision in each
case to impose an EM condition and the defendant has the records, such as they are, of what those
officers decided.

139. In the unusual circumstances of this case, where the defendant submitted evidence on issue 1(a)
after the hearing, the defendant was clearly on notice that, in effect, the claimants would submit that
generic evidence of the kind provided by Mr Murray was not sufficient to meet the defendant's evidential
burden. In those circumstances, it is particularly significant that Mr Murray did not say in his witness
statement that he had been unable to identify or to speak to the relevant decision-maker in ADL's or PER's
case.

_(9)(c)(i) Issue 1(a): Decision: ADL_

140. ADL's was a non-deportation case. Consequently, the question whether it would be contrary to
ADL's Convention rights to impose an EM condition should have been considered by the officer who made
the final decision to impose an EM condition. As I have said, that officer clearly made a conscious decision
to impose an EM condition, since they ticked the relevant box on the form Bail 201 and inserted details of
when and where the device was to be fitted. However, I have seen no evidence that that officer
considered whether imposing an EM condition would be impractical or contrary to ADL's Convention rights,
nor any evidence explaining why such evidence could not be produced. Accordingly, I find that they did
not do so. I do not consider that it would be appropriate to infer that he considered these matters “if the
ordinary procedures were followed”, since that would be to assume the very matter which the defendant
needs to prove.

_(9)(c)(ii) Issue 1(a): Decision: PER_

141. Since PER's case was a deportation case, consideration should have been given when the
provisional decision was made to the question whether it would be contrary to PER's Convention rights to
impose an EM condition. Mr Murray's evidence is that he assumes that the caseworker did this, but I do
not consider that it is appropriate to draw in inference in the defendant's favour on the basis of a mere
assumption. The letter of 12 July 2022 in form Bail 211 notifying Duncan Lewis of the provisional decision
referred expressly to both the defendant's duty to impose an EM condition in deportation cases and the
exceptions to that duty and said that, if Duncan Lewis did not respond, an EM condition would be imposed.
I have considered whether I can infer from the terms of this letter that consideration was given when the
provisional decision was made to the question whether it would be contrary to PER's Convention rights to
impose an EM condition, but this letter was in the same terms as the equivalent letter which was sent to
ADL at a time when it is the defendant's own case that no such consideration had been given in ADL's
case. The terms of the letter are therefore neutral on the issue of what, if any, consideration was given
before the letter was sent. I find that no consideration was given in PER's case when the EM condition
was imposed to the question whether imposing an EM condition would be impractical or contrary to PER's
Convention rights.

**(10) Issue 1(b): The Alleged Duty to Give Reasons**

142. BNE, ADL and PER allege that the defendant was under a duty at common law to give them reasons
for his decision to impose an EM condition and that he failed to give them such reasons. The principal
dispute in this respect concerned the existence of the alleged duty. It was accepted that the defendant did
not give reasons for imposing an EM condition on ADL or PER. Mr Gullick submitted that reasons were
given in BNE's case in the letter of 24 May 2022 responding to the representations made on his behalf.

**_(10)(a) Issue 1(b): The Parties' Submissions_**

143. I drew attention during the hearing to the fact that paragraphs 3(5) and 6(6) of Schedule 10 require
the defendant to give notice of decisions concerning immigration bail. Mr Buttler did not invite me to
conclude that this implied an obligation to give reasons for that decision and I make no such implication.
That does not preclude the existence of the alleged common law duty to give reasons, but it is a relevant
feature of the statutory framework


-----

144. Mr Buttler's primary submission was that it is now the law that the common law imposes a duty to
give reasons for any decision unless there is a cogent reason not to. He relied for this purpose on
paragraph 30 of Elias LJ's judgment in R (Oakley) v South Cambridgeshire District Council [2017] 1 WLR
3765, CA (“Oakley”).  He also referred to: R (CPRE Kent) v Dover District Council [2018] 1 WLR 108, SC
(“CPRE Kent”); and _R (Bourgass) v Secretary of State for Justice [2016] AC 384(“Bourgass”). He_
submitted that no cogent reason for not giving reasons had even been advanced and, in particular, the
giving of reasons would not impose an undue burden on the defendant, given that reasons were recorded
when EM conditions were reviewed and reasons were provided in response to representations.

145. Mr Buttler's alternative submission was that fairness required the giving of reasons, especially having
regard to: the serious consequences of an EM condition for the individual; the need for reasons to enable
the individual to bring judicial review proceedings; and the need for reasons to enable the individual to
make representations as to why an EM condition should not be imposed. I note that these latter two points
address two different stages in the decision-making process, namely the provisional decision, after which
representations can be made, and the final decision, which may be the subject of an application for judicial
review. Mr Buttler submitted that the most appropriate point for reasons to be given was when the
provisional decision was made and representations invited. This is akin to the situation in _Bourgass, in_
which it was held, albeit obiter, that when a prison governor sought authority from the Secretary of State for
Justice to continue a prisoner's segregation, fairness required that the prisoner must be informed of the
substance of the matters on the basis of which the authority of the Secretary of State is sought, because,
as Lord Reed, with whom the other justices agreed, said in paragraph 100 of his judgment:

“A prisoner's right to make representations is largely valueless unless he knows the substance of the case
being advanced in sufficient detail to enable him to respond.”

146. Mr Gullick submitted that the law was not as stated by Mr Buttler in his primary submission and that
Elias LJ's dicta in Oakley had not been adopted by the Supreme Court in CPRE Kent. He also relied on
_Oxton Farm v Harrogate Borough Council_ _[2020] EWCA Civ 805. He submitted that there was no reason_
for the common law to impose a duty to give reasons in the present situation, at least where the individual
had not made representations against the imposition of an EM condition. In particular, he submitted that:

(1) The criteria to be applied were set out clearly in Schedule 10.

(2) The individual was best placed to identify reasons why he or she contended that an EM condition
should not be imposed.

(3) The individual had the right to make representations to that effect and, if he did so, would receive a
reasoned response.

(4) There was no need for reasons to be given to an individual who did not make representations why an
EM condition should not be imposed.

(5) The decision to impose an EM condition was not a once-for-all decision.

(6) This was not a situation in which the individual needs to be informed of allegations which were being
made against him.

(7) Individuals did not need reasons in order to be able to make representations or apply for judicial
review.

147. I asked for clarification whether the defendant accepted that he was under a duty to give reasons for
imposing or maintaining an EM condition in cases where representations were made. Mr Vinall confirmed
that that was accepted, on the basis that it was the defendant's policy to give reasons in such
circumstances.  As I have explained, it was not spelled out in the text of the Bail Guidance until 30 August
2023 that it was the defendant's policy, as stated on page 38 of the Bail Guidance, to respond to
representations, but the form Bail 215, which was used by the defendant both before and after that date to
respond to representations, provided for the inclusion of reasons.

**_(10)(b) Issue 1(b): The Law_**


-----

148. In R v Secretary of State for the Home Department, ex parte Doody [1994] 1 A.C. 531(“Doody”) Lord
Mustill, with whom the other members of the House of Lords agreed, said as follows, at 564E:

“I accept without hesitation, and mention it only to avoid misunderstanding, that the law does not at present
recognise a general duty to give reasons for an administrative decision.”

149. In paragraphs 29 and 30 of his judgment in Oakley, Elias LJ, with whom Patten LJ agreed, said as
follows:

“29  It is firmly established that there is no general obligation to give reasons at common law, as
confirmed by Lord Mustill in Ex p Doody [1994] 1 AC 531. However, the tendency increasingly is to require
them rather than not. Indeed, almost 20 years ago, when giving judgment in _Stefan v General Medical_
_Council [1999] 1 WLR 1293, 1301, Lord Clyde observed:_

“There is certainly a strong argument for the view that what was once seen as exceptions to a rule may
now be becoming examples of the norm, and the cases where reasons are not required may be taking on
the appearance of exceptions.”

30  In view of this, it may be more accurate to say that the common law is moving to the position whilst
there is no universal obligation to give reasons in all circumstances, in general they should be given unless
there is a proper justification for not doing so.”

150. Whilst I do not question Elias LJ's observation that there is an increasing tendency to require reasons
rather than not, I do not accept Mr Buttler's submission that paragraph 30 of Elias LJ's judgment is
authority for the proposition that there is a common law duty to give reasons unless there are cogent
reasons not to. On the contrary, Elias LJ affirmed in paragraph 29 that it is firmly established that there is
no general obligation to give reasons at common law and in paragraphs 56 to 61 he identified the particular
features of the decision in _Oakley which justified the imposition of the duty to give reasons in that case._
Paragraph 30 of his judgment is not part of the ratio of Elias LJ's decision. Indeed, it does not purport to be
a definitive statement of the current law, as opposed to a statement of what may be the position towards
which the common law is currently moving.

151. Moreover, in CPRE Kent Lord Carnwath, with whom the other justices agreed: restated (in paragraph
51) that public authorities are under no general common law duty to give reasons for their decisions;
described _Oakley (in paragraph 52) as reaffirming the general principle that a local planning authority is_
under no common law duty to give reasons for the grant of planning permission and (in paragraph 54) as
consistent with the general law as established by the House of Lords in Doody; and referred (in paragraph
57) to the “special circumstances” in Oakley.

152. It will be a matter for consideration on the facts of individual cases whether the circumstances are
such that the common law requires reasons to be given for a decision. The matters relied on by Mr Buttler
are relevant to that consideration. For instance:

(1) In paragraph 79 of his judgment in Oakley, Sales LJ said as follows:

“… Similarly, where a person's private interest is particularly directly affected by a decision, that may also
provide a normative basis for imposition of a duty to give reasons, as exemplified in Ex p Doody [1994] 1
AC 531and Ex p Cunningham [1992] ICR 816. …”

(2) As Elias LJ recognised in paragraph 15 of his judgment in Oakley, Doody was an example of a case in
which reasons were necessary to make the remedy of judicial review effective. However, as Sales LJ
explained in paragraph 75 of his judgment, the absence of reasons does not necessarily make judicial
review ineffective.

(3) I have already referred to what was said in Bourgass.

**_(10)(c) Issue 1(b): Decision_**

153. In my judgment, the question whether there is a common law duty to give reasons really only arises
in cases where the individual has not made representations in response to the invitation made in the letter


-----

in form Bail 211 or 211 B. That is because, in a case where representations are made, the defendant
accepts that he has a duty to give reasons, because that is his policy. A failure to comply with that policy
would be an error of law, as is established by the authorities to which I will refer when considering issue 2.
It follows that the defendant was under a duty to give reasons for not accepting the representations made
on behalf of BNE and ADL.

154. Thus, PER is the only claimant who needs to rely, in relation to issue 1(b), on the alleged common
law duty to give reasons. However, PER's is a unusual case, in that she invited the defendant to impose
an EM condition on her without considering the representations which her solicitors had made, on the basis
that she did not want consideration of those representations to delay her release. It is difficult to see why
the common law needs to impose a duty to give reasons in such a case.

155. Consequently, I need not decide whether the common law imposes a duty on the defendant to give
reasons for his decision to impose an EM condition in the more straightforward case where the individual
does not make representations why an EM condition should be imposed. In deference, however, to the
arguments which I have heard, I will say that I would have decided that the defendant was under no such
duty. That decision would have been based on all of the relevant factors, considered in context, including,
in particular, the following considerations:

(1) The significance for the individual of an EM condition is a factor, but it is a less weighty factor in the
case of an individual who does not express any objection to its imposition.

(2) An individual has the opportunity, before an EM condition is imposed, to make representations why he
should not be subject to an EM condition.

(3) If the individual does not make such representations, then the defendant is entitled to proceed, in
deportation cases, on the basis that they do not require any further consideration of the question. (This is
subject to the qualification that, in non-deportation cases, the provisional decision does not involve any
consideration of the question whether the imposition of an EM condition would be contrary to the
individual's Convention rights.)

(4) BNE, ADL and PER did not complain that they were unable to make effective representations. On the
contrary, representations were made on behalf of all of them. BNE's representations were not accepted.
ADL's representations were not considered. PER's representations were abandoned. In no case was it
alleged that effective representations could not be made.

(5) There was good reason why BNE, ADL and PER did not complain that they were unable to make
effective representations.  That is because the crucial issue in these cases is likely to be whether the
imposition of an EM condition would be contrary to the individual's Convention rights. The individual is
likely to be the best source of evidence on this issue. The Bail Guidance recognises that the defendant
may have evidence about the individual's mental or physical health which may be relevant to the decision
whether or not to impose an EM condition, but it remains the case that the individual is best placed to say,
for instance, why wearing a fitted device would be likely to exacerbate his or her PTSD.

(6) The absence of reasons has not precluded BNE, ADL or PER from applying for judicial review, not only
on the basis of absence of reasons, but also on substantive grounds.

_(10)(c)(i) Issue 1(b): Decision: BNE_

156. I do not consider that the letter of 24 May 2022 contained adequate reasons for rejecting the
representations made on behalf of BNE. Mr Vinall was only able to point to one sentence in the letter as
potentially containing reasons, namely the sentence which read:

“[BNE's] Electronic Monitoring will be subjected to review should substantial evidence be submitted stating
why Electronic Monitoring is detrimental to his physical and/or mental health.”

157. I consider that this sentence is capable of being read as an adequate response to that (small) part
Duncan Lewis' letter which addressed the likely effect of an EM condition on BNE, saying, in effect, that
that part of the representations has not been accepted because it is not supported by substantial evidence.


-----

158. However, the letter says nothing about the matters which make up the majority of the
representations, namely the matters going to the assessment of the risk of absconding, re-offending or
causing harm presented by BNE. For instance, the letter did not say whether the defendant assessed
those risks as low, medium or high. Presumably, the defendant considered that those risks meant that the
imposition of an EM condition would not violate BNE's Convention rights, but the letter does not say so.

_(10)(c)(ii) Issue 1(b): Decision: ADL_

159. The defendant did not comply with his duty to give reasons for imposing an EM condition on ADL.
That is because the defendant did not consider the representations made on behalf of ADL and therefore
did not respond to them.

_(10)(c)(iii) Issue 1(b): Decision: PER_

160. I have already held that the defendant was not under a duty to give reasons for imposing an EM
condition on PER.

**(11) Issue 2: Late Reviews and Lawfulness**

161. Issue 2 concerns a proposed ground for judicial review, Ground 1D, which the claimants first sought
permission to raise by an application notice issued on 13 October 2023, 11 months after the claim form
had been issued on 15 November 2022. The defendant contends that permission to amend the grounds
should be refused.

**_(11)(a) Issue 2: The Parties' Submissions_**

162. It is convenient to begin by considering the parties' submissions on the merits of issue 2. There was
a considerable amount of common ground:

(1) First, as I have already said, it was accepted that the defendant's policy, as set out in the Bail
Guidance, required every EM condition imposed by the defendant to be reviewed within 3 months of its
imposition and within 3 months of any review.

(2) Secondly, it was common ground that the common law requires the defendant to comply with his
published policy, in the absence of good reason for departing from it: see R (Lumba) v Secretary of State
_for the Home Department [2012] 1 AC 245(“Lumba”); and paragraphs 29 and 30 of the decision of Lord_
Wilson, with whom the other justices agreed, in Mandalia v Secretary of State for the Home Department

[2015] 1 WLR 4546, SC (“Mandalia”).

(3) Thirdly, it was accepted that the reviews in Mr Dos Reis's, BNE's and PER's cases were late. In
particular:

(a) In Mr Dos Reis' case, the EM device was fitted on 7 March 2022. The defendant should have
conducted a review by 7 June 2022, but did not conduct a review until 18 August 2022. The outcome of
the review was to maintain the EM condition. The EM condition was removed within 3 months of 18
August 2022.

(b) In BNE's case, the EM condition was imposed on 26 May 2022. The defendant should have
conducted a review by 26 August 2022, but did not conduct a review until 3 November 2022, the outcome
of which was not approved until 7 November 2022. The outcome of the review was to remove the EM
condition.

(c) In PER's case, the EM condition was imposed on 19 July 2022. The defendant should have conducted
a first review by 19 October 2022, but did not conduct a review before the claim form was issued on 17
November 2022. There was a review on 18 November 2022, the outcome of which was to maintain the
EM condition. Since then:

(i) A review should have been conducted by 18 February 2023. It was conducted on 18 January 2023, but
the outcome was not approved until 7 March 2023. The EM condition was maintained.

(ii) The next review should have been conducted by 7 June 2023. It was conducted on 5 June 2023 and
th t d 6 J 2023 Th EM diti i t i d


-----

(iii) The next review should have been conducted by 6 September 2023. It was not conducted until 18
September 2023 and the outcome was not approved until 3 October 2023. The EM condition was
maintained, but with a non-fitted device when available.

(4) In the light of Mr Duffy's third witness statement, served in response to the claimant's application for
permission to advance ground 1D, the claimants did not seek to pursue that part of ground 1D which
alleged that the defendant had adopted an unpublished policy in relation to the conduct of reviews.

163. There was an issue whether the defendant had good reason for the delay in conducting these
reviews, with Mr Gullick submitting that the operational problems identified by Mr Duffy amounted to a good
reason and Mr Buttler submitting that a shortage of resources cannot amount to a good reason.

164. However, the principal issue between the parties was whether delay in conducting a review would
have the effect that an EM condition became unlawful and therefore not “in accordance with law” for the
purposes of Article 8. Mr Buttler submitted that:

(1) In Mr Dos Reis' case, the EM condition was unlawful from 7 June to 18 August 2022.

(2) In BNE's case the EM condition was unlawful from 26 August 2022 until it was removed on 7
November 2022.

(3) In PER's case the EM condition was unlawful from 18 October to 18 November 2022 and again from
19 February to 7 March 2023. (It seems that the same logic would apply to the period from 7 September to
3 October 2023, but PER did not advance a claim in respect of that period.)

165. I propose to deal with this issue in the context of issue 3. I note, however, that the period of any
unlawfulness on this ground would not begin on the day when the quarterly review was due, but on the day
after that.

166. Mr Buttler also advanced in connection with issue 2 an argument that, in effect, in the words of
paragraph 7(3)(a) of Schedule 10, it would be impractical for a person to continue to be subject to an EM
condition if it was impractical to review that condition, since reviewing the condition was implicitly required
in order to enable the defendant to pursue the duty imposed by sub-paragraph 7(2)(a) or (b) of Schedule
10. However, this argument did not go to any pleaded ground for judicial review and no reason was
advanced why that was the case.

**_(11)(b) Issue 2: Nelson_**

167. In Nelson, the Upper Tribunal decided that it was an error of law for the defendant not to review an
EM condition in accordance with his policy, unless he had good reason to depart from his policy: see, in
particular, paragraph 66 of the decision and reasons in Nelson. In their submissions on Nelson, the parties
agreed that I should follow it unless I was convinced that it was wrong or that there was a powerful reason
for not following it: see paragraph 71 of Eyre J's judgment in R (Roehrig) v Secretary of State for the Home
_Department [2023] 1 WLR 2032. Far from being convinced that the decision and reasons in Nelson was_
wrong on this point, I consider that it was right.

**_(11)(c) Issue 2: Permission_**

168. I consider that ground 1D is arguable. I note that it was not submitted to me that I should refuse
permission to amend on the basis of sub-section 31(3D) of the Senior Courts Act 1981, but it may be that
that sub-section will be relied on in future cases of this nature, especially having regard to the decision of
the Supreme Court in R (O) v Secretary of State for the Home Department [2016] 1 WLR 1717(“O”), a case
in which permission to apply for judicial review was refused because, while there had been a breach of
public law rendering detention unlawful for a period of time, judicial review proceedings would only have
resulted in an award of nominal damages.

169. CPR 54.5(1) provides that:

“(1)  The claim form must be filed –

(a)  promptly; and


-----

(b)  in any event not later than 3 months after the grounds to make the claim first arose.”

170. Insofar as PER seeks to complain of the two earlier periods of delay in her case, and insofar as Mr
Dos Reis and BNE seek to complain of the period of delay in each of their cases, I could only grant
permission to amend if I were of the view that it was appropriate to extend the time limit imposed by CPR
54.5(1).

171. Mr Gullick submitted that ground 1D could and should have been raised when the claim forms were
issued on 17 November 2022. The evidence accompanying the claim forms included:

(1) a statement by Pierre Makhlouf, the legal director of Bail for Immigration Detainees, in which he quoted
from paragraph 5.81 of the Chief Inspector's report and said that quarterly reviews of EM conditions did not
appear to be taking place; and

(2) a statement by BNE's mother, in which she said that there had been no quarterly review of the EM
condition in his case.

172. I note that, while the first period of delay complained of by PER (i.e. from 18 October to 18 November
2022) started before the claim form was issued, the second period of delay (i.e. from 19 February to 7
March 2023) started 3 months after the claim form was issued. That, however, was nearly 8 months
before the claimants issued their application notice.

173. Mr Buttler suggested that what prompted the claimants to raise ground 1D was Mr Duffy's first
witness statement, dated 12 May 2023, which referred to the backlog of reviews, but:

(1) the existence of a backlog of reviews had been apparent from the Chief Inspector's report, which was
quoted in the evidence relied on by the claimants when the claim form was issued; and

(2) in any event, the claimants did not issue their application notice until 13 October 2023, 5 months after
Mr Duffy made his first statement, having foreshadowed it in a Part 18 request dated 1 August 2023.

174. Mr Buttler also submitted that the delay in raising ground 1D had not caused any prejudice to the
defendant, who had submitted evidence, in the form of Mr Duffy's second statement, in response to the
application, and the delay had not prevented the ground from being fully argued. These are factors which
are relevant to my discretion to extend time.

175. Another relevant factor is that delays in conducting quarterly reviews are clearly part of a widespread
problem which has affected large numbers of individuals subject to EM conditions and which has continued
for at least two years and which remains to be fully resolved. There is thus a wider general interest in
having ground 1D resolved, but that interest has already been addressed by the decision and reasons in
_Nelson._

176. Taking account of all of the relevant factors, I do not consider that it would be appropriate to grant
permission to the claimants to amend their statements of grounds so as to complain of delays which ended
significantly more than 3 months before 13 October 2023, i.e.:

(1) over 13 months before in Mr Dos Reis' case;

(2)  over 11 months before in BNE's case; and

(3) over 11 months before and over 7 months before in PER's case.

**_(11)(d) Issue 2: The Reason for the Delay_**

177. It follows that it is unnecessary for me to address the reason for the defendant's delay in conducting
quarterly reviews. However, it may be helpful for me to indicate what I would have decided in that respect
if I had been obliged to make a decision.

178. The defendant's policy required him to review EM conditions every 3 months. On a number of
occasions he did not do so. That was unlawful, unless he had good reason to depart from his policy. I do
not consider that he had good reason to depart from his policy.

179 I should not be understood as accepting Mr Buttler's submissions that:


-----

(1) a shortage of resources is incapable of amounting to a good reason for departing from a policy such as
this one; and

(2) the defendant can only depart from a policy if he makes a conscious decision to do so.

180. A possible counter-example which I mentioned in the hearing was the unexpected loss of substantial
resources due to an event such as the recent pandemic, which rendered the defendant unable to comply
with his policy, without the defendant having made a choice not to comply with it, as opposed to
recognising the reality that he cannot comply with it. That is a matter which may fall for decision in another
case.

181. In the present case, however, Mr Duffy's evidence was that one of the three causes of the backlog in
quarterly reviews was a shortage of staff. As I have already observed, the backlog was substantial and it
has continued for a substantial period of time. The backlog had grown to over 800 by 28 February 2022, it
more than doubled in size in the next 12 months and, although it fell between February and May 2023, it
more than doubled again between May and October 2023. The first period of delay relied on in the present
cases began on 8 June 2022, which was over 3 months after the backlog had already grown to over 800.
In that context, I do not consider that the defendant could rely on a shortage of staff as a good reason for
the delay in conducting the quarterly reviews in the cases of Mr Dos Reis, BNE and PER.

**(12) Issue 3: Alleged Breaches of Article 8 ECHR**

182. Article 8 ECHR provides as follows:

“1  Everyone has the right to respect for his private and family life, his home and his correspondence.

2  There shall be no interference by a public authority with the exercise of this right except such as is in
accordance with the law and is necessary in a democratic society in the interests of national security,
public safety or the economic well-being of the country, for the prevention of disorder or crime, for the
protection of health or morals, or for the protection of the rights and freedoms of others.”

183. In the present case:

(1) There is no dispute that Article 8 is engaged by an EM condition.

(2) There is a dispute whether the interference with the claimants' rights under Article 8 by reason of the
EM conditions imposed on them was, or was at all times, “in accordance with the law”. This will require
consideration of the questions:

(a) whether the matters complained of in issues 1(a), 1(b) and 2 rendered any of the EM conditions
imposed on any of the claimants unlawful under English law for any period or periods of time; and

(b) if not, whether there is any other basis for concluding that any of the EM conditions imposed on any of
the claimants was not “in accordance with the law” for any period or periods of time.

(3) It is not disputed that the EM conditions imposed on the claimants pursued a legitimate interest.

(4) There is an issue whether the EM conditions imposed on the claimants were “necessary in a
democratic society” or whether they were disproportionate, whether from the outset or for a period or
periods of time. That is issue 4.

**_(12)(a) Issue 3: The Meaning of “in accordance with the law”_**

184. It is well-established in the jurisprudence of the ECtHR that an interference with an Article 8 right will
only be “in accordance with the law” if:

(1) it is lawful under national law; and

(2) the national law is clear, foreseeable, and adequately accessible.

185. For English authorities on this point, see paragraph 11 of Lord Sumption's judgment in _R (Catt) v_
_Commissioner of Police of the Metropolis_ [2015] AC 1065; and paragraph 80 of the Divisional Court's


-----

judgment in _R (Bridges) v Chief Constable of South Wales_ [2020] 1 WLR 5037. (These cases were not
cited before me, but they were quoted in the Upper Tribunal's decision and reasons in Nelson.)

186. There is a dispute about the first of these requirements, but Mr Buttler made clear that he was not
alleging that the relevant provisions of English law failed to meet the second, “quality of law” requirement.
(In that respect, this case was different from _Nelson, in which there was an issue whether the relevant_
English law was accessible and foreseeable, an issue which the Upper Tribunal resolved in the defendant's
favour: see paragraphs 57 to 59 of the decision and reasons in Nelson.)

187. However, Mr Buttler advanced a different basis for alleging that the EM conditions imposed in this
case were not “in accordance with the law”. I will address first the relevant English law and then Mr
Buttler's alternative argument.

188. In relation to the question whether the alleged breaches of English law rendered the EM conditions
unlawful, Mr Buttler relied primarily on the Supreme Court's decision in R (Kambadzi) v Secretary of State
_for the Home Department [2011] 1 WLR 1299, SC (“Kambadzi”). Mr Gullick relied on R v Soneji [2006] 1_
AC 340(“Soneji”), _R (Lee-Hirons) v Secretary of State for Justice [2017] AC 52(“Lee-Hirons”) and R_
_(Lauzikas) v Secretary of State for the Home Department_ _[2018] EWHC 1045 (Admin) (“Lauzikas (No 2)”)._
He also drew my attention to the decision of the Supreme Court in O, which, as I will explain, was regarded
as significant by the Upper Tribunal in Nelson.

189. In the present case, I have found that the defendant acted unlawfully in three different ways. I have
found that:

(1) The defendant acted unlawfully in ADL's and PER's case by not considering whether the imposition of
an EM condition would be impractical or contrary to ADL's or PER's Convention rights.

(2) The defendant also acted unlawfully in ADL's case by not considering the representations made on
behalf of ADL.

(3) The defendant acted unlawfully in BNE's and ADL's case by not giving reasons for rejecting the
representations made on behalf of BNE and ADL.

190. Moreover, had their claims been brought in time, I would have found that the defendant acted
unlawfully in Mr Dos Reis', BNE's and PER's case by not conducting a quarterly review of their EM
conditions in time. Although I do not have to consider issue 3 in relation to these alleged unlawful acts, I
consider that it is helpful for me to do so, for a number of reasons:

(1) It may be decided that I should have granted permission for the proposed amendment in relation to
issue 2.

(2) In any event, the argument on issue 3 focused on this type of public law breach, especially in the light
of the decision in Kambadzi.

(3) I have found it helpful to consider the effect of this type of breach as part of the overall picture when
considering the effect of other types of public law breach.

**_(12)(b) Issue 3: English law on the Effect of Breaches of Policy_**

191. As I have already noted, it was not disputed that the common law requires a minister not to depart,
without good reason, from his published policy. A breach of that public law duty may render an individual's
detention unlawful, giving rise to the tort of false imprisonment. The cases primarily relied on by Mr Buttler
and Mr Gullick, i.e. _Kambadzi and_ _Lee-Hirons, each involved deciding whether a breach of a particular_
public law duty in a particular context rendered the individual's detention unlawful. In each case, the court
applied the principles laid down in Lumba.

_(12)(b)(i) Lumba_

192. It is appropriate, therefore, to begin with a consideration of what was decided in Lumba. Lord Wilson
summarised the relevant parts of Lumba as follows in paragraph 34 of his judgment in Lee-Hirons:


-----

“… The Home Secretary had, so the majority held, infringed the rights of two men in reaching a decision to
detain them pending deportation by reference to unpublished criteria inconsistent with her published
criteria. Also by a majority, the court decided that the infringement had rendered their actual detention
unlawful. It was obvious that the criteria by reference to which the Home Secretary decided whether initially
to detain the men, and thereafter whether to continue to detain them, bore in principle, ie at least
theoretically, on the decision to detain them even though, as the court also proceeded to find, they would
nevertheless have fallen to be detained by reference to the published criteria. Lord Dyson JSC said, at
para 68:

“It is not every breach of public law that is sufficient to give rise to a cause of action in false imprisonment.
In the present context, the breach of public law must bear on and be relevant to the decision to detain.”

Baroness Hale of Richmond JSC said, at para 207:

“the breach of public law duty must be material to the decision to detain and not to some other aspect of
the detention and it must be capable of affecting the result - which is not the same as saying that the result
would have been different had there been no breach.”

Lord Kerr of Tonaghmore JSC added at para 248 that the breach had to have a “direct” bearing on the
decision to detain.”

193. See also the discussion of Lumba by Michael Fordham QC (as he then was) in paragraph 18 of his
judgment in Lauzikas (No. 2).

194. At the risk of stating the obvious, it is clear that:

(1) The Supreme Court in Lumba identified two separate questions:

(a) Was there a breach of public law in relation to Lumba's detention?

(b) Did that breach render his detention unlawful?

(2) The second question only arises because, as Lord Dyson stated, it is not the case that every breach of
public law in relation to a person's detention renders his detention unlawful.

195. I emphasise this latter point because it is relevant to the question whether an interference with a
person's Convention rights is “in accordance with law”. The law in that context is national law. This can be
seen, for instance, in cases under Article 5(1) ECHR in which the ECtHR has considered whether a breach
of English public law has, or has not, rendered a person's detention unlawful: see, for example: Benham v
_United Kingdom (1996) 22 E.H.R.R. 293; and Perks v United Kingdom (1999) 30 E.H.R.R. 33._

196. Lumba was decided by a court consisting of nine justices. Lord Dyson gave the principal judgment.
Lord Hope said (in paragraph 170) that he agreed with Lord Dyson's reasons. Lord Collins said (in
paragraph 219) that he agreed with Lord Dyson substantially for the reasons which he gave. Lord Kerr
said (in paragraph 238) that he would allow the appeal for the reasons given by Lord Dyson. Baroness
Hale dealt very briefly (in paragraph 207) with what she called the second question. She agreed with Lord
Dyson in the result on that question.

197. In those circumstances, I consider that Lord Dyson's formulation of the test is the most authoritative.
It is worth quoting more fully what he said in paragraph 68 of his judgment:

“… It is not every breach of public law that is sufficient to give rise to a cause of action in false
imprisonment. In the present context, the breach of public law must bear on and be relevant to the decision
to detain. Thus, for example, a decision to detain made by an official of a different grade from that specified
in a detention policy would not found a claim in false imprisonment. Nor too would a decision to detain a
person under conditions different from those described in the policy. Errors of this kind do not bear on the
decision to detain. They are not capable of affecting the decision to detain or not to detain.”

_(12)(b)(ii) Kambadzi_

198. The test propounded in Lumba is not always easy to apply. For instance, Kambadzi was a case in
hi h t h d b h d b f _L_ _b_ d id d b t th d i i i _K_ _b d i_ dj d


-----

until after Lumba had been decided. Kambadzi was decided by a majority of three to two. Even then, one
member of the majority, Lord Hope, said (in paragraph 35) that he had not found the question in Kambadzi
an easy one to answer and another, Baroness Hale, also said (in paragraph 75) that it was not an easy
question.

199. The claimant in Kambadzi was in immigration detention for 27 months. Munby J found that there was
no breach of the Hardial Singh principles during that period. However, the defendant had failed to carry
out many of the regular reviews of the claimant's detention required by the defendant's policy (as set out in
paragraph 38.8 of the defendant's Operational Enforcement Manual). Munby J held that these failures
meant that the claimant's detention had been unlawful for various periods, amounting to about 19 months
in total. The Court of Appeal allowed the defendant's appeal against Munby J's decision, but the Supreme
Court allowed the claimant's appeal against the Court of Appeal's decision.

200. It is relevant to note what Lord Hope said about the Court of Appeal's decision in paragraph 36 of his
judgment in Kambadzi:

“I do not accept the Court of Appeal's view that the question is one of statutory construction. We are
dealing in this case with what the Secretary of State agrees are public law duties which are not set out in
the statute.”

201. Baroness Hale also distinguished, in paragraphs 71-73 of her judgment, between cases where the
procedural requirement in question is laid down in legislation, in which case it will be a matter of statutory
construction whether failure to comply with it renders detention unlawful, and cases where the procedural
requirement is imposed by the common law, including the duty imposed by the common law on a minister
to comply with his published policy.

202. I highlight these parts of the judgments in Kambadzi because they seem to me to make clear that the
judgment in Soneji, on which Mr Gullick relied, is irrelevant to the present case. Soneji was concerned with
the correct approach to determining the effect of a failure to comply with a procedural requirement
contained in a statute (in that case, section 72A(3) of the Criminal Justice Act 1988), which is a question of
statutory construction. Cases such as the present, however, are concerned with a failure to comply with a
common law duty and therefore cannot be resolved by statutory construction.

203. Another aspect of Lord Hope's judgment which is worth highlighting is what he said in paragraph 51:

“The question then is what is to be made of the Secretary of State's public law duty to give effect to his
published policy. In my opinion the answer to that question will always be fact-sensitive. …”

204. Lord Hope gave his reasons for his decision on this issue in paragraphs 49 to 54 of his judgment. He
said that the defendant's original decision to detain the claimant was not indefinite in effect, since it was
subject to the _Hardial Singh principles. He said that the policy was designed to give practical effect to_
these principles and that, in the words of Munby J (with which Baroness Hale also agreed), the reviews
were fundamental to the propriety of continued detention. He added that, if the system worked as it
should, authorisation for continued detention was to be found in the decision taken at each review.
Conversely, if the reviews were not carried out (unless for good reason, which was not suggested in that
case) continued detention was not authorised by the initial decision to detain and it was no defence for the
defendant to say that there were good grounds for detaining the claimant anyway.

205. Baroness Hale gave the reasons for her decision in paragraphs 73 and 74 of her judgment. She
distinguished those parts of the policy in question which were not directly concerned with the justification
and procedure for the detention and had more to do with its quality or conditions, but she said that the
whole point of the regular reviews was to ensure that the detention was lawful. She noted that it was held
in Tan Te Lam [1997] AC 97that the substantive limits on the power to detain were jurisdictional facts, so
the defendant had to be in a position to prove these if need be, but she said that he would not be able to do
so unless he had kept the case under review. She said that it followed that the detainee's detention is
unlawful during the periods when it has not been reviewed in accordance with the policy. She added that it
followed from the decision in Lumba that the fact - if it be a fact – that, had the requisite reviews been held,
the decision would have been the same made no difference


-----

206. Baroness Hale added in paragraph 77 of her judgment that she believed that her reasons were no
different from those of Lord Hope or Lord Kerr. She added that the departure from the defendant's policy
was “so obvious and so persistent and so directly related to the decision to continue to detain that it was
clearly “material” in the Lumba sense.” I note that this way of putting the matter appears to assume that
the defendant had taken a conscious decision to continue to detain the claimant, which is not an
assumption made by Lord Hope.

207. Lord Kerr said (in paragraph 78) that he agreed with Lord Hope that the appeal should be allowed for
the reasons given by Lord Hope. However, he also added observations of his own in paragraphs 80 to 88
of his judgment. Having noted the Hardial Singh principles, he said that periodic review of the justification
for continued detention was required. He said that the review was the means by which the existence of the
justification was to be established. He said that it could not be lawful to hold someone without examining
whether good grounds for doing so continue to exist. He agreed with Munby J's characterisation of the
system of review as being integral to the lawfulness of the detention. He said that the majority in Lumba
had held that causation was not a necessary ingredient for liability. He added that “The public law error in
the present case bore directly on the decision to detain in that it was made without the necessary review of
the justification for detention.” Again, I note that this way of putting the matter appears to assume that the
defendant had taken a conscious decision to continue to detain.

_(12)(b)(iii) O_

208. I regard O as an application of Lord Hope's reasoning in Kambadzi. O was liable to detention and
was in immigration detention pursuant to paragraph 2 of Schedule 3 to the Immigration Act 1971. The
defendant's policy, as set out in chapter 55 of his manual entitled “Enforcement Instructions and
Guidance”, required regular reviews of O's detention, including consideration of whether her serious mental
illness could be satisfactorily managed within detention. In breach of that policy, the reviews of O's
detention were both late and inadequate, in that they did not address the question whether her mental
illness could be satisfactorily managed in detention.  It was an error of law for her reviews to be late and to
be inadequate in this way. The Supreme Court considered whether this rendered her detention unlawful.
The crucial part of Lord Wilson's judgment is sub-paragraph 48(g), in which he said as follows, referring to
_R (Francis) v Secretary of State for the Home Department [2015] 1 WLR 567:_

“In my view, therefore, the preferable analysis is along the lines sketched by Sir Stephen Sedley in his
concurring judgment in the Francis case at paras 56-57, namely that the mandate to detain conferred by
paragraph 2(1) and by the words in parenthesis in paragraph 2(3) is subject to two conditions. At the risk of
oversimplifying the Hardial Singh principles, I would summarise the first condition as being that there is a
prospect of deportation within a reasonable time. I would summarise the second as being that the Home
Secretary will consider in accordance with her policy whether to exercise the power expressly given to her
to direct release. Were either condition not to be satisfied, the mandate would cease and the detention
would become unlawful.”

_(12)(b)(iv) Lee-Hirons_

209. The claimant in Lee-Hirons had been detained pursuant to hospital and restriction orders made under
[the Mental Health Act 1983,then released subject to conditions and finally recalled. However, it was held](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y0F8-00000-00&context=1519360)
that, in breach of his policy, and therefore in breach of his public law duty, the defendant did not provide
the claimant with an adequate explanation for the recall within 3 days of the recall. The explanation was
provided 12 days late. One of the issues was whether this breach of a public law duty rendered the
claimant's detention unlawful for those 12 days.

210. Lord Wilson, with whom the other justices agreed, gave his reasons for his decision on that issue in
paragraph 39 of his judgment, where he said:

“In my opinion there is no link, let alone a direct link, between, on the one hand, the Minister's wrongful
failure for 12 days to provide to the claimant an adequate explanation for his recall and, on the other, the
lawfulness of his detention. The failure did not delay reference of his case to the First-tier Tribunal. Nor has
the claimant suggested that it delayed institution of the present proceedings. Even if it had created delay,


-----

the unequivocal statement of Lord Mance and Lord Hughes JJSC in the _Kaiyam case [i.e._ _R (Kaiyam) v_
_Secretary of State for Justice [2015] AC 1344] about the limited effects of a violation of article 5.4 would_
appear to exclude the relevance of the delay to the validity of the detention itself. The case closest to the
present is the _Saadi case [i.e._ _R (Saadi) v Secretary of State for the Home Department [2002] 1 WLR_
3131, HL; and Saadi v United Kingdom (2008) 47 EHRR 17] where the difference was one only of degree
(namely a delay of three days rather than of 12) and not of kind.”

_(12)(b)(v) Lauzikas (No. 2)_

211. The claimant in Lauzikas (No. 2) was placed in immigration detention, but he was not given reasons
for his detention until the day after he was detained. It was conceded that the first day of his detention was
unlawful. Since this was a concession, I do not derive much assistance from it.

_(12)(b)(vi) Nelson_

212. _Nelson was a case concerning immigration bail with an EM condition. Reviews of Nelson's EM_
condition were both late and inadequate. The Upper Tribunal relied primarily on the decision in _O in_
deciding that, during the relevant periods, Nelson's detention was not in accordance with the law.

213. As I have already said, the parties agreed that I should follow Nelson unless I was convinced that it
was wrong or that there was a powerful reason for not following it. There is one aspect of the reasoning in
_Nelson in relation to which I respectfully disagree with the Upper Tribunal, but that does not lead me to_
disagree with the result. In paragraphs 62 and 63 of its decision and reasons, the Upper Tribunal said as
follows:

“62. The respondent submits that the authority of _Kambadzi is of no assistance in resolving this issue._
Firstly, that was a case which did not address the requirements of article 8 or the “in accordance with the
law” criteria. In fact, it was a case concerned with the position at common law in respect of a claim for
damages for false imprisonment or trespass to the person. The Supreme Court specifically did not address
article 5 and the case was not, therefore, one about human rights.

63. We consider that there is force in the submissions made by the respondent about the case of
_Kambadzi. It does appear that that case was not only a case concerned with a common law right to_
damages and not human rights, but it also arose in a differing statutory context. However, in our view the
applicant is on far firmer ground when making the further submissions based on the case of _O_ and
_Malcolm.”_

214. I agree that Kambadzi arose in a different statutory context to the imposition and maintenance of EM
monitoring conditions, but so did _O and_ _Malcolm_ (i.e. _Malcolm v Secretary of State for Justice_ _[2011]_
_EWCA Civ 1538).  I also agree that Kambadzi did not address human rights law, but neither did O. As I_
have already said, I regard O as no more than an application of Lord Hope's reasoning in Kambadzi.

215. As for _Malcolm, the Upper Tribunal quoted in paragraph 38 of its judgment an obiter dictum by_
Richards LJ in paragraph 32 of his judgment in _Malcolm. The context was that for a period of time_
Malcolm, a life prisoner in a segregation unit, had been given only 30 minutes' open air recreation per day,
rather than the one hour provided for in Prison Service Order 4275. The Court of Appeal agreed with the
judge at first instance that Article 8 was not engaged. However, Richards LJ went on to say that, if he had
been satisfied that Article 8 was engaged, the Secretary of State would have had difficulties in respect of
the provisions of Article 8(2). I do not doubt that that was correct on the facts of Malcolm, which are very
different from the facts of the present case.

216. Richards LJ said as follows in paragraph 32 of his judgment in Malcolm:

“PSO 4275 was a published policy to guide the exercise of prison officers' discretion under rule 30 of the
Prison Rules 1999. The prison officers at HMP Frankland failed to give effect to the mandatory
requirements of PSO 4275 as regards the opportunity to be given to those in the segregation unit to spend
a minimum of one hour in the open air. If they did not have good reason for that failure, I have little doubt
that in a public law challenge they would be found to have acted unlawfully. One does not need to look
further than the passages in R (Lumba) v Secretary of State for the Home Department cited by Miss


-----

Kaufmann for the proposition that a decision-maker must follow his published policy unless there are good
reasons for not doing so; a proposition that applies equally to a policy published by the Secretary of State
for the guidance of those exercising powers under rules made by him … When determining whether an
interference is “in accordance with the law”, even the Strasbourg court looks at domestic law (see, for
example, _Eriksson v Sweden (1989) 12 EHRR 183 at [62]-[63]); a fortiori the national court must look at_
domestic law when deciding whether the requirement is satisfied; and I can see no possible basis for
contending that the principles of public law do not form part of domestic law for this purpose.”

217. I read this paragraph as saying no more than that public law is part of domestic law for the purpose of
deciding whether an interference with an Article 8 right is “in accordance with law”. However, I do not read
it as meaning that every breach of public law in relation to a person's detention has the effect that their
detention is not “in accordance with law” for the purposes of their Convention rights. Indeed, such a
reading would be inconsistent with the reasoning in _Lumba (a case on which Richards LJ relied in this_
paragraph), for reasons which I have already explained. If and insofar as my reading of this paragraph
from Richards LJ's judgment is different from that of the Upper Tribunal, then I respectfully disagree with
the Upper Tribunal.

218. In paragraph 65 of its decision and reasons, the Upper Tribunal said as follows:

“Thus, the process of regular reviews is an integral part of the lawful administration of an electronic
monitoring condition and, as has been set out above, a key feature of concluding that in principle the
regime fulfils the requirements of accessibility and foreseeability so as to meet the “in accordance with the
law” standard. Failure to comply with these integral elements of the legal framework by failing to review the
circumstances in which an electronic monitoring condition has been imposed on a regular basis therefore
clearly undermines the legality of continuing to impose such a condition. For the reasons given in the case
of O, the fact that a later review might conclude that the imposition of the condition had been practicable
and in accordance with the applicant's human rights, does not eliminate or obscure the failure to conduct a
review at all, or the failure to conduct a review lawfully. …”

219. I understand that to be an application by the Upper Tribunal to the law concerning EM conditions of
the reasoning in Kambadzi and O.

220. Then in paragraph 66 of its decision and reasons in Nelson the Upper Tribunal said as follows:

“A further route to the same conclusion arises from the well-established proposition that a decision-maker
must apply a relevant policy they have established when making a decision to which the policy applies
unless there are clear reasons for departing from it. This proposition can be seen at work in the case of
_Malcolm, and finds expression in high authority in the Supreme Court case of_ _Mandalia v Secretary of_
_State for the Home Department_ [2015] 1 WLR 4546; _[2015] UKSC 59 at paragraphs 29 to 31. In the_
present case the requirements of the policy were not met either as to the regularity of the reviews or the
reviews being conducted lawfully. The respondent has not identified any reason, let alone a good reason,
why that policy was not adhered to in the applicant's case. It follows that this amounts to a public law error
on the part of the respondent and one which renders the requirement to wear the GPS tag during the
period when reviews should have been but were not carried out, or alternatively were carried out
incompetently, not “in accordance with the law”, albeit the same observations in relation to relief set out
above remain pertinent. …”

221. This is expressed as an alternative line of reasoning, on which basis it would not form part of the ratio
of the decision in Nelson. For my part, however, I do not consider that it is an alternative line of reasoning.
The public law error in Kambadzi and in O was a failure to follow the defendant's published policy without
good reason. For the reasons set out in Kambadzi and in O, that public law error rendered the claimant's
detention unlawful in each case. I do not read paragraph 66 of the Upper Tribunal's decision and reasons
in Nelson as saying anything inconsistent with the application to the law concerning EM conditions of the
reasoning in _Kambadzi and_ _O. I note that it was not contended at the hearing, and has not been_
contended since, that any public law error in relation to an individual's detention has the effect that his
detention would not be “in accordance with the law” for the purposes of Article 8.


-----

**_(12)(c) Issue 3: Submissions_**

_(12)(c)(i) Issue 3: Submissions: Failure to conduct Quarterly Review in Time_

222. Decisions to impose or to maintain an EM condition are executive acts which result in an interference
with a Convention right. It is clear from Lumba and Kambadzi that that is a significant part of the context in
the present case. In relation to failures to conduct quarterly reviews in time, Mr Buttler submitted that the
circumstances of the present cases were closely analogous to the context in Kambadzi, in that: the original
decision to impose an EM condition was not of indefinite duration; sub-paragraph 7(2)(b) of Schedule 10
recognised that circumstances might arise in which the defendant was obliged to remove the EM condition;
it was in order to inform himself whether those circumstances had arisen that the defendant had adopted a
policy of conducting quarterly reviews; and those reviews were therefore directly related to the
maintenance of the EM condition.

223. On the other hand, Mr Gullick submitted that:

(1) While undoubtedly significant, the interference with personal liberty involved in the imposition or
maintenance of an EM condition is not as significant as that resulting from immigration detention.

(2) A delay in conducting a quarterly review of an EM condition is merely incidental to the EM condition
and does not render the EM condition unlawful.

(3) In a deportation case, sub-paragraph 7(2)(a) of Schedule 10 was determinative of the question
whether a failure to conduct a review in time rendered an EM condition unlawful, on the basis that, unless
and until he concluded that it would be impractical or contrary to the individual's Convention rights for the
individual to continue to be subject to the EM condition, the defendant remained subject to the duty
imposed by sub-paragraph 7(2)(a) and that, since the defendant could not, while subject to that duty,
lawfully decide to remove an EM condition, he could not do the same thing by delaying the conduct of a
review.

(4) Judicial review was precluded in the present case by section 31(2A) of the Senior Courts Act 1981,
which provides as follows:

“The High Court—

(a)  must refuse to grant relief on an application for judicial review, and

(b)  may not make an award under subsection (4) on such an application,

if it appears to the court to be highly likely that the outcome for the applicant would not have been
substantially different if the conduct complained of had not occurred.”

(5) Mr Gullick submitted that these were cases in which the outcome for the claimants would not have
been substantially different if the conduct complained of had not occurred.

224. Mr Buttler submitted that sub-paragraph 7(2)(a) of Schedule 10 did not preclude the application of the
reasoning in Lumba and Kambadzi to the present case.

225. In his most recent submissions, Mr Gullick submitted that I should not follow the Upper Tribunal's
decision in Nelson because:

(1) The Upper Tribunal's decision and reasons did not address the submission that whether a breach of
domestic law renders an interference not “in accordance with the law” depends on the domestic remedial
consequences of the breach of domestic law. I have already dealt with this issue when addressing
paragraphs 62, 63 and 66 of the decision and reasons in Nelson.

(2) The Upper Tribunal's decision and reasons made no reference to _Petrovic v Serbia (Application No_
75229/10) 14 April 2020. This was one of a pair of ECtHR authorities cited by Mr Gullick, the other being
_Budak v Turkey (2021) 73 E.H.R.R. 8. Both of these cases concerned a search of an individual's home_
which did not comply with the requirement of Turkish law that there be two witnesses to the search. In the
first case there was no finding that this rendered the search unlawful under Turkish law. In the second
th h fi di I d t id th t l t i t f i i l i t f th


-----

(3) The Upper Tribunal did not address the argument based on section 31(2A) of the Senior Courts Act
1981.

_(12)(c)(ii) Issue 3: Submissions: Failure to Consider_

226. The parties did not advance discrete submissions on the question whether an EM condition would be
rendered unlawful by a failure to consider either: (i) whether it would be impractical or contrary to the
individual's rights to impose an EM condition; or (ii) any representations made. However, I understood
them to rely on substantially the same points as they made in relation to the issue whether a failure to
conduct a quarterly review on time rendered an EM condition unlawful.

_(12)(c)(iii) Issue 3: Submissions: Failure to Give Reasons_

227. Mr Buttler submitted that a failure to give reasons for the imposition or retention of an EM condition
rendered the EM condition unlawful because it went to the individual's right to make effective
representations and/or to bring judicial review proceedings.

228. Mr Gullick submitted that a failure to give reasons is merely incidental to the EM condition and does
not render the EM condition unlawful.

**_(12)(d) Issue 3: Mr Buttler's Alternative Argument_**

229. Mr Buttler referred to paragraphs 113 and 114 of Lord Reed's judgment in R (T) v Chief Constable of
_Greater Manchester Police [2015] AC 49(“T”), quoted by Lord Sumption in In re Gallagher [2020] AC 185,_
in support of a submission that, even if the breaches of public law in the present case did not render the
imposition or maintenance of an EM condition unlawful under English law, they would have the effect that
the imposition or maintenance of the EM condition was not “in accordance with the law” for the purposes of
Article 8. Lord Reed said as follows:

“113. As long ago as 1984, the court said in _Malone v United Kingdom EHRR 14, in the context of_
surveillance measures, that the phrase “in accordance with the law” implies that “the law must . . . give the
individual adequate protection against arbitrary interference”: para 68. In _Kopp v Switzerland (1998) 27_
EHRR 91, para 72, it stated that since the surveillance constituted a serious interference with private life
and correspondence, it must be based on a “law” that was particularly precise: “It is essential to have clear,
detailed rules on the subject, especially as the technology available for use is continually becoming more
sophisticated.” These statements were reiterated in _Amann v Switzerland 30 EHRR 843.  As I have_
explained, that approach to the question whether the measure provides sufficient protection against
arbitrary interference was applied, in the context of criminal records and other intelligence, in _Rotaru v_
_Romania, where the finding that the interference was not “in accordance with the law” was based on the_
absence from the national law of adequate safeguards. The condemnation of Part V of the 1997 Act in MM
_v United Kingdom is based on an application of the same approach. Put shortly, legislation which requires_
the indiscriminate disclosure by the state of personal data which it has collected and stored does not
contain adequate safeguards against arbitrary interferences with article 8 rights.

114.  This issue may appear to overlap with the question whether the interference is “necessary in a
democratic society”: a question which requires an assessment of the proportionality of the interference.
These two issues are indeed inter-linked, as I shall explain, but their focus is different. Determination of
whether the collection and use by the state of personal data was necessary in a particular case involves an
assessment of the relevancy and sufficiency of the reasons given by the national authorities. In making that
assessment, in a context where the aim pursued is likely to be the protection of national security or public
safety, or the prevention of disorder or crime, the court allows a margin of appreciation to the national
authorities, recognising that they are often in the best position to determine the necessity for the
interference. As I have explained, the court's focus tends to be on whether there were adequate
safeguards against abuse, since the existence of such safeguards should ensure that the national
authorities have addressed the issue of the necessity for the interference in a manner which is capable of
satisfying the requirements of the Convention. In other words, in order for the interference to be “in
accordance with the law”, there must be safeguards which have the effect of enabling the proportionality of


-----

the interference to be adequately examined. Whether the interference in a given case was in fact
proportionate is a separate question.”

230. Mr Buttler submitted that, in relation to the imposition and maintenance of EM conditions, the duties
to provide reasons and to conduct quarterly reviews were part of the safeguards of the kind to which Lord
Reed referred. He further submitted that it followed that, if those safeguards were not observed in a
particular case, then the interference with the individual's Article 8 rights which the EM condition involved
was not “in accordance with the law”. I do not consider that Lord Reed's judgment in _T provides any_
support for that latter submission and Mr Buttler did not provide any other authority for it.

231. As I have already said, an interference with an Article 8 right will only be “in accordance with the law”
if two requirements are satisfied, i.e. it is lawful under national law and the national law is clear,
foreseeable, and adequately accessible. As I understand it, the relevant paragraphs of Lord Reed's
judgment were directed to the second, “quality of law” requirement, but Mr Buttler made clear that he was
not alleging that the relevant provisions of English law failed to meet that requirement. I am not aware of
any authority for a third requirement along the lines proposed by Mr Buttler.

**_(12)(e) Issue 3: Decision_**

_(12)(e)(i) Issue 3: Failure to Conduct Quarterly Review in Time_

232. In relation to the question whether a failure to conduct a quarterly review of an EM condition on time
is a breach of public law which renders the continuation of the EM condition unlawful, the parties agreed
that I was obliged to follow Nelson unless I was convinced that it was wrong or that there was a powerful
reason for not following it. I am not convinced that Nelson was wrong. Nor am I convinced that there is a
powerful reason for not following it.

233. In particular, while I accept that the imposition of an EM condition is a less significant interference
with a person's Convention rights than detention, I do not consider that the difference between the two is
sufficient to disapply the reasoning in Kambadzi and O. The statutory scheme in the present case differs
from that considered in those cases, but they have several important features in common, such that the
quarterly reviews are fundamental to the propriety of continuation of the EM condition.

234. I consider that, adapting the words used by Lord Wilson in _O, the mandate to impose an EM_
condition conferred by sub-paragraph 2(3)(a) of Schedule 10, the power to impose an EM condition
conferred by sub-paragraph 2(1)(e) of Schedule 10 and the mandate to retain an EM condition imposed by
sub-paragraph 7(2)(a) of Schedule 10 are subject to two conditions. The first condition is that the
defendant does not consider that it would be either impractical or contrary to the person's Convention rights
for the person to be, or to continue to be, subject to the EM condition. The second condition is that the
defendant will consider in accordance with his policy whether the duty not to impose, or to remove, the EM
condition has arisen under sub-paragraph 2(6) or 7(2)(b) of Schedule 10. Were either condition not to be
satisfied, the mandate or power would cease and the EM condition would become unlawful.

235. I do not consider that sub-paragraph 7(2)(a) of Schedule 10 precludes this conclusion. A failure to
conduct a quarterly review in time is not a decision to remove the EM condition, but an unlawful failure to
operate the policy which is intended to give effect to sub-paragraph 7(2) of Schedule 10.

236. I do not consider that sub-section 31(2A) of the Senior Courts Act 1981 obliges me to reach any
different conclusion. That subsection concerns the availability of relief, but I am not concerned at this
stage in the proceedings with the relief, if any, to be granted to any of the claimants and I say nothing in
this judgment about the issue of relief. I note that subsection 31(3D) of the Senior Courts Act 1981 can
result in the refusal of permission to apply for judicial review, as in O, but the claimants in this case have
been given permission to apply for judicial review on the ground addressed by issue 3.

_(12)(e)(ii) Issue 3: ADL and PER: Failure to Consider_

237. ADL's case was a non-deportation case, so the defendant was not under a duty to impose an EM
condition. However, in both ADL's and PER's case the defendant was under a duty not to impose an EM
condition if he considered that imposing an EM condition would be impractical or contrary to the person's


-----

Convention rights.  In order to ensure that he complied with that duty, the defendant had to consider
whether imposing an EM condition on ADL or PER would be impractical or contrary to ADL's or PER's
Convention rights. Mr Murray has explained the defendant's policy for considering this question in both
deportation and non-deportation cases. I have found that that policy was not complied with.

238. In addition, the defendant's policy is that representations should be considered. A failure to comply
with that policy is unlawful. The question for present purposes is whether the decision to impose an EM
condition in ADL's and PER's case was rendered unlawful by the defendant's failure: to consider whether
imposing an EM condition on ADL or PER would be impractical or contrary to their Convention rights;
and/or to consider ADL's representations.

239. I consider that both of these failures made it unlawful for the defendant to impose an EM condition in
ADL's case and that the first of these failures made it unlawful for the defendant to impose an EM condition
in PER's case. The decision whether or not to impose an EM condition required consideration of whether it
would be either impractical or contrary to ADL's or PER's Convention rights for ADL or PER to be subject
to an EM condition. Consideration of that question required consideration of the representations made on
ADL's behalf. The defendant's failure to consider that question and his failure to consider those
representations are each akin to the failure in _O to consider whether O's mental illness could be_
satisfactorily managed in detention.

240. The approach adopted in _Kambadzi was that any unlawfulness lasted until the relevant public law_
breach was remedied. I will hear further submissions on this issue if necessary, but it appears that, on this
basis, the EM condition remained unlawful on this ground from its imposition: until 12 August 2022 in ADL's
case, when the defendant responded to Duncan Lewis' further representations; and until 18 November
2022 in PER's case, when the EM condition was first reviewed.

_(12)(e)(iii) Issue 3: ADL and BNE: Failure to give Reasons_

241. _Lee-Hirons demonstrates that, depending on the context, even detention may not be rendered_
unlawful by a failure to give reasons for a decision. I do not consider that the context in the present case
requires a conclusion that a failure to give reasons for imposing an EM condition renders that condition
unlawful. In the words of Lord Dyson in Lumba, I do not consider that a breach of the public law duty to
give reasons bears on or is relevant to the decision to impose or to maintain an EM condition. The duty to
give reasons arises after such a decision has been made. Accordingly, I conclude that the failure to give
reasons for the decision to impose an EM condition in ADL's and BNE's case did not render the EM
condition unlawful.

**(13) Issue 4: Necessity and Proportionality in BNE's and ADL's cases**

242. I have found that the EM condition in ADL's case was unlawful from its imposition until 12 August
2022. It follows that it is not necessary for me to address issue 4 in his case in respect of that period.
However, it may be helpful for me to indicate what I would have decided if it had been necessary for me to
do so.

243. Assuming (as I have decided in BNE's case, but not in ADL's case in respect of the period to 12
August 2022) that the interference with their Article 8 rights was “in accordance with the law”, BNE and
ADL accepted that it pursued a legitimate aim, but contended that it was not “necessary in a democratic
society”. It is therefore appropriate to consider the four questions set out by Lord Reed in Bank Mellat v
_Her Majesty's Treasury (No 2) [2014] AC 700(“Bank Mellat”), namely;_

“(1) whether the objective of the measure is sufficiently important to justify the limitation of a protected right,
(2) whether the measure is rationally connected to the objective, (3) whether a less intrusive measure
could have been used without unacceptably compromising the achievement of the objective, and (4)
whether, balancing the severity of the measure's effects on the rights of the persons to whom it applies
against the importance of the objective, to the extent that the measure will contribute to its achievement,
the former outweighs the latter.”


-----

244. No issue arises in relation to questions (1) and (2). Mr Buttler accepted that the objectives of
preventing absconding and preventing offending were weighty ones which justified limiting a fundamental
right and that EM conditions were rationally connected to those objectives.

245. As to the approach to questions (3) and (4), it is appropriate to have regard to: what Lord Bingham
said in paragraph 16 of his speech in Huang v Secretary of State for the Home Department [2007] 2 A.C.
167and in paragraph 30 his speech in R (SB) v Governors of Denbigh High School [2007] 1 AC 100; what
Lord Wilson said in paragraph 46 of his judgment in _R (Quila) v Secretary of State for the Home_
_Department [2012] 1 AC 621; and what Lord Reed said in paragraph 75 of his judgment in Bank Mellat. I_
need not set out these familiar passages.

246. In general terms, Mr Buttler submitted that, when considering the proportionality of EM conditions:

(1) There is no evidence of how effective or ineffective EM conditions are in preventing absconding or
offending. He prayed in aid the statement in version 2.0 of the Pilot Guidance that the data collected by
the 12 month stage of the pilot did not provide sufficient evidence to establish whether the use of electronic
monitoring was an effective tool for contact management.

(2) The rate of absconding by individuals on immigration bail is low. The information provided in response
to certain freedom of information requests was that in 2021 only 2.7% of individuals on immigration bail
absconded, while in 2022 the figure was 1.3%.

(3) There is evidence that EM conditions have a significant adverse effect on the individuals concerned.

247. Mr Vinall's general submissions were that GPS monitoring has real benefits which cannot be
achieved by other bail conditions. In particular, it can disclose the actual location of someone who fails to
comply with a reporting requirement or a residence requirement or who is suspected of committing a crime.
The knowledge that it can do this can act as a deterrent to absconding or offending. These features of EM
conditions mean that they are frequently relied on by First-tier Tribunal Judges when granting immigration
bail, which I take to mean that First-tier Tribunal Judges grant immigration bail because they can impose
an EM condition in cases in which they might not otherwise have granted immigration bail.

248. Mr Vinall rightly submitted that the defendant's decisions fell to be assessed by reference to the
evidence available to the defendant at the time when each decision was taken.

**_(12)(a) Issue 4: Necessity and Proportionality in BNE's case_**

249. The first question in BNE's case is whether it was a violation of his Article 8 rights to impose an EM
condition when he was first granted immigration bail. I do not consider that it was. There was at that stage
no evidence which specifically addressed the question whether the imposition of an EM condition on him
would have a disproportionate impact on him. It was consistent with the Bail Guidance (which, as I have
said, was not criticised in this case) for the defendant to require such evidence in a case where it was
alleged that an EM condition would cause serious harm to the person's mental or physical health or in a
case where a person's claim to be a victim of modern slavery had received a positive conclusive grounds
decision. (BNE had received a positive reasonable grounds decision.)

250. Mr Buttler submitted that there were available alternatives to an EM condition which could have been
used without unacceptably compromising the achievement of the objective of the EM condition. He
suggested that BNE's mother could have been asked either to “keep an eye on” BNE or to use a non-fitted
device. However, it does not appear that non-fitted devices were available at that time and it is difficult to
see how a request to BNE's mother could be formulated as a bail condition.

251. Alternatively, Mr Buttler submitted that the EM condition had become disproportionate by 26 August
2022, when the first quarterly review should have been conducted, but the only basis for this submission
was that BNE had by then complied with the EM condition for 3 months. I do not consider that that factor
made the EM condition disproportionate.

252. On 5 September 2022 Duncan Lewis sent to the defendant a copy of Ms Davies' addendum report of
25 August 2022, which the defendant treated as representations requiring a response. In that report, Ms


-----

Davies expressed the opinion that it was highly likely that further deterioration in BNE's mental health
would result from being subject to constant surveillance, i.e. from the continuation of the EM condition.
That was the evidence which led the defendant to announce on 7 November 2022 that the defendant had
decided that BNE's EM condition should cease.

253. Given that the defendant's own assessment was that the EM condition should be removed, which the
defendant could only do if the defendant considered that the continuation of the EM condition would be a
violation of BNE's Convention rights, it appears to be accepted by the defendant that the EM condition had
by 7 November 2022 become disproportionate as a result of the information contained in the addendum
report provided to the defendant on 5 September 2022.

254. Moreover, the evidence for that conclusion had been provided to the defendant on 5 September
2022. I will, if necessary, hear further submissions on this point, since it was not fully argued in the
hearing, but my provisional view is that the EM condition in BNE's case became unlawful at some point in
the period between 5 September and 7 November 2022, on the basis that:

(1) The defendant was entitled to a reasonable period of time in which to consider that evidence.

(2) On the other hand, as the Bail Guidance states, representations must be considered and responded to
in a timely manner.

(3) 62 days was a long time in which to respond to BNE's representations.

(4) The Bail Guidance mentions a period of 28 days. It may be that the EM condition in BNE's case was
unlawful from 3 October 2022.

**_(4)(b) Issue 4: Necessity and Proportionality in ADL's case_**

255. I do not consider that it was disproportionate to impose an EM condition on ADL on 14 July 2022.
ADL's was not a deportation case. He was not someone who had been convicted of a criminal offence.
The defendant knew that ADL claimed to have been tortured and that it had been decided that there were
reasonable grounds to conclude that he was a victim of trafficking, but there was at that stage no medical
evidence that an EM condition would have a significant effect on his mental or physical health. Duncan
Lewis acknowledged this in their representations of 13 July 2022 and said that a medical report was shortly
to be prepared. Pending that, they said that requiring ADL to wear a fitted device carried the risk of retraumatising him.

256. Mr Buttler submitted that an EM condition requiring ADL to use a non-fitted device would have been
an adequate alternative, but, as I have said, it does not appear that those devices were available at the
relevant time.

257. In my judgment, it was disproportionate to maintain the EM condition after receipt and consideration
of Dr Galappathie's report of 25 July 2022. Dr Galappathie's evidence was that, although some symptoms
had reduced since ADL's release from detention, others had been exacerbated by the EM condition and
that overall his mental health condition had deteriorated as a result of the EM condition. The defendant in
his letter of 12 August 2022 focused on the acknowledgement that some symptoms had improved without
placing that point in the context of Dr Galappathie's overall opinion.

258. Moreover, the defendant placed reliance in his letter of 12 August 2022 on the possibility of treatment
improving ADL's condition, without acknowledging Dr Galappathie's opinion that both the EM condition and
the possibility of being removed to Rwanda would prevent ADL taking part in therapy.

259. As to the other matters addressed in the defendant's letter:

(1) The fact that ADL had arrived in the United Kingdom clandestinely was clearly relevant to the
assessment of his risk of absconding.

(2) So too was the fact that he had been told that he might be removed to Rwanda, since that provided an
incentive to abscond and was clearly a matter of concern to ADL.


-----

(3) On the other hand, the defendant was wrong to say that ADL had not provided an explanation for his
failure to report on 20 July 2022 (which was the first of only two occasions on which ADL had been obliged
to report before 12 August 2022). In that respect, the defendant's assessment of ADL's compliance with
his reporting requirement, as part of his assessment of ADL's risk of absconding, was flawed. I do not
consider that I can simply dismiss that point, as Mr Vinall suggested.

260. I conclude that the EM condition in ADL's case was unlawful on this ground from 12 August 2022.

261. In those circumstances, it is not necessary for me to decide an alternative submission made by Mr
Buttler, which concerned the period from 11 to 31 October 2022. The submission was that, if there had
been no violation of Article 8 prior to 11 October 2022, when the defendant said that the EM condition
would be removed, there was a violation thereafter because of the time taken to remove the fitted device.
I do not propose to say any more about this submission because it was not made in the statement of facts
and grounds or in the claimants' skeleton argument and, perhaps for that reason, was not squarely
addressed in the defendant's evidence. Consequently, I am not sure that all of the relevant evidence was
before me as to what, if anything, was being done with a view to removing ADL's device after 11 October
2022.

**(14) Issue 5: Individual Decisions on Trail Data Retention?**

262. It is not disputed that the retention and use of trail data constitutes an interference with the
individual's Article 8 rights. Nor is it disputed that Schedule 10 provides implied statutory authority to retain
the data for as long as is reasonably required to achieve the statutory purposes. This follows, in particular,
from paragraph 4(1) of Schedule 10, which gives express authority for not only “detecting”, but also
“recording”, trail data.

263. However, Mr Buttler submitted that the defendant's policy of retaining trail data for 6 years after the
data ceases to be recorded is unlawful because it is a blanket decision as to how to exercise the power to
retain in all cases, which is a fettering of the defendant's discretion and converts the power into a duty, in
breach of the “British Oxygen principle”: see _British Oxygen Co v Minister of Technology [1971] AC_
610(“British Oxygen”). Mr Buttler submitted that the defendant is obliged to make an individual decision in
the case of every person subject to an EM condition, when they cease to be subject to an EM condition,
whether to retain their trail data and, if so, for how long.

264. Mr Buttler relied on British Oxygen, but he did not take me to the speech by Lord Reid in that case
which established the _British Oxygen_ principle. At page 625B-C of his speech, Lord Reid quoted the
following passage from Bankes LJ's judgment in _Rex v. Port of London Authority, Ex parte Kynoch Ltd._

[1919] 1 K.B. 176(“Kynoch”), at 184:

“There are on the one hand cases where a tribunal in the honest exercise of its discretion has adopted a
policy, and, without refusing to hear an applicant, intimates to him what its policy is, and that after hearing
him it will in accordance with its policy decide against him, unless there is something exceptional in his
case. I think counsel for the applicants would admit that, if the policy has been adopted for reasons which
the tribunal may legitimately entertain, no objection could be taken to such a course. On the other hand
there are cases where a tribunal has passed a rule, or come to a determination, not to hear any application
of a particular character by whomsoever made. There is a wide distinction to be drawn between these two
classes.”

265. Lord Reid then said as follows, at page 625D-E:

“I see nothing wrong with that. But the circumstances in which discretions are exercised vary enormously
and that passage cannot be applied literally in every case. The general rule is that anyone who has to
exercise a statutory discretion must not “shut his ears to an application” (to adapt from Bankes L.J. on p.
183). I do not think there is any great difference between a policy and a rule. There may be cases where
an officer or authority ought to listen to a substantial argument reasonably presented urging a change of
policy. What the authority must not do is to refuse to listen at all. But a Ministry or large authority may have
had to deal already with a multitude of similar applications and then they will almost certainly have evolved
a policy so precise that it could well be called a rule There can be no objection to that provided the


-----

authority is always willing to listen to anyone with something new to say—of course I do not mean to say
that there need be an oral hearing. …”

266. I do not consider that it follows from either of these dicta that the defendant's policy in the present
case is unlawful. The defendant is prepared to consider applications for trail data to be deleted and has in
some cases deleted trail data.

267. In one of his responses to a part 18 request, the defendant said as follows:

“To date, the only cases in which data has been deleted prior to 6 years are cases where the Defendant
has concluded that there was some unlawfulness in the imposition of EM (as in the cases of ADL and (in
part) Mr Dos Reis). The Defendant does not presently envisage other circumstances in which a request to
delete trail data prior to 6 years would be acceded to.”

268. I agree with Mr Gullick's submission that the words “does not presently envisage” are not to be read
as meaning “has closed his mind to the possibility that”.

269. The authority to which Mr Buttler did refer me, namely R v Hampshire County Council, ex parte W

[1994] ELR 460 (“W”) does not add anything. He relied on the following dictum of Sedley J, at pages 4756:

“The difficulty arises, I think, because it is not always appreciated that in this area two principles come into
conflict. An authority with the broad discretions created under s 81 of the 1944 Act and s 6(1) of the 1953
Act would be acting arbitrarily if it decided one case after another with no discernible rationale or
consistency as between applicants. It is to enable a public authority to guard against such arbitrariness that
the law recognises the wisdom and acceptability of having a policy for the exercise of administrative
discretions, especially those which involve the disbursement of public funds in favour of individuals. But
public law is also jealous to guard the discretion which a permissive power carries with it, and discretion is
negated if an inflexible rule is adopted for the exercise of the power. This is why British Oxygen Company v
_Minister of Technology lays down principles which permit, and indeed encourage, the adoption of a policy_
but forbid the decision-maker to allow the policy to ossify. This had happened in R v Hampshire Education
_Authority ex parte J because the two exceptions, being in themselves rigid and exclusive, were simply_
subsets of a rigid rule.

What is required by the law is that, without falling into arbitrariness decision-makers must remember that a
policy is a means of securing a consistent approach to individual cases, each of which is likely to differ
from others. Each case must be considered, therefore in the light of the policy but not so that the policy
automatically determines the outcome.”

270. It is appropriate also to have regard to the different context in which those cases were decided.
_Kynoch concerned an application for permission to construct a wharf._ _British Oxygen and_ _W each_
concerned applications for grants. Applications of that nature call for an individual decision on each
application. In the present case, where an application, or request, is made for the deletion of trail data, the
defendant will make a decision on that application.

271. Accordingly, I conclude that the defendant is not obliged to make an individual decision in the case of
every person subject to an EM condition whether to retain their trail data and, if so, for how long.

272. In the course of his submissions, I asked Mr Buttler what circumstances, other than the unlawfulness
of an EM condition, might make it appropriate for an individual's trail data to be deleted. He submitted that
the revocation of a deportation order, as in Mr Dos Reis' case, would be such a circumstance. I will
consider that issue in the context of issue 7.

**(15) Issue 6: The Use of Trail Data**

273. Mr Buttler submitted that, assuming that it was lawful for the defendant to retain trail data in a
particular case, it was unlawful for the defendant to use that trail data for the purpose of responding to any
representations made under Article 8 or further submissions made by the subject of the EM condition. Mr


-----

Duffy's evidence was that the defendant has so far not used any trail data in any case for this purpose, but
his policy is that he would, or might, do so if the situation arose.

274. I am concerned that issue 6 is a hypothetical issue in the present case and would be better
addressed in a case in which it is a real issue, if such a case arises. However, the claimants have been
given permission to apply for judicial review on this ground and therefore I propose to address it.

275. It seems to me that I have to assume for this purpose that there may be a case in which an individual
makes representations under Article 8 or makes further submissions which contain a claim or claims which
is or are capable of being either verified or shown to be false by reference to the trail data which was
collected when he was subject to an EM condition. I do not regard that as a fanciful assumption. Many
individuals who are liable to deportation or removal make representations under Article 8 and/or further
submissions.  Experience shows that they can make claims which are true and claims which are false. I
do not doubt that, in some cases, trail data can assist in distinguishing between true and false claims.
Examples which were suggested in the course of argument were a claim that the individual had regularly
been living with his partner and/or taking his children to school.

276. I did not understand it to be disputed that the defendant needs statutory authority to make use of trail
data for such a purpose in such a case. The only potential source of that authority is Schedule 10. The
issue arises because Schedule 10 does not expressly address the use which can be made of trail data.
Thus:

(1) Sub-paragraph 2(1)(e) of Schedule 10 gives the defendant the power to impose an EM condition. This
is not a power, but a duty, in cases to which sub-paragraph 2(3)(a) applies and sub-paragraph 2(5) does
not apply.

(2) Sub-paragraph 4(1) of Schedule 10 defines an EM condition as meaning a condition requiring the
person on whom it is imposed to co-operate with such arrangements as the defendant may specify for
“detecting and recording by electronic means” the person's location etc.

(3) Schedule 10 says nothing about the use which may be made of data which is detected and recorded in
this way, but the claimants accept that it is a necessary implication of sub-paragraph 4(1) that some use
can be made of the data recorded.

277. However, Mr Buttler submitted that it could not be implied from Schedule 10 that the defendant had
the power to use trail data in responding to any representations made under Article 8 or further
submissions made by the subject of the EM condition. He relied in that context on section 11.5 of Bennion,
_Bailey and Norbury on Statutory Interpretation (2020) 8[th] Edn and the cases referred to therein, especially_
paragraph 45 of Lord Hobhouse's speech in R (on the application of Morgan Grenfell & Co Ltd) v Special
_Commissioners of Income Tax [2003] 1 AC 563._

278. The issues between the parties in this respect included:

(1) whether the relevant statutory purpose was immigration control in a broad sense or facilitating removal
in a narrower sense;

(2) if the narrower sense was the relevant one, whether responding to representations made under Article
8 or further submissions was part of facilitating removal; and

(3) whether the use which could be made of trail data was limited to the reasons for its collection and
retention.

[279. The parties did not refer me to any provision of the Immigration Act 2016 as indicating the purposes](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
of Schedule 10. The preamble to the Act does not assist, but I consider that some assistance can be
derived from paragraph 3(2) of Schedule 10, which lists matters to which the Secretary of State or First-tier
Tribunal must have regard when determining the conditions to which a person's immigration bail is to be
subject. It was not disputed that bail conditions, including EM conditions, serve the purpose of preventing
absconding, preventing the commission of offences and preventing the causing of harm. However, sub

-----

paragraph 3(2)(ea) also provides that, when determining the conditions to which a person's immigration
bail is to be subject, regard must be had to:

“whether the person has failed without reasonable excuse to cooperate with any process
(i)  for determining whether the person … should be granted leave to … remain in the United Kingdom,

…

(iv)  for determining whether the person should be removed from the United Kingdom, or

(v)  for removing the person from the United Kingdom,”

280. This suggests that the purposes of Schedule 10 include preventing non-cooperation with the
immigration control processes identified. Those processes include the consideration of representations
under Article 8 or further submissions, which are processes “for determining whether the person … should
be granted leave to … remain in the United Kingdom” and “for determining whether the person should be
removed from the United Kingdom”. Moreover, a form of non-cooperation with such a process is to make
false claims in the context of that process.

281. As I have said, the claimants accept that it is a necessary implication that some use can be made of
the trail data collected in respect of an individual. In my judgment, what is to be implied is that the data
may be used for the purposes of Schedule 10. I see no basis for limiting the implied authority to use the
trail data to some purposes, but not others.

282. It may well be, as Mr Buttler submitted, that an EM condition would never be imposed for the sole
purpose of gathering data for use in responding to any representations made under Article 8 or further
submissions made by the subject of the EM condition, but what are relevant, in my judgment, are the
purposes of Schedule 10, rather than the reasons why individual bail conditions are imposed.

283. In those circumstances, I conclude that it would be lawful for the defendant to use trail data which
had been lawfully collected and retained for the purpose of responding to any representations made under
Article 8 or further submissions made by the subject of the EM condition.

**(16) Issue 7: The Proportionality of Trail Data Retention**

284. Mr Dos Reis, ADL and BNE contend that the retention of their trail data is, or was, contrary to their
Article 8 rights. In summary, their contentions are as follows:

(1) Mr Dos Reis submits that he is no longer subject to immigration control, since the deportation order
made in his case has been revoked and his indefinite leave to remain has been reinstated. He submits
that it follows that the statutory purpose of Schedule 10 has ceased to apply to him and, consequently:

(a) the retention of his trail data is no longer justified under English law and therefore is not “in accordance
with the law” for the purposes of Article 8; or

(b) the retention of his trail data no longer pursues a legitimate aim for the purposes of Article 8; or

(c) the retention of his trail data is disproportionate and is not “necessary in a democratic society” for the
purposes of Article 8.

(2) ADL's trail data was deleted on 11 May 2023, but ADL submits that it was unlawful for his trail data to
be retained from 14 July 2022 (when the EM condition was first imposed) to 11 May 2023.

(3) BNE contends that, if and insofar as the EM condition imposed on him was unlawful, then the retention
of his trail data was unlawful.

**_(16)(a) Issue 7: Mr Dos Reis_**

285. I do not consider that there was any good reason to retain Mr Dos Reis' trail data after the deportation
order in his case had been revoked. From that point onwards, the defendant was not seeking to deport Mr
Dos Reis. The implied authority to retain his trail data conferred by Schedule 10 expired.


-----

286. It may be that the defendant was entitled to a reasonable, but short, period of time after the
revocation of the deportation order in which to make arrangements for Mr Dos Reis' trail data to be deleted,
but that was not an issue which was raised before me and so I make no decision about it.

**_(16)(b) Issue 7: ADL_**

287. I have found that the EM condition imposed on ADL was unlawful from the outset. It follows that it
was unlawful for the defendant to collect or retain ADL's trail data.

**_(16)(c) Issue 7: BNE_**

288. There is no issue for me to decide in relation to BNE, since the defendant accepts that he should
delete BNE's trail data for any period during which BNE's EM condition was unlawful.

**(17) Duty of Candour**

289. In submissions made on 23 April 2024, which developed, in the light of the further disclosure made
on 18 April 2024, submissions which had been made at the hearing, the claimants invited me to find that
the defendant had breached his duty of candour and cooperation. I do not propose to make a finding on
that issue.

**(18) Summary**

290. In summary, I have decided as follows:

_Issue 1(a)_

(1) The defendant failed, when granting immigration bail, to consider whether imposing an EM condition
on ADL or PER would be either impractical or contrary to ADL's or PER's Convention rights.

_Issue 1(b)_

(2) The defendant was not under a duty to give reasons for his decision to impose an EM condition on
PER.

(3) The defendant failed in his duty to give reasons for his decision to reject BNE's representations.

(4) The defendant failed in his duty to give reasons for his decision to impose an EM condition on ADL.

_Issue 2_

(5) I refuse permission to Mr Dos Reis, BNE and PER to amend their statement of grounds so as to
challenge the defendant's failure to conduct their quarterly reviews in time. (Had I granted permission, I
would have held that there was no good reason for this departure from the defendant's policy.)

_Issue 3_

(6) The EM condition imposed on ADL was unlawful from its imposition until 12 August 2022, and
therefore not “in accordance with the law” for the purposes of Article 8, by reason of the defendant's failure:
(a) to consider whether imposing an EM condition would be impractical or contrary to ADL's Convention
rights; and (b) to consider ADL's representations.

(7) The EM condition imposed on PER was unlawful from its imposition until 18 November 2022, and
therefore not “in accordance with the law” for the purposes of Article 8, by reason of the defendant's failure
to consider whether imposing an EM condition would be impractical or contrary to PER's Convention rights.

(8) The defendant's failure to give reasons for imposing an EM condition on BNE and ADL did not render
the EM condition imposed on either of them unlawful and it was therefore “in accordance with the law” for
the purposes of Article 8.

_Issue 4_

(9) The EM condition in ADL's case was unlawful from 12 August 2022 because it was no longer
“necessary in a democratic society”.


-----

(10) Subject to further argument, the EM condition in BNE's case became unlawful at some point between
5 September and 7 November 2022 because it was no longer “necessary in a democratic society”.

_Issue 5_

(11) The defendant is not obliged to make an individual decision in the case of every person subject to an
EM condition whether to retain their trail data and, if so, for how long.

_Issue 6_

(12) It would be lawful for the defendant to use trail data which had been lawfully collected and retained for
the purpose of responding to any representations made under Article 8 or further submissions made by the
subject of the EM condition.

_Issue 7_

(13) The defendant was not entitled to retain Mr Dos Reis's trail data after the deportation order in his case
had been revoked.

(14) The defendant was not entitled to retain ADL's trail data, because his EM condition was at all times
unlawful.

291. I express my gratitude to all counsel and solicitors for their hard work in the preparation and
presentation of this case. Their thorough, but concise, exploration of a wide range of issues has been of
great assistance to me.

**End of Document**


-----

