(on the application of Brighton and Hove City Counci....

# R (on the application of Every Child Protected Against Trafficking UK) v Kent County Council and another; R (on the application of Brighton and Hove City
 Council) v Secretary of State for the Home Department; R (on the application
 of Kent County Council ) v Secretary of State for the Home Department

 [2023] EWHC 1953 (Admin)

King's Bench Division (Administrative Court)

The Hon. Mr Justice Chamberlain

27 July 2023Judgment

**Martin Westgate KC, Shu Shin Luh** and Antonia Benfield (instructed by Freshfields Bruckhaus
**Deringer LLP) for ECPAT UK**

**Stephanie Harrison KC,** **Ollie Persey and** **Georgina Rea (instructed by Bhatt Murphy Solicitors)** for
**Brighton and Hove City Council**

**Hugh Southey KC and Azeem Suterwalla (instructed by Bevan Brittan LLP) for Kent County Council**

**Deok Joo Rhee KC and** **Benjamin Tankel (instructed by** **Government Legal Department) for** **the**
**Secretary of State for the Home Department and the Secretary of State for Education**

Hearing dates: 20 and 21 July 2023

- - - - - - - - - - - - - - - - - - - - 
**APPROVED JUDGMENT**

**Mr Justice Chamberlain:**

**Introduction**

1 Ensuring the safety and welfare of children with no adult to look after them is among the most
fundamental duties of any civilised state. In the United Kingdom, this duty is imposed on local authorities.
They discharge it in a variety of ways, depending on the needs of the child concerned, for example, by
placing children with foster parents or in registered children's homes or other appropriate accommodation
under the supervision of a social worker. The common feature of these arrangements is that the children
are, to use the statutory term, “looked after”, and not simply given a roof over their head. A detailed
legislative regime requires the local authority, as “corporate parent”, to assess each child's social,
educational and health needs and make plans to meet them.

2 In recent years, large numbers of unaccompanied children have arrived in the UK and claimed asylum,
most having crossed the Channel in small boats. They are referred to as unaccompanied asylum-seeking
children or, as the parties have called them, “UASC”. Acronyms can be helpful, but they can also divert the
reader's attention from something important. I shall refer to these children as “UAS children”. All have
travelled long distances. Some have been abused or mistreated in their country of origin or on their journey


-----

(on the application of Brighton and Hove City Counci....

here. Some are victims of human trafficking. Many speak little or no English and are ill-equipped to
navigate life as an asylum-seeker in the UK. As a cohort, they are especially vulnerable.

3 Because almost all of these children enter the UK in Kent, the local authority responsible for
accommodating and looking after them in the first instance is Kent County Council (“Kent CC”). Like every
other local authority, Kent CC is also responsible for looking after children who already live in its area.
Looking after children in care is resource intensive. There are limited numbers of social workers. At various
times, the numbers of children in Kent CC's care have reached what it considers to be the limit at which its
children's services can continue to operate safely. It has responded by announcing that it will no longer
accept newly arriving UAS children into its care, while continuing to accept other children.

4 The last such announcement was on 11 June 2021. The Education Secretary then considered whether
to exercise the power to direct Kent CC to comply with its statutory duties and Kent CC threatened judicial
review proceedings against the Home Secretary. After an exchange of correspondence, the Education
Secretary decided not to make such a direction and Kent CC decided not to bring proceedings. In
September 2021, Kent CC and the Home Secretary agreed a protocol (“the Kent Protocol”), which sets out
how Kent CC will deal with UAS children in the future. It has never been published but was disclosed in the
course of this litigation.

5 The Kent Protocol reflected and formalised the establishment of a new Reception and Safe Care Service
(“RSCS”), partly funded by the Home Secretary. Through the RSCS, Kent CC agreed to accept a capped
number of UAS children into its care pending their transfer to other local authorities under the National
Transfer Scheme (“NTS”), a scheme made by the Home Secretary under s. 72(1) of the Immigration Act
2016 (“the 2016 Act”) for the transfer of social services functions between local authorities. The NTS itself
operates according to a protocol (“the NTS Protocol”).

6 The Home Secretary responded to Kent CC's “derogation” from its statutory duties by commissioning
hotels to accommodate UAS children outside the care system altogether. The use of hotels started in July
2021, before the Kent Protocol was agreed, and has continued ever since. In total, more than 5,400 UAS
children have been accommodated in hotels, of whom 32% were under 16. Some 1,700 were housed at
Langfords Hotel in Hove. The remainder were sent to other hotels in Kent, East Sussex, London,
Oxfordshire and Warwickshire. The children remain in hotels while a local authority is found that is
prepared to offer them a placement under the NTS. While in these hotels, the children are offered some
support in addition to accommodation and food, but they are not “looked after” and have no “corporate
parent”.

7 Different figures were given for the average length of time spent by UAS children in hotels before
transfer to the care of a local authority. Brighton & Hove CC said in evidence that, at Langfords Hotel, the
average stay was 30 days, though a significant number were staying for as long as 60 days. The Home
Secretary's counsel said on instructions that the average stay at that hotel was in fact 23 days. Across all
hotels, the average stay has fluctuated between 9 and 20 days. Some stays are considerably longer than
these averages.

8 According to data given to Parliament on 3 April 2023, 447 UAS children had by that time gone missing
from these hotels, mostly within 72 hours of arrival; and 186 were still missing. At the time of the hearing,
154 were missing. They are mostly 16 or 17-year olds but they also include 11 children aged 15, a 14-year
old and a 12-year old. Neither Kent CC nor the Home Secretary knows where these children are, or
whether they are safe or well. There is evidence that some have been persuaded to join gangs seeking to
exploit them for criminal purposes. These children have been lost and endangered here, in the United
Kingdom. They are not children in care who have run away. They are children who, because of how they
came to be here, never entered the care system in the first place and so were never “looked after”.

9 As at 17 July 2023, 218 UAS children were being housed in hotels in Kent and elsewhere. The Home
Secretary concedes that these hotels are unsuitable for UAS children, but says there is no alternative. No
children are currently at Langfords Hotel, but the Home Secretary has said that she is “standing up” this
hotel in anticipation of further UAS children arriving in the coming days and weeks Brighton & Hove City


-----

(on the application of Brighton and Hove City Counci....

Council (“Brighton & Hove CC”), the local authority for the area, considers that Langfords Hotel is not only
unsuitable but also unsafe.

**The claims and issues**

10 There are three claims for judicial review. The first is brought by ECPAT UK (Every Child Protected
Against Trafficking) against Kent CC and the Home Secretary. The second and third are brought by Kent
CC and Brighton & Hove CC respectively, in each case against the Home Secretary as defendant. In
Brighton & Hove CC's claim, the Education Secretary and Kent CC are interested parties. In Kent CC's
claim, Brighton & Hove CC is an interested party.

11 At a directions hearing on 7 July 2023, Linden J identified certain preliminary issues common to all
claims, which he ordered to be tried on a highly expedited timetable:

(a) Whether it is unlawful for newly arrived UAS children to be accommodated by the Home Secretary in
hotels instead of in the care of the local authority where they first arrive and are physically present, pending
any transfer under s.72 IA 2016? (Issue 1)

(b) Whether the Home Secretary is unlawfully failing to comply with s. 72 IA 2016 in that:

(i) it does not confer a power to commission the use of hotels to accommodate relevant children outside
[the statutory Children Act 1989 (“CA 1989”) framework or to create an NTS Protocol that permits such an](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)
arrangement, where relevant children will not be “in the care of a local authority”?

(ii) it provides the power to prepare a scheme for transfer of functions and responsibility of relevant
children between local authorities, and does not permit a scheme whereby the SSHD transfers relevant
children from a local authority that has not exercised its functions or responsibilities to the area of another
local authority?

[(iii) it cannot be exercised to absolve a local authority from performing any part of its CA 1989 functions](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
and responsibilities toward a relevant child?

(iv) by failing to exercise her power under s. 72 IA 2016 to implement a scheme which clearly directs local
authorities who have a UASC population below their 0.1% threshold to accept the transfer of UASC in a
[timely manner, the Home Secretary is acting contrary to the statutory purpose of the IA 2016 and/or the CA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
_[1989 and/or in a manner which frustrates the statutory purpose (Padfield v Ministry of Agriculture [1968]](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
AC 997)?

(Issue 2)

(c) Whether the Home Secretary is unlawfully failing to comply with the express terms of the NTS Protocol
including in respect of the requirement to transfer a child from one local authority to another within 10
working days? (Issue 3)

(d) Whether, by accommodating relevant children in hotels she has commissioned, the Home Secretary
frustrates the statutory purpose of:

(i) ss. 69-73 IA 2016?

[(ii) the CA 1989?](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)

(Issue 4)

(e) Whether the Home Secretary is acting unlawfully in accommodating relevant children in hotels in areas
in which the relevant local authorities have already exceeded their 0.1% threshold? (Issue 5)

(f) Whether Kent CC is unlawfully failing to perform its _[CA 1989 duties by not taking into care all newly](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
arrived UAS children when notified of their presence in the area? (Issue 6)

(g) Whether the Kent Protocol, made in September 2021, is unlawful, applying the test in R (A) v Secretary
_of State for the Home Department_ _[2021] UKSC 37, [2021] 1 WLR 3931 at [46]? (Issue 7)_


-----

(on the application of Brighton and Hove City Counci....

(h) What legal powers do the Home Secretary and/or local authorities have under ss. 69-73 IA 2016
and/or the NTS Protocol to facilitate the effective operation of the NTS? (Issue 8)

12 The claims raise other issues about the Home Secretary's operation of the NTS, but their resolution will
turn on detailed evidence about what has been done on the ground and Linden J decided that it would not
be feasible to produce that evidence on such an expedited timetable.

13 The parties filed a great deal of evidence, much of it not in accordance with the procedural directions
agreed before Linden J. There was initially a dispute about whether I should admit parts of this evidence. I
made clear to the parties that it was important not to take up valuable hearing time with procedural
disputes. The parties were able to agree, and I directed, that all the evidence filed should be admitted.

14 The preliminary issues hearing took place on 20 and 21 July 2023. ECPAT was represented by Martin
Westgate KC, Shu Shin Luh and Antonia Benfield. Kent CC was represented by Hugh Southey KC and
Azeem Suterwalla. Brighton & Hove CC was represented by Stephanie Harrison KC, Ollie Persey and
Georgina Rea. The Home Secretary and Education Secretary were represented by Deok Joo Rhee KC
and Benjamin Tankel. I am grateful to all counsel and to their instructing teams for their excellent
submissions, prepared under great pressure of time.

15 Immediately before and during the hearing, those representing the Home Secretary disclosed further
documents under the duty of candour. I gave the parties permission to file brief written submissions on
these documents, and on certain other points arising at the hearing, by the morning of 24 July 2023.
Counsel and instructing teams worked over the weekend to prepare these.

16 It was agreed that the urgency of the issues was such that I should try to produce a judgment on the
preliminary issues, or such of them as I was able to determine, before the end of term. I have borne in
mind Linden J's view was that this hearing should consider only “hard-edged” points about the legality of
the current arrangements. Having seen the evidence, which was produced on the very truncated timetable
he ordered and disclosed some disputes of fact, I share and endorse his view. Further directions will be
given for the resolution of the remaining issues, if necessary.

**Summary of submissions**

17 The parties have each made extensive and detailed written and oral submissions. What follows is a
high-level summary.

18 ECPAT submits that Kent CC is in breach of its duties under the _[Children Act 1989 (“CA 1989”) to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
accommodate and look after UAS children. There are things it could have done to increase its capacity.
Instead of doing these things, it unilaterally announced that it would not discharge its statutory duties to a
particular cohort of children, defined by reference to their immigration status. This was and is unlawful,
because the duties are absolute and non-derogable. The Kent Protocol is premised upon and formalises
this breach of duty by capping the numbers of UAS children it will accept into its RSCS. The Home
Secretary acted unlawfully in agreeing the Kent Protocol and continues to facilitate Kent CC's breach of
duty by routinely accommodating UAS children in hotels, outside the care system, when she has no
statutory or other power to do so, save in a genuine emergency situation. This frustrates the purposes of
[the CA 1989. The use of hotels to accommodate children destined for the care of another local authority is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
[also contrary to the scheme of IA 2016,which contemplates transfers between local authorities and does](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
nothing to attenuate Kent CC's duties up to the point when the transfer takes effect.

19 Brighton & Hove CC adopts ECPAT's arguments and adds that the Home Secretary's practice of using
hotels is also unlawful for other reasons. The practice was begun on the understanding that the local
authority for the area in which the hotel is situated would not owe _[CA 1989 duties to the children](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
accommodated there. In fact, as the Home Secretary has belatedly recognised, the local authority does
owe such duties. The duties will invariably include a duty on the local authority to accommodate UAS
children, even where they are already in hotels – especially where the hotel is both unsuitable and unsafe,
as Brighton & Hove CC believes Langfords Hotel to be. The NTS has a carefully calibrated threshold
(c rrentl 0 1% of the total child pop lation) for identif ing the n mbers of UAS children that a local


-----

(on the application of Brighton and Hove City Counci....

authority could fairly be expected to accept. It is irrational for the Home Secretary to place UAS children in
hotels in areas where the numbers already exceed this threshold. At the very least, it is unlawful to do so
without taking into account the additional burden which these children will place on the local authority in
whose area the hotel is situated.

20 As defendant to ECPAT's claim and as claimant in its own claim against the Home Secretary, Kent CC
accepts that it has breached its statutory duty to UAS children who are physically in its area, but claims to
be in an impossible situation. It says that, if it accepted more UAS children, it would breach another equally
important duty, to ensure that the children already in its care (both UAS and others) are safe. The Kent
Protocol and the establishment of the RSCS were attempts to remedy the admitted illegality, not
perpetuate it. These attempts might well have succeeded if the Home Secretary had not failed to enforce
transfers from Kent CC to other local authorities within the 10 working day limit in the NTS Protocol. Kent
CC adds that the use of hotels in Kent is unlawful for reasons similar to those advanced by Brighton &
Hove CC.

21 The Home Secretary says that, although she has no express statutory power to accommodate UAS
children, she has a prerogative or common law power to do so, alternatively a statutory power under s. 3(5)
CA 1989, particularly where the provision of accommodation is necessary to avoid a breach of the
children's rights under Articles 2 and 3 ECHR. The Home Secretary does not accept that Kent CC was
forced to derogate from its statutory duties. It was acting unlawfully in doing so. She agreed the Kent
Protocol because the establishment of the RSCS was a step forward, but in doing so did not endorse or
accept Kent CC's continuing breach of its statutory duties. The Home Secretary accepts that hotel
accommodation is unsuitable for UAS children and that her department does not have the expertise to care
for them properly, but if Kent CC will not comply with its duties in respect of UAS children, it is better to put
them in hotels than leave them in immigration reception centres (which have no proper beds) or leave them
with no accommodation at all. There is nothing irrational about commissioning hotels in areas where the
population of UAS children exceeds 0.1% of its total child population. The burden this will place on the
local authority is not likely to be large and in any event was taken into account as one among a number of
factors relevant to the selection of hotels.

**Law, guidance, policy and protocols**

[The Illegal Migration Act 2023](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)

22 On the first day of the preliminary issues hearing, 20 July 2022, the _[Illegal Migration Act 2023 (“the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_
2023 Act”) received Royal Assent. The 2023 Act contains powers which are likely to be relevant to the
issues raised by these claims, including a power in the Home Secretary to accommodate UAS children, but
those powers have yet to be commenced and the Home Secretary says that no decision has been made
about when they will be commenced. Although the parties referred briefly to some of its provisions by way
of comparison, it is common ground that these claims fall to be decided on the basis of the powers and
duties now in force.

[The Children Act 1989](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)

23 Eligibility for many parts of the welfare state depends on the applicant's immigration status. For
example, in the _[Immigration and Asylum Act 1999 (“the 1999 Act”), s. 115 excludes those “subject to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)_
immigration control” from eligibility for certain benefits; s. 118 prevents a housing authority from granting a
[tenancy or licence under the Housing Act 1985 to most persons who require leave to enter or remain in the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJW0-TWPY-Y0XD-00000-00&context=1519360)
UK; s. 122(5) prevents local authorities from providing assistance to dependent children of asylum seekers
[in receipt of support under s. 95. In the Housing Act 1996,those who require leave to enter or remain in the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)
UK are ineligible for housing assistance (s. 160ZA(4) and (5)) or homelessness support (s. 185(3)), unless
they fall within a class prescribed by regulations (which cannot include persons “subject to immigration
[control”). In the Care Act 2014,an adult who would otherwise be eligible for care and support will not be so](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-W431-DYCN-C3MY-00000-00&context=1519360)
eligible if he or she is “subject to immigration control” and the need for care and support has arisen only
beca se the ad lt is destit te or beca se of the effects or anticipated effects of destit tion (s 21)


-----

(on the application of Brighton and Hove City Counci....

[24 It is common ground, however, that the entitlements of children under the CA 1989 do not depend on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
immigration status. It is a fundamental feature of the statutory regime of the _[CA 1989 that the duties it](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
imposes on local authorities are owed to all children equally, on the basis of need.

25 Section 17 CA 1989 provides insofar as material as follows:

“(1) It shall be the general duty of every local authority (in addition to the other duties imposed on them by
this Part)—

(a) to safeguard and promote the welfare of children within their area who are in need…

by providing a range and level of services appropriate to those children's needs.

…

(10) For the purposes of this Part a child shall be taken to be in need if—

(a) he is unlikely to achieve or maintain, or to have the opportunity of achieving or maintaining, a
reasonable standard of health or development without the provision for him of services by a local authority
under this Part;

(b) his health or development is likely to be significantly impaired, or further impaired, without the provision
for him of such services; or

(c) he is disabled…”

26 A child who lacks accommodation or is destitute is, ipso facto, a child in need for the purposes of s.
17(10)(b): R (G) v Barnet London Borough Council _[2003] UKHL 57, [2004] 2 AC 208, [99] (Lord Hope). It_
is therefore common ground that UAS children arriving in the UK will inevitably be children in need for the
purposes of s. 17. Even if they have accommodation, many UAS children are likely to be children in need
by virtue of s. 17(10)(a) and/or (b).

27 UAS children who arrive in Kent are “within [the] area” of Kent CC by virtue of being physically present
there: see R (Stewart) v Wandsworth London Borough Council _[2001] EWHC 709 (Admin), [28]-[29] (Jack_
Beatson QC).

28 Section 20 CA 1989 provides relevantly as follows:

“(1) Every local authority shall provide accommodation for any child in need within their area who appears
to them to require accommodation as a result of—

(a) there being no person who has parental responsibility for him;

(b) his being lost or having been abandoned; or

(c) the person who has been caring for him being prevented (whether or not permanently, and for whatever
reason) from providing him with suitable accommodation or care.

…

(3) Every local authority shall provide accommodation for any child in need within their area who has
reached the age of sixteen and whose welfare the authority consider is likely to be seriously prejudiced if
they do not provide him with accommodation.”

29 It is common ground that UAS children arriving in the UK will inevitably be owed a duty under one or
more of these provisions. It is also common ground that the duty is absolute. The local authority cannot
impose eligibility criteria beyond those stipulated in the statute; and the duty applies irrespective of the
local authority's resources or lack of them: R (JL) v Islington London Borough Council _[2009] EWHC 458_
_[(Admin), [2009] 2 FLR 515, [70]-[71] (Black J).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G1PF-00000-00&context=1519360)_

30 Once accommodation is provided to a child under s. 20 for more than 24 hours, the child becomes
“looked after”: s. 22(1)(b) & (2). That triggers the duties in s. 22(3) and (3A), which provide as follows:


-----

(on the application of Brighton and Hove City Counci....

“(3) It shall be the duty of a local authority looking after any child—

(a) to safeguard and promote his welfare; and

(b) to make such use of services available for children cared for by their own parents as appears to the
authority reasonable in his case.

(3A) The duty of a local authority under subsection (3)(a) to safeguard and promote the welfare of a child
looked after by them includes in particular a duty to promote the child's educational achievement.”

31 Section 22(4) imposes the duty, before making any decision with respect to a child, to consult various
people, including the child themselves. Section 22(5) requires the local authority to have due regard “(a)
having regard to his age and understanding, to such wishes and feelings of the child as they have been
able to ascertain… and (c) to the child's religious persuasion, racial origin and cultural and linguistic
background”.

32 Section 22G(1) and (2) impose a general anticipatory duty on local authorities “to take steps that
secure, so far as practicable” that the local authority are able to provide the children in its care (among
others) with accommodation that “(a) is within the authority's area; and (b) meets the needs of those
children”.

33 Under s. 1 of the Children and Social Work Act 2017, the local authority becomes the “corporate
parent” of its looked after children. This means that, in carrying out its functions, it must have regard to the
need:

“(a) to act in the best interests, and promote the physical and mental health and well-being, of those
children and young people;

(b) to encourage those children and young people to express their views, wishes and feelings;

(c) to take into account the views, wishes and feelings of those children and young people;

(d) to help those children and young people gain access to, and make the best use of, services provided by
the local authority and its relevant partners;

(e) to promote high aspirations, and seek to secure the best outcomes, for those children and young
people;

(f) for those children and young people to be safe, and for stability in their home lives, relationships and
education or work;

(g) to prepare those children and young people for adulthood and independent living.”

34 Where a looked after child cannot be placed with their parent, a person who has responsibility for them
or a person named in a child arrangements order, s. 22C(5) CA 1989 imposes a duty to place the child “in
the placement which is, in their opinion, the most appropriate placement available”. Section 22C(6) lists the
permissible placements, which are:

“(a) placement with an individual who is a relative, friend or other person connected with C and who is also
a local authority foster parent;”

(b) placement with a local authority foster parent who does not fall within paragraph (a);

(c) placement in a children's home in respect of which a person is registered under Part 2 of the Care
Standards Act 2000 or Part 1 of the Regulation and Inspection of Social Care (Wales) Act 2016; or

(d) subject to section 22D, placement in accordance with other arrangements which comply with any
regulations made for the purposes of this section.”

35 “Children's home” is defined in s. 105(1) CA 1989 as having the same meaning as in the _[Care](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y07N-00000-00&context=1519360)_
_[Standards Act 2000 (“CSA 2000”), viz., subject to certain exceptions, a home that provides care and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y07N-00000-00&context=1519360)_
accommodation wholly or mainly for children.


-----

(on the application of Brighton and Hove City Counci....

36 Section 22C(11) confers power on the Secretary of State to make regulations for and in connection
with the purposes of s. 22C. The regulations currently in force are the Care Planning, Care Placement and
[Case Review (England) Regulations 2010 (SI 2010/959: “the Care Planning Regulations 2010”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y43-J600-YC34-71KR-00000-00&context=1519360)

The Care Planning Regulations

37 Regulation 4(1) of the Care Planning Regulations imposes on local authorities a duty to assess a
child's needs for services to achieve a reasonable standard of health or development, and prepare a care
plan.

38 By reg. 5(1), the care plan must include both a long-term plan for the child's upbringing (“the plan for
permanence”) and the arrangements made to meet the child's needs in relation to various matters
including health, education and identity (in the latter case, with particular regard to the child's religious
persuasion, racial origin and cultural and linguistic background). By an amendment made in 2014, it must
also include the fact that the child is a victim of trafficking (or there is reason to believe they are) or a UAS
child. This requirement was explained as intended to “bring greater attention and focus to the particular
needs of these children and [to] help ensure they receive from local authorities the specialist support and
[care that they need”: Explanatory Memorandum to the Care Planning (Amendment) Regulations 2014 (SI](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5CRS-YRV1-F16W-C19K-00000-00&context=1519360)
_[2014/1917).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5CRS-YRV1-F16W-C19K-00000-00&context=1519360)_

39 Regulation 9(1) imposes a duty, before making arrangements under s. 22C for the child's placement, to
prepare a placement plan, which sets out how the placement will contribute to the child's needs and
includes the matters set out in Sch. 2, including “how on a day to day basis [the child] will be cared for and

[the child's] welfare will be safeguarded and promoted by the appropriate person” (Sch. 2, para. 1).
Regulation 9(2) provides that, if it is not reasonably practicable to prepare the placement plan before
making the placement, the placement plan must be prepared within five working days of the start of the
placement.

40 Regulation 27A, introduced by amendment with effect from 9 September 2021, provides that a local
authority may only place a child under 16 in one of an exhaustive list of regulated kinds of accommodation.
The hotels commissioned by the Home Secretary are not among these.

41 Regulations 32-38 provide for reviews of the care plan by an independent reviewing officer (“IRO”).

42 A person who carries on or manages a children's home without being registered commits an offence: s.
11(1) of the CSA 2000).

Statutory guidance for local authorities

[43 Section 7(1) of the Local Authority Social Services Act 1970 (“LASSA 1970”) provides that local](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y089-00000-00&context=1519360)
authorities must, in the exercise of their social services functions, including the exercise of any discretion
conferred by any relevant enactment, act under the general guidance of the Secretary of State. That
provision was considered by Sedley J in R v Islington London Borough Council ex p. Rixon [1997] ELR 66.
He said this:

“Parliament in enacting section 7(1) did not intend local authorities to whom ministerial guidance was given
to be free, having considered it, to take it or leave it. Such a construction would put this kind of statutory
guidance on a par with the many forms of non-statutory guidance issued by departments of state. While
guidance and direction are semantically and legally different things, and while 'guidance does not compel
any particular decision' (Laker Airways Ltd v Department of Trade [1967] QB 643, 714 per Roskill LJ),
especially when prefaced by the word 'general', in my view Parliament by s.7(1) has required local
authorities to follow the path charted by the Secretary of State's guidance, with liberty to deviate from it
where the local authority judges on admissible grounds that there is good reason to do so, but without
freedom to take a substantially different course.”


-----

(on the application of Brighton and Hove City Counci....

44 The Secretary of State has exercised the power conferred by s. 7(1) LASSA 1970 (among other
[powers) to issue statutory guidance on the performance by local authorities of their functions under the CA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
_[1989 entitled Working Together to Safeguard Children (2018). It provides as follows:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_

“78. Within **one working day of a referral being received, a local authority social worker should**
acknowledge receipt to the referrer and **make a decision about next steps and the type of response**
required. This will include determining whether:

- the child requires immediate protection and urgent action is required

- the child is in need and should be assessed under section 17 of the Children Act 1989

- there is reasonable cause to suspect that the child is suffering or likely to suffer significant harm, and
whether enquires must be made and the child assessed under section 47 of the Children Act 1989…”

…

81. For children who are in need of immediate protection, action must be taken by the social worker, or the
police or the NSPCC if removal is required, as soon as possible after the referral has been made to local
authority children's social care (sections 44 and 46 of the Children Act 1989).” (Emphasis in original)

45 Separately, the Secretary of State has issued guidance entitled Care of Unaccompanied Child Migrants
_and Unaccompanied Child Victims of Modern Slavery (2017). It provides, insofar as material, as follows:_

“1. Unaccompanied migrant children and child victims of **_modern slavery, including trafficking, can be_**
some of the most vulnerable children in the country. Unaccompanied children are alone, in an unfamiliar
country and may be surrounded by people unable to speak their first language…

…

3. Local authorities have a duty to protect and support these highly vulnerable children. Because of the
circumstances they have faced, unaccompanied migrant children and child victims of **_modern slavery,_**
including trafficking, often have complex needs in addition to those faced by looked after children more
generally. The support required to address these needs must begin as soon as the child is referred to the
local authority or is found in the local authority area…

…

9. Section 17 of the Children Act 1989 places a general duty on every local authority to safeguard and
promote the welfare of children in need within their area by providing services appropriate to those
children's needs.

10. An unaccompanied child will become looked after by the local authority after having been
accommodated by the local authority under section 20(1) of the Children Act 1989 for 24 hours. This will
mean that they will be entitled to the same local authority provision as any other looked after child.
Assessment and care provisions for the child should commence immediately as for any looked after child,
irrespective of whether an application (e.g. an asylum claim) has been submitted to the Home Office.

…

40. Many unaccompanied and/or trafficked children are at risk of going missing from care, often within the
first 72 hours, whilst others may be at risk of repeated missing episodes due to ongoing exploitation.
Children may go missing because of uncertainty over their immigration status or due to feeling
unsupported or being unsure or unaware of what it means to be 'looked after' and that they need to
communicate their whereabouts to carers. Even if they are not a victim of **_modern slavery,_**
unaccompanied children are still highly vulnerable and if they go missing they are at risk of being exploited
or mistreated.

…


-----

(on the application of Brighton and Hove City Counci....

43. The local authority in whose area the looked after child is has responsibility for looking after the child.
The Care Planning, Placement and Case Review (England) Regulations 2010 require the responsible local
authority to undertake the single assessment conducted as the first step in the care planning process.
Following assessment, the local authority will produce a care plan setting out how their needs will be met.
This must include the child's permanence plan and the arrangements that the local authority will make to
meet the child's needs in relation to: health; education; behavioural and emotional development; identity –
with particular regard to religious persuasion, racial, cultural and linguistic background; family and social
relationships; social presentation; and self-care skills. Where appropriate the local authority might also
need to carry out an enquiry under section 47 of the Children Act 1989.

…

67. The local authority should also take steps to ensure robust procedures are in place to monitor
educational progress and a culture of proactive commitment to secure the highest educational outcomes
for unaccompanied children or child victims of **_modern slavery. This should be monitored by a senior_**
manager, such as the Virtual School Head, who is responsible for making sure their local authority
promotes the educational achievement of its looked after children. A child protection plan may be required
to protect unaccompanied children from further harm. This is particularly likely where there is reason to
believe the child is a victim of modern slavery (or at risk of being so) or where the child is a witness to
serious crime. In such cases, there is a high risk that the child will go missing from care and return to those
who wish to exploit them. In these cases, the plan should include what steps will be taken by carers, the
local authority and police to reduce the risk of the child going missing, and to recover the child if they do go
missing, in accordance with local Runaway and Missing from Home and Care protocols. The child should
be placed in safe and suitable accommodation, with particular care given to ensuring that the particular
placement is fully risk-assessed…

…

70. Placement decisions should take particular account of the need to protect the child from any risk of
being exploited, and from a heightened risk of them going missing. Transfer to the care of another local
authority or an out of area placement might in some cases be appropriate to put distance between the child
and where their traffickers expect them to be.

71. Each unaccompanied asylum seeking child should be assessed and a decision made about which
placement is the most appropriate for them in accordance with section 22C of the Children Act 1989. There
is no 'one-size-fits-all' placement. The benefits of each placement will depend on the needs of the child;
whether or not they have been trafficked; their experience during their journey to the UK; their culture, age,
sex and personality; their sense of personal autonomy and ability to live independently; and their sense of
safety and ideas on what will make them feel safe.

72. Often very little information about the child is available in the first few days and so it is highly likely that
a permanent placement decision will not be made immediately. A temporary placement can enable the
child to feel safe and physically recover from their journey and be able to engage with an assessment of
their needs with the help of interpreters where necessary.

73. An unaccompanied child is likely to have developed survival skills and possibly a veneer of being able
to cope, which may mask their actual needs. Assessments should be carefully completed before assuming
any level of physical, social and emotional resilience. An assessment of needs should include (but not be
limited to) language and communication skills, ability to buy and cook food, ability to care for themselves
and keep themselves safe, their understanding of British laws and social customs, and their ability to
access education and public services (including GP and dentist).

74. It may be that the child would benefit from being in a placement with a high level of support initially and
then when they are ready they can move on to a placement with a lower level of support.

…


-----

(on the application of Brighton and Hove City Counci....

79. It is important that suitable emergency accommodation can be accessed directly at any time of the day
or night where there is sufficient supervision and monitoring by on-site staff to keep the child safe. Bed and
breakfast (B&B) accommodation is not suitable for any child, even on an emergency accommodation
basis. Such accommodation can leave the child particularly vulnerable to risk from those who wish to
exploit them and does not cater for their protection or welfare needs.”

[The “primacy” of local authorities' duties under the Children Act 1989](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)

46 Ms Rhee for the Secretaries of State submitted, correctly in my view, that the duties imposed on local
[authorities under the CA 1989 have “primacy” over other statutory functions that could in principle apply to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
children. This means that a local authority cannot avoid complying with the panoply of duties and powers
which flow from providing accommodation under s. 20 CA 1989 by instead accommodating a child under
[another statutory regime (e.g. the Housing Act 1996) which does not trigger those additional duties: R (G) v](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)
_Southwark London Borough Council_ _[2009] UKHL 26, [2009] 1 WLR 1299, [28] (Lady Hale). See also_ _R_
_(M) v Hammersmith and Fulham London Borough Council_ _[2008] UKHL 14, [2008] 1 WLR 535, [29]-[31]_
(Lady Hale).

47 The effect of the statutory scheme is that “a child, even one on the verge of adulthood, is considered
and treated by Parliament as a vulnerable person to whom the state, in the form of the relevant local
authority, owes a duty which goes wider than the mere provision of accommodation”: R (G) v Southwark
_LBC, at [3] (Lady Hale, quoting Rix LJ in the Court of Appeal in the same case)._

The Secretary of State's powers and duties

48 When a child first arrives in the UK, their first contact with the state will be with immigration officers.
They have power to examine persons entering the UK by ship or aircraft and to detain such persons for the
[purpose of the examination: Immigration Act 1971, Sch. 1, paras 2 and 16. The powers of detention are,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y0C0-00000-00&context=1519360)
however, very sparingly used in relation to children.

49 The Secretary of State's instructions to her own staff, _Detention: General instructions, provide as_
follows at p. 37:

“As a general principle, even where one of the statutory powers to detain is available in a particular case,
unaccompanied children (that is persons under the age of 18) must not be detained other than in very
exceptional circumstances. If unaccompanied children are detained, it must be for the shortest possible
time, with appropriate care. This may include detention overnight, but a person detained as an
unaccompanied child must not be held in an immigration removal centre in any circumstances. This
includes age dispute cases where the person concerned has been given the benefit of the doubt and is
being treated as a child.

The very exceptional circumstances in which it might be appropriate to detain unaccompanied children are
set out below. In all cases, the decision-making process must be informed by and take account of the duty
to have regard to the need to safeguard and promote the welfare of children under section 55 of the
Borders, Citizenship and Immigration Act 2009.”

50 One of the circumstances in which very short-term detention may be permitted is pending the making
of alternative arrangements for care and safety – for example, collection by local authority children's
services. As the guidance makes clear, “Efforts to secure alternative care arrangements in such cases
must be made expeditiously” (p. 39).

51 Section 55(1) of the Borders, Citizenship and Immigration Act 2009 (“the 2009 Act”) requires the
Secretary of State to make arrangements for ensuring that her immigration, asylum and nationality
functions are discharged “having regard to the need to safeguard and promote the welfare of children who
are in the United Kingdom” and that any services provided by another person pursuant to arrangements
made by her which relate to the discharge of those functions are provided having regard to that need.
Section 55(3) provides that a person exercising any of those functions must have regard to guidance given
to the person by the Secretary of State for the purpose of s 55(1)


-----

(on the application of Brighton and Hove City Counci....

52 The Secretary of State has given guidance under this provision entitled _Every Child Matters (2009)._
This provides as follows at para. 2.22:

“The UK Border Agency must always make a referral to a statutory agency responsible for child protection
or child welfare such as the police, the Health Service, or the Children's Department of a Local Authority in
the following circumstances:

    - When a potential indicator of harm (the most comprehensive such list is found in Working Together to
_Safeguard Children who have been Trafficked and their application is wider than trafficking cases alone)_
has been identified.

     - When a child appears to have no adult to care for them and the Local Authority has not been notified.”

53 This is consistent with guidance to caseworkers on the steps to be taken when a UAS child is
encountered in the UK: Children's Asylum Claims. The current version is 4.0, published in December 2020.
This makes clear that officers “must always notify the relevant local authority children's services contact of
the arrival of an asylum seeking child in their area… at the earliest possible point so that the local authority
can consider the best course of action for that specific case” (see p. 27).

54 All of this reflects the fact that the primary duty to accommodate and look after UAS children is that of
the local authority. The Home Secretary has power under s. 95 of the Immigration and Asylum Act 1999 to
support destitute asylum seekers, but the definition of “asylum seeker” for these purposes expressly
excludes children: see s. 94(1). The 2023 Act contains provisions which empower the Home Secretary to
provide accommodation and support to UAS children (ss. 16 to 21). As noted, however, these provisions
have not yet been commenced.

55 Where the Home Secretary has “care” of a child (including where the child is initially detained for
examination under paras 2 and 16 of Sch. 1 to the 1971 Act), the Home Secretary has the same power
under s. 3(5) CA 1989 as any person who does not have parental responsibility to “(subject to the
provisions of this Act) do what is reasonable in all the circumstances of the case for the purpose of
safeguarding or promoting the child's welfare”.

Transfer powers

56 Section 69 IA 2016 (headed “Transfer of responsibility for relevant children”) applies to a local authority
in England and Wales (“the first authority”) if: (a) the authority has functions under Parts 3, 4 or 5 CA 1989
in relation to a relevant child, or (b) functions under those provisions may be conferred on the authority in
relation to a relevant child: s. 69(1).

57 Section 69(2) empowers the first local authority to make arrangements with another local authority in
the same part of the UK (i.e. England, Scotland, Wales or Northern Ireland), under which the functions of
the first authority (or those which may be conferred on it) become the functions of another local authority in
relation to the relevant child. Section 69(3A) confers a similar power to make such arrangements with a
local authority in another part of the UK. The remaining subsections deal with the legal consequences of
the making of such arrangements, which provide for the functions of the first local authority to cease and
those of the second authority commence. This takes place “from the time at which the arrangements have
effect according to their terms”: see s. 69(3) and (3A).

58 Section 72 (headed “Scheme for transfer of responsibility for relevant children”) provides relevantly as
follows:

“(1) The Secretary of State may prepare a scheme for functions of, or which may be conferred on, a local
authority (“the transferring authority”) to become functions of, or functions which may be conferred on, one
or more other local authorities in the same part of the United Kingdom (a “receiving authority”) in
accordance with arrangements under section 69(2).


-----

(on the application of Brighton and Hove City Counci....

(1A) The Secretary of State may prepare a scheme in relation to a local authority to which section 69
applies (“the transferring authority”) and one or more other local authorities in one or more other parts of
the United Kingdom (“a receiving authority”) having the effects mentioned in section 69(3B).

(2) A scheme under this section—

(a) must specify the local authorities to which it relates, and

(b) unless it relates to all relevant children who may be the subject of arrangements under section 69
between the transferring authority and each receiving authority, must specify the relevant child or children,
or descriptions of relevant children, to which it relates.

(3) The Secretary of State may direct the transferring authority and each receiving authority under a
scheme under this section to comply with the scheme.

(4) A direction may not be given under subsection (3) unless the Secretary of State is satisfied that
compliance with the direction will not unduly prejudice the discharge by each receiving authority of any of
its functions.

(5) Before giving a direction under subsection (3) to a local authority, the Secretary of State must give the
authority notice in writing of the proposed direction.

(6) The Secretary of State may not give a direction to a local authority before the end of the period of 14
days beginning with the day on which notice under subsection (5) was given to it.

(7) The local authority may make written representations to the Secretary of State about the proposed
direction within that period.

(8) The Secretary of State may modify or withdraw a direction under subsection (3) by notice in writing to
the local authorities to which it was given.

(9) A modification or withdrawal of a direction does not affect any arrangements made under section 69
pursuant to the direction before it was modified or withdrawn.”

[59 The Explanatory Notes to the IA 2016 provide as follows at para. 30:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)

“When unaccompanied children are identified by immigration officers they are referred to local authority
care. This means that certain local authorities have significant responsibility for the care of migrant children
because of the presence of large ports of arrival in their locality. For example, Kent County Council is
responsible for unaccompanied children referred from the Port of Dover and the London Borough of
Hillingdon is responsible for unaccompanied children referred from Heathrow Airport. The Act contains
measures to enable the transfer of these children between authorities to achieve a more even distribution.”

60 The reference to “the transfer of children” is apt to confuse. What ss. 69 to 73 provide for is, in fact, the
transfer of responsibility for relevant children.

61 The Home Secretary has exercised the power in s. 72(1) to make the NTS and subsequently exercised
the s. 72(3) power to direct all local authorities to comply with it. The terms of that scheme are set out in
the NTS Protocol.

The NTS Protocol

62 The NTS Protocol has gone through several iterations. The current one is version 5, published on 28
June 2023. In essence, it works as follows:

(a) The scheme applies to UAS children who are not within 13 weeks of their 18th birthday.

(b) A local authority may (but is not obliged to) request a transfer if its UAS child population is above the
threshold percentage of its total child population. However, the Home Secretary will not transfer a child to a
local authority exceeding the threshold. When the NTS was first implemented, in July 2016, the threshold
was 0.07%. It was increased to 0.1% from 24 August 2022 (p. 7).


-----

(on the application of Brighton and Hove City Counci....

(c) A decision by a local authority which exceeds the threshold to request a transfer “must take into
account the child's best interests as a primary consideration alongside other considerations, and the
appropriateness of transfer must be considered on a case-by-case basis” (p. 8). Further details are given in
Good Practice Note 1, which lists the factors indicating that it may be in the best interests of the child to be
referred for transfer and the factors which indicate the contrary.

(d) The entry local authority is to make the decision to transfer a child as soon as practicable, ideally within
two working days after the child's asylum claim has been registered (p. 8).

(e) The entry authority then completes Part A of the Unique Unaccompanied Child Record (“UUCR”) and
sends this to the UAS Children NTS Team at the Home Office.

(f) The transfer should take place within ten working days of a referral, or five working days of a referral of
a UAS child not currently in the care of a local authority (p. 9).

(g) To identify a receiving authority, a rota system is used, which is weighted to take into account wider
pressures on receiving authorities. It determines how often a receiving authority can expect to receive UAS
children under the NTS (p. 10).

(h) Once a child has been referred to the NTS, the Home Office team completes Part B of the AACR form
and sends both parts to the Strategic Migration Partnership (“SMP”) UAS children lead of the region or
nation on duty under the national rota. They then identify a receiving authority under their own agreed
arrangements. Since the NTS has been mandatory, the receiving authority has been responsible for
placing the transfers allocated to them, unless arrangements have been made for another authority within
the same region or nation to accept them.

(i) The receiving authority then acknowledges its acceptance of the transfer by filling in Part C of the
UUCR form and sending it to the Home Office, entry authority and the SMP UAS Children lead.

(j) Where any issues arise between the transferring and receiving authorities (for example where they
have differing views as to what is in the best interests of the child, or where an authority is consistently
slow to correspond about an upcoming transfer), and this has been escalated to senior social worker level
but still cannot be resolved, there is an “escalation procedure” which involves the SMP UAS Children Lead,
with “input” from Home Office and Department for Education officials on NTS policy intent. However, issues
that arise before transfer should be resolved within the ten working day period for transfers (or 5 working
days for UAS children not in local authority care).

63 As can be seen, the general structure of the NTS Protocol is based upon the participation of two local
authorities – the “transferring authority” and the “receiving authority”. In its first two versions, there was no
mention of the possibility that the NTS could apply to a child not in the care of any local authority. The first
indication of that possibility came in version 3.0, which came into force on 14 December 2021. It said that
all transfers should take place within 10 working days of referral to the NTS, but added this on p. 10:

“Any child not in the care of a local authority will take first priority for transfer in accordance with the NTS.”

64 Version 4.0 (in force from 5 September 2022) uses the same phrase and adds that the 10 working day
period applies “where a child is in the care of a local authority”; and a different period of 5 working days
applies where the child is “not currently in the care of a local authority”. Materially similar wording appears
in the current version 5.0 (in force from 28 June 2023).

65 As noted, the NTS Protocol appears to require a request by the transferring authority and a process of
engagement between the transferring and receiving authorities. The NTS Protocol does not spell out how
the transfer process works for children who are not in care. For this, it is necessary to turn to the first
witness statement of Hannah Honeyman for the Home Secretary. She explains as follows:

“19. The NTS process has been temporarily adapted for UASC arriving in Kent and temporarily
accommodated by the Home Office in hotels, as a means of facilitating their transfer into local authority
care as soon as possible.


-----

(on the application of Brighton and Hove City Counci....

20. When a child arrives in Kent, and Kent CC is unable to accommodate them, the following amended
process applies:

     - The UASC's asylum claim is registered at the Kent Intake Unit (“KIU”) as described above.

    - A KIU officer refers the UASC by email to the NTS Team, in Asylum Support, Resettlement and
Accommodation in the Home Office. That referral summarises the UASC's details, the UASC welfare form
and, where relevant age dispute details.

     - Upon receipt of the referral, the NTS Team review the case to identify if there is any reason the child
cannot be allocated to a region in England or to one of the other nations that is currently taking it's turn on
the rota. By way of example, if the NTS referral contains information about a relative residing in the UK
they would usually be allocated to the area where that relative(s) resides.

    - The relevant Strategic Migration Partnership (“SMP”), UASC lead will notify the NTS team which local
authority the UASC has been allocated to and the date the referral was emailed to the local authority.

    - When the local authority has identified a care placement, they will email the NTS team with the care
placement details and the transfer from the temporary hotel accommodation will be arranged.”

66 As a matter of administrative record-keeping, transfers of UAS children who are not in the care of a
local authority are recorded as having no “entry” local authority.

The Kent Protocol

67 The Kent Protocol was agreed in September 2021. The version I have been shown is headed “Working
Draft – Not For Wider Circulation Without Prejudice”, but it is common ground that this text represents the
final agreement between Kent CC and the Home Secretary. It begins as follows:

“This document seeks to establish a Protocol for more effectively managing and supporting the arrival of
vulnerable young people into the United Kingdom who arrive on the coastline of the county of Kent. It is
recognised by both parties (Kent County Council and the Home Office) that the statutory provisions and
Government policy means that the Home Office has primary responsibility for the creation of appropriate
schemes to lawfully and effectively disperse young people arriving in the UK and claiming asylum.

It is further recognised that within that operating context and of unprecedented numbers of arrivals, Kent
County Council (Kent CC) cannot meet the needs of all of the Unaccompanied Asylum Seeking Children
(UASC) arriving in Kent and has a limited capacity for doing so safely and lawfully.

The approach recognises that the Government has determined that the National Transfer Scheme (NTS)
shall be, for the time being, a voluntary scheme. Whilst Kent CC assert that the most effective way to
manage and support young people on arrival is through a mandated scheme, this Protocol is a mechanism
which endeavours to maximise the resources available in Kent CC to better meet the needs of the young
people whilst the voluntary NTS persists. The parties' shared intention is to improve the service received by
young people and support their transition to other local authorities under the NTS, and give the NTS the
best possible chance of operating successfully.”

68 The key operative provisions were these:

“Kent CC has finite capacity for the care of UASC; its resources need to be used appropriately for
supporting UASC arrivals assigned to Kent CC on an ongoing basis and supporting the arrival and
dispersal of vulnerable young people under the NTS. As such, it is proposed to create a “Reception and
Safe Care Service” (RSCS) to better meet the needs of UASC whilst they wait to be transferred.

“1. The Home Office will pay Kent CC a fixed fee for the RSCS, this fee will fully cover the cost of the first
60 young people accommodated in the RSCS (but for clarity will be payable whether placements are
utilised or not); for 2021/2 the fee will be set at £4,370,000 per annum, which will be reviewed annually. For
each young person accommodated above the first 60 the Home Office will pay Kent CC on a per young


-----

(on the application of Brighton and Hove City Counci....

person per night basis; for 2021/2 this will be £122 per young person per night, which will be reviewed
annually.”

2. Kent CC will have a maximum capacity to provide the RSCS to 120 UASC at any one time, provided that
the number of UASC within Kent CC's care as looked after children under sections 20 – 22G of the
Children Act 1989 does not exceed 0.07% of child population (currently 242, based on mid 2020 ONS
population estimate). Where the number of UASC cared for by Kent CC as looked after children exceeds
0.07% of Kent CC's total child population, the maximum number of UASC to whom Kent CC provides the
RSCS shall be reduced on a one for one basis. The Home Office will ensure that the speed of transfers
though the NTS is calibrated to allow Kent CC to remain below this maximum capacity; for clarity Kent CC
will not provide RSCS for more than 120 UASC at any one time. Through reviewing the flow of UASC into
and out of the service Kent CC will provide notice to the Home Office at the point when it can no longer
receive any further UASC above this agreed limit, numbers in RSCS should be constantly shared between
Kent CC and the Home Office.

3. In addition to staying within the maximum capacity the Home Office will make best endeavours to
transfer UASC within the time frames set out above, that is to identify a local authority that accepts a
transfer within 5 working days and complete the physical and legal transfer within 10 working days of their
arrival in the UK having been registered. A schedule of compliance with the 5 working and 10 working day
timescales shall be prepared and shared between the parties by the Home Office on a fortnightly basis
beginning on two weeks after this Protocol is agreed.

4. The RSCS will only provide temporary accommodation and address any immediate safeguarding or
health needs of UASC. In particular the RSCS will accommodate under 16 UASC arrivals in Ofsted
registered provision. It will not commence activity around long term care planning, including as required by
the Care Planning, Placement and Case Review (England) Regulations 2010, which will be undertaken by
the local authority which accepts the UASC's transfer (i.e. within 5 working days of referral to the NTS).

5. The Home Office commits to reviewing the effectiveness of the NTS on a regular basis. As part of that
review, Ministers will review the speed at which transfers from the RSCS are being effected (as set out
above).

6. Both parties agree to, as far as possible and appropriate:

a. work together on any legal challenge that is brought by a third party in relation to matters covered in this
Protocol and,

b. without prejudice to any order of the courts, seek to ensure that Kent's legal costs are apportioned in a
fair and reasonable way.

7. These arrangements will be reviewed (initially monthly) between the Director of Children's Services Kent
CC and Home Office and Department for Education Directors to ensure the system is operating as
envisaged.”

69 The evidence does not reveal to what extent the protocol was disseminated to staff at Kent CC, but it is
clear that relevant staff in Kent CC's children's services department knew that it had been agreed with the
Home Office and were well aware of the policy it formalised, viz. that the numbers of UAS children which
Kent CC was prepared to accept into its care would be capped.

**The evidence**

70 As noted, the evidence in this case is extensive. When the other issues come to be determined, it may
be necessary to consider it in greater detail and, possibly, to resolve some disputes of fact. In order to
decide the “hard-edged” preliminary issues, I have not found it necessary to resolve any such disputes. For
present purposes, the following summary suffices.

ECPAT's evidence


-----

(on the application of Brighton and Hove City Counci....

71 ECPAT's principal evidence is contained in witness statements of Laura Durán and Josephine
Schofield.

[72 On 17 August 2020, Kent CC decided that it was unable to continue to assume its CA 1989 duties for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
unaccompanied children who arrive in Kent and were notified to it by the Home Secretary. This was not the
first time Kent CC felt it had to take action of this kind; it had previously done so in 2015, although this was
not publicly known at the time. As a result, hundreds of children were held under immigration powers at the
KIU, a short-term holding detention facility. The Home Secretary arranged for many of these children to be
[placed into the care of other local authorities under the CA 1989 directly from the KIU.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)

73 A report issued by Kent CC's monitoring officer on 2 September 2020, under s. 5(2) of the Local
[Government and Housing Act 1989 (“LGHA 1989”) accepted that duties under s. 20 CA 1989 “are](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-F0W0-TWPY-Y122-00000-00&context=1519360)
mandatory … non-delegable” and “not optional” and that Kent CC's failure to perform those important
statutory duties towards newly arrived UAS children was unlawful “no matter how valid the reasons for our
current circumstances.”

74 On 7 December 2020, Kent CC reversed its decision, resuming performance of _[CA 1989 duties for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
newly arrived unaccompanied children. But this only lasted for six months until, on 11 June 2021, Kent CC
[again decided unilaterally not to perform its CA 1989 duties towards newly arrived UAS children. On each](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
occasion Kent CC's decision not to accept further referrals applied only to UAS children. It did not apply to
children in need coming to their attention in other ways (for example, those already resident in Kent).

75 In response to Kent CC's conduct, the Home Secretary announced in June 2021 that a new national
rota would be set up for the NTS, additional funding for local authorities for looking after UAS children and
care leavers, and £3 million to support local authorities experiencing exceptional costs of looking at this
cohort of children. These measures were said to be directed at alleviating the local authorities' asserted
pressures on resources. A decision was, however, made by the SSHD not to use its s. 72(3) IA 2016
power to direct local authorities to comply with the NTS, despite Kent CC's view that it was necessary to do
so.

76 In July 2021, the SSHD decided to commission hotels, first in Kent and then in other local authority
areas, to house newly arrived UAS children outside the statutory _[CA 1989 childcare or child protection](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
guarantees. The Hove hotel came into use in July 2021. The SSHD did not consult local authorities such
as Brighton & Hove CC in advance or otherwise about the impact of locating hotels in their areas,
particularly where they already had an unaccompanied child population at the NTS Protocol threshold.

[77 In September 2021, Kent CC announced a resumption of its CA 1989 responsibilities. What was not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
known publicly at the time was that this would only be toward a specified (and limited) number of UAS
children arriving in its area, governed by the terms of the Kent Protocol agreed with the SSHD. The
protocol itself was not disclosed by Kent CC or SSHD until 5 July 2023, after these proceedings started. It
is now clear that the proposal for a Kent Protocol was initiated by Kent CC in July 2021, shortly after it
[decided, for the third time, not to comply with its CA 1989 duties in respect of all UAS children arriving in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
Kent.

78 On a natural reading, the Kent Protocol imposes a cap on the total number of UAS children (466) for
[whom it will accept CA 1989 responsibility at any given time, and confirms that it will not take any additional](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
child beyond the cap. The logical and inescapable consequence is that children arriving in the UK in Kent
[who require CA 1989 support will not receive it from Kent CC and will be housed in hotels.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)

79 On 19 October 2022 the Independent Chief Inspector of Borders and Immigration (“ICIBI”) published
_An inspection of the use of hotels for housing unaccompanied asylum-seeking children. Of particular note_
is the discomfort Home Office staff expressed about housing unaccompanied children in hotels owing to
their “lack of skills, expertise and authority”. The ICIBI recommended an exit strategy from the use of hotels
for unaccompanied children within 6 months. This recommendation was “accepted” by the Home Secretary
in her response dated 19 October 2022. On 6 March 2023, the Home Secretary informed Brighton & Hove
CC that the Hove hotel was being “stepped down and no children are at the hotel, until further notice.”


-----

(on the application of Brighton and Hove City Counci....

Kent CC's evidence

80 Kent's evidence is contained in witness statements from Sarah Hammond, its Director of Children's
Services.

81 Kent is the main entry point for asylum seekers, including UAS children. When Kent CC accepts
responsibility for UAS children, the support it provides will usually include (amongst other matters):
accommodation, either in foster care (for under 16s and female UAS children) or shared accommodation
(for 16-17 year old males); allocation of social workers and IROs; education and assistance, including
admissions to local schools and further education colleges; and health facilities, including registration with
a primary care provider. Kent CC remains under a duty to provide services and assistance to young people
who have been in its care even after they reach the age of 18. This may continue until they turn 25.

82 Until 2014, all UAS children and formerly looked after care leavers were managed by Kent CC in a
standalone service which was separate and distinct from other children. However, Ms Hammond undertook
a review of that service after an Ofsted inspection in 2013. It was apparent that there was a lack of parity
between the service for UAS children and the service for children already resident in Kent. Ms Hammond
was asked to propose an alternative model which would mean that UAS children received “the same level
and quality of care as British citizen children in care”. An integrated model of care was developed and the
experience is that this has improved the quality of outcomes.

83 Kent CC, however, faces a particularly acute challenge compared with other local authorities, as UAS
children arrive spontaneously and often in large numbers within a very short space of time. Kent CC's
unique circumstances mean that it retains a reception service to collect young people on arrival and
referral by the Home Office. It has also created physical reception centres for some UAS children to live in
until longer term arrangements are made.

84 There are two reception centres (Appledore Reception Centre and Millbank Reception & Assessment
Centre) which, between them, are able safely to accommodate 89 young people. Foster placements are
required for girls and for all UAS children under the age of 16, to mitigate the risk of harm. On 5 July 2022,
after its most recent inspection, Ofsted said:

“Following referral to Kent, newly arrived asylum unaccompanied asylum-seeking children are provided
with support in line with their individual needs and accommodated in a timely way.”

85 Kent CC currently has 14 social workers experienced in working with UAS children. They need to have
manageable caseloads to ensure the needs of children in care are met. The average caseload in the
RSCS is currently 13 children per social worker. Overall, the average caseload for children in care in Kent
is 19, but the target capacity limit is 15. These differences reflect the fact that looking after UAS children is
(on average) more resource intensive than looking after other children. The effectiveness of Kent CC's
reception service is therefore dependent on UAS children being promptly transferred to other local
authorities.

86 In June 2015, 948 UAS children arrived in Kent, which was significantly more than had been seen in
the previous ten years. Kent CC was unable to meet its statutory duties to this cohort of young people. Its
services were completely overwhelmed and unsafe and, as a result, Kent CC faced multiple legal
challenges brought by young people. Kent CC requested help from other local authorities under s. 27 CA
1989. This did not result in meaningful assistance being provided. The Department for Education and the
Home Office intervened directly to encourage other local authorities to accept transfers from Kent CC. This
resulted in 149 of the 948 UAS children being transferred.

87 It was in response to this that the Government inserted provisions into the Bill which became the _[IA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
_[2016,creating the NTS. This included a provision (s. 72(3)) enabling the Home Office to direct local](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
authorities to accept transfers through the NTS. It was intended that this power would be exercised if the
NTS did not function on a voluntary basis, as initially intended. The Home Secretary and Department for
Education jointly established the NTS Protocol.


-----

(on the application of Brighton and Hove City Counci....

88 Between 1 January and 31 May 2020, Kent CC was not able to transfer a single UAS child, despite
having made numerous requests to the Home Office NTS team. In the period January to August 2020, 448
UAS children arrived in Kent, but Kent CC was able to transfer only 69 of them to other local authorities. By
17 August 2020, Kent CC was responsible for 605 UAS children and an additional 940 young people who
were formerly cared for as UAS children. At this point, the then Director of Children's Services considered
that Kent CC could no longer safely provide services to all of the children to whom it owed legal duties
[under the CA 1989,whilst also complying with its duties to the children already in its care.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)

89 In particular, accommodation placements in Kent's reception centres and with foster carers were
exhausted; social workers in Kent CC's UAS children's teams were managing an average caseload of
between 35 and 38 children each, against a target of 15 – i.e. more than double the number which Kent
CC considered safe and appropriate; Kent CC had been unable to allocate any social worker to ten
children in its care and many more had not been allocated an IRO; IRO caseloads were averaging 75
children each, against a target of 50; there were 102 children awaiting age assessments (which are crucial
to determine the service to which arrivals are entitled); and on 4 August 2020, the Government directed
that all new arrivals into the UK (including UAS children) would need to self-isolate for 14 days because of
the Covid-19 pandemic.

90 As a result of the advice given by the Director of Children's Services, Kent CC's political leadership
advised that Kent CC would be unable to accept responsibility for new UAS children arrivals in Kent. This
[meant that Kent CC was operating outside of its statutory duties under the CA 1989. The Monitoring Officer](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
issued a report to this effect to the members of Kent CC under s. 5 LGHA 1989, which was considered at a
full council meeting on 10 September 2020.

91 The Government wrote to all local authorities urging them to come forward with offers of emergency
support. In the coming months, the Government took ad hoc action to place new UAS child arrivals in the
care of other local authorities directly from the KIU. This led to 200 UAS children who arrived in Kent being
distributed amongst other local authorities and responsibility for 118 UAS children being transferred from
Kent CC to other local authorities under the NTS.

92 In a letter of 7 December 2020, the political leadership explained that Kent CC was now in a position to
begin accepting responsibility for new arrivals.

93 Meanwhile, on 28 August 2020, the Government wrote to local authorities to consult on changes to the
NTS. The proposal included a rota for regions to take turns as receiving authority for UAS children as they
arrived. However, the proposals still relied on voluntary participation by local authorities. Kent CC
responded, saying that the scheme would have to make transfers mandatory to be effective. On 23
December 2020, the Government wrote to local authorities noting that local authority views on mandation
were split. Kent CC believes that those who opposed it are likely to include local authorities in the
southwest, northwest and northeast regions which have consistently refused to participate voluntarily
because they are not willing to accept a fair share of UAS children.

94 On 3 June 2021, Kent CC sent a letter before claim to the Home Secretary indicating its intention to
bring judicial review proceedings challenging the failure to exercise her statutory power to mandate the
NTS. On 10 June 2021, the Home Office wrote to all local authorities in England to launch the new (still
voluntary) NTS. The new scheme was launched in July 2021, though an updated NTS Protocol was not
published until 16 December 2021. The changes included a number of features which remain today,
including: a regional rota, which is supposed to determine a fair allocation of NTS referrals to each region;
increased funding to local authorities for each UAS child accepted; an uplift to the funding rates for over-18
UAS children care leavers; an exceptional costs fund of £3m to support local authorities experiencing
exceptional costs; improvements in the NTS model, including an escalation procedure designed to resolve
disagreements between local authorities; and additional support for local authorities to carry out age
assessments. However, the Home Secretary declined to make the NTS mandatory, given the lack of “clear
consensus” among local authorities for such a move.


-----

(on the application of Brighton and Hove City Counci....

95 Kent CC's then Director of Children Services wrote to the Council's political leadership on 10 June
2021 to advise that that Kent CC should again cease to accept responsibility for UAS children by no later
than 14 June 2021. This was because the number of UAS children cared for by Kent CC had risen
significantly and far exceeded the then applicable threshold of 0.07%; neither of the two reception centres
had any free beds for new UAS children arriving; sourcing suitable additional beds was not straightforward;
and despite making enquiries with 165 fostering agencies, only eight additional foster placements could be
identified for UAS children; as in August 2020, caseload targets for social workers were being significantly
exceeded; and it was becoming impossible to find the resources to carry out lawful age assessments.

96 The Monitoring Officer wrote to members on the same day to notify them that he would be preparing a
further report under s. 5 LGHA 1989.

97 Kent CC believes that the actions taken by the Home Secretary after 14 June 2021 (which include
accommodating UAS children at the KIU, requesting other local authorities to make offers of assistance
and commissioning hotels) show that the voluntary version of the NTS was ineffective. However, rather
than bringing further proceedings, Kent CC sought to engage with the Home Secretary to address the
problem. The result was the establishment of the RSCS, under which Kent CC would provide care under
the _[CA 1989 on a temporary basis pending transfer to another local authority, with some Home Office](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
funding.

98 The arrangements for the RSCS were agreed on 10 September 2021. They involve Kent CC taking into
its care as looked after children an additional 120 UAS children above the threshold specified in the NTS.
This means that Kent CC can take up to 466 UAS children into its care at any time. This is the maximum
number which Kent CC believes it can safely care for. Its ability to make even this number of places
available is contingent on obtaining Ofsted registration for its supported accommodation facilities by
October 2023 (when such registration will become mandatory). This number does not include the UAS
care leavers who have reached the age of 18 and for whom Kent CC retains responsibility up to the age of
25 (some 1,033 as at 11 July 2023).

99 Kent CC believes that, in respect of those children admitted to its RSCS, it discharges its duties under
the _[CA 1989,although it does not make long-term care plans within the first 10 days (since the young](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
person should be transferred to another local authority's care within that time). If, however, a young person
[has not been transferred within that time, Kent CC continues to comply with its duties under the CA 1989](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
and the Care Planning Regulations and planning takes place in the same way as for any other looked after
child.

100 In Kent CC's view, the RSCS reflects how the NTS is supposed to work, with young people taken into
Kent CC's care pending transfer to another local authority. This transfer is supposed to take place within 10
working days. If it did, Ms Hammond is confident that every UAS child could be taken into Kent CC's care
and accommodated pursuant to s. 20 CA 1989. In her view, “the [Home Secretary's] failure to meet and
enforce the 10 working day timeframe in the NTS Protocol is directly to blame for the [Home Secretary]
having to temporarily accommodate UAS [children] in hotels”.

101 Kent CC resumed accepting newly arrived UAS children on 9 September 2021. However, it could not
immediately accept all UAS children who had arrived over the summer and been accommodated by the
Home Secretary in hotels. Many had to remain in hotels until placements with other local authorities could
be found.

102 On 23 November 2021, the Government wrote to local authorities informing them that the Home
Secretary was minded to mandate their participation in the NTS. The intention was confirmed on 14
December 2021. Ms Hammond is critical of the bureaucratic nature of the NTS and of the lack of any
power in the Home Secretary to adjudicate disputes (despite the “escalation procedure”).

103 Ms Hammond considers that the continued use of hotel accommodation by the Home Secretary for
UAS children shows that the NTS is being operated and/or enforced ineffectively, and in particular criticises
the failure to meet and enforce the 10 working day timeframe. As at 11 July 2023, it is taking on average


-----

(on the application of Brighton and Hove City Counci....

20 working days for UAS children to be transferred from Kent CC to other local authorities via the RSCS.
This delay means that Kent CC is unable to make RSCS placements available quickly enough to keep up
with the pace of UAS children arriving in Kent.

104 Ms Hammond considers that part of the problem lies with local authorities which opposed mandation
in the first place. She notes that the barriers to accepting responsibility for the care of UAS children are “not
purely financial, but also political, cultural, and due to the lack of infrastructure that other local authorities
have in place to care for UASC”.

105 As at 11 July 2023, Kent CC is caring for 466 UAS children under the age of 18, including 120 cared
for as part of the RSCS. It also provides care and services to 1,033 former UAS care-leavers over the age
of 18. In addition, there are eight asylum seekers currently in prison who have been assessed as adults but
are challenging those assessments. If they are subsequently assessed as children, they will likely be
referred to Kent CC.

106 Since the Home Secretary first commissioned hotels in Kent for UAS children, Ms Hammond
understands that 2,462 UAS children have been accommodated there and that, as at 11 July 2023, there
are 29 being accommodated at one hotel and a further 29 at a another, both in Kent. These children are
not in Kent CC's care as looked after children. Kent CC has acknowledged that it is failing to discharge its
_[CA 1989 duties in relation to them. Nonetheless, social workers from Kent CC do regularly attend these](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
hotels to collect any UAS children which Kent CC has capacity to take into its care, including as part of the
RSCS. Kent CC is in daily contact with social work managers at the hotels to understand if there are any
particularly vulnerable children.

107 Kent CC's experience is that the hotels in Kent are “well equipped by health staff, care workers and
social workers, and young people accommodated there have told the Children's Commissioner and Ofsted
that they feel safe”. Ms Hammond does not, however, suggest that hotel accommodation is suitable for
UAS children. It is not. She would much prefer these vulnerable young people to be in local authority care
with a corporate parent as soon as possible. But Kent CC remains aware of its duties under s. 47 CA 1989
to make enquiries and investigate whether a child is suffering, or is likely to suffer, significant harm. This
places an additional burden on Kent CC's already overstretched social workers.

The Secretary of State

108 The evidence for the Secretaries of State comes from the witness statements of Hannah Honeyman,
Head of Temporary Unaccompanied Asylum-Seeking Children Accommodation at the Home Office; Dr
Meirav Elimelech, Deputy Director for the Asylum and Protection Unit at the Home Office; and Julian Ward,
Assistant Director, Unaccompanied Asylum-Seeking Children at the Department for Education.

109 Ms Honeyman explains that UAS children who arrive in Kent are moved to the KIU to have their
biometrics taken and security checks completed. A welfare and screening interview is undertaken to
identify any welfare or safeguarding issues, including whether the child is a potential victim of trafficking. If
there are indicators that this is so, the screening officer makes a referral to the National Referral
Mechanism (“NRM”). As soon as reasonably practicable, the Home Office notifies Kent CC of the arrival of
a UAS child. Until Kent CC takes charge of the child, the Home Office provides food and shelter and takes
such steps as it considers reasonably necessary to safeguard and promote the welfare of the child.

110 On 17 August 2020, Kent CC notified the Home Office that the numbers of UAS children arriving on
small boats had outstripped their capacity, they could not comply with their statutory responsibilities under
the _[CA 1989 and they would therefore no longer accept newly arriving UAS children into their care.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
Consequently, UAS children had to remain at the KIU until a suitable care placement was identified with
another local authority through the NTS. This situation persisted until 7 December 2020. Kent CC gave a
similar notification in June 2021.

111 The KIU is not a residential or accommodation facility and does not have beds or adequate bathrooms
to cope with the needs of people staying for more than a few hours. Before hotels were used, UAS children
had to sleep on the floor there Some remained in the non detained area of the KIU for prolonged periods


-----

(on the application of Brighton and Hove City Counci....

(up to 10 days in a small number of cases) before being collected by a local authority. The Department for
Education and the Home Office considered this unsatisfactory and determined to find another solution.

112 Following Kent CC's announcement on 11 June 2021, the Home Office explored options, for
immediate alternative accommodation, which included: hotel accommodation, private care placements,
children's homes, portacabin-type accommodation alongside the KIU and refurbishing other nearby
buildings. For various reasons, including the need to act quickly, the view was taken that hotels were the
most viable option.

113 Hotel accommodation was first used in July 2021, relieving the pressure on the KIU and providing a
more appropriate environment for young people. The number of UAS children arriving in the UK has
continued to increase through 2021, 2022 and 2023 and Kent CC's position remains unchanged.
Consequently, seven hotels remain under contract to the Home Office as contingency accommodation for
UAS children in the absence of local authority care on arrival.

114 Since July 2021, over 5,400 UAS children have been temporarily accommodated by the Home Office.
As at the date when Ms Honeyman signed her statement, the Home Office was using six hotels located in
four local authority areas in England. A seventh, Langfords Hotel in Hove, had been “stood up in
anticipation”.

115 The process for transferring UAS children is set out in the NTS Protocol. The NTS operates on a rota
system in which regions and nations take it in turns to assume responsibility for UAS children referred into
the scheme. There is a weighting system to take wider pressures into account. Currently, local authorities
are expected to accept UAS children until they reach a threshold, currently set at 0.1% of the area's child
population. If a local authority is willing to take more, it can do so. Based on incomplete management
information self-reported by local authorities, 24 local authorities are current exceeding the 0.1% threshold.

116 The NTS process has been amended for UAS children arriving in Kent. When a UAS child arrives in
Kent, and Kent CC is unable to support them, the child's asylum claim is registered at the KIU and an
officer refers the child to the NTS Team in the Home Office. When the referral is received the NTS Team
review the case to see if there is any reason why the child cannot be allocated to a region in England or to
one of the other nations (if it is that nation's “turn” on the rota). If a child has a relative residing in a
particular area, they would normally be allocated to that area. The lead for UAS children in the relevant
Strategic Migration Partnership then notifies the NTS team of the local authority area to which the child has
been allocated and the date of the referral. When the local authority has identified a care placement, they
email the NTS team and the transfer from temporary hotel accommodation is arranged.

117 On 10 September 2021, the Kent Protocol was agreed between Kent CC and the Home Office. It set
up the RSCS to “more effectively manage and support the arrival of vulnerable young people into the
United Kingdom who arrive in Kent”. This requires Kent CC temporarily to look after 120 UAS children
above its 0.1% threshold. This amounts to 466 children. Between 10 September 2001 and 26 June 2023,
1,924 UAS children have been accommodated in the RSCS. According to management data, of these,
1,493 have been transferred to other local authorities through the NTS; and 362 were withdrawn from the
NTS for various reasons (including that they remained in Kent CC's care, were reunited with family
members, turned 18 and were supported by Kent CC as care leavers; or turned 18 and were moved to
adult asylum support accommodation). UAS children “largely flow into the RSCS via the temporary
accommodation provided by the Home Office in hotels as RSCS capacity becomes available, though there
have been brief periods when limited numbers of UAS children were transferred directly into the RSCS
from the KIU”.

118 The Home Office has sought to improve the operation of the NTS in various ways. From 14 December
2021, it made the NTS mandatory for the majority of local authorities with children's services in the UK. Full
mandatory participation commenced on 15 February 2022. From 24 August 2022, it increased the
threshold up to which local authorities must accept UAS children from 0.07% to 0.1% of their child
population and reduced the expected deadline for completion of transfers from ten to five working days for
all UAS children not currently in the care of a local authority From 16 December 2022 it introduced a new


-----

(on the application of Brighton and Hove City Counci....

incentivised funding pilot, which provided £15,000 for each eligible young person taken into care by a local
authority from a Home Office-run hotel or from the RSCS by the end of February 2023.

119 The Home Office considers that it has had no alternative but to temporarily use hotels to give arriving
children an immediate roof over their heads whilst a long-term placement is secured with a local authority.
The hotels are solely for the use of UAS children. The Home Office has put in place “robust safeguarding
procedures” to ensure all UAS children are accommodated and supported as safely as possible while
urgent local authority placements are sought.

120 These measures include: team leaders and support workers on site 24 hours per day, seven days per
week “to ensure children have support, are safe and their daily care needs are met”; teams of qualified and
registered social workers and nurses, alongside a “rolling registration” programme with local GPs to ensure
access to primary healthcare; 24-hour security to protect young people and staff; supervision of social
workers by senior social workers, who in turn are managed by a social work team manager; a matrix team
(made up of staff from the Asylum Safeguarding Hub, professional advisors from Safeguarding Advice and
the Children's Champion, the NTS and “commercial”) overseeing the operation of the UAS children's
hotels. Members of the Temporary UAS Children's Accommodation team, including the social work team
manager, visit the hotels at least weekly to provide support, identify improvements and “drive compliance”.
All those working at the UAS children's hotels have enhanced Disclosure and Barring Service (“DBS”)
clearance.

121 UAS children with additional vulnerabilities (such as cognitive impairment, learning disability, trauma
and/or physical injury or disability) are prioritised by the NTS team and moved to Kent CC's temporary care
in the RSCS whilst the transfer to the allocated local authority is progressed.

122 The Home Office has no power to detain UAS children in these hotels and recognises that some do
go missing. Children's movements in and out of the hotels are monitored and recorded and they are
accompanied by support workers when attending organised activities and social excursions off-site, or
where specific vulnerabilities are identified. When a UAS child goes missing from a Home Office hotel,
there is a Standard Operating Procedure (“SOP”), informed by the Home Secretary's duties under s. 55 of
the 2009 Act and professional advice from the Home Office Safeguarding Team and from the Children's
Champion, explaining the steps that should be taken.

123 During the summer of 2022, the Home Office noticed a spike in the numbers of young people going
missing from Home Office hotels and established a multi-agency “Task and Finish Group”, led by
Immigration Intelligence, to identify mitigating actions, reduce the chances of children going missing and
locate them if they do. The group includes staff from the National Crime Agency, police forces, the
Department for Education and the Home Office.

124 The SOP was last updated in February 2023 and has recently been updated to take account of advice
from the Task and Finish Group and the launch of the National Age Assessment Board on 31 March 2023.
The latest version of the SOP is expected to be operational imminently.

125 The Home Office considers that there is little evidence that disproportionate numbers of UAS children
go missing from Home Office hotels, compared with the numbers of UAS children who go missing from
local authority care. For example, Kent CC experienced a spike in UAS children going missing from their
care in the summer of 2022.

126 The Home Office recognises that Albanian UAS children accounted for the largest proportion of
missing incidents during the spike in the summer of 2022. To mitigate the risk to this cohort of vulnerable
young people, an initial assessment is undertaken by a social worker as soon as a young person arrives on
site. The social worker considers whether the child is displaying any indicators that the child is a potential
victim of **_modern slavery. If so, a referral is made to the NRM and the local authority is informed. For_**
particularly vulnerable children, such as Albanian nationals, social workers put in place a safety plan in
conjunction with the on-site team to mitigate the risks to the extent possible. Third sector and community


-----

(on the application of Brighton and Hove City Counci....

groups are also being identified to provide support to those UAS children identified as at risk of going
missing.

127 The Home Office began temporarily accommodating children at Langfords Hotel, Hove, in July 2021.
Only 16-18 year old males are placed there. The Home Office has worked closely with Brighton & Hove
CC's Children Services to meet the needs of the children accommodated there, including: providing daily
registers; referring all serious safeguarding concerns and issues to Brighton & Hove CC's “frontdoor”
services; providing additional funding to Brighton & Hove's Children's Services in the years 2021/2022 and
2022/2023, in recognition of the additional burden on their “frontdoor” services; and engaging
constructively and collaboratively with Brighton & Hove CC's Children's Services and other local partners
(health, police, community, safety etc.), managed through a specifically established multi-agency forum.

128 The year to the end of March 2023 saw an 8% increase in applications by UAS children compared to
the previous year. The Home Office “must be prepared for this to increase further in the coming
weeks/months”. If there is no change in Kent CC taking arriving UAS children into their care, or the pace of
transfers into the care of other local authorities, it is anticipated that the capacity of all seven hotels will be
required. Ms Honeyman says this:

“45… Any legal barrier to accommodating UASC at established sites such as the Langfords Hotel
increases this risk to vulnerable UASC as it takes at least 4-6 weeks to stand up a new hotel site and it
may encourage other local authorities to seek similar means of preventing hotels in their area being used
to accommodate UASC.”

129 The Home Office considers that it is not possible to make meaningful comparisons between the
numbers going missing from Langfords Hotel and the numbers going missing from other hotels used by the
Home Office, since everything depends on the characteristics of the children being accommodated there.

130 Due to a seasonal decrease in the numbers of arrivals, Langfords Hotel has not been accommodating
young people since 1 March 2023. However, on 19 June 2023, the Home Office wrote to Brighton & Hove
CC advising that, in response to the increased number of arrivals in recent days and in anticipation of
further crossings, they had decided to “stand up” Langfords Hotel.

131 Ms Honeyman concludes:

“51. The Home Office have made clear in public its position that the current situation is not sustainable.
The matter is currently under consideration by Parliament with provisions addressing the position of UAC in
the Immigration and Migration Bill. I am informed that the Bill makes provision for the accommodation and
support of unaccompanied children who are in the scope of the Bill pending their removal once they have
turned 18 years or whilst awaiting removal if the power to make arrangements to remove under 18s is
exercised. The Bill confers a power on the Secretary of State to provide accommodation, and other
appropriate support, for unaccompanied children who are subject to the scheme, and a power (enforceable
through the courts) for the Secretary of State to transfer responsibility for the care of an unaccompanied
child within the scheme to a local authority. These provisions apply to England but with a power, by
regulations, to apply them to Scotland, Wales and Northern Ireland.

52. The Bill does not require the Secretary of State to provide this accommodation but provides the power
to do so if such provision was felt appropriate. A child in scope of the scheme might enter local authority
care without first being accommodated under this power. Whilst the clause contains no time limit on how
long any child spends in Home Office accommodation, the policy intention is that their stay is a temporary
one until they transfer into local authority care.”

132 Dr Elimelech says that the NTS has operated to better distribute the burden of looking after UAS
children across local authorities. The process “necessarily proceeds by way of individual assessments as
to the appropriateness of a particular placement for the child and involves a degree of negotiation despite
the directions in place”. The numbers transferred under the NTS has risen from the low hundreds per year
in 2016-2019 to 1,276 in 2021, 3,164 in 2022 and 679 in the first quarter of 2023.


-----

(on the application of Brighton and Hove City Counci....

133 The Home Secretary's decision to “stand up” hotel accommodation in July 2021 was preceded and
triggered by Kent CC's announcement on 11 June 2021 that it would cease to accept newly arriving UAS
children. Dr Elimelech attributes the pressures on Kent to fluctuations in the numbers of UAS children
arriving, rather than to the operation of the NTS.

134 The Home Office had to react at speed to Kent CC's decision to refuse new arrivals. A ministerial
submission was prepared, indicating that the KIU was not a secure location at which children could be
expected to stay for long periods. A deterioration in the mental health of those accommodated there had
been noted. There was no access to the sort of one-to-one social and health care to which the children
were entitled. Other alternatives were considered, but hotel accommodation was the only feasible one,
given the urgency of the problem.

135 The identification of hotels takes account of a range of factors: the capacity of the hotel; whether there
are unsuitable premises (such as bars and nightclubs attached to the hotel); whether there is space for
children to eat, a recreation room and outside space. The need for available, suitable accommodation is an
overriding consideration. The Home Office “regards [UAS children] placed in a hotel temporarily within the
area of another local authority as sitting outside the NTS and thus as not 'counting' towards the 0.1%
threshold which exists”.

136 There are five local authorities with hotels in their area. According to management information for
June 2023, three of these are below the 0.1% threshold, discounting those in hotels. Brighton & Hove CC
was at 0.11%. Kent was at 0.1% not counting those in the RSCS. If UAS children in hotels counted
towards the 0.1% threshold, then in some cases hotels would account for much if not all of the total
number of children that a local authority could be required to take under the NTS. This would be contrary to
the intention to spread the burden equitably across local authorities.

137 The provision of hotels is “an exceptional, temporary measure to address a crisis situation”. The
Home Office aims to end their use.

138 In the summer of 2021, the Home Office faced a situation in which Kent CC had announced that it
would cease to accept newly arriving UAS children. In the negotiations which led to the Kent Protocol, it
became clear that Kent CC was willing to take additional UAS children, but only on certain conditions,
including (i) funding from the Home Secretary; (ii) a cap on numbers, set at the then threshold of 0.07 plus
120 children in the RSCS; (iii) no long-term planning for those in the RSCS; (iv) the Home Secretary to use
her best endeavours to transfer UAS children in the RSCS within a total of 15 working days. Ministers were
asked to approve the RSCS on 8 September 2021.

139 Once the RSCS came into operation, in September 2021, the numbers being accommodated in hotels
did not markedly increase or decrease. The Home Office considers that it is “beneficial to the best interests
of the children for them to be looked after by Kent CC, even in this modified way pending transfer, than
accommodated across hotels commissioned by [the Home Secretary] for this purpose”. As at 17 July 2023,
218 UAS children are accommodated in hotels.

140 Under the RSCS Operational Guidance, UAS children are transferred from hotels to the RSCS as
spaces become available. Twice per week, Kent CC reviews capacity in the RSCS and confirms how many
UAS children can move to their temporary care. They confirm the number of places available in their
reception centres (for males of 16 and over) and how many foster places (for males under 16 and
females). When the numbers of UAS children in the RSCS drop significantly below the 120 cap, Kent CC
will collect males aged 16 and over from the KIU. When the numbers in the RSCS are at 90 or more, it
does not. Instead, the Home Office NTS teams refers UAS children in hotels to the RSCS.

141 The NTS team in the Home Office prioritises the more vulnerable UAS children for RSCS placements,
as well as children who have been in hotels for the longest periods. Where an exceptionally vulnerable
child arrives and the 120 cap has already been reached, the NTS team (or KIU at weekends and out of
hours) will request that Kent CC identify a placement exceptionally.


-----

(on the application of Brighton and Hove City Counci....

142 When a UAS child is moved into a hotel, the Home Office endeavours to ensure that the local
authority for the area is notified promptly.

143 Dr Elimelech is aware that the use of hotels was intended as a temporary measure when it first
began. However, the Home Secretary does not accept that, if it simply ceased to provide this
accommodation, newly arriving UAS children would be looked after by Kent CC. Nor does she accept that
the NTS could be operated more effectively than it is now being operated. The Home Secretary is “picking
up the pieces and ensuring a safe and practical mechanism to ensure that those children who would
otherwise be without safe shelter… have access to food, safety and support”.

144 The Home Secretary attributes the continuing need to use hotels to the sustained high numbers of
small boat arrivals. On 23 March 2023, the Home Secretary agreed to the continued use of hotels for
accommodating UAS children throughout 2023. This was in the context of what was known as the
“incentivised funding pilot” coming to an end. The pilot involved providing funding of £15,000 for each UAS
child transferred into local authority care from a hotel, or from the RSCS. The ministerial submission
identified advantages to the use of hotels over continuing with the pilot. The use of hotels was, therefore, a
response to gaps created by (i) Kent CCC's derogation from its statutory duties; and (ii) insufficient uptake
from other local authorities.

145 Since the point where the NTS was mandated, the average times taken to transfer a child via the NTS
(taken from management data) are: 9 working days for transfers from a hotel to receiving local authority; 11
working days for transfers from an entry local authority other than Kent to a receiving local authority; 16
working days for transfers from the RSCS to a receiving local authority.

146 It is true that the NTS does not contain any enforcement provisions. It would be difficult to design such
provisions, given that the NTS cannot be used to place UAS children in areas where doing so would cause
undue prejudice. Nevertheless, the NTS includes an escalation procedure. Compliance with the 10 and 5
working day timescales is monitored and, as at 4 July 2023, 354 cases had been referred to the escalation
procedure.

147 The Home Office is actively pursuing opportunities to reduce the reliance on hotels and has taken a
series of steps to increase the volume and speed of transfers into local authority care. This includes
changes to the NTS threshold (increasing it to 0.1%); reducing the time to move a child not in care into a
placement to 5 working days; providing additional funding of £6,000 over 3 months for young people
moved from hotels within 5 working days; and additional incentivised funding of £15,000 per child
transferred from the RSCS and hotels accommodating UAS children.

148 At para. 108 of her statement, Dr Elimelech says this:

“However, there is not an 'exit strategy' from hotels as such. Until the number of UASC arriving in small
boats reduces considerably, or local authorities begin to accept more responsibility and with greater speed,
there will be numbers of UASC who have nowhere to go when they arrive. The causes which first led to the
temporary use of hotels for this cohort have not gone away. Instead, the Home Office seeks to minimise
the use of hotels by making the NTS work as well as it can, and by introducing and part-funding the RSCS
in liaison with Kent CC.”

Brighton & Hove CC

149 Brighton & Hove CC's evidence is contained in witness statements from Deborah Austin, its Director
of Children's Services, Nigel Manvell, its Chief Financial Officer, Justin Grantham, Head of Safeguarding
and Performance Families, Children & Learning and Chris Robson, Brighton and Hove Safeguarding
Children's Partnership's Independent Scrutineer. Much of that evidence is relevant to issues which have
not been identified for resolution now. However, the following points are of relevance to the preliminary
issues.

150 The numbers of children going missing from Langfords Hotels is a very serious concern for Brighton &
Hove CC and for Sussex Police. As at 15 June 2023, 139 UAS children accommodated at Langfords Hotel


-----

(on the application of Brighton and Hove City Counci....

had gone missing, of which 12 were suspected or alleged to be involved in crime or exploitation (thought to
be indicative of the endemic issue of “County Lines” drugs gangs based in Brighton). As at 20 June 2023,
50 were still missing. These account for all but one of the young people recorded by the police as missing
from the City.

151 In selecting Langfords Hotel, the Home Secretary did not take advice from Brighton & Hove CC. If she
had, Brighton & Hove CC would have pointed out that the hotel is not fit for purpose, given its lack of
secure outdoor space and its ownership. It is owned by a company called Tombstone Ltd, whose directors
include four children of Nicholas Hoogstraten.

152 Ms Austin says that, in operating Langfords Hotel, the Home Secretary is running an unregistered, de
facto children's home with a capacity for approximately 70 children. The children are not there for only a
few days. They are there for weeks and in a few cases months. A children's home for traumatised
teenagers would normally have no more than three or four residents at any one time, given the complexity
of the children's needs. In selecting the children who are placed there, the Home Office appears to operate
no screening process beyond considering the age of the children.

153 As the authority in whose area the children are physically present, Brighton & Hove CC has
assessment duties under s. 17 CA 1989 and safeguarding duties under s. 47 CA 1989. When it first
informed Brighton & Hove CC that UAS children were to be placed at Langfords Hotel, the Home Office
gave an assurance that it would act as corporate parent. An entry in the Home Office risk register on 18
August 2021 records: “Senior civil servants confirmed we are running childrens homes and committing a
criminal offence but relying on the defence of necessity”.

154 Ms Austin says that the use of hotels is not a temporary measure, but a long-term system. Brighton &
Hove CC “simply cannot discharge its statutory duties if the [Home Secretary] continues to operate this
unlawful scheme”.

155 Concerns about the safety of Langfords Hotel were raised in a report dated February 2023 by the
local Safeguarding Partnership, chaired by Chris Robson, who is the Independent Scrutineer. It identified
serious safeguarding issues. Mr Robson has filed a statement indicating the numbers who have gone
missing and setting out details of the criminal exploitation to which 12 of them have been exposed.

The UASC Strategic Review

156 On the afternoon of the second day of the hearing, following a request by ECPAT's solicitors,
Freshfields, the Home Secretary disclosed a document entitled UASC Strategic Review: April – October
2022 (version 1.0). This document is on UK Visas and Immigration headed notepaper and is marked
“Official Sensitive”. However, the Government Legal Department have indicated, on instructions, that it is in
[fact an external report prepared by an organisation called Baringa, that it was prepared before the Illegal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)
_[Migration Act 2023 was enacted and that it no longer represents government policy. It makes a number of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_
criticisms of the Home Secretary's practice of using hotels to accommodate UAS children and makes
recommendations for change.

**Discussion**

157 A review of the statutory scheme and authorities establishes that it is local authorities, and not the
Home Secretary, which have the primary duty to accommodate and look after UAS children. Any analysis
of the powers and duties applicable in this case must, therefore, start with the position of Kent CC. I have
re-ordered the preliminary issues accordingly.

Issue 6: The legality of Kent CC's cap on the number of UAS children it will accept into care

158 Most cases end up being fought because one party says that another party has done or is doing or is
threatening to do something unlawful and the allegation is denied. This case is unusual in that Kent CC has
acknowledged from the outset that, in declining to accommodate UAS children when it has reached what it
regards as its safe limit, it is breaching its statutory duty under s. 20 CA 1989. All the other parties agree.


-----

(on the application of Brighton and Hove City Counci....

Sometimes counsel referred to Kent CC's stance as a “derogation” from its duty, but this was just a polite
way of saying the same thing.

159 The parties are correct. Issue 6 is, therefore, the most straightforward of those I have to determine:
[Kent CC was and is acting unlawfully, in breach of its duties under the CA 1989,by failing to accommodate,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
and then look after, all UAS children when notified of their arrival by the Home Office. This is because
newly arrived UAS children are necessarily children in need to whom the s. 20 duty is owed; and because
it is well-established that the duty is absolute and non-derogable and applies irrespective of the resources
of the local authority.

160 Moreover, in announcing that it would cease to accept responsibility for some newly arriving UAS
children, while continuing to accept other children into its care, Kent CC has chosen to treat some UAS
children differently from and less favourably than other children, because of their status as asylum seekers.
Whether this amounts to unlawful discrimination contrary to ss. 19 and 29 of the Equality Act 2010 or
contrary to Article 14 read with Article 8 ECHR (and therefore contrary to s. 6 HRA 1998) is not among the
preliminary issues for determination at this stage. But whatever the answer to that question, Kent CC's
refusal to accommodate and look after UAS children violates a fundamental aspect of the statutory
[scheme, which I sought to identify at paras 23-24 above: a local authority's duties under the CA 1989 apply](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
to all children, irrespective of immigration status, on the basis of need alone.

Issue 7: The legality of the Kent Protocol

161 Mr Southey for Kent CC sought to distinguish the accepted illegality of Kent CC's decision not to
accept newly arriving UAS children (announced most recently on 11 June 2021) from the Kent Protocol,
which he submitted was a genuine attempt by Kent CC to avoid the use of hotels and could have
succeeded if the Home Secretary had ensured that children received into the RSCS were transferred out
within 10 working days, as the protocol envisaged. Mr Southey submitted that the Kent Protocol was not
itself unlawful, applying the test in R (A) v Secretary of State for the Home Department, at [46].

162 The difficulty with this submission is that it measures the legality of the Kent Protocol by reference to
Kent CC's motives and intentions in agreeing it, rather than by reference to its terms, objectively construed.
I accept that Kent CC intended and expected that it would help to avoid the existing illegality which had
been acknowledged, but the protocol's terms included a cap on the numbers of UAS children which Kent
CC would accept. It is inherent in the concept of a cap that Kent CC will continue to refuse to discharge its
statutory duties in respect of a particular cohort of children – i.e. UAS children who present themselves at a
time when the numbers of UAS children already in care have reached the cap. In other words, the Kent
Protocol expresses Kent CC's contingent intention to breach its statutory duty in respect of those children
should those circumstances arise – as in fact they have, consistently, since the protocol was agreed.

163 Mr Southey submitted that there was nothing to suggest that Kent CC envisaged in September 2021
that the cap would ever be reached. He pointed to documents which showed that Kent CC was concerned
that the RSCS might be uneconomic because it was under-used and that it negotiated a minimum payment
from the Home Office because it regarded this as a likely outcome. I accept that this casts some light on
Kent CC's expectation, but the inclusion of a cap on numbers would have been unnecessary if there were
no possibility that the cap would ever be reached. That a cap was included shows that, whatever it hoped
or expected, Kent CC did consider the possibility that the cap might be reached and decided that, in that
event, it would breach its statutory duty in respect of the cohort I have identified.

164 Mr Westgate for ECPAT submits that the Kent Protocol is unlawful because it formalises a policy that
tells staff working in Kent CC's children service that they can refuse to accommodate a child to whom a
duty is owed under s. 20 CA 1989 if doing so would cause the cap to be exceeded. This would “induce a
person who follows the policy to breach their legal duty” and so falls within the first of the three types of
unlawfulness identified in A, at [46] (the species of unlawfulness identified in _Gillick v West Norfolk and_
_Wisbech Area Health Authority [1986] AC 112). In my judgment, this analysis is correct. Whatever Kent_
CC's intentions in agreeing it, any member of staff who knew of the terms of this agreement, endorsed by


-----

(on the application of Brighton and Hove City Counci....

the Home Secretary, would naturally assume that giving effect to it would be lawful. That assumption would
be false.

165 It does not matter that the Kent Protocol says nothing on its face about the use of hotels. In fact, at the
time when it was agreed, everyone knew that hotels were being used by the Home Secretary. Those who
negotiated it must have assumed they would continue to be used if the cap were reached. But in any
event, the unlawfulness which the Kent Protocol formalises and endorses is not the use of hotels per se,
but the refusal (when the cap is reached) to accept certain children, viz. UAS children, whom the local
authority has a legal obligation to accommodate and look after.

166 I do not find compelling Mr Southey's complaint that the real challenge is to the policy announced on
11 June 2021, rather than to the Kent Protocol itself. Even if the Kent Protocol had simply formalised the
announcement of 11 June 2021, the agreement of the protocol would still be a separate public law act,
challengeable as such. As a matter of fact, however, the 11 June 2021 announcement said something
quite different: that Kent CC would accept no more UAS children at all. That could be regarded as part of a
practice of announcing, from time to time and on an ad hoc basis, that it could no longer safely accept UAS
children. The Kent Protocol, by contrast, was an agreement intended to last for the long term by which
Kent CC agreed to take some additional UAS children, subject to a fixed and unchanging cap. For the
reasons I have given, Kent CC's decision to conclude an agreement in those terms was unlawful.

167 Nor is Kent CC saved by the fact that it does sometimes accept “exceptionally vulnerable” children
even when the cap is reached. The complaint is not that Kent CC has fettered its discretion to accept UAS
children, but that it has announced in advance its intention to refuse to discharge its duty to accept them. It
is obliged to accommodate and look after every such child, not only the exceptionally vulnerable ones.

168 Ms Rhee for the Secretaries of State submitted that, even if Kent CC's decision to agree the Kent
Protocol was unlawful, the Home Secretary's was not. She argues that the Home Secretary had never
endorsed Kent CC's refusal to discharge its statutory duties and was not doing so by agreeing the Kent
Protocol. I find it impossible to accept this submission. As already noted, whether a policy offends the
principles in [46] of _A v Secretary of State for the Home Department depends on its terms, objectively_
construed. If it does, the decision to adopt it will be unlawful. If the policy is contained in an agreement
between two public authorities, then, as a matter of principle, the unlawfulness is attributable to both
parties to the agreement. It does not matter that the breach of duty induced by the policy will be by one
authority alone. There are many examples (including the _Gillick case itself) of guidance given by one_
authority which is unlawful because it induces a person acting on behalf of another authority to breach his
or her statutory duty. The position is a fortiori when the policy is contained or reflected in an agreement to
which both authorities are party.

169 This analysis also accords with the reality of the situation. The Education Secrteary had to decide how
to react to Kent CC's announcement of 11 June 2021. He could have directed Kent CC to comply with its
statutory duties, but chose not to do so. He could have made clear to Kent CC that the law required it to
discharge its duties to all children irrespective of immigration status and committed to provide the (no doubt
much greater) funding and support necessary to achieve a flexible and uncapped service. Instead, the
Home Secretary agreed a protocol premised upon a continuing breach of Kent CC's duties if and when the
cap was reached, on the understanding that, in that event, newly arriving UAS children would continue to
be accommodated in hotels. The responsibility for this unlawful state of affairs lies as much with the Home
Secretary as with Kent CC.

[Issue 2: What does a transfer under s. 72 IA 2016 require](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C465-00000-00&context=1519360)

170 Five features of the statutory scheme in ss. 69-73 IA 2016 are significant.

171 First, both ss. 69 and 72 are concerned with the transfer of _responsibility for relevant children from_
one local authority (the “first” or “transferring” authority) to another (the “second” or “receiving” authority),
rather than the physical transfer of children: see the headings to these sections.


-----

(on the application of Brighton and Hove City Counci....

172 Second, the statutory precondition for transfer is that the first or transferring authority “has” functions
in relation to the relevant child (or that such functions may be conferred on it), not that it has discharged
those functions, whether fully or to any extent: see s. 69(1).

173 Third, s. 69(2) provides for the transfer of functions in relation to a relevant child pursuant to
“arrangements” made by one local authority (“the first authority”) with another local authority (“the second
authority”) in the same part of the UK. By s. 69(3A), arrangements can also be made by the first authority
with a second authority in a different part of the UK. In both cases, there is a transfer of responsibility for
relevant children, though the legal effect is described in slightly different terms because the legislation
conferring functions is different in other parts of the UK. In both cases, however, the statute requires the
active involvement of the first authority in making the “arrangements” for the transfer.

174 Fourth, s. 72(1) empowers the Home Secretary to prepare a scheme for the transfer of functions from
one local authority (“the transferring authority”) to another local authority (“the receiving authority”) in the
same part of the UK “in accordance with arrangements made under section 69(2)”. Section 72(1A)
empowers the Home Secretary to prepare a scheme in relation to one local authority (“the transferring
authority”) and another (“the receiving authority”) in a different part of the UK “having the effects mentioned
in section 69(3B)”. The difference in wording again reflects the fact that authorities in different parts of the
UK will be subject to different legislation, so the functions will not be identical. But in both cases,
“arrangements” made by the transferring authority with the receiving authority are integral to the statutory
scheme. This can be seen from the terms of s. 69(3B), which defines the effects of a scheme made under
s. 72(1A). Those effects are triggered “from the time at which the arrangements have effect in accordance
with their terms”. The “arrangements” in question are those referred to in s. 69(3A).

175 Fifth, nothing in ss. 69 or 72 attenuates or otherwise affects the functions of the “first” or “transferring”
authority up to the point when the transfer of responsibilities takes place. This point is “the time at which
the arrangements have effect according to their terms”: see s. 69(3) & (3B)”.

[176 Mr Westgate for ECPAT and Ms Harrison for Brighton & Hove CC argued that the scheme of the IA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
_[2016 necessarily contemplates that the “first” or “transferring” authority will be discharging functions at the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
point of the transfer. It seems very likely that Parliament envisaged that this would be so in most cases,
because assessing whether it is in a child's best interests to be transferred to another authority in practical
terms involves many of the same steps as assessing a child for the purposes of s. 17 CA 1989; and unless
the transfer takes place very quickly, the duty under s. 20 is likely to be triggered in the meantime. It may
be noted in this regard that the NTS Protocol itself provides the transferring authority “must take into
account the child's best interests as a primary consideration alongside other considerations, and the
appropriateness of transfer must be considered on a case-by-case basis”.

177 However, I accept Ms Rhee's submission for the Secretaries of State that there is nothing in the terms
of ss. 69-73 which makes the prior exercise of functions by the transferring authority a legal precondition of
the transfer of responsibility. If, for example, the transferring local authority assessed the child and made
arrangements with the receiving authority for the transfer of responsibility to take place on the same day, it
is possible to envisage a lawful transfer taking effect before the transferring authority had exercised its s.
20 function. As noted, the precondition for a transfer is simply that the “first” or “transferring” local authority
“has” functions under the _[CA 1989 (or that such functions may be conferred on it), not that it has](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
discharged those functions.

178 But, whereas a prior exercise of functions by the transferring authority is not necessary for a transfer,
“arrangements made by the transferring authority” are. Parliament could have empowered the Home
Secretary simply to direct the receiving authority to provide accommodation for the child from the transfer
date. A power to that effect will be conferred by s. 17 of the 2023 Act when that provision is brought into
[force. However, the IA 2016 does not empower the Home Secretary to prepare a scheme for the transfer](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
of responsibilities other than in accordance with arrangements made by the “first” or “transferring” authority
with the “second” or “receiving” authority. Sections 69-73 provide for the transfer of responsibility for UAS


-----

(on the application of Brighton and Hove City Counci....

children between local authorities. They do not provide for “transfers” in which the “first” or “transferring”
local authority plays no part at all.

179 At its inception, the NTS Protocol was fully consistent with these aspects of the statutory scheme, as I
have interpreted it. It was structured to require a request by the transferring authority and an acceptance by
the receiving authority, leading to the inter-authority “arrangements” contemplated by ss. 69 and 72. The
structure of the NTS Protocol has remained broadly the same, subject to one important change. With effect
from 14 December 2021, it was amended to provide for (or at least acknowledge the fact of) referrals into
the NTS of children who were “not in the care of a local authority”. As I have said, the fact that no local
authority has yet discharged functions in respect of these children does not in law preclude a transfer being
made. But, although the NTS Protocol does not say so in terms, the practice has been that the
“arrangements” for transfers in these cases are made between the Home Secretary and receiving
authority, with no part being played by the “first” or “transferring” authority: see the excerpt from Ms
Honeyman's statement set out at para 65 above.

180 Ms Rhee submitted that this was lawful, because – for this cohort of children – the Home Secretary
was arranging the transfer “in lieu of the local authority”. This is a beguiling phrase, but it is legally
imprecise and, however it is interpreted, it does not accord with the statutory regime. If “in lieu of” means
“as delegate of”, the submission is wrong both in law and in fact. As to the law, Parliament conferred the
power to make “arrangements” for a transfer of functions on the “first” or “transferring” authority in
circumstances where it must have envisaged that authority forming a view about the appropriateness of the
transfer in the individual case. It did not authorise the first authority to delegate the power to make these
arrangements to anyone else. It authorised the Home Secretary to make a scheme to provide for transfers
of responsibility, but only in accordance with arrangements between local authorities. In any event, even if
the statutory regime allows the transferring authority to delegate the power to make arrangements for the
transfer, there is no evidence that Kent CC has in fact delegated that power in respect of the UAS children
for whom it refuses to accept responsibility.

181 If “in lieu of the local authority” means “as agent for the local authority” the submission is
fundamentally at odds with the evidence. The reason why the Home Secretary has to accommodate UAS
children in hotels is precisely because Kent CC refuses to accept responsibility for them. The Kent Protocol
says nothing about how the Home Secretary will provide for them. There is no evidence that Kent CC is
involved in any way with, let alone has authorised, the actions taken by the Home Secretary to provide for
them, whether with respect to accommodation or with respect to transfer.

182 It follows from this analysis that the _[IA 2016 does not permit transfers of responsibility for UAS](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
children in accordance with “arrangements” in which the “first” or “transferring” authority plays no part. This
does not preclude all transfers of UAS children who are accommodated in hotels, but it does require the
first authority to make the arrangements for the transfer. Under the terms of the NTS Protocol, before the
first authority makes such arrangements, it must satisfy itself of the appropriateness of the transfer on a
case-by-case basis, taking into account the child's best interests as a primary consideration.

Issue 8: What is the scope of the Home Secretary's power of direction under s. 72(3)?

183 The power in s. 72(3) is to direct “the transferring authority and each receiving authority under a
scheme” to comply with the scheme. Given that a transfer can only be made between one transferring
authority and one receiving authority, the reference to “each receiving authority” suggests that the direction
requires compliance with the scheme generally, rather than in an individual case. That impression is
bolstered by the procedural requirements in s. 72(5)-(7). These paragraphs require the Home Secretary to
give notice in writing of any proposed direction, then to allow 14 days for the local authority to make
representations and (by necessary implication) consider the representations before making the direction.
This timescale would be impracticable if the direction-giving power were exercisable in relation to individual
cases. Section 72(9) (which refers to “arrangements made pursuant to the direction before it was modified
or withdrawn”) seems to confirm that the direction to comply with the scheme was intended to apply
generally rather than to a specific case.


-----

(on the application of Brighton and Hove City Counci....

184 The statute contains no bespoke mechanism for enforcing compliance with a direction generally or in
any specific case. There is, for example, no express power to apply to the court to enforce the direction by
mandatory order. But the absence of such an express power does not matter, because the conferral of a
power to “direct” a local authority to “comply” with the scheme necessarily implies that, where the direction
is lawfully made, the local authority is under a duty to comply with it. The duty would be enforceable by
proceedings for judicial review even without an express enforcement power.

185 It follows that the Home Secretary has exercised the only power of direction she has under the _[IA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
_[2016. She could have taken steps to enforce that direction by judicial review proceedings against](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
recalcitrant local authorities. Whether her failure to do so is irrational is not among the preliminary issues
for determination today.

Issues 1 and 4: The Home Secretary's practice of accommodating children in hotels?

_The submissions_

186 The parties' submissions on this issue reflects their very different perspectives about how to
characterise the Home Secretary's use of hotels to accommodate UAS children.

187 Ms Rhee for the Secretaries of State started by noting that Kent CC had made it very clear that it
would not provide accommodation to UAS children who arrived at a point when the cap for entry to the
RSCS had been reached (save in “exceptionally vulnerable” cases). There was no prospect of anyone else
doing so. In those circumstances, there were only two options: either the children would remain at the KIU
(which was manifestly unsuitable for stays of a few days, let alone weeks or months) or the Home
Secretary would have to provide accommodation. In choosing the latter option, she was simply “picking up
the pieces” left by Kent CC's breach, to use Dr Elimelech's phrase. The provision of accommodation was,
therefore, no more than a temporary, emergency measure. Viewed in those terms, there must be a
prerogative or common law power to provide it. The alternative could leave the UK in breach of its
[obligations under Article 2 and 3 ECHR. This did not undermine or frustrate the CA 1989 regime, because](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
[the reason why accommodation was being provided was that Kent CC had failed to discharge its CA 1989](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
obligations.

188 Mr Southey for Kent CC did not, of course, accept the suggestion that the Home Secretary was forced
to act by Kent CC's breach of duty. However, he accepted and averred that the Home Secretary must have
a power, either under s. 3(5) CA 1989 or at common law (invoking the principle of necessity) or under s. 6
HRA 1998 (where necessary to avoid a breach of Articles 2 or 3 ECHR) to accommodate children if the
alternative was to leave them at the KIU or without any accommodation at all.

189 Mr Westgate for ECPAT and Ms Harrison for Brighton & Hove accepted that there was a narrowly
circumscribed power under s. 3(5) CA 1989 to provide accommodation in a true emergency, but that the
situation here could not on any view be characterised as an emergency. It had now persisted for over two
years. Whatever the hope or intention, the latest decision to extend the use of hotels, taken in March 2023,
contemplated their use for the remainder of the year. The practice had now become routine.

190 The analysis can be broken down into five stages.

_(1) Does the Home Secretary have power to accommodate UAS children at all?_

191 Leaving aside s. 3(5) CA 1989 for the time being, the Home Secretary has no express power to
accommodate UAS children. Indeed, the position is somewhat starker than this because the exclusion of
children from the definition of asylum-seekers in s. 94(1) of the 1999 Act is a strong indication that
Parliament made a positive choice not to confer such a power. But all the parties balked at the submission
that there was no power at all, even in an emergency situation. In my judgment, their stance was not only
understandable, but also analytically correct.

192 In _R v Somerset County Council ex p. Fewings [1991] 1 All ER 513, at 524, Laws J identified a_
fundamental constitutional asymmetry:


-----

(on the application of Brighton and Hove City Counci....

“For private persons, the rule the rule is that you may do anything you choose which the law does not
prohibit… But for public bodies the rule is opposite… It is that any action to be taken must be justified by
positive law.”

193 The distinction was repeated by Sir Thomas Bingham MR in the same case on appeal: [1995] 1 WLR
1037, 1042. But the public body to which Laws J was referring was a local authority, whose powers were
derived exclusively from statute. The powers of the Crown are not so derived; and, in addition to those
powers which it has as sovereign (the Royal prerogative stricto sensu), it may also do whatever a private
person may do: R v Secretary of State for Health ex p. C [2000] HRLR 400, 405 (Hale LJ). These latter
powers have been referred to as the “common law powers of the Crown”: see the speeches in R (Hooper)
_v Secretary of State for Work and Pensions_ _[2005] UKHL 29, [2005] 1 WLR 1681._

194 Suppose that a UAS child arrived in the UK and, for whatever reason, was not provided with food or
shelter by a local authority. It seems to me obvious that, subject to any statutory restriction, a charitably
minded private individual could lawfully provide food, shelter and other support. So, therefore, can the
Crown, unless a statutory provision has modified or excluded the common law power. In the case of the
Crown, the breadth of the power must be informed by the obligation under s. 6 HRA 1998 not to act
incompatibly with Convention rights. In my judgment, the Crown, acting through the Home Secretary, must
have power to provide food, shelter and support, at least to the extent required to avoid a breach of Articles
2 and 3 ECHR.

195 There was some discussion as to whether s. 3(5) CA 1989 now “occupied the field” so as to replace
or modify the common law power (in the sense described in _Miller v Secretary of State for Exiting the_
_European Union_ _[2017] UKSC 5, [2018] AC 61, at [48]). I do not consider it necessary to resolve this issue,_
because in my judgment the position would be the same whether the power to provide food, shelter and
support comes from the common law or from s. 3(5). Mr Westgate and Ms Harrison attached significance
[to the fact that the power in s. 3(5) is limited by the words “subject to the provisions of [the CA 1989]”. But,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
by s. 3 of HRA 1998, a statutory power would have to be read compatibly with the ECHR rights of the
[children concerned; and a common law power would still be subject to any provisions of the CA 1989 that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
were relevant to its exercise.

_[(2) Section 11 of the Care Standards Act 2000](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4J0-TWPY-Y1H9-00000-00&context=1519360)_

196 One possible limit on the scope or extent of the power to provide accommodation is s. 11(1) of the
CSA 2000, which (read with s. 1(2) of that Act) makes it an offence to carry on or manage an unregistered
children's home. The officials responsible for the Home Office risk register appear to have thought that this
offence was in principle being committed. As they saw it, the only answer lay in the doctrine of necessity,
which might provide a defence.

197 It is understandable that this issue has exercised those tasked by the Home Secretary with managing
risk. When a local authority places an individual child in an unregistered children's home, the person who is
or may be committing the offence is likely to be the person who runs the home. Where, however, an entire
hotel is commissioned by the Home Secretary for the sole purpose of accommodating children, there may
be an argument that the Home Secretary herself (or her department) is “carrying on” the establishment.

198 Section 1(2) of the CSA 2000 defines a children's home as an establishment which “provides care and
accommodation wholly or mainly for children”. Since the commissioning arrangements stipulate that the
hotels are exclusively for the use of children, whether the offence is in principle committed is likely to
depend on whether the establishment provides “care” as well as accommodation. As to that, the Home
Secretary's evidence goes to great lengths to emphasise the extent to which what is provided goes beyond
mere food and shelter and includes assistance from social workers, nurses and other support staff.
Whether this package amounts to “care” in any given case may be a fact-sensitive question. Whether a
defence of necessity is available at all raises an unresolved question of law. Whether such a defence
would be made out on the facts of an individual case may also be difficult to determine in advance.


-----

(on the application of Brighton and Hove City Counci....

199 I cannot and do not need to resolve these questions, which would be for a criminal court to determine
if a prosecution were brought. An analogy may be drawn with the approach of the Supreme Court in In Re
_T (A Child)_ _[2021] UKSC 35, [2022] AC 723. There, the question was whether a court could, under its_
inherent jurisdiction, authorise the placement of a child in an unregistered children's home if the person
carrying on or managing the establishment was or might be committing a criminal offence. The answer was
in the affirmative, but this did not mean, however, that the possibility that a criminal offence might be
committed was irrelevant. On the contrary, it was “sufficient for the court to be aware of the potential that
such an offence may be committed by another and to examine how that impacts on the best interests of
the child”: see at [168] (Lord Stephens, with whom Lord Lloyd-Jones, Lord Hamblen and Lady Black
agreed). This meant that the exercise of the court's power was subject to strict limits – in particular, a
requirement to take steps to register the home as quickly as possible.

200 The facts that there is a serious possibility of an offence being committed, and that the Home Office
itself appears to be relying on the defence of necessity to avoid that consequence, serve to underline that
the provision of accommodation by a person other than a local authority is not in accordance with the
scheme laid down by Parliament.

_(3) What constraints does the regime of the_ _[Children Act 1989 place on the Home Secretary's power to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
_accommodate UAS children?_

201 The _[CA 1989 imposes duties on local authorities and says nothing about the powers of the Home](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
Secretary. This does not entail that the Home Secretary has free rein to provide accommodation of a kind
which Parliament envisaged should be provided by local authorities, with all the concomitant duties
imposed on them in respect of looked after children. Here, the reasoning In Re T illustrates a broader point:
when it lays down a detailed statutory scheme about how children are to be cared for by local authorities,
the scheme does not necessarily exclude the powers of other actors (in that case, the court; here, the
Home Secretary) to fill gaps in a true emergency situation, but it may nonetheless impose constraints on
the exercise of those powers. The constraints may include strict limits on the period for which the power
can be used to achieve a result that is contrary to what Parliament intended and obligations, during that
period, to do everything that can be done to regularise the position.

202 In my judgment, similar constraints apply to the use of the Home Secretary's power to provide
accommodation. The power may be used over very short periods in true emergency situations, where
stringent efforts are being made to enable the local authority promptly to resume the discharge of its duties.
It cannot be used systematically or routinely in circumstances where it is intended, or functions in practice,
as a substitute for local authority care. The use of the power in that way, particularly pursuant to formalised
arrangements that are not time-limited, would undermine and frustrate Parliament's intention that children
who are owed duties under s. 20 CA 1989 are to be not only accommodated, but also looked after by a
corporate parent with the relevant expertise and experience.

_(4) Has the Home Secretary exceeded the limits of the power to accommodate UAS children?_

203 Deciding whether these limits have been exceeded will require fine judgments in some cases. Every
newly arriving UAS child that Kent CC refuses to accept is, in one sense, in an emergency situation. But
the court's analytic and remedial toolkit is not narrowly confined to examining the position of each newly
arriving child and asking whether that child should be left without accommodation or accommodated by the
Home Secretary, those being (on the Home Secretary's case) the only options given Kent CC's breach of
duty. The court can stand back, look at the wider picture and ask whether, overall, the accommodation
power is being used systematically or routinely as a substitute for local authority care, rather than as an
emergency measure to fill an unexpected gap in provision.

204 On the facts of this case, there is only one answer. The Home Secretary has been accommodating
children in hotels for over two years. It may be that, in June and July 2021, the Home Secretary could
plausibly have contended that the commissioning of hotels was intended and functioning an emergency
measure. It is much more difficult to make that case after September 2021, when she agreed the Kent
Protocol which formalised the cap on the numbers of UAS children that Kent CC would accept against a


-----

(on the application of Brighton and Hove City Counci....

common understanding that any UAS children who arrived when the cap had been reached would be
accommodated by the Home Secretary in hotels. She and Kent CC may well have hoped that it would not
be necessary to use hotels, but it rapidly became clear that this intention was not being realised. The fact
that the cap had been formally agreed appears to have had the effect of entrenching and normalising the
practice of using hotels to accommodate UAS children. Nothing was done to increase the capacity of the
RSCS. The amendment of the NTS Protocol in December 2021 to include express reference to children
“not in the care of a local authority” is an indicator that the practice was by then already both systematic
and routine and had become an established part of the procedure for dealing with UAS children. The
decision in March 2023 to continue using hotels for the remainder of this year confirms this.

205 By December 2021 at the latest, the Home Secretary's provision of hotel accommodation for UAS
children had exceeded the proper limits of her powers and become unlawful.

_(5) What can the Government do?_

206 It has been a consistent feature of the submissions for the Secretaries of State that Kent CC's refusal
to discharge its duties with respect to UAS children when the cap is reached should be treated as a fixed
feature of the factual and legal landscape; and that the legality of the Home Secretary's response should
be measured against it. But remedying a breach of duty by one public authority may often require action by
another, particularly where the remedy may involve the provision of additional funding.

207 In this case, the Secretaries of State have a range of options open to ensure that UAS children are
accommodated and looked after as envisaged by Parliament. These include: directing Kent to comply with
its statutory duty under s. 84 CA 1989 (a power which can be exercised by the Education Secretary);
increasing the funding made available to Kent CC with a view to lifting the cap on the number of UAS
children the RSCS can accept; increasing the financial incentives available to other local authorities to
encourage them to accept transfers from the RSCS more timeously; making more robust the arrangements
for dispute resolution in the NTS Protocol (for example, by introducing a binding adjudication mechanism);
and bringing judicial review proceedings to enforce the terms of the NTS. It is for the Home Secretary to
decide whether to take any of these measures, or others, and if so in what combination.

Issue 3: Is the Home Secretary failing to comply with the express terms of the NTS Protocol including in
respect of the requirement to transfer a child from one local authority to another within 10 working days?

208 If there is any breach of the timescales in the NTS Protocol, the primary breach is on the part of local
authorities, not the Home Secretary. The NTS Protocol itself does not itself provide what the Home
Secretary must do in response to a breach by one or more local authorities. The decision whether and if so
how to remedy such breaches is for her, subject to the usual public law constraints. Whether she has acted
irrationally, or otherwise unlawfully, in taking that decision is not a matter that can be determined as a
preliminary issue.

Issue 5: Is the Home Secretary acting unlawfully in accommodating relevant children in hotels in areas in
which the relevant local authorities have already exceeded their 0.1% threshold?

209 The identification in the NTS of a threshold (initially 0.07% of the total child population, then 0.1%)
beyond which local authorities are entitled to request transfers, and below which they may be required to
accept them, shows that the Home Secretary regards these ratios as relevant to the authority's ability to
[discharge its CA 1989 functions in respect of further UAS children.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)

[210 It is now common ground that accommodating children in hotels engages CA 1989 functions on the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
part of the local authority in whose area the hotel is situated. Those functions will certainly include the s. 17
assessment function and the s. 47 safeguarding function. Given the vulnerability of the UAS child cohort,
and their likely need for the services available to looked after children, it is also likely to include the full s.
20 accommodation duty. Having made a transfer scheme structured around a 0.1% threshold, rationality
dictates that the Secretary of State ought, when deciding where to commission hotels for emergency


-----

(on the application of Brighton and Hove City Counci....

accommodation, to consider the impact that accommodating children in such hotels will have on the local
authority.

[211 It does not follow, however, that the burden on the local authority of discharging its CA 1989 duties in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
[respect of a child in a hotel is necessarily equivalent to that of discharging its CA 1989 duties in respect of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
a child in a long-term placement. Much will depend on the circumstances. I would accordingly reject the
suggestion that rationality imposes a hard-edged duty not to accommodate children in hotels in local
authority areas where the authority already exceeds the 0.1% threshold.

212 A separate and more modest argument was made by Ms Harrison for Brighton & Hove CC that the
decision to use Langfords Hotel was initially based on a misdirection of law that the Home Secretary would
be the corporate parent and Brighton & Hove CC would owe no _[CA 1989 duties. Ms Rhee for the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
Secretaries of State responded in a note, disputing the factual basis for the argument. The allegation of a
misdirection of law, and the broader allegation that the Home Secretary has failed properly to consider the
[impact of accommodating children in Hove on Brighton & Hove CC's ability to perform its CA 1989 duties,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
are not among the preliminary issues identified by Linden J. Their resolution will turn on a detailed review
of the evidence. I decline to determine this issue now.

**Conclusions**

213 For these reasons, I have concluded as follows:

(a) Kent CC was and is acting unlawfully, in breach of its duties under the _[CA 1989,by failing to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
accommodate, and then look after, all UAS children when notified of their arrival by the Home Office. In
ceasing to accept responsibility for some newly arriving UAS children, while continuing to accept other
children into its care, Kent CC chose to treat some UAS children differently from and less favourably than
other children, because of their status as asylum seekers. This violates a fundamental aspect of the
statutory scheme: that a local authority's duties under the _[CA 1989 apply to all children, irrespective of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
immigration status, on the basis of need alone. (Issue 6)

(b) Kent CC intended and expected that the Kent Protocol would help to avoid the existing illegality which
had been acknowledged, but the protocol's terms included a cap on the numbers of UAS children which
Kent CC would accept. It is inherent in the concept of a cap that Kent CC will continue to refuse to
discharge its statutory duties in respect of a particular cohort of children – i.e. UAS children who present
themselves at a time when the numbers of UAS children already in care have reached the cap. This
formalised a policy which would induce a person who follows it to breach their legal duty. The policy is
therefore unlawful. Since the Home Secretary agreed the Kent Protocol, the unlawfulness is attributable to
her as much as to Kent. (Issue 7)

(c) There is nothing in the terms of ss. 69-73 IA 2016 which makes the prior exercise of functions by the
transferring authority a precondition of the transfer of responsibility. However, the _[IA 2016 does not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)_
empower the Home Secretary to prepare a scheme for the transfer of responsibilities other than in
accordance with arrangements made by the “first” or “transferring” authority with the “second” or “receiving”
authority. Sections 69-73 provide for the transfer of responsibility for UAS children between local
authorities. They do not provide for transfers in which the first authority plays no part at all. At its inception
the NTS Protocol was fully consistent with these aspects of the statutory scheme. But, although the NTS
Protocol does not say so in terms, the practice has been that the arrangements for transfers in these cases
are made between the Home Secretary and receiving authority, with no part being played by the first
authority. This is unlawful. (Issue 2)

(d) The power in s. 72(3) IA 2016 is to direct compliance with the scheme generally, rather than in an
individual case. It follows that the Home Secretary has exercised the only power of direction she has. The
statute contains no bespoke mechanism for enforcing compliance with a direction. But the absence of such
an express power does not matter, because the conferral of a power to “direct” a local authority to “comply”
with the scheme necessarily implies that, where the direction is lawfully made, the local authority is under a
duty to comply with it. The duty is enforceable by proceedings for judicial review even without an express


-----

(on the application of Brighton and Hove City Counci....

enforcement power. The Home Secretary could have taken steps to enforce that direction by judicial
review proceedings against recalcitrant local authorities. Whether her failure to do so is irrational is not
among the preliminary issues for determination at this stage. (Issue 8)

(e) (1) The Home Secretary has power at common law, or under s. 3(5) CA 1989, to accommodate
children in hotels. (2) However, the exercise of that power gives rise to a serious possibility that an offence
would be committed by a person carrying on or managing the hotel. This serves to underline that the
provision of accommodation by a person other than a local authority is not in accordance with the scheme
laid down by Parliament. (3) This scheme envisages that children are to be accommodated by local
authorities, with all the concomitant duties imposed on them in respect of looked after children. The power
may be used over very short periods in true emergency situations, where stringent efforts are being made
to enable the local authority promptly to resume the discharge of its duties. It cannot be used
systematically or routinely in circumstances where it is intended, or functions in practice, as a substitute for
local authority care. (4) From December 2021 at the latest, the practice of accommodating children in
hotels, outside local authority care, was both systematic and routine and had become an established part
of the procedure for dealing with UAS children. From that point on, the Home Secretary's provision of hotel
accommodation for UAS children exceeded the proper limits of her powers was unlawful. (5) There is a
range of options open to the Home Secretary to ensure that UAS children are accommodated and looked
after as envisaged by Parliament. It is for her to decide how to do so. (Issues 1 and 4)

(f) If there is any breach of the timescales in the NTS Protocol, the primary breach is on the part of local
authorities, not the Home Secretary. The NTS Protocol itself does not itself provide what the Home
Secretary must do in response to a breach by one or more local authorities. The decision whether and if so
how to remedy such breaches is for her, subject to the usual public law constraints. Whether she has acted
irrationally, or otherwise unlawfully, in taking that decision is not a matter that can be determined as a
preliminary issue. (Issue 3)

(g) Accommodating children in hotels engages _[CA 1989 functions on the part of the local authority in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)_
whose area the hotel is situated. Those functions will certainly include the s. 17 assessment function and
the s. 47 safeguarding function. Given the vulnerability of the UAS child cohort, and their likely need for the
services available to looked after children, it is also likely to include the full s. 20 accommodation duty.
There is, however, no hard-edged legal duty on the Home Secretary not to accommodate children in hotels
in local authority areas where the authority already exceeds the 0.1% threshold. The argument that the
Home Secretary misdirected herself, and the broader allegation that the Home Secretary has failed
properly to consider the impact of accommodating children in Hove on Brighton & Hove CC's ability to
[perform its CA 1989 duties, are not among the preliminary issues and are not suitable for determination at](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C3K0-TWPY-Y0CT-00000-00&context=1519360)
this stage. (Issue 5)

214 I shall invite further submissions from the parties before deciding what relief should be granted.

**End of Document**


-----

