# R v Gurney [2022] EWCA Crim 1331

Court of Appeal, Criminal Division

Carr LJ, Griffiths J, Hilliard J

21 September 2022Judgment

MR D WOOD appeared on behalf of the First Appellant.

MS V MEADS appeared on behalf of the Second Appellant.

MR P MARSHALL appeared on behalf of the Third Appellant.

MR J POLNAY appeared on behalf of the Respondent.

________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

LADY JUSTICE CARR:

**Introduction**

1. We have before us three related matters:

i) Two applications by His Majesty's Attorney General for leave to refer sentences imposed by HHJ
Barklem sitting in the Crown Court at Kingston upon Thames on the ground that they are unduly lenient.
The offenders in question are Keith Davis ("Davis"), now 56 years old, and Andrew Gurney ("Gurney"), now
aged 51 years.

ii) A renewed application for permission to appeal against sentence imposed by HHJ John sitting in the
Crown Court in Kingston upon Thames on Elliot Walker ("Walker"), now 50 years old.

2. For the avoidance of doubt, when in this judgment we address the applications by His Majesty's
Attorney General, references to “the judge” are to HHJ Barklem. When we address the renewed
application for leave to appeal sentence, references to “the judge” are references to HHJ John.

3. On 8 June 2022, following a 12-day trial before the judge and a jury, both Davis and Gurney were
convicted of involvement in a professional conspiracy to produce tons of amphetamine sulphate ("the
amphetamine conspiracy"). Davis was convicted of involvement in further conspiracies to supply different
class B drugs and also money laundering. Gurney was further convicted as well of a money laundering
offence.


-----

4. On 10 June 2022 the judge sentenced Davis to five years and three months' imprisonment and Gurney
to six years and three months' imprisonment for conspiracy to produce a controlled drug of class B
(amphetamine) contrary to s.1(1) of the Criminal Law Act 1977 (Count 6), this being the amphetamine
conspiracy. Davis was sentenced on the basis that he played a role on the cusp of lesser and significant
role offending for the purpose of the Sentencing Council Guideline for drug offences ("the Guideline"). He
had been trained in the manufacturing process and stored chemicals in a facility rented in his name.
Gurney was sentenced on the basis that he had played a significant role. He was an electrician and
plumber who assisted in building the laboratory in question and who was also trained and also worked at
the laboratory for a period of some nine months producing the amphetamine. Concurrent sentences were
imposed on Davis for further offences contrary to s.1(1) of the Criminal Law Act 1977 as follows:

i) Conspiracy to produce a class B drug (cannabis) Count 2 ("the cannabis conspiracy") – two years and
three months' imprisonment.

ii) Conspiracy to produce a class B drug (ketamine) Count 4 ("the ketamine conspiracy") – four years and
six months' imprisonment.

iii) Conspiracy to conceal, convert or transfer criminal property, Count 5 – 26 weeks' imprisonment.

A concurrent sentence of nine months' imprisonment was imposed on Gurney for possessing criminal
property contrary to s.329(1)(c) of the Proceeds of Crime Act 2002 (Count 7).

5. Walker had earlier pleaded guilty to the amphetamine conspiracy in Count 6 and to possessing criminal
property contrary to s.329(1)(c) of the Proceeds of Crime Act 2002 (Count 8) and also to two other
offences of conspiracy to supply class A controlled drugs (cocaine) contrary to s.1(1) of the Criminal Law
Act 1977 ("the cocaine conspiracies") indicted separately. He was sentenced on 14 December 2021 to a
total of 16 years' imprisonment, made up of two concurrent sentences of 10 years' imprisonment for the
class A conspiracies and a consecutive sentence of six years' imprisonment for the amphetamine
conspiracy and six months' imprisonment for the possession of criminal property to run concurrently. He
was sentenced on the basis that he had played a significant role in the amphetamine conspiracy, assisting
in the obtaining of the relevant glassware from China, and a leading role in the cocaine conspiracies.
Walker's application for permission to appeal against sentence was refused by the single judge on the
papers and is now renewed.

6. Another defendant, John Keet ("Keet"), pleaded guilty to a number of counts and he awaits sentence.
Another alleged co-conspirator, Rajnikant Parmar, remains at large. A fourth alleged co-conspirator,
Bartosz Kaminsky, was acquitted of involvement in the amphetamine conspiracy, but pleaded guilty to a
firearms offence.

7. The evidence against all three offenders arose from data obtained from Operation Venetic, an
investigation by the National Crime Agency arising from the compromise of the encrypted EncroChat
communication service in 2020. Davis and Walker were both identified users of EncroChat handsets.

8. The submission for the Attorney General is that the sentences imposed on Davis and Gurney were
unduly lenient due to an error of principle. The quantity of drugs involved in the amphetamine conspiracy
was about 300 times the starting point of 20kg for Category 1 offending identified in the Guideline. The
judge's approach, which was to uplift the sentence by 20% to take account of the quantity of drugs
involved, was flawed. Further, it is said that the judge failed to have any regard to the principle of totality, in
particular so far as Davis was concerned, making no increase for Davis' additional significant and harmful
criminal activity reflected in Counts 2, 4 and 5.

9. The submission for Walker is that the total sentence of 16 years' imprisonment imposed on him was
manifestly excessive when considering his overall criminality.

**The Facts**

10. The relevant facts can be summarised as follows. We address indictment T20217135 first.

Count 2 Davis: the cannabis conspiracy between 1 March and 2020 and 7 June 2020


-----

11. Analysis of Encro messages showed that Davis, using the EncroChat handle "mister-kebab",
conspired with Keet to supply at least 21kg of cannabis. Davis worked as a courier for Keet. The messages
showed arrangements being made on over three days in March, April and May 2020 for the exchange or
delivery of cannabis.

Count 4. Davis: the ketamine conspiracy between 1 March 2020 and 7 June 2020

12. Analysis of Encro messages showed that Davis conspired with Keet to supply ketamine. On 20 March
2020 there were discussions between Davis and Keet about arrangements for the retrieval of 5kg of
ketamine from someone else in the supply chain. The following day Davis confirmed that the drugs had
been returned. On 5 April 2020 Davis received a message from an unknown man discussing arrangements
for a payment in cash for ketamine earlier supplied by Davis.

Count 5. Davis: the criminal property conspiracy between 1 March 2020 and 7 June 2020

13. Davis delivered and collected cash on behalf of Keet. Messages were recovered relating to cash
deliveries involving Davis totalling £56,120.

Count 6. Davis, Gurney and Walker: the amphetamine conspiracy between 1 March 2020 and 27 April
2021

14. Davis, Gurney and Walker conspired together and with Keet to produce amphetamine. As indicated,
others were involved. They constructed and operated a drugs laboratory in rural Warwickshire to
manufacture amphetamine on what was an industrial scale. The laboratory was located inside a double
garage. We have seen photographs of what was a substantial enterprise containing large quantities of
equipment and chemicals for use in the production and subsequent cutting of amphetamine sulphate,
including plastic containers of hydrochloric acid, sacks of caustic soda and drums of caffeine. The
necessary equipment included heating mantles with thermostats or thermometers, round bottom flasks,
vertical condensers, gas burners, a steel reaction vessel, distilling condensers and separation funnels.
There was also a large fridge for storage and a freezer alongside the installation of running water supply,
venting and ducting with an inline fan for ventilation.

15. The laboratory was built in the spring of 2020. It operated until the offenders were arrested on 27 April
2021. It was capable of producing 136kg of amphetamine sulphate per week, meaning that around six tons
with a wholesale value of £11 million could have been produced during the operational period. The amount
of amphetamine sulphate produced was clearly very substantial, although there was no direct evidence of
precisely how much amphetamine sulphate actually had been produced. The production method used was
Leuckart synthesis, a five-stage process using benzyl methyl ketone (BMK) as a precursor. The laboratory
was an end-to-end production facility. Gurney accepted in evidence that several hundred litres of
amphetamine oil were produced. He stated that any deliveries made by him, of which two had been
observed directly under surveillance, were of amphetamine oil not sulphate. It was accepted at trial that
there was also a market for amphetamine oil.

16. So far as roles were concerned, Keet was in control of equipment and training. Davis and Gurney
received training in the chemical process for producing the amphetamine sulphate and Gurney then
operated the laboratory. Davis was heavily involved with other conspirators and knowledgeable about the
production process: so, for example, there was an exchange between Davis and Keet in April 2021
suggesting a test run. Gurney was an electrician and plumber and assisted in building the laboratory. He
also worked in the laboratory for substantial periods of time. Walker was in frequent contact with Keet who
told him what to purchase. He discussed ordering and collecting equipment with Davis. In June 2020 he
sent photographs to Davis showing exchanges about temperatures and chemical processes in the
production of amphetamine. Walker's unchallenged basis of plea was that his role was limited to obtaining
the relevant glassware from China, for which he was paid.

Count 7. Gurney: criminal property possession


-----

17. Gurney was arrested on 27 April 2021. His house was searched. Two quantities of cash totalling just
under £10,500 were found concealed behind a panel under a sink in the upstairs bathroom and in the
bottom of a wardrobe.

Count 8. Walker: criminal property possession

18. Upon his arrest on 7 May 2021, Walker was found to be in possession of £3,100 in cash.

19. We turn then to indictment T20217135 involving Walker.

Counts 1 and 8. The cocaine conspiracies between 25 May 2020 and 4 May 2020 and between 19 March
2020 and 14 June 2020

20. Walker conspired with Christopher Francis (“Francis”) and others to supply cocaine. His EncroChat
handle was "still jaw". The messages demonstrated a close relationship between Walker and Francis with
frequent contact, including the sending of pictures of kilogram blocks of cocaine and discussion of
importing product into this country on a weekly basis. On one occasion Walker arranged to purchase two
cheap kilograms of cocaine from Keet with the use of a driver to facilitate handover. Vehicles were used as
a place for concealment. Individual payments or handovers of over £70,000 were evidenced. Upon his
arrest on 20 April 2021, Walker was found to be in possession of £1,000 in cash and a cash counting
machine. Over 8kg of cocaine were actually supplied.

**The Proceedings. Walker.**

Guilty pleas

21. Walker pleaded guilty following non-effective plea and trial preparation hearings on a basis. He had
been recruited to purchase the equipment that created the laboratory. He had been instructed what to
purchase and the acquisitions were financed by others. He knew that the equipment would be used for the
production of amphetamine. His role was limited to the acquisition of the equipment. He accepted that he
was concerned in the actual supply of 8kg of cocaine.

Pre-sentence materials

22. In terms of personal circumstances, Walker had a 2008 previous conviction for a conspiracy in 2006 to
transfer criminal property, for which he received a sentence of 18 months' imprisonment, and a 2013
conviction for fraudulent evasion of duty, prohibition or provision arising out of the importation of 10 million
cigarettes in 2011, for which he received a sentence of 18 months' imprisonment suspended for two years.

23. No pre-sentence report was obtained and we agree that one was unnecessary. There were positive
reports from the prison substance recovery team, character references and a letter of remorse from Walker
to the judge, in which he described having been in a spiral of drug use and despair and huge debt.

The sentences

24. The judge sentenced Walker on the basis of having played a leading role in the cocaine conspiracies.
These were overlapping conspiracies falling squarely within Category 1 harm for the purpose of the
Guideline. He assessed Walker to have played a leading role. There were aggravating factors in the shape
of Walker's previous convictions, the use of vehicles for concealment purposes and an EncroChat
telephone. For the cocaine conspiracies alone, the judge would have imposed a sentence of 15 years'
custody, to which 20% credit for guilty pleas would be applied.

25. The judge assessed Walker as having played a significant role in the amphetamine conspiracy. He
commented that the amount of amphetamine involved was "vastly greater" than the indicative amount of
20kg for Category 1 harm for the purpose of the Guideline. The aggravating features were an ongoing
large scale operation using specialist equipment sourced by Walker; exposure to the risk of serious harm
due to the use of large quantities of dangerous chemicals and the production of toxic fumes, and the use of
sophisticated methods to avoid detection in the form of an EncroChat telephone.


-----

26. The judge was quite satisfied that he should step outside the normal category range of five to seven
years' custody. On Count 6 alone, he took the view that a term of eight years before 20% credit before
guilty plea would be justified. On Count 8, a term of eight months' imprisonment before credit for guilty plea
would be appropriate.

27. After credit for Walker's guilty pleas, the sentences for the cocaine conspiracies would be 12 years'
imprisonment on each to run concurrently to each other; six years and four months' imprisonment for the
amphetamine conspiracy and six months' imprisonment for the possession of criminal property to run
concurrently to each other. The two enterprises, said the judge, were entirely different in nature, being
different offending with different co-defendants, save in respect of one individual. He therefore imposed
consecutive sentences in relation to the offending relating to each. To take account of totality, however, he
reduced the custodial terms on the cocaine conspiracies from 12 years to 10 years and on the
amphetamine conspiracy from six years and four months to six years, producing the final overall 16-year
custodial term.

**The Proceedings. Davis and Gurney.**

The trial

28. Davis advanced a defence under s.45 of the **_Modern Slavery Act 2015. His case was that he was_**
vulnerable due to his poor mental health. He had been coerced and exploited by the other conspirators
who had supplied him with medication that he could not reliably obtain from his doctor, which they
threatened to withhold. Gurney accepted building the laboratory and working there. He accepted that he
had been involved in the manufacturing process and accepted making the deliveries that had been
observed by surveillance officers. He said he had been paid around £8,000 to £9,000. However, he denied
knowing that amphetamine, or indeed any controlled drugs, were being manufactured at the laboratory. He
said he had been recruited by someone he knew as "Dublin" and was told that they were manufacturing
vape oil for use in E-cigarettes and also a solid product used for making nicotine replacement tablets. He
denied knowing that he was doing anything illegal.

29. The jury rejected both defences.

Pre-sentence materials

30. In terms of personal circumstances, Davis had old irrelevant convictions dating back to 1982, (criminal
damage), 1984 (going equipped for theft and handling stolen goods), and 1987 (handling stolen goods and
possession of a shotgun). In 1986 he had been diagnosed with bipolar affective disorder and had been
prescribed medication from at least 2013 onwards. In 2014 he had been admitted into an acute day
hospital following a deterioration in his mental state. In 2016 his diagnosis was recorded as bipolar
affective disorder, with a current episode of moderate to severe depression, and personality difficulties
resulting in volatile mood. In 2017 correspondence referred to a significant deterioration in his mental state.
In 2019 Davis was seen on an urgent basis after reporting feelings of paranoia. In 2020 he was discharged
from the complex needs team, but remained under the care of a consultant psychiatrist.

31. Three character references from family members were provided for Davis. They spoke of Davis as a
caring, supportive and helpful grandfather, father and brother and as a good hard-working employee prior
to his mental health problems. Davis wrote a letter of remorse to the judge expressing deep shame for his
actions, stating that he would never act in the same way again and had used his time in prison
constructively. A prison report suggests that there are no serious concerns and evidences some positive
entries for good work.

32. Gurney had no previous convictions with only one caution in 2001 for assault occasioning actual bodily
harm. He was married with two children in their teens or early 20s. He provided care for his elderly mother.
There were character references from his wife of 22 years and his sister-in-law. His wife spoke of the many
positive aspects of his character and the difficulties caused for her and her family by his incarceration.
Gurney also wrote to the judge. He explained that his poor money management and desire to provide for
his family had led him to become involved in the amphetamine conspiracy He expressed shame and


-----

remorse and also said that he intended to use his time in custody constructively. Again, a prison report
confirms good behaviour in custody with multiple positive entries and good motivation to engage, including
by participation in ICT training.

The sentences

33. Addressing the Guideline, the judge stated:

"The laboratory was clearly capable of producing in excess of 20 kilograms of amphetamine which is
Category 1 in the guidelines. The guidelines state that, 'Where the operation is on the most serious and
commercial scale involving a quantity of drugs significantly higher than Category 1, sentences of 20 years
and above may be appropriate, depending on the offender's role'. I take that to be a reference to Class A,
leading role, for which the upper end of the range is 16 years. So the reference to sentences of 20 years or
more seems to me to mean an uplift of around 20% from the applicable sentence."

34. So far as Davis was concerned, the judge said:

"The jury were provided with details from your GP's records of your history of mental illness but rejected
[your account that what happened to you amounted to a defence under the Modern Slavery Act 2015 as](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
was advanced on your behalf. However, in my judgment, there is some evidence in some of the EncroChat
messages which I have seen, which make clear that you did make excuses from time to time as being
drunk, not having slept, being unwell or having been in contact with people with Covid to avoid having to
work for Mr Keet. To an extent you were also, in my judgment, a vulnerable person who was susceptible to
demands made on you to others, albeit falling well short of coercion as defined in the Act.

That said, the messages I have read also indicate that you were paid for some work that you carried out,
albeit it is abundantly clear that you were not living a lifestyle which was in any way lavish. Additionally, you
were, as the messages show, in receipt from Mr Keet and others, drugs similar to those which have been
prescribed to you from time to time and which, as you explained to the jury, you felt were insufficient to
deal with your symptoms."

35. The judge found that Davis' involvement in the laboratory was limited to two visits. However, he had
been trained by others. He was not involved after 1 June 2020 when he was stopped by the police.
Although he would not have known the actual production capacity of the laboratory, it would have been
clear to him from the quantities of chemicals that he was dealing with that well in excess of 20kg was going
to be produced and that it was expected to be a very lucrative venture, certainly so far as Keet and others
were concerned. He did not have an expectation of high cash gains for himself. He was in reality never
other than a "foot soldier". There were elements, said the judge, of significant and lesser role and so Davis
would be sentenced at the cusp of the category at five years' imprisonment. There would then be an uplift
based on the scale of the operation to increase that sentence to six years' imprisonment. Having regard to
mitigation, the sentence would be reduced to five years and three months' imprisonment for Count 6.
Concurrent sentences would be imposed for the other offending.

36. As for Gurney, there came a point when he realised just how deeply he had fallen into a very large
scale criminal enterprise. This was a laboratory working on an industrial scale with the wholesale value of
the amphetamine running into millions of pounds, possibly over 10 million. Much of the money found
hidden in his home was the result of his earnings from work at the laboratory. He had an operational role,
was paid significant monies for it and was clearly aware of the scale of production. Gurney was plainly
within the overall description of a significant role and the judge therefore adopted a starting point of five
and a half years' imprisonment. That would be increased to seven years' imprisonment to reflect the
quantity of the drugs. The judge also had regard to the sentence imposed on Walker, who he said had
relevant previous convictions and had played a higher role, albeit for a shorter period.

37. Having regard to Gurney's good character, the sentence would be reduced, said the judge, to six years
and six months' imprisonment on Count 6 with a concurrent sentence imposed for the money laundering.
The judge called Gurney's case back later on the same day and reduced the sentence for Gurney on


-----

Count 6 to six years and three months' imprisonment, having intended, he said, to give Gurney a greater
reduction on account of his personal mitigation.

**The parties' submissions**

38. For the Attorney General, Mr Polnay submits that the sentences imposed were unduly lenient due to
two errors of principle made by the judge. It is submitted first that the approach of the judge to uplift the
sentences by 20% to account for the quantity of drugs was incorrect. That uplift was based on the
difference identified by the judge between the top of the class A leading role and the 20 year period
mentioned in the rubric for the most serious and commercial scale operations. However, the rubric refers to
20 years or more. It is submitted that a sentence approaching 30 years would have been appropriate had
this scale of production been used for class A drugs. Therefore, on the judge's approach, submits Mr
Polnay, a 100% uplift would have been appropriate, not 20%. But fundamentally it is submitted that a
mathematical exercise of this sort is inapt.

39. Mr Polnay submits that the scale of this operation was exceptional, such that the maximum sentence,
or something close to the maximum sentence, would have been appropriate for someone playing a leading
role in the conspiracy. If that be right, how, he asks rhetorically, does one deal with the lower roles? There
may be cases where the harm is so great that role may not be reflected to the same extent as would be the
case with lower quantities. In his submission the judge's figures simply did not reflect adequately the
quantities and the scale of the conspiracy in question.

40. Further, whilst he has no objection in principle to the passing of concurrent sentences given the
overlapping time, Mr Polnay submits that the judge ignored the principle of totality. In relation to Davis in
particular, Davis had been involved in separate conspiracies, albeit with one of the same group of
offenders, to supply cannabis and ketamine with associated transfer. The ketamine conspiracy alone, he
suggests, merited a sentence of around five years' imprisonment. So it is apparent, he says, that the judge
paid no regard to totality, making no increase in sentence to reflect what he suggests was additional
significant criminality which could have caused real harm. This was an error of principle affecting the
overall sentence so far as Davis in particular was concerned.

41. For Davis, Mr Meads relies in her written grounds heavily on the judge's findings of fact. She points to
the fact that the EncroChat material was said to have revealed that Davis made excuses to attempt to
avoid fulfilling his role within the conspiracy; that Davis was a vulnerable person and susceptible to
demands made on him; that he was not living a lavish lifestyle; that messages demonstrated he was in
receipt of drugs similar to those for which he had been prescribed, but which he felt were insufficient to
deal with his symptoms. She relies on the judge's finding that Davis' involvement at the laboratory was
limited and that he had received training at another venue together with Gurney. She relies on the finding
that Davis' involvement ceased on 1 June 2020 and that Davis had exaggerated the significance of the
stop by the police, which was indicative of a reluctance to continue working at the laboratory or indeed for
Keet more generally. She relies on the judge's finding that, although Davis could not have known the actual
production capacity of the laboratory, he would have had some awareness from the quantities of chemicals
involved that an amount in excess of 20kg would be produced. She relies on the finding by the judge that
any expectation of high cash gains on Davis' part were no more than “pipe dreams”. He was no more than
a “foot soldier” and had engineered his departure from the conspiracy, not attempting to re-join. She
submits that the judge was best placed to assess the culpability of Davis in the light of all the evidence and
relies on his categorisation of Davis' role.

42. As for totality, Ms Meads suggests that it can be seen from the judge's reasoning in relation to the
passing of concurrent sentences that, implicitly, the judge took account of totality. He was entitled to
consider what was the appropriate proportionate uplift to reflect the offending overall and the scale of drugs
involved. His overall sentencing exercise and the result reached by him was within the spirit of the
Guideline. There was an increase of 12 months, which was sustainable by reference to Davis' role and
understanding and his reluctance to be involved. Whilst she does not seek to support the mathematical
exercise carried out by the judge in terms of uplift, she submits that he nevertheless carried out the correct
exercise in substance This is an exercise which should reflect not only the part played by the offender in


-----

question, but also the significance of the offending to the operation as a whole. In this regard, she relies on
comments made by this court in _R v Sanghera_ _[2016] EWCA Crim 94. Those remarks, whilst clearly_
correct, must be read in context, namely cases where there is an element of crowding or bunching of
offenders facing sentences already ranging between 20 and 30 years' imprisonment with very compressed
scope for differentiation by reference to amounts and roles.

43. For Gurney, Mr Wood echoes the approach of Ms Meads. He also relies on the judge's finding of fact
so far as Gurney was concerned. There was no evidence of Gurney having a lavish lifestyle or reaping the
benefits of the profits made. He was not continuously involved in the laboratory or working there alone.
Further, Gurney never had possession or use of an EncroChat telephone and was not involved in the other
conspiracies in which Davis was involved. The process in which Gurney was educated was hazardous, but
not complicated. He was considered by the leaders of the conspiracy to be a paid member of staff. He had
no previous convictions.

44. In his written grounds, as in his oral submissions, Mr Wood emphasises that it was the judge who had
the benefit of observing Gurney give evidence for the best part of two days. Gurney was, it is said, "a world
away" from the professional organised criminals who make it their business to profit out of illicit drug
production and supply. The judge was entitled to temper his approach to the Guideline as it applied to
Gurney. Gurney was important to the operation, but he plainly did not act alone, could easily have been
replaced and, on any view, was not working there full-time. It was thus perfectly proper for the judge to
raise a custodial term of five and a half years by no more than 18 months to account for the quantities of
drugs that could have been produced before then making appropriate reductions for mitigation. Mr Wood
emphasises what he describes as the compelling personal mitigation available to Gurney. Gurney had
been a hard-working person of essentially good character. He had found himself in challenging financial
circumstances. He was a family man with character references in support and a positive prison report
demonstrating impeccable behaviour.

45. In his written and oral submissions, Mr Wood also points to the sentence imposed on Walker for
support. Walker's sentence on Count 6 was based on a term of eight years' imprisonment before
adjustment for totality. Walker's involvement might have ceased when the EncroChats were compromised,
but Walker was on any view substantially more important, he said, to the success of the enterprise than
Gurney. If eight years' imprisonment was a condign starting point for Walker, submits Mr Wood, then a
custodial term of seven years was not inappropriate for Gurney. In his oral submissions, Mr Wood
emphasises that, even if the judge's methodology to reach the 20% uplift was incorrect, that does not
necessarily mean that the result he arrived at was wrong. The uplift that needed undoubtedly to be applied
did not have to result in a sentence outside the range for Category B1 offending. Reflecting the quantities
involved, Gurney's role and involvement, the judge's conclusions are defensible. The result may have been
lenient, but it was not unduly so.

46. For Walker, Mr Marshall, whose pro bono assistance has been appreciated, re-orientates the written
grounds of appeal that were rejected by the single judge. Those grounds made a number of discrete and
detailed criticisms in relation to the starting points adopted, the imposition of current sentences and the
categorisation of Walker's role and have not been pursued. All that is now said is that the overall sentence
of 16 years' imprisonment was manifestly excessive, the over-arching submission being that such a term
was disproportionate to Walker's overall offending. That offending spanned no more than a three-month
period between March and June 2020. The drugs came primarily from Keet so far as the cocaine
conspiracies were concerned, and in the amphetamine conspiracy Walker had been instructed by Keet.

47. Mr Marshall invites to us step back and look at Walker's course of conduct in the round. These were all
drug-related offences but, factoring in what Mr Marshall describes as Mr Walker's limited role in the
amphetamine conspiracies, there should have been a greater overall downward adjustment from a figure
of 16 years' imprisonment for totality.

**Discussion**


-----

48. The relevant law is non-controversial. The maximum sentence on each of Counts 2, 4, 5, 6 and 7 was
14 years' imprisonment. The maximum sentence permitted by statute is reserved not for the worst possible
case which can realistically be conceived, but for cases which in a statutory context are truly identified as
cases of the utmost gravity: see R v Bright _[2008] EWCA Crim 462, [2008] 2 Crim App R (S) 102 at [29]._
The maximum sentence for a class A conspiracy was life imprisonment.

49. Every court must, in sentencing an offender, follow any relevant Sentencing Council Guidelines. The
principal guideline's duty includes a duty to impose on an offender, in accordance with the offence-specific
guideline, a sentence which is within the offence range. A court does not have to follow a relevant guideline
if satisfied that it would be contrary to the interests of justice to do so: see s.59(1) and s.60(2) of the
Sentencing Act 2020.

50. The Guideline identifies that in assessing culpability the sentencer should weigh up all of the factors of
the case to determine role. Where there are characteristics present which fall under different role
categories, the court should balance these characteristics to reach a fair assessment of the offender's
culpability. In assessing harm, output or potential output is determined by the weight of the product or
number of plants and scale of operation.

51. As the editors of Archbold (2022) comment at 5A-26, extremely high or low serious cases are likely to
go beyond the upper and lower limits of the ranges identified in the guidelines. Indeed, the Guideline here
states in terms:

"Where the operation is on the most serious and commercial scale involving a quantity of drugs
significantly higher than Category 1, sentences of 20 years and above may be appropriate, depending on
the offender's role."

52. This passage is applicable in a measured way not only to offences involving class A drugs, but to
offences involving class B drugs as well, bearing in mind always that the maximum sentence where class B
drugs are involved is 14 years: see R v Lawlor & Ors _[[2020] EWCA Crim 485 at [24]. Just as sentences of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YNW-FGH3-CGXG-01P4-00000-00&context=1519360)_
up to 20 years' imprisonment may be appropriate, depending on the role of the offender in a case involving
class A drugs on a commercial scale, the same is true by measured reference to class B drugs on a
commercial scale.

53. Where there is a conspiracy, and where the known amounts of the drugs well exceed the indicative
amounts in the Guideline, so that a judge is permitted to exceed the maximum sentences there identified,
the Guideline should nevertheless be borne in mind as a "valuable touchstone": see _R v Cuni_ _[[2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RYT-5481-F0JY-C177-00000-00&context=1519360)_
_[EWCA Crim 600 at [40] endorsing R v Copeland [2015] EWCA Crim 2250, [2016] 1 Crim App R (S) 56 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RYT-5481-F0JY-C177-00000-00&context=1519360)_

[24]. When addressing offences of conspiracy, a guideline should be applied with a degree of common
sense and flexibility: see R v Khan &Ors _[[2013] EWCA Crim 800, [2014] 1 Crim App R (S) 10. There the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58GH-J8S1-F0JY-C26C-00000-00&context=1519360)_
court also rightly noted that the fact of involvement in a conspiracy would be an aggravating feature since
each conspirator, playing their part, gives comfort and assistance to others, knowing that they are doing so.
The greater the awareness of the scale of the enterprise in which they are involved, the greater will be their
culpability.

54. On the question of totality, the relevant Sentencing Council Guideline provides:

"All courts, when sentencing for more than a single offence, should pass a total sentence which reflects all
the offending behaviour before it and is just and proportionate. This is so whether the sentences are
structured as concurrent or consecutive. Therefore, concurrent sentences will ordinarily be longer than a
sentence for a single offence."

55. Further and finally, relevant to Davis was the Sentencing Council Guideline for sentencing offenders
with mental disorders. The fact that an offender has a disorder should always be considered by the court,
but will not necessarily have an impact on sentencing. The approach must always be individualistic and
focus on the issues in the case. In any case where the offender is or appears to be suffering from a mental
disorder at the date of sentencing, the court must obtain and consider a medical report before passing a
custodial sentence, other than one fixed by law, unless in the circumstances of the case the court
considers that it is unnecessary: see s 232 of the Sentencing Act 2020 Culpability may be reduced if an


-----

offender was at the time of the offence suffering from a disorder, but only if there is sufficient connection
between the offender's disorder and the offending behaviour.

**The Attorney General's applications: Davis and Gurney**

56. We turn first to the Attorney General's applications. References under s.36 of the Criminal Justice Act
1988 are made for the purpose of the avoidance of gross error, the allaying of widespread public concern
at what may appear to be an unduly lenient sentence and the preservation of public confidence in cases
where a judge appears to have departed to a substantial extent from the norms of sentencing generally
applied by the courts in cases of a particular type: see Attorney General's Ref No.132 [2001], R v Johnson

[2020] EWCA Crim 1418, [2003] 1 Crim App R (S) 41 at [25]. We remind ourselves that the threshold in
order for appellate interference to be justified is a high one. The sentences in question must be not only
lenient, but unduly so.

57. No criticism is made of the judge's assessments as to roles. Both Davis and Gurney performed
important operational functions within a chain. Davis used an EncroChat telephone. He visited the
laboratory twice. He provided storage facilities for the chemicals involved. Gurney was involved in the
building of the laboratory and was involved in the production. Both knew the process. Both had an
awareness and understanding of the scale of the operation. Davis was paid for his work and received
drugs similar to his prescription drugs. Gurney was involved for around a year and earned significant
monies from working at the laboratory on a regular basis. He may not have started out as a professional
organised criminal, but he certainly agreed to join into what he knew to be a professional organised
criminal operation.

58. Despite the presence of significant role characteristics for Davis, the judge considered that there were
also lesser role characteristics for him, as we have indicated. He was actively involved for only a limited
period of time and there was some evidence of him trying to remove himself. There were elements of
engagement by pressure, coercion and intimidation and involvement through naivety or exploitation. There
was no evidence of significant payments to him. We do not consider, nor are we invited to do so, that there
is any proper basis for us to interfere with the judge's assessment after trial that for the purpose of the
Guideline Davis' involvement should be placed at the bottom of significant/ top of lesser role offending.
However, in making that assessment, it should be noted that the judge took into account, amongst other
things, Davis' mental health difficulties. Thus, Davis would not be entitled to significant additional credit by
way of mitigation in this regard. As Mr Polnay put it, available mitigation should not be double counted.

59. Based on a starting point of 20kg of amphetamine, the Guideline gives a starting point of five and a
half years' imprisonment for significant role offending, with a range of five to seven years' imprisonment;
and a starting point of three years' imprisonment with a range of two and a half to five years' imprisonment
for lesser role offending.

60. The real challenge in these references is to the manner in which the judge approached that range in
the light of the quantity of drugs in play, being over some 300 times the Category 1 starting point of 20kg.
As we have recorded, the judge reflected those quantities by applying an uplift of 20% to the relevant
Guideline range figures. That 20% figure was reached apparently by reference to the difference calculated
by the judge between the upper range of 16 years for class A Category 1 leading role offending and 20
years.

61. There are, for the reasons identified by the Attorney General, very real logical difficulties with the
judge's methodology on the figures themselves. In particular, his use of 20 years as a reference point was
inapt. The most serious class A conspiracies can receive sentences of 30 years' imprisonment and indeed
more. More fundamentally, a mathematical approach was simply not appropriate nor, as we have
indicated, has anyone before us attempted to justify it. It is not what treating the Guideline as a “valuable
touchstone” or what adopting a measured approach to the Guideline envisages. For very significant
commercial drug offending, such as this, to an extent way beyond the indicative amounts in the Guideline,
what is required is an exercise of judgment in scaling up in a way which fairly reflects the quantities
involved and the offender's role.


-----

62. As has been submitted for both Davis and Gurney, however, the fact that the judge erred in principle in
his calculation of and application of an uplift of 20% does not of course resolve the references before us.
The question remains whether or not the sentences arrived at can stand as falling, despite the error, within
the boundaries of acceptability. The standout feature is of course the scale of the operation in question.

63. By way of aggravation, it is important to acknowledge that many of the potentially aggravating features
are bound up intrinsically in the scale and nature of the operation and inherent in any illegal massive
commercial manufacturing such as this. This was an ongoing large scale operation evidenced by the
presence and nature of specialist equipment and training for those operating it, a risk of harm to those
involved and the use of sophisticated methods to avoid or impede detection.

64. By way of mitigation, as indicated, neither Gurney nor Davis had any relevant previous convictions.
They had led previous industrious lives and had strong family bonds. Davis had a history of mental health
problems, but, as indicated, this feature was largely catered for by the judge's categorisation of Davis'
culpability.

65. We turn first to Davis. Taking Count 6 alone for the moment, considering culpability, harm and all
relevant aggravating and mitigating features, the offending in our judgment required a custodial term of no
less than eight years. Such a term remains faithful to the judge's categorisation of Davis' role, but reflects
the necessary scaling up exercise required by the sheer extent of the operation. It was in the interests of
justice to go outside the range for Category 1 significant role offending. This was no ordinary Category 1
significant role or lesser role offending. The modest year's increase to a term of five years applied by the
judge was in our judgment manifestly insufficient.

66. Moving on to totality, there can be no objection in principle to the imposition of concurrent sentences
on Counts 2, 4 and 5, which were committed with Keet by Davis at around the same time as the
amphetamine conspiracies, but always subject to the critical proviso that proper regard would then need to
be paid to totality. The judge did not mention totality at all; on a fair reading, his analysis does not appear to
us to have taken account of it in any meaningful way. There needed to be a material increase to reflect
Davis' other significant offending on Counts 2, 4 and 5. Both the ketamine and cannabis conspiracies alone
merited significant custodial sentences of many years. The judge himself considered that the ketamine
conspiracy alone should carry a sentence of four years and six months and on the cannabis conspiracy
two years and three months' imprisonment. In our judgment, considerations of totality necessitated an
upward increase on Count 6 from eight years to ten years' custody.

67. Turning then to Gurney, it was again in the interests of justice to go outside the relevant range in the
Guideline. Considering culpability, harm, all relevant aggravating and mitigating features and the additional
money laundering offence in Count 7, in our judgment a custodial sentence of no less than 10 years was
warranted. We do not consider that there was significant assistance to be gained from cross-referencing to
the sentences imposed on Walker, and such an exercise did not play a major part in the judge's thinking.
The sentencing exercise for Walker, who played a different role, was set in a very different overall context.

68. Seen in the light of our conclusions above, the overall custodial sentences imposed on Davis of five
years and three months and on Gurney of six years and three months on Count 6 were not only lenient, but
unduly so. We recognise the advantage held by the judge over this court, having presided over a lengthy
trial at which both offenders gave evidence, but, as set out above, we have not interfered with his
assessment of their roles and culpability. We recognise also the fact that Gurney and Davis are both
middle-aged family men with no relevant previous convictions. However, the quantities involved in the
amphetamine conspiracy were massive. Indeed, there is no reported case of which we are aware involving
conspiracy to manufacture amphetamine on this scale. And in the case of Davis there was significant
additional offending. We are bound to conclude that the original sentences are not sustainable.

69. We therefore grant leave. We allow both references. The sentences on Counts 6 for both Davis and
Gurney will be quashed. Substituted sentences will be imposed as follows: on Count 6 for Davis, ten years'
custody; on Count 6 for Gurney, ten years' custody. All other elements of the sentences remain in place
undisturbed.


-----

**The renewed application for leave to appeal sentence: Walker**

70. That takes us to Walker's renewed application for leave to appeal sentence. We do not consider,
despite Mr Marshall's able submissions, that it has any merit and it falls to be refused.

71. The judge was unarguably entitled to conclude that the cocaine conspiracies involved Walker playing a
leading role in what was undeniably Category 1A offending for the purpose of the Guideline. As for harm,
the indicative quantity in the Guideline is 5kg. The offending here involved the actual delivery of 8kg and
the prospect of far greater volumes of delivery. As for culpability, as the judge commented, “a” leading role
does not mean “the” leading role. The judge was right to point to Walker's substantial links to others in a
chain, close links to the original source and the expectation of financial gain. In short, these were
sophisticated conspiracies in which Walker played a very substantial part.

72. As for the amphetamine conspiracy, the fact that Walker's involvement was only short-lived was of little
assistance to him in circumstances where that involvement occurred at the very outset. He was
responsible for the successful establishment of the operation from inception and thus facilitated everything
that followed. This was not a case where, for example, he had joined the conspiracy late in the day, for the
last few weeks of the operation.

73. We have stood back, as Mr Marshall has invited us to do, and asked ourselves whether or not the
sentence of 16 years' custody offends the principle of totality. Was it disproportionate to Walker's
criminality overall? We do not consider it to be arguable that it did so offend. Walker played an integral part
in the operation of multiple sophisticated high-value high-volume class A and class B drug conspiracies.
Like the single judge, and for similar reasons, we consider that the application for permission to appeal
against sentence is without merit.

**Conclusion**

74. For these reasons:

i) We grant leave and allow both references by the Attorney General in respect of Davis and Gurney. On
Count 6 the substituted sentence on Davis is one of ten years' imprisonment and on Gurney again ten
years' imprisonment. Each will serve half of their sentences in custody.

ii) We refuse the renewed application by Walker for permission to appeal against sentence.

75. Finally, we would wish to record our gratitude to all counsel for their very helpful written and oral
submissions in this matter, and in particular to Mr Marshall who appeared pro bono.

__________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge_**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**


-----

This transcript has been approved by the Judge

**End of Document**


-----

