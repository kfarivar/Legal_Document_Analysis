# LY, petitioner 2019 Scot (D) 16/2

[2019] CSOH 13

Outer House, Court of Session

Lord Beckett

14 February 2019

**Judicial review – Human Trafficking – Chinese national seeking reduction of decision that she was not**
**victim of human trafficking from China to Denmark for purposes of forced labour or sexual exploitation –**
**Whether decision-maker erring in law by failing to apply relevant guidance in certain respects – Whether**
**erring in relation to question of petitioner's identity – Council of Europe Convention on Action against**
**Trafficking in Human Beings.**
Abstract

_Judicial review – Human Trafficking. Court of Session: In judicial review proceedings in which a Chinese national_
_sought reduction of a decision that she was not a victim of human trafficking from China to Denmark for the_
_purposes of forced labour or sexual exploitation, the court rejected contentions that the decision-maker had erred in_
_law by failing to apply the relevant guidance in certain specified respects and had erred in relation to the question of_
_the petitioner's identity, holding that the decision-maker had not made any material error in law in reaching the_
_decision complained of, which was reasonably open to her on the information before her._
Digest

In the early hours of 24 August 2014 the petitioner found herself on the streets of Glasgow, barefoot and in a state
of distress. The police attended and spoke with her. She said that she was LY, a national of China, born in
September 1993. In due course she was referred via the National Referral Mechanism ('NRM') to the Home Office
as a potential victim of trafficking. On 28 August 2014 the Home Office, as Competent Authority, concluded that
there were reasonable grounds to believe that the petitioner had been a victim of trafficking. On 6 March 2018, the
Home Office conclusively recognised the petitioner as a victim of trafficking in relation to her experiences in the
United Kingdom but not as a victim of trafficking in Denmark and China. She was granted discretionary leave to
remain until March 2019. On 16 March 2018 the petitioner was refused asylum on the basis that there would be a
sufficiency of protection on her return to China. These proceedings did not relate to the refusal of the petitioner's
asylum claim which was subject of appeal proceedings before the First-tier Tribunal. In this petition for judicial
review the petitioner ostensibly sought declarator that two decisions made on 6 March 2018 were unlawful, namely
that in relation to her departure from China and entry to and presence in Denmark she was not a victim of
trafficking, and the rejection of her true identity as being LY. However, at the hearing on 10 January 2018 counsel
for the petitioner invited the court instead to reduce the decision of 6 March 2018 in so far as expressed in the
following passage in a decision letter of the same date: 'It has therefore been decided that you are not a victim of
human trafficking from China to Denmark for the purposes of forced labour or sexual exploitation.' The Council of
Europe Convention on Action against Trafficking in Human Beings ('the Trafficking Convention') was ratified by the
UK on 1 April 2009. As part of implementing its obligations under the Trafficking Convention the UK government
created the NRM in 2009. The Home Office published guidance based on the Trafficking Convention, 'Victims of
**_modern slavery— Competent Authority Guidance', of which Version 3, issued on 21 March 2016, was in force on 6_**
March 2018. It gave information to staff in the Competent Authorities in the Home Office and UK Human Trafficking
Centre to help them decide whether a person referred under the NRM was a victim of trafficking. The petitioner


-----

maintained that she was LY, born in September 1993 in Jilin Province, in the north-east of China, where the
languages spoken were Mandarin and Korean. She said that when she was 6 she moved with her mother, who had
remarried, to Guangdong Province in the south-west of China, where the languages spoken were Cantonese and
Mandarin. The petitioner's stepfather physically and sexually abused her as a child. The petitioner claimed that in
2009, when she was 15, she was sold by her stepfather to an organised criminal gang as payment for debt and left
China without her mother after the Chinese New Year. She was taken by car to an airport in China but was not able
to say what airport it was or give any details about it. She was taken to Denmark. The petitioner was accompanied
on the flight to Denmark by a man called A Zhen. She was sedated. She was met at the airport in Denmark by a
man called A Nai, under whose control she was kept throughout her time in Denmark. He enrolled her in classes at
a design and technology school, under an alias identity which would later come to be identified to the petitioner as
YZ or ZY, with a date of birth in August 1990. Whilst enrolled in the school, and thereafter, she was forcibly
prostituted by Mr Nai, who also forced her to work in the evenings at a restaurant and as a night cleaner in a
hospital. She was told that if she did not comply her mother would be harmed. She was physically threatened and
her finger was cut with a meat slicer. The petitioner said that she was taken to London in 2010 under the YZ alias
identity when she was about 16. Mr Nai accompanied her on the flight to London, during which she was again
sedated, and he took her to a house in a place which she later learned was London. She was forced to work as a
prostitute there and elsewhere on a daily basis for four years. In August 2014 she was driven to Scotland to have
sex with a particular client but she escaped after a fight broke out between the client and her driver in the early
hours of 24 August 2014, when she made contact with the police. The respondent accepted that the petitioner had
been ill-treated and sexually abused by her stepfather as a child in China but did not consider that that part of her
account amounted to trafficking. That conclusion was not challenged. The respondent accepted evidence, and its
import, from a clinical psychologist, Dr Sharon Doherty, who reported in 2015 after examining the petitioner and
reviewing the available information since her arrival in the UK. She was considered to meet the diagnostic criteria
for PTSD. When the petitioner's fingerprints were taken in November 2014 they were found to match a UK Visa
application submitted in Denmark in 2010 in the name YZ, Chinese national born in August 1990. A bank statement
and a letter of support from Kea 'University', Copenhagen were submitted along with the visa application, which
also disclosed that a previous passport issued to YZ had expired so that a renewal passport had been sought and
issued at the Chinese Embassy in Copenhagen. Investigations established that the visa application was submitted
in person at the British Embassy in Copenhagen on 28 June 2010 and that fingerprints were taken and processed.
A particular Chinese passport in the name YZ was submitted in support of the application. The passport had been
issued by the Chinese Embassy in Copenhagen on 16 November 2009. That must have required personal
attendance at the Chinese Embassy by the petitioner, who must have produced either a passport or identity card.
The petitioner had denied knowledge of obtaining a passport in that identity and of the visa application. She made
no reference to renewing her passport and applying for a visa at the Chinese and British embassies in
Copenhagen. She had not produced to the respondent any evidence from the Chinese Embassy in the UK to
support her true identity being LY. The relevant decisions were given in two letters dated 6 March 2018.
Acceptance that the petitioner was the victim of trafficking in relation to her experiences in the UK was set out in a
three-page letter. In a detailed letter of 22 pages (the decision letter), the allocated NRM case-worker explained
why it was not accepted that the petitioner was a victim of trafficking from China to Denmark for the purposes of
forced labour or sexual exploitation. The fundamental difficulty for the petitioner, as explained at page 11, was that
the decision-maker did not accept the credibility of her account in material respects and accordingly attached little
weight to evidence emanating from her in those respects.

Counsel for the petitioner contended that the decision-maker had erred in law by failing to apply the relevant
guidance in certain specified respects: (1) Failing to recognise trafficking as a process and compartmentalising the
assessment of the petitioner's history. In particular, on her account Mr Nai featured both as controlling the petitioner
in Denmark and bringing her to London and taking her to a house there. Having accepted those facts in relation to
the UK, the decision-maker had erred in failing to give effect to their significance in relation to what occurred in
Denmark. (2) Overestimating and misapplying the significance of the petitioner not being subject to control at all
times in Denmark, given the definition of 'means' and the fact that she claimed to be a child when in Denmark. (3)
That was also said to be an error of law over and above a failure to follow guidance. (4) Failure to take account of
the petitioner's diagnosis of PTSD and her account that she was at times sedated, and rejecting the significance of
the mitigating circumstances provided by PTSD by rejecting the medical evidence on the basis that there was no


-----

suggestion that the petitioner suffered from cognitive impairment. It was irrational to accept the petitioner's evidence
as to how she arrived in the UK with a person implicitly accepted to be her trafficker whilst rejecting her evidence
that she was trafficked in Denmark. The second general attack related to the question of the petitioner's identity.
The respondent had attached significance to the ZY passport being genuine without noticing that it might be a
genuine document obtained by fraudulent means, or a genuine document which had been altered, and in doing so
failed to give effect to guidance. It was also a material error to fail to take account of the positive outcome of a
'telephone identity interview' conducted with the petitioner on 10 March 2016.

The petition would be refused.

The court rejected the contention that the petitioner erred in law by failing to treat the petitioner as a child when
considering if her account of what occurred in China and Denmark constituted trafficking. At page 7-8 of the
decision letter the nature of human trafficking per the Trafficking Convention was summarised and the different
assessment applicable in the case of a child was identified. At pages 18-21 the Trafficking Convention criteria of (a)
action, (b) means and (c) purpose in relation to both China and Denmark were considered. It was clear that the
decision-maker recognised that if the petitioner was under 18 at the material times, which she would have been if
she was LY born September 1993, 'means' would not need to feature. At page 19, in relation to China, the decisionmaker stated in terms: 'Therefore you are not required to meet part “b” for this aspect of your account.' The
conclusion reached was that in China, the petitioner was a victim of child abuse but not human trafficking. For
Denmark it was made clear that the decision-maker proceeded on the hypothesis, derived from the LY identity, that
the petitioner was a child in Denmark so that the 'means' criterion was not applicable. There were a number of
references to the petitioner not being subject to control at all times in Denmark, but they should be understood in
context. Reference to the petitioner not being under control at all times in Denmark was primarily considered,
alongside other pertinent facts and inferences relating to Denmark, and internal contradictions within the petitioner's
account, as undermining the credibility of her claim to have been trafficked in Denmark. The decision-maker was
aware from the materials before her that the petitioner claimed to have been sedated at certain times and made
explicit reference to that in the decision letter. That did not disentitle her from considering that the absence of any
detail about the airport from which the petitioner left China was surprising and a weakness in her account,
particularly when viewed alongside other objective facts which cast doubt on her account of the circumstances in
which she came to be in Denmark. The medical information was given detailed consideration at pages 5-7 of the
decision letter. The analysis of medical evidence formed the background which was referred to at page 18 in the
following passage which the petitioner complained about: 'It is noted that you were diagnosed as suffering from
PTSD and all medical evidence submitted has been fully considered. However, it is noted that within the various
information received regarding your mental health, no suggestion has been made that you suffer from any form of
cognitive impairment, to explain your inability to recount certain facts regarding your alleged experiences from
China within Denmark.' That suggested acceptance of the evidence about trauma and not rejection of it. That
passage demonstrated that the decision-maker was fully aware of the PTSD diagnosis and other related
information but, whilst it was accepted and taken account of, it was not considered to provide sufficient mitigation
for parts of the petitioner's account where there was a surprising lack of detail. Indeed it was very difficult indeed to
envisage how the symptoms and consequences of PTSD could account for some of the most fundamental
difficulties in the petitioner's account; for example her claim to know nothing (prior to flying to London) of the ZY
identity in relation to which she was involved in obtaining documentation at two embassies in Copenhagen and in
which she studied at Kea over a period of months. The court was not persuaded that the decision-maker did accept
the petitioner's account of how she came to the UK. She accepted that the petitioner's experiences in the UK
constituted trafficking but that was as far as it went. There was nothing irrational about accepting part of the
petitioner's account whilst rejecting other parts. A finder of fact was entitled to accept one part of an account from a
witness whilst rejecting another part. So far as the UK was concerned, not only was there material available to
support the petitioner's account of her experiences in the UK, on the face of it there was no reason to doubt it. The
position relating to Denmark was different and it had implications which bore relevantly on the circumstances in
which the petitioner left China. It was a reasonable inference that the petitioner must have applied to participate in a
course at Kea before March 2009, at which time on her own account she might well have been in China, although
that could not be known with certainty. The paucity of information which the petitioner could provide as to the airport
from which she said she left China was considered. Even allowing for the care which must be taken where an


-----

account came from someone who had been traumatised the respondent was entitled to consider that to be a
weakness in the credibility of the petitioner's account for the reasons given. It was also a reasonable inference that
somebody must have paid fees for the petitioner's attendance at Kea. On the information available at the time it
was reasonable to conclude that those fees would have exceeded 12000 Euros. As the decision-maker noted, that
did not sit easily alongside an account of the petitioner being sold and trafficked to settle a debt. The conclusion that
the petitioner must have known of the identity of ZY, born August 1990, was a reasonable one. She must have
attended at the Chinese and British Embassies in Denmark in order for her photograph to be in the passport and for
her to have obtained a visa to enter the UK. Even allowing for her explanation that threats were made to her safety
and that of her mother, her account of relative freedom of movement at times in Denmark, whilst not inevitably
destructive of her being a trafficked person there, was capable of undermining aspects of her account, particularly
when viewed alongside the factors identified relating to the ZY passport and the petitioner's admitted attendance at
Kea. The decision-maker did not err by failing to consider trafficking as a process. The petitioner's whole account of
events over more than 5 years was considered against relevant law and guidance, but the evidence available in
relation to different chapters of that account was different in quantity and quality. Whilst the respondent ascertained
that the petitioner had used an identity and travel documents in the name ZY, born September 1990, at no time was
a conclusion reached that that was the petitioner's true identity. The letters of 6 March 2018 proceeded on the basis
of both identities, and facts were considered on the hypothesis that the petitioner's true age and date of birth was
that which she stated in giving the name LY, as she consistently did in her dealings with investigative and
therapeutic agencies and individuals in the UK. The primary importance of the ZY identity was that related facts and
circumstances about passports, a visa, and the means of their acquisition, and information from Kea which was
gleaned therefrom, cast considerable doubt generally on the petitioner's account of what went on in Denmark and
why she came to be there. Given those conclusions there was no substance in the argument that the decisionmaker failed to consider possibilities other than the ZY passport being genuine and obtained by the petitioner. The
decision-maker's treatment of the ZY passport and identity disclosed no error of law. There was no substance in the
argument that the absence of an explicit reference to the impression formed over the telephone, that the petitioner's
accent was consistent with her coming from one part of China and not coming from another, was a material failure
to have regard to relevant information. It was likely that that information was amongst the UKVI notes to which
reference was made in the decision letter. However, even if it was missed, that fact could not provide any
meaningful support for any part of the petitioner's account which was rejected as lacking credibility. The court was
not persuaded that the decision-maker made any material error in law in reaching the decision complained of, which
was reasonably open to her on the information before her.

[R (on the application of YH) v Secretary of State for the Home Dept [2010] 4 All ER 448 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)

[MA (Somalia) v Secretary of State for the Home Dept [2010] UKSC 49, [2011] 2 All ER 65 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52HJ-R1C1-DYBP-M495-00000-00&context=1519360)

**End of Document**


-----

