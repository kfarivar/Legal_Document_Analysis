# *A and another v Criminal Injuries Compensation Authority and another

 [2021] All ER (D) 33 (Jul)

[2021] UKSC 27

Supreme Court

Lord Lloyd-Jones, Lady Arden, Lord Hamblen, Lord Burrows and Lord Stephens SCJJ

9 July 2021

**Compensation – Criminal injuries – Entitlement to compensation**
Abstract

_Excluding the appellant victims of human trafficking from compensation under the 2012 iteration of the Criminal_
_Injuries Compensation Scheme (the CICC) on the ground of their previous criminal convictions did not unjustifiably_
_discriminate against them, in breach of art 14, taken with art 4, of the European Convention on Human Rights. The_
_Supreme Court, in dismissing the appellant's appeal, held that the appellants' case on unlawful discrimination,_
_founded on the fact that they were victims of people trafficking, had not been made out, and that the difference in_
_treatment on ground of 'other status', resulting from Annex D of the CICC, was justified because it had the_
_legitimate objective of limiting eligibility to compensation to those deserving of it. Further, the court held that the_
_measure satisfied the requirement of proportionality, and that the lower courts had correctly concluded that it could_
_not be regarded as manifestly without reasonable foundation._
Digest

The judgment is available at: [2021] UKSC 27

**Background**

The appellants (A and B) were twin brothers and Lithuanian nationals.

In June 2010, A was convicted of burglary by a Lithuanian court and he was sentenced to a three-year custodial
sentence. In December 2011, B was convicted of theft by a Lithuanian court and he was sentenced to an 11-month
custodial sentence

In 2013, the appellants were trafficked from Lithuania to the UK and subjected to labour exploitation and abuse. The
traffickers responsible were convicted and each sentenced to a custodial term of three-and-a-half years and slavery
[and trafficking prevention orders were made under the Modern Slavery Act 2015 (MSA 2015).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

The appellants applied to the first respondent, the Criminal Injuries Compensation Authority (the CICS) for
compensation. However, they were refused an award pursuant to the exclusionary rule contained in para 26 and
Annex D para 3 of the CICS (the exclusionary rule), as they each had an unspent conviction which had resulted in a
custodial sentence. The effect of the exclusionary rule was that the appellants were automatically disqualified from
receiving an award under the CICS.

The appellants brought judicial review proceedings to challenge the lawfulness of the exclusionary rule,
disqualifying them from receiving an award of compensation by virtue of the existence of unspent convictions which
had resulted in a custodial sentence or a community order


-----

The judge (Wilkie J) dismissed the claim that the exclusionary rule constituted discrimination, contrary to art 14 of
the European Convention on Human Rights, against victims of crimes of violence who had unspent convictions. He
also dismissed the claim that the exclusionary rule was a breach of art 1 of the First Protocol to the Convention
(which concerned the protection of property) or art 4 of the Convention (concerning the prohibition of slavery and
forced labour). Further, Wilkie J dismissed the appellants' claim that the CICS constituted a violation of _[Directive](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_
_[2011/36/EU (the Directive).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_

The appellants appealed to the Court of Appeal, Civil Division. Their amended grounds of appeal raised two
grounds, namely that: (i) the CICS was incompatible with art 17 of the Directive because it mandatorily excluded
some victims of trafficking from an award by virtue of their unspent convictions; and (ii) such a rule constituted
discrimination contrary to art 14, read with art 4, of the Convention. The Court of Appeal dismissed the appeal on
both grounds.

The appellants appealed to the Supreme Court.

**Issues and decisions**

Whether excluding A and B, who had been victims of human trafficking, from compensation under the 2012 iteration
of the Criminal Injuries Compensation Scheme (the CICC) on the ground of their previous criminal convictions
unjustifiably discriminated against them, in breach of art 14, taken with art 4, of the Convention.

Article 14 of the Convention was not a freestanding prohibition of discriminatory treatment. It prohibited
discrimination only in the context of the enjoyment of the rights and freedoms set out in the Convention. As a result,
it was necessary to determine whether the subject matter of the complaint was sufficiently closely connected with
one of the substantive Convention rights, so as to fall within its ambit or scope. The appellants did not need to
establish that the exclusionary rule set out in para 26 and Annex D para 3 of the CICS violated or interfered with
their rights under art 4. They need only establish that it was sufficiently closely linked to art 4 to bring art 14 into play
(see [23] of the judgment).

In the present case, while the CICS was not limited to victims of trafficking, it extended its benefits to them. In the
preparation of the scheme, specific attention was paid to its application to victims of trafficking and provisions
included in order to accommodate them. The UK, in applying the scheme to victims of trafficking, had chosen to
confer a degree of protection to promote their interests. In doing so, it was applying a measure which had a more
than tenuous connection with the core value of the protection of victims of trafficking under art 4. The rights
voluntarily conferred in that way under the scheme on victims of trafficking fell within the general scope of art 4 and
had, therefore, to be made available without discrimination (see [39] of the judgment).

Article 14 of the Convention provided that the enjoyment of the rights and freedoms set out in the Convention would
be secured 'without discrimination on any ground such as sex, race, colour, language, religion, political or other
opinion, national or social origin, association with a national minority, property, birth or other status'. It provided a list
of grounds on which discrimination was prohibited. In the present case, the treatment of which the appellants
complained did not fall within any of the specific grounds listed in art 14 and they had to, therefore, demonstrate
that they enjoyed some 'other status' for the purpose of art 14 (see [40] of the judgment).

In the light of the more generous approach to status, being a victim of trafficking did constitute a status for that
purpose. Although it was an acquired characteristic resulting from something done, as opposed to being inherent or
innate, it was plainly a personal identifiable characteristic to which many important legal consequences attached
(see [46] of the judgment).

Further, the recent jurisprudence in Strasbourg and in the Supreme Court had shown a significant shift towards
taking a broad view of status under art 14 and, as a result, the concept of 'other status' had to be generously
interpreted. Article 14 drew a distinction between relevant status and difference in treatment and the former could
not be defined solely by the latter. There had to be a ground for the difference of treatment in terms of a
characteristic which was something more than a mere description of the difference in treatment. In the present
case, the distinguishing feature or characteristic which enabled persons with an unspent conviction which resulted


-----

in a custodial or community sentence to be singled out for separate treatment had been identified as a personal
characteristic before it was used for this purpose in the CICS. The status of the appellants as persons with unspent
relevant convictions did have a significance independent of the CICS. However, there was no requirement that the
status should have legal or social significance for other purposes or in contexts other than the difference in
treatment of which complaint was made (see [57], [66] of the judgment).

It followed that having an unspent conviction which resulted in a custodial or community sentence was a status for
the purposes of art 14, considered in conjunction with art 4 (see [67] of the judgment).

Discrimination might arise where the state failed to treat differently persons whose situations were significantly
different. However, the present court was unable to identify any feature of the offence of people trafficking which
could require preferential treatment to be accorded in the present context to victims of trafficking over victims of
other serious crime. The difficulty faced by the appellants in the present case was that nexus offenders formed a
sub-group of victims of trafficking who had unspent convictions, and the appellants did not fall within that sub-group.
The relevant conviction of each of the appellants related to an offence committed long before they had become a
victim of trafficking. Each had been convicted and had completed his prison sentence before being trafficked. The
offending on the part of the present appellants was totally unconnected with their being victims of trafficking. As a
result, their arguments as to the alleged inadequacies of the non-punishment provisions applicable to nexus
offenders had no application to their case. Whatever inadequacies in that regime there might be, they could not say
that it puts them in a different position from a non-trafficked offender, because that regime did not, and could not,
apply to their earlier offending. It followed that the appellants' case on unlawful discrimination, founded on the fact
that they had been victims of people trafficking, had not been made out (see [69]-[78] of the judgment).

On the alternative basis, the appellants submitted that, in excluding from the CICS victims of trafficking with an
unspent conviction which resulted in a custodial or community sentence, but not other victims of trafficking, the
scheme discriminated on ground of other status. Clearly, there was a difference in treatment between those who
had relevant unspent convictions and who were, therefore, excluded from compensation, and those who did not
and were, therefore, not excluded from compensation. The issue for consideration was whether the exclusion from
the CICS of victims of trafficking with an unspent conviction which resulted in a custodial or community sentence, as
opposed to other victims of trafficking, was justified. The applicable test was whether the decision to adopt the CICS
was manifestly without reasonable foundation (see [79]-[82] of the judgment).

The CICS operated in the field of social welfare policy where courts should normally be slow to substitute their view
for that of the decision maker. The question whether and, if so to what extent, the state should pay compensation to
victims of crimes of violence who had, themselves, committed crimes was essentially a question of moral and
political judgement, Further, it required the exercise of political judgement in relation to the allocation of finite public
resources. That was, therefore, a field in which the courts should accord a considerable degree of respect to the
decision maker. Furthermore, the reasons for judicial restraint were greater where, as in the present case, the
statutory instrument had been reviewed by Parliament. Moreover, the basis of the discriminatory treatment
complained of was also relevant. The status relied on in the present case, i.e. being a victim of trafficking with a
relevant unspent conviction, was not within the range of suspect reasons where discrimination was usually
particularly difficult to justify. Accordingly, to ask whether the measure was manifestly without reasonable
foundation was an entirely appropriate test (see [83]-[85] of the judgment).

In all the circumstances, the difference in treatment on ground of other status, resulting from Annex D, was justified.
The measure had the legitimate objective of limiting eligibility to compensation to those deserving of it. Further, the
measure satisfied the requirement of proportionality. It was rationally connected to the objective. The measure was
no more intrusive than it required to be and it struck a fair balance between the competing interests. Wilkie J and
the Court of Appeal had clearly been correct in concluding that it could not be regarded as manifestly without
reasonable foundation (see [86]-[88], [90]-[92] of the judgment).

_R v Docherty_ _[[2016] UKSC 62 [2017] 1 WLR 181 [2017] 4 All ER 263](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PN2-YC81-DYBP-M2J5-00000-00&context=1519360)_ _[[2016] All ER (D) 72 (Dec) distinguished](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MD0-XN21-DYBP-N1NB-00000-00&context=1519360)_


-----

_R (on the application of DA and others) v Secretary of State for Works and Pensions; R (on the application of DS_
_and others) v Secretary of State for Work and Pensions_ _[2019] UKSC 21_ _[[2020] 1 All ER 573](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5Y55-TKT3-GXFD-830S-00000-00&context=1519360)_ _[[2019] All ER (D) 76](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VH3-GRH2-D6MY-P55H-00000-00&context=1519360)_
_[(May) explained](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VH3-GRH2-D6MY-P55H-00000-00&context=1519360)_

_Engel v Netherlands (Application 5100/71, 5101/71, 5102/71) 1 EHRR 647 [1976] ECHR 5100/71 considered_

_Petrovic v Austria (1998) 33 EHRR 14 considered_

_[Pine Valley Developments Ltd v Ireland (Application 12742/87) 14 EHRR 319 (1991) Times, 11 December [1991]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4PN-00000-00&context=1519360)_
_[ECHR 12742/87 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F881-DYBP-X4PN-00000-00&context=1519360)_

_[Thlimmenos v Greece (Application 34369/97) 31 EHRR 411 [2000] ECHR 34369/97 9 BHRC 12 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X4N9-00000-00&context=1519360)_

_[Okpisz v Germany (Application No 59140/00) 42 EHRR 671 [2005] ECHR 59140/00 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1BC-00000-00&context=1519360)_

_[Stec v United Kingdom (Applications 65731/01 and 65900/01) 43 EHRR 1017 [2006] ECHR 65731/01](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X398-00000-00&context=1519360)_ _[[2006] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JXM1-DYBP-N1KH-00000-00&context=1519360)_
_[(D) 215 (Apr) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JXM1-DYBP-N1KH-00000-00&context=1519360)_

_R (on the application of Clift) v Secretary of State for the Home Department; R (on the application of Hindawi) v_
_Secretary of State for the Home Department_ _[[2006] UKHL 54 [2007] 1 AC 484 [2007] 2 WLR 24 [2007] 2 All ER 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NBY-MTM0-TWP1-60SN-00000-00&context=1519360)_

_[[2006] All ER (D) 188 (Dec) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JVY1-DYBP-N418-00000-00&context=1519360)_

_Shelley v United Kingdom (App no 23800/06)_ _[[2008] Lexis Citation 4870 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4RTV-8D20-TWYV-N1CC-00000-00&context=1519360)_

_R (on the application of Animal Defenders International) v Secretary of State for Culture, Media and Sport_ _[2008]_
_[UKHL 15 [2008] 2 WLR 781 [2008] 3 All ER 193](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SW6-XF50-TWP1-602H-00000-00&context=1519360)_ _[[2008] All ER (D) 155 (Mar) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4S1T-GFY0-TWP1-713C-00000-00&context=1519360)_

_R (on the application of RJM (FC) v Secretary of State for Work and Pensions_ _[2008] UKHL 63 [2008] 3 WLR 1023_

_[[2009] 2 All ER 556](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W6K-CMW0-Y96Y-G0D2-00000-00&context=1519360)_ _[[2008] All ER (D) 220 (Oct) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4TRR-PBR0-TWP1-70TH-00000-00&context=1519360)_

_[Rantsev v Cyprus and Russia (Application 25965/04) 51 EHRR 1 [2010] ECHR 25965/04 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X02K-00000-00&context=1519360)_

_[Clift v United Kingdom (Application 7205/07) (2010) Times, 21 July [2010] ECHR 7205/07 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1CR-00000-00&context=1519360)_

_Bah v United Kingdom 54 EHRR 773 [2011] ECHR 56328/07_ _[[2011] All ER (D) 134 (Sep) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53WS-5F61-DYBP-N0C7-00000-00&context=1519360)_

_Bank Mellat v Her Majesty's Treasury_ _[[2013] UKSC 39 [2013] 3 WLR 179 [2013] 4 All ER 533](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_ _[[2013] All ER (D) 172](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58P9-HPY1-DYBP-N1GX-00000-00&context=1519360)_
_[(Jun) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58P9-HPY1-DYBP-N1GX-00000-00&context=1519360)_

_R v L_ _[2013] EWCA Crim 991_ _[[2014] 1 All ER 113](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_ _[[2014] 3 LRC 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CNF-07R1-DYJ0-84JT-00000-00&context=1519360)_ _[[2013] All ER (D) 216 (Jun) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58RB-D6B1-DYBP-N1KF-00000-00&context=1519360)_

_R (on the application of Tigere) v Secretary of State for Business, Innovation and Skills_ _[2015] UKSC 57 [2015] 1_
[WLR 3820 [2016] 1 All ER 191](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HVR-2151-DYBP-M3GG-00000-00&context=1519360) _[[2015] All ER (D) 304 (Jul) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GJG-V641-DYBP-N52S-00000-00&context=1519360)_

_R (on the application of Haney) v Secretary of State for Justice_ _[[2014] UKSC 66 [2015] 2 WLR 76 [2015] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G0G-M5W1-DYBP-M2GS-00000-00&context=1519360)_
_[822](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G0G-M5W1-DYBP-M2GS-00000-00&context=1519360)_ _[[2014] All ER (D) 114 (Dec) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DT8-02M1-DYBP-N2ST-00000-00&context=1519360)_

_Mathieson v Secretary of State for Work and Pensions_ _[[2015] UKSC 47 [2015] 1 WLR 3250 [2016] 1 All ER 779](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J5P-0TS1-DYBP-M47G-00000-00&context=1519360)_

_[[2015] All ER (D) 90 (Jul) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GD1-P231-DYBP-N0D7-00000-00&context=1519360)_

_Chowdury v Greece (App no 21884/15) (unreported, 30 March 2017) considered_

_R v Joseph_ _[[2017] EWCA Crim 36 [2017] 1 WLR 3153 [2017] All ER (D) 100 (Feb) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_


-----

_Smith (suing in her own right and as the surviving partner of Bulloch, deceased) v Lancashire Teaching Hospitals_
_NHS Foundation Trust and others_ _[[2017] EWCA Civ 1916 [2018] QB 804 [2018] 2 WLR 1063 [2017] All ER (D) 11](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R3P-8GP1-DYBP-N285-00000-00&context=1519360)_
_[(Dec) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R3P-8GP1-DYBP-N285-00000-00&context=1519360)_

_R (on the application of Tirkey) v Director of Legal Aid Casework and another_ _[2017] EWHC 3403 (Admin) [2018] 1_
[WLR 2112 [2018] All ER (D) 18 (Jan) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RCT-77N1-DYBP-N1X0-00000-00&context=1519360)

_Re McLaughlin's Application for Judicial Review (Northern Ireland)_ _[[2018] UKSC 48 [2018] 1 WLR 4250 [2019] 1 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TR3-9KC2-8T41-D42W-00000-00&context=1519360)_
_[ER 471](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TR3-9KC2-8T41-D42W-00000-00&context=1519360)_ _[[2018] All ER (D) 144 (Aug) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T52-6V31-DYBP-N06D-00000-00&context=1519360)_

_R (on the application of Stott) v Secretary of State for Justice_ _[[2018] UKSC 59 [2018] 3 WLR 1831 [2019] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)_
_[351](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V99-0X92-D6MY-P4GS-00000-00&context=1519360)_ _[[2018] All ER (D) 142 (Nov) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TV7-Y171-DYBP-N049-00000-00&context=1519360)_

_Mayor and Burgesses of the London Borough of Haringey v Simawi (Secretary of State for Housing, Communities_
_and Local Government, interested party)_ _[2019] EWCA Civ 1770_ _[[2020] 2 All ER 701](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YX3-1X23-CGXG-03WY-00000-00&context=1519360)_ _[[2019] All ER (D) 01 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XD9-8XY3-GXFD-80MB-00000-00&context=1519360)_
applied

_S.M. v Croatia (App. No. 60561/14)_ _[[2020] ECHR 60561/14 49 BHRC 1 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60B2-3B93-CGXG-045Y-00000-00&context=1519360)_

_R (on the application of SC, CB and 8 children) v Secretary of State for Work and Pensions and others._ _[2021]_
_UKSC 26 considered_

Appeal dismissed.

[Decision of The Court of Appeal, Civil Division [2018] All ER (D) 17 (Jul) affirmed.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SPW-2N41-DYBP-N18D-00000-00&context=1519360)

Phillippa Kaufmann QC and Shu Shin Luh (instructed by Leigh Day (London)) for the appellants.

Ben Collins QC and Robert Moretto (instructed by Government Legal Department) for the CICS.

Karon Monaghan QC, James Robottom and Admas Habteslasie (written submissions only) (instructed by
Freshfields Bruckhaus Deringer LLP (London)) for ATLEU as intervener.
Carla Dougan-Bacchus Barrister.

**End of Document**


-----

