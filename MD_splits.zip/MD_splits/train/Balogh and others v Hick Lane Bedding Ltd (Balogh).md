# Balogh and others v Hick Lane Bedding Ltd (Balogh)

**Date** 09/03/2021

**General damages (PSLA)** £60,000.00


**General Damages (PSLA)**
**Today's Value (incl SvC uplift*)**


£78,794.21


**Major injury** PTSD with an alternative diagnosis of adjustment disorder with depression and anxiety
and also development of paranoid schizophrenia

**Injury category** Psychiatric Damage Generally; Post Traumatic Stress Disorder

**Injury duration and prognosis**

Psychiatric Damage Generally

Post Traumatic Stress Disorder

The Claimant needed at least 12 sessions of CBT. The prognosis then was for
improvement over an 18-month to two-year period, and a period of two to three years
to recover his working capacity.

**Facts**

The Claimant was a victim of modern slavery. His period of employment with the
Defendant was 14 days. He was housed in squalid and overcrowded conditions and
treated with a total lack of respect and consideration amounting to cruelty. The expert
report confirmed the Claimant was suffering from complex PTSD, caused by his
experiences at the hands of the Defendant. An alternative diagnosis was adjustment
disorder with depression and anxiety. This was in the 'severe' range of DSM-IV, though
his presenting symptoms were in the 'moderate' range. He stood in need of at least 12
sessions of CBT. The prognosis then was for improvement over an 18-month to twoyear period, and a period of two to three years to recover his working capacity. When
he saw an expert who prepared an updating report three years and six months after
the first report, he was suffering from PTSD within the diagnostic criteria of DSM-V,
and he had also developed paranoid schizophrenia. The worsening of his condition
meant he required more intensive treatment from a clinical psychologist over a period
of two years. He had had two hospital admissions, was taking antidepressant
medicines, and was under the care of the community mental health team. The expert
did not give a specific prognosis, but it appeared from the report by the first expert that
the most optimistic prognosis would be a return to a reasonably normal level of
functioning within about two and a half years. The Claimant fell into the 'moderately
severe' bracket of the Judicial College Guidelines for post-traumatic stress disorder
and/or a general psychological damage. His symptoms were not sufficiently disabling
and the prognosis was not sufficiently bleak to place him into the 'severe' bracket. But
he had two separate conditions and therefore fell above the midpoint of the 'moderately
severe' bracket. Additionally, he suffered the loss of his personal autonomy and the
impact on his liberty and freedom of action, which were the result of the intentional
torts. This was akin to a period of false imprisonment. The duration was 14 days. For
injury to feelings, he fell into the middle Vento guideline. An appropriate global award,
reflecting these three heads was £60,000. The conduct of the Defendant led to an
award of exemplary damages of £5,000. This was added to the total, making a grand
total of general damages of £65,000. Citation: [2021] EWHC 1140 (QB).

**Age at injury** 34 Year(s)

**Age at trial** 42

**Gender** Male


-----

**Type of claim** Employers' Liability; Other; Psychiatric and Occupational Stress; Criminal Injury

**Total damages** £263,120.00

**Court** Queen's Bench Division

**Judge** Master Davison

**Contributor's firm** Lexis Nexis

**Notes**

The General Damages (PSLA) Today’s Value figure includes:

## • the Heil v Rankin uplift if the award was made on or before 23 March 2000
and is over £10,000 and

## • * the Simmons v Castle uplift. (If the award was made on or before 1 April
2013 or if the award was after 1 April 2013 and subject to a pre-1 April 2013
Conditional Fee Agreement, the Simmons v Castle uplift has been added by
us except in mesothelioma cases. All other cases will have already had the
_Simmons v Castle uplift applied in the original damages award)._

For further details see our Flowchart: Quantum database general damages uplifts.

**End of Document**


-----

