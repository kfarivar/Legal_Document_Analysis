# Sheikh v The Law Society of England and Wales and others

_[2024] EWHC 2185 (Ch)_

**Court: Chancery Division**
**Judgment Date: 21/08/2024**

# Catchwords & Digest

**LOCAL GOVERNMENT—DRAFT APPLICATION—APPLICATION AGAINST LAW SOCIETY**

[The Chancery Division dismissed the claimant’s the application for leave under s 42(3) of the Senior Courts](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y1C1-00000-00&context=1519360)
Act 1981 to issue her draft application notice against the defendants, the Law Society. She sought leave not only to
issue applications in a number of proceedings but also to initiate fresh proceedings. She identified herself as
vulnerable and as a victim of torture, of modern slavery, as having been made homeless. The court held that the
provision of leave under s 42(3) to the claimant would have unleashed a tidal wave of re-litigation and/or fresh
litigation. The court was satisfied that every part of it would have been an abuse of process, on one or more of the
following bases that: (i) she sought to re-open litigation which concluded with a final decisions years ago; (ii) she
sought to intermeddle in other litigation and also finally concluded, she had no involvement at the time of the
original cases; and (iii) she seemed to have appointed herself as the standard bearer for any solicitor aggrieved by
an intervention by the Law Society, but her application(s) failed to appreciate that, if anyone was to strike down or
revise the intervention powers provided to the Law Society by s 35 of and Sch 1 to the Solicitors Act 1974, that was
a matter for Parliament and not judges.

**End of Document**


-----

