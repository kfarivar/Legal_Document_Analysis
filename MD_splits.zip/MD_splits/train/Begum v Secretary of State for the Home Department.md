# Begum v Secretary of State for the Home Department [2023] Lexis Citation
 393

Special Immigration Appeals Commission

Jay J, Judge Canavan and J Battley

22 February 2023Judgment

OPEN JUDGMENT

Dan Squires KC, Samantha Knights KC, Julianne Kerr Morrison, Ayesha Christie and Tim James-Matthews
(instructed by Birnberg Peirce) for Shamima Begum

Sir James Eadie KC, Jonathan Glasson KC, David Blundell KC, Jennifer Thelen and Karl Laird (instructed by the
Government Legal Department) appeared on behalf of the Secretary of State

Angus McCullough KC and Adam Straw KC (instructed by Special Advocates' Support Office) appeared as Special
Advocate

MR JUSTICE JAY:

INTRODUCTION

1. This appeal is brought under section 2B of the Special Immigration Appeals Act 1997 (“the 1997 Act”). We will
describe the parties to the appeal as Ms Begum and the Secretary of State. The Special Immigration Appeals
Commission will be referred to throughout as “the Commission”.

2. It is an appeal about fundamental principles, rights and obligations. These are matters of the highest importance.
British citizenship is a fundamental entitlement and carries with it rights and privileges of huge importance to the
individual, in particular the right of abode in this country. The rule of law is equally important, placing at the heart of
our constitutional settlement ever since Magna Carta, the right of the subject not to be outlawed or exiled “except by
the lawful judgment of [her] peers and the law of the land” (clause 39). Last but not least in this catalogue comes
the duty of Government, acting for these purposes through the Secretary of State, to uphold and safeguard the
national security of the United Kingdom.

3. The rule of law is non-negotiable. What it requires in any given case is for the Commission to determine, loyally
applying principles enunciated by higher courts.

4. British citizenship is not an absolute entitlement for everyone. It can be removed by the Secretary of State, but
not if to do so would render the subject stateless. Many citizens of the United Kingdom are immune from deprivation
action for that reason, but not Ms Begum.

5. National security is not an absolute imperative. It does not trump everything else. It must be weighed against
fundamental rights and entitlements.

6. Expressing the issues in this stark way demonstrates the importance of this appeal to the parties and the public
at large as well as the importance of the work undertaken by this Commission.


-----

7. Ms Begum was born in the United Kingdom on 25th August 1999. She was brought up in Bethnal Green in the
London Borough of Tower Hamlets. Her parents are of Bangladeshi origin and, through them, Ms Begum has
Bangladeshi citizenship (or, at least, had it until her 21st birthday). There is no OPEN evidence that Ms Begum has
ever been to Bangladesh or that she has any ties with that country.

8. On 17th February 2015 Ms Begum, then aged 15, travelled with two friends to Syria. Once there, it is the
Secretary of State's judgment, advised as he was at all material times by the Security Service (“SyS” or “MI5”), that
she aligned with ISIL and married an ISIL fighter.

9. The self-styled caliphate effectively collapsed in January 2019 after a series of military defeats. Ms Begum,
together with her husband, were in the last pockets of ISIL territory in Baghuz. They surrendered and were captured
by members of the Syrian Democratic Forces (“the SDF”). Ms Begum was taken to the Al-Hawl camp in north-east
Syria. In mid-February 2019, then nine months pregnant and subsequently even after she had just given birth, she
gave a number of interviews to a reporter from The Times newspaper and to other print and TV journalists.

10. On 18th February 2019 the Secretary of State was provided with a Ministerial Submission, backed by other
statements and assessments, recommending that Ms Begum be deprived of her British citizenship. The Secretary
of State accepted that recommendation and on 19th February he decided to make a deprivation order under section
40(2) of the British Nationality Act 1981 (“the _[BNA 1981”) on the ground that it would be conducive to the public](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GSM0-TWPY-Y0YY-00000-00&context=1519360)_
good to do so, because her return to the United Kingdom would present a national security risk. The deprivation
order was made the same day.

11. Since late February 2019 Ms Begum has been held in the Al-Roj camp for internally displaced persons. Those
responsible for the camp, the Autonomous Administration of North and East Syria, are keen for the camp to be
cleared and for foreign nationals to be repatriated by those they consider to be responsible for them.

12. Ms Begum's section 2B appeal has already accumulated considerable litigation. In short, this Commission
ordered the trial of three preliminary issues in 2019, and her case went all the way up to the Supreme Court where
judgment was handed down on 26th February 2021 ([2021] UKSC 7; [2021] AC 765). Having lost all three
preliminary issues, Ms Begum brought her appeal back to the Commission on a series of proposed amended
grounds, described as “replacement grounds”, incorporating new arguments. The Commission held a number of
directions hearings in 2021 and handed down three judgments. These reveal an evolution in the Chairman's
thinking as the complex ramifications of the Supreme Court's judgment were more fully understood.

13. Any further summary of the litigation to date is not required. All that need be stated is that Ms Begum was
granted permission to advance all her amended grounds in the face of resistance from the Secretary of State as to
some of them. It was apparent that for the foreseeable future Ms Begum could not give her solicitors confidential
instructions on the merits of her appeal. The Commission having decided that she should not be permitted to
advance certain grounds with others being stayed, concluded that Ms Begum's options were twofold: either to
accept that the entirety of her appeal should be stayed until her circumstances changed and instructions could be
given; or, alternatively, instruct her legal team to advance her appeal without those instructions. She chose the
latter course.

14. The Commission fully understands Ms Begum's reasons and that she will have been advised on the pros and
cons. One obvious disadvantage is that she has been unable to give sworn evidence to the Commission on the
issues at the heart of this appeal. Another factor, although it is capable of cutting both ways, is that the Secretary of
State has not had the opportunity to cross-examine Ms Begum. Although it would not be right to draw inferences
adverse to Ms Begum from the fact that she has not testified, the Commission accepts the Secretary of State's
submission that caution must be exercised before accepting some of the assertions made on Ms Begum's behalf
regarding her reasons and motivations at relevant times. The Commission can, of course, draw inferences where
appropriate, but will only do so having exercised that element of circumspection.

MS BEGUM'S AMENDED GROUNDS


-----

15. The “Replacement Grounds of Appeal” is a lengthy document. For these purposes, the Commission
summarises these grounds as follows.

16. GROUND 1: the Secretary of State failed to take into account an obviously material relevant consideration
and/or failed to undertake proper inquiries into it, namely that Ms Begum may have been a victim of trafficking in
February 2015, and thereafter.

17. GROUND 2: the decision to deprive Ms Begum of her British citizenship was in breach of the United Kingdom's
obligations under section 6 of the Human Rights Act 1998 (“the HRA”) with reference to Article 4 of the European
Convention on Human Rights (“the ECHR”), because there was at the very least a credible suspicion that she had
been trafficked.

18. GROUND 3: the deprivation decision rendered Ms Begum de facto stateless because Bangladesh was unlikely
to be able or willing to provide her with any practical protection. This was a relevant consideration and/or one in
respect of which the Secretary of State failed to undertake proper inquiry.

19. GROUND 4: the deprivation decision was procedurally unfair in that Ms Begum was not afforded the
opportunity to make representations about it, or to have representations made on her behalf.

20. GROUND 5: the Secretary of State personally had pre-determined whether Ms Begum should be deprived of
her citizenship, alternatively a fair-minded and informed observer would think that the evidence gives rise to a real
possibility or risk that this was the case.

21. GROUND 6: the Secretary of State failed to undertake sufficient inquiries to ensure that his deprivation
decision was made on the basis of a body of material allowing him properly to assess whether Ms Begum posed a
sufficient threat to national security to justify depriving her of citizenship and/or failed to take account of relevant
considerations.

22. GROUND 7: the Secretary of State failed to comply with the public sector equality duty (“the PSED”) imposed
[by section 149 of the Equality Act 2010 (“the EqA 2010”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)

23. GROUND 8: the Secretary of State's national security assessment was irrational and/or, to the extent that Ms
Begum poses a risk, less intrusive measures were capable of dealing with it.

24. GROUND 9: the deprivation decision was disproportionate under common law and Article 8 of the ECHR.

THE MATERIAL BEFORE THE COMMISSION

25. The Commission has been provided with voluminous evidence and submissions, all of which has been
considered but not all of which will be summarised. The key matters will be identified and examined during the
course of this judgment.

26. We acknowledge the vast amount of work that has been undertaken by both sides as well as the quality, range
and depth of the written and oral arguments.

27. The Commission has also examined CLOSED material. For reasons of national security that cannot be placed
into the public domain. In relation to this CLOSED material, Ms Begum's interests have been protected by Special
Advocates, two experienced King's Counsel, appointed to act on her behalf. They have discharged their obligations
fully. The Commission has prepared a CLOSED judgment which addresses that material. As much as possible has
been placed in OPEN as this litigation has progressed.

THE LEGAL FRAMEWORK

Conducive to the Public Good

28. The deprivation power is expressed in the broadest possible terms in section 40 of the BNA 1981:


-----

“40. Deprivation of Citizenship UK

…

(2) The Secretary of State may by order deprive a person of a citizenship status if the Secretary of State is satisfied
that deprivation is conducive to the public good.

…

(4) The Secretary of State may not make an order under subsection (2) if satisfied that the order would make a
person stateless.

(5) Before making an order under this section in respect of a person the Secretary of State must give the person
written notice specifying –

(a) that the Secretary of State has decided to make an order,

(b) the reasons for the order, and

(c) the person's right of appeal under section 40A(1) or under section 2B of the [1997 Act].”

29. The phrase “conducive to the public good” is familiar to the Commission in an immigration context generally.
Chapter 55.4.4 of the Secretary of State's guidance, under the rubric “Deprivation and nullity of British citizenship”,
defines the phrase as meaning “depriving in the public interest on the grounds of involvement in terrorism,
espionage, serious organised crime, war crimes or unacceptable behaviours”. It is not in dispute that the power may
be exercised if a person is a threat to the national security of the United Kingdom. The meaning of that concept
does not require much elaboration, but the Commission may recall to mind what a former Home Secretary, the Rt
Hon Douglas Hurd MP, had to say about it during the passage of the Security Service Bill in 1989:

“By its very nature, the phrase refers – and can only refer – to matters relating to the survival and well-being of the
nation as a whole, and not to party political, sectional or lesser interests.”

30. In Secretary of State for the Home Department v Rehman _[2001] UKHL 47; [2003] 1 AC 153, Lord Slynn_
described national security as being “the security and well-being of the nation” (para 15). For Lord Hoffmann, it was
“the security of the United Kingdom and its people” (para 49). Lord Hoffmann gave the following additional
guidance:

“56. But the question in the present case is not whether a given event happened but the extent of future risk. This
depends upon an evaluation of the evidence of the appellant's conduct against a broad range of facts with which
they may interact. The question of whether the risk to national security is sufficient to justify the appellant's
deportation cannot be answered by taking each allegation seriatim and deciding whether it has been established to
some standard of proof. It is a question of evaluation and judgment, in which it is necessary to take into account not
only the degree of probability of prejudice to national security but also the importance of the security interest at
stake and the serious consequences of deportation for the deportee.”

These last observations are all the more salient in a case involving deprivation of a fundamental right because Mr
Rehman had only limited leave to remain in the United Kingdom.

31. Ms Begum relies on the following passage from the dissenting judgment of Lord Kerr of Tonaghmore JSC in Ali
v SSHD [2016] UKSC 60; [2016] 1 WLR 4799:

“169. … the public interest is multi-faceted, and there are important factors which contribute to the positive
development of our society and are thus matters in the general public interest. These factors may be a relevant
consideration in the article 8 proportionality assessment, and have a free-standing value, independent of that which
attaches to the individual facing deportation. For example, there is a public interest in families being kept together,
in the welfare of children being given primacy, and in encouraging and respecting the rehabilitation of offenders.


-----

These factors all play a role in the construction of a strong and cohesive society. They are recognised outwith the
immigration context, and certain factors are given statutory recognition. Where relevant they should be part of the
proportionality equation.”

Ms Knights submitted that the possibility that an individual has been trafficked should be added to these public
interest considerations.

32. Lord Kerr was writing in the context of the deportation of foreign criminals, where certain factors are given
statutory recognition. But the deprivation power under section 40(2) is extremely broad, and it is for the Secretary of
State to make the primary judgment as to whether deprivation is conducive to the public good. In the present
context, an assessment that an individual poses a threat to national security may rationally be given great weight by
the Secretary of State. Factors in the individual's favour must, of course, be considered, but to the extent that Lord
Kerr might be interpreted as saying that any particular weight must be given to those factors (and the Commission
is far from convinced that he was saying that) we would respectfully disagree. The weight to be given to any factor
known to the Secretary of State, or after Tameside inquiry ought to have been known to him, is for the Secretary of
State to evaluate and not for us to decide for ourselves, subject always to Wednesbury review.

The Role of the Commission

33. Section 2B of the 1997 Act provides:

[“A person may appeal to [the Commission] against a decision to make an order under section 40 of the [BNA 1981]](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GSM0-TWPY-Y0YY-00000-00&context=1519360)
…”

34. The Commission was created by section 1(1) of the 1997 Act. Beyond being described as a superior court of
record under section 1(1), the functions of the Commission are not specified. All that may be deduced from the
statute is that an appeal is not a review: c.f. for example, section 2C, where judicial review principles are expressly
applicable.

35. The Commission has recently summarised its understanding of the relevant legal principles in the case of B4 v
SSHD (SC/159/2018) handed down on 1st November 2022. That summary was largely drawn from the decisions in
Begum, SSHD v P3 [2021]

EWCA Civ 1642; [2022] 1 WLR 2869, and the Commission's decision in U3 v SSHD (Appeal No: SC/153/2018 and
SC/153/2021). In U3 the Commission's judgment was written by Chamberlain J; in B4 by the Chairman. It should
now be made clear, as it perhaps may not have been in B4, that if the Chairman had disagreed with U3 in any
material respect that would have been made explicit. Subject to the specific matters mentioned below, the parties
do not take issue with the Commission's analysis, although Ms Begum formally reserves her position in the event
that the ground-rules should be altered in a higher court.

36. It is convenient to repeat what the Commission said in B4 before going any further. Eight propositions were
distilled from the authorities although Sir James Eadie KC suggested that proposition seven was the Commission's
own “feathering” of proposition five, derived as it was from U3. We have slightly modified the text of B4 to reflect the
different nomenclature being used in this appeal and the removal of irrelevant sub issues.

37. First, although s. 2B of the 1997 Act confers a right of appeal, as opposed to a right to a review, the principles
to be applied by SIAC in reviewing the Secretary of State's exercise of discretion are largely the same as those
applicable to judicial review. To the extent that matters in issue are justiciable (see the second proposition below),
this entails an application of the familiar principles enunciated in the Wednesbury case ([1948] KB 223) and in
Edwards v Bairstow [1956] AC 14.

38. Secondly, certain national security questions are simply not justiciable (e.g. whether the promotion of terrorism
in a foreign country by a UK resident would be contrary to national security); others entail an evaluative judgment
which is incapable of objective assessment. In relation to such questions (e.g. the level and nature of the risk posed
by an appellant, the effectiveness of the means available to address that risk, and the acceptability or otherwise of


-----

the consequent danger), the Commission is able to investigate them but must apply familiar public law principles.
The Commission's approach, which falls short of applying the principles ordinarily germane to a full merits appeal,
reflects the axioms of institutional competence and democratic accountability.

39. Thirdly, the full gamut of public law grounds is available to an appellant, including failure without good reason to
apply an established policy, failure to take into account relevant considerations (a sub-set of Wednesbury), breach
of the Tameside duty to make adequate inquiry (to which Wednesbury principles apply, because it is not for the
Commission to decide for itself what constitutes adequate inquiry), failure to provide the decision-maker with
adequate information and a fair and balanced account of the case as a whole, and error of established fact.

40. Fourthly, the public law error must be material in the sense that it would be open to the Secretary of State to
show that the outcome would have been the same irrespective of the error.

41. Fifthly, evidence post-dating the deprivation decision is admissible in the appeal, but only insofar as it relates to
matters occurring before the decision.

42. Sixthly, although the Commission applies public law principles, it is not confined to the materials that were
before the Secretary of State. As the Commission explained at para 31 of its judgment in U3:

“Even though it applies a public law standard of review to the national security assessment, SIAC is not simply the
alter ego of the Administrative Court. Its constitution gives it special expertise both in immigration law and,
pertinently here, in the assessment of intelligence. Its procedures allow for a detailed consideration of evidence,
OPEN and CLOSED, including exculpatory evidence. It can and very often does hear oral evidence from a Security
Service witness about the national security assessment … In this respect, the tools available to SIAC [Sc. the “more
powerful microscope”] go beyond those which would be available in the Administrative Court, even in a case where
closed material procedures apply.”

43. Seventhly, the fifth proposition set out above should be refined to this extent. During the course of the appellate
process, which involves the supply of evidence from an appellant and the carrying out of an exculpatory review,
material may come to light which warrants further consideration by those advising the Secretary of State. As the
Commission explained in U3, it is incumbent on the Secretary of State (the Commission uses this term in this
particular context to identify the department as a whole, and those advising it) to keep the decision under review.
We accept the Secretary of State's qualification that this does not entail the re-making of the national security
assessment on a rolling basis, including whether the appellant constitutes the same risk to national security as she
did when the decision was originally made. Rather, the correct analysis is that, in the event that exculpatory
material should demonstrate that a particular piece of evidence or intelligence may now bear a different
interpretation, the Secretary of State must consider whether the original decision can still be supported. It will be a
matter of judgment for those advising him whether the case should be returned to the Secretary of State personally
for further consideration.

44. Eighthly, the Commission's role is limited to allowing or dismissing an appeal. The response of the Secretary of
State to a decision allowing an appeal would be for him to decide in the light of all relevant factors. If the
Commission were to decide that the national security assessment was Wednesbury unreasonable, the Secretary of
State could not properly make the same assessment unless further evidence and/or intelligence has come to light.
Upon a reconsideration following a successful appeal, the Secretary of State would of course be looking at the
matter as at the current date, not as at the date on which the original decision was made.

45. Ms Begum's skeleton argument was filed before the Commission handed down its judgment in B4. In those
circumstances, Mr Dan Squires KC and his team were afforded the opportunity to advance contrary argument. In
the light of the submissions that were filed and elaborated orally, the submissions that were advanced in Ms
Begum's original skeleton argument, the Special Advocates' submissions and the Secretary of State's submissions,
the following matters of clarification and elaboration may be given.

46. First, the parties are not agreed as to whether “anxious scrutiny” is required in a case such as this although the
stances they adopted in writing were scarcely touched on in oral argument. Here, it is necessary to define one's


-----

terms. “Anxious scrutiny” may be relevant to what may be described as pure Wednesbury issues (see, R v SSHD,
ex parte Bugdaycay [1987] AC 514), or it may have a role in assigning particular weight to fundamental rights in a
proportionality assessment. At this stage, the Commission will address only the first question (proportionality is
dealt with below, at §62ff).

47. There are conceptual difficulties with the notion that a test as apparently binary as Wednesbury could contain
within it an inherent flexibility. However, in Pham v SSHD _[2015] UKSC 19; [2015] 1 WLR 1591, which was a_
deprivation of nationality case, Lord Reed JSC stated:

“There are also authorities which make it clear that reasonableness review, like proportionality, involves questions
of weight and balance, with the intensity of the scrutiny and the weight to be given to any primary decision-maker's
view depending on the context. The variable intensity of reasonableness review has been made particularly clear in
authorities, such as … Bugdaycay [other well-known cases are cited]

…, concerned with the exercise of discretion in contexts where fundamental rights are at stake.” (at para 114)

48. In the light of Pham we consider that the Secretary of State's written submission that the “anxious scrutiny”
principle has no application is incorrect. It was not mentioned by Lord Reed PSC in Begum, but the issue in that
case was whether SIAC stands in the shoes of the Secretary of State when exercising its appellate function.
Furthermore, the notion that this Commission should not be examining a case as important as this, involving
fundamental rights, without exercising the utmost care and attention to detail seems unrealistic. That is both a
natural judicial instinct and consistent with principle.

49. The Commission in U3 did not rule on whether the “anxious scrutiny” principle applied. Instead, it preferred to
address the issue in terms of what it called “SIAC's more powerful microscope”. This is an apposite metaphorical
tool because the Commission, unlike the judicial review court, hears oral evidence and witnesses cross-examined,
and it also examines far more material. Irrespective of any inherent flexibility in the concept of irrationality, the
powerful microscope achieves the same practical result as anxious scrutiny, whether in Lord Reed's meaning (the
Wednesbury test is flexible) or any alternative meaning (a decision is either irrational or it is not).

50. Secondly, Ms Begum takes issue with the terminology, “a sub-set of Wednesbury” (see §39 above). That
should not be misunderstood. The concept of relevant considerations appears in the judgment of Lord Greene MR
in the Wednesbury case itself, and the language of the third proposition in B4 was simply in recognition of that. For
obvious reasons, the Commission as presently constituted was in no way intending to depart from the Divisional
Court's analysis in DSD v Parole Board _[2018] EWHC 694 (Admin); [2019] QB 285at paras 134-141, the last_
paragraph in particular. See also paras 116121 of the judgment of Lord Hodge and Lord Sales in R (Friends of the
Earth Ltd) v Secretary of State for Transport [2020] UKSC 52; [2021] PTSR 190.

51. Ms Begum does not submit that the lexicon of section 40(2) identifies the considerations that it is mandatory to
take into account. Rather, she relies on the second category of considerations that are so obviously material that
no reasonable decision-maker could fail to have regard to them. In this latter category, it is for the decision-maker
and not for the court to decide which considerations are relevant. The court, and here the Commission, exercises a
secondary judgment on the basis that the decision-maker would be acting unlawfully if he failed to take account of
considerations that were obviously material to the question at issue.

52. Thirdly, the Special Advocates in particular have been troubled by what they believe to be the conundrum or
paradox created by the idea that, putting to one side human rights considerations for one moment, the appeal under
section 2B is governed in the main by administrative law principles. The Special Advocates' concern is that, on the
one hand, the decision under challenge is that of the Secretary of State and its lawfulness must therefore be judged
at the time it was made, and on the other hand the Commission has always accepted written and oral evidence
which was not before the decision-maker at the material time. That antinomy will, we hope, be resolved finally by
the Court of Appeal's judgment in the appeal of U38, although that will come too late to justify holding back the
Commission's judgment in the present case.


-----

53. Fourthly, this appeal is against the Secretary of State's decision made on 19th February 2019: see the use of
the present tense in section 40 itself, and the common ground in

Begum in the Supreme Court (at para 129). One of the Special Advocates' submissions was that the terms of the
updated assessment indicated that the function being exercised then was that under section 40(2) of the 1981 Act,
and the use of the present tense in that sub-section might lead to the conclusion that the lawfulness must be judged
at the date of the updated assessment. We do not think that can be right.

54. Fifthly, if post-decision evidence, to the extent that it bears on the position on and before 19th February 2019,
were inadmissible, Ms Begum's appeal right would be a misnomer. Her case would, perforce, collapse into a review
and she would be placed at an obvious disadvantage. But that is not what the statute says, and it is not what the
Court of Appeal decided in P3. It would also mean that the SIAC Procedure Rules, which permit the adducing of
evidence by an Appellant and the Secretary of State and require the performance of an exculpatory review, would
be ultra vires.

55. Rules 10 and 10A enable the Secretary of State to file both evidence and further evidence without limitation
and qualification. The Rules therefore contemplate that the Secretary of State may, if so advised, file additional
inculpatory evidence that was either not before him or not considered at the time the decision was made. The
Commission therefore rejects the Special Advocates' submission in CLOSED (the context in which that submission
was made will have to remain in CLOSED) that the Secretary of State is confined to adducing evidence that is
exculpatory and/or is derived from the exculpatory review, or subsequent evidence which arises directly out of the
Appellant's evidence. That submission is based on the fallacy that post-decision evidence is, generally speaking,
inadmissible and that the exceptions are limited to the exculpatory. It is true that post-decision evidence is, as a
general rule, inadmissible in judicial review proceedings, but that it is not the true nature of a section 2B appeal.

56. Sixthly, unless those advising the Secretary of State change their mind, or identify something new and
important in an Appellant's favour that in their estimation should be put before him for further decision, the evidence
and any assessments filed under the rules is not in the nature of being a fresh decision. The original decision
remains in place although in a pragmatic albeit legally inexact sense it could be said that it has been affirmed. Fresh
decisions under section 40(2) in the strict sense of that term cannot be taken by officials; they may only be taken by
the Secretary of State personally. But this affirmatory process is desirable in section 2B appeals not least because
the default position must be that this is a “one-stop” process; and the Commission, mindful always of where
constitutional and institutional competence reposes, should as far as possible receive the benefit of expert
evaluation and assessment of any further material. This obviates the need for cases having to go back to the
Secretary of State for reconsideration if any public law error in the original decision be identified.

57. The corollary of the foregoing is that in practice, as U3 pointed out, this will often mean that the identification of
a relevant public law error in subsequent statements and assessments may be sufficient for an appellant's
purposes. Typically, albeit not necessarily, it will be a case of earlier errors simply being carried through into later
assessments. In situations which do not fall into that paradigm, it will not always be the case that the identification of
a public law error in subsequent statements will lead to the allowing of an appeal. For example, a submission that a
ministerial briefing or advice note was not fair and balanced may not go very far if it were not in fact placed before
the Secretary of State. Whether it goes far enough will depend on the facts of the individual case.

Human Rights

58. It is clear that human rights grounds may be taken on an appeal to the Commission under section 2B: see
Begum, para 64. This, as Ms Begum rightly submits, is because the Commission is a public body which must act
compatibly with an appellant's Convention rights: see section 6 of the HRA.

59. Begum is also authority for the proposition that in a human rights context the

Commission must determine the issue of compatibility “objectively on its own assessment” (see para 69). In the
case of a qualified right (sc. Article 8 and c.f. Article 4), where one key issue is proportionality, this means that the
Commission must undertake its own assessment on the same objective basis.


-----

60. However, this principle travels only a certain distance in a national security case. Unless the Commission
decides in any individual case that the national security assessment is infected by public law error, it must be taken
to be correct. Usually, the national security risk will not be quantified; it rarely can be. As the Commission observed
in U3, matters of extent and degree are likely to entail an imprecise evaluative exercise. This has important
ramifications for the proportionality assessment the Commission is dutybound to undertake in the human rights
context. If the public interest germane to Article 8.2 of the ECHR (to take the most obvious example) is incapable of
objective assessment, it is almost impossible for the Commission to displace the primary judgment of the decisionmaker as to where the relevant balance falls. Even if the Article 8.1 factors are given greater weight by the
Commission – having undertaken its own assessment - than by the Secretary of State, that does not, without more,
translate into public law error. For such an error to be made out, it would have to be demonstrated that the decisionmaker acted irrationally, failed to consider some obviously relevant factor, or fettered his discretion. Complaints
about insufficient weighting of factors rarely go far enough.

61. We think that these are the points the Commission was making in U3, at paras 42-43. It should be recalled that
in U3 Article 8 considerations arose in the context of the entrance clearance appeal. In the present case, as we will
come to explain, Article 8 has only a limited application.

Proportionality: Common Law

62. It is not disputed by the Secretary of State that he has to weigh national security considerations against the
personal factors in Ms Begum's favour. This is an implicit acceptance that the balance has to be struck in a
proportionate manner. We express the matter in those terms because in B4 and other cases, albeit not in the
present case, the Secretary of State declared in terms that he considered the deprivation decision to be
proportionate. In para 56 of Rehman, as we have seen, Lord Hoffmann used the explicit language of proportionality
in terms of the balancing of the degree of danger to national security against the interests of the individual.

63. An issue arises as to the role of the Commission in reviewing the balance that the Secretary of State has
struck.

64. The contention of the Secretary of State is that the position at common law is a fortiori that under the ECHR
because the jurisprudence does not require, or permit, the Commission to carry out its own assessment. Although it
is incumbent on the decisionmaker to identify accurately and then place in the balance what may be described as
the compassionate factors of the individual case, including the impact of deprivation on the subject, the weight to be
given to these is not for the Commission to determine.

65. Ms Begum relied on various dicta in Pham in support of a more searching approach. That was a national
security case although when it was being considered by the Supreme Court the national security assessment was
not being tested. Lord Carnwath JSC, with whose judgment three of his colleagues agreed (it was a seven-judge
panel), referencing the earlier decision of the Supreme Court in Kennedy v Charity Commission [2014] UKSC 20;

[2015] AC 455, endorsed academic commentary to the effect that the intensity of review in a proportionality case is
context-specific. He further stated:

“Those considerations apply with even greater force in my view in a case such as the present where the issue
concerns the removal of status as fundamental, in domestic, European and international law, as that of citizenship.”
(para 60)

66. Lord Mance JSC, in whose judgment three of his colleagues joined, expressly agreed with Lord Carnwath (para
98), and stated:

“Removal of British citizenship under the power provided by section 40(2) … is, on any view, a radical step,
particularly if the person has little real attachment to the country of any other nationality that he possesses and is
unlikely to be able to return there. A correspondingly strict standard of judicial review must apply to any exercise of
the power contained in section 40(2), and the tool of proportionality is one that would, in my view and for the
reasons explained in Kennedy, be both available and valuable for the purposes of such review …”


-----

67. Finally, Lord Sumption JSC (also in the majority), acknowledged that the case before him required a balance to
be struck between two countervailing and weighty considerations: Mr Pham's fundamental right to citizenship, and
the public interest in safeguarding national security. He observed (at para 108):

“The suggestion that at common law the court cannot itself assess the appropriateness of the balance drawn by the
Home Secretary between his right to British nationality and the relevant public interests engaged, is in my opinion
mistaken. In doing so, the court must of course have regard to the fact that the Home Secretary is the statutory
decisionmaker, and to the executive's special institutional competence in the area of national security …”

68. On a first reading, there appears to be a tension between the first and second sentences of the foregoing
citation from Lord Sumption. At para 81 of Begum, Lord Reed did not detect any, observing that there was no
difference between Lord Sumption's observations and the key reasoning in Begum itself at paras 66-71. We are
reassured by this. Furthermore, although the Commission's attention was not drawn to this passage by either party,
it may be reasonable to proceed on the footing that Lord Reed in Begum did not intend to qualify in any way what
he said about proportionality in Pham, at para 114:

“The rigorous approach which is required in such contexts involves elements which have their counterparts in an
assessment of proportionality, such as that an interference with a fundamental right should be justified as pursuing
an important public interest, and that there should be a searching review of the primary decision-maker's evaluation
of the evidence.”

69. In our judgment, and pace (on one reading) the first sentence of para 108 of Lord Sumption's judgment in
Pham, it is not for the Commission to judge for itself the balance in any given case between national security
against fundamental rights. The correct approach is Lord Reed's in Pham and in Begum. In this respect, the
approach to proportionality and Wednesbury is the same.

70. Nonetheless, the Commission returns to its observation that national security as the public interest factor
occupying one side of the balance remains (largely) legally inscrutable. To the extent that it can be evaluated, the
Commission defers. As we have already said, the Secretary of State is entitled to accord very considerable weight
to it. It follows that our review of how the balancing exercise has been performed must be carried out in the context
of this legal reality. But the position would be broadly speaking the same even if the Commission's function were to
perform the exercise for itself: see U3, paras 42-43.

71. This is not to say, however, that the Commission's tools are entirely blunt. The Commission must examine with
rigour and close scrutiny the Secretary of State's identification and characterisation of what goes into the balance
on Ms Begum's side and must conduct a searching review of the primary decision-maker's evaluation of the
evidence. The focus must be on any material error, particularly one that is capable of tipping the balance in her
favour.

72. For completeness, the Commission agrees with the Secretary of State that proportionality does not form a
separate head of public law challenge in a non-human rights context. Our reading of the decision of the Supreme
Court in Keyu v SSFCDA [2015] UKSC 69; [2016] AC 1355, paras 131ff, is that the law has not moved that far. That
was the point the Commission was seeking to make in B4 at para 81 (“no overarching proportionality assessment”),
in response to a wide-ranging submission made by the appellant. However, in a case such as the present this
matters very little because the Secretary of State accepts that he must undertake a balancing exercise and in our
judgment it is the Commission's role to review it closely.

Other Legal Arguments

73. These will be addressed in the context of Ms Begum's individual grounds.

MS BEGUM'S RADICALISATION AND TRAVEL TO SYRIA


-----

74. This section of the Commission's judgment is derived, in the main, from the Revised Chronology appended to
the fifth witness statement of Ms Gareth Peirce as well as the specific matters drawn to our attention in oral
argument by Ms Samantha Knights KC.

75. Until her departure to Syria in February 2015 Ms Begum was living with her mother and older sister at an
address in Tower Hamlets.

76. In September 2014 Ms Begum entered Year 11 at Bethnal Green Academy. She was predicted to attain A/A*
grades in most of her GCSE subjects.

77. In the autumn of 2014, Ms Begum's school-friend and peer, Sharmeena Begum (no relation, and referred to
hereinafter, without intended disrespect, as “Sharmeena”), was following the Tumblr blog of Aqsa Mahmood. The
latter had travelled to Syria from this country earlier in 2014 and, using the moniker “Um Laith”, was encouraging
others to follow her there. Sharmeena tweeted Aqsa Mahmoud asking her to message her directly via Twitter. Ms
Peirce points out that Sharmeena was close friends of Ms Begum and the two other girls (Amira Abase and
Khadisa Sultana) who were in due course to travel as a group to Syria in February 2015.

78. By the end of February 2015 it is in the public domain that 60 women and girls had travelled to Syria. On 6th
December 2014 it is a matter of record that another girl from the borough, known only as “B”, was planning to travel
to Syria via Istanbul but was taken off the plane at the last moment.

79. The case of B came to be considered by Hayden J sitting in the Family Division on 21st August 2015. It merits
close attention ([2015] EWHC 2491 (Fam)). The evidence before Hayden J was that B, who was a “stellar” student,
had undertaken internet research about ISIS including information about how to travel to Syria and other
propagandist material. B was also left in no doubt that ISIS was a brutal entity which had carried out, and was
planning to carry out, the most hideous atrocities. As Hayden J observed:

“4. The case comes before me consecutively with a number of other cases within the Borough of Tower Hamlets,
each of which involves intelligent young girls, highly motivated academically, each of whom has, to some and
greatly varying degrees, been either radicalised or exposed to extreme ideology …

5. … In each of these cases … young women … have been captured, seduced, by a belief that travelling to Syria to
become what is known as 'Jihadi brides' is somehow romantic and honourable both to them and their families.
There is no doubt, to my mind, that young women have been specifically targeted, in addition to young men of
course, but for different purposes. The reality is that the future for such girls as we know, holds only exploitation,
degradation and risk of death; in other words these children with whose future I have been concerned, have been
put at risk of really serious harm and as such the State is properly obligated to protect them. …”

80. On 5th December 2014, Sharmeena travelled from Gatwick airport to Istanbul. Given that it is known that she
ended up in Syria, it is reasonable to infer that she took a bus from Istanbul to the south east of Turkey and then
crossed the border. Ms Peirce has identified other evidence in support of this inference.

81. According to the Secretary of State, OPEN source reporting indicates that Sharmeena may have encouraged
Ms Begum and her friends to travel to Syria.

82. On a date between 5th and 10th December 2014 police officers visited the school and spoke to seven girls,
including Ms Begum and her two friends. The police came to the conclusion that Ms Begum was not at risk.

83. This conclusion, which may be thought to be somewhat myopic, was not shared by the school. In their opinion:

“… due to her friendship ties with the student who left the UK recently, we have identified her as being at risk
herself. The risk is that she could also be encouraged to leave her family and possibly the UK. The additional risk is
that she will go to Syria. We have therefore put the above plan in place to recognise, counter and minimise the risk.

The plan focuses on vigilant supervision of the student at all times, offering the opportunities for students to discuss
their ideas in safe forums and a scrutiny of any unexpected changes in behaviour. The police have interviewed


-----

Shmima [sic] in regard to this risk and believe that she is not at risk. At present Shamima's behaviours are in line
with our expectations. Under the guidance of the police investigation we therefore believe that she represents a low
risk.”

84. The school's assessment was contradictory in certain places and appears to have placed considerable weight
on the police assessment as to absence of risk. The inescapable conclusion must be that the school allowed the
police assessment to overrule it.

85. On 5th February 2015 police officers returned to the school. They handed a letter to Ms Begum and her friends
in the expectation that it would be provided to their parents. It never was. The letter was dated 2nd February and
sought parental consent to their child being interviewed by the police “to understand Sharmeena better and the
reasons why she has decided to leave the country”. It is not clear why the police did not send these letters to the
parents directly and did not suggest to them that this was a wider problem. The police were later to apologise for
their shortcomings.

86. On 17th February 2015 Ms Begum and her two friends gave their families untrue reasons as to why they would
be absent that day. They travelled together to Gatwick airport. Ms Begum used the passport of her sister which she
had stolen. They flew to Istanbul on Turkish airways flight TK1966 and arrived there at 18:40 local time.

87. Ms Begum's eldest sister, concerned that she had not returned home, searched her room and found the police
letter dated 2nd February. She phoned 999 and another number, but it was not until 00:35 on 18th February that a
missing persons enquiry was received by officers at Gatwick airport. At 10:30 the same morning the Metropolitan
Police held a

“Gold Meeting” at Limehouse Police Station.

88. Ms Begum and her friends left Istanbul by bus at some point during the course of the evening of 19th February.
The girls travelled overnight and arrived at a point near the Syrian border the following day. There is video footage
showing them being helped into a vehicle by Mohammed Al-Rashed, an individual whom press coverage exhibited
by the Appellant describes as working for both ISIL and the Canadian Security Intelligence Service.

89. The Commission received submissions on the basis that Al-Rashed acted as a

“facilitator” or smuggler and played no role in encouraging Ms Begum to travel. To the extent that we may deal with
these issues in OPEN, Ms Begum's case is largely based on inference and common sense. The real point here is
that only a very blinkered approach would hold that everyone in Turkey, Syria or wherever who assisted the girls at
various times before they arrived at their intended destination, could fairly and properly be described only as a
“facilitator”. In the absence of contrary evidence, the sensible inference must be that they were also encouraging.

90. Ms Knights advanced a submission that, notwithstanding that opportunities were missed to prevent Ms
Begum's leaving the country in the first place, there was a further window of opportunity between her landing in
Istanbul on 17th February and arriving at the Syrian border at some stage on 20th February.

91. It is not the Commission's function to arrive at definitive conclusions about the responsibility of certain public
bodies, whether here or overseas. We merely record that there is some evidence suggesting that the police in this
country were saying that they notified the Turkish authorities immediately after the girls arrived in Istanbul, whereas
the latter's account is that this occurred three days later.

92. We have provided only a bare outline of what happened. No more than that is necessary because the facts
really speak for themselves. It is said on Ms Begum's behalf that “there were a series of obvious questions of
individual, local and national importance” as to whether steps could and should have been taken to prevent this
tragedy occurring. The police, the school, the local authority, the Home Office and the Security Services have been
blamed in various ways. In our view, putting the matter at its very lowest, there is an arguable case of failing to take
reasonable preventative measures directed against the police, the school and the local authority. The case against
the Home Office is less clear

-----

cut; the case against the Security Services appears thin. None of that matters for the purposes of Ms Begum's
trafficking argument, as will be more fully examined below.

93. There is a limit as to what may be said in OPEN about what happened to Ms Begum in Syria. On the basis of
what is in the public domain, any fair-minded person would have to agree that Hayden J's generic predictions as to
what could well happen to those exploited in this way have been amply borne out in Ms Begum's case. She was
“married off” to an ISIL fighter shortly after her arrival in Syria and spent much of the following four years pregnant.
Her three babies have all died. She remained in ISIL territory until January 2019, at which time she was in the ninth
month of her pregnancy (her third child died in March 2019, three weeks old). Whatever the extent of her ideological
commitment before she left in February 2015, Ms Begum could not have had any inkling of how much personal
suffering she was destined to endure.

THE PRESS REPORTING

94. The story broke in The Times at or shortly after midnight on 14th February 2019 in the form of an article titled
“Shamima Begum: Bring me home”. It appears that a journalist had been given access to Ms Begum on more than
one occasion, and a video interview, of which a transcript is available, took place on 13th February.

95. Before addressing what Ms Begum actually said, the Commission must address Ms Knights' submission that
little or no weight should be given to this and later interviews. This is because Ms Begum was a victim of trafficking
and such victims must only be questioned by trained professionals; and she was in any event exhausted,
traumatised, in the final stages of her pregnancy and a detained person with rights under the Geneva Conventions.

96. The Commission is prepared to accept much of Ms Knights' argument. However, there are no exclusionary
rules of evidence that apply to these interviews, and ultimately the weight to be accorded to what she said is for
those advising the Secretary of State to assess. Even if it were appropriate to treat these interviews with a degree
of caution, our assessment of the television interviews, for which transcripts exist, is that she was asked fair and
non-leading questions by journalists in a manner which could not be characterised as oppressive.

97. We also bear in mind, as did the Secretary of State, that in later interviews Ms Begum was more critical of ISIL
and expressed regret for her actions. She later told The Times journalist that her remarks were influenced by fear of
reprisals by radical ISIS extremists at the Al-Hawl camp. SyS accepts that extremist women were present in that
camp, and that there were reports that she was moved to Al-Roj camp for her own safety. Nonetheless, and as SyS
points out: (1) Ms Begum made comments critical of ISIS in her earlier interviews, and (2) she admitted even in
later interviews that she still

supported ISIL albeit she was brainwashed. There were other inconsistencies in her accounts which SyS has
noted.

98. Ms Begum told The Times that her life in Raqqa (the ISIL capital) was mostly “normal” although from time to
time there was bombing and stuff. When she saw a severed head in a bin for the first time, Ms Begum said that this
did not faze her at all –

“It was from a captured fighter seized on the battlefield, an enemy of Islam. I thought only of what he would have
done to a Muslim woman if he had the chance.”

99. Ms Begum also claimed that she had no regrets coming to Syria.

100. Ms Begum was then interviewed by Sky News on 17th February. That was possibly the very day her third
baby was born. Ms Begum stated that she had a “good time” with ISIS and did not regret joining them. She said that
she was aware before she left of atrocities committed by ISIL including executions. She stated that it would be
really hard for her to be rehabilitated after “everything I have been through” and she was “still kind of in the
mentality of Daesh”.

101. These were statements against her interest but they displayed a considerable degree of personal insight.


-----

102. On 19th February 2019 there was an interview with a BBC journalist which was transmitted that day. Ms
Begum was asked about the Manchester arena attack and she described it as “kind of retaliation” for the women
and children being killed in Syria and Iraq. Her comment was that this was “fair justification”. She stated that she
had made the choice to leave and travel from the United Kingdom to Syria:

“Even though I was only 15 years old … I could make my own decisions back then. I do have the mentality to make
my own decisions and I did leave on my own knowing that it was a risk.”

103. The Commission understands the force of the argument that those who have been groomed, radicalised and
trafficked do not necessarily understand and/or process all of what has happened to them. However, that argument
cannot be elevated to a universal or absolute principle. On one interpretation of this interview, Ms Begum was being
disarmingly frank and was also showing self-awareness.

104. In a later interview published in the Times on 1st April 2019, Ms Begum explained that before she travelled
she met people online “who encouraged me to come as well as brainwashed me”. The Commission's observation is
that, depending on what one makes of what Ms Begum said (and by then she had been deprived of her citizenship),
this statement lends greater weight to the contention that she was the victim of radicalisation. 105. In September
and November 2021 Ms Begum was interviewed by Good Morning Britain and Sky News. She denied reports in the
media that she had sewn suicide vests or been part of ISIL's morality police and claimed that her activities were
limited to being a housewife and mother. The MI5 assessment is that many of the comments Ms Begum made in
her later interviews are likely to have been self-serving and an attempt to obtain favourable media coverage in the
run-up to this appeal.

106. There are other interview transcripts which it is not necessary to summarise in this judgment.

THE SECRETARY OF STATE'S DECISION

107. The publication of The Times article created a media storm. It is unnecessary for the Commission to refer to
any of it, not least because public opinion, whether selfgenerated or in response to media stories, is irrelevant to the
proper exercise of the judicial function conferred on us by Parliament. However, the fact that there was a media
storm has some bearing on Ms Begum's submission that this was a hasty decision made by a Secretary of State
whose mind was already made up.

108. On 14th February 2019 the Secretary of State approved an advice note dated 31st January

2019. All that we have in OPEN is a document entitled “Extract of Submission to the Home Secretary”. Sir James
described it in oral argument as a “policy”. Although only an extract is available, it clearly constitutes advice to the
Secretary of State on the treatment of minors in the context of deprivation decisions.

109. Given Sir James' no doubt deliberate use of language, we will call the 14th February document a “policy”.

110. The Secretary of State's approval of this policy post-dated the first of the articles in The Times. However,
there is no suggestion that it was amended after the story broke, and in our view nothing turns on this. The
inference must be that the policy was in its final form on 31st January.

111. According to Mr Phil Larkin (his evidence will be addressed in more detail below), the Home Office sought an
updated assessment from the Security Service on the threat to national security posed by Ms Begum. This was
received on 15th February and incorporated into a submission, with various annexes and assessments, which was
provided to the Secretary of State on 18th February.

112. Meanwhile, the Secretary of State was briefing the media. On 15th February he told The Times that he would
use all available powers to prevent Ms Begum returning to this country:

“We must remember that those who left Britain to join Daesh are full of hate for our country … My message is clear
– if you have supported terrorist organisations abroad I will not hesitate to prevent your return. If you do manage to
return you should be ready to be questioned, investigated and potentially prosecuted. … We have a range of tough


-----

measures to stop people who pose a serious threat from returning to the UK, including depriving them of their
British citizenship or excluding them from the UK.”

113. On 17th February 2019 The Sunday Times published an article by the Home Secretary under the headline, “If
you run away to join Isis, like Shamima Begum, I will use all my power to stop you coming back”. The article itself is
more measured. The Secretary of State explained that deprivation powers are used “very carefully” and “we look at
the facts of each case, the law and the threat to national security”.

114. The Home Office submission was provided to the Secretary of State at 17:00 on Monday 18th February 2019.
At 07:00 on 19th February an email was received from the Secretary of State's Private Office indicating that he
agreed with the recommendation to deprive Ms Begum of her British citizenship. Disclosure has been made in
OPEN by way of gist of the Secretary of State's brief comments on the case.

115. The letter sent to Ms Begum's family that day (presumably for their and her attention) stated that the reason
for the decision was:

“… you are a British/Bangladeshi dual national who it is assessed has previously travelled to Syria and aligned with
ISIL. It is assessed that your return to the UK would present a risk to the national security of the

United Kingdom.”

116. Whether the Commission accepts the contention that the Secretary of State predetermined the issue will be
addressed below. In the Commission's judgment nothing turns on the point, to the extent to which it was ever
elevated into a submission by Ms Begum, that the decision was taken overnight on 18th/19th February. We do not
know whether the Secretary of State read all the papers and/or how much time he took to do so. That is irrelevant:
there is clear evidence that he took the decision personally, and the reasons for it are now deemed to lie in the
Ministerial Submission and the documentation provided with it.

117. Whether this was an overly hasty or rushed decision-making process is of marginal relevance to its quality.
One possible inference is that the Secretary of State put pressure on his officials to get on with it, and that had there
been no media storm more time would have been taken. That, however, is little more than a jury point. A deeply
considered decision may be incorrect in law; a hasty decision may turn out to be entirely correct. The observation
that the greater the time taken the more likely it is that mistakes will not be made cannot really avail Ms Begum in
these circumstances because in the end it is the merits of the decision that must be scrutinised, and on their own
terms.

THE SECRETARY OF STATE'S DECISION

The Material before the Secretary of State on 18th/19th February 2019

118. The hideous brutality of ISIL is firmly in the public domain. Media coverage of ISIL, its intentions and extremist
activities, has been extensive and long-running. It is reasonable to infer that anyone who manifested any interest in
its ideology, its aims, purposes and activities, would, through basic internet research, be well-aware of much if not
all of this.

119. The generic risk to the national security of the United Kingdom posed by those who are assessed to have
travelled to Syria to align with ISIL has been clearly explained in a number of ISIL Statements, one of which was
part of the material placed before the Secretary of State on 18th February. The risks to the United Kingdom,
particularly if individuals were to return, are likely to manifest themselves in a number of ways, with ISIL-directed
attack planning at the extreme end of the spectrum to “posing a latent threat to UK national security” at the lower
end. The various ISIL statements explain these various risks in some detail. Those who meet these basic criteria
are likely to have been radicalised and desensitised in theatre. The risk is significantly greater for those who have
spent prolonged periods in theatre, which became the pattern after about April 2015.

120. As the ISIL Statement of April 2017 points out:


-----

“We assess that there could be little doubt or confusion as to the ideological extremism of ISIL amongst those who
live under its control or those who have endeavoured to travel to join the group of their own volition. We therefore
assess that anyone who has travelled voluntarily to ISIL-controlled territory to align with ISIL since the declaration of
the caliphate in June 2014, …, is aware of the ideology and aims of ISIL and the attacks and atrocities it has
carried out.”

121. At that point, the United Kingdom was assessed to be a prime ISIL target. The reasons for that are obvious.

122. The ISIL Statement also addressed the risk posed by women (although there is a separate document that
addressed this specifically):

“Women who travel to join the group will not be routinely trained as fighters … the primary role for most women will
typically be as wives of fighters and mothers of their children, raising the next generation of fighters and “citizens” in
the caliphate.”

Ms Begum fulfilled this role. If she could have had little doubt or confusion as to the ideological extremism of ISIL
generally (which the Commission accepts), it is also reasonable to infer that she would have known what she would
be required to do once in Syria.

123. The ISIL Statement further addressed the position of children:

“Open source reporting indicates that children in ISIL-controlled territory are subjected to ideological indoctrination
programmes aimed at instilling and reinforcing the group's extremist message. Furthermore, we assess that all
individuals are exposed to routine acts of extreme violence in ISIL-controlled territory. … We assess that this is
likely to have the effect of desensitising individuals to acts of brutality, and encourage them to view violent terrorist
activity in the UK or against UK interests as an acceptable and legitimate course of action. To that extent, we
assess that even individuals who have travelled to ISIL-controlled territory involuntarily (for example, minors, taken
by their parents) are likely to have been radicalised during their time in theatre, due to their daily exposure to ISIL
indoctrination and extreme violence.”

124. And by way of conclusion:

“Most of the individuals who may seek to return to the UK will have spent a considerable amount of time in theatre,
in some cases up to four years … We assess that, while these individuals would continue to present a threat to the
UK from ISIL-controlled territory, or from a third country should they leave theatre in the future, the threat would
increase significantly if they return to the UK.”

125. The April 2017 ISIL Statement was updated twice, on the second occasion in June 2019. Although the
caliphate had collapsed by then, the risk from returnees had not varied.

126. Sir James drew the Commission's attention to other evidence bearing on the issue of risk and its apparent
saliency to Ms Begum's case. The Commission bears this material in mind in the context of the generic risk
assessment.

127. The OPEN bundles do not contain all the information that was placed before the Secretary of State. The
Commission has been given the full picture in CLOSED.

128. In the Ministerial Submission the Secretary of State was informed as follows:

“The Security Service considers that any individual assessed to have travelled to Syria and to have aligned with
ISIL poses a threat to national security. The basis for this assessment is set out [in the ISIL Statements]. The
Security Service assesses that BEGUM travelled to Syria and aligned with ISIL, and has provided its assessment
and national security case as included in the relevant annexes. SCU note that BEGUM travelled to Syria as a minor
without informing her family [in Annex A, it is further pointed out that she used her sister's passport, suggesting that
she had taken steps to plan her travel]. However, BEGUM is assessed to have been in ISIL-controlled territory
including after she turned 18 in August 2017. SCU therefore considers that the fact BEGUM travelled to Syria and


-----

aligned with ISIL as a minor does not alter the Security Service assessment of the risk she now poses to the UK.
Recent media reporting indicates that she has also not sought to distance herself from ISIL and seeks to leave
Syria as ISIL is losing its last remnants of territory there. … SCU have reflected on the interview given to The Times
newspaper on 14 February 2019, and do not assess that the content undermines the Security Service assessment
that BEGUM is aligned with ISIL and that she therefore poses a threat to UK national security.” [emphasis added]

129. The passage we have highlighted might have been better expressed. The meaning sought to be conveyed is
that the only reason Ms Begum now wishes to return to the United Kingdom is that the caliphate has fallen. Had it
survived, she would have remained with it. That interpretation is consistent with what Ms Begum said to a journalist:
that she effectively gave herself up because she was concerned for the safety of her unborn child.

130. As has already been noted, on 14th February 2019 the Secretary of State approved the advice note or policy
dated 31st January. This provided as follows:

“Note our starting position that we consider minors, assessed to have been radicalised, as vulnerable victims.

4. We accept that individuals who have been radicalised as minors and travelled to Syria or Iraq, or who, whilst a
minor, have been taken to Syria or Iraq by their family, are first and foremost victims. It is possible that some of
these individuals may be self-motivated but that may be difficult to establish and so our presumption is that in most
if not all cases, the individual will have been manipulated or radicalised at some stage – either at home in the UK, or
during their time in Iraq/Syria. Our general view is that it is reasonable to consider that, as a minor, such an
individual would be more at risk of radicalisation, and less able to resist such manipulation, than an adult. For this
reason we consider that individuals who have been radicalised as minors should be considered as vulnerable
victims.

19. Where a minor has now reached the age of majority but there is a national security case against them to justify
deprivation and that is based on their actions as a minor, we will recommend deprivation … Whilst such individuals
may once again be considered as a victim, perhaps having been radicalised or compelled to travel to Syria/Iraq as
a minor, this does not alter the assessment that will have been carried out as the threat they now pose to the UK. In
preparing advice in such cases, we would continue to explore carefully any information to suggest an individual who
had not travelled to theatre as a minor of their own volition and had not been involved in further activity of concern,
is now as an adult seeking to distance themselves or escape from an ISIL/AQ group. As with other cases, where
such information exists, it will be included in the advice put before you, as this could provide a basis for holding
back from deprivation action.”

131. It may be inferred from the numbering that this document is incomplete. Further, para 19 is described, at least
in part, as a gist.

Subsequent Material

132. Ms Begum's case was never returned to the Secretary of State for reconsideration after February 2019.
However, and for the reasons that we have already given, subsequent material is admissible evidence which must
be taken into account.

133. The First National Security Statement is dated 25th March 2022, although the version we have available
appears to be the amended one dated 27th May 2022. The Commission assumes that the amendments have been
highlighted by underlining.

134. The following additional matters emerge from this Statement:

(1) The issue of deprivation in Ms Begum's case was considered at various times before February 2019 but it was
put on hold pending the resolution of certain policy matters.

(2) Sharmeena may have encouraged and assisted Ms Begum and her friends to leave.


-----

(3) It was assessed that Ms Begum's travel was voluntary and “that her activities prior to and during travel to Syria

[including the use of the sister's passport] demonstrated determination and commitment to aligning with ISIL.”

(4) Police reporting indicated that Sultana wanted to return home as her mindset was not the same as Amira's and
Ms Begum's. If accurate, this indicated that Ms Begum remained supportive of ISIL following her arrival in ISIL
territory.

(5) What Riedijk, Ms Begum's husband, said at interview about his wife sitting at home for three years amounted to
a deliberate obfuscation of the extent of her alignment with ISIL, in order to protect her.

(6) Even if Ms Begum's activities were limited to her being a housewife, she would still pose a risk to national
security.

(7) The recommendation to deprive was not dependent on any risk band but was based on the intelligence picture
as a whole.

(8) The Secretary of State was given information in the ISIL Statement about the numbers of those known to have
travelled to theatre from the UK. The majority of those who had already returned from theatre as at November 2016
were assessed to be of lower risk. However, this was in direct comparison with those who remained in ISILcontrolled territory for longer periods, which is what came to be the pattern.

135. The Commission would wish to place particular emphasis on the following passages in the Amended First
National Security Statement, at paras 36-37:

“We assess that multiple factors are likely to have contributed to BEGUM's decision to travel but, as outlined above
we assess that BEGUM's activities prior to and during her travel to Syria demonstrated determination and
commitment to aligning with ISIL. As set out above, we assess that BEGUM was aware of the atrocities committed
by ISIL and their ideology prior to travel and her decision to align with ISIL and was therefore indicative of her
extremist mindset.

Considering all the information that is now available, we have not altered our assessment that BEGUM posed a risk
to UK national security at the time she was deprived of her British nationality. We maintain our assessment that
BEGUM travelled to Syria and aligned with ISIL.”

136. As for the Amended Second National Security Statement dated 17th October 2022 (the original version is
dated 22nd August), some of which is a commentary on Ms Begum's evidence, the following matters may be
highlighted:

(1) Ms Begum must have known about the atrocities committed by ISIL and ISIL's ideology before she travelled.
These included the horrific beheadings and the attack on a Kosher supermarket in Paris in January 2015.

(2) Ms Begum told the Sky News journalist on 17th February 2019 that she had seen “all the videos on the internet
and that just kind of attracted me”. The Commission understands that to mean a range of videos showing ISILinspired atrocities. Ms Begum will not have known whether she had seen all of them.

(3) By “alignment”, the Security Service means: “the adoption and/or mental positioning alongside ISIL (or AQ)
ideology, which may be coupled with a physical joining or colocation with the relevant group.” (This formulation has
been considered in more detail in B4.)

(4) The Security Service is aware of adults having left ISIL between 2015 and 2018, and one example is given.

137. The Amended Second National Security Statement takes issue with aspects of the evidence of Messrs Jordan
and Barrett, who have filed a report in support of Ms Begum's appeal. For example, it is said that it is not right to
assert that female involvement in violence was confined to the last days of the caliphate. It is also said that Messrs
Jordan and Barrett have furnished no evidence to support the proposition that Ms Begum's risk could be


-----

appropriately managed in the United Kingdom. On what appears to the Commission to be the core issue in this
appeal, the following matters are stated:

“At para 49 of their report, Barrett and Jordan indicate that BEGUM was radicalised 'predominantly through
messaging and viewing propaganda videos online' and also some form of personal contact. If their assertion is
correct, there appears nothing unusual about the cause(s) of BEGUM's radicalisation compared with others who
have travelled to Syria to join ISIL. However, Barrett and Jordan fail to recognise that BEGUM's radicalisation would
have continued during the four years that she spent in ISIL territory. The cause(s) of BEGUM's radicalisation prior
to her travel to Syria in 2015 would be of limited relevance to the risk that she posed to national security when
deprived as an adult in 2019. At the point of deprivation, BEGUM had been aligned with ISIL and had lived in ISIL
territory for four years; it is her activities and experiences during these four years that are of critical importance
when assessing her national security risk.

It is unclear why Barrett and Jordan consider that the cause(s) of BEGUM's radicalisation was/were important to
any assessment of risk. They suggest in their report that it could be relevant to 'the genuineness of deradicalization,
whether abroad or on return'. It is assumed that Barrett and Jordan consider the cause(s) of radicalisation to be
relevant to BEGUM's capacity for de-radicalisation. While it is possible that BEGUM may have been susceptible to
de-radicalisation, this is inherently uncertain (particularly given the four years BEGUM spent aligned with ISIL). We
remain of the view that deprivation was the most effective risk mitigation.”

138. The Amended Second National Security Assessment concludes by saying that account has been taken of all
Ms Begum's evidence, and all the material in the bundles before us. The assessment that Ms Begum was aligned
with ISIL and posed a threat to national security when she was deprived in February 2019 is maintained.

MR LARKIN'S EVIDENCE

139. Phil Larkin is the deputy head of the Special Cases Unit (“SCU”), Homeland Security Group within the Home
Office. He has provided three witness statements and he gave oral evidence.

140. Mr Larkin's amended first witness statement dated 27th May 2022 adds little to what we have already
covered, although it provides assistance on the public sector equality duty. The Commission will bear that evidence
in mind when Ground 7 is under specific consideration.

141. Mr Larkin's conclusion was as follows:

“The [Ministerial Submission] provided Ms Begum's date of birth, that she travelled as a minor and made reference
to the fact that Ms Begum was 15 years' old when she travelled to Syria. It also explained that it was not suggested
that Ms Begum's travel to Syria was against her will or not of her own volition. As outlined above the voluntary
nature of Ms Begum's travel to Syria therefore was a matter that was specifically considered by the Home Secretary
when he was deciding whether to deprive Ms Begum of her British nationality. Similarly, the submission set out
how individuals such as Ms Begum who had been radicalised as minors may be considered victims, but this did not
alter the threat the Security Service assessed she posed to national security.”

142. Mr Larkin's amended second witness statement dated 14th October 2022 addressed the issue of trafficking in
these terms:

“… the evidence submitted on behalf of Ms Begum demonstrates that both the police and Ms Begum's school,
having considered her circumstances, concluded there was a low risk she might travel to Syria to align with ISIL
(see exhibit GP1). Consequently, no referral suggesting such a risk existed was made to the Home Office prior to
Ms Begum's departure from the UK. In the absence of any such referral, the Home Secretary was unaware of Ms
Begum's case at the time of her departure from the UK and was not in a position to take any safeguarding action.
Further, Ms Begum had left the UK several years previously and was resident in Syria at the point the Home
Secretary was considering deprivation. These points explain why the submission that was provided to the Home
Secretary detailing Ms Begum's case did not include a reference to trafficking.”


-----

143. It also explains why the Secretary of State denied in the Scott Schedule that trafficking was a relevant
consideration in this case.

144. Mr Larkin gave oral evidence before the Commission and was cross-examined. On the premise that this case
may be considered elsewhere, the Commission ordered a transcript of his evidence. The parties did not ask the
Commission to delay handing down this judgment pending the preparation of the transcript. Logistical reasons
mean that it takes time for such transcripts to be prepared, and the Commission took a good note.

145. Save in relation to the timing of the Secretary of State's decision and one aspect of his CLOSED evidence, Mr
Larkin was a satisfactory witness who gave reasonably forthcoming answers to the skilful questioning he faced. As
often happens in this sort of situation, Mr Larkin appeared to be keen to understand and anticipate the potential
ramifications of the question before giving a full answer.

146. Mr Larkin agreed with counsel that personal circumstances and individual impact are factors to be considered
in conducting the balancing exercise that must always be performed in a deprivation case.

147. Mr Larkin did not accept that what he called a formal trafficking assessment was required. Instead, the
obligation was to consider the circumstances and the backdrop as part of the overall balancing exercise. Mr Larkin
agreed that the case was not put up to the Secretary of State on the basis that Ms Begum may have been
trafficked; that terminology was never used (the Commission's short-hand paraphrase of his evidence). Likewise,
the Secretary of State was not advised of the legal consequences of any trafficking determination.

148. Mr Larkin was asked by Upper Tribunal Judge Canavan to explain what was meant by the term, “victim”. His
answer was that Ms Begum, and those in like case to her, were “victims of manipulation by others. As well as
victims of a terrible set of circumstances that has resulted in travelling to a war-zone in Syria”.

149. Mr Larkin was asked whether, in the context of the formal definition of trafficking (as to which, see below), Ms
Begum was the victim of sexual exploitation. Mr Larkin could not say.

150. Mr Larkin's evidence was that it was for the Secretary of State to decide whether personal circumstances
outweighed the risk to national security in the context of the balancing exercise that is conducted. He surmised that
the Secretary of State would have been broadly aware through media reporting of the circumstances surrounding
her departure from this jurisdiction. (The Commission observes that it is highly unlikely that the Secretary of State
could have forgotten the videos of her movements in Turkey, in February 2019.)

151. Mr Larkin was asked a series of questions about the policy document dated 31st January 2019. It was put to
him that the policy conflated two issues – the first being the national security risk (solely for SyS); the second being
the overall evaluative exercise that was for the Secretary of State. Mr Larkin's answer was that, in a case where
para 19 of the policy applied, because the subject was no longer a minor, the recommendation to deprive will
always be made unless she falls within one of the stated exceptions. Mr Larkin also accepted in cross-examination
that the para 19 exceptions had nothing to do with the classification of victims as vulnerable. In any case, he said
that it was for the Secretary of State to make up his own mind.

152. Mr Larkin was asked some searching questions about the timing and speed of the decision-making in this
case. He said that it was certainly true that there was no immediate prospect of Ms Begum returning to the United
Kingdom. He said that the Secretary of State was concerned about national security and was desirous of taking
decisions to protect national security. Mr Larkin could not satisfactorily explain the six months' delay in the similar
cases of C3, C4 and D4.

153. The plain and obvious reality of the matter, which Mr Larkin failed to accept, was that his department was
under pressure from the Secretary of State to make a decision in Ms

Begum's case as soon as possible. There are, however, certain other matters germane to this question which may
only be addressed in CLOSED.


-----

154. At the conclusion of his evidence, the Chairman asked Mr Larkin whether children who fell within para 4 of the
policy document could be regarded as acting of their own volition. After a modicum of equivocation, Mr Larkin said
no.

155. At the time, this appeared to the Commission to be an important concession. However, its value must not be
overstated. The question as phrased had the tendency to suggest that the required answer was binary: either yes
or no. Putting philosophical questions about free will to one side and approaching this issue in a more intuitive and
commonsense manner, the reality is that even apparently bright and academically gifted 15 year olds have less
personal responsibility than adults but they are not devoid of responsibility altogether. They cannot lawfully consent
to sex, still less to marriage, but they are capable of committing criminal offences. A criminal court will take their
(lower) personal culpability into account when determining the appropriate sentence . This is an important issue to
which the Commission will need to return.

WITNESS E'S EVIDENCE

156. The Commission also heard oral evidence from Witness E.

157. His witness statements are not particularly revealing, and the evidence he gave will be more fully addressed
in CLOSED. What the Commission is able to say is that Witness E was an appropriate witness in the sense that he
could talk with authority on issues germane to the national security case, and that he was also an impressive
witness. His knowledge of the material was formidable and he also holds quite strong opinions. We take all these
factors on board when assessing his evidence, accepting always the constraints of Begum in the Supreme Court.

158. Witness E emphasised that the principal role of the Security Service was to assess whether someone is a
threat. He said that victims can be a national security risk. He said that it was not the function of the Security
Service to advise the Secretary of State whether deprivation would be appropriate “in the round”, although he said
that it was a critical part of the assessment that Ms Begum had travelled voluntarily to Syria.

159. Witness E bridled at the characterisation of ISIL as an “apocalyptic Islamic cult”. He accepted, and no doubt
also averred, that it was a brutal terrorist organisation. He did not dispute that some women may have been the
subject of terrorist brutality at ISIL's hands – in context, he was accepting that this applied to some women in ISILcontrolled

territory. He accepted, and again no doubt also averred, that ISIL's state-building project sought to attract recruits
from Western countries.

160. Witness E was cross-examined on the Home Office's CONTEST report on the United Kingdom's strategy for
Countering Terrorism, dated June 2018. He accepted that it was a fair summary to say that ISIL:

“… cynically groom the vulnerable and the young to join their movement, inspiring people within their own
communities to commit senseless acts of violence.”

161. Witness E also accepted, albeit not immediately, that one of ISIL's purposes was the offering of children to
marry adult men. Witness E preferred the word “radicalise” to “groom” and, contrary to the note of his evidence
provided by Ms Begum's legal team to the Commission, he did not embrace the use of the term, “trafficking”.
Whether this labelling matters raises a separate question.

162. Later in his cross-examination, Witness E agreed with the notion that the issue of trafficking entailed a
complex assessment requiring skill and expertise. He was also confident, as he put it, that a victim of trafficking
may wish to remain with their traffickers for complex reasons.

163. Witness E was asked further questions on the topic of voluntariness. He said that it was inconceivable that Ms
Begum, with her predicted A and A* grades, would not have known what ISIL were doing as a terrorist organisation
at the time. He listed some of the horrendous acts ISIL either carried out or inspired. Overall, the Commission
cannot and does not take issue with that evaluation. But raising issues of greater complexity, and potential
concomitant concern to the Commission was Witness E's asseveration that Ms Begum “had agency in doing so”


-----

164. Witness E was asked about the media interviews carried out between 13th and 19th February 2019. He
accepted what was being put to him about Ms Begum's pregnancy and the likely timing of the birth; more
importantly, he also accepted that at Al-Hawl there were extremist women who posed a threat to others who spoke
out against ISIL. Witness E supported the Secretary of State's reliance on this material as being reliable with
reference to a footnote which opined that it was “broadly consistent with what is known by MI5”. In the
Commission's estimation, that takes an overly narrow approach and to some extent is question-begging. Even so,
the Commission accepts the Secretary of State's overarching contention that these press interviews are admissible
and are capable of being regarded as compelling.

THE EVIDENCE RELIED ON BY MS BEGUM

165. It is unnecessary to refer to all of the impressive corpus of evidence that Ms Begum's legal team has been
able to obtain. The Secretary of State did not ask to cross-examine any of Ms Begum's witnesses. As will be made
clear at the appropriate stage, the Commission accepts that there is a “credible suspicion” that Ms Begum was
trafficked. The Commission has examined the entirety of this evidence but for the purposes of this judgment will
highlight the following.

166. Dr Michael Korzinski is a trauma and psycho-social expert with particular knowledge of and expertise in
victims of trafficking. In his report dated 4th July 2022, he points out that the adolescent brain continues to undergo
neurological development and that someone in Ms Begum's position was especially vulnerable. In the specific
context of “the current epidemic” of trafficking into the commercial sex trade, relevant factors include “the process of
identity formation, yearning for love and attention, susceptibility to peer pressure, cognitive and neurological
changes.”

167. Dr Korzinski speaks at the level of some generality, not least because for obvious reasons he has not
clinically examined Ms Begum. He accepts that anyone conducting an assessment of her, including an assessment
of the reliability of her press statements, would need a great deal of information about her family background and
history, and her interpersonal relationships. He does not say that Ms Begum was trafficked; rather, that “there were
indicators of her having been trafficked present”. That betokens an appropriately cautious and measured approach.

168. The Commission has already touched on the Joint report dated 5th July 2022 of Richard Barrett CMG OBE
and Paul Jordan which has been addressed in the Amended Second National Security Statement. Although their
opinions are reasonably compelling on their own terms, the difficulty that arises is that much of what they say
travels onto the terrain of national security assessment that is pre-eminently for those advising the Secretary of
State. However, para 40 of their report is not without interest:

“Importantly, there were many push factors as well as pull factors. A feeling of estrangement and discomfort in their
home community often led impressionable young people to contrast their current circumstances with those
promised in the caliphate. Marriage, authority, independence and a supportive community governed by religious
principles were attractive options for someone growing up in an urban environment feeling stultified by cultural
norms and with limited opportunity for self-fulfilment. In other words, there were many foreigners who travelled to
join the caliphate who had no interest or – or real awareness of – the uncompromising brutality of ISIS; and, to the
extent that they were aware of it while in Syria, had little opportunity to escape, nowhere to return to and a tendency
to cling to a fading hope that everything would settle down and work out once the fighting was over.”

The Commission neither agrees nor disagrees with this. We question the authors' expertise to opine on all of these
topics. Whether an able student such as Ms Begum had “limited opportunity for self-fulfilment” must be open to
debate.

169. Dr Peter Green is an expert in, amongst other things, child safeguarding. Much of his report dated 11th July
2022 covers the same ground as Dr Korzinski, albeit from a slightly different perspective. He is as critical as is Dr
Korzinski of the Secretary of State's reliance on the press reporting. Dr Green emphasises what he calls the loss of
two possible opportunities in Ms Begum's case: the first being “the use of local authority processes to help rescue
Ms Begum during and after her flight”; the second, “consideration of the ways in which Ms Begum might
successfully be rehabilitated should she have returned to the country before the decision”


-----

170. Dr Green's overall conclusion is as follows:

“The absence of any process to see Ms Begum as a vulnerable adolescent who was entitled to safeguarding
consideration runs counter to statutory child safeguarding requirements and is in defiance of the neuroscience.
Instead, the SSHD decision was based on the false premise that Ms Begum's thoughts and actions could
reasonably be treated as if she were an adult. This approach fails to express the foreseeable impact upon Ms
Begum of her remaining childhood years of development being spent under ISIS and married to a considerably
older man. The Secretary of State's decision lacked critical information and insights that was within the knowledge
of those authorities required to act under statutory processes that are an obligation on those services involved.”

171. Mr Steve Harvey is a former police officer who, since 2013, has been engaged as an independent law
enforcement consultant in counter human trafficking and people smuggling activities. In his professional opinion,
there were missed opportunities at Gatwick airport in particular to prevent Ms Begum and her friends leaving the
country. On the broader question of trafficking, Mr Harvey identifies what he calls a number of misconceptions,
including:

“Individuals being trafficked for forced labour, especially in the early stages of the process, are often unaware that
they are being trafficked, or indeed, exposed to any kind of risk or danger. The recruiter (a trafficker) ensures
through preparation of the individual, that they feel safe and confident with the proposal or offer they have accepted.
It is my professional experience that victims of trafficking have little or no concept of what they will actually be
engaged in.

Individuals being trafficked often pay for any travel costs incurred … They may make their own travel arrangements.
The willingness or motivation to travel elsewhere may often extend to following a set of instructions or directions
from the trafficker, which may involve some measure of deceit on behalf of the trafficked person …”

172. The Commission is grateful for, but does not consider it necessary to summarise, the evidence of Professor
Huckerby and Professor Gary Younge.

173. One point that the experts did not make in terms but we feel should be made is this. In our experience, there
is little or no correlation between academic potential on the one hand and judgment, maturity and common sense
on the other.

TRAFFICKING: OVERVIEW AND KEY AUTHORITIES

174. Trafficking in human beings is an international crime and a form of modern slavery. As Mostyn J stated in R
(K and AM) v SSHD [2018] EWHC 2951 (Admin); [2019] 4 WLR 92, at para 2, it is “a repulsive, strikingly malignant
practice, as damaging in its impact on victims as was its historical predecessor”.

175. As the Court of Appeal, Criminal Division explained in R v Joseph and others [2017] EWCA Crim 36; [2017] 1
WLR 3153, the legal framework includes:

(1) the Protocol to Prevent, Suppress and Punish Trafficking in Persons, especially

Women and Children, 2000 (the “Palermo Protocol”). This was ratified by the United Kingdom on 9th February
2006.

(2) The Council of Europe Convention on Action Against Trafficking in Human Beings, 2005 (“ECAT”). This came
into force in the United Kingdom on 1st April 2009.

(3) The National Referral Mechanism (“NRM”) which came into force on the same date as ECAT in order to give
effect to it in certain respects. The Secretary of State is the responsible Minister for NRM purposes.

(4) EU Directive 2011/36/EU on preventing and combatting trafficking in human beings and protecting its victims
(“the EU Directive”). This has had direct effect in the United Kingdom since 6th April 2013.


-----

[(5) The Modern Slavery Act 2015,with effect from 31st July 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

(6) Article 4 of the ECHR.

176. Article 4 of the ECHR provides:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.”

This is one of the trilogy of absolute rights under the Convention.

177. It is well established (see, for example, Rantsev v Cyprus and Russia [2010] 51 EHRR 1, at para 282, and SM
v Croatia [2021] 72 EHRR 1, at paras 289-90) that the definition of trafficking contained in Article 4 of ECAT reads
across to Article 4 of the ECHR. Furthermore, although Sir James is quite right to point out that ECAT as an
international treaty does not create private law rights, the Secretary of State has consistently accepted that the
NRM should comply with ECAT: see R (Atamewan) v SSHD [2013] EWHC 2727; [2014] 1 WLR 1959(para 55) and
R (PK Ghana) v SSHD [2018] EWCA Civ 98; [2018] 1 WLR 3955. The ECAT definition has found its way into our
law by absorption,

but the extent to which the specific requirements of ECAT feed into and/or supplement those of Article 4 of the
ECHR is debatable.

178. Article 4 of ECAT provides:

“(a) 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the
abuse of power or a position of vulnerability or of the giving or receiving of payment or benefits to achieve the
consent of a person having control over another person, for the purpose of exploitation. Exploitation shall include, at
a minimum, the exploitation or the prostitution of others or other forms of sexual exploitation, forced labour or
services, slavery or practices similar to slavery, servitude or the removal of organs.

(b) The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in subparagraph (a)
of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used.

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation shall be
considered 'trafficking in human beings' even if this does not involve any of the means set forth in subparagraph (a)
of this article.

(d) Child shall mean any person under 18 years of age.”

179. The submission of Ms Knights on Article 4 of ECAT was advanced quite straightforwardly. If the Secretary of
State were required in the discharge of his functions under section 40 of the BNA 1981 to view Ms Begum through
the prism of trafficking, it is difficult to avoid the inference that she was recruited etc. for the purpose of sexual
exploitation. Given that she was a child, and in any case could not consent to a forced marriage as a matter of
international law, proof of any of the means set out in subparagraph (a) is not required.

180. Ms Knights built her case on trafficking in a number of stages. First, she accepted that, in order for her case to
move to the second stage of the analysis, she had to demonstrate that there was a “credible suspicion” that Ms
Begum had been a victim of trafficking. This is a criterion that appears in a number of the Strasbourg authorities,
including Rantsev at para 286, and the threshold for its fulfilment is low. The Commission has already indicated its
direction of travel on this issue, but will need to come back to it.

181. Ms Knights' second stage is to identify the duties which arise under ECHR law once a finding of credible
suspicion has been made. For the purposes of this case, she relies on “the operational duty” and “the investigative
duty”. The former, it is submitted, possesses three corollaries: the protective duty, the recovery duty and the


-----

nonpunishment duty. The investigative duty entails a State obligation, once the credible suspicion threshold has
been transcended, to undertake a full and effective investigation into the allegations of trafficking.

182. In order better to understand how and why these obligations arise, and what they precisely entail, it is
necessary to examine four authorities, two from Strasbourg and two domestic.

183. In Rantsev Ms Rantseva, who was aged 21 at the age of her death, was working as an “artiste” in a cabaret in
Cyprus. Ms Rantseva left a note saying that she wanted to return home to Russia. The manager of the cabaret
informed the authorities and, when she was seen at a discotheque, he went and apprehended her and took her to a
police station. The police consigned her to the manager, who collected her and took her to the apartment of the
male employee. The next morning, she was found dead in the street below the apartment. Her father then brought a
claim against both Russia and Cyprus under inter alia Article 4 of the ECHR. Ms Knights focused her attention on
the claim against Russia because at the time of Ms Rantseva's death she was outside the jurisdiction of that
country. She was meeting the submission that Ms Begum is out of the jurisdiction and what may have happened
here in 2015 is irrelevant.

184. The ECtHR rejected the argument that Russia was in breach of its operational duty – in particular, its
protective duty - arising under Article 4. The claim failed against Russia because there was no evidence that any of
the relevant authorities was aware of circumstances giving rise to a credible suspicion of a real and immediate risk
to the deceased before her departure to Cyprus (paragraph 305). It appears that the ECtHR decided for itself on the
evidence before it whether that relatively low threshold had been satisfied.

185. Ms Begum argues that her case is different because there is a credible suspicion not merely that she was
trafficked but also that relevant State bodies, which do not have to include the Home Office, were or ought to have
been aware – at least after December 2014 – that she was at risk. This, so the argument runs, is relevant to the
protective duty.

186. The ECtHR then proceeded to consider a possible violation of the separate procedural obligation arising
under Article 4 to investigate potential trafficking. At para 289 the ECtHR said this:

“Finally, the Court reiterates that trafficking is a problem which is often not confined to the domestic arena. When a
person is trafficked from one state to another, trafficking offences may occur in the state of origin, any state of
transit and the state of destination … [ECAT] specifically requires each Member State to establish jurisdiction over
any trafficking offence committed in its territory. Such an approach is, in the Court's view, only logical in the light of
the general obligation, outlined above, incumbent on all states under Article 4 of the Convention to investigate
alleged trafficking offences. In addition to the obligation to conduct a domestic investigation into events occurring on
their own territories, Member States are also subject to a duty in cross-border trafficking cases to co-operate
effectively with the relevant authorities of other states concerned …”

187. On the facts of Rantsev, there was a breach of Article 4 because the Russian authorities failed to carry out a
full and effective investigation covering all aspects of the trafficking allegations that had been made, including the
possibility that individual agents or networks in Russia were involved (para 307). The fact that Ms Rantseva was in
Cyprus at the time she died did not constitute a jurisdictional impediment.

188. We may deal quite shortly with Sir James' submission that at para 289 of its judgment the ECtHR referred in
terms to the investigation of criminal offences and none were committed in the United Kingdom. That takes far too
narrow an approach. First of all, it is not clear whether criminal offences were committed in the United Kingdom.
There is a credible suspicion that Ms Begum was radicalised online by individuals overseas, but even if
radicalisation by those in this jurisdiction appears unlikely, we received no assistance from counsel as to where
criminal offences would or might have been committed. Secondly, any proper investigation of the trafficking
allegations would have to include possible failures by the State to protect Ms Begum. It is quite true that these
failures could not amount to criminal offences, but there is no sensible reason why any such an investigation would
be outwith the scope of Article 4. Para 289 of Rantsev was directed to the particular facts of that case. In SM v
Croatia [2012] 72 EHRR 1, the Grand Chamber, at paras 313 and 316, held that any investigation had to be


-----

capable of leading to the establishment of the facts and, if appropriate, the punishment of those responsible. The
principal duty is to establish the facts.

189. In R (TDT (Vietnam) v SSHD [2018] EWCA Civ 1395; [2018] 1 WLR 4922, the Court of Appeal explained that
the “credible suspicion” threshold for the breach of the protective duty under Article 4 of the Convention was a low
one. If a putative victim's account that he had been trafficked was not inherently implausible, the test was met (the
Commission would add that the obligation does not require a complaint by a victim in order to be triggered). TDT
applied Rantsev and avails Ms Knights' submission to the extent that it is authority for the proposition that the
protective duty may arise in temporal terms before the case may be brought to the attention of the competent
authority (para 35). Her point was that the protective duty arose back in 2015.

190. In MS (Pakistan) v SSHD [2020] UKSC 9; [2020] 1 WLR 1373, it was said that there was a credible suspicion
that MS had been the victim of trafficking in 2011. It would follow that he remained a victim for as long as he was
being harboured by his traffickers, but by the time the Secretary of State decided to remove him that was no longer
the case, nor was there any risk that he might be re-trafficked. The NRM concluded that there were no reasonable
grounds that MS had been a victim, but on appeal to the First-tier Tribunal and then the Upper Tribunal against the
removal decision these tribunals concluded that there were. MS's appeal under section 82 of the Nationality and
Asylum

Act 2002 was on human rights grounds (viz. a violation of Article 4), and although the relevant provisions, including
sections 84 and 85, do not apply to this Commission Begum is, as we have seen, authority for the proposition that
such grounds may be raised.

191. One of the main issues in the appeal to the Supreme Court was whether and the extent to which the
obligations imposed by ECAT are incorporated into a State's positive or procedural obligations under Article 4 of the
ECHR. This was the issue we have previously described as “debatable”. Baroness Hale of Richmond, giving the
sole reasoned judgment, held that it was unnecessary to decide that question (para 27). She reviewed a number of
Strasbourg authorities and noted that there was some reliance on specific provisions of ECAT in order to “flesh out
the content” of the positive obligations arising under the Convention.

192. MS was decided on the following narrow basis:

“However, it is clear that there has not yet been an effective investigation of the breach of Article 4. The police took
no further action after passing him to the social services department. It is not the task of the NRM to investigate
possible criminal offences, although the competent authority may notify the police if it considers that offences have
been committed. … The authorities are under a positive obligation to rectify that failure. And it is clear that an
effective investigation cannot take place if MS is removed to Pakistan: the UT quite rightly held that 'it is
inconceivable that an effective police investigation and any ensuing prosecution could be conducted without the full
assistance and co-operation of MS. Realistically, this will not be feasible if he is removed to Pakistan.'” (para 35)

193. Baroness Hale was clearly contemplating an effective investigation into the circumstances of MS's case which
would not be narrowly confined to whether criminal offences had been committed. Moreover, Ms Begum may
clearly gain advantage from Baroness Hale's observation that an effective investigation could not take place without
his presence. The breach of Article 4 inhered in the fact that MS's removal from the jurisdiction would violate his
human right to an effective investigation into his case. It followed that he could not be removed, or deported,
pending the completion of that investigation.

194. In MS Pakistan the appellant did not argue that it could be sufficient for his purposes that the credible
suspicion threshold was surpassed without proof of anything else.

195. During the course of oral argument, after a lunch adjournment when the Commission had read MS with close
attention, the Chairman asked Ms Knights whether para 35 of that case represented any obstacle for her
submission. The point that was being made, albeit implicitly, was that there may be difference between a removal
case (MS Pakistan) and what in substance and reality must be put as a repatriation case (Ms Begum). Ms Knights


-----

dismissed that suggestion. Sir James did not make much of the point either, the primary focus of his argument
being that ECAT does not inform, or infuse, Article 4 of

the ECHR. As will soon be made clear, however, MS Pakistan is distinguishable from the present case, and in an
important respect.

196. The final case the Commission wishes to examine is VCL v UK [2021] 73 EHRR 9, which was concerned with
the prosecution of children who may have been the victims of trafficking. The ECtHR reaffirmed the principles
relevant to the operational and investigative duty. At para 158 of its judgment, the ECtHR identified Article 26 of
ECAT as being relevant to the issue of whether possible victims of trafficking could be prosecuted: there was no
absolute prohibition. Nevertheless:

“… the Court considers that the prosecution of victims, or potential victims, of trafficking may, in certain
circumstances, be at odds with the State's duty to take operational measures to protect them where they are aware,
or ought to be aware, of circumstances giving rise to a credible suspicion that an individual has been trafficked. In
the Court's view, the duty to take operational measures under Article 4 of the Convention has two principal aims: to
protect the victim of trafficking from further harm; and to facilitate his or her recovery. It is axiomatic that the
prosecution of victims of trafficking would be injurious to their physical, psychological and social recovery and could
potentially leave them vulnerable to being re-trafficked in the future. Not only would they have to go through the
ordeal of a criminal prosecution, but a criminal conviction could create an obstacle to their reintegration into society
… (para 159)

197. The ECtHR further concluded that potential victims of trafficking should be appropriately assessed by trained
persons (para 160) and that a decision whether to prosecute should not be taken until the trafficking assessment
has been made by a competent person (para 161). That assessment would then have to be taken into account by
the prosecutor (para 162). The CPS's failure to undertake these steps amounted to a violation of Article 4 (para
174).

198. Ms Knights relied on VCL in a number of ways. She submitted that it demonstrates that the protective
obligation is ongoing and includes recovery and rehabilitative duties. Ms Knights relied separately on SL (Vietnam)
v SSHD _[2010] EWCA Civ 225; [2010] INLR 651 in support of the proposition that the Secretary of State should_
bear in mind the need to remedy past injustice (para 42, per Jackson LJ). Ms Knights further submitted that the
protective obligation must heed the non-punishment principle which Article 4 of the ECHR has absorbed through
ECAT and other instruments. A decision on prosecution should not be made until a proper trafficking assessment
has been completed. The final building-block in Ms Knights' argument is that the deprivation power is punitive in
nature.

199. Ms Knights relied on other authorities in support of subordinate arguments on this topic.

In the Commission's view, they do not add to Ms Begum's case. Her Grounds 1 and 2 stand or fall on the
authorities that we have identified.

GROUNDS 1, 2 AND 8

200. It is convenient to take these together but, as will be made clear, they are better considered in a different
sequence. It is logical to address the direct route (violation of Article 4) before the indirect route (failure to take
account of mandatory relevant considerations). However, in setting out the parties' submissions the Commission
will respect their ordering.

201. It is also opportune that Ground 8 be considered at this juncture, as part of the mandatory relevant
considerations issue which is the subject-matter of Ground 1.

Ms Begum's Submissions

202. Many of Ms Knights' submissions have already been taken into account in the previous section of this
judgment


-----

203. Ms Knights submitted that the issue of trafficking is relevant in three important respects. It is germane to the
issue of personal responsibility, particularly in the context of a child victim whose “agency” is not fully-fledged in any
event; it is germane to the issue of the quantum of risk Ms Begum posed; and it is also relevant to whether
deprivation is in the public interest. The Secretary of State's admission that trafficking was not considered betrays a
fundamental flaw of approach.

204. Ms Knights invited the Commission to conclude that there is a credible suspicion that Ms Begum was the
victim of trafficking at all material times until January 2019, when she left ISIL-controlled territory. She also invited
the Commission to find as a fact that there was a sufficient nexus between Ms Begum's trafficking, her personal
responsibility for her actions, and the risk she poses. These are matters which were simply ignored by the Secretary
of State.

205. Ms Knights argued that the Secretary of State's policy was erroneous in law. This was because it ignored the
possibility of trafficking altogether and placed inappropriate weight on the issue of risk. The fact that Ms Begum was
a child in 2015 was not properly respected, particularly in the context of paragraph 19 of the policy. If, to put the
point at its lowest, Ms Begum was a victim of radicalisation in 2015, that remained the case even though deprivation
was being considered when she was 19. History cannot be rewritten.

206. In the “Appellant's Closing Reply Note to the SSHD's Skeleton”, it is said that the common law would always
require a decision-maker to have regard to factors relating to personal responsibility, mitigation and proportionality.
The Commission doubts whether that is seriously disputed. However, para 17 of that document, and Ms Knights'
oral reply, went one step further:

“Further, it is not enough to cite age, gender, facilitation, children, her situation in Syria without having regard to
context of trafficking and thus to alignment, risk and rehabilitation.”

This brings the submission back to para 54 of Ms Begum's skeleton argument.

“Trafficking” adds a further important ingredient.

207. So, and drawing these various strands together, Ms Knights' argument on Ground 1 was that the Secretary of
State excluded from account mandatory relevant considerations all brought together under the umbrella of
trafficking, and her argument on Ground 2 was that Ms Begum's Article 4 rights were violated both in terms of the
protective and investigative duties that were owed to her. Ms Knights' submission that the Secretary of State has
applied an unlawful policy should, we think, better be considered under the rubric of Ground 1.

208. Ms Begum could have little to say about Ground 8 because she has not seen the CLOSED material. She may
be reassured that the Commission, with the help of the Special Advocates, has scrutinised that material very closely
indeed.

209. The Commission acknowledges that many of Ms Knights' submissions were extremely powerful. Her oral
presentation was excellent and a vast amount of work and expertise has gone into the preparation of the written
argument. The Commission considers, with respect, that the trafficking arguments were, at times, addressed by the
Secretary of State in a somewhat dismissive way. The suggestion being made was that these arguments serve to
raise the emotional temperature but do nothing else.

210. The Commission would agree that a high emotional temperature is capable of clouding the cool application of
the relevant legal principles to an extremely difficult and disturbing case. However, Ms Knights advanced a series of
compelling and important submissions, and we do not think that she ever strayed into jury advocacy.

The Secretary of State's Submissions

211. Sir James submitted that the key focus of the section 40 deprivation power is, and must be, the threat to
national security. He reminded the Commission that the national security assessment is essentially one for the
Secretary of State, that the issue of proportionality should be viewed through the lens of Begum in the Supreme
Court; and he submitted that the Commission's decision in B4 is entirely correct


-----

212. Sir James made six short points on the national security case. First, the assessment has been made that Ms
Begum travelled voluntarily to Syria, with commitment and determination. Secondly, Ms Begum's motivation was to
align with ISIL. Thirdly, the threat posed by someone who travels and aligns has been subject to the most careful
consideration and assessment by the Secretary of State. Sir James added that “none of this is binary; it is protean”.
He accepted that the consequences are “austere”, but the “hard school” is the repeated attacks committed or
inspired by ISIL which are all in the public domain (the Commission might add that attacks that may have been
thwarted, either in the United Kingdom or in mainland Europe, will not be). Fourthly, Sir James submitted that the
fact that someone is radicalised, and may have been manipulated, is not inconsistent with a finding that she may
pose an extremely serious national security threat. Fifthly, Sir James submitted that it is highly relevant that Ms
Begum remained in ISIL-controlled territory for nearly four years. Sixthly, it was argued that detailed and specific
consideration of her case has been given by the Secretary of State.

213. On the issue of trafficking, Sir James' headline submission was that it is not a necessary part of the
deprivation decision-making process to determine whether someone may have been trafficked, whether that label
should be attached, and whether further investigations should be undertaken. In this regard, he made five
fundamental points. First, he submitted that the section 40 power has been conferred by Parliament to protect the
public from terrorist threat. Secondly, the proper exercise of the power depends primarily on an expert assessment
of the issue of risk. It is no answer that the public must be exposed to the danger because events and
circumstances conspired to make Ms Begum one. That, Sir James submitted, is the central point. Thirdly, he
submitted that all the factors relevant to a formal trafficking analysis (which does not have to be undertaken) have in
fact been taken into account by the Secretary of State in deciding whether the deprivation power should be
exercised. Fourthly, Sir James invited the Commission to bear in mind both the generality and the height of the
trafficking case that was being advanced. It is being said that the power to deprive cannot be exercised until the
Secretary of State has at the very least considered whether Ms Begum was the victim of trafficking, but that cannot
be correct. Fifthly, and connectedly, if a trafficking investigation were required, the Secretary of State would then
become “mired” in issues which would impede the exercise of a power which often has to be done speedily.

214. On Ground 1, Sir James submitted in outline that trafficking (by which he meant trafficking stricto sensu) was
not a mandatory relevant consideration, that all relevant factors were considered in any case, including the degree
of Ms Begum's responsibility, that the assessment that Ms Begum travelled voluntarily can only be challenged on
the basis set forth by the Supreme Court in Begum, and the Secretary of State's policy does no more than to
identify an approach to the sort of factors that fall to be considered in a case of this sort.

215. On Ground 2, Sir James submitted that Ms Begum was not in the jurisdiction, that the investigative obligation
could not be discharged in these circumstances, and the

Commission could not be “fully confident” (see the decision of the Supreme Court in R (AB) v SSJ [2021] UKSC 28;

[2022] AC 287, at para 57) that the Strasbourg Court would hold that a violation of Article 4 would somehow impede
the exercise of the section 40 power. Sir James emphasised that the non-punishment principle did not apply (Ms
Begum was not being subjected to a criminal prosecution) and that there was no obligation to repatriate.

216. Sir James' oral argument was, as ever, immensely compelling and attractive. In one sense, he held many of
the best cards, the decision of the Supreme Court in Begum having placed them in his hand. In another sense, the
human dimension to this case is very powerful. Sir James naturally recognised the latter, but one key issue for the
Commission is whether the Secretary of State did – and, in particular whether the considerations that Sir James
accepted were “protean” were wrongly treated by the Secretary of State as “binary”.

217. In the light of the parties' submissions, the Commission proposes to address Ground 2 before it turns to
Ground 1. Under the rubric of Ground 1, it will address the issues in the following sequence:

(1) Mandatory relevant considerations.

(2) The National Security Case (this will bring in Ground 8)

(3) The lawfulness of the Secretary of State's policy.


-----

(4) The Secretary of State's identification and characterisation of matters known to him potentially inuring to Ms
Begum's advantage, in particular the “voluntary” nature of her travel and the application of his policy to her case.

Ground 2

218. The first issue to decide is whether there is a credible suspicion that Ms Begum was the victim of trafficking
from the United Kingdom to Syria. The Commission cannot avoid determining that issue, because it is an essential
building-block of Ms Knights' argument that the Secretary of State was in breach of Article 4 of the ECHR in terms
of the protective and the investigative duty. In MS Pakistan, the Supreme Court did not comment adversely on the
Upper Tribunal deciding that issue for itself. In the Commission's view, and in line with Begum in this context of an
absolute human right, this is matter for it to decide and there is no deference to the Secretary of State.

219. In the Commission's opinion, there is a credible suspicion that Ms Begum was recruited, transferred and then
harboured for the purpose of sexual exploitation. Given that she was a child at the time, proof of one or more of the
subparagraph (a) “means” (see Article 4 of ECAT) is not required.

220. The Secretary of State's ISIL Statements recognise that female recruits, including children, are destined to be
“married off” to act as brides for ISIL fighters and to provide the next generation. The Secretary of State's policy
recognises that some minors may be “self-motivated” but that is not on the Commission's understanding being
suggested here. It is accepted that Ms Begum was radicalised (although its extent is not accepted), and as a matter
of basic common sense that must have happened, at least in part, through internet research and grooming whilst in
the United Kingdom. Her press interviews are entirely consistent with that interpretation. There must at the very
least be a credible suspicion that this is what took place. The fact that Sharmeena may have played an important
role, whether acting entirely unaided or as agent for a third party, does not disturb the drawing of these inferences;
nor does the fact that there is no evidence of duress.

221. The idea that Ms Begum could have conceived and organised all of this herself is not plausible. True, the theft
of her sister's passport was not ISIL inspired, but getting to the Syrian border would not have been straightforward
even for someone ten years older. Whether those in Syria acted as mere facilitators does not really matter for the
purposes of the ECAT definition because there must be a credible suspicion that she was in touch with these
people before she left the United Kingdom and that they provided encouragement.

222. For the avoidance of doubt, the Commission does not consider that Ms Begum's inability to give evidence is a
decisive factor against her. It is a consideration that the Commission takes into account and weighs in the balance,
albeit not particularly strongly. The Strasbourg jurisprudence indicates that a victim complaint is not required to
trigger any relevant obligation.

223. The credible suspicion threshold is a low bar. As we have pointed out, proof of any of the subparagraph (a)
“means” is not required. Looking at subparagraph (c), the relevant exploitative purpose can be any form of sexual
exploitation, and Ms Begum's ideological commitment is not relevant. Additionally, matters of fact and degree are
irrelevant, including the extent to which she was radicalised and the extent of her personal responsibility. Hayden J
pointed out in B that the various girls whose cases he knew about had been radicalised to “greatly varying
degrees”. The trafficking analysis bypasses all the more nuanced questions of this type.

224. It is also arguable, in the Commission's judgment, that there were State failures, and possible violations of the
corollary protective duty, between December 2014 and February 2015. There is force in the submission that these
could be investigated.

225. There is evidence in CLOSED which also bears on the credible suspicion issue.

226. The Commission has little or no hesitation in concluding that the credible suspicion threshold has been
surpassed. But that, without more, is insufficient for Ms Begum's purposes.

227. Ms Begum must also show that the exercise of the section 40 power amounts to a breach of her rights under
Article 4 of the ECHR. Anything less than that will not suffice on this appeal under section 2B. A credible suspicion


-----

that she was trafficked does not, in and of itself, amount to a violation of Article 4. Consideration must now be given
to the investigative duty and then the protective duty.

228. Did the exercise of the section 40 power violate the investigative duty? The exercise of the executive power to
remove MS under Schedule 2 to the Immigration Act 1971 did entail a violation of Article 4 because his presence in
this country was integral to an effective investigation. There was, accordingly, a direct, obvious and essential nexus
between the exercise of an admittedly wide discretionary power and the postulated breach. But Ms Begum is not
within the jurisdiction. Even if, for the purposes of argument, it may be accepted that an effective investigation
requires her to be here, because she cannot be properly assessed in Syria, a violation of Article 4 would occur only
if the Secretary of State were under an obligation to repatriate her for that purpose.

With respect to Ms Knights' submission on the irrelevance of MS Pakistan, the Commission sees no way round this.

229. However, Ms Knights did grasp this nettle and submitted in the alternative that the Secretary of State was
under an obligation to repatriate Ms Begum as a victim of trafficking. If she were right about that, the Commission
would see the force of the contention that a failure to repatriate is as much a violation of Article 4 as was the failure
to investigate in MS Pakistan.

230. The repatriation obligation is said to arise under Article 16 of ECAT, which provides:

“(1) The Party of which a victim is a national or in which that person had the right of permanent residence at the
time of entry into the territory of the receiving party shall, with due regard for his or her rights, safety and dignity,
facilitate and accept, his or her return without undue or unreasonable delay.”

There is also an obligation to provide necessary travel documents.

231. Ms Knights did not seek to contend that Article 16 of ECAT “fleshes out” the content of Article 4 . Her
argument is that the Secretary of State has adopted Article 16 as a matter of policy. The Commission has already
noted that arguments of this sort are entirely appropriate, at least in principle.

232. Article 16 of ECAT is referred to in the Home Office's “Review of NRM for Victims of Human Trafficking”, but
that is too general a reference to assist. Ms Knights relies on Home Office guidance, “Victims of Modern Slavery –
Competent Authority Guidance”. The Commission has both the up-to-date and the version current as at January
2019. Lord Reed in Begum stated (at para 129) that human rights questions are generally assessed at the date of
the Commission's decision. We did not receive submissions as to which date should be taken. No decision on this
is required because it makes no difference. We will consider the up-to-date version, although both versions have
been provided, because that was the target of the parties' submissions.

233. The following paragraphs of the Guidance are relevant:

“2.67 Forced marriage is a crime and victims of forced marriage deserve help and support.

2.68 The joint [Government] unit provides direct support and advice for victims and those at risk through its public
helpline. The support offered ranges from providing information and guidance, to organising rescue and repatriation
overseas. …

2.69 A forced marriage alone would not necessarily mean that a person is a victim of modern slavery. …

…

15.171 Non-British nationals referred into the NRM may wish to return home. This is known as 'voluntary return'.
Ensuring that victims can return home safely helps to reduce the risk of future exploitation.

15.172 A desire to return home is not a barrier to entering the NRM …”


-----

234. If the Article 16 ECAT duty were directly justiciable, Ms Begum's argument would have some force. However,
it is not and the Guidance does not go so far as to incorporate all the components and ramifications of this
international obligation. General statements to the effect that the Government offers assistance to victims of
**_modern slavery are insufficient, in the Commission's view, to constitute an obstacle to the exercise of the section_**
40 power; or, put more precisely, to place the Secretary of State in breach of his Guidance in deciding to exercise
that power instead of repatriating.

235. Another difficulty with the Article 16 argument is that, read as a whole, this provision appears to be
contemplating reciprocal action between two State parties. Syria is not a signatory to ECAT and the United
Kingdom does not have diplomatic relations with the Assad regime. The Commission points this out without
considering it necessary to resolve the issue.

236. Finally on this topic, Ms Knights submitted that a duty to repatriate may also be channelled through the
recovery obligation. At para 286 of Rantsev the ECtHR held that the State has a recovery obligation to “take
appropriate measures within the scope of their powers to remove the individual” from the situation or risk of their
trafficking or exploitation. However, by February 2019 Ms Begum was no longer in ISIL-controlled territory, and in a
case such as the present we cannot accept that the Secretary of State would have been, or is, under an obligation
to take positive steps to bring about her return to the United Kingdom within the terms of any recovery obligation.

237. Overall, the Commission is unable to accept the submission that there has been a relevant breach of the
investigative duty by the Secretary of State by exercising his section 40 deprivation powers in these circumstances
and/or a failure to apply relevant policy. We have already explained our reasons for concluding that a breach of the
investigative duty by the State in general terms cannot, without more, avail Ms Begum.

238. Turning now to the protective duty, the State may have failed in its duties to Ms Begum before she travelled to
Syria, but she is now well beyond the scope of its protection. An investigation into whether there was a material
failure meets the same arguments that have just been addressed in the context of the investigative duty. Ms Begum
needs to persuade us, not merely that there is a credible suspicion that the protective duty has been breached, but
also that this violation is directly and necessarily relevant to the exercise of the section 40 power, to the extent that
it would, perforce, be an unlawful exercise of that power to exercise it pending any investigation. Although in a
general and unspecific sense we recognise the force of the point that by depriving Ms Begum of her citizenship she
is not being “protected”, that is not the issue. There must be a direct connection between the exercise of the power
and the violation of the right, and what happened in 2015, even if a past injustice falls to be remedied, or at least
recognised, does not provide that connection.

239. Ms Knights sought to supply that necessary link by relying on the “non-punishment” principle. Again, the
Commission sees the force of the argument that if the exercise of the section 40 power were properly envisaged as
a form of punishment, that link could well be made out.

240. Article 26 of ECAT provides:

“Each party shall, in accordance with the basic principles of its legal system, provide for the possibility of not
imposing penalties on victims for their involvement in unlawful activities, to the extent that they have been
compelled to do so.”

241. The natural and ordinary meaning of this provision is that it is limited to criminal sanctions, or at least
sanctions which are punitive in nature. The section 40 power is not a punishment as such, although its exercise
does involve consequences of the utmost severity. As the Commission observed in U3, in many ways those
consequences are more severe than a long prison sentence.

242. However, Article 26 of ECAT should be read purposively, and the Commission has been referred to the report
of the UN Special Rapporteur on trafficking in persons, especially women and children, Professor Siobhán Mullally.
In her opinion:


-----

“The range of punishments covered by the non-punishment principle include non-repatriation, family separation or
refusal of consular assistance”. (para 36)

“Failure to respect the principle of non-punishment leads to further serious human rights violations, including
detention, family separation and unfair trial. It also increases the risks of trafficking and retrafficking …” (para 37)

243. These statements of opinion are naturally worthy of considerable respect, although no jurisprudence has been
cited to support them. Ms Knights did not contend that Article 26 of ECAT had been incorporated into domestic law.
The Commission understands her argument to be that Article 26 sheds light on the meaning and scope of Article 4
of the ECHR, and that we may be confident that were the issue ever litigated either here or in Strasbourg the
authoritative opinion of Professor Mullally would be accepted.

244. Put in these terms, the Commission is required to come to its own conclusion as to whether it would be a
violation of Article 4 effectively to punish Ms Begum by exercising the section 40 deprivation power. Furthermore,
putting the matter in these terms serves to highlight the height and breadth of Ms Knights' argument. If correct, the
Secretary of State would never be able to exercise the section 40 power in a trafficking case, unless and until a
determination were made that the putative victim has not been trafficked or, possibly, is no longer in a situation of
trafficking.

245. That Ms Knights' submission may have unpalatable consequences is not a proper reason for not accepting it.
The more compelling objection is that the Commission is being required to determine a human rights question on
terra incognita. We have not been referred to case-law on the point, and Professor Mullally's opinion is no more
than persuasive. The operative principle in circumstances such as these is that set out in the decision of the
Supreme Court in AB. The question for the Commission is whether it can be “fully confident” that the Strasbourg
Court would conclude that the protections under Article 4 encompass the non-punishment principle as interpreted
by the UN Special Rapporteur.

246. The answer to that question is that the Commission cannot be so confident. There is more than a reasonable
prospect that the Strasbourg Court would accept the Secretary of State's submission that Article 26, to the extent
that it illuminates Article 4 of the Convention, covers punishment in the form of criminal convictions and sanctions,
and that the exercise of the section 40 power does not entail a punishment in that sense. It is a power exercisable
to protect the public, not to punish persons who may also be victims.

247. For all these reasons, Ground 2 fails.

Ground 1

A Mandatory Relevant Consideration?

248. The Secretary of State is required to consider and weigh in the balance all the known factors of Ms Begum's
case which might militate against deprivation. In the Commission's judgment, he must do so in the context of this
being one of the most potent powers conferred on Government against the individual, entailing the removal of one
of the most fundamental rights in the international and domestic canon. This is a power to be exercised only where
the national security of the United Kingdom requires it in the estimation of the Secretary of State.

249. Ms Knights fully endorses all of the foregoing, but seeks to go two steps further. First, she contends that a
finding that there is a credible suspicion that Ms Begum has been trafficked is obviously relevant to the exercise of
the section 40 power. Secondly, she argues that not merely are the sort of factors relevant to a trafficking
assessment pertinent to the balancing exercise in the loose and general sense set out above, as accepted by Sir
James, but also the panoply of assessments and protections bestowed by modern trafficking law have the status of
being mandatory relevant considerations. They are so obviously relevant that they must be considered. They must
be addressed before the deprivation power may be exercised.

250. It may immediately be understood where these arguments lead. If there is a credible suspicion that Ms Begum
has been trafficked, how could it be said that Ms Begum's travel was voluntary? A requirement that it is incumbent


-----

on the Secretary of State to consider whether Ms Begum has been trafficked and may have rights under relevant
legislation, serves to strengthen and intensify the weight that must be given to the overall compassionate
circumstances of her case.

251. Ms Knights' submission, yet again, has considerable force. That Ms Begum has failed on Ground 2 does not
mean that she must fail on all aspects of Ground 1. This is because Ground 1 is a lesser version of Ground 2. Here,
it does not have to be argued that the exercise of the deprivation power was necessarily a violation of Article 4:
rather, that the Secretary of State failed to take account of an obviously relevant consideration.

252. The Commission has already found that there is a credible suspicion that Ms Begum has been trafficked.
Applying the principles in Rantsev, there is a credible suspicion that the State's protective duties were violated back
in 2015. On the evidence, there is also a credible suspicion that Ms Begum was harboured by her traffickers until
January 2019. How, then, can these factors not be mandatory relevant considerations?

253. The Commission's response to the rhetorical question it has posed begins with the observation that it is
necessary to take stock and to stand back. The power under section 40 is framed in extremely wide terms.
Parliament has chosen not to specify any of the factors that the Secretary of State must take into account in the
public interest. The Commission's finding that there is a credible suspicion that Ms Begum was trafficked was made
solely in the context of Ms Knight's submission under Ground 2. It was a necessary part of her argument that the
credible suspicion threshold has been fulfilled, and out of fairness to her the Commission has set out its conclusion.
Ground 2 has failed for other reasons.

254. The Commission decided for itself the credible suspicion issue for the purposes of Ms Begum's human rights
argument. Begum in the Supreme Court is authority for the proposition that, exceptionally, its duty is to do that.
However, for the purposes of Ground 1, which is on analysis a public law ground, the Commission must not do that;
it must defer to the Secretary of State. Thus, what Ms Knights' submission seeks to do is to achieve an
impermissible cross-over from one exercise (human rights) to another (public law). The Commission's finding for
the purposes of the former has no relevance to the latter. For the purposes of Ground 1, the limelight is on the
Secretary of State and the breadth of the section 40 power.

255. It is common cause between Ms Knights and Sir James that it is incumbent on the Secretary of State to
consider all the factors known or ought to be known to him which are capable of weighing in Ms Begum's favour.
Despite the breadth of the statutory power, Parliament cannot be presumed to have legislated on the basis that
national security is the sole statutory question. However, there is a significant leap between what is common ground
and Ms Knights' case. Applying the second limb of DSD, there is nothing in the statute which suggests that the
Secretary of State is required to make a formal judgment about trafficking with all the consequences that would flow
from that; or, indeed, to take into account a credible suspicion that the individual may have been trafficked. Here, it
is relevant that Ground 2 has failed.

256. These consequences need to be underlined. The legal policy underlying Article 4 of ECAT, and Article 4 of the
ECHR, is that children are victims and are deemed not to have acted voluntarily. Consent is irrelevant. If trafficking
were relevant, it would be difficult for those advising the Secretary of State to assess that Ms Begum's travel was
voluntary.

257. However, the proposition that the Secretary of State must view Ms Begum's case through the lens of trafficking
cannot be supported. This is not a mandatory relevant consideration, and there is an inherent question-begging in
the contention that it is. On Ms Knights' argument, the primary focus would not be national security but the fact that
Ms Begum was groomed by others for the purposes of sexual exploitation. The Commission cannot accept that the
Secretary of State should be compelled to view her case in these terms. Further, the trafficking analysis removes
from consideration all questions of fact and degree. We have already made the point that the legal policy underlying
Article 4 is not nuanced. Children cannot consent to sexual exploitation and the inquiry ends there. However, for the
purposes of the broader considerations relevant to the proper exercise of the power under section 40, there is force
in Sir James' submission that issues of personal responsibility and agency are not black and white. Despite her
age, Ms Begum could “consent” to travelling to Syria for the purpose of aligning with ISIL: that is a key


-----

consideration relevant to national security and the lawful exercise of the section 40 power. We know from the case
of B that children such as Ms Begum were radicalised to greatly varying degrees. It cannot be presumed in her
favour that her radicalisation was at the more serious end of the scale.

258. Reasonable Secretaries of State could lawfully apply different policies to the exercise of the section 40
function. It is possible to envisage a perfectly lawful policy that precludes the decision-maker from depriving children
at all, or from depriving them without deciding whether they were or may have been trafficked. But that is not the
policy that this Secretary of State implemented.

259. For all these reasons, the Commission is unable to accept Ms Knights' argument that trafficking is relevant to
the exercise of the section 40 power.

260. The sequel to this conclusion is that it is for the Secretary of State to decide what is in the public interest, and
how much weight to give to certain factors, subject always to this Commission intervening on ordinary
administrative law principles. This Secretary of State, speaking through Sir James, maintains that national security
is a weighty factor and that it would take a very strong countervailing case to outweigh it. Reasonable people will
profoundly disagree with the Secretary of State, but that raises wider societal and political questions which it is not
the role of this Commission to address. This is because questions of weight and balance are pre-eminently for the
decision-maker and not for the Commission, subject always to Wednesbury review. It is well established that a
decision-maker may decide to give a material factor no weight: see Lord Hoffmann in Tesco Stores Ltd v Secretary
of State for the Environment [1995] 1 WLR 759, at 780.

261. For all these reasons, Ground 2 fails.

The National Security Case and Ground 8

262. The Commission puts to one side, at least for the time being, one of the Security Service's key assessments:
that Ms Begum's travel to Syria and aligned with ISIL was “voluntary”. The Commission has not lost sight of Sir
James' submission that this key assessment is an integral part of the national security case, but it is more
appropriate to address this assessment later.

263. There was little that Ms Begum could say in OPEN about Ground 8, subject to her discrete point under
Ground 6.

264. The Special Advocates have advanced a series of submissions under Ground 8, and on cognate and related
grounds, in CLOSED. These submissions are addressed in the CLOSED judgment.

265. For the reasons set out in the CLOSED judgment, Ground 8 fails.

The Secretary of State's Policy

266. The approach the Commission must take to the Secretary of State's policy is set out by Lord Reed in Begum,
in particular at paras 123-24. Specifically:

(1) It is perfectly appropriate, indeed even desirable, for the Secretary of State to formulate policies in the form of
guidance in the exercise of an administrative discretion, to secure the coherent and consistent performance of
administrative functions.

(2) Such policies are not law, and may consciously be departed from for good reason.

(3) The meaning of policy is for the Commission and not the decision-maker.

(4) The application of the policy is for the Secretary of State, subject to review on Wednesbury principles.


-----

267. The Commission would add that, when approaching the meaning of a policy (item 3 above), an overly
linguistic or scholastic method is not required. Phraseology may not be ideal, and matters may be capable of
clearer and more precise expression, but a sensible degree of latitude should be given.

268. With these considerations well in mind, the Commission returns to the Secretary of State's policy dated 31st
January 2019. It does so in the context of a document that appears to be far from complete. Much of the relevant
analysis will have to be carried out in CLOSED.

269. There is obvious force in Ms Knight's submission that para 4 of the policy apparently fails to inform para 19. If
an individual radicalised as a minor is a vulnerable victim, that at the very least must be a highly relevant factor in
connection with that person's deprivation as an adult, particularly one aged only 19. Moreover, para 19 of the policy
states that deprivation will be recommended if a national security case exists. Para 19 does recognise that such
persons “may once again be considered a victim”, but the default position under the policy is that they will be
deprived because victimhood has no or little bearing on the risk assessment. Furthermore, the only exception is for
someone who has taken steps to distance himself or escape, provided always that such a person had not travelled
to theatre of her own volition and had not been involved in further activity of concern. Ms Knights submitted that the
“not of their own volition category” is limited to those who were taken under duress, probably by their parents.
Someone who travelled alone, or in the company of other minors, could not avail herself of para 19 at all.

270. Sir James submitted that the Commission should be more flexible. What the policy was doing was identifying
the sort of factors that the decision-maker should bear in mind when exercising this important discretionary power.

271. To the extent that this issue can properly be addressed in OPEN, because paras 5-18 are hidden from Ms
Begum, the Commission's point of departure is that para 19 of the policy is not well drafted. This exposes it to
precisely the sort of criticisms levelled by Ms Knights. The Commission's criticism of the drafting must not be taken
as a personal criticism of Mr Larkin. This will be further explained in the CLOSED judgment.

272. However, albeit not by the widest of margins, the Commission is not persuaded that this is an unlawful policy.

273. Detailed reasons are given in the CLOSED judgment, but what the Commission can say in OPEN is that para
4 of the policy does not state that a person who has been radicalised as a minor and was not taken to theatre by his
or her family is free from personal responsibility altogether. It is clear from the last sentence of para 4 that this must
be a question of fact and degree, and may well depend on the age and personal circumstances of the minor when
she or he was radicalised. The fact that such persons may be considered to be vulnerable victims is not
inconsistent with this evaluation.

274. The first sentence of para 19 is not free from difficulty because it might be interpreted as suggesting that
everything changes at the age of 18. However, in the Commission's view it does no more than express a starting
point. The rest of the paragraph suggests that a national security risk, without more, will not automatically lead to
deprivation.

275. In the context of someone who has been radicalised as a minor but is now over 18, the policy expressly
recognises that she or he “may once again be considered as a victim”. “Once again” appears to be a reference
back to para 4, and on that basis the earlier paragraph informs the meaning and application of para 19.

276.One key aspect of the policy is that even someone who was radicalised as a minor, and by necessary
implication was a vulnerable victim when that happened, may nonetheless pose a threat to national security. The
Commission cannot accept Ms Begum's argument that radicalisation as a minor is relevant to the degree of risk the
individual may pose and the extent to which that individual, once away from her traffickers, might be deradicalised.
That is one possible viewpoint but the Commission can see that there may be strong arguments the other way.
Some might argue that a child who has been radicalised or brainwashed has become more intractable and
refractory than an adult. But the real point here is that, in the light of Begum, this is exactly the sort of issue that lies
within the judgment of the Secretary of State and not the Commission.


-----

277. Para 19 of the policy, taken literally, does appear to limit the exception to the case of someone who is not in
category X or Y but may fulfil category Z. Thus, a person who was radicalised as a child and travelled of their own
volition cannot, on a literal reading, benefit from para 19 at all.

278. The Commission continues to acknowledge the strength of that submission. However, para 19 does state in
terms that someone who was radicalised as a minor may be considered as a victim. Accordingly, the decisionmaker's mind is being directed to a relevant factor. That factor is not being reduced to the nugatory by what the
Commission is calling category X: that Ms Begum was not someone who was taken to Syria under duress.
Furthermore, those considering and applying the policy would be expected to exercise a degree of latitude and
common-sense, rather than being too hidebound by the linguistic analysis that the Commission has identified on a
literal reading. The assessment in the Amended First National Security Statement that Ms Begum's travel was
voluntary was not based on the narrow view that she was not taken to Syria under duress.

279. Overall, the Commission is not persuaded that this is an unlawful policy.

Voluntariness and the Application of the Policy to Ms Begum's Case

280. One of the key planks of the national security assessment is that Ms Begum travelled voluntarily to Syria,
demonstrated determination and commitment in doing so, and remained in ISIL-controlled territory for four years.

281. It is argued on Ms Begum's behalf that it is both illogical and unfair to place such weight on these factors. If
she were to be regarded as a victim of trafficking who had been groomed and radicalised, it would not be surprising
that she stole her sister's passport and took apparently determined steps to leave. Moreover, once she was in
theatre she was in the clutches of her traffickers, married to an ISIL fighter much her senior, and there was no
realistic prospect of her getting away.

282. Furthermore, an assessment in the stark and uncompromising terms that Ms Begum travelled voluntarily did
not engage the sort of free-flowing, fluid factors mentioned by Sir James but was the manifestation of an all-ornothing or binary approach.

283. Again, the Commission recognises that Ms Knights advanced compelling and empathetic submissions on
these issues. Ultimately, however, the Commission continues to remind itself of its function under section 2B of the
1997 Act and is unable to accept these arguments.

284. The first question is whether the assessment made by SyS that Ms Begum travelled voluntarily falls within the
category of national security assessment that the Supreme Court in Begum held to be reviewable only on a
Wednesbury basis.

285. The Commission's point of departure is to recall that Lord Reed in Begum identified only two species of
national security assessment: those which are not justiciable at all, and those which are reviewable only on
administrative law principles. There was no third category. It is clear from all the documentation available in OPEN
that the assessment that Ms Begum travelled voluntarily is in the nature of a national security assessment. It may
well be the case that experts and those with experience of these matters are well-placed to form their own
judgments as to whether a 15 year old girl who may have been radicalised and was not “self-motivated” acted
“voluntarily”. It may also be the case that the Commission is not without experience of its own derived from other
areas of the law, including criminal law. However, in the Commission's experience many national security
assessments require an understanding of human nature, and the context of the present case is terrorism and
national security. We consider that SyS is not merely well-placed to make experiential judgments on matters such
as voluntariness and degree of commitment in that particular context, but also that these issues fall within their
institutional and constitutional competence. The consequence must be that the Commission defers.

286. In short, the Commission concludes that it was for those advising the Secretary of State and not for the
appellate tribunal, to consider and assess whether Ms Begum's travel was voluntary.


-----

287. The second question is whether those advising the Secretary of State followed the sort of flexible, non-binary
approach which Sir James' submissions, by implication, accepted was necessary. If they did not, and still following
Begum, it might be possible to say that the decision-maker mischaracterised a factor that was clearly in her favour
(sc. on any view, her travel at the age of 15 was not entirely voluntary) and/or placed too much weight on the factor
that was held against her (sc. that her travel was entirely voluntary).

288. There were aspects of the evidence of Mr Larkin and Witness E which betrayed an allor-nothing approach. Ms
Knights described Witness E's eloquent evidence about it being inconceivable that an intelligent 15 year old with
predicted high GCSE grades did not fully understand what was involved as “stark”. That was not unfair or
inapposite. Witness E said that Ms Begum “had agency” although he was not pressed on whether this was, or could
be, a matter of fact and degree or whether the extent of her prior radicalisation might have anything to do with her
mindset

289.The Commission is also concerned by the SyS's apparent downplaying of the significance of radicalisation and
grooming, in stating that what happened to Ms Begum is not unusual. The Commission does not doubt that this has
been commonplace but that has no real relevance. History, and sadly the present, is replete with examples of
dictatorships attempting to manipulate their subject populations with propaganda and the like. It is commonplace
that they succeed.

290. Important features of the evidence bearing on this issue can only be addressed in CLOSED. However, what
can be addressed, and repeated, in OPEN is the acknowledgement in the Amended First National Security
Statement that “multiple factors are likely to have contributed to Ms Begum's decision to travel”. There was no
cross-examination on this sentence. In our view, the reference to “multiple factors” can only be interpreted as a
recognition that Ms Begum's motivation was multifactorial and that voluntariness was and is a matter of degree.

291. It is clear from all the available evidence that the Secretary of State was aware of the following matters: Ms
Begum's youth; that she travelled to Syria as a minor and was therefore, under the terms of the policy that he had
approved just four days previously, could once again be regarded as a victim because she was radicalised at an
age when she could not be treated as fully responsible (per para 4 of the policy); and, that it was not solely the risk
she posed that was driving the outcome.

292. Furthermore, although voluntariness falls on a notional spectrum, those advising the Secretary of State are
entitled to say on which side of the line a particular case is assessed to fall. The steps Ms Begum had to take to get
to Syria can be viewed as being in her favour, against her or neutral, but that was for the Secretary of State to reach
a conclusion about and not for the Commission to decide for itself. The same applies to the ramifications of Ms
Begum's lengthy sojourn in Syria and whether there was any possibility of escape. Even had the Secretary of State
been advised in terms that the issue of voluntariness was nuanced and that this was not an all-or-nothing question,
he would still have been told that her travel to Syria demonstrated determination and commitment.

293. Ultimately, although many right-thinking people will strongly take issue with the assessment of those advising
the Secretary of State, the Commission has come to the conclusion that the assessment that Ms Begum's travel
was voluntary cannot be impugned on the application of administrative law principles in these appellate
proceedings.

294. The consequences of the Commission deciding for itself – if that were indeed the law - that Ms Begum's travel
was involuntary, or on the less voluntary end of the spectrum, need to be spelt out. That decision would impact on
the balancing exercise which it is accepted must be carried out under section 40. It would mean that the
Commission would be according more weight to Ms Begum's personal circumstances and less weight to her
national security risk. These are the consequences which would flow from the Commission undertaking a full merits
appeal, but that is not what is required or permitted. As the Supreme Court in Begum explained with crystal clarity,
Parliament has conferred a different function on the Commission in recognition of the constitutional reality that it is
the Secretary of State to assess, and to weigh, the risk to the national security of the United Kingdom.

295. Further reasons in support of this conclusion appear in the CLOSED judgment.


-----

296. For all these reasons, Ground 1 fails.

GROUND 3: DE FACTO STATELESSNESS

297. Ms Begum's case under this Ground is straightforward. Even if the deprivation decision did not render her
technically stateless, it had that practical effect. This was because it could not reasonably be deduced or inferred
that Bangladesh could or would afford her any sort of protection overseas, and there was no reasonable prospect
that she would or could return to Bangladesh for the foreseeable future. Had appropriate inquiry been made of the
Bangladeshi authorities at the time, Home Office officials would have discovered that they were disowning Ms
Begum and were threatening her with immediate imprisonment or worse.

298. The OPEN Ministerial Submission did not address the risk of Ms Begum being mistreated in Bangladesh. In
the Commission's view, it should have done explicitly because it was a matter which particularly merited the
attention of a busy Secretary of State. However, the Secretary of State was also provided with a Mistreatment Risk
Statement in relation inter alia to Bangladesh for the purposes of his Article 2/3 policy. Compliance with the policy
was one of the preliminary issues tried by the Commission in 2019 (judgment handed down in February 2020) and
was ultimately determined by the Supreme Court.

299. The version of the Mistreatment Risk Statement which is in the OPEN bundle is incomplete. It is appropriate
to read this in conjunction with Lord Reed's conclusions on this topic. Essentially, the Secretary of State was
advised that there was no risk of Ms Begum being repatriated or travelling to Bangladesh for the foreseeable future,
although “open source reporting indicates that there is a risk that individuals in Bangladesh could be subject to
conditions which would not comply with the ECHR”.

300. The Commission is prepared to assume in Ms Begum's favour that what was being said was that in the event
that she was to find herself in Bangladesh, as to which there was no real risk, there was a risk that she would suffer
mistreatment that amounted to a violation of her rights under Article 3 of the Convention.

301. So, the strength of the submission advanced by Mr Squires (who presented all the oral arguments on
Grounds 3-9) was that the devastating impact of deprivation was not properly considered by the Secretary of State.
She was not de jure stateless, but she could not travel to Bangladesh, a country with which she had no connection
and where she would run a real risk of being tortured.

302.Putting the submission in those terms does not invoke the concept of de facto statelessness, which carries with
it the notion that Bangladesh would fail to afford Ms Begum the full panoply of protections it affords its citizens or
nationals. The issue is rather more straightforward. But the Commission does not consider that the labelling
matters; it is the substance of the argument that must be addressed. The real point being advanced was that the full
impact on Ms Begum was not properly considered because one way or another she could not go to Bangladesh
and that meant that there was nowhere for her to go.

303. The Commission has thought carefully about this but cannot accept this argument. It will assume for present
purposes that the relevant question must be addressed as at 19th February 2019, taking into account subsequent
evidence to the extent that it bears on that question, and not as at today's date – when there is absolutely no
prospect of Ms Begum being admitted to Bangladesh since she is now over 21 and is not a citizen of that country.
The Secretary of State was told in terms that there was no real prospect that Ms Begum would go, or be compelled
to go, to Bangladesh and he also knew that she could not go there for her own safety. He was therefore aware of
the devastating impact that the Commission has identified, and it must be inferred that he considered this. Mr
Squires did not contend in the alternative that the Secretary of State's decision was perverse.

304. Mr Squires relied on certain dicta in Pham but these cut both ways. Lord Mance emphasised that deprivation
is “a radical step, particularly if the person affected has little real attachment to the country of any other nationality
that he possesses and is unlikely to be able to return there” (para 98). Lord Sumption observed that de jure
nationality may not be “of any practical value even if it exists in point of law” (para 108). However, the Supreme
Court was not saying that it would be unlawful to deprive someone if the inevitable consequence would be that she
could not go to the country of which she is technically a national. The point that was being made was that this was


-----

draconian executive action and that these consequences would have to be weighed in the proportionality balance
and/or the overall evaluative assessment.

305. For completeness, the Commission cannot accept the Secretary of State's argument, advanced only in
writing, that this issue has either been already determined by the Supreme Court or ought to have been advanced
at that stage as one of the suite of preliminary issues that the Commission ordered to be tried in June 2019. Even if
the Commission were wrong about that, the Secretary of State's objection should have been raised in judicial
review proceedings, and these have not been progressed. However, the Commission does accept the Secretary of
State's argument that he was aware of the impact on Ms Begum were the deprivation order to be made, including
the fact that she neither would nor could go to Bangladesh.

306. For these reasons, and those briefly elaborated in the CLOSED judgment, Ground 3 fails.

GROUND 4: PROCEDURAL UNFAIRNESS

307. This Commission over many years has proceeded on the basis that the recipient of a deprivation decision and
order did not have the right to make prior representations to the decision-maker, and that any unfairness is
remedied by the appellate process. The leading case on this issue is Al-Jedda (No 2) v SSHD (SC/66/2008) (“AlJedda”), Flaux J, as he then was, presiding.

308. In B4 the Commission adopted a slightly narrower approach:

“The general rule in national security cases is that there is no duty to seek representations before making the
deprivation order. This is because the very act of seeking representations would be contrary to the national security
of the UK: the individual would take immediate steps to return, in the knowledge of what was about to happen.”
(para 138)

At para 140 of its judgment, the Commission explained that there was no feature of B4's case indicating that the
general rule should not apply. Indeed, there was a national security reason necessitating a rapid decision.

309. The decision in U3, at para 38, appears to be more consistent with B4 than Al-Jedda, although the extent to
which the point was argued is not clear.

310. Mr Squires launched an impressive, full-frontal attack both on the orthodox approach (Al-Jedda) and the more
attenuated approach (B4). Given that his submissions have ramifications which extend well beyond the present
case, the Commission will set out the position in full.

311. The leading authority on procedural fairness in a national security context is Bank Mellat v HMT (No 2) (“Bank
Mellat”) [2013] UKSC 38/39; [2014] AC 700. In that case, an order was made against an Iranian bank which had the
effect of proscribing its operations in this jurisdiction. There was a right of application to the High Court under
section 63 of the Counter-Terrorism Act 2008, in respect of which judicial review principles would be exercised.

312. Lord Sumption gave the judgment for the majority and opined that the issue could not be answered in wholly
general terms; it depended on the particular circumstances (para 31). In the next paragraph, he held:

“… unless the Act expressly or impliedly excluded any relevant duty of consultation, it is obvious that fairness in this
case required that Bank Mellat should have an opportunity to make representations before the direction was made.”

313. At para 35 Lord Sumption addressed the issue of principle in this way:

“The duty of fairness governing the exercise of a statutory power is a limitation on the discretion of the decisionmaker which is implied into the statute. But the fact that the statute makes some provision for the procedure to be
followed before or after the exercise of a statutory power does not of itself impliedly exclude either the duty of
fairness in general or the duty of prior consultation in particular. … Like Lord Bingham in R (West) v Parole Board

_[2005] UKHL 1; [2005] 1 WLR 350, para 29, I find it hard to envisage cases in which the maxim expressio unius_
exclusion alterius could suffice to exclude so basic a right as that of fairness.”


-----

314. There are other authorities at the highest level to the effect that the making of limited, specific statutory
provision does not, without more, exclude the implication of the duty to act fairly. The Commission mentions Lloyd v
McMahon [1987] AC 625and R v SSHD, ex parte Doody [1994] AC 531. This is what Lord Sumption meant when
he observed that the Latin maxim did not apply. On the other hand, that is not to rule out the possibility that the
statutory scheme, properly construed, may by necessary implication exclude the relevant duty.

315. At para 37 of his judgment, Lord Sumption considered the ramifications of section 63 of the 2008 Act. This
provision did no more than confer public law rights that would have existed in any event. Accordingly:

“It would I think be surprising if the mere fact that the right of persons affected to apply for judicial review had been
superseded by a statutory application with substantially the same ambit, were to make all the difference in the
context of the Treasury's common law duty of

fairness.”

316. Lord Sumption's further reasons for holding that section 63 did not by necessary implication displace the right
that would otherwise have existed at common law were that the bank would be suffering detriment in the period
between the initiation and resolution of proceedings under section 63, and that the recognition of a duty of prior
consultation would not frustrate the purpose of the scheme or cut across its practical operation.

317. Lord Neuberger of Abbotsbury PSC dissented in part, but not on the point of principle. We may see that
eloquently set out at para 179:

“In my view, the rule is that, before a statutory power is exercised, any person who foreseeably would be
significantly detrimentally affected by the exercise should be given the opportunity to make representations in
advance unless (i) the statutory provisions concerned expressly or impliedly provide otherwise, or (ii) the
circumstances in which the power is to be exercised would render it impossible, impractical or pointless to afford
such an opportunity. I would add that any argument advanced in support of impossibility, impracticability or
pointlessness should be very closely examined, as a court will be slow to hold that there is no obligation to give
such an opportunity, when such an obligation is not dispensed with in the relevant statute.”

318. On the foot of Bank Mellat, Mr Squires submitted that, unless the statute is by necessary implication to the
contrary effect, the general rule is that fairness imports a duty to give an opportunity to make advance
representations. That rule may be displaced but only in the circumstances specified by Lord Neuberger. The
Commission did not understand Mr Squires to be submitting that Lord Neuberger's criteria do not include reasons of
national security which either reasonably prevent the opportunity being given or substantially qualify the content of
the duty. Mr Squires' submission was that no proper national security reason has been put forward in his client's
case.

319. Lord Neuberger referred to the opportunity to provide representations in advance rather than, by implication,
after the event. It is well-established in principle and on authority that there is value in hearing any alternative or
opposing viewpoint at the formative, evolving stage of the decision-making process: see, for example, R (SP) v
[SSHD [2004] EWCA Civ 1750, at para 58.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TXB-5J00-Y96Y-H53T-00000-00&context=1519360)

320. Mr Squires also drew attention to the decision of the Supreme Court in R (Osborn) v Parole Board _[2013]_
_UKSC 61; [2014] AC 115where some of the reasons for requiring the solicitation of prior representations were_
explored. The Commission does not consider that these carry any real weight in the present context of a section 2B
appeal.

321. Finally, Mr Squires made a number of submissions on R (BAPIO Action Ltd) v SSHD [2007] EWCA Civ 1139.
That was a case about legitimate expectation and consultation, and although it was analysed in Al-Jedda the
Commission does not consider that it adds significantly to this discussion.

322. The point of departure for our analysis of this issue is Al-Jedda. There, the Commission examined relevant
authority and concluded that there was no duty to consult before a deprivation order is made. This was because:


-----

(1) Section 40(5) of the BNA 1981 sets out an exhaustive procedural framework which does not include any
obligation to give prior notice (para 156)

(2) Parliament has conferred a full merits appeal, contrasting the position with judicial review proceedings which do
not afford such a right (para 159)

323. Our understanding of Al-Jedda is that these reasons formed independent rather than cumulative grounds for
the Commission's conclusion. It is clear from para 161 that the first reason, by itself, would have been sufficient.

324. The Al-Jedda Commission provided detailed reasons in connection with item (1). In summary these were that
Parliament has set out the limit of the Secretary of State's obligations in section 40(5): these are to notify the
individual before the relevant order is made that a decision adverse to her interests had been taken, and that it was
appealable. We would add that this is an irreducible common law right: see R (Anufrijeva) v SSHD [2003] UKHL 36;

[2004] 1 AC 604. In the Al-Jedda Commission's view there is no requirement that the subject must also be given the
opportunity to make representations prior to the decision or order being made. As a matter of statutory construction
this code should be viewed as a whole, and there was no room at common law for the co-existence of a duty to act
fairly at the pre-decision stage: that had been impliedly excluded.

325. Mr Squires' immediate riposte to this was that in section 40(3) cases of fraud and misrepresentation it is the
Secretary of State's practice to afford an opportunity to make representations before any decision is made. His
point was that section 40(5) applies as much to section 40(3) as it does to section 40(2). Sir James, maybe taken
by surprise by a submission not prefigured in writing, did not comment on this. Since the hearing, the Commission
has heard nothing from the Secretary of State to suggest that Mr Squires may have been incorrect.

326. Our approach must be to treat the reasoning and conclusions of Al-Jedda as persuasive albeit not binding.
This was a careful, detailed decision reached after full argument from highly distinguished counsel. It merits very
considerable attention.

327. With great respect, however, we part company with the Al-Jedda Commission as to whether the para 156
reason (sc. an exhaustive statutory code) may be regarded as sufficient by itself to justify the conclusion that
common law fairness has been impliedly excluded. The requirement to notify the person of the decision and her
appeal rights is indefeasible. The fact that the statute gives express recognition to it should in our judgment be
regarded as a neutral factor. Clear words are required to give rise to the necessary implication, and we are not
persuaded that these are to be found in section 40(5), or elsewhere. With appropriate diffidence, we think that the
Al-Jedda Commission did not give sufficient weight to para 35 of Lord Sumption's judgment in Bank Mellat.

328. We are, however, entirely satisfied that on the premise that an individual has a “full merits appeal” the
conclusion in Al-Jedda was correct. In our judgment, paras 156 and 159 should be taken together rather than
separately. Anything that the individual would, could or should have said in the context of a hypothetical opportunity
to make representations in advance of the decision being made would be considered by the Commission in the
exercise of its appellate function. Indeed, on this premise the Commission would be considering the matter for itself
on a more comprehensive basis because it has far more material then an appellant could ever put before the
Secretary of State at the pre-decision stage. In effect, Parliament has said that fairness does not require a prior
opportunity because the subsequent opportunity to advance one's case is more than sufficient.

329. This conclusion is not disturbed by Mr Squires' submission on section 40(3). It does not appear that the AlJedda Commission's attention was drawn to the Secretary of State's practice in non-national security cases. Even if
it remains good practice to afford a prior opportunity to make representations in section 40(3) cases, not least
because it is obviously desirable to avoid unnecessary appeals if the individual has a knock-out point unknown to
the decision-maker, any failure to afford this opportunity could not affect the outcome – in the context, that is, of a
full merits appeal.

330. We may introduce a note of reservation inasmuch as by using the term “full merits appeal” the Al-Jedda
Commission may not necessarily have been intending to convey the notion that this Commission has carte blanche
in its approach to the national security assessments made by those advising the Secretary of State. The


-----

Commission's consistent jurisprudence before Begum in the Supreme Court acknowledged that although it did
carry out a merits appeal rather than a review, “due deference” or “great weight” should be accorded to these
assessments: see, for example, K2 v SSHD (SC/96/2010), Y1 v SSHD (SC/112/2011) and R3 v SSHD
(SC/150/2018). In Al-Jedda v SSHD (SC/66/2008), the Commission stated that it does not carry out a Wednesbury
review (for which it was roundly criticised by the Supreme Court), although it expressly acknowledged that
deference must be accorded. As will become clear, our conclusion in the present case does not hinge on any
particular interpretation of “full merits appeal”, although the justification for holding that fairness does not require
prior notification is obviously stronger if the premise be that the Commission has an unfettered fact-finding role.

331. Para 159 of Al-Jedda cannot of course be reconciled with Begum. The relevant premise having been
removed, what is the correct analysis now?

332. One of Sir James' submissions in oral argument was that the Commission undertakes a full merits appeal. By
advancing that submission it appeared to us that Sir James was trying to have his cake and eat it. The submission
was obviously incorrect and we say no more about it.

333. Perhaps a slightly better argument, not that it was one that Sir James advanced, is that the 1981 Act confers
an appeal right. In inferring Parliamentary intention it might therefore be said that it is not the substance of the right
that really matters: the right is described in those terms, and that is key.

334. If Ms Begum's appeal right were precisely analogous to judicial review, the instant case would in our view be
indistinguishable from Bank Mellat, in particular para 37 of Lord Sumption's judgment. If there were no obligation to
solicit prior representations, the

bank's factual case would self-evidently not be considered by the decision-maker and, furthermore, could not be
examined by the judicial review court because post-decision evidence is inadmissible. This amounts to a very
powerful reason for the conclusion that The insufficient to remedy this injustice.

335. However, Ms Begum's appeal right is not precisely the same as judicial review. For these purposes, we must
consider the substance of the matter rather than the taxonomy. Following Begum this Commission applies
administrative law principles but, as we have already said at some length, post-decision evidence (in the sense in
which we have defined it) is admissible. In particular, the Commission must consider the appellant's case and any
exculpatory evidence adduced by the Secretary of State. It is not as if this material is excluded from account, and it
is not as if evidence cannot be very thoroughly tested during the proceedings.

336. Unfortunately, the parties did not assist us in resolving this issue in the nuanced terms in which we have
styled it. Instead, they sought to take the high ground rather than to attempt to explore the undifferentiated middle.
We have to do the best we can in those circumstances.

337. On balance, and not without some hesitation, we have concluded that in the absence of a full merits appeal it
cannot be said that common law fairness has been impliedly excluded. Although the Commission will consider an
appellant's evidence on a section 2B appeal, in so doing it must do more than demonstrate the exercise of “due
deference” to the national security assessments that have been made but must apply a Wednesbury test.
Conversely, powerful evidential points advanced by or on behalf of an individual at a formative stage of the
decision-making process are at least capable of affecting the outcome. Such points could of course affect the
outcome even on a section 2B appeal, but by the time her case reaches the Commission the bar for an appellant to
surmount is higher.

338. As we shall explain in due course (see §343 below), the potential value of any opportunity to make prior
representations varies as between deprivation cases on the one hand and (for example) exclusion cases on the
other. However, at this stage of the analysis – addressing whether common law fairness has been impliedly
excluded in the context of the statutory scheme - we are addressing the issue at a reasonably high level of
generality, applying paras 31-37 of Bank Mellat. We are not seeking to distinguish between the range of issues
which are capable of arising in section 40 deprivation decisions and appeals from them.


-----

339. We should make it clear that in a section 40(2) case what the common law requires at the pre-decision stage
in terms of the information to be given to the person about to be deprived cannot be greater than what the statute
requires at the time of making the decision pursuant to section 40(5). Mr Squires did not submit that the notice was
invalid because the reasons it provided were inadequate, and in our opinion he was right not to. The paucity of
reasons received by the subject of the deprivation decision will render it difficult if not impossible for her to
contradict the national security case, but that is not a reason for holding that fairness has been impliedly excluded
(it may be a reason for concluding that it would be pointless for there to be an opportunity for prior representations
on national security to be made, but that raises a different matter). This is because in a deprivation of citizenship
case the enquiry does not begin and end with the issue of national security.

340. In the present case, the decision was “served to file” and the order was signed almost immediately (the exact
sequence is unclear, but it does not matter). The Court of Appeal had something to say about this practice in R (D4)
v SSHD [2022] EWCA Civ 33; [2022] QB 508. It is unlawful; but Mr Squires, who appeared for the successful party
in that case, did not advance a submission about it on behalf of Ms Begum. Again, he was right not to do so
because the Secretary of State's sound instinct – that he should be seen to act transparently and a letter should
therefore be sent to Ms Begum's family – means that this is a wholly technical breach.

341. Having decided the point of principle in Ms Begum's favour, the Commission must therefore return to Lord
Neuberger's stated exceptions: impossibility, impracticability and pointlessness. We take into account that within
either the first or second of these concepts, or in any event, must be included the fact that the giving of the
postulated opportunity to make representations may be contrary to the national security of the United Kingdom. The
Commission's experience is that this will usually be so if the individual is outside this country, not least because
prior notification runs an unacceptable risk of precipitating his or her early return; but is prepared to accept that in
B4 it may have gone slightly too far in saying that in national security cases there is a general rule. The deprivation
power can of course be exercised when the individual is here, in which circumstances it is difficult to accept that
there must be a presumption against an opportunity being given. In practice, such an individual cannot be removed
until his appeal rights have been exhausted and a deportation order made.

342. Mr Larkin has said in OPEN that there were national security reasons justifying the omission to give Ms
Begum a prior opportunity although no particulars have been given. The Commission addresses these in CLOSED
and rejects his evidence. What the Commission can say in OPEN is that in its view the real reasons why Ms Begum
was given no prior opportunity were that the Secretary of State was, fortified by Al-Jedda, following his standard
policy not to do so, and that it is clear from all the material we have seen that, from the moment the news story
broke, this decision would have to be made quickly. Political rather than national security factors drove the
outcome.

343. Next, we must address Lord Neuberger's third rubric, pointlessness. In D9 v SSHD (SC/180/2021), the
Commission (Steyn J presiding) concluded in the context of exclusion from the United Kingdom that it would be
pointless for the individual to be given prior notice because there could be nothing that he could usefully or sensibly
say on the issue of national security (para 45). We respectfully agree (see §339 above) but must underline that D9
was a case about exclusion. The position is different in a case about deprivation where the individual may well have
rather a lot to say about the proportionality and overall justice of a decision removing a fundamental right. We
cannot therefore conclude that, as a matter of principle, prior notification would be pointless in a case such as the
present. To do so would be to acknowledge, on an erroneous basis, that national security really trumps everything
else whatever the individual might say.

344. But these conclusions are insufficient to cause us to allow Ms Begum's appeal. It is insufficient for her to win
the point of principle which arises on the special and unusual facts of her case. We must also consider whether the
failure to afford her an opportunity to advance prior representations made any difference to the outcome in these
particular circumstances.

345. In this context the burden of persuasion on the Secretary of State is a high one (see further, §350 below). We
also take into account in Ms Begum's favour that this forensic exercise must be conducted on the premise of a
hypothetical reasonable and openminded Secretary of State being notionally in office at the relevant time, rather


-----

than one who may be deaf to whatever might be said on her behalf. There is some scope for a range of reasonable
opinions – thereby rendering it more difficult for the Secretary of

State to say in these proceedings that Ms Begum's prior representations could have made no practical difference.

346. We have already held that any attempt by Ms Begum to challenge the national security case at the predecision stage would have been fruitless. More realistically, prior notification would have given her the opportunity
to set out in summary form some of the compassionate circumstances which should go into the balance. It would
not have been incumbent on the Secretary of State to wait the many months it would have taken to assemble the
powerful evidential case contained in the voluminous bundles placed before the Commission in this appeal. The
Secretary of State is entitled to proceed relatively speedily in the public interest, and a brief window of opportunity is
all that would and should have been afforded. The national security context is relevant here.

347. In this brief hypothetical timeframe, and whatever the position regarding Ms Begum's legal representation as
at 19th February 2019, it would not have been possible for valuable instructions to have been obtained from Ms
Begum herself, given the circumstances in which she was living. We cannot ignore the practical reality that these
instructions still have not been obtained. The most that would and could have happened, assuming everything in
Ms Begum's favour, is that Ms Gareth Peirce or someone else would have put together, no doubt expressed in
powerful and eloquent terms, a number of obvious reasons why this draconian and radical step should not be
taken.

348. In assessing whether the failure to afford an opportunity to make representations made any practical
difference, this appellate process is not irrelevant. Although it does not constitute a reason for concluding that in
principle there is no fairness duty in the first place, it is a factor to be borne in mind in any individual case when
assessing the materiality of the failure. The Commission takes into account all that has been said on Ms Begum's
behalf as well as the reaction to it by those advising successive Secretary of States.

349. Overall, the Commission does not consider that representations of the nature we are predicating would have
made any practical difference in the particular circumstances of Ms Begum's case, even in the context of a
decision-making process that was at its formative stage. The Secretary of State was of course aware that Ms
Begum was a child at the time of her departure and might have been the victim of radicalisation and so forth, and
he would clearly understand that this was not a decision to be taken lightly. He was also aware, as we have found,
that Ms Begum – assuming that she could ever surmount a number of obvious practical difficulties - could not travel
to Bangladesh without putting herself at personal risk. Whatever the force of the pre-decision advocacy put forward
on Ms Begum's behalf, we are confident to the requisite standard that the outcome would have been the same.

350. It is not sufficient for Ms Begum's purposes to demonstrate a technical breach of the rules of natural justice.
As U3 explains, at para 33:

“SIAC's more powerful microscope may enable it to see more clearly not only the potentially significant flaws but
also their evidential context. This means that it may be better placed than would a judge in judicial review
proceedings to conclude, once a flaw is identified, that it is not material or that the outcome would inevitably have
been the same …”

The Commission understands the formulation, “it is not material or that the outcome would have been inevitably the
same”, to embody just one test. These are slightly different ways of making the same point. If the Commission were
wrong about that, the Secretary of State would be in an even stronger position. Strictly speaking, the position must
be examined as at today's date, taking into account all the material now available, rather than as at 19th February
2019 or shortly thereafter. Either way, it makes no difference. The Commission is entirely satisfied that the outcome
would have been the same four years ago and that it would be and is the same now.

351. Sir James did not advance any oral submissions directed to paras 231-234 of his skeleton argument and the
well-known decision of the Court of Appeal in Simplex GE (Holdings) v Secretary of State for the Environment

[1988] P & CR 306, at 327 and 329, as applied by this Commission in LA v SSHD (SN/63/2015), at para 113, and


-----

as also reflected in U3. However, Sir James did not abandon his skeleton argument, and could not have predicted
on which issue or issues his submissions might not prevail.

352. For all these reasons, Ground 4 fails.

GROUND 5: PREDETERMINATION

353. This Ground may be addressed quite shortly.

354. Mr Squires' submission was that the Secretary of State, in his public utterances before the deprivation
decision was made, predetermined the issue, alternatively gave the appearance of having predetermined the issue.
In this regard the Commission applies the same “fair-minded and informed observer test” (see, for example, R
(Electronic Collar Manufacturers Association) v SSEFRA [2019] EWHC 2813 (Admin), para 140) as it would in an
apparent bias case, recognising as it does that predetermination and bias are not precisely co-extensive. It is
unnecessary to reference the relevant jurisprudence.

355. The high watermark of Ms Begum's case is that the Secretary of State's promise to “use all available powers”
etc. may only be understood in context as a reference to his powers under section 40 of the BNA 1981.
Furthermore, it is argued that in the headline to the article The Sunday Times published on 17th February 2019 the
Secretary of State said:

“If you run away to join Isis like Shamima Begum, I will use all my power to stop you coming back”.

356. The Commission must consider all the pre-decision information in the round. Having conducted that exercise,
it notes that the text of The Sunday Times article is unobjectionable. The Secretary of State said in terms that this
would be a case-specific decision. He did not say that the making of an order was inevitable.

357. The fair and informed observer would also be well aware that politicians often deploy bullish soundbites to get
their overall message across. She or he would also know that politicians may have a policy preference in relation to
the exercise of broad statutory powers, and that they receive detailed submissions and briefing notes from their
officials. These must be fair and balanced.

358. Finally, the Commission is entitled to take judicial notice of the fact that the sub-editor, and not the author of
any piece, chooses the headline. This particular headline, it is true, was not an unfair paraphrase of what the
Secretary of State had said on previous occasions.

359. The Commission cannot accept the submission that an adverse inference should be drawn on account of the
failure to serve evidence from Mr Javid. That is not required and is rarely appropriate in relation to ad hominem
challenges of this sort.

360. Overall, the Commission is not persuaded that a fair-minded and informed observer would think that the
evidence gives rise to a real possibility or real risk of predetermination. Such an observer would take into account
the text of the Sunday Times article and not just the headline.

361. Ground 5 therefore fails.

GROUND 6: UNFAIR/ONE-SIDED PRESENTATION OF THE RISK POSED BY RETURNEES

362. Mr Squires' argument was that the Secretary of State was wrongly advised, without qualification, that any
individual who travelled to Syria to align with ISIL posed a threat to the national security of the United Kingdom. No
mention, however, was made in any of the OPEN material to the existence of individuals, in particular those with a
similar profile to Ms Begum (sc. having been trafficked to Syria as a child) who had returned to the United Kingdom,
had been successfully reintegrated into society, no longer constituted a risk, or alternatively represented a risk that
could be, and had been, successfully managed.


-----

363. The first ISIL Statement dated April 2017 made the point that in general individuals are no longer travelling to
Syria for short periods: the pattern is that they are staying for the longer term. It was said that:

“While travel to the region for short periods of terrorism-related activity is assessed to have presented a threat to
national security, prolonged periods spent in theatre increase that threat significantly.”

A similar point was made in the Amended First National Security Statement.

364. Mr Squires, on the Commission's understanding, did not submit that the assessment cited above is wrong.
What he submitted is that it failed to present the full picture, namely evidence bearing on the risk presented by the
earlier returnees in the light of what was known about them in the period after their return, alternatively (applying
Tameside) evidence that ought with reasonable diligence to have been obtained.

365. Mr Squires drew the Commission's attention to paras 6ff of the third witness statement of Ms Gareth Peirce.
There, she made the following points:

(1) Significant numbers have returned and there is no evidence that they constitute a threat.

(2) Various figures are in the public domain and these relate to slightly different dates, but overall anything between
700-900 individuals went to Syria and approximately half have returned.

(3) The Government's CONTEST report dated June 2018 states that the majority of returnees came back in the
early stages of the conflict, were assessed on their return, and a significant proportion were no longer assessed to
be a risk.

366. Mr Squires' essential point was that the Secretary of State should have been given this information, and that
without it the picture presented to him was unbalanced if not onesided.

367. According to the Amended First National Security Statement:

“38. At paragraph 69 of BEGUM's grounds of appeal, it is asserted that the Secretary of State was provided with no
information about individuals who travelled to Syria and went on to pose no threat to national security.

39. The ISIL Statement refers to the numbers of those known to have travelled to Syria and ISIL-controlled territory
in Iraq from the UK. The statement indicates, as of November 2016, the numbers known to have travelled to Syria
and ISIL-controlled territory in Iraq from the UK. The Statement also expressly referred to, and took account of,
those who had returned to the UK, setting out current estimates of those in theatre and those who had returned (of
whom, the number assessed to be ISILaffiliated). The statement further explains that the majority of those who had
already returned from ISIL-controlled territory were considered to be of lower risk, compared with those who
remained in theatre.”

368. The ISIL Statements in OPEN do not set out these figures. The Commission addresses this issue in
CLOSED, although can say in OPEN that nothing really turns on exact numbers.

369. The first issue to determine is the nature of the legal test that applies to a fairness issue of this nature. Mr
Squires submitted that para 80 of B4 is incorrect and that it is for the Commission, and not for the Secretary of
State, to determine whether relevant material was placed before the decision-maker in a fair and balanced fashion.

370. The Commission continues to believe that B4 contains an accurate statement of the law but it is appropriate to
add the following elements of clarification and qualification.

371. B4 cited extensively from the decision of the Divisional Court (Elias LJ and Simon J) in R (oao Khatib) v SSJ

_[2015] EWHC 606 (Admin), paras 49ff in particular. B4 did not review the various authorities anthologised by_
Fordham J in his Judicial Review Handbook, 7th edition, paras 51.2.1 and 51.2.2, as perhaps it should have done.
Interestingly, Khatib has not found its way into these paragraphs.


-----

372. In Khatib itself, the Divisional Court found, at para 56, that the decision-maker was not given a fair and
balanced picture of the Claimant's progress in prison. The language of para 56 was not explicitly that of
Wednesbury. The same may be said of many of the cases listed by Fordham J.

373. However, in Khatib itself and all the other cases of which the Commission has refreshed its memory since the
hearing it will have been plain and obvious to the court that the material presented to the decision-maker was not
fair and balanced. Essential matters were not included and/or such matters as were mentioned were presented in
an unfair and distorted fashion. Whatever the correct characterisation of the legal test, the court was well-placed to
intervene in the exercise of its supervisory jurisdiction.

374. In a national security case, we consider that the position can rarely be so stark. There may be situations in
which it is possible to conclude for example that essential material was omitted, but the Commission will be slow to
do so. This is because the Commission is not well-placed to decide what is “essential” or “relevant”, and could not
reach such a decision without at the same time reaching a conclusion about the merits of the national security case
– an area which, generally speaking, is off limits. On the other hand, there may be situations in which it will be plain
and obvious to the Commission that the decision-maker, here the Secretary of State, was unfairly briefed.

375. It follows that B4's analysis of Khatib should be confined to the particular context of appeals under section 2B
of the 1997 Act. It has no wider application.

376. The Secretary of State was told that Ms Begum had travelled to Syria and aligned with ISIL as a child, and
that she had been in ISIL-controlled territory for four years. That was a highly significant factor, because she was
exposed to further radicalisation and desensitisation for a lengthy period of time. Whether or not that placed her in
an atypical category the Commission is not in a position to judge. However, it is in a position to say that it is clear
that the Secretary of State applied his mind to her individual case rather than seek to draw inferential or generalised
conclusions from her occupying any particular category or sub-set of returnees. Furthermore, the Secretary of State
was told in terms that those who went to Syria slightly later, and in particular remained there for a significant period,
were likely to represent a greater risk that those who returned earlier.

377. Mr Squires' real complaint is that the Secretary of State should have been advised, on the basis of the hard
evidence, that the early returnees were not merely a low risk but represented a danger so low that it could
effectively be managed in the community back in the United Kingdom.

378. In the Commission's judgment, there are two essential difficulties with that argument. First, and with respect to
Mr Squires, Ms Begum does not fall in the low/zero risk category appropriate to the early returnees. She remained
in ISIL-controlled territory until the bitter end, and only left through fears for the safety of her unborn child. This
conclusion applies even if one were to accept, which the Secretary of State does not, the gravamen of her case that
she had no choice but to remain.

379. The second essential difficulty is that Mr Squires is seeking to assail the SyS assessment that the earlier
returnees were a low risk as opposed to a zero, or next-to-zero risk. His argument must be that the numbers permit
of only one interpretation. However, the Commission cannot accept that this is so, and in this regard must defer to
the expert assessment of the specialists. The Commission would wish to point out that no evidence is not evidence
of absence: in other words, the absence of evidence that the risk had in fact eventuated is not evidence that there
is, or was, no risk; and it is also relevant that of the earlier returnees who have been assessed, only a significant
proportion, and by no means all, have been assessed as being of no risk.

380. Overall, the Commission cannot accept the argument that the Secretary of State was not given a fair and
balanced picture, and Ground 6 fails.

381. Further reasons for dismissing Ground 6 are set out in the CLOSED judgment (the Special Advocates
advanced more wide-ranging submissions on the fair and balanced issue).

GROUND 7: THE PSED


-----

382. Section 149(1) of the EqA 2010 provides:

“A public authority must, in the exercise of its functions, have due regard to the need to –

(a) eliminate discrimination, harassment, victimisation and any other conduct that is prohibited under this Act;

(b) advance equality of opportunity between persons who share a relevant protected characteristic and persons
who do not share it; and

(c) foster good relations between persons who share a relevant protected characteristic and persons who do not
share it.”

383. Sub-paragraph (b) does not apply in relation to an immigration and nationality function. The present case is
concerned with (a) and (c).

384. Section 192 provides:

“[a] person does not contravene this Act only by doing, for the purpose of safeguarding national security, anything
that it is proportionate to do for that purpose.”

385. The Commission considers that the section 192 exemption should be addressed before the substantive
merits. If the conclusion must be that the exemption applies, the substantive issue will then merit briefer
consideration.

386. Mr Squires' submission was that the exemption did not apply in these circumstances. This is because the
[“doing” and the “anything” in section 192 relates to the discharge of any function or duty under the EqA 2010,here](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
the function under section 149, and not to any different function under a separate statute, there the exercise of the
discretionary power under section 40 of the BNA 1981.

387. The Commission cannot accept that argument, essentially for the following reason. Section 149 refers to “the
exercise of its functions” in the broadest possible terms. On the natural and ordinary meaning of that section, in the
present case we are concerned with the Secretary of State's functions under section 40 of the BNA 1981. That
much is not in dispute. In our judgment, the “doing” and “anything” in section 192 can only be sensibly understood
on these facts as a reference to the exercise of function under this separate legislation rather than to any obligation
[under the EqA 2010 itself, including the due regard duty under section 149. Thus, section 192 is not looking at the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
[duties and obligations imposed under any provision of the EqA 2010 in relation to which it is imposing an exemption](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
but rather to functions arising elsewhere.

388. Imagine a case of direct discrimination and section 13 of the EqA 2010. A person discriminates against
another if she or he treats that other less favourably because of a protected characteristic. Could section 192 apply
in these circumstances? The answer, obviously, is yes. The “doing” and the “anything” is the performance of the
discriminatory act under contractual, statutory or other powers, most typically arising in the context of employment.
There is no analogue in section 13 to the section 149

“exercise of its functions”. The point is that section 192 provides a complete defence, subject always to
proportionality and the other requirements of the section if, in this context, the public body does or performs a
discriminatory act that would otherwise breach section 13. If that is the correct approach to the interplay between
section 192 and section 13, it must also be the correct approach to section 192 and section 149.

389. Thus, in the present case the focus must be on the Secretary of State's exercise of functions under section
40. That exercise is what he was “doing” for the purpose of section 192. National security is not a complete answer
to this section 149 claim, because the Commission must be satisfied that the section 40 function was exercised in a
proportionate fashion in these circumstances. For the reasons it has given elsewhere, the Commission is so
satisfied.


-----

390. Mr Squires' submission is not, therefore, supported by the natural and ordinary meaning of the section. But
there is a further difficulty. Section 192 refers to “doing” but the breach of section 149 consists in a failure to do,
namely a failure to have due regard. This reinforces the point that section 192 is not casting its eye back to section
149, as Mr Squires would have it, but to whatever “thing” is being done on the facts of the particular case.

391. Finally, we note that in D9 the Commission considered it unnecessary to address the s. 192 issue. Counsel
for D9 had made a rather different point. He submitted that in assessing proportionality the test set out by Simler LJ
in R (Independent Workers Union) v Mayor of London [2020] EWCA 1046, at paras 37-38, should be applied. We
received no submissions about this and must leave the matter there.

392. If, contrary to above, the section 192 exemption does not apply in these circumstances, the Commission's
conclusions on the substantive issue are as follows.

393. First, the Commission applies the law as set out in the well-known cases, in particular Hotak v Southwark LBC

_[2015] UKSC 30; [2016] AC 811and Powell v Dacorum Borough Council [2019] EWCA Civ 23; [2019] HLR 21._

394. Secondly, the Commission rejects the Secretary of State's submission that the relevant impacts are felt
abroad. They are not; they are clearly, and obviously, felt in Muslim communities in the United Kingdom (c.f. R
(Turani) v SSHD [2021] EWCA Civ 248; [2021] 1 WLR 5793) and, in contradistinction to D9 which was an exclusion
case (see para 75 of the judgment in D9) Ms Begum's citizenship at the time the decision was being considered
created an inextricable link with the United Kingdom.

395. Thirdly, the Commission rejects the Secretary of State's submission that the exercise of the section 40 power
does not raise a PSED issue because he was acting in an individual, isolated case and was not applying a general
policy. In the Commission's view, the PSED issue arises because the exercise of the deprivation power against Ms
Begum is, and was, quite capable of having a much wider impact.

396. Fourthly, the Commission is not attracted by Ms Begum's arguments directed to section 149(1)(a). This is
because Islamic fundamentalist terrorism is, and remains, a potent threat and it is hardly surprising that the section
40 power has been used in that context against Muslims – albeit the overwhelming majority do not support
terrorism. It is no real answer to say that the same power has not been used against extreme right-wing terrorism (it
very rarely could be, because the exponents are not dual-nationals), or against Irish extremism, or indeed against
Islamic fundamentalist terrorism in the 1990s. The Commission may take judicial notice of the fact that in recent
times the section 40 power started to be used with vigour after 2002 or thereabouts - and against Islamic
fundamentalist terrorism.

397. Fifthly, the Commission is concerned that there is nothing in OPEN which indicates that the Secretary of State
has addressed his mind to the real issue here, which is that many right-thinking people in this country's Muslim
communities (and beyond) feel that they are being treated as second-class citizens, and/or that their welcome is
somehow contingent. The Commission has received a considerable body of evidence on that topic, and it raises
important issues. It is not an answer to that concern to say that the Secretary of State has paid regard at a general
level to inter-community relations or was given advice that the deprivation of Ms Begum was strongly supported by
a majority of public opinion.

398. However, there is evidence in CLOSED which addresses this issue. The Commission is satisfied that the real
issue was considered.

399. For the reasons set out here and in the CLOSED judgment, Ground 7 fails, even if the Commission were
wrong about the application of the exemption under section 192 of the EqA 2010.

GROUND 9: ARTICLE 8 OF THE ECHR

400. Mr Squires realistically accepted that this Ground would be difficult to advance if Ms Begum had lost all the
way down the line to this point.

401 The Commission has received late evidence from Ms Begum's mother Mrs Aqsa


-----

Begum. Although post-decision evidence it is admissible. For these purposes, the Commission will apply the
general rule that the Convention breach must be considered at the time of this judgment rather than as at 19th
February 2019.

402. The Commission fully understands the profound impact that this deprivation decision has had on Mrs Aqsa
Begum and on Ms Begum's immediate family in the United Kingdom. For these purposes, the focus must be on the
impact resulting from the deprivation rather than from Ms Begum's decision, however that be characterised, to
travel to Syria in 2015.

403. At best from Ms Begum's perspective, Article 8 of the ECHR has only a limited scope in deprivation cases,
particularly when the individual was outside the United Kingdom when the decision was made. For present
purposes, the Commission need only refer to part of para 64 of Lord Reed's judgment in Begum:

“The ECtHR has accepted that an arbitrary denial or deprivation of citizenship may, in certain circumstances, raise
an issue under article 8. In determining whether there is a breach of that article, the court has addressed whether
the revocation was arbitrary (not whether it was proportionate), and what the consequences of revocation were for
the applicant. In determining arbitrariness, the court considers whether the deprivation was in accordance with the
law, whether the authorities acted diligently and swiftly, and whether the person deprived of citizenship was
afforded the procedural safeguards afforded by article

8: see, for example, K2 v UK [2017] 64 EHRR SE 18, para 49-50 and

54-61.”

404. K2 was an admissibility decision. In that case, K2 had Sudanese citizenship and had returned to that country.
He received visits from his wife and family. The Article 8 case was unsustainable on the facts.

405. In the Commission's judgment, particularly if account were taken of this section 2B appeal, the mass of
evidence that has been provided and the weight of submission that has been brought to bear, it is impossible to say
that Ms Begum's deprivation was arbitrary. The rule of law has been applied to Ms Begum's case, in line with the
principles set forth by the Supreme Court.

406. Ultimately, Ground 9 does not add to Ms Begum's case on Grounds 1 and 2, and must therefore fail.

407. For the avoidance of doubt, we have not overlooked the very recent decision of the Court of Appeal in R3 v
SSHD _[[2023] EWCA Civ 169, in particular paras 107-110. This lends further support to the proposition that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67KN-9YV3-RT47-V4SD-00000-00&context=1519360)_
scope of Article 8 in a case such as this is very limited. To the extent that it applies at all (viz. in the context of
arbitrariness and the impact of the deprivation decision on an applicant), we have covered these topics at various
stages of this judgment. We recognise, however, that R3 could not be addressed

by the parties in the instant case, and in these circumstances we note its conclusions but do not treat it as providing
a complete answer to the Article 8 claim.

SIMPLEX

408. As we have already pointed out, the Secretary of State's skeleton argument, but not Sir James in his oral
submissions, invited the Commission to conclude that the outcome would inevitably have been the same absent
any public law error that the Commission has found.

409. The Commission has identified one immaterial error of law during the course of its judgment (Ground 4). We
should make it absolutely clear that had either or both of Grounds 1 and 2 succeeded, this appeal would have been
allowed. Further reasons are set out in the CLOSED judgment. No further consideration of Simplex is either
necessary or appropriate.

NATIONAL SECURITY


-----

410. SyS's core assessment is that Ms Begum travelled voluntarily to Syria and aligned with ISIL. We have set out
our conclusions on the issue of voluntary travel. There can be no real dispute on the OPEN material that Ms Begum
aligned with ISIL, but further reasons appear in the CLOSED judgment. We should also make it clear – as we do in
CLOSED - that the national security assessment addressed other matters.

DISPOSAL

411. The Commission has found this to have been a case of great concern and difficulty. The legal issues have
been challenging and (in respect of Grounds 1 and 2, novel), and the evaluative judgments on the essential
questions often finely balanced.

412. At para 94 of his judgment in the Court of Appeal ([2020] EWCA Civ 918; [2020] 1 WLR 4267), Flaux LJ
stated that one of the topics the Commission would have to consider “is precisely what were the circumstances in
which [Ms Begum] left the UK in 2015”, and should do so in the context of a full and effective appeal. Flaux LJ also
stated that whether Ms Begum left “of her own free will” was also in point. We cannot conduct the sort of “full merits
appeal” that the Court of Appeal had in mind but we have sought to examine this issue as carefully and closely as
we have been able to. Ultimately, however, the Commission has not been able to conclude on Ms Begum's
principal Grounds (i.e. Grounds 1 and 2) that the Secretary of State's judgment that the risk to national security
outweighs her personal interests is wrong in public law terms.

413. For the reasons set out in this OPEN judgment, as well as those contained in the CLOSED judgment that is
being handed down simultaneously, Ms Begum's appeal under section 2B of the 1997 Act must be dismissed.

**End of Document**


-----

