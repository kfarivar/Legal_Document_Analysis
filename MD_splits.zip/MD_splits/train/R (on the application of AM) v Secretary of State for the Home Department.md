# R (on the application of AM) v Secretary of State for the Home Department

 [2021] EWHC 1373 (Admin)

Queen's Bench Division, Administrative Court (London)

Michael Ford QC (sitting as a deputy High Court judge)

25 May 2021Judgment

**Mr Allan Briddock (instructed by Duncan Lewis Solicitors) for the Claimant**

**Mr Simon Murray (instructed by Government Legal Department) for the Defendant**

Hearing date: 28 April 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Michael Ford QC, sitting as a Deputy High Court Judge :**

**Introduction**

1. The Claimant, AM, is an Albanian national, who was born in 1978. He arrived in the UK on a fishing
boat alongside 69 other immigrants on 18 November 2020. On arrival he was identified as an illegal
migrant, arrested by police and detained under immigration powers in Schedule 2 to the Immigration Act
1972 at Southend Police Station. Since then he has been held in immigration detention, so that his current
period in detention is almost six months.

2. AM has made an asylum claim and a claim to be a victim of trafficking, neither of which had been
resolved at the date of the hearing. He was convicted of murder in Albania and served, it appears, 12.5
years in prison there; he denies the offence and claims he was wrongfully convicted. On around 29
December, the Defendant received a report from a medical practitioner, made under rule 35(3) of the
Detention Centre Rules 2001, expressing his opinion that AM may have been the victim of torture and that
continued detention would lead to a deterioration in his mental state. Accepting on the basis of the report
that AM was an adult at risk, at level 3, the Defendant decided to continue his detention, for reasons
initially set out in a letter dated 6 January 2021.

3. The judicial review claim, challenging the lawfulness of AM's detention, was issued on 15 February
2021. It sought the release of the Claimant, a declaration, damages for false imprisonment and interim
relief. The application for interim relief was refused by John Howell QC, sitting as a Deputy Judge of the
High Court, by Order dated 23 February 2021. The Judge also ordered that the application for permission
should be dealt with as soon as practicable. By Order dated 19 March 2021, David Lock QC, sitting as a
Deputy High Court Judge, granted permission and ordered an expedited hearing.

4. At the hearing before me, AM's challenge was based on the lawfulness of his detention during the
period following the date of receipt of the rule 35 report on 29 December, allowing a short period for the
Defendant to make arrangements to release AM. There were two grounds of challenge: first, that his
detention was in breach of the Hardial Singh principles, derived from R v Governor of Durham Prison ex
_parte Hardial Singh [1984] 1 WLR 704; and, second, that his detention was in breach of the Defendant's_


-----

policies relating to particularly vulnerable detainees. I was greatly assisted by the focused written and oral
submissions of both counsel.

5. No anonymity order has been made in respect of AM but an application was made for anonymity, to
which Mr Murray did not object.

**Relevant Facts**

6. There were many documents before me, including the records of the detention reviews and the GCID
notes. Below I summarise the critical facts, relevant to what was known to the Defendant at the time(s) in
respect of which the lawfulness of the detention was challenged. Owing to how the challenge was put in
the grounds for judicial review, I have divided the facts into the period before the rule 35 report and the
period afterwards.

7. Prior to the rule 35 report. On 19 November, after arrival in the UK, AM was transferred to immigration
detention. He told an immigration officer that, while in Belgium, he overhead people discussing about
leaving for England on a boat, and was told he needed to pay £2000-3000 but he did not pay anything and
was only supposed to pay on arrival in the UK. He provided originals of documents, in Albanian, giving
details of his criminal conviction in Albania for murder. Once translated into English on 10 February 2021,
these documents provided extensive information to the Defendant about AM's conviction for “Intentional
Murder”, contrary to the Albanian Criminal Code, including the circumstances of the killing of the female
victim in 1997, the evidence of witnesses about the murder, and details of the court proceedings.

8. AM claimed asylum on 20 November. On the same day, his first detention review took place which
referred to a medium risk of absconding because of his lack of family ties in the UK. An assessment on 23
November recorded that there were no concerns about his health or vulnerability and noted that because
Albania is NSA country, meaning a country listed in s.94 of the Nationality, Immigration and Asylum Act
2002, he would be removed within a reasonable period of time if his asylum claim were refused.

9. AM was inducted at Yarl's Wood detention centre on 26 November. He answered “no” to whether he
had been subject to exploitation, such as forced labour, in his country of origin or on the way to the UK but
answered “yes” to whether he had been a victim of torture, saying he had been bullied and beaten by
police officers while in prison.

10. There is some confusion about the exact date of AM's asylum screening interview, but it was around
the end of November. At that interview, he gave details of his journey to the UK via Germany, Sweden and
Belgium. He again denied ever being exploited, such as being forced to carry out work. He said he had
claimed asylum in Sweden, and repeated that he did not have to pay anything to come to UK.

11. In relation to his why he had come to the UK, AM said this was because of a “blood feud” which also
prevented his returning to Albania. According to the notes, in 1997 he said he was accused of murder and
sent to prison between 2006 and 2020. AM said he was at risk of being killed by the family of victim if he
returned, explaining that it was the former police officer who prosecuted him in 2006 who in fact had killed
the victim. He also explained he had been sentenced to 15 years for the murder conviction but only served
12.5 years. This matter came to the attention of the officer who reviewed AM's detention on the same day.

12. A detention review took place on 2 December. The authorising officer said that negative immigration
factors outweighed the presumption in favour of release, referring to the risk of absconding and the
potential risk to the public arising from AM's conviction. The decision was taken to maintain detention until
his asylum interview on 8 December.

13. On 7 December an ad hoc review took place because AM had been refusing food. On the following
day, 8 December, the claimant refused to be interviewed at his asylum interview, saying he had been on a
hunger strike for the past seven days. The notes also record his saying he was unwell. On 11 December,
the notes record that he refused to come down to a second attempted asylum interview, saying that he
needed to see a doctor. The day before he had complained to an officer of health problems and said he
was not willing to attend his asylum interview without a letter from the police, which he had requested.


-----

14. Following these refusals AM was referred by the Defendant to IRC Healthcare, who advised that AM
did not have a chronic medical condition, although he had complained of insomnia and stress, and he
could be interviewed “if he is feeling well enough on the day”. As a result of his refusal to be interviewed,
on 19 December a letter was sent to AM, requiring him to produce a witness statement for his asylum
claim, to which he did not respond.

15. In the meantime, on 13 December the Defendant obtained information from Europol, giving the
following criminal record information about AM: (i) that in 2006 a warrant was issued because of what were
described as offences of “Theft” and “Meaning of Collaboration”; and (ii) in 2009 he had been convicted of
“Murder with Intent” and sentenced to 15 years' imprisonment.

16. It seems from around late November the Defendant had been making e-mail enquiries of the Single
Competent Authority (“SCA”), the independent body responsible for identifying victims of modern slavery
under the National Referral Mechanism (“NRM”), set up under the **_[Modern Slavery Act 2015. The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
Defendant's staff wanted to know when the SCA could process NRM decisions about the Albanian
migrants, including AM, who arrived together on the same boat. These documents were only disclosed at
the hearing, and were not referred to in the witness statement of Ms Vaughan; but Mr Briddock did not
object to their production.

17. The NRM proceeds in three stages: (i) a “Reasonable Grounds” decision by the SCA when the SCA
suspects an individual is a victim of modern slavery, which includes human trafficking and forced labour;
(ii) if that decision is positive, a 45-day “reflection period”; (iii) at the end of the 45-day period, a “Conclusive
Grounds” decision, determining whether on the balance of probabilities the individual is a victim of modern
**_slavery (see the_** **_Modern Slavery Statutory Guidance, Version 2.1, at p 52). In response to a question_**
about the anticipated timetable for dealing with the migrants on the boat who had received a positive
Reasonable Grounds decision, Stephanie Lee, Head of Decision Making in the SCA, told the Defendant
that, while it was difficult to provide a specific timetable, it was the SCA's intention to expedite the process
and they “would anticipate that [the Conclusive Grounds decisions] would be concluded with 3 months of
45-day reflection period ending” (see e-mail of 18 December 2020).

18. At that stage AM had not been referred into the NRM. That occurred four days later, on 22 December,
after details had been provided by AM, on the basis it was considered he might be a victim of trafficking.
His allegations were that he had been trafficked to Greece as a teenager, and beaten and forced to work
there. His reports of psychological distress led to an ACDT being opened for him (Assessment Care in
Detention and Teamwork) and increased observations of him.

19. Following a further detention review, on 17 December the authorising officer said that AM was not an
adult at risk and the presumption of release was outweighed by two factors: first, there were “strong
grounds for believing the individual would fail to comply with any bail restrictions in the UK”, given his illegal
entry and his “insufficient close ties in the UK”; and, second, his murder conviction gave rise “to a potential
risk to the public based on the severity and gravity of conviction and sentence”.

20. The rule 35 report and subsequent. The claimant's “at risk” status changed soon afterwards because
on 24 December a report was prepared by Dr Irfan Sayed, an independent medical who prepared a report
under rule 35 of the Detention Centre Rules. The report said that Dr Sayed had concerns AM may have
been a victim of torture, and assessed him as a “level 3" adult at risk. Dr Sayed referred to him being
attacked between 1991-95 while in Greece, and being used by agents to beg in the street. It also said he:

“was attacked by the police (who killed someone) in 2006 in Lushnja, Albania, in prison over 14 years - he
was accused of murdering someone and beaten into a forced false confession. His head was hit [sic]
against the wall and was hit with batons. His nose was broken. He was imprisoned for 14 years. He
attempted to kill himself on 2 occasions in prison”

The report went on to refer a scar, which Dr Sayed, said might be due to the history, and said that M was:

“suffering with depression, nightmares, flashbacks and anxiety. Since being detained his condition has
worsened and he has started medication for depression and insomnia. He has attempted to kill himself on


-----

2 occasions while in detention. He is under the care of the mental health team here in detention - he is on
ACDT.

My opinion is that his continued detention will lead to deterioration in his mental health due to the history
given and the nature of being detained with an unknown status.”

21. On 30 December, the SCA made a positive Reasonable Grounds decision in respect of AM, meaning
he was subject to the 45-day “reflection period” before any Conclusive Grounds decision could be taken.
On the same day, a “bully log” was opened because of allegations that AM had been bullying another inmate. This led to him being the subject of observations, which were recorded in the log. According to the
later detention reviews, this log was closed on 28 January because no further issues were reported to staff
and because the alleged victim was released.

22. Having received Dr Sayed's report on 29 December, on 6 January the Defendant conducted a risk
assessment and review in light of the rule 35 report. The decision taken was to maintain detention, for
reasons set out in the review and in a letter to AM dated 6 January 2021. The review assessed his risk of
absconding as high because he had no family ties in the UK and because his asylum claim was said to be
“opportunistic”. The risk of harm was also assessed as high because of his murder conviction. The review
gave no timetable for resolution of his claims to asylum or under the NRM.

23. The letter accepted that the evidence provided meant that AM was an “adult at risk”, and listed positive
factors in favour of release, including AM's vulnerability and his positive Reasonable Grounds
determination. But it considered these were outweighed by negative factors. It stated:

“The doctor attending for your Rule 35(3) Report has stated his opinion that continued detention will
lead to deterioration in your mental health due to the history given and the nature of being detained with
an unknown status. You are assessed at level 3 of the Home Office's Adults at Risk in Detention Policy,
and your detention can continue to be considered.

It is accepted that you do present a significant public protection concern as you have committed a serious
offence. In Albania, you were convicted for murder in 2006 and sentenced to 15 years' imprisonment, of
which you served 12.5 years.

You  were  released from  prison  in  January 2020. You  have  refused  to accept responsibility for
the crime for which you have been convicted in Albania and the Home Office considers that there is
therefore an increased likelihood that you will re-offend. The Home Office considers that there is a medium
risk that you will re- offend and that the harm would be high.

Conclusion

Therefore, when balancing the indicators of vulnerability against the negative factors highlighted above, it
is considered that the negative factors outweigh the risks in your particular circumstances. Accordingly, a
decision has been made to maintain your detention at this time but this will be regularly reviewed under
chapter 55 of the Enforcement Instruction Guidance and the Adults at Risk Policy”

24. Further detention reviews took place throughout the period January to March, as explained by Ms
Vaughan in her witness statement.

25. On 14 January, the First-Tier Tribunal refused to grant AM bail on the basis that he would fail to
comply with conditions of bail and would pose a risk to the public. In her reasons for resisting the grant of
bail, the Defendant said that the claimant could be removed to the UK within a reasonable time frame if his
asylum application were refused, but said nothing about an expedited timetable for dealing with the
Conclusive Grounds decision under the NRM.

26. On 10 February, the documents which AM had provided about his criminal convictions were translated
into English, meaning the Defendant now had more details about these: see paragraph 7, above.

27. Following a pre-action protocol letter received on 25 January, in a reply dated 10 February the
Defendant said that the 45-day reflection period would expire on 13 February and the Conclusive Grounds


-----

decision was being “actively progressed”. The application for judicial review was lodged on 15 February,
and included an application for interim relief.

28. On 17 February, a Case Progression Panel (“CPP”) – a body appointed to review and scrutinise
detention after three months in order to minimise the risk of unlawful detention - recommended AM's
release, and that the Defendant liaise with probation in respect of release arrangements. This
recommendation was considered and rejected by the Defendant on 22 February. The decision referred to
the murder conviction, which had been “corroborated and confirmed”, saying it gave rise to a “credible and
considerable risk to the public”. On the timetable for release, it stated that the Conclusive Grounds decision
was awaited “and the SCA confirm this is being treated as a priority”, though it gave no timetable.

29. The interim relief hearing took place before John Howell QC, sitting as a Deputy High Court Judge, on
23 February. At the hearing it is not in dispute that it was stated on behalf of the Defendant that the
Conclusive Grounds decision could be dealt with in six months (it is not clear why no reference was made
to the communication in the e-mail of 18 December). However, the GCID notes for 23 February, made
following the hearing, record a “direction” from the court that there should be an up-dated risk assessment,
later adding “the CG decision is being expedited by the [SCA] and it is anticipated it will be made within 3
months”.

30. At around the same time, the notes record AM talking about suicide. He had previously seen a mental
health nurse on 21 December, reporting flashbacks. On 25 February, a member of the Detention
Engagement Team noted that AM was “currently experiencing trauma related symptoms, linked to his past
torture experiences and I am concerned that ongoing detention will lead to further deterioration in his
mental health and increase his risk of suicide and self harm”.

31. Owing to comments of the Judge at the interim relief hearing, on 25 February the Defendant
conducted a further evaluation of the risk posed by AM. It once more referred to an anticipation that the
SCA Conclusive Grounds decision would be made within three months. It stated:

“It is acknowledged that he has an outstanding asylum claim and conclusive ground decision relative to his
trafficking claim. However, the individual has been non-compliant with the asylum process and
consequently has prolonged his period of detention through his own actions. It is apparent given his
behaviour in the IRC, that unless detained his asylum claim cannot be progressed;

The CG decision is being expedited by the Single Competent Authority and it is anticipated will be made
within 3 months;

The individual has a serious offending history and information obtained from the Albanian authorities via
EUROPOL confirms he has a conviction for Murder for which he was sentenced to 18 years imprisonment.
Given the severity of this crime, the individual is considered to pose a significant risk to others.

The negative immigration and public protection factors as highlighted above outweigh the presumption in
favour of release and detention is maintained to await the outcome of the CG decision and if negative, to
progress the asylum claim.”

32. On 26 February it seems that the Claimant provided the statement which was relied on as his
evidence in these proceedings. It was provided for the purpose of his claim being dealt with in the NRM. In
it, the Claimant explained that he had been trafficked to Greece and forced to work there.

33. On 3 March the CPP again recommended release, this time with measures such as reporting, curfews
or tagging, because there was “no prospect of imminent removal” in light of the pending Conclusive
Grounds and asylum decisions. This recommendation was rejected by an employee of the Defendant on 4
March. The foremost reason given was public protection in light of the murder conviction. The review
stated:

“I note the individual presently engages level 3 of the AaR in detention policy due to a Rule 35 torture
allegation report. He is suffering with depression, nightmares, flashbacks and anxiety. Since being
detained he has been provided medication for depression and insomnia. [AM] is under the care of the


-----

mental health team and a VACP has also been opened, though there has been no further indication from
IRC that the individual cannot continue to be managed.

…..

[AM] entered the UK illegally having boarded a vessel with 68 other ALB nationals from Belgium. It is
considered that given this attempt to illegally enter, and given his adverse criminal conviction, he is a
credible risk of harm to the public.

Notwithstanding, their [sic] barriers can be resolved in a reasonable timescale and steps are being taken to
ensure this is facilitated and effected as efficiently as possible. Contact has been made with the SCA to
expedite the Conclusive Grounds decision. [AM] has repeatedly failed to comply with the asylum process
and consequently prolonged his detention.

The negative immigration and public protection factors as highlighted above outweigh the presumption in
favour of release and detention is maintained to await the outcome of the CG decision and if negative, to
progress the asylum claim. The individual's case remains subject to regular detention reviews and CPP
oversight and his case is being closely monitored and managed by colleagues in the detention centre, with
respect to his health and wellbeing.”

34. The summary grounds of defence served on 8 March repeated that the Conclusive Grounds decision
could be made within three months (paragraph 36).

35. On 16 March, the Defendant received further information from Albania about the Claimant's criminal
records. These stated that, in addition to his murder conviction, he had been sentenced to two years'
imprisonment for theft; that he had been sentenced for another offence for one year and four months (it is
not clear if this was also for theft); that he was initially found not guilty of “premeditated murder” but,
following an appeal, he was found guilty in 2009 and sentenced to 15 years in a high security prison; and
that in 2016 he was found guilty of introduction and possession of a prohibited item while in custody, for
which he was sentenced to eight months' imprisonment (There was also further mention of a sentence of
four years and four months of imprisonment).

36. A further review of detention took place on 24 March. In relation to the estimated timetable for release,
this review said:

“A request was made at Director level to the [SCA] to prioritise and expedite the Conclusive Grounds
decision...The SCA has agreed to fast-track the CG decision. When James Tonks, NRC Barrier Team,
contacted them on 24 March 2021, for further information, they advised they were actively working on the
case and committed to the expedited timetable of three months (the average CG conclusion time is 12
months+)

Therefore the timescale for removal can be estimated,

24 May 2021 - CG decision

27 May 2021 - asylum decision concluded.

Provided that the asylum decision is refused and certified, removal directions can be set providing a 5
working day notice period.”

After referring to the time to process the Conclusive Grounds decision, the authorising officer said that
AM's health needs “can and are being managed effectively by the health team in IRC”. The officer
considered that the presumption in favour of release was outweighed by overriding public protection
factors.

37. The latest detention review I saw was dated 7 April 2021. It adopted similar reasoning to the one on 24
March. It noted that AM refused to attend a re-arranged asylum interview on 7 April. It repeated the same
envisaged timetable for the Conclusive Grounds decision. It set out the claimant's medical history,
including comments he had made about suicide. The assessment was he had a high risk of absconding
because, among other matters, it was considered he “does not have an incentive to comply with bail


-----

conditions through a genuinely held belief that his immigration applications are substantial and likely to be
successful”, adding that he had no close family associations in the UK. The risk of harm to the to the public
was assessed as high in view of his criminal history, reinforced by his bullying while in detention, as was
the risk of reoffending.

38. The decision of the authorising officer on 8 April was that detention remained appropriate and
proportionate. The reasons against release were said to be the “overriding public protection factors”. The
office said that if AM had been convicted of murder in the UK, the public protection factors would prevail “in
light of the assessment that removal can reasonably be achieved within the next three months”. He
considered the fact that AM had denied his guilt as a psychological indicator that increased the risk of a
future offence. The recent information about a theft conviction and an additional eight-month sentence
while serving in prison indicated he was a “persistent offender”. The conclusion was that:

“detention is deemed appropriate and necessary as there is a realistic prospect that [AM's] removal can be
enforced in a reasonable period of time and the public protection factors in this case outweigh the
presumption of release”.

39. On 18 April 2021, AM was found to have a class A drug in his possession while in detention, recorded
as white powder which tested positive for cocaine. According to Mr Briddock, the Claimant contends this
was codeine.

40. The claimant was due to attend an asylum interview on 30 April, two days after the hearing.

**The Relevant Legal Principles**

41. The legal principles were not significantly in dispute. Mr Briddock accepted that the Defendant had a
right to detain AM under powers in the _[Immigration Act 1971. There were two areas of relevant law: the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
_Hardial Singh principles, and the duties on the Defendant to comply with her own published policies._

42. The well-established Hardial Singh principles reflect the common law rules that detention is prima facie
unlawful and that powers of detention are restrictively construed. There is no material difference between
these principles and Article 5 of the ECHR. They were conveniently summarised by Lord Dyson in _R_
_(Lumba) v Secretary of State for the Home Department [2011] UKSC 12 [2012] 1 AC 245 at [22], adopting_
his earlier summary from R (I) v Secretary of State for the Home Department [2002] EWCA Civ 88, in the
following terms:

“(i) The Secretary of State must intend to deport the person and can only use the power to detain for that
purpose.

(ii) The deportee may only be detained for a period that is reasonable in all the circumstances.

(iii) If, before the expiry of the reasonable period, it becomes apparent that the Secretary of State will not
be able to effect deportation within that reasonable period, he should not seek to exercise the power of
detention.

(iv) The Secretary of State should act with reasonable diligence and expedition to effect removal.”

The claimant only relied on (ii) and (iii) here.

43. As for principle (ii) of _Hardial Singh, in_ _Lumba at [104] Lord Dyson cited and approved his earlier_
guidance in R (I) at [48] on what constitutes a reasonable period in all the circumstances:

“It is not possible or desirable to produce an exhaustive list of all the circumstances that are, or may be,
relevant to the question of how long it is reasonable for the Secretary of State to detain a person pending
deportation pursuant to paragraph 2(3) of Schedule 3 to the Immigration Act 1971. But in my view, they
include at least: the length of the period of detention; the nature of the obstacles which stand in the path of
the Secretary of State preventing a deportation; the diligence, speed and effectiveness of the steps taken
by the Secretary of State to surmount such obstacles; the conditions in which the detained person is being
kept; the effect of detention on him and his family; the risk that if he is released from detention he will
abscond; and the danger that, if released, he will commit criminal offences.”


-----

As Lord Dyson later pointed out, the question of what is a reasonable period is a “fact specific exercise”
and the “Hardial Singh principles should not be applied rigidly or mechanically” (Lumba [115]).

44. The risk of absconding is a factor of “paramount importance”, which is likely of often to be decisive. For
if a person absconds that will defeat the primary purpose for which Parliament conferred the power to
detain and for which a detention order was made in an individual case: see Lord Dyson in Lumba [121] and
Lord Toulson in R (A) v Secretary of State for Home Department [2007] EWCA Civ 804 [54].

45. A failure to accept voluntary repatriation may be relevant evidence of a likelihood of absconding. But it
is not evidence relevant to the risk of absconding where a person has issued proceedings challenging
deportation on the ground that, for example, he would face the risk of persecution on return: see Lord
Dyson in _Lumba [125]-[127]. Even for those who have not issued proceedings challenging their_
deportation, it is a factor of limited weight and not a trump card because otherwise “the refusal of an offer
of voluntary repatriation would justify as reasonable any period of detention”: Lord Dyson in Lumba [128],
citing from his earlier judgment in R (I).

46. The factors relevant to what is a reasonable period of detention listed by Lord Dyson in Lumba include
the effect of detention on the individual and his family. A person's psychiatric condition is relevant to
whether the length of detention is reasonable, where detention causes or contributes to that condition: see,
for example, R (ASK) v Secretary of State for the Home Department _[2019] EWCA Civ 1239 [59]._

47. As for principle (iii) above, once it is clear that the Secretary of State will not be able deport the
detained person within a reasonable period, having regard to the time already spent in detention, the
detention is unlawful: see Lord Dyson in _Lumba [103]: “if there is no realistic prospect that detention will_
take place within a reasonable time, then continued detention is unlawful” [103].

48. Other ways of putting the test are that there must be a “sufficient prospect” of removal to warrant
continued detention: see Richards LJ in R (MH) v Secretary of State for Home Department [2010] EWCA
_Civ 1112 [64] and in R (Muqtaar) v Secretary of State for Home Department [2013] 1 WLR 649[37]._

49. But the state is not required to identify the exact timescale within which removal can be effected.
Rather, “there can be a realistic prospect of removal without it being possible to specify or predict the date,
or period within which, removal can reasonably be expected to occur, and without any certainty that
removal will occur at all”: see Richards LJ in _Muqtaar [37]-[38]. In accordance with the_ _Hardial Singh_
principles, the duty to release arises where it is “apparent” that there is no real prospect of removal within a
reasonable time. As Richards LJ put it in applying principle (iii) in Muqtaar at [36].

“I see no reason for differing from the conclusion reached by the deputy judge on this issue. At the time of
receipt of the rule 39 indication there was a realistic prospect that the ECtHR proceedings concerning
removal to Somalia would be resolved within a reasonable period: it was possible but was not apparent
that they would drag on as in practice they did. Nor was it apparent that the ECtHR's final decision would
be such as to prevent the appellant's removal. I stress “apparent”, because that is the word used in the
approved formulation of Hardial Singh principle (iii) and in my view it is important not to water it down so as
to cover situations where the prospect of removal within a reasonable period is merely uncertain.”

50. It is for the court itself to decide as primary decision-maker whether the detention was or will be for a
reasonable length in accordance with the Hardial Singh principles: see R (A) per Toulson LJ [61], Keene LJ

[71]-[75]. For this purpose, both parties agreed with the summary of Jay J in in AXD v Home Office [2016]
_EWHC 1133 (QB) [176]:_

“In unlawful detention cases, the court does not conduct a _Wednesbury review but assumes the role of_
primary decision maker: See _R(A) v SSHD [2007] EWCA Civ 804, per Toulson LJ at para 90. The court_
can take into account any facts that were known to the Defendant at the time, even if they did not feature in
the reasons for the detention that were furnished: see R(MS) v SSHD [2011] EWCA Civ 938. Hindsight is
no part of the exercise: see _R(Fardous) v SSHD [2015] EWCA Civ 931. The weight to be given to the_
Defendant's view is a matter for the court, although certain issues are more within the expertise of the
executive than the judiciary, for example the progress of diplomatic negotiations and the attitude of other


-----

countries to accepting returnees. I would add that in my judgment the Defendant knows more than judges
sitting in this jurisdiction about the absconding risk of immigration detainees.”

51. If there is a breach of the Hardial Singh principles, the Defendant is entitled to a short period of grace
before detention is unlawful. In FM v Secretary of State for the Home Department [2011] EWCA Civ 807,
Pitchford LJ said at [60]:

“I have already expressed my opinion that the test for the lawfulness of a period of detention is one of
reasonableness. The obligation of D is to cease detention when it becomes clear that detention is no
longer required to effect removal but, in my view, common sense demands that a short period of grace is
required for the decision-making process to take place which _may include a decision as to the_
management of the detainee on release.”

52. A failure by the Defendant to follow her own published policy will amount to an error of law, unless
there is good reason not to do so: Lord Dyson in Lumba [26]. While the meaning of the policy is a question
of law for the court, a discretionary decision to detain under a policy can only be challenged in accordance
with ordinary public law principles, to see if the decision-maker acted within the proper limits of that power:
see Hickinbottom LJ in ASK [54]. Neither of these principles was in dispute.

**The Relevant Policies**

53. I was referred to three relevant policies.

[54. The first was “Immigration Act 2016: Guidance on Adults at Risk in Detention Centres” dated July](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)
2018. It is statutory guidance issued under s.59 of the Immigration Act 2016, specifying the matters to be
taken into account in determining whether a person would be particularly vulnerable to harm if detained
and, if the person is particularly vulnerable, whether he or she should be detained. There is a presumption
that detention will not be appropriate for persons considered to be “at risk” (paragraph 3). Where there is
professional evidence (e.g. from a medical practitioner stating that the person is at risk and detention is
likely to cause harm, the individual is classed as “level 3" (paragraph 9).

55. Paragraphs 13-15 of the Guidance state:

“13. The presumption will be that, once an individual is regarded as being at risk in the terms of this
guidance, they should not be detained. However, any risk factors identified and evidence in support, will
then need to be balanced against any immigration control factors in deciding whether they should be
detained.

14. The immigration factors that will be taken into account are:

    - Length of time in detention – there must be a realistic prospect of removal within a reasonable period.
What is a “reasonable period” will vary according to the type of case but, in all cases, every effort should be
made to ensure that the length of time for which an individual is detained is as short as possible. In any
given case it should be possible to estimate the likely duration of detention required to effect removal. This
will assist in determining the risk of harm to the individual. Because of their normally inherently short
turnaround time, individuals who arrive at the border with no right to enter the UK are likely to be detainable
notwithstanding the other elements of this guidance.

     - Public protection issues – consideration will be given to whether the individual raises public protection
concerns by virtue of, for example, criminal history, security risk, decision to deport for the public good.

    - Compliance issues - an assessment will be made of the individual's risk of abscond [sic], based on the
previous compliance record.

15. An individual should be detained only if the immigration factors outweigh the risk factors such as to
displace the presumption that individuals at risk should not be detained. This will be a highly case specific
consideration.”

56. The second relevant policy (the “Policy”) is entitled “Adults at Risk in Immigration Detention” (Version
5.0, March 2019). It is internal guidance for Home office staff, on how to assess whether a person is an


-----

“adult at risk”. It makes clear that if there is no realistic prospect of release within a reasonable timescale,
the individual should be released (p 13). It adds:

“In cases in which there is such a prospect [of release within a reasonable time], and in which the individual
is at risk in the terms of this policy, the decision makers should carry out an assessment of the balance
between the risk factors and the immigration factors. this should involve a weighing of the evidence-based
level of risk to the individual against:

     - how quickly removal is likely to be affected

     - the compliance history of the individual

     - any public protection concerns.”

57. The Policy goes on to give further guidance on the public protection issues and states that the
decision-maker should take into account, among other factors, the following (p 15):

“- is the individual a foreign national offender (FNO)

     - if so, how serious was the offence or offences

    - is there available police or National Offender Management Service (NOMS) evidence on the level of
public protection concern”

The policy also says an assessment must be made of whether an individual is likely to leave the UK
voluntarily or “whether the individual is likely to be removable only if they are detained for that purpose” (p
15).

58. The Policy goes on to give more specific guidance for weighing risk factors and immigration factors in
relation to different categories of at risk individuals. For those, such as AM, who are assessed as a “level 3"
risk, it states:

“Level 3

Where on the basis of professional and/or official documentary evidence, detention is likely to lead to a
risk of harm to the individual if detained for the period identified as necessary to effect removal, they
should be considered for detention only if one of the following applies:

     - emoval has been set for a date in the immediate future, there are no barriers to removal, and escorts and
any other appropriate arrangements are (or will be) in place to ensure the safe management of the
individual's return and the individual has not complied with voluntary or ensured return

     - he individual presents a significant public protection concern, or if they have been subject to a 4 year plus
custodial sentence, or there is a serious relevant national security issue or the individual presents a current
public protection concern.

It is very unlikely that compliance issues, on their own, would warrant detention of individuals falling into
this category. Non-compliance should be taken into account if there are also public protection issues or if
the individual can be removed quickly.”

The Defendant here relied on the “significant public protection concern” as the justification for detention
under the Policy.

59. The third relevant policy was the statutory guidance on **_modern slavery for England and Wales,_**
issued under s.49 of the **_Modern Slavery Act 2015 and aimed at staff of the SCA when they take_**
decisions on whether an individual is a potential victim of modern slavery for the purpose of the NRM. The
guidance that where individuals are held in detention “a positive Reasonable Grounds decision does not
require the individual to be released where there are reasons of public order not to do so” (paragraph
15.30). The parties agreed that a decision under the NRM must be taken before any decision on an asylum
application.

**Ground (1): Breach of Hardial Singh Principles**


-----

60. This ground relied on _Hardial Singh_ principles (ii) and (iii). It was, in summary, that AM's detention
became unlawful shortly after the production of the rule 35 report, allowing a period of grace for making
arrangements to release him, because there was no realistic prospect of his removal within a reasonable
period of time. Although the grounds refer to both principles, in his arguments Mr Briddock focused on
principle (iii); but he relied on principle (ii) to say that the detention had become unreasonable by the date
of the hearing.

61. The legal principles were not significantly in dispute, but the parties disagreed about the approach I
should take in applying them. Mr Briddock invited me to look sequentially at three different periods of
detention and decide whether each such period complied with the _Hardial Singh_ principles. Mr Murray
resisted that approach and sought to rely on matters relevant to detention which post-dated the relevant
periods.

62. I consider the logic of the passage in _AXD, to which both parties agreed, supports Mr Briddock's_
approach, which accords with the analysis I have seen adopted in other cases. Because the approach is
not an exercise in hindsight, I should look at the period(s) of detention and decide, in light of the
information before the Secretary of State at the time, whether the detention was lawful in accordance with
the Hardial Singh principles.

Period (1) - 29 December to 23 February

63. This is the period from around the receipt of the rule 35 report and the positive “Reasonable Grounds”
decision until the interim relief hearing. The argument for AM was that during this period it was apparent to
the Defendant that removal of AM could not take place in a reasonable period of time.

64. Mr Briddock fairly accepted that, from the extensive GCID notes, it appeared at some time in late
February there was evidence of an arrangement for an expedited timetable to take the Conclusive Grounds
decision. There was, for example, a reference to an anticipation that this decision would be made within
three months in the case notes for 25 February. But the notes also indicated that, without expedition, such
decisions ordinarily took longer than 12 months (see e.g. the notes for the review on 24 March). In light of
the delays in the system, Mr Briddock argued that until an expedited timetable was fixed, the Defendant
must have known that there was no realistic prospect of AM's asylum application being dealt with for at
least a year, amounting to a breach of Hardial Singh principle (iii).

65. Mr Briddock supported this primary argument with other factors, including the assessment in the rule
35 report and in subsequent notes that AM was an adult at risk who was suffering serious mental
difficulties, including thoughts of suicide, and whose condition was deteriorating in prison. These were
highly relevant to the question of what was a reasonable period of detention in respect of AM.

66. The question under _Hardial Singh_ principle (iii) is whether it was apparent to the Defendant at the
relevant time that she would not be able to effect deportation within a reasonable period. In addition to
facts known to the Defendant about the anticipated timescale for dealing with the Conclusive Grounds
decision and asylum application, that information included the following:

1) The evidence about AM's conviction(s) in Albania. This initially came from AM's asylum screening
interview at the end of November, in which he volunteered that he had been convicted of murder in
Albania, albeit on his account for a murder he did not commit. It was supplemented by information obtained
from Europol on 13 December that AM had been convicted of murder and that warrants had been issued
for other offences, including theft. It was only on 10 February, however, that the documents giving fuller
details of his convictions were translated into English, so I do not think they can be relied upon as facts
known to the Defendant until that date.

2) The information known to the Defendant that he had entered the UK illegally and had no close relatives
in the UK - at his asylum screening interview, for example, he explained that his children were in Albania both of which, coupled with his criminal record, led the Defendant to conclude his risk of absconding was
high.


-----

3) The information that AM was a level 3 adult at risk, as accepted by the Defendant on 6 January on the
basis of the report of Dr Sayed. This was later supplemented by evidence that AM's mental health was
deteriorating while in detention and his threats of self-harm.

67. The question is whether it was “apparent” to the Defendant that AM's release could not be effected
within any reasonable period. The first and perhaps foremost relevant factor is the length of that anticipated
time of removal. It seems clear that the Defendant knew that ordinarily it would take more than 12 months
for the SCA to reach a Conclusive Grounds decision. Such a distant and uncertain prospect of removal
would appear to breach Hardial Singh principle (iii), especially for an individual assessed as an adult at risk
level 3. The factual issue is whether the Defendant knew other facts, relevant to AM's circumstances,
which meant it was not “apparent” to her that removal would drag on for that long. In the passage from
_AXD to which both parties agreed, Jay J. made clear that a court can take account of any facts known to_
the Defendant at the time, even if they did not figure in the contemporaneous reasons. He cited R (MS) v
_Secretary of State for the Home Department, in which the Court of Appeal had regard to information_
contained in an e-mail, disclosed in the course of the appeal hearing, and which for the first time provided
the factual reasons which justified the claimant's detention (see Thomas LJ at [47-48]).

68. The evidence disclosed at the hearing here showed that on around 18 December Ms Lee of the SCA
told staff in the Home Office that they “would anticipate” that the cohort of Albanian migrants on the boat
“would be concluded within 3 months of the 45-day [reflection] period ending”. AM was one of those
named as a member of the cohort in the list earlier provided to Ms Lee.

69. Mr Briddock did not dispute that this e-mail is relevant to what was known to the Defendant, but he
argues that all it demonstrates is that those within the cohort who had _already received positive_
Reasonable Grounds decision were expected to be dealt with in three months, whereas AM did not receive
such a decision until 30 December. The specific enquiries in relation to the timescale for dealing with AM's
Conclusive Grounds suggest that it was not until 23 February, he argues, that a three-month timescale for
the conclusive grounds decision was activated in relation to him (see the GCID notes).

70. I do not consider matters are so straightforward. It seems there was a degree of confusion within the
Defendant's staff as to the anticipated SCA timetable for dealing with AM's claim to be a victim of
trafficking. For example, on the same day as the Judge at the interim relief hearing was told AM's
Conclusive Grounds decision was expected to be resolved within six months, the GCID notes record an
anticipated timetable of three months. That anticipation, I consider, probably came from the earlier
communication of 18 December from Ms Lee.

71. The e-mail of 18 December is relevant, in my view, to what was “apparent” to the Defendant at the
time. It suggested that the anticipated general timetable for a Conclusive Grounds decision for all those
found on the boat would be three months from the end of the 45-day reflection period, given that the
intention of the SCA was to expedite the cases. Nothing in the e-mail suggests a different or longer
timetable would apply to those, such as AM, who had not yet received a Reasonable Grounds decision.
Nothing after that e-mail, so far as I can tell, informed the Defendant that the timetable had changed.
Because that e-mail was within the knowledge of the Defendant's staff, I do not consider it was “apparent”
to her in the period from the end of December until 23 February that AM could not be deported for more
than twelve months. Rather, the facts known to the Defendant at the time showed that there was a realistic
prospect of the Conclusive Grounds decision being taken in around three months after the end of the 45day reflection period which began, for AM, on 30 December. This meant a Conclusive Grounds decision in
around the middle of May.

72. No decision to deport could be made, of course, until the asylum procedure has been completed. But
there was no challenge to the evidence that the asylum claim could be processed very quickly after the
Conclusive Grounds decision, especially given that AM was, I was told, to attend an asylum interview while
in detention shortly after the hearing. Moreover, because Albania is a country listed in s.94(4) of the
Nationality, Immigration and Asylum Act 2020 the Defendant must certify the asylum claim as “clearly
unfounded” unless satisfied it is not clearly unfounded (s.94(1)(3)). If such a certificate is issued, any
appeal will take place outside the UK. The parties do not dispute that if the asylum decision is in favour of


-----

AM, the likelihood is that he will then be released; it if is against him, there is no suggestion of any
significant obstacle to his removal.

73. The anticipated timetable for dealing with AM's Conclusive Grounds is the starting point for
determining whether there was a sufficient prospect of his removal within a reasonable period. But what is
a reasonable period falls to be assessed in light all the relevant circumstances and I consider these even
though the principal argument for AM was that there simply was no envisaged timetable. I bear in mind the
following (see _Lumba_ per Lord Dyson at [48]). First, by the end of the period under challenge, AM had
already been in detention for around three months, and if the anticipated timetable is followed removal
should take place not long after the end of May. While any period of detention must be subject to anxious
scrutiny, it appears that the Defendant had been reasonably diligent in attempting to arrange for expedition
of the Conclusive Grounds timetable and to process AM's asylum claim while he was in detention.

74. Second, I accept the assessment of the Defendant's staff in the contemporaneous detention reviews
that his risk of absconding was high. AM has no close relatives in the UK, he had already unsuccessfully
claimed asylum in Sweden, he had entered the UK clandestinely without voluntarily going to the
authorities, he had not been tested with reporting restrictions, his application for bail had been refused and,
in light of Albania being listed in s.94 of the NIAA 2002, his pending asylum claim was probably insufficient
to generate a realistic expectation that he would comply with reporting requirements if released.

75. Third, as the Defendant knew at the time, AM had a conviction for murder in Albania, for which he
received a 15-year sentence and for which he had only recently been released. The Europol evidence
indicated that AM may have committed other offences other than murder (which it seems AM did not
mention at his asylum screening interview). By 10 February, once the Albanian documents had been
translated, the Defendant had substantial corroborating and apparently credible information from Albania
about the murder. Although he had contended at his asylum screening interview he was wrongly convicted,
AM had not given any more information at other interviews to substantiate this. While I accept the risk of
re-offending may only have been medium, the great seriousness of the murder conviction supported the
assessment of the Defendant's officers that the risk of harm was high and there was a significant public
protection concern if AM were released.

76. On the other side of the coin is the effect of detention on AM's psychiatric condition which led to his
being assessed as a level 3 adult at risk. While he was and is receiving treatment in detention, I accept the
evidence showing it was likely that continued detention could lead to a deterioration in his mental health, as
stated in the rule 35 report. This is a very important factor in favour of early release and means I must give
the closest scrutiny to the strength of the competing factors.

77. Weighing these incommensurable factors is a difficult task, and Mr Briddock has presented a robust
and measured argument for AM. But, stepping back, I consider the critical factor here was the expedited
timetable for dealing with AM's Conclusive Grounds decision and the uncontested evidence that the
asylum decision could be taken swiftly thereafter. Owing to the risk of absconding and, above all, the public
protection concerns arising from AM's criminal history, it does not seem realistic to me to contend that the
rule 35 report meant AM had to be released forthwith, and |Mr Briddock did not really press such an
argument. In light of the relatively short anticipated period for the Conclusive Grounds decision, I consider
it was not “apparent” to the Defendant in this period that deportation could not be effected within a
reasonable time (Hardial Singh principle (iii)). In all the circumstances, and for the same reasons, I also
consider it was reasonable to detain AM during this period (Hardial Singh principle (ii)).

Period (2) - 24 February to 8 March

78. This is the second period of challenge, based on what was said to the Judge at the interim relief
hearing, that the Conclusive Grounds decision could be made within six months. On that premise, Mr
Briddock submitted the period of detention would again infringe principle (iii) of Hardial Singh, because it
would mean that the Conclusive Grounds decision could not be taken until around the end of August and,
even then, the asylum decision would need to be taken. Given the effect of detention on AM's psychiatric
condition, he argued such a period of detention was too long.


-----

79. The principal difficulty with this argument is its premise. Mr Briddock's submission is understandable
because it is not in dispute that at the interim relief hearing that the Judge was told that the anticipated
timetable for the Conclusive Grounds decision was six months. Nor could Mr Murray explain how a sixmonth timetable instead of three months came to be given to the Judge, though he speculated about
delays which might have arisen because of COVID. The evidence before me, however, suggests that a
three-month timetable for the Conclusive Grounds decision was anticipated in December and that
continued to be the anticipation at the end of February: see, in particular, the GCID notes for 25 February:
no evidence suggests it was changed. For the reasons I have already given in relation to the earlier period
of detention, I consider that, given that anticipated timetable, it was not apparent to the Defendant in this
later period that detention could not be effected within a reasonable time.

80. In the event, however, that the anticipation was of a Conclusive Grounds decision within six months, I
still consider with hesitation there would be no infringement of Hardial Singh principle (iii) at this time. At
this stage the GCID notes for 25 February provided further evidence indicating that AM's continued
detention was contributing to a deterioration in his psychiatric condition, underling what had been said in
the rule 35 report. But he was receiving treatment while in detention, and I consider the public protection
concerns and risk of absconding, identified in the review which took place on 25 February, meant detention
until shortly after an anticipated Conclusive Grounds decision at around the end of August would still be
reasonable in all the circumstances. Put in terms of _Hardial Singh_ principle (iii), I do not consider it was
then apparent to the Defendant that deportation could not be effected within a reasonable period, even if
the Conclusive Grounds decision was expected to take six months.

Period (3) - 9 March 2021 to date of hearing

81. The final period of challenge is from 9 March. Mr Briddock accepted that from this date the anticipated
timetable for dealing with the Conclusive Grounds decision was three months from the end of the 45-day
reflection period.

82. During this period, further reviews of detention took place, in particular on 24 March and 7 April. These
anticipated the Conclusive Grounds decision taking place on 24 May and the asylum decision taking place
on 27 May.

83. In addition, as well as the translation of the Albanian documents about AM's murder conviction and the
information from Europol, on around 15 March the Defendant received further information from the
Albanian authorities about his criminal record, including his past sentence for theft and for possession of a
prohibited item while in custody. From 18 April the Defendant had further relevant evidence of AM's
propensity to commit crimes because he was found in possession of cocaine.

84. For the similar reasons as I have given in relation to the first period, in all the circumstances I consider
it was not apparent to the Defendant from 9 March onwards that deportation could not be effected within a
reasonable period. I accept the views about AM's risk of absconding in the contemporaneous reviews, of
24 March and 7 April. Moreover, the additional evidence from Albania about his criminal record and his
being found in possession of cocaine while in detention, reinforced the view that there was a danger that
AM would commit criminal offences if released. In view of the expedited timetable, I do not consider it was
apparent that the anticipated period of detention will be unreasonable.

85. Though the point was not pressed by Mr Briddock, for the same reasons I consider there was no
breach of Hardial Singh principle (ii) when the matter is viewed historically rather than prospectively at the
date of the hearing. Although the effects of detention on AM are serious, the period has not been
unreasonable in view of the total length of time in detention to date, the steps taken by the Defendant to
arrange for expedition of the SCA Conclusive Grounds decision and to process AM's asylum decision, the
risk of absconding and, above all, the public protection factors revealed by his criminal record.

**Ground (2) - No Justification for Detention under Policies**

86. The second ground of challenge relates to the Defendant's policies. In summary, it was that the
identification of AM as a level 3 adult at risk meant that he should have been released, consistent with the


-----

Defendant's policies on adult at risks. I can deal with this aspect shortly because Mr Briddock only dealt
with it briefly in his oral submissions.

87. AM relies on, first, the “Guidance on Adult at Risks in Immigration Detention” (the “Guidance”).
Paragraph 14 of that Guidance lists the immigration factors which might justify continued detention,
including “public protection issues” and “compliance issues”, and paragraph 15 makes clear that detention
should only continue if the immigration factors outweigh the risk factors. Second, he relies on the internal
policy “Adults at Risk in Immigration Detention” (the “Policy”), which states at p 17 that an individual
assessed at Level 3 should only be detained if either removal has been set for the immediate future or the
individual presents a “significant public protection, or if they have been subject to a 4 year plus custodial
sentence...”. That Policy indicates that compliance issues alone are unlikely to justify continued detention.

88. I accept Mr Briddock's submission that, in light of the Policy and the effect of detention on the
Claimant's detention, the compliance issues here were not sufficiently exceptional to justify continued
detention, even accepting that the discretionary decision not to release can only be challenged on
_Wednesbury grounds. Indeed, for the Defendant, Mr Murray relied on the public protection concern in that_
Policy alone and did not press the risk of absconding as itself justifying continued detention.

89. I consider, however, it was open to the Defendant to consider that AM's history justified his continued
detention on public protection grounds, both under paragraph 14 of the Guidance and in accordance with
how public protection concerns are expressed in the Policy. The Policy itself indicates that custodial
sentences of four years or more give rise to a significant issue of public protection and, when it comes to
assessing risk to public protection, the Policy directs the decision-maker to consider whether the individual
is a foreign national offender and, if so, the seriousness of the offence. The considerations all pointed
towards AM presented a significant public protection concern under the Policy.

90. In his argument, Mr Briddock contended that the murder conviction could not in itself justify detention,
pointing out that AM volunteered the information about his conviction and said he was wrongfully
convicted. But these facts hardly meant that the Defendant was not entitled to take account of the murder
conviction, especially in circumstances where there was substantial documentary evidence from Albania,
on its face setting out details of the evidence and procedure which led to the conviction, and other
evidence of offences there. Mr Briddock makes other criticisms of the process, arguing that the Defendant
did not make any real effort to assess the risk from AM until 23 February and paid little regard to public
protection. In fact, however, in the _ad hoc_ review on 6 January the authorising officer justified continued
detention because, it was said, AM presented a “significant public protection concern” owing to his murder
conviction. In the circumstances, I do not consider that the Defendant's officials failed to follow the
Guidance or the Policy.

**Conclusion**

91. For the reasons set out above, I have concluded that the application for judicial review fails and is
dismissed. As set out above, the terms of the final order will include a provision for anonymity.

**End of Document**


-----

