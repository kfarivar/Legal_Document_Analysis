# Taiwo v Olaigbe and another; Onu v Akwiwu and another [2017] 1 All ER 985

[2016] UKSC 31

SUPREME COURT

LADY HALE DP, LORD WILSON, LORD REED, LORD HUGHES AND LORD TOULSON SCJJ

20, 21 APRIL, 22 JUNE 2016

**Employment — Discrimination — Nationality, on grounds of — Immigration status — Domestic workers**
**visa — Whether discrimination because of, or on grounds of, immigration status amounting to**
**discrimination because of, or on grounds of, nationality — Whether employers' conduct amounting to**
**indirect discrimination against persons sharing that nationality — Race Relations Act 1976 — Equality Act**
**2010.**

The appellant in the first action, T, was a Nigerian national. In February 2010, she entered the United Kingdom
lawfully with a migrant domestic worker's visa obtained for her by the respondents in the first action, her employers.
T was subjected to both physical and mental abuse by her employers. In April 2011, T brought a claim of direct and
indirect race discrimination under the _[Equality Act 2010 and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_ _[Race Relations Act 1976 in the employment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)_
tribunal. The tribunal dismissed her claims finding that T was treated as she was because she was a vulnerable
migrant worker who was reliant on her employers for her continued employment and residence in the UK, not
because she was Nigerian. The Employment Appeal Tribunal ('the EAT') upheld the tribunal's conclusions on direct
discrimination. It further found that the tribunal had not properly approached the claim of indirect discrimination,
because it had not tried to identify the 'provision, criterion or practice' ('PCP') which put the group to which T
belonged at a comparative disadvantage; but as no tenable PCP had been put forward, the appeal was dismissed.
The appellant in the second action, O, was Nigerian. In July 2008, she entered the UK on a domestic worker's visa
obtained for her by the respondents in the second action, her employers. They had taken away her passport on
arrival and did not tell her where it was kept. She was threatened and abused by her employers. In September
2010, O brought proceedings, including making the same claims as T. The tribunal held that her employers had
directly discriminated against her and had harassed her on grounds of race. It found that the employers had treated
her less favourably than they would have treated someone who was not a migrant worker. They had treated her in
the way that they did because of her status as a migrant worker which was 'clearly linked' to her race. The EAT
allowed the employers' appeal in respect of the discrimination claim. It held that no part of the employers' treatment
of O was inherently bound up with her race, but rather with her subordinate position and the relative economic
benefits of her work in the UK compared with the poverty of her situation in Nigeria. They also rejected a claim for
indirect discrimination based on a PCP of the mistreatment of migrant domestic workers, because it was not a
neutral criterion which disadvantaged some of those to whom it applied disproportionately when compared with
others to whom it applied. The Court

**[*986]**

of Appeal, Civil Division, heard T's and O's appeals on the discrimination issues together. It held that immigration
status was not to be equated with 'nationality' for the purpose of the 1976 Act and the 2010 Act. On the indirect
discrimination claim, it found that the mistreatment of migrant workers was not a PCP. T and O appealed. The
principal question for the court was whether discrimination because of, or on grounds of, immigration status


-----

amounted to discrimination because of, or on grounds of, nationality. The subsidiary question was whether the
employers' conduct had amounted to indirect discrimination against persons who shared that nationality.

**Held – Parliament could have chosen to include immigration status in the list of protected characteristics, but it had**
not done so. The only question was whether immigration status was so closely associated with nationality that they
were indissociable for the present purpose. It was correct that immigration status was a 'function' of nationality. In
the present cases, T and O had had limited leave to enter on domestic workers' visas. It had been the terms of
those visas which had made them particularly vulnerable to the mistreatment which they had suffered. The reason
why T and O had been treated so badly had been their particular vulnerability arising, at least in part, from their
particular immigration status. It had had nothing to do with the fact that they had been Nigerians. That was enough
to dispose of the direct discrimination claim. The point about the present case was that the criterion in fact being
adopted by the employers had not been nationality, but having been 'a particular kind of migrant worker, her
particular status making her vulnerable to abuse'. With respect to indirect discrimination, no-one could think of a
PCP which the employers would have applied to all their employees, whether or not they had had the particular
immigration status of T and O. The only PCP which anyone could think of was the mistreatment and exploitation of
workers who were vulnerable because of their immigration status. By definition, that would not be applied to
workers who were not so vulnerable. Applying it to T and O could not, therefore, be indirect discrimination within the
meaning of the 2010 Act. However, the possibility could not be ruled out that, in other cases involving the
exploitation of migrant workers, it might be possible to discern a PCP which had an indirectly discriminatory effect. It
followed that the appeals had to fail (see [22]–[24], [26], [27], [30]–[34], below); R (on the application of Morris) v
_[Westminster City Council [2005] 1 All ER 351, A-G's Reference (No 4 of 2004) [2005] 1 WLR 2810and R v Rogers](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FF1-RR30-TWP1-617G-00000-00&context=1519360)_

_[[2007] 2 All ER 433 distinguished; Patmalniece v Secretary of State for Work and Pensions [2011] 3 All ER 1 and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NM5-JYV0-TWP1-60DV-00000-00&context=1519360)_
_[Bull v Hall [2014] 1 All ER 919 applied; Schnorbus v Land Hessen (Case C-79/99) [2000] ECR I-10997 and Bressol](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BK0-1R21-DYBP-M43P-00000-00&context=1519360)_
_v Gouvernement de la Communauteì Française, Chaverot v Gouvernement de la Communauteì Française (Case_
_C-73/08) [2010] ECR I-2735 considered._

[Per curiam. Parliament may well wish to address its mind to whether the remedy provided by s 8 of the Modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C270-00000-00&context=1519360)
**_Slavery Act 2015 is too restrictive in its scope and whether an employment tribunal should have jurisdiction to grant_**
some recompense for the ill-treatment meted out to workers such as these, along with the other remedies which it
does have power to grant (see [34], below).

[Decision of the Court of Appeal [2014] IRLR 448 affirmed.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C80-S0H1-DYPB-W1K9-00000-00&context=1519360)
**[*987] Notes**

For the protected characteristic of race, direct discrimination under the _[Equality Act 2010,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_ indirect discrimination
[under the Equality Act 2010, see 33 Halsbury's Laws (5th edn) (2013) paras 61, 65, 72.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)

[For the Equality Act 2010, see 7(1) Halsbury's Statutes (4th edn) (2015 reissue) 1255.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
**Cases referred to**

_A-G's Reference (No 4 of 2004)_ _[[2005] EWCA Crim 889, [2005] 1 WLR 2810.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JST1-DYBP-N2Y4-00000-00&context=1519360)_

_Bressol v Gouvernement de la Communauteì Française, Chaverot v Gouvernement de la Communauteì Française_
(Case C-73/08) EU:C:2009:396, EU:C:2010:181, [2010] ECR I-2735, [2010] 3 CMLR 559, ECJ.

_[Bull v Hall [2013] UKSC 73, [2014] 1 All ER 919, sub nom Preddy v Bull (Liberty intervening) [2013] 1 WLR 3741.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BK0-1R21-DYBP-M43P-00000-00&context=1519360)_

_[Hounga v Allen [2014] UKSC 47, [2014] 4 All ER 595, [2014] 1 WLR 2889.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DMS-8XS1-DYBP-M3G0-00000-00&context=1519360)_

_[Patmalniece v Secretary of State for Work and Pensions [2011] UKSC 11, [2011] 3 All ER 1, [2011] 1 WLR 783.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5340-0831-DYBP-M519-00000-00&context=1519360)_

_[R (on the application of Morris) v Westminster City Council [2004] EWHC 2191 (Admin), [2005] 1 All ER 351, [2005]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FF1-RR30-TWP1-617G-00000-00&context=1519360)_
1 WLR 865.

_[R v Rogers [2007] UKHL 8 [2007] 2 All ER 433 [2007] 2 AC 62 [2007] 2 WLR 280](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NM5-JYV0-TWP1-60DV-00000-00&context=1519360)_


-----

_Schnorbus v Land Hessen (Case C-79/99) EU:C:2000:370, EU:C:2000:676, [2000] ECR I-10997, [2001] 1 CMLR_
1025, ECJ.
**Additional cases referred to in list of authorities**

_Aduma v Mehmet (t/a Rose Hotel Group)_ _[[2007] All ER (D) 04 (Jun), EAT.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JSV1-DYBP-N0BS-00000-00&context=1519360)_

_Ahmed v Amnesty International_ _[[2009] IRLR 884, [2009] ICR 1450, EAT.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W50K-00000-00&context=1519360)_

_Aitken v Comr of Police of the Metropolis_ _[2011] EWCA Civ 582, [2012] ICR 78._

_Ali v Office of National Statistics_ _[[2004] EWCA Civ 1363, [2005] IRLR 201.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W3BY-00000-00&context=1519360)_

_Aylott v Stockton-on-Tees BC_ _[[2010] EWCA Civ 910, [2010] IRLR 994, [2010] ICR 1278.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:516W-KBK1-DYPB-W0YB-00000-00&context=1519360)_

_[Aziz v Trinity Street Taxis Ltd [1988] 2 All ER 860, [1989] QB 463, [1988] 3 WLR 79, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60FH-00000-00&context=1519360)_

_British Airways v Starmer_ _[[2005] IRLR 862, EAT.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W3MD-00000-00&context=1519360)_

_BT Pension Scheme Trustees Ltd v British Telecommunications plc_ _[[2011] EWHC 2071 (Ch), [2011] All ER (D) 294](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53DY-XJX1-DYBP-N4RX-00000-00&context=1519360)_
_[(Jul).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53DY-XJX1-DYBP-N4RX-00000-00&context=1519360)_

_Centrum voor Gelijkheid van Kansen en voor Racismebestrijding v Firma Feryn NV (Case_ _C-54/07)_
[EU:C:2008:397, [2008] All ER (EC) 1127, [2008] ICR 1390, [2008] ECR I-5187, ECJ.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TVD-YJT0-Y96Y-F4C0-00000-00&context=1519360)

_[CHEZ Razpredelenie Bulgaria AD v Komisia za zashtita ot diskriminatsia (Case C-83/14) EU:C:2015:480, [2015] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HBN-CYV1-DYBP-K06R-00000-00&context=1519360)_
_[ER (EC) 1083, [2015] IRLR 746, [2016] 1 CMLR 491, ECJ.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HBN-CYV1-DYBP-K06R-00000-00&context=1519360)_

_Chief Constable of West Yorkshire Police v Khan_ _[[2001] UKHL 48, [2001] 4 All ER 834, [2001] 1 WLR 1947.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-6164-00000-00&context=1519360)_

_CLFIS (UK) Ltd v Reynolds_ _[[2015] EWCA Civ 439, [2015] IRLR 562, [2015] ICR 1011.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5G78-7R11-DYPB-W10D-00000-00&context=1519360)_

_Cocking v Sandhurst (Stationers) Ltd [1974] ICR 650, NIRC._

_[Coleman v Attridge Law (Case C-303/06) EU:C:2008:415, [2008] All ER (EC) 1105, [2008] ECR I-5603, [2008] ICR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TVD-YJT0-Y96Y-F45K-00000-00&context=1519360)_
1128, ECJ.

_Comrs for Her Majesty's Revenue and Customs v Spiridonova_ _[[2014] NICA 63, [2015] 1 CMLR 26.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D9C-2D01-DYBP-Y2SR-00000-00&context=1519360)_
**[*988]**

_Dawkins v Dept of the Environment_ _[[1993] IRLR 284, sub nom](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W4H4-00000-00&context=1519360)_ _Crown Suppliers (Property Services Agency) v_
_Dawkins [1993] ICR 517, CA._

_Donkor v The Royal Bank of Scotland_ _[[2016] IRLR 268, EAT.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9P-58S1-DYPB-W21B-00000-00&context=1519360)_

_Edie v HCL Insurance BPO Services Ltd [2015] ICR 713, EAT._

_European Roma Rights Centre v Immigration Officer at Prague Airport (United Nations High Commissioner for_
_Refugees intervening)_ _[[2004] UKHL 55, [2005] 1 All ER 527, [2005] 2 AC 1, [2005] 2 WLR 1.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FGH-JVK0-TWP1-609F-00000-00&context=1519360)_

_Fecitt v NHS Manchester_ _[[2011] EWCA Civ 1190, [2012] IRLR 64, [2012] ICR 372.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:54GJ-TK01-DYPB-W0M2-00000-00&context=1519360)_

_Garland v British Rail Engineering Ltd_ _[[1982] 2 All ER 402, [1983] 2 AC 751, [1982] 2 WLR 918, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD9-0DT0-TWP1-6043-00000-00&context=1519360)_

_Gaysusuz v Austria (1997) 23 EHRR 364, ECt HR._


-----

_Grobbelaar v News Group Newspapers Ltd_ _[[2002] UKHL 40, [2002] 4 All ER 732, [2002] 1 WLR 3024.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61K9-00000-00&context=1519360)_

_Hewage v Grampian Health Board_ _[[2012] UKSC 37, [2012] 4 All ER 447, [2012] ICR 1054.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56VF-HDG1-DYBP-M16D-00000-00&context=1519360)_

_[Home Office (UK Border Agency) v Essop [2015] EWCA Civ 609, [2016] 3 All ER 137, [2015] ICR 1063.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K32-VM01-DYBP-M3YS-00000-00&context=1519360)_

_Homer v Chief Constable of West Yorkshire_ _[[2012] UKSC 15, [2012] 3 All ER 1287, [2012] ICR 704.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56G1-0B81-DYBP-M00K-00000-00&context=1519360)_

_James v Eastleigh BC_ _[[1990] 2 All ER 607, [1990] 2 AC 751, [1990] 3 WLR 55, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60SV-00000-00&context=1519360)_

_Khan v Royal Mail Group Ltd_ _[[2014] EWCA Civ 1082, [2014] IRLR 947.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DJB-8J81-DYPB-W0PC-00000-00&context=1519360)_

_London Borough of Ealing v Race Relations Board_ _[[1972] 1 All ER 105, [1972] AC 342, [1972] 2 WLR 71, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DDP-64W0-TWP1-60M0-00000-00&context=1519360)_

_London Underground Ltd v Edwards (No 2)_ _[[1998] IRLR 364, [1999] ICR 494, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W3FR-00000-00&context=1519360)_

_[Madarassy v Nomura International plc [2007] EWCA Civ 33, [2007] IRLR 246, [2007] ICR 867.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W50W-00000-00&context=1519360)_

_Mandla v Dowell Lee_ _[[1983] 1 All ER 1062, [1983] 2 AC 548, [1983] 2 WLR 620, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-60K5-00000-00&context=1519360)_

_McAuley Catholic High School v CC_ _[[2003] EWHC 3045 (Admin), [2004] 2 All ER 436, [2004] ICR 1563.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-60FB-00000-00&context=1519360)_

_Ministry of Defence v DeBique_ _[[2010] IRLR 471, EAT.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YF8-M1D0-Y9JK-R21F-00000-00&context=1519360)_

_Nagarajan v London Regional Transport_ _[[1999] 4 All ER 65, [2000] 1 AC 501, [1999] 3 WLR 425, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-61CF-00000-00&context=1519360)_

_Naraine v Hoverspeed Ltd [2000] EuLR 321, CA._

_Nyazi v Rymans Ltd (EAT/6/88) (10 May 1988, unreported), EAT._

_O v Comr of Police for the Metropolis_ _[2011] EWHC 1246 (QB), [2011] HRLR 29._

_Orphanos v Queen Mary College_ _[[1985] 2 All ER 233, [1985] AC 761, [1985] 2 WLR 703, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-60PJ-00000-00&context=1519360)_

_R (on the application of Amicus–MSF section) v Secretary of State for Trade and Industry_ _[2004] EWHC 860_
_[(Admin), [2004] IRLR 430, [2007] ICR 1176.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1DD-00000-00&context=1519360)_

_R (on the application of E) v Governing Body of JFS (Secretary of State for Children, School and Families,_
_interested parties) (United Synagogue intervening), R (on the application of E) v Office of the Schools Adjudicator_
_(Governing Body of JFS, interested parties) (British Humanist Association intervening)_ _[[2009] UKSC 15, [2010] 1 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XM1-PY80-Y96Y-G1BH-00000-00&context=1519360)_
_[ER 319, [2010] 2 AC 728, [2010] 2 WLR 153.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XM1-PY80-Y96Y-G1BH-00000-00&context=1519360)_

_R (on the application of Elias) v Secretary of State for Defence_ _[[2006] EWCA Civ 1293, [2006] IRLR 934, [2006] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1JR-00000-00&context=1519360)_
WLR 3213.

_R (on the application of Morris) v Westminster City Council, R (on the application of Badhu) v Lambeth London BC_

_[[2005] EWCA Civ 1184, [2006] LGR 81, [2006] 1 WLR 505.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4JB8-9G30-TWP1-N0N3-00000-00&context=1519360)_
**[*989]**

_R (on the application of SG) v Secretary of State for Work and Pensions_ _[2015] UKSC 16,_ _[[2015] 4 All ER 939,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HHT-9M41-DYBP-M3F7-00000-00&context=1519360)_

[2015] 1 WLR 1449.

_Rantsev v Cyprus and Russia_ _[(2010) 28 BHRC 313, (2010) 51 EHRR 1, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

_Secretary of State for Trade and Industry v Rutherford_ _[[2006] UKHL 19, [2006] 4 All ER 577, [2006] ICR 7855.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4M7D-4SS0-TWP1-611W-00000-00&context=1519360)_


-----

_Secretary of State for Work and Pensions v Bobezes_ _[[2005] EWCA Civ 111, [2005] 3 All ER 497.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4GR3-1040-TWP1-60J2-00000-00&context=1519360)_

_Selkent Bus Co Ltd v Moore_ _[[1996] IRLR 661, [1996] ICR 836, EAT.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W4C8-00000-00&context=1519360)_

_Shamoon v Chief Constable of the Royal Ulster Constabulary_ _[[2003] UKHL 11, [2003] 2 All ER 26, [2003] ICR 337.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61F1-00000-00&context=1519360)_

_Siliadin v France_ _[(2005) 20 BHRC 654, (2005) 43 EHRR 287, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

_Stone v Cineworld Cinemas plc [2012] EqLR 289, ET._

_Tejani v Superintendent Registrar for the District of Peterborough_ _[[1986] IRLR 502, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W212-00000-00&context=1519360)_

_The Law Society v Bahl [2003] IRLR 640, EAT._

_Thompson v Bermuda Dental Board_ _[[2008] UKPC 33, (2008) 24 BHRC 756.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2DF-00000-00&context=1519360)_

_Wakeman v Quick Corp_ _[[1999] IRLR 424, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3Y1-DYPB-W13G-00000-00&context=1519360)_

_Walker (JH) Ltd v Hussain [1996] ICR 291, EAT._

_Wong v Igen Ltd (Equal Opportunities Commission intervening), Emokpae v Chamberlin Solicitors (Equal_
_Opportunities Commission intervening), Webster v Brunel University (Equal Opportunities Commission intervening)_

_[[2005] EWCA Civ 142, [2005] 3 All ER 812, [2005] ICR 931.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4GY2-7590-TWP1-61N7-00000-00&context=1519360)_
**Appeal**

The appellants, Ms Taiwo ('T') and Ms Onu ('O'), appealed against the decision of the Court of Appeal, Civil Division
[(Maurice Kay VP, Ryder and Underhill LJJ) of 13 March 2014 ([2014] EWCA Civ 279, [2014] IRLR 448, [2014] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C80-S0H1-DYPB-W1K9-00000-00&context=1519360)
WLR 3636), finding that immigration status was not to be equated with 'nationality' for the purpose of the _[Race](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)_
_[Relations Act 1976 and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)_ _[Equality Act 2010. That decision affirmed decisions of the Employment Appeals](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
[Tribunal (Langstaff J, Mr B Beynon and Mr P Gammon) of 5 March 2013 ([2013] All ER (D) 294 (Mar)) and 1 May](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:582K-WG51-DYBP-N4GK-00000-00&context=1519360)
[2013 ([2013] IRLR 523), dismissing their discrimination claims against the respondents, Mr and Mrs Olaigbe and Mr](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58NW-1M51-DYPB-W11B-00000-00&context=1519360)
and Mrs Akwiwu. The facts are set out in the judgment of the court delivered by Lady Hale DP.

_Robin Allen QC and Christopher Milsom (instructed by Anti Trafficking and Labour Exploitation) for T._

_Robin Allen QC and James Robottom (instructed by Anti Trafficking and Labour Exploitation) for O._

_Thomas Linden QC and Sarah Hannett (instructed by Lewis Silkin LLP) for the respondents in the first appeal._

_Sami Rahman and David Mold (instructed by BH Solicitors) for the respondents in the second appeal._

_Judgment was reserved._

22 June 2016. The following judgment of the court was delivered.

**LADY HALE DP.**

**[1] The mistreatment of migrant domestic workers by employers who exploit their employees' vulnerable situation is**
clearly wrong. The law
**[*990]**

recognises this in several ways. Depending on the form which the mistreatment takes, it may well amount to a
breach of the worker's contract of employment or other employment rights. It may also amount to a tort. It may even
[amount to the offence of slavery or servitude or forced or compulsory labour under s 1 of the Modern Slavery Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C212-00000-00&context=1519360)
2015 or of human trafficking under s 2 of that Act. If a person is convicted of such an offence and a confiscation
order made against him, the court may also make a slavery and trafficking reparation order under s 8 of the Act,
requiring him to pay compensation to the victim for any harm resulting from the offence. But such orders can only


-----

be made after a conviction and confiscation order; and remedies under the law of contract or tort do not provide
compensation for the humiliation, fear and severe distress which such mistreatment can cause.

**[[2] Such a remedy could be found if the employer's conduct amounts to race discrimination under the Equality Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)**
_[2010 or its predecessor the Race Relations Act 1976. This would have the added advantage that proceedings for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
the statutory tort of race discrimination can be brought in an employment tribunal, at the same time as proceedings
for unpaid wages and other breaches of the contract of employment and for unfair dismissal. The issue in this case,
therefore, is whether the conduct complained of amounts to discrimination on grounds of race. In both the 1976 and
2010 Acts, at the relevant time, the definition of race also covered nationality and ethnic or national origins. In the
two cases before us, the employment tribunals both found that the reason for the employers' mistreatment of their
employees was their victims' vulnerability owing to their precarious immigration status. The principal question for
this court, therefore, is whether discrimination because of, or on grounds of, immigration status amounts to
discrimination because of, or on grounds of, nationality. The subsidiary question is whether the employers' conduct
amounted to indirect discrimination against persons who shared that nationality.
**Ms Taiwo's case**

**[3] Ms Taiwo is a Nigerian national of Yoruba and Nigerian ethnicity. She is married and has two children but was**
living in poverty in Nigeria. She entered the United Kingdom lawfully in February 2010 with a migrant domestic
worker's visa obtained for her by Mr and Mrs Olaigbe, her employers. Mr Olaigbe is also a Nigerian of Yoruba
ethnicity, but comes from a wealthy and influential family. Mrs Olaigbe is a Ugandan. They have two children (and
at the time were also fostering two other children). They had 'manufactured a history' of Ms Taiwo's previous
employment with Mr Olaigbe's parents so that she would qualify for a domestic worker's visa. They had also
'fabricated' a contract of employment, which Ms Taiwo never saw, and which provided for more favourable terms of
employment than Ms Taiwo had understood. On arrival in the United Kingdom, Mr Olaigbe took her passport and
kept it.

**[4] The employment tribunal found that Ms Taiwo was expected to be 'on duty', during most of her waking hours**
and was not given the rest periods required by the Working Time Regulations 1998, _[SI 1998/1883. She was not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW8-5HH0-TX08-C0F5-00000-00&context=1519360)_
[paid the minimum wage to which she was entitled under the National Minimum Wage Act 1998. For April, May and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)
June 2010, she was paid the sum of £200 per month which she had been promised, and there was a further
payment of £300 in August. But in October she was forced to hand over £800 to the employers. She was not given
enough to eat and suffered a dramatic loss of weight. She was subjected to both physical and mental abuse by Mr
and
**[*991]**

Mrs Olaigbe and Mr Olaigbe's mother, who was living with them for some of the time. She was slapped and spat at;
she was mocked for her tribal scars and her poverty, and called a 'crazy woman'. She was not allowed her own
personal space and shared a room with the employers' two children. The Employment Appeal Tribunal ((2013)
_(2013) UKEAT/254/12, [2013] ICR 770) characterised her situation as 'systematic and callous exploitation'._

**[5] Eventually, through a sympathetic worker at the children's playgroup, she was put in touch with social services**
and other agencies. These enabled her to escape in January 2011 and supported her thereafter. In April 2011 she
brought a claim in the employment tribunal. In January 2012, the tribunal upheld her claims under the _[National](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)_
_[Minimum Wage Act 1998, for unlawful deduction from wages under s 13 of the Employment Rights Act 1996, for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)_
failure to provide the rest periods required by the Working Time Regulations 1998 and for failure to provide written
terms of employment under s 1 of the 1996 Act. In February she was awarded £30,458.85 under the National
Minimum Wage Regulations, _[SI 1999/584, £1,520 for failure to provide written particulars of her contract of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW8-2N90-TX08-C01Y-00000-00&context=1519360)_
employment, and £1,250 for failing to provide rest periods.

**[6] However, the employment tribunal dismissed her claims of direct and indirect race discrimination under the**
_[Equality Act 2010 (in fact some of her employment was covered by the Race Relations Act 1976, as the relevant](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
[provisions of the Equality Act 2010 only came into force on 1 October 2010, but it makes no material difference).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
The tribunal found that Ms Taiwo was treated as she was because 'she was a vulnerable migrant worker who was
reliant on the respondents for her continued employment and residence in the United Kingdom' She had not been


-----

treated as she was because she was Nigerian. Another migrant worker whose employment and residence in the
United Kingdom was governed by immigration control and by the employment relationship would have been treated
in the same way. Mr and Mrs Olaigbe might have chosen to employ a Ugandan and there was no reason to think
that a Ugandan would have been treated any more favourably than Ms Taiwo had been. Hence there was no direct
discrimination on grounds of race.

**[7] The Employment Appeal Tribunal upheld the employment tribunal's conclusions on direct discrimination. They**
found that the tribunal had not properly approached the claim of indirect discrimination, because it had not tried to
identify the 'provision, criterion or practice' ('PCP') which put the group to which the claimant belonged at a
comparative disadvantage; but no tenable PCP had been put forward. Hence the appeal on discrimination was
dismissed.
**Ms Onu's case**

**[8] The facts of Ms Onu's case are similar. She too is Nigerian. She entered the United Kingdom in July 2008 on a**
domestic worker's visa obtained for her by her employers, Mr and Mrs Akwiwu. She had previously worked for them
in Nigeria, but they too had supplied false information to the United Kingdom authorities in order to obtain the visa.
Mrs Akwiwu's mother later drafted a contract for her in Nigeria which provided that she would neither leave nor
abscond from them within a year and that if she did she would be reported to the UK police and immigration
authorities. They had taken away her passport on arrival and did not tell her where it was kept. She was not
provided with a written statement of her terms and conditions of employment. She was required to work, on
average, for 84 hours a week, looking after the home and
**[*992]**

the couple's two children, one of whom was a prematurely born baby who required special care. She was not given
the required rest periods or annual leave. She was not paid the minimum wage. She was threatened and abused by
her employers. She was told that she would be arrested and imprisoned if she tried to run away. She was also told
that the police in the United Kingdom were not like the Nigerian police, by which was meant that she would be
arrested and put in prison for minor matters. She was not registered with a general practitioner.

**[9] Ms Onu fled her employers' home in June 2010, walking some eight miles to the home of a Jehovah's Witness**
whom she had met on the doorstep of the home because she had no money. She was put in touch with a charity
which assists trafficked migrant workers. In September 2010 she brought proceedings making the same claims that
[Ms Taiwo made, to which she later added claims for harassment and victimisation under the Equality Act 2010. The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
employment tribunal upheld the same claims as had the tribunal in Ms Taiwo's case and also held that Ms Onu had
been constructively and unfairly dismissed. They further held that her employers had directly discriminated against
her and had harassed her on grounds of race. They found that the employers had treated her less favourably than
they would have treated someone who was not a migrant worker. They had treated her in the way that they did
because of her status as a migrant worker which was 'clearly linked' to her race. At the later remedy hearing, she
was awarded £11,166.16 for unfair dismissal, including the failure to provide a statement of terms and condition;
£43,541.06 for unpaid wages; £1,266.72 for unpaid holiday; and £25,000 for injury to feelings and £5,000
aggravated damages.

**[10] The Employment Appeal Tribunal ((2013)** _[(2013) UKEAT/0022/12,UKEAT/0283/12,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58CR-7K61-F0JY-C2GG-00000-00&context=1519360)_ _[[2013] IRLR 523, [2013]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58NW-1M51-DYPB-W11B-00000-00&context=1519360)_
ICR 1039) allowed the employers' appeal in respect of the discrimination claim. They held that no part of the
employers' treatment of Ms Onu was inherently bound up with her race but rather with her subordinate position and
the relative economic benefits of her work in the United Kingdom compared with the poverty of her situation in
Nigeria. They also rejected a claim for indirect discrimination based on a PCP of 'the mistreatment of migrant
domestic workers', because it was not a neutral criterion which disadvantaged some of those to whom it applied
disproportionately when compared with others to whom it applied.
**The Court of Appeal**

**[11] The Court of Appeal heard the appeals of Ms Taiwo and Ms Onu on the discrimination issues together: [2014]**
_[EWCA Civ 279, [2014] IRLR 448, [2014] 1 WLR 3636. On the direct discrimination claim, there were two issues: the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C80-S0H1-DYPB-W1K9-00000-00&context=1519360)_
'grounds' issue and the 'nationality issue' On the grounds issue the court held that this was not a case in which the


-----

employers had published or applied a discriminatory criterion (an example would be that women required higher
qualifications for employment than did men). It was therefore necessary to examine the employers' mental
processes to discover whether the employees' immigration status formed part of the reasons for treating them so
badly. It did not have to be the sole reason as long as it played a significant part. In this case it did so. That holding
is not under appeal. On the nationality issue, the court held that immigration status was not to be equated with
'nationality' for the purpose of the Race Relations and Equality Acts. There were many non-British nationals working
in the United Kingdom who did not share the particular dependence and vulnerability of these migrant domestic
workers. On the
**[*993]**

indirect discrimination claim, the court found that the mistreatment of migrant workers was not a PCP. This factual
situation had nothing to do with the kind of mischief which indirect discrimination is intended to address.

**[12] Ms Taiwo has permission to appeal to this court on the nationality issue. Ms Onu's case has been heard with**
hers as an application for permission to appeal with appeal to follow if permission is granted. In view of the
importance of the issue, permission to appeal is granted. The court is particularly grateful to counsel for appearing
for Mr and Mrs Akwiwu at very short notice, following the tragic and untimely death of Mr Jake Dutton who had
represented them in the Employment Appeal Tribunal and the Court of Appeal. We are also grateful to counsel and
their instructing solicitors for appearing pro bono for both Mr and Mrs Olaigbe and Mr and Mrs Akwiwu. Given that
the Anti Trafficking and Labour Exploitation Unit is, quite properly, supporting the claims of Ms Taiwo and Ms Onu, it
was particularly important that the contrary arguments were also fully presented to the court.
**Direct discrimination**

**[13]** _[Section 13(1) of the Equality Act 2010 provides that 'A person (A) discriminates against another (B) if, because](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-746R-00000-00&context=1519360)_
of a protected characteristic, A treats B less favourably than A treats or would treat others'. By s 4 of the Act, race is
a protected characteristic. By s 9(1) race 'includes—(a) colour, (b) nationality, and (c) ethnic or national origins'. By
s 39(2), 'An employer (A) must not discriminate against an employee of A's (B)—(a) as to B's terms of employment,
(b) in the way A affords B access, or by not affording B access, to opportunities for promotion, transfer or training or
for receiving any other benefit, facility or service, (c) by dismissing B, (d) by subjecting B to any other detriment.'
[The previous provisions of the Race Relations Act 1976 were to the same effect.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y093-00000-00&context=1519360)

**[14] There can be no doubt that the conduct of these employers would amount to unlawful direct discrimination if it**
was 'on racial grounds' (under the 1976 Act) or 'because of' race (under the 2010 Act), which includes nationality.
These employees were treated disgracefully, in a way which employees who did not share their vulnerable
immigration status would not have been treated. As the employment tribunals found, this was because of the
vulnerability associated with their immigration status. The issue for us is a simple one: does discrimination on
grounds of immigration status amount to discrimination on grounds of nationality under the 1976 and 2010 Acts?
On the face of it, the two are different. What basis is there for saying that they are the same?

**[15] Mr Robin Allen QC, who has said all that could possibly be said on behalf of the appellants, makes two basic**
points. First, he argues that immigration status is a function of nationality. It is indissociable from it. British nationals
have a right of abode here which cannot be denied. All non-British nationals are potentially subject to immigration
control. They require leave to enter and leave to remain. These can be granted for limited periods and on limited
terms. Even those granted indefinite leave to remain may have that status withdrawn.

**[16] Secondly, he points to the flexible approach which has been adopted to the concept of nationality in other**
contexts. Thus, art 14 of the European Convention for the Protection of Human Rights and Fundamental Freedoms
1950 (as set out in Sch 1 to the Human Rights Act 1998) forbids discrimination in the enjoyment of the Convention
rights on 'any ground such
**[*994]**

as … national or social origin … or other status'. In _R (on the application of Morris) v Westminster City Council_

_[2004] EWHC 2191 (Admin),_ _[[2005] 1 All ER 351, [2005] 1 WLR 865, it was held incompatible with art 14 of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FF1-RR30-TWP1-617G-00000-00&context=1519360)_


-----

ECHR, read with art 8, to deny a priority need for accommodation on the ground that a non-British child was subject
to immigration control while her British mother was not.

**[[17] By s 28 of the Crime and Disorder Act 1998, an offence is racially aggravated if the offender shows at the time,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61G0-TWPY-Y19P-00000-00&context=1519360)**
or is motivated by, hostility towards members of a racial group to which the victim belongs or is assumed to belong.
By s 28(4) a racial group means 'a group of persons defined by reference to race, colour, nationality (including
citizenship) or ethnic or national origins'. In A-G's Reference (No 4 of 2004) _[[2005] EWCA Crim 889, [2005] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JST1-DYBP-N2Y4-00000-00&context=1519360)_
2810, calling a doctor an 'immigrant doctor' was enough to establish that an assault was racially motivated: the
epithets 'Indian' and 'immigrant' were both 'clearly referable to his nationality and national origins'. In _R v Rogers_

_[[2007] UKHL 8, [2007] 2 All ER 433, [2007] 2 AC 62, it was held that calling people 'bloody foreigners', although](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4NM5-JYV0-TWP1-60DV-00000-00&context=1519360)_
without reference to a specific nationality, amounted to racially aggravated abuse.

**[18] Mr Allen also points out that the United Kingdom Border and Immigration Agency's Code of Practice,**
_Prevention of illegal working: Guidance for employers on the avoidance of unlawful discrimination in employment_
_practices while seeking to prevent unlawful working (2008), gives as an example of direct discrimination on racial_
grounds, giving an employee with limited leave to remain more degrading forms of work in comparison with
employees with unlimited leave (para 3.2).

**[19] None of these examples is very helpful in deciding the issue which we have to decide. Article 14 of the ECHR**
contains an open-ended list of characteristics which may result in unjustified discrimination in the enjoyment of the
rights protected by the convention, ending in 'other status'. Foreign residence has been held to be a status for this
purpose, so it is quite clear that immigration status also qualifies. There was no need to distinguish between this
and nationality in the Morris case and so the fact that it was regarded as nationality discrimination is neither here
nor there. The courts were not required to address their minds to the difference, if any, between the two, as we are
here.

**[20] Similarly, when deciding whether an offence is racially aggravated for the purpose of the 1998 Act, the**
distinction is unlikely to be relevant. 'Bloody foreigners' is in any event a reference to nationality. AG's Reference
_(No 4 of 2004) is closer to this case, but it is easy to justify a liberal approach to a statute which recognises that_
some forms of criminal behaviour are more hurtful to the victim and more damaging to society than others. The
courts had recognised this in their sentencing policies before the 1998 Act was enacted.

**[21] The** _[Equality Act 2010,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_ and its predecessors, are very different. Generally speaking, the suppliers of
employment, accommodation, goods and services are allowed to choose with whom they will do business. There is
freedom to contract, or to refuse to contract, with whomever one pleases. The 2010 Act limits that freedom of
contract (and also the freedom of suppliers of public services). It does so in order to protect specified groups who
have historically been discriminated against by those suppliers, shut out of access to the employment,
accommodation, goods and services they supply, for irrelevant
**[*995]**

reasons which they can do nothing about. In that context, the dividing line between which characteristics are
protected and which are not protected is crucial.

**[22] Parliament could have chosen to include immigration status in the list of protected characteristics, but it did not**
do so. There may or may not be good reasons for this—certainly, Parliament would have had to provide specific
defences to such claims, to cater for the fact that many people coming here with limited leave to remain, or entering
or remaining here without any such leave at all, are not allowed to work and may be denied access to certain public
services. So the only question is whether immigration status is so closely associated with nationality that they are
indissociable for this purpose.

**[23] Mr Allen is entirely correct to say that immigration status is a 'function' of nationality. British nationals**
automatically have the right of abode here. Non-British nationals (apart from Irish citizens) are subject to
immigration control. But there is a wide variety of immigration statuses. Some non-nationals enter illegally and have
no status at all. Some are given temporary admission which does not even count as leave to enter. Some are


-----

initially given limited leave to enter but remain here without leave after that has expired. Some continue for several
years with only limited leave to enter or remain. Some are allowed to work and some are not. Some are given
indefinite leave to remain which brings with it most of the features associated with citizenship.

**[24] In these cases, Ms Taiwo and Ms Onu had limited leave to enter on domestic workers' visas. It was the terms**
of those visas which made them particularly vulnerable to the mistreatment which they suffered. At the relevant
time, such visas were granted to workers who had already been working abroad for the employer, or the employer's
family, for at least a year; typically they would be granted for a year, though renewable; and the employee would
have to seek the approval of the immigration authorities for any change of employer while here. In practice,
therefore, such workers were usually dependent upon their current employers for their continued right to live and
work in this country.

**[25] The Independent Review of the Overseas Domestic Workers Visa (2015), commissioned by the Home Office,**
identified ten reasons for these workers' particular vulnerability: their motivation and mentality is one of desperation,
born of their inability to find work or earn enough to support their families in their home country (sometimes having
left that country to work elsewhere before being brought to this country); they are without the safety net of friends
and family and other support networks; they are often unfamiliar with the culture and language, which represents a
significant barrier to wider social interaction; they often work long hours; they often do not know their legal rights;
they mainly work in private homes, which are less easy to regulate; their work is often part of an informal economy,
paid in cash and not declared to the tax authorities; their permission to be here depends upon their employers' want
or need of them; they have no recourse to public funds; and those employed by diplomats may have to combat
claims of diplomatic immunity. Those, like the claimant in _Hounga v Allen [2014] UKSC 47,_ _[[2014] 4 All ER 595,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DMS-8XS1-DYBP-M3G0-00000-00&context=1519360)_

[2014] 1 WLR 2889, who have come here as visitors without permission to work and stayed here illegally, are even
more vulnerable.

**[26] Clearly, however, there are many non-British nationals living and working here who do not share this**
vulnerability. No doubt, if these employers had employed British nationals to work for them in their homes, they
would
**[*996]**

not have treated them so badly. They would probably not have been given the opportunity to do so. But equally, if
they had employed non-British nationals who had the right to live and work here, they would not have treated them
so badly. The reason why these employees were treated so badly was their particular vulnerability arising, at least
in part, from their particular immigration status. As Mr Rahman pointed out, on behalf of Mr and Mrs Akwiwu, it had
nothing to do with the fact that they were Nigerians. The employers too were non-nationals, but they were not
vulnerable in the same way.

**[27] That, in my view, is enough to dispose of the direct discrimination claim. But it is consistent with the approach**
[of this court in the cases of Patmalniece v Secretary of State for Work and Pensions [2011] UKSC 11, [2011] 3 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5340-0831-DYBP-M519-00000-00&context=1519360)
_[ER 1, [2011] 1 WLR 783, which in turn applied the approach of the European Court of Justice in the cases of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5340-0831-DYBP-M519-00000-00&context=1519360)_
_Schnorbus v Land Hessen (Case C-79/99) EU:C:2000:370, EU:C:2000:676, [2000] ECR I-10997, [2001] 1 CMLR_
1025 and Bressol v Gouvernement de la Communauteì Française, Chaverot v Gouvernement de la Communauteì
_Française (Case C-73/08) EU:C:2009:396, EU:C:2010:181, [2010] ECR I-2735, [2010] 3 CMLR 559, and Bull v Hall_

_[[2013] UKSC 73, [2014] 1 All ER 919, sub nom Preddy v Bull (Liberty intervening) [2013] 1 WLR 3741. These were](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BK0-1R21-DYBP-M43P-00000-00&context=1519360)_
cases, not about whether a particular characteristic fell within the definition of a protected characteristic in the 2010
Act, but about whether the conduct complained of amounted to direct or indirect discrimination. There was no doubt
that it was one or the other.

**[28]** _Patmalniece_ was about whether a residence requirement, which all British nationals, but not all non-British
nationals, could meet was directly discriminatory on grounds of nationality. In Schnorbus, Advocate General Jacobs
had said this (at para 33):


-----

'The discrimination is direct where the difference in treatment is based on a criterion which is either explicitly
that of sex or necessarily linked to a characteristic indissociable from sex. It is indirect where some other
criterion is applied but a substantially higher proportion of one sex than of the other is in fact affected.'

This concept of indissociability was taken up by Advocate General Sharpston in Bressol, where the facts were very
similar to those in Patmalniece, and formulated thus (at para 56):

'I take there to be direct discrimination when the category of those receiving a certain advantage and the
category of those suffering a correlative disadvantage coincide exactly with the respective categories of
persons distinguished only by applying a prohibited classification.'

In all three cases, the discrimination was held to be indirect rather than direct (the Court of Justice disagreeing with
the Advocate General in _Bressol). There was not an exact correspondence between the advantaged and_
disadvantaged groups and the protected characteristic, as some of those distinguished by their nationality were not
disadvantaged, although others were.

**[29] The same approach was adopted in Bull v Hall, where Christian hotel keepers would deny a double bedded**
room to all unmarried couples, whether of opposite sexes or the same sex. That would undoubtedly have been
indirect discrimination, as same sex couples were not then able to marry and thus fulfil the criterion, whereas
opposite sex couples could do so if they chose. But the majority held that it was direct discrimination, because the
hotel keepers
**[*997]**

expressly discriminated between heterosexual and non-heterosexual married couples. The couple in question were
in a civil partnership, which for all legal purposes is the same as marriage.

**[30] Mr Allen argues that these cases can be distinguished, because they were cases in which an express criterion**
was being applied, be it nationality or heterosexuality, whereas these appeals are not concerned with such a
criterion or test, but with the mental processes of the employers. But that makes no difference. In 'mental
processes' cases, it is still necessary to determine what criterion was in fact being adopted by the alleged
discriminator—whether sex, race, ethnicity or whatever—and it has to be one which falls within the prohibited
characteristics. The point about this case is that the criterion in fact being adopted by these employers was not
nationality but, as Mr Allen freely acknowledges, being 'a particular kind of migrant worker, her particular status
making her vulnerable to abuse'.
**Indirect discrimination**

**[31] Mr Allen accepts that this is not a case of indirect discrimination. It is direct discrimination or nothing. In my**
view he is wise to do so, but the fact that these cases cannot be fitted into the concept of indirect discrimination is
further support for the view that the mistreatment here was not because of the employees' race but for other
reasons. Indirect discrimination is defined in s 19 of the 2010 Act thus:

'(1) A person (A) discriminates against another (B) if A applies to B a provision, criterion or practice which is
discriminatory in relation to a relevant protected characteristic of B's.

(2) For the purposes of subsection (1), a provision, criterion or practice is discriminatory in relation to a relevant
protected characteristic of B's if—

(a) A applies, or would apply, it to persons with whom B does not share the characteristic,

(b) it puts, or would put, persons with whom B shares the characteristic at a particular disadvantage when
compared with persons with whom B does not share it,

(c) it puts, or would put, B at that disadvantage, and

(d) A cannot show it to be a proportionate means of achieving a legitimate aim.'


-----

**[32] The concept in the 1976 Act was differently worded, but the basic principle is the same. An employer or**
supplier has a rule or practice which he applies to all employees or customers, actual or would-be, but which
favours one group over another and cannot objectively be justified. Requiring all employees to sport a moustache is
obviously indirectly discriminatory against women. The problem in this case is that no-one can think of a 'provision,
criterion or practice' which these employers would have applied to all their employees, whether or not they had the
particular immigration status of these employees. The only PCP which anyone can think of is the mistreatment and
exploitation of workers who are vulnerable because of their immigration status. By definition, this would not be
applied to workers who are not so vulnerable. Applying it to these workers cannot therefore be indirect
discrimination within the meaning of s 19 of the 2010 Act.

**[33] In disclaiming any reliance on indirect discrimination in these cases, Mr Allen urges the court not to rule out the**
possibility that, in other cases
**[*998]**

involving the exploitation of migrant workers, it may be possible to discern a PCP which has an indirectly
discriminatory effect. I am happy to accept that: in this context 'never say never' is wise advice.
**Conclusion**

**[34] It follows that these appeals must fail. This is not because these appellants do not deserve a remedy for all the**
grievous harms they have suffered. It is because the present law, although it can redress some of those harms,
[cannot redress them all. Parliament may well wish to address its mind to whether the remedy provided by s 8 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C270-00000-00&context=1519360)
**_Modern Slavery Act 2015 is too restrictive in its scope and whether an employment tribunal should have_**
jurisdiction to grant some recompense for the ill-treatment meted out to workers such as these, along with the other
remedies which it does have power to grant.

Appeals dismissed.

Karina Weller Solicitor (NSW) (non-practising).

**End of Document**


-----

