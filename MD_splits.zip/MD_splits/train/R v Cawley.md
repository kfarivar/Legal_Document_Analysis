# R v Cawley [2023] EWCA Crim 76

Court of Appeal, Criminal Division

Singh LJ, McGowan J, Picken J

24 January 2023Judgment

**Mr A Roxborough appeared on behalf of the Applicant**

**Mr T E Sherrington appeared on behalf of the Crown**

**____________________**

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

Monday 24th January 2023

**LORD JUSTICE SINGH:**

1. This is an application for leave to appeal against sentence which has been referred to the full court by the
Registrar because it would appear that some of the sentences imposed in the Crown Court were unlawful, as
indeed is common ground before us now. We make it clear at the outset that we grant leave to appeal and proceed
to determine this case as an appeal against sentence. We have been assisted by both written and succinct oral
submissions by counsel for the appellant, Mr Roxborough, and counsel for the prosecution, Mr Sherrington.

2. The facts are inevitably lengthy but can, we hope, be summarised for present purposes as follows.

3. The appellant fell to be sentenced in the Crown Court for a large number of offences. They totalled, so far as
relevant, 16 matters. As will become clear, as a matter of law, the sentences which were imposed on five of those
matters were lawful. The others, regrettably, were not.

4. The first matter was the burglary of a non-dwelling on 5th October 2021. The appellant and another male
entered the Maxwell Building at Salford University. The door had not been closed properly by security. They took
two electric bikes and chargers which were stored in the security vestibule. Each bike was valued at £1,139.

5. The appellant was identified by a police officer from CCTV footage of the area. He was arrested and
interviewed. He answered "No comment" to all questions asked.


-----

6. The second matter was a non-dwelling burglary committed on 13th October 2021. The appellant and another
male attended a Travelodge on River Street in Bolton. They followed a hotel guest inside and poured themselves a
glass of orange juice. They then gained access to the staff area and stole debit cards, £20 in cash and two packets
of cigarettes.

7. The appellant was identified in February 2022 when fingerprints taken from the orange juice glass were matched
to his.

8. The third matter was a dwelling burglary committed on 25th November 2021. The appellant entered a property
on Victoria Street in Rochdale. The home owners were present but did not see him enter the property. The
appellant stole the keys to a Volkswagen Golf vehicle and drove it away. The home owners were unaware until
they saw that the car and the keys missing. A wallet was also missing. The couple traced their car using a tracker
on their phone and managed to reclaim it. The appellant was later identified from CCTV footage.

9. There then followed a series of offences in January 2022 which were committed with a co-defendant, Lewis
Brierley. On 4th January 2022, there was the theft of a motor vehicle. The appellant and Brierley drove near an
address in Shaw, where they found a Mr Borg unloading shopping from his Land Rover Freelander. Mr Borg left
the keys in the vehicle. The appellant took the opportunity to jump into it and drive away. The car contained Mr
Borg's work tools with a value of between £3,000 and £4,000. The appellant was identified from CCTV. The car
was recovered on 10th January 2022 bearing false registration plates.

10. On 5th January 2022, there was a non-dwelling burglary. The appellant and Brierley attended Modern
Plumbing Solutions in Bury in a stolen Land Rover. The appellant exited the vehicle and entered the premises. He
took the keys to another Land Rover and two Ford Transit vans. Brierley had a machete which was not seen by the
complainant, a Mr O'Donoghue, although he did hear the appellant ask Brierley to pass it to him. The keys were
not recovered. The appellant was identified from CCTV footage.

11. Shortly after that incident, there was an attempted burglary of a dwelling. The appellant and Brierley drove to
an address in Blenheim Close in Bury. The complainant was a Ms Walmsley. She was at home with her 6 year old
child when she heard her front door open. She walked to the door and saw the appellant crouching next to it. She
asked what he was doing and he walked away. The appellant was identified from the Ring Doorbell footage.

12. On 7th January 2022, there was an offence of robbery. The complainant, a Mr Pearson, was at his address on
Bury Old Road carrying out work on a BMW vehicle in his garage. He watched the appellant approach the garage.
The appellant asked him twice for the keys. He was told to "fuck off" and the appellant left. The appellant then
returned with Brierley who was holding a machete. They repeatedly asked for the keys. Brierley chased Mr
Pearson around the garage with the machete and a red axle that he had picked up. At one point the appellant took
the machete and threatened the complainant. He also attempted to pull away an e-bike and a quad bike that were
chained up. They were unsuccessful in stealing any vehicles but did steal the key fobs that controlled the entry to
the garage. They left in the stolen Land Rover. The appellant was identified from CCTV.

13. An hour after that incident, there was an attempted non-dwelling burglary and an interference with a vehicle.
The appellant and Brierley drove to Pennine Industrial Estate in Rochdale. The appellant exited the Land Rover at
Worldwide Foods and attempted to take a Mercedes Sprinter vehicle which he had entered but for which he was
unable to find the keys.

14. There was then an offence of theft. The appellant and Brierley forced entry to a Mercedes E250 by throwing
objects at the window. He stole a gym bag belonging to a Mr Chaudry containing various items including Air Pods
and a Gucci wallet. The appellant was identified from CCTV.

15. On 11th January, there was an attempted burglary of a non-dwelling. The appellant and Brierley drove a
Vauxhall Corsa into the forecourt of Williams BMW. The appellant exited the vehicle and began to look at cars in
the workshop, which was off limit to the public. When confronted by a member of staff, he said, "Fuck off or I'll stab
you", and left in the Corsa. He was identified from CCTV.


-----

16. Four minutes later, there was an attempted burglary of a non-dwelling. The appellant and Brierley attended
Car Time in Rochdale, which was across the road from the BMW garage. The appellant exited the Corsa and
walked into a private workshop area. He approached a Honda vehicle and tried the doors. He was confronted by
staff, at which point his co-defendant joined him. They then returned to the Corsa and drove off. On his return to
the Corsa, the appellant jumped on an Audi A3, causing some damage. He was identified from CCTV.

17. Forty minutes later, the offence of making off without payment was committed. The appellant and Brierley
attended a petrol station in the Corsa, filled it up and drove away.

18. Ten minutes after that, there was a burglary of a non-dwelling. The appellant and Brierley attended Stone Acre
car showroom in Rochdale. The appellant exited the Corsa, tried the door of another vehicle, entered the valet bay,
stole three sets of house keys and keys to a Fiat from the bag of a member of staff, and returned to the Corsa.
They were about to drive away when they spotted a member of the public parking a silver estate. The appellant
exited the Corsa, went to that vehicle, opened the doors and searched the front. He was disturbed by the owner
and ran back to the Corsa. He was identified from CCTV.

19. The next offence was one of robbery, committed on 12th April 2022. The appellant entered Car Time in
Rochdale. A receptionist, a Ms Vickers, saw the appellant in a Renault Capture vehicle. The appellant started the
vehicle as if to drive off. Ms Vickers leant into the vehicle through the open passenger door and pulled the
handbrake. The appellant shouted, "What the fuck are you doing, you slag?" and shoved her head to push her out
of the car. The appellant reversed the vehicle. Ms Vickers was afraid that she would be squashed into another
vehicle that was parked next to it in the garage. The appellant reversed the vehicle out of the garage. In doing so,
the open door of the car collided with another vehicle. The appellant then made off in the Renault.

20. The final offence was one of handling stolen goods on 3rd May 2022. On 1st May 2022, a Mr Toner parked
his Ford B-Max outside the Royal Court Theatre in Bacup. When he returned to his vehicle at around 5 pm it was
gone. In its place was smashed glass from the windows. The car had contained two jump leads, two computers
and a child seat. The appellant was identified by a police officer from CCTV. He had committed the offence with
two others: Thomas Cawley (the appellant's cousin, aged 21) and Kyle Binns (aged 20). The car was recovered
with new number plates.

21. The appellant was aged 17 at the time both of the commission of the offences and at the date of sentence,
although he has since turned 18. He had four previous convictions for 12 offences. His first conviction was in July
2020. He had not previously received a custodial sentence.

22. The sentencing court had the benefit, as have we, of a pre-sentence report, an addendum to that report, and
also a speech, language and communication assessment. That court, like this, also had the benefit of victim
personal statements from the various victims involved.

23. The appellant had appeared before the Magistrates' Court and had pleaded guilty to the various offences. He
was then committed to the Crown Court for sentence. The sentencing hearing took place on 2nd September 2022
in the Crown Court at Manchester, where Mr Recorder Ford imposed the following sentences: on the first matter
(burglary of a non-dwelling), three months' detention; on the second matter (theft of a motor vehicle), two months'
detention, to run consecutively; on the third matter (attempted burglary of a dwelling), six months' detention, to run
consecutively; on the fourth matter (burglary of a non-dwelling), 12 months' detention, to run consecutively; on the
fifth matter (vehicle interference), no separate penalty was imposed; and on the sixth matter (theft from a motor
vehicle), one month's detention, to run concurrently. The most serious offence, in the Recorder's view, was the
robbery on 7th January 2022, for which the appellant was sentenced to two years and eight months' detention,
which was ordered to run consecutively to the other sentences. On the eighth matter (attempted burglary of a nondwelling) he was sentenced to four months' detention, which was ordered to run concurrently. On the ninth matter
(making off without payment), no separate penalty was ordered. On the tenth matter (burglary of a non-dwelling),
he was sentenced to four months' detention, ordered to run concurrently. On the eleventh matter (attempted
burglary of a non-dwelling), he was sentenced to four months' detention, to run consecutively. On the twelfth matter
(attempted burglary of a non-dwelling), he was sentenced to six months' detention, ordered to run concurrently. On


-----

the thirteenth matter (burglary of a non-dwelling), he was sentenced to three months' detention, which was ordered
to run consecutively On the fourteenth matter (handling stolen goods), he was sentenced to one month's detention,
to run consecutively On the fifteenth matter (burglary of a dwelling), he was sentenced to eight months' detention,
to run consecutively.  Finally, for another offence of robbery, he was sentenced to 12 months' detention, which was
ordered to run consecutively. Those sentences totalled six years and eight months' detention.

24. A statutory surcharge was not imposed at the time, but we are informed at this hearing that that was corrected
by the Crown Court subsequently. We need say no more about that.

25. We should mention that the co-defendant, Brierley, who was born on 29th August 2001, pleaded guilty to two
counts of non-dwelling burglary, one count of robbery, one count of having an article with a blade or point, and two
counts of theft. He was sentenced by a different Recorder at another hearing in total to 50 months' detention in a
young offender institution.

26. As is now common ground before this court, in the light of a helpful note which has been provided by the
Registrar, the committals in respect of a number of the offences were, in truth, not lawful. The committals were
lawful in respect of the offences of robbery, burglary of a dwelling (including attempted burglary) and handling
stolen goods. The remaining offences did not satisfy the requirements of section 16 of the Sentencing Act 2020
("the Sentencing Code"), and therefore the committals for sentence pursuant to section 16 were unlawful to that
extent.

27. However, a memorandum of conviction that purports to have committed an offender under a statutory power
unavailable to the Magistrates' Court does not affect the validity of the committal, provided that the magistrates had
the necessary jurisdiction to make the committal: see R v Ayhan [2011] EWCA Crim 3184, [2012] 1 WLR 1775. In
the present case, section 20 of the Sentencing Code provided the necessary jurisdiction to make the committals for
those offences falling outside the remit of section 16.

28. Of more material significance is the consideration that the majority of the sentences imposed in this case were,
in truth, unlawful. The power to impose detention under section 250 of the Sentencing Code applies where a
person aged under 18 is convicted on indictment of (so far as material to the present case) an offence punishable in
the case of a person aged 21 or over with imprisonment for 14 years or more, not being an offence the sentence for
which is fixed by law. Furthermore, that power may only be exercised if the court is of the opinion that neither a
Youth Rehabilitation Order or a Detention and Training Order is suitable: see section 251(2) of the Sentencing
Code.

29. In the present case, the Recorder identified that the two offences of robbery fell into the category of offences
punishable with imprisonment for a term of 14 years or more. He went on to say that in respect of those offences
neither a Youth Rehabilitation Order, nor a Detention and Training Order was suitable.

30. The Recorder imposed custodial sentences for the remaining offences, with the exception of the offence of
vehicle interference, but did not specify whether the sentences were detention, pursuant to section 250 of the
Sentencing Code, or were Detention and Training Orders. In fact, and regrettably, the Recorder erroneously
referred to the custodial sentences as terms of "imprisonment".

31. The offences of burglary of a dwelling, attempted burglary of a dwelling and handling stolen goods are all
offences for which the maximum sentence in the case of a person over 21 would be 14 years' imprisonment, and
therefore, as a matter of law, sentences of detention could have been imposed. The remaining offences did not
satisfy the requirements of the Sentencing Code. Accordingly, the only custodial sentence in principle that would
have been available is a Detention and Training Order. A Detention and Training Order must be at least four
months in length (some of these sentences were not), and must not exceed 24 months: see section 236(1) of the
Sentencing Code, as amended by the _[Police, Crime, Sentencing and Courts Act 2022. The court may pass](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F9-MJP3-GXF6-80DM-00000-00&context=1519360)_
consecutive Detention and Training Orders, so long as the aggregate of the orders does not exceed two years. Any
period in excess of 24 months is automatically remitted: see section 238(2). If the intention in the present case was
that Detention and Training Orders were passed for the offences of non-dwelling burglary, theft from a motor


-----

vehicle and handling stolen goods, the sentences would have been in contravention of section 236(1), because
they were less than four months in length. Furthermore, depending on whether the offences of dwelling burglary
and handling stolen goods attracted a sentence of detention or a Detention and Training Order, the total length of a
putative Detention and Training Order may have exceeded 24 months.

32. When considering a case in which it is possible to impose a Detention and Training Order and a term of
detention consecutively – for example, because one of the offences does not carry a maximum custodial sentence
of 14 years or more – the suggestion made in Archbold (2023 edition) at paragraph 5A-1216 is that the court may
impose only a sentence of detention under section 250 for a period of time commensurate with the whole of the
offending, including those offences for which detention under section 250 is not available. It is suggested, though,
that the court could then impose no separate penalty for the other offences, provided that they do not attract
mandatory sentences. That approach was endorsed by counsel for both sides appearing before us.

33. As a factual matter, the parties were notified of these difficulties about the lawfulness of the sentences imposed
and invited to have the matter relisted under the "slip rule". At today's hearing, we were informed by counsel that
efforts were made to have the case listed under the slip rule. In fact, we were informed by Mr Sherrington that a
date was obtained for a hearing in the Crown Court, but, inexplicably, the case came out of the list. In any event,
the time limit for such correction under the slip rule then expired. Accordingly, for that reason, if no other, the case
has had to be brought before this court.

34. On behalf or the appellant, Mr Roxborough submits, first, that the Recorder gave insufficient reduction to take
account of the appellant's youth and personal mitigation. This is because he indicated in his sentencing remarks
that he would allow a 33 per cent discount to reflect both the appellant's guilty pleas and his age. Mr Roxborough
submits that the appellant was entitled to a 33 per cent discount for his guilty pleas alone. Further, he submits that
the pre-sentence report and the report on language and communication assessment made it clear that the appellant
is an extremely troubled young man with many difficulties. He had no formal education and had severe learning
difficulties. At the time of his assessment he was found to be (in educational terms) between seven and nine years
behind the average for his chronological age. Mr Roxborough submits that by reference to the overarching
principles governing the sentencing of young offenders, this should have led to a sentence which was considerably
shorter than that which would be appropriate for an adult.

35. Next, Mr Roxborough submits that the Recorder did not have sufficient regard to the principle of totality. The
sentence he arrived at was equivalent, it is said, to a sentence of around 11 years' custody, had there been a trial.
It is submitted that such a sentence would have been "way too high".

36. Finally, Mr Roxborough draws attention to the disparity with the sentence imposed on Brierley. He submits that
the sentence imposed upon the appellant was 30 months longer than that imposed upon Brierley, for what he
describes as essentially the same offending. He points out that Brierley was at least three years older than the
appellant, and had not faced the educational difficulties which the appellant has.

37. On behalf of the respondent, Mr Sherrington has filed a Respondent's Notice and has assisted this court with
brief oral submissions as well. Mr Sherrington submits, first, that in respect of the appellant's age, it is accepted
that it is unclear from the sentencing remarks (at page 11) whether the Recorder applied the 33 per cent discount
for both the guilty pleas and the appellant's age. However, it should be noted, submits Mr Sherrington, that earlier
in his sentencing remarks (at page 7), the Recorder had indicated (to take only one example) that the armed
robbery committed on 7th January 2022, which was considered by him to be the most serious offence, had a
starting point of 60 months' custody. That would have been for an adult offender of good character after trial. The
appellant had previous convictions and was in breach of a Youth Rehabilitation Order. In fact, the appellant was
eventually sentenced to 32 months' custody. As a matter of arithmetic, that shows that he must have received
more that a one-third discount. Mr Sherrington submits that the same principle was no doubt applied by the
Recorder to all the sentences imposed.


-----

38. Secondly, Mr Sherrington submits that the Recorder did have regard to the principle of totality. The appellant
was sentenced for a total of 16 offences (not including the breach of the Youth Rehabilitation Order) and received
consecutive sentences for only seven of them.

39. Turning to the sentence passed on Brierley, Mr Sherrington submits that each case is different and that these
two defendants were dealt with by different judges. Although Brierley was older, the Recorder made it clear that he
did not consider the appellant to have acted under coercion or control; nor was there any indication of **_modern_**
**_slavery. Furthermore, the appellant ultimately received a sentence of 32 months' detention for the most serious_**
offence (the robbery on 7th January 2022), whereas Brierley was given a custodial sentence of 50 months. Of
course, in the case of Brierly, those sentences were ordered to run concurrently. But the fundamental point which
Mr Sherrington makes is that the appellant's true complaint is that the sentences in the present case were not all
ordered to run concurrently with each other. That was a matter within the discretion of the sentencing judge.

40. All of that said, Mr Sherrington does accept that the Recorder erred by not distinguishing the nature of the
sentences passed for offences that fell outside the scope of section 250 of the Sentencing Code, the length of
those sentences, and the correct procedure which is suggested in Archbold.

41. We turn to our assessment of this appeal. On any view, the Recorder had a complicated sentencing exercise
to perform. He had to sentence for a total of 16 offences, so far as relevant. The most serious of those were the
two robberies. There is some force in the submission made by Mr Roxborough relating to the appellant's youth and
his educational difficulties. On the other hand, there was a large number of offences, including separate victims.
There were aggravating features, including the appellant's previous record and a breach of a court order.
Furthermore, a machete was carried in the most serious offence of robbery.

42. We are unimpressed with the alleged disparity argument for the reasons given by Mr Sherrington. The codefendant Brierley was sentenced for fewer offences. Although the sentence imposed upon Brierley was lower
than that imposed upon the appellant, in fact the sentence imposed for the main offence of robbery was higher than
it was for the appellant, although we note that the other sentences were ordered to run concurrently. Furthermore,
it is regrettable that the Recorder in the present case appeared to say that the one-third discount he would give
included a discount not only for the guilty pleas, but for other mitigation. When read as a whole, we consider that to
be a slip of the tongue. Other parts of his sentencing remarks do indicate that in fact he gave a greater reduction
than one-third, which must have been to reflect the mitigation that was otherwise available.

43. Nevertheless, in all the circumstances of this case, we have come to the conclusion that the sentences were
manifestly excessive because insufficient account was taken of the appellant's youth and immaturity. Further, we
must deal with the important point that the majority of the sentences passed were, in truth, unlawful.

44. Accordingly, in our judgment, justice can be done in the present appeal by structuring the sentence as follows.
We will quash all of the unlawful sentences, but impose no separate penalty on them. That would leave in place all
five lawful sentences, as they were. We calculate that that makes a total of 59 months' detention (four years and
eleven months). In our judgment, that total reflects the overall justice of the case and is a just and proportionate
sentence for the entire offending of which the appellant was guilty.

____________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________


-----

**End of Document**


-----

