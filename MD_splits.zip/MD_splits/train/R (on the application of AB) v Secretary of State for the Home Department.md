# R (on the application of AB) v Secretary of State for the Home Department

 [2019] EWHC 1969 (Admin)

Queen's Bench Division, Administrative Court (London)

Dan Squires QC (sitting as a deputy judge of the High Court)

17 July 2019Judgment

**Ronan Toal (instructed by Wilson Solicitors LLP) for the Claimant**

**Jennifer Gray (instructed by Government Legal Department) for the Defendant**

Hearing date: 18 June 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Dan Squires QC sitting as a Deputy High Court Judge:**

**Introduction**

1. The Claimant is a foreign national who has been in immigration detention since 4 February 2018. The
Defendant is the Secretary of State for the Home Department (“the Secretary of State”).

2. This claim for judicial review concerns the legality of the Claimant's detention for the period from 27
March 2019 and currently ongoing. On 1 May 2019 Laing J granted permission to the Claimant to
challenge: (i) the lawfulness of his detention from 27 March 2019 and (ii) the lawfulness of the decision to
maintain the Claimant's detention after a place in Approved Premises (“AP”) became available for him on
30 April 2019. As to (i), the Claimant contends that, in breach of Home Office Guidance, insufficient weight
was given to recommendations of the Secretary of State's Case Progression Panel that he be released
and/or insufficient reasons were given for disagreeing with the Panel's recommendations, and that had the
recommendations been followed he would have been released on 27 March 2019. As to (ii), the Claimant
contends that his detention, in any event, became unlawful on 30 April 2019 when the AP place became
available as he then satisfied the conditions for immigration bail, granted by the First Tier Tribunal on 2
April 2019. The Secretary of State maintains that the Claimant's detention was at all times lawful, but that if
any errors were made in the detention process they did not alter the outcome, which is that the Claimant
would have been properly detained throughout the material time in any event.

3. As will become clear below, a number of matters arose shortly before and during the hearing on 18
June 2019 and new material provided to me at the hearing. I gave the parties the opportunity to make
written submissions on those matters after the hearing was complete. I am grateful to the parties for those
submissions and grateful to counsel for the clear and helpful way the rival cases were put orally and in
writing.

**Factual background**

**The Claimant's immigration history**

4 The Claimant is a Somali national ho as born on 1 March 1996


-----

5. On 30 March 2014 the Claimant arrived in the UK and claimed asylum at port. In his asylum interview
he gave an account of having been abducted in 2013 from his home in Somalia by Al-Shabaab (the armed
group that had, at various times, controlled substantial portions of Somalia). Prior to the abduction the
Claimant lived with his family at a camp for Internally Displaced Persons in Elasha Biyaha (a town on the
outskirts of Mogadishu). After he was abducted the Claimant claimed to have then been detained for
several months and forced to work for Al-Shabaab in their camp - cooking, cleaning and doing agricultural
work. He claimed that he managed to escape from the camp when there was fighting between Al-Shabaab
and another armed group. About two months later, he left Somalia and travelled to the UK.

6. The thrust of the Claimant's asylum claim on arrival in the UK was that he feared a return to Somalia
because he would be targeted by Al-Shabaab, in particular as he was a member of a minority clan, the
Sheqel.

7. On 14 January 2015 the Claimant was refused asylum. The Secretary of State accepted that he had
“incidents with Al-Shabaab” in Somalia, but concluded that he would not be at real risk of harm from them if
he returned.

8. The Claimant appealed the Secretary of State's decision to the First Tier Tribunal (“the FTT”). On 19
March 2015 his appeal was dismissed. The judge found that although he had suffered serious harm from
his capture and subsequent treatment by Al-Shabaab, he did not have a well-founded fear of further harm
from the group. The judge found that the Claimant was not at risk of harm falling within Articles 2 or 3 of the
European Convention of Human Right (“ECHR”) and his Article 8 claim also failed. Permission to appeal to
the Upper Tribunal was refused on 3 August 2015.

9. On 27 November 2015 the Claimant was convicted of a sexual assault by Doncaster Magistrates. On
29 January 2016 he was convicted of battery by the same Magistrates. On 25 July 2016, at Bradford
Crown Court, the Claimant was convicted of wounding with intent to do grievous bodily harm, assault by
beating and breach of a bail order for failing to surrender to custody at an appointed time. He was
sentenced to 3 years and 8 months imprisonment. The grievous bodily harm conviction followed the
Claimant stabbing his partner in the head with a steak knife. According to the judge's sentencing remarks,
the Claimant initially did not call the emergency services believing it would lead to his apprehension.
Subsequently the Claimant called the police claiming he had been attacked by the victim.

10. On 6 August 2016 the Secretary of State determined that the Claimant was liable for deportation and
on 29 November 2016 a deportation order was made against him. On receipt of the deportation order the
Claimant stated he feared returning to Somalia. That was taken to be a further asylum claim.

11. On 11 January 2017 the Claimant underwent an asylum screening interview. He again claimed that his
life was in danger from Al-Shabaab. He explained that his claim was now different, as his mother had been
killed by Al-Shabaab in early 2015. On 3 February 2017 the Claimant presented further submissions in
support of his asylum claim in the form of a handwritten letter stating that Al-Shabaab had been looking for
him and when they could not find him had killed his mother and taken his sister. He claimed it was too
dangerous for him to return to Somalia given the threat from Al-Shabaab.

12. On 18 September 2017 the Secretary of State decided that the further submissions did not constitute a
fresh claim within the meaning of paragraph 353 of the Immigration Rules. The Secretary of State noted
the claim regarding the Claimant's mother's death but stated that he had provided no indication of how that
made him more likely to face persecution or other threats if he returned to Somalia. In the Secretary of
State's view it therefore did not constitute a new ground which might cause an immigration judge to arrive
at a different conclusion to that already reached.

13. On 4 February 2018, at the end of his sentence, the Claimant was not released but detained under
Immigration Act powers as a person against whom a deportation order had been made. It was stated in the
minute of the decision to detain that the Claimant's risk of absconding was “low” but that his risk of
reoffending was “high”. It was said that if he was not in detention he would pose a high risk of re-offending
and a high risk of harm to the public, and that this risk outweighed any presumption in favour of release.


-----

14. On 31 July 2018 the Secretary of State made a further decision refusing to accept the Claimant had
made a fresh asylum claim within the meaning of paragraph 353 of the Immigration Rules and on 21
August 2018 issued a “notice of removal window” indicating that the Claimant would not be removed for
five days, but thereafter could be removed without further notice within three months of the notice.

**The Claimant's further submissions and October 2018 judicial review**

15. On 6 September 2018 the Claimant's solicitors sent further submissions in support of the Claimant's
asylum claim. They enclosed a photocopy of a document purporting to be a “death certificate” signed by
Colonel Omar Abdi Ilmi of the Somalia Police Force. The certificate stated that the Claimant's mother
(“FA”) had been shot in October 2015. It continued:

“As a result, the son of [FA], [the Claimant] received death threats from individuals claiming to be AlShabaab. Stating the death of his mother was direct result of him leaving the country and evading AlShabaab recruitment. These suspected Al-Shabaab members claimed that they were also on the hunt for

[the Claimant] as they cannot afford to be seen lenient towards him.”

16. On 15 October 2018, the Claimant's solicitors sent a pre-action protocol letter. They enclosed a
statement from the Claimant on how he had found out about his mother's death. The letter also submitted
that the further evidence, taken together with that of 6 September 2018, constituted a fresh human rights
and protection claim. Also on 15 October 2018 the Claimant issued judicial review proceedings challenging
the decision to maintain the “notice of removal window”. On the same day Upper Tribunal Judge Kopieczek
ordered a stay on the Claimant's removal in the light of “what appear to be further submissions made to the
respondent which have not, apparently, been dealt with”.

17. On 5 November 2018, the Secretary of State filed an Acknowledgment of Service. He agreed to
withdraw the decision to remove the Claimant and to consider his further submissions. A consent order
was sealed to that effect on 4 December 2018. The recital stated that the claim was being withdrawn upon
the Secretary of State “agreeing to reconsider the [Claimant's] further submissions dated 6 September
2018.” The Secretary of State also agreed to allow the Claimant 28 days to provide further evidence and to
issue a decision on the fresh claim within three months of any further evidence.

**Assessment of Claimant as victims of trafficking**

18. On 6 November 2018 the detention centre medical practitioner issued a report in accordance with Rule
35 of the Detention Centre Rules 2001 indicating that the Claimant “may be a victim of torture”. On 19
November 2018 the Secretary of State decided that, although the Claimant was an “adult at risk level 2 on
the basis of Torture Claim” and notwithstanding the Rule 35 report, his detention was to be maintained.

19. On 19 December 2018 the Claimant's solicitors wrote to the Secretary of State stating that the
Claimant was a potential victim of human trafficking (“PVOT”) and should be referred to the National
Referral Mechanism (“NRM”). On 16 January 2019 Gemma Kingett, the assigned caseworker for the
Claimant at the Home Office Criminal Casework team, completed a NRM referral and sent it to the
Claimant to sign. He did so the next day.

20. On 29 January 2019 the Secretary of State concluded that there were reasonable grounds to suspect
that the Claimant was the victim of trafficking. That meant he would not be removed for 45 days.

21. On 14 March 2019 the Secretary of State decided that there were conclusive grounds that the
Claimant was the victim of trafficking. That did not, however, result in a grant of discretionary leave to
remain. The letter concluded that there was no realistic risk of the Claimant being re-trafficked or becoming
a victim of modern slavery again if he were returned to Somalia and that his Article 3 and Article 8 rights
would not be breached by deportation.

**Claimant's detention from 15 January to 29 April 2019**

22. On 15 January 2019 the Secretary of State's Case Progression Panel (“CPP”) met. It may be helpful at
this stage to set out the role played by the CPP. I have been provided with a copy of the Home Office


-----

guidance on “Detention Case Progression Panels”. It was published on 18 April 2019 but I am told that, for
present purposes, it is not materially different to that in place in January 2019. The guidance explains at
page 5 that CPPs provide “internal independent assurance” in immigration cases where detention has
reached three months and are intended to be a “safeguard” providing “additional scrutiny to further
minimize the likelihood of inappropriate or unduly prolonged detention”. The panel consists of a “chair, CPP
members and CPP experts” who review the appropriateness of continued detention on a minimum threemonthly basis (ibid). The guidance states that CPPs review each case and may recommend the granting of
bail or maintenance of detention (p 17-18). The CPP's recommendations are not binding on the Secretary
of State. Decisions on release are made on the Secretary of State's behalf following a Detention and Case
Progression Review (“DCPR”).

23. It appears from the notes of the CPP's meeting of 15 January 2019 that the CPP believed that there
was, at the time, a “JR outstanding” and “Court injunction outstanding”. It considered those were “factors in
favour of release”. In fact, by 15 January 2019 neither the Claimant's judicial review nor the injunction of 15
October 2018 were “outstanding”. On 4 December 2018 the judicial review had ended on the Secretary of
State agreeing to withdraw the decision to remove the Claimant and consider his further submissions. The
CPP listed factors in favour of maintaining detention which included that the Claimant had been
“continuously disruptive while in detention” and noted that his “violence has not decreased in detention”.
This was referring to a number of incidents in detention in which the Claimant had, among other things,
assaulted detainees and staff. The CPP nevertheless recommended the Claimant's release as there was
“no prospect of imminent removal”, in particular noting that the “outstanding” judicial review claim needed
to be determined. The CPP also noted that the Claimant's risk was “high” and recommended that
“appropriate measures be in place to restrict the risk factors such as reporting, curfews, approved
accommodation or tagging.”

24. A DCPR was held on 16 January 2019. The CPP decision of 15 January 2019 was only recorded in
the Secretary of State's General Case Information Database “GCID” in relation to the Claimant on 17
January 2019. It thus appears that those who conducted the DCPR on 16 January were not aware of the
CPP release recommendation and it was not referred to in the DCPR decision. Following the DCPR the
authorising officer, Jane Sutton, authorised the Claimant's continued detention on behalf of the Secretary
of State on the following basis:

“[The Claimant] has been convicted of a serious offence and the risk posed to the public of absconding and
of re-offending have all been considered when reviewing his on-going detention. His disruptive and violent
behaviour whilst in detention all give grounds to suggest the risk of re-offending remains high.

A last minute JR was submitted to halt the deportation planned for 21st October. This is currently in the
process of being resolved and a PVOT [Potential Victim of Trafficking] claim has also now been submitted.
I note this is also under consideration. Once these barriers have been resolved removal will be imminent.

On this basis, having considered the risks, I am satisfied that detention remains proportionate and I
authorise detention for 28 days.”

25. As set out above, on 16 January 2019 Gemma Kingett, the Claimant's Home Office caseworker,
completed a NRM referral for the Claimant. As part of that she asked the Claimant for his preferred release
address in the UK. He gave his grandparents' home. Between 17 January and 24 January 2019 there was
correspondence between Ms Kingett and the Offender Manager assigned to the Claimant by Her Majesty's
Prison and Probation Service (“HMPPS”) concerning possible release addresses. In the course of that
correspondence the Offender Manager stated he would look into the UK address proposed by the Claimant
on 16 January 2019, but that it was unlikely to be suitable.

26. On 28 January 2019 there is recorded in the Claimant's GCID case record the outcome of a further
“panel discussion”. It is stated that the “panel” were told that “as a result of the JR the [Claimant's] case
was to be reconsidered”. It appears that this was a reference to the compromise reached on 4 December
2018 in the judicial review requiring consideration of the Claimant's further submissions. It was stated
“action required: expedite decision.” It was decided to “maintain detention pending service of decision:
review if appeal lodged”


-----

27. Ms Gray for the Secretary of State invites me to find that the “panel” referred to in the GCID case
record of 28 January 2019 was the CPP, and that this was an ad hoc meeting of the CPP. She submitted
that it can be inferred that at some point between its meeting on 15 January and the 28 January 2019, the
CPP was told that the judicial review was not, in fact, ongoing, as had been believed on 15 January, and
that the Secretary of State had agreed to consider the Claimant's further submissions. Ms Gray submits
that this led to the CPP reconvening. She submits that in the light of the new information about the judicial
review having ended, the CPP considered that the Claimant's removal could, in fact, be more imminent
than had been thought on 15 January. That led to the CPP changing its mind on the appropriateness of
release. While the documents are not entirely clear, I consider, on balance, that Ms Gray's interpretation is
probably correct. As set out further below, that is relevant to Ground 1 of the Claimant's challenge.

28. Despite the CPP having changed its release recommendation, Ms Kingett continued to seek potential
accommodation for the Claimant. On 30 January 2019 she inquired of the Salvation Army if they could
provide accommodation. The Salvation Army refused on 31 January 2019 as they considered
accommodating the Claimant would place their staff and other residents at too high a risk. On the same
day Ms Kingett asked if the National Probation Service (“NPS”) could provide approved accommodation for
the Claimant and how long that might take to obtain.

29. On 31 January 2019 the Head of NPS, Northamptonshire wrote to Ms Kingett stating that in her “firm
professional view” the risks presented by the Claimant were “extensive and imminent and that a release
into the community placed the public at risk”. She stated that there were currently no beds in an AP in any
event, and that the Claimant would be unlikely to be offered one given the risk he posed.

30. On 13 February 2019 the Claimant's detention was considered at a DCPR. It concluded that the
Claimant should remain in detention on public protection grounds while options for potential release were
considered.

31. On 27 February 2019 the Claimant's Offender Manager emailed Ms Kingett indicating that “based on
the current information we do not feel that the risk [the Claimant poses] can be managed within the
community however if his release is directed he will have to reside in Approved Premises with a robust risk
management plan tailored to meet his risks and needs”. It was stated that Northampton AP “will have a bed
available from 27 March [2019]” for the Claimant.

32. Having sent pre-action protocol letters challenging the Claimant's continued detention and failure to
release him to suitable accommodation on 13 February 2019 and 25 February 2019, the Claimant issued
the current judicial review proceedings on 1 March 2019.

33. On 18 March 2019 Murray J refused the Claimant permission to apply for judicial review on the
papers. The Claimant renewed the application and sought an oral hearing.

34. On 22 March 2019 the Claimant's solicitors made further submissions in support of his challenge to his
deportation. They also stated that, in addition to the Claimant being targeted by Al-Shabaab if he returned
to Somalia, there was a real risk that the conditions to which he would return would breach Article 3 of the
ECHR. In particular they relied on the poor conditions in which the Claimant and his family were living in a
camp for internally displaced persons (“IDP”) in Elasha Biyaha prior to his capture by Al-Shabaab in 2013.
It was said there was a real risk that he would again find himself forced to live in such conditions if he was
returned to Somalia.

35. On 27 March 2019 a call was received from NPS by a member of the Home Office staff, J Salisbury. It
is not stated in the Claimant's GCID case notes why the call was made but it can be inferred that it was to
discuss the place at the AP which, as had been indicated, was to become available for the Claimant on 27
March. The GCID notes record that J Salisbury “provided [the NPS officer] with an update and advised her
to call back in 2 weeks as at present the [further representations] still needs to be dealt with which appears
to be the only barrier to removal”. It appears, therefore, that, as it was not planned to release the Claimant
at that stage, NPS was not asked to keep the place at the AP for him and it appears the place was
allocated to someone else.


-----

36. Also on 27 March 2019 there was a further CPP meeting (though the notes of the meeting were not
recorded in the GCID until 28 March). The CPP again recommended the Claimant's release. It stated:

“After considering the evidence from all the information presented … the panel consider there are factors
which suggest that removal within a reasonable timeframe … may not be possible.

Factors in favour of maintain detention : removal can take place on an EUL [EU letter].

Factors in favour of release : [the Claimant] … has further representations outstanding since September
2018. [He] is an “adult at risk” due to a Rule 35 torture allegations Positive reasonable ground decision has
been made on his PVOT claim.

Reason for balance : the Panel has recommended release in this case as there is no prospect of imminent
removal…. The Panel has noted the ... risk [posed by the Claimant] being high and to mitigate any risk
upon release the panel have recommended appropriate measures be in place to restrict the risk factors,
such as reporting, curfews, approved accommodation or tagging….

The case should be re-referred … if additional case progression is to be undertaken which will minimise
the barriers to allow a realistic prospect of removal within a reasonable timeframe.”

37. On 28 March 2019 the Claimant submitted a bail application to the FTT. It was opposed by the
Secretary of State.

38. The next DCPR was on 1 April 2019. The Authorising Officer, Helen Scott, authorised the Claimant's
continued detention notwithstanding the CPP recommendation of 27 March 2019. She stated:

“[The Claimant] has continued to demonstrate violence during detention and has little incentive to comply
with any restrictions given the knowledge that HO is pursuing deportation. In progressing release
contingency, the proposed address has not been accepted by the probation officer and the Salvation Army
have declined to provide accommodation given the risks associated with [the Claimant]. It is noted that this
review is sixteen days late however this has not materially affected the decision. The CPP on the 27
March 2019 has recommended release. This is the 14th [Detention Review] and without significant
progress to removal in this next period arrangements for release are to be confirmed in the next two-week
period, including victim liaison/mitigation as required.”

39. On 2 April 2019, and despite the Secretary of State's opposition, the Claimant was granted conditional
bail by the FTT. The condition was that the Secretary of State “identify a suitable bed for the [Claimant] in
Approved Premises.”

40. Following the FTT's grant of bail, Ms Kingett sought to obtain a place at AP for the Claimant. She was
told that was a matter for the “HMPPS to sort out.” Accordingly Ms Kingett emailed the Claimant's Offender
Manager on 3 and 11 April 2019. Ms Kingett sent a further email on 23 April 2019 asking for an update.
There was however, no suitable place at AP available and the Claimant's Offender Manager was unable to
provide a timetable for when they would become available. As set out below, a place at AP did not become
available until 30 April.

**Claimant's detention from 29 April 2019**

41. As set out above, following the compromise of the Claimant's judicial review on 4 December 2018, the
Secretary of State had undertaken to consider the Claimant's further submissions of 6 September 2018
challenging his deportation. Additional submissions had also been made on 22 March 2019. On 29 April
2019 a decision was taken by the Secretary of State to reject the further submissions. The Secretary of
State refused to accept the Claimant's further claim that his deportation would breach the Refugee
Convention or the ECHR. He also declined to treat the Claimant's further submissions as a fresh claim
pursuant to paragraph 353 of the Immigration Rules. The Secretary of State concluded that the Claimant
had not raised any “new material”, and that any claim he had did not have a reasonable prospect of
success. The details of the decision, and its legality, is considered further below at [116]-[120].

42. On 30 April 2019 the further submissions refusal was served on the Claimant. On the same day,
though it is unclear whether it was before or after the service of the further submission refusal on the


-----

Claimant, a place at AP became available for the Claimant. Consequently the conditions for bail set by the
FTT were met. The Claimant's detention was, however, maintained by the Secretary of State. The reason
was that the Secretary of State considered that his decision of 29 April 2019 rejecting the further
submissions was a material change of circumstances since the FTT bail decision. He considered that
entitled him to continue to detain the Claimant.

43. The reasons for maintaining the Claimant's detention on 30 April 2019 were recorded in the entry for
the Claimant on the GCID as follows:

“Having reviewed this case following AP being sourced, I have confirmed that detention would be
maintained on the basis that the asylum representations have been considered and refused with no right of
appeal. We are now referring the case for inclusion on the Somalian Priority list. Two prior attempts to
remove were made and deferred due to representation, as such this should be escalated for urgent
removal directions given the time that [the Claimant] has spent within immigration detention.

I note that previous consideration of release following the reasonable grounds decision was made.
Ordinarily release would be expected during the recovery and reflection period, however HMPPS noted
that there were grounds of Public Order which would justify ongoing detention in-line with the policy and
the AAR [Adults at Risk] policy was compliant given he was assessed at level 2 and following the
conclusive grounds decision the asylum claim could be expedited with referral for removal if certified.
Progression to conclude the barriers was indeed expedited resulting in him being barrier free at this time.

We will be liaising very closely with our Country Specialist Team to prioritise the removal on an EU letter.”

44. On 14 May 2019 there was a further DCPR. The Claimant's detention was authorised for another 28
days. The authorising officer, Jane Sutton, gave the following reasons:

“[The Claimant] has been convicted of a number of serious and violent offences resulting in him being
assessed as posing a high risk of harm to the public and a high risk of re-offending. I note the
recommendation from the CPP on 27th March to consider release but note that there has been significant
progress with the case since that date.

Further reps have been cleared and the decision served, a date of 18th June has been set to hear the JR
and [the Claimant] has been placed on the priority returns list and a date for removal post 18th June is in
the process of being obtained.

In light of this I consider removal can be achieved within a reasonable timescale and having balanced this
against the risk to the public upon release I authorise detention for a further 28 days.”

**Material provided at hearing of 18 June 2019**

45. At the judicial review hearing on 18 June 2019 a number of further documents were handed up. These
included a report of a further DCPR on 24 May 2019. This time the authorising officer, Richard Faulkner,
determined that the Claimant should be released once appropriate accommodation could be found. He
stated:

“I note that there is ongoing litigation in this case against detention and in light of the Bail grant, which was
open ended we should proceed to release upon securing appropriate accommodation. It is confirmed that
such accommodation will be in place from 4 June 2019 and as such we would proceed to release at that
time in-line with the bail grant.

Pending the accommodation there are risks [that] would not make release to no fixed abode appropriate
and we will continue to expedite the remaining barriers to removal via service of the supplementary letter, if
this does not attract a right of appeal then we can refer for removal on the Somalia priority list and retain
with removal directions in place. [The Claimant] has continued to demonstrate aggressive behaviours
within detention and must be managed with robust contact management in place.”

46. In the event the Claimant was not released on 4 June 2019. Instead his case was considered again at
a DCPR on 6 June 2019. This time the authorising officer, Jackie Salisbury, declined to authorise the
Claimant's release She stated:


-----

“On 30 April 2019 having reviewed the case following AP being sourced, the Claimant's detention was
maintained, his further asylum representations having been considered and refused on 29 April 2019.
Following the renewed hearing on 1 May 2019, for the avoidance of doubt [the Claimant] will now be
served with further detention forms (not strictly necessary given the change of circumstances but done for
the avoidance of doubt) relating to his continued detention following the grant of bail in principle being
satisfied.

The JR hearing is due to take place on 18 June 2019 and if the case is dismissed we will set [Removal
Directions] immediately.

However, in the event that the JR is allowed counsel have requested an AP address is in place so that
release can be facilitated without delay.

Further detention is therefore warranted given the assessment of high harm to the public given the violent
nature of [the Claimant's] offences and his ongoing disruption and violent tendencies whilst detained and
also the high probability of re-offending.”

47. Further detention forms were served on the Claimant on 6 June 2019. The reason the forms were
served, as set out further below, appears to be a concern arising from the present proceedings that, given
the Claimant had satisfied the conditions for bail on 30 April 2019 when the AP became available, it might
have been necessary formally to re-detain him and therefore serve fresh detention forms upon him.

48. On 10 June 2019 the Secretary of State produced a “supplementary letter to refuse a protection
claim”. The 10 June letter sought to supplement the letter dated 29 April 2019. It sought to deal with a
number of matters that had not been dealt with, or were not dealt with in detail, by the 29 April letter and
which the Claimant had criticised in the present judicial review proceedings. The Secretary of State again
concluded that the further submissions that had been made by the Claimant did not indicate that his
deportation would breach the Refugee Convention or the ECHR. It also concluded that the Claimant had
not made a fresh claim within the meaning of paragraph 353 of the Immigration Rules. Details of the
decision are set out further below at [134]-[135] and [145]-[146].

49. On 17 June 2019 the Claimant issued judicial review proceedings in the Upper Tribunal. He sought to
challenge the decision of 29 April 2019 that he had not made a fresh protection and human rights claim. He
contended that on 29 April (i) the Secretary of State had failed properly to consider his representations of 6
September 2018 relating to the death of his mother and (ii) the Secretary of State failed properly to
consider the representations of 22 March 2019 that there was a real risk that, if returned to Somalia, he
would find himself in\an IDP camp in conditions which breached ECHR Art 3. He also contended that those
matters had not been properly considered in the supplementary letter of 10 June 2019. I consider further
below the relationship between the present proceedings and the proceedings in the Upper Tribunal.

**Material legislation and policy**

**Primary Legislation**

50. The Claimant is a “foreign criminal” as defined by section 32(1) of the United Kingdom Borders Act
2007. By reason of s 32(4), his removal is deemed “conducive to the public good” for the purposes of
section 3(5)(a) of the Immigration Act 1971. Pursuant to s 32(5) of the 2007 Act the Secretary of State
must make a deportation order in respect of a “foreign criminal” unless one of the exceptions in s 33
applies. The exceptions include that removal would breach ECHR rights or the UK's obligations under the
Refugee Convention.

51. Authority to detain an individual subject to a deportation order is contained in paragraph 2(3) of
Schedule 3 of the Immigration Act 1971 which provides:

“Where a deportation order is in force against any person, he may be detained under the authority of the
Secretary of State pending his removal or departure from the United Kingdom (and if already detained by
virtue of sub-paragraph (1) or (2) above when the order is made, shall continue to be detained unless he is
released on immigration bail under Schedule 10 to the Immigration Act 2016.”


-----

52. Those detained under _[Immigration Act 1971 powers can be granted bail. The provisions on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
immigration bail are contained in Schedule 10 of the Immigration Act 2016. It provides where material in
paragraph 1:

“(1) The Secretary of State may grant a person bail if—

…

(b) the person is being detained under paragraph 2(1), (2) or (3) of Schedule 3 to [the _[Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
_[1971] (detention pending deportation),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_

…

(3) The First-tier Tribunal may, on an application made to the Tribunal for the grant of bail to a person,
grant that person bail if—

…

(b) the person is being detained under paragraph 2(1), (2) or (3) of Schedule 3 to [the _[Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
_[1971],](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_

…

(4) In this Schedule references to the grant of immigration bail, in relation to a person, are to the grant of
bail to that person under any of sub-paragraphs (1) to (3) …

(5) A person may be granted and remain on immigration bail even if the person can no longer be detained,
if—

(a) the person is liable to detention under a provision mentioned in sub-paragraph (1), or

(b) the Secretary of State is considering whether to make a deportation order against the person under
[section 5(1) of the Immigration Act 1971.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

(6) A grant of immigration bail to a person does not prevent the person's subsequent detention under a
provision mentioned in sub-paragraph (1).

(7) For the purposes of this Schedule a person is on immigration bail from when a grant of immigration bail
to the person commences to when it ends.

(8) A grant of immigration bail to a person ends when—

(a) in a case where sub-paragraph (5) applied to the person, that sub-paragraph no longer applies to the
person,

(b) the person is granted leave to enter or remain in the United Kingdom,

(c) the person is detained under a provision mentioned in sub-paragraph (1), or

(d) the person is removed from or otherwise leaves the United Kingdom.

(9) This paragraph is subject to paragraph 3 (exercise of power to grant immigration bail).”

53. By paragraph 2(1) of Schedule 10, a grant of immigration bail must be subject to at least one of a
number of listed conditions. One of the potential conditions is a condition about the person's residence:
para 2(1)(c).

54. Paragraph 3 of Schedule 10 provides:

“(1) The Secretary of State or the First-tier Tribunal must have regard to the matters listed in subparagraph (2) in determining—

(a) whether to grant immigration bail to a person, and

(b) the conditions to which a person's immigration bail is to be subject.

(2) Those matters are—


-----

(a) the likelihood of the person failing to comply with a bail condition,

(b) whether the person has been convicted of an offence (whether in or outside the United Kingdom or
before or after the coming into force of this paragraph),

(c) the likelihood of a person committing an offence while on immigration bail,

(d) the likelihood of the person's presence in the United Kingdom, while on immigration bail, causing a
danger to public health or being a threat to the maintenance of public order,

(e) whether the person's detention is necessary in that person's interests or for the protection of any other
person, and

(f) such other matters as the Secretary of State or the First-tier Tribunal thinks relevant.

…

(5) If the Secretary of State or the First-tier Tribunal decides to grant, or to refuse to grant, immigration bail
to a person, the Secretary of State or the Tribunal must give the person notice of the decision.

(6) Where the First-tier Tribunal is required under sub-paragraph (5) to a give a person notice of a decision,
it must also give the Secretary of State notice of the decision.

(7) Where the decision is to grant immigration bail, a notice under sub-paragraph (5) or (6) must state—

(a) when the grant of immigration bail commences, and

(b) the bail conditions.

(8) The commencement of a grant of immigration bail may be specified to be conditional on arrangements
specified in the notice being in place to ensure that the person is able to comply with the bail conditions.”

**Material Immigration Rules and policies**

**Immigration Rules**

55. Pursuant to section 3(2) of the Immigration Act 1971, the Secretary of State is empowered to make
Immigration Rules. Paragraph 353 and 353A of the Rules deal with fresh claims. They provide:

“353. When a human rights or protection claim has been refused or withdrawn or treated as withdrawn
under paragraph 333C of these Rules and any appeal relating to that claim is no longer pending, the
decision maker will consider any further submissions and, if rejected, will then determine whether they
amount to a fresh claim. The submissions will amount to a fresh claim if they are significantly different from
the material that has previously been considered. The submissions will only be significantly different if the
content: (i) had not already been considered; and (ii) taken together with the previously considered
material, created a realistic prospect of success, notwithstanding its rejection. This paragraph does not
apply to claims made overseas.

353A. Consideration of further submissions shall be subject to the procedures set out in these Rules. An
applicant who has made further submissions shall not be removed before the Secretary of State has
considered the submissions under paragraph 353 or otherwise.”

**Chapter 55 : immigration detention policy**

56. The Secretary of State's policy on immigration detention is set out in Chapter 55 of the “Enforcement
Instructions and Guidance” (EIG). Paragraph 55.1.2 provides in relation to “Criminal Casework cases”:

“Due to the clear imperative to protect the public from harm from a person whose criminal record is
sufficiently serious as to satisfy the deportation criteria, and/or because of the likely consequence of such a
criminal record for the assessment of the risk that such a person will abscond, in many cases this is likely
to result in the conclusion that the person should be detained, provided detention is, and continues to be,
lawful. However, any such conclusion can be reached only if the presumption of immigration bail is


-----

displaced after an assessment of the need to detain in the light of the risk of re-offending and/or the risk of
absconding.”

57. Paragraph 55.1.3 provides:

“… due to the clear imperative to protect the public from harm, the risk of re-offending or absconding
should be weighed against the presumption in favour of immigration bail in cases where the deportation
criteria are met. In criminal casework cases concerning foreign national offenders (FNOs), if detention is
indicated, because of the higher likelihood of risk of absconding and harm to the public on release, it will
normally be appropriate to detain as long as there is still a realistic prospect of removal within a reasonable
timescale.

If detention is appropriate, an FNO will be detained until either deportation occurs, the FNO wins their
appeal against deportation …, bail is granted by the Immigration and Asylum Chamber, or it is considered
that Secretary of State immigration bail is appropriate because there are relevant factors which mean
further detention would be unlawful…

Substantial weight should be given to the risk of further offending or harm to the public indicated by the
subject's  criminality. Both the likelihood of the person re-offending, and the seriousness of the harm if the
person does re- offend, must be considered. Where the offence which has triggered deportation is more
serious, the weight which should be given to the risk of further offending or harm to the public is particularly
substantial when balanced against other factors in favour of granting immigration bail.”

58. Paragraph 55.6 of Chapter 55 sets out the forms that must be completed and served when individuals
are subject to immigration detention. It provides: “written reasons for detention should be given in all cases
at the time of detention and thereafter at monthly intervals (in this context, every 28 days)”. Paragraph
55.6.2 makes provision for service of a “Form IS91” which gives “authority to detain”. It is served by an
Immigration Officer or person acting on behalf of the Secretary of State “on the detaining agent.” It
continues “This allows for the subject to be detained in the detaining agent's custody under Immigration Act
powers”. Paragraph 55.6.2 continues: “Form IS91 is issued once and only once for any continuous period
of detention, irrespective of how many detaining agents there are during the course of a person's
detention.” Paragraph 55.6.3 makes provision for service of “Form IS91R” which provides “reasons for
detention” and “must be served on every detained person … at the time of their initial detention.” The form
“must specify the power under which a person has been detained, the reasons for detention and the basis
on which the decision to detain was made.” Paragraph 55.6.3 continues: “In addition there must be a
properly evidenced and fully justified explanation of the reasoning behind the decision to detain placed on
file in all detention cases.”

**Adults at risk and victims of modern slavery**

[59. Immigration Act 2016 section 59 requires the Secretary of State to give guidance specifying matters to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C41M-00000-00&context=1519360)
be taken into account in determining whether a person who is particularly vulnerable to harm should be
released or remain in detention. The Secretary of State's policy “Adults at risk in detention” provides:

“Who is an adult at risk?

7.  For the purposes of this guidance, an individual will be regarded as being an adult at risk if:

    - they declare that they are suffering from a condition, or have experienced a traumatic event (such as
trafficking, torture or sexual violence), that would be likely to render them particularly vulnerable to harm if
they are placed in detention or remain in detention

    - those considering or reviewing detention are aware of medical or other professional evidence, or
observational evidence, which indicates that an individual is suffering from a condition, or has experienced
a traumatic event (such as trafficking, torture or sexual violence), that would be likely to render them
particularly vulnerable to harm if they are placed in detention or remain in detention – whether or not the
individual has highlighted this themselves.


-----

8. On the basis of the available evidence, the Home Office will reach a view on whether a particular
individual should be regarded as being “at risk” in the terms of this guidance. If, on this basis, the individual
is considered to be an adult at risk, the presumption will be that the individual will not be detained.”

60. In respect of the detention of individuals identified as being “at risk” the Guidance says:

“13. The presumption will be that, once an individual is regarded as being at risk in the terms of this
guidance, they should not be detained. However, any risk factors identified and evidence in support will
then need to be balanced against any immigration control factors in deciding whether they should be
detained.

14. The immigration factors that will be taken into account are:

     - Length of time in detention – there must be a realistic prospect of removal within a reasonable period.
What is a 'reasonable period' will vary according to the type of case but in all cases, every effort should be
made to ensure that the length of time for which an individual is detained is as short as possible. In any
given case it should be possible to estimate the likely duration of detention required to effect removal. This
will assist in determining the risk of harm to the individual. Because of their normally inherently short
turnaround time, individuals who arrive at the border with no right to enter the UK are likely to be detainable
notwithstanding the other elements of this guidance;

     - Public protection issues – consideration will be given to whether the individual raises public protection
concerns by virtue of, for example, criminal history, security risk, decision to deport for the public good;

    - Compliance issues – an assessment will be made of the individual's risk of abscond, based on the
previous compliance record

15. An individual should be detained only if the immigration factors outweigh the risk factors such as to
displace the presumption that individuals at risk should not be detained. This will be a highly case specific
consideration.”

61. In respect of victims of trafficking the guidance says:

“18. Any decision made on the immigration detention of an individual who has received a positive
reasonable grounds decision under the National Referral Mechanism (NRM), and who has not yet received
their conclusive grounds decision or otherwise left the NRM, will be made on the basis of the **_modern_**
**_slavery policy set out in separate guidance.”_**

62. Further policy concerning the detention of victims of modern slavery is set out in “Victims of modern
**_slavery - Competent Authority Guidance”_** (version 5.0, 21.1.2019). It states at p. 56 in relation to
“immigration detention” that “If the potential victim of modern slavery is in immigration detention they will
normally need to be granted immigration bail by the Home Office unless in the particular circumstances
their detention can be justified on grounds of public order.”

**Detention Case Progression Panels**

63. The Home Office Guidance on Detention Case Progression Panels for immigration detention states at
p 5:

“Case Progression Panels (CPP) have been in operation since February 2017 providing internal
independent assurance of all cases where detention has reached three months (and every three months
thereafter). Each CPP consists of a chair, CPP members and CPP experts, who review the
appropriateness of continued detention, adherence to the Adults at Risk in Immigration Detention policy,
case progression actions and provide recommendations to the team responsible for the ownership of the
cases concerned.

The CPP review detention on a minimum of a three-monthly basis. However, cases can also be referred by
units such as Detention Gatekeeper, Detention Operations, Detention Engagement Teams and the Adults
at Risk Returns Assurance Team when it is felt that additional scrutiny might be useful outside of the threemonthly cycle. Cases from all detained commands are reviewed together with the aim of ensuring


-----

consistency of use of detention powers across different case types, increasing the speed of case
progression and reducing the length of time any individual spends in detention.”

64. The functions and purpose of CPPs is described as follows at p 6 of the guidance:

“The functions of the CPP are to:

- ensure a consistency of process and approach to reviewing detention and case progression across the
immigration system

- drive case progression and casework diligence to effect departure from the UK, whether by
administrative removal or deportation

- provide additional oversight for the identification and management of potentially vulnerable people in
detention.

In ensuring consistency of process and approach across the immigration system the CPP will:

- provide a forum to review all cases where individuals have been detained for more than a prescribed
period

- standardise the review methodology: balancing application of Hardial Singh principles and where
applicable, any associated risks attached to release

- provide clearly evidenced and fully justified reasoning behind recommendations for continued detention
or consideration of release

In placing considerations about an individual detainee's vulnerability at the heart of detention management
the CPP will:

- provide established, robust safeguards to prevent detention continuing for longer than is absolutely
necessary

- afford an additional opportunity to identify and highlight potential vulnerability in line with the Adults at
Risk in Immigration Detention Policy..”

65. Page 17-18 of the guidance states that the CPP will review each case and will “recommend a grant of
Secretary of State bail”, “recommend maintain detention but with case progression actions”, or
“recommend to maintain detention.”

66. Page 19 of the guidance sets out the following in relation to “post-panel case work actions”:

“Following a recommendation from the Case Progression Panel (CPP), casework teams will be informed of
the recommendation by the CPP Team; a note will be placed on the Central Information Database (CID) by
the CPP Team. This note will include details of the CPP the case was presented to, casework information
such as the Adults at Risk level, any deportation and removal information, factors in favour of maintaining
detention or of granting immigration bail, the CPP recommendation and the reasoning behind the
recommendation (which is based on the information presented to the CPP on that day) and any casework
actions recommended by the CPP. This information will also be sent via email to the casework team that
are responsible for the case, including the case owner.

The casework team must give significant weight and consideration to any CPP recommendations, which
must not be rejected without careful consideration. If recommendations are rejected there must be clear
reasoning for this decision, which must be recorded on CID and in the next Detention and Case
Progression Review (DCPR) form.”

67. The guidance continues at p 19 under the heading “rejecting a recommendation”:

“When a CPP recommendation is disagreed with or rejected, this must be recorded clearly and fully
reasoned. All reasoning for the disagreement or rejection must be entered within a note on CID and within
the next DCPR. There needs to be a clear and auditable account on CID and within DCPRs setting out the
reasons why the recommendation or case progression actions have not been followed (for example, there
has been a change in circumstances/new information) This will not only help when the next DCPR is


-----

conducted, or when cases return to the CPP, but will also assist in the event that a claim for unlawful
detention is made.”

**Grounds of Challenge**

**Ground 1 : Failure to release the Claimant on or after 27 March 2019**

68. The Claimant claims that the failure to release him on or after 27 March 2019, the date upon which a
place at AP had become available, was unlawful.

69. It is no criticism of the way in which the Claimant puts his case, but it is important to note the
narrowness of Ground 1. His claim is that his detention breached the Secretary of State's policies in
relation to the treatment of CPP recommendations. He does not suggest pursuant to Ground 1 that his
detention from 27 March 2019 was unlawful on Hardial Singh principles (as set out by Dyson LJ in R(I) v
_SSHD [2003] INLR 196 at [46] and as approved by the Supreme Court in R(Lumba) v SSHD [2011] UKSC_
_12, [2012] 1 AC 245)._

70. It is also not said that, where decisions were taken that the Claimant posed too high a risk of harm to
the public to be safely released, those were irrational decisions. The Claimant has undoubtedly had a
difficult life, and was found to have been a victim of trafficking. That means that he was an “adult at risk” for
the purpose of the Secretary of State's “Adults at risk in detention” policy and subject to the presumption
that he should not be detained (paragraph 13 of the policy). As the policy states, however, the presumption
can be rebutted if there are “public protection issues” (and the Secretary of State's “Victims of **_Modern_**
**_Slavery” guidance is in similar terms: see page 56). It is not suggested that the concerns about the high_**
risk the Claimant would pose to the public if released were irrational. They were shared by the NPS, the
Salvation Army, as well as, at various times, officers of the Secretary of State.

71. Despite those concerns, given the length of time he had been in immigration detention (commencing
as it did on 4 February 2018), as well as his particular vulnerabilities as a victim of trafficking, on a number
of occasions recommendations were made by the CPP that the Claimant be released. The claim pursuant
to Ground 1 is that the Secretary of State breached his Guidance on Detention Case Progression Panels
(“the CPP Guidance”) in relation to those recommendations. The Guidance provides that where CPPs
recommend a detainee's release those recommendations should be given “significant weight and
consideration” by the Secretary of State, and where CPP recommendations are rejected “this must be
recorded and fully reasoned”. It is well-established that the Secretary of State, unless he has good reason
to depart from them, must exercise his powers of immigration detention in accordance with his policies
(see _R (Kambadzi) v Secretary of State for the Home Department [2011] 1 WLR 1299). The Claimant_
contends that the CPP Guidance was not followed in his case and that there were no good reasons for that
failure. The Claimant's argument is, further, that had CPP recommendations not been improperly rejected,
he would have been released on 27 March 2019 when a place at AP became available for him.

72. The relevant facts are these:

i) On 15 January 2019 the CPP recommended the Claimant's release with “appropriate measures … to
restrict the risk factors such as reporting, curfews, approved accommodation or tagging”. It appears,
however, that the recommendation was made in the mistaken belief that the Claimant's judicial review, and
a court injunction preventing his removal from the UK, were still outstanding. It was these factors that the
CPP specifically considered favoured release as they meant “there [was] no prospect of imminent
removal”.

ii) At some point between 15 January and 28 January 2019 it was brought to the CPP's attention that, in
fact, the judicial review was no longer outstanding and that the only bar on removal was the Secretary of
State consideration of the Claimant's further representations challenging his deportation. On 28 January
the CPP reconsidered its 15 January recommendation and decided to recommend the Claimant's
continued detention pending consideration of his further representations.

iii) Had it been requested by the Secretary of State, a bed in AP would have been available for the
Claimant on 27 March 2019 At that date however given the CPP's decision of 28 January there was no


-----

extant recommendation for the Claimant's release from the CPP. The 15 January 2019 recommendation to
release had been superseded by the 28 January decision. The failure to release the Claimant on 27 March,
therefore, was not taken in “disagreement” with a CPP decision.

iv) On 27 March 2019 there was a further CPP meeting which recommended the Claimant's release from
detention on the basis that his further representations from September 2018 had still not been considered
and it therefore seemed that removal within a reasonable timeframe would not occur. The recommendation
was considered at the DCPR on 1 April 2019 and a decision was taken not to follow the CPP's
recommendation. The disagreement with the CPP was recorded in the notes of the DCPR decision and it
was explained by the relevant officer, Ms Scott, why release was not being authorised.

v) Matters moved on after the DCPR of 1 April 2019. The FTT granted the Claimant conditional bail on 2
April, and thereafter the Secretary of State sought a place at AP to which the Claimant could be released.
No place was, however, found until 30 April. By that time the Secretary of State had concluded that there
had been a material change of circumstance, namely his decision of 29 April to reject the Claimant's further
submissions. He therefore did not release the Claimant.

73. There was thus only one occasion on which there was a recommendation from the CPP to release the
Claimant which was not followed. That was the CPP recommendation of 27 March which the DCPR
declined to follow on 1 April. I do not consider the failure to follow the recommendation constituted a
breach of the CPP Guidance.

74. On 27 March 2019 the CPP had recommended release, notwithstanding the “high” risk the Claimant
posed, because it considered that the removal of the Claimant within a reasonable timescale might not be
possible. In its decision of 1 April 2019, the DCPR noted the CPP had recommended release. The DCPR
explained why it nevertheless decided the Claimant should remain in detention. It stated that the Claimant
had “continued to demonstrate violence during detention and has little incentive to comply with any
restrictions given knowledge that [the Home Office] is pursuing deportation”. The DCPR decided it was
appropriate to wait a little longer to see whether removal became possible and stated if there was no
“significant progress to removal” by the next review, “arrangements for release are to be confirmed”.

75. The fact that the DCPR did not follow the CPP recommendations was not, in itself, unlawful. The
DCPR was required only to give the CPP recommendation “significant weight and consideration” and not
necessarily to agree with it. The CPP recommendation was specifically referred to in the DCPR decision
and I have no reason to believe it was not given sufficient weight. In addition, pursuant to the CPP
Guidance, if the DCPR disagrees with a CPP decision that must be “reasoned and fully recorded”. I
consider the DCPR complied with that requirement. While the DCPR reasons were brief and could perhaps
have said more about why it disagreed with the CPP, it is apparent why it took a different view from the
CPP. It reached a different conclusion on the balance between the risk the Claimant posed and the
likelihood of his being removed imminently, and considered the matter should be revisited at the next
DCPR rather than, as the CPP suggested, immediately seek to release the Claimant. That difference of
view was set out in the DCPR notes, and I consider that to be a sufficiently reasoned decision to satisfy the
CPP Guidance. Accordingly I reject Ground 1 of the Claimant's claim.

76. Furthermore, even if the decision of 1 April 2019 not to follow the CPP recommendation on release
was unlawful, it made no difference to the Claimant's detention. It is clear that, even if the CPP
recommendation was accepted on 1 April, the Claimant would have needed to be released to AP given the
risk he posed. There was, however, no place available at AP for the Claimant as of 1 April. Following the
bail decision of the FTT on 2 April 2019, the Secretary of State sought an AP placement for the Claimant
so that he could be released. A placement was not, however, found until 30 April. By that time the
Secretary of State had decided, following the rejection of the Claimant's further submissions on 29 April
2019, that there had been a material change of circumstances justifying not releasing the Claimant. The
Claimant would, therefore, have been in exactly the same position if the DCPR on 1 April had agreed with
the CPP recommendation. Even if the DCPR had agreed that because the Claimant's submissions of
September 2018 had still not been considered he should be released, it would not have altered the time he
spent in detention. A place at AP would still have needed to be found and the only difference would have


-----

been that the Secretary of State would have begun looking for the placement on 1 April rather than, as he
did, on 2 April. That would not have had any material impact on the Claimant.

**Grounds 2 & 3 : Failure to release the Claimant after he satisfied the grant of bail on 30 April 2019**

77. On 2 April 2019 the FTT granted the Claimant bail on the condition that a place at AP be found for him.
It is not suggested by the Claimant that there was a place available on 2 April or that in the following weeks
the Secretary of State failed conscientiously to seek an AP placement for him. It is also common ground
that on 30 April an AP place was found, and that the Claimant then satisfied the condition for bail set by the
FTT. The Claimant's claim pursuant to Grounds 2 and 3 is that he should have been released on that date.

78. The Secretary of State did not release the Claimant. The reason he did not do so was that on 29 April
2019 he rejected the Claimant's further submissions under paragraph 353 of the Immigration Rules. The
Secretary of State believed that he had thus removed the barrier to the Claimant's removal from the UK.
On that basis the Secretary of State concluded that there had been a material change of circumstances
since the FTT decision granting conditional bail which justified his not releasing the Claimant.

79. Ground 2 of the Claimant's challenge is that it was unlawful to detain him from 30 April. He contends
that on 30 April he satisfied the FTT bail conditions, that he should have been released and that the
Secretary of State was not entitled to treat the decision of 29 April 2019 as a material change of
circumstances. Ground 3 is that the Secretary of State “unreasonably” treated his decision of 29 April 2019
to reject the Claimant's further submissions as removing the barriers to his removal. Grounds 2 and 3 are
linked. Whether the decision not to release the Claimant on 30 April was lawful depends on whether the
Secretary of State was entitled to conclude that the decision of 29 April had, indeed, removed the barriers
to removal. I will therefore consider Grounds 2 and 3 of the claim together.

80. In order to determine the lawfulness of the Claimant's detention from 30 April 2019 I have divided the
analysis into three questions:

i) Is the Secretary of State entitled to detain a person notwithstanding that they have been granted bail by
the FTT on the basis of a material change of circumstance?

ii) Are there any procedural requirements, for the giving of notification and reasons which must be satisfied
for the Secretary of State to be able to continue to detain someone if they meet the conditions for bail
granted by the FTT?

iii) If the answers to (i) or (ii) is yes, did the Secretary of State act lawfully in declining to release the
Claimant in the present case on 30 April 2019?

**(i) Substantive requirements for detention following an FTT grant of bail**

81. The relevant provisions governing immigration bail are contained in Schedule 10 of the Immigration
Act 2016 (“Schedule 10”). Pursuant to paragraph 1(3)(b) of Schedule 10, the FTT may grant bail to a
person, such as the Claimant, detained under paragraph 2(3) of Schedule 3 of the Immigration Act 1971
[(“IA 1971”). Pursuant to paragraph 3(1) of Schedule 10, in determining whether to grant bail the FTT must](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
have regard to matters listed in paragraph 3(2). They include the likelihood of the person failing to comply
with bail conditions, the likelihood of the person committing an offence on bail, whether detention is
necessary to protect the person's interest or for the protection of any other person.

82. Paragraph 1(6) of Schedule 10 provides that “a grant of immigration bail to a person does not prevent
the person's subsequent detention under a provision mentioned in sub-paragraph 1.” Sub-paragraph 1
includes paragraph 2(3) of Schedule 3 of the IA 1971 (see paragraph 1(1)(b) of Schedule 10). The position,
therefore, is that pursuant to paragraph 1(6) of Schedule 10, where the FTT grants bail to someone subject
to a deportation order such as the Claimant, the Secretary of State can subsequently re-detain them.

83. Schedule 10 came into force on 15 January 2018. Whether the Secretary of State can detain a person,
notwithstanding that they have been granted bail by the FTT, was considered under the predecessor bail
regime in R (Mahmood) v Secretary of State for the Home Department [2006] EWHC 228 (Admin) and R
_(Shote) v Secretary of State for the Home Department [2018] EWHC 87 (Admin) In Mahmood and Shote_


-----

as was the procedure under the pre-Schedule 10 bail scheme, the FTT had granted bail and ordered the
claimants' subsequent appearance and surrender to an immigration officer. At a subsequent appearance
the claimants were re-detained. They sought to challenge their re-detention. Under the previous regime it
had been held that an FTT grant of bail comes to an end on surrender to an immigration officer (see R (AR
_(Pakistan) v Secretary of State for the Home Department [2016] EWCA Civ 807; [2017] 1 WLR 255 at [15]-_

[17] and [26]). If the immigration officer ordered bail to continue, even if he or she did so on the same terms
as the FTT's original grant of bail, the bail is that of the immigration officer not the FTT. Michael Fordham
QC, sitting as a Deputy Judge of the High Court, held in _Shote_ at [37], that there were, nevertheless,
“public law implications of an original grant of tribunal conditional bail [which] could in principle endure,
notwithstanding subsequent surrenders of bail to an immigration officer”. Those public law implications did
not prevent the Secretary of State re-detaining a person who had previously been granted bail by the FTT.
They meant, however, that it was necessary for the Secretary of State to establish a “material and genuine
change of circumstances [since the FTT bail decision] justifying the use of immigration detention powers”
(see Shote at [41] applying the principles set out by Underhill J in Mahmood at [12]-[14]).

84. The bail regime pursuant to Schedule 10 is different from its predecessor. Pursuant to Schedule 10
paragraph 1(6) an individual granted bail by the FTT can be re-detained by the Secretary of State at any
time and irrespective of whether that occurs at an appearance before an Immigration Officer. Indeed in
most cases under the new regime there will be no “appearance date” set by the FTT (see Guidance on
Immigration Bail for Judges and the FTT paragraph 54). Instead pursuant to paragraph 1(8)(c) of Schedule
10, immigration bail now ends automatically, not when a person surrenders to bail, but where the person is
re-detained by the Secretary of State pursuant to paragraph 1(6) of Schedule 10.

85. In my view, despite the differences in the bail regime, the key principles set out in Mahmood and Shote
apply to the Schedule 10 bail regime. Detention by the Secretary of State pursuant to paragraph 1(6) of
someone previously granted bail by the FTT can therefore, in principle, be lawful. It is, however, necessary
for there to be a “material and genuine change of circumstances” which provides a proper justification for
departing from the FTT decision. Without a change of circumstances the detention would simply reflect the
Secretary of State's disagreement with the conclusions of an independent judicial body specifically
accorded power to grant bail to those who the Secretary of State has chosen not to release. That would not
be a proper exercise of the power to re-detain.

86. In order to constitute a material change of circumstances, the change must significantly alter the
assessment of one or more of the considerations relevant to bail, such as the risk of absconding or
committing offences on bail. It is clear that a change in the imminence of an individual's removal can, in
principle, constitute such a material change. Indeed that was the change of circumstance accepted by the
Court to justify re-detention in both Mahmood (see para 9) and Shote (see para 39). The reason is obvious.
A person who is to be imminently removed may be significantly more likely to abscond, or indeed commit
offences, and significantly less likely to comply with bail conditions, than one whose removal is some way
in the future. In addition the concern about a person being “detained for a further undefined period”, which
may have justified the grant of bail (see Mahmood at [9]), diminishes where removal is imminent.

87. The present case is more factually complex than _Shote_ and _Mahmood._ _Shote_ and _Mahmood_
concerned individuals who had been released following the grant of bail by the FTT and then re-detained
some time later. In the present case the Claimant was never, in fact, released. Pursuant to paragraph 3(8)
of Schedule 10 “the commencement of a grant of immigration bail may be conditional on arrangements
specified in the notice being in place”. In the Claimant's case the “condition” was that the Secretary of State
“identify a suitable bed space” for him in AP. Pursuant to paragraph 1(7) of Schedule 10, “a person is on
immigration bail from when a grant of immigration bail to the person commences”. On the Secretary of
State's case the material change of circumstances occurred on 29 April 2019 when he rejected the
Claimant's further submissions. Subject to the arguments set out in Ground 3 of the Grounds of Claim, that
meant that when the further submissions decision was served on the Claimant on 30 April 2019, the barrier
to his removal had been lifted. This raises the question of whether the Claimant's bail commenced on 30
April, when the bed in AP was located and he was then immediately re-detained, or whether he never
commenced bail. The Secretary of State's position is that “the Claimant was on immigration bail from the


-----

date on which the residence condition was met until bail came to an end” (Detailed Grounds of Defence
paragraph 69: emphasis here and below added). The Secretary of State thus accepts on the facts that the
Claimant commenced immigration bail when the bed in AP was obtained on 30 April 2019, but his bail was
immediately brought to an end by his being re-detained, also on 30 April, pursuant to paragraph 1(6) of
Schedule 10.

88. The fact that the Claimant was not, in fact, released, may have procedural ramifications considered
below. However it does not alter the analysis set out above on the substantive question of when the
Secretary of State can decline to follow an FTT bail decision. It is open to the Secretary of State to redetain someone who has been released following the FTT's grant of bail if there is a genuine and material
change of circumstance after the FTT decision. It must be equally open the Secretary of State not to
release an individual if, before or immediately after the conditions for bail set by the FTT are met, there has
been a material change of circumstances.

**(ii) Procedural requirements for detention following an FTT grant of bail**

89. It was suggested by Ms Gray that where a person is granted bail and then re-detained pursuant to
paragraph 1(6) of Schedule 10, there is no obligation to give reasons as no such obligation appears in the
Schedule. Her position was that that was so even if an individual was, in fact, released and re-detained at
some later date. I do not consider that can be the correct position.

90. It is a long-established principle of the common law that “in this country a person is, prima facie,
entitled to his freedom and is only required to submit to restraints on his freedom if he knows in substance
the reason why it is claimed that this restraint should be imposed”: Christie v Leachinsky [1947] AC 573,
587 per Viscount Simon. Viscount Simon continued at p 588:

“No one, I think, would approve a situation in which when the person arrested asked for the reason, the
policeman replied "that has nothing to do with you: come along with me." Such a situation may be tolerated
under other systems of law, as for instance in the time of lettres de cachet in the eighteenth century in
France, or in more recent days when the Gestapo swept people off to confinement under an over-riding
authority which the executive in this country happily does not in ordinary times possess. This would be
quite contrary to our conceptions of individual liberty.”

91. It is true that those subject to immigration bail can be re-detained by the Secretary of State at any time
pursuant to paragraph 1(6) of Schedule 10. It cannot, however, be the case that the person, who may have
been on immigration bail for months, can simply be stopped and detained without any explanation. That is,
in Viscount Simon's words, “quite contrary to our conceptions of individual liberty”. It is also contrary to our
conception of individual dignity and the proper relationship between the executive and those present in the
UK, whether as citizens or not, to permit individuals to be apprehended and detained without according
them any explanation for the state's actions.

92. The requirement for reasons is also reflected in the Secretary of State's published policies. Pursuant to
the Secretary of State's Enforcement Instructions and Guidance, Chapter 55, two forms must be served
when a person is detained. Paragraph 55.6.3 provides that an IS91R form “must be served on every
detained person … at the time of their initial detention”. The form must include “the reasons for [the]
detention and the basis on which the decision to detain was made” (ibid). In addition another form, IS91, is
provided to the person who is the custodian of the detainee giving authority to detain. Chapter 55
paragraph 55.6.2 provides that “form IS91 is issued once and only once for any continuous period of
detention.” Reading paragraphs 55.6.2 and 55.6.3 together, in my view, indicates that where a person is
detained, released and then re-detained, new forms, both an IS91 and IS91R, must be served on their redetention. A person, in those circumstances, has not been subject to a “continuous period of detention”
and a new IS91 would need to be issued. There is no reason why the same should not be true of the
IS91R. The latter must be provided at the time of the “initial detention”. I take that to refer, as in relation to
the IS91, to the start of any continuous period of detention. That interpretation of Chapter 55 fits the
purpose of the notification provisions. It is to enable a person to understand the lawful basis of and reasons
for their detention and to protect against its arbitrary imposition. If a person is released and then re

-----

detained, they will not understand why they are in detention unless they understand, not only the reasons
for their original detention, but why they have been re-detained after they were released. That explanation
will need to be provided in the IS91R.

93. A person, such as the Claimant, who formally commences immigration bail because they have met the
conditions of bail, but is then immediately re-detained such that they are never in fact physically released,
is not in precisely the same position as someone who is detained after they have been at liberty for some
time. In my view someone in the Claimant's position is, nevertheless, entitled to be told the reasons for the
Secretary of State's decision that, notwithstanding that they have met the conditions for bail, they are not
being released. That is so for two reasons.

94. Firstly, in my view they are entitled to notice and reasons pursuant to Chapter 55. As set out above, a
person who formally commences immigration bail following a FTT's grant of bail, and is then immediately
re-detained has not had a “continuous period of detention” even if they were not, in fact, released. It is
therefore necessary that they be served fresh IS91 and IS91R forms.

95. Secondly, and even if that is not the correct interpretation of Chapter 55, in my view a detainee is
entitled at common law to be given reasons explaining why, despite meeting the conditions for bail granted
by the FTT, it has been decided not to release them.

96. Lord Steyn held in R (Anufrijeva) v Home Secretary [2003] UKHL 36, [2004] 1 AC 604 at [26]:

“Notice of a decision is required before it can have the character of a determination with legal effect
because the individual concerned must be in a position to challenge the decision in the courts if he or she
wishes to do so. This is not a technical rule. It is simply an application of the right of access to justice. That
is a fundamental and constitutional principle of our legal system.”

That applies to a person in the Claimant's position who has been granted conditional bail by the FTT, but
the Secretary of State decides not to release them because, it is said, there has been a material change of
circumstances since the FTT decision. The detainee is entitled to challenge that decision, whether by
returning to the FTT or by issuing judicial review proceedings, and is entitled to notification that it has been
decided not to release them.

97. I also consider the detainee is entitled to the reasons for the decision not to release them. There is, at
least as yet, no general duty at common law to give reasons for a decision (see _R (Oakley) v South_
_Cambridgeshire District Council_ _[2017] EWCA Civ 71, [2017] 1 WLR 3765 at [29]; R (CPRE Kent) v Dover_
_District Council [2017] UKSC 79, [2018] 1 WLR 108 at [51], and R (DSD) v Parole Board [2018] EWHC 694_
_(Admin), [2019] QB 285 at [183]). Nevertheless, as Elias LJ held in_ _Oakley_ at [30], “the common law is
moving to the position whilst there is no universal obligation to give reasons in all circumstances, in general
they should be given unless there is a proper justification for not doing so”. It is also clear that there are
categories of case in which the nature of the decision at issue requires reasons to be given on grounds of
fairness (see R v Higher Education Funding Council ex parte Institute of Dental Surgery [1994] WLR 242,
258 and discussion in Oakley para 14 and CPRE Kent para 51). For example, where a decision is made
concerning a detainee's liberty, and where, without adequate reasons a meaningful challenge to detention
will not be possible, fairness requires that reasons be given (see discussion in ex parte Institute of Dental
_Surgery_ p 256 and see _R v Secretary of State for the Home Department ex p Doody_ [1994] 1 AC 531,
565). That applies, in my view, to the present case. Fairness requires reasons be given where the
Secretary of State has decided, because of a material change of circumstance, not to release an individual
who has been granted bail by the FTT. It is a decision that directly impacts on the individual's liberty which
they are entitled to challenge. It is also a decision in which the Secretary of State is declining to follow the
ruling of an independent judicial tribunal. In those circumstances the individual is entitled to be told why the
decision was taken so that they have “an effective means of detecting the kind of error which would entitled
the court to intervene” (ex p Doody p 565).

**(iii) Were the procedural and/or substantive requirements for re-detaining the Claimant met on the**
**facts of this case?**


-----

98. The Claimant seeks to challenge the Secretary of State's refusal to release him on 30 April 2019 on
three bases:

i) The Claimant challenges the decision on procedural grounds and contends that the Secretary of State
should have given him notice that he was exercising statutory powers to re-detain him and the reasons for
the decision.

ii) The Claimant contends that the Secretary of State was not entitled to treat the rejection of the
Claimant's fresh submissions on 29 April 2019 as justifying re-detaining him because it was not a relevant
material change of circumstances.

iii) The Claimant contends that the Secretary of State was not entitled to treat the rejection of his further
submissions on 29 April 2019 as justifying re-detaining him because the Secretary of State had not, in fact,
properly considered the Claimant's submissions.

_(a) Procedural breach_

99. As set out above, I consider that the Claimant was entitled to be given reasons for the Secretary of
State's decision not to release him notwithstanding that he had met the conditions for FTT bail. That was a
requirement of Chapter 55 and the common law.

100. The Secretary of State did not serve fresh IS91 and IS91R forms on the Claimant until 6 June 2019. I
consider that to be a breach of Chapter 55. The Claimant formally commenced bail and was re-detained on
30 April 2019. That began a new period of detention which required new IS91 and IS91R forms. I do not,
however, consider that the failure to serve the forms earlier caused any substantive unfairness or had any
impact on the Claimant's detention.

101. The Claimant was, in fact, informed on 30 April 2019 that he was not being released and told of the
reasons (namely that the Secretary of State considered that the decision of 29 April meant that there was
no barrier to his removal and therefore he was not being released). Even if the Claimant was not told that
directly, it was, at the very least, set out in the Secretary of State's skeleton argument of 30 April 2019 for
the permission hearing in this case. On 1 May Laing J granted permission to challenge the lawfulness of
the decision not to release the Claimant in part because it was arguable that the 29 April decision did not
constitute a lawful basis for refusing to release him. The Claimant was therefore notified of the decision of
30 April 2019 not to release him and provided with the reasons for the decision. Even if IS91 and IS91R
forms were not served on the Claimant, it therefore made no practical difference in this case. I do not
therefore consider the failure to serve the relevant forms on 30 April rendered the Claimant's detention
unlawful. Even if that is wrong, however, it is clear the Claimant would have been lawfully detained even if
the forms has been served, and so would be entitled to only nominal damages (see _Lumba_ [95]-[101],

[169] and [253]-[256] and discussion below at [129]).

_(b) Treating the 29 April 2019 decision as a material change of circumstance_

102. Secondly, the Claimant argues that the Secretary of State was not entitled to treat the rejection of his
fresh submissions on 29 April 2019, even if that was lawful, as justifying re-detaining him as it did not
constitute a material change of circumstances.

103. I do not agree. If the decision of 29 April 2019 had been lawfully taken, which I examine below, I
consider that the Secretary of State was entitled to treat it as a material change of circumstances. As set
out above, in both Mahmood and Shote it was held that the fact that an individual's imminent removal had
become possible constituted a material change of circumstances which justified their re-detention. I
consider the same applies in the present case. The decision of 29 April 2019, if lawful, removed the
remaining barrier to the Claimant's removal. A person who has no barriers to removal, and can be removed
imminently, has significantly less incentive to comply with bail conditions, and is significantly more likely to
abscond, than one whose challenge to deportation is still being considered. A person's application for bail
is also significantly stronger where their detention would otherwise be for an undefined period than where
removal can be shortly arranged. I consider that the Secretary of State was entitled to conclude that a
decision to reject the Claimant's further submissions was if lawfully made a material change of


-----

circumstances that occurred since the FTT decision of 2 April 2019 and justified not releasing the Claimant
even if he met the FTT's bail conditions.

_(c) Flaws in 29 April 2019 decision_

104. Thirdly, the Claimant argues that, even if in principle the Secretary of State was entitled to treat a
rejection of his further submissions as a material change of circumstances, it was not “reasonable” of the
Secretary of State to treat the decision of 29 April 2019 as removing barriers to his detention. That is
because, the Claimant contends, the decision failed properly to address his further submissions.

105. Mr Toal submits that the Claimant does not need to show that the decision of 29 April 2019 was
unlawfully made. He argues that he is challenging the decision to treat the Claimant's submissions as
having been properly considered so as to remove the bar to removal contained in paragraph 353A of the
Immigration Rules, but that he is not challenging the lawfulness of the decision to reject the submissions
itself. Ms Gray argues that that is a distinction without a difference. I agree with her. Paragraph 353A
provides that while further submissions are being considered, the Secretary of State cannot remove an
individual. If the decision of 29 April 2019 to reject the Claimant's further submissions was lawfully made,
that would mean the Secretary of State had properly considered the further submissions. He was then
entitled to treat the decision of 29 April as removing the barrier to the Claimant's removal. On the other
hand, if the Secretary of State had not lawfully considered the further submissions, he was not entitled to
conclude that the barriers to the Claimant's deportation had been removed. That would mean the Claimant
could not be removed and the Secretary of State was not entitled to conclude that there had been a
material change of circumstances since the FTT decision on 2 April 2019. In my view, therefore, unless the
Claimant can show that the decision of 29 April 2019 to reject his further submissions was unlawfully taken,
whether because the further submissions had not been properly considered or otherwise, he cannot
succeed in his claim that the decision not to release him on 30 April was unlawful.

Legal framework

106. Whether further submissions are rejected or treated as a fresh claim under paragraph 353 of the
Immigration Rules is a question for the Secretary of State. He must ask himself whether the further
submissions are significantly different to those already considered, and, if so, whether they create a
realistic prospect of success in a further asylum claim (see WM (DRC) v Secretary of State for the Home
_Department_ _[2006] EWCA Civ 1495 at [6]). If the answer to either question is negative the Secretary of_
State is entitled not to treat the submissions as a “fresh claim”. The Secretary of State's decision in this
regard can be impugned on ordinary public law grounds, such as a failure to consider a relevant matter or
breach of legitimate expectation or failure to ask to _“ask himself the right question and take reasonable_
steps to acquaint [himself] with the relevant information to enable him to answer it correctly” (Secretary of
_State for Education and Science v. Tameside MBC [1977] AC 1014, 1065B per Lord Diplock)._

107. The decision to refuse a fresh claim can also be challenged on grounds of irrationality. The Court of
Appeal explained in WM(DRC) at [10]-[11] how irrationality is approached in this context:

“Whilst, ... the decision remains that of the Secretary of State, and the test is one of irrationality, a decision
will be irrational if it is not taken on the basis of anxious scrutiny. Accordingly, a court when reviewing a
decision of the Secretary of State as to whether a fresh claim exists must address the following matters.

First, has the Secretary of State asked himself the correct question? The question is not whether the
Secretary of State himself thinks that the new claim is a good one or should succeed, but whether there is
a realistic prospect of an adjudicator, applying the rule of anxious scrutiny, thinking that the applicant will
be exposed to a real risk of persecution on return:…The Secretary of State of course can, and no doubt
logically should, treat his own view of the merits as a starting-point for that enquiry; but it is only a startingpoint in the consideration of a question that is distinctly different from the exercise of the Secretary of State
making up his own mind. Second, in addressing that question, both in respect of the evaluation of the facts
and in respect of the legal conclusions to be drawn from those facts, has the Secretary of State satisfied
the requirement of anxious scrutiny? If the court cannot be satisfied that the answer to both of those


-----

questions is in the affirmative it will have to grant an application for review of the Secretary of State's
decision.”

108. In relation to “anxious scrutiny” Lord Carnwath observed as follows in MN (Somalia) v Secretary of
_State for the Home Department [2014] UKSC 30, [2014] 1 WLR 2064 at [31]:_

“The higher courts have emphasised the special responsibility carried by the tribunals in the context of
asylum appeals. It is customary in this context to speak of the need for “anxious scrutiny”… As a concept
this is not without its difficulties, but I repeat what I said in _R(YH) v Secretary of State for the Home_
_Department para 24:_

“the expression [anxious scrutiny] in itself is uninformative. Read literally, the words are descriptive not of a
legal principle but of a state of mind: indeed, one which might be thought an 'axiomatic' part of any judicial
process, whether or not involving asylum or human rights. However, it has by usage acquired special
significance as underlining the very special human context in which such cases are brought, and the need
for decisions to show by their reasoning that every factor which might tell in favour of an applicant has
been properly taken into account. I would add, however, echoing Lord Hope in R (BA (Nigeria)) v Secretary
of State for the Home Department [2010] 1 AC 444, para 32], that there is a balance to be struck. Anxious
scrutiny may work both ways. The cause of genuine asylum seekers will not be helped by undue credulity
towards those advancing stories which are manifestly contrived or riddled with inconsistencies.””

109. In relation to a claim being having “no realistic prospect of success”, the courts have explained that,
for all practical purposes, a claim will have no realistic prospect of success before an Immigration Judge if
the case is “clearly unfounded” (see R(YH) v Secretary of State for the Home Department [2010] EWCA
_Civ 116 at [8]-[10])._

Application to present case

110. The Claimant contends that the decision of 29 April 2019 to reject his fresh submissions of 6
September 2018 and 22 March 2019 was flawed for two reasons:

i) He argues that the Secretary of State failed properly to consider the risk that if he was returned to
Somalia he would be placed in humanitarian conditions similar to those he faced in the Elasha Biyaha IDP
camp where he was living before he was abducted by Al-Shabaab in 2013 and which, he claims, would
engage ECHR Art 3.

ii) The Claimant also argues that the Secretary of State failed to consider the evidence he provided on 6
September 2018 which, he claimed, showed that his mother was killed by Al-Shabaab as retribution for his
leaving Somalia and which established that he was at risk from Al-Shabaab if he returned.

Failure to consider humanitarian conditions claim

111. Up to 22 March 2019 the Claimant's claim for asylum and protection had focussed upon his assertion
that he had a well-founded fear of being targeted by Al-Shabaab if he returned to Somalia. Although he
had provided some very limited evidence of the conditions in which he was living in Elasha Biyaha before
he was abducted by Al-Shabaab in 2013, he had not made any claim challenging his return to Somalia
based upon the humanitarian conditions he would face there. That was explained by the Claimant on the
basis that he had not had legal representation at the time he made his original asylum and protection
claim.

112. On 22 March 2019 the Claimant, through a witness statement and letter from his solicitors, made
submissions, for the first time, that if he was returned to Somalia there was a real risk that he would find
himself forced to live in an IDP camp where conditions, he claimed, would be so poor as to breach his
ECHR Art 3 right to be protected from “inhuman or degrading treatment”.

113. In his witness statement of 22 March 2019, the Claimant provided a description of the conditions in
which, he said, he and his family had lived in an IDP camp at Elasha Biyaha. He described the nature of
the makeshift home in which his family lived (a temporary shelter made out of sticks and plastic sheeting),
and the lack of food medicine and running water or sanitation in the camp He stated that because of the


-----

lack of food and water there was significant levels of violence in the camp and that he had seen people
killed in arguments over food and water.

114. Submissions were made in the accompanying letter from the Claimant's solicitors also of 22 March
2019. They explained that the IDP camp at Elasha Biyaha was on the “outskirts of Mogadishu”. The letter
referred to the very poor humanitarian conditions in the camp and contended that there was a real risk the
Claimant would find himself forced to live in such conditions again if he was returned to Somalia. The letter
[referred to the decision of the Upper Tribunal in MOJ and others (return to Mogadishu) Somalia GC [2014]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DDJ-W7M1-F0JY-C2YF-00000-00&context=1519360)
_[UKUT 00442which had found that those forced to live in IDP camps in Somalia “will be experiencing](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DDJ-W7M1-F0JY-C2YF-00000-00&context=1519360)_
adverse living conditions such as to engage the protection of Article 3 of the ECHR.”

115. The 22 March 2019 letter stated that the Claimant relied on paragraph 339K of the Immigration Rules
which provides that:

“The fact that a person has already been subject to …serious harm, or to direct threats of such persecution
or such harm, will be regarded as a serious indication of [a] …real risk of suffering serious harm, unless
there are good reasons to consider that such …serious harm will not be repeated.”

The Claimant asserted that there was no “good reason” to consider that he would not find himself again in
conditions which engage ECHR Art 3 if returned to Somalia. It was noted in the letter that the Claimant and
his family were still living in the IDP camp in Elasha Biyaha when the, so called, “economic boom” in
Mogadishu had begun, but that they had not benefited from it. The letter also stated that since he left
Somalia the Claimant's mother had been killed and it was said he did not know the whereabouts of his
other family members.

116. The Secretary of State sought to deal with the Claimant's 22 March 2019 submissions and evidence
in his decision letter of 29 April 2019. The decision letter summarised the description the Claimant gave of
the conditions he and his family experienced in Elasha Biyaha, but set out none of the consequences in
terms of risk of return it was claimed flowed from that. The Secretary of State stated that the Claimant had
provided “no new material when assessed against the previous claims that have already been considered.”
It was said that the further representations dated 22 March 2019 merely “re-iterated the claims that have
already been considered and refused in 2015.”

117. Irrationality is a high threshold, but it is difficult to see how that can be a rational conclusion. The
suggestion that, if returned, the Claimant might face living conditions which would fall below acceptable
humanitarian standards simply was not considered in 2015 when the Claimant applied for asylum. Nor was
it considered subsequently. The Claimant's claim had been considered purely on the basis of the risk he
would face of persecution from Al-Shabaab. That is no criticism of the relevant decision-maker as the
humanitarian claim had not been made. It is difficult to see, however, how it can be said that the 22 March
2019 letter was simply “re-iterating” the previous claim or that the humanitarian standards claim had
already been considered where it does not appear in any of the relevant decisions of the Secretary of State
or the FTT.

118. It appears from reading the 29 April 2019 decision letter as a whole that the Secretary of State had
misunderstood the 22 March 2019 submissions as being concerned with the threat of persecution from AlShabaab. The decision letter described the Claimant as having “maintained that your fear of returning to
Somalia is due to a fear of persecution because of your imputed religious opinion as a result of being in
fear of Al-Shabaab”. The letter set out in some detail evidence of the waning power of Al-Shabaab in
Somalia (paragraphs 25-27) and stated that “it is apparent from the information … that Al-Shabaab's
influence on the region is diminishing”. While there was some reference to the guidance in _MOJ_ on
conditions in Somalia generally (see further below at [136]), that was regarded as relevant by the Secretary
of State only in relation to the risk of the Claimant being targeted by Al-Shabaab if he returned (paragraphs
29-33). It was not referred to in respect of the general humanitarian conditions the Claimant would face.
The letter also described the experience of individuals who had returned to Somalia from abroad. Again,
however, that was in the context of an assessment of whether the Claimant would be targeted because he
was seen as “westernised” or because he was an English speaker (paragraphs 34-37). The Secretary of
State set out evidence from 2013 2014 about the different elements that made up the “returning diaspora”


-----

in Mogadishu (paragraph 36-43). That made some reference to the opportunities for those returning,
however the material was relied on by the Secretary of State solely to establish that there was no evidence
of Al-Shabaab “targeting returnees” (paragraph 42) and to establish that there was no evidence that
“westernised speech and fashion” placed “returnees at risk” (paragraph 43).

119. The fact that the Secretary of State focused exclusively upon the risks the Claimant might face from
Al-Shabaab is clear from his “summary of findings of fact”, which was that:

“It is not accepted that you will be persecuted on return to Somalia because of your imputed religious
beliefs namely being kidnapped by Al-Shabaab. It is also not accepted that on your return to Somalia you
would be at risk because you are westernized.”

The letter concluded that the Claimant had not made a fresh claim within the requirements of paragraph
353 of the Immigration Rules.

120. Nowhere in the letter of 29 April 2019 did the Secretary of State consider the risk that if the Claimant
was returned to Somalia he would find himself forced to live in an IDP camp where humanitarian conditions
engaged the protection of ECHR Art 3. It cannot therefore be said that the Secretary of State treated such
a claim with the required anxious scrutiny or rationally concluded that it had no realistic prospect of
success before an Immigration Judge. The decision of 29 April to reject the Claimant's further submissions
was thus not lawfully taken.

Failure to consider the “death certificate” for the Claimant's mother

121. The Claimant further submits that the Secretary of State failed in his decision of 29 April 2019 to
consider, properly or at all, the material provided on 6 September 2018 (namely the “death certificate” for
the Claimant's mother suggesting that the Claimant was at risk of being targeted by Al-Shabaab if he
returned to Somalia).

122. On 15 October 2018 the Claimant issued judicial review proceedings challenging the failure to
consider the 6 September 2018 material, and arguing that without the material being considered the “notice
of removal window” then in place was unlawful. The Secretary of State compromised the judicial review
and in a consent order sealed on 4 December 2018 agreed to “reconsider the [Claimant's] further
submissions dated 6 September 2018.”

123. The decision letter of 29 April 2019, however, makes no mention of the Claimant's further submission
of 6 September 2018 nor says anything about their contents. It does not refer to the “death certificate” for
the Claimant's mother or indicate whether that material altered the assessment of the threat to the
Claimant from Al-Shabaab. As set out below at [145], those matters were considered in the supplementary
letter of 10 June 2019 but there is no trace of them in the letter of 29 April 2019. Ms Gray submitted that I
should infer that those matters were considered by the Secretary of State. I am unable to accept that. If
those matters had been considered by the Secretary of State one would have expected some reference to
them in the decision letter. Instead the only further submissions referred to were those of 22 March 2019
and there is nothing to suggest that the 6 September 2018 submissions were considered.

124. In my view, the failure to consider the 6 September 2018 submissions meant that the 29 April 2019
decision was not lawfully taken. Given the compromise of the judicial review proceedings, the Claimant had
a legitimate expectation that his further submissions of 6 September 2018 would be considered. The
Secretary of State gave a specific undertaking to that effect in the consent order in which the judicial review
was withdrawn. That legitimate expectation was clearly breached in the decision of 29 April 2019.

Consequence for detention

125. If the 29 April 2019 decision was not properly taken for either of the reasons set out above, it follows
that the Secretary of State was not entitled to conclude that he had dealt with all the Claimant's further
submissions, and that there was thus no barrier to the Claimant's removal from the UK. It also follows,
therefore, that the Secretary of State was not entitled to conclude that there had been a material change of
circumstances since the FTT decision of 2 April 2019. The position on 30 April remained, as it had been on


-----

2 April, that the Claimant had extant further submissions that had not been properly considered. Until they
were properly considered, the Claimant could not lawfully be removed. Ms Gray accepted that if the
Secretary of State's conclusion on 29 April 2019 that the Claimant could now be removed was erroneous, it
was an error that could be said to “bear on and be relevant to the decision to detain [him]” (see Lumba at

[68]). I consider that concession to be correctly made. Subject to the discussion in the following section,
that meant the Claimant's continued detention from 30 April 2019, once he had satisfied the bail conditions,
was unlawful.

**Events after 30 April 2019 and remedy**

**Secretary of State's decision of 10 June 2019**

126. Matters have moved on since 30 April 2019. On 10 June 2019 the Secretary of State served a
“supplementary letter” to that of 29 April 2019. It dealt, in some detail, with the material served on 6
September 2018 relating to the death of the Claimant's mother. It also said more about conditions in
Elasha Biyaha and the Claimant's risk on return.

127. The possible purposes for, and legal consequences of, the Secretary of State serving “supplementary
letters” in immigration proceedings was considered by the Court of Appeal in _Caroopen v Secretary of_
_State for the Home Department [2016] EWCA Civ 1307. The Court of Appeal held supplementary letters_
could serve three purposes. Firstly, where a decision was challenged on the basis of inadequate reasons,
a supplementary letter could “cure defects in [the] original decision” by supplying “reasons, or fuller
reasons, for the original decision” (paragraph 30). Secondly, “a supplementary letter may be effective not
by retrospectively curing the original decision but by prospectively filling the gap which would be held to
arise if it should be held to be invalid” (paragraph 31). The supplementary letter is then relevant to remedy.
It will not cure the deficiencies in the earlier unlawful decision, but it will mean, if the supplementary
decision is lawfully made, that there is no purpose in remitting the matter for reconsideration as the same
decision would inevitably be taken. Thirdly, a supplementary letter may be required, not because an
original decision was invalid but to deal with further material that came to light after it was made (paragraph
32).

128. In the present case, I do not consider that it can be said that the 10 June 2019 decision was no more
than an explanation, or fuller explanation, for the decision on 29 April 2019 (i.e. it does not fall within the
first category of case listed in _Caroopen). If, however, the 10 June decision was lawfully made, and the_
Claimant's further submissions were properly considered, it is relevant to remedy (i.e. it is capable of falling
within the second category of Caroopen case).

129. Pursuant to _Lumba, if an individual was unlawfully detained following a public law error, they are_
entitled to only nominal damages if they would have been detained in any event and even if the error had
not occurred (see Lumba [95]-[101], [169], [253]-[256]). There was some suggestion in Lumba that it might
be necessary for the Secretary of State to show that detention would “inevitably” have occurred absent the
public law error. It is now clear that it is sufficient for the Secretary of State to establish, on the balance of
probability, that the individual could have been lawfully detained in any event (see _OM (Nigeria) v_
_Secretary of State for the Home Department_ _[2011] EWCA Civ 909 at [23]). It remains the case, however,_
that the burden is on the Secretary of State in this regard (see R (EO) v Secretary of State for the Home
_Department_ _[2013] EWHC 1236 (Admin) at [70]-[74])._

130. The Secretary of State submits in the present case that, even if the decision of 29 April 2019 was
erroneous because of the failure to consider the Claimant's further submissions of 6 September 2018 or
because of the way in which the risk of the Claimant returning to an IDP camp was considered, that made
no difference to his detention. That is apparent, he argues, because those matters were properly
considered on 10 June 2019 and were not found to amount to a fresh claim within the meaning of
paragraph 353 of the Immigration Rules. Therefore, the Secretary of State contends, even if the Claimant
was detained on the basis of an unlawful decision on 29 April, he is entitled to only nominal damages. If
that submission is correct, the Secretary of State also contends that I should not order the Claimant's


-----

release, as it means that, at least since 10 June 2019, when the Secretary of State submits his further
submissions were properly considered, the Claimant has been lawfully detained.

131. One issue that arose before me is whether the above submission means that I can and should
determine the legality of the 10 June 2019 decisions to reject the Claimant's further submissions. This was
a matter addressed, in particular, in the parties' post-hearing submissions which I received, following
requests for short extensions, on 3 July, 8 July and 12 July 2019. The Claimant submits that the legality of
the 10 June 2019 is not a matter before me. He submits that the present challenge is only to the legality of
his detention and not to the legality, or otherwise, of the decision of 10 June 2019. The latter is being
challenged, he submits, in the judicial review lodged before the Upper Tribunal on 17 June 2019 and are
not before the court in the present claim. The Secretary of State disagrees and submits that the legality or
otherwise of the 10 June 2019 decision is an issue I should determine.

132. One possibility I canvassed with the parties was staying the present claim pending the determination
of the judicial review lodged before the Upper Tribunal. The Secretary of State opposed such a course of
action. The Claimant was more receptive during the course of the hearing, but in post-hearing submissions
did not suggest that was a course I should take. Instead he submitted that I should consider whether the
Secretary of State “correctly concluded, as he did at various times, that the Claimant had no outstanding
submissions in support of a putative fresh claim” and whether it was “reasonable” for the Secretary of State
to treat the 29 April and 10 June 2019 decisions as removing the basis for the Claimant's removal. He
submitted, however, that I should not consider the legality of the decision to reject the Claimant's further
submissions.

133. I recognise that the present judicial review is a challenge to the legality of the Claimant's detention. In
my view, however, and as set out above at [105], determining the legality of the decision of 29 April 2019 to
reject the Claimant's further submissions is necessary for assessing the legality of the Claimant's detention
from 30 April. Similarly, the legality of the 10 June 2019 decision is, in my view, also a matter that I need to
consider. It is relevant to remedy. I agree with the Secretary of State that if the Claimant's further
submissions were properly considered and lawfully rejected on the 10 June 2019, it will indicate that, even
if the decision of 29 April 2019 was unlawful, he would have been detained in any event. It will demonstrate
that if the fresh submissions had been properly considered on 29 April 2019, they would have been
rejected. He is then entitled only to nominal damages. It will also mean that it is not unlawful to continue to
detain the Claimant notwithstanding the FTT bail decision. I therefore do consider it necessary to consider
the legality of the 10 June 2019 decision.

**Did the 10 June 2019 decision, read with that of 29 April, properly consider the Claimant's further**
**submissions?**

Humanitarian conditions claim

134. The 10 June 2019 letter dealt with the Claimant's submissions about humanitarian conditions he
might face if he was returned to Somalia as follows:

“Although it has been submitted by your solicitors that the decision letter of 29 April 2019 does not address
the risks of you finding yourself living in an IDP camp, the letter of the 29 April 2019 refers to the returning
diaspora and to the opportunities in Mogadishu that returnees have been able to take advantage of. The
letter of the 29 April 2019 refers to reports of the returning diaspora dating back to 2013 and 2014 and
more recent reports that show this trend is continuing and that diaspora communities continue to return to
Mogadishu and that through increasing investment and construction projects the city of Mogadishu and its
economy have been revived and continue to develop.”

The letter referred to a 2018 “Country Policy and Information Note” on Somalia which set out the role of
returnees in the development of Somalia, and their role in the “business sector” and politics.

135. The letter of 10 June 2019 continued:

“It is accepted that there have been reports that the humanitarian conditions within some of the IDP

[camps] in Somalia were so poor that a person's protected rights under Article 3 of ECHR would be


-----

engaged if returning them to Somalia would result in their return or placement in some of these camps…
However it is not accepted that there is a real risk that you will be in the situation of having to reside in an
IDP camp, where humanitarian conditions breach Article 3 upon being returned to Somali and we refer
back to the situation of the returning diaspora to Mogadishu, the city you will be removed to, and the
opportunities that they are able to take advantage of in Mogadishu.”

The letter referred to “inconsistencies” between accounts the Claimant had given, and stated that they
undermined the credibility of the Claimant's claim that he had resided at Elasha Biyaha camp. In his
decision, however, the Secretary of State assumed that the Claimant had resided at Elasha Biyaha as he
claimed. The Secretary of State concluded: “even if you had been at Elasha Biyaha camp prior to coming
to the UK, as claimed, there is no real risk of you having to return there. The reason for this are… reports
of the improved situation in Mogadishu and opportunities for those who return to Somalia and decide to
remain in Mogadishu.” The letter stated, on the basis of both the 29 April and 10 June 2019 letters, that the
Claimant had not made a fresh claim pursuant to paragraph 353 because the grounds he raised “had
either been considered already or … when taken together with the previously considered material, would
not create a realistic prospect of success before an Immigration Judge.”

136. As set out above, the reason the Secretary of State gave in the 29 April 2019 letter for considering
evidence of the experience of the “returning diaspora” in Mogadishu was to establish that they did not face
a risk from Al-Shabaab or of being targeted because they were “westernised” or spoke English. The 10
June 2019 letter relied upon the same evidence to demonstrate the opportunities for those returning to
Somalia, and as an indication the Claimant would not face a real risk of living in conditions which engaged
ECHR Art 3. The evidence referred to in the 29 April letter related to the experience of Somalis who had
returned to Mogadishu from different Western countries and managed to re-settle successfully. It set out 11
examples of individuals who had had set up businesses or found work on their return. The 29 April letter
also referred to newspaper articles from 2013 and 2014 about the role the “returning diaspora” played in
Mogadishu's “renaissance” and described the “quirky” characteristics of the returning groups (“Somali-Brits
– the serial title collectors”, “The Americans – the Tea Party Types” and others).

137. The difficulty with the Secretary of State's analysis is that it is clear that while some returnees to
Somalia have, indeed, succeeded in re-establishing themselves in Mogadishu, and have been able to take
part in and contribute to the development of the city, others face conditions that are not acceptable in
humanitarian protection terms. That is apparent from the current “country guidance” for Somalia set out by
the Upper Tribunal in _MOJ and others (return to Mogadishu) Somalia GC_ _[[2014] UKUT 00442. The](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DDJ-W7M1-F0JY-C2YF-00000-00&context=1519360)_
following guidance from MOJ was cited in the Secretary of State's letter of 29 April 2019:

“(ii) Generally, a person who is “an ordinary civilian” (i.e. not associated with the security forces; any aspect
of government or official administration or any NGO or international organisation) on returning to
Mogadishu after a period of absence will face no real risk of persecution or risk of harm such as to require
protection under Article 3 …

(xi) It will … only be those with no clan or family support who will not be in receipt of remittances from
abroad and who have no real prospect of securing access to a livelihood on return who will face the
prospect of living in circumstances falling below that which is acceptable in humanitarian protection terms.”

138. The Upper Tribunal had found in MOJ at [420] in relation to those returning to Mogadishu that “it is
likely that those who … find themselves living in inadequate makeshift accommodation in an IDP camp will
be experiencing adverse living conditions such as to engage the protection of Article 3 of the ECHR”. It
found at [421] that while “the humanitarian position in Mogadishu has continued to improve since …
country guidance … was published [in 2011]” that did not apply to “those with no alternative to living in
makeshift accommodation in an IDP camp.” The Upper Tribunal recognised that generally conditions were
improving in Somalia, but again that that did not apply to everyone. It found at [424]-[425]:

“The evidence indicates clearly that it is not simply those who originate from Mogadishu that may now
generally return to live in the city without… facing a real risk of destitution. Large numbers of Somali
citizens have moved to Mogadishu where, as we have seen there is now freedom of movement and no
clan based discrimination Such a person seeking to settle in Mogadishu but who has not previously lived


-----

there would be able to do so provided he had either some form of social support network, which might be
in the form of membership of a majority clan or having relatives living in the city, or having access to funds
such as would be required to establish accommodation and a means of on-going support. That might be in
terms of continuing remittances or securing a livelihood, based on employment or self employment.

On the other hand, relocation in Mogadishu for a person of a minority clan with no former links to the city,
no access to funds and no other form of clan, family or social support is unlikely to be realistic as, in the
absence of means to establish a home and some form of ongoing financial support there will be a real risk
of having no alternative but to live in makeshift accommodation within an IDP camp where there is a real
possibility of having to live in conditions that will fall below acceptable humanitarian standards.”

139. The Upper Tribunal explained in its guidance at (ix) how an assessment should be made of whether
a person returning to Mogadishu after some years abroad would be likely to be able to re-establish
themselves:

“If it is accepted that a person facing a return to Mogadishu after a period of absence has no nuclear family
or close relatives in the city to assist him in re-establishing himself on return, there will need to be a careful
assessment of all of the circumstances. These considerations will include, but are not limited to:

- circumstances in Mogadishu before departure;

- length of absence from Mogadishu;

- family or clan associations to call upon in Mogadishu;

- access to financial resources;

- prospects of securing a livelihood, whether that be employment or self employment;

- availability of remittances from abroad;

- means of support during the time spent in the United Kingdom;

- why his ability to fund the journey to the West no longer enables an appellant to secure financial support
on return”

140. The letter of 10 June 2019 concluded that the Claimant's claim that there was a real risk he would
face conditions falling below ECHR Art 3 standards if returned did not have a realistic prospect of success
before an Immigration Judge. I do not consider that conclusion was reached on the basis of the Secretary
of State asking himself the right question.

141. The applicable country guidance suggests that an “ordinary civilian” returning to Mogadishu will
“generally” not face a risk of conditions so poor as to engage ECHR Art 3. As was recognised in _MOJ,_
however, where an individual is from a “minority clan” does not have “clan or family support”, “remittance
from abroad” or a “real prospect of securing access to livelihood” they may face the prospect of living in
conditions that are “[un]acceptable in humanitarian protection terms”. The Claimant, as the FTT accepted
in 2015, is from a “minority clan”. If the Claimant was in an IDP camp before he left Somalia in 2014, where
the conditions breached ECHR Art 3 (as he now claims), that would suggest a real possibility of an
Immigration Judge finding that he did not, at least at that time, have “clan or family support” to protect him
from such conditions. It may be that even without that support the Claimant would have a “real prospect of
securing access to livelihood”, so as to avoid living in conditions breaching ECHR Art 3 in the future, as
other returnees have done. That, however, required the Secretary of State to ask himself about the
Claimant's specific prospects on return, having obtained sufficient evidence to enable him to answer it
correctly. He failed to do so.

142. It was not sufficient, in my view, for the Secretary of State solely to rely on generic evidence of
returnees who had managed to find work or start businesses. It is not understood to be the Secretary of
State's view that, given economic growth in Somalia, any adult now returning to Mogadishu, irrespective of
their family ties, skills or connections, will be able to obtain work so that there is no real risk of any of them
finding themselves living in conditions breaching ECHR Art 3. That would not be consistent with the MOJ


-----

country guidance. The guidance suggests that there are returnees who face a risk of finding themselves in
IDP camps and that deciding whether their prospects of “establishing” themselves successfully on return
so as to avoid that require “a careful assessment of all of the circumstances” on the facts of an individual
case. In his post-hearing submissions the Claimant refers to the kinds of factors suggesting he may be
unable to establish himself successfully in Mogadishu (including that he lacks family or social connections
in Mogadishu, that he lacks capital, education, work experience or any links to Mogadishu he could use to
establish himself there).

143. The Secretary of State notes that the FTT had found in its decision of 19 March 2015 that the
Claimant would be returned not to Elisha Biyaha but to Mogadishu. That is not, however, an answer. The
_MOJ country guidance referred to above concerns those returning to Mogadishu. As the guidance_
recognises, while ordinarily returnees will not face conditions that breach ECHR Art 3, that is not the case
for everyone. The Secretary of State needed to ask if the Claimant's particular circumstances mean he will
be a successful returnee, or whether there is a real prospect of an Immigration Judge, considering all the
facts and applying the required anxious scrutiny, finding a real risk that the Claimant will be one of those
unable to establish themselves and forced to reside in an IDP camp. The Secretary of State did not ask
that question and that rendered the decision to reject the Claimant's submissions unlawful.

144. Or to put it another way, the Secretary of State could not rationally conclude that there was no real
prospect of an Immigration Judge, applying anxious scrutiny, finding that the Claimant fell within the
category of those returnees who would face a real risk of conditions that breached ECHR Art 3 if he
considered only generic evidence about returnees who were successful in re-establishing themselves in
Mogadishu. It also meant the Secretary of State had not himself given the case the “anxious scrutiny”
which, as the Court of Appeal held in WM (DRC), is necessary if it is to be rational. As Lord Carnwath held
in _MN, “anxious scrutiny” refers to the “need for decisions to show by their reasoning that every factor_
which might tell in favour of an applicant has been properly taken into account.” Without considering
whether there were factors specific to the Claimant that suggest he might not be able to establish himself
successfully in Mogadishu, the Secretary of State has not “properly taken into account” every factor that
might tell in the Claimant's favour.

Claimant's mother's “death certificate”

145. Unlike the 29 April 2019 decision, the 10 June 2019 decision expressly considered the 6 September
2018 submissions, and it considered in some detail the evidence in the Claimant's mother's “death
certificate”. The Secretary of State noted in the 10 June 2019 letter that the Immigration Judge in 2015 had
found that even though the Claimant had been held by Al-Shabaab for some months and forced to work for
them in 2013-2014, he had not established a future risk from Al-Shabaab if he returned to Somalia. The
Secretary of State further noted that in order to establish such future risk “you would need to show that a
boy abducted by a terrorist group and used as a cook for a period of a few months who managed to
escape … would be of such interest that years later his mother would be killed as a result”. The Secretary
of State analysed the “death certificate”, and its authenticity, in some detail to determine whether it
suggested such a risk. He set out reasons for doubting the authenticity of the certificate. The certificate
stated that the Claimant had received death threats from Al-Shabaab when he was in the UK, but without
indicating how the Somali police would be aware of them. The certificate suggested that Al-Shabaab
members claimed that they were on the hunt for the Claimant, and the Secretary of State noted that if
those threats were made to the police “they would appear to have access to your mother's alleged
murderers”. The Secretary of State considered that to be implausible. The Secretary of State also noted
there have been problems more generally with the authenticity of documents apparently coming from
Somalia and noting the ease of procuring fraudulent documents.

146. The Secretary of State concluded that, taken with the earlier findings of the Immigration Judge about
the Claimant's credibility, little weight could be attached to the “death certificate”. The Secretary of State
also concluded that the evidence, as a whole, did not show that the Claimant is of interest to Al-Shabaab or
that they would pose a direct threat to him if he returned to Somalia. The Secretary of State concluded that


-----

the new submissions, taken with those already made, did not therefore create a realistic prospect of
success before an Immigration Judge.

147. In the Claimant's judicial review of 17 June 2019, issued before the Upper Tribunal, he contends that
the Secretary of State could not reasonably exclude a “realistic prospect” of a further tribunal accepting the
Claimant's evidence about his mother's death. Such a conclusion can be challenged on grounds of
rationality. I do not, however, consider it was irrational for the Secretary of State to conclude there was not
a realistic prospect of an Immigration Judge, applying the rule of anxious scrutiny, concluding that the
Claimant faced a real risk of prosecution or mistreatment in breach of the ECHR at the hands of AlShabaab.

**DCPR decisions on 24 May and 6 June 2019**

148. As set above, at the hearing before me on 18 June 2019 I was provided with the DCPR decision of
24 May 2019 in which the Secretary of State's authorising officer determined that the Claimant should be
released once appropriate accommodation was in place for him. I was also provided with a further DCPR
decision on 6 June 2019 at which a different authorising officer concluded that the Claimant should remain
in detention pending this judicial review and should only be released if the judicial review succeeded.

149. Mr Toal took me to those decisions. I do have sympathy with the Claimant's concerns about the
decision-making process. It does seem unsatisfactory to have two decisions made by different decisionmakers two weeks apart reaching different conclusions. A challenge to the failure to release the Claimant
on the basis of the DCPR decision of 24 May 2019 does not, however, fall into the grounds of claim
brought. It neither involved a failure to follow CPP recommendations (Ground 1), nor did it relate to the
decision of 30 April 2019 not to release the Claimant despite the FTT bail decision (Grounds 2 and 3). It is
not clear on what, if any, grounds a failure to release the Claimant following the decision of 24 May 2019
was being brought and no amendment was sought to the Claimant's pleadings. In fairness to Mr Toal, I
understood him to be taking me to the decisions to suggest the generally unsatisfactory nature of the
Secretary of State's decision-making process rather than as giving rise to a fresh ground of claim.

**Conclusion**

150. For the reasons given, I consider that the Claimant has been unlawfully detained since 30 April 2019.
He has been detained because the Secretary of State believes that on 29 April, or at least on 10 June
2019, he had lawfully considered the Claimant's further submissions, and, having rejected them, that the
remaining barrier to the Claimant's removal had been lifted. The Secretary of State considered that to be a
material change of circumstances justifying him not releasing the Claimant on 30 April despite his then
satisfying the conditions for bail set by the FTT. The decision of 29 April 2019 was, however, in my view
flawed because the Secretary of State had failed properly to consider (i) the submissions and material
provided on 6 September 2018 and (ii) whether there was a realistic prospect of an Immigration Judge
finding a real risk the Claimant would be returned to humanitarian conditions so poor as to engage ECHR
Art 3. I consider that the 10 June 2019 decision remedied the first flaw but not the second.

151. It thus remains the case that the Claimant's further submissions have not been properly considered.
The Secretary of State is therefore not entitled to conclude that there has been a material change of
circumstances since the FTT bail decision. The Claimant has been detained unlawfully since 30 April 2019
and I consider he is entitled to a declaration to that effect. The Claimant invites me to direct that he be
released from detention without delay. I do not intend to do so. The FTT granted the Claimant bail subject
to the Secretary of State identifying a suitable bed space in AP for him. Unless the Secretary of State can
identify some further, and proper, change of circumstance, he is required to seek an appropriate place for
the Claimant and release him once one is found as per the grant of bail. As to the Claimant's claim for
damages, I would invite the parties' submissions on how to deal with that.

**End of Document**


-----

