# Northern Ireland Human Rights Commission's Application and JR295's
 Application for Judicial Review [2024] NIKB 35

NORTHERN IRELAND KING'S BENCH DIVISION

HUMPHREYS J

13 MAY 202413 MAY 2024

**Immigration — Judicial Review — Applicants' claiming judicial review relating to Illegal Migration Act 2023**
**(“IMA”) — 16 year old asylum seeker from Iran claiming asylum — Challenging legislations on**
**unaccompanied children — Applicant contending incompatibility of IMA with relevant convention rights —**
**Disapplication of primary legislations — Analysis of diminution of rights safeguards or equality of**
**opportunities — Whether international protection applying to all eligible persons — Whether the applicant**
**qualifies as refugee in accordance with Qualification Directive — Human Rights Act 1988.**

**HUMPHREYS J:**

**_Introduction_**

**[[1] In these applications for judicial review, the Applicants seek to challenge certain core provisions of the Illegal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)**
_[Migration Act 2023 ('IMA') on two discrete bases:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_

i That the statutory provisions are incompatible with art 2 of the Ireland/Northern Ireland Protocol or Windsor
[Framework ('WF'), as implemented by s 7A of the European Union (Withdrawal) Act 2018; and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5Y3G-5FB3-GXFD-82P9-00000-00&context=1519360)

ii That the same provisions are incompatible with arts 3, 4, 5, 6 and/or 8 of the European Convention on Human
[Rights ('ECHR') and s 4 of the Human Rights Act 1998 ('HRA').](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0T1-00000-00&context=1519360)

**[2] The first applicant is the Northern Ireland Human Rights Commission ('NIHRC'), a body corporate established**
[under s 68 of the Northern Ireland Act 1998 ('NIA') and which is mandated by s 69(1) of the NIA to:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y0Y4-00000-00&context=1519360)

“keep under review the adequacy and effectiveness in Northern Ireland of law and practice relating to the
protection of human rights”

**[3] The NIHRC is empowered, by s 69(5) of the NIA, to bring proceedings involving law or practice relating to the**
protection of human rights.

**[[4] By amendments to the NIA introduced by the European Union (Withdrawal Agreement) Act 2020, the NIHRC is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5Y26-JS33-CGXG-0486-00000-00&context=1519360)**
obliged to monitor the implementation of art 2(1) of the Protocol on Ireland/Northern Ireland in the EU withdrawal
agreement (“rights of individuals”). By s 78C of the NIA it is given the right to:

“(a) bring judicial review proceedings in respect of an alleged breach (or potential future breach) of Article 2(1)
of the Protocol on Ireland/Northern Ireland in the EU withdrawal agreement;


-----

(b) intervene in legal proceedings, whether for judicial review or otherwise, in so far as they relate to an alleged
breach (or potential future breach) of Article 2(1).”

**[5] The second applicant is a 16 year old asylum seeker from Iran, born on 5 July 2007, who arrived in the United**
Kingdom as an unaccompanied child. He had travelled from France by small boat and claimed asylum on 26 July
2023, which application is not yet determined. He is currently residing in Northern Ireland and makes the case that
he would be killed or sent to prison if returned to Iran.

**[6] In my judgment on leave,** _[[2024] NIKB 7, I held that JR295 enjoyed the requisite standing to bring these](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6BCP-J5D3-RV63-826D-00000-00&context=1519360)_
proceedings and also, if necessary, potential victim status under s 7 of the HRA (see paras [55] – [63]).

**[7] The Respondents are the Secretary of State for Northern Ireland ('SoSNI') and the Secretary of State for the**
Home Department ('SSHD').

**_The Windsor Framework_**

**[8] As a result of a Joint Declaration made by the UK and EU on 24 March 2023, the Protocol on Ireland/Northern**
Ireland is now known as the Windsor Framework ('WF').

**[9] Article 2(1) of the Windsor Framework provides:**

**“Right of individuals**

(1) The United Kingdom shall ensure that no diminution of rights, safeguards or equality of opportunity, as set
out in that part of the 1998 Agreement entitled Rights, Safeguards and Equality of Opportunity results from its
withdrawal from the Union, including in the area of protection against discrimination, as enshrined in the
provisions of Union law listed in Annex 1 to this Protocol, and shall implement this paragraph through dedicated
mechanisms.”

**[10] The rights protected by art 2(1) are therefore those set out in the Rights, Safeguards and Equality of**
Opportunity ('RSE') part of the Belfast/Good Friday Agreement ('B-GFA'), including those referred to in Annex 1,
which comprises a list of six Equality Directives, namely:

i Council Directive 2004/11/EC on equal treatment between men and women in access to and supply of goods and
services;

ii Directive 2006/54/EC on equal opportunities between men and women in employment;

iii Council Directive 2000/43/EC on equal treatment between persons of different racial or ethnic origin;

iv Council Directive 2000/78/EC on equal treatment in employment;

v Directive 2010/41/EU on equal treatment between men and women in self-employment;

vi Council Directive 79/7/EEC on equal treatment between men and women in social security.

**[11] In a paper published in 2020 entitled “UK Government Commitment to 'No Diminution of Rights, Safeguards**
and Equality of Opportunity' in Northern Ireland: what does it mean and how will it be implemented?”(“the
Explainer”), the Northern Ireland Office acknowledged that the Annex 1 Directives only represent a subset of the 'no
diminution' commitment and that it extended, non-exhaustively, to other pieces of EU law including the Pregnant
Workers' Directive, the Parental Leave Directive and the Victims Directive.

**[12] The NIHRC and the Equality Commission for Northern Ireland, as part of the dedicated mechanisms**
framework, have published a list of other EU measures which, in their opinion, fall within the scope of the art 2
protection in their document “Working Paper: The Scope of art 2(1) of the Ireland/Northern Ireland Protocol” in
December 2022.


-----

**[13] Article 5 of the WF concerns the movement of goods and 5(4) states:**

“The provisions of Union law listed in Annex 2 to this Protocol shall also apply, under the conditions set out in
that Annex, to and in the United Kingdom in respect of Northern Ireland.”

**[14] Annex 2 sets out an extensive list of EU legal instruments which range across all aspects of trade and**
generally applies the EU's customs code and single market rules to goods to Northern Ireland.

**[15] The Respondents contrast the wording of art 2 and art 5. Article 2 imposes an obligation on the UK to ensure**
no diminution of rights whilst art 5 makes certain provisions of EU law apply in the UK in respect of Northern
Ireland. It is contended that the former imposes an obligation of result and, provided there is no diminution of right, it
is a matter for the state to determine how the relevant standards are to be maintained. In the case of a provision
listed in Annex 2, it simply applies without more.

**[16] By art 13 of the WF:**

“2. Notwithstanding Article 4(4) and (5) of the Withdrawal Agreement, the provisions of this Protocol referring to
Union law or to concepts or provisions thereof shall in their implementation and application be interpreted in
conformity with the relevant case law of the Court of Justice of the European Union.

3. Notwithstanding Article 6(1) of the Withdrawal Agreement, and unless otherwise provided, where this
Protocol makes reference to a Union act, that reference shall be read as referring to that Union act as
amended or replaced.”

**_The Belfast-Good Friday Agreement_**

**[17] The B-GFA is divided into a number of sections and annexed to it is an agreement between the UK**

Government and the Government of Ireland. The B‑GFA begins with a 'Declaration of Support' on behalf of all the

participants in the multi-party talks which resulted in the agreement. It then sets out the Constitutional Issues and
the Strands 1, 2 & 3 institutions.

**[18] The RSE section in the B-GFA recites that the parties affirm:**

“… their commitment to the mutual respect, the civil rights and the religious liberties of everyone in the
community. Against the background of the recent history of communal conflict, the parties affirm in particular:

   - the right of free political thought;

   - the right to freedom and expression of religion;

   - the right to pursue democratically national and political aspirations;

   - the right to seek constitutional change by peaceful and legitimate means;

   - the right to freely choose one's place of residence;

   - the right to equal opportunity in all social and economic activity, regardless of class, creed, disability, gender
or ethnicity;

   - the right to freedom from sectarian harassment; and

   - the right of women to full and equal political participation.”

**[19] It then recites the UK's obligation to complete incorporation of the ECHR into Northern Irish law and the**
establishment of the NIHRC. It also mandates the right to a remedy for breach of the ECHR with direct access to
the courts. The RSE section includes a piece on reconciliation and victims of violence as well as economic, social
and cultural issues.


-----

**[20] The B-GFA then goes on to address decommissioning, security, policing and justice, prisoners and the**
validation, implementation and review of the agreement.

**_The Withdrawal Agreement_**

**[21] The Withdrawal Agreement ('WA'), made between the UK and the EU on the former's exit from the European**
Union provides, at art 4:

“1. The provisions of this Agreement and the provisions of Union law made applicable by this Agreement shall
produce in respect of and in the United Kingdom the same legal effects as those which they produce within the
Union and its Member States.

Accordingly, legal or natural persons shall in particular be able to rely directly on the provisions contained or
referred to in this Agreement which meet the conditions for direct effect under Union law.

2. The United Kingdom shall ensure compliance with paragraph [1], including as regards the required powers
of its judicial and administrative authorities to disapply inconsistent or incompatible domestic provisions,
through domestic primary legislation.

3. The provisions of this Agreement referring to Union law or to concepts or provisions thereof shall be
interpreted and applied in accordance with the methods and general principles of Union law.

4. The provisions of this Agreement referring to Union law or to concepts or provisions thereof shall in their
implementation and application be interpreted in conformity with the relevant case law of the Court of Justice of
the European Union handed down before the end of the transition period …”

**[22] “Union law” is defined by art 2(a) as, including, inter alia:**

“(i) The Treaty on European Union (“TEU”), the Treaty on the Functioning of the European Union (“TFEU”) and
the Treaty establishing the European Atomic Energy Community (“Euratom Treaty”), as amended or
supplemented, as well as the Treaties of Accession and the Charter of Fundamental Rights of the European
Union; and

(ii) The general principles of the Union's law.”

**_[The European Union (Withdrawal) Act 2018](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SNC-4N71-DYCN-C32Y-00000-00&context=1519360)_**

**[[23] By s 7A of the European Union (Withdrawal) Act 2018 (“the Withdrawal Act”):](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5Y3G-5FB3-GXFD-82P9-00000-00&context=1519360)**

“(1) Subsection (2) applies to—

a all such rights, powers, liabilities, obligations and restrictions from time to time created or arising by or under
the withdrawal agreement, and

b all such remedies and procedures from time to time provided for by or under the withdrawal agreement,

as in accordance with the withdrawal agreement are without further enactment to be given legal effect or used
in the United Kingdom.

(2) The rights, powers, liabilities, obligations, restrictions, remedies and procedures concerned are to be—

a recognised and available in domestic law, and

b enforced, allowed and followed accordingly.

(3) Every enactment (including an enactment contained in this Act) is to be read and has effect subject to
subsection (2).”


-----

**_[The Illegal Migration Act 2023](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_**

**[24] Section 1(1) of the IMA sets out its legislative purpose:**

“… to prevent and deter unlawful migration, and in particular migration by unsafe and illegal routes, by requiring
the removal from the United Kingdom of certain persons who enter or arrive in the United Kingdom in breach of
immigration control.”

**[25] The provisions of the IMA under challenge in the NIHRC proceedings are as follows:**

i Section 5(2) relating to admissibility of protection or human rights claims;

ii Section 5(2) and s 54 concerning effective remedy;

iii Sections 2(1), 5(1) and 6 which require removal from the UK in specified cases;

iv Sections 2(1), 5(1) and 6 in relation to the principle of non-refoulement;

v Section 13(4) concerning the court's ability to review detention;

vi Sections 22(2) and 22(3) which require the removal of victims of slavery and/or trafficking in certain
circumstances;

vii Sections 2(1), 5(1) and 6 insofar as they relate to the removal of children and children's claims.

**[26] The JR295 application seeks to impugn the following additional provisions:**

viii Section 4 in relation to unaccompanied children;

ix Sections 16-20 relating to accommodation and support for unaccompanied children; and

x Section 57 concerning age assessments.

**[27] Colton J granted leave to the NIHRC on all grounds on 10 October 2023. I granted leave to JR295 following a**
contested hearing on 12 February 2024, save that the challenge to ss 16-20 of the IMA was stayed in light of
evidence from the Respondents that the UK Government was considering the issue of accommodation and support
afresh following the judgment of the High Court in England & Wales in R (On the Application of ECPAT UK) v Kent
_[County Council & Anor [2023] EWHC 1953 (Admin).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68V6-2PN3-RRK4-00DS-00000-00&context=1519360)_

**[28] The IMA received Royal Assent on 20 July 2023. Certain sections came into force on this date (ss 30-37, 52 &**
63-69). Others came into force solely for the purpose of making regulations (ss 3, 4, 7, 11(2), 11(6), 18, 20, 24, 40,
42, 43 & 60(7)). Otherwise the provisions of the IMA come into force in accordance with regulations made by the
Secretary of State.

**[29] To date, only two sets of regulations have been made. The IMA (Commencement no. 1) Regulations 2023**
provided that a number of provisions came into force on 28 September 2023, namely ss 12, 15, 59, 60, 61 & 62.
The IMA (Commencement no. 2) Regulations 2024 brought s 50 of the IMA (which relates to tribunal procedure
rules in respect of suspensive claims) into force on 1 May 2024. Otherwise the provisions of the IMA are
uncommenced.

**[30] The position of the Respondents is that the government intends to commence the remaining provisions of the**
IMA as soon as possible.

**_The applicants' evidence_**

**[31] The NIHRC application is grounded on evidence from its Chief Commissioner, Alyson Kilpatrick. She deposes**
to a belief that the provisions of the IMA will have a “very serious adverse effect.” On her analysis, the duty to


-----

remove in s 2 will apply to “the vast majority of asylum seekers” and their human rights or international protection
claims rendered inadmissible. Many will be removed from the UK and for those not removed, they may be left in a
form of legal limbo, unable to work or have recourse to public funds.

**[32] Support for these contentions is derived from the report of the United Nations High Commissioner for**
Refugees ('UNHCR') dated 2 May 2023 and a statement dated 18 July 2023. On the available evidence, the
UNHCR concluded that the s 2 conditions would apply to the vast majority of people who had fled their homes to
escape conflict and persecution. In its response to the Joint Committee on Human Rights in September 2023, the
Government stated that it may need to use the regulation making power in s 4 of the IMA to except certain
categories of person from the s 2 duty to remove. No further detail on this possibility has been forthcoming

**[33] In the case of JR295, the court has been referred to evidence given to the Joint Committee on Human Rights**
during the legislative process of the IMA. The Children's Commissioner for England & Wales expressed concerns
that:

i The duty to remove unaccompanied children on turning 18 has the potential to make the task of local authorities
in fulfilling their statutory duties to such children more difficult;

ii It will be significantly more difficult for such children to form relationships, participate in education or feel a sense
of stability;

iii The threat of deportation is likely to drive such children into the arms of people traffickers and abusers.

**[34] When he arrived in the UK, JR295 was told that his claimed age was not accepted as a result of a lack of**
evidence to substantiate it. However, on 13 November 2023, it was confirmed that he had been accepted as a child.

**[35] Sinead Marmion, the solicitor acting for JR295, who has particular specialisation in immigration and asylum**
claims, deposes to the risk of this age assessment changing which can and does happen when new evidence is
received. She also avers that, in her experience, many children have wrongly been treated as adults in the UK
immigration system.

**[36] JR295 himself has sworn two affidavits in which he details his arrival to the UK and how he has settled in**
Belfast. He has enjoyed educational classes and professional training but says that he is terrified of the impact of
the IMA and the risk of removal which it creates.

**_The disapplication of primary legislation_**

**[37] The principle of parliamentary sovereignty remains a fundamental tenet of our constitutional law. As the**
Supreme Court confirmed in R (Miller) v The Prime Minister [2019] UKSC 41:

“laws enacted by the Crown in Parliament are the supreme form of law in our legal system, with which
everyone, including the Government, must comply”

**[38] However, during the period of the UK's membership of the EU, it was recognised that EU law was supreme**
and, in the event of a conflict existing between EU and relevant domestic law, the former would prevail. As Lord
Bridge said in the seminal case of R (Factortame) v Secretary of State for Transport [1991] 1 AC 603:

“Under the terms of the Act of 1972 it has always been clear that it was the duty of a United Kingdom court,
when delivering final judgment, to override any rule of national law found to be in conflict with any directly
enforceable rule of Community law. Similarly, when decisions of the European Court of Justice have exposed
areas of United Kingdom statute law which failed to implement Council directives, Parliament has always
loyally accepted the obligation to make appropriate and prompt amendments. Thus, there is nothing in any way
novel in according supremacy to rules of Community law in those areas to which they apply and to insist that,
in the protection of rights under Community law, national courts must not be inhibited by rules of national law
from granting interim relief in appropriate cases is no more than a logical recognition of that supremacy.”


-----

**[39] A piece of national law found to be inconsistent with directly enforceable EU law would therefore be**
'disapplied' in the sense that it would remain on the statute book but have no legal effect. In the event that the
relevant provision of EU law was repealed then the previously offending domestic provision would take effect.

**[40] Of course, as is illustrated by the Withdrawal Act itself, Parliament remained sovereign since it could legislate**
[for the repeal of the European Communities Act 1972 ('the 1972 Act') and thereby bring the era of supremacy of EU](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVT0-TWPY-Y0DD-00000-00&context=1519360)
law to an end.

**[41] In that context, Lord Steyn had mused in R (Jackson) v Attorney General** _[2005] UKHL 56 that if parliament_
sought to abolish access to judicial review:

“… Supreme Court may have to consider whether this is constitutional fundamental which even a sovereign
Parliament acting at the behest of a complaisant House of Commons cannot abolish” (para [102])

**[42] Lord Hope echoed this in AXA v Lord Advocate** _[2011] UKSC 46:_

“The question whether the principle of the sovereignty of the UK Parliament is absolute or may be subject to
limitation in exceptional circumstances is still under discussion … The rule of law requires that the judges must
retain the power to insist that legislation of that extreme kind is not law which the courts will recognise.” (paras

[50] & [51])

**[43] More recently, in** _R (Privacy International) v Investigatory Powers Tribunal [2019] UKSC 22 Lord Carnwath_
considered:

“I see a strong case for holding that, consistently with the rule of law, binding effect cannot be given to a clause
which purports wholly to exclude the supervisory jurisdiction of the High Court to review a decision of an inferior
court or tribunal, whether for excess or abuse of jurisdiction, or error of law.” (para [144])

**[44] These judicial views are all properly recognised as obiter dicta and have been the subject of both academic**
and judicial criticism. Most notably, the contention that parliament cannot legislate contrary to the rule of law was
emphatically rejected by Lord Bingham in his distinguished text on that subject. In _Re Dillon's Application_ [2024]
NIKB 11 Colton J rejected the Applicants' case that a court could declare the provisions of primary legislation
unlawful on the basis that it is contrary to the rule of law and therefore unconstitutional. This is not surprising given
that there is no instance of a judge in the UK taking such a step. Equally, the Applicants in the instant case do not
make such an ambitious claim. These constitutional principles do however provide the backcloth to the primary
submission of the Applicants that the relevant provisions of the IMA ought to be disapplied.

**_Disapplication and the Windsor Framework_**

**[45] Article 2 of the WF, and its interaction with the RSE provisions of the B-GFA, the WA and s 7A of the**
Withdrawal Act, were the subject of detailed analysis by Colton J in Re Dillon, at paras [520] et seq.

**[46] Whilst I am not bound by this decision as a matter of precedent, the principle of judicial comity requires that, in**
order to depart from the decision, I would need to be persuaded that it is 'plainly wrong' or 'clearly incorrect' (see my
[observations in Re Mooreland and Owenvarragh Residents' Association [2022] NIQB 40 at paras [42] to [44]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65NX-TRT3-GXF6-8348-00000-00&context=1519360)

**[47] The Respondents argue that in Dillon Colton J failed to address a key part of their argument, namely that there**
is a qualitative difference between the rights safeguarded by art 2 and those 'trade' laws made applicable by art 5.
On this analysis the directives in Annex 1 to the WF are not “made applicable” within the meaning of art 4(1) of the
WA by contrast to those laws contained in annex 2. The Respondents contend that there is a significant distinction
between the art 2(1) obligation to ensure no diminution as compared to the art 5(4) wording “shall also apply.”

**[48] The position of the UK Government is reflected in its Explainer document:**


-----

“In the extremely unlikely event that such a diminution occurs, the UK Government will be legally obliged to
ensure that the holders of the relevant rights are able to bring challenges before the domestic courts and,
should their challenges be upheld, that appropriate remedies are available” (para [6])

**[49] As such, it is argued that this is an obligation of result: the RSE elements of the B-GFA are not made**
applicable but rather set a benchmark by which rights can be measured and no diminution ensured.

**[50] The answer to this is to be found in the wording of the WA and the Withdrawal Act. Section 7A of the latter has**
a direct predecessor in s 2 of the 1972 Act. This recognised three ways in which EU law could take effect in the UK:

i The rights and duties created by the Treaties were directly applicable;

ii EU regulations were directly applicable (by virtue of TFEU art 288); and

iii Domestic legislation gave effect to EU law, in the form of directives, which were not themselves directly
applicable, but which could have direct effect.

**[51] The doctrine of direct effect of directives derives from the seminal case of Van Gend en Loos [1963] ECR 1.**
As developed, it means that, provided the terms of a directive are sufficiently clear and precise, they could be
invoked by citizens in the national courts in actions against the state where there had been a failure to implement
the particular directive properly or in time.

**[52] In** _Marks and Spencer plc v Customs and Excise Commissioners_ [2003] QB 866, the ECJ extended the
doctrine to cases where even though the directive had been correctly implemented, the national measures were not
being applied in such a way as to achieve the result sought by the directive. It was held therefore that not only must
the directive be correctly transposed into national law, the domestic legislation must be applied in conformity with
the directive.

**[53] Section 7A mirrors the language of s 2 of the 1972 Act in that “all rights, powers, liabilities, obligations and**
restrictions from time to time created or arising by or under the WA” are given legal effect without further enactment.
It is, in the language of R (Miller) v Secretary of State for Exiting the European Union [2017] UKSC 5 and Dillon the
“conduit pipe” through which the WA provisions flow into UK domestic law.

**[54] By art 4 of the WA, its provisions and those of EU law “made applicable” by the Agreement shall produce in**
the UK the same legal effects as those which they produce in EU Member States. Furthermore, legal or natural
persons will be able to rely directly on the provisions contained in or referred to in the WA (including the WF) “which
meet the conditions for direct effect under Union law.”

**[55] Article 4(1) therefore differentiates between two types of measure:**

i The provisions of the WA; and

ii The provisions of EU law made applicable by the WA.

**[56] The rights referred to in art 2(1) and Annex 1 fall within the first category – they are provisions of the WA. The**
art 5 and Annex 2 provisions represent EU law made applicable by the WA. In each case, there is imposed what
the Court of Appeal in England & Wales described in SSWP v AT [2023] EWCA Civ 1307 as:

“a duty of reciprocal and identical effect which is intended to ensure that UK citizens and EU citizens working
and residing in the EU and UK respectively are treated in the same way.” (para [106])

**[57] Furthermore, by art 4(2), the UK is obliged to ensure compliance with art 4(1), including by giving judicial**
authorities the power through domestic primary legislation to disapply inconsistent or incompatible provisions. The
domestic primary legislation takes the form of s 7A of the Withdrawal Act. As a result, _Factortame_ is still in play
since the rights and obligations under the WA must prevail over any inconsistent domestic law.


-----

**[[58] In Dillon Colton J revisited his previous decision in Re Angesom's Application [2023] NIKB 102 and held that,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69VK-2HX3-SBM4-70DY-00000-00&context=1519360)**
contrary to what he had previously found, the EU Reception Conditions Directive did have direct effect since, in line
with Marks and Spencer, the directive had been implemented but the national measures were not being applied in
such a way as to achieve the results sought.

**[59] In G v G [2021] UKSC 9, Lord Stephens, referring to the Qualification Directive and the Procedures Directive**
commented:

“The Secretary of State accepts, for the purposes of this appeal, and I agree, that the relevant provisions of the
Directives are directly effective …” (para [84])

**[60] The rights relied upon by the Applicants arising from the EU Directives were clear and precise and therefore**
had direct effect on 31 December 2020. The Dublin III Regulation was directly applicable.

**[61] More contentious is the question of the status of the CFR. Article 51 of the CFR states:**

“(1) The provisions of this Charter are addressed to the institutions and bodies of the Union with due regard for
the principle of subsidiarity and to the Member States only when they are implementing Union law. They shall
therefore respect the rights, observe the principles and promote the application thereof in accordance with their
respective powers.

(2) This Charter does not establish any new power or task for the Community or the Union, or modify powers
and tasks defined by the Treaties.”

**[62] Article 52 goes on to say that insofar as rights under the CFR correspond to rights guaranteed by the ECHR,**
the meaning and scope of those rights shall be the same as those laid down by the ECHR.

**[63] In** _Rugby Football Union v Consolidated Information Services Ltd_ _[2012] UKSC 55 at para [28] Lord Kerr_
analysed the legal impact of the CFR:

“26. The European Charter was proclaimed by the European Parliament, Council and Commission at Nice in
December 2000. Its purpose was expressed to be the assembly in a single instrument of those fundamental
rights which European Union law had previously identified in legislation or in decisions of the CJEU. In its initial
incarnation the Charter had persuasive value: the CJEU referred to and was guided by it (see, for instance,
_Promusicae at paras [61]-[70])._

27. The Charter was given direct effect by the adoption of the Lisbon Treaty in December 2009 and the
consequential changes to the founding treaties of the EU which then occurred. Article 6(1) of the Treaty on
European Union (TEU) now provides: “The Union recognises the rights, freedoms and principles set out in the
Charter of Fundamental Rights of the European Union of 7 December 2000, as adapted at Strasbourg, on 12
December 2007, which shall have the same legal value as the Treaties. The provisions of the Charter shall not
extend in any way the competences of the Union as defined in the Treaties. The rights, freedoms and
principles in the Charter shall be interpreted in accordance with the general provisions in Title VII of the Charter
governing its interpretation and application and with due regard to the explanations referred to in the Charter,
that set out the sources of those provisions.

28. Although the Charter thus has direct effect in national law, it only binds member states when they are
implementing EU law - article 51(1). But the rubric, “implementing EU law” is to be interpreted broadly and, in
effect, means whenever a member state is acting “within the material scope of EU law.”“

**[64] Section 5(4) of the Withdrawal Act provides that the CFR is “not part of domestic law” after 31 December**
2020. However, that provision is itself subject to the strictures of s 7A. In _AT_ the Court of Appeal in England &
Wales held that the CFR is brought into the WA through the definition of 'Union law' and that it was one of the
provisions of EU law “made applicable” by the WA (see para [82]).


-----

**[65] By virtue of these provisions, the CFR continues to have effect in UK law in circumstances where 'Union law'**
continues to be implemented.

**[66] By art 13(3) of the WF, the provisions in the WA whereby EU law no longer has effect at the conclusion of the**
transition period do not apply to the WF. As a result, any amendment or replacement of the specific annex 1
directives takes effect in place of the amended or replaced directive. By art 13(2), the interpretation of the general
prohibition on non-diminution must be in conformity with the caselaw of the Court of Justice of the European Union
('CJEU'). By these means, full dynamic alignment with EU law is maintained, and the Northern Ireland courts will be
obliged to interpret these rights accordingly.

**[67] Article 2 of the WF is an unusual provision in that it seeks to incorporate into law a chapter of the B-GFA which**
was never intended to create binding legal rights and obligations. It was the product of lengthy negotiations
between political parties, the UK and Irish Governments, and contains statements of aspiration as well as legal
right. A document renowned for its 'constructive ambiguity' does not lend itself easily to the tenets of statutory
construction.

**[68] The starting point of the analysis is that the RSE provisions contain a specific commitment to the “civil rights …**
of everyone in the community”, which must extend to asylum seekers as well as UK or Irish citizens (see Colton J in
_[Re Angesom's Application [2023] NIKB 102 at paras [107] and [108]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69VK-2HX3-SBM4-70DY-00000-00&context=1519360)_

**[69] The argument advanced by the Respondents that the RSE referenced in the B‑GFA are limited to those which**

relate to the healing of sectarian division in Northern Ireland through reconciliation did not find favour with Colton J
in either _Angesom_ or _Dillon. Whilst it is true to say that the B-GFA did not expressly reference immigration or_
asylum, there is no basis to exclude such individuals from the wide compass of “everyone in the community.”

**[70] Reading the B-GFA as a whole, it is apparent that its provisions and protections were broad in scope. As part**
of it, the UK Government undertook to incorporate the full sweep of ECHR rights into the law of Northern Ireland
and make them directly enforceable in the courts. In _Dillon_ Colton J held that the concept of “civil rights”
encompasses “the political, social and economic rights which are recognised as the entitlement of every member of
a community, and which can be upheld by appeal to the law.” (para [543]). By this measure, the rights of asylum
seekers must come within the definition. In arriving at this conclusion, I have not found it necessary to engage with
the “generous and purposive approach” advocated by the Vienna Convention on the Law of Treaties but have relied
on a first principles approach to the interpretation of the document.

**[71] The fact that the directives confer individual rights is clear from the wording of the instruments themselves and**
this was confirmed by the High Court in England & Wales in AD v Home Office [2015] EWHC 663 (QB).

**[72] Indeed, the Supreme Court has recognised that the reliance on the provisions of EU asylum directives**
constitutes the exercise of a right – see Lord Stephens in G v G [2021] UKSC 9:

“asylum applicants are able to rely upon the right within article 7 of the Procedures Directive to be allowed to
reside in the UK during the pendency of their application on the basis of the Marleasing principle. It is a right
arising from a Directive which has been recognised by our courts, so the position has not been changed by the
United Kingdom's exit from the EU.” (para [133])

**_Diminution of Rights, Safeguards or Equality of Opportunity_**

**[73] The Court of Appeal in** _Re SPUC Pro Life Limited's Application_ _[[2023] NICA 35 concluded that in order to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68DN-TG23-RVCG-X2Y3-00000-00&context=1519360)_
establish a breach of art 2 of the WF, it is necessary to show:

i A right (or equality of opportunity protection) included in the relevant part of the Belfast/Good Friday 1998
Agreement is engaged;

ii That right was given effect (in whole or in part) in Northern Ireland, on or before 31 December 2020;


-----

iii That Northern Ireland law was underpinned by EU law;

iv That underpinning has been removed, in whole or in part, following withdrawal from the EU;

v This has resulted in a diminution in enjoyment of this right; and

vi This diminution would not have occurred had the UK remained in the EU. (para [54])

**[74] There is no issue in this case (unlike** _SPUC) in relation to EU competence in the area of asylum and_
immigration – see arts 4(2)(j), 78 and 79 of TFEU. In this field, the Applicants rely on the following as relevant Union
law:

i Council Directive 2005/85/EC on minimum standards on procedures in member states for granting and
withdrawing refugee status ('the Procedures Directive');

ii Council Directive 2004/83/EC on the minimum standards for the qualification and status of third country nationals
or stateless persons as refugees who otherwise need international protection and the content of the protection
granted ('the Qualification Directive');

iii Council Directive 2011/36/EU on preventing and combating trafficking in human beings and protecting its victims
('the Trafficking Directive');

iv Regulation (EU) 604/2013 establishing the criteria and mechanisms for determining the member state
responsible for examining an application for international protection lodged in one of the member states by a third
country national or stateless person (recast) ('the Dublin III Regulation'); and

v The Charter of Fundamental Rights of the European Union ('the CFR').

**[75] In relation to each of the nine areas, it is necessary therefore to analyse:**

i The rights created by and enjoyed under the relevant EU law;

ii The statutory provisions of the IMA; and

iii Whether the latter has caused (or will cause when commenced) a diminution in the rights enjoyed.

**_(1) Effective examination and grant of asylum claims_**

**[76] This aspect of the challenge concerns the effect of s 5(2) of the IMA and its impact on the right to the effective**
examination of a claim for asylum, and a grant of international protection to a person who is eligible.

**_(a) The EU Law Rights_**

**[77] Recital (13) to the Procedures Directive states:**

“every applicant should, subject to certain exceptions, have an effective access to procedures, the opportunity
to cooperate and properly communicate with the competent authorities so as to present the relevant facts of
his/her case and sufficient procedural guarantees to pursue his/her case throughout all stages of the
procedure.”

**[78] Recital (22) states:**

“Member States should examine all applications on the substance, i.e. assess whether the applicant in
question qualifies as a refugee in accordance with” the Qualification Directive.

**[79] Article 2(a) defines an application for international protection as meaning either refugee or subsidiary**
protection status. In this context, 'asylum' and 'international protection' are synonymous.


-----

**[80] By art 8(2):**

“Member States shall ensure that decisions by the determining authority on applications for asylum are taken
after an appropriate examination” including the matters in Article 8(2)(a) to (c).

**[81] Article 4(3) of the Qualification Directive states:**

“The assessment of an application for international protection is to be carried out on an individual basis and
includes taking into account: (a) all the relevant facts as they relate to the country of origin …; (b) … whether
the applicant has been or may be subject to persecution or serious harm … (c) the individual position and
personal circumstances of the applicant …; (d) whether the applicant's activities since leaving the country of
origin … will expose the applicant to persecution or serious harm if returned to that country …”

**[82] Article 13 of the Qualification Directive states:**

“Member States shall grant refugee status to a third country national or a stateless person, who qualifies as a
refugee in accordance with Chapters II and III.”

**[83] A 'refugee' is defined in art 2(c), as:**

“a third country national who, owing to a well-founded fear of being persecuted for reasons of race, religion,
nationality, political opinion or membership of a particular social group, is outside the country of nationality and
is unable or, owing to such fear, is unwilling to avail himself or herself of the protection of that country, or a
stateless person, who, being outside of the country of former habitual residence for the same reasons as
mentioned above, is unable or, owing to such fear, unwilling to return to it, and to whom Article 12 does not
apply”

**[84] Article 18 of the Qualification Directive states:**

“Member States shall grant subsidiary protection status to a third country national or a stateless person eligible
for subsidiary protection in accordance with Chapters II and V.”

**[85] Article 2(e) defines “person eligible for subsidiary protection” as:**

“… a third country national or a stateless person who does not qualify as a refugee but in respect of whom
substantial grounds have been shown for believing that the person concerned, if returned to his or her country
of origin, or in the case of a stateless person, to his or her country of former habitual residence, would face a
real risk of suffering serious harm as defined in Article 15, and to whom Article 17(1) and (2) do not apply, and
is unable, or, owing to such risk, unwilling to avail himself or herself of the protection of that country”

**[86] There are limited exceptions to some of the Union law requirements identified above. Articles 25-27 of the**
Procedures Directive provide for applications to be inadmissible when:

“(i) Another member state has granted refugee status;

(ii) A country which is not a member state is considered as a first country of asylum for the applicant; and

(iii) A country which is not a member state is considered as a safe third country for the applicant, subject to a
connection between that person and the third country on the basis of which it would be reasonable for that
person to go to that country.”

**_[IMA 2023 provisions](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_**

**[87] Section 2 of the IMA provides:**

“(1) The Secretary of State must make arrangements for the removal of a person from the United Kingdom if
the person meets the following four conditions.


-----

(2) The first condition is that—

a the person requires leave to enter the United Kingdom, but has entered the United Kingdom—

i without leave to enter, or

ii with leave to enter that was obtained by means which included deception by any person,

b the person has entered the United Kingdom in breach of a deportation order,

c the person has entered or arrived in the United Kingdom at a time when they were an excluded person within
the meaning of _[section 8B of the Immigration Act 1971 (persons excluded from the United Kingdom under](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y16T-00000-00&context=1519360)_
certain instruments) and—

i subsection (5A) of that section (exceptions to section 8B) does not apply to the person, and

[ii an exception created under, or direction given by virtue of, section 15(4) of the Sanctions and Anti-Money](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SFC-WRR1-DYCN-C029-00000-00&context=1519360)
Laundering Act 2018 (power to create exceptions to section 8B) does not apply to the person,

d the person requires entry clearance under the immigration rules, but has arrived in the United Kingdom
without a valid entry clearance, or

e the person is required under immigration rules not to travel to the United Kingdom without an electronic
travel authorisation that is valid for that person's journey to the United Kingdom, but has arrived in the United
Kingdom without such an electronic travel authorisation.

(3) The second condition is that the person entered or arrived in the United Kingdom as mentioned in
subsection (2) on or after the day on which this Act is passed.

(4) The third condition is that, in entering or arriving as mentioned in subsection (2), the person did not come
directly to the United Kingdom from a country in which the person's life and liberty were threatened by reason
of their race, religion, nationality, membership of a particular social group or political opinion.

(5) For the purposes of subsection (4) a person is not to be taken to have come directly to the United Kingdom
from a country in which their life and liberty were threatened as mentioned in that subsection if, in coming from
such a country, they passed through or stopped in another country outside the United Kingdom where their life
and liberty were not so threatened.

(6) The fourth condition is that the person requires leave to enter or remain in the United Kingdom but does not
have it.”

**[88] By s 2(11), the duty does not apply when s 4(1) applies to the person, namely when the person is an**
unaccompanied child. In such a case the duty to remove is replaced by a power to do so under s 4(2):

“(3) The power in subsection (2) may be exercised only—

a where the person is to be removed for the purposes of reunion with the person's parent;

[b where the person is to be removed to a country listed in section 80AA(1) of the Nationality, Immigration and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68V7-5YY3-RVJR-T1YX-00000-00&context=1519360)
Asylum Act 2002 (safe States for the purposes of section 80A of that Act) which is—

i a country of which the person is a national, or

ii a country in which the person has obtained a passport or other document of identity;

c where the person has not made a protection claim or a human rights claim and the person is to be removed
to—


-----

i a country of which the person is a national,

ii a country or territory in which the person has obtained a passport or other document of identity, or

iii a country or territory in which the person embarked for the United Kingdom;

d in such other circumstances as may be specified in regulations made by the Secretary of State.”

**[89] Thus, in the case of an unaccompanied child, he or she may be removed from the UK in certain circumstances**
and, in any event, will be subject to the s 2 duty to remove once majority is attained.

**[90] Section 5 provides:**

“(1) The duty in section 2(1) or the power in section 4(2) applies in relation to a person who meets the four
conditions in section 2 regardless of whether—

a the person makes a protection claim,

b the person makes a human rights claim,

c the person claims to be a victim of slavery or a victim of human trafficking as defined by regulations made by
[the Secretary of State under section 69 of the Nationality and Borders Act 2022, or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KR-00000-00&context=1519360)

d the person makes an application for judicial review in relation to their removal from the United Kingdom
under this Act.

(2) If a person who meets the four conditions in section 2 makes a protection claim, or a human rights claim
within subsection (6), the Secretary of State must declare the claim inadmissible (and see section 41(4) in
relation to human rights claims not within subsection (6)).

(3) A protection claim or a human rights claim declared inadmissible under subsection (2) cannot be
considered under the immigration rules.

(4) A declaration under subsection (2) that a protection claim or a human rights claim is inadmissible is not a
[decision to refuse the claim and, accordingly, no right of appeal under section 82(1)(a) or (b) of the Nationality,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-74HS-00000-00&context=1519360)
Immigration and Asylum Act 2002 (appeal against refusal of protection claim or human rights claim) arises.

(5) A human rights claim is within this subsection if it is a claim that removal of a person from the United
Kingdom to—

a a country of which the person is a national, or

b a country or territory in which the person has obtained a passport or other document of identity,

would be unlawful under _[section 6 of the Human Rights Act 1998 (public authority not to act contrary to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)_
Convention).

(6) In this Act “application for judicial review” means—

a in England and Wales and Northern Ireland, an application to the High Court for judicial review,

b in Scotland, an application to the supervisory jurisdiction of the Court of Session, and

c any other application to a court or tribunal which is required by an enactment to be determined by applying
the principles that would be applied by a court on an application within paragraph (a) or (b).

(7) In this section, references to a claim include a claim—


-----

a that was made on or after the day on which this Act is passed, and

b that has not been decided by the Secretary of State on the date on which this section comes into force.”

**[91] Thus, in the case of an asylum claim advanced after 20 July 2023, and not decided by the SSHD prior to s 5**
coming into force, and where the s 2 conditions apply, the SSHD is obliged to by s 5(2) to declare such an
application inadmissible.

**[92]** _[Section 2(2)-(6) IMA 2023 sets out four conditions:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31N-00000-00&context=1519360)_

i The person arrived in the UK irregularly;

ii The date of arrival was after 20 July 2023;

iii The person did not come directly to the UK from a country in which their life and liberty were threatened; and

iv The person requires leave to remain in the UK but does not have it.

**[93] When these conditions are satisfied, the IMA provides that any protection claim or human rights claim must be**
declared inadmissible by the SSHD, without any assessment being carried out.

**[[94] A 'protection claim' is defined by s 82(2) of the Nationality, Immigration and Asylum Act 2002 ('the NIAA 2002')](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-74HS-00000-00&context=1519360)**
as a claim made that removal from the UK would breach the UK's obligations under the Refugee Convention or
those in relation to persons eligible for a grant of humanitarian protection.

**[[95] A 'human rights claim' is defined by s 113(1) of the NIAA 2002 as:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-73KF-00000-00&context=1519360)**

“a claim made to the Secretary of State … that to remove the person from or require him to leave the United
Kingdom or to refuse him entry into the United Kingdom would be unlawful under _[section 6 of the Human](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)_
Rights Act 1998”

**[96] Sections 38 – 43 of the IMA permit a person to make a “removal conditions suspensive claim”, or a “serious**
harm suspensive claim.” Section 39(3), in relation to the latter, requires the person to provide “compelling evidence”
that the person would, before the end of “the relevant period”, face a “real, imminent and foreseeable risk of serious
and irreversible harm if removed” to the country specified in the removal notice. A serious harm suspensive claim
applies only to third country removals, not to removal to the country of origin.

**[97] The “relevant period” is defined by s 39(9) as being “the total period of time it would take for [the person] to**
make a human rights claim in relation to [the person's] removal … for the claim to be decided by the Secretary of
State, and for any application for judicial review” of that decision to be exhausted. That period will in a number of
cases be short, particularly for a country of origin human rights claim, which is automatically inadmissible.

**[98] By s 47(2), if the suspensive claim is upheld, the person may not be removed from the UK under the IMA to**
the country specified in the removal notice. However, a suspensive claim does not lead to a grant of refugee or
subsidiary protection status, nor does it provide for the rights and protections which must be granted to a refugee or
a person eligible for subsidiary protection, such as access to education, employment, housing, health care and
social security.

**_Diminution_**

**[99] Section 5(2) IMA, alongside the other provisions in the section above, leads to a diminution of rights for the**
following reasons:

i There will not be the “appropriate examination” of the substance of the application for asylum as required by art
8(2) of the Procedures Directive, and art 4(3) of the Qualification Directive.


-----

ii The UK will not grant refugee status or subsidiary protection to a person who qualifies for it, which is inconsistent
with arts 13 and 18 of the Qualification Directive.

**[100] This flows from the fact that, under s 5(2) of the IMA, when the s 2 conditions are met, a protection claim**
(which is a claim to be a refugee, or a claim for subsidiary protection) must be declared inadmissible.

**[101] The remaining claims which can be made under the IMA do not provide for the grant of refugee or subsidiary**
protection status, or for the rights that are contingent on the grant of that status, or for an equivalent remedy. Nor do
they provide for the proper and individual assessment and determination of asylum applications as required by EU
Law.

**[102] A country of origin human rights claim must be declared inadmissible where the s 2 conditions apply by virtue**
of s 5(2) IMA. While a third country human rights claim is admissible, a successful claim does not require the SSHD
to grant refugee or subsidiary protection status or the rights in the Qualification Directive that are contingent on it.
Moreover, a third country human rights claim does not suspend removal. In such circumstances, an individual will
be obliged to pursue his or her claim from another country. In the opinion of the UNHCR such “out of country
remedies are generally ineffective in practice” (report of 2 May 2023).

**[103] A successful suspensive claim only serves to disapply the duty to remove; it does not lead to a grant of**
international protection status, nor the rights contingent on it.

**[104] Furthermore, a serious harm suspensive claim applies only to third country removals. It will not be granted on**
the sole basis that the person is at risk of harm in their own country.

**[105] A serious harm suspensive claim provides for an elevated and more difficult threshold than the test for**
refugee status or subsidiary protection in the Qualification Directive. In particular:

a The “real, imminent and foreseeable risk” test applies a higher threshold than that set out in the directives which
does not require any risk to be 'imminent';

b For a serious harm suspensive claim, the risk must arise during the 'relevant period', which will often be short. If
the risk arises after the relevant period has expired, then no such claim can be made;

c In a suspensive claim, an applicant must prove the risk arises in the country in the removal notice, rather than in
the country of origin. EU Law requires that refugee status (or subsidiary protection) should be granted where there
is a relevant risk in the country of origin (see arts 4, 13 and 18 of the Qualification Directive);

d The Applicant must provide “compelling evidence” that the serious harm suspensive claim is met; whereas there
is no such requirement for an application in EU Law. The NIHRC evidence details the problems faced by asylum
seekers generally in finding lawyers and in overcoming the considerable challenges posed by unfamiliar
environments, often with a backdrop of psychiatric problems caused by recent experience. These issues will make
the provision of “compelling evidence” to ground a serious harm suspensive claim significantly difficult;

e Section 42(7) of the IMA requires that a serious harm suspensive claim must be made within eight days of the
person being given a removal notice unless: (i) before the end of the eight day period or a further four day period,
the SSHD decides it is appropriate to extend the period (s 42(6)); or (ii) if a suspensive claim is made after the eight
day period, the SSHD considers there were compelling reasons for the person not to make the claim within eight
days: s 46(2). The evidence again sets out the formidable challenges an applicant would face in gathering materials
within this time scale for an effective application;

f There are procedural requirements in Chapter II of the Procedures Directive for asylum applications which include
the making available of certain information from the UNHCR under art 8(2)(b); access to an interpreter and
communication with the UNHCR under art 10(1)(c); and effective consultation with legal representative pursuant to
arts 15 & 16;


-----

g The inability to demonstrate “compelling reasons” to extend time will mean that otherwise meritorious serious
harm suspensive claims are rejected as being out of time.

**[106] Section 5(2) of the IMA requires all applications for asylum to be declared inadmissible whilst arts 25-27 of**
the Procedures Directive apply only to a limited cadre of cases.

**[107] Furthermore, there will be a category of asylum applications declared inadmissible under s 5(2), but where**
the individual cannot be removed under s 6 and this will leave the individual in 'limbo.' They cannot be removed
consistently with arts 25-27, but they will not be granted international protection or equivalent protection. Further,
there will be a category of asylum seekers who will be removed pursuant to s 6 of the IMA, but where that is not
permitted by arts 25-27. It is accepted by the Respondents that s 5(2), if and when it comes into force, would result
in a diminution of rights in a category of cases.

**[108] For these reasons, there is a diminution of rights as a result of the enactment of the IMA.**

**_(2) Lack of effective remedy_**

**_The EU Law Right_**

**[109] Article 39(1) of the Procedures Directive imposes an obligation on Member States to ensure that asylum**
applicants have the right to an effective remedy before a court or tribunal in respect of any decision taken on their
application, including a determination that an application is inadmissible. Article 47 of the CFR enshrines a right to
an effective remedy in respect of any violation of the rights contained therein.

**_The IMA Provisions_**

**[110] By virtue of s 5(2) the Secretary of State must declare any protection claim or human rights claim**
inadmissible when the four s 2 conditions are met. Section 5(4) provides that such a declaration of inadmissibility is
[not a decision to refuse the claim and therefore no appeal lies under s 82(1) of the NIAA 2002.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-74HS-00000-00&context=1519360)

**[111] Section 54 of the IMA forbids any court or tribunal from granting an interim remedy which prevents or delays**
the removal of a person from the UK pursuant to a decision to remove for any reason.

**_Diminution_**

**[112] These provisions lead to a diminution of the right enshrined in art 39 since no appeal lies against the**
declaration of inadmissibility.

**[113] Whilst an appeal to the Upper Tribunal is available in respect of a suspensive claim under s 44 of the IMA, a**
serious harm suspensive claim is considerably more limited than an asylum claim for the reasons already set out.
The Appellant must, for the purpose of an appeal, provide compelling evidence, and adhere to the tight timeframes.

**[114] The lack of any power in a court or tribunal to grant interim relief that prevents or delays removal infringes the**
principle laid down by the ECJ in Factortame [1990] 3 CMLR 1:

“It must be added that the full effectiveness of Community law would be just as much impaired if a rule of
national law could prevent a court seised of a dispute governed by Community law from granting interim relief
in order to ensure the full effectiveness of the judgment to be given on the existence of the rights claimed under
Community law. It follows that a court which in those circumstances would grant interim relief, if it were not for
a rule of national law, is obliged to set aside that rule.” (para [21])

**[115] In Abdida [2015] 2 CMLR 15, the Grand Chamber held that when an individual seeks to appeal against an**
order removing him from a Member State when enforcement of this order may expose him to a real risk of serious
and irreversible deterioration in his health, then he must be entitled to an appeal against such an order with
suspensive effect. Section 54 IMA runs contrary to this right to an effective remedy in art 39 of the Procedures
Directive when read with art 47 of the CFR.


-----

**[116] The Respondents accept that, in a category of cases, the IMA, once in force, will diminish the rights enjoyed**
by asylum applicants under art 39 of the directive.

**[117] In respect of this issue, I have concluded that there is a diminution of rights brought about by the enactment**
of the IMA.

**_(3) Removal_**

**_The EU Law Rights_**

**[118] Article 7(1) of the Procedures Directive states:**

“Applicants shall be allowed to remain in the Member State, for the sole purpose of the procedure, until the
determining authority has made a decision in accordance with the procedures at first instance set out in
Chapter III.”

**[119] Chapter III of the Procedures Directive includes art 23, which states that Member States shall process**
applications for asylum in an examination procedure in accordance with the basic principles and guarantees in
Chapter II. Chapter II includes art 8(2) (the duty to determine an application for asylum after an appropriate and
individual examination of it). Chapter III also includes the procedure for considering an application to be
inadmissible: arts 25-27. Article 7(1) prohibits removal prior to the application for asylum either (a) being individually
determined, or (b) being considered inadmissible pursuant to arts 25-27.

**_The IMA Provisions_**

**[120] Section 6 relates to removal:**

“(1) Where the Secretary of State is required by section 2(1) to make arrangements for the removal of a person
from the United Kingdom, the Secretary of State must ensure that the arrangements are made—

a as soon as is reasonably practicable after the person's entry or arrival in the United Kingdom, or

b where the person has ceased to be an unaccompanied child, as soon as is reasonably practicable after the
person has ceased to be an unaccompanied child.

(2) The following provisions of this section apply where—

a the Secretary of State is required by section 2(1) to make arrangements for the removal of a person (“P”)
from the United Kingdom, or

b the Secretary of State may make arrangements for the removal of a person (“P”) from the United Kingdom
under section 4(2).

(3) Subject to section 4(3)(c) (removal of certain unaccompanied children) and to the following provisions of
this section, P may be removed to—

a a country of which P is a national,

b a country or territory in which P has obtained a passport or other document of identity,

c a country or territory in which P embarked for the United Kingdom, or

d a country or territory to which there is reason to believe P will be admitted.

[(4) If P is a national of a country listed in section 80AA(1) of the Nationality, Immigration and Asylum Act 2002](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68V7-5YY3-RVJR-T1YX-00000-00&context=1519360)
(inadmissibility of certain asylum and human rights claims: safe States), or has obtained a passport or other


-----

document of identity in such a country, P may not be removed to a country or territory within subsection (3)(a)
or (b) if—

a P makes a protection claim or a human rights claim, and

b the Secretary of State considers that there are exceptional circumstances which prevent P's removal to that
country or territory.

(5) For the purposes of subsection (4), exceptional circumstances include—

a in a case where P is a national of a country that is a signatory to the Human Rights Convention, or has
obtained a passport or other document of identity in such a country, where that country is derogating from any
of its obligations under the Human Rights Convention in accordance with Article 15 of the Convention;

b in a case where P is a national of a member State, or has obtained a passport or other document of identity
in a member State, where the member State is the subject of a proposal initiated in accordance with the
procedure referred to in Article 7(1) of the Treaty on European Union and—

i the proposal has yet to be determined by the Council of the European Union or (as the case may be) the
European Council,

ii the Council of the European Union has determined, in accordance with Article 7(1), that there is a clear risk
of a serious breach by the member State of the values referred to in Article 2 of the Treaty, or

iii the European Council has determined, in accordance with Article 7(2), the existence of a serious and
persistent breach by the member State of the values referred to in Article 2 of the Treaty.

(6) Subsection (7) applies if—

[a P is a national of a country listed in section 80AA(1) of the Nationality, Immigration and Asylum Act 2002, or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68V7-5YY3-RVJR-T1YX-00000-00&context=1519360)
has obtained a passport or other document of identity in such a country, and

b P makes a protection claim or a human rights claim.

(7) P may be removed to a country or territory within subsection (3)(c) or (d) only if it is listed in Schedule 1.

(8) Subsection (9) applies if—

[a P is not a national of a country listed in section 80AA(1) of the Nationality, Immigration and Asylum Act 2002,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68V7-5YY3-RVJR-T1YX-00000-00&context=1519360)
and has not obtained a passport or other document of identity in such a country, and

b P makes a protection claim or a human rights claim.

(9) P may not be removed to a country or territory within subsection (3)(a) or (b); and P may be removed to a
country or territory within subsection (3)(c) or (d) only if it is listed in Schedule 1.

(10) Where a country or territory is listed in Schedule 1 in respect of a description of person, subsection (7) or
(9) has effect in relation to P and that country or territory only if the Secretary of State is satisfied that P is
within that description.

(11) Where a part of a country or territory is listed in Schedule 1, references to a country or territory in
subsections (7), (9) and (10) have effect in relation to that country or territory as if they were references to that
part.

(12) In this section references to a claim include a claim—

a that was made on or after the day on which this Act is passed, and


-----

b that has not been decided by the Secretary of State on the date on which this section comes into force.

(13) In this Act “the Human Rights Convention” means the Convention for the Protection of Human Rights and
Fundamental Freedoms, agreed by the Council of Europe at Rome on 4 November 1950, as it has effect for
the time being in relation to the United Kingdom.

(14) Where the Secretary of State exercises the power in subsection (2) of _[section 80AA of the Nationality,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68V7-5YY3-RVJR-T1YX-00000-00&context=1519360)_
Immigration and Asylum Act 2002 to amend the list of States in subsection (1) of that section so as to add a
State, subsections (4), (6) and (7) apply to a person who is a national of that State, or who has obtained a
passport or other document of identity in that State, if—

a they have made a protection claim or a human rights claim on or after the day on which this Act is passed,
and

b the claim has not been decided by the Secretary of State on the date on which the amendment comes into
force.”

**[121] Save in the case of unaccompanied children, s 2(1) of the IMA imposes a duty to remove a person when the**
s 2 conditions are met. That removal duty applies regardless of whether:

a the person makes a protection claim;

b the person makes a human rights claim;

c the person claims to be a victim of slavery or a victim of human trafficking; or

d the person makes an application for judicial review in relation to their removal from the United Kingdom under the
IMA.

**[122] By s 6(1), the Secretary of State is required to make arrangements for removal as soon as reasonably**
practicable. The person may be removed to:

a Their country of origin. However, if they make a protection or human rights claim, they may not be removed to
that country if:

[i it is not a 'safe State' listed in s 80AA(1) of the NIAA 2002; or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68V7-5YY3-RVJR-T1YX-00000-00&context=1519360)

ii it is a 'safe State', but the Secretary of State considers there are exceptional circumstances which prevent
removal to that country: s 6(4); or

b A country from which they embarked for the UK or where there is reason to believe they will be admitted.
However, if they make a protection or human rights claim they may be removed to that country only if it is one of the
States named in Sch 1 to the IMA.

**[123] The are 57 states in the Schedule, including Albania, Rwanda, Jamaica, Kenya, Nigeria and Ghana. The**
NIHRC evidence reveals that in 2023 Albania had the highest numbers claiming asylum in the UK, with some 48%
of decisions on Albanian adults' asylum applications positive on an initial decision, and 57% of appeals by Albanian
asylum seekers successful.

**[124] Four of the countries on the list (India, Mongolia, Kosovo and Mauritius) are not signatories to the Refugee**
Convention.

**[125] In R (Brown) v Secretary of State for the Home Department [2015] UKSC 8 the Supreme Court decided that**
the listing of Jamaica as a safe state for the purpose of s 94(4) of the 2002 Act was unlawful because there was a
serious risk of persecution for homosexual people.


-----

**[126] The designation as 'safe' in this context requires adherence to the principle of non-refoulement. In** _AAA v_
_SSHD [2023] UKSC 42 the Supreme Court determined that Rwanda was not a safe country since, on the evidence,_
a real risk of refoulement existed. Section 2(1) of the Safety of Rwanda Act 2024, which is not yet in force, will
require every decision maker to conclusively treat Rwanda as a safe country.

**_Diminution_**

**[127] Sections 2, 5 and 6 of the IMA lead to a diminution of the right in art 7(1) of the Procedures Directive.**

**[128] First and foremost, many people will be removed without their asylum claims being individually determined.**
The asylum claim will automatically be declared inadmissible pursuant to s 5(2), so when the removal duty is
effected the removal will breach art 7(1), subject only to the exceptions in arts 25-27 of the Procedures Directive.

**[129] Secondly, the availability of a serious harm suspensive claim does not cure that problem since it does not**
lead to a grant of refugee status, or the range of rights that are contingent on that status.

**[130] Thirdly, the duty to remove is inconsistent with the exceptions in arts 25‑27 of the Procedures Directive.**

Under art 27(2)(a), for an application to be considered inadmissible on the basis that there is a safe third country,
national legislation must contain rules requiring a connection between the person seeking asylum and the third
country on the basis of which it would be reasonable for that person to go to that country. At para [108] of AAA the
Supreme Court observed:

“It is ASM's case that the MEDP scheme is incompatible with articles 25 and 27 of the Procedures Directive
because it is an application of the “safe third country” concept which is not set out in national legislation and
which does not require a prior connection between the asylum claimant and the third country concerned on the
basis of which it would be reasonable to remove him to that country. The Secretary of State does not dispute
that if the Procedures Directive remains in force in United Kingdom domestic law as retained EU law, the
MEDP scheme as relevant to these appeals is not compatible with articles 25 and 27 of the Directive.”

**[131] A number of the countries listed in Sch 1 do not meet the definition of 'safe third country' in art 27(1). Even**
where a country is lawfully designated generally safe, art 27(2)(c) requires national legislation to contain rules which
allow for individual examination of whether the third country is safe for a particular applicant. The rules must permit
the Applicant to challenge the application of the safe third country concept on the grounds that he or she would be
subjected to torture, cruel, inhuman or degrading treatment or punishment. The IMA does not permit this course to
be taken.

**[132] The availability of a serious harm suspensive claim does not mean that an application will only be**
inadmissible in the circumstances in arts 25-27. For example, it is not available in respect of a country of origin, and
contains a higher threshold than art 27(1), as well as being subject to very tight timescales.

**[133] Again, the Respondents accept that, in a category of case, the IMA, once in force, will result in a diminution**
of right. For the reasons set out, I find that there is such a diminution brought about by these provisions of the IMA.

**_(4) Non-refoulement_**

**_The EU Law Right_**

**[134] Article 21 of the Qualification Directive requires Member States to respect the principle of non-refoulement.**
This is defined in art 33 of the Refugee Convention:

“1. No Contracting State shall expel or return (“refouler”) a refugee in any manner whatsoever to the frontiers of
territories where his life or freedom would be threatened on account of his race, religion, nationality,
membership of a particular social group or political opinion.


-----

2. The benefit of the present provision may not, however, be claimed by a refugee whom there are reasonable
grounds for regarding as a danger to the security of the country in which he is, or who, having been convicted
by a final judgement of a particularly serious crime, constitutes a danger to the community of that country.”

**[135] In AAA, the Supreme Court noted that this right had long been held to extend not only to direct return to the**
country where persecution is feared but also indirect return via a third country. On the facts of that case, there were
substantial grounds for believing that a real risk of refoulement existed at the relevant time.

**_The IMA Provisions_**

**[136] The provisions of the IMA around the duty to remove and serious harm suspensive claims have been**
addressed above.

**_Diminution_**

**[137] For the same reasons as set out in relation to the issue of removal, there is a diminution of the right of non-**
refoulement, notwithstanding the limitations in s 6 of the IMA.

**[138] The availability of a serious harm suspensive claim does not ensure that the principle of non-refoulement is**
respected. A suspensive claim would not be successful on the grounds that the country to which the person is being
removed will fail to determine a substantive asylum application properly and in accordance with the EU rules.
Furthermore, the threshold is higher in that the risk must be 'imminent' as well as being real. The above analysis of
arts 25-27 of the Procedures Directive is equally applicable to the issue of non-refoulement.

**_(5) Detention_**

**_The EU Law Right_**

**[139] Article 18 of the Procedures Directive states:**

“Where an applicant for asylum is held in detention, Member States shall ensure that there is a possibility of
speedy judicial review.”

**_The IMA Provisions_**

**[140] Sections 11 and 12 of the IMA empower an immigration officer to detain an individual who satisfies, or is**
suspected of satisfying, the conditions in s 2 for such period as, in the opinion of the Secretary of State, is
reasonably necessary to enable the decision to be made or directions to be given.

**[141] Section 13 concerns immigration bail and by s 13(4), amendments are made to Sch 10 to the Immigration**
Act 2016:

“3A (1)This paragraph applies in relation to—

a a decision to detain a person under the authority of an immigration officer under paragraph 16(2C) of
_Schedule 2 to the Immigration Act 1971,_

b a decision to detain a person under the authority of the Secretary of State under _[section 62(2A) of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-73D4-00000-00&context=1519360)_
Nationality, Immigration and Asylum Act 2002, and

c where a person is being detained under a provision mentioned in paragraph (a) or (b), a decision of the
Secretary of State to refuse to grant immigration bail to the person.

(2) In relation to detention during the relevant period, the decision is final and is not liable to be questioned or
set aside in any court or tribunal.

(3) In particular—


-----

a the powers of the immigration officer or the Secretary of State (as the case may be) are not to be regarded
as having been exceeded by reason of any error made in reaching the decision;

b the supervisory jurisdiction does not extend to, and no application or petition for judicial review may be made
or brought in relation to, the decision.

(4) Sub-paragraphs (2) and (3) do not apply so far as the decision involves or gives rise to any question as to
whether the immigration officer or the Secretary of State is acting or has acted—

a in bad faith, or

b in such a procedurally defective way as amounts to a fundamental breach of the principles of natural justice.

(5) Sub-paragraphs (2) and (3) do not affect any right of a person to—

a apply for a writ of habeas corpus, or

b in Scotland, apply to the Court of Session for suspension and liberation.

(6) In this paragraph—

“decision” includes any purported decision;

“relevant period” means the period of 28 days beginning with the date on which the person's detention under
the provision mentioned in sub-paragraph (1) began;

“the supervisory jurisdiction” means the supervisory jurisdiction of—

**[142] The effect of these provisions is that a person so detained “must not be granted immigration bail by the First-**
tier Tribunal until after the end of” 28 days from when the detention began.

**[143] Further, a decision to detain for the first 28 days “is final and is not liable to be questioned or set aside in any**
court or tribunal”, per para [3A(2)] to Sch 10, including by way of an application for judicial review. The only
exceptions are if it is claimed that the Secretary of State acted in bad faith or in fundamental breach of the principles
of natural justice; or an application for habeas corpus: para [3A(4)] and [(5)] of Sch 10.

**_Diminution_**

**[144] The Respondents contend that the right in art 18 is confined to persons who are “applicants for asylum” and**
since, by dint of s 5(2) any such claim is rendered inadmissible when the s 2 conditions apply, the person in
question does not fall within that category and there is therefore no diminution of right.

**[145] This simply cannot be correct. Where a person who would have been categorised an applicant for asylum**
under the law as it stood on 31 December 2020 is deprived of the right to make such an application by the IMA, that
must entail a diminution in right. Coupled with that is an inability to seek speedy judicial review of detention, save in
limited and defined circumstances.

**[146] The IMA deprives an individual of the same level of access to a court and to an effective remedy during that**
period. Whilst there may be a debate around the meaning of 'speedy' on the given facts of particular case, there
must nonetheless be diminution in a category of cases.

**_(6) Trafficking_**

**_EU Law Rights_**

**[147] Article 11 of the Trafficking Directive requires the Member State to ensure that assistance and support are**
provided to a victim of trafficking as soon as the competent authorities have a reasonable-grounds indication for


-----

believing that the person might have been subjected to trafficking. Article 11(3) requires that “assistance and
support for a victim are not made conditional on the victim's willingness to cooperate in the criminal investigation …”
The assistance and support required is specified in more detail in art 11(5).

**[148] The Trafficking Directive was intended to give effect to the Council of Europe Convention on Action against**
Trafficking in Human Beings ('ECAT'), which was signed in 2007 and came into force in the UK in 2009. Article 13
of ECAT says:

“Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when there are
reasonable grounds to believe that the person concerned is a victim”

**[149] This is subject to an exception in art 13(3) whereby the parties are not bound to observe this period if public**
order prevents it.

**_IMA Provisions_**

**[150] Section 22 of the IMA relates to modern slavery:**

“(1) Subsection (2) (disapplication of modern slavery provisions) applies in relation to a person if—

a the Secretary of State is required by section 2(1) to make arrangements for the removal of the person from
the United Kingdom, and

b a decision has been made by a competent authority that there are reasonable grounds to believe that the
person is a victim of slavery or human trafficking (a “positive reasonable grounds decision”).

This is subject to subsections (3) to (7).

(2) Where this subsection applies in relation to a person—

[a any prohibition arising under section 61 or 62 of the Nationality and Borders Act 2022 (recovery period) on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KF-00000-00&context=1519360)
removing the person from, or requiring them to leave, the United Kingdom does not apply in relation to the
person, and

b any requirement under section 65 of that Act (leave to remain) to grant the person limited leave to remain in
the United Kingdom does not apply in relation to the person.

(3) Subsection (2) does not apply in relation to a person if—

a the Secretary of State is satisfied that the person is cooperating with a public authority in connection with an
investigation or criminal proceedings in respect of the relevant exploitation,

b the Secretary of State considers that it is necessary for the person to be present in the United Kingdom to
provide that cooperation, and

c the Secretary of State does not consider that the public interest in the person providing that cooperation is
outweighed by any significant risk of serious harm to members of the public which is posed by the person.

(4) In subsection (3)—

a the reference to a person cooperating with a public authority in connection with an investigation or criminal
proceedings is to the person doing so to the extent that is reasonable having regard to the person's
circumstances, and

b “the relevant exploitation” means—

i the conduct or alleged conduct resulting in the positive reasonable grounds decision, and


-----

ii where a positive conclusive grounds decision has also been made in relation to the person, any other
conduct resulting in that decision.

The Secretary of State must assume for the purposes of subsection (3)(b) that it is not necessary for the
person to be present in the United Kingdom to provide the cooperation in question unless the Secretary of
State considers that there are compelling circumstances which require the person to be present in the United
Kingdom for that purpose.

In determining whether there are compelling circumstances as mentioned in subsection (5), the Secretary of
State must have regard to guidance issued by the Secretary of State.

Subsection (2) does not apply in relation to a person (“A”) if subsection (3) applies in relation to a person (“P”)
and—

a A is P's child, or a child living in the same household as P in circumstances where P has care of A, or

b in a case where P is a child—

i A is P's parent, or

ii A lives in the same household as P and has sole responsibility for P.

(8) Subsection (9) applies to a person if—

a the Secretary of State is not required by section 2(1) to make arrangements for the removal of the person
from the United Kingdom,

b the only reason why the Secretary of State is not required to do so is that the person has limited leave to
[remain in the United Kingdom granted under section 65(2) of the Nationality and Borders Act 2022,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KK-00000-00&context=1519360)

c that leave was granted on or after 7 March 2023, and

d subsection (3) or (7) does not apply in relation to the person.

[The Secretary of State may revoke the leave granted to the person under section 65(2) of the Nationality and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KK-00000-00&context=1519360)
Borders Act 2022.

[Subsection (9) is to be treated for the purposes of section 3 of the Immigration Act 1971 as if it were provision](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y09P-00000-00&context=1519360)
made by that Act.

In this section—

“child” means a person who is under the age of 18;

“competent authority” means a person who is a competent authority of the United Kingdom for the purposes of
the Trafficking Convention;

“positive conclusive grounds decision” means a decision made by a competent authority that a person is a
victim of slavery or human trafficking;

[“public authority” means a public authority within the meaning of section 6 of the Human Rights Act 1998;](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)

“the Trafficking Convention” means the Council of Europe Convention on Action against Trafficking in Human
Beings (done at Warsaw on 16 May 2005);

“victim of slavery” and “victim of human trafficking” have the meanings given in regulations made by the
[Secretary of State under section 69 of the Nationality and Borders Act 2022.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KR-00000-00&context=1519360)


-----

**[151] Where the s 2 duty is imposed on the Secretary of State, and there has been a 'positive reasonable grounds**
decision', ie a decision to the effect that there are reasonable grounds to believe a person is a victim of slavery or
trafficking, the s 22(2) disapplies the **_modern slavery provisions of the_** _[Nationality and Borders Act 2022 ('NBA](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_
_[2022').](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_

**[[152] As a result, there is no prohibition on removal during the recovery period, defined by s 61(3) of the NBA 2022](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KF-00000-00&context=1519360)**
as the period from the date of the positive reasonable grounds decision until either the conclusive decision or 30
days, whichever is the later.

**[[153] Equally, the requirement to grant limited leave to remain under s 65(2) of the NBA 2022 does not apply.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KK-00000-00&context=1519360)**

**[154] Furthermore, by s 25(2) of the IMA, where the s 2(1) duty applies, and a reference relating to the person has**
been, or is about to be, made to the competent authority for a reasonable grounds decision, the duty in s 18 of the
Human Trafficking and Exploitation (Criminal Justice and Support for Victims) Act (Northern Ireland) 2015 to
provide assistance and support, is disapplied.

**[155] The statute recognises, in ss 22(3) and 25(3), exceptions to these disapplication measures where the**
Secretary of State considers:

a the person is cooperating with a public authority in connection with an investigation or criminal proceedings in
respect of the relevant trafficking;

b it is necessary for the person to be in the UK to provide that cooperation; and

c the public interest in that person providing that cooperation is not outweighed by the risk of serious harm to
members of the public by that person.

**_Diminution_**

**[156] The Respondents say no diminution of right is caused by the IMA since the s 22 disapplication is consistent**
with the art 13(3) public order exception. However, that exception expressly applies to “this period”, meaning the
recovery and reflection period referred to in art 13(1). There is no basis, as a matter of straightforward construction,
to extend this exception to any other right.

**[157] The provisions of the IMA mean:**

i Where the s 2 conditions are satisfied and a positive reasonable grounds decision has been made, victims of
trafficking will by default be subject to the duty to remove, since by s 5(1)(c) the duty persists and any claim to be a
victim of human trafficking or slavery is to be disregarded even though they have made a trafficking claim;

ii The disapplication of the duty to provide assistance and support by s 25(2) runs contrary to art 11. In _R (K) v_
_Secretary of State for the Home Department [2019] 4 WLR 92, Mostyn J held that a decision taken by the SSHD to_
reduce the level of assistance payments to potential victims of **_modern slavery to the 'destitution' level was_**
unlawful;

iii Article 11(3) prohibits the making of the entitlement to assistance and support conditional on cooperation in a
criminal investigation.

**[158] For these reasons, I find that the relevant provisions of the IMA, once in force, will cause a diminution in right**
enjoyed by victims of slavery or trafficking.

**_(7) Children_**

**_EU Law Rights_**


-----

**[159] Article 20(3) and art 20(5) of the Qualification Directive require states to take into account the best interests**
of children as a primary consideration when implementing that directive. The provisions of the Qualification and
Procedures Directives must be interpreted and applied in accordance with art 24 of the CFR which states that, “in
all actions relating to children … the child's best interests must be a primary consideration.” The directives require
the proper and individual assessment of an application for international protection, and international protection to be
granted to those eligible, prior to removal (subject to arts 25-27 of the Procedures Directive). In performing that
assessment and determining claims for international protection prior to removal, the child's best interests must be a
primary consideration.

**_IMA Provisions_**

**[160] The provisions under challenge are those in s 2 and s 6 which mandate removal and the s 5(2) duty to**
declare certain claims inadmissible.

**_Diminution_**

**[161]** _[Section 55 of the Borders, Citizenship and Immigration Act 2009 ('BCIA 2009') imposes a duty on the SSHD](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7W77-8620-Y97X-70TF-00000-00&context=1519360)_
to have regard to the need to safeguard and promote the welfare of children when discharging any function relating
to asylum or immigration. By virtue of this, the Respondents contend that there will be no diminution. However, the
s 5(2) duty to declare protection and human rights claims inadmissible applies to children on a blanket basis. As a
result, the best interests of the child will not be considered before a claim for international protection is declared
inadmissible.

**[162] Furthermore, whilst a third country human rights claim is admissible, it does not suspend removal which is**
inconsistent with the EU law duty to take into account the child's best interests, in respect of these decisions, prior
to removal.

**[163] The s 2 duty to remove applies to all accompanied children unless the SSHD considers there are exceptional**
circumstances within the meaning of s 6(4)(b). This means that best interests will not be the primary consideration
before removal of an accompanied child.

**[164] The IMA provisions, when in force, will constitute a diminution in the rights enjoyed prior to its enactment.**

**_(8) Unaccompanied Children_**

**_EU Law Right_**

**[165] The Dublin III Regulation requires a member state to “examine any application for international protection” by**
a third-country national who applies on their territory (art 3(1)). Article 6(1) of the Regulation further provides that
“the best interests of the child shall be a primary consideration for Member States with respect to all procedures
provided for in this Regulation.” By art 8(4) the member state responsible for determining an asylum application is
the member state where the unaccompanied minor lodged their application. The Respondents sought to argue that
the Dublin III Regulation is concerned only with the mechanics of asylum applications as between Member States
and does not, of itself, confer individual rights. This runs contrary to the jurisprudence both in Strasbourg and
[domestically – see, eg, Ghezelbash (Case C-63/15, 7 June 2016) and Re Tahmasebi's Application [2021] NIQB 99,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64MX-VNV3-GXF6-846G-00000-00&context=1519360)
per Scoffield J. Thus, prior to 31 December 2020, a child in the position of JR295 had the right to have his asylum
application determined in the UK on the basis of his best interests.

**_IMA Provisions_**

**[166] The s 2 duty to remove does not apply to unaccompanied children but by virtue of s 4(2) of the IMA the**
SSHD is nonetheless empowered to remove such a child in the circumstances prescribed by s 4(3).

**[167] Furthermore, s 6(1)(b) makes it explicit that the duty to remove applies as soon as such a child attains his or**
her majority.


-----

**_Diminution_**

**[168] In the case of JR295, when the statutory provisions come into force, he can be removed from the UK at any**
time and will become subject to the duty to remove on 5 July 2025. The protection claim which he made on 27 July
2023 will be rendered inadmissible. There will be no right to appeal against this inadmissibility. This will result in a
diminution in the civil right previously enjoyed to an in-country assessment of his asylum application, with his best
[interests being the primary consideration. Whilst the Respondents will remain under the duty imposed by s 55 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7W77-8620-Y97X-70TF-00000-00&context=1519360)
BCIA 2009, this will not impact on the automatic rendering of the protection application as inadmissible.

**_(9) Age Assessment_**

**_EU Law Right_**

**[169] Prior to the IMA, the assessment of a person's age could be the subject of a court challenge and would be**
determined as a question of fact (R (A) v Croydon LBC [2009] UKSC 8) on the balance of probabilities (Re JR147

_[[2023] NIKB 67 per Colton J at paras [61] and [62]) and in the UK.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68JS-5PM3-S1G4-H3CY-00000-00&context=1519360)_

**[170] JR295 contends that rights recognised in the ECHR, including those in art 6 and 8, are rights for the**
purposes of the analysis required by the WF and WA in line with the judgment of Colton J in Dillon at para [588].
Article 47 of the CFR guarantees the right to an effective remedy in respect of the violation of any EU law right.

**_IMA Provisions_**

**[171] Section 57 of the IMA states:**

“(1) This section applies if a relevant authority decides the age of a person (“P”) who meets the four conditions
in section 2 (duty to make arrangements for removal), whether that decision is for the purposes of this Act or
otherwise.

[(2) If the decision is made on an age assessment under section 50 or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02K2-00000-00&context=1519360) _[51 of the Nationality and Borders Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02K3-00000-00&context=1519360)_
2022, P may not bring an appeal against the decision under section 54(2) of that Act.

(3) Subsections (4) and (5) apply if P makes an application for judicial review of—

a the decision mentioned in subsection (1), or

b any decision to make arrangements for the person's removal from the United Kingdom under this Act which
is taken on the basis of that decision.

(4) The application does not prevent the exercise of any duty or power under this Act to make arrangements for
the person's removal from the United Kingdom.

(5) The court or tribunal must determine the application on the basis that the person's age is a matter of fact to
be determined by the relevant authority; and accordingly the court or tribunal—

a may grant relief only on the basis that the decision was wrong in law, and

b may not grant relief on the basis that the court or tribunal considers the decision mentioned in subsection (1)
was wrong as a matter of fact.

(6) In this section “relevant authority” means—

a the Secretary of State,

b an immigration officer,


-----

c a designated person within the meaning of Part 4 (age assessments) of the _[Nationality and Borders Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_
_[2022,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_

d a local authority within the meaning of that Part, subject to subsection (7), or

e a public authority within the meaning of that Part which is specified in regulations under section 50(1)(b) of
that Act (referral of age-disputed person for age assessment).

(7) This section applies in relation to a decision of a local authority which is a decision within subsection (1)
only if it is for the purposes, or also for the purposes, of the local authority deciding whether or how to exercise
any of its functions under relevant children's legislation within the meaning of _Part 4 of the Nationality and_
Borders Act 2022.

(8) For the purposes of this section, the cases in which a relevant authority decides the age of a person on an
age assessment under _[section 50 or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02K2-00000-00&context=1519360)_ _[51 of the Nationality and Borders Act 2022 include where a relevant](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02K3-00000-00&context=1519360)_
authority is treated by virtue of regulations under section 58 of this Act as having decided that a person is over
the age of 18.

(9) This section applies only in relation to a decision which is made after this section comes into force.”

**[172] Thus, the IMA will prohibit a person who meets the four criteria in s 2 from appealing an age assessment**
[under ss 50 or 51 of the NBA 2022 (which themselves are not yet in force). By s 57(4), if a person seeks to bring a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02K2-00000-00&context=1519360)
judicial review of their age assessment, this will not prevent their removal and the court or tribunal hearing that
challenge may not consider the age assessment on the facts but could only grant relief if the decision were wrong in
law. There will be no fact finding hearing.

**_Diminution_**

**[173] The removal of fact-based judicial review challenge to age assessments will represent a clear diminution of**
right in a defined category of cases.

**_Overview_**

**[174] As will be apparent, I have found that there is a relevant diminution of right in each of the areas relied upon**
by the Applicants.

**[175] Applying the SPUC criteria:**

i Each of the rights in question falls within the concept of “the civil rights … of everyone in the community” and
these are therefore protected by the RSE provisions of the B-GFA;

ii These rights were given effect in Northern Ireland on or before 31 December 2020;

iii The Northern Irish law was underpinned by EU law including the Procedures Directive, the Qualification
Directive, the Trafficking Directive, the Dublin III Regulation and the CFR.;

iv The UK's withdrawal from the EU has removed this underpinning – see s 5 of the Withdrawal Act, as amended
[by the Retained EU Law (Revocation and Reform) Act 2023;](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68MF-MC63-RV93-T3G7-00000-00&context=1519360)

v The IMA will cause a diminution in the rights enjoyed by asylum seekers in a variety of significant ways as
outlined; and

vi This diminution could not have occurred but for the UK's withdrawal since, otherwise, the supremacy principle
would have ensured that the corpus of EU law prevailed over inconsistent domestic law.


-----

**[176] The Applicants' primary submission therefore succeeds. Each of the statutory provisions under consideration**
infringes the protection afforded to RSE in the B-GFA and therefore s 7A of the Withdrawal Act applies.

**_Remedy_**

**[177] The Respondents say that the court ought not to grant any relief in respect of statutory provisions which are**
uncommenced and which may be impacted by the introduction of secondary legislation in the near future. Further,
in the event of an adverse finding being made, the Respondents invited the court to identify the areas of breach or
make declaratory relief which would enable the UK Government to consider whether to rectify the identified issues.

**[178] The IMA is on the statute book and the Respondents have indicated the Government's intention to**
commence its provisions as soon as possible. NIHRC has an express statutory jurisdiction to seek to impugn future
breaches of the WF. In these circumstances, I am satisfied that the court ought, in an appropriate case, to grant
relief prior to legislative commencement. Colton J drew no distinction between the commenced and uncommenced
provisions of the Legacy Act when he concluded pithily in Re Dillon:

“In short, any provisions of the 2023 Act which are in breach of the WF should be disapplied.” (para [527])

**[179] Read together, the provisions of art 4 of the WA and s 7A of the Withdrawal Act are juridically aligned to the**
approach to the supremacy of EU law under the 1972 Act and Factortame. In the circumstances where domestic
law is inconsistent with the provisions of the WA and laws made applicable by art 4, the latter take precedence and
domestic law is disapplied. This outcome does not occur at the whim of the courts but represents the will of
Parliament as articulated in the Withdrawal Act.

**[[180] This approach is to be contrasted with the remedy of a declaration of incompatibility under s 4 of the Human](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0T1-00000-00&context=1519360)**
Rights Act 1998 ('HRA'). This is a discretionary remedy which, the Supreme Court has recently noted, is often
regarded as “a measure of last resort” and it may be, in a given case, appropriate to afford Parliament an
opportunity to rectify a defect or fill a lacuna (see Secretary of State for Business and Trade v Mercer [2024] UKSC
_12). Even when granted, such a declaration does not affect the validity of a statute or a particular statutory_
provision. The distinction between the two remedies was noted by the court in AT:

“Secondly, the SSWP's criticism of AT for not pursuing her Article 3 ECHR/ HRA remedy is misplaced since
under the Agreement the UK agreed to enhanced rights of enforcement relative to those available under the
_[HRA 1998. Provisions finding their way into domestic law via the Agreement and Section 7A EU(W)A 2018 can](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
be enforced under the conditions set out in Article 4(1) and (2) of the Agreement (see paragraph [52] above)
which confers direct effect upon litigants and a connected power and duty on national courts to disapply
[inconsistent domestic law, an important point emphasised in the Explanatory Notes accompanying Section 7A](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5Y3G-5FB3-GXFD-82P9-00000-00&context=1519360)
[EU(W)A 2018: see paragraph [62] above. That potency is missing from the HRA 1998 when equivalent rights](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
are being enforced where the remedies available to a court do not stretch to the power of disapplication.” (para

[106])

**[181] In line with the approach adopted by Colton J, I have concluded that where there is a breach of the WF, s 7A**
mandates disapplication of the offending provision.

**[182] The following sections of the IMA are therefore disapplied in Northern Ireland:**

(iii) Section 2(1);

(iv) Section 5(1);

(v) Section 5(2);

(vi) Section 6;

(vii) Section 13(4);


-----

(viii) Section 22(2);

(ix) Section 22(3);

(x) Section 25;

(xi) Section 54; and

(xii) Section 57.

**_The Incompatibility Claim_**

**[183] The Applicants also contend that elements of the IMA are incompatible with relevant Convention rights and**
that the court should make a declaration of incompatibility pursuant to s 4 of the HRA.

**[184] The SSHD was unable to make a statement of compatibility at the time of the second reading of the**
proposed legislation under s 19(1)(a) of the HRA.

**[185] Recent caselaw has addressed the approach to ab ante challenges, that is to say a pre-emptive claim of**
incompatibility not based on some individual factual matrix. In Christian Institute v Lord Advocate [2016] UKSC 51,
the court considered whether the Children and Young People (Scotland) Act 2014, a piece of legislation not yet in
force, was within the legislative competence of the Scottish Parliament. The HRA challenge was grounded on art 8
ECHR, it being argued that the legislative provisions breached the right to privacy of parents and children.

**[186] The court held, at para [88]:**

“an ab ante challenge to the validity of legislation on the basis of a lack of proportionality faces a high hurdle: if
a legislative provision is capable of being operated in a manner which is compatible with Convention rights in
that it will not give rise to an unjustified interference with article 8 rights in all or almost all cases, the legislation
itself will not be incompatible with Convention rights … The proportionality challenge in this case does not
surmount that hurdle …”

**[187] The first applicant in this case challenged the criminal law then prevailing in relation to abortion in Northern**
Ireland in Re NIHRC's Application [2018] UKSC 27. The focus of the challenge was on the specific cases of rape
and foetal abnormality where abortion was prohibited. A literal application of the Christian Institute test would mean
that such a challenge could never succeed since such cases make up a small minority of the instances where a
pregnant woman seeks but is denied an abortion. Alternatively, if the cadre of cases is limited to those involving
rape or foetal abnormality, it is difficult to see how the “all or almost all cases” requirement can operate since, in any
case, a litigant could seek to divide the cadre into categories or sub-groups.

**[188] The court did not speak with one voice on this issue. Lord Mance said:**

“The relevant question is whether the legislation itself is capable of being operated in a manner which is
compatible with that right or, putting the same point the other way around, whether it is bound in a legally
significant number of cases to lead to an unjustified interference of the right … It cannot be necessary to
establish incompatibility to show that a law or rule will operate incompatibly in all or most cases. It must be
sufficient that it will inevitably operate incompatibly in a legally significant number of cases.” (para [82])

**[189]** _Re McLaughlin's Application [2018] UKSC 48 was a case from this jurisdiction concerning the entitlement of_
an unmarried partner to widowed parent's allowance. This was not an ab ante challenge since the Applicant had
suffered denial of the benefit. It was argued that the lack of such entitlement constituted unlawful discrimination on
the grounds of marital status contrary to art 14 ECHR when read together with art 8 or art 1 of the First Protocol to
the ECHR.

**[190] Lady Hale stated, at para [43]:**


-----

“… the test is not that the legislation must operate incompatibly in all or even nearly all cases. It is enough that
it will inevitably operate incompatibly in a legally significant number of cases: see _Christian Institute v Lord_
_Advocate [2016] UKSC 52 at para [88]”_

**[191] It was apparent therefore that the highest court was approaching the question by the application of two**
different tests: “all or almost all cases” as against “a legally significant number of cases.” Confusingly, Lady Hale
referred to Lord Reed's judgment in Christian Institute rather than Lord Mance's test in NIHRC when adopting the
words “legally significant number of cases.”

**[192] The question was revisited in Re Abortion Services (Safe Access Zones) (Northern Ireland) Bill [2022] UKSC**
_32, a reference by the Attorney General for Northern Ireland in relation to the legislative competence of the_
Assembly to make a law prohibiting protest in the vicinity of clinics offering pregnancy termination services. It was
argued that the lack of any “reasonable excuse” defence gave rise to a disproportionate interference with the art 9,
10 and 11 ECHR rights of protesters and demonstrators.

**[193] Counsel for the Attorney contended that** _McLaughlin_ represented a less demanding test than _Christian_
_Institute. However, Lord Reed determined that Lady Hale had misstated the test in the former case and the test_
remained as expressed at para [88] of _Christian Institute, ie the “all or almost all cases” test. Para [12] of the_
judgment makes it clear that this analysis applies to cases where it is alleged there is a disproportionate
interference with a qualified Convention right.

**[194] These decisions were recently considered by the Northern Ireland Court of Appeal in Department for Justice**
_v JR123 [2023] NICA 30, which concerned a challenge to the Convention compatibility of art 6(1) of the_
Rehabilitation of Offenders (Northern Ireland) Order 1978. The court concluded that the _Christian Institute_ test
applied to challenges to extant legislation as well as ab ante challenges:

“[80] Our analysis is as follows. In _Re McLaughlin the Supreme Court, unanimously, clearly considered the_
_Christian Institute test to govern the determination of whether a provision of extant primary legislation is_
compatible with a Convention Right. In _Safe Access Zones the Supreme Court, again unanimously, did not_
disagree. The extent of its disagreement with Re McLaughlin was confined to the aforementioned gloss. The
Supreme Court did not suggest that any different test should have been applied in McLaughlin. The argument
on behalf of the respondent did not include any contention that the wrong test had been applied in _Re_
_McLaughlin. Nor did it identify any decided cases, binding on this court or otherwise, espousing a different test_
to be applied to provisions of extant (to be contrasted with draft, or uncommenced) legislation of whatever
status.

[81] We consider that a declaration that a provision of legislation is incompatible with a Convention right,
whether made within or outwith section 4 of the Human Rights Act, by its very nature reflects an assessment of
a general nature applying to a broad panorama, clearly extending beyond the particular facts of the individual
case in which the question of granting this discretionary remedy arises. Such a remedy declares the relevant
provision of the legislation generally to be incompatible with a Convention right. This is to be contrasted with a
remedy personal to a successful claimant, such as an order of certiorari quashing an act or decision held to
have infringed that person's Convention right/s or a suitably tailored mandatory order or an order declaring
such violation. This contrast highlights the general nature and reach of a declaration of incompatibility.

[82] Our interpretation of the decision in Safe Access Zones is, for the reasons explained, that it applies to both
extant legislation (on the one hand) and draft, or uncommenced, legislation (on the other). There is no reason
in principle why this test, which applies to a declaration of incompatibility under section 4 of the Human Rights
Act, should not apply also to an equivalent declaration under section 18(1)(d) of the Judicature (NI) Act 1978.”

**[195] The NIHRC contends that there are two significant differences between those decided cases and the instant**
one:

i This claim is brought by the NIHRC which has specific powers under the NIA to review the effectiveness of
Northern Ireland legislation relating to the protection of human rights and powers to bring compatibility challenges


-----

without being a victim or without showing that there is an actual or potential victim, including in cases of potential
future breach;

ii Secondly, the Supreme Court cases referred to concerned qualified Convention rights and challenges to
legislation on the basis of a lack of proportionality. This claim concerns rights which are absolute and unqualified. It
does not involve any question of proportionality.

**[196] In Re Gallagher [2019] UKSC 3, the various applicants challenged the validity of statutory rules governing the**
disclosure of criminal records to prospective employers. The individuals claimed that their art 8 rights had been
breached and Lord Sumption explained:

“The respondents submit that because the categories of disclosable conviction or caution are (they say) too
wide, and not subject to individual review, the legislation does not have the quality of law. Before I examine this
submission in the light of the authorities, it is right to draw attention to some of its more far reaching
consequences if it is correct. In the first place, it means that the legislation is incompatible with article 8,
however legitimate its purpose, and however necessary or proportionate it may be to deal with the problem in
this particular way. That conclusion would plainly have significant implications for the protective functions of the
state, especially in relation to children and vulnerable adults. Secondly, it must be remembered that the
condition of legality is not a question of degree. The measure either has the quality of law or it does not. It is a
binary test. This is because it relates to the characteristics of the legislation itself, and not just to its application
in any particular case: see _Kruslin v France (1990) 12 EHRR 547, paras [31]-[32]. It follows that if the_
legislation fails the test of legality, it is incompatible with the Convention not just as applied to those convicted
of minor offences like these respondents, but to the entire range of ex-offenders including, for example,
convicted child molesters, rapists and murderers. Thirdly, this consequence cannot be confined to the right of
privacy. Most Convention rights are qualified by reference to various countervailing public interests. These
qualifications are fundamental to the scheme of the Convention. They are what makes it possible to combine a
high level of protection of human rights with legitimate measures for the protection of the public against real
threats to their welfare and security. For that reason, exceptions corresponding to those in article 8 attach to a
number of other Convention rights. They too must also have a proper basis in law. It is fair to say that the
jurisprudence of the Strasbourg court has been especially sensitive to the keeping of files on individuals by the
state, a practice which was gravely abused by the authoritarian regimes of the 20th century in most of
continental Europe … But the question what constitutes law is the same whatever the subject matter. Neither
the Strasbourg court nor the courts of the United Kingdom have ever suggested that the condition of legality
applies in any different way in article 8 as compared with other articles. In principle, therefore, whatever
conclusion we reach in this case about the scope of the condition of legality must apply equally to the
exceptions to article 5 (right to liberty and security), article 9 (freedom of thought, conscience and religion),
article 10 (freedom of expression), and article 11 (freedom of assembly and association). In none of these
articles would there be any scope for distinctions based on judgment or discretion or weighing of broader public
interests, even on the most compelling grounds, once the relevant measure failed the respondents' exacting
test of legality” (para [14])

**[197] Therefore, if a legislative provision fails the “in accordance with law” test, it is incompatible with the ECHR**
without more. The court does not then require to consider the question of proportionality. In a challenge based on
proportionality, however, the position was set out by Lord Sumption at para [50]:

“In those cases where legislation by pre-defined categories is legitimate, two consequences follow. First, there

will inevitably be hard cases which would be regarded as disproportionate in a system based on case‑by-case

examination. As Baroness Hale observed in R (Tigere) v Secretary of State for Business, Innovation and Skills

[2015] 1 WLR 3820, para [36], the Strasbourg court's jurisprudence “recognises that sometimes lines have to
be drawn, even though there may be hard cases which sit just on the wrong side of it.” Secondly, the task of
the court in such cases is to assess the proportionality of the categorisation and not of its impact on individual
cases. The impact on individual cases is no more than illustrative of the impact of the scheme as a whole.”


-----

**[198] The Strasbourg jurisprudence confirms that, in order to constitute a violation of art 3 ECHR, the behaviour**
complained of must meet a minimum level of severity. Once that threshold is crossed, it matters not that some
justification can be offered for it. In Ilias v Hungary [2020] 71 EHRR 6, the Grand Chamber stated:

“The court is mindful of the challenge faced by the Hungarian authorities during the relevant period of 2015,
when a very large number of foreigners were seeking international protection or passage to western Europe at
Hungary's borders. However, the absolute nature of the prohibition of ill-treatment enshrined in Article 3 of the
Convention mandates an adequate examination of the risks in the third country concerned” (para [155])

**[199] In any event, in this case, the Applicants argue that each of the impugned provisions will operate**
incompatibly with the ECHR in all circumstances.

**[200] When considering the question of compatibility, it is important to note that s 1(5) of the IMA excludes the**
operation of the interpretative obligation contained in s 3 of the HRA – it “does not apply in relation to provision
made by or by virtue of this Act.” In the event therefore of some conflict between a provision of the IMA and a
Convention right, it will not be possible for the courts to resolve this by operation of s 3 HRA.

**_(1) Removal_**

**[201] Article 3 ECHR states simply:**

“No one shall be subjected to torture or to inhuman or degrading treatment or punishment”

**[202] In Ilias v Hungary the Grand Chamber set out the following principles in relation to the application of art 3 to**
asylum claims, at paras [124] to [141]:

i Where substantial grounds have been shown for believing that the person in question, if removed, would face a
real risk of being subjected to treatment contrary to art 3 in the receiving country then art 3 implies an obligation not
to remove the individual to that country;

ii The assessment of whether there are substantial grounds for believing that the Applicant faces a real risk of
being subjected to treatment in breach of art 3 must necessarily be a rigorous one and inevitably involves an
examination by the competent national authorities and later by the court of the conditions in the receiving country
against the standards of art 3;

iii These standards imply that the ill-treatment the Applicant alleges he or she will face if returned must attain a
minimum level of severity if it is to fall within the scope of art 3;

iv Where a contracting state seeks to remove the asylum seeker to the country of origin, there must be a proper
determination of whether the asylum claim is well-founded;

v Where the removal is to a third country the authorities must either carry out a determination of whether the claim
is well-founded or examine thoroughly whether there is an adequate, accessible and reliable asylum procedure in
the receiving third country, including an analysis of whether the person will be protected from refoulement; and

vi These assessments must be carried out prior to removal.

**[203] The IMA provisions, at ss 2 and 6, mandate removal to a country listed in Sch 1 even where the person**
concerned has made a third country human rights claim (see s 5(1)). This has the following consequences:

i Such claims may not be determined prior to removal and the assessments required by art 3 will not occur;

ii A suspensive claim will not, in a number of cases, determine whether there are substantial grounds to believe the
individual will be at a real risk of treatment contrary to art 3, directly or indirectly, if removed, or the asylum claim is
well-founded;


-----

iii A serious harm suspensive claim concerns the risk of serious harm in a third country in the removal notice. By
contrast, an asylum claim may be upheld based solely on risk in the country of origin;

iv In a serious harm suspensive claim the harm must arise within the “relevant period” whereas there is no such
requirement in art 3 claim or an asylum claim;

v A person must supply “compelling evidence” to establish a suspensive claim, whereas that is not required for the
purpose of art 3;

vi To establish that removal would breach art 3, it is not necessary for the Applicant to show a “real, imminent and
foreseeable risk of serious and irreversible harm if removed” in the third country as required by a suspensive claim.
It is sufficient for there to be a “real risk” of treatment contrary to art 3, or a real risk of the asylum seeker being
denied an adequate and reliable asylum procedure in the third country;

vii “Serious and irreversible harm” is more limited than treatment which would infringe art 3;

viii Section 39(5)(c) of the IMA excludes from the definition of 'serious and irreversible harm' any harm resulting
from differences in the standard of healthcare between the UK and the receiving country. In _AM (Zimbabwe) v_
_Secretary of State for the Home Department_ _[2020] UKSC 17, the Supreme Court followed the Grand Chamber_
decision in Paposhvili v Belgium [2017] Imm AR 867, and held that an applicant could rely on art 3 when he or she
could show substantial grounds for believing that although not at imminent risk of dying, he or she would face a real
risk, on account of the absence of appropriate treatment in the receiving country or the lack of access to such
treatment, of being exposed to either a serious, rapid and irreversible decline in his or her state of health resulting in
intense suffering or a significant reduction in life expectancy;

ix The very short time limit for a suspensive claim will in many cases inhibit the person's ability to obtain legal
advice and the required compelling evidence of serious harm, and to produce an effective claim.

x A serious harm suspensive claim will not meet the art 3 requirement that the UK authorities examine whether the
third country will deal adequately and reliably with the asylum claim.

**[204] In** _Ilias_ the Grand Chamber made it clear that states may establish lists of 'presumed safe' states but, in
doing so, this must be sufficiently supported at the outset by an analysis of the relevant conditions in that country
and, in particular, of its asylum system (para [152]). In _R (EM (Eritrea)) v SSHD [2014] UKSC 12, Lord Kerr_
commented “this calls for a rigorous assessment.”

**[205] The uncontroverted evidence adduced on behalf of the NIHRC is to the effect that such rigorous assessment**
has not been carried out in relation to Albania, India, Mongolia, or Mauritius.

**[206] Furthermore, whilst there is a significant evidential presumption following such an assessment, it remains**
only a presumption and where there is evidence that the state is not safe in an individual case, there should be an
examination of whether removal will breach art 3 prior to removal: see Lord Kerr in EM (Eritrea) at para [41].

**[207] The duty imposed by ss 2 and 6 of the IMA will require removal of a person to their country of origin if it is**
one of the 'safe States', unless, the person has made a protection claim or a human rights claim and the Secretary
of State considers there are exceptional circumstances which prevent the person's removal to that country or
territory (s 6(4)). The examples given of exceptional circumstances in s 6(5) are limited.

**[208] Furthermore, by s 39(2), a serious harm suspensive claim is not available when the country in the removal**
notice is the country of origin.

**[209] For all these reasons, it is inevitable that the s 2 duty will require removal of persons in circumstances where**
they have advanced valid protection or human rights claims, and these have not been assessed. There will be no
examination of whether or not those individuals are at real risk of being subjected to treatment contrary to art 3.

**[210] The removal provisions are therefore incompatible with art 3 ECHR.**


-----

**_(2) Trafficking_**

**[211] Article 4 of the ECHR states:**

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

3. For the purpose of this article the term 'forced or compulsory labour' shall not include:

a any work required to be done in the ordinary course of detention imposed according to the provisions of
Article 5 of the Convention or during conditional release from such detention;

b any service of a military character or, in case of conscientious objectors in countries where they are
recognised, service exacted instead of compulsory military service;

c any service exacted in case of an emergency or calamity threatening the life or well-being of the community;

d any work or service which forms part of normal civic obligations.”

**[212] In VCL and AN v United Kingdom (2021) 73 EHRR 9, the ECtHR identified:**

“Article 4 may, in certain circumstances, require a State to take operational measures to protect victims, or
potential victims, of trafficking. In order for a positive obligation to take operational measures to arise in the
circumstances of a particular case, it must be demonstrated that the State authorities were aware, or ought to
have been aware, of circumstances giving rise to a credible suspicion that an identified individual had been, or
was at real and immediate risk of being, trafficked or exploited” (para [152])

**[213] The court went on to observe that:**

“Protection measures include facilitating the identification of victims by qualified persons and assisting victims
in their physical, psychological and social recovery” (para [153])

**[214] Article 4 ECHR also entails a procedural obligation to conduct an effective official investigation into situations**
of potential trafficking, see para [155] of VCL.

**[215] The European court in** _VCL made it clear that these duties must be construed in light of the provisions of_
ECAT, which I will now set out. In doing so, I am cognisant of the admonition of Lord Reed in _R (SC) v SSWP_

_[2021] UKSC 26 at paras [79] et seq in relation to the lack of domestic legal effect of unincorporated international_
treaties. However, it is a legitimate aspect of the application of the mirror principle from _R (Ullah) v Special_
_Adjudicator [2004] UKHL 26 to consider how the Strasbourg courts engage with international treaties in the_
interpretation of Convention rights.

**[216] Article 10 provides:**

“1. Each Party shall provide its competent authorities with persons who are trained and qualified in preventing
and combating trafficking in human beings, in identifying and helping victims, including children, and shall
ensure that the different authorities collaborate with each other as well as with relevant support organisations,
so that victims can be identified in a procedure duly taking into account the special situation of women and
child victims …

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure that,
if the competent authorities have reasonable grounds to believe that a person has been victim of trafficking in
human beings, that person shall not be removed from its territory until the identification process as victim of an
offence provided for in Article 18 of this Convention has been completed by the competent authorities and shall
likewise ensure that that person receives the assistance provided for in Article 12 paragraphs [1] and [2] ”


-----

**[217] Article 12 states:**

“1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:

a standards of living capable of ensuring their subsistence, through such measures as: appropriate and secure
accommodation, psychological and material assistance;

b access to emergency medical treatment;

c translation and interpretation services, when appropriate;

d counselling and information, in particular as regards their legal rights and the services available to them, in a
language that they can understand;

e assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

f access to education for children.

2. Each Party shall take due account of the victim's safety and protection needs.

3. In addition, each Party shall provide necessary medical or other assistance to victims lawfully resident within
its territory who do not have adequate resources and need such help.

4. Each Party shall adopt the rules under which victims lawfully resident within its territory shall be authorised to
have access to the labour market, to vocational training and education.

6 Each Party shall adopt such legislative or other measures as may be necessary to ensure that assistance to
a victim is not made conditional on his or her willingness to act as a witness.”

**[218] Article 13 reads:**

“1. Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when there
are reasonable grounds to believe that the person concerned is a victim. Such a period shall be sufficient for
the person concerned to recover and escape the influence of traffickers and/or to take an informed decision on
cooperating with the competent authorities. During this period it shall not be possible to enforce any expulsion
order against him or her. This provision is without prejudice to the activities carried out by the competent
authorities in all phases of the relevant national proceedings, and in particular when investigating and
prosecuting the offences concerned. During this period, the parties shall authorise the persons concerned to
stay in their territory.

2. During this period, the persons referred to in paragraph [1] of this Article shall be entitled to the measures
contained in Article 12, paragraphs [1] and [2].

3. The Parties are not bound to observe this period if grounds of public order prevent it or if it is found that
victim status is being claimed improperly.”

**[219] Article 14 reads:**

“1. Each Party shall issue a renewable residence permit to victims, in one or other of the two following
situations or in both:

a the competent authority considers that their stay is necessary owing to their personal situation;

b the competent authority considers that their stay is necessary for the purpose of their cooperation with the
competent authorities in investigation or criminal proceedings.


-----

2. The residence permit for child victims, when legally necessary, shall be issued in accordance with the best
interests of the child and, where appropriate, renewed under the same conditions.

3. The non-renewal or withdrawal of a residence permit is subject to the conditions provided for by the internal
law of the Party.

4. If a victim submits an application for another kind of residence permit, the Party concerned shall take into
account that he or she holds, or has held, a residence permit in conformity with paragraph [1].

5. Having regard to the obligations of Parties to which Article 40 of this Convention refers, each Party shall
ensure that granting of a permit according to this provision shall be without prejudice to the right to seek and
enjoy asylum.”

**[220] ECAT therefore provides for a scheme whereby a person is not removed following a “reasonable grounds”**
decision until a final decision that a person is a victim. During this time, he or she must receive the 'basic level' of
assistance specified in art 12(1) and (2).

**[221] Article 13(1) and (2) mandates, in any event, the recovery and reflection period during which time the person**
must not be removed and shall be entitled to basic assistance.

**[222] Article 14(1)(a) requires leave to remain to be granted if the victim's stay in the UK is “necessary owing to**
their personal situation.” This includes where the victim is pursuing a protection claim based on their fear of being
re-trafficked: R (EOG) v Secretary of State for the Home Department [2023] QB 351at para [78].

**[223] Article 12(6) of ECAT provides that such duties arise whether or not the victim is co-operating with a criminal**
investigation.

**[[224] The limited right to remain for victims of slavery or human trafficking is enshrined in domestic law in s 65 of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KK-00000-00&context=1519360)**
the NBA 2022. However, once the IMA is in force, the duty to remove imposed by ss 2, 5 and 6 of the IMA, read
with s 22, will mean that a person in respect of whom a positive reasonable grounds decision has been made will
be removed prior to any identification process being complete, or before any asylum claim based on the fear of
being re-trafficked has been determined. Such a protection claim will be inadmissible by virtue of s 5(2).

**[225] Section 25(2) of the IMA disapplies the assistance and support duty under the Human Trafficking and**
Exploitation (Criminal Justice and Support for Victims) Act (Northern Ireland) 2015. The case law makes it clear that
asylum support is not sufficient to meet the requirements of art 12(1) and (2) of ECAT: see R (K) v SSHD (supra).

**[226] The Respondents rely on the defence in art 13(3) to say that grounds of public order exist to disapply the**
protections in art 4 ECHR when read with the ECAT provisions.

**[227] However, the art 13(3) provision states specifically “the parties are not bound to observe this period if**
grounds of public order prevent it.” It expressly only applies therefore to the recovery and reflection period set out in
art 13(1). It does not entitle a state to disapply the art 10(2) protection which forbids removal until the process of
identification is complete.

**[228] Furthermore, it cannot conceivably be the case that mere presence in a state alone can trigger the public**
order exception. Something more must be required.

**[229] For these reasons, the trafficking provisions are incompatible with art 4 ECHR when read with ECAT.**

**_(3) Detention_**

**[230] Article 5(4) ECHR states:**


-----

“Everyone who is deprived of his liberty by arrest or detention shall be entitled to take proceedings by which the
lawfulness of his detention shall be decided speedily by a court and his release ordered if the detention is not
lawful.”

**[231] The meaning of 'speedily' in any given context will be fact-specific but the question must itself be decided by**
a court: see the Grand Chamber in Khlaifia v Italy (16483/12) 15 December 2016 at para [131].

**[232] The ECtHR found a breach of art 5(4) in Shcherbina v Russia (41970/11) 26 June 2014 when a period of 16**
days elapsed between an application for release and examination by a court in an extradition case. Similarly, a
period of 17 days between a plea of unlawfulness first being raised and decided by the court was found to be a
violation in Kadem v Malta (55263/00) 9 January 2003.

**[233]** _[Section 13(3) and (4) of the IMA 2023 prohibits a court from determining, in the first 28 days of detention: (a)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S322-00000-00&context=1519360)_
whether a decision as to the lawfulness of detention is required within that period; and, (b) in cases where it is so
required, whether detention was lawful and release should be ordered. A decision to detain during this 28 day
period is only capable of challenge when:

i The SSHD acted in bad faith;

ii The SSHD acted in fundamental breach of the principles of natural justice; or

iii On an application for habeas corpus.

**[234] In** _R v SSHD ex p Cheblak [1991] 1 WLR 890, the Court of Appeal in England & Wales outlined the_
distinction between habeas corpus and judicial review:

“A Writ of habeas corpus will issue where someone is detained without any authority or the purported authority
is beyond the powers of the person authorising the detention and so is unlawful. The remedy of judicial review
is available where the decision or action sought to be impugned is within the powers of the person taking it but,
due to some procedural error, a misappreciation of the law, a failure to take account of relevant matters, or
taking account of irrelevant matters or the fundamental unreasonableness of the decision or action, it should
never have been taken.” (at 894)

**[235] On this analysis habeas corpus concerns the existence of a power to detain not whether a power to detain**
was exercised lawfully. However, it must be recognised that the seminal case relating to asylum detention, _R v_
_Governor of Durham Prison ex p. Hardial Singh (1984) 1 WLR 704, was itself a habeas corpus application which_
led to the establishment of legal principles in this field. Indeed, in R (Khadir) v SSHD [2005] UKHL 39, Lord Brown
pointed out, at para [33} that the “Hardial Singh line of cases” concern the exercise of the power to detain rather
than its existence.

**[236] The remedy of habeas corpus may have been out of fashion in asylum and immigration cases since Cheblak,**
and judicial review has been seen as having procedural primacy. However, the Respondents themselves say in
argument that the principles would apply to either remedy in the same way. It remains to be seen whether the
courts will seek to reinvigorate habeas corpus in due course.

**[237] On that basis, it cannot be said, at least for the purposes of an ab ante challenge, that the detention**
provisions cannot be operated in a Convention compliant way. I therefore reject the claim of incompatibility of the
IMA provisions with art 5(4) ECHR.

**_(4) Children_**

**[238] Article 8 ECHR states:**

“1. Everyone has the right to respect for his private and family life, his home and his correspondence.


-----

2. There shall be no interference by a public authority with the exercise of this right except such as is in
accordance with the law and is necessary in a democratic society in the interests of national security, public
safety or the economic well-being of the country, for the prevention of disorder or crime, for the protection of
health or morals, or for the protection of the rights and freedoms of others.”

**[239] The Strasbourg courts read art 8 in accordance with art 3.1 of the UN Convention on the Rights of the Child**
which requires that, in all cases concerning children, the best interests of the child shall be a primary consideration.
The NIHRC does not seek to argue that any of the IMA provisions represent a disproportionate interference with the
art 8 rights of children. Rather, it is contended that they will render decisions relating to children as being not “in
accordance with law.” Reliance is placed on Lady Hale's judgment in _ZH (Tanzania) v Secretary of State for the_
_Home Department [2011] UKSC 4:_

“This means that any decision which is taken without having regard to the need to safeguard and promote the
welfare of any children involved will not be “in accordance with the law” for the purpose of article 8(2)” (at para

[24]).

**[240] Whilst** _[s 55 of the BCIA 2009 imposes a duty on the SSHD to have regard to the need to safeguard and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7W77-8620-Y97X-70TF-00000-00&context=1519360)_
promote the welfare of children when discharging any function relating to asylum or immigration, the duty to remove
in s 2 and 6 of the IMA (subject to s 4) and the duty to declare certain types of claim inadmissible under s 5 will
mean that the child's interests will not be the primary consideration and, as such, will not satisfy the “in accordance
with the law” requirement. There is no need to consider the question of proportionality.

**[241] There is, however, a distinction between accompanied children, who are subject to the duty to remove, and**
unaccompanied children, who are not. In its response to the Joint Committee, the UK Government acknowledged
[that the exercise of the power to remove would remain subject to the s 55 BCIA 2009 obligation. To that extent, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7W77-8620-Y97X-70TF-00000-00&context=1519360)
IMA provisions are capable of being operated in a Convention compliant manner in relation to unaccompanied
children.

**[242] However, any protection claim made by an unaccompanied minor, when the s 2 criteria apply, will be**
rendered inadmissible when the IMA comes into force. This means that no decision will be made on such an
asylum claim at all, whether in the best interests of the child or not, and they will face inevitable removal upon
attainment of majority. This cannot satisfy the “in accordance with law” requirement.

**[243] These provisions in relation to children are therefore incompatible with art 8 ECHR.**

**_(5) Age Assessment_**

**[244] Article 6(1) of the ECHR requires that:**

“In determination of his civil rights and obligations everyone is entitled to a fair and public hearing within a
reasonable time by an independent and impartial tribunal established by law.”

**[245] There has historically been some dispute as to where the line is drawn between public law rights which would**
not attract the art 6 entitlement and civil rights which would. In Ali v Birmingham City Council [2010] UKSC 8, the
Supreme Court rejected the claim that homelessness decisions under the Housing Acts constituted determinations
of civil rights. However, in Ali v United Kingdom [2016] 63 EHRR 20, the ECtHR disagreed. The court said:

“It is now well-established that disputes over entitlement to social security or welfare benefits generally fall
within the scope of Article 6 § 1 of the Convention … The Court has even recognised a right to a noncontributory welfare benefit as a civil right … However, the present case differs from previous cases concerning
welfare assistance, as the assistance to be provided under section 193 of the 1996 Act not only was
conditional but could not be precisely defined … It concerns, as the Government noted, a “benefit in kind” and
the Court must therefore consider whether a statutory entitlement to such a benefit may be a “civil right” for the
purposes of Article 6 § 1. …


-----

It is true that accommodation is a “benefit in kind” and that both the applicant's entitlement to it and the
subsequent implementation in practice of that entitlement by the Council were subject to an exercise of
discretion. Nonetheless, the Court is not persuaded that all or any of these factors necessarily militate against
recognition of such an entitlement as a “civil right” … In any case, the “discretion” in the present case had
clearly defined limits: once the initial qualifying conditions under section 193(1) had been met, pursuant to
section 206(1) the Council was required to secure that accommodation was provided by one of three means,
namely by providing accommodation itself; by ensuring that the applicant was provided with accommodation by
a third party; or by giving the applicant such advice and assistance to ensure that suitable accommodation was
available from a third party.” (paras [58] & [59])

**[246] In light of this ECtHR decision, and in application of the Ullah principle, I am satisfied that an age assessment**
is a determination of an individual's entitlement to significant rights and welfare benefits. It involves a question of
precedent fact and therefore engages discretion and evaluative judgment only to a limited extent. The determination
of an individual's age is a matter of fact. Once it is established that a person is a child then certain legal rights and
entitlements follow. It is therefore subject to the art 6 right to determination by a court which entails an effective
judicial remedy to assert civil rights.

**[247] Article 6 does not create an absolute right but any interference with it must be in pursuit of a legitimate aim**
and there must be a proportionate relationship between this aim and the means employed – see, eg, Nait-Liman v
_Switzerland [2018] 3 WLUK 861 at paras [101] – [104]._

**[248] The Respondents rely on an affidavit from Dr Meirav Elimelech, a Deputy Director in the Asylum and**
Protection Unit within the Home Office, who helpfully sets out the present arrangements and guidance in relation to
age assessment, particularly in the context of unaccompanied children. Where there is doubt or suspicion around
an individual's age, they will be subjected to an age assessment in accordance with the principles laid down in R
_(B) v London Borough of Merton [2003] EWHC 1689 (Admin). It is recognised that even comprehensive and holistic_
age assessments under this 'Merton-compliant' approach can nonetheless carry a significant margin of error.

**[249] In relation to s 57 of the IMA, Dr Elimelech comments:**

“Given that unaccompanied children will be treated differently to adults, it is essential to ensure age is
assessed as accurately as possible. Section 57 IMA seeks to reserve age assessments to suitably qualified
and trained professionals with experience of conducting age assessments. In doing so section 57 also aims to
avoid lengthy age disputes preventing the removal of those who have been assessed to be adults … the right
of appeal for age assessment … is disapplied for individuals that come to the UK illegally and are subject to the
duty to remove. Instead, those wishing to challenge a decision on age will be able to do so through judicial
review, as they can do currently. Applications for judicial review will not suspend removal and can continue
from outside the UK after they have been removed.”

**[250] This averment does not address the fundamental change in the nature of the judicial review remedy**
introduced by the IMA.

**[251] The evidence relied upon by the Respondents in respect of the legitimate aim in removing a fact-finding age**
assessment judicial remedy refers to a need to avoid “lengthy age disputes” and a desire to disincentivise adults
from falsely claiming to be children.

**[252] However, the inevitable consequence of the legislation will be to prevent individuals who are children from**
being able to challenge age assessments, save on limited judicial review grounds, and thereby be deprived of their

entitlements. The interference with the right will, in all cases of a minor who seeks to challenge fact‑based age

assessment, result in a violation of art 6.

**[253] JR295 also relies upon the qualified right created by art 8 ECHR. Recently, in Darboe and Camara v Italy**
(2023) 76 EHRR 5, the ECtHR observed:


-----

“The court considers that the age of a person is a means of personal identification and that the procedure to
assess the age of an individual alleging to be a minor, including its procedural safeguards, is essential in order
to guarantee to him or her all the rights deriving from his or her minor status. It also emphasises the importance
of age-assessment procedures in the migration context. The applicability of domestic, European and
international legislation protecting children's rights starts from the moment the person concerned is identified as
a child. Determining if an individual is a minor is thus the first step to recognising his or her rights and putting
into place all necessary care arrangements. Indeed, if a minor is wrongly identified as an adult, serious
measures in breach of his or her rights may be taken.” (paras [124] & [125]

**[254] The court identified that there was no judicial decision or administrative measure concluding that the**
Applicant was of adult age, and no appeal against this conclusion. The court found there was a violation of the
Applicant's art 8 rights on the following basis:

“In the present case, the Italian authorities failed to apply the principle of presumption of minor age, which the
court deems to be an inherent element of the protection of the right to respect for private life of a foreign
unaccompanied individual declaring to be a minor.

While the national authorities' assessment of the age of an individual might be a necessary step in the event of
doubt as to his or her minority, the principle of presumption implies that sufficient procedural guarantees must
accompany the relevant procedure.” (paras [153] & [154])

**[255] The lack of “sufficient procedural guarantees” in the scheme created by the IMA will, in a category of cases,**
to lead to a breach of art 8 rights.

**[256] The Respondents maintain that JR295 lacks the necessary standing pursuant to** _[s 18(4) of the Judicature](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJW0-TWPY-Y1MT-00000-00&context=1519360)_
(Northern Ireland) Act 1978 in order to be granted relief in the form of a s 4 declaration of incompatibility. In granting
leave, I held that JR295 enjoyed the necessary standing both to bring the judicial review application and to seek to
invoke the provisions of the HRA. However, the question demands reconsideration in light of the complete
evidential picture now available and the discretionary nature of the relief sought.

**[257] Colton J reflected on the issue of standing at paras [704] – [709] of Dillon and concluded that the Applicant**
Fitzsimmons lacked the necessary standing to advance the ECHR challenge. It is important to recall that the age
assessment process has resolved in JR295's favour and whilst there is a risk that this could be reviewed on the
basis of new evidence, there is no indication that this will take place. Section 57 has not yet commenced and
therefore JR295 has not been denied any fact finding judicial remedy. In these circumstances, and whilst my
observations on the compatibility of the provision remain apposite, I have determined that JR295 lacks the
necessary standing for the grant of relief under the HRA. I therefore decline in my discretion to make a s 4 HRA
declaration in respect of the age assessment provisions of the IMA.

**_Remedy_**

**[258] As discussed above, the declaration of incompatibility is a discretionary remedy and has been referred to as**
a measure of last resort. The Respondents submit that it would be inappropriate to grant such relief in respect of
uncommenced legislation. However, the authorities recognise that the remedy can be granted in such instances –
see, eg, Christian Institute, Abortion Services and JR123.

**[259] Given the significant nature of the violations identified, and the Government's avowed intention to proceed to**
bring the IMA into force, I am satisfied, in the instant cases, that it would be appropriate to exercise my discretion
and grant the s 4 declarations of incompatibility sought in respect of:

1 Sections 2(1), 5(1), 6(3) and 6(7) insofar as they impose a duty to remove;

2 Sections 2(1), 5, 6, 22 and 25 insofar as they relate to potential victims of modern slavery or human trafficking;
and


-----

3 Sections 2(1), 5(1) and 6 relating to children.

**_Conclusions_**

**[260] For the reasons set out, the relevant provisions of the IMA listed at para [178] are disapplied in Northern**
Ireland and I make declarations of incompatibility in respect of those sections of the Act set out at para [255].

**[261] I will hear the parties on the precise form of the court's orders, the question of costs and any ancillary issues**
arising.

Order accordingly.

**End of Document**


-----

