# R v Kovalkov [2023] EWCA Crim 1509

Court of Appeal, Criminal Division

Edis LJ, Baker J, Sir Robin Spencer

5 December 2023Judgment

MR P SPARY appeared on behalf of the Applicant

MR D O'DONNELL appeared on behalf of the Crown

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

SIR ROBIN SPENCER:

1. This is an appeal against sentence brought by leave of the single judge.

2. The appellant is now 18 years old, date of birth 6 August 2005. He was sentenced on 18 April 2023 to
a term of 42 months' detention for offences involving the supply of class A and class B drugs and for two
offences of affray. He had pleaded guilty to all the offences on earlier occasions. He was only 17 at the
date of sentence.

3. Issues arise in this appeal as to the lawfulness of the sentences the judge passed as well as their
length. It is submitted on the appellant's behalf that a custodial sentence was not called for at all and, in
the alternative, that 42 months was manifestly excessive.

4. The appeal was listed before another constitution of this Court in September and adjourned for the

preparation of an addendum pre‑sentence report and for further written submissions by counsel for the

parties. We are grateful to Mr Spary on behalf of the appellant and to Mr O'Donnell on behalf of the Crown
for their written and oral submissions.

5. The appellant was sentenced at Ipswich Crown Court by His Honour Judge Levett along with seven
other defendants. It was clearly a complex sentencing task, with six different indictments and 26 offences
in total. The sentencing hearing extended over two days.

The offences


-----

6. Taking the appellant's offences chronologically, the first in time was the drugs indictment. He was
charged with being concerned in the supply of cocaine (count 1) and cannabis (count 2). There was a

co‑defendant several years older. No disparity argument arises. For these offences the judge imposed a

sentence of 30 months' detention. Because the appellant was under 18 at the date of conviction, that
[sentence could only have been imposed under section 250 of the Sentencing Act 2020,although the judge](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)
did not spell this out. The only lawful alternative in view of the appellant's age would have been a detention
and training order for a maximum of two years.

7. The brief facts are that between January and June 2022 the appellant was involved in the supply of
cocaine and cannabis in the Ipswich area using a dedicated mobile phone number ending 984. On that
number messages advertising the sale of both cocaine and cannabis were sent out in bulk. The phone
was also used to make taxi bookings to various destinations. Phone credit for the mobile number was
topped up by the appellant at the end of March 2022.

8. On 23 April 2022 the appellant was stopped by the police and found in possession of six separate

grip‑sealed bags of cannabis, £100 in cash and two mobile phones. One of the phones was the phone

using the number 984.

9. The appellant's home address was searched. Further cannabis and cash were found along with a
notepad showing a list of names and numbers under headings referring separately to cannabis and
cocaine. A further eight sealed bags of cannabis were found in that search. No cocaine was recovered
but it is plain that the appellant had been concerned in supplying cocaine over this period, as confirmed by
his guilty plea. It was accepted by the prosecution that cannabis had been the main drug supplied.

10. The next offence in time, on a separate indictment, was an affray committed on 2 June 2022. There

were three co‑defendants. It took place in Ipswich town centre at about 9.00 pm, in daylight still. In the

course of the affray a man called Jordan Vincent was stabbed by one of the co‑defendants. That

defendant was charged with and pleaded guilty to section 18 wounding with intent. The appellant's group
had clearly been looking for Vincent to attack him. CCTV footage showed them entering a McDonald's a
short distance away from the public house where Vincent and two other males had congregated and were

standing outside. Seeing the other group, one of the appellant's co‑defendants drew a large machete and

ran up the street towards the other group. He stabbed Vincent to the back of the shoulder causing a
punctured lung and an injury to his wrist. The appellant was seen to throw a glass bottle at Vincent which

smashed on the kerb. Vincent's injuries were thought at first to be life‑threatening but after sedation at

hospital he discharged himself next morning against medical advice. He declined to support the police
investigation.

11. The final offence was another affray, on a separate indictment, committed on 15 August 2022. By now
the appellant had appeared at the Crown Court in respect of the first affray charge and was on bail. The
offence took place in the Maple Park area of Ipswich, an area which had been regenerated following gang

violence and turned into a family‑based park with play areas for children.

12. At around 3.40 pm that Monday afternoon the police were called to the area by a local resident who
reported that she had seen three males beating up another male, as she put it. That resident was then
approached by the male she thought had been beaten up, a man called Crumlish; in fact it was he who had
been the original aggressor. He was wielding a machete which was subsequently recovered by the police
from the resident's garden. The police also noticed blood spatter on the floor by the gates to the resident's
address.

13. CCTV footage showed another co‑defendant approaching Crumlish and taking out a cosh. The

appellant was seen to throw a bicycle at Crumlish and then to pick up a bin. The appellant had been

advancing towards the group on the bicycle, apparently escorting another co‑defendant in that direction.

Crumlish was also charged with affray and was injured in the incident.


-----

The sentencing hearing

14. The appellant had no previous convictions, but he had received a youth caution on 29 March 2022 for
possession of cannabis on 8 February 2022. He received a further youth caution on 9 June 2022 for an
offence of violent disorder on 19 January 2022 and for possession of cocaine and cannabis with intent to
supply the following day.

15. There was a pre‑sentence report which acknowledged the possibility of a detention and training order

but recommended a 12‑month youth rehabilitation order with supervision and unpaid work requirements

and a drug activity requirement to address the appellant's cannabis use. The report explained that the
appellant had been involved with the Youth Justice Service since 2020, after concerns about his behaviour
were raised by his school. Following the cautions in 2022 the appellant's engagement with the Youth
Justice Service had been intermittent. He had engaged more positively on the bail support programme
after June 2022, although as we have noted he committed the final affray whilst on bail.

16. Regrettably there was a long delay in dealing with all these defendants for so many offences, owing
partly to the impact of the pandemic and the barrister's action. In consequence, as the judge noted, the
appellant had been on bail with a qualifying curfew for 303 days, entitling him to credit of 152 days.

17. In his sentencing remarks the judge identified the appellant's role in the drugs offences and the role of

each co‑defendant in the drugs offences as "significant" for the purposes of the Sentencing Council

guideline. He concluded that the appellant had an expectation of receiving significant financial benefit and
had an awareness and understanding of the scale of the operation. Because it was street dealing, it was

Category 3 offending under the guideline with a starting point for an adult of four‑and‑a‑half years. The

judge increased that to five years to reflect the prolonged period of offending. He then reduced this by

one‑third to 40 months "in accordance with paragraph 6.4 of the youth sentencing guideline", as the judge

put it. After 25 per cent credit for his guilty pleas, the sentence for the class A offence was 30 months and
for the cannabis offence 12 months concurrent.

18. For the first affray the judge took a starting point for an adult of 24 months, as a Category 1A offence

under the relevant Sentencing Council guideline. He reduced this by one‑third to 16 months for the

appellant's youth. After a further 25 per cent reduction for the guilty plea the sentence was 12 months.
That was ordered to run consecutively to the sentence of 30 months for the drugs offences.

19. For the second affray, the judge concluded that for an adult the sentence after trial would have been

18 months, as a Category 2A offence under the guideline. He reduced that by one‑third for the appellant's

youth. After a further 25 per cent reduction for the guilty plea the sentence was eight months. That was
ordered to run concurrently to take account of totality.

20. In pronouncing sentence the judge said: "…therefore the total sentence will be one of 42 months as it's
a grave crime."

Was the sentence lawful?

21. Pausing there, we need to address a technical aspect of the sentences. We note that the judge did
not indicate the form of detention that he was imposing for the various different offences. His reference to
[a "grave crime" must, we take it, have been a reference to section 250 of the Sentencing Act 2020 which in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)
the case of a defendant under the age of 18 at the date of conviction permits the court to pass a sentence
longer than the maximum of two years for a detention and training order, provided the offence carries a
maximum sentence of at least 14 years. The drugs offences met this requirement but the offences of
affray did not. Any custodial sentence for the offences of affray could therefore only have been a detention
and training order.

22. We also note that the Crown Court recorded the sentences the judge imposed as detention in a young
offender institution. That was incorrect. The appellant was 17; such a sentence can only be passed on a
defendant who is over 18 at the date of conviction.


-----

23. We therefore pose the question: could the judge's sentence be interpreted as 30 months' detention
under section 250, with a consecutive sentence of 12 months' detention and training order? And if so,
would that have been a lawful sentence?

[24. Section 237(4) of the Sentencing Act 2020 permits the court to make a detention and training order run](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)
consecutively to an order for detention under section 250 in certain circumstances. However, as a matter
of construction, as it seems to us that power is open to the court only where the offender is already "subject
to" the section 250 sentence of detention, that is to say already actually serving such a sentence. It does
not, we think, entitle the court to pass a consecutive sentence of detention and training order on the same
occasion as imposing detention under section 250 for another offence. In the course of submissions we
raised this point with both counsel and our interpretation accords with theirs.

25. We therefore conclude that the purported sentence of 42 months "as a grave crime" (assuming that is
what the judge intended) was unlawful.

26.  It is well established that where a defendant falls to be sentenced for an offence or offences which
[qualify under section 250 of the Sentencing Act 2020 and for another offence or offences which do not, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)
court should pass a term of detention under section 250 commensurate with the seriousness of all the
offences on those (and only those) offences which do qualify; and the court should order no separate
[penalty on those which do not: see R v Robinson [2020] EWCA Crim 866, [2020] 2 Cr.App.R (S) 48.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60FM-MM73-GXFD-823C-00000-00&context=1519360)

The parties' submissions on the appeal

27. On behalf of the appellant, it is submitted that the individual custodial sentences were manifestly
excessive. In short, most of the drug dealing related to class B not class A drugs; the appellant's role in
both the affrays was peripheral; the custody threshold, it was said, was not met; if it was, consideration
should have been given to a youth rehabilitation order.

28. Mr Spary points out that information was not brought to the judge's attention in full which would have
been very important, namely the detail of a conclusive grounds decision under the National Referral
Mechanism ("NRM") in relation to the appellant's involvement in drug dealing. That decision had been

made on 16 August 2022. It was referred to in the pre‑sentence report which was before the judge and it

was referred to by Mr Spary in his sentencing note for the hearing. But no details had been obtained at
that stage. We note that the NRM decision was not referred to at all by the judge in his sentencing
remarks. Mr Spary has confirmed that is no suggestion that the NRM deceision would have afforded the
[appellant any defence to the drugs offences under the Modern Slavery Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

29.  However, Mr Spary submits that knowledge of the full circumstances of the NRM decision would have
caused the judge to think long and hard before assigning the appellant a "significant" role under the
guideline. We see the force in that point. His role would more properly have been assessed as "lesser"
bearing in mind that he was performing a limited function under direction, was engaged by pressure,
coercion, intimidation, grooming and/or control, and his involvement was through naivety, immaturity or
exploitation. These are all factors which could have been put forward more strongly had the full
circumstances of the NRM been revealed at that time.

30.  Mr Spary also relies on the addendum pre‑sentence report ordered by the Full Court at the last

hearing. The report highlights the immaturity of the appellant which is likely to have put him in a position

where he became vulnerable and liable to exploitation, with his decision‑making severely impaired by

those around and above him.

31. A further significant development since the appellant was sentenced has been the guidance given by
this court several weeks later in R v AZ [2023] EWCA Crim 596; [2023] 2 Cr.App.R (S) 45. That guidance
emphasises that when dealing with young offenders the court should not go straight to paragraph 6.46 of

the youth guideline, with its reference to two‑thirds of the adult sentence, without first considering the

general principles applicable to youth sentencing as set out in the various relevant guidelines. A stepped
approach is required. Custody should be regarded as a measure of last resort.


-----

32. On behalf of the Crown, Mr O'Donnell submits that the judge's categorisation of the individual offences
by reference to the guidelines cannot be faulted. He points out in his written submissions that the
addendum PSR is not positive in all respects. For example, the appellant is assessed as posing a high risk
of serious harm to members of the public and the NRM conclusive grounds decision reveals that the
appellant had been offending in relation to the supply of class A drugs some two years before the present
offending behaviour. We note that the appellant would have been only 14 or 15 years old at that time.

Discussion and conclusion

33. We begin by considering what the appropriate custodial sentence should have been if custody was
required. We think that in the light of the material which we now have but the judge did not have, in
particular the full details of the NRM conclusive grounds decision, the appellant's role in the drugs offences
should properly be regarded as "lesser" rather than "significant". Thus for an adult the starting point under

the guideline would be three years. The judge made a reduction of one‑third for the appellant's youth.

That is the suggested reduction in paragraph 6.46 of the youth guideline for the upper end of the age range
of 15 to 17. We note that although the appellant was 17 at the date of sentence, he was only 16 during the
period of the drugs offences. We also bear in mind that mostly the drug supplied was cannabis rather than
cocaine.

34.  Even adopting a reduction of only one‑third, that would bring the sentence down from three years to

two years. After a reduction of 25 per cent for the guilty pleas the sentence at most should have been 18
months. A period of only 18 months' custody would not justify a sentence of detention under section 250.
Mr O'Donnell in his oral submissions very properly conceded that. The period of such a sentence would
normally have to be at least two years, otherwise a detention and training order would be appropriate.

35. Turning to the offences of affray, for the reasons already explained the only available custodial
sentence was a detention and training order. The judge was right to make the sentences for the two
affrays concurrent on the grounds of totality. Accepting the judge's categorisation under the guideline and

his one‑third reduction for youth, the resulting sentence of 12 months in total would also be reduced

automatically by half the number of days spent on bail with a qualifying curfew. That takes place
automatically now even in the case of a detention and training order; 153 days fell to be deducted,
equating to about five months.

36. It is perfectly possible and lawful to pass consecutive sentences of detention and training order
[provided the aggregate does not exceed two years: see section 238(1) of the Sentencing Act 2020. On the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)
above analysis, if custody was inevitable, the total sentence of detention and training order should not have
been more than two years, i.e. 18 months for the drugs offences and six months consecutive for the
affrays.

37. Mr Spary confirmed in the course of submissions this morning that the appellant has now served the

equivalent of about 15 months in custody. He has actually served seven‑and‑a‑half months since

sentence. However on to top of that he would be entitled to the credit of five months or so that we have
already mentioned for time spent on bail on a qualifying curfew. If we were to allow the appeal and
substitute a total sentence of detention and training order of two years, he would have very little if any of
the sentence left to serve.

38. Notwithstanding this, we have considered very carefully whether a more constructive course might
even now be appropriate. That would have to be on the basis that we were satisfied that the judge was

wrong in principle not to impose a non‑custodial sentence, or that a sentence of custody of two years

detention would still be manifestly excessive.

39. We are grateful to the court's liaison probation officer Ms Tracey Coggins for her very thorough

addendum pre‑sentence report. She describes the appellant as "guarded" when she interviewed him; he

was reluctant to discuss the circumstances of the drugs offences in particular. She thinks this is in line with
continued fears on his part of potential recriminations. She has made very full enquiries into the NRM


-----

decision. From the information provided she is of the view that there is a direct link between the appellant's
current offending and his criminal exploitation. She reports that the appellant's behaviour in custody has
been inconsistent. There have been some positive reports but also some incidents of violence and rule
breaking. In her view this reflects the appellant's immaturity and a desire to gain status amongst his peers.
Overall she considers that he poses a high risk of serious harm to members of the public.

40. Because the appellant has now reached the age of 18, he will be supervised by the adult probation
service whenever he is released. Ms Coggins points out that had the appellant been sentenced to a youth
rehabilitation order when still 17, there would have been the opportunity of an intensive supervision and
surveillance order ("ISS"). That is no longer available.

41.  Instead, Ms Coggins has helpfully investigated and suggested a range of controls and interventions
that could assist in managing his risk in the community, if that were the path this court chose to follow
today. She notes that on release from custody he will be subject in any event to a criminal behaviour order
for a period of three years. That order was imposed by the judge at the sentencing hearing and there is no
appeal against it. The appellant will be able to return to live with his mother, who is entirely supportive and
has done her best to steer him away from criminal behaviour and bad company. His good relationship with
his mother and his grandfather is a protective factor. Ms Coggins notes that prior to sentence the appellant
had complied with a curfew for several months, as we have explained. She thinks that with the experience
of custody for the last seven and a half months there will be a greater incentive for the appellant to make
positive changes and there is a realistic prospect of rehabilitation.

42. On that basis, if the court felt able to take such a course she recommends a community‑based order of

a minimum of 12 months' duration with a rehabilitation activity requirement for up to 35 days, a trail
monitoring requirement and an electronically monitored curfew. She has discussed these requirements
with the appellant who assures her that he would comply with them, as does the appellant's mother.

43.  Ms Coggins suggests that if the appellant remains in custody, even for a much reduced period, the
same requirements could form part of his licence conditions on release.

44. We have considered carefully whether even at this stage a youth rehabilitation order might be the
appropriate resolution of this appeal. However, these offences plainly passed the custody threshold. They
were all serious offences, particularly the offences of being concerned in the supply of cocaine and
cannabis. We have considered whether the sentence should have been a youth rehabilitation order. We
are satisfied that it cannot be said that it was wrong in principle to impose a custodial sentence rather than
a youth rehabilitation order, nor would it be manifestly excessive to have imposed detention totalling two
years.

45. However, for the reasons we have explained already, the sentence of 42 months in total, if such a term
could lawfully have been imposed at all, was in our view manifestly excessive. The appropriate term would
have been a total of two years' detention and training order.

46. We therefore allow the appeal. We quash all the sentences of detention and impose instead the
following sentences: on count 1 of the drugs indictment we substitute a sentence of 18 months' detention
and training order; on count 2 of the drugs indictment we substitute a sentence of 12 months' detention and
training order, concurrent; for the first affray and the second affray on the two separate indictments we
impose a detention and training order of six months concurrently with each other, but that six months will
run consecutively to the 18 months on the drugs indictment, making a total of two years' detention and
training order.

47. We make it clear for the avoidance of doubt that the 153 days with which the appellant is entitled to be
credited(for the time he spent on an electronically monitored curfew whilst on bail should count towards
sentence. That ought to happen automatically but we think it appropriate to spell it out.

48. We express the hope that, particularly if the appellant is to be released very soon, Ms Coggins'
suggestion will be followed that licence conditions should be imposed mirroring the requirements she


-----

suggested in her report in the event of a youth rehabilitation order being made. We hope that will be
possible.

49. Finally, we should say that we sympathise with the judge in having to deal with so many defendants,
including other very young defendants, under the pressure of time created by shortage of court space and
time, with the inevitable result that he was not able to focus so sharply on the particular circumstances of
this appellant, hampered as he was too by a lack of full information in relation to the NRM decision.

50.  Applying the guidance in R v AZ, this was a sentencing hearing which cried out for the provision of
comprehensive detailed sentencing notes by prosecution and defence to ensure that the judge was given
all possible assistance in the necessary stepped approach to the youth guideline, and in the technicalities
of the available sentences. On behalf of the appellant, Mr Spary did provide a sentencing note although,
very properly, he accepts that he had not addressed all the relevant issues as fully as he might have done.
Mr O'Donnell has explained and apologised for the absence of a sentencing note and we understand the
difficulty he faced as the sentencing hearing came on at short notice after a very long period of delay, as is
evident from the expressions of concern by the judge on the same point in the course the hearing. Again,
emphasising the guidance in R v AZ, this case illustrates the problems that can arise if, for whatever
reason, insufficient time is allowed for such a complex sentencing hearing.

51. LORD JUSTICE EDIS: I think Tracey Coggins is still online.

52. Ms COGGINS: Yes, I am, my Lord.

53. LORD JUSTICE EDIS: Thank you. Now Mr Kovalkov I want you to listen, and Mr Spary I hope you
will be able perhaps to speak with him after we have risen. Mr Kovalkov, I do not know when you are
going to be released but I suspect it will be quite soon. When you are released you will be subject to
supervision and terms of a licence for the rest of your sentence. You will have to report to a probation
officer in Ipswich either on the day when you are released or by no later than 10 o'clock in the morning on
the day after you are released. I think it will probably take you about four hours to get from Cookham
Wood to Ipswich by public transport if that is how you are travelling. If you can get there on the day of your
release you must. If you cannot, then you must be there by 10 o'clock the following day.

54. The person you need to speak to is called Kaz Alvous. She is to be found at Peninsula House which

is in Lower Brook Street in Ipswich, that is 11‑13 Lower Brook Street, Ipswich, Suffolk IP4 1AQ. There is a

telephone number as well. I will not read that out to you. What I am hoping can happen is that perhaps Ms
Coggins can email the prison or the detention centre where you are held so that you will have that phone
number to make an arrangements to meet Kaz Alvous. The purpose of this is so that the terms of your
licence and the requirements attached to your supervision can be carefully explained to you because you
have to comply with those. In the end if you do not or if you commit offences while you are still subject to
this sentence you can find yourself serving the rest of it in detention. So it is very important for you that
you understand what is required of you and that you comply with it.

55. I just want to check with Tracey Coggins that I have correctly explained what needs to happen to him.

56. Ms COGGINS: My Lord, yes you have. But in any event, as it is now going to be a licence rather than
an immediate release, the appellant will be given a full copy of his licence conditions and reporting
instructions before he leaves the prison.

57. LORD JUSTICE EDIS: Thank you. Very well. You have heard that. You will get a document which
will tell you precisely what it is and then you will need to make contact with the probation service. So you
do what it says on the document. It is very important for your future, really important for your future, that
you do take advantage of the help you are going to get to stay away from criminality. I hope you have
understood all of that. Thank you both.

**End of Document**


-----

