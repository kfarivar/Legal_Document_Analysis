(Admin)

# R (on the application of O and others) v Secretary of State for the Home
 Department [2020] EWHC 1243 (Admin)

Queen's Bench Division, Administrative Court (London)

Swift J

28 April 2020Judgment

**TRANSCRIPT OF JUDGMENT**

MR JUSTICE SWIFT:

1 On 17 April 2020, the three claimants in this case, each of whom was subject to immigration detention
pending removal from the United Kingdom, filed a claim to the effect that their detention was unlawful.
They also filed applications for interim relief, seeking orders for immediate release from detention. Those
applications for interim relief now come before me.

2 The applications made by the first and second claimants have been overtaken by events. The Secretary
of State has agreed to release the first claimant and also the second claimant, those decisions being taken
on 22 April and 24 April respectively. For that reason, their applications for interim relief are no longer live
and I am not asked to make any orders in respect of those claims. May I just say this in relation to those
claims by way of observation. If they are claims that continue in any form, it seems to me that they are
most likely to continue as claims for damages for unlawful detention. If they do continue in that form, it
seems to me almost inevitable that the appropriate venue for those claims should be the County Court. I
understand the parties are seeking to agree directions in relation to those claims and I hope they will be
able to do so in short order.

3 The third claimant remains in detention and the application for interim relief is pursued in her case. She
has been in detention since 23 January 2020. Yesterday, the defendant undertook a further review of her
detention and concluded that it should continue for a further 28 days. Although that decision post-dates
the issue of these proceedings and the applications for interim relief, it is agreed by all concerned that it is
that decision that should be the focus of attention in this application to determine whether or not an order
should be made requiring the release of the third claimant pending determination of her claim.

4 The outcome of this application for interim relief depends on the application of the well-known American
_Cyanamid principles, subject to appropriate modification for the public law context: see the judgment of_
Cranston J in _Medical Justice, R (on the application of) v Secretary of State for the Home Department_

_[[2010] EWHC 1425 (Admin). The claimant must show a real prospect of success at trial, that is to say a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_
real prospect that at trial she will succeed in obtaining an order in the form that is now sought by way of
interim relief, an order for release. If such real prospect exists, the order requested as interim relief must
be the preferable option on the balance of convenience, that balance of convenience taking account of the
public interest in the operation of an effective system of immigration control. It is also the case that since
the relief sought in this application may well be, for all practical purposes, a form of final relief, and since
the order sought is also in the form of a mandatory order, the claimant must demonstrate a particularly
strong case on the merits before the possibility of an interim order arises.

5 The claimant is detained pending deportation from the United Kingdom to Greece. She is 23 years old.
She is a Greek national She came to the United Kingdom in December 2017 and worked as a member of


-----

(Admin)

cabin crew on commercial passenger flights. In April 2018, she was kidnapped, held hostage and sexually
assaulted. This traumatic experience led to profound changes in her life. She became addicted to drugs.
During 2019, she was convicted on five occasions in respect of some 12 criminal offences. On 30
December 2019, she was convicted by magistrates on a charge of possession of a Class A drug; she was
sentenced to seven weeks' imprisonment.

6 A deportation order was made on 13 February 2020. Prior to that, on 23 January 2020, the claimant had
been detained under Immigration Act powers, pending removal. On 2 April 2020, the Secretary of State
gave notice of deportation arrangements for the claimant's return to Greece by plane on 5 May 2020. The
claimant remains at Yarl's Wood IRC. There, she occupies a room on her own. She explains in her
statement that her room has shower and WC facilities. She further explains that she leaves her room only
to collect meals from the canteen. She then returns to her room to eat those meals.

7 The legality of the claimant's detention depends both on the existence of a legal basis for that detention
and on whether maintaining detention is consistent with the Secretary of State's policies as to how she will
exercise the powers to detain that are available to her. In this application, the claimant does not question
the legal basis for her detention. She does not submit that her detention is unlawful on the basis of the
well-known Hardial Singh principles. Rather, her submission is that her detention is unlawful because it is
contrary to the Secretary of State's statements of policy as to when she will exercise her power to detain.

8 The Secretary of State's policy on use of immigration detention powers starts with Chapter 55 of the
Enforcement Instructions and Guidance. Chapter 55 refers to a general approach of a presumption in
favour of bail rather than detention unless detention is required to effect removal or there are reasons to
believe that the person concerned would not comply with bail conditions. Chapter 55 also refers to various
special cases. One such is that of persons falling within the Secretary of State's “Adults at Risk” Policy.
Adults at Risk are persons assessed by the Secretary of State to be particularly vulnerable to harm if in
detention. The Secretary of State's policy is that for this class of person the usual presumption against
detention is strengthened. The Adults at Risk Policy lists classes of person who may be particularly
vulnerable to harm if detained. For present purposes, these include persons who are potential victims of
**_modern slavery, persons who may, in the past, have suffered torture and persons suffering from serious_**
illness or health conditions. Further guidance on the scope of this particular category has been given in the
specific context of the present COVID-19 pandemic so as to capture those who would be at increased risk
of serious harm were they to contract COVID-19. This includes persons with chronic heart disease.

9 Is there a real prospect that the claimant will succeed at trial on her submission that her detention is
unlawful as in breach of any material part of the Secretary of State's policies?

10 First, the claimant's position as a potential victim of modern slavery. In 2018, the claimant made a
claim to the National Referral Mechanism (“NRM”) that she had been a victim of **_modern slavery by_**
reason of what had happened to her in 2018. She received a positive reasonable grounds decision from
the NRM but then absented herself from the process, resulting in a negative conclusive grounds decision
by the NRM on 8 August 2018. On 6 April 2020, the solicitors now acting for the claimant wrote to the
NRM requesting reconsideration of that decision. It is agreed by the parties that a message from the NRM
dated 15 April 2020 does mean that the NRM has agreed to reconsider its negative conclusive grounds
decision and that that reconsideration is now in progress. The claimant submits that this means she
should be treated as if she is a person in receipt of a positive reasonable grounds decision, a submission
[that seems to me to be consistent with para.14.229 of the Modern Slavery Act 2015 Statutory Guidance.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

11 The Adults at Risk Policy states that whether persons who are the subject of a positive reasonable
grounds decision should be detained should be decided on the basis of guidance given in the statutory
guidance on the Modern Slavery Act. That guidance, however, is largely silent on the matter of detention.
The only reference seems to be at para.15.249 of Annexe F to the Guidance, where it is said that there is
no requirement to release from detention if there are reasons of public order not to do so. The reference to
public order picks up language used in Article 13 of the Council of Europe Convention on Action Against
Trafficking in Human Beings, although that Article deals not with detention but rather with the


-----

(Admin)

circumstances in which states may remove a person from its territory notwithstanding that it is believed that
they may be a victim of modern slavery. It is unfortunate that the present Statutory Guidance in relation
to the Modern Slavery Act deals with detention only in such an oblique way.

12 I have been shown the judgment of the Court of Appeal in TT (Vietnam) v Secretary of State for the
_Home Department_ _[2019] EWCA Civ 248, where the court considered an earlier version of the Statutory_
Guidance which set out the position on detention in more detail and in the main body of the guidance,
rather than an annexe. I cannot help but suspect that this specific policy “ball” was dropped somewhere
between the EIG and the Modern Slavery Act Statutory Guidance. Be that as it may, and focusing on the
27 April 2020 detention review document, I am satisfied that, on the facts of this case, there is a real
prospect at trial that the claimant will demonstrate that her detention is contrary to this part of the Secretary
of State's policy and therefore unlawful.

13 Mr Manknell, counsel for the Secretary of State, has taken me to the judgment of the Court of Appeal in
_TT and, in particular, to para.46, para.54 and para.58 to 60. Based on those passages, I accept that_
matters such as a risk of absconding or a risk of reoffending are matters that can make good an argument
that the public order criterion for maintaining detention is made out. In this case, those matters have been
formally assessed in the most recent detention review as “medium” and “high” respectively. This is by
reference to the boxes that are ticked on that form. I recognise that on the facts in _TT, where similar_
rankings were in issue, the court concluded that the public order basis for detention was present. But in
doing so, it is apparent that the court looked at the substance of the position, not simply looking to which
boxes had been ticked on the pro-forma document. Looking at the substance in this case, the risk of
absconding does not recognise that if released the claimant would, as a person with the benefit of a
positive reasonable grounds decision under the NRM, have the benefit of accommodation and financial
support until such time as the reconsideration process is complete. As to the risk of reoffending, the
offences that the claimant did commit, as I have said, 5 convictions for 12 offences in the course of 2019,
were the consequence of her drug addiction, itself a consequence of being out of accommodation. The
claimant has now completed a programme of Methadone treatment and if released her status in the NRM
would mean that accommodation would be available to her.

14 I also take account of the time likely now to pass before the reconsideration decision is made. I am told
that the NRM has not yet allocated the case to a case worker and will not do so until some point next week.
Thereafter, that person will need to decide what steps need to be taken and how to take them. In present
circumstances, that is to say the severe restrictions on movement and so on that have been put in place in
order to combat transmission of COVID-19, it does not seem to me that any of those matters that the NRM
will need to address are likely to happen quickly.

15 The Secretary of State suggests that a “wait and see” approach on this point is appropriate. The
decision taken in the most recent detention review document is a decision to maintain detention for a
further 28 days. If, as time passes, it becomes apparent that the reconsideration process will require an
extended period, then, says the Secretary of State, either she would be able to review the matter again or
the matter could be brought before the court again, either by way of a further application for interim relief or
a bail application. While I can see some force in that submission, I am satisfied that on the facts of the
present case it is tolerably clear now that the NRM process is likely to take some time. It is then a matter
that feeds into the assessment of the claimant's likely prospects of success. I have taken this into account
as Mr Manknell accepted that as a matter of policy this would be a relevant consideration for the Secretary
of State.

16 I mentioned earlier the lack of any clear statement of policy relating to the approach to the detention of
persons who are the subject of positive reasonable grounds decision. The point accepted by Mr Manknell,
entirely correctly as it seems to me, about the relevance of the likely duration of detention, is not a matter
that is addressed anywhere on the face of any policy relating to the exercise of the power of detention
when it comes to person who are the subject of positive reasonable grounds decision. This seems to me
to be simply an example of why it would be beneficial for the Secretary of State to set out her policy on this
aspect of the use of her detention powers in one place in a way that is comprehensive in the same way as


-----

(Admin)

she has already done when it comes to the remainder of the classes of persons falling within the Adults at
Risk Policy.

17 The second matter is the claimant's submission by reference to her contention that she is a victim of
historic torture. The Adults at Risk Policy is to the effect that in the circumstances of this case, where there
is objective information in the form of scarring to support the claimant's claim to have been tortured, this
brings her into what is described as Evidence Level 2 under the Adults at Risk Policy. The policy provides
that in such instances a person should be considered for detention only if removal would take place within
a reasonable timescale or that there were public protection concerns or that there is evidence of past noncompliance with immigration control or other relevant court orders. As I see it, the first of those possible
matters is relevant here.

18 Had this basis of challenge stood alone and had the basis of challenge based on the claimant's position
within the NRM not existed, I would not have concluded that this ground of challenge gave rise to a real
prospect that the claimant would, at trial, make good a submission that her detention was unlawful for this
reason. In support of this part of her submission the claimant points to the fact that the detention review
refers to a proposed removal date to Greece of 5 May, when the evidence is that for now, there are no
direct commercial flights between the United Kingdom and Greece, and it is unlikely that there will be any
before 15 May 2020 at the earliest. Thus, says the claimant, the information on the detention review
document is in error.

19 I do not consider that this matter is sufficient to make out a case to the required standard. Whether
such a case exists must depend on the likelihood that the substantive decision to maintain detention will be
found to be unlawful, even though removal will not take place on 5 May. Removal would, but for the
matters I have already mentioned relating to the NRM reconsideration process, have taken place within a
reasonable timescale, or at least that was still likely to be the position. The effects of the COVID-19
pandemic have been severe in many European countries. The date for the claimant's removal certainly
could not be stated with certainty. However, I accept that when those circumstances change the Secretary
of State would remove the claimant from the UK, again now subject to the conclusion of the NRM process.
That event would, no doubt, be more distant than originally envisaged. It would certainly not take place on
5 May 2020. But nevertheless, it remains an event that would take place within a reasonably proximate
period of time. Although there are restrictions on international travel presently in force, there is no
suggestion for now that those restrictions will be in force indefinitely. Again, then, for that reason I would
not conclude that the claimant's present detention was likely to be found unlawful on the basis that her
detention was at odds with her contention to be within the Adults at Risk Policy on the basis that she is a
victim of torture.

20 The third basis on which the claimant contends that her detention is contrary to the Secretary of State's
policy is on the basis of serious ill-health. Various claims have been made about the claimant's health.
The one that is pursued before me is contained in a letter dated 6 April 2020 from her solicitors, which
states that the claimant suffers from mitral valve prolapse, a condition that affects the proper functioning of
her heart. The letter stated that, while living in Greece and for some time while she was living in the United
Kingdom, the claimant was prescribed medication for this condition which appears to result in episodes of
hypertension. The detention review document refers to the fact that the claimant mentioned no such
condition either while in prison or on arrival in detention. It appears that the claimant's blood pressure and
pulse were measured on her arrival at Yarl's Wood and were found to be normal.

21 The claimant's submission is that the Secretary of State has failed to take sufficient steps to look into
the heart condition the claimant claims to suffer from. For example, no steps to undertake regular
measurement of the claimant's blood pressure or pulse, and no steps to undertake any other suitable
medical examination that might assist in identifying whether the claimant falls within a class of persons at
increased risk of serious harm in the event that they were to contract COVID-19.

22 It is apparent that since 6 April 2020 the claimant has visited the health centre on a number of
occasions. There is no record of any examination or test to determine whether the claimant has the heart


-----

(Admin)

condition claimed or symptoms of it. The response to the 6 April letter I am told is in the form of a note on
the claimant's medical file made on 14 April which reads as follows:

“No entry in YW or prison records during any health screening with doctor or nurse of any heart
condition/mitral valve prolapse. Has informed healthcare re history of lymph node swelling in past.
Investigated in Greece one year ago. Advised to monitor. Pulse and BP checked on arrival. No
indication/reason to have rechecked since then. Has been seen in healthcare last month for mental health
review and substance misuse clinics and sexual health nurse.”

23 The Secretary of State has provided no further evidence to explain why further steps or, it would
appear, any steps need to be taken to investigate the presence or not of a condition which, if it exists,
seems to be common ground would be a condition giving rise to an increased risk of harm were the
claimant to contract COVID-19. It seems to me that further steps could and should have been taken and
perhaps now those steps should be taken to investigate whether the claimant does suffer from mitral valve
prolapse. That is something I consider the Secretary of State should do. But I do not consider that the
Secretary of State's failure to take those steps so far is a matter that goes to the legality of the claimant's
detention or gives rise to a real prospect of success that on this ground she would succeed at trial in
demonstrating that her detention is now unlawful.

24 If the claimant does suffer from the heart condition she has described, it is highly likely, given the terms
of the Adults at Risk guidance, as supplemented to take account of the potential effects of COVID-19, that
the claimant would be released because her case would fall within the Evidence Level 3 category in that
policy. If she does not have that condition, her circumstances would fall within Evidence Level 2 and the
situation in respect of this argument would be materially the same as the situation I have described on the
basis of the grounds that the claimant is within the category of victims of torture.

25 All this being so, I consider the Secretary of State should take reasonable steps as soon as possible to
determine whether the claimant falls within either evidence level 2 or evidence level 3 of the Adults at Risk
Policy for this reason. This is not, however, a matter that I consider goes to the legality of her detention.

26 Balance of convenience. My conclusion on the balance of convenience is heavily influenced by the
fact that the claimant only seeks an order for release if and to the extent that the Salvation Army, in
performance of its obligations as part of the NRM machinery, will provide accommodation for her pending
reconsideration of the negative conclusive grounds decision. That condition, together with such reporting
conditions as the Secretary of State may think appropriate, in my view mitigate the risks arising from
release, that is to say the risk of absconding and the possible risk of reoffending. It was the claimant's
chaotic life without accommodation, as it seems to me, that drew her into offending. If released, it will be
with the benefit of the accommodation and support provided to those with favourable positive reasonable
grounds decisions within the NRM process.

27 I therefore consider that the balance of convenience favours an order requiring the claimant's release
from detention subject to regular ordinary reporting conditions and subject also to a condition that she is
not released until such time as accommodation from the Salvation Army is available for her occupation.

**End of Document**


-----

