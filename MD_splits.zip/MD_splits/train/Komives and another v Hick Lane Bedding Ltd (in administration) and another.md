# Komives and another v Hick Lane Bedding Ltd (in administration) and
 another [2021] EWHC 3139 (QB)

Queen's Bench Division

May J

24 November 2021Judgment

Jeffrey Jupp and James Robottom (instructed by Anti-Trafficking and Labour Exploitation Unit) for the Claimants

Geoffrey Brown (instructed by Kennedys) for the Second Defendant

Hearing dates: 15 October 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

**Mrs Justice May DBE :**

**Introduction**

1. This is an appeal from the decision of Master Davison following a trial of preliminary issues in March
2020. The issues were directed at determining whether the claimants, here the appellants, were entitled to
recover pursuant to rights conferred under the Third Party (Rights against Insurers) Act 1930 (“the 1930
Act”) on an Employers' Liability insurance policy issued by the second defendant, here the respondent
(“ATE”), in favour of the first defendant (“HLB”) for the year 2011-2012. The Master determined that as
ATE had been entitled to avoid the policy, and had reasonably done so, the claimants' claim was bound to
fail. I set out the particular preliminary issues, and the specific answers which he gave, in more detail
below.

2. I have been greatly assisted on this appeal by the excellent written and oral submissions of counsel –
Jeffrey Jupp and James Robottom for the appellants and Geoffrey Brown for the respondent. I am grateful
to them all.

**Facts**

3. I take the following summary from the Master's clear and helpful judgment.

4. The appellants were trafficked into the UK by two men named Janos Orsos and Ferenc Illes. Orsos
and Iles sent the appellants and others to work, in conditions amounting to **_modern slavery, at HLB, a_**
company owned by Mohammed Rafiq. HLB had been a reputable business, with a substantial workforce
of regular employees but Rafiq decided to supplement his staff with cheap trafficked labour, supplied to
him by Orsos and Illes. Rafiq, Orsos and Illes were subsequently arrested, tried and convicted for their
parts in the trafficking and forced labour of the appellants and others.


-----

5. The first appellant, Mr Komives, worked at HLB from summer 2009 to October 2013. The second
appellant, Mr Varhelyi, worked there from January 2009 to June 2013. Both were brutalised by their slave
masters and suffered psychiatric injury but in addition Mr Varhelyi was badly injured by an accident at work
which occurred on or around 23 May 2012. The forks on a forklift truck which he was driving failed,
causing a large and heavy industrial bin to fall onto his left leg. This injury which he sustained ultimately
resulted in Mr Varhelyi having to undergo a below-knee amputation.

6. HLB went into administration on 9 June 2015 and is insolvent. However, during the period 12 July 2011
to 11 July 2012, HLB had employers' liability insurance with ATE (“the EL policy”). Accordingly the
appellants sought to make a claim on the EL policy, exercising their rights under the 1930 Act, for the
injuries they suffered at work during the period of cover.  But by letter dated 22 March 2018 ATE purported
to avoid the EL policy ab initio on the ground of material non-disclosure and/or misrepresentation on the
part of HLB or its brokers at the time of placing the cover. Having avoided the policy ATE rejected the third
party claims of the appellants brought under the 1930 Act.

**Preliminary issues**

7. Letters of claim on behalf of the claimants were sent to ATE on 30 August 2017 and 18 January 2018.
Claim forms were issued on 31 October 2017 (Mr Varhelyi) and 11 December 2017 (Mr Komives). As
indicated above, the letter from ATE avoiding the policy was dated 22 March 2018. ATE thereafter filed a
defence denying any liability to the appellants.

8.  By a case management order dated 10 December 2018 the Master ordered a trial of four preliminary
issues as follows:

(1) Whether ATE was, and/or is entitled to avoid the policy of insurance issued by it in favour of HLB on
the grounds of material non-disclosure and/or misrepresentation as pleaded in the defence of ATE;

(2) If so, whether the policy had been validly avoided by reason of the above;

(3) Whether Mr Komives and/or Mr Varhelyi have a valid claim against ATE under the 1930 Act;

(4) If so, whether there is a right of indemnity under the policy in connection with the claimants' claims for
breach of contract quantum meruit, conspiracy by unlawful means, intimidation and/or harassment, and/or
in respect of any such claim not arising from bodily injury occurring during the period of insurance and or in
respect of the claimants' claims for aggravated damages.

9. At trial the Master heard factual evidence from James Carroll, an underwriter at ATE, although it had not
been Mr Carroll who wrote the EL policy itself. There were no witnesses with direct experience of how and
on what information the EL policy came to be placed, although there was documentary evidence produced
of contemporaneous reports and surveys. The Master heard expert evidence on underwriting and broking
matters from Miles Emblin instructed by ATE and Roger Flaxman for the claimants.

10. By his judgment, the Master answered the preliminary issues as follows (1) Yes, (2) Yes, (3) No and
(4) N/A. Accordingly he dismissed Mr Komives' and Mr Varhelyi's claims against ATE.

11. By his order dated 14 June 2021 Stewart J granted permission to appeal the Master's decision.

**Grounds of Appeal**

12. There is no challenge to the Master's findings of fact nor to his finding that (at least so far as HLB was
concerned) ATE was entitled to avoid the EL policy on grounds of non-disclosure and/or misrepresentation.
Instead Mr Jupp, for the appellants, argues that the Master erred in his approach to the interpretation and
application of rule 8.1.1(3) of the Insurance Conduct of Business Sourcebook (“ICOBS”) (set out at [24]
below) as follows:

(1) The question of whether ATE acted unreasonably in avoiding the policy should be assessed objectively
and not, as the Master did, viewed solely from the insurer's perspective.


-----

(2) The Master wrongly conflated the reasonableness test with the established grounds for avoidance
under insurance contract law.

(3) The Master erred in failing to regard the fact that insurers had made scant enquiries prior to placing the
cover as relevant to the reasonableness of avoidance.

(4) The Master further erred by failing to take into account; (a) the statutory scheme for the protection of
employees introduced by the Employer Liability (Compulsory Insurance) Act 1969 (b) the nature and
circumstances of the appellants' injuries which fall under the protection intended by the statutory scheme
(c) the fact that the appellants did not know and had no reason to know of the material nondisclosure/misrepresentation made by HLB (d) the effect of HLB's conduct on the appellants and (e) the
circumstances of the appellants as trafficking victims.

**The legal background**

_Avoidance for non-disclosure and/or misrepresentation_

13. As is well-known, a contract of insurance is a contract of the utmost good faith, engaging strict
obligations on the insured to make full disclosure of all matters material to the risk which is to be covered.
If, after the contract of insurance has been placed, insurers discover matters which should have been
disclosed but were not, or if it becomes clear that material aspects of the risk were misrepresented, then
insurers may have a right to avoid the policy. If the contract is avoided then it is as if it never existed.

14. The two-stage test which insurers must satisfy in order to avoid a policy is set out by the House of
Lords in Pan Atlantic Insurance Co Ltd v Pine Top Insurance Co Ltd [1995] AC 501:

(1) That the particular facts misrepresented or not disclosed would have influenced the mind of a
reasonably prudent underwriter in exercising his underwriting judgement as to whether to write the risk (per
Lord Mustill at 550C and Lord Goff at 517E), and

(2) That the underwriter who agreed the risk was induced to do so by the facts misrepresented or not
disclosed (per Lord Mustill at 550D and Lord Goff at 517E)

15. As Mr Brown pointed out in argument, the law relating to non-disclosure and avoidance has been
given considerable legislative attention in recent years, particularly in relation to consumers. The
Consumer Insurance (Disclosure and Representation) Act 2012 (“the 2012 Act”) and the _[Insurance Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5F9R-2V51-DYCN-C47V-00000-00&context=1519360)_
_[2015 (“the 2015 Act”) have introduced important limitations on an insurer's right to avoid, for instance in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5F9R-2V51-DYCN-C47V-00000-00&context=1519360)_
relation to non-negligent misrepresentations made by consumers or facts that a consumer policyholder
could not reasonably have been expected to disclose.

16. It is to be noted that the policyholder in this case, HLB, was not a consumer but a commercial entity,
also that the EL policy upon which the appellants' claim is based pre-dated the coming into force of the
legislative amendments referred to above.

_Employer's Liability Insurance_

17. The _[Employers' Liability (Compulsory Insurance) Act 1969 (“the 1969 Act”) made it compulsory for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1FB-00000-00&context=1519360)_
employers to take out insurance covering incidents of liability to their employees, for instance through
accidents at work. Under regulations made pursuant to section 1(2) of the 1969 Act insurers are obliged to
issue, and employers to display in the workplace, a certificate of Employers' Liability Insurance.

18. The limitations of the scheme in circumstances where the contract is avoided by reason of the
employer's non-disclosure/misrepresentation were highlighted as long ago as 1985 in the case of Dunbar v
_AB Painters Ltd [1985] 2 QB 616where, at first instance, Mr Pratt QC, sitting as a deputy High Court judge,_
remarked as follows:

“I have to say in passing that repudiation by insurers in such circumstances as these has caused this Court
to be deeply concerned. It seems that it is, in effect, driving a coach and horse through the provisions of
the [1969 Act]…It is now apparent that that certificate was not worth the paper on which it was printed. It is
diffi lt t h th l i tiff f hi k t ld h f d th t t d it i t i l


-----

arguable that they would be entitled to assume that their employers and, therefore, they were properly
covered in respect of injury and damage. In reality the certificate issued by Economic and displayed by the
defendants was a snare and a delusion”

On appeal, Balcombe LJ referred to the above passage, sharing the concern expressed by the judge

[1986] 2 Lloyd's LR 38 at 44.

19. Regulation 2 of The Employers' Liability (Compulsory Insurance) Regulations 1998 (“the 1998
regulations”) prohibits an employer's liability insurance from containing any condition which provides that
no liability (either generally or in respect of a particular claim) shall arise under the policy, or that any such
liability so arising shall cease if:

_( a) some specified thing is done or omitted to be done after the happening of the event giving rise to a_
_claim under the policy;_

_(b) the policy holder does not truce reasonable care to protect his employees against the risk of bodily_
_injury or disease in the course of their employment;_

_(c) the policy holder fails to comply with the requirements of any enactment for the protection of_
_employees against the risk of bodily injury or disease in the course of their employment.; or_

_(d) the policy holder does not keep specified records or fails to provide the insurer with or make available_
_to him information from such records._

It is to be noted that these restrictions do not go so far as to prevent an insurer from relying on an
employer's non-disclosure/misrepresentation to avoid the policy. As the Master identified in his judgment
(at [21-22]) the statutory scheme for employer's liability insurance provides considerably less protection in
this respect than the scheme for motor insurance.

_Third party rights against insurers_

20. The rights of third parties to claim directly under a liability policy, upon the bankruptcy/insolvency of the
insured policyholder, was first introduced by the Third Party (Rights against Insurers) Act 1930 (“the 1930
Act”). The 1930 Act effected a statutory subrogation, by virtue of which a third party was entitled to
exercise the rights of the insured as against the insurer. Insurer's rights remained unaffected, accordingly
if the insurer had a defence against the insured, for instance a right of avoidance for
misrepresentation/non-disclosure, it remained good as a defence to a claim by the third party.

21. The 1930 Act has now been replaced by the Third Party Rights Against Insurers Act 2010 (“the 2010
Act”). The 2010 Act removes certain procedural obstacles found in the provisions of the 1930 Act, for
instance the requirement under the 1930 Act for a struck off company to be revived in order to be added as
a party, but the broad effect of the scheme - placing the third party into the shoes of the insured under a
statutory subrogation – remains unchanged.

22. The appellants' claim in the present case is brought under the 1930 Act since the EL policy and any
liability arising under it pre-dates the coming into force of the 2010 Act.

_Insurance Conduct of Business Sourcebook (ICOBS)_

23. Under s.137A of Part 9A of the Financial Services and Markets Act 2000 (“FSMA”) the Financial
Conduct Authority (“FCA”) is given power to make rules applying to “authorised persons” with respect to
“regulated activities”. Insurers are authorised persons and underwriting is a regulated activity under FSMA.
The FCA has accordingly made rules governing insurer's conduct which are set out in ICOBS.

24. Part 8 of ICOBS, entitled “Claims Handling”, contains the following provisions:

_“ 8.1.1R_ _An insurer must:_

(1) handle claims promptly and fairly;


-----

(2) _provide reasonable guidance to help a policyholder make a claim and appropriate information on its_
_progress;_

_(3)              not unreasonably reject a claim (including by terminating or avoiding a policy); and_

_(4)              settle claims promptly once settlement terms are agreed._

**_Cases where rejection of consumer's claim is unreasonable:_**

**_contracts before 1 August 2017_**

**_8.1.2R_** _For contracts entered into or variations agreed before 1 August_
_2017, a rejection of a consumer policyholder's claim is unreasonable, except where there is evidence of_
_fraud, if it is :_

_(1)              in relation to contracts entered into or variations agreed on or before 5 April 2013, for:_

_(a) non-disclosure of a fact material to the risk which the policyholder could not reasonably be expected to_
_have disclosed; or_

_(b) non-negligent misrepresentation of a fact material to the risk; or_

_(2) in relation to contracts entered into or variations agreed on or after 6 April 2013, for misrepresentation_
_by a customer and the misrepresentation is not a qualifying misrepresentation (see ICOBS 8.1.3R); or_

_(3)              for breach of warranty or condition unless the circumstances of the claim are_
_connected to the breach and unless (for a pure protection contract):_

_(a) under a 'life of another' contract, the warranty relates to a statement of fact concerning the life to be_
_assured and, if the statement had been made by the life to be assured under an_

_'own life' contract, the insurer could have rejected the claim under this rule; or_

_(b) the warranty is material to the risk and was drawn to the customer's attention before the conclusion of_
_the contract_

**_Cases where rejection of consumer's claim is unreasonable:_**

**_contracts on or after 1 August 2017_**

**_8.1.2A_** _(1)              Cases in which rejection of a consumer's_
_claim would be unreasonable_

_(in the FCA's view) include, but are not limited to rejection:_

_(a) for misrepresentation, unless it is a qualifying misrepresentation_

_(see n ICOBS 8.1.3R);_

_[(b) where the claim is subject to the Insurance Act 2015, for breach of warranty or term, or for fraud, unless](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5F9R-2V51-DYCN-C47V-00000-00&context=1519360)_
_[the insurer is able to rely on the relevant provisions of the Insurance Act 2015; and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5F9R-2V51-DYCN-C47V-00000-00&context=1519360)_

_(c) where the policy is drafted or operated in a way that does not allow the insurer to reject._

_[(2)              The Insurance Act 2015 sets out a number of situations in which an insurer may have](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5F9R-2V51-DYCN-C47V-00000-00&context=1519360)_
_no liability or obligation to pay. For example:_

_(a) section 10 provides situations in which an insurer has no liability under a policy due to a breach of_
_warranty;_

_(b) section 11 places restrictions on an insurer's ability to reject a claim for breach of a term where_
_compliance is aimed at reducing certain types of risk; and_

_(c) sections 12 and 13 provide for the extent to which a firm is entitled to reject fraudulent claims._

24. The rule at which arguments on this appeal have particularly been directed is ICOBS rule 8.1.1(3)
above (“rule 8.1.1(3)”).


-----

**The parties' arguments**

25.  Mr Jupp, for the appellants, addressed his Grounds 1 and 2 together. He began by pointing to the
FCA's “operational objectives”, set out at section 1B(3) of FSMA, in particular the “consumer protection
objective”. The meaning of “consumer” at section 1G of FSMA includes “persons who have relevant rights
or interests in relation to the services”, which indicates, Mr Jupp argued, that the rules which the FCA
makes are not only there to protect people who take out insurance but also those who have acquired rights
or interests derived under such contracts.

26. Bearing this in mind and turning to rule 8.1.1(3), Mr Jupp submitted that this rule is not restricted to a
claim brought by the policyholder but also covers persons who, like the appellants, make a claim on a
policy under the 1930 Act. He pointed to the absence of the word “policyholder” from rule 8.1.1(3).

27. Mr Jupp accepted that if HLB had sought to make a claim on the EL policy then ATE could properly
and reasonably have rejected it on the basis that they ATE was entitled to avoid the policy. But the
position changed, Mr Jupp maintained, once ATE became aware of claims being made by trafficked
workers; ATE knew of such claims before avoiding the policy. Mr Jupp submitted that by the time ATE
came to avoid, the trafficked victims had stepped into the shoes of the insured at which point ATE was
obliged to look not at the position of the policyholder but at the position of the workers who were
subrogated to the claim under the 1930 Act. By that time, an avoidance which would have been
reasonable vis a vis HLB had become unreasonable when meeting a claim by these appellants. Mr Jupp
referred to the case of Total Graphics [1997] 1 Lloyds LR 599 in support of his argument that a claim may
continue to be maintainable by a third party in circumstances where a claim by the policyholder would fail.

28. Pointing to the context of mandatory requirements introduced by the 1969 Act and subsequent
regulations, taken together with the concerns expressed in Dunbar, Mr Jupp submitted that by the ICOBS
rules, in particular rule 8.1.1(3), Parliament had decided to address this issue, amongst others, by ensuring
that employees who believed that they were protected at work would not have their claims rejected. He
relied on reasoning in _Parker v NFU_ [2012] EWHC 2156 and _Bate v Aviva Insurance UK Limited_ [2014]
334, as support for his submission that rule 8.1.1(3) requires an approach which looks at all the
circumstances of the case, albeit Mr Jupp acknowledged that that neither of these cases specifically
addressed the effect of the ICOBS rules on third party claims. He suggested that had rule 8.1.1(3) been in
force at the time of the Dunbar case then the judge would have found avoidance in that case to have been
wholly unreasonable.

29. Mr Jupp argued that if the reasonableness requirement under rule 8.1.1(3) was satisfied simply by
establishing an entitlement to avoid as between insurer and insured then this would render the rule otiose.
The rule was plainly designed, he said, to introduce some further consideration(s). Although it was located
in a part of ICOBS ostensibly dealing with claims handling Mr Jupp maintained that the rule was not limited
to aspects of process, it was intended to interfere with a fundamental right of the insurer to avoid (or
terminate) the policy. He explained the absence of any reference to claims, avoidance or rights of third
parties in the section of ICOBS specifically addressing Employers' Liability by suggesting that this section
was limited to rules about keeping a policy register, pointing out that rule 8.1.1(3) was not limited to claims
under Employers Liability policies. As to the inclusion of a reference to “injured party” under rule ICOBS
rule 8.2 (dealing with Motor Insurance), Mr Jupp argued that motor policies, which cover third party fire and
theft, specifically contemplate a claim being brought by an injured party, hence the use of this term in this
context; by contrast it is not usually the case that an injured employee will be the claimant under an
Employers' Liability policy.

30. As to Ground 3, Mr Jupp contended that the Master was wrong to find that the scantiness of placing
information and enquiries had no bearing on the materiality of the non-disclosure. He argued that the fact
that ATE made scant enquiry of HLB in a sector where trafficking is likely to occur is a factor going to the
reasonableness of the avoidance: If ATE had been taking its responsibility seriously then they should have
made full enquiries, he suggested.

31. Mr Jupp's Ground 4 covered aspects of the legislative and policy context bearing upon trafficked
persons which he maintained that the Master should have taken into account in determining


-----

reasonableness. Citing the cases of _Hounga v Allen [2014] UKSC 47 and_ _Rantsev v Cyprus_ (2010) 51
EHRR 1, together with Articles 1 and 15 of the European Convention against Trafficking (“Trafficking
Convention”) he pointed to the UK policy commitment of providing compensation and legal redress to
trafficked victims. He argued that whilst Article 15 of the Trafficking Convention does not give the
appellants an independent right to claim, nevertheless they are in a unique position, as victims of
trafficking, which affects how rule 8.1.1(3) is to be interpreted and applied in this case. When considering
the question of insurers avoiding the policy where the ground for doing so is the use of trafficked labour
and where the policy covers, or would cover, loss and injury sustained by trafficked victims, then broader
policy considerations should come into play, he argued. Mr Jupp said that if one looks at the
circumstances here, that vulnerable trafficking victims will go uncompensated, then the fact that insurers
knew of this, but proceeded to avoid the policy for non-disclosure anyway, rendered the avoidance
unreasonable.

32. In response Mr Brown, for ATE, submitted that the appellants' case throws up three insurmountable
anomalies. In the first place there was no extant policy, since it was avoided ab initio; the appellants' case
in effect seeks to maintain that a payment should be made pursuant to a policy which does not exist.

33. Second, Mr Brown emphasised use of the word “by.. avoiding a policy” in rule 8.1.1(3). He pointed out
that avoidance is of its essence a matter as between insurer and policyholder. As between insured and
policy holder in this case it was in no way unreasonable to avoid the policy, as the appellants have
accepted on this appeal, thus it cannot have been unreasonable to have rejected the appellants' claims.

34. Mr Brown's third anomaly arose from a consideration of other, regular, employees at HLB. He pointed
out that the case for appellants has focussed on their position as trafficked employees, asking the court to
consider the reasonableness of avoidance in relation to them. But what of claims by other employees? Mr
Brown asked. He invited the court to consider, if the EL policy is to subsist for the benefit of trafficked
employees but not for any other, how the rule is to operate in any practical way.

35. Having raised these points as general difficulties with the appellants' case on this appeal, Mr Brown
turned to deal with particular aspects of rule 8.1.1(3). He submitted that the Master was right, when
considering the application of the rule, to look at the position vis a vis the policyholder. The word
“policyholder” appears in rule 8.1.1(2) and although not specifically used in (3) it is necessarily implied,
since avoidance (and also termination) is something which by its nature takes place between insurer and
insured.

36. Mr Brown went on to invite consideration of rule 8.1.2, pointing out that this rule is couched in terms of
policyholders. He indicated that rule 8.1.2 covers historic claims by consumers, whilst rule 8.1.2A covers
the current position. Rule 8.1.2 covers claims by consumers under policies entered into before the
provisions of the 2012 Act came into force, but at a time when the insurance industry had made
commitments in relation to consumers and the circumstances under which consumer policies would and
would not be avoided. These commitments were encapsulated in ICOBS and given statutory force upon
the implementation of the 2012 Act. Accordingly rules 8.1.2 and 2A go beyond a process requirement but
only in a limited and specific way. Otherwise, Mr Brown submitted, this part of ICOBS, and specifically rule
8.1.1(3), deals only with process requirements, that is to say with claims handling, as the heading of the
section suggests. Rule 8.1.1(3), which applies to all contracts, consumer and commercial, is concerned
with the way an insurer sets about rejecting a claim; Mr Brown suggested as an example of what behaviour
might be captured by rule 8.1.1(3) a premature avoidance, or by contrast a much-delayed decision to
avoid/terminate. He argued that the focus of this section of ICOBS is on how a claim is dealt with and was
not intended to effect a wholesale adjustment of long-established principles relating to avoidance and
termination of policies of insurance. He stressed that, to the extent that rules 8.1.2 and 2A, in relation to
consumer policies, go beyond the process of claims handling, it is in a limited and specific way consistent
with, and only reflecting, legislative and regulatory developments.

37. Mr Brown next pointed to the use of the term “injured party” in ICOBS rule 8.2, drawing a contrast
between the term “policyholder” used in rule 8.1 and “injured party” in rule 8.2. He submitted that where
ICOBS intended a rule to apply to an injured (third) party, then it said so. Mr Brown argued further that any


-----

change to well-established principles of avoidance and third party rights in the context of Employers'
Liability policies would have been expected to be found in the section of ICOBS dealing with such policies,
yet there was nothing there.

38.  Mr Brown urged caution in deriving interpretive assistance for the ICOBS rules from the provisions of
FSMA setting out general objectives of that Act as a whole. In any event, he argued, rule 8.1.1(3) cannot
be construed as appertaining to the rights of third parties under the 1930 Act. There was nothing in rule
8.1.1 which suggested that it was meant to embrace a claim under the 1930 Act; moreover it was all the
more unlikely that it would do so as the whole area of third party rights had recently been re-visited by
Parliament when enacting the replacement 2010 Act. Mr Brown pointed out that the changes suggested
by the appellants' case as to the meaning of rule 8.1.1(3) would be significant, dramatically altering longestablished principles of avoidance and third party rights, in an area where there has been a recent
legislative reform which has not resulted in Parliament introducing the changes for which Mr Jupp
contends.

39. Mr Brown argued that, as a result of recent reform through the 2012 Act and the 2015 Act, there has
been enacted a proportionate remedy replacing the previous draconian effects of the avoidance regime,
with detailed restrictions limiting insurers' right to avoid contracts with consumers.  Likewise there has also
been recent reform of the third party rights regime, under the 2010 Act. Mr Brown suggested that if public
policy demanded that victims of trafficking be treated as a special case then it would be a matter for
legislation, yet the changes introduced by the 2010 Act go nowhere near the radical overhaul which the
appellants' case suggests is the result of rule 8.1.1(3). Mr Brown observed that no textbook, FCA guidance
or authority has to-date suggested that further radical limitations on insurers' right to avoid alongside a
broad expansion to third party rights were introduced by the ICOBS claims handling rules.

40. Mr Brown next raised concerns about how the regime would operate, if rule 8.1.1(3) had the effect for
which the appellants contend. He pointed out that an insurer could never know the full circumstances of all
potential third party claimants at the time of placing a liability policy; in such circumstances how is such a
policy to be underwritten, the terms and premium properly arrived at? Mr Brown asked. He suggested that
under a broad requirement of “reasonableness” the demands of a trafficked labourer would always trump
the interests of the insurer. The risks would swiftly become uninsurable as no insurer would offer
insurance in the face of such uncertainty.

41. Mr Brown suggested that the real issue for the appellants in this case is that limitations in the Criminal
Injuries Compensation Scheme have resulted in their being unable to recover for the mental and physical
injury caused by the crimes of their handlers, Orsos and Illes, and of the owner of HLB, Rafiq. ATE is not
an emanation of the state, Mr Brown pointed out: the absence of compensation may be a proper subject
for judicial review but it cannot form the basis for a broad reasonableness interpretation of a regulatory
provision in the claims handling section of ICOBS.

42. By his respondent's notice Mr Brown raised a point which he said the Master had not needed to
consider, in the light of his judgment. He argued that even if a broad reasonableness test did apply, ATE
had not acted unreasonably. He pointed to the Master's finding – unchallenged on appeal – that the
position “could not get much worse” in terms of non-disclosure (see [49] of the Master's judgment). Rule
8.1.1(3) provides that an insurer must not act unreasonably in rejecting a claim by avoiding a policy; Mr
Brown said that in considering whether an insurer, here ATE, has acted unreasonably it is relevant (if not
actually decisive, which I understood to be his primary position) that as between ATE and HLB, ATE acted
reasonably in avoiding the policy.

43. Finally Mr Brown stressed that a claim under the 1930 Act does not come under the ICOBS regime.
He pointed out that HLB would have had no rights under s.138D of FSMA, not being a private person.
Although Mr Jupp's position was that his clients were making not claim under s.138D of FSMA,
nevertheless the effect of his clients' case was that they would have had a claim in circumstances where
the insured, HLB, would not.

44. Mr Jupp responded briefly as follows: As to the process point he pointed out that neither of the two
examples suggested of avoidance activity which might be captured by rule 8 1 1(3) premature avoidance


-----

and delayed avoidance – supported a process interpretation; premature avoidance either would, or would
not, be a valid avoidance and a late avoidance would equally give rise to an argument that insurers had
waived their rights to avoid. Mr Jupp submitted that the paucity of proper examples suggested that the rule
went wider than simply addressing process. In relation to claims notification the process point may arise,
but not in relation to avoidance, he said.

45. Mr Jupp reasserted his client's case that rule 8.1.1(3) introduced a fetter on insurer's right to avoid,
confirming his clients' case that ATE had unreasonably rejected their claims by avoiding the policy at a
time when it was aware that trafficked persons were seeking to make a claim.

**Discussion**

46. The plight of trafficked persons in general, and of these appellants in particular, is bound to evoke
sympathy for them and outrage against the perpetrators. But it is the criminal acts of the latter – here
Orsos, Iles and Rafiq - which are responsible for the circumstances in which these appellants now find
themselves. To the extent that the Criminal Injuries Compensation Authority (“CICA”) rules improperly
prevent, or limit, the compensation to which the appellants would otherwise be entitled as victims of crime
– as to which I heard no detailed submissions – then as Mr Brown rightly observed, the proper recourse
would be via judicial review proceedings of the CICA's rules.

47. The rights or wrongs of the CICA's rules on compensation are not the subject of this appeal, which is
concerned only with the nature of the civil rights, if any, of these appellants to make a claim against ATE on
the EL policy, under the 1930 Act.

_Grounds 1 and 2_

48. I have no doubt at all that the Master correctly decided the preliminary issues. In my view Mr Jupp's
submissions as to the ambit of ICOBS rule 8.1.1(3) are untenable.

49. First, I agree with Mr Brown that notwithstanding the absence of the word “policyholder” from rule
8.1.1(3), this provision is apt only to deal with the position as between insurer and insured. In reaching this
decision I have had particular regard to the following

(i)  use of the term “policyholder” in the preceding sub-rule, 8.1.1(2);

(ii) subsequent rules 8.1.2 and 2A, which are clearly couched in terms of policyholders;

(iii) the fact that avoidance and termination are by their nature matters as between the parties to the
contract, insurer and insured, here ATE and HLB;

I conclude that the absence of the word “policyholder” from (3) signifies nothing, since the scope of the rule
– covering the relationship between insurer and insured - is implicit.

50. Next, I accept Mr Brown's submission that rule 8.1.1 as a whole is intended to express a process
requirement, each of the sub-rules regulating how an insurer is to deal with a claim. This interpretation is
consistent with the title of the section of ICOBS where the rule is located, namely “Claims Handling”. To
the extent that the provisions of subsequent rules 8.1.2 and 8.1.2A extend beyond strictly claims handling,
this is in a limited and specific way which encapsulates commitments previously signed up to by insurers
(as per rule 8.1.2, covering the position before the 2012 Act) or subsequently imposed by legislation (rule
8.1.2A applicable to insurance contracts entered into after the 2012 Act). I acknowledge Mr Jupp's point
concerning the weakness of examples suggested by Mr Brown (premature avoidance/delayed avoidance),
but the rule is a general one, drafted to cover how claims are handled in many different situations, under
many different sorts of policies. Moreover avoidance and termination are only given as examples of the
ways in which an insurer might seek to reject a claim on a policy.

51. Further if Mr Jupp were right that Parliament sought to address the concerns raised in _Dunbar by_
means of the rules set out in ICOBS, then it might be expected that any change would be effected through
rules contained in the section of ICOBS dealing with Employer's Liability, yet there are no relevant
provisions to be found in that part of ICOBS.


-----

52. I come to the principal consideration which has persuaded me that Mr Brown is right: this is the driving
of a coach and horses through many decades of well-established insurance law which Mr Jupp's
construction of rule 8.1.1(3) demands. If Mr Jupp is right, then rule 8.1.1(3) not only strikes through wellknown and long held principles of avoidance but also formidably expands the law relating to the rights of
third parties; doing so, moreover, through a single sentence buried within a section of ICOBS dealing with
claims handling.

53. The inherent unlikelihood of this increases when one considers how much time and attention - of
commentators, academics, the insurance industry, the Law Commission, the FCA and Parliament, over
many years – has been given to addressing what limitations might sensibly be placed on insurers' right to
avoid; likewise to defining the rights of third parties to claim on a contract of insurance when the
policyholder has ceased, through insolvency, to be able to do so.  Yet none of the legislative changes has
introduced a fetter upon an insurer's right to avoid for non-disclosure by reference to the circumstances of
a person or persons not parties to the contract, and none has sought to expand the rights of third parties
beyond the rights which the policyholder itself/themself would have had. If public policy in relation to
trafficked persons demanded that such significant changes be made to the law of insurance then, as Mr
Brown rightly observed, one would expect to find them in primary legislation.

54. The cases of Parker and Bate relied upon by Mr Jupp are not directly on point, as he acknowledged,
since each concerns a claim made by the policyholder, not by a third party. I do not read either decision as
authority for an objective approach to the application of rule 8.1.1(3). In Parker Teare J was dealing with a
breach of condition (to provide information, here bank statements), which necessarily engaged
consideration of whether there was a connection between the nature of the breach and the insurer's
concern. Interestingly Teare J then went on to look at the process by which insurers had taken up the
breach of warranty, noting that the insurer had made clear to the insured what the consequences of not
disclosing the bank statements would be – a clear warning - before taking the point and refusing the claim.

55. _Bate concerned a retail policy, where the claimant was held to be a consumer, to whom the more_
detailed ICOBS provisions (forerunners of rules 8.1.2 and 2A) applied. Mr Jupp relied upon this authority
as demonstrating that the court took into account the insured's own professional experience and his
dishonest role in the material non-disclosure, but these were considerations which the relevant ICOBS rule
in that case (relating to consumer policies) explicitly engaged.

56. I concluded that neither of these authorities provided support for Mr Jupp's contention that rule 8.1.1(3)
engaged a broad reasonableness test.

57. Mr Jupp's timing point was irreconcilable with his acceptance of ATE's right to avoid as against HLB.
He appeared to be saying that ATE could reasonably have avoided the policy before they were aware of
claims by these appellants, but not afterwards. But if there is material non-disclosure/misrepresentation
justifying avoidance then (subject to any waiver argument, which does not arise here) it makes no
difference when insurers take the point and avoid the policy, a point which Mr Jupp himself made when
seeking to refute the claims handling examples raised by Mr Brown in argument.

58. Nor do I read the decision in _Total Graphics as providing support for an application of rule 8.1.1(3)_
which would result in the finding that avoidance was valid in response to any claim made by HLB as
policyholder, but invalid when meeting a claim by these appellants under the 1930 Act. The situation in
_Total Graphics was entirely different: in that case the clients of a broker sought to make a claim under the_
broker's liability policy, for damages arising from the broker's failure to obtain valid insurance for the client.
The failure had been due to the dishonesty of the broker. On the claim by the client against the broker's
liability insurers under the 1930 Act, Mance J found that liability for dishonest activity by a director (as in
that case) was excluded under the terms of the liability policy, accordingly the claim failed. However he
went on to observe (at p.606) that if the terms had been apt to cover the loss, then although public policy
would have imposed a “personal disability” on the broker himself, preventing him from successfully
claiming on the policy, it would not have precluded the client from claiming under the 1930 Act. A
“personal disability” imposed by public policy to prevent a claim is not at all the same as saying (as Mr
Jupp sought to do) that public policy acts to enable a claim by deserving third parties through the means of


-----

preventing insurers from implementing what would otherwise be a valid right to avoid. In the first place
Mance J was dealing with a theoretical position (since he had found that the terms of the policy did not
provide cover anyway); in the second, there was no question in that case of the broker's liability policy
being avoided for non-disclosure/misrepresentation. Mance J was considering the (hypothetical) effect of
public policy on a claim made under a valid contract of insurance, not a claim made under a contract of
insurance that had been validly avoided vis a vis the policyholder. The case is not authority for a general
approach which seeks to put a person claiming under the 1930 Act (or the 2010 Act), in a better position
that the insured.

59. Mr Jupp's first two grounds of appeal must therefore fail. In my view rule 8.1.1(3) does no more than
set out a process requirement, regulating how an insurer sets about rejecting a claim. Where, as in this
case, an insurer is entitled to avoid the policy by reason of non-disclosure/misrepresentation on the part of
the policyholder, rule 8.1.1(3) does not act to remove or limit that right by reference to other (unspecified,
apparently at large) considerations, including the circumstances of third parties seeking to claim under the
policy. Were it to be otherwise then I agree with Mr Brown that employer's liability risks, probably other
types of risk also, would become unrateable and thus uninsurable, having too many unknown, and
unknowable, variables.  As Mr Brown asked rhetorically in argument - how indigent would an employee
have to be before an avoidance that would otherwise be reasonable would be rendered unreasonable?

60. The result of Rafiq's criminal activity in engaging slave labour to work at HLB indisputably constituted
non-disclosure/misrepresentation entitling ATE to avoid the EL policy. The Master's decision in that
respect is not challenged. The effect of avoidance is to annul and remove the policy altogether, for all
purposes and against all persons.  Under the 1930 Act the appellants only had such claim under the EL
policy as HLB would have had. The policy having been (validly) avoided, HLB would have failed in any
claim which it brought under the policy and thus the appellants' claims must also fail. That is the effect of
the statutory subrogation under the 1930 Act: the appellants stand in the shoes of HLB, having no better
claim than HLB would have had.

_Ground 3 – scantiness of placing information and enquiries_

61. The Master's finding (at [42] of his judgment) that scant enquiries made by ATE at the time of placing
had no bearing on the materiality of the non-disclosure is not challenged on this appeal. Given my decision
on the first two grounds, above, this ground must fail.

_Ground 4 – matters to be taken into account under a broad test of reasonableness_

62. Since I have rejected Mr Jupp's “broad reasonableness” test it follows that in my view the Master did
not err in failing to take account of the matters raised by Mr Jupp under his fourth ground of appeal.

63. Mr Jupp's policy arguments, made by reference to the cases of Hough and Rantsev, together with an
examination of the UK's obligations under the European Convention against Trafficking, took the matter no
further.  He suggested that a policy calling for proper treatment and compensation of trafficking victims
should “feed into” how rule 8.1.1(3) is interpreted but I simply could not see how this would work. As Mr
Brown observed, properly understood what Mr Jupp appeared to be saying was that such a policy should
affect how the rules are interpreted for the appellants. Yet there is nothing whatsoever in the ICOBS rules
which could justify drawing such a distinction.

**Conclusion**

64. For the reasons set out above the appeal is dismissed.

**End of Document**


-----

