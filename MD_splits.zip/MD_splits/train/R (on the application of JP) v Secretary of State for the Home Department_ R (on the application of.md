Secretary of State for the Home Department [2019] EWHC....

# R (on the application of JP) v Secretary of State for the Home Department; R
 (on the application of BS) v Secretary of State for the Home Department

 [2019] EWHC 3346 (Admin)

Queen's Bench Division, Administrative Court (London)

Murray J

10 December 2019Judgment

**Mr Chris Buttler (instructed by Deighton Pierce Glynn Solicitors) for the Claimants**

**Ms Joanne Williams (instructed by the Government Legal Department) for the Defendant**

Hearing date: 2 May 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Murray :**

1. Each of the claimants, JP and BS, is a victim of human trafficking and has also claimed asylum in the
United Kingdom. Each claimant seeks to challenge the decision of the defendant, the Secretary of State for
the Home Department, not to determine her application for a residence permit under Article 14(1) of the
Council of Europe Convention on Action against Trafficking in Human Beings of 16 May 2005 (“ECAT”)
before determining her claim for asylum. In the case of JP, the relevant decision is dated 21 September
2018 (“the JP Decision”). In the case of BS, the relevant decision is also dated 21 September 2018 (“the
BS Decision”).

2. Each of JP and BS also seek to challenge the lawfulness of the Secretary of State's policy that, in the
case of a victim of trafficking who is also making an application for asylum, the Secretary of State will not
determine the victim's application for a residence permit under Article 14(1) of ECAT before making a
decision on the asylum application.

_Procedural history_

3. JP's claim (CO/4606/2018) for judicial review of the JP Decision was issued on 19 November 2018.
BS's claim (CO/4608/2018) against the BS Decision was also issued on 19 November 2018. There are
some factual differences in the background to each claim, but the claims raise the same issues. The same
solicitors, Deighton Pierce Glynn (“DPG”), act for each of JP and BS in these proceedings.

4. On 29 November 2018 Garnham J granted anonymity to each of JP and BS and ordered that JP's claim
and BS's claim should be managed together.

5. By order dated 16 January 2019 (sealed on 17 January 2019) HHJ Bidder QC, sitting as a Deputy
Judge of the High Court, gave BS permission to amend her Statement of Facts and Grounds and the
Secretary of State permission to amend her Summary Grounds of Defence in relation to BS's claim.


-----

Secretary of State for the Home Department [2019] EWHC....

6. By order dated 17 January 2019 (sealed on 23 January 2019) HHJ Bidder QC, sitting as a Deputy
Judge of the High Court, gave JP permission to amend her Statement of Facts and Grounds and the
Secretary of State permission to amend her Summary Grounds of Defence in relation to JP's claim. HHJ
Bidder QC also ordered that JP's claim and BS's claim be consolidated.

7. By order dated 8 March 2019 (sealed on 13 March 2019) (“the Permission Order”), on a review of the
papers, Andrew Baker J gave permission for JP and BS to bring their claims for judicial review, for the
reasons appended to his order. He also granted expedition of the claims, to be heard as soon as possible
after 30 April 2019. At para 4 of his reasons, Andrew Baker J observed that it would be appropriate to hear
the claims even if they became academic, because the issue:

“raises an argument of real public importance that does not turn on the detailed facts and substantial
numbers of other potential claimants are or are likely to be affected. Moreover, that challenge relates to a
recent change of policy and there is a strong public interest in the lawfulness of the new policy (since open
to doubt) being authoritatively considered, if possible, before it becomes too well embedded.”

_The Secretary of State's applications for adjournment of the hearing_

8. Shortly before the hearing, the Secretary of State made an application, supported by detailed written
submissions, for (i) a stay of these proceedings behind proceedings relating to the claimants in two other
judicial review cases that were being heard together, R (NN) v SSHD (CO/1040/2019) and R (LP) v SSHD
(CO/1039/2019) or (ii) in the alternative, for an order adjourning the hearing of this case, which was then
due to be heard on either 2 or 3 May 2019 (and was heard on 2 May 2019), on the basis that the
consolidated case of NN & LP should proceed as the lead case for various reasons.

9. The claimants, JP and BS, opposed the Secretary of State's stay application. I dealt with it on the
papers, refusing it by order dated 26 April 2019. Broadly, I accepted the position of JP and BS that their
claims were sufficiently different from those of NN and LP so as to justify proceeding with their claims at
the hearing then listed for 2/3 May 2019. The Secretary of State renewed her stay application, with further
detailed written submissions, which was again opposed by JP and BS. By order dated 30 April 2019 I
refused the renewed application, and the hearing proceeded on 2 May 2019.

_After the hearing on 2 May 2019_

10. After the hearing on 2 May 2019, I was notified that the Secretary of State had agreed to reconsider
the applications made by each of JP and BS for a residence permit under Article 14(1) of ECAT, having
refused each application shortly before the hearing by letters dated 23 April 2019. I will revert to the impact
of this on the claims later in this judgment.

_The obligations of the UK in relation to trafficking victims_

11. The United Kingdom is a party to ECAT, having ratified it on 17 December 2008. As a treaty, it does
not have direct effect, and it has never been incorporated into the law of any part of the UK, including
England and Wales. It has, however, been implemented administratively in the UK by the National Referral
Mechanism (“NRM”), a process for identifying and supporting victims of trafficking created in 2009 in light
of the UK's obligations under ECAT.

12. The issue of whether ECAT is justiciable arose in the case of R (PK (Ghana)) v SSHD _[2018] EWCA_
_Civ 98. In that case at [34] Hickinbottom LJ noted that it had been common ground before Picken J in the_
court below that a failure to give effect to ECAT would be a justiciable error of law. Before the Court of
Appeal in that case, counsel for the Secretary of State confirmed that concession. In her Detailed Grounds
of Defence for each claim in this case, the Secretary of State stated that “the published policies came into
being to give effect to [Articles 10, 12 and 14] of ECAT”, which the claimants say is consistent with the
Secretary of State's concession on justiciability of ECAT in PK (Ghana). The Secretary of State's position
in this case is that she is constrained to follow this concession, but she reserves her position for the future.


-----

Secretary of State for the Home Department [2019] EWHC....

In any event, she maintains that her published policies are consistent with the United Kingdom's obligations
under ECAT and that they give proper effect to those obligations.

13. Articles 10(1) and 10(2) of ECAT provide as follows:

“1.  Each Party shall provide its competent authorities with persons who are trained and qualified in
preventing and combating trafficking in human beings, in identifying and helping victims, including children,
and shall ensure that the different authorities collaborate with each other as well as with relevant support
organisations, so that victims can be identified in a procedure duly taking into account the special situation
of women and child victims and, in appropriate cases, issued with residence permits under the conditions
provided for in Article 14 of the present Convention.

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in Article 18 of this Convention has been completed by the
competent authorities and shall likewise ensure that that person receives the assistance provided for in
Article 12, paragraphs 1 and 2.”

14. Articles 10(1) and 10(2) of ECAT require each state that is a party to ECAT to have an appropriate
legislative and administrative framework, as well as a procedure and relevant resources, for identifying
potential and actual victims of trafficking and, where appropriate issuing victims with residence permits
under Article 14(1) of ECAT. Article 10(2) also requires a member state to ensure that, until a conclusive
determination has been made whether a potential victim is an actual victim of trafficking, the potential
victim is:

i) protected from removal from the state; and

ii) entitled to receive the assistance provided for in Articles 12(1) and 12(2) of ECAT (discussed further
below).

15. Articles 14(1) and 14(5) of ECAT provide as follows:

“1.  Each Party shall issue a renewable residence permit to victims, in one or other of the two following
situations or both:

(a) the competent authority considers that their stay is necessary owing to their personal situation;

(b) the competent authority considers that their stay is necessary for the purpose of their co-operation with
the competent authorities in investigation or criminal proceedings.

…

5. Having regard to the obligations of the Parties to which Article 40 [Relationship with other international
instruments] of this Convention refers, each party shall ensure that granting of a permit according to this
provision shall be without prejudice to the right to seek and enjoy asylum.”

16. In the UK, a “renewable residence permit”, as referred to in Article 14(1) of ECAT would be in the form
of discretionary leave to remain (“DLR”) granted to the victim by the Secretary of State, as the competent
authority under ECAT and the NRM for victims or potential victims of trafficking who have made an asylum
claim or are subject to immigration control. The Modern Slavery Human Trafficking Unit (MSHTU) is the
other competent authority under ECAT in the UK, primarily responsible for potential or actual victims of
trafficking who are UK or EEA nationals.

17. During the hearing of this matter, DLR granted to a victim by the Secretary of State under Article 14(1)
of ECAT was referred to as “ECAT leave” to distinguish it from leave that may be granted following a
decision to grant asylum, which, for convenience, was referred to as “refugee leave”.


-----

Secretary of State for the Home Department [2019] EWHC....

18. ECAT leave is a temporary form of leave that enables a victim of trafficking to receive support (through
access to the labour market, education and mainstream benefits) to facilitate recovery from trafficking
and/or to facilitate co-operation with a criminal investigation into trafficking. It is generally granted for a
period of 30 months, although it can be granted for a longer or shorter period in individual cases. It is not a
route to settlement in the UK.

19. Refugee leave is a longer-term form of leave granted, in principle, because the person granted asylum
cannot safely return to his or her country of origin. A person with refugee leave is able to access the labour
market, education and mainstream benefits. The leave is generally granted for five years, and it is a route
to settlement in the UK. Accordingly, refugee leave is a more favourable form of leave than ECAT leave.

20. Prior to 21 February 2018, the Secretary of State would decide whether to grant ECAT leave to an
applicant at the same time as he made a decision as to whether there were conclusive grounds for
determining that the applicant was, in fact, a victim of trafficking (“a conclusive grounds decision”). Further
references in this judgment to a “victim” without other qualification means a person in respect of whom the
Secretary of State has made a positive conclusive grounds decision that the person is an actual victim of
trafficking.

21. A person who is referred to the NRM as a possible victim of trafficking is first assessed in order to
make a decision whether there are reasonable grounds for considering that the person may be a victim of
trafficking (“a reasonable grounds decision”). If a positive reasonable grounds decision is made, the
person, as a potential victim of trafficking, is entitled to a degree of support under Articles 12(1) and 12(2)
of ECAT (“basic trafficking support”).

22. Articles 12(1) and 12(2) of ECAT provide as follows:

“1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in
their physical, psychological and social recovery. Such assistance shall include at least:

a. standards of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

b. access to emergency medical treatment;

c. translation and interpretation services, when appropriate;

d. counselling and information, in particular as regards their legal rights and the services available to them,
in a language that they can understand;

e. assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

f. access to education for children.

2. Each Party shall take due account of the victim's safety and protection needs.”

23. The date of notification of a positive reasonable grounds decision to a potential victim of trafficking marks the
start of a 45-day period of “recovery and reflection”. Article 13 of ECAT requires this period to be at least 30 days.
During the recovery and reflection period, basic trafficking support will be available to the potential victim. According
to the Secretary of State's policy guidance “Victims of Modern Slavery – Competent Authority Guidance” (Version
7, published 29 April 2019) (“the Trafficking Guidance”), the expectation is that the Secretary of State's conclusive
grounds decision will be made “as soon as possible” following the end of the recovery and reflection period.

24. Basic trafficking support in the UK is provided by the Salvation Army under a contractual arrangement
between the Salvation Army and the Secretary of State and includes specialist accommodation (where
needed), a support worker to provide practical and emotional support, access to free healthcare in

emergency or other limited circumstances, short‑term counselling and financial support at a rate of £65 per

week.


-----

Secretary of State for the Home Department [2019] EWHC....

25. A person who has made an application for asylum, but who is not a potential or actual victim of
trafficking, is entitled to receive financial support and, if needed, assistance with housing from the National
Asylum Support Service (“NASS”), a section of the UK Visas and Immigration division of the Home Office.
The NASS financial support rate is £37.75 per week, which is £27.25 per week less than the financial
support paid to victims or potential victims of trafficking under basic trafficking support.

26. A potential or actual victim of trafficking who has made an application for asylum and has moved out of
NRM support into asylum support accommodation is entitled to financial support at the NASS financial
support rate of £37.75 per week.

27. If a potential victim of trafficking is “lawfully resident within the territory of” the UK, then he or she is
also entitled to support under Articles 12(3) and 12(4) of ECAT (“enhanced trafficking support”). The
Explanatory Report to ECAT dated 16 May 2005 makes clear at para 165 that “lawfully resident” victims
are those who, if not nationals of the relevant state, have the residence permit referred to in Article 14(1) of
ECAT. Accordingly, neither JP nor BS are eligible for enhanced trafficking support.

28. Article 12 of ECAT provides at paras 3 and 4 as follows:

“3. In addition, each Party shall provide necessary medical or other assistance to victims lawfully resident
within its territory who do not have adequate resources and need such help.

4. Each Party shall adopt the rules under which victims lawfully resident within its territory shall be
authorised to have access to the labour market, to vocational training and education.”

29. Whereas under basic trafficking support a potential victim is entitled to access medical treatment only
in emergency or other limited circumstances, under enhanced trafficking support, pursuant to Article 12(3)
of ECAT, a potential or actual victim is entitled to “necessary medical or other assistance to victims … who
do not have adequate resources and need such help”. Similarly, whereas under basic trafficking support a
potential victim is not entitled to access the labour market, vocational training or education in the UK,
pursuant to Article 12(4) of ECAT, a potential or actual victim is entitled to that access.

30. If a person receives a positive conclusive grounds decision, basic trafficking support continues for a
further 45 days from the date of the decision and then ends (“the 45-day rule”). Prior to 1 February 2019,
basic trafficking support continued only for a further 14 days after the date of the positive conclusive
grounds decision (“the 14-day rule”). The 14-day rule applied to the claimants. The change to the 45-day
rule was announced by the Secretary of State in a policy document entitled “National referral mechanism
reform”, which was published on 16 October 2018. A victim can ask for an extension of basic trafficking
support beyond the 45 days, but there is no guarantee that the extension will be granted. No material
extension of basic trafficking support was provided to JP or BS after the application of the 14-day rule in
relation to each of them.

31. As I have already noted, basic trafficking support does not permit the potential victim of trafficking to
access the labour market, education or mainstream benefits. It is, however, more generous than NASS
support, namely, the support available to applicants for asylum who have not been identified as potential
victims of trafficking.

32. After the Secretary of State had issued a notice on 18 January 2018 cutting the rate of support paid to
potential victims of trafficking (namely, those in respect of whom a reasonable grounds decision had been
made) from £65 per week to the level of the NASS financial support rate of £37.75 per week, Mostyn J in R
_(K) v SSHD_ _[2018] EWHC 2951 (Admin), [2019] HRLR 2 (Admin) at [25]-[30] found that the NASS financial_
support rate was insufficient to meet the needs of potential victims of trafficking. He noted that the NASS
financial support was no more than “the minimum sum needed to stave off destitution”, whereas ensuring
the “subsistence” of a potential victim of trafficking requires more than that. He therefore quashed the
Secretary of State's decision to cut the weekly rate paid to support potential victims of trafficking.

_The scheduling rule_


-----

Secretary of State for the Home Department [2019] EWHC....

33. Since 8 August 2018 the Secretary of State has operated a policy under which he will not make a
decision on ECAT leave in respect of a victim of trafficking unless and until it is determined that the victim
does not qualify for any other form of leave. The claimants refer to this as “the scheduling rule”. The
Secretary of State apparently objects to the term as inapt, but Ms Joanne Williams, counsel for the
Secretary of State, did not make any submissions as to why the Secretary of State considers the term to
be inapt. For convenience of reference, I adopt the term in this judgment.

34. The scheduling rule and the criteria for granting ECAT leave are set out in a policy document
published on 10 September 2018 entitled “Discretionary leave considerations for victims of **_modern_**
**_slavery (Version 2.0)” (“the Policy”). The scheduling rule is set out in the first sentence of the following_**
paragraph at page 12 of the Policy:

“All outstanding asylum decisions should be taken before any consideration is given to whether the victim
_is eligible for discretionary leave. If it is decided that a grant of leave is appropriate and the length of that_
leave is more generous than any discretionary leave grant, that leave should be granted. This may be the
case where the person qualifies for a grant of asylum or humanitarian protection or for leave to remain on
the basis of family or private life.” (emphasis added)

35. The Policy sets out (at pages 6 to 9) three alternative criteria under which ECAT leave may be
granted:

i) leave that is necessary owing to the personal circumstances of the victim, for example, the need to finish
medical treatment from a healthcare professional;

ii) leave in order to pursue compensation against the perpetrators of the victim's trafficking through legal
proceedings in the UK; and

iii) leave to enable the victim to assist the police in the UK with their investigation or proceedings against
the perpetrators or facilitators of the victim's trafficking.

The claimants make no complaint about those criteria.

36. The effect of the scheduling rule is that a victim of trafficking who is also an asylum seeker will not
have their application for ECAT leave determined until their application for asylum has been granted and
then a decision on refugee leave has been made. A victim of trafficking who is not an asylum seeker (and
has not applied for any other form of status that could result in a grant of leave) will have their application
for ECAT leave determined at the same time as they receive a positive conclusive grounds decision.

37. Given that it typically takes several months for an asylum decision to be made (as was the case for
each of the claimants in this case), an asylum-seeking victim of trafficking is required by the scheduling
rule to wait for several months after their conclusive grounds decision for a decision on ECAT leave while a
non-asylum-seeking victim of trafficking may have a decision on ECAT leave at the same time as their
conclusive grounds decision.

38. A victim of trafficking is not guaranteed to receive ECAT leave, just as a person granted asylum is not
guaranteed to receive refugee leave. While acknowledging that point, the claimants say that the effect of
the delay in determining ECAT leave has the following consequences for victims of trafficking:

i) The victim loses trafficking support 45 days after receiving a positive conclusive grounds decision and is
without that support (typically, for many months) before a decision is made on asylum, on refugee leave or,
if refugee leave is not granted, on ECAT leave. The victim remains eligible for NASS support, however
that, as already noted, is only a minimal level of support necessary to stave off destitution.

ii) The victim loses the advantages of ECAT leave that would otherwise apply if a favourable ECAT leave
decision were made at the time of the conclusive grounds decision, including the right to work or study and
the right to access mainstream benefits.


-----

Secretary of State for the Home Department [2019] EWHC....

iii) The victim suffers from continuing uncertainty, which can impede their recovery from the trauma they
have suffered. The claimants have provided expert evidence on this point, which I will summarise in due
course.

_The effect of the scheduling rule on trafficking support_

39. Before turning to consider the position of the individual claimants, I briefly outline the claimants' case
on point (i) in [38] above. The claimants say that the Secretary of State was wrong to contend in her
Detailed Grounds of Defence at para 26 that the Secretary of State takes due account of a victim's safety
and protection needs in accordance with Article 12(2) of ECAT by virtue of the fact that:

“victims, including the Claimant[s], are still able to access the support and benefits conferred under Article
12(1) [of ECAT] pending a decision on asylum and/or DLR … .”

40. The claimants say that this is wrong for the following reasons. Due to the 45-day rule (and the 14-day
rule, which applied in the case of the claimants), basic trafficking support ends 45 days after a conclusive
grounds decision (and ended 14 days after the conclusive grounds decision in relation to each of the
claimants). The Secretary of State provides a weekly drop-in support service for up to six months after the
conclusive grounds decision to “all confirmed victims with leave to remain in the UK”, but that does not
apply to victims, such as the claimants, who do not have leave to remain and are awaiting a decision on
ECAT leave.

_The interaction of the scheduling rule and the 45-day rule_

41. At the time of the hearing, the 45-day rule was under challenge in the case of NN and LP, to which I
have already referred. On 17 April 2019 Julian Knowles J gave NN and LP permission to challenge the 45day rule by way of judicial review: R (NN) v SSHD _[2019] EWHC 1003 (Admin)._

42. By consent order dated 28 June 2019 (“the NN-LP Consent Order”) NN and LP withdrew their claim
for judicial review upon the Secretary of State recognising that the legislative and other measures whose
adoption is contemplated by Article 12(1) of ECAT as necessary to assist victims in their recovery may vary
from individual to individual and cannot be delimited by time alone, and the Secretary of State agreeing to
not cease providing basic trafficking support to NN and LP by reference only to the lapse of time after her
conclusive grounds decision in relation to each of them and further agreeing to determine NN's asylum
claim within three months of the date of the consent order.

43. In the Statement of Reasons accompanying the NN-LP Consent Order, which was supported by a
witness statement dated 6 June 2019 provided by Ms Rachel Devlin of the Home Office, Modern Slavery
Unit, the Secretary of State indicated that in response to that judicial review claim the Secretary of State
had reviewed the current NRM system and concluded that some aspects of the system were
unsatisfactory, recognising that what Article 12 of ECAT contemplates is necessary to assist with recovery
may vary from individual to individual and cannot be delimited by time alone. Among other things, the 45day rule and how it is applied is under review by the Secretary of State.

44. According to the Statement of Reasons, the Secretary of State is “currently formulating a sustainable
replacement, needs-based system for supporting victims of trafficking”. Pending the completion of that
work, the Secretary of State would be making interim revisions to its current policy so that support through
the NRM for a victim would not be restricted by reference only to the date of the conclusive grounds
decision or the length of time for which such support has been provided. The Statement of Reasons
concludes:

“Pending these interim revisions, the [Secretary of State] has no intention of reapplying the '45-day rule' or
reintroducing any provision that restricts support by reference only to such a date or length of time.”

45. The claimants accepted that for purposes of this case it has to be assumed that the 45-day rule is
lawful. A key issue raised by this case is the interaction between the scheduling rule and the 45-day rule.
Before the scheduling rule was introduced, a victim claiming asylum would receive a decision on ECAT


-----

Secretary of State for the Home Department [2019] EWHC....

leave at about the time the conclusive grounds decision was taken. If it was a positive decision, the loss of
basic trafficking support would be replaced by a more comprehensive system of welfare support available
to holders of ECAT leave.

46. The introduction of the scheduling rule means that victims losing basic trafficking support after 45 days
under the 45-day rule fall to the level of NASS support from that point until the asylum claim and then
ECAT leave decisions are taken. As already noted, NASS support involves a weekly payment at a level
sufficient only to avoid destitution, as found by Mostyn J in the case of K. As Mr Chris Buttler, counsel for
the claimants, put it in his skeleton argument, this “has created a lacuna in support for victims of
trafficking”.

47. This lacuna is significant, say the claimants, because in about half of all cases, the asylum decisionmaking process takes longer than six months, meaning that a victim, without leave or support on another
basis, must survive at the near-destitution level of NASS support potentially for several months, as has
happened in this case in respect of each of JP and BS.

48. This claim challenges the legality of the scheduling rule. The claimants do not contend that, in every
case of a victim who is also an asylum seeker, the Secretary of State must determine the victim's
application for ECAT leave before his or her application for asylum. The claimants simply challenge the
blanket nature of the scheduling rule, namely, that an application for ECAT leave should never be
determined unless and until the related asylum claim has been rejected.

_Factual background relating to JP's claim_

49. JP has provided a witness statement dated 15 November 2018, with a number of exhibits. She is a

national of Albania. She is 29 years old and has a two‑year old son.

50. On 2 August 2016 JP was trafficked into the UK to pay her husband's gambling debts. She was
approximately 5-6 months pregnant at the time. She was held captive and forced to have sex with men for
two or three weeks before she escaped. The traffickers knew she was pregnant. In her witness statement,
JP describes her trauma as a result of these horrific experiences. She has been taking anti-depressants
since about September 2017 . She has found it difficult to engage with counselling or other forms of mental
health treatment due to the uncertainty of her immigration status.

51. On 8 September 2016 JP made an application for asylum. On 9 September 2016 JP was referred to
the NRM as a potential victim of trafficking. By letter dated 13 September 2016 the Secretary of State
informed JP that she had made a positive reasonable grounds decision in her case. The letter included
standard wording noting that 13 September 2016 marked the start of a 45-day recovery and reflection
period, during which she would be entitled to safe accommodation and support as a potential victim of
trafficking and following which the Secretary of State would make a conclusive grounds decision.

52. On 8 February 2017 JP had a full asylum interview. On 28 March 2017 the Secretary of State sent her
a letter stating that there was a six-month delay in respect of asylum decisions.

53. On 22 June 2017 JP felt compelled to move to a new location after seeing a man whom she believed
to have been involved in trafficking her near where she had been staying.

54. On 24 January 2018 the Secretary of State sent JP a letter informing her that there would be a further
delay in making her asylum decision. By letter dated 29 March 2018 JP's solicitors sent a pre-action
protocol letter to the Secretary of State alleging an unlawful delay by the Secretary of State in notifying JP
of her conclusive grounds decision. In her response dated 5 April 2018, the Secretary of State indicated
that a decision would be made within three months, absent special circumstances.

55. On 7 June 2018 JP filed judicial review proceedings challenging the delay in making the conclusive
grounds decision. By letter dated 28 June 2018 the Secretary of State confirmed to JP that she had made
a positive conclusive grounds decision in her case. The Secretary of State indicated in the letter, however,
that a decision on JP's application for ECAT leave was “on hold” pending the Secretary of State's


-----

Secretary of State for the Home Department [2019] EWHC....

consideration of the Court of Appeal's decision in the case of _PK (Ghana). As a result, JP withdrew her_
challenge to the delay.

56. On 21 September 2018, in the JP Decision, the Secretary of State applied the scheduling rule to JP,
stating that it was not necessary to consider her application for ECAT leave until her asylum claim had
been determined.

57. On 24 October 2018 DPG sent a pre-action protocol letter to the Secretary of State challenging her
delay in making a decision in relation to JP's application for ECAT leave. On 7 November 2018 the
Secretary of State replied stating that JP “will be notified in due course”.

58. On 19 November 2018, JP issued her application for judicial review of the JP Decision and the policy
reflected in the scheduling rule.

59. In a letter dated 23 November 2018 the Secretary of State notified JP that her application for asylum
was refused and set out her reasons for that decision.

60. On 12 December 2018 the Secretary of State filed her Summary Grounds of Defence, in which she stated that
her decision on ECAT leave had also been made. On 19 December 2018 JP filed her Amended Statement of Facts
and Grounds of Judicial Review (“JP Grounds”) challenging that contention. On 1 February 2019 the Secretary of
State filed Amended Summary Grounds of Defence maintaining her position on that point.

61. On 13 March 2019 the Permission Order was sealed by the court, granting JP permission to apply for
judicial review of the JP Decision and the lawfulness of the policy reflected in the scheduling rule. In his
reasons for making the Permission Order, Andrew Baker J indicated, among other things, that he
considered it properly arguable that the Secretary of State had not yet made a decision on ECAT leave (as
opposed to some other form of discretionary leave) in relation to JP.

62. On 2 April 2019 the Secretary of State filed her Detailed Grounds of Defence, in which she stated that
she had not decided JP's application for ECAT leave but would do so by 15 April 2019. On 23 April 2019
she issued her decision refusing ECAT leave to JP.

_Factual background of BS's claim_

63. BS has provided a witness statement dated 15 November 2018, with a number of exhibits. She is a
national of Albania. She is 33 years old.

64. On 2014 BS was deceived by a man whom she considered to be her boyfriend, but who was a
trafficker, into travelling from Albania to Italy, where she was forced to have sex with numerous men every
day for two years.

65. In 2016 traffickers moved BS from Italy via Switzerland and Belgium to Brighton, where she was kept
in a house and forced to have sex with men. She was occasionally forced to have unprotected sex, and
she became pregnant. The traffickers forced her to have an abortion.

66. BS escaped from the traffickers on 8 February 2017. In the summer of 2018, she underwent eight
weeks of counselling at Somerset and Avon Rape and Sexual Abuse Support to help her begin to address
the trauma she had suffered as a result of the serious and long-term sexual exploitation I have described.
In November 2018 she began a six-month counselling course at Womankind. She has suffered from
depression and has been prescribed Mirtazapine, an anti-depressant.

67. Following her escape from the traffickers on 8 February 2017, BS travelled to London, where she went
to the police. On 14 February 2017, the police referred her to the Home Office as a potential victim of
trafficking. She received a positive reasonable grounds decision on the same day.

68. BS made an application for asylum and attended an asylum screening interview on 22 February 2017.
After providing a witness statement dated 3 April 2017 to the Home Office, BS attended a full asylum
interview on 15 August 2017.


-----

Secretary of State for the Home Department [2019] EWHC....

69. On 29 March 2018 DPG sent a pre-action protocol letter to the Secretary of State, challenging her
delay in making a conclusive grounds decision. On 13 April 2018 the Secretary of State responded saying
that she would endeavour to make the decision within three months, absent special circumstances. On 15
May 2018 the Secretary of State made a positive conclusive grounds decision in relation to BS. In her letter
notifying BS of that decision, the Secretary of State stated that a decision on BS's application for ECAT
leave was “on hold” pending the Secretary of State's consideration of the Court of Appeal's decision in the
_PK (Ghana) case._

70. On 21 September 2018, in the BS Decision, the Secretary of State applied the scheduling rule to BS,
stating that it was not necessary to consider her application for ECAT leave until her asylum claim had
been determined.

71. On 24 October 2018 DPG sent a pre-action protocol letter to the Secretary of State challenging her
delay in making a decision in relation to BS's application for ECAT leave. On 1 November 2018 the
Secretary of State replied stating that she was actively working on BS's case and aimed to have made a
decision within eight weeks, absent special circumstances.

72. On 19 November 2018, BS issued her application for judicial review of the BS Decision and the policy
reflected in the scheduling rule.

73. On 12 December 2018 the Secretary of State filed her Acknowledgement of Service and Summary
Grounds of Defence to BS's claim.

74. In a letter dated 22 January 2019 the Secretary of State notified BS that her application for asylum was
refused and set out her reasons for that decision.

75. On 1 February 2019 the Secretary of State filed her Amended Summary Grounds of Defence, in which she
stated that her decision on BS's application for ECAT leave had also been made.

76. On 13 March 2019 the Permission Order was sealed by the court, granting BS permission to apply for
judicial review of the BS Decision and the lawfulness of the policy reflected in the scheduling rule. As I
have already noted in relation to JP's claim, in his reasons for making the Permission Order, Andrew Baker
J indicated, among other things, that he considered it properly arguable that the Secretary of State had not
yet made a decision on ECAT leave (as opposed to some other form of discretionary leave) in relation to
BS.

77. On 27 March 2019 BS filed her Re-amended Statement of Facts and Grounds of Judicial Review (“the
BS Grounds”), challenging the Secretary of State's contention that she had determined BS's application for
ECAT leave.

78. On 2 April 2019 the Secretary of State filed her Detailed Grounds of Defence, in which she stated that
she had not decided BS's application for ECAT leave but would do so by 15 April 2019. On 23 April 2019
she issued her decision refusing ECAT leave to BS.

_Professor Katona's evidence regarding the impact of delay on victims of trafficking_

79. The claimants provided as part of their evidence a witness statement dated 18 December 2018 of Mr
Adam Hundt, a partner at DPG. One of the exhibits to that witness statement is a witness statement dated
10 October 2018 prepared by Professor Cornelius Katona, a practising psychiatrist and Medical Director of
the Helen Bamber Foundation. The Helen Bamber Foundation is a human rights charity based in London,
the principal activity of which is to provide, through specialist teams of therapists, doctors and legal
experts, integrated care to individuals who have experienced torture, trafficking and other human rights
violations.

80. Professor Katona's witness statement was given in another claim raising similar issues, in which JP
and BS had proposed to join before receiving their positive conclusive grounds decisions. JP, in fact, was

originally a co‑claimant in that other claim, but withdrew after receiving her positive conclusive grounds

d i i h BS h d i d h iti l i d d i i b f th l i i d


-----

Secretary of State for the Home Department [2019] EWHC....

The substance of Professor Katona's evidence, according to Mr Hundt, applies mutatis mutandis to these
claims and deals with the mental health consequences of delay in determining ECAT leave for victims of
trafficking who also have pending asylum applications.

81. Professor Katona explains that a delay in granting ECAT leave (or some other form of leave to remain)
to a victim of trafficking makes it much more difficult for the victim to engage fully in and thereby benefit
from trauma-focused work. He considers that “prolonged indefinite uncertainty of waiting for a decision is
also clinically distressing and destabilising” and that the inability of a victim of trafficking, without some form
of leave to remain, to work or study:

“… can increase survivors' social isolation which is further aggravated by the difficult financial
circumstances in which they have to subsist pending the conclusion of the NRM identification process.
Even in circumstances where survivors receive some emotional support through the NRM, they
nonetheless cannot lead full and free lives and are constrained economically, which increases stress and
can increase vulnerability to further exploitation. All these factors can contribute to prolonged mental ill
health and worsen long-term prognosis. This may in turn impede their ability to give evidence, either in
their own immigration cases, for the purpose of accessing their legal rights and entitlements, or in providing
witness evidence for police investigations.”

_The Policy and the Trafficking Guidance_

82. To provide more context for consideration of the Secretary of State's policies at issue in these claims, I
set out below relevant provisions from the Policy and the Trafficking Guidance.

83. The Policy provides in relevant part at pages 6 to 7 as follows:

“Background to discretionary leave for potential victims of modern slavery

…

When to consider a grant of discretionary leave

A person will not qualify for discretionary leave (DL) solely because they have been identified as a victim of
**_modern slavery – there must be reasons based on their individual circumstances to justify a grant of DL_**
where they do not qualify for other leave such as asylum or humanitarian protection.

Where the case involves a child the best interest of the child should always be factored into the
consideration. The Secretary of State has the power to grant leave on a discretionary basis outside the
rules from residual discretion under the _[Immigration Act 1971. Discretionary leave is a form of leave to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
remain that is granted outside the Immigration Rules in accordance with this policy. Applications for DL
cannot be made from outside the UK. Part 9 of the Immigration Rules covers the general grounds for
refusal and must be consulted and applied before DL is granted.

Discretionary leave may be considered where a Competent Authority has made a positive conclusive
grounds decision that an individual is a victim of modern slavery[,] they are not eligible for any other form
of leave (such as asylum or humanitarian protection) and either:

    - leave is necessary owing to personal circumstances

    - leave is necessary to pursue compensation

     - victims who are helping police with their enquiries [sic]

…”

84. The section of the Policy in which the scheduling rule appears provides in relevant part at page 12 as
follows:

“Actions to take following a positive conclusive grounds decision

Immigration cases


-----

Secretary of State for the Home Department [2019] EWHC....

Victims of **_modern slavery also make asylum claims. Where they do it is for the Home Office to make_**
decisions on the asylum claim once a conclusive grounds decision has been taken.

A positive conclusive grounds decision does not result in an automatic grant of immigration leave.

However, if the Home Office is the Competent Authority it will automatically consider whether a grant of
discretionary leave (DL) is appropriate under the following criteria:

- those relating to personal circumstances

- assisting police with enquires [sic]

- pursuing compensation once a positive conclusive grounds decision is issued

_All outstanding asylum decisions should be taken before any consideration is given to whether the victim is_
_eligible for discretionary leave. If it is decided that a grant of leave is appropriate and the length of that_
leave is more generous than any discretionary leave grant, that leave should be granted. This may be the
case where the person qualifies for a grant of asylum or humanitarian protection or for leave to remain on
the basis of family or private life.” (emphasis added)

85. The relevant section of the Trafficking Guidance provides as follows:

“Home Office Competent Authority next steps for live immigration cases following a positive
**Conclusive Grounds decision**

Action 5: make a decision on any outstanding asylum claim

Many victims of modern slavery also make asylum claims. These are usually non EEA nationals although
not always.

The Home Office may make a positive decision on an asylum claim whilst a person is being considered
under the NRM process. Once a conclusive grounds decision has been taken, any outstanding claim for
asylum should be decided when possible.

If a person seeks to rely on being a victim of modern slavery as part of their asylum claim, the information
and evidence gathered during the NRM process and the findings in respect of whether a person is a victim
of modern slavery will inform the asylum process.

Asylum processes which need to take place prior to taking a decision on asylum but fall short of the
decision itself can also be carried out during the NRM process to ensure that asylum decisions do not
encounter significant and unjustified delays. The outcome of the reasonable or conclusive grounds
decision is not indicative of the outcome of any asylum claim. A positive or negative reasonable or
conclusive grounds decision on modern slavery does not automatically result in asylum being granted or
refused. This is because the criteria used to grant asylum is not the same as the criteria used to assess
whether a person is a victim of modern slavery.

The conclusive grounds decision will be included in any outstanding asylum decision made after that
decision as a finding of fact on whether the person was a victim of **_modern slavery or not; unless_**
information comes to light at a later date that would alter the finding of modern slavery.

Every asylum claim must be considered on its merits and in line with existing guidance.

Action 6: consider whether the victim is eligible for discretionary leave

If the Home Office is the Competent Authority, a positive conclusive grounds decision does not result in an
automatic grant of immigration leave.

However, the Home Office will consider whether a grant of discretionary leave is appropriate following a
positive conclusive grounds decision. This consideration will happen automatically where the individual has
received a positive conclusive grounds decision from the Home Office Competent Authority teams.

…”


-----

Secretary of State for the Home Department [2019] EWHC....

_The Upper Tribunal decision in the case of VHH v SSHD (JR/3134/2018)_

86. In her Summary Grounds of Defence filed on 12 December 2018 with her Acknowledgement of
Service in relation to each of JP's claim and BS's claim, the Secretary of State referred to and relied on the
Upper Tribunal case of VHH v SSHD (JR/3134/2018), an unreported decision of UTJ Kebede made on 21
November 2018 in respect of a judicial review claim brought by VHH, a victim of trafficking. In his claim,
VHH challenged the delay in the Secretary of State's making a decision on ECAT leave for him pending
resolution of his asylum claim. The grounds of challenge in that case were somewhat different to those in
this case, although there is some overlap in the claimant's arguments.

87. The Secretary of State relied on VHH in her Summary Grounds of Defence to establish that JP's claim
and BS's claim were not arguable and relied, in particular, on the reasoning of UTJ Kebede at [34] to [38]
of her decision. At [37] UTJ Kebede held that making a decision on ECAT leave after deciding on an
asylum application was not contrary to Article 14(1) of ECAT. She did, however, accept the claimant's
submission that the Secretary of State's delay in that case in deciding the asylum application and then
making a decision on ECAT leave was unjustified and therefore contrary to then relevant policy guidance
and the terms of ECAT.

88. In the first paragraph of his reasons for making the Permission Order, Andrew Baker J said:

“It is properly arguable that:

(a) the Defendant's current policy (since September 2018) for considering discretionary leave or the
purpose of complying with Article 14(1) of the European Convention on Action against Trafficking in Human
Beings ('ECAT') mandates the deferral of consideration of such leave, if an asylum or international
humanitarian protection claim has been made, until after the asylum/protection claim has been determined;
and

(b) such a 'blanket' deferral is contrary to Article 14(1) of ECAT.

In that regard, and without limitation, it seems to me well capable of being the case that the personal
situation of a trafficking victim, _including her status (if applicable) as an asylum/protection claimant, may_
render it necessary that she stay in the country where she has been rescued from trafficking and claimed
asylum/protection (if she has). On the face of things, Article 14(1)(a) of ECAT calls for an assessment of
the necessity of the victim staying in that country owing to their personal situation (and mandates the grant
of a residence permit where such necessity is assessed to exist), not an assessment of the necessity of
granting residence under Article 14(1) to enable her to stay. The view to a contrary effect expressed,
_obiter, in the Upper Tribunal in_ _R (VHH) v SSHD, 21 November 2018, seems to me open to doubt.”_
(emphasis in original)

_The grounds of challenge_

89. There are three grounds of challenge that are maintained by each of JP and BS in their respective
claims, which can be dealt with together. JP's grounds of challenge are set out in her Amended Statement
of Facts and Grounds of Judicial Review dated 18 December 2018. BS's grounds of challenge are set out
in her Re-Amended Statement of Facts and Grounds of Judicial Review dated 25 March 2019. Other
grounds of challenge mounted on the basis of Articles 4 and 8 of the European Convention on Human
Rights (“ECHR”) are no longer pursued.

90. The grounds of challenge in each claim are:

i) the Secretary of State had failed to apply the Policy in relation to each claimant in that she had failed to
make a decision in relation to ECAT leave for each claimant;

ii) the scheduling rule and, as a consequence, the JP Decision and the BS Decision, are incompatible with
the obligations of the UK under ECAT; and

iii) the scheduling rule is incompatible with Article 14 of the ECHR.


-----

Secretary of State for the Home Department [2019] EWHC....

_Ground 1 - No decision on ECAT Leave_

91. The first ground of challenge in each claim is that the Secretary of State had failed to make a decision
in accordance with her own policy in relation to ECAT leave for each of JP and BS.

92. As I have noted above, the Secretary of State had originally taken the view, in her Summary Grounds
of Defence in relation to JP's claim and her Amended Summary Grounds of Defence in relation to BS's
claim, that her decision on ECAT leave was made at the same time as her decision in relation to asylum.
Andrew Baker J indicated in the Permission Order that it was arguable that the Secretary of State had not
yet made a decision on ECAT leave.

93. In her Detailed Grounds of Defence in relation to each claim, the Secretary of State stated that she
had not yet decided the applications for ECAT leave in relation to the claimants but would do so by 15 April
2019. In the event, she issued her decision on ECAT leave in relation to each of JP and BS on 23 April
2019, refusing it in each case.

94. The claimants characterise the foregoing as the Secretary of State having conceded this ground of
challenge.

95. The Secretary of State notes that this ground of challenge was introduced by amendment to each
claimant's grounds for judicial review. She characterises her position as her having simply acted in
accordance with the scheduling rule, and that the claimants no longer pursue this ground. She also notes
that the decision on ECAT leave in relation to each claimant has now been made.

96. This ground is no longer extant as far as each substantive claim is concerned. Mr Buttler submitted
that it may be relevant to costs in due course.

_Ground 2 – The scheduling rule is inconsistent with ECAT_

97. The second ground of challenge is that the scheduling rule and, as a consequence, the JP Decision
and the BS Decision, are incompatible with the obligations of the UK under ECAT.

98. In his skeleton argument, Mr Buttler sets out the issue under this ground as follows:

i) Is it consistent with Article 14(1) of ECAT never to grant ECAT leave to those with a well-founded claim
for asylum?

ii) Put another way, on its proper construction, is Article 14(1) of ECAT a residual (or fall-back) provision,
applicable only if no asylum claim is made or an asylum claim is rejected?

99. Ms Williams objected to this formulation of the issues on the ground that the claims were not pleaded
in this way. I accept that this is not, in terms, how this ground was pleaded in the JP Grounds and in the BS
Grounds, but in my view the difference in approach is, essentially, semantic. The same arguments underlie
this ground. I do not think that the way Mr Buttler has formulated the issues in his skeleton argument is
particularly helpful, and I therefore consider whether the arguments now made by the claimants support
their case as pleaded, rather than by reference to this formulation of the issues in Mr Buttler's skeleton.

100. Mr Buttler made a number of submissions in relation to this ground. First, he noted the claimants'
evidence as to the substantial delays in making decisions on asylum applications, citing the Secretary of
State's asylum statistics for 2018, which showed that in almost half the cases it took longer than six months
to reach an initial decision on an asylum application.

101. Mr Buttler noted that in JP's case, there was a delay of almost five months between the date of her
conclusive grounds decision (28 June 2018) and the decision on her asylum application (23 November
2018), with a further delay of five months before the decision on ECAT leave was made (23 April 2019). In
BS's case, there was a delay of over eight months between the date of her conclusive grounds decision
(15 May 2018) and the decision on her asylum application (22 January 2019), with a further delay of three
months before the decision on ECAT leave was made (23 April 2019).


-----

Secretary of State for the Home Department [2019] EWHC....

102. I have already summarised at [38] above the claimants' general submissions on the impact of delay
in determining ECAT leave on victims of trafficking and at [77] to [79] I have summarised the evidence of
Professor Katona in that regard.

103. Mr Buttler submitted that the specific impact on JP of the delay in determining ECAT leave was and is
that:

i) she lost her basic trafficking support following the application of the 14-day rule, which applied in her
case, with the effect that she was reduced to NASS support and lost her support worker;

ii) she is prohibited from working or studying;

iii) she is prohibited from claiming mainstream benefits, whereas with ECAT leave, if she were not
working, she would be entitled to £189.01 per week in Jobseeker's Allowance, Child Tax Credits and Child
Benefit, plus Housing Benefit; and

iv) her recovery from the traumatic abuse she suffered as a result of having been trafficked has been
impeded due to the uncertainty of her immigration status, and she feels unable to begin counselling until
her immigration status is settled, which is consistent with the evidence of Professor Katona that trafficking
victims, until granted leave to remain, are “often unable to undertake trauma-focussed work”.

104. Mr Buttler submitted that the specific impact on BS of the delay in determining her ECAT leave was
and is that:

i) she lost her basic trafficking support following the application of the 14-day rule, which applied in her
case, with the effect that on 30 May 2018 she was required to move into shared NASS accommodation,
which she found to be cramped, dirty and unsafe and to live on the NASS financial support rate of £37.75
per week;

ii) she is prohibited from working or studying, despite having had a University education in Albania;

iii) she is prohibited from claiming mainstream benefits, whereas with ECAT leave she would be entitled to
£73.10 per week in Jobseeker's Allowance, plus Housing Benefit and possibly disability-related benefits;
and

iv) her recovery from the traumatic abuse she suffered as a result of having been trafficked has been
impeded due to the uncertainty of her immigration status and her consequent inability to work or study,
which, as Professor Katona noted in his evidence, has the effect of prolonging her mental ill health and
worsening her long-term prognosis.

105. Mr Buttler submitted that the scheduling rule prevents the Secretary of State, on a blanket basis, from
considering ECAT leave until a decision is made on the related asylum application. This blanket limitation
is not authorised by ECAT. ECAT requires that a residence permit must be granted if the relevant
competent authority considers that the victim's stay in that member state is necessary owing to the victim's
personal situation or for the purpose of their cooperation with the competent authorities in investigation or
criminal proceedings. Given that the purpose of the Policy, of which the scheduling rule forms part, is to
give effect to ECAT, the scheduling rule is irrational. In other words, a blanket rule deferring a decision on
ECAT leave until an asylum application from the same person is decided bears no rational relationship to
the purpose of the Policy.

106. Mr Buttler submitted that in deciding when to make a determination on ECAT leave, the Secretary of
State must have regard to the victim's vulnerability and safety and protection needs. This view, he said, is
supported by the decision of UTJ Kebede in VHH at [42] where she found that the impact of the delay in
making a decision on ECAT leave in relation to VHH:

“flies in the face of the requirements in Article 12 of the Convention for account to be taken of the special
needs of vulnerable people and the victim's safety and protection needs.”


-----

Secretary of State for the Home Department [2019] EWHC....

While Mr Buttler supported this conclusion, he did not seek to support UTJ Kebede's reasoning in that
case, noting that it appeared that she did not have the benefit of the same submissions as those advanced
on behalf of JP and BS in this case.

107. Mr Buttler submitted that ECAT leave and refugee leave perform very different functions. ECAT leave
is a temporary form of leave, lasting up to 30 months, intended to facilitate a victim's recovery or the
victim's cooperation with a criminal investigation. Refugee leave is longer term and is granted with a view
to settlement. Given the length of time it often takes to determine asylum claims, the grant of ECAT leave
pending determination of the asylum claim will, in many cases, have real utility, as in the cases of JP and
BS.

108. Mr Buttler submitted that Article 14(5) of ECAT expressly contemplates that a victim of trafficking may
be granted ECAT leave before his or her asylum claim is determined.

109. Andrew Baker J commented on this point in the Permission Order as follows:

“On the face of things …, a 'blanket deferral', so that leave to remain pursuant to Article 14(1) of ECAT is
not considered unless and until an asylum/protection claim (if made) has been rejected, seems
inconsistent with Article 14(5) of ECAT.”

110. Mr Buttler submitted that ECAT does not permit victims to be left without adequate support. They
must be afforded either subsistence support under Articles 12(1) and 12(2) of ECAT or the support under
Articles 12(3) and 12(4) of ECAT available to those with a residence permit granted under Article 14(1) of
ECAT. In the UK that means basic trafficking support or, where ECAT leave has been granted, enhanced
trafficking support. The scheduling rule taken with the 45-day rule creates a lacuna where recognised
victims of trafficking who are awaiting an asylum decision will receive neither form of support. As held by
Mostyn J in the case of K, NASS support is not sufficient to meet the requirements of Articles 12(1) and
12(2) of ECAT.

111. Finally, Mr Buttler accepted that it may sometimes be appropriate to decide an asylum claim before
deciding entitlement to ECAT leave. It is, he submitted, the blanket nature of the scheduling rule that is
unlawful.

112. For the Secretary of State, Ms Williams submitted that the Secretary of State's published policies are
consistent with the UK's obligations under ECAT and give proper effect to those obligations. The relevant
policy considerations are those set out in the Policy and in the Trafficking Guidance, which I have set out at

[81] to [83] above.

113. Ms Williams noted that the legality of the scheduling rule was considered by the Upper Tribunal in the
case of VHH. She submitted that UTJ Kebede's reasoning in that case at [34] to [38] was compelling and
correct and she invited this court to take the same view.

114. Ms Williams noted that the claimants pose a false dichotomy between ECAT leave and refugee leave
in that, in either case, there is a grant of the same “permission” to “live, work and settle” in the United
Kingdom pursuant to the [1971 Act]. To the extent that the claimants are suggesting that the effect of the
scheduling rule is that a person with a well-founded asylum claim will never have their claim for ECAT
leave considered and that that is incompatible with the obligations of the UK under ECAT, that argument is
rejected by the Secretary of State. As has already been noted, refugee leave is more advantageous than
ECAT leave, as it is generally for a longer period and with more generous conditions. Accordingly, if
refugee leave is granted, it would be otiose for the Secretary of State also to consider the application for
ECAT leave. It is simply not necessary. There is no incompatibility with the UK's obligations under Article
14(1) of ECAT. If asylum is granted, then any obligation under Article 14(1) of ECAT is discharged without
the need for any separate consideration of ECAT leave.

115. Ms Williams submitted that the rationale for the scheduling rule is as follows:

i) it is in the best interests of an applicant for the more advantageous form of leave, refugee leave, to be
determined first; and


-----

Secretary of State for the Home Department [2019] EWHC....

ii) there are good administrative reasons for considering the asylum claim first, and therefore refugee
leave, namely that the decision-maker will only need to consider one claim against one set of criteria.

116. Ms Williams also noted that this order of consideration was consistent with the decision-making
process followed by the Secretary of State in relation to cases not involving trafficking, where an individual
claims, but does not qualify for, asylum and has to be considered for the grant of leave on some other
basis. This includes, she submitted, situations in which the UK has obligations under an international
instrument to protect the individual. She gave as an example a case where an individual claims to fear
persecution in their country of origin. The person's asylum claim is required to be determined before it is
determined whether the person is entitled to humanitarian protection under Article 3 of the ECHR, since
such protection is only available under para 339C(ii) of the Immigration Rules to a person who is not a
refugee.

117. Ms Williams further noted that discretionary leave outside the trafficking context is not available to a
person who qualifies for asylum, humanitarian protection, any other form of leave under the Immigration
Rules or Leave Outside the Rules for Article 8 ECHR reasons, as set out in the paras 1.1, 2.1 and 3.1 of
the Secretary of State's Asylum Policy Instruction “Discretionary Leave”. Thus, she submits, asylum and
humanitarian protection claims must logically be determined before any question of discretionary leave can
be determined.

118. Ms Williams submitted that Article 14(1) does not require that a decision to grant a residence permit
must be made at the same time as, or even within a particular period of time after, a positive conclusive
grounds decision. She referred to paras 180 and 181 of the Explanatory Report to ECAT, which discusses
the objects of Article 14, and she notes that it is made clear there that the provision of the residence permit
contemplated by Article 14 is “meets both the victims' needs and the requirements of combating” trafficking
in human beings, it being the case that:

“… immediate return of the victims to their countries is unsatisfactory both for the victims and for the lawenforcement authorities endeavouring to combat the traffic.”

119. Having the foregoing in mind, Ms Williams submitted, it cannot be said that the mere fact that a
residence permit is not granted prior to a decision on asylum being made does not result in a failure to
meet the individual's needs, nor does it result in the individual's being immediately returned to her or his
country of residence.

120. In relation to the argument that Article 14(5) of ECAT contemplates that a victim of trafficking may be
granted ECAT leave before his or her asylum claim is determined, Ms Williams first noted that this
argument was not raised in the JP Grounds or the BS Grounds. She accepted that it was, however,
mentioned by Andrew Baker J in the Permission Order and therefore addressed it by submitting that Article
14(5) seeks only to ensure that a victim of trafficking is not prejudiced in any way by the grant of a
residence permit with respect to any right that she or he may have to claim and enjoy asylum. It says
nothing about the relative timing of the determination of a person's asylum claim and her or his application
for ECAT leave.

121. Ms Williams noted that the JP Grounds and the BS Grounds alleged that the scheduling rule violated
Articles 12(3) and 12(4) of ECAT, under which enhanced trafficking support is provided in the UK but did
not set out reasons for that allegation. She also noted that this argument was not raised in the claimants'
skeleton argument, but, in the event that the claimants were to raise this argument again during the
hearing, she submitted in her skeleton argument that para 165 of the Explanatory Report to ECAT makes it
clear that “lawfully resident” victims are those who have been issued with a residence permit under Article
14, in other words, ECAT leave in relation to the UK. Accordingly, she submitted, it cannot be argued that
there is any inconsistency between the scheduling rule and Articles 12(3) and 12(4).

122. Finally, Ms Williams submitted that ECAT leave was determined in relation to each of the claimants
prior to the hearing by the decisions of the Secretary of State made on 23 April 2019. The present issue
was, at the date of the hearing, now academic as far as the claimants were concerned. She noted that if


-----

Secretary of State for the Home Department [2019] EWHC....

the ECAT leave decision had been made at or about the time of the positive conclusive grounds decision,
as the claimants contend it should have been, the practical outcome for each of the claimants would have
been no more favourable than the actual outcome. From the date of the refusal of ECAT leave, they each
would have been treated as asylum seekers entitled (after application of the 14-day rule in their cases) only
to NASS support until the decisions were made on their asylum claims on 23 November 2018 in respect of
JP and 22 January 2019 in respect of BS. This is, in fact, what happened. After determination of their
asylum claims, neither JP nor BS would have had a basis for staying in the UK, and that again, as at the
date of the hearing, was the position. Accordingly, section 31(2A) of the Senior Courts Act 1981 applied,
under which the High Court must decline to grant relief on the claimants' application for judicial review on
the basis of its appearing to the court:

“… to be highly likely that the outcome for the applicant would not have been substantially different if the
conduct complained of had not occurred.”

123. In reply to this point, Mr Buttler for the claimants said that it cannot be assumed that the decision on
ECAT leave in respect of JP and BS would have been the same had it been made at or about the time of
the conclusive grounds decisions in relation to each of them. He submitted that the burden was on the
Secretary of State to show that it is “highly likely” the decision would have been the same, and that this
was not a burden that she has discharged in this case.

124. Dealing first with Ms Williams's invitation to the court to adopt the reasoning of UTJ Kebede in the
case of VHH as to the enforceability of the scheduling rule, I note that UTJ Kebede's analysis appears to
be based, at least in part, on a mistaken assumption that basic trafficking support for a victim continues
until a decision is made on the victim's asylum claim and, where that decision is negative, until the victim is
returned to his or her country of residence. UTJ Kebede in _VHH relies at [37] of her judgment on a_
mistaken concession to that effect made by agreement between counsel in the case of PK (Ghana), which
was set out at [46] of Hickinbottom LJ's judgment in that case. UTJ Kebede does not consider or take into
account the effect of the 45-day rule.

125. Ms Williams accepted that the judge's reliance on the mistaken concession made in PK (Ghana) was
not correct, but she submitted that, nonetheless, overall the judge's reasoning in _VHH held good. I note_
that UTJ Kebede does not appear to have been asked to consider the arguments that have been raised by
the claimants in this case. Accordingly, it is of limited assistance to me in relation to the resolution of this
claim.

126. I agree with Ms Williams that, to the extent that the JP Grounds and the BS Grounds alleged that the
scheduling rule violated Articles 12(3) and 12(4) of the ECAT, that argument is unsustainable. I note that
Mr Buttler did not pursue that at the hearing, and nothing more needs to be said about it.

127. I also agree with Ms Williams that Article 14(5) does not provide particular assistance to the
claimants' case. I agree with Mr Buttler that the wording of Article 14(5) contemplates the possibility of a
permit being granted to a person under Article 14 before an asylum claim by the same person is
determined, but if it is otherwise justifiable to have a rule deferring consideration of ECAT leave until after a
related asylum claim is determined, then Article 14(5) does not conflict with such a rule.

128. I accept Ms Williams's submission that if refugee leave is granted to a victim of trafficking, it is not
necessary for the Secretary of State to make a further determination in relation to ECAT leave in order to
satisfy the requirements of Article 14(1) of ECAT.

129. It is common ground that refugee leave is more advantageous than ECAT leave. There would be no
basis for these claims if there were not, in practice, a material delay between the making of a conclusive
grounds decision and the making of a decision on an asylum claim in relation to the same person. It is that
material delay, coupled with the effect of the 45-day rule, which lies at the heart of this case. Ms Williams
did not seek to deny the assertion made by the claimants that it is common for the Secretary of State to
take several months before making a decision on an asylum claim, as happened in the claimants' own
cases. The claimants referred to the Secretary of State's asylum statistics for 2018, which recorded that in


-----

Secretary of State for the Home Department [2019] EWHC....

60,214 out of 127,302 cases, representing 47 per cent of the total number of cases, the Secretary of State
took longer than six months to reach an initial decision on asylum.

130. As I have already noted, in relation to JP there was a gap of almost five months between her
conclusive grounds decision and the decision on her asylum application. In the case of BS, there was a
gap of over eight months. As a result of the application of the 14-day rule in their cases, they each lost
basic trafficking support for a period of months and were reduced to NASS support until their asylum
applications were determined.

131. Ms Williams submitted that it was in the best interests of an applicant for the more advantageous
form of leave to remain, namely, refugee leave, to be determined first. She did not, however, articulate why
that is in the best interests of an applicant. A better outcome for the applicant would clearly be to have a
decision on ECAT leave made as soon as possible after a positive conclusive grounds decision was made
so that, either way, the applicant would know where she or he stands in relation to that issue. If ECAT
leave were to be granted, it would be for the reasons that apply to the grant of ECAT leave. It would have
no effect on the application for asylum, as stipulated by Article 14(5) of ECAT. If the asylum claim were
subsequently rejected, that would not affect the justification for ECAT leave having been granted, the
criteria for the grant of each form of leave being different. If ECAT leave were granted and the asylum
claim subsequently rejected, that would not put the relevant victim or the Secretary of State in an
anomalous position. If the asylum claim were granted, there would be no conceptual difficulty with the
terms applicable to the person's leave to remain in the form of ECAT leave being amended to conform with
the more favourable terms applicable to refugee leave.

132. Accordingly, the Secretary of State's justification for the scheduling rule amounts, in substance, only

to “good administrative reasons … namely that the decision‑maker will only need to consider one claim

against one set of criteria”, as I have summarised that submission by Ms Williams at [113] above. This is a
rational justification for the policy, so I reject the submission of Mr Buttler that the scheduling rule is
irrational. As Ms Williams noted, and as I summarised at [114] above, the scheduling rule sets out an order
of consideration of decisions that is consistent with the Secretary of State's approach to other cases where
more than one form of leave to remain is potentially available to be considered in relation to an applicant
for leave to remain.

133. The question remains, however, whether the scheduling rule, as currently formulated, is consistent
with the obligations of the UK under Articles 12(1), 12(2) and 14(1) of ECAT.

134. I note that in dealing with the point regarding Articles 12(3) and 12(4) of ECAT that had been raised
in the JP Grounds and the BS Grounds (but not in the claimants' skeleton argument), Ms Williams said the
following at para 5.39 of her skeleton argument:

“… in considering asylum before DLR [ECAT leave] and thereby deferring the possible grant of a
'residence permit' until such time as asylum has been considered, the Secretary of State takes due
account of a victim's safety and protection needs in accordance with Article 12(2) ECAT. Victims of
trafficking remain entitled in the interim to support by way of asylum support [NASS support]. The package
of support provided includes free accommodation and a weekly cash allowance to cover their other
essential living needs, and they also have access to free NHS medical treatment. They may also continue
to receive support within the NRM, if an application is made for an extension of NRM support beyond the
time at which it would normally terminate (currently 45 day after a positive conclusive grounds decision).”

135. In my view, the foregoing encapsulates the Secretary of State's position in defence of this claim more
generally and highlights a key difference between the position of the Secretary of State and the position of
the claimants. The Secretary of State says that providing NASS support to an actual victim of trafficking,
during the period between the expiration of the 45-day period following the conclusive grounds decision
and the determination of the victim's asylum claim, is compatible with the obligations of the UK under
Articles 12(1), 12(2) and 14(1) of ECAT. The claimants say that providing only NASS support during that


-----

Secretary of State for the Home Department [2019] EWHC....

period, which can last several months, is clearly not sufficient and is therefore incompatible with the UK's
obligations under those provisions of ECAT.

136. In my view, the scheduling rule, as currently formulated, is not consistent with the obligations of the
UK under Articles 12(1), 12(2) and 14(1) of ECAT.

137. Although it may be administratively efficient always to consider an asylum claim before determining
ECAT leave, where there is, in practice, likely to be a significant delay after a positive conclusive grounds
decision has been made before an asylum decision is made, then there is a material risk that, in a
significant number of cases, victims will be reduced to NASS support for a considerable period of time.
Mostyn J in K held that NASS support is not sufficient to meet the requirements of Articles 12(1) and 12(2)
of ECAT. Ms Williams did not argue that his decision in that case was wrong.

138. The evidence of Professor Katona and the evidence provided by JP and BS in relation to their own
cases amply demonstrate the special safety and protection needs of victims, which the Secretary of State
is required by ECAT to bear in mind in determining whether it is appropriate to defer making a decision on
ECAT leave for a victim before making a decision on the victim's asylum claim. The combined effect of (i)
the foregoing, (ii) the long delay that may occur (and did in this case for both JP and BS) between a
positive conclusive grounds decision in respect of a victim and the determination of the victim's asylum
claim and (iii) the effect of the 45-day rule mean that the victim may receive an inadequate level of support
for an extended period of time in circumstances where it is necessary for their personal situation that they
have access to, at least, basic trafficking support if not the enhanced trafficking support that would be
available to them if ECAT leave were granted.

139. Accordingly, the scheduling rule in its current form, where it applies regardless of the personal
position of a victim who has also made an asylum claim, is, in my judgment, not compatible with the
obligations of the UK under Article 14(1) of ECAT and is therefore unlawful.

140. As for the argument raised by Ms Williams on behalf of the Secretary of State that the court should
decline to grant relief, applying section 31(2A) of the Senior Courts Act 1981, on the basis that the outcome
for the claimants in this case would not have been substantially different if the scheduling rule had not been
applied, I agree with the submission made by Mr Buttler for the claimants that it cannot be assumed that
the decision on ECAT leave in respect of JP and BS would have been the same had it been made at or
about the time of the conclusive grounds decision in relation to each of them.

141. In making a decision about whether it is necessary for a victim to stay owing to their personal
situation or for the purpose of the victim's co-operation with the competent authorities in the investigation or
criminal proceedings, the Secretary of State needs to consider the position of the relevant victim at the time
the decision is made. Personal situations evolve and change, as do investigations and criminal
proceedings.

142. I note that, in relation to JP, there was a gap of almost 10 months between the conclusive grounds
decision and the decision on ECAT leave. In relation to BS, there was a gap of over 11 months. The
significant passage of time in each case makes it very difficult, if not impossible, in my view, to conclude
that it is “highly likely” the decision on ECAT leave would have been the same in relation to either, even if it
is possible or even probable that it would have been.

143. Accordingly, the claim succeeds on Ground 2.

_Ground 3 – The scheduling rule is incompatible with Article 14 of the ECHR_

144. The claimants also pursue a claim under Article 14 of the ECHR, which provides:

“The enjoyment of the rights and freedoms set forth in this Convention shall be secured without
discrimination on any ground such as sex, race, colour, language, religion, political or other opinion,
national or social origin, association with a national minority, property, birth or other status.”


-----

Secretary of State for the Home Department [2019] EWHC....

145. In Re McLaughlin _[2018] UKSC 48, 1 WLR 4250(SC), Baroness Hale said at [15] that this raises four_
questions, although these are not “rigidly compartmentalised”, namely:

“(1) Do the circumstances 'fall within the ambit' of one or more of the Convention rights?

(2) Has there been a difference of treatment between two persons who are in an analogous situation?

(3) Is that difference of treatment on the ground of one of the characteristics listed or 'other status'?

(4) Is there an objective justification for the difference in treatment?”

146. It appears to be common ground that:

i)  the circumstances fall within the ambit of one or more Convention rights (although, of course, the
Secretary of State denies that there has been a breach of any of those rights);

ii) due to the scheduling rule, there is a difference of treatment between two persons who are in an
analogous situation (namely, a victim with an asylum claim seeking ECAT leave and a victim without an
asylum claim seeking ECAT leave); and

iii) being a victim of trafficking who claims asylum falls within “other status” for purposes of Article 14.

147. In relation to circumstances falling within the ambit of one or more Convention rights, the Secretary of
State, of course, denies that there has been a breach of any of those rights, but appears to concede that
the circumstances fall within the ambit of one or more rights. The claimants argue that the provision of
ECAT leave falls within the ambit of Article 4 (Prohibition of slavery and forced labour) of the ECHR
because it forms part of a package of measures by which the state protects victims of trafficking. Article 8
(Right to respect for private and family life) of the ECHR is also engaged, according to the claimants, since
ECAT leave is a means by which a victim's right to live, work and study is promoted by the state. Article 1
of Protocol 1 (Protection of property) (“A1P1”) to the ECHR is also engaged according to the claimants
because ECAT leave confers access to state benefits, so a blanket refusal to consider an application for
ECAT leave pending determination of a related asylum claim blocks access to those benefits, and
therefore falls within the scope of A1P1 to the ECHR. In the case of K, Mostyn J found that Article 4 of the
ECHR and A1P1 to the ECHR were potentially engaged by the facts of that case in relation to potential
victims of trafficking. I am satisfied that Articles 4 and 8 of the ECHR are potentially engaged by the facts of
this case in relation to victims of trafficking, as well as A1P1 to the ECHR.

148. I also accept that an asylum-seeking victim, that is, a victim seeking ECAT leave who also makes an
asylum claim, is in an analogous position to a non-asylum-seeking victim, that is, a victim seeking ECAT
leave who does not make an asylum claim.

149. Ms Williams submitted that the appropriate comparators against whom the claimants' treatment is to
be compared are victims who were not entitled to and did not seek asylum, but who sought and were not
entitled to ECAT leave. This is because, given the decisions that were made by the Secretary of State in
relation to asylum and in relation to ECAT leave in respect of JP and BS, each was a victim who was not
entitled to, but did seek asylum, and who sought and was not entitled to ECAT leave. With respect, that
unnecessarily and, in my view, unfairly complicates the analysis, applying the benefit of hindsight. The
proper comparators for asylum-seeking victims for the purposes of this exercise are, quite simply, nonasylum-seeking victims. The positions are clearly analogous, and it is important to determine whether the
treatment of the former group differently from the latter group in relation to the timing of a decision under
Article 14(1) of ECAT is justified, without the benefit of hindsight.

150. Finally, I accept that the status of being an asylum seeker falls within “other status” for purposes of
Article 14 of the ECHR. I note that Mostyn J in the case of K at [38] held that being a potential victim of
trafficking is a qualifying status under Article 14 of the ECHR. I see no reason to take a different view in this
case in relation to actual victims of trafficking.

151. Accordingly, the question to resolve is whether there is an objective justification for the Secretary of
State's treating asylum-seeking victims differently from non-asylum-seeking victims by deferring


-----

Secretary of State for the Home Department [2019] EWHC....

consideration of ECAT leave until after the asylum decision rather than making that decision at the time of
or shortly after the positive conclusive grounds decision.

152. The burden of proving justification rests on the Secretary of State. In R (Quila) v SSHD _[2011] UKSC_
_45, [2012] 1 AC 621 (SC) at [44] Lord Wilson held that the burden of establishing justification of_
interference with the rights under Article 8 of the ECHR of the claimants in that case fell on the Secretary of
State. There is no reason why the position would be different in relation to justifying the difference in
treatment of asylum-seeking victims and non-asylum-seeking victims at issue in this case.

153. For purposes of this analysis under Article 14 of the ECHR, what must be justified is not the
scheduling rule, per se, but the difference in treatment between one group and another: A v SSHD _[2004]_
_UKHL 56, [2005] 2 AC 68(HL) at [68] (Lord Bingham)._

154. The test for assessing a purported justification by the Secretary of State for a difference in treatment
between one group and another is well-settled according to Lord Kerr in _Re Brewster_ _[2017] UKSC 8,_

[2017] 1 WLR 519(SC) at [66], where Lord Kerr refers to the judgment of Lord Wilson in Quila at [45], and
the judgment of the Supreme Court in Bank Mellat v HM Treasury (No 2) _[2013] UKSC 39, [2014] AC 70 at_

[20] (Lord Sumption) and [74] (Lord Reed). Although Lords Sumption and Reed disagreed on the
application of the test in the _Bank Mellat case, they agreed on the formulation of the test. Lord Reed's_
formulation at [74] of Bank Mellat was as follows:

“… it is necessary to determine (1) whether the objective of the measure is sufficiently important to justify
the limitation of a protected right, (2) whether the measure is rationally connected to the objective, (3)
whether a less intrusive measure could have been used without unacceptably compromising the
achievement of the objective, and (4) whether, balancing the severity of the measure's effects on the rights
of the persons to whom it applies against the importance of the objective, to the extent that the measure
will contribute to its achievement, the former outweighs the latter.”

155. Mr Buttler noted in his submissions that the Secretary of State had not filed any evidence to support
its defence against this claim. There is therefore no evidence that the Secretary of State considered the
possible impact of the scheduling rule on victims with asylum claims and took that into account when
making his decision to implement it. While the Secretary of State is not precluded from attempting to justify
the differential treatment of asylum-seeking and non-asylum-seeking victims _post hoc, the level of_
deference that might otherwise have been afforded his decision by the court is necessarily less. Mr Buttler
justified these propositions by reference to the following passage from the judgment of Lord Mance in
_Belfast City Council v Miss Behavin' Ltd_ _[2007] UKHL 19, [2007] 1 WLR 1420 at [46]-[47]:_

“46. … [W]hat is the position if a decision maker is not conscious of or does not address his or its mind at
all to the existence of values or interests what are relevant under the Convention?

47. The court is then deprived of the assistance and reassurance provided by the primary decisionmaker's 'considered opinion' on Convention issues. The court's scrutiny is bound to be closer, and the
court may … have not alternative but to strike the balance for itself, giving due weight to such judgments as
were made by the primary decision-maker on matters he or it did consider.”

156. Mr Buttler also referred to a similar observation made by Lord Kerr in Re Brewster at [52]:

“Obviously, if reasons are proffered in defence of a decision which were not present to the mind of the
decision-maker at the time that it was made, this will call for greater scrutiny than would be appropriate if it
could be shown to have influenced the decision-maker when the particular scheme was devised.”

157. I note, however, that the next sentence in the same passage reads as follows:

“Even retrospective judgments, however, if made within the sphere of expertise of the decision-maker, are
worthy of respect, provided that they are made bona fide.”

158. I note that in Re Brewster at [64] Lord Kerr expands on these points as follows:


-----

Secretary of State for the Home Department [2019] EWHC....

“64. Where a conscious, deliberate decision by a government department is taken on the distribution of
finite resources, the need for restraint on the part of a reviewing court is both obvious and principled.
Decisions on social and economic policy are par excellence the stuff of government. But where the
question of the impact of a particular measure on social and economic matters has not been addressed by
the government department responsible for a particular policy choice, the imperative for reticence on the
part of a court tasked with the duty of reviewing the decision is diminished. … [T]he level of scrutiny of the
validity of the claims [by the government department as to the advantages of the policy choice] must
intensify to take account of the fact that the claims are made ex post facto and the claimed immunity from
review on account of the decision falling within the socio-economic sphere must be more critically
examined.”

159. Finally, in relation to the lack of evidence provided by the Secretary of State, Mr Buttler also referred
to the following statement of Lord Kerr in Re Brewster at [65], where His Lordship commented as follows
on a similar lack of evidence by the relevant government decision-maker in relation to the government
decision at issue in that case:

“… the attempt to justify [the relevant decision] was characterised by general claims, unsupported by
concrete evidence and disassociated from the particular circumstances of the claimant's case.”

160. In her Defence to each of JP's claim and BS's claim, in relation to Ground 3, the Secretary of State
gave the following justification of the scheduling rule at paras 33 and 34:

“33. In considering the balancing exercise and whether the severity of the measure's effects upon the
rights of the persons to whom it applies outweighs the importance of the objective, it is respectfully
submitted that it does not. It is important for an effectively functioning system of immigration control that
fully reasoned and rational decisions can be made by the relevant decision makers. If a decision upon DLR
is always to be made prior to a decision upon asylum there will inevitably be a need for two decisions to be
made on separate occasions thereby risking the prospect of inconsistency of decision making with the
consequent further risk of adverse outcomes for victims of trafficking. Some weight, too, should be given to
the added burden on the system as a whole if successive decisions are to become the norm as, in effect,
the Claimants suggests is necessary to comply with ECAT.

34. Contrary to the claims in this ground, it is submitted that the nature of the 'administrative convenience'
of deciding trafficking related DLR after asylum claims (or sometimes at the same time when there is an
obvious overlap between such claims) is not at all modest in nature as alleged. Moreover, victims of
trafficking are provided with the necessary support and benefits in accordance with Article 12(1) of ECAT
while they await such decisions which, save for having access to the labour market and social security
benefits for a relatively short period of time if the system is operating as envisaged under the policy[,] is
reasonably sufficient to protect their rights under the ECHR and ECAT. ”

161. My preliminary comments on this justification, before turning to the four-stage proportionality test, are
as follows:

i) In relation to para 33 of the Defence, I note that the claimants are not seeking a declaration that ECAT
leave should always be determined before an asylum decision is made, but merely that there be no
requirement, on a blanket basis, that ECAT leave not be determined until the asylum decision is made.

ii) As to the risk of inconsistent decisions, I note that the purpose of and criteria applicable to a decision on
ECAT leave and a decision on asylum claim are different, so while there may be some overlap between
the applicable criteria in specific cases, the risk of inconsistency in decision-making appears to be a very
weak justification, not capable of justifying the impact on an asylum-seeking victim of the scheduling rule.

iii) It is difficult, in the absence of evidence, to assess the Secretary of State's submission that some
weight should be given to the added burden on the system of immigration control of requiring that there be,
in most if not in all cases, successive decisions on ECAT leave and asylum. I note, in particular, that there
was no evidence provided by the Secretary of State of any particular difficulties or problems arising before
the scheduling rule was introduced which the scheduling rule was intended to address


-----

Secretary of State for the Home Department [2019] EWHC....

iv) In relation to para 34 of the Defence, it is difficult, in the absence of evidence, to assess the Secretary
of State's submission that the “administrative convenience” of avoiding two decisions in relation to an
asylum-seeking victim by deferring the decision on ECAT leave until after an asylum decision has been
made is “not at all modest in nature”. Once again, no evidence (or even explanation) of administrative
difficulties arising prior to the scheduling rule having been introduced was advanced by the Secretary of
State.

v) Finally, the Secretary of State does not deal in her Defence in relation to Ground 3 with the impact of
the 45-day rule (or 14-day rule, which applied to JP and BS). The second sentence of para 34 of the
Defence appears, therefore, not to be accurate for those asylum-seeking victims who must wait
significantly more than 45 days after the positive conclusive grounds decision before an asylum decision is
made.

162. Turning, then, to the first limb of the proportionality test, in the absence of evidence from the
Secretary of State, it is difficult to assess whether the aim of the scheduling rule, namely, “administrative
convenience”, is sufficiently important to justify the limitation of a protected right, namely, the right to a
decision on ECAT leave arising under Article 14(1) of ECAT. As I have already noted, the risk of
inconsistency in decision-making seems to be a very weak factor, in the absence of evidence to the
contrary.

163. Turning to the second limb of the proportionality test, the scheduling rule is, in my view, rationally
connected to the objective of administrative convenience. Mr Buttler rightly conceded this point on behalf of
the claimants.

164. Turning to the third limb of the proportionality test, the Secretary of State has not provided any
evidence, or even submissions, to suggest that she considered a “less intrusive” rule than the scheduling
rule to achieve the goal of administrative convenience in relation to decisions on ECAT leave and asylum
in relation to asylum-seeking victims. In particular, she has not shown that the blanket nature of the
scheduling rule is justified. It may be the case that for certain asylum-seeking victims it is appropriate to
defer the decision on ECAT leave until after a decision is made on asylum, but it is not clear why a blanket
rule to that effect is necessary or desirable. A less intrusive rule would be one that allowed for the decision
on the relative timing of the decision on ECAT leave and on asylum to be made on a case by case basis by
reference to the position of the relevant asylum-seeking victim.

165. Turning to the fourth limb of the proportionality test, I am satisfied that the claimants have shown, by
reference to the evidence of Professor Katona as well as the evidence of the impact of the scheduling rule
on the claimants themselves, that the effect of the scheduling rule is relatively severe in relation to asylumseeking victims in a case where there is a significant gap between the end of the 45-day period after which
basic trafficking support ceases and the date an asylum decision is made. That impact includes the
psychological impact of the prolonged uncertainty suffered by victims as to their immigration status, which,
as the evidence of Professor Katona shows, inhibits the ability of many victims to begin proper trauma
recovery work. Indeed, that is the evidence of BS in relation to her own case, as I have noted at [102]
above. I conclude that the severity of the effects of the scheduling rule on the rights of asylum-seeking
victims outweighs the importance of the objective of administrative convenience to which the scheduling
rule is intended to contribute.

166. The Secretary of State has provided no evidence to suggest that a more flexible approach to the
timing of such decisions would not strike a better balance of achieving administrative convenience while
having regard to the individual circumstances of particular asylum-seeking victims and bearing in mind the
obligations of the UK towards such victims under Articles 12(1), 12(2) and 14(1) of ECAT.

167. The clear conclusion that I draw from this application of the four-stage proportionality test is that there
is no sufficient objective justification for the discriminatory impact of the scheduling rule in its current
formulation on asylum-seeking victims relative to non-asylum seeking victims.

168. Accordingly, the claims succeed on Ground 3.


-----

Secretary of State for the Home Department [2019] EWHC....

_Conclusion_

169. Each of JP's claim and BS's claim succeeds on Grounds 2 and 3. I have already noted, however, at

[42] to [44] above in connection with the NN-LP Consent Order, that the Secretary of State is reviewing the
current NRM system and has, among other things, moved away from a relatively rigid application of the 45day rule. That post-dates the hearing of this matter but is clearly relevant to the formulation of any order
consequential to this judgment.

170. I will invite the parties to agree a draft form of order or, failing agreement, to provide written
submissions as to the appropriate order, including any necessary consequential directions.

**End of Document**


-----

