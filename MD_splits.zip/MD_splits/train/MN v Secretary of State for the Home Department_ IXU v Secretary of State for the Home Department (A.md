Centre and another intervening) [2020] EWCA Civ 1746

# MN v Secretary of State for the Home Department; IXU v Secretary of State
 for the Home Department (AIRE Centre and another intervening) [2020]
 EWCA Civ 1746

Court of Appeal, Civil Division

Underhill VP, Baker and Simler LJJ

21 December 2020Judgment

**Mr Raza Husain QC, Ms Shu Shin Luh and Mr Ronan Toal (instructed by Simpson Millar) for MN**

**Mr Raza Husain QC, Ms Shu Shin Luh and Mr Ronan Toal (instructed by Wilsons Solicitors LLP) for**
**IXU**

**Sir James Eadie QC and Mr William Irwin (instructed by the Treasury Solicitor) for the Respondent**

**Ms Stephanie Harrison QC,** **Ms Gemma Loughran** and **Ms Ella Gunn** (instructed by Herbert Smith
**Freehills LLP) for AIRE**

**Mr Thomas de la Mare QC, Mr Jason Pobjoy and Ms Gayatri Sarathy (instructed by Deighton Pierce**
**Glynn) for Anti-Slavery International**

Hearing dates: 7-10 July 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

IMAGE NOT AVAILABLE

CONTENTS

**INTRODUCTION             1-9**

**THE ISSUES             10-14**

**THE LEGAL BACKGROUND          15-85**

INTRODUCTION          15-16

(A)  THE COUNCIL OF EUROPE CONVENTIONS    17-49

(1) ECAT                                   18-42

(2) Article 4 of the ECHR      43-49

(B)  THE EU LEGISLATION        50-69

(1) The Pre-ECAT EU Instruments     50-53


-----

Centre and another intervening) [2020] EWCA Civ 1746

(2) The 2011 Directive       54-69

(C)  THE DOMESTIC REGIME        70-83

(1) The NRM        70-74

(2) Reasonable Grounds Decision     75-77

(3) The Conclusive Grounds Decision    78-83

OVERVIEW OF THE LEGAL FRAMEWORK     84-85

**ISSUE (1): STANDARD OF PROOF            86-101**

**ISSUE (2): EXPERT EVIDENCE           102-124**

INTRODUCTORY          102-105

_MIBANGA            106-109_

EXPERT EVIDENCE ABOUT CREDIBILITY     110-124

**ISSUE (3): CREDIBILITY            125-128**

**MN's APPEAL               129-256**

MN'S ACCOUNT IN OUTLINE        130-137

PREVIOUS DECISIONS         138-141

THE APPLICATION FOR RECONSIDERATION     142-160

The Witness Statements       143-145

The Expert Evidence        146-160

THE DECISION OF THE COMPETENT AUTHORITY    161-233

Introductory         161-165

Ms Rees' Letter        166-171

Dr Johnson's Report        172-176

Ms Thullesen's Report       177-182

Overview of the Treatment of the Expert Evidence   183-184

The CA's Self-Directions       185-186

The Difficulties with MN's Account     187-228

The FTT Decision        229-230

“Mitigating Circumstances”      231-232

“Consideration”            233

THE JUDGE'S DECISION         234-237

THE GROUNDS OF APPEAL        238-239

GROUND 2: ANXIOUS SCRUTINY       240-246

GROUNDS 3/4: CREDIBILITY AND EXPERT EVIDENCE   247-253


-----

Centre and another intervening) [2020] EWCA Civ 1746

DISPOSAL                                               254-256

**IXU's APPEAL               257-353**

IXU's ACCOUNT IN OUTLINE        257-260

OVERVIEW OF THE ALLEGED TRAFFICKING     261-264

THE CRIMINAL PROCEEDINGS       265-267

THE ASYLUM PROCEEDINGS        268-276

REFERRAL TO THE NRM AND RECONSIDERATION REQUEST

277-278

Dr Sharp         279-282

Ms Thullesen        283-290

Overview         291-295

THE DECISION OF THE COMPETENT AUTHORITY    296-323

Introductory        296-299

Credibility         300-311

The Elements in IXU's Narrative     312-316

“Mitigating Circumstances”      317-312

Conclusions        322-323

THE DECISION OF THE DEPUTY JUDGE      324-331

THE GROUNDS OF APPEAL              332

GROUND (1): “NEXUS”         333-343

GROUND (2): EXPERT EVIDENCE       344-348

GROUND (3): CREDIBILITY OF A CHILD VICTIM OF TRAFFICKING

349-352

DISPOSAL               353

**---**

**Lord Justice Underhill:**

**INTRODUCTION**

1. This is the decision of the Court, to which all its members have contributed.

2. These two appeals have been heard together because they both raise issues about the correct
approach to deciding whether someone is a victim of human trafficking for the purpose of the process
established under the so-called National Referral Mechanism (“the NRM”). We give more details of that
process later, but in short the NRM provides for a two-stage identification procedure under which:

(a) a “competent authority” (“CA”), which at the time material to these appeals was typically a unit within
the Home Office, first makes an initial decision about whether there are “reasonable grounds” to believe
that a person is a victim of trafficking; and

(b)  subsequently, after further consideration/investigation, the CA makes a “conclusive grounds
decision”1 as to whether the person in question is in fact a victim of trafficking.


-----

Centre and another intervening) [2020] EWCA Civ 1746

We will refer to beneficiaries of the two kinds of decision as, respectively, a “potential victim of trafficking”
and an “established victim of trafficking”. Established victims of trafficking are entitled to various kinds of
support under the NRM: some, but not all, of that support is available also to potential victims. There is no
right of appeal against adverse reasonable grounds and conclusive grounds decisions, but they may be the
subject of judicial review.

3. It is convenient to note at the start that the question whether a person is a victim of human trafficking
may arise in other contexts besides eligibility for support under the NRM. In particular, it may arise in the
context of immigration: victims of trafficking do not as such acquire any right to leave to remain under
domestic legislation or the Immigration Rules, but the circumstances surrounding their trafficking may,
depending on the facts of the particular case, mean that they are entitled to leave to remain as a refugee or
by way of humanitarian protection. Accordingly decisions on whether a person is, in substance, a victim of
trafficking may be taken in the context of immigration appeals.2 The relationship between decisions made
by the CA in the context of the NRM and decisions made by a tribunal in an immigration context was
recently considered by the Supreme Court in MS (Pakistan) v Secretary of State for the Home Department

_[2020] UKSC 9, [2020] 1 WLR 1373._

4. At this stage we will only give a bare outline of the facts of the two cases sufficient to introduce the
issues. Although there is no automatic right to anonymity in cases involving victims of human trafficking,
we were satisfied that such an order was appropriate in these cases. We accordingly refer to the
Appellants as “MN” and “IXU”; and one or two individuals with whom IXU had dealings have been
anonymised also.

5. MN. MN is an Albanian national. She was born on 11 January 1988. She came to this country on 26
February 2013 and claimed asylum. In her screening interview she gave an account which contained
numerous indicators that she was a victim of trafficking, including that she had been forced to work as a
prostitute in Italy. She was referred to the NRM. The CA made a reasonable grounds decision in her
favour on 21 March 2013. On 7 August 2017, four years later, the CA made a conclusive grounds decision
that MN was not a victim of trafficking. During the interval between the two decisions her asylum claim was
refused. An appeal to the First-tier Tribunal (“the FTT”) was unsuccessful. On 12 October 2017 MN began
proceedings for judicial review of the CA's decision. By a judgment handed down on 29 November 2018
Farbey J dismissed her claim. She appeals from that decision with permission granted by Hickinbottom LJ.

6. _IXU._ IXU is a Nigerian national. She says that she was born on 27 March 1999. She came to this
country on 18 July 2012 on a student visa, which gave her date of birth as 27 October 1988. She says that
in fact she came not primarily as a student but because she was trafficked and that on her arrival she was
expected to become a prostitute. After, on her account, escaping from her traffickers she agreed to marry
an EU national, but the marriage was prevented by the immigration authorities; and on 9 April 2014 she
was convicted of an offence of conspiracy in relation to the proposed marriage and sentenced to two years'
imprisonment. Following her sentence she was served with notice of liability to automatic deportation. She
made an asylum claim. Her application was refused. In the context of her appeal to the FTT (which was
eventually unsuccessful) she gave an account of her history which led to her being referred to the NRM in
June 2015. After various delays a decision on that referral was made by the CA on 6 December 2016. It
found that there were reasonable grounds to believe that she was a victim of trafficking. However, its
eventual conclusive grounds decision, dated 12 February 2018, was that she was not. On 11 May 2018
she commenced proceedings for judicial review of that decision. In a judgment handed down on 9 January
2019 Mr Philip Mott QC, sitting as a deputy High Court Judge, dismissed her claim. She appeals from that
decision with (again) permission granted by Hickinbottom LJ.

7. Both Appellants have been represented before us by Mr Raza Husain QC, leading Ms Shu Shin Luh
and Mr Ronan Toal. In the Administrative Court both were represented by Ms Luh. The Respondent, the
Secretary of State for the Home Department, has been represented by Sir James Eadie QC, leading Mr
William Irwin, who also represented her below. Sir James and Mr Irwin addressed us on different aspects
of the case.


-----

Centre and another intervening) [2020] EWCA Civ 1746

8. Permission has been given to the AIRE Centre and Anti-Slavery International to intervene in the
appeals. They have been represented by, respectively, Ms Stephanie Harrison QC, leading Ms Gemma
Loughran and Ms Ella Gunn, and Mr Thomas de la Mare QC, leading Mr Jason Pobjoy and Ms Gayatri
Sarathy. The AIRE Centre was also an intervener in MN below, where it was represented by Ms Harrison,
Mr Toal and Ms Loughran.

9. The Appellants, the Secretary of State and the Interveners have helpfully provided consolidated
skeleton arguments covering both appeals. We will for convenience sometimes refer to those skeleton
arguments as if they were the work of leading counsel alone, though we are sure that that is far from being
the case.

**THE ISSUES**

10. The decisions of the CA which are challenged in both cases have three features in common which are
central to the issues in the appeals. First, the decision-maker, in accordance with the guidance in the
NRM, reached his or her conclusion on the basis of the balance of probabilities. Second, the decisions
were taken principally on the basis of the decision-maker's assessment of the Appellant's credibility. Third,
in both cases the Appellant relied on expert evidence.

11. The grounds of appeal as pleaded raise three issues which the Appellants have presented as being
common to both appeals. We can summarise them as follows.

(1) _Standard of proof (ground 1 in both appeals). The label “standard of proof” does not quite give the_
flavour of the issue here. The Appellants submit that they were entitled to continue to receive support and
protection for as long as there was “credible suspicion”, or “reasonable grounds to believe”, that they were
victims of trafficking; and that the provision in the NRM for a second stage, at which a conclusive grounds
decision is made on the balance of probabilities, is contrary to their rights under article 4 of the European
Convention on Human Rights (“the ECHR”) and the applicable EU Directive. They contend that the Judge
in both cases was wrong to reject that submission.

(2) Approach to expert evidence (ground 3 in both appeals). In both cases the Appellants argued before
the Judge that the CA had taken the wrong approach to the expert evidence that was before it. They
contend that that argument was wrongly rejected.

(3) _Approach to credibility (ground 4 in both appeals). In both cases the Appellants argued before the_
Judge that the CA had taken the wrong approach to assessing the credibility of their accounts. They
contend that that argument also was wrongly rejected.

Another potential common ground, labelled “irrationality”, is not now pursued.

12. In addition there is in the case of each appeal a ground peculiar to it (as it happens, ground 2 in each
case). These are:

(4) Anxious scrutiny. MN argues that in her case Farbey J wrongly held that no duty of anxious scrutiny
arose.

(5) “Nexus”. While she was still a child IXU underwent female genital mutilation (“FGM”). She says that
the FGM was performed for the purpose of an intended forced marriage to an older man. The Judge held
that that was immaterial to the question whether she was a victim of trafficking because the connection
between the FGM and any possible future exploitation was not sufficiently proximate. IXU contends that
he was wrong to do so. This has been referred to before us as the “nexus” issue, and we will retain the
shorthand for convenience, though we are not sure that it is entirely apt.

13. Issue (1) is indeed a pure point of law common to both appeals and can be decided without reference
to the facts of the individual appeals, and we will deal with it on that basis. Issues (2) and (3) are not
common in any real sense because they depend on an examination of the approach taken by the decisionmaker in each case to the particular evidence in that case. It is fair to say, however, that each of them
does raise a question of approach that may be of more general application. We will accordingly, after


-----

Centre and another intervening) [2020] EWCA Civ 1746

setting out the legal background, deal with issue (1) and such points of general application as arise from
issues (2) and (3) before turning to the facts of the individual cases.

14. We should deal with one related matter at this stage. Shortly before the hearing of the appeal AntiSlavery International made an application to rely on a witness statement from Kate Roberts, who is their
UK & Europe Manager. The Secretary of State objected to its admission. In our judgment she was entitled
to do so. The first problem about the evidence is that it is being sought to be introduced for the first time in
this Court, and by an intervener who was not even a party below. That might not in itself be fatal: when
this Court is considering an appeal which raises issues of general import it will sometimes be willing to
admit for the first time evidence which explains uncontentious background or contextual matters. But Ms
Roberts' witness statement contains extensive passages which include statements of fact and opinion
about such matters as the way in which CAs acquire evidence and make their decisions and about the
quality of the decisions made. That evidence is self-evidently contentious, and it should have been
apparent to those advising Ms Roberts that it would be impossible for this Court, on an appeal and without
evidence from the Secretary of State, to make any assessment of the extent to which it is reliable. In
fairness to Ms Roberts we should acknowledge that her statement is evidently the product of considerable
work and based on deep experience and sincere concerns, and there are other parts of it which are
uncontentious and potentially useful. But those parts contain nothing that could not be advanced by way of
submissions, and in our view the most straightforward course is to decline to admit the statement in its
entirety.

**THE LEGAL BACKGROUND**

INTRODUCTION

15. The law relating to the treatment of victims, and potential victims, of trafficking has to be found in a
complicated patchwork of international and domestic sources. We take in turn:

(A)   the Council of Europe Conventions

(B)   the EU legislation

(C)   the domestic legislation and practice.

16. We should emphasise that we do not propose to give any kind of comprehensive summary of the law
relating to human trafficking. Our focus is on the aspects which are directly relevant to the issues in these
appeals, though it will be necessary to refer also to some other aspects.

(A)          THE COUNCIL OF EUROPE CONVENTIONS

17. Two Conventions entered into by the member states of the Council of Europe are relevant for our
purposes – the ECHR and the Convention on Action against Trafficking in Human Beings (“ECAT”).
Although the latter post-dates the former it is convenient to take it first, since, as will appear, the effect of
the relevant provision of the ECHR (article 4) has been expounded in the case-law of the European Court
of Human Rights (“the ECtHR”) in such a way as to reflect the provisions of ECAT.

(1)         ECAT

_Introductory_

18. ECAT was adopted by the Council of Europe on 16 May 2005 and ratified by member states over the
following years. Its adoption was accompanied by the publication of an Explanatory Report. It drew to a
considerable extent on the earlier “Palermo Protocol” to the UN Convention against Transnational
Organised Crime, adopted by the General Assembly in November 2000.

19. ECAT has ten Chapters. We are primarily concerned with Chapter III, but we need to refer to some
provisions of some of the other Chapters.

20. Chapter I contains the definitions provision, article 4, which reads:


-----

Centre and another intervening) [2020] EWCA Civ 1746

“For the purposes of this Convention:

(a) 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt
of persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of
deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other
forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or
the removal of organs;

(b) The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in
subparagraph (a) of this article shall be irrelevant where any of the means set forth in subparagraph (a)
have been used;

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation
shall be considered 'trafficking in human beings' even if this does not involve any of the means set forth in
subparagraph (a) of this article;

(d)  'Child' shall mean any person under eighteen years of age;

(e)  'Victim' shall mean any natural person who is subject to trafficking in human beings as defined in this
article.”

Most of those definitions, and specifically the definition of “trafficking in human beings” at (a), are taken
from the Palermo Protocol. That definition is conventionally analysed into three elements, comprising (1)
“action”, (2) “means”, and (3) “purpose”; but by virtue of (c) the “means” element is not required in the case
of a child.

21. Mr Husain asked us to note that in _R (Atamewan) v Secretary of State for the Home Department_

[2013] EWHC (Admin), [2014] 1 WLR 1959, the Divisional Court held (and the Secretary of State accepted)
that the definition of “victim” at (e) should be understood as covering any person who is _or has been_
subject to trafficking: see para. 70 of the judgment of Aikens LJ. That is plainly correct.

22. Chapter II is headed “Prevention, co-operation and other measures”. We need only note article 5.1,
which reads:

“Each Party shall take measures to establish or strengthen national co-ordination between the various
bodies responsible for preventing and combating trafficking in human beings.”

_Chapter III_

23. Chapter III is headed “Measures to protect and promote the rights of victims, guaranteeing gender
equality”. It comprises articles 10-17. Article 10 – headed “identification of the victims” – is of a preliminary
character, in that it provides for how states should identify the persons to whom the substantive benefits
provided for in articles 11-12 and 14-16 should be accorded. Those benefits are “protection of private life”
(article 11); “assistance to victims” (article 12); “residence permit” (article 14); “compensation and legal
redress” (article 15); and “repatriation and return of victims” (article 16). Article 13 – “recovery and
reflection period” – is of a rather different character: see below. Article 17 obliges states to apply the
measures required by the chapter in such a way as to promote gender equality. For our purposes the
provisions which are principally relevant are articles 10, 12 and 13; but we need also to note article 14. We
take them in turn.

24. Article 10 is headed “Identification of the victims”. It reads, so far as material:

“1. Each Party shall provide its competent authorities with persons who are trained and qualified in
preventing and combating trafficking in human beings, in identifying and helping victims, including children,
and shall ensure that the different authorities collaborate with each other as well as with relevant support
organisations, so that victims can be identified in a procedure duly taking into account the special situation
of women and child victims … .


-----

Centre and another intervening) [2020] EWCA Civ 1746

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party [(1)] shall
ensure that, if the competent authorities have reasonable grounds to believe that a person has been victim
of trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in Article 18 of this Convention3 has been completed by the
competent authorities and [(2)] shall likewise ensure that that person receives the assistance provided for
in Article 12, paragraphs 1 and 2 [square-bracketed numbers inserted for ease of reference].

3-4. …”

25. We should set out some parts of the commentary on article 10 in the Explanatory Report:

“127. To protect and assist trafficking victims it is of paramount importance to identify them correctly. Article
10 seeks to allow such identification so that victims can be given the benefit of the measures provided for
in Chapter III. Identification of victims is crucial, is often tricky and necessitates detailed enquiries. Failure
to identify a trafficking victim correctly will probably mean that victim's continuing to be denied his or her
fundamental rights and the prosecution to be denied the necessary witness in criminal proceedings to gain
a conviction of the perpetrator for trafficking in human beings. Through the identification process,
competent authorities seek and evaluate different circumstances, according to which they can consider a
person to be a victim of trafficking.

128. Paragraph 1 places obligations on Parties so as to make it possible to identify victims and, in
appropriate cases, issue residence permits in the manner laid down in Article 14 of the Convention.
Paragraph 1 addresses the fact that national authorities are often insufficiently aware of the problem of
trafficking in human beings. Victims frequently have their passports or identity documents taken away from
them or destroyed by the traffickers. In such cases they risk being treated primarily as illegal immigrants,
prostitutes or illegal workers and being punished or returned to their countries without being given any
help. To avoid that, Article 10, paragraph 1, requires that Parties provide their competent authorities with
persons who are trained and qualified in preventing and combating trafficking in human beings and in
identifying and helping victims, including children, and that they ensure that those authorities cooperate
with one other as well as with relevant support organisations.

129-130. …

131. Even though the identification process is not completed, as soon as competent authorities consider
that there are reasonable grounds to believe that the person is a victim, they will not remove the person
from the territory of the receiving State. Identifying a trafficking victim is a process which takes time. It may
require an exchange of information with other countries or Parties or with victim-support organisations, and
this may well lengthen the identification process. Many victims, however, are illegally present in the country
where they are being exploited. Paragraph 2 seeks to avoid their being immediately removed from the
country before they can be identified as victims. Chapter III of the Convention secures various rights to
people who are victims of trafficking in human beings. Those rights would be purely theoretical and illusory
if such people were removed from the country before identification as victims was possible.

132. The Convention does not require absolute certainty – by definition impossible before the identification
process has been completed – for not removing the person concerned from the Party's territory. Under the
Convention, if there are 'reasonable' grounds for believing someone to be a victim, then that is sufficient
reason not to remove them until completion of the identification process establishes conclusively whether
or not they are victims of trafficking.

133-134. …

135. Even though the identification process may be speedier than criminal proceedings (if any), victims will
still need assistance even before they have been identified as such. For that reason the Convention
provides that if the authorities 'have reasonable grounds to believe' that someone has been a victim of
trafficking, then they should have the benefit, during the identification process, of the assistance measures
provided for in Article 124 paragraphs 1 and 2


-----

Centre and another intervening) [2020] EWCA Civ 1746

136-137. …”

26. The most important part of article 10 for our purposes is paragraph 2. The second sentence of that
paragraph distinguishes between two stages of the identification process – first, where there are
“reasonable grounds to believe” that a person is a victim of trafficking; and second where “the identification
process as a victim … has been completed”. In accordance with para. 2 above we will refer to a person at
the first stage as a “potential victim” and to a person identified as a victim at the completion of the process
as an “established victim”.

27. On a very literal reading, the only right required to be accorded to potential victims during the first
stage is the one that we have marked (1) – namely, non-removal – because as a matter of syntax the
words “until the identification process … has been completed” only apply to that right. But that is overliteral. The intention is plainly also that “right (2)” – assistance in accordance with article 12 (1) and (2) –
should be conferred while the identification process is being carried out, since it would not otherwise make
sense to refer to it in article 10; and that is confirmed by para. 135 of the Explanatory Report. That is in
accordance with the analysis of Aikens LJ in Atamewan (see para. 72 of his judgment).

28. Article 12 reads:

“1.  Each Party shall adopt such legislative or other measures as may be necessary to assist victims in
their physical, psychological and social recovery. Such assistance shall include at least:

a  standards of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

b  access to emergency medical treatment;

c  translation and interpretation services, when appropriate;

d  counselling and information, in particular as regards their legal rights and the services available to them,
in a language that they can understand;

e  assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

f  access to education for children.

2.  Each Party shall take due account of the victim's safety and protection needs.

3. In addition, each Party shall provide necessary medical or other assistance to victims lawfully resident
within its territory who do not have adequate resources and need such help.

4. Each Party shall adopt the rules [sic, but I think “the” must be a slip] under which victims lawfully
resident within its territory shall be authorised to have access to the labour market, to vocational training
and education.

5. Each Party shall take measures, where appropriate and under the conditions provided for by its internal
law, to co-operate with non-governmental organisations, other relevant organisations or other elements of
civil society engaged in assistance to victims.

6. Each Party shall adopt such legislative or other measures as may be necessary to ensure that
assistance to a victim is not made conditional on his or her willingness to act as a witness.

7. For the implementation of the provisions set out in this article, each Party shall ensure that services are
provided on a consensual and informed basis, taking due account of the special needs of persons in a
vulnerable position and the rights of children in terms of accommodation, education and appropriate health
care.”

These provisions are glossed in considerable detail at paras. 146-171 of the Explanatory Report.


-----

Centre and another intervening) [2020] EWCA Civ 1746

29. It will be seen that it is paragraphs 1-4 which are the substantive provisions requiring states to provide
specific forms of “assistance to victims”; paragraphs 5-7 are ancillary. Although we are not directly
concerned in these appeals with the details of the assistance required, it is necessary to identify its nature.

30. Paragraph 1 is concerned with both the material needs of victims – most obviously the means of
subsistence as referred to under head (a) – and their needs for advice and other services to enable them
to cope with their situation. As for paragraph 2, the language of “tak[ing] due account” of the victim's safety
and protection needs is rather awkward, but its intended effect is plainly that the victim should be afforded
protection against further exploitation, in particular from their traffickers: this is made clear in para. 164 of
the Explanatory Report. In _Atamewan Aikens LJ treated paragraph 2 as ancillary to paragraph 1 (see_
para. 73 of his judgment). There is certainly a considerable overlap, since (for example) the obligation to
ensure “secure” accommodation has a protective element: the need to ensure accommodation where
victims can be safe from their traffickers is emphasised in para. 153 of the Explanatory Report.

31. Those two paragraphs can be regarded as concerned with victims' core needs. Paragraphs 3 and 4
provide for assistance of a wider character. The right to medical treatment afforded by paragraph 3 goes
beyond the right to “emergency” medical treatment under paragraph 1 (b): this is explained in para. 165 of
the Explanatory Report. Paragraph 4 requires states to give victims of trafficking at least a degree of
access to the labour market and to training and education5.

32. The effect of article 10.2 [(2)] is that assistance under (only) paragraphs 1 and 2 must be given to
potential victims of trafficking as well as to established victims, whereas assistance under paragraphs 3
and 4 is required only in the case of established victims. That is confirmed by para. 148 of the Explanatory
Report, which reads:

“The persons who must receive assistance measures are all those who have been identified as victims
after completion of the Article 10 identification process. Such persons are entitled to all the assistance
measures set out in Article 12. During the actual identification process, in the case of someone whom the
authorities have 'reasonable grounds to believe' to be a victim, that person is entitled solely to the
measures in Article 12, paragraphs 1 and 2, and not to all the Article 12 measures. During the recovery
and reflection period (Article 13) such a person is likewise entitled to the measures in Article 12,
paragraphs 1 and 2.”

33. Article 13 is headed “Recovery and reflection period”. It reads:

“1. Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be
sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the competent authorities. During this period it shall not be possible
to enforce any expulsion order against him or her. This provision is without prejudice to the activities
carried out by the competent authorities in all phases of the relevant national proceedings, and in particular
when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise
the persons concerned to stay in their territory.

2. During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures
contained in Article 12, paragraphs 1 and 2.

3. The Parties are not bound to observe this period if grounds of public order prevent it or if it is found that
victim status is being claimed improperly.”

34. Paras. 172-174 of the Explanatory Report read as follows:

“172. Article 13 is intended to apply to victims of trafficking in human beings who are illegally present in a
Party's territory or who are legally resident with a short-term residence permit. Such victims, when
identified, are, as other victims of trafficking, extremely vulnerable after all the trauma they have
experienced. In addition, they are likely to be removed from the territory.


-----

Centre and another intervening) [2020] EWCA Civ 1746

173. Article 13, paragraph 1, accordingly introduces a recovery and reflection period for illegally present
victims during which they are not to be removed from the Party's territory. The Convention contains a
provision requiring Parties to provide in their internal law for this period to last at least 30 days. This
minimum period constitutes an important guarantee for victims and serves a number of purposes. One of
the purposes of this period is to allow victims to recover and escape the influence of traffickers. Victims
recovery implies, for example, healing of the wounds and recovery from the physical assault which they
have suffered. That also implies that they have recovered a minimum of psychological stability. Paragraph
3 of Article 13 allows Parties not to observe this period if grounds of public order prevent it or if it is found
that victim status is being claimed improperly. This provision aims to guarantee that victims' status will not
be illegitimately used.

174. The other purpose of this period is to allow victims to come to a decision 'on cooperating with the
competent authorities'. By this is meant that victims must decide whether they will cooperate with the lawenforcement authorities in a prosecution of the traffickers. From that standpoint, the period is likely to
make the victim a better witness: statements from victims wishing to give evidence to the authorities may
well be unreliable if they are still in a state of shock from their ordeal. 'Informed decision' means that the
victim must be in a reasonably calm frame of mind and know about the protection and assistance
measures available and the possible judicial proceedings against the traffickers. Such a decision requires
that the victim no longer be under the traffickers' influence.”

35. It will be seen that a recovery and reflection period under article 13 must be accorded when “there are
reasonable grounds to believe that the person concerned is a victim” – i.e. to potential victims. The actual
substance of the right is (a) that the potential victim cannot be removed during that period (see the third
and final sentences of paragraph 1) and (b) he or she is entitled to support and protection in accordance
with paragraphs 1 and 2 of article 12 (paragraph 2). On the face of it they would to be entitled to the
benefit of these paragraphs anyway, under article 10.2; but we cannot see anything significant in this
element of repetition.

36. The purpose of according victims (or potential victims) a period of recovery and reflection is, as
appears from the article itself, twofold – to allow potential victims to recover from the trauma which they
have (or, more strictly, may have) experienced (“recovery”) and to give them the opportunity to decide to
co-operate in the investigation and prosecution of their traffickers (“reflection”).

37. Article 14 is headed “Residence permit”. Paragraph 1 reads:

“Each Party shall issue a renewable residence permit to victims, in one or other of the two following
situations or in both:

a  the competent authority considers that their stay is necessary owing to their personal situation;

b  the competent authority considers that their stay is necessary for the purpose of their cooperation with
the competent authorities in investigation or criminal proceedings.”

The effect of those two conditions is discussed at paras. 180-187 of the Explanatory Report, but we need
not set the passage out here. The only point to note is that ECAT does not impose an obligation on states
to grant a right of residence to established victims of trafficking generally. Nor need we set out paragraphs
2-5 of the article, though we should note that paragraph 5 cross-refers to article 40, which recognises that
in some circumstances victims of trafficking may have a right to asylum.

38. It is clear from the structure of Chapter III that the right to a renewable residence permit under article
14, in the circumstances specified, is a right to be accorded to established victims of trafficking and is
different in character from the kind of provisional irremovability accorded to potential victims of trafficking
by article 10.2 [(1)] and article 13.1.

39. Looking at the position overall, the nature of the assistance which states are required to accord to
victims, or potential victims, depends on which stage of the identification process under article 10 has been
reached. The position can be summarised as follows:


-----

Centre and another intervening) [2020] EWCA Civ 1746

(1) The first stage begins when there are reasonable grounds to believe that a person is a victim of
trafficking – that is, that they are a potential victim. The effect of articles 10.2 and 13 is that at that stage
they must, for at least 30 days, be accorded temporary irremovability and the lesser degree of assistance
(relating to what we have called core needs) provided for by paragraphs 1 and 2 of article 12.

(2) The second stage begins when they have been definitively identified as victims of trafficking at the
conclusion of the identification process – that is, when they become an established victim. They must at
that point be accorded not only the assistance required by paragraphs 1 and 2 of article 12 but the more
extensive assistance provided for by paragraphs 3 and 4 and the right to a “renewable residence permit” if
they can satisfy the conditions specified.

40. Chapter III does not clearly state at what point the state ceases to be obliged to provide established
victims with assistance of the kind identified by article 12. That issue does not directly arise on these
appeals, which is concerned with whether a person is entitled to any support following a decision that they
are not an established victim. However, the natural reading seems to us to be that it should be provided as
long as it is reasonably required for the identified purposes6 or until the victim leaves the country (whether
voluntarily or by lawful removal).

_Other chapters_

41. Chapter IV is headed “Substantive criminal law”. Article 18 requires state parties to “adopt such
legislative and other measures as may be necessary to establish as criminal offences the conduct
contained in article 4 of this Convention, when committed intentionally”. Chapter V deals with the
procedural aspects of such criminal liability and Chapter VI with “international co-operation and cooperation with civil society”.

42. Chapter VII provides for the establishment of a Group of Experts on Action against Trafficking in
Human Beings (“GRETA”) with responsibility for monitoring the implementation of ECAT.

(2)         Article 4 of the ECHR

43. Article 4 of the ECHR provides, so far as material for present purposes:

“1.   No one shall be held in slavery or servitude.

2.  No one shall be required to perform forced or compulsory labour.

3. …”

44. Although that language is very general, the European Court of Human Rights (“the ECtHR”) has held
that it imposes on member states certain positive obligations as regards trafficking. That was first
established by _Siliadin v France (2005) 43 EHRR 16, but the law was much more fully developed in_
_Rantsev v Cyprus and Russia (2010) 51 EHRR 1 and has since been applied and re-stated in a number of_
later cases, most notably J v Austria (58216/12), Chowdhury v Greece (21884/15) and SM v Croatia (2019)
68 EHRR 7 (a decision of the Grand Chamber).

45. In Rantsev the Court said, at para. 282 of its judgment:

“There can be no doubt that trafficking threatens the human dignity and fundamental freedoms of its
victims and cannot be considered compatible with a democratic society and the values expounded in the
Convention. In view of its obligation to interpret the Convention in light of present-day conditions, the Court
considers it unnecessary to identify whether the treatment about which the applicant complains constitutes
'slavery', 'servitude' or 'forced and compulsory labour'. Instead, the Court concludes that trafficking itself,
within the meaning of Article 3 (a) of the Palermo Protocol and Article 4 (a) of the Anti-Trafficking
Convention, falls within the scope of Article 4 of the Convention.”

It is clear from that language that the Court's approach to the effect of article 4 in the context of human
trafficking derives, in effect, from ECAT. That was clearly re-stated in Chowdhury, where it said, at para.
104 of its judgment:


-----

Centre and another intervening) [2020] EWCA Civ 1746

“… [T]he member States' positive obligations under Article 4 of the Convention must be construed in the
light of the Council of Europe's Anti-Trafficking Convention and be seen as requiring, in addition to
prevention, victim protection and investigation, together with the characterisation as a criminal offence and
effective prosecution of any act aimed at maintaining a person in such a situation (see Siliadin … §112).
The Court is guided by that Convention and the manner in which it has been interpreted by [GRETA].”

46. The post-Rantsev cases develop in more detail the nature of the positive obligations imposed by
article 4 as regards trafficking. At paras. 87-89 of its judgment in _J v Austria the Court identified three_
classes of positive obligation, and that classification was endorsed by the Grand Chamber at para. 306 of
its judgment in SM (Croatia). At para. 17 of the judgment of Underhill LJ in R (TDT) v Secretary of State
_for the Home Department_ _[2018] EWCA Civ 1395, [2018] 1 WLR 4922, he summarised those duties as_
follows:

(a) a general duty to implement measures to combat trafficking – “the systems duty”;

(b) a duty to take steps to protect individual victims of trafficking – “the protection duty” (sometimes called
“the operational duty”);

(c) a duty to investigate situations of potential trafficking – “the investigation duty” (sometimes called “the
procedural duty”).

The duties in question are not absolute: what is required will depend on the circumstances of the particular
case.

47. As will appear, the Appellants seek to assimilate the duty to provide assistance under article 12 of
ECAT to the protection duty now recognised in the ECtHR case-law. But we should note here that that
duty was held in _Rantsev to be triggered by the existence of a “credible suspicion” that the person in_
question is a victim of trafficking or is at real and immediate risk of being trafficked. The nature of that
trigger was one of the issues in TDT, to which we have referred above. It was held that it corresponded to
the concept of “reasonable grounds” in ECAT: see para. 38 of the judgment of Underhill LJ. It represents a
relatively low threshold and is plainly less demanding than a conclusion on the balance of probabilities.

48. We should say for completeness that at paras. 22-33 of her judgment in _MS (Pakistan) Lady Hale_
gave a fuller analysis of the Strasbourg case-law (with the exception of _SM (Croatia), which had not yet_
been decided) than is necessary for our purposes.

49. The effect of section 6 of the Human Rights Act 1998 is of course that the Secretary of State and this
Court are obliged to act compatibly with article 4 of the ECHR, and the effect of section 2 is that in
interpreting article 4 the Court is obliged to take into account the Strasbourg case-law. Accordingly the
duties identified at para. 46 above are for practical purposes binding as a matter of domestic law.

(B)         THE EU LEGISLATION

The Pre-ECAT EU Instruments

50. Article 5 of the Charter of Fundamental Rights of the European Union, which was promulgated in 2000
but finally took legal effect in December 2009, reads

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

3. Trafficking in human beings is prohibited.”

51. The first EU instrument making more detailed provision in relation to human trafficking was a
“Framework Decision on Combating Trafficking in Human Beings” dated 19 July 2002 (2002/629/JHA): this
precedes ECAT. We need not set out any of its provisions here, since it has been superseded by the 2011
Directive to which we refer below.


-----

Centre and another intervening) [2020] EWCA Civ 1746

52. The first EU Directive in the field of human trafficking, 2004/81/EC “on the Residence Permit Issued to
Third-Country Nationals who are Victims of Trafficking in Human Beings … who Cooperate with the
Competent Authorities” (“the 2004 Directive”). This too precedes ECAT. Its purpose is to put in place a
system under which victims of trafficking who are not EU nationals and who co-operate in the investigation
and prosecution of their traffickers are given a temporary residence permit covering the period during
which they assist the authorities: see recitals (9) and (10) and article 1. It also, at article 6.1, provides for a
rest period in the following terms:

IMAGE NOT AVAILABLE

“Member States shall ensure that the third-country nationals concerned are granted a reflection period allowing
them to recover and escape the influence of the perpetrators of the offences so that they can take an informed
decision as to whether to cooperate with the competent authorities.

The duration and starting point of the period referred to in the first subparagraph shall be determined
according to national law.”

That has an obvious family resemblance to the “recovery and reflection period” under article 13 of ECAT,
though at least on the face of it it is more limited in its purpose, which is stated simply to be to enable the
victim to take a decision on whether to co-operate in the investigation and prosecution of their traffickers.

53. The 2004 Directive was adopted as part of the justice and home affairs (“JHA”) “pillar” of the EU. The
UK was only bound by such Directives to the extent that it opted in to them, which it did not do in the case
of the 2004 Directive.

The 2011 Directive

_Introductory_

54. The Directive with which we are principally concerned is “Directive 2011/36/EU of the European
Parliament and of the Council of 5 April 2011 on preventing and combating trafficking in human beings and
protecting its victims”. It is often called the Anti-Trafficking Directive, but we will refer to it as the 2011
Directive in order to distinguish it from the 2004 Directive.

55. The 2011 Directive replaces the earlier Framework Decision. It does not, however, replace the 2004
Directive, which remains in force as regards the matters covered by it (though not as regards the UK: see
above). Accordingly, recital (17) to the 2011 Directive records that it “does not deal with the conditions of
the residence of the victims of trafficking in human beings in the territory of the Member States”. Nor, for
the same reason, does the 2011 Directive provide for any recovery and reflection period: the only such
period is that provided for at article 6.1 of the 2004 Directive. However, recital (7) to the 2011 Directive,
which we quote below, makes it clear the 2004 Directive must be “taken into consideration” when
implementing the Directive, and its provisions – including the requirement for a rest period – are referred to
in it.

56. The 2011 Directive of course post-dates ECAT. Most if not all member states of the EU are parties to
ECAT, and it is referred to in recital (9) as a “crucial step in the process of enhancing international
cooperation against trafficking in human beings”. Further, all member states are parties to the ECHR,
which, as we have seen, had by 2011 been interpreted by the ECtHR as in practice giving effect to the
provisions of ECAT. That being so, it is unsurprising that the provisions of the Directive bear a close
resemblance to those of ECAT and in some respects directly reproduce them. In _R (Gudanaviciene) v_
_Director of Legal Aid Casework_ _[2014] EWCA Civ 1622, [2018] 1 WLR 2247, Lord Dyson MR described the_
Directive as “intended in part to give effect” to ECAT (see para. 105 of his judgment). However, its
provisions are not identically worded nor in all respects to identical effect to those of ECAT.

57. Article 1 of the Directive, “Subject matter”, reads:


-----

Centre and another intervening) [2020] EWCA Civ 1746

“This Directive establishes minimum rules concerning the definition of criminal offences and sanctions in
the area of trafficking in human beings. It also introduces common provisions, taking into account the
gender perspective, to strengthen the prevention of this crime and the protection of the victims thereof.”

The purpose of the Directive also appears from recital (7), which reads (so far as relevant for our
purposes):

“This Directive adopts an integrated, holistic, and human rights approach to the fight against trafficking in
human beings and when implementing it, [the 2004 Directive] and Directive 2009/52/EC7 … should be
taken into consideration. More rigorous prevention, prosecution and protection of victims' rights, are major
objectives of this Directive. …”

58. As there appears, and as indeed is reflected in the title, the Directive has two aspects – the prevention
of human trafficking and the protection of victims. Articles 2-10 are concerned with the first of those
objectives. They impose various obligations on member states as regards the investigation and
prosecution of trafficking in human beings. These are broadly to the same effect as Chapter IV of ECAT,
though in one or two specific respects they go further.

59. We are in these appeals concerned with the articles which provide for the second of the two objectives
– being articles 11-16 – and specifically with article 11, which is of the most general application. Article 12
provides for the protection of victims in the context of criminal investigation and proceedings, and articles
13-16 make special provision for child victims. There is no provision for a recovery and reflection period or
for residence rights for victims of trafficking; but, as already noted, there are provisions of that character in
the 2004 Directive, which remains in force and is intended to be read with the 2011 Directive.

_Article 11_

60. Article 11 is headed “Assistance and Support for Victims of Trafficking in Human Beings”. It reads as
follows:

“1. Member States shall take the necessary measures to ensure that assistance and support are provided
to victims before, during and for an appropriate period of time after the conclusion of criminal proceedings
in order to enable them to exercise the rights set out in Framework Decision 2001/220/JHA8, and in this
Directive.

2. Member States shall take the necessary measures to ensure that a person is provided with assistance
and support as soon as the competent authorities have a reasonable-grounds indication for believing that
the person might have been subjected to any of the offences referred to in Articles 2 and 3.

3. Member States shall take the necessary measures to ensure that assistance and support for a victim
are not made conditional on the victim's willingness to cooperate in the criminal investigation, prosecution
or trial, without prejudice to [the 2004 Directive] or similar national rules.

4. Member States shall take the necessary measures to establish appropriate mechanisms aimed at the
early identification of, assistance to and support for victims, in cooperation with relevant support
organisations.

5. The assistance and support measures referred to in paragraphs 1 and 2 shall be provided on a
consensual and informed basis, and shall include at least standards of living capable of ensuring victims'
subsistence through measures such as the provision of appropriate and safe accommodation and material
assistance, as well as necessary medical treatment including psychological assistance, counselling and
information, and translation and interpretation services where appropriate.

6. The information referred to in paragraph 5 shall cover, where relevant, information on a reflection and
recovery period pursuant to [the 2004 Directive], and information on the possibility of granting international
protection pursuant to Council Directive 2004/83/EC of 29 April 2004 … and Council Directive 2005/85/EC
of 1 December 2005 …9 or pursuant to other international instruments or other similar national rules.


-----

Centre and another intervening) [2020] EWCA Civ 1746

7. Member States shall attend to victims with special needs, where those needs derive, in particular, from
whether they are pregnant, their health, a disability, a mental or psychological disorder they have, or a
serious form of psychological, physical or sexual violence they have suffered.”

61. The recital relating to article 11 is recital (18). This reads:

“It is necessary for victims of trafficking in human beings to be able to exercise their rights effectively.
Therefore assistance and support should be available to them before, during and for an appropriate time
after criminal proceedings. Member States should provide for resources to support victim assistance,
support and protection. The assistance and support provided should include at least a minimum set of
measures that are necessary to enable the victim to recover and escape from their traffickers. The practical
implementation of such measures should, on the basis of an individual assessment carried out in
accordance with national procedures, take into account the circumstances, cultural context and needs of
the person concerned. A person should be provided with assistance and support as soon as there is a
reasonable-grounds indication for believing that he or she might have been trafficked and irrespective of
his or her willingness to act as a witness. In cases where the victim does not reside lawfully in the Member
State concerned, assistance and support should be provided unconditionally at least during the reflection
period. If, _after completion of the identification process [words italicised for ease of cross-reference] or_
expiry of the reflection period, the victim is not considered eligible for a residence permit or does not
otherwise have lawful residence in that Member State, or if the victim has left the territory of that Member
State, the Member State concerned is not obliged to continue providing assistance and support to that
person on the basis of this Directive. Where necessary, assistance and support should continue for an
appropriate period after the criminal proceedings have ended, for example if medical treatment is ongoing
due to the severe physical or psychological consequences of the crime, or if the victim's safety is at risk
due to the victim's statements in those criminal proceedings.”

It was common ground before us that the drafting of recital (18) is rather puzzling in that it appears to
proceed (at least mostly) on the basis that the support referred to is for the purpose of facilitating victims'
co-operation in criminal proceedings, which is the focus of the 2004 Directive and article 11.1 of the
Directive, whereas article 11.2 is not so limited (as to this, see para. 63 below). Fortunately, however, it
will be necessary to refer to it only for one or two specific points.

62. The structure of article 11 can be summarised as follows:

(1) The primary duty which it imposes is defined in paragraphs 1 and 2, namely to provide “assistance and
support” (for short, “support”) to victims of trafficking in the circumstances there identified. There was an
issue before us as to the relationship between paragraphs 1 and 2: we consider that at para. 64 below.

(2) The support required by paragraphs 1 and 2 is defined in paragraph 5, supplemented (in so far as it
relates to “information”) by paragraph 6.

(3) The remaining paragraphs are ancillary to that primary duty. In brief:

- Paragraph 3 stipulates that the provision of the required support cannot be made conditional on the
victims' co-operation in criminal proceedings.

- Paragraph 4 adds to paragraphs 1 and 2, (a) by requiring member states to establish appropriate
mechanisms for affording such support and (b) by requiring that those mechanisms provide not only for the
support itself but for “the early identification” of those who are entitled to it.

- Paragraph 7 requires attention to be paid to victims with special needs, including as a result of any
psychological disorder or “psychological … violence”.

63. Those provisions are differently structured from article 12 of ECAT and not identically worded, but they
are in substance to the same effect10. As regards the other provisions of Chapter III, the Directive
contains no equivalent to article 13 (recovery and reflection period) or article 14 (residence permits), but
similar (though possibly more limited) rights are accorded by the 2004 Directive. As regards article 10,
paragraph 4 requires the provision of an identification process, albeit that the drafting is far less elaborate;


-----

Centre and another intervening) [2020] EWCA Civ 1746

so also does recital (18) – see the words which we have italicised. Mr de la Mare was anxious to make the
point that the provisions relating to child victims go further than the passing reference to children's needs in
Chapter III: he said that demonstrated that the Directive could not be treated simply as a mirror image of
ECAT. We accept that, but we cannot see that it adds anything in the respects relevant to these appeals.

64. The issue referred to at para. 62 (1) above is this. In R (Galdikas) v Secretary of State for the Home
_Department_ _[2016] EWHC 942 (Admin), [2016] 1 WLR 4031, counsel for the Secretary of State argued_
that:

“Article 11(2) does not impose a separate duty on the Defendants, but instead it specifies when the
obligation in Article 11(1) arises, namely 'as soon as the competent authorities have a reasonable-grounds
indication for believing that the person might have been subjected to any offences [concerning trafficking in
human beings or inciting, aiding and abetting or attempting to commit such an offence]'. He submits that
this provision is necessary because Article 11(1) merely states that the obligation to support arises 'before'
the criminal proceedings, but that it does not specify a starting point and that explains the need for and the
role of Article 11(2). In other words, the case for the Defendants is that Articles 11(1) and (2) complement
each other.”

Sir Stephen Silber, sitting as a High Court judge, rejected that argument and held that the two paragraphs
imposed distinct obligations, for reasons which he gives at paras. 33-44 of his judgment. In two
subsequent decisions this Court proceeded, although without argument, on the basis that that was correct
– see _Gudanaviciene (above), at para. 104 and_ _R (EM) v Secretary of State for the Home Department_

_[2018] EWCA Civ 1070, [2018] 1 WLR 4386, at para. 31. Mr de la Mare, supported by Mr Husain,_
submitted that that was the correct approach.

65. We did not understand Sir James Eadie to argue to the contrary; but in any event in our view Mr de la
Mare and Mr Husain are right that the obligations imposed by the two paragraphs are formally distinct.
That seems necessarily to follow from the way they are drafted, and we will refer to them as “the paragraph
1 duty” and “the paragraph 2 duty”. It follows that we think that Galdikas was rightly decided on this point
(though we were not taken through the details of Sir Stephen Silber's reasoning, and we should not be
taken to be endorsing each element in it).

66. The question, however, is what difference that makes in practice. It certainly makes no difference to
the content of the obligations, since they are defined in the same terms in paragraph 5. The potential
differences would seem to be twofold.

67. First, the circumstances which give rise to the duty are differently characterised. Paragraph 1 requires
the provision of support by reference to the existence of criminal proceedings whereas the paragraph 2
duty arises where there are reasonable grounds to believe that the person in question is a victim of
trafficking. It may be arguable that that is a distinction without a difference, since if there are reasonable
grounds to believe that a person is a victim of the crime of trafficking it must be contemplated, at least until
there has been some investigation, that there will be criminal proceedings, and the duty under paragraph 1
arises “before” criminal proceedings, not just once they have started. It is unnecessary to decide whether
that argument is correct: even if the paragraph 1 duty may not always arise in parallel with the paragraph 2
duty, that has no consequences because the content of the two duties is identical. We suspect, however,
that the drafters of the Directive did not focus on this question but, rather, provided for two distinct duties in
order to acknowledge that support for victims is required not only in order to encourage their co-operation
in any investigation and prosecution (which had been the sole focus of the 2004 Directive) but also for its
own sake, which is clearly the policy of ECAT.

68. Second, the period during which the two duties subsist is differently defined. In short:

(1) The paragraph 1 duty subsists “before, during and for an appropriate period of time after the
conclusion of criminal proceedings”. As noted above, the question of what is meant by “before … criminal
proceedings” is academic. As for what is meant by an “appropriate period” after the conclusion of
proceedings, that does not arise on these appeals. However, it seems clear that the intention is that what


-----

Centre and another intervening) [2020] EWCA Civ 1746

is appropriate will have to be judged in the circumstances of a particular case: there is some limited
guidance at the end of recital (18).

(2) The duration of the paragraph 2 duty is more problematic. We are told when it starts but not when it
comes to an end. We will have to consider this question in connection with issue (1).

_The Effect of the Directive in UK Law_

69. Although, as recorded at recital (35), the UK did not initially opt in to the 2011 Directive (see para. 53
above) when it was first adopted, it did so with effect from 14 October 2011 (see Commission decision
2011/692/EU) and was accordingly obliged to implement its requirements by 6 April 2013. The provisions
which are most relevant for our purposes (and in particular article 11) were not transposed into UK
legislation. The reasons for this were not explored before us, but presumably it was not thought that the
Directive added anything substantial to what was already required under ECAT, which had already been
incorporated in the domestic regime described below. In any event, on ordinary principles the
requirements of the Directive were at the relevant time (and indeed remain for the time being) directly
effective against the Government.

(C)   THE DOMESTIC REGIME

The NRM

70. ECAT was ratified by the UK in December 2008, with a view to its implementation with effect from 1
April 2009.  Lady Hale summarised the position about implementation at para. 20 of her judgment in MS
_(Pakistan):_

“ECAT as such has not been incorporated into UK law. Its obligations have been implemented by a variety
of measures. The NRM is designed to fulfil the obligations in articles 10, 12 and 13; immigration rules have
[been modified in the light of article 14; and various criminal offences are created by the Modern Slavery](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
_[Act 2015.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_

71. In these appeals we are concerned only with the NRM. It has no legislative basis. Rather, it is a set of
administrative measures prescribed by the Secretary of State. Authoritative details appear in published
Home Office Guidance. For our purposes the relevant Guidance is version 3 of “Victims of **_Modern_**
**_Slavery – Competent Authority Guidance”, first published in March 2016.11 This is very lengthy and in_**
places repetitious, but the relevant parts for our purposes can be summarised as follows.

72. The substantive part of the Guidance begins (at pp. 13-15) by identifying the applicable legal
framework. The section headed “International framework” (p. 13) makes it clear that the NRM has been
established in order to give effect to the UK's obligations under ECAT. There is no reference to the
Directive: presumably this is for the same reason as suggested at para. 69 above.

73. The Guidance provides at pp. 21-22 “a summary of the key steps in the [NRM] process”. The
summary begins with what is in effect a summary of the summary:

“To establish whether a person is a victim of any form of modern slavery (including trafficking) identified in
England and Wales …, 2 decisions are made:

1. A reasonable grounds decision to establish whether someone is a potential victim.

2.  A conclusive grounds decision on whether they are in fact a victim.”

It goes on to say that those decisions are made “by Competent Authorities within the UK Human Trafficking
Centre (UKHTC) and the Home Office”: in practice most decisions were made by units within the Home
Office12.  The “key steps” are then identified as (1) the identification of “a potential victim of human
trafficking13”, who must be referred to the NRM; (2) the reasonable grounds decision; and (3) the
conclusive grounds decision. Various points are made about both kinds of decision, but since these are
made again, and more fully, later in the Guidance we need not set them out here.


-----

Centre and another intervening) [2020] EWCA Civ 1746

74. Pages 52-56 of the Guidance are headed “The 2 stage National Referral Mechanism consideration
process”. It begins:

“This section explains the 2 stage National Referral Mechanism (NRM) process for identifying victims of
trafficking, stipulated by the Council of Europe Convention on Action against Trafficking in Human Beings.

**Part 1**

The first part is the Reasonable Grounds test, which acts as an initial filter to identify potential victims.

**Part 2**

The second is a substantive Conclusive Grounds decision as to whether the person is in fact a victim. This
2 stage test covers all human trafficking cases in any part of the UK (and slavery, servitude, or forced or
compulsory labour in England or Wales).”

That two-stage process is plainly intended to reflect the process envisaged by article 10 of ECAT (see
para. 38 above).

Reasonable Grounds Decision

75. “Part 1” – dealing with reasonable grounds decisions – is at pp. 52-65. Since there is no issue about
the reasonable grounds decision in these appeals, the only passages to which we need to refer are those
relating to a recovery and reflection period. A section on pp. 57-58 identifies the steps to be taken where a
positive reasonable grounds decision is made.

76. The first required step is:

“Provide the potential victim with support if they want it for a minimum of 45 days during a recovery and
_reflection period_

If the Competent Authority makes a positive reasonable grounds decision, the individual must be given
support if they want it during a 45 day recovery and reflection period. This temporary period provides the
conditions for a full evaluation to conclusively decide if the person was a victim of human trafficking or
**_modern slavery at the date of the reasonable grounds decision. This is not an immigration decision. The_**
recovery and reflection period is a legal concept that triggers certain rights and measures under the
Council of Europe Convention on Action against Trafficking in Human Beings and in no circumstances
should the Competent Authority deny an identified victim these rights where the victim indicates they want
them. This recovery and reflection period is being extended to cover positive Reasonable Grounds
decisions in all modern slavery cases in England and Wales.”

This provision of course reflects article 13 of ECAT, although it provides for a period of 45 rather than 30
days. It makes clear that during that period potential victims must be offered support in accordance with
the rights which ECAT requires to be accorded (i.e. principally, though there is no express reference, those
identified in article 12.1 and 12.2). There is provision later in the Guidance for the period (and thus the
required support) to be extended: see pp. 93-95.

77. The fourth step involves notifying the agencies who can give support during this period: one of those
agencies is (in England and Wales) the Salvation Army, which has a contract with the Home Office to
provide support to potential victims of trafficking. The sixth step involves the Home Office considering
whether the potential victim in question requires temporary admission: that reflects the irremovability
requirement under articles 10.2 and 13 of ECAT.

The Conclusive Grounds Decision

78. The part of the Guidance dealing with “Part 2”, headed “Making a Conclusive Grounds decision”, is at
pp. 66-70. It begins:


-----

Centre and another intervening) [2020] EWCA Civ 1746

“When a Competent Authority makes a positive reasonable grounds decision, at the end of the recovery
and reflection period they then have to conclusively decide whether the individual is a victim of human
trafficking (Scotland and Northern Ireland) or modern slavery (England and Wales)14.

The Competent Authority is responsible for making a conclusive decision on whether, 'on the balance of
probabilities', there are sufficient grounds to decide that the individual being considered is a victim of
human trafficking or modern slavery. We refer to this as the Conclusive Grounds decision.”

We should quote from two sections of this part.

79. The first, on p. 67, is headed “Standard of proof for Conclusive Grounds decision”. It reads:

“At the conclusive grounds decision stage, the Competent Authority must consider whether, 'on the
balance of probabilities', there is sufficient information to decide if the individual is a victim of human
trafficking or modern slavery.

_The balance of probabilities_

The 'balance of probabilities' essentially means that, based on the evidence available, human trafficking or
**_modern slavery is more likely than not to have happened. This standard of proof does not require the_**
Competent Authority to be certain that the event occurred. In reaching their decision the Competent
Authority must weigh the balance of probabilities by considering the whole human trafficking or **_modern_**
**_slavery process and the different and interrelated actions that need to have taken place. To make their_**
decision, they must weigh the strength of the indicators or evidence presented, including the credibility of
the claim, and use common sense and logic based on the particular circumstances of each case. See
_Assessment of_ **_modern slavery by the Competent Authority [this is a hyperlink to a different section, to_**
which we need not refer].”

80. The second, also on p. 67, is headed “Evidence gathering”. It reads:

“Competent Authority staff may need to gather more information to make a conclusive grounds decision.

The Competent Authority must make every effort to secure all available information that could prove useful
in establishing if there are conclusive grounds. If they cannot make a conclusive grounds decision based
on the evidence available, they must gather evidence or make further enquiries during the 45 day recovery
and reflection period.

The Competent Authority must gather this information, where appropriate, from:

the first responder

support provider

police

Local Authority (in the case of children)”

81. We need not quote from the remainder of this part, which is principally concerned with the
circumstances in which the CA should interview potential victims for the purpose of making a conclusive
grounds decision, and guidance for the conduct of such interviews.

82. The Guidance sets out at pp. 85-87 what steps the CA should take in the case of a negative
conclusive grounds decision. They are preceded by the following statement:

“If the Competent Authority decides that there are not conclusive grounds to accept the person is a victim
of human trafficking or **_modern slavery, the Competent Authority must not offer any further support for_**

[sic, but we think this is a slip for “or”] a further recovery and reflection period (including further Temporary
Admission (TA) or Temporary Release (TR) in order to receive support as a victim).”

Step 2 requires that the person to whom the decision relates (rather inaptly described as “the victim”) must
be notified of the decision using a standard-form letter. Such a letter was sent in the case of both
Appellants: rather oddly it does not state in so many words that they are no longer entitled to support


-----

Centre and another intervening) [2020] EWCA Civ 1746

under the NRM, but that is implicit. Step 3 requires that the same agencies as are identified at para. 77
above be notified.

83. There is a section of the Guidance are headed “How to assess credibility when making a Reasonable
Grounds or Conclusive Grounds decision” (pp. 98-100). So far as necessary, we deal with this in the
context of our observations on issue (3).

OVERVIEW OF THE LEGAL FRAMEWORK

84. The NRM as embodied in the Guidance is for practical purposes the primary source of the obligation to
support victims of trafficking. The Guidance does not itself have the status of law, but it represents a
formal statement of Government policy and practice, and failures to comply with it may on ordinary
principles be the subject of challenge by way of judicial review: see para. 20 of the judgment of Lady Hale
in MS (Pakistan).

85. Since the NRM is avowedly intended to give effect to the UK's obligations under ECAT the Guidance
must be construed so far as possible to give effect to those obligations; and the same must in principle be
the case as regards the UK's obligations under the 2011 Directive notwithstanding the absence of any
explicit reference to it. However, where a compatible construction is not possible (or appropriate remedies
are not otherwise available) obligations under Chapter III of ECAT will be directly enforceable to the extent
that they correspond to positive obligations under article 4 of the ECHR (see para. 49 above); and
obligations under article 11 of the 2011 Directive are likewise directly enforceable on ordinary principles
(see para. 69).

**ISSUE (1): STANDARD OF PROOF**

86. Mr Husain's essential submission on behalf of the Appellants can be summarised as follows:

(1) The effect of article 4 of the ECHR is that once it is established that there are reasonable grounds to
believe15 that a person is a victim of trafficking, the protection duty recognised in the case-law of the
ECtHR (see para. 47 above) requires the state concerned to afford them support and assistance of the
kind provided for by Chapter III of ECAT for as long as it is needed.

(2) The duty to afford support and assistance continues so long as there remain reasonable grounds to
believe that the person in question is a victim of trafficking. It will only be terminated by the results of
further investigation or consideration if those results justify the conclusion that there are no longer such
reasonable grounds. An adverse conclusion on the balance of probabilities is not enough.

(3) The NRM thus fails to comply with the requirements of article 4, and any person who is a potential
victim of trafficking (in the sense that there are reasonable grounds to believe that they are) is entitled to
enforce those obligations as a breach of section 6 of the HRA.

87. Mr Husain acknowledged that element (2) in that submission was not entirely easy to reconcile with
the language of Chapter III of ECAT, but he submitted that the purposes underlying it and/or article 4 of the
ECHR as interpreted in the Strasbourg case-law, were only consistent with a duty of support which
continued as long as there were reasonable grounds to believe that a person was a victim. He referred by
way of analogy to the lower – “reasonable degree of likelihood” – standard of proof which applies to claims
for asylum under the Refugee Convention: see _R (Sivakumaran) v Secretary of State for the Home_
_Department [1988] AC 958and Karanakaran v Secretary of State for the Home Department [2000] EWCA_
[Civ 11, [2000] 3 All ER 449.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-613F-00000-00&context=1519360)

88. Mr de la Mare's submissions on behalf of Anti-Slavery International focused not on ECAT but on article
11 of the 2011 Directive, but they depend on the same essential point as Mr Husain's. He submitted that
the duty under article 11.2 to afford support to potential victims of trafficking (in the same sense) continues
so long as there remain reasonable grounds to believe that the person in question is a victim of trafficking
and is not terminated by a decision to the contrary on the balance of probabilities. He submitted that that


-----

Centre and another intervening) [2020] EWCA Civ 1746

was the natural construction (there were no difficulties of the kind acknowledged by Mr Husain as regards
Chapter III of ECAT) but that it was in any event right as a matter of policy and principle.

89. Both Mr Husain and Mr de la Mare supported each other's submissions, arguing that the ECHR, ECAT
and the 2011 Directive should be interpreted consistently with one another and produced the same result.
Ms Harrison for AIRE did not make separate submissions on issue (1) but supported the submissions of Mr
Husain and Mr de la Mare.

90. Persuasively though those submissions were advanced, we do not believe that they are correct. Our
reasons are as follows.

91. In our view the right starting-point is Chapter III of ECAT.  The case-law of the ECtHR about article 4
is “guided” by ECAT (see paras. 44-46 above); and it is evident also that it is one of the foundation stones
of the 2011 Directive (see para. 55).

92. Mr Husain was right to acknowledge that his submissions do not sit comfortably with the structure and
language of Chapter III. The essential question is the nature of the two-stage structure which we have
described at para. 39 above. On the Appellants' and Interveners' case it has to represent two freestanding levels of support, depending on how firmly it can be established that the person in question is a
victim of trafficking – one to be accorded where there are no more than reasonable grounds for that
conclusion, and the other where a definitive conclusion is possible. We cannot read the relevant provisions
in that way. What article 10 expressly provides for is a single identification process leading to a definitive
decision which then attracts the substantive rights provided for in Chapter III. The purpose of the first
stage is simply to ensure that persons who may in due course be identified as victims of trafficking are not
removed, and are assisted with their essential needs, pending that decision.  That is in our view the only
natural reading of, in particular, article 10.2: the first sentence provides for the identification process, and
the second provides for certain minimum rights “until the identification process … is completed”. That view
is reinforced by the relevant passages in the Explanatory Report: see in particular paras. 132 (“until
completion of the identification process establishes conclusively whether or not they are victims of
trafficking”) and 135 (“the benefit, during the identification process, of the assistance measures provided for
…”).

93. We see nothing objectionable in such a construction as a matter of principle or policy. It is entirely
normal, and rational, in a case where an entitlement depends on a particular legal status, for a decision to
be required as to whether or not the putative beneficiary enjoys that status. That is not inconsistent with
the benefit (or some part of it) being provided on a provisional basis pending the decision; but that is a very
different matter from a definitive right being accorded on the basis that the person in question may enjoy
the status, and even after a decision that in fact they do not do so. Such an approach would be unusual,
and if it was intended we would expect it to be explicitly specified.

94. We acknowledge that the duties under article 12 are not concerned wholly with provision of material
assistance and advice and that they involve an element of protection, such as (where necessary) the
provision of secure accommodation so as to reduce the risk of a victim, or potential victim, being harmed
by their traffickers or coming back under their influence: see para. 30 above. We do not believe that that
means that ECAT has to be interpreted as requiring the continuation of support (including protection) in
such a case. No system can protect against all risk; and it seems to us understandable that the parties to
ECAT should have chosen to draw the line at the point of a definitive decision taken, after proper
investigation, by people who are (as article 10 (1) requires) “trained and qualified in preventing and
combating trafficking in human beings”. It should be borne in mind that a conclusive decision will not be
taken until the expiry of a period “sufficient to allow [the potential victim] to recover _and escape the_
_influence of traffickers”._

95. We do not believe that the analogy with the test for establishing refugee status is a good one. As Sir
James pointed out, that test is based on the particular language of the Refugee Convention and is directed
to the question of the likelihood of a future event, namely persecution if the putative refugee is returned.
That may not be a complete distinction because the protective element in the provisions of Chapter III is


-----

Centre and another intervening) [2020] EWCA Civ 1746

likewise addressed to future risk, necessarily assessed on the basis that the account of past trafficking is
true. Nevertheless, the risk of a victim of trafficking coming back under the influence of his or her
traffickers, particularly after a protected recovery and reflection period, is not to be compared with the risk
to a victim of persecution if they are returned to their country of origin. If the drafters of ECAT had intended
that a similar standard of proof should be applied they could and would have made express provision.

96. Mr Husain sought to draw some support from the fact that ECAT at some points uses the term “victim”
where it is clear from the context that the reference is to, or in any event must include, someone who has
not yet been identified as a victim under the process provided for in article 10. He referred, for example, to
article 11, which requires states to protect “the private life and identity of victims” and to article 15, which
requires that “victims” be given access to information about relevant administrative judicial and
administrative proceedings “as from their first contact with the competent authorities”. But we can see no
significance in this. It simply means that in contexts where it was evident that reference was required to
potential as well as established victims the drafter used the term to cover both: that might be somewhat
loose by domestic standards but it is entirely understandable.

97. If, as for those reasons we believe, that is the correct reading of Chapter III of ECAT we can see no
reason to believe that article 4 confers any greater rights. Mr Husain submitted that the obligation to
provide assistance under article 12 formed part of the protection duty identified in the case-law of the
ECtHR. The position may be a little more complicated than that, but we are prepared to proceed on the
basis that he is right.  But that does not advance the argument. The case-law shows that the content of
the duty is to be derived from the provisions of ECAT, with which we have already dealt.

98. The position is essentially the same as regards the 2011 Directive. We fully accept that, as Mr de la
Mare urged on us, the Directive cannot be treated as no more than the adoption by the EU into its own
legislation of the provisions of ECAT. But ECAT is plainly one of its principal foundations, and we do not
believe that we should treat it as requiring a radically different approach to the support and protection of
victims of trafficking unless there is a clear indication to that effect. We can see no sign that that is the
case. On the contrary, as shown at para. 63 above, the provisions of the 2011 Directive (read with the
2004 Directive) in all essential respects reflect those of Chapter III. We accept that the distinction between
rights to be accorded when there are first reasonable grounds to believe that a person is a victim of
trafficking and rights to be accorded at the completion of the identification process is not explicit in article
11 itself; but it is clear from the italicised passage in recital (18), notwithstanding the confusion about what
rights are being referred to.

99. We therefore conclude that the provision in the Guidance that the right to support is terminated by an
adverse conclusive grounds decision is not inconsistent either with article 4 of the ECHR or with the 2011
Directive.

100. Once that point is reached it follows that the adoption of the civil standard of proof is unobjectionable,
indeed in practice inescapable, and we would reject the Appellants' case on issue (1).

101. We are conscious that we have not in the foregoing made any reference to the reasoning of Farbey J
on this issue in MN, which Mr Mott adopted in IXU. We do not thereby intend any disrespect to her careful
analysis, but the case was argued rather differently before us, and we see no advantage in prolonging an
already lengthy judgment by analysing the extent to which her reasoning corresponds to ours.

**ISSUE (2): EXPERT EVIDENCE**

INTRODUCTORY

102. In both cases the Appellant adduced expert evidence which expressed the witness's opinion about
the extent to which her narrative was consistent with her account of being trafficked and/or with symptoms
of mental ill-health which she reported or displayed. In both cases it is contended that the CA gave
insufficient weight to that evidence. As we have already observed, that issue can only be resolved by
reference to the evidence and reasoning in the two cases separately. At this stage we intend only to make


-----

Centre and another intervening) [2020] EWCA Civ 1746

some observations about the correct general approach. We were referred to a number of authorities about
that issue in the context of asylum appeals, which are for present purposes analogous to claims to be a
victim of trafficking: in both a central question is whether the account of the putative refugee or victim (for
short, though not quite accurately16, “an applicant”) is truthful.

103. Before we turn to those authorities, we should make a point about terminology. It is very common for
experts in this field to express their opinion in terms of whether their findings are “consistent with” the
claimant's account. That phrase has a range of shades of meaning. In the context of the value of physical
scarring as evidence of torture para. 187 of the so-called “Istanbul Protocol” makes a distinction between
“not consistent”, “consistent” and “highly consistent”, with further categories of “typical” and “diagnostic”
(see para. 16 of the judgment of Lord Wilson in _KV (Sri Lanka) v Secretary of State for the Home_
_Department_ _[2019] UKSC 10). We need not reproduce the whole paragraph, but we note that “consistent”_
is glossed as

“the lesion could have been caused by the trauma described, but it is non-specific and there are many
other possible causes”

and “highly consistent” is glossed as

“the lesion could have been caused by the trauma described, and there are few other possible causes”.

In the former case the finding of consistency is essentially neutral: it means only that the physical signs do
not contradict the applicant's account. In the latter case, however, it positively supports, or corroborates,
the account: the degree to which it does so will depend on just how few or unlikely the other possible
causes are.

104. That categorisation has not been systematically adopted in other contexts, but it illustrates that in this
field, whatever linguistic purists may think, there can be degrees of “consistency”. It is important to
distinguish between cases where an expert is saying no more than that the signs found and/or symptoms
reported are consistent with the treatment recounted by the applicant – “mere consistency” cases – and
cases where they what they are saying is that they are positively supportive of it. Even if the witness does
not use the Istanbul categories, the intended meaning will usually be sufficiently clear from the context.
This needs to be borne in mind both when considering the report of an expert in a particular case and
when considering the case-law.

105. There are two strands in the authorities to which we were referred about the proper approach to the
use of expert evidence in this context. We take them in turn.

(1)    MIBANGA

106. The first strand consists of a point which emerged in the decision of this court in Mibanga v Secretary
_of State for the Home Department_ _[[2005] EWCA Civ 367. The appellant claimed to have been tortured by](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG21-DYBP-P50W-00000-00&context=1519360)_
the authorities in the DRC. He relied on medical evidence reporting very extensive scarring. The doctor
expressed the opinion that the appellant's account was supported by two points. First, the scarring was
“consistent with” his account of torture: some of the tortures were of very particular kinds, corresponding to
the scarring found, and it is clear that the doctor was using the language of “consistency” in a way that
corresponds to the Istanbul terminology of “highly consistent”. Secondly, she expressed the opinion that
the veracity of his account was supported by the fact that he had himself told her to ignore certain
particular scars which he said had a different cause and by what she judged to be his genuine distress in
describing the torture. The adjudicator attached no weight to her evidence and that decision was upheld
by the IAT.

107. This court (Ward and Buxton LJJ and Wilson J) allowed an appeal on the basis that the adjudicator
had reached a conclusion on the appellant's credibility before turning to consider the effect of the expert
evidence. She had failed to treat the expert evidence “as an integral part of the findings on credibility
rather than just as an add-on”: see para. 22 of the judgment of Wilson J (with whom the other members of


-----

Centre and another intervening) [2020] EWCA Civ 1746

the Court agreed), in fact quoting from Ouseley J's judgment in HE to which we refer below. At para. 24
Wilson J said:

“It seems to me to be axiomatic that a fact-finder must not reach his or her conclusion before surveying all
the evidence relevant thereto. Just as, if I may take a banal if alliterative example, one cannot make a cake
with only one ingredient, so also frequently one cannot make a case, in the sense of establishing its truth,
otherwise than by combination of a number of pieces of evidence. Mr Tam, on behalf of the Secretary of
State, argues that decisions as to the credibility of an account are to be taken by the judicial fact-finder and
that, in their reports, experts, whether in relation to medical matters or in relation to in-country
circumstances, cannot usurp the fact-finder's function in assessing credibility. I agree. What, however, they
can offer, is a factual context in which it may be necessary for the fact-finder to survey the allegations
placed before him; and such context may prove a crucial aid to the decision whether or not to accept the
truth of them. What the fact-finder does at his peril is to reach a conclusion by reference only to the
Appellant's evidence and then, if it be negative, to ask whether the conclusion should be shifted by the
expert evidence.”

108. Whether a tribunal or other decision-maker has fallen into the “Mibanga error” depends on an
analysis of the reasoning in the individual case. Later cases have made clear that the question is one of
form rather than substance: if it is evident that the tribunal has in fact taken the expert evidence into
account as part of the primary assessment, it does not matter at what particular point in the decision it is
specifically referred to. The point is well made at para. 21 of the decision of the AIT in HH (Ethiopia)17:

“… [T]here is a danger of Mibanga being misunderstood. Judgments in that case are not intended to place
judicial fact finders in a form of forensic straitjacket. In particular the Court of Appeal is not to be regarded
as laying down any rule of law as to the order in which judicial fact finders are to approach the evidential
materials before them. To take Wilson J's cake analogy, all its ingredients cannot be thrown together into
the bowl simultaneously. One has to start somewhere. There is nothing illogical about the process by
which the immigration judge in the present case chose to approach his analytical task.”

That passage was quoted with approval by Rix LJ at para. 32 of his judgment in S (see para. 114 below).
But the basic principle established by _Mibanga remains important. It was succinctly summarised, and_
applied by this Court in AM (Afghanistan) v Secretary of State for the Home Department _[2017] EWCA Civ_
_1123, [2018] 4 WLR 78, where the Senior President of Tribunals, Sir Ernest Ryder, said, at para. 19 (a):_

“It is an error of approach to come to a negative assessment of credibility and then ask whether that
assessment is displaced by other material.”

109. Although that is the ratio of Mibanga, it is worth also noting that part of the evidence in question in
that case was the doctor's opinion about the applicant's veracity, based on his presentation and the way he
gave his history. There is nothing in the judgment of Wilson J to suggest that his observations about the
need to take her evidence fully into account did not include that aspect of it. This is relevant to the second
strand in the case-law, to which I now turn.

(2)    EXPERT EVIDENCE ABOUT CREDIBILITY

110. The second strand is concerned with the weight to be given to the opinion of an expert witness about
whether his or her findings on examination are supportive of the credibility of the applicant's account.
Typically, the expert witness will be medically qualified, though they may sometimes be a clinical
psychologist: we will say “doctor” for short. For the purpose of these appeals we are principally concerned
with findings about the psychological or psychiatric condition of an applicant, which are of course to a great
extent dependent on the histories which they give. As to this, we were referred to a number of authorities
which it is best to go through in date order.

111. In R (Minani) v Immigration Appeal Tribunal _[[2004] EWHC 582 (Admin) the claimant was an asylum-](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P1CY-00000-00&context=1519360)_
seeker who reported being the victim of persecution in Burundi. He relied in part on a psychiatric report
which diagnosed PTSD. The adjudicator rejected that evidence. Part of his reasoning was expressed as
follo s


-----

Centre and another intervening) [2020] EWCA Civ 1746

“It is always difficult to assess the value of such reports of [PTSD]. In the absence of any physical
symptoms, the assessment must inevitably turn on the account given by the patient to the doctor and that
account must inevitably reflect the same pattern as that given to the immigration authorities. It is not the
duty of a doctor or a social worker to disbelieve the account given by their patient … I do not find it possible
to put great weight on Dr Eastgate's report because he has simply listened to the appellant's account of her
experiences, accepted it uncritically and concluded that if the events occurred, it would follow that she
would suffer from Post Traumatic Stress Disorder.”

Moses J held that that was the wrong approach. He said, at para. 26 of his judgment:

“I think that the adjudicator did err in reaching the conclusion that she was not suffering from PTSD. It
seems that his error stemmed from the belief that the correctness of that diagnosis depended upon the
correctness of her account. In reaching that conclusion he seems to have also somewhat unusual, and in
my view unsupportable, views of expert psychiatrists … [T]o say that it is not the duty of a doctor to
disbelieve the account given by a patient may be correct but takes one absolutely nowhere. It is plain that a
psychiatrist does exercise his critical facilities and experience in deciding whether he is being spun a yarn
or not, and all of us sitting in these courts in different jurisdictions from time to time have heard
psychiatrists saying that they do believe an account or that they do not believe an account. It is, therefore,
wrong to suggest, as part of support for his conclusion, that doctors do not look into anything critically … .”

In our view the clear implication of that passage, in the context of the decision, is that where a doctor
expresses an opinion on the truthfulness of the applicant's account it should be taken into account (which
is not the same as saying that it should be determinative).

112. In HE (DRC) v Secretary of State for the Home Department _[[2004] UKIAT 321 an asylum-seeker who](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4HJR-NPR0-TWYV-R043-00000-00&context=1519360)_
claimed to have been the subject of ill-treatment by the authorities in the DRC also relied on a psychiatric
report which, on the basis of her own account of her experiences, concluded that she was suffering from
PTSD. An adjudicator declined to attach weight to the report as supporting the asylum claim. The
Immigration Appeal Tribunal held that he had been right to do so. We should quote paras. 17-19 of the
judgment of Ouseley J:

“17. A particular difficulty arises in the contention that a report should be seen as corroborating the
evidence of an applicant for protection. A doctor does not usually assess the credibility of an applicant; it is
not usually appropriate for him to do so in respect of a patient or client. That is in any event the task of the
fact-finder who will have often more material than the doctor, and will have heard the evidence tested. So
for very good and understandable reasons the medical report will nearly always accept at face value what
the patient or client says about his history. The report may be able to offer a description of physical
conditions and an opinion as to the degree of consistency of what has been observed with what has been
said by the applicant. But for those conditions, eg scarring, to be merely consistent with what has been
said by the applicant, does no more than state that it is consistent with other causes also. It is not common
for the phrases which indicate a higher probative value in the observed conditions to be used. That limits
the weight which can be afforded to such a report when judging the credibility of the claim. Rather than
offering significant separate support for the claim, a conclusion as to mere consistency generally only has
the effect of not negating the claim.

18. Where the report is a psychiatric report, often diagnosing PTSD or some form of depression, there are
often observations of behaviour at the interview, and a recounting of the answers given to questions about
relevant conditions eg dreams and sleep patterns. Sometimes these answers are said to be consistent with
what has been set out as the relevant history of the applicant. It is more difficult for the psychiatrist to treat
what he observes as objectively verified, than it is for the description of physical conditions, because they
are the more readily feigned; it is rare for a psychiatrist's report to be able to indicate that any part of the
observations were undertaken in a way which makes them more objectively verifiable. It is the more
difficult for there to be any verification of conditions which the psychiatrist cannot observe and for which he
is wholly dependent on the applicant. The further major problem with the contention that a psychiatric
report can be used to support an applicant's claim to have told the truth about the history, is that there are


-----

Centre and another intervening) [2020] EWCA Civ 1746

usually other obvious potential causes for the signs of anxiety, stress and depression. These include the
fact that the applicant may be facing return to the country which he has left, at some expense to himself
and family, and it may well not be a pleasant place to which to return. He may face the loss of friendships
and lifestyle which he has enjoyed in the United Kingdom. There may be a loss of family contacts and of
medical treatment. He may anyway suffer from some depression, without having been ill-treated in a way
requiring international protection. He may have experienced difficulties other than those which he relies on
for his claim. But it is very rare, and it will usually be very difficult, for a psychiatrist to assess such other
factors without engaging in the process of testing the truth of what the applicant says. This is not his task
and if there is a therapeutic side to the interview, it may run counter to those aims as seen properly by the
doctor.

19. Accordingly, the part which a psychiatric report can play in assisting the assessment of credibility is
usually very limited indeed. It will be even rarer for the report to be or contain a factor which is of real
significance in the assessment. Where the report merely recounts a history which the Adjudicator is
minded to reject, and contains nothing which does not depend upon the truthfulness of the applicant, the
part which it can play is negligible. In any event, and importantly, the report is unlikely to have considered
other causes for what has been observed, or the possible diagnosis, if any, if the history is untrue.”

113. It may be helpful to summarise Ouseley J's thoughtful analysis in those paragraphs:

(1) The overall structure is that para. 17 is concerned with doctors' reports generally, as they bear on
credibility, whereas paras. 18-19 are addressed specifically to psychiatric reports.

(2) The point made in the first half of para. 17 is Ouseley J's observation that a doctor usually accepts the
applicant's history at face value and does not express an opinion about its credibility. That may well be so,
and we agree that in such cases it is obviously right that the history as recounted cannot constitute
evidence supportive of the applicant's case; but we would observe that the case-law reviewed below shows
that doctors do sometimes express an opinion about the credibility of the history given by the applicant.
Ouseley J also says that in any event the decision about credibility has to be taken by the fact-finder and
that he or she will typically have more material than the doctor and will have heard the evidence tested.
That is indeed typically so, but we should observe that in the case of a conclusive grounds decision the
decision-maker will not have heard the applicant's evidence tested by cross-examination.

(3) In the second half of para. 17 Ouseley J acknowledges that even if the witness expresses no opinion
about credibility, their findings may nevertheless be corroborative of the applicant's account. But he makes
the point that that will only be so if they go beyond “mere consistency”.

(4) The effect of para. 18 is to draw attention to two particular problems about the value of opinions
expressed by psychiatrists which are relied on as supportive of the truth of a claimant's account. The first
is that those opinions are likely to be based on the applicant's history of symptoms which cannot be
objectively verified. The second is that the symptoms in question are likely, of their nature, to be nonspecific and thus potentially due to causes other than the ill-treatment which the applicant claims to have
suffered.

(5) Para. 19 expresses the view that for those reasons the part which a psychiatric report can play in
assisting the assessment of credibility “is usually very limited indeed”.

Those are, to anticipate our overall conclusion on this issue, important points, which must be borne well in
mind by the decision-maker; but, as will appear, the authorities to which we now turn suggest that the last
two sentences of para. 18, and the conclusion in para. 19, may be rather too restrictively expressed.

114. The next case in point of time is Mibanga. As noted above, it is evident that Wilson J believed that
the doctor's evidence – apparently including the views which she expressed about the appellant's
credibility – deserved considerable weight.

115. In S v Secretary of State for the Home Department _[[2006] EWCA Civ 1153 the sole ground of appeal](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG31-DYBP-P1CY-00000-00&context=1519360)_
was what I have called the Mibanga point. This Court held that the tribunal had not fallen into that error.


-----

Centre and another intervening) [2020] EWCA Civ 1746

But Rix LJ went on (at para. 29 of his judgment), albeit expressly obiter, to quote para. 17 of Ouseley J's
judgment in HE (though not paras. 18-19) and continued, at para. 30:

“We think that those words are entirely applicable to the circumstances of this case. What the tribunal there
said is generally the position. As such, it is of course capable of being subject to exceptions and, for the
reasons which I have sought to give, I would regard Mibanga as being a good example of the exceptional
situation in which a medical report can have clear corroborative weight which will need to be properly
addressed.”

116. Next, in HK v Secretary of State for the Home Department _[2006] EWCA Civ 1037 the appellant was_
an asylum-seeker from Sierra Leone who claimed to have been tortured by members of a secret society.
He adduced evidence from two doctors, both of whom diagnosed PTSD and who also found that scarring
on his body was consistent (in one case “highly consistent”) with his account. One of them also recorded
the negative results of a particular (“EMDR”) test which were said to provide no evidence that his account
was fabricated. His claim was rejected by the adjudicator, whose decision was upheld by the IAT. The IAT
found that the expert evidence did not carry significant weight, for various reasons including that the two
doctors perforce proceeded on the basis that the appellant's story was true. This Court allowed his appeal.
As regards the particular reason to which we have referred Neuberger LJ said, at para. 44:

“The mental difficulties suffered by HK, as discussed by the doctors, were consistent with his case. Dr
Groszer's conclusion, as a result of his observation of Mrs Levy's EMDR test, that HK's story was true, is
also of real support to HK's case. Of course, as Chadwick LJ observed during the argument, it is the
Tribunal, not the doctors, who must ultimately decide whether or not the story is to be believed. However,
particularly in a case such as this, with the very unusual nature of the story and the absence of much other
corroborating or conflicting evidence, that testimony should not have been passed over without mention.”

Thus Neuberger LJ clearly did not discount the evidence of PTSD simply because the doctor had
proceeded on the basis of the appellant's account.

117. In _HH (Ethiopia) v Secretary of State for the Home Department_ _[[2007] EWCA Civ 306 the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG31-DYBP-P0SX-00000-00&context=1519360)_
Immigration Judge had disbelieved the appellant's account of having been detained and beaten by the
authorities in Ethiopia. She had sought to rely on the evidence of a GP who worked in a specialist practice
for asylum-seekers. There were various challenges to the way in which the Judge had dealt with that
evidence. We need only mention two:

(1) The Judge was said wrongly to have disregarded the opinion of the doctor that the appellant's account
of her treatment was credible. Keene LJ, with whom Pill and Moore-Bick LJJ agreed, did not accept that
criticism. He said that that was not an opinion that the doctor should have expressed and that she should
have confined herself to the question whether the appellant's physical and psychological condition was
consistent with her story: it was for the Judge alone to decide on credibility on the basis of all the evidence,
including the medical report (see paras. 17-18).

(2) The Judge was criticised for observing that the doctor should have considered other possible causes of
the appellant's mental health symptoms. Keene LJ did not accept that criticism either, saying that he had
been entitled to comment as he did, especially since the diagnosis was very largely dependent on
assuming that the account given by the appellant was to be believed (see para. 23).

118. In MO (Algeria) v Secretary of State for the Home Department _[2007] EWCA Civ 1276 an adjudicator_
had found that an asylum-seeker's account of having been tortured was not credible, notwithstanding some
arguably supporting evidence from a doctor; and the Asylum and Immigration Tribunal upheld its decision.
On appeal to this Court the appellant sought, again, to rely on a _Mibanga point. The appeal was_
dismissed, but at para. 18 of his judgment Moses LJ (sitting with Auld and Rix LJJ, who, it will be noted,
were members of the court in S) said:

“I would, however, add words of caution. It is true that a doctor is not required to give his view of the
credibility of the patient and it will be of limited assistance. But a doctor is not to be criticised when he does
so Doctors often do comment upon the consistency and credibility of the historian before them namely of


-----

Centre and another intervening) [2020] EWCA Civ 1746

the patient's account. Whilst, as [counsel] pointed out in the authorities to which I have already referred,
there are a number of dicta that are not usually appropriate for a doctor to assess the credibility of the
applicant18, he is not to be criticised when he does so. Indeed, sometimes it will be unfortunate if he did
not, since then the fact-finder will be deprived of the benefit of the doctor's opinion that someone has
proved to be an unreliable historian. Of course that is not dispositive. A tribunal charged with finding facts
must make up its own mind but I make these comments because the tribunal, at the second stage in the
instance appeal, said this:

'As we have found [the appellant] not credible, we place limited weight on this medical report and note that
he was not unable to give evidence and appeared to have a selective memory as he could recall certain
points. It is not within the doctor's remit to make credibility findings, he should confine himself to clinical
ones as they are based on accepting what he said, which we have not [sic].'

This passage was, in my view, too prescriptive. What the tribunal should have said is that Doctor Frank's
views, based as they were in the main on what he had been told by the appellant, did not determine the
issue of credibility. Dr Frank made findings which the tribunal was bound to take into account in
considering credibility, in particular, [that some of his symptoms were] attributable to his memory of
torture.”

(This judgment was delivered orally, and the passage does not seem to have been very well transcribed;
but the gist is clear enough.) In fact, the court held that there was an ample basis for the tribunal to reject
the appellant's account notwithstanding the doctor's opinion; but the important point for our purposes is that
Moses LJ held that it should have taken it into account.

119. In R (AM) v Secretary of State for the Home Department _[2012] EWCA Civ 521 the appellant claimed_
to have undergone torture and rape. She was assessed by an expert, Ms Kralj, who placed weight not
only on evidence of scarring but on her own assessment of the appellant's history and presentation. An
immigration judge rejected her evidence because it “depended upon accepting the claimant's account how
the injuries were caused”. This Court held that he was wrong to do so.  Rix LJ said:

“29. In my judgment, Ms Kralj's reports constituted independent evidence of torture. Ms Kralj was an
independent expert. She was expressing her own independent views. … [I]t is evident from her
assessment that she believed that AM had suffered torture and rape and that those misfortunes had
rendered her the 'grossly traumatized' woman that she found her to be, with 'feelings of deep and intense
shame and self disgust', 'feelings of shame and stigmatization', and a 'fragile mental state'. Those findings
are Ms Kralj's interpretation of what she found, they are not the mere assertions of AM.

30. … As the judge himself rightly stated, Ms Kralj 'believed the claimant'. That belief, following an expert
examination and assessment, also constituted independent evidence of torture. Ms Kralj's belief was her
own independent belief, even if it was in part based on AM's account. However, the judge was mistaken to
suggest that such belief was merely as a result of 'taking everything she said at face value'. A fair reading
of her reports plainly went very much further than that. …

31. … Ms Kralj's belief … was plainly independent evidence, even if it depended in part on formulating her
opinion in the light of AM's account.”

120. In SS (Sri Lanka) v Secretary of State for the Home Department _[2012] EWCA Civ 945 one of the_
grounds of appeal against a decision that the appellant was not a victim of rape was that the tribunal
wrongly discounted the medical evidence that the appellant was suffering PTSD associated with rape when
reaching its conclusion that she was not a credible witness. Two doctors were of the opinion that she
displayed symptoms of PTSD and both reported that she experienced flashbacks to the events
surrounding the rape. The tribunal treated the reports as being of no value. One reason was that the
expert's opinions were based on the appellant's own account. The tribunal also said, of one of the reports:

“… it entirely fails to consider other reasons for her mental condition, for example, that she has been
suffering from breast cancer; that she is out of her home country; that her husband has disappeared and
his whereabouts are said to be unknown and the protracted determination of her asylum claim All the


-----

Centre and another intervening) [2020] EWCA Civ 1746

foregoing might reasonably be [sic] wholly or partly contribute to her mental condition, but these
possibilities have been overlooked.”

This Court held that the tribunal's approach was wrong. Moore-Bick LJ said, at para. 23:

“Although inevitably those opinions were ultimately based on what they had been told by the appellant
herself, there is no reason to think that the doctors believed that she was giving them anything other than a
reliable description of her symptoms. In those circumstances their reports do provide support for her
account. Unless her accounts of flashbacks were fabricated (something that the doctors could have been
expected to detect, or at any rate suspect), they inevitably supported her evidence.”

121. In our view the law as appears from those authorities19 (so far as relevant to the issues in these
appeals) can be summarised as follows:

(1) The decision whether the account given by an applicant is in the essential respects truthful has to be
taken by the tribunal or CA caseworker (for short, the decision-maker) on the totality of the evidence,
viewed holistically – Mibanga.

(2) Where a doctor's opinion, properly understood, goes no further than a finding of “mere consistency”
with the applicant's account it is, necessarily, neutral on the question whether that account is truthful – see
_HE (DRC), but the point is in truth obvious._

(3) However, it is open to a doctor to express an opinion to the effect that his or her findings are positively
supportive of the truthfulness of an applicant's account (i.e. an opinion going beyond “mere
consistency”)20; and where they do so that opinion should in principle be taken into account – _HK;_ _MO_
_(Algeria); and indeed, though less explicitly, Mibanga. In so far as Keene LJ said in HH (Ethiopia) that the_
doctor in that case should not have expressed such an opinion (see para. 117 (1) above), that cannot be
read as expressing a general rule to that effect.

(4) Such an opinion may be based on physical findings (such as specially characteristic scarring). But it
may also be based on an assessment of the applicant's reported symptoms, including symptoms of mental
ill-health, and/or of their overall presentation and history. Such evidence is equally in principle admissible:
there is no rule that doctors are disabled by their professional role from considering critically the
truthfulness of what they are told – Minani; HK; MO (Algeria); SS (Sri Lanka). We would add that in the
context of a decision taken by the CA on a wholly paper basis, a doctor's assessment of the truthfulness of
the applicant may (subject to point (5) below) be of particular value.

(5) The weight to be given to any such expression of opinion will depend on the circumstances of the
particular case. It can never be determinative, and the decision-maker will have to decide in each case to
what extent its value has to be discounted for reasons of the kind given by Ouseley J at para. 18 of his
judgment in HE (DRC).

(6) One factor bearing on the weight to be given to an expression of opinion by a doctor that the
applicant's reported symptoms support their case that they were persecuted or trafficked (as the case may
be) is whether there are other possible causes of those symptoms. For the reasons explained by Ouseley
J (loc. cit.), there may very well be obvious other potential causes in cases of this kind. If the expert has
not considered that question that does not justify excluding it altogether: SS (Sri Lanka). It may diminish
the value that can be put on their opinion, but the extent to which that is so will depend on the likelihood of
such other causes operating in the particular case and producing the symptoms in question.

122. Those conclusions are concerned specifically with evidence from doctors. In the asylum and
trafficking context applicants sometimes adduce evidence from non-medical witnesses, with experience of
the kind of persecution or trafficking in question, to the effect that the account which the applicant gives of
their experiences is “consistent with” the accounts given by other established victims. This is obviously
evidence of a different character from evidence of signs or symptoms assessed by a doctor, and the
relevance of “consistency” would appear to be rather different. If an applicant gives a highly circumstantial
account of, say, the means used to recruit or transport them or the way in which they were exploited, and


-----

Centre and another intervening) [2020] EWCA Civ 1746

the details closely correspond to what other established victims have reported, that will in principle support
the truth of their story, though the extent to which it does so will depend on the particular case: it will
always be necessary to assess the degree of correspondence, and a decision-maker will also have to bear
in mind the real possibility of the applicant having been coached to give a convincing account. We were
referred to no authority about the proper approach to opinion evidence of this character, but in our
experience it is commonly admitted and taken into account (see, for example, para. 78 of the judgment of
Underhill LJ in TDT). We can see no reason why it should not be, and indeed no objection was taken in
the two appeals before us to elements in the evidence of one of the expert witnesses (Ms Thullesen) which
was of this character.

123. The essential message of that possibly over-elaborate discussion is that decision-makers should in
each case assess whether and to what extent any particular expert evidence relied on by an applicant
supports their case as a matter of rational analysis. Observations in the case-law are useful in drawing
attention to likely limitations on the value of particular kinds of evidence, but they should not be treated as
laying down rigid rules.  If there are qualifications to the value to be given to a particular piece of evidence,
that is not a reason for excluding it altogether: if it has some weight it must go into the overall assessment.

124. We should note for completeness that the Guidance contains a short section entitled “Views of
experts during the [NRM] process” (pp. 101-2). We heard no submissions on it, but we can see nothing in
it inconsistent with what we have said above.

**ISSUE (3): CREDIBILITY**

125. For the reasons given, we again confine ourselves to a particular question that may be of some
general application. It concerns the part of the Guidance that addresses the assessment of credibility by
CA staff (pp. 97-100). This is headed “How to assess credibility when making a Reasonable Grounds or
Conclusive Grounds decision”.21 It gives detailed guidance under a number of headings. We need not
summarise it generally because although we were briefly taken through it no issue arose as to most of it.
The only section on which any point was taken is headed “Assessing credibility – mitigating circumstances”
(pp. 98-99). It reads:

“Competent Authority staff need to know about the mitigating circumstances which can affect whether a
potential victim's account of human trafficking or **_modern slavery is credible. When the Competent_**
Authority assesses the credibility of a claim, there may be mitigating reasons why a potential victim of
human trafficking or modern slavery is incoherent, inconsistent or delays giving details of material facts.
The Competent Authority must take these reasons into account when considering the credibility of a claim.
Such factors may include, but are not limited to, the following:

trauma (mental, psychological, or emotional)

inability to express themselves clearly

mistrust of authorities

feelings of shame

painful memories (including those of a sexual nature)

Children may be unable to disclose or give a consistent credible account due to additional factors such as:

their age

the on-going nature of abuse throughout childhood

fear of traffickers or modern slavery facilitators, violence, or witchcraft.”

126. In our view, although the particular points made in that passage are valid and important, their
categorisation as “mitigating circumstances” is not apt, and indeed Mr Irwin, who argued this part of the
case for the Secretary of State, accepted as much. It is not simply that that phraseology has an
inappropriate echo of criminal proceedings More substantially it implies an approach under which the


-----

Centre and another intervening) [2020] EWCA Civ 1746

decision-taker first identifies the defects in the account of a putative victim and then tries to decide whether
they can be excused for reasons of the kind given. That risks being over-mechanistic and does not reflect
the real nature of the exercise. As is made clear in Mibanga, what is required is a single process in which
the decision-maker assesses the credibility of the core account given by the putative victim. In doing so it
will be necessary to take into account features which potentially call their credibility into question, such as
incoherence, inconsistency or delay, alongside factors which may explain those features.

127. We would add one further point about language. The term “credibility” is used a good deal in the
context both of asylum appeals and of decisions whether a person is a victim of trafficking, and we have
detected a tendency to treat it as having some special technical meaning. But in truth it connotes no more
than whether the applicant's account is to be believed. In making that assessment the decision-maker will
have to take account all factors that may bear on that question. Likewise the term “plausibility” is not a
term of art. To say that a particular account, or element in that account, is implausible is simply to say that
it seems to the decision-maker to be inherently surprising, or the kind of thing that you would not normally
expect to happen; and such an assessment will obviously feed in to the overall assessment of credibility,
though the weight to be given to it will depend on the degree of unlikelihood and how confident the
decision-maker can be about it. Perhaps both points are too obvious to need making; but if terms are used
too regularly they sometimes get in the way of the process of common sense decision-making.

128. Essentially the same points are made by Neuberger LJ at para. 30 of his judgment in HK, to which
we have already referred. Since Mr Husain placed some weight on the passage in his submissions we will
set it out in full:

“Inherent improbability in the context of asylum cases was discussed at some length by Lord Brodie in
_Awala v Secretary of State_ [2005] CSOH 73. At paragraph 22, he pointed out that it was "not proper to
reject an applicant's account _merely_ on the basis that it is not credible or not plausible. To say that an
applicant's account is not credible is to state a conclusion' (emphasis added). At paragraph 24, he said that
rejection of a story on grounds of implausibility must be done 'on reasonably drawn inferences and not
[simply on conjecture or speculation'. He went on to emphasise, as did Pill LJ in Ghaisari [[2004] EWCA Civ](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG31-DYBP-P4N4-00000-00&context=1519360)
_[1854], the entitlement of the fact-finder to rely 'on his common sense and his ability, as a practical and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG31-DYBP-P4N4-00000-00&context=1519360)_
informed person, to identify what is or is not plausible'. However, he accepted that 'there will be cases
where actions which may appear implausible if judged by … Scottish standards, might be plausible when
considered within the context of the applicant's social and cultural background'.”

**MN's APPEAL**

129. We should observe by way of preliminary that Mr Husain used almost all the time available to him in
his oral submissions in addressing the issues of general application; and Sir James and Mr Irwin followed
suit. We accordingly heard very little by way of oral argument on the facts of the individual cases and have
had to rely largely on the submissions in the skeleton arguments. In MN's case in particular, that was far
from ideal, since, as will appear, it has turned out to require a very detailed analysis of the decision of the
CA and of the materials on which it is based.

MN's ACCOUNT IN OUTLINE

130. MN has given a number of accounts of how she says she was trafficked and of the aftermath – in
immigration interviews, in witness statements and in the histories that she has given to doctors. As will
appear, there are a number of inconsistencies within and between those accounts. At this stage we need
only give a bare outline of her account based on what she says in her first witness statement submitted to
the CA for the purpose of the decision which is challenged in these proceedings.

131. MN is an Albanian national from Burrel in northern Albania, born on 11 January 1988. She says that
in 2009, when she was aged 21, she began a relationship with a man called Ardian whom she met through
her work in a cafe. She claims to have left Albania with Ardian for Italy, against the wishes of her parents,
on 23 December 2010, with the intention of improving her situation in preparation for marriage. She
travelled on a new passport for which she had applied the previous month


-----

Centre and another intervening) [2020] EWCA Civ 1746

132. MN says that on their arrival in Italy Ardian took her to the house of an associate of his called Luli in
Turin. This turned out to be a brothel. Luli beat her and said that Ardian had sold her to him and that she
would have to work for him: he then raped her. She remained there for eighteen months under his total
control, being forced to work daily as a prostitute and leaving the house only occasionally, and never
unaccompanied, to be taken to clients at their homes or hotels. There were security cameras in the
corridors, the whole house was guarded, and she was often locked in her room. She was occasionally
given small sums of money by Luli or her clients.

133. MN says that she was only able to escape on an unspecified date at the end of May 2012 when the
police raided the brothel. She walked out without being challenged and went straight to the airport and
flew back to Albania. She travelled on the passport that she had travelled to Italy with originally, which she
had retained throughout her captivity; but on her arrival she was told that it was “invalidated” (which we
assume means that it was cancelled, if not indeed confiscated) because she had been in Italy for longer
than the three months covered by her visa.

134. MN says that on her return to Albania she did not go back to Burrel but stayed with her maternal
uncle in Tirana. She was deeply ashamed of, and traumatised by, what she had done and what she had
been subjected to. She had indirect contact with her family through her uncle and was told that her father
had disowned her.  She says that both Ardian and Luli, separately, visited her family in Burrel to try to
discover her whereabouts: on Luli's visit he “kidnapped” her father and her brother and beat her father up
so badly that he was in hospital for a fortnight. She says that she did not believe she was safe in Albania
and that the only place where she could be safe was the UK. She applied for a new passport, her old one
having been invalidated.

135. On 3 November 2012 MN tried to enter the UK on a flight from Turin to Stansted, travelling on a false
Italian ID card. She says that she had flown to Turin from Tirana earlier the same day. The arrangements
had been made by her uncle with an agent. She was interviewed (using the services of an interpreter over
the telephone). She made no claim for asylum, or to be a victim of trafficking, and was returned to Milan
the following day. The Italian authorities put her on a flight back to Tirana.

136. On 18 February 2013 MN re-entered the UK. Again, the arrangements were made by the agent.
She travelled clandestinely in the same lorry all the way from Albania. She made a claim for asylum. On
26 February she underwent a screening interview. A full asylum interview took place on 14 March. Both
interviews were conducted through an interpreter.

137. It is well recognised that the trafficking of young women from Albania to Italy to work as prostitutes is
a common phenomenon. It is clear from the evidence which was before the CA that the essential features
of MN's account are typical of the experiences of genuine victims. It does not of course necessarily follow
that it is true. If a young Albanian woman wanted to come to the UK in order to better herself, and planned
to present herself as a victim of trafficking in order to obtain leave to remain, she could be expected to
know, or be coached by an agent in, the kinds of thing that she needed to say.

PREVIOUS DECISIONS

138. As a result of what she said in her asylum interview MN's case was referred to the NRM. A second
referral was made on her behalf by the Salvation Army on 18 March 2013. A reasonable grounds decision
was made on 21 March.

139. By a decision dated 27 September 2013 the CA made a conclusive grounds decision that MN was
not a victim of trafficking. That is not the decision with which we are concerned on this appeal, and we
need give no details of the reasoning.

140. By a decision dated 28 January 2015 MN's asylum and human rights claim was refused by the
Secretary of State. She appealed to the FTT. Her appeal was heard by First-tier Tribunal Judge Whalan
on 24 June 2015. She was represented by a solicitor, though not by the firm now representing her. It is
clear from the papers that a great deal more detailed work has been done on MN's case by her current
legal team than as done for the p rpose of the FTT proceedings (tho gh e sho ld make it clear that that


-----

Centre and another intervening) [2020] EWCA Civ 1746

is not necessarily a criticism of the lawyers then instructed). The only witness statement from MN appears
to have been a very brief two-page statement clarifying or correcting some points from the asylum
interview. MN gave evidence through an Albanian interpreter and was cross-examined.

141. By a decision with reasons promulgated on 22 July 2015, MN's appeal was dismissed. The Judge
found that she was “a particularly poor witness”. He regarded certain aspects of her account as inherently
implausible and he found that her evidence was undermined by repeated and unexplained inconsistencies
in the core elements of her claim. He also observed that there had been “no relevant medical evidence in
support of her claim”. He held that the only reasonable conclusion on the evidence, even when assessed
by reference to the comparatively low standard of proof applicable in asylum claims, was that MN was an
economic migrant and not a victim of trafficking for sexual exploitation. He said:

“I have rejected the Appellant's factual claim in its entirety and so it follows that she has no well-founded
fear of persecution and/or is not at risk of serious harm on return to Albania. She is not entitled to asylum,
humanitarian protection or protection under Article 3 of the ECHR.”

THE APPLICATION FOR RECONSIDERATION

142. On 29 June 2016 solicitors acting for MN sought reconsideration of the 2013 conclusive grounds
decision on the basis that it was flawed and that there was new material which gave rise to a duty on the
CA to conduct further investigations and reach a fresh decision. Following that original request they
produced some further evidence. In its final form the material relied on included three witness statements
from MN and evidence from three expert witnesses.

The Witness Statements

143. MN's first witness statement, dated 12 July 2016, gives a comprehensive account of her history from
when she first met Ardian up to and including the hearing in the FTT. One of its features is that it identifies
a number of points where the record of her answers in the screening and asylum interviews is said to be
wrong, whether as a result of errors by the interpreter, misunderstandings or errors in the recording of her
answers. At paras. 86-87 she says that during both interviews she was anxious and upset. She says that
as a result during the asylum interview in particular she had difficulty understanding and answering the
questions that she was asked and also that the interpreter put her under a lot of pressure. As to that, there
are occasions in the record where the immigration officer is recorded as telling her that she was not
answering the questions or that she was not speaking clearly and also where she is recorded as becoming
upset.

144. Her second statement, dated 23 February 2017, provided a short update on her counselling
sessions, accommodation and support; and addressed what is described as “an omission from her first
witness statement”: we explain this later.

145. MN's third witness statement, dated 18 July 2017, contained her response to questions raised by the
CA following its initial consideration of her application for reconsideration: we will refer to this as the
questionnaire. These related partly to perceived inconsistencies within and between the accounts given in
her witness statements and her screening and asylum interviews. But they related also to information
which the Home Office had obtained from the Albanian authorities about the dates on which MN was first
issued with a passport and about her recorded travel into and out of Albania. An important element in that
information was that MN was not issued with any passport until 8 June 2012.

The Expert Evidence

146. MN relied first on a one-page letter dated 19 April 2016 from Hannah Rees, a registered
psychotherapist and the “Counselling Co-ordinator” at the charity Rape Crisis, where MN had been
receiving counselling. The letter is very short and is to whom it may concern “in support of her status as
victim of trafficking”. Ms Rees had not herself seen MN and the letter is based on what appeared in Rape
Crisis' internal assessment report and what Ms Rees had been told by MN's counsellor. After a very


-----

Centre and another intervening) [2020] EWCA Civ 1746

summary account of MN's reported history, it describes her as displaying “symptoms of high anxiety and
low mood, hypervigilance and hyper arousal, rumination, sleeplessness, overwhelming feelings of shame
and issues with memory recall”. She said that those symptoms were “consistent with those displayed by
people who had suffered sexual violence-related trauma and PTSD”.

147. Second, MN relied on a report dated 24 October 2016 addressed to MN by Dr Rebecca Johnson of
London Trauma Specialists. Dr Johnson is a clinical psychologist working in the Haringey Complex Care
Team at the Barnet, Enfield and Haringey NHS Trust, who met MN for the purpose of an assessment on 9
and 26 September: there is no mention of whether an interpreter was required. It is based on an
assessment of MN in September 2016. It contains, again, a short summary of MN's account of her
experiences followed by a fuller account of her presenting symptoms. It concludes that she “is presenting
with difficulties consistent with a diagnosis of PTSD as a result of trafficking and sexual abuse in Italy”.
The symptoms of PTSD are described as “intrusive memories, nightmares, hyper arousal, persistent and
negative views about herself”. It refers in particular to MN's overwhelming feelings of shame and describes
them as similar to those reported by other Albanian victims of sexual abuse whom Dr Johnson has treated.

148. Finally, MN relied on a report dated 15 March 2017 from Mirjam Thullesen, a psychologist and
psychotherapist specialising in the assessment and treatment of victims of trafficking. She interviewed MN
for over three hours on 14 November 2016: she says that an interpreter was present, and presumably
therefore MN was interviewed wholly or mainly in Albanian. Ms Thullsen's report is exceedingly long, and
we should summarise her principal conclusions in a little detail.

149. In the introductory section of her report Ms Thullesen identified the questions on which she had been
asked to give her opinion. These included (para. 12 (iii)) “whether or not [MN's] account is plausible”. At
para. 13 she says:

“It is important to note that whilst I cannot comment on credibility, as this is a matter for the court to decide,
I base my opinions on the consistency of [MN's] account in relation to that of other victims of trafficking I
have provided support to, as well as on objective evidence.”

As will appear, Ms Thullesen does in fact later in her report express opinions – based on MN's presentation
as well as on consistency with the accounts of other victims of trafficking – the effect of which is strongly
supportive of the conclusion that her account of being a victim of trafficking is true. On one view that does
indeed amount to her “commenting on credibility”; but it appears that Ms Thullesen meant that she ought
not to express a view on the ultimate question of whether the account was true although she plainly does
express a view on factors feeding into that question. That is unexceptionable.

150. At paras. 18-77 of her report Ms Thullesen sets out in great detail MN's account of her experiences
derived from her interview. At paras. 78-104 she identifies commonly recognised indicators of trafficking in
that account.

151. At paras. 105-128 she performs “an assessment of [MN] as a victim of trafficking”. Her conclusion at
para. 124, based on her knowledge of assessing and working with victims of trafficking, is that MN's
account “contains a significant number of trafficking indicators”. She continues:

“I find the explanation of her personal history of oppression, as well how she came to be recruited, to be
broadly consistent with other Albanian victims of trafficking. My opinion is based not only on [MN's]
documents but also on relevant literature and on a comparison with other accepted victims of trafficking I
have assessed.”

At para. 126 she says:

“Her presentation during the assessment was synonymous with the majority of other accepted victims of
trafficking I have assessed and supported. I consider it possible and probable that she continues to
withhold some aspects of her account, for various possible reasons including fear, shame and distrust.
However, based on her overall presentation during the assessment and the details of her narrative, I


-----

Centre and another intervening) [2020] EWCA Civ 1746

consider it unlikely that she has fabricated fundamental and key features of her experiences or is feigning
her current emotional and psychological difficulties.”

After referring to an academic study of indicators on deception in the context of medical reports, she
continues:

“127. … [MN] did spontaneously correct information and admitted concern about her own testimony as well
as her ability to recall information.

128. When fabricating accounts it can often be difficult for a person to divert from a rehearsed narrative
and it can sound static and inflexible, consistently emerging in the same order and with the same key
details, a feature I did not observe in the interview with [MN] … I did not experience her account as
rehearsed or presented in a manner which would lead me to question its overall consistency with that of
other victims of trafficking I have assessed … [H]er account is consistent with the broad themes and
patterns in the accounts of many other Albanian victims. From a clinical perspective, I also did not consider
her affect or general presentation as inappropriate, forced or questionable”.

152. At paras. 129-132 Ms Thullesen refers to a number of published sources describing the prevalence of
the trafficking of young women from Albania to Italy for the purpose of prostitution. She notes also that in
2015 Albania was the highest source country for victims of trafficking accepted under the NRM. She
observes that MN's account is consistent with that of other Albanian victims of trafficking whom she has
assessed.

153. At paras. 133-146 Ms Thullesen addresses “Self-identification, reluctance, delay and inconsistency in
disclosing experiences of trafficking and exploitation”. Among other things, at para. 133, after referring to
“… the prevalence of psycho-emotional phenomena such as narrative inconsistency, lack of memory,
delay, difficulty identifying experiences as exploitation/trafficking and reluctance to disclose experiences”
she continues:

“I concur with the Home Office Guidance to frontline staff22 which outlines 'Potential victims of **_modern_**
**_slavery may be reluctant to come forward with information, not recognise themselves as having been_**
_trafficked/enslaved, teller stories with obvious errors.  It is not uncommon for traffickers or_ **_modern_**
**_slavery facilitators to provide stories for victims to tell if approached by the authorities. Errors or lack of_**
_reality may be because their initial stories are composed by others and learnt.' This point is consistent with_
and directly relevant to the manner in which [MN's] account has emerged in a piecemeal fashion over time,
and in her difficulties recording the exact details of certain aspects of her experiences.

The section concludes:

“In summary, MN's significant difficulty in disclosing her account, and the piecemeal fashion which it has
emerged, is highly consistent with other victims of trafficking, and indeed generally with refugee women,
who have experienced sexual violence. Thus, the delay in disclosure of certain aspects of her account
does not lead me to question the general consistency of her narrative with that of other victims of trafficking
assessed. The level of control exerted, her psychosocial presentation, combined with pre-existing
emotional vulnerability, in my opinion, renders her style of disclosure a pattern consistent with that of many
other victims.”

154. Paras. 147-158 are headed “Psychosocial and health effects”. She recounts MN's symptoms which
she considers characteristic of PTSD and which she says “appear highly consistent with the presentation
of a woman who has been trafficked for the purpose of sexual exploitation”.

155. Ms Thullesen's summary, at para. 186, reads:

“In conclusion, I find the indicators and patterns of trafficking evident within MN's account to be consistent
with other victims I have assessed, and with objective evidence referred to in this report. This is based on
my knowledge of assessing and working with victims of trafficking whilst at the Poppy Project, at the
Refugee Council and as an independent consultant. It is also based on the particulars of MN's case, taking
into consideration all of the evidence available to me. It is my opinion that she fulfils the key elements


-----

Centre and another intervening) [2020] EWCA Civ 1746

known to constitute trafficking. Namely, (i) the action of being recruited and transported by Ardian, by the
(ii) _means of coercion, abuse of position of vulnerability, falsely leading her to believe they were in a_
genuine relationship. MN seems to have been groomed for a period of time before travelling to Italy where
she was used for the (iii) purpose of sexual exploitation in prostitution.”

156. We should identify the ways in which the evidence of the three expert witnesses was potentially
supportive of MN's claim to be a victim of trafficking.

157. First, all three witnesses express the opinion that MN's reported symptoms – primarily characterised
as PTSD – are “consistent with” those experienced by women who have suffered sexual exploitation of the
kind described by her. On a fair reading, it seems that all three witnesses use that phrase to connote more
than “mere consistency”: that is, they intend to convey that the symptoms are at least to some extent
positively supportive of the truth of her account. But the weight to be given to that evidence must depend
on the extent to which similar symptoms may be caused by other experiences, which is not a point that any
of the reports directly addresses. It is also, of course, dependent on whether the symptoms were being
feigned. But Ms Thullesen expressly and Dr Johnson (we think) by implication express the opinion that
that is not the case.

158. Second, Ms Thullesen expresses the opinion that MN's narrative contained indicators of trafficking
and sexual exploitation that were consistent with the accounts of other victims. That is based not on her
medical expertise but on her experience in working with other victims of trafficking; but, as noted above, it
is in principle capable of supporting the truthfulness of her account, though the extent to which it does so
will depend on the circumstantialness of the features relied on.

159. Third, Ms Thullesen expresses the opinion that inconsistencies in, and late disclosure of, MN's
account of her experiences are characteristic of victims of trafficking. That, as a general proposition, is of
course consistent with the Secretary of State's own Guidance: see para. 125 above.

160. Fourth, Ms Thullesen expresses the opinion that MN was not fabricating her account of her
experiences. Evidence of that kind is admissible though in no way determinative: see para. 121 above.

THE DECISION OF THE COMPETENT AUTHORITY

Introductory

161. By letter dated 7 August 2017 the CA maintained its earlier conclusive grounds decision that on the
balance of probabilities MN was not a victim of trafficking, essentially on the basis that her account was not
considered credible. The reasons for the decision are contained in an enclosed “Consideration Minute”
running to over 30 pages: though the Minute is strictly a separate document, we will refer to it in the usual
way as “the decision letter”.

162. It is convenient to note at this point that, following an initial consideration of the materials provided,
the CA wrote to the three expert witnesses asking them to comment on a number of apparent
inconsistencies in the accounts given by MN on different occasions. Only Ms Thullesen replied, and her
response was to the effect that the questions should be raised, at least in the first instance, with MN's
solicitors. The CA accordingly wrote to them, and they provided the third witness statement from MN to
which we have referred above.

163. The decision letter starts with a Case Summary, which sets out a summary of MN's accounts derived
principally from her screening and asylum interviews (with references), though there are occasional
references to her first and second witness statements23. Thereafter, after some introductory materials, it
sets out or summarises some key provisions of the law on human trafficking. The letter then records a
short summary of the objective evidence considered regarding human trafficking and modern slavery in
Albania and Italy, and in particular that these countries were regarded as source, transit and destination
countries for the sexual exploitation of women.

164. The next section of the decision letter consists of a consideration of what are described as the
“medical professional reports”24. Para. 13 reads:


-----

Centre and another intervening) [2020] EWCA Civ 1746

“Your request for a reconsideration of your Conclusive Grounds Decision centres around the submission of
these reports. The placement of these documents' consideration should not be taken as indicative of the
weight attributed to them. However, they will be considered at the outset of your claim before making any
adverse credibility findings. The conclusions therein have been given due weight when assessing the
credibility of your accounts.”

That evidently reflects a wish to avoid the _Mibanga error. However, as noted above, the point made in_
_Mibanga does not depend on precisely where in a decision the consideration of any expert evidence_
appears. It is the substance that matters, not the form: the decision-maker must, demonstrably, have
undertaken a holistic exercise.

165. It will be convenient if when going through this part of the letter we not only record the CA's reasoning
but make some observations about its validity.

Ms Rees' Letter

166. The decision letter notes Ms Rees' opinion that the mental health symptoms suffered by MN were
consistent with those displayed by people who have suffered sexual violence-related trauma and PTSD.
But it then makes three points which appear to be intended to diminish the weight to be attached to that
evidence.

167. First, it notes, at para. 16, that her report was not based on contact with MN herself. This is a fair
point as far as it goes. In this case, however, it may not go very far, since the evidence is simply that MN
was reporting or displaying symptoms of PTSD which are characteristic of victims of sexual violence. The
fact that those symptoms had been reported to/observed by Ms Rees's colleagues rather than herself does
not much diminish the weight of that evidence: it might be different if, for example, Ms Rees had expressed
an opinion about whether the way she gave her history was credible.

168. Second, at paras. 17-19, the letter identifies two inconsistencies between MN's history as set out in
Ms Rees' report and her accounts elsewhere. These are (1) that Ms Rees records her as saying that she
left Albania “at the end of 2025 November 2010”, whereas in her other accounts she says that she left in
December; and (2) that she is said to have escaped from the brothel “after a two year period”, whereas the
period described in her first witness statement is 17 months. It then says, at para. 20:

“Consequently, whilst your mental health symptoms may have been consistent with someone who has
experienced sexual violence, it is not accepted that it was due to the events depicted in your narrative.”

We do not believe that that conclusion could reasonably be drawn from the two discrepancies identified.
Ms Rees's account of the history given by MN was both second-hand and extremely summary: it does not
represent a full and thorough history of the kind recorded by Ms Thullesen. The first discrepancy could
very readily have arisen as a result of an error of recollection more than five years after the event, quite
apart from the warnings contained both in the Guidance and in Ms Thullesen's evidence about the effect of
a prolonged period of abuse on a victim's ability to recall detail; or it could simply be an error in recording.
Similarly, it would not be surprising for a client, in a summary account given to a counsellor, to refer to a
period of 17 months as “two years”. Nor would it be surprising if MN had in fact given precise dates but
they were approximated when being written down: we repeat that this was not a full clinical history, nor
would it have been of any significance to the counsellor whether MN was held for 17 months or 24. The
significance attached to these minor discrepancies is rather troubling inasmuch as it suggests a hypercritical mindset on the part of the decision-maker where he was positively looking for reasons to discount
the evidence of the expert.

169. Third, it is noted that “the document does not explore any alternative aetiology”. This is a fair point in
itself (see para. 121 (6) above), though it is not a criticism of Ms Rees, who was not providing a full
medico-legal report.

170. This part of the decision letter concludes:


-----

Centre and another intervening) [2020] EWCA Civ 1746

“Taken in the round with the rest of your claim, this report is not considered mitigation for credibility issues
raised later in the interview26. In fact, it only serves to produce further inconsistencies.”

That is, with respect, an unsatisfactory conclusion. We have already deprecated the language of
“mitigation”. In any event, the report was not being relied on “in mitigation of credibility issues”: the
diagnosis of PTSD, and the consistency of MN's symptoms with those of established victims of sexual
violence, constituted evidence supportive of MN's account in its own right. The “further inconsistencies” in
themselves cannot reasonably be regarded as being of any significance.

171. Having said that, Ms Rees' one-page letter is not in truth of central importance to MN's case when
compared with the reports of Dr Johnson and, in particular, Ms Thullesen. Any defects in the treatment of
it could not undermine the CA's overall conclusion if it were otherwise sound. We have drawn attention to
them only because they may be indicative of an unsatisfactory approach on the part of the decision-maker.

Dr Johnson's Report

172. The decision letter sets out two of the main passages expressing Dr Johnson's opinion that MN was
suffering from PTSD as a result of her reported experiences. It then proceeds to make three points about
her report.

173. First, it identifies what it describes as “a notable discrepancy” between the history given by MN to Dr
Johnson and what she told the Home Office in the screening and asylum interviews. Dr Johnson records
her as having said that she did not tell her family about her relationship with Ardian before they left for Italy
because they would not have approved, whereas she had told the Home Office, as the letter puts it, that
“your family were not only aware of your relationship but gave you their blessing to relocate with him to
Italy” (paras. 25-27). We will return to this discrepancy later in a wider context, but the conclusion drawn
from it as regards Dr Johnson's report is that it “raises concerns that the report was produced without the
medical professional benefitting from access to all your previously submitted material”. This presumably
means that Dr Johnson had not seen the screening and asylum interviews. For ourselves, we think it is
clear from the report itself that Dr Johnson had indeed simply relied on MN's history. But we do not see
how this affects the weight of the evidence in her report. It was not her business to carry out a critical
assessment of MN's accounts and she had not purported to do so. She had simply expressed the opinion
that MN's symptoms were consistent with those reported by other established victims of trafficking.

174. Second, Dr Johnson had not considered the possibility that there were other causes for MN's
symptoms – “any alternative aetiology”. It is said that HH (Ethiopia) had “ruled” that she should have done
so (paras. 30 and 31). This is in principle a reasonable point, but we are concerned that the way that it is
deployed here suggests that the CA regarded it as some kind of absolute legal requirement rather than a
common sense point which might affect the weight to be given to Dr Johnson's opinion but did not render it
valueless.

175. Third, Dr Johnson had proceeded on the basis that MN's account as given to her was factually
correct, whereas it was in fact implausible and inconsistent (see paras. 30 and 32): the reasons for the
latter conclusion are said to appear “throughout this letter”. This is an important point, to which we return
later.

176. The decision-maker's conclusion (at para. 33) is that

“For these reasons Dr Johnson's report do [sic] not add weight to your claim.”

As discussed above, at least the first two of the reasons relied on by the CA for that conclusion are
unsatisfactory.

Ms Thullesen's Report

177. The decision letter begins by acknowledging that Ms Thullesen had had a three-and-a-half-hour faceto-face interview with MN and had considered a good deal of documentary material that included
transcripts of the screening and asylum interviews, the previous negative conclusive grounds decision and


-----

Centre and another intervening) [2020] EWCA Civ 1746

the FTT decision. It then proceeds to make a number of points which are not entirely easy to disentangle
but which can be summarised as follows.

178. First, it is said (paras. 39-42) that there were a number of “notable” discrepancies between MN's
account as given to Ms Thullesen and her previous accounts, of which the three “most significant” are
identified. The first is very similar to that discussed at para. 173 above, MN having told Ms Thullesen that
she had not told her father about her intention to leave Albania. As to the other two:

(1) In her asylum interview the way in which MN describes the assault and rape by Luli following her
arrival at his house suggests that it occurred very soon after she and Ardian arrived; whereas the decision
letter characterises her account as recorded by Ms Thullesen as being that Ardian left her at the house,
saying that he was going to buy some food, and that “it was not until later that evening that it became
apparent that Luli 'owned' you”. That does not appear to be an accurate summary of the relevant passage
in Ms Thullesen's report: there is no reference to “later that evening”, the phrase used (para. 48) being
“after some time”. We cannot see that that phrase is inconsistent with the much shorter account given in
the asylum interview (Q61); but, even if it could be said to be, this is precisely the kind of minor
inconsistency which is to be expected between accounts given some time apart, and in different
circumstances, of a traumatic event years previously.

(2) In her account of the police raid as recounted by Ms Thullesen, MN says (at para. 59) that when she
came downstairs from her room she saw “policemen talking to everyone … policemen at the reception
talking to the people there”. The letter says that that is contrary to her answers in the asylum interview,
“where you stated the police did not speak to anybody during their raid”. We can find no such statement in
the asylum interview. At Q105 she says that “the policemen were basically talking to the men that were
around”; and at Q106, in answer to a question why the police did not stop her and the other women who
were leaving, she said “I don't know why they didn't stop us but they stopped the men at the reception and
around the house”. That does not seem to us substantially different from what is recorded by Ms
Thullesen: an inconsistency can only be contrived by taking the word “everyone” wholly literally and out of
context, even supposing that Ms Thullesen was recording MN's exact language. The truth is that in both
accounts what MN was saying is that the police were talking to several men at the reception but not to the
women. Elsewhere in the letter the CA expresses the view that that is implausible, and we return to that
below; but there is no inconsistency.

What is of concern in both cases is the suggestion of a mind-set that regards even the most insubstantial
differences of wording as “notable” discrepancies.

179. Secondly, the letter quotes at para. 43 several passages where Ms Thullesen explains why some
inconsistencies in MN's account and the late disclosure of some matters need not impugn its credibility, but
it says (at para. 44):

“It remains that many of your adverse credibility findings exist beyond your late disclosure and the
prevalence of inconsistencies in your account.”

It goes on to refer to the fact that information obtained from the Albanian authorities undermined MN's
account. It then says, at para. 45:

“These discrepancies are material to your narrative, arise outside of your experience of being trafficked
and display internal and external inconsistencies.”

There is similar language at para. 54 of the letter. The two passages quoted are a little opaque, but the
essential point being made appears to be that the discrepancies revealed by the information from the
Albanian authorities cannot be explained by the kind of effects of being trafficked to which Ms Thullesen
refers. The letter goes on to say that her story “contains many implausible elements” and gives as “the
most prominent examples … your retention of your passport, your traffickers giving you money and the
circumstances of your escape”. There is also a reference at para. 54 to MN's account “lacking plausibility
in fundamental aspects … which exist independently of your alleged experiences as trafficking victim”: it is
said that it will be “discussed below” i e in a later section of the letter We deal later with the


-----

Centre and another intervening) [2020] EWCA Civ 1746

discrepancies and implausibilities in MN's account identified by the CA. At this stage we need only say that
this element in the CA's reasoning is plainly legitimate in principle. Ms Thullesen's evidence could not offer
more than a potential explanation of inconsistencies in her account or late disclosure of parts of it. It was
the CA's responsibility to weigh the evidence as a whole, including objective evidence of the kind here
referred to and questions of inherent plausibility. Whether it performed that exercise properly is in truth the
essential question in this appeal, and we return to it later.

180. Third, the letter attaches importance to the fact that Ms Thullesen had said that she could not
“comment on credibility” and had not expressed any opinion on “plausibility” despite having been asked to
do so (see para. 147 above). We do not understand why this is regarded as significant. It was entirely
appropriate for Ms Thullesen not to express a view on the ultimate question of whether MN's account
should be believed. But that does not mean that she was not entitled to give her expert opinion on issues
that were relevant to that question – such as the consistency of MN's account both with her symptoms, its
similarity with the accounts of other Albanian victims of trafficking the known modus operandi of Albanian
traffickers, and her presentation when giving her account; and she did so.

181. Fourth, at paras. 50-52 the letter says that Ms Thullesen had not considered the possibility that there
were other causes for MN's symptoms “such as your clandestine travels across Europe, your immersion
into a culture where you do not speak the language, and desire not to return to Albania”. It is said that that
was contrary to the decision of this Court in _HH (Ethiopia) (paras. 50-52). As to this, we repeat our_
observations in relation to the same point in relation to Dr Johnson's report: the point is in principle valid,
but we are concerned about how it is deployed here and what weight the CA gave to it. Mr Husain
submitted that the CA had no evidential basis for the suggestion that the experiences which it identifies
could account for her symptoms. We see some force in that: this is an area where it is dangerous for lay
people to speculate.

182. The consideration of Ms Thullesen's report concludes (at para. 55) that:

“Because these issues have not been addressed in this report, little weight can be given to the findings in
her report.”

The reference to “these issues … not [having] been addressed” is rather opaque; but it seems that the
reference is to the four points which we have set out.

Overview of the Treatment of the Expert Evidence

183. The effect of the passages which we have reviewed above is that the CA concludes that for all
practical purposes it need not take into account any part of the evidence given by the expert witnesses.
We do not believe that that conclusion was justified. The expert evidence was relevant and of real weight,
and the CA was obliged to take it into account. We have identified a number of flaws in the reasons which
the CA gives for not doing so. The underlying problem is a failure on its part to proceed analytically. What
it needed to do was to identify, if only in summary form, the specific opinions expressed by the witnesses
that were potentially supportive of the truth of MN's account, and to assess in relation to each the weight to
be given to it – which of course involves identifying the points which qualified or undermined their value.
The CA did not adopt such a structured approach but simply listed in relation to each witness a number of
criticisms – some, it has to be said, of a rather formulaic nature – without any assessment of their specific
relevance.

184. However that conclusion is not necessarily fatal to the CA's overall conclusion that MN was not a
victim of trafficking. As noted at para. 179 above, it would in principle have been quite legitimate for it to
give the expert reports full weight but nevertheless conclude that the difficulties with MN's account were
simply so great that they could not be explained by the factors to which the experts draw attention. If on a
fair reading of the letter that was in substance what the CA did – or if it was the only possible conclusion in
any event – its decision should be upheld, despite its having made criticisms of the reports which are illfounded or of marginal significance. We will have to return to that question later.

The CA's Self Directions


-----

Centre and another intervening) [2020] EWCA Civ 1746

185. In a section headed “Caselaw” the decision letter quotes paras. 18 and 19 of the judgment of
Ouseley J in HE (DRC) and repeats what had already been said about the effect of HH (Ethiopia). It also
quotes a passage from a decision of the IAT (Collins J presiding) called Secretary of State for the Home
_Department v AE (Sri Lanka) [2002] UKIAT 05237, which reads:_

“Doctors generally accept the account given by a patient unless there are good reasons for rejecting it or
any material part of it. That is not and is not intended to be a criticism. There is no reason why a doctor
should necessarily probe the history or approach his patient's account in a spirit of scepticism. But this
does mean that the doctor's conclusions will sometimes be seen to be flawed if it transpires that the
account is not credible.”

We were not in fact referred to AE (Sri Lanka) in the course of submissions, but it does not say anything
inconsistent with our summary of the relevant law at para. 121 above.

186. After referring briefly to the reasonable grounds decision and summarising the material on which the
CA was proceeding, the letter identifies the parts of the Guidance that were taken into account when
assessing credibility. Under the heading “Consistency”, a passage is quoted which reads:

“It is also reasonable to assume that a potential victim who has experienced an event will be able to
recount the central elements in a broadly consistent manner. A potential victim's inability to remain
consistent through their written and oral accounts of past and current events may lead you to disbelieve
their claim …

When you assess the credibility of a claim, there may be mitigating reasons why a potential victim of
trafficking is incoherent, inconsistent or delays giving details of material facts. You must take these reasons
into account when considering the credibility of a claim.”

Under the heading “Difficulty recalling facts”, the passage quoted reads:

“As a result of trauma, victims in some cases might not be able to recall concrete dates and facts and in
some cases their initial account might contradict their later statement. This is often connected to their
traumatic experience. However, the need to be sensitive does not remove the need to assess all
information critically and objectively when you consider the credibility of a case.”

Those are important passages as far as they go, but they are less directly in point in a case of this kind
than the passage which we quote at para. 125 above, to which no reference is made.

The Difficulties with MN's Account

187. At paras. 62-134 the decision letter identifies a large number of what we will describe compendiously
as “difficulties” with MN's claim that she was a victim of trafficking – comprising inconsistencies both
between and within the various versions of her account, their inconsistency with the information supplied
by the Albanian government, and what is said to be the implausibility of parts of her story. On the basis of
those difficulties the CA declines to accept the key elements in her account. The letter considers the
issues under a series of headings, which we will also use. Again, it will be convenient if we make some
observations as we go. We are very conscious that the task of fact-finding is not for this Court, but it is
necessary for us to consider whether the reasons given by the CA are capable of justifying the conclusions
which it draws from them.

188. We would observe that there are in fact some apparent difficulties with MN's account to which the CA
does not refer; but our focus must be on those on which it relied in reaching its decision.

_Albania – Leaving with Ardian_

189. The CA noted three main inconsistencies in this part of MN's account, or accounts, though, as will
appear, it only directly relied on two of them.

190. First, MN gave inconsistent accounts about her parents' knowledge of her relationship with Ardian
and their plan to go to Italy.  In her screening interview she is recorded as saying that her father wanted


-----

Centre and another intervening) [2020] EWCA Civ 1746

Ardian to ask him for permission to marry her, but that Ardian said he was not ready to get engaged and
wanted instead for them both to go to Italy and earn some money. The immigration officer then asked “So
your parents were aware you were moving to Italy with Ardian?” and MN is recorded as answering:

“Yes. They were aware that Ardian was not ready to get engaged and settle down, and that we would go
to Italy, work and get more money.”

Both in the accounts which she gave to Dr Johnson and Ms Thullesen and in her first witness statement
MN gives a different account. She says that she had told her parents that she and Ardian were thinking of
going to Italy but her father had made it clear that he was implacably opposed to her doing so; and that
accordingly when they eventually decided to go she told her mother but not her father.

191. In her first witness statement (para. 13) MN accepts that the account there given is contrary to her
answer in the screening interview, and she says that her answer in the interview must have been wrongly
recorded; and she repeats that in her third witness statement. The CA did not accept that explanation. It
noted at para. 76 of the letter that she had had ample opportunity to correct the error since then, “not least
in your witness statements or during the Asylum Appeal system”. As regards the witness statements, that
is simply wrong: as we have said, the alleged error was corrected in her first witness statement. As
regards the asylum appeal, the weight of the point depends on the extent to which the discrepancy was
relied on in the FTT: that was not a point explored before us, but it seems unlikely that it was, since it is not
referred to in the FTT's decision. The decision-maker also refers to the fact that at para. 35 of the FTT's
decision the judge “addressed your repeated assertions of erroneous interpretation” and said that he could
not accept them, describing her answers in interview as “recorded repeatedly and very clearly”. This,
however, refers to a particular set of answers in a different interview (being her interview at Stansted in
November 2012), and the FTT does not make any more general criticism of MN for repeatedly resorting to
allegations of having been wrongly interpreted. That does not mean that such a criticism may not be
available, and it is also obviously material that the FTT rejected MN's account overall; but what troubles us
about the CA's reasoning at this point is that it smacks of the deployment of a stock answer to her
explanation without attempting to see whether it is actually applicable to the specific point.

192. Standing back from the details of the decision-maker's reasoning, Mr Husain contends that there
could easily have been a confusion in the screening interview between MN saying that she had told her
family that she and Ardian were thinking of going to Italy and her saying that she had not told her father
when they actually went because she knew he disapproved. That does not seem to us implausible.

193. Secondly, there is a serious difficulty about what MN said in her different accounts about the passport
on which she travelled to Italy. The essential points are as follows:

(1) In her first witness statement she said that she flew to Italy on an Albanian passport for which she had
applied about a month previously. She said that Ardian told her that he had arranged that the passport
would not be stamped on exit, but that it was stamped on their arrival in Bari. The clear implication is that,
as one would expect, she had the passport in her possession throughout her journey (indeed she
described the bag in which she kept it); and in fact she had said so in terms in her asylum interview. It was
her explicit evidence that she retained this passport throughout the time that she was imprisoned in the
brothel and that she took it with her when she escaped; again, she had said the same in her asylum
interview.

(2) As already noted, the Home Office subsequently ascertained from the Albanian authorities that no
passport had been issued to her until June 2012.

(3) The CA raised this point in its questionnaire. In her third witness statement MN said that Ardian made
the application for a passport on her behalf and that she had no involvement with the application. She said
that when Ardian came back with a passport for her

“he showed it to me and then took it back from me. I didn't really have time to look at it properly; I only
remember looking at my photograph and name”.


-----

Centre and another intervening) [2020] EWCA Civ 1746

She says nothing about how or why Ardian in due course gave it back to her, as on her account he must
have eventually have done before he abandoned her. She said that she had no way of telling whether the
passport was genuine or not, as Ardian did everything and “he held onto the passport most of the time”.
The clear implication of the third witness statement is that Ardian obtained a false passport for her, which is
why the Albanian authorities have no record of her being issued with one. Mr Husain referred us to the UK
Border Agency Country of Origin Information Report for Albania dated 30 March 2012, which states that
women are regularly trafficked out of Albania using false documentation.

(4) She also said that her solicitor had suggested that the reason why there might not be a record of her
travel to Italy in 2010 is that at that time not all Albanian passports were biometric. The CA records that
that is inconsistent with the evidence of the Albanian authorities.

194. The CA regarded the evidence of the Albanian authorities as conclusive that MN had no passport in
December 2010 and that accordingly she could not have travelled to Italy with Ardian as described. The
soundness of that conclusion depends on whether she could have travelled on a false passport. As to that,
the letter makes no reference to the Country of Origin report, but we are prepared to assume that the
decision-maker was aware that the use of false passports was common in the case of trafficking from
Albania. It appears that the CA did not accept that MN had travelled on such a passport, but it is not
entirely clear what its reasons were. The letter does not, as it might have done, take any point on the late
emergence of the account given by MN of the passport having been obtained by Ardian and kept by him
for most of the journey. It does, however, observe that her account of having her passport invalidated on
her return to Albania in 2012 following her escape was inconsistent with it being false. The point is not fully
spelt out, but we take it to be that if the passport was false the Albanian authorities would have invalidated
it on that basis, rather than on the basis that she had outstayed her Italian visa (which in any event it is
hard to see why the _Albanian authorities would be worried about); they might indeed even have made_
difficulties about allowing her into the country. That is a reasonable point, and we are not the fact-finders.
But we are not sure that it is conclusive by itself. It is not possible to know for sure how the Albanian
authorities would have behaved if MN presented what must, on her account as it now is, have been a false
passport: we do not know if it was obviously false, though we do know (if her story is true) that they
invalidated it, albeit giving (at least as she recounts it) a puzzling reason for doing so.

195. Thirdly, MN gave inconsistent accounts about how she travelled to Italy in December 2010. In her
asylum interview she said that she travelled by plane to Turin with Ardian on a ticket bought by him. In her
first witness statement she said they took a ferry from Durres to Bari and then travelled by car to Turin.
However, this striking discrepancy was not raised in the CA's questionnaire, so we do not know how she
might account for it.  Perhaps for that reason, although it is noted by CA in the context of a different point,
it is not explicitly relied on as an inconsistency which damages her credibility.

_Italy - Exploitation_

196. The letter refers here to the same discrepancy on which the CA relied in connection with Ms
Thullesen's report: see para. 178 (1) above. For the reasons there given, we do not believe that there is
any real discrepancy. However, we should refer to a further point made at para. 92 of the letter. In her
third witness statement, as part of her answer to the CA's question on this aspect, MN said that she had
used the term “everyone” in a “generic” sense, by which we understand her to mean not literally.  The CA
does not accept that, saying that “everyone” was “an unmistakably categorical term”. With respect, that
answer seems to us out of touch with ordinary colloquial English, and suggests a hyper-critical mindset on
the part of the decision-maker.27

197. However, there is another aspect which we should mention. In her answer to the next question but
one in the asylum interview (Q63), MN appears to say that Ardian was present when Luli attacked her.
That is inconsistent with what she told Ms Thullesen, and also with the account in her first witness
statement, which was that Ardian had left, ostensibly to buy some food, and never came back. That is a
much more substantial discrepancy than the one actually identified by the CA. Although she was not
directly asked about it in the questionnaire, after answering the CA's (different) question she took the


-----

Centre and another intervening) [2020] EWCA Civ 1746

opportunity to say that her answer at Q63 had been “wrongly recorded”. The CA rejects that explanation,
observing (again) that MN had not sought to correct the record during the appeal process. That is correct,
but (again) it does not appear that any point arose about this in the FTT. The CA refers to the FTT's
comment to which we refer at para. 191 above; but our comments there apply equally.

198. The CA's principal point about MN's account of being held against her will in a brothel in Turin for
over eighteen months was that it was implausible that, despite the extensive measures of control which
she described and her saying that Luli had searched her bag on the first day and taken her phone, he did
not take her passport and she was able throughout the period of her imprisonment to retain it and sufficient
money to pay for a flight from Italy to Albania. The FTT had made the same point. The CA also noted that
it was all the more surprising that she should have had kept possession of her passport if, as she said in
her third witness statement, Ardian had kept control of it on their journey from Albania: why would he have
given it back to her?

199. Mr Husain submitted that the CA's description that those features of her account were implausible
was not open to it. We do not agree. In our view it was plainly open to it to treat this as a real difficulty
about her account, as indeed the FTT had done. “Implausible” is not the same as “impossible”, and the
unlikelihood of this particular feature of MN's account might not by itself be a sufficient reason for rejecting
it, but it was a legitimate factor in the CA's overall assessment.

_Italy - Escape_

200. The CA noted both inconsistency and implausibility in MN's account of the circumstances of her
escape from the brothel and her actions thereafter.

201. So far as inconsistencies are concerned, it relied on the point about whether the police questioned all
the women which we have already considered in relation to the evidence of Ms Thullesen. We need not
repeat what we have said at para. 178 (2) above. But there is a further aspect. The CA raised this
discrepancy in the questionnaire. In the course of MN's answer in her third witness statement she refers to
her answer to Q102 in the asylum interview, where she is recorded as saying that she saw five or six
police, “who were going to the big rooms and the reception”. She says that she hadn't said that the police
“just went to the big rooms”, but that “they were somewhere at the reception … and then spread out” and
that her answer must have been misrecorded or misunderstood by the interpreter. We are bound to say
that we cannot see how that very minor difference matters: it is certainly not what the CA was asking
about. But we mention it because the CA letter says, again, that “as previously stated, you did not raise
erroneous interpretation during the asylum process” (para. 93). Read literally, this does not make sense
because the alleged error arose in recording of the asylum interview itself; but we assume that what the CA
means is that MN did not raise it in the FTT. There is, however, no sign that any point was taken about
Q102 during the FTT proceedings; and it seems that the decision-maker has, again, raised this objection
mechanistically and without any consideration of its applicability to the particular point being made.

202. As for implausibility, the CA makes three points.

203. First, the CA regarded it as inherently implausible that if the police were raiding the house because it
was a brothel they would simply have let MN – and indeed, as she appeared to have said in one of her
answers in the asylum interview, the other women – leave without questioning them: they were likely to
need support, and they were also potential witnesses in any prosecution. The letter makes the point that
many Italian law enforcement officers are specially trained in trafficking situations. The FTT had made
essentially the same point. Mr Husain submitted that that finding was not open to the CA. As to the
likelihood of MN being simply allowed to leave, the decision-maker had no way of knowing how the Italian
police would behave on such an occasion: he was simply making an assumption. He referred us to para.
30 of the judgment of Neuberger LJ in _HK_ (see para. 128 above), where he endorsed Lord Brodie's
warning against finding an asylum-seeker's account to be implausible on the basis of speculation or in
disregard of his or her social or cultural background. We do not accept that submission. In our view it was


-----

Centre and another intervening) [2020] EWCA Civ 1746

entirely reasonable of the CA to find this aspect of MN's account surprising – though, again, it does not
follow that this was by itself a sufficient reason to reject her entire story.

204. The second respect in which the CA found MN's account implausible was that she did not seek
support either from the Italian authorities (most obviously from the police who were conducting the raid) or
from her sister, who on her account lived in Turin, but instead immediately returned to Albania, where she
was at obvious risk of falling back into the hands of her traffickers. The same point was made by the FTT.

205. As regards her not speaking to the Italian police, MN said in her first witness statement that she
thought the police in Italy would be the same as in Albania, and that Ardian had friends in the Albanian
police. She explained that even now that she is in the UK she is scared of any dealings with the police.
The CA does not refer to that evidence. However, it does refer to a passage in her third witness statement,
where she says:

“I did not ask the Italian authorities for help because I was very scared that I would be passed on to the
Albanian police and I knew Ardian had connections with the Albanian police. Also, I did not speak Italian,
so I would not have been able to communicate with them. I just wanted to get away from the place where I
had been exploited as soon as possible and going to the police would not have helped at all.”

The CA did not accept that explanation. Its reasoning is not very clearly expressed, but the essence is that
she must have appreciated that the Italian police would be on her side because she had just seen them
trying to arrest her traffickers; and also that, whatever her concerns about the Italian authorities, the risks of
returning directly to Albania, where she risked harm not only from Ardian, but from her father, who she said
she feared might kill her or force into marriage, were greater.

206. As regards her failure to contact her sister, MN had initially addressed this in her first witness
statement, where she said:

“I have been asked why I didn't contact my sister at this point, who I knew to be in Turin. I wasn't sure if
she would be in a position to help or support me. I knew that the decision wouldn't be up to her, but up to
her husband, and I wasn't sure how she would feel about my decision to leave Albania with Ardian and
whether he would allow her to assist me or not.”

The CA rejects this explanation on the basis that it was inconsistent of MN not to contact her sister
because she was uncertain if she could help when she had also said in the same witness statement that
when she got a taxi to the airport she was “afraid that the taxi driver might try to exploit me again”. We are
bound to say that this seems an extraordinarily contrived inconsistency. MN addressed the question again
in her third witness statement, where she said:

“I did not ask my sister for help when I escaped the house in Italy because the last time I had probably
been in touch with her was when she got married. After this, I did not speak with her very often, only from
time to time. I did not even know where in Italy she lived, not even the region she lived in. I also did not
have her telephone number and her contact details. She was the one who would normally call my father
from Italy and everyone else spoke to her. I was also worried that I could create tension in her own married
family life or that she would inform my family. I was in a terrible state and felt I had been ruined as a person
and destroyed so I did not want to create further problems for my sister.”

The CA does not set out the whole of that answer but it does quote her statements that she had not been
in touch with her sister for a long time “and did not even know where in Italy she lived” and points out that
the latter statement is wholly inconsistent with her first statement and with numerous other statements to
the effect that her sister lived in Turin. That inconsistency we accept is obvious and very puzzling.

207. Generally as regards the implausibility of MN not seeking help, whether from the police or from her
sister, and flying straight back to Albania, Mr Husain relied again on para. 30 of the judgment of Neuberger
LJ in HK. He submitted that the CA could not draw any safe conclusions about how a young woman would
react in the situation that MN was in if her account was true. It was entirely plausible that she would
instinctively want to get away from her place of captivity as soon as possible and return to her home


-----

Centre and another intervening) [2020] EWCA Civ 1746

country, whatever the risks: it should be noted that she did not go back to her home town or her immediate
family but went instead to her uncle in Tirana. What she said in the third witness statement about being “in
a terrible state” and feeling “ruined” is consistent with the expert evidence of Ms Thullesen, and indeed with
the Guidance. There is obvious force in those points.

208. The third area of implausibility relied on in the decision letter relates to how MN was able to fly back
to Albania following her escape. She could only have flown on the passport which she said that she
acquired in November 2010 and which she had retained throughout her captivity, but the evidence from the
Albanian authorities established that no passport had been issued to her. However, that brings us back to
the question whether she may have had a false passport: see para. 193 above.

_Albania – Threats against MN's Family_

209. As noted above, it was MN's evidence that following her return to Albania both Ardian and Luli visited
her family to try to find out where she was.

210. As regards Ardian's visit, MN said in her screening interview that he visited them in June 2012. In her
asylum interview she said that it was in August. In her short witness statement in the FTT she said that the
correct date was August and that she was “confused at screening which was done quickly”. In her first
witness statement she said that she could not now remember when Ardian's visit had been. The CA says
at para. 110 that it cannot accept MN's explanation in her FTT witness statement for the discrepancy
between June and August, because there had been no fewer than 26 questions in the basis of claim
section of the screening interview and that she therefore had the opportunity “to coherently relay this
information”. We cannot regard that as a satisfactory reason: the fact that there were 26 questions
(covering the entirety of her account) does not mean that she had the opportunity to avoid all errors. In any
event we are bound to say that an error of dates of this kind does not seem to us to be of real significance
in an assessment of MN's credibility.

211. As regards Luli's visit, in which MN had said that he beat her father up, the CA referred to a hospital
record produced by her which showed her father having been admitted to hospital for two weeks in
October 2012 with a broken arm. It quotes at para. 111 from the decision of the FTT, in which the
document was said not to be probative of her account because it did not refer to how the injury was
sustained, and observes at para. 112 that “consequently this document does not add weight to your claim”.

212. Para. 113 begins “Whilst discussing why you felt unable to relocate to another area of Albania, you
responded:” – but nothing follows the colon. This is not a unique instance of careless drafting or
presentation in the letter28. Of course errors of this kind do not necessarily mean that the decision-maker
has not thought carefully about the substance, but they can be a pointer in that direction.

213. The conclusion, at para. 114, is:

“For the reasons given above, it is not accepted that Ardian and Luli threatened your family in Albania.”

We do not believe that the “reasons given above” are capable of supporting that conclusion. The fact that
MN first said that Ardian's visit was in June and later that it was in August is not a particularly significant
discrepancy. And the fact that the hospital record did not state the cause of her father's injury only means
that it is not positively probative: it does not undermine her account. We do not wish to be misunderstood.
If there are good grounds for disbelieving MN's core account, then it will no doubt be legitimate to
disbelieve this part of it as well; but that is not the reasoning of the CA as regards this episode.

_Travelling to the UK_

214. The CA identifies a number of difficulties about MN's evidence about her first attempt to enter the UK
on 3 November 2012. In order to explain them it is necessary to explain the history of her accounts in a
little detail.

215. First, when she was interviewed at Stansted she said that she had left Albania by ferry to Bari on 19
October using her Albanian passport She did not give many details about what had happened in the


-----

Centre and another intervening) [2020] EWCA Civ 1746

intervening fortnight, and those that she did give are not entirely easy to understand from the record of the
interview. However, she said that she had gone by train to a town in France whose name she could not
recall, but had stayed only for one day (including staying overnight in a hotel) and that at the station a man
had given her a false Italian ID and said that he would keep her passport. She was asked why she went to
France and said that it was because she could not find work. At the start of the interview she had been
asked how she acquired the false Italian ID. She said that she did so after a chance meeting with some
Albanians in a café in an Italian town recorded as “Alexandra” (presumably Alessandria), who had advised
her to try to find work in the UK and put her in touch with someone who sold her the ID card for €200.
There are thus two different accounts of how she acquired her Italian ID (though they are ostensibly
reconciled in the fuller account that she gave later – see para. 217 below). At the end of the interview she
was asked “Anything to add or tell me?”. The reply reads:

“I came here for work, better life and not commit any crimes and not involved in trafficking”29.

216. Second, in her asylum interview in March 2013 four months later MN was asked when she left
Albania. She said that she flew from Albania to Turin on 2 November 2012, spent the night at the airport
and flew on to Stansted the following day. One of the questions she was asked was why she didn't claim
asylum at Stansted when she came to the UK in November. She replied:

“Because they didn't ask me whether I wanted to claim asylum or whether I feared for my life. I was still
worried at that time.”

It was pointed out to her that she had been at Stansted for some time and had had plenty of opportunity to
tell officials that she thought her life was in danger. She said again that the interview had only asked her
about how she came into the country and her ID card. She was also asked why she had chosen to come
to the UK and not another country. She said that she knew that the UK was the safest place: Ardian and
Luli might have friends in other countries, and other countries would not support her.

217. Third, in her first witness statement she repeats the account given in her asylum interview about how
she came to the UK but with a lot more detail. She says that she was met in Turin by the agent, who gave
her the false Italian ID on which she flew to the UK. She says that she preferred to stay in the airport,
spending much of the time in the toilets, because it felt familiar from the occasion of her escape earlier in
the year. She says that she lost her Albanian passport there, but she does not say how. She also
comments on the record of her interview at Stansted. She says:

“I confirm that I did not tell the truth at this interview. I was very frightened. I thought something bad would
happen. The police were there. I was being interviewed by a man with a male interpreter on the phone. I
just didn't feel that I could disclose my true circumstances. I just made stuff up and I cannot even
remember what it was now that I made up when questioned. Just whatever came into my head on the
spur of the moment ... In my ... screening interview, I said that the interpreter at Stansted Airport was
aggressive towards me. This is true. He was telling me to stop crying and pull myself together and just
answer the questions, because he was finding it difficult to understand because of the way I was talking
and because I was crying so much.”

She made a similar criticism of the interpreter in her third witness statement.

218. Fourth, in her second witness statement she explains how while giving her history to Ms Thullesen
she had suddenly remembered a part of the story which she had omitted from her first witness statement
and which she immediately reported to her solicitor. She explains that about three or four weeks before
her unsuccessful attempt to enter the UK in November 2012 she had attempted to fly to the UK from
France but had been stopped at the airport. In summary her account was that she left Albania with an
agent by ferry to Bari and then took a train to a city in France whose name she did not know. She was
given a false Italian ID. The agent took her to the airport for a flight to the UK, but the false ID was
detected and she was not allowed to fly. She contacted the agent again, who took her to Turin, where she
stayed for “a few days” before being given a new false Italian ID, which is the one that she used to fly to
Stansted. That account is broadly consistent, though not in all respects (see below), with what MN said


-----

Centre and another intervening) [2020] EWCA Civ 1746

when interviewed at Stansted (see above), but it is wholly inconsistent with what she said in her asylum
interview and in her first witness statement, where she says, with some circumstantiality, that she had
flown from Tirana to Turin the previous day. In her second witness statement MN explains her failure to
recall this episode earlier by saying that previous solicitors had told her not to mention (presumably, though
she does not say this, at the asylum interview) that she had been in France, because if she did she might
be returned there, and that that had driven it to the back of her mind.

219. In the questionnaire MN was asked about the discrepancies in her accounts of how she no longer
had her Albanian passport: at Stansted she said that she had given it to the man in France who had given
her her false Italian ID, whereas in her first witness statement she said she lost it at Turin airport. In her
third witness statement she says: “I remember losing my passport at the airport, but I do not remember
what airport exactly”. (That only reconciles the inconsistency if “lose” is treated as covering “parting with”.)

220. The information obtained by the Home Office from the Albanian authorities in mid-2017 showed that
MN had indeed left Albania by ferry on 19 October 2012 (and had not re-entered since then). It was put to
her in the questionnaire that that was contrary to what she had said in her first witness statement. In her
third witness statement she acknowledged that, but she said that she had already corrected the account in
her second witness statement. She accepted, however, that that correction was itself not fully accurate
because it had described the episode as occurring “around 3-4 weeks before flying from Tirana to Turin”,
whereas it was clear from the account overall that she had never flown from Tirana to Turin but had taken
the ferry to Italy and remained there, or in France, until she flew to Stansted. She put the mistake down to
“a misunderstanding or … interpreting error”. While some scepticism about explanations of that kind may
be justified, on this particular occasion there must indeed have been a slip in the preparation of the second
witness statement because the whole story told in it is inconsistent with her having flown to Turin the day
before flying on to England.

221. The CA makes a number of points about those accounts. In summary:

(1) At paras. 115-117 it sets out two of the principal inconsistencies – about how and when MN travelled
from Albania to Italy, and about how she lost her passport. As regards the first, it notes the explanation in
the third witness statement that the mistake in the second witness statement was the result of
misinterpretation, observing that that is an explanation that she has used on several other occasions: as to
this, see our observation at para. 219 above. As regards the second, it points out that losing her passport
at an airport is very different from handing it to a stranger for safekeeping and that if she had simply
forgotten at which airport she had lost it she could have said so.

(2) At paras. 119-122 it rejects MN's statement that she did not have the opportunity to explain in the
Stansted interview what she now says was her reason for coming to the UK, referring to the final question
and to her response that she had come for work “and not involved in trafficking”.

(3) It does not accept that if she felt that it was unsafe for her to stay in Italy she would not have told the
truth to the immigration officers rather than being returned to Italy or Albania.

(4) It does not accept that she would not have claimed asylum in France or Italy if her account was true.

(5) It notes that in the FTT MN had apparently not accepted that she had told the officers at Stansted that
she was coming to the UK to work and had blamed the statements to that effect in the record on
misunderstandings by the interpreter; and that that had been rejected by the Judge, who had described it
as eminently likely that she was coming for work because she had an Italian ID card. The letter accepts
that she has since then submitted “your witness statement” – the reference is apparently to the first witness
statement – but says that the explanation given in it is not compelling, because MN has so often attributed
inconsistencies and errors to mistakes by interpreters. We must observe that, while that may be a fair
comment generally30, it is not an answer to MN's explanation in her first witness statement for having told
the interviewer at Stansted that she had come to the UK for work. She does not say that she was
misinterpreted but that she was, in short, in such a state that she said the first thing that came into her
head: see para. 217 above.


-----

Centre and another intervening) [2020] EWCA Civ 1746

222. This section of the letter concludes, at para. 129:

“For the reasons given above, your journey to the UK and reasons for seeking entry are not accepted.”

That is over-compressed. As regards “your journey to the UK”, plainly the CA accepted that MN had
travelled to the UK on 3 November 2012. We think that it must, too, have accepted her account in her
second witness statement (as clarified in her third) of having left Albania by ferry on 19 October, which
accords not only with what she said in her Stansted interview, which was virtually contemporaneous, but
also with what the Home Office had been told by the Albanian authorities. It is not, therefore, clear what
else about the “journey” is not accepted. However, what matters more is the rejection of “your reasons for
seeking entry”. What the CA clearly means is that the reasons that MN gave for seeking entry – i.e. to find
work – were true, and that her subsequent account of having come to the UK to escape her traffickers, but
feeling unable to give that reason when interviewed, is untrue.

223. Mr Husain in his skeleton argument addressed no submissions to this part of the CA's reasoning.

_Return to Albania_

224. MN said in her first witness statement that following her removal from the UK to Italy on 4 November
2012 she was returned by the Italian authorities to Albania the same day. Although she had no passport
the Italian authorities gave her some “paperwork” and that was sufficient for the authorities on her arrival in
Tirana.

225. The Home Office enquiries established that the Albanian authorities had no record of MN returning to
Albania after leaving on 19 October 2012. MN was asked about this in her questionnaire. Her response in
her third witness statement was essentially the same as she had given in her first statement, but the
implication appears to be that the reason why there was no record might be that she was not travelling on
her passport.

226. The CA says at para. 133 of the letter that since she had been returned from Italy officially “it is
reasonable to expect there to be some record of this movement” and that accordingly it was not accepted
that she had returned to Albania after being removed from the UK in November 2012.

227. Mr Husain did not in his skeleton argument address any submissions to this part of the CA's
reasoning. However, if its conclusion was correct it would mean that when MN was returned to Milan
(apparently without a passport) the Italian authorities either simply allowed her to pass through immigration
controls or made a positive decision not to return her to Albania. We are bound to say that that seems
rather less plausible than that the reason why the Albanian authorities have no record of her return – or
none that turned up on the search done at the request of the Home Office – is as suggested by MN. But
the issue is only significant to the extent that it bears on the credibility of MN's core account of being a
victim of trafficking, as to which there are clearly points which are more directly relevant.

_Overview_

228. It will be clear from the foregoing that there are indeed a large number of inconsistencies between,
and to a lesser extent within, MN's accounts; and that some at least of them are substantial. However, not
all of those relied on by the CA are significant, and the reasons given in the letter for rejecting MN's
explanation of those that may be significant are not all convincing: some indeed are plainly wrong. The CA
also found important aspects of her account to be implausible. We agree that that is a legitimate comment
about some of them, but not all.

The FTT Decision

229. At paras. 135-138 the decision letter considers the decision of the FTT on MN's asylum claim. It is
noted that her claim to be a victim of trafficking relies on the same “narrative and records” and says (at
para. 136) that accordingly the FTT's findings “have been considered in the round with the rest of your
evidence.”


-----

Centre and another intervening) [2020] EWCA Civ 1746

230. Mr Husain submitted that the CA was wrong to “essentially adopt” the findings of the FTT when the
FTT did not have the expert evidence of Ms Rees, Dr Johnson or Ms Thullesen before it and where it had
indeed specifically referred to the fact that no medical evidence had been adduced. We do not believe that
that is a fair description of the CA's approach. As it said, it considered the FTT's findings “in the round with
the rest of your evidence”. We can see nothing wrong in it doing so. The FTT had had the advantage,
which the CA had not, of hearing MN give evidence and being questioned on her account. The issues
canvassed before it traversed the same ground as those with which the CA was concerned. It would be
artificial and unsatisfactory if it was not entitled to take into account both the FTT's assessment of MN as a
witness and those parts of its reasoning that were applicable to the material before it. It was of course
important also that the CA should recognise that it had the advantage not only of expert evidence of a kind
which the FTT did not have but of much fuller and more circumstantial witness statements; and that if the
FTT had had the benefit of those materials its assessment, even of MN's demeanour as a witness, might
have been different. But the CA did indeed treat the primary material before it as the focus of its
consideration and referred only to the decisions of the FTT as one part of that material.

“Mitigating Circumstances”

231. Para. 139 of the decision letter, under the heading “Mitigating circumstances”, says that

“consideration has been given as to whether there are any mitigating circumstances in relation to your
account, namely expert medical reports”

and that the reports had been considered at the start of the decision letter, before making adverse
credibility findings, “along with all other available evidence”.

232. We have already observed that the description of the expert evidence as “mitigating circumstances”
is unfortunate, and the whole passage is rather clumsily expressed. The purpose is no doubt to make
clear that the CA had not fallen into the _Mibanga error – cf. para. 164 above; but we return below to_
whether it had in truth done so.

“Consideration”

233. This is the CA's conclusion section. The effect of the foregoing consideration is analysed at paras.
146-153 by reference to the three components in the definition of human trafficking in article 4 (a) of ECAT.
The CA formally concludes that MN had not travelled to Italy in the way she claimed; that she had not been
deceived into working as a prostitute; and that she had not been sexually exploited.

THE JUDGE'S DECISION

234. There were before Farbey J three grounds of challenge to the CA's decision. The first concerned the
standard of proof, with which we have already dealt. The other two she summarised at para. 14 of her
judgment as challenges to “the general assessment of the claimant's credibility” and to “the CA's approach
to the independent reports submitted in support of the trafficking claim”: permission in relation to these had
been refused on the papers, but MN's renewed application had been directed to be heard on a rolled-up
basis alongside the first ground.

235. In support of the latter two challenges Ms Luh developed her case in detail both in her very full
skeleton argument and supplementary skeleton argument and in her oral submissions. We were told that
Ms Luh spent a considerable part of her oral submissions going in detail through the evidence relating to
the supposed inconsistencies (supported by a schedule of references to the relevant evidence) and the
reports.

236. Farbey J considered the credibility challenge at paras. 71-73 of her judgment. At para. 71 she said:

“While I am grateful for the schedule, [Ms Luh] has in my judgment put forward a series of essentially
factual challenges which are inapt for the Court's consideration in judicial review proceedings. I do not
propose to go through her schedule in detail, which in truth highlights the very many areas of the claimant's
testimony which give rise to difficulties. Two examples will suffice.”


-----

Centre and another intervening) [2020] EWCA Civ 1746

She then went on to give two examples of inconsistencies in MN's evidence which she held were plainly
capable of undermining her credibility” these were the discrepancy about whether she had flown to Italy in
November 2012 or travelled by ferry and the “talking to everyone” issue. She concluded, at para. 73:

“The accumulation of inconsistencies – across many different elements of the trafficking claim – is capable
in my judgment of undermining the claimant's credibility. Absent irrationality or some other public law error
by the CA, it is not the role of this Court to conclude that the difficulties are merely tensions on the margins.
The CA was well within its discretion to regard her various accounts as inconsistent and implausible in
material respects.”

237. Farbey J dealt with the challenge to the way in which the CA had approached the reports in para. 74,
which reads:

“Finally, Ms Luh contended that the CA was irrational or unreasonable in concluding that nothing in the
medical and other expert evidence was capable of mitigating the weight to be placed on the discrepancies
in the claimant's account. I do not agree. The Secretary of State accepts Ms Thullesen's expertise but her
report cannot be a trump card. The Secretary of State (delegating his function to the CA) is the primary
decision-maker whose function is to determine whether a person is a victim of trafficking under ECAT. The
task of identifying victims of trafficking is an executive task and is not a matter of expert opinion. The
claimant cannot show that the CA's treatment of Ms Thullesen's report was erroneous in point of law. Nor
is there any error of law in the CA's treatment of Dr Johnson's or Ms Rees's reports.”

THE GROUNDS OF APPEAL

238. Ground 1 claims that the CA applied the wrong standard of proof: we have already addressed that.
The remaining grounds of appeal are pleaded as follows:

**“Ground 2: Error in failing to apply anxious scrutiny to the conclusive grounds decision**

The Judge erred failing to apply anxious scrutiny to the conclusive ground decision: see R (SL) (St Lucia v
_SSHD [2015] EWHC 2705 (Admin at [98]-[104]). Her approach was suggestive of the application of a_
conventional Wednesbury analysis … .

**Ground 3: Misdirection as to the approach to credibility**

In upholding the Respondent's credibility findings (set out at [8]-[13]), the Judge committed the same errors
of law as the Respondent in her conclusions at [69]-[73].

[1]  In overemphasising the significance of personal credibility to the determination of victim status, in
equating inconsistency with incredibility and in failing to address the materiality of the apparent
inconsistency to the critical question, namely whether the Appellant was trafficked for sexual exploitation:
see MA (Somalia) v SSHD _[2010] UKSC 49_ _[[2011] 2 All ER 65 per Sir John Dyson at [31] & [33];](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52HJ-R1C1-DYBP-M495-00000-00&context=1519360)_

[2]  In failing to take a holistic approach and assessing all the evidence in the round as required by R (AA)
_(Iraq) v SSHD_ _[2012] EWCA Civ 23 and R (Karanakaran) v SSHD_ _[[2000] 3 All ER 449;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-613F-00000-00&context=1519360)_

[3]  In failing to interfere with the Respondent's approach which was to rely on the FTT's findings as
effectively determinative of the Appellant's credibility, and in failing to address her mind to whether, with the
benefit of the significant new expert evidence, the FTT might now come to a different view as to the
Appellant's credibility: see by analogy WM (DRC) v SSHD _[2006] EWCA Civ 1495 at [11]._

**Ground 4: Misdirection in law as to expert evidence**

Marginalising the Respondent's treatment of expert evidence …, the Judge erred in law in:

[1] marginalising the expert reports on the basis that they depended upon accepting the Appellant's
account when experts are not only entitled but expected to express their opinion on the degree to which
their findings support an individual's narrative: R (AM) v SSHD _[2012] EWCA Civ 521 and SS (Sri Lanka) v_
_SSHD_ _[2012] EWCA Civ 945;_


-----

Centre and another intervening) [2020] EWCA Civ 1746

[2] thereby failing to acknowledge the potential of the expert evidence to undermine the Respondent's
reliance on the First-Tier Tribunal determination as effectively settling the question of credibility (the FTT
did not have the benefit of expert evidence): see by analogy, WM (DRC) v SSHD _[2006] EWCA Civ 1496.”_

239. We will consider ground 2 first, but we will then take grounds 3 and 4 together.

GROUND 2: ANXIOUS SCRUTINY

240. MN's case is essentially that the approach taken by the Judge in paras. 71-74 of her judgment was
simply too broad-brush given the detailed challenge raised by the two grounds in question and did not
involve the kind of “heightened” or “rigorous” scrutiny appropriate to the judicial review of a decision of this
character31.

241. We do not believe that this ground can be dispositive of the appeal. The ultimate question, which is
squarely raised by grounds 3 and 4 is whether the CA did in fact err in the respects complained of. If we
hold that it did, ground 2 is redundant. If we hold, ourselves applying what we believe to be the correct
level of scrutiny, that it did not, any failure to do so on the part of the Judge goes nowhere. Nevertheless,
since it raises a question on which some guidance from this Court may be useful, we will address it.

242. There was no real dispute before us as to the nature of the scrutiny required in a case of this kind.
Although, strictly, we are concerned only with the court's scrutiny of the original decision, the starting-point
must be the standard of reasoning required in the decision itself. As to that, it is clear that a high quality of
reasoning is required in a conclusive grounds decision, which engages fully with the case advanced by the
putative victim of trafficking. Sir James Eadie and Mr Irwin acknowledged that expressly in their skeleton
argument, citing the judgments of Dove J in R (FK) v Secretary of State for the Home Department _[2016]_
_EWHC 56 (Admin) (see para. 27) and of this Court in R (YH) v Secretary of State for the Home Department_

_[[2010] EWCA Civ 116, [2010] 4 All ER 448, where Carnwath LJ refers to the “need for decisions to show](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
by their reasoning that every factor which tells in favour of the applicant has been properly taken into
account” (see para. 24 of his judgment)32. This is for obvious reasons. A conclusive grounds decision is
very important for the putative victim: we have described above some of the rights to which an established
victim of trafficking becomes entitled. Although the potential consequences of a wrong conclusive grounds
decision are not generally comparable in terms of gravity to the risk to a victim of persecution if wrongly
returned to their country of origin, these are nonetheless gateway decisions that relate to important rights.
But the decision is also likely to influence the decision of the state whether to pursue a prosecution against
alleged traffickers. The requirement for a high standard of reasoning is all the more important given that in
general the decision-making process is a primarily paper exercise33 conducted by a caseworker, albeit
one who is required by ECAT to be “trained and qualified in preventing and combating trafficking in human
beings”.

243. It is fair to say that the need for very thorough decision-making is properly emphasised in the
Guidance itself. In addition to the passages to which we have already referred, it makes clear that it is
essential that decision-makers make a “comprehensive written assessment of how the person's situation
meets or does not meet the definition of a trafficked victim”. To make the decision “they must weigh the
strength of the indicators or evidence presented, including the credibility of the claim, and use common
sense and logic based on the particular circumstances of each case”. They “must also take into account
any medical reports submitted, particularly those from qualified health practitioners”. Decision-makers are
advised to assess the material facts of past and present events (material facts being those which are
serious and significant in nature), taking into account coherence, internal and external consistency, the
level of detail in an account and matters that might provide good reason for a potential victim's account to
be lacking in detail or consistency (inappropriately labelled as “mitigating circumstances”, as discussed
above) and might explain gaps or inconsistencies that could lead a decision-maker to accept an account
which might otherwise not be accepted. The Guidance requires decision-makers to include in their
decision letters a “full and detailed consideration explaining the reason for the decision in every case”.


-----

Centre and another intervening) [2020] EWCA Civ 1746

244. In our view it follows that on a judicial review challenge to a conclusive grounds decision the Court
likewise must consider the decision with particular care. That was expressly accepted by Sir James and
Mr Irwin in their skeleton argument. They cited the observations of Cranston J at paras. 56-58 of his
judgment in R (BG) v Secretary of State for the Home Department _[2016] EWHC 786 (Admin), in which he_
held that in cases involving rights under article 4 of the ECHR “the intensity of review is high”. It is
important in particular to establish whether the decision-maker has indeed observed Carnwath LJ's
injunction (see above) that every factor which tells in favour of the putative victim's case has been properly
taken into account.

245. Of course, as in any such review what matters is the substance of the analysis, reasoning and
conclusions, rather than matters of wording or form. It is also right to bear in mind two cautionary notes.
Immediately following the passage we have cited from his judgment in YH Carnwath LJ said:

“… there is a balance to be struck. Anxious scrutiny may work both ways. The cause of genuine asylum
seekers will not be helped by undue credulity towards those advancing stories which are manifestly
contrived or riddled with inconsistencies.”

And in Mibanga Buxton LJ said (at para. 29):

“[P]articular care is necessary to ensure that the criticism is as to the fundamental approach of the

[decision-maker], and does not merely reflect a feeling on the part of the appellate tribunal that it might
itself have taken a different view of the matter from that that appealed to the [decision-maker].”

246. Applying those standards, we believe that the way in which Farbey J dealt with the grounds of appeal
with which we are concerned was, with respect, too summary. It may be that she had in mind the fact that
permission had not in fact been given on those grounds.

GROUNDS 3 AND 4: CREDIBILITY AND EXPERT EVIDENCE

247. Our full review of the decision letter enables us to take these grounds fairly shortly. We have
concluded at para. 183 that many of the reasons that the CA gave for attaching no substantial weight to the
expert evidence submitted by MN were seriously flawed. However, as we acknowledge at para. 184, that
failure would not be fatal if on a fair reading of the letter its essential reasoning was that there were simply
too many “difficulties” with MN's account for it to be believed even if full weight was given to the expert
evidence, and if that conclusion was reached in a sustainable way.

248. We should start by saying that we are not satisfied that that was the CA's reasoning. It certainly
nowhere articulates it. There is, it is true, a reference to reasons “given throughout this letter” (see para.
175 above) and another to a lack of plausibility “as will be discussed below” (para. 179), but those are only
part of an omnium gatherum of miscellaneous points which are treated as reducing the value of the
reports.  However, even if we were charitably to hold that that was the substance of its reasoning, we do
not believe that the way in which it reached that conclusion was sustainable. That is essentially for two
reasons, though they overlap.

249. First, the letter does not engage in any real analysis of most of the various inconsistencies or other
difficulties on which the CA relies in reaching its conclusion that MN's account was untrue. It simply piles
up difficulties without any attempt to assess their significance to the issue of credibility: cf. our criticisms of
its approach to the expert evidence. We will not repeat the various instances of wrong or unsatisfactory
reasoning which we have identified at paras. 189-228 above. We fully accept that there remain some
serious difficulties to which the CA was entitled to give real weight, most obviously about whether MN's
account is consistent with the passport on which she says she travelled to Italy in 2010 being false (as it
must have been, given the evidence of the Albanian authorities). But the undiscriminating basis on which
the CA proceeds overall does not inspire confidence that it has carefully assessed whether those more
serious difficulties are such as to undermine her account overall.

250. Secondly, and connectedly, the CA does not at any stage in this section of the letter attempt to
consider the inconsistencies and other difficulties in the light of the expert evidence. That evidence was


-----

Centre and another intervening) [2020] EWCA Civ 1746

relevant to the credibility of MN's account in all the ways identified at paras. 157-160 above. For example,
some weight should have been given to Ms Thullesen's reasoned opinion that MN's history gave no sign of
being feigned, though of course that could not in any sense be determinative. Weight also had to be given
to her evidence about the impact of trauma on a victim's ability to recount their experiences coherently and
consistently; that is of course a point also made in Home Office Guidance, not only in the Frontline
Guidance from which Ms Thullesen quotes but in a passage from the Competent Authority Guidance which
is not quoted in the decision letter (see para. 185 above). Some at least of the inconsistencies on which
the CA relied might quite readily have been explained on that basis.34 These points are simply not fed into
the credibility analysis. Having dismissed the expert evidence as being of no real value before embarking
on the assessment of credibility, the CA makes no reference to it thereafter. If the evidence was indeed
worthless, that would be acceptable; but that was not the case. In truth, despite its evident attempt to
avoid it, the CA did in substance fall into the Mibanga error. The point made by Mibanga is not that the
expert evidence and the issue of credibility must be considered in a particular order but that the former
must be allowed to feed into the latter. That did not happen here.

251. In short, if the CA's conclusion could fairly be characterised as being that the supportive elements in
the expert evidence were outweighed by the difficulties which it found in MN's account the process by
which it reached that conclusion was unsustainable.

252. None of that would matter if it were clear that the only conclusion that the CA could have reached on
the evidence before it was that MN's core account was untrue. We have thought carefully about this. This
was not an easy case for the CA. As we hope we have made clear, by no means all the reasons given for
impugning the credibility of her account are insubstantial. There are, as Mr Husain candidly conceded,
substantial inconsistencies. We have identified several above and need not repeat them. There are also
elements in her account which might legitimately be thought implausible. We have also been given serious
pause by the fact that the FTT believed that MN was lying and found that she had come to the UK for
economic reasons and not as a victim of trafficking. As we have already said, we do not accept Mr
Husain's submission that the FTT's conclusions should have been treated as irrelevant.

253. In the end, however, we are not satisfied that the only conclusion to which the CA could properly
have come was that MN's story was untrue. There is a known problem of Albanian women being trafficked
into prostitution in Italy. MN's overall account and her presentation to the expert witnesses were
characteristic of those of genuine victims. The inconsistencies within and between her various accounts
are a real problem, but some at least are explained in her evidence in ways which are not self-evidently
untrue. Full weight must be given to the evidence (and guidance) about the difficulties that victims of
trafficking have in telling their stories, not only because of the effects of trauma but because their
experiences often engender distrust of authority and sometimes entangle them in deceptions of various
kinds from which it is difficult to escape. It is also necessary to heed the caution expressed in the
authorities about judging accounts to be implausible without complete knowledge of the relevant
circumstances, and making full allowance for how people can behave in circumstances of stress. As to the
decision of the FTT, we repeat the reasons given at para. 230 above as to why it cannot be treated as
decisive.

DISPOSAL

254. We will accordingly allow MN's appeal on grounds 2-4, though not on ground 1, and quash the CA's
decision on her application for reconsideration of the original conclusive grounds decision. The result is
that that application will have to be determined afresh by a different decision-maker on behalf of the CA.
Given its unusual complexities, we would encourage the CA to consider whether this is a case in which MN
should be interviewed. Such interviews were provided for at p. 68 of the version of the Guidance which is
before us, and no doubt there is similar provision in the current version. Nothing is there said about legal
representatives attending the interview, but consideration may need to be given to whether that is
appropriate in this case and if so what their role should be.


-----

Centre and another intervening) [2020] EWCA Civ 1746

255. Our reasons for that decision broadly reflect the main points pleaded under grounds 3 and 4,
although, as will have appeared, we have not accepted all the submissions made by Mr Husain. We have
not referred specifically to the submissions in the skeleton argument of Sir James Eadie and Mr Irwin,
which were supplemented to a very limited extent in Mr Irwin's oral submissions. In truth they amounted
essentially to a submission that it was legitimate to treat the decision letter as having found that there were
simply too many difficulties with MN's story for it to be believed and that that was an entirely sustainable
conclusion. It will be sufficiently clear why we cannot accept that submission.

256. We acknowledge that we have subjected the reasoning of the decision letter in MN's case to very
detailed criticism. We are conscious that letters of this kind are not drafted by lawyers, and also that they
are likely to be based, at least as regards structure, on templates or guidance produced within the Home
Office. We should not, therefore, read them in quite the same way as we would read the judgment of a
court or tribunal. It is fair to record that the decision-maker in this case considered the materials before him
thoroughly and observed procedural fairness by giving MN's advisers the opportunity to answer what
seemed to him to be the principal difficulties with her account. We would not, any more than with the
decision of a court or tribunal, find his decision to be wrong in law only because of minor inaccuracies or
loosenesses of expression or thinking on inessential matters. However, as we have said, the question
whether a person is a victim of trafficking governs access to important Convention rights. The fact that the
Government has chosen to entrust the determination of that question to an official in the Home Office
rather than to a court or tribunal cannot justify a less rigorous approach to the reasoning required to
support their decisions. For the reasons given above we have been driven to the conclusion that the CA
here adopted a wrong approach to its task, as well as making a number of particular errors, and overall its
decision cannot stand.

**IXU's APPEAL**

IXU's ACCOUNT IN OUTLINE

257. Like MN, IXU has given several accounts of the experiences which she says amount to her being
trafficked, and a number of difficulties have been identified with them. At this stage we will simply identify
the key features in her account as now advanced.

258. IXU says that she was born on 27 March 1997. Her family lived in Benin City. At the age of nine she
was taken away into the bush and subjected to FGM. She says that she was told that this was in
preparation for her forced marriage to a much older man. She was kept there for about three weeks. She
was told that the FGM had not been complete and that she was being returned to her home pending a
second procedure. She pleaded with her parents not to allow her to be cut again, but they refused, so she
ran away. She was picked up by an older man, Sam Okoro, with whom she lived for several years and by
whom she was raped and sexually exploited.

259. IXU entered the UK on, as we have said, 29 July 2012 on a student visa which she says was
arranged for her by Sam Okoro. On her account she was aged 15, but a false date of birth of 27 October
1988 was provided for the visa application. She was told that she was going to go to college. It is her case
that on her arrival in the UK she was met by a woman known to her as “Ma” (also referred to as “Oz”) and
taken to her house and forced into prostitution, although she was allowed to go to college intermittently.
She escaped from Ma in early 2013 when she and some other girls from the brothel were taken to an
airport in order to be sent to work in Italy.

260. Following her escape she met a Hungarian national called Karoly Farkas, who offered to help her but
who she says in the event raped and threatened her. She agreed to marry him and attended a registry
office for that purpose, but immigration officials intervened and she and Mr Farkas were arrested and
charged with participating in a sham marriage.

OVERVIEW OF THE ALLEGED TRAFFICKING


-----

Centre and another intervening) [2020] EWCA Civ 1746

261. It is convenient to note at this stage that that account potentially comprises three distinct episodes of
trafficking.

262. First, if, as IXU says, the episode in which she was subjected to FGM occurred in order to prepare
her for a forced marriage, that can be analysed as an act of trafficking. So far as element (a) (“action”) is
concerned, there are elements of both “transfer” and “harbouring” since she was taken into the bush and
kept there for a period of weeks; and if forced marriage constitutes exploitation element (c) (“purpose”) is
potentially satisfied too – though there are issues about this which we will have to consider later. Element
(b) (“means”) is unnecessary because she was a child. We are bound to say that we find it rather odd that
where a child is subjected to FGM for the purpose of exploitation it will constitute trafficking if they are
taken elsewhere for the procedure but not if it is performed at home: the element of “transfer” seems
adventitious. However that would appear to follow from a literal reading of the definition; and, as will
appear, it was accepted by the CA in the present case and was common ground before us35.

263. Second, if IXU's account of her time with Sam Okoro is accepted she was plainly a victim of
trafficking in Nigeria: she was harboured by him for the purpose of sexual exploitation. Again, she was a
child for at least part of the period, so the “means” element is not required, though no doubt it was present.

264. Third, if IXU's account of how she came to the UK is accepted she was plainly a victim of trafficking in
that regard also: she was transported to the UK by Sam Okoro and harboured by Ma for the purpose of
sexual exploitation. If her date of birth is as given on her visa application, rather than as she claims, she
would by this time be an adult, but on her account she was deceived by Mr Okoro as to the reason for her
coming to the UK and her vulnerability was abused by Ma.

THE CRIMINAL PROCEEDINGS

265. IXU was prosecuted for participating in a sham marriage. Initially she claimed to be in a genuine
relationship with Karoly Farkas, but in an amended defence statement she asserted that she was only 16,
that the date of birth on her visa was false, that Mr Farkas had raped and threatened to kill her, and that
she had agreed to marry him because she thought she had no choice.

266. IXU's case about what she was told about the purpose of the FGM is important to one of the issues in
the appeal, and we set out what she said about it in her defence statement:

“It all started between the ages of 7-9 years when I will be given out for marriage to a man who is much
older than [sic] and all because of the tradition, so because of that I had to be circumcised for me to be with
him and the rituals had to be regular to me as I cannot stand it so I had to run away from him at the age of
9.”

267. On 9 April 2014 IXU was convicted, as an adult, at the Crown Court and sentenced to two years'
imprisonment.

THE ASYLUM PROCEEDINGS

268. On 1 May 2014 IXU was notified that she was liable to automatic deportation. She then made a
claim for protection on asylum and human rights grounds, asserting in her application that she was 16
years old, that she had been subjected to FGM for the purposes of forced marriage, that she had been
kept and abused by Sam Okoro and that she had been sent to this country by him with a promise of
studies.

269. On 16 June 2014 IXU took part in an asylum interview. We need not summarise what she said, but
we should set out her answer when asked to describe what kind of rituals she had undergone in Nigeria.
She said:

“At the age of nine I must be circumcised and they force me into marriage. I must marry an older man and
be with throughout, during that I must continue with the ritual of circumcision all my life [sic].”


-----

Centre and another intervening) [2020] EWCA Civ 1746

In answer to further questions, she gave details of how and by whom the FGM had been performed. When
asked what type of marriage she was being asked to be part of, she replied “traditional (forced) marriage”.
Later in the interview she said that the men who carried out the circumcision said that the process would
take a long time and “they would then choose the man that I would be married to”; and she had to return
home before they started the ritual again – “then after that ritual I would be given to a man”.

270. Medical examination for the purpose of the asylum claim confirmed that IXU had undergone FGM
involving loss of the posterior labia minora.

271. On 21 November 2014 IXU's asylum and human rights claims were rejected. She appealed. In a
statement in support of the appeal she described the FGM in these terms:

“When I was nine years old I was taken by seven men from my home. They were my father's relatives and
I was told that my tribe's tradition require that I should have circumcision in order to be made ready for
being married. I was told that because I was the youngest child then I would be the one that the rituals
were done to. I had some cutting of my genitals but was told this was incomplete and that it will be
necessary for this to be continued in the future.”

She gave further details about what exactly had been done to her which it is unnecessary to recite here.
She also asserted that she had been forced into prostitution in this country by Ma.

272. On 22 October 2015 the FTT dismissed IXU's appeal. The central focus of the decision was whether
she would be at risk if she were returned to Nigeria, and more particularly on whether she was at risk of
being forced by her family to undergo further FGM and of a forced marriage. In that connection, her
account of undergoing the original FGM was relevant; and, as noted above, what she said about it is
important for the purpose of the issues before us. The judge, while accepting her account of having
undergone FGM, found that she had been untruthful about the procedure having been incomplete and
about having fled in order to escape her family. At para. 12 of her decision, the judge summarised IXU's
case on this aspect as follows:

“The Appellant was taken from her home at the age of nine by her father's relatives. She was subject to
FGM which she was told was incomplete and it will be necessary [for] this to be continued in the future.
She was [sic] also suffered incisions made to her chest. She believed that these rituals were in preparation
for her being married. The rituals took three weeks during which time she was kept naked in the mud
house in a village. The process was extremely painful and frightening. After she was brought home she
believed that she would be taken again and she ran away from her home in the middle of the night.”

She added, at para. 25:

“She believes that she is at risk from family members who will force her to undergo further FGM or that she
would be forced into marriage.”

273. The judge set out her findings on this issue at para. 50 of her decision:

“The FGM was confirmed in the examination by Dr Pryce who described the Appellant as having 'the loss
of posterior labia minora only'. There is no mention of the word 'partial.' It is the Appellant's claim that this
FGM was not completed and only partial. I have no evidence about FGM practices of the Appellant's tribe
but I am aware of other cases and reports on the subject that the type of FGM varies from country to
country and tribe to tribe and even within families. I am aware that what has happened to the Appellant
may be the extent of the FGM practised. This is not to diminish what must have been horrific for the
Appellant at her age. I conclude that this happened to her at the age of nine but that this was the end of the
process and that the Appellant has added her claim to the abuse being partial to assist in her claims of
persecution on return to Nigeria.”

At para. 62 of her decision she concluded:


-----

Centre and another intervening) [2020] EWCA Civ 1746

“For the reasons I have given I do not accept that the Appellant is at real risk of further FGM on her return
to Nigeria. My conclusion is that she is a victim of FGM but that this was carried out and completed many
years ago. I do not accept that she has been or will be forced into marriage by her family.”

At para. 64 she added:

“I do not accept that she has been truthful in her account of fleeing from her family at a young age and the
reasons for this. She continues to maintain contact with her family who she has stated were going to force
her into a marriage. I note that her family in Nigeria gave her the address of her sister and have asked her
to return home. I do not accept that her family are attempting to force her into marriage or cooperate in
further abuse. I conclude that the Appellant can return to her family in Nigeria.”

274. Although risk on return was the focus of the FTT's decision, the judge also considered IXU's evidence
about having been trafficked to England by Sam Okoro and forced into prostitution and about the
circumstances in which she had entered into a sham marriage. As regards the marriage, she found, again,
that IXU had lied: she had not been in fear of Karoly Farkas but had gone ahead voluntarily in order to
obtain leave to remain following the closure of the college where she was studying.

275. However, as regards whether IXU was trafficked to England, the judge's findings were more
equivocal. At para. 52, while rejecting elements in IXU's account of her relationship with Mr Okoro, she
says that

“It is plausible that a man made arrangements for her to come here with her cooperation and it is plausible
that a form of abusive relationship existed given her account.”

She says at para. 65:

“There is no evidence to support the Appellant's claim that she was trafficked to this country. I certainly
have suspicions but I have not been given anything near to the full disclosure of the background to her
coming to this country and who arranged this. However to take these suspicions any further would be to
make speculations which are not based on any evidence or full disclosure from the Appellant. There is no
evidence to support her claim that she would be re-trafficked on her return.”

It is of course only the finding made in the final sentence that was necessary for the purposes of the
appeal.

276. We should note, finally, that the FTT looked carefully at the evidence concerning IXU's age. Although
there had been a _Merton-compliant age assessment which had accepted her claimed date of birth of 27_
March 1997, the judge concluded that she was older than that. She was not able to say how much older,
but she was satisfied that she was over 18 at the date of her criminal conviction on 9 April 2014 but
younger than 27 (which is the age she would have been if the date on the visa application was correct).

REFERRAL TO THE NRM AND RECONSIDERATION REQUEST

277. On 7 June 2015 IXU was referred to the NRM by the Salvation Army. On 24 June the CA concluded
that there were no reasonable grounds for believing that she was a victim of trafficking.

278. On 13 May 2016, having consulted her current solicitors, IXU again asked the CA to review the
negative reasonable grounds decision. In support of that request she in due course submitted reports from
a psychiatrist, Dr Rachel Sharp, of the Trauma and Immigration Service Legal Unit at the Tavistock and
Portman NHS Foundation Trust, and from Ms Thullesen, to whom we have already referred in connection
with MN's appeal. The contents of their reports can be sufficiently summarised for the purposes of the
issues as follows.

Dr Sharp

279. Dr Sharp reviewed the full papers and had a two-hour interview with IXU in which she took a history.
In the introductory section of her report she explains that the purpose of her interview was to establish
IXU's current mental state and make a full psychiatric assessment. At para. 12 she says:


-----

Centre and another intervening) [2020] EWCA Civ 1746

“Although it is not possible, nor have I been requested, to ascertain for certain that [IXU] is telling the truth,
it is always my practice to bear in mind the possibility that an individual might be feigning symptoms of
mental illness particularly in cases where there is a clear secondary gain to be had.”

280. From paras. 14-88 Dr Sharp records IXU's history as given in the interview and her “mental state
examination”. The history corresponds to the account which we have summarised above. At para. 20 she
says:

“[IXU] did not come across as someone who was particularly well rehearsed or even especially keen to
take full advantage of an opportunity to convince me of anything or 'make a case'. Those who are
deliberately trying to mislead or feign symptoms can adopt both of these aforementioned positions. I did
not see evidence of this here.”

At para. 88 she says:

“At no time during my interview and assessment of [IXU] did I have the impression that she was feigning
symptoms or fabricating/concealing aspects of her history.”

281. The “Opinion” section of Dr Sharp's report begins at para. 89 (though the paragraph numbering then
reverts to 74). She starts with her diagnosis, which is that IXU met the criteria for post-traumatic stress
disorder and persistent depressive disorder (moderate severity). At para. 77 she observes that her history
contained several episodes of severe trauma. She continues, at para. 78:

“It is not possible to be highly specific about exactly which trauma led to the development of the PTSD
symptomatology.”

Her symptoms had become more severe when she was in prison. Dr Sharp continues:

“By this point she had experienced many and severe traumas, a number of which alone could have led to
the development of PTSD. The likelihood is that they have had a cumulative effect. It should also be
acknowledged that being in immigration detention, under threat of deportation, may in itself be experienced
as highly distressing even to less vulnerable individuals.”

Para. 79 reads:

“In terms of her individual presentation, [IXU] experiences recurrent, involuntary and intrusive recollections;
traumatic nightmares; persistent effortful avoidance of distressing trauma-related thoughts and feelings;
persistent distorted blame of herself for causing the resulting consequences of the traumatic event;
persistent trauma-related fear, guilt and shame; feeling alienated from others; constricted affect;
hypervigilance; problems in concentration and sleep disturbance. The aforementioned symptoms, coupled
with her history, are diagnostic of PTSD.”

After, at para. 80, explaining the further diagnosis of persistent depressive disorder, she says, at para. 81:

“I have given consideration to the possibility that these disorders are feigned/fabricated and I am satisfied
that this is not the case, as indicated below at paragraph 8736. If anything, I think [IXU] may have
underestimated their significance.”

282. At para. 91 Dr Sharp addresses a question raised by IXU's solicitors about whether her account
“corresponds with/is in any way corroborated by her current psychological state”. She says:

“[IXU's] psychiatric presentation is consistent with the history as described. This opinion is based on my
impression of her in our meeting, and in particular my view of how her personality has developed, or rather
underdeveloped.”

She continues, at para. 92:

“That is not to say that I can determine for sure that events have occurred precisely as [IXU] describes
them and nor can I guarantee the veracity of her account. What I can say is that she presents as a woman
who has experienced considerable trauma and that it has had a significant impact not just on her current


-----

Centre and another intervening) [2020] EWCA Civ 1746

mental health but on her developing personality. The latter is symptomatic of her having been affected at
such an early age, while her character was still in development.”

Ms Thullesen

283. Ms Thullesen's report is, again, extremely lengthy; but for the purpose of the issues on this appeal we
are concerned only with some specific aspects.

284. At para. 11 of her report Ms Thullesen identifies no fewer than fourteen questions which she had
been asked to address. At para. 12 she says:

“In this report, I intend to comment on the points relevant to and within my expertise and will highlight
particular aspects of the instructions which are not within my remit to comment on. It is important to note
that I do not comment on credibility, as this is a matter for the court to decide. I base my opinions on the
consistency of [IXU's] account in relation to that of other victims of trafficking I have provided support to, as
well as objective evidence. My opinion is furthermore grounded in my psychological training in conducting
clinical assessment and my clinical understanding of how victims of trauma and trafficking present
behaviourally.”

285. At paras. 13-17 Ms Thullesen explains her assessment procedure. She says at para. 13 that she has
had a “semi-structured face-to-face interview” with IXU. At para. 15 she says that the purpose of her
assessment was to identify the presence of key trafficking indicators as well as the presence of the three
essential elements in the definition of trafficking (see para. 20 above).

286. At paras. 18-74 Ms Thullesen records IXU's history as given by her. Again, this is consistent with the
account which we have summarised. We need only note that the part of the history dealing with her being
subjected to FGM begins (para. 22):

“[IXU] recalled her mother and father telling her that she had to go with her uncle because they had to give
her up for marriage. [IXU] told me that she never met the man she was supposed to marry. When I asked
whether she knew why she had been made to go with her uncle, she said she didn't. She narrated how at
this young age she didn't actually know what it meant to get married and was scared.”

The history then proceeds to describe her being taken by her uncle into the bush and how the FGM
proceeded.

287. At paras. 75-141 she identifies the indicators of trafficking in that account. If IXU's account is true
there is no doubt that she was trafficked, so we need not summarise the discussion37. However we
should quote three passages from her conclusion. At para. 139 she says:

“It is my professional opinion, based on objective analysis, that [IXU's] account, as provided within the
documentation in her file and her narrative, contains a significant number of trafficking indicators.
Furthermore, I find the explanation of her personal history of being forced to undergo FGM with the
intention of being given up for marriage at a young age, as well as how she came to be recruited, to be
broadly consistent with other victims of trafficking I have assessed.”

At para. 140 she says that in her extensive experience of working with victims of trafficking “I have
observed patterns similar and comparable to that of [IXU's] experiences”. At para. 141 she says:

“I consider it possible [IXU] continues to experience difficulty narrating some aspects of her account for
various reasons … Despite this, I consider it unlikely that she has fabricated fundamental and key features
of her experiences as described in the assessment conducted or that she is feigning her current emotional
and psychological difficulties. … When fabricating accounts it can often be difficult for a person to divert
from a rehearsed narrative and it can sound static and inflexible, consistently emerging in the same order
and with the same key details, a feature I did not observe in the interview with [IXU]. I did not experience
her account as rehearsed or presented in a manner which would lead me to question its overall
consistency with that of other victims of trafficking I have assessed. [IXU] was able to provide many
pertinent details that I would expect her to be able to narrate. Nevertheless, I noted that [IXU] appeared to


-----

Centre and another intervening) [2020] EWCA Civ 1746

struggle to disclose her experiences of exploitation and experienced significant shame at events that have
taken place, a presentation which is highly consistent with accepted patterns of disclosure related to
human trafficking.”

288. Paras. 147-165 are headed “Self-identification, reluctance, delay and inconsistency in disclosing
experiences of trafficking & exploitation”. Ms Thullesen notes at para. 148 that IXU's various accounts of
her experiences have become “more detailed and congruent” over time. She describes this pattern of
disclosure as “highly consistent with that of a young girl who has been subjected to emotional, physical and
sexual exploitation from a young age”. She refers at para. 149, as she did in her report in MN's case, to
the Home Office's Guidance to frontline staff. Her conclusion, at para. 165, reads:

“In summary, [IXU's] significant difficulty in disclosing her account, and the piecemeal fashion in which it
has emerged, is highly consistent with other victims of trafficking, and indeed generally with refugee
women, who have experienced sexual violence. Thus, the delay in disclosure of certain aspects of her
account does not lead me to question the consistency of her narrative. The level of control exerted, her
psychosocial presentation, combined with pre-existing emotional vulnerability, in my opinion, renders this a
pattern consistent with that of many other victims of trafficking I have assessed and supported.”

289. Paras. 169-179 are headed “Psychosocial and health effects”. The summary at para. 179 reads:

“[IXU] appears to suffer from a range of physical and psychological symptoms, all of which are commonly
associated with the experience of interpersonal violence and trafficking. The symptoms described within
her documents and narrative are, in my opinion, highly consistent with the experience of abuse, ritualised
violence, control, rape, trafficking and exploitation and appear to be compounded by the lack of certainty
related to her immigration and legal status. The evidence gained regarding her physical and psychological
presentation, in my view, further corroborates her experience of exploitation and trafficking. Based on the
manner in which she presented during the interview it is in my clinical opinion unlikely that she was
fabricating her symptomatology.”

290. Ms Thullesen's overall conclusion, at para. 199, reads:

“I find the indicators and patterns of trafficking evident in [IXU's] account to be consistent with other victims
I have assessed and with objective evidence referred to in this report. This is based on my knowledge of
assessing and working with victims of trafficking … It is also based on the particulars of [IXU's] case, taking
into consideration all of the evidence available to me. It is my opinion that she fulfils the key elements
known to constitute trafficking. Namely, (i) the _action of being recruited by Sam Okoro, who appears to_
have groomed her for a period before using her for the (ii) purpose of domestic servitude and sexual
exploitation. She was consequently transferred to the UK where the woman known as Ma evidently
exploited her in prostitution.”

Overview

291. The evidence of Dr Sharp and Ms Thullesen was potentially supportive of IXU's claim to be a victim
of trafficking in the same ways as we identified in the case of MN.

292. First, both witnesses express the opinion that MN's reported symptoms – primarily characterised as
PTSD – are “consistent with” those experienced by women who have suffered sexual exploitation of the
kind described by her. Ms Thullesen uses the phrase “highly consistent” (see para. 179 of her report); and
it may be that Dr Sharp intended also to connote more than “mere consistency”. The weight to be given to
that evidence must depend on the extent to which those symptoms might be caused by other experiences.
Dr Sharp acknowledges that the experience of immigration detention can itself be “highly distressing” (see
para. 78 of her report); but we do not understand her to be saying that it is probable that that was the
principal, let alone sole, cause. Ms Thullesen refers to the uncertainty about her immigration status as
“compounding” the effect of the other experiences (para. 179). Both express the opinion that the
symptoms are not feigned.


-----

Centre and another intervening) [2020] EWCA Civ 1746

293. Second, both Dr Sharp (at para. 88) and Ms Thullesen (at para. 141) say that it is unlikely that IXU
was fabricating the fundamental features of her experiences as recounted in the history.

294. Third, Ms Thullesen expresses the opinion (at para. 140) that IXU's narrative contained indicators of
trafficking and sexual exploitation that were consistent with the accounts of other victims. That is in
principle capable of supporting the truthfulness of her account, though the extent to which it does so will
depend on the circumstantialness of the features relied on.

295. Fourth, Ms Thullesen expresses the opinion (at para. 165) that the pattern of disclosure of IXU's
account of her experiences is characteristic of victims of trafficking and should not be treated as itself
undermining her credibility.

THE DECISION OF THE COMPETENT AUTHORITY

Introductory

296. On 6 December 2016 the CA concluded that there were reasonable grounds to believe that IXU was
a victim of trafficking. It then proceeded with its consideration for the purpose of a conclusive grounds
decision. In September 2017 it wrote to IXU's solicitors asking for further information or explanation on
some points.

297. The CA's conclusive grounds decision that IXU was not a victim of trafficking is dated 12 February
2018. The Consideration Minute (to which, again, we will refer as the decision letter) is lengthy, running to
over thirty pages. Because the issues in IXU's appeal are not the same, we need not analyse it as fully as
in MN's case.

298. Paras. 1-54 are essentially introductory, though they contain some important material. Para. 19
includes a full summary of the adverse findings about IXU made by the FTT. Paras. 21-26 contain full
summaries of the reports of Dr Sharp and Ms Thullesen. Paras. 30-31 summarise IXU's case. At paras.
32-49 the CA sets out the law and some of the guidance relating to human trafficking and slavery. Paras.
50 to 52 of the decision are headed “Objective Evidence” and set out passages from a US report on
trafficking in Nigeria, concluding:

“The evidence above confirms that **_modern slavery is prevalent in Nigeria and in the UK, where_**
individuals, including women and children, are subject to exploitation. Your account of events in both
Nigeria and the UK is therefore externally consistent in that regard.”

299. The substantial part of the decision is found in the section headed “Conclusive Grounds Decision”
from paras. 55 to 149. It is in a number of sections.

Credibility

300. The first section, which runs from paras. 55-68, has no heading, but it appears to be directed to IXU's
credibility, and para. 56 states the CA's overall conclusion on that issue, namely:

“For the reasons set out below, there are significant reasons to doubt the credibility of your evidence and
consequently this reduces the weight that can be placed upon your evidence.”

301. The letter goes on at para. 57 to set out four short quotations from different parts of the Guidance
relevant to the assessment of the truthfulness of the account given by a potential victim of trafficking.
These include the passages which we have summarised at para. 241 above and the first of the two
passages quoted at para. 184, which relates to consistency. It does not, however, quote the other
passage which we have there summarised, headed “Difficulty recalling facts”, nor the passage quoted at
para. 124 – “Assessing credibility – mitigating circumstances”.

302. At para. 58 the CA says that it has taken into account all available evidence and notes that the
appropriate test is the balance of probabilities.


-----

Centre and another intervening) [2020] EWCA Civ 1746

303. At para. 59 the CA records the fact that IXU had freely acknowledged that she had told various lies
about important matters. At para. 60 it points out that the FTT (to which it refers as “the IAC”) “had
difficulties with your evidence” and itemises those difficulties under nine heads.  The points summarised
include the FTT's findings of untruthfulness in her evidence about her date of birth and aspects of the
circumstances surrounding her FGM, and also about her relationship with Karoly Farkas and her motives.

304. At paras. 61-68 the CA considers the reports of Dr Sharp and Ms Thullesen in order, as we
understand it, to assess their relevance to IXU's credibility. We should note at this point that the CA in fact
considers the expert evidence in two distinct sections of the decision letter. In these paragraphs its focus
appears to be on whether that evidence gives any positive support to IXU's account – or, as it sometimes
expresses it, whether it “corroborates” it. Later, at paras. 140-143, it considers whether it offers any
“mitigation” for what would otherwise be features which cast doubt on its truth (such as inconsistency or
late disclosure): see paras. 317-321 below. We understand the theoretical logic behind that distinction, but
it is not clear-cut in practice and, as appears below, the CA had difficulty observing it. We should also say
that the term “corroboration”, though not as inappropriate as “mitigation”, is not ideal, because it carries a
certain amount of baggage from its use in the context of criminal law: in particular, it may imply that a
person's account cannot be accepted in the absence of some supporting evidence. We prefer the term
“supporting evidence”.

305. The CA's conclusion about the value of the expert evidence to credibility is at para. 68. It reads:

“Notwithstanding the reports from Dr Sharp and Ms Thullesen, for the reasons given above, they are only
of limited value in determining whether you are a credible witness regarding the material facts of your
account. It is acknowledged that you present as a vulnerable individual who has undergone at least one
traumatic experience having undergone FGM as a child. However it is also true that there is still no
independent evidence of any of the other material facts upon which you seek to rely.”

We should identify the “reasons given above”. It will be convenient to comment on them as we go through.
Paras. 62-64 are concerned with Dr Sharp's report and paras. 65-67 with Ms Thullesen's.

306. Paras. 62-63 are based on the fact that Dr Sharp accepted IXU's history at face value. The CA says
at the end of para. 62 that Dr Sharp “pays no attention to the IAC's concerns as the veracity of your
account”. At para. 63 it refers to Dr Sharp's statement at para. 12 of her report (see para. 284 above),
which it characterises (rather tendentiously) as her “even [our emphasis] advising that she was not
concerned with the veracity of your account”, and says that this demonstrates that Dr Sharp appears to
have been concerned only with “whether you may be feigning symptoms of mental illness”. It says that Dr
Sharp's reliance on IXU's history “detracts from the weight that can be placed on [her report] as evidence
of your credibility regarding historical events” and that “her report therefore carries very little weight as
corroborative evidence of the material facts within your account”.

307. At para. 64 the CA addresses Dr Sharp's opinion that her diagnosis of PTSD was consistent with
IXU's history. It refers to para. 92 of her report and makes the point that while her diagnosis is evidence
that IXU had suffered trauma it is not evidence that the trauma was caused “by other unsubstantiated
events which you claim to have occurred”; the “other” appears to mean “other than the FGM”, which the CA
had accepted that IXU suffered.

308. It will be convenient to comment on that reasoning at this stage. We wish to make three points:

(1) We do not regard it as appropriate for the CA to discount the value of Dr Sharp's evidence because
she did not take into account the fact that the FTT had found that IXU had not told the truth on important
aspects of her account and that she had “even” said that she had not been asked to “ascertain for certain
that [IXU] is telling the truth”. As the CA itself emphasises elsewhere, the question whether IXU was telling
the truth was ultimately for it to decide, and it is not the role of an expert witness to undertake the task of
assessing a subject's account against other accounts or evidence or previous judicial findings. What Dr
Sharp said at para. 12 of her report was thus perfectly conventional. But it does not follow that an expert


-----

Centre and another intervening) [2020] EWCA Civ 1746

may not give evidence which is relevant to the decision-maker's assessment of credibility, and Dr Sharp
did so: see paras. 292-293 above.

(2) It is wrong to say that Dr Sharp was only concerned with IXU was feigning symptoms of mental illness.
Para. 12 does indeed refer only to the possibility of her feigning symptoms; but para. 88 says that she gave
no impression of fabricating her history.

(3) It is entirely fair for the CA to point out at para. 64 that the degree to which Dr Sharp's diagnosis of
PTSD supports the truth of IXU's account of being trafficked depends on the likelihood of the trauma in
question having occurred in some other way; and Dr Sharp herself at para. 78 acknowledges that it is not
possible to be “highly specific” about which trauma or traumas are the cause of IXU's condition. The
possibility – albeit not specifically raised by Dr Sharp herself – that the experience of undergoing FGM was
the only cause of IXU's PTSD, to the exclusion of the subsequent episodes of exploitation by Sam Okoro
and Ma which she describes, is certainly something which the CA was entitled to take into account, but it is
not in our view a sufficient reason for disregarding this aspect of Dr Sharp's evidence altogether.

309. As regards Ms Thullesen's report, the CA quotes at para. 65 the statements at paras. 12 and 15
(wrongly referred to as para. 14) of her report (see paras. 284-285 above), together with a further passage
in which she accepts the findings of the age assessment. At para. 66 it says:

“This demonstrates that [Ms Thullesen's report] does not offer an unbiased view on the credibility of your
account, instead the report is primarily concerned with assessing whether your account contained key
elements of trafficking, whether it was consistent with accounts given by other victims of trafficking and
whether the events which you describe might satisfactorily account for any issues regarding your
disclosure. The presence [sic] of [Ms Thullesen's report] does not substantiate your claims as it
presupposes that the material facts of your claim are settled. The report starts from a position of accepting
all key elements of your account and is therefore of limited value in terms of an objective assessment of
the credibility of that account.”

310. That passage falls into the same error as we have identified with regard to Dr Sharp's report. It is
obviously the case that Ms Thullesen's report does not “substantiate” IXU's claim, in the sense that she
made no finding based on all the evidence about whether she was telling the truth: that was the CA's role,
not hers. But it was entirely appropriate for her to express her opinions on the basis of IXU's history as
recounted to her; and it is regrettable that the CA should have used the language of “bias” (though we are
sure that it was not its intention to impugn Ms Thullesen's good faith). Of course, if the CA's ultimate
conclusion were that IXU's account was fabricated, Ms Thullesen's opinions based on that account would
be invalidated. But it was necessary for the CA when considering whether IXU's account was true to take
Ms Thullesen's opinions fully into account. It is also misleading to suggest that Ms Thullesen simply
uncritically accepted IXU's history. She did not do the same exercise that the CA itself was required to do,
of assessing it in the round against all the available evidence; but para. 141 of her report makes it clear
that she was alive to the possibility of fabrication and that, so far as presentation was concerned, she
judged that it was unlikely. That opinion required to be fed into the CA's assessment, all the more so as
the decision-maker had had no opportunity to see IXU for himself.

311. At para. 67 the CA acknowledges the importance of the points made by Ms Thullesen at para. 165
about the difficulties which victims of trafficking may have in giving a full and consistent account of their
histories, noting that the same point is made in the Guidance; but it says that the question whether a
potential victim of trafficking is telling the truth has to be decided by the CA, and it notes that although the
FTT had also acknowledged the same points as are made by Ms Thullesen it “still came to the conclusions
… summarised at paragraph 60 above”. As we understand it, what the CA is saying is that even where full
allowance is made for this factor a decision-maker may still find an applicant's story to be untrue. It seems
to us that this point is more relevant to “mitigation” than it is to “corroboration”. As far as it goes it is
obviously correct, but we do not see how it supports the CA's conclusion in para. 68 that Ms Thullesen's
evidence is “only of limited value”: rather, her evidence is of real value, but it is not (of course) conclusive.


-----

Centre and another intervening) [2020] EWCA Civ 1746

The Elements in IXU's Narrative

312. The following sections are headed “Age”, “Ritual”, “Encounter and time with Sam Okoro”; “Visa
application and time with Ma”; “Circumstances surrounding departure from Ma/Oz”; and “Karoly Farkas”.
Under each the CA considers the credibility of the relevant aspects of IXU's account. We need only note
some particular points.

313. Under the heading “Ritual”, the CA observes:

“89. You have been broadly consistent around your claims to have undergone some form of ritual in
Nigeria and medical evidence supports you having undergone FGM and to have been harmed in a manner
consistent with a ritual. The [FTT] concluded that you underwent FGM at the age of nine, but that it was
completed without any further procedure outstanding and that you added the claim that it was only partially
completed in order to assist your claim of fear on return. It is not considered that the significant doubts
regarding your credibility outweigh the available evidence with respect to the ritual and FGM performed on
you. This element of your claim is therefore accepted, but it does not specifically relate to the matter
regarding human trafficking or another form of modern slavery without an intention to exploit you. Whilst
we do not wish to belittle the traumatic effects of FGM, there is nothing within your accounts to
demonstrate that this related to a further intention to exploit you.

90. It must nevertheless be noted that the [FTT] concluded that you had embellished this element of your
background. The fact that you had embellished this incident does not mean that you have been untruthful
about other aspects of your account, but it does detract from your overall reliability as a witness of truth
regarding material facts.”

The statement in para. 89 that “this element of your claim … does not specifically relate to the matter
regarding human trafficking” is puzzling. It might at first sight appear to suggest that the CA did not regard
this episode as part of IXU's claim to have been trafficked; but, as will appear, that is not the basis on
which it eventually proceeded – see para. 323 below.

314. Dealing with the issues concerning Sam Okoro, the CA started by noting that the FTT had concluded
that IXU's account could not be accepted. Having referred to the passage in Ms Thullesen's report
concerning IXU's account of her time with Mr Okoro, the CA observed, at para. 93:

“[It] appears to relay your own evidence with respect to your time with Sam Okoro and does not properly
question the veracity of your account. It is not accepted the new evidence affords you any further mitigation
with regard to the matters that the FTT did not find to be credible.”

This criticism betrays the same misunderstanding as we identify at para. 310 above: there was no
obligation on Ms Thullesen to “properly question the veracity” of IXU's account.

315. As regards IXU's account of her time with Sam Okoro, the CA noted various inconsistencies and
implausibilities and concluded, at para. 101, that it could not be accepted, on a balance of probabilities,
“that your claimed version of events … amounts to a plausible account of exploitation that would bring you
within the definition of human trafficking”.

316. Similarly, the CA did not accept parts of IXU's account of her time with Ma, on the basis of a number
of elements which it regarded as inconsistent, implausible or disclosed very late. With regard to her
allegations concerning Karoly Farkas, it was held that her failure to disclose “a cohesive account” of her
whereabouts after her alleged departure from Ma cast further doubt on her overall reliability as a witness of
truth.

“Mitigating Circumstances”

317. The next section of the decision letter is headed “Mitigating circumstances”. It is more substantial
than the equivalent in MN's case. We can summarise it as follows.

318. At para. 136 the letter refers to the fact that victims of trafficking “may be reluctant to disclose details
of their experiences and that this in turn may cause inconsistencies errors or delays in a victim's


-----

Centre and another intervening) [2020] EWCA Civ 1746

disclosure”. This is of course the point made both by Ms Thullesen and in the passage from the Guidance
quoted at para. 124 above. The CA notes that such inconsistencies and delays had occurred in IXU's
account of her experiences. Accordingly, it says at para. 137, consideration has been given to “whether
there are any mitigating circumstances which adequately explain the delayed disclosures and
inconsistencies in your case”. Paras. 138-139 itemise in some detail all the medical records relating to
treatment received by IXU for mental ill health and note one or two omissions. No attempt is made to
analyse those records, but that is not unreasonable since the important statement of the “mitigating
circumstances” (in the sense in which the CA uses that term) is in the expert evidence, which it addresses
in the following paragraphs.

319.  Dr Sharp's report is considered at paras. 140-142, but these simply repeat, albeit in different terms,
the two points that had already been made in relation to credibility, namely that the report took IXU's
account at face value, without any attempt to assess its veracity, and that it does not identify what
particular trauma caused IXU's PTSD. We have already commented on those points, but we are not clear
what they have to do with “mitigation”.

320. At para. 143-146 the CA acknowledges paras. 147-165 of Ms Thullesen's report, which express the
view that the pattern of late disclosure in IXU's case is characteristic of victims of trafficking, but goes on to
give reasons why difficulties of the kind which she describes are not an adequate explanation of IXU's late
disclosure in this case.  It is not necessary to examine its reasoning for the purpose of the issues before
us.

321. The CA concludes the “mitigating circumstances” section at para. 147 as follows:

“Consideration has been given to all of the documents and evidence submitted in support of your case.
However, it is not accepted that the mitigating circumstances present in your case provide sufficient
mitigation in your case in the face of the [FTT's] findings. Therefore, for the reasons given earlier, your
credibility has been damaged to the extent that your specific claim to have been exploited by Sam Okoro,
Ma and Karoly Farkas cannot be believed against the test of 'the balance of probabilities'.”

Conclusions

322. At paras. 150-177 the CA sets out its conclusions (under the heading “Consideration: Human
Trafficking”). At para. 150 it helpfully analyses IXU's claims into five “events” – (1) “being subjected to ritual
FGM”; (2) “being harboured, sexually exploited and subjected to domestic servitude by Sam Okoro”; (3)
being transferred to the UK for the purpose of forced prostitution; (4) forced prostitution at the hands of Ma;
and (5) rape and being forced into a sham marriage by Karoly Farkas.

323. On the basis of the factual consideration in the previous part of the letter none of the events save (1)
was, on the balance of probabilities, accepted as having occurred.  As regards (1), the CA's reasoning is
fuller. At paras. 156-177 it considers IXU's case by reference to the three elements in the definition of
trafficking (see para. 20 above). As regards (a) – “action” – it accepts at para. 157 that IXU was “subjected
to an act of transportation and harbouring in relation to [your] account of FGM”. As regards (b) – “means” –
it accepts that she had experienced a threat of the use of force whilst being in a position of vulnerability,
though it acknowledges that if she was in fact a child this element did not require to be established. As
regards (c) – “purpose” – it concludes that the action in question had not been for the purpose of
exploitation, whether in the form of forced labour, domestic servitude or sexual exploitation. As to domestic
servitude, it says, at para. 172:

“It is acknowledged that you went through FGM as a child in Nigeria and you claim to have been informed
that such action was in preparation for your marriage to an older man at some point in the future. However
there is no evidence to demonstrate, 'on the balance of probabilities' that the intention was for you to be
placed in a situation amounting to domestic servitude.”

As to sexual exploitation, para. 176 is in identical terms save that it concludes “… that the intention for the
purposes of your sexual exploitation”.


-----

Centre and another intervening) [2020] EWCA Civ 1746

THE DECISION OF THE DEPUTY JUDGE

324. On 11 May 2018 an application for judicial review of the negative conclusive grounds decision was
filed and permission granted on 26 August. The substantive hearing took place before Mr Mott in
December 2018. As we have said, on 19 January 2019 he handed down judgment dismissing the claim.

325. The judge summarised the grounds of appeal as follows. It was alleged that the CA:

(1) misdirected itself in law in relation to whether forced marriage constituted exploitation for the purposes
of the definition of human trafficking;

(2) misdirected itself in rejecting an accepted plausible account of child sexual abuse and domestic
servitude when living with Sam Okoro as not constituting trafficking;

(3) adopted a wrong approach to credibility in focusing on personal credibility rather than the credibility of
the trafficking situations, and in particular failed to consider or apply the guidance in evaluating how expert
evidence may offer valid reasons for inconsistencies, delays and lack of sufficient detail, treated the expert
evidence unlawfully, and treated late disclosure erroneously;

(4) unlawfully imposed a burden to provide corroboration; and

(5) applied the wrong standard of proof, namely the balance of probabilities.

326. As regards ground (5), the judge decided to follow the recently-reported decision of Farbey J in MN,
and counsel agreed not to pursue the point before him, whilst reserving the right to raise it on appeal.

327. As regards ground (1), the argument before the judge appears to have proceeded on the basis that
the “marriage to an older man” to which the CA refers in paras. 172 and 176 of the decision letter – that is,
the marriage for which IXU claims to have been told that the FGM was a preparation – would be a forced
marriage: that is of course what IXU had said on more than one occasion. At paras. 55-59 of his judgment
he considers whether a forced marriage constitutes a form of exploitation within the meaning of article 4 (a)
of ECAT (and thus the NRM). Ms Luh submitted that it necessarily did, relying on a number of materials
which the judge sets out at para. 55. Mr Irwin submitted that it would not necessarily do so: it would
depend on the circumstances of a particular case. The judge accepted Ms Luh's submission, and his
conclusion in that regard is not challenged before us. But he continued, at para. 60:

“The problem faced by the Claimant in this case is not so much whether forced marriage amounts to
exploitation but whether her FGM was 'for the purpose of' a forced marriage. In my judgment the decision
maker was entitled to come to the conclusion that it was not sufficiently established, or sufficiently
proximate. The Claimant's accounts of her understanding were not clear (perhaps unsurprisingly in view of
her age at the time). At their highest they hardly suggest an immediate forced marriage. Rather they
suggest that the FGM was a ritual which would be practised regardless of marriage, although in her culture
it would be expected of any prospective bride. I bear very much in mind that I am not the factfinder, but the
FTT judge was, and she concluded that the Claimant was not going to be forced into a marriage.”

328. Having considered a passage in the Secretary of State's Country Policy and Information Note on
FGM in Nigeria, the judge observed that this merely emphasised that FGM had a cultural significance
which was not restricted to forced marriage and did not undermine the FTT's finding of fact. He added (at
para. 63):

“It is fair to say that the [CA's] decision letter does not engage in this sort of analysis, but simply states that
the necessary element of exploitation has not been made out. However, it is very clear that the FTT
decision is taken as the starting point and the Tribunal Judge's finding is specific. Accordingly I cannot treat
this as an error of law which would justify quashing the decision on this point.”

329. The judge next addressed ground (3), credibility. He started (at paras. 13-25) by summarising the
inconsistencies in IXU's various accounts. He then considered the approach to expert evidence generally.
He noted that the structure of the conclusive grounds decision was that it dealt with expert evidence on two
different bases – first whether the reports reflected directly on the question of credibility, and secondly in


-----

Centre and another intervening) [2020] EWCA Civ 1746

relation to “mitigating circumstances”, meaning, as the judge said, the adjustments to the normal
assessment of credibility necessary to take account of the effect of trafficking on a victim. On the first
basis, he held that the CA's approach was correct in light of the statements in the two reports which
demonstrated that the experts had not considered directly the question of credibility. On the second basis,
he noted that the CA had quoted extensively from the relevant passages in the Guidance. He described
the CA's summary of Dr Sharp's opinion as wholly fair and accurate. He noted Ms Thullesen's view that
IXU's presentation of her account was consistent with the pattern seen in many other trafficking victims, but
he observed that the CA had specifically referred to this passage in her report in its decision. He added
that the CA had correctly identified the problem about her report being that it did not grapple with the FTT's
findings. He concluded (at para. 86) that:

“Looking at the CG letter as a whole, and the way in which the conclusion on credibility is reached in a
structured and incremental manner, I can see no basis for these challenges.”

330. As to ground (4), the judge acknowledged that at one point in the conclusive grounds decision the CA
had used the word “corroboration” when considering whether there was independent evidence to support
IXU's accounts. He conceded that this was an unfortunate word to use and it would have been better to
employ the term “supporting evidence”. He added, however, that it was clear from the context that this was
what the CA had meant. On this point, he concluded (at para. 89):

“Of course any suggestion that supporting evidence is required before an account can be accepted must
be wrong in law (see Mutesi v SSHCD _[2015] EWHC 2476 (Admin) at paragraph [61]). But the CG letter_
does not say this, nor even imply it. In circumstances such as this, where there are multiple untruths, and
changes and additions to the accounts such that credibility is doubted, even after making due allowances
for the guidance and expert evidence, it is reasonable to look to see if there is any supporting evidence. If
none, it is reasonable to conclude that the lack of credibility means that the accounts should be rejected.”

This ground was not pursued before us, but what he says about the term “corroboration” is in line with what
we have said at para. 304 above.

331. Finally, the judge returned to ground (2). He noted that the FTT had concluded that, given IXU's
account of her relationship with Sam Okoro, it was “plausible that a form of abusive relationship existed”.
But he rejected Ms Luh's submission that that finding was inconsistent with the CA's rejection of the
allegation of exploitation by Mr Okoro. This ground is not pursued before us, so we need not summarise
his reasoning.

THE GROUNDS OF APPEAL

332. The amended grounds of appeal in this Court include, as ground (1), the assertion that there was a
misdirection as to the standard of proof. We have already considered this issue. The remaining three
grounds are as follows:

(2) Error of law in finding that IXU was not a victim of trafficking for the purposes of forced marriage (the
_“nexus” point). Under this ground it is argued that, having held, at paras. 57-59 of his judgment that forced_
marriage per se is a form of exploitation within the definition of trafficking under article 4 (a) of ECAT, the
judge was bound to quash the Secretary of State's decision to the contrary and erred in not doing so. He is
also said to have erred at paras. 60-63 by proceeding to substitute his reasons for the Secretary of State's
as to why IXU was not a victim of trafficking for the purposes of forced marriage. In doing so, he is said to
have impermissibly imposed a requirement that the purpose of exploitation must be “immediate” and
“sufficiently established or proximate” to the act and means of trafficking. He is said to have exceeded the
supervisory jurisdiction of the court on judicial review.

(3) _Misdirection in law as to expert evidence. Under this ground, it is argued that in upholding the_
Secretary of State's treatment of expert evidence the judge erred in law in

(a) endorsing the CA's focus on whether the expert evidence directly supported IXU's credibility;


-----

Centre and another intervening) [2020] EWCA Civ 1746

(b) marginalising the experts' reports on the basis that they depended upon accepting IXU's account
where (i) they considered but rejected the suggestion that she was feigning, (ii) case law has established
that experts are not only entitled but expected to express their opinion on the degree to which their findings
support an individual's narrative, and (iii) on any rational view the reports amounted to independent
supporting evidence and commanded weight;

(c) thereby failing to acknowledge the potential of this expert evidence to undermine reliance on the FTT's
determination on the question of credibility.

(4) Error in approach to assessing credibility of a child victim of trafficking. Under this ground, it is argued
that, having acknowledged that IXU was a child at all times during the episodes of claimed exploitation, the
CA erred in failing to assess evidence in accordance with principles that apply to the evaluation of a child's
testimony, and that the deputy judge erred in failing to correct that error. That is said to have
overemphasised the significance of personal narrative, wrongly relied on the FTT's findings, failed to take a
holistic approach, and rejected the account as incredible in the absence of evidence in support, when it is
for the Secretary of State to seek all available evidence and evaluate it in the round.

GROUND (2): “NEXUS”

333. This ground is a challenge to the judge's reasoning at paras. 60-63 of his judgment, which we set out
at paras. 327-328 above. But that reasoning is itself a response to the CA's reasoning in the decision letter
about whether IXU was taken away38 to be circumcised “for the purpose of” exploitation within the
meaning of article 4 (a) of ECAT; and that is where we should start.

334. The CA's reasoning on this point appears in paras. 172 and 176: see para. 323 above. In the first
sentence of both paragraphs it “acknowledged” that IXU claimed that she was told that the FGM was “in
preparation for your marriage to an older man at some point in the future”: as we have noted, it is common
ground that that should be treated as a reference to a forced marriage. However it makes no finding about
whether that claim is true or, which is strictly the relevant question, whether that was indeed the purpose of
subjecting her to FGM. That must be because it believed that it was unnecessary to make such a finding
because there was, as it says in the second sentence, no evidence that such a forced marriage would
constitute either domestic servitude (para. 172) or sexual exploitation (para. 176).

335. As we have seen, the judge found that forced marriage is, necessarily, a form of exploitation, and that
conclusion is not challenged by the Secretary of State. It follows that the CA's reasoning was defective.
What it ought to have done, but did not, is to decide whether the FGM was indeed performed for the
purpose of a forced marriage.

336. The question then becomes whether the judge was nevertheless entitled to dismiss this ground on
the basis of his reasoning in para. 60. On analysis that paragraph appears to contain two distinct strands.
Logically the first is that IXU's account that she was told that she was undergoing circumcision for the
purpose of forced marriage had been implicitly rejected by the CA. The second is that, even if her account
is accepted the forced marriage was not going to be “immediate” and accordingly the purpose was not
“sufficiently proximate”. We take them in turn.

337. As to the first, the judge says at the end of para. 60, and repeats in para. 63, that the FTT made a
specific finding that IXU was not going to be forced into a marriage; and he says that the CA takes the FTT
decision as its starting-point. He evidently had in mind para. 62 of the FTT's decision (see para. 273
above), where the judge says that she did not accept that IXU “has been or will be forced into marriage by
her family”. That is slightly opaquely expressed, but the judge had glossed it at para. 25 (viii) of his
judgment as follows:

“Since it has never been suggested that the Claimant had been forced into marriage, the Tribunal Judge
must have meant she did not accept that the Claimant had been threatened with a forced marriage in the
past, or would be so threatened if you returned to Nigeria.”


-----

Centre and another intervening) [2020] EWCA Civ 1746

It is not clear, but ultimately does not matter, whether the judge is saying that the CA should be regarded
as having implicitly adopted that finding or that it is the finding that it would have made, or in any event
ought to have made, given the weight to be given to the FTT's findings.

338. We see the force of that point. In the end, however, we do not think that the FTT's finding will bear
the weight that the judge puts on it. Apart from that single and elliptically expressed sentence in para. 62,
there is no discussion in the FTT's decision about the purpose of the FGM or, specifically, whether it was
done in preparation for a forced marriage. Such discussion as there is about IXU's evidence about the
FGM relates to whether it was, as she claimed, only partial (so that she was at risk of a further procedure).
That is not particularly surprising, since the issue for the FTT was whether she would be at risk on return
and that was the focus of its findings. We do not think that it was safe for the judge to proceed on the basis
that the CA had implicitly found, or would or should have found, that IXU had never been threatened with
forced marriage in connection with the FGM procedure (or indeed at all, which is what the FTT appears to
have held). Indeed if that is what it believed its reasoning in paras. 172 and 176 would have been
redundant.

339. We turn to the second strand. The judge says at para. 60 that even at their highest IXU's accounts of
what she was told was going to happen to her “hardly suggest an immediate forced marriage”; and that
accordingly the CA “was entitled to come to the conclusion that it [that is, the forced marriage] was not
sufficiently established, or sufficiently proximate”. The phrase “entitled to conclude” suggests that the
judge thought that the CA had indeed found that any forced marriage would not be immediate. The CA's
use in paras. 172 and 176 of the phrase “at some point in the future” suggests that he may be right about
that, though it is very general and there is no supporting discussion. If he is, the next question is whether
that was a finding to which it was entitled to come. Mr Husain challenged the judge's description of IXU's
accounts as not suggesting an immediate marriage.  He referred us in particular to what she had said in
her amended defence statement (para. 266 above), her asylum interview (para. 269) and her history as
taken by Ms Thullesen (para. 286). Those statements are, unsurprisingly, not identical in their details, but
(if they are true) what IXU says that she was told does go further than mere general statements to the
effect that girls have to be cut in order to be fit for marriage: their effect is that once the procedure was
complete the next step would be to give her in marriage. Whether that can be described as “immediate”
depends on what you mean by that term. We can accept that it does not suggest days or weeks,
particularly as there is no suggestion that a husband had yet been identified; but it is not possible to say
more than that.

340. The question then is whether on those facts (if accepted) it can be said that IXU was taken away to
be circumcised “for the purpose of” the intended (forced) marriage. The judge proceeded on the basis that
the connection between the action (taking away) and the purpose (marriage) must be sufficiently
“proximate”.  Mr Husain submitted that to impose such a requirement was an unwarranted gloss on the
language of article 4 (a). It was sufficient if the family members who performed the FGM did so with a view
to IXU being subjected to forced marriage in the future. Mr Irwin submitted that the judge's approach was
right. He argued that if every act or experience which was, or might be, preparatory to an act of
exploitation were to bring an individual into the definition of trafficking, that would render the definition so
broad as to be practically useless. The correct principles were that:

(1) any act of exploitation must be closely linked to the other acts which make up the elements of the
trafficking definition;

(2) an application of the definition of trafficking which allows experiences which are disparate in time to be
shoehorned together into a trafficking case risks broadening the definition of trafficking until it is rendered
hopelessly broad;

(3) where the line is to be drawn is a question of fact and degree to be decided in each case.

As regards (2), he pointed to a survey referred to in the Country Policy and Information Note on FGM in
Nigeria which concluded that 18.4% of women in that country reported having undergone FGM. If the
infliction of FGM together with a cultural expectation that a woman or girl will marry as directed by relatives


-----

Centre and another intervening) [2020] EWCA Civ 1746

or her broader community was sufficient to meet the trafficking definition, that would render the definition
so wide as to be practically impossible to administer.

341. This is what was labelled “the nexus issue”, the essential question being what degree of nexus there
should be between the action relied on by IXU and her intended forced marriage. It is not an issue which
may arise very often in practice, since typically where a child (or indeed an adult woman) is subjected to
FGM for the purpose of a forced marriage the marriage will happen, in which case that will involve
trafficking in its own right. It was also only of real significance in the present case because the CA had
rejected IXU's account of being trafficked by Sam Okoro and/or Ma.

342. In our view only limited general guidance can be given on the nexus issue. The concept of “purpose”
must be applied as a matter of ordinary language and common sense, having regard to what may
reasonably be supposed to be the intended scope of ECAT: in that regard there is real force in Mr Irwin's
second principle, though we should not be taken to be endorsing its precise wording. Taking that approach
to a case involving FGM (or, more accurately, taking a child away to be subjected to FGM39), we accept
Mr Irwin's submission that it is necessary to assess the degree of the connection between the performing
of the FGM and the intention (if proved) to force the child into marriage in any particular case. It is easy
enough at either extreme. If, say, the intended husband had said that he wanted to marry the child in
question but that she must undergo FGM first, it would be a natural use of language, and in accordance
with the aims of ECAT, to describe the FGM (or, rather, any associated taking away) as being for the
purpose of the forced marriage (which, as already established, constitutes exploitation). At the other
extreme, if the evidence were only that in a particular culture (1) girls were routinely taken away and
subjected to FGM at a young age in order to render them marriageable40 and (2) girls and women are
generally given no choice about who they have to marry, we do not think that that it would be natural to
describe the FGM, or the taking away, as being done for the purpose of exploitation. In between those two
extremes there will be a wide variety of circumstances, and it would not be appropriate for us to offer
guidance divorced from the particular facts found. The distinction between the two cases could be
characterised in terms of the degree of proximacy (the judge's term) or closeness (Mr Irwin's) of the act to
the intended exploitation; but we are wary of introducing glosses of this kind which may distract decisionmakers from the language of article 4 (a) itself. We certainly think that it is dangerous to substitute a test of
“immediacy”: the distance of time between the act and any possible future exploitation will be relevant to an
assessment of whether the one is done for the purpose of the other, but it cannot be the touchstone.

343. Taking that approach, the only question for us is whether the judge was right to say that, even taking
IXU's evidence at its highest, the act of taking her away to be circumcised could not naturally be described
as being for the purpose of subjecting her to a forced marriage. We do not believe that he was. The case
may be near the borderline, but we believe that the decision is one which required a proper assessment by
the CA as the designated fact-finder. It is accordingly necessary for the issue to be remitted to it.

GROUND (3): EXPERT EVIDENCE

Submissions

344. The CA's treatment of the expert evidence in IXU's case is not as obviously unsatisfactory as in MN's.
There is no equivalent to the numerous particular errors in the criticisms of the expert reports which we
identify in her case. Instead of the expert evidence being effectively discounted altogether, it is described
at para. 68 as being “only of limited value” as regards credibility; and at paras. 143-146 some reasons are
given for why Ms Thullesen's evidence about the effect of being trafficked on a victim's ability to give a
complete and consistent account did not afford adequate “mitigation” in the particular circumstances of
IXU's case. Nevertheless, we have come to the conclusion that the CA did indeed fail to give proper
weight to the expert evidence, essentially for the reasons pleaded. In view of what we have already said,
we can state our reasons briefly.

345. The essential point is that the errors in the CA's reasoning on the relevance of the expert evidence to
IXU's credibility, as identified at paras. 308-311 above, in our view led it to discount altogether the respects


-----

Centre and another intervening) [2020] EWCA Civ 1746

in which it was potentially supportive of the truth of her account which we identify at paras. 292-295 above.
Although it uses the phrase “little value”, there is in truth no sign that it considered any of those points at all
when assessing the various disputed elements in her narrative. As Mr Husain submitted, its approach did
indeed marginalise the expert evidence.

346. We accept of course that even if the CA had given due weight to the expert evidence which
supported IXU's case, and which potentially explained some of the difficulties in her account (“mitigating
circumstances”), it might have come to the same conclusion. But we are not satisfied that that would
necessarily have been the case. The grounds of IXU's appeal did not involve a detailed review of the
difficulties in IXU's account which led the CA to reject it, and we are not in a position to comment on their
cogency. It is, we think, sufficient for our purposes that the FTT, while rejecting important aspects of IXU's
overall account, nevertheless described it as “plausible” that IXU had been in an exploitative relationship
with an older man in Nigeria and said that she had suspicions that she had been trafficked to the UK: see
para. 275 above. That is, as the judge pointed out, not the same as a finding; but it does mean that we
should not be prepared to hold that the failures which we have found in the CA's approach to the expert
evidence were immaterial.

347. It is probably correct, as Mr Husain submitted, that in this case too the CA can be described as
having fallen into the Mibanga error. But we would emphasise that the problem is not about the particular
part (or in this case parts) of the decision letter in which the expert evidence was considered: see para. 108
above. As Mr Irwin submitted, the analysis of the expert reports was included in the section of the report
relating to credibility, which was the fundamental issue in the claim. But the problem is substantive: the
approach that the CA took meant that it did not feed the opinions of the experts into its assessment of the
credibility of IXU's account because it had (wrongly) determined that they were of little weight.

348. It follows that we respectfully disagree with the judge's conclusion, including his observation that the
problem with Ms Thullesen's report was that it did not grapple with the FTT's findings and his conclusion
that there was no basis for the appellant's challenges. We do not find his analysis of the structure of the
CA's decision – referring to the two bases on which the expert evidence was considered – meets the force
of the appellant's criticism as to the overall approach of the CA to that evidence. Accordingly, we uphold
this ground of appeal.

GROUND (4): CREDIBILITY OF A CHILD VICTIM OF TRAFFICKING

349. In view of our conclusions on the two previous grounds of appeal, we do not propose to deal with this
ground in any detail.

350. The ground is based on two passages in the Guidance, at pp. 46 and 47, which read:

“Children who are in a trafficking situation are often very reluctant to give information, and often relate their
experiences in an inconsistent way or with obvious errors.

…

In some cases, a potential victim of modern slavery may have been a victim as a child, but only identified
and referred into the NRM after reaching adulthood. In these circumstances, the Competent Authority
should treat the potential victim as having been a child at the time of the **_modern slavery incident and_**
follow the guidance covering children within the NRM decision-making process. This means assessing the
case as if they were a child to make a reasonable grounds and conclusive grounds decision.”

Mr Husain says that since on any view IXU was a child when she underwent FGM and for much of the time
that, on her account, she was being exploited by Sam Okoro those passages mean that the CA should
throughout have been particularly careful about drawing adverse conclusions about her credibility from
inconsistencies in her accounts of those episodes. He says that the decision letter nowhere alludes to this
consideration and that it does not show any sign of applying particular caution.

351. Mr Irwin, as we understood him, accepted that the CA should in assessing the account given by a
potential victim of trafficking of events that occurred when they were a child take into account the difficulties


-----

Centre and another intervening) [2020] EWCA Civ 1746

that a child may have in understanding events, and the different perceptions that they may have of them,
and the effect that this may have on the cogency of their evidence – quite apart from the fact that the
events may have been traumatic and have happened many years ago. In any event that seems to us to be
plainly correct. He did not, however, accept that in evaluating the account of an adult potential victim of
trafficking it was necessary to treat their evidence as if, contrary to the fact, they were still children, simply
because some of the events which they describe occurred when that was the case; and he said that that
was not the effect of the passages in the Guidance.

352. We are bound to say that this debate seems more theoretical than real. Any decision-maker in such
a case should as a matter of common sense when assessing the accounts given by a potential victim of
trafficking take into account both their age at the time when their accounts were given and their age at the
time of the events which they narrate. But it will be difficult to isolate the weight to be given to those
considerations as distinct from other considerations, which will include (as we have said) the potential
impact of any traumatic events described on how coherently and consistently they are recounted, and of
course their inherent plausibility, their consistency with such objective evidence as there may be and so
forth. Given that IXU's case is to be remitted in any event we see no value in attempting to discern to what
extent the CA may or may not have given sufficient weight to the “age factor”.

DISPOSAL

353. It follows that we will allow IXU's appeal on grounds 2 and 3, though not on ground 1, and quash the
CA's decision, with the result that her application will have to be determined afresh by a different decisionmaker.

**End of Document**


-----

