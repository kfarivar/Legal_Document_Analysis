# DUNSHOU HE Petitioner against SECRETARY OF STATE FOR THE HOME
 DEPARTMENT Respondent [2018] CSOH 103

OUTER HOUSE, COURT OF SESSION

Lord Armstrong

Petitioner: Forrest; TLT LLP

Respondent: Maciver; Office of the Advocate General

02 November 2018

**Lord Armstrong**

[1]     The petitioner is a Chinese national who seeks reduction of a decision of the respondent, dated 1 March
2018, to the effect that there are no reasonable grounds to suspect that the petitioner is a victim of human
trafficking. That decision was made on the basis that, _inter alia, the inconsistencies between the petitioner's_
differing accounts were such that his credibility was so undermined that his claim to have been trafficked could not
be accepted.

[2]     The petitioner's claim was that he had fled China in order to escape the authorities whom he feared would
persecute him because they suspected him of having breached the State's one child policy. He had approached a
person (Aming) who undertook to assist his escape to Europe on the basis that, once there, he would work for
Aming in order to pay off his travel costs of about £36,000. Once in Ireland, he claimed to have been under the
control and direction of Aming, and to have been forced to work in a number of Chinese restaurants.
**The legal context**

[3]     On 17 December 2008, the UK ratified the Council of Europe Convention on Action against Trafficking in
Human Beings. By virtue of Article 4(a) of the Convention, and the 2000 Palermo Protocol, ratified by the UK on 9
February 2006, “human trafficking” is defined as:

“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having
control over another person, for the purpose of exploitation. Exploitation shall include, at a minimum, the
exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or services, slavery
or practices similar to slavery, servitude or the removal of organs.”

[4]     It is generally accepted, and was accepted by the parties that the essence of human trafficking comprises:

“(a) An action – the person has been subject to the act of recruitment, transportation, transfer, harbouring or
receipt – which is achieved by

(b) a means – the threat or use of force or other form of coercion, of abduction, of fraud, of deception, of
abusive power, of a position of vulnerability, of giving or receiving payments or benefits to achieve the consent
of a person having control over another person – for the purpose of


-----

(c) exploitation – sexual exploitation, forced labour or services, slavery or practices similar to slavery,
servitude, forced criminality or the removal of organs.”

[5]     Against that background, the National Referral Mechanism (“NRM”) operates by way of a three stage
process. First, it is open to the police, in their capacity as “first responder” to refer a case of suspected human
trafficking to a Competent Authority, and request that it assess whether there are reasonable grounds to suspect
that a person has been a victim of human trafficking. The respondent is such a Competent Authority. Second, the
Competent Authority conducts a Reasonable Grounds test, designed to act as a filter to identify potential victims.
Third, in the event that the Competent Authority concludes that there are reasonable grounds to suspect that a
person is a victim of human trafficking, then a substantive Conclusive Grounds decision, as to whether the person is
in fact a victim, is taken. If at the second stage, the Competent Authority concludes that there are no reasonable
grounds for suspicion, then no further action is taken.

[6]     The decision challenged by the petitioner in this case is that made by the respondent at the second stage.
For the purposes of that second stage decision, the test which the Competent Authority must apply is:

“Whether the statement 'I suspect but cannot prove' (the person is a victim of human trafficking in Scotland and
Northern Ireland, or the person is a victim of **_modern slavery which includes human trafficking or slavery,_**
servitude or forced or compulsory labour in England and Wales):

   - is true

  - whether a reasonable person having regard to the information of the mind of the decision maker, would think
there are reasonable grounds to believe the individual has been a victim of human trafficking or **_modern_**
**_slavery.”_**

[7]     The Home Office document: “Victims of modern slavery – Competent Authority guidance”, 21 March 2016,
provides guidance as to how, for the purposes of a Reasonable Grounds decision, the Competent Authority should
assess credibility. In particular, the document includes the following passages:

“In assessing credibility the Competent Authority should assess the material facts of past and present events
(material facts being those which are serious and significant in nature) which may indicate that a person is a
victim of human trafficking or modern slavery. It is generally unnecessary, and sometimes counter-productive,
to focus on minor or peripheral facts that are not material to the claim.”;

“The level of detail with which a potential victim presents their claim is a factor when the Competent Authority
assesses credibility. It is reasonable to assume that a victim giving an account of their human trafficking or
**_modern slavery experience will be more expressive and more likely to include sensory details (for example_**
what they saw, heard, felt or thought about an event) than someone who has not had this experience.”; and

“Competent Authority staff need to know about the mitigating circumstances which can affect whether a
potential victim's account of human trafficking or modern slavery is credible.

When the Competent Authority assesses the credibility of a claim, there may be mitigating reasons why a
potential victim of human trafficking or modern slavery is incoherent, inconsistent or delays giving details of
material facts. The Competent Authority must take these reasons into account when considering the credibility
of a claim. Such factors may include, but are not limited to, the following:

   - trauma (mental psychological, or emotional)

   - inability to express themselves clearly

   - mistrust of authorities

   - feelings of shame


-----

   - painful memories (including those of a sexual nature).”

**The basis for the decision**

[8]     The respondent assessed the credibility of the petitioner by reference to the inconsistencies apparent in
differing accounts given by him, viz, inter alia:

(a)   when first interviewed by an Immigration Officer, on 15 November 2017, the petitioner advised that
he had a wife and a 20 year old son in China, and that his parents also lived there. Subsequently, on 18
January 2018, he advised British Transport Police that his wife had left him and no longer lived in China
and that he had three children remaining who were looked after by his father, as his mother had died while
he had been in the UK;

(b)   he claimed to be completely under the control of Aming, but also stated that he had attended a
Chinese Embassy and had obtained a passport, contrary to what might be expected of a person wanted by
the Chinese Government;

(c)   on 15 November 2017 he had indicated that he had travelled to the UK by a flight from China to
Paris, and then, by another, from Paris to London. On 18 January 2018, he advised, rather, that he had
travelled from China to Hong Kong by car, had climbed mountains and, from an airport there, had flown to
France, and then onward to Ireland in a container on a boat.

[9]     Before me, counsel for both parties adopted their Notes of Argument, which together with the oral
submissions made at the Bar, I have taken into account in what follows:
**The submissions for the petitioner**

[10]     First, the respondent had failed to apply the correct standard of proof. Reference was made to the Home
Office guidance as to the test to be applied. The formulation “I suspect, but cannot prove” was a much less stringent
test than proof beyond reasonable doubt or proof on the balance of probabilities. By assessing the petitioner's
credibility as he had, the respondent had applied the relevant test too vigorously in respect of the four remaining
grounds of challenge.

[11]     Second, the decision revealed a fundamental misunderstanding of the facts relating to how, and when, the
petitioner travelled from China. Although the petitioner's position was that he had left China in about 2007/08, it was
noted in the decision that he came to the UK at that time. That noted date of the petitioner's arrival in the UK was
factually incorrect, and represented an initial error which then pervaded the entire decision. The country which had
been his first destination had been Ireland and not the UK, as repeated elsewhere in the decision where the
petitioner's claim to have moved from Ireland to the UK in April/May 2017 was recorded, and as was consistent with
the content of his interview on 18 January 2018. The effect of that fundamental misunderstanding was to undermine
the whole decision.

[12]     Third, in the context of the Convention definition of “human trafficking” which involved (a) “an action”, (b)
“a means”, and (c) “exploitation”, the respondent had fallen into error by characterising the petitioner as having
“willingly” travelled to Ireland and the UK. Such a description was not justified in circumstances where the
petitioner's true position was that he had been deceived into travelling to Ireland and exploited by what
subsequently became apparent as being subject to forced labour.

[13]     Fourth, in assessing the petitioner's credibility, the respondent had fallen into error by attaching undue
weight to inconsistencies in the petitioner's account. In doing so, the respondent had failed to follow the relevant
Home Office policy guidance to the effect that:

“it is generally unnecessary, and sometimes counter-productive to focus on minor or peripheral facts that are
not material to the claim”.

[14]     The inconsistencies in the petitioner's account which the respondent had founded upon in assessing his
credibility, which related to the facts surrounding (i) the death of his mother, (ii) the extent to which, if at all, he had
been under the control of another, (iii) whether he had first entered the UK or Ireland, (iv) the manner in which the


-----

business he was engaged in was managed, (v) his medical condition, (vi) his dealings with certain phone numbers,
(vii) the cost of his journey from China, and (viii) the extent to which he was in fear for his life, were of that type.

[15]     Further, the implicit assumption that the petitioner could not be a victim of human trafficking but, rather,
had had some control over his situation, as, for example, by having attended the Chinese Embassy, was not
justified. The respondent had failed properly to determine the true factual position, and had failed properly to take
into account the need to understand “the many subtle ways an individual can fall under the control of another” (CN v
_United Kingdom (2013) 56 EHRR 24, at paragraph (80))._

[16]     Fifth, in assessing the petitioner's credibility, the respondent had failed to take into account mitigating
reasons which might explain inconsistencies in his accounts. There was a need to take into account such matters
which served as general indicators for human trafficking, such as (i) expression of fear or anxiety, (ii) conduct as if
instructed by another, (iii) restriction of movement, (iv) limited contact with family, and (v) ignorance of relevant
addresses, and others which served as indicators of forced or compulsory labour, such as (i) withholding of wages,
(ii) dependence on employer, (iii) imposed place of accommodation, and (iv) deception.

[17]     Having regard to all of these factors, the respondent, by applying an undue standard of proof and
attaching insufficient weight to the low threshold of the relevant test, had erred by failing to conclude that there were
reasonable grounds for suspecting that the petitioner was a victim of trafficking.
**Submissions for the respondent**

[18]     First, the respondent had applied the correct test, as was expressly stated on the last page of the
decision, viz:

“In summary, based on the information available, it is considered that you do not meet the three constituent
elements of the trafficking definition on account of your adverse credibility and therefore, it is not accepted to
the low standard of proof, 'I suspect but cannot prove', that you were trafficked from China to Ireland or within
the UK for the purpose of forced labour or forced criminality.”

[19]     Second, it was in fact the case that the petitioner had given two conflicting accounts in relation to the detail
of his travel from China. It was accepted and noted in the decision, as recorded at his interview on 18 January
2018, that he had been in Ireland for some ten years before travelling latterly to the UK, but, equally, when
interviewed earlier, on 15 November 2017 following his arrest, he had indicated that he had flown from China to the
UK, via Paris.

[20]     Third, whether the petitioner was in fact in a vulnerable position was something the respondent was not
able to ascertain. The question was whether, applying the appropriate test, there was room for suspicion that the
three aspects of the accepted definition of “human trafficking” were met. In that regard, in considering whether the
petitioner had been subject to forced transportation, the description in the decision that the petitioner had “willingly”
travelled from China was an accurate reflection of the detail of his claim. On his own account, the petitioner had
actively sought out the agent who could facilitate his travel. That he had travelled willingly was a legitimate
conclusion for the respondent to have reached. Upon that basis, one of the three branches of the relevant definition
was not met.

[21]     Fourth, the detail of the assertion that the respondent had erred by attaching undue weight to the recorded
inconsistencies between the petitioner's accounts amounted only to disagreement with the respondent's resulting
conclusion. Although it was necessary to recognise that there were subtle ways to exert control over another, the
respondent's conclusion, from the fact that the petitioner had attended the Chinese Embassy voluntarily, was not
unreasonable. In drawing the conclusion reached in the decision, it was not necessary for the respondent to
ascertain the true underlying factual position. The respondent was entitled to draw appropriate inferences from the
several recorded examples of significant inconsistencies in the petitioner's accounts.

[22]     Fifth, expressly, in terms of the decision, the respondent had considered whether there were any relevant
mitigating factors and had concluded that there were none. As the Competent Authority, that was a conclusion
which the respondent was entitled to reach on his own assessment of the position. Reliance on indications


-----

identified by the police at the first stage of the NRM amounted to no more than disagreement with the respondent's
own findings in that regard.
**Decision**

[23]     For the reasons advanced on behalf of the respondent, I am not persuaded that the decision under
challenge should be reduced on the submitted grounds of irrationality or inconsistency. I find, rather, that the
respondent was entitled to assess the petitioner's credibility as he did, when considering whether, in the petitioner's
case, applying the correct test to the relevant and accepted definition, there was scope for suspicion that he had
been a victim of human trafficking. Given the nature of the relevant test, there was no requirement on the
respondent to ascertain the true factual position. I am satisfied that there was adherence to the relevant Home
Office guidance.

[24]     The inconsistencies concerned, which bore, for example, on the detail of (i) the petitioner's name, (ii) the
composition of his family, (iii) the route of his travel from China, (iv) the timing of his arrival in the UK, (v) his
medication, and (vi) the circumstances of his claimed control by others, were, viewed in their cumulative effect,
significant matters which the respondent was entitled to take into account. Assessing the whole matter in the round,
I find that, the decision, which is comprehensive in its terms, extending to ten pages, provides adequate, cogent,
and rational reasons. On the basis of the information available to him, the conclusion reached by the respondent
was one which was legitimately open to him, and one which he was entitled to reach.

[25]     Accordingly, I repel the petitioner's plea-in-law, sustain the respondent's third plea in-law and refuse the
petition. I reserve, meantime, all questions of expenses.

Crown Copyright

**End of Document**


-----

