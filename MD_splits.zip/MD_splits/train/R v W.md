# R v W [2023] EWCA Crim 803

Court of Appeal, Criminal Division

Carr LJ, Jay J, Sir Nigel Davis

29 June 2023Judgment

MR B DOUGLAS-BROWN KC & MR J ROBOTTOM appeared on behalf of the Applicant.

MR A JOHNSON appeared on behalf of the Crown.

_________

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**JUDGMENT**

LADY JUSTICE CARR:

1. We make an anonymity order in this case in order to protect the interests of the proper administration of
justice. We bear in mind that the normal rule is open justice, but an anonymity order, on the facts of
present case, is strictly necessary, pursuant to the principles identified in R v AFU _[[2023] EWCA Crim 23 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_

[1]. The risk to the applicant of being re-trafficked for criminal exploitation is real, and such an order is
consistent with and so does not risk undermining anonymity orders made in respect of the applicant in
other legal proceedings.

**_Introduction_**

2. This is a renewed application for leave to appeal against conviction alongside applications to adduce
fresh evidence and for an extension of time of some eight years. On 9 April 2014, the applicant was
convicted, following trial in Cardiff Crown Court before HHJ Richards and a jury, of conspiring to secure the
avoidance or postponement of enforcement action by deception (a substantive offence under section 24A
of the Immigration Act 1971), contrary to section 1(1) of the Criminal Law Act 1977. She was sentenced to
two years' immediate imprisonment.

3. The matter has a complex factual and procedural history. The renewed application came first before the
Court on 14 March 2023, when the matter was adjourned in order, amongst other things, for the
respondent to attend and make representations. At that stage the respondent was resisting the application.

4. During the adjournment period the respondent has reconsidered its position in the light of recent case
law and the arguments have narrowed considerably Now although there remains disagreement as to the


-----

precise correct analytical approach to be taken, it is common ground between the parties that, one way or
another, the applicant's conviction is unsafe. It remains, of course, for us to be satisfied this is the case.

**_The Facts_**

5. We need only summarise the facts. The detail can be found in the judgment of Underhill LJ in R (MN &
_Or) v Secretary of State for the Home Department_ _[2020] EWCA Civ 1746; [2021] 1 WLR 1956, at [6] and_

[257] to [323]. The applicant arrived in the United Kingdom from Nigeria on 30 July 2012, on a student visa
valid until 13 July 2013, with the applicant enrolled on a course in hospitality and tourism in London. On 22
March 2013 she and a man named Karoly Farkas (KF), a European national aged 43, went to City Hall in
Cardiff to register their intention to marry. They saw the Superintendent Registrar who asked them
questions about the proposed marriage. The applicant provided information and documentation, including
a birth certificate giving a date of birth of 27 October 1988, making her 24 years old at the time. She and
KF gave a residential address in Newport. The applicant produced a Nigerian passport and KF a
Hungarian one. Newport Registry Office was specified as the wedding location and a wedding date of 9
April 2013 was set.

6. The Superintendent Registrar had become suspicious about the couple and reported them to the Home
Office. When the applicant and KF attended the wedding location on 9 April, they were apprehended and
interviewed under caution. The applicant gave an account that the proposed marriage was genuine. She
had met KF in a nightclub. They had started calling each other and in December 2012 began living
together. He had proposed to her in February 2013. Immigration officers attended the Newport address
that they had given as their residence but found the address to be occupied by another man and not the
applicant and KF.

**_Trial and Conviction_**

7. The applicant was treated as an adult and tried alongside others including, so far as relevant, KF. The
prosecution case was that the proposed marriage was a sham, planned in order to enable the applicant to
reside in the United Kingdom permanently by reason of marriage to a European national. Evidence was
adduced to the effect that her birth certificate had been false.

8. In her first Defence Statement, in June 2013, the applicant asserted that her relationship with KF was
genuine. However, in a second Defence Statement, served in early February 2014, the applicant stated
that she was in fact born in 1997, was 15 years old when she met KF and did not want to enter into a
relationship with him. This set in train a series of correspondence, commencing with a letter dated 12
February 2014 in which the prosecution invited the applicant's solicitor, amongst other things, to arrange an
age assessment. Details of a social worker who could assist were provided. It does not appear that that
invitation was followed up; rather the applicant's legal team at the time took the view that the commission of
an age assessment was something for the prosecution, and not the defence. All that appears to have
happened is that the defence legal team responded to the prosecution, indicating that it was not for the
defence to have commissioned an age assessment but rather the prosecution could undertake one if they
needed to, and that the applicant was agreeable to such an assessment. No age assessment in the event
took place.

9. At around the same time, in March 2014, the applicant's solicitor passed the applicant's complaints of
multiple rapes by KF, as set out in her second Defence Statement, on to her prison police liaison officer. It
is not clear what happened to those complaints; but what is clear is that they were never taken up in terms
of any criminal process or further investigation.

10. At trial the applicant's case was that the marriage was a sham, but not because she wanted to evade
immigration enforcement action; rather it was because she was being threatened by KF and felt that she
had no alternative but to go along with his wish to marry her. Her true date of birth was 27 March 1997,
making her only 17 years old at trial. She had just turned 16 in April 2013. A second yellow birth certificate
was genuine, as was her passport. She accepted that she did not live at the given Newport address. She
gave evidence as to how she had run away from home in Benin city at the age of nine because of the risk
of female genital mutilation (“FGM”) She had stayed with an older man Sam Okoro for some six years


-----

He had sex with her, although he also taught her to read and write. When she was 15, he helped her to
leave the country. He obtained the false birth certificate which showing her to be older than she was. He
paid for her flight and half of her college fees. When she arrived in this country, she had no
accommodation and was on her own. A friend allowed her to stay at an address in London. She had an
older sister who lived in Leicester. When visiting that sister, she had met KF whilst walking from a bus
station and ended up going to his home. He had forced himself upon her sexually and made threats to kill
her and her sister. Out of fear she had stayed with him. They had discussed marriage. He told her that he
had a friend in Newport where they could get married. He had authority over her, and she had to do what
he said. He took her to the Cardiff Registry Office. She had done everything because he wanted it, under
threats, and because he had said that otherwise he would kill her sister. She had not agreed to marry him
in order to improve her chances of staying in the United Kingdom.

**_Events following conviction and fresh evidence_**

11. Following sentence and having been served with Notice of Liability to Automatic Deportation, the
applicant made an asylum claim. That was refused and she appealed unsuccessfully to the First-tier
Tribunal. In the context of that appeal, she gave an account which led to a referral to the National Referral
Mechanism (“NRM”) in June 2015. An age assessment carried out that year found her date of birth to be
as she had claimed, namely 27 March 1997. In December 2016, it was found that there were reasonable
grounds to believe that she was a victim of trafficking (“VOT”). In February 2018 however, a conclusive
grounds decision held that that was not the case. The applicant commenced proceedings for judicial review
against that decision, which ultimately succeeded in the Court of Appeal in December 2020 (see the
decision in R (MN & Or) to which we have referred above).

12. On reconsideration, it was then accepted in a Conclusive Grounds Decision of September 2021, that
the applicant had been a victim of modern slavery as follows: sexual exploitation in Nigeria between 2006
and 2012; sexual exploitation and domestic servitude in the United Kingdom during 2012 and 2013; forced
criminality in the United Kingdom during 2013. The applicant's date of birth was again accepted as being
27 March 1997.

13. There are available a number of medical reports dated between November 2016 and 2022, addressing
the applicant's psychiatric and psychological condition, together with a statement from her.

14. The matters that we have identified in this section are all the subject of the application to adduce fresh
evidence under section 23 of the Criminal Appeal Act 1968. That application and the application for an
extension of time are supported by a witness statement from the applicant's solicitor dated 2 August 2022.
The statement contains, amongst other things, an outline chronology of events since the solicitor's
instruction in May 2019.

**_Grounds of Appeal and Response_**

15. In overview it is said that the applicant committed the offence against a background of being subject to
the threat of FGM, rape and violent abuse in Nigeria as a child. She was then trafficked or smuggled to the
United Kingdom and trafficked through exploitation in which she was subject to forced prostitution and
criminal activity - at all material times remaining a child. Yet, and although the applicant had said at the
time in terms that she was a minor, the defence took no steps to obtain or secure a formal age assessment
and no one made any inquiry as to whether the applicant should be referred as a possible VOT. She was
not advised about human trafficking or modern slavery law or of the possibility of a referral to the NRM.

16. It is now clear, it is said, that the applicant was targeted by KF for the purpose of criminal and child
sexual exploitation. This was against a background of **_modern slavery. If what is now known about the_**
applicant's status as a VOT had been known at the time, the Crown Prosecution Service would or might
well have not prosecuted her. These submissions are strengthened, it is said, by virtue of the fact that the
applicant was a child. Thus, the prosecution was an abuse of process and the conviction unsafe.

17. Mr Johnson sets out the respondent's revised position as revised:


-----

i) In the light of what is now known, the prosecution would have accepted at trial that the applicant was,
when arrested, 16 years old.

ii) The prosecution would not have accepted her account of her relationship with KF, in particular that she
was coerced to marry him. It would have remained the prosecution case that she sought to marry KF in
order to regularise her immigration status.

iii) The proceedings below do not fall to be treated as an abuse of process on the basis that the applicant
was a VOT. The real issue is whether the fresh evidence undermines the jury's conclusion that the
applicant was party to the conspiracy. It is said that it does not. If there is no basis to go behind the jury's
verdict then the proceedings cannot, it is said, be an abuse of process on trafficking grounds.

iv) However, the respondent recognises that even whilst maintaining its case as set out above, what is
now known is that the applicant was a victim of prior exploitation, who was 16 years old at the time she
sought to marry KF. Had that been known at the time she would not have been prosecuted on public
interest grounds.

18. Mr Douglas-Jones KC, for the applicant, accepts that the applicant's conviction is unsafe for the
reasons identified by the respondent. But in the alternative, he submits that the conviction is unsafe by
reason of the abuse of process doctrine as it applies to VOTs. This is, he suggests, an orthodox VOT
abuse of process appeal. It is irrelevant that it follows a conviction following trial or that the applicant gave
evidence at trial. The question, namely whether it was fair to try the applicant, remains the same. The real
issues are whether the conviction is safe by reference to breaches of the non-prosecution principles under
the relevant international and regional instruments, breaches of the Crown Prosecution Service Guidance
and failures by the applicant's lawyers, whether it was fair to try the applicant and whether this is a case in
which the prosecution would or might well not have been maintained. Further, the prosecution of a child as
an adult itself rendered the trial process unfair.

**_Analysis_**

19. The applicant's conviction predated the advent of the **_[Modern Slavery Act 2015 but not the United](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
Kingdom's international obligations under the Palermo Protocol, the Council of Europe Convention on
Acting Against Trafficking in Human Beings and the EU Directive 2011/36 on preventing and combating
trafficking human beings and protecting its victims.

20. The relevant principles relating to abuse of process and the context of offending predating the Act can
be found in AFU (supra) at [105] to [113]. One way of formulating the relevant question is to ask whether
the applicant would or might not have been prosecuted in the public interest. If the answer is “yes”, then
the proper course is to quash the conviction.

21. The common ground here is:

i) There was a failure to identify the applicant as a VOT, albeit the respondent does not accept that she
was a victim at the hands of KF.

ii) There was a failure to identify the applicant as 15 years old at the beginning of the alleged conspiracy,
and only just 16 at the end of it.

iii) There was a failure by the respondent to comply with the Crown Prosecution Guidance as it applied at
the time.

iv) That, had these failures not occurred, the prosecutorial decision would have been not to prosecute on
the grounds of public interest.

22. The respondent is right to note that this is not a typical case where it is common ground that an
offence was committed, and the question is whether there is a nexus and, if so, to what extent between the
trafficking and the commission of the offence. For here, the applicant denies having committed any offence
whatsoever. The jury, properly directed, and after hearing from the applicant in the witness box, rejected
that denial.


-----

23. Against that the applicant can suggest that it is wrong to proceed by reference only to the jury's verdict
following trial, when that trial provided neither the requisite safeguards for a child or a (child) VOT.

24. We do not consider it necessary for present purposes to resolve the narrow legal dispute between the
parties as identified above, namely whether the application falls to be assessed by reference to trafficking
grounds or by reference only to public interest grounds. The position is that it is now accepted that the
applicant was only 17 years old at the time of her conviction and just 16 at the time of her attempt to marry
KF set against a history of prior exploitation. The prosecution concedes that, in the light of this
understanding, the applicant would not have been prosecuted on the basis that such a prosecution would
not have been in the public interest.

25. This seems to us to be an entirely realistic and appropriate concession on the particular facts of the
case. The decision that it was in the public interest to prosecute was made on the basis that the applicant
was an adult. There is no evidence that receipt of the applicant's second Defence Statement led to any
meaningful reconsideration of public interest or, most essentially, any meaningful further inquiry into her
true age. Had the full picture been known, the prosecution would have been aware that it was considering
the prosecution of a child who had been previously exploited and who had sought to enter into a marriage
with a 43-year-old man. It would also have been aware that the child had done so in circumstances where
the legal requirement for consent to marriage had not been met, and where any sexual activity, even if
consensual, that had occurred at any time up until very shortly before the intended marriage date would
_prima facie have involved the man in committing an offence contrary to section 9 of the Sexual Offences_
Act 2003. Prosecution would not have been in the public interest.

26. The general principle that decisions to prosecute are ordinarily for the prosecutor is an important one
(see for example _R (Barons Pub Ltd) v Staines Magistrates' Court [2013] EWHC 898 Admin, at [51(i))]._
However, in circumstances where, as set out above, the respondent has itself concluded that the public
interest test was not met, there can be no question that a judicial decision to the same effect would offend
it. This is therefore one of those very rare cases where, despite the applicant's conviction following trial, we
conclude that her conviction is unsafe.

**_Conclusion_**

27. For these reasons and in these circumstances, we consider it to be in the interests of justice to extend
time and to grant leave together with permission to adduce the fresh evidence. The conviction is unsafe,
and we quash it accordingly.

28. Finally, we express our thanks to Mr Douglas-Jones and Mr Johnson for their able assistance in this
matter.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

