# R v Henry-Smith [2022] EWCA Crim 1674

Court of Appeal, Criminal Division

Macur LJ, Cutts J, Ellebogen J

9 December 2022Judgment

MR A MORRIS appeared on behalf of the Applicant.

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

1. MRS JUSTICE ELLENBOGEN: This is a renewed application, made 261 days out of time, for leave to
appeal against sentence, and for the requisite extension of time in which to seek it. We have had the
benefit of submissions from Mr Andrew Morris, who appears pro bono and did not appear below including,
de bene esse, as to the substantive merit in the proposed grounds of appeal.

**_The Facts_**

2. The applicant, Mr Henry‑Smith, was one of four defendants convicted by a jury of conspiracy to commit,

respectively, robbery (count 1) and grievous bodily harm with intent (count 2), on 22 July 2021. On 24
August 2021, he pleaded guilty to a separate and unrelated offence of wounding with intent. A further
offence was ordered to lie on the file. He was sentenced for all three offences on 29 October 2021,
receiving an extended determinate sentence of 17 years' detention, of which the custodial period was 12
years, on count 2, and concurrent identical sentences for each of his other offences. The applicant was
born on 12 January 2003. Thus, at the time of his convictions and sentence, he was 17 years old, having
been 16 or 17 years old at the time of the offences to which they related.

3. Two of the applicant's three co‑defendants at trial, Messrs Harley Kavanagh and Isaac Wallace

Greaves, were also charged with counts 1 and 2 and received the same sentence on each count as was
imposed on the applicant, identically constituted. With the leave of the full court, their appeals against
sentence were considered, and allowed in part, by a different constitution of this court, on 8 July 2022. The
facts giving rise to all convictions were outlined at [7] to [15] of its judgment, _[[2022] EWCA Crim 1121,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6642-XVF3-GXF6-820B-00000-00&context=1519360)_
which we reproduce below:

"The Facts


-----

7. Between 1 December 2019 and 20 September 2020, Harvey Kavanagh, Isaac Wallace Greaves, Kobi
Nelson and Kai Henry Smith were involved in conspiracies to commit robbery and grievous bodily harm
with intent. They targeted people they believed were drug dealers.

8. The prosecution was based in essence on four incidents.

The First Incident

9. On 9 December 2019 Oscar Deed, a known drug dealer, was lured to York Road in St Albans. Deed
pulled up in his car and was ambushed. The telephone evidence showed that Henry Smith, Kavanagh and
Wallace Greaves were involved in the incident, along with others. A nearby witness contacted the police at
18.43 and said that there were four or more attackers wearing hoodies. The group were armed with a
machete and another knife. Deed did not co-operate with the prosecution, but did tell police that he had
been attacked with a knife. He received surgery to repair the tendons in his hands. Later medical
evidence showed Deed had also sustained stab wounds in the thigh, chest and forehead. The attack
came to an end after nearby security lights were activated by a householder.

The Second Incident

10. At 13.43 on 21 December 2019 there was an attempt to rob Jamal Lewis that took place in Artisan
Crescent, St Albans. There was no evidence that Lewis was a drug dealer, but the group thought that he
was one. Lewis had initially been approached by the group the night before, but on that occasion had
managed to escape into nearby shops. On 21 December Lewis was forced to take refuge in his car. He
was followed by Henry Smith, Nelson and Wallace Greaves, who were driven across St Albans to Artisan
Crescent by Mason Monaghan, who was acquitted of any involvement in the conspiracies at trial. When
Lewis parked, the group ran out and stabbed the tyres to his vehicle. The car was searched for drugs, but
none were found. Lewis escaped to some nearby woods and telephoned 999. There was no evidence
that Kavanagh had been directly involved in this attack, but he was in contact with his co-conspirators that
day.

The Third Incident

11. At approximately 18.34 on 13 January 2020, Lemar Hoyte was attacked in Cotlandswick, London
Colney. He sustained serious injuries, including the loss of two fingers; the end of his nose was severed
and surgeons were unable to re attach it; a bleed on the brain; part of his scalp had been severed from his
head; a skull fracture; stab injuries to his collar bone, shoulder blade and elbow; a broken arm; slash marks
to the head; the loss of several teeth and slash wounds to both wrists that were repaired with pins and
springs. Those injuries could indeed result in the loss of the use of both hands.

12. Following the attack, Hoyte was taken to the specialist trauma unit at St Mary's Hospital in Paddington.
He was interviewed by police and described having been followed. During his attempt to flee, he tripped
and was attacked by two men armed with a large sword and baton. The trial judge concluded the two
directly responsible were Kavanagh and Wallace Greaves. We will return to that when dealing with the
grounds of appeal.

The Fourth Incident

13. The final incident took place on 23 September 2020. Dawood Al-Abaidy was attacked as he left a
Sainsbury's supermarket in London Colney. Al-Abaidy was a convicted drug dealer known to Kavanagh.
He was cornered by a group. Someone was in possession of a knife. Al-Abaidy was punched to the face
and knocked to the ground. He was robbed of cash and Apple ear pods. He was able to identify
Kavanagh, because his balaclava had dropped. The incident only came to an end after intervention from
Sainsbury's staff. There was no evidence of who the others involved in the attack were.

Previous Convictions

14. Harley Kavanagh, as we have stated, born on 19 May 2004 was 17 and so during the course of the
conspiracy was 15/16 years old. He had previous convictions, including possession with intent to supply
Class B drugs and eight convictions of simple possession.


-----

15. Isaac Wallace Greaves, 18, born on 5 April 2003, was 16/17 years old during the conspiracy period.
He had previous convictions, including five convictions for six offences and, again, possession with intent
to supply of Class B drugs."

4. The judge was satisfied that the applicant had been a physical participant in the First and Second
Incidents, as described above, and that, although not physically present at the Third Incident, he had been
party to the agreement as to what had been planned and carried out by Messrs Kavanagh and Wallace
Greaves. In that connection, the judge found:

"You could not take part directly in the attack, Smith, because you had to leave early to be home in time for
your bail curfew, but telephone evidence makes it clear that you knew what was going on. As soon as
Kavanagh got home, just in time for his curfew that night, you were on the phone to him straightaway, no
doubt asking him for a report as to what had happened. You were in the vicinity earlier when a group
circled the victim. He was lured out later by his car being attacked."

There was no evidence of any involvement by the applicant in the Fourth Incident.

5. The separate offence to which the applicant had pleaded guilty had been committed on 4 November
2020, when, then on bail, he had chased Mr Jay Bryan along a street and into a driveway, in daylight, and
had stabbed him in his back with a large combat knife. The incident had been captured by a video
doorbell. Mr Bryan had been treated at hospital, receiving stitches to his single, 3‑4 centimetre stab

wound, before discharging himself, against medical advice.

6. In June 2019, the applicant had been convicted of three offences of knife‑point robbery, for which he

had received concurrent 10‑month referral orders.

7. As was recorded in R v Kavanagh and Wallace Greaves [20], the Crown had not distinguished between
individual offenders; it was said that all had been party to the overall agreement. Not all incidents had
been equally violent in the result. The third victim had suffered particularly extreme violence, whilst other
victims had been able to defend themselves, to varying degrees, and to avoid the same level of injury. The
intention underlying each incident had been, so the Crown inferred, the same. All defendants who had
participated in the conspiracy had understood that the aim in each case had been to inflict grievous bodily
harm by the use of swords and machetes. Having regard to the principles in R v McArdle [2021] EWCA
Crim 1490, the Crown submitted that this had been a case of particular gravity, entitling the court to
sentence outside the range indicated by the relevant sentencing guidelines.

**_Sentence_**

8. In sentencing the applicant, the judge had had regard to a pre‑sentence report (“the PSR”), together

with the character references which had been provided. In the course of his remarks, and having found the
applicant to have been a dangerous offender, he stated:

"You, Kai Henry Smith, also fall to be sentenced for an offence of wounding with intent which occurred on
4th November 2020…This was captured on CCTV and your inevitable guilty plea was delayed by you, no
doubt for forensic advantage in the conspiracy trial, until a late stage in the proceedings. You will receive
generous credit of 20 per cent to allow also for your earlier plea to unlawful wounding. You will receive a
concurrent sentence for this, but the overall sentence will reflect this separate offence.

This offence is clearly high culpability on the guidelines, because of the use of a knife. Fortunately, the
injury is not a grave injury, so category 3 for harm. The aggravating features are that you were on bail and
your criminal history. The starting point should be increased to six years to reflect this, which can be
reduced to four years and nine months by virtue of your guilty plea. Any further reduction for your age,
taking into account the guidelines for sentencing children and young people, should be minimal, bearing in
mind the criminal sophistication indicated by your previous offending and that, at the time of this offence,
you were just five weeks away from your 18th birthday. If you were sentenced for this alone, you would
receive a sentence of four years in custody.


-----

I now turn to deal with the background and personal circumstances of each of you.  You, Kai Henry Smith,
were born on 12th January 2003, so you are now 18 years of age. During the conspiracy period, you were
aged between 16 and 17 and, at the time of the separate wounding with intent matter, as I have said, you
were five weeks away from your 18th birthday.

You have previous convictions for three knife‑point robberies in June 2019. I have read the character

references provided on your behalf. It is sad to read how you have clearly gone off the rails since the

promising attributes in your earlier years. I have also read the detailed pre‑sentence report prepared by

the Probation Service, dated 28th October 2021.

….

In your cases, Smith, Kavanagh and Wallace Greaves, the relevant guidelines are those for causing
grievous bodily harm with intent and this case falls within the top category, high culpability, because of the
significant degree of planning and the use of a highly dangerous weapon, amongst other things, and
category harm 1, because of the particularly grave injuries. For an adult and a single offence this has a
starting point of twelve years in custody with a range of between ten and sixteen years.

…

This case, on the robbery guidelines, is high culpability because of the use of a weapon and category 2 for
harm, bearing in mind how petrified the victim was, as evidenced by the 999 call, so a starting point of five
in years in custody, with a range of between four and eight years. On the assault guidelines, it is a
category 2 harm with medium culpability, a starting point of five years and a range of between six and ten
years. I take both guidelines into account in setting concurrent sentences.

For all of these, there is the significant aggravating feature of the motivation of targeting known or
suspected drug dealers, either to steal their money or drugs in the knowledge that such victims are unlikely

to co‑operate with the police.

In each of your cases I must also follow the guidelines of the Sentencing Council; the guidelines for
sentencing children and young people, and apply an appropriate reduction for what would be the
appropriate sentence for an adult, bearing in mind your ages at the time of these matters.

…

I pass concurrent sentences for all three matters; both the conspiracies and the separate wounding with
intent, taking account of your overall conduct. For the conspiracies the appropriate sentence, if you were
an adult, would be sixteen years in custody. I considered going outside the guidelines, and this is a case
where it would be appropriate, but I can pull back from so doing by virtue of your personal mitigation and
the harshness of the custody regime in view of the pandemic. I reduce this to fourteen years, because you
were not physically present at the Cotlandswick attack, so did not directly inflict those devastating injuries,
but then it goes back up to sixteen to reflect the separate wounding with intent, allowing for totality.

You were 16 or 17 years of age during the conspiracy period, but were a sophisticated criminal, evidenced
by your antecedent history, the facts of this case and the cuckooing at St Edmunds Walk. I reduce what
would be an adult sentence by 25 per cent. You will therefore serve twelve years in youth custody, with an
extension period of five years."

**_The proposed grounds of appeal and the basis advanced for an extension of time_**

9. The applicant accepts that the judge was right to find him dangerous. He contends that the custodial
element of each sentence imposed was manifestly excessive, having regard to (i) his age at the time of
each offence and (ii) the fact that he had not been present at the Third Incident, to which the judge had
given insufficient weight when elevating the starting point to the top of the category range.

10. The single judge refused leave to appeal on 24 January 2022. Notification of that refusal was sent to
the applicant the following day. His renewed application for leave to appeal was made on 21 October

2022 upon discovery of the successful appeal by his co defendants


-----

**_The proposed grounds of appeal_**

**_Ground 1_**

11. On behalf of the applicant, it is submitted that the judge adopted the correct approach to the sentence
structure and totality. It is accepted that, subject to ground 2, the most serious elements of the conspiracy
(count 2) had been assessed correctly, as category 1A within the section 18 sentencing guideline, having,

for an adult committing a single offence, a starting point of 12 years' and a category range of 10‑16 years'

custody. Having determined the appropriate sentence for an adult to have been 16 years, it is said, the

judge ought to have applied a reduction which resulted in a custodial element no higher than two‑thirds of

that figure, in accordance with paragraph 6.46 of the Sentencing Children and Young People overarching
guideline.

12. The first ground of appeal is, in substance, identical to the second ground of appeal which was
considered and allowed in R v Kavanagh and Wallace Greaves, at [35] to [40]:

"Ground 2

35. It is submitted on behalf of each of the appellants that 25 per cent was insufficient discount to reflect
the ages and level of maturity at the time of the conspiracy, notwithstanding the seriousness of the case.
We note that the full court refused leave to argue that the sentence for an adult following a trial of 16 years
was wrong in principle or manifestly excessive. We respectfully agree with that decision. Paragraph 6.46
of the guidelines of the Sentencing Council on Children and Young Persons provides:

'When considering the relevant adult guideline, the court may [our emphasis] feel it appropriate to apply a

sentence broadly within the region of half to two thirds of the adult sentence for those aged 15 ‑ 17 ... This

is only a rough guide and must not be applied mechanistically. In most cases when considering the
appropriate reduction from the adult sentence the emotional and developmental age and maturity of the
child or young person is of at least equal importance as their chronological age.'

36. Whatever the seriousness and apparent culpability of the underlying offending, these remain very
important guidelines when considering the issue of age. Real weight should be attached to the principal
aims of sentencing children and young persons; namely, to prevent re-offending and the welfare of the
individual child or young person. The seriousness of the offending should be reflected when assessing the
starting point of the sentence at step one and then adjusting it to reflect aggravating and mitigating factors,
as was done in the present case in reaching 16 years.

37. Although it is a matter of judicial discretion, we would expect a sentencing judge to give cogent
reasons before departing from the guideline. In determining the discount, regard should be had to the
emotional and developmental age and maturity and any departure from the guidelines should be clearly
explained by reference to those factors.

38. In the present case, the appellants were aged 15/16, and 16/ 17, respectively at the time. The concise
sentencing remarks by the learned judge on this aspect, regrettably, do not fully set out in detail the
reasons why he departed from the guideline in discounting for age less than one third. There remains a
concern that in attaching weight to criminal sophistication the concepts of seriousness and developmental
maturity were being elided. The passing reference to developmental age in Kavanagh's case does not
dispel this concern. We note that pre-sentence reports on both defendants which were before the
sentencing court suggest a lack of maturity as a factor contributing to their criminal conduct. In addition,
Wallace Greaves was reported to have been found to be a victim of modern slavery. A psychiatric report
on him indicated that he was suffering from an adjustment disorder with predominant disturbance of
conduct, for which treatment was suggested. Having regard to the ages of each of the defendants in the
context of these reports, we are persuaded that insufficient weight was attached to their ages and level of
maturity.

39. The difference between the appellants in age and maturity was marginal so we propose to deal with
them in a similar manner. In our judgment, having assessed the adult sentence after a trial, the custodial


-----

term of 16 years should have been discounted by one third in each case. The judge was right to make a
finding of dangerousness and to assess that the public would best be protected by the making of an
extended sentence and, indeed, that has been conceded before us. Therefore, we vary the sentences on
Counts 1 and 2 in respect of each appellant concurrently to an extended sentence of 15 years; the
custodial element to be ten years and eight months and the extended licence to be four years and four
months.

40. To that extent, this appeal against sentence is allowed."

13. In the assessment of the author of the PSR, the reasons behind the applicant's offending included his
age and immaturity.

14. The principle that joint offenders ought to be sentenced by the same court to avoid disparity (R v Berry
(1985) 7 Cr App R(S) 392, CA) applies equally to appeals and applications. Regrettably, the full court in R
v Kavanagh and Wallace Greaves was not seised of a renewed application on behalf of the applicant.

15. We consider the merit in ground 1 to be such that it is in the interests of justice to extend time for
renewal and to grant leave to advance that ground. Having done so, we conclude that the information
which was before the judge in relation to the applicant's age and lack of maturity at the time of each of the
offences for which he was being sentenced indicates that the applicant was in a position comparable to

that of his co‑defendants, Kavanagh and Wallace Greaves. So it was that each received identical

sentences. There is no basis for concluding that any difference between the age and maturity of the
applicant and those of Messrs Kavanagh and Wallace Greaves was other than marginal. We shall address
the consequences of that conclusion having considered ground 2, which can be dealt with briefly.

**_Ground 2_**

16. Here, it is submitted that whilst the wounding conspiracy had been correctly categorised as a 1A
offence, the applicant had not been responsible for inflicting the injuries at Cotlandswick (the Third

Incident) and would not have been aware that such grave injuries had been inflicted by his co‑conspirators.

The fact that the judge had reduced the applicant's sentence to take account of his limited participation is
said to demonstrate that the applicant could not be held fully responsible for the nature of the injuries which
were actually inflicted (to be contrasted with his involvement in planning the offence more generally).
Where harm falls within category 2 and culpability within category A, the starting point for an adult is 7

years' custody with a category range of 6‑10 years' custody. Thus, a more significant discount ought to

have been applied, reflective of the five‑year difference in starting point between the two categories of

harm. In any event, it is submitted, the judge ought not to have considered a starting point outside the
range for a category 1A offence, or to have imposed a sentence at the top of the category range.

17. We note that, in R v Kavanagh and Wallace Greaves, this Court endorsed the full court's prior refusal
of leave to argue that the sentence for an adult, following a trial, of 16 years' custody, had been wrong in
principle, or manifestly excessive. Having regard, collectively, to the features of the applicant's offending to
which the judge referred, we do not consider the point to be properly arguable in this case either. True it is,
as the judge found, that his involvement in the Third Incident had been less extensive, but he had also
fallen to be sentenced for a separate offence of wounding with intent and we consider that the judge
permissibly concluded that the nett effect, allowing for totality, was neutral. As the trial judge, he found it to
be clear from the evidence that the applicant had known what was happening in relation to the Third
Incident and had been party to the agreement in that connection. The asserted relevance of the extent of
the gap between the respective starting points for a category 1A and category 2A case, as a yardstick, is
misconceived. The nature and extent of the harm caused during the Third Incident did not change
according to whether or not the applicant had joined in inflicting it. Rightly, it is not argued that his level of
culpability was other than high. Whilst it was appropriate that the judge make a downward adjustment to
mark the applicant's lesser involvement, that is what he did, and, subject to ground 1, it cannot be said that
his approach was wrong in principle, or resulted in a sentence which was manifestly excessive. He made
clear that the concurrent sentences passed for all offences took account of the applicant's overall conduct.


-----

18. In short, we do not consider ground 2 to be properly arguable. Certainly it lacks the merit which would
justify the significant extension of time required to advance it. It follows that we refuse both the extension
of time and leave to appeal on ground 2.

**_Disposal_**

19. By reason of our conclusions as to ground 1, we consider that, in each case, the discount which the

judge ought to have applied to the custodial term of 16 years was one‑third.  Accordingly, each of the

concurrent extended sentences imposed for counts 1 and 2, and for the further offence to which the
applicant pleaded guilty, is varied to one of 15 years, the custodial element of which will be 10 years and 8
months and the extended licence period 4 years and 4 months. To that extent the applications and the
appeal against sentence are allowed.

LADY JUSTICE MACUR: Do you have an application Mr Morris?

MR MORRIS: Can I apply for a representation order.

LADY JUSTICE MACUR: You may, and it is granted.

MR MORRIS: Thank you very much.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

