# R v Fucija

_[[2024] EWCA Crim 616](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6CB5-HNK3-RVMD-K2BR-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 17/05/2024**

# Catchwords & Digest

**CRIMINAL LAW—EXTENSION OF TIME—DRUG TRAFFICKING**

The Court of Appeal, Criminal Division, dismissed the defendant’s appeal against the renewal of his
application for an extension of time of 161 days in which to apply for leave to appeal against conviction following
refusal by the single judge. He also applied for leave to rely on fresh evidence relating to his status as a victim of
**_modern slavery. The fresh evidence is a lengthy report which supported the conclusion that the defendant was a_**
victim of **_modern slavery. The defendant’s main ground was that his conviction was unsafe because he was a_**
victim of **_modern slavery. Had this been known before he pleaded guilty the prosecution would not have_**
proceeded. Alternatively, he would have had a statutory defence. The court held that there were no arguable
grounds for considering that the prosecution of the defendant was or could have been an abuse of process or that
the prosecution should not have proceeded. Even if was admissible, nothing in the new report or the defendant’s
witness statement could have made any difference to their decision. The fresh evidence could not undermine his
guilty plea.

**End of Document**


-----

