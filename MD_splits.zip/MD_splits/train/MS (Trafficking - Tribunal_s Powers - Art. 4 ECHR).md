# MS (Trafficking – Tribunal's Powers – Art. 4 ECHR) [2016] UKUT 226 (IAC)

Upper Tribunal (Immigration and Asylum Chamber)

McCloskey J (P) and Judge Blum

23 March 2016Judgment

**Representation**

Appellant: Ms K Cronin and Ms B Poynor, of Counsel, instructed by ATLEU

Respondent: Mr T Wilding, Senior Home Office Presenting Officer

(i) _Having regard to the decision of the ECtHR in Rantsev v Cyprus and Russia [2010] 51 EHRR 1, Article 4_
_ECHR, which outlaws slavery, servitude and forced or compulsory labour, encompasses also human trafficking._

(ii) _Trafficking decisions are not immigration decisions within the compass of the 2002 Act, with the result that_
_judicial review provides the appropriate mechanism for direct challenge._

(iii)  Tribunals must take into account, where relevant, a decision that an appellant has been a victim of trafficking.

(iv)  Where satisfied that a negative trafficking decision is perverse, Tribunals are empowered to make their own
_decision on whether an appellant was a victim of trafficking._

(v)  Tribunals are also empowered to review a trafficking decision on the ground that it has been reached in breach
_of the Secretary of State's policy guidance._

(vi)  While, in principle it seems that other public law misdemeanours can also be considered by Tribunals, this
_issue does not arise for determination in the present appeal._

(vii) _Tribunals may well be better equipped than the Competent Authority to make pertinent findings relating to_
_trafficking._

(viii) _The procedural obligations inherent in Article 4 ECHR are linked to those enshrined in the Trafficking_
_Convention, Articles 10(2) and 18 in particular._

(ix) _Any attempt to remove a trafficking victim from the United Kingdom in circumstances where the said_
_procedural obligations have not been discharged will normally be unlawful._

**ANONYMITY**

**[Pursuant to Rule 14 of the Tribunal Procedure (Upper Tribunal) Rules 2008 (SI2008/2698) we make](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4TRB-0DX0-TX08-H066-00000-00&context=1519360)**
**an Anonymity Order. Unless the Upper Tribunal or Court orders otherwise, no report of any proceedings or**
**any form of publication thereof shall directly or indirectly identify the original Appellant. This prohibition**
**applies to, amongst others, all parties.**

**DECISION AND REASONS**

**Introduction**


-----

(1)  The origins of this appeal are traceable to a decision made on behalf of the Secretary of State for the Home
Department (hereinafter the “Secretary of State”), dated 01 August 2013, whereby the application of the Appellant,
a national of Pakistan aged 20 years, for asylum, was refused. This was followed by a decision dated 02 August
2013 to remove the Appellant from the United Kingdom. By its decision dated 03 December 2013, the First-tier
Tribunal (the “FtT”) dismissed the Appellant's ensuing appeal on both asylum and human rights grounds. Following
a somewhat convoluted procedural course, permission to appeal to the Upper Tribunal was granted on 23 June
2014. By its decision dated 20 August 2014, this Tribunal (differently constituted) held that the decision of the FtT
was vitiated by material error of law and ordered that same be set aside accordingly. We hereby re-make such
decision.

**Error of Law**

(2)  We draw attention to, firstly, [42] of the error of law decision of this Tribunal:

“[The FtT] _misdirected_ [itself], firstly in omitting to make a clear finding as to whether or not the Appellant was a
_victim of trafficking, secondly in concluding that it was sufficient to ascribe to the Appellant a lower position on a_
_spectrum of trafficking and in omitting clearly to evaluate the nature of the Appellant's employment in the United_
_Kingdom and whether even if freely chosen by him it was nonetheless exploitative.”_

Fundamentally, there was a failure to make any finding on the issues of whether the Appellant was trafficked to the
United Kingdom and/or re-trafficked within the United Kingdom. In setting aside the decision of the FtT, Upper
Tribunal Judge Goldstein expressly preserved certain findings, namely the FtT's “positive credibility findings that
_related to the Appellant's circumstances in the United Kingdom ….”_

**The Trafficking Decisions**

(3)  Under United Kingdom law decisions on trafficking under the Council of Europe Convention on Action Against
Trafficking in Human Beings (the “Trafficking Convention”) are made by the _soi - disant “Competent Authority”_
(hereinafter “the Authority”) under the so-called National Referral Mechanism (the “NRM”), which operates under
the auspices of the Home Office and, hence, the Secretary of State. We elaborate on this framework in [19] et seq.
On 29 November 2012 one of the national social services agencies made a formal referral of the Appellant to the
authority under the NRM. On 01 February 2013, the Authority made a decision that the Appellant, then aged 16
years, was not a victim of trafficking. While accepting that he had been recruited, transported, transferred to and
harboured in the United Kingdom and had been the victim of deception, the Authority did not accept that the
Appellant had been brought to the United Kingdom for the purpose of exploitation. The basis of this was that the
Appellant had not made the case that he was coerced into working or that his freedom of movement had been
curtailed.

In its decision the Authority stated, inter alia:

“In looking at the circumstances of your client's passage to the United Kingdom it is accepted that he has been
_subject to an act of recruitment, transportation, transfer, harbouring or receipt as it is not only accepted that his_
_step-grandmother did accompany him to the United Kingdom, it is also accepted that he may have been deceived_
_as to the true purpose of being brought to the United Kingdom. Your client has clearly stated that he was told by his_
_step-grandmother he was being brought to the United Kingdom to study ….._

_Given that he was not enrolled in any form of study or education following his arrival it is accepted that he_
_was potentially deceived as to the true purpose of being brought to the United Kingdom.”_

The conclusion made was that there were no reasonable grounds for believing that the Appellant was a victim of
trafficking within the compass of the Trafficking Convention (infra).

(4)  By a further decision dated 02 April 2014, postdating the decision of the FtT, the Authority notified the outcome
of its reconsideration of its dismissal of the Appellant's trafficking claim. Focusing on the Appellant's life subsequent
to his arrival in the United Kingdom, the Authority reasoned that, as the Appellant had received a salary, was able to


-----

rent accommodation and pay his bills and had moved around and worked in different jobs, he was not exploited and
“ …. was never under the control or influence of the alleged traffickers in the UK”. Next, the Authority adopted the
finding of the FtT that the Appellant had not been the victim of forced labour in the United Kingdom as there had
been no threat or menace to him. At the height of the Appellant's case he may have been subjected to a degree of
manipulation which did not amount to exploitation via forced labour. Rather, the Appellant worked “out of pure
_economic necessity”._

(5)  Next, the Authority reconsidered the Appellant's claim of having been trafficked to the United Kingdom by his
step-grandmother. It reasoned that even if this were accepted the Appellant was not under the control of his
traffickers when first encountered by the police in September 2012, with the result that he did not require time to
recover from any trafficking experience. It is appropriate to reproduce this somewhat enigmatic passage in full:

“It is noted that you were not under the control of your alleged traffickers when you were encountered by the police
_in September 2012. It is therefore not considered that you would require further time to recover from your alleged_
_trafficking situation. Furthermore, it is considered that as you left the accommodation that was provided to you by_

[WY] when you worked in the Kebab shop in August 2013, the benefit of a 45 day period of reflection and recovery
_would be limited in relation to the time you have already had to recover. Therefore it is not accepted that you_
_require a period of time to recover from the influence of your traffickers.”_

The decision maker then highlighted that the Appellant was not suffering from any medical condition and had not
made any complaint to the police, continuing:

“In conclusion, for the reasons given above, even if your account of your alleged experiences was accepted, it is
_considered that you are still not a victim of trafficking for the purpose of the Convention and at the present time.”_

**The Asylum Refusal Decision**

(6)  This is dated 01 August 2013. In the text the nub of the Appellant's claim is framed thus:

“If returned to Pakistan, you fear that your life is in danger from your step-grandmother and her son because they
_have taken your father's property from you, even though this is in your name. You fear your grandmother's_
_nephews as well because they are criminals involved in dealing drugs and kill people.”_

Continuing, the author suggests that a land dispute described by the Appellant was the reason for him leaving
Pakistan and that the fear arising out of such dispute is not based upon a fear of persecution in Pakistan for a
Convention reason. The decision maker then highlighted the inconsistent ages (eight or ten?) put forward by the
Appellant relating to the death of his father and his inconsistent replies relating to siblings (none or two?).  These
two factors were considered to damage his credibility. The decision maker then concluded, highlighting the
absence of any documentary proof, that the Appellant's assertion of a land dispute with his step grandmother could
be neither accepted nor rejected. Further, the Appellant's claim of fearing death at the hands of his stepgrandmother and her nephews was rejected as not worthy of belief. In the next section of the decision, the
conclusion of the Authority that the Appellant had been neither trafficked to, nor trafficked in, the United Kingdom
was adopted.

(7)  The decision maker's conclusions were that the benefit of the doubt would not be given to the Appellant
regarding the unsubstantiated aspects of his claim; he was not considered to be at risk upon returning to Pakistan
because of the rejection of his account of a land dispute with his step-grandmother; further and alternatively internal
relocation would be reasonable and viable and there was considered to be a sufficiency of state protection available
to him in Pakistan; he was not considered entitled to humanitarian protection; he did not qualify for leave to remain
under the Immigration Rules; and his return to Pakistan would not infringe Article 3 or Article 8 ECHR.

**Decision of the FtT**

(8)  The trafficking issue features in the decision of the FtT. Its findings on this issue include the following:


-----

“[72] It seems to me that whether or not there was any intention to bring him to the UK to exploit him as opposed
_to assisting him to find work and support himself in the knowledge that he was not legally entitled to do so, he was a_
_child at the time he was brought here and under the control of adults.”_

“[73] I find on his own evidence that he was not subjected to any physical threats or actual violence to make him
_work and that when he was not happy with his situation he was able to leave without attracting any adverse_
_attention. I do not find that this amounted to 'forced labour' but accept in reality he would have had little choice but_
_to work on the black market as he had no permission to work and needed money to survive. He was a child_
_surrounded by adults from his own country and at the very least would have been heavily influenced by them._
_Clearly he was vulnerable to exploitation.”_

Having referred to the evidence of an expert witness, the FtT continued:

“[74] … In her opinion the Appellant ….. would not have been able to facilitate his own travel and employment. In
_her expert opinion the intermediaries arranged the jobs and accommodation and thus exploited his vulnerability as_
_a child to use him as cheap and illegal labour. It was her opinion that victims of trafficking are often accommodated_
_at the site of the premises making them dependent on exploiters …. Living and usually [working] behind the scenes_
_away from public view so that they can be controlled and isolated from the general public. I am satisfied that at least_
_initially this was the position for the Appellant. However, his detailed account of events in the UK includes reference_
_to him deciding himself to move closer to his work on one occasion …. and to his own decisions to move from one_
_place to another ….. albeit with the assistance of others working in the industry. He was not sleeping at the work_
_premises. He was not at any time subjected to violence or threats. At the most he may have been manipulated.”_

“[75] ….. I find as a fact that he was assisted by adult males of Pakistani origin working in the same industry to
_move around the country to different jobs. I find as a fact that he was not in fear of those people but rather felt he_
_had no choice but to work in these establishments in order to survive. His experiences in the UK may well have_
_been an improvement to the life he had been experiencing in Pakistan before he came here. It is perhaps_
_understandable that he would regard these people as friends and not understand exploitative relationships. He may_
_have been manipulated by them or alternatively they may simply have been helping him to survive as an illegal_
_immigrant.”_

“It was his view that he was paying money to people who arranged for his jobs and accommodation as returning a
_favour. He accepted long working hours and irregular payments as a fact of life.”_

“[77] _… He was to some degree exploited by adults in the catering industry who knew he did not have legal_
_status and permission to work and that he was under 18. Given his apparent freedom to move around and choose_
_to rent somewhere closer to his work and the fact that he was able to chose how to spend his money_
_(notwithstanding he was paid below minimum wage) if he was a victim of trafficking this was very much at the_
**_lower end of the spectrum. There was no evidence that he was in any way traumatised by his experiences.”_**

[Our emphasis.]

“[78] …. It was his clear instruction to his representatives that he was not currently a victim of trafficking ….

_I also take into account that since his arrest by the police he had been looked after by Social Services and_
_having reached the age of 18 was now receiving assistance from a personal advisor in the transition to independent_
_living …_

**_I find as a fact that he ceased to be in a situation which might have amounted to being a_**
**_victim of trafficking following his arrest in September 2012.        ”_**

[Emphasis added.]

At this juncture we interpose the FtT's positive finding relating to the Appellant's credibility:


-----

“[75] I found his very detailed SEF […….] with regard to his history in the UK to be a truthful account of his activity
_up to the point when he was arrested by the police.”_

We juxtapose with this finding the absence of any finding in the decision of the FtT that any aspect of the
Appellant's case was to be disbelieved.

**Framework of this appeal**

(9)  A case management review was convened for the purpose of clarifying and delineating the framework of this
appeal. This was stimulated by the panel's perception of a significant lack of clarity relating to the issues of fact
and law to be determined. This resulted in the parties' joint suggested formulation of the issues in the following
terms:

(i)  First, does this Tribunal have jurisdiction to determine whether the Appellant is a victim of trafficking?

(ii)  If this Tribunal is so empowered and proceeds to make a finding of trafficking, what is the impact, if any, of
such finding on the removal decision under appeal?

(iii)  Is there any distinction in law between a victim of trafficking and a victim of forced labour?

(iv)  If this Tribunal finds the Appellant to be a victim of trafficking, does the Secretary of State have continuing
obligations to him under Articles 12 – 14 of the Trafficking Convention? And would the removal of the Appellant
from the United Kingdom violate Article 16 thereof?

(v)  In Refugee Convention terms, will the Appellant, in the event of returning to Pakistan, be at risk of persecution
as a member of a particular social group (former victims of trafficking and/or his family) or of treatment proscribed
by Article 3 ECHR?

Following reflection, we are content to adopt this formulation of the issues and the appeal shall be determined
accordingly.

**Factual Matrix**

(10) This has three main components: the uncontentious facts, the preserved findings of the FtT and our further
findings on contentious factual issues.  We interpose at this juncture the Appellant's chronology, which embraces
both the factual background and the (regrettably) rather protracted history of this appeal:

**CHRONOLOGY**

**Date** **Event**

2 June 1995 A born in Attock, Pakistan, eldest child of 3

1999 Moved to Jhelum, Pakistan

2005ff Father passed away

Mother re-married and took younger daughters with her leaving behind A with
step-grandmother

Step-grandmother and her family 'land grab' and traffick A for forced labour

|CHRONOLOGY|Event|
|---|---|
|Date||
|2 June 1995|A born in Attock, Pakistan, eldest child of 3|
|1999|Moved to Jhelum, Pakistan|


-----

|8 June 2011|Application made for A for a visit visa to the UK as an accompanied child|
|---|---|
|20 June 2011|Visit visa granted and valid until 20 December 2011|
|22 July 2011|A entered UK at the age of 16 accompanied by KF, step-grandmother Passport taken away. Passed to a man upon arrival Trafficked for the purposes of labour exploitation / forced labour|
|September 2012|A Arrested by police and referred to LB Tower Hamlets|
|25 September 2012|Claimed asylum|
|October 2012|Referral of A to Child Abuse Investigation Command SCD5 by Mohamed Obsiye, social worker LB Tower Hamlets|
|22 October 2012|SCD5 Information Requests x 5 by LB Tower Hamlets on names given by A of those who trafficked him|
|13 November 2012|Substantive asylum interview takes place R refuses to refer A to the National Referral Mechanism (NRM)|
|29 November 2012|NRM referral by LB Tower Hamlets|
|23 January 2013|LB Tower Hamlets Pathway Plan indicates that A would benefit from counselling and notes his headaches and lack of sleep|
|1 February 2013|NRM negative reasonable grounds decision issued|
|February 2013|Pangea Support Services Bi-Monthly Report notes A's headaches, lack of sleep and recognises that he may require counselling|
|15 February 2013|Request for review of NRM negative decision by Fadiga & Co to UKBA|
|22 February 2013|NRM negative decision maintained|
|20 March 2013|Letter before action in respect of NRM negative decision|
|26 April 2013|Judicial review proceeding issued in respect of NRM negative decision|
|8 May 2013|Form IHP-YP completed by LB Tower Hamlets indicates that A is self-harming|
|1 August 2013|Asylum / humanitarian protection / discretionary leave to remain application refused|
|18 August 2013|A gives notice of appeal against refusal of claim|
|27 November 2013|Appeal heard by the First-tier Tribunal|
|10 December 2013|Appeal dismissed by the First-tier Tribunal|
|19 December 2013|Application for permission to appeal to the Upper Tribunal made to the First-tier Tribunal|


13 January 2014 Permission to appeal to the Upper Tribunal refused by the First-tier Tribunal


-----

|Col1|Col2|
|---|---|
|21 January 2014|Application for permission to appeal to the Upper Tribunal made to the Upper Tribunal|
|18 February 2014|Permission to appeal to the Upper Tribunal refused by the Upper Tribunal|
|5 March 2014|R agrees to reconsider NRM negative reasonable grounds decision within the context of the on-going judicial review challenge to the NRM decision|
|11 March 2014|Judicial review proceedings against refusal of permission to appeal|
|2 April 2014|Negative reconsidered NRM reasonable grounds decision|
|23 April 2014|Permission to judicially review granted by High Court|
|28 April 2014|Judicial review proceeding against the NRM negative reasonable grounds decision dated 1 February 2013 withdrawn by consent|
|19 May 2014|High Court Order quashing refusal of permission|
|23 June 2014|Upper Tribunal grant permission to appeal in light of High Court Order|
|14 August 2014|Upper Tribunal finds error of law – appeal to be re-heard|
|7 October 2014|CMRH: Upper Tribunal designate matter to be guidance case|


We recognise that certain aspects of this chronology are contentious. We shall return to this infra.

**The Appellant's family**

(11)  According to the Appellant, his family comprises the following relevant members:

(i) His paternal grandfather, who died when the Appellant was aged around ten. The grandfather's first wife was the
Appellant's grandmother. Following her demise, the grandfather married the Appellant's step-grandmother (“KF”).

(ii) KF, the Appellant's step-grandmother, is the step-mother of three children of the Appellant's paternal
grandfather. These three persons are the Appellant's uncles/aunts. One of the aunts has two sons who are
described consistently as the step-grandmother's nephews.

(iii) The Appellant's father died when he was approximately eleven or twelve years. Subsequently, KF sponsored
the marriage between the Appellant's mother and SI, a son of KF. For some time thereafter, all of the
aforementioned persons lived together in the same household.

(iv)  SI is the Appellant's paternal uncle and became his step-father subsequent to his father's death.

(v)  When the Appellant was on a visit to a maternal aunt, his mother married SI and they and the Appellant's
sisters left the family home. The Appellant claims to have had no contact with any of them subsequently.

We shall revisit these factual issues in our findings, infra.

**Preserved Findings**

(12)  As noted in [2] above, in its error of law decision, this Tribunal preserved the FtT's “positive credibility findings
_that related to the Appellant's circumstances in the United Kingdom”. Having considered the parties' submissions_
on this issue these, on analysis, are the following:


-----

(i) The Appellant was conveyed to the United Kingdom by his step grandmother, having been deceived by her into
thinking that this was for the purpose of being educated.

(ii) The Appellant was a child at the material time, having just attained his 16th birthday and he was “under the
_control of adults”._

(iii) Subsequently he was employed and went from job to job, in circumstances wherein 
“… He would have had little choice but to work on the black market as he had no permission to work and needed
_money to survive.”_

(iv) “He was a child surrounded by adults from his own country and at the very least would have been heavily
_influenced by them. Clearly he was vulnerable to exploitation.”_

(v) The Appellant was initially exploited by adults for the purpose of using him as “cheap and illegal labour”.

(vi) Subsequently (at some unspecified stage) “at the most he may have been manipulated”.

(vii) The Appellant's “SEF” account of his life in the United Kingdom prior to arrest by the police (in September
2012) was truthful.

(viii) The Appellant was assisted by adult males of Pakistani origin working in the same industry to move around
the country from job to job and, in doing so, he “… felt he had no choice but to work in these establishments in
_order to survive”._

(ix) He paid a person for the purpose of using that person's particulars in the event of the Appellant being
encountered by the police.

(x) The Appellant “… was to some degree exploited by adults in the catering industry ….”

(xi) Given his movements and changes of job, “…. if he was a victim of trafficking this was very much at the lower
_end of the spectrum.”_

(xii) “I accept that he may have telephoned his step-grandmother's home shortly after arriving in the UK when he
_was unhappy with his situation and that he may have been told that a lot of effort had been taken [sic] to get him to_
_the UK and even been threatened by one of his step-grandmother's nephews.”_

(xiii) The nature of this threat was a threat to kill him.

(xiv) (As regards the Appellant's account of events in Pakistan) “I accept that he was a child and may not be
_expected to remember detail or respond in interview as an adult would be expected to do.”_

**Contentious Factual Issues: Our Findings**

[(13)  In KS (benefit of the doubt) [2014] UKUT 552 (IAC) and [2015] Imm AR 419, the Upper Tribunal considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DTN-GCF1-F0JY-C2VF-00000-00&context=1519360)
Article 4 of the Qualification Directive, which provides:

_“Assessment of facts and circumstances_

_1. Member States may consider it the duty of the applicant to submit as soon as possible all elements_
_needed to substantiate the application for international protection. In cooperation with the applicant it is the duty of_
_the Member State to assess the relevant elements of the application._

_2. The elements referred to in of paragraph 1 consist of the applicant's statements and all documentation_
_at the applicants disposal regarding the applicant's age, background, including that of relevant relatives, identity,_
_nationality(ies), country(ies) and place(s) of previous residence, previous asylum applications, travel routes, identity_
_and travel documents and the reasons for applying for international protection._


-----

_3. The assessment of an application for international protection is to be carried out on an individual basis_
_and includes taking into account:_

_(a) all relevant facts as they relate to the country of origin at the time of taking a decision on the_
_application; including laws and regulations of the country of origin and the manner in which they are applied;_

_(b) the relevant statements and documentation presented by the applicant including information on_
_whether the applicant has been or may be subject to persecution or serious harm;_

_(c) the individual position and personal circumstances of the applicant, including factors such as_
_background, gender and age, so as to assess whether, on the basis of the applicant's personal circumstances, the_
_acts to which the applicant has been or could be exposed would amount to persecution or serious harm;_

_(d) whether the applicant's activities since leaving the country of origin were engaged in for the sole or_
_main purpose of creating the necessary conditions for applying for international protection, so as to assess whether_
_these activities will expose the applicant to persecution or serious harm if returned to that country;_

_(e) whether the applicant could reasonably be expected to avail himself of the protection of another_
_country where he could assert citizenship._

_4. The fact that an applicant has already been subject to persecution or serious harm or to direct threats of_
_such persecution or such harm, is a serious indication of the applicant's well-founded fear of persecution or real risk_
_of suffering serious harm, unless there are good reasons to consider that such persecution or serious harm will not_
_be repeated.”_

It was held that the duty on the applicant under Article 4 to substantiate his application for international protection is
a limited one. Specifically, it is limited to the situation where aspects of the applicant's statements are not supported
(ie corroborated) by documentary or other evidence. In such circumstances, the effect of Article 4(5) is that the
Applicant will not need to provide corroboration where the conditions enshrined therein are cumulatively met: see

[81] and [85]. Article 4(5) provides:

“5.Where Member States apply the principle according to which it is the duty of the applicant to substantiate the
_application for international protection and where aspects of the applicant's statements are not supported by_
_documentary or other evidence, those aspects shall not need confirmation, when the following conditions are met:_

_(a)        the applicant has made a genuine effort to substantiate his application;_

_(b)        all relevant elements, at the applicant's disposal, have been submitted, and a satisfactory_
_explanation regarding any lack of other relevant elements has been given;_

_(c) the applicant's statements are found to be coherent and plausible and do not run counter to available_
_specific and general information relevant to the applicant's case;_

_(d)        the applicant has applied for international protection at the earliest possible time, unless the_
_applicant can demonstrate good reason for not having done so; and_

_(e) the general credibility of the applicant has been established.”_

We shall adopt this approach in making our findings on contentious issues. We also give effect to the lower
standard of proof, well established, in asylum cases.

(14)  The main contentious factual issues in the Appellant's case are ascertainable from his cross examination.
These are, in brief compass, the land owned by his deceased father; the jobs which the Appellant had before
leaving Pakistan; the date of his father's death; his step grandmother's refusal to have him educated; his mother's
remarriage; the departure of his mother, sisters and stepfather from the family home; his sojourn with an aunt in
another place; his subsequent attempts to contact his mother; his relationship with his step grandmother and her


-----

two sons and, in particular, their treatment of him; the authenticity of the two marriage certificates of his mother
upon which he relied and the circumstances in which he acquired these; the date appearing on his father's death
certificate; and his interaction and communications with two former friends following his departure from Pakistan. All
of these issues and their offshoots were probed in considerable detail at the hearing.

(15)  The Appellant's story is certainly not perfect. The exercise of juxtaposing the accounts provided by him
during interview, in his witness statement and in his testimony to the Tribunal exposes a number of inconsistencies
and imperfections. The question for us is whether these defects render the core of his account unworthy of belief
bearing in mind the burden and standard of proof. We have considered his various accounts with care. In
evaluating his story, we have had the benefit of assessing the Appellant's demeanour and presentation at two
separate hearings. In this particular case this has proved to be an asset of considerable value. While the Appellant
had the services of an interpreter at both hearings, he readily co-operated with the Tribunal in its suggestion that he
endeavour to give his evidence in English if possible. This established that he had a good command of the English
language and this, in turn, facilitated our task of assessing his credibility. The Appellant made no attempt to take
advantage of the protective shield which the interpreter would have provided. We were impressed by his
willingness to engage with the Tribunal throughout his evidence.

(16)  Furthermore there was a notable spontaneity about the Appellant's evidence. On occasions, unprompted, he
volunteered further information. Some of this entailed correcting, enlarging or clarifying earlier answers provided by
him. This reinforced his credibility. We consider that the inconsistencies and gaps in his several accounts are
precisely the kind of imperfections to be reasonably expected, taking into account his youth and immaturity during
the key periods and the passage of time. Furthermore, we have identified no inconsistency of note in three of the
key aspects of the Appellant's story, namely the circumstances in which he arrived in the United Kingdom, his life
since arrival here and his subsequent communications with friends in Pakistan.

(17)  This latter issue encompasses one further issue of substantial importance, namely the authenticity of the
marriage certificates and the circumstances in which the Appellant acquired these. As regards the document
purporting to be the certificate of the death of the Appellant's father, we make two specific findings. First, bearing in
mind that there was no frontal challenge to its authenticity, and taking into account the onerous burden of proving
fraud which would be engaged if there were, we are satisfied that this is a genuine document. Further, to hold
otherwise would be contrary to our findings about the Appellant's credibility generally. Second, having regard to
this latter consideration and in particular our finding that the Appellant's struggle with certain dates does not
undermine the core of his story, we find that the date appearing on the document is not inconsistent with the thrust
of the Appellant's case. The simple reality is that an unerringly precise and accurate chronology of all material
events in the Appellant's story will never be feasible. Furthermore it is perfectly conceivable that the certificate was
issued some time after the death. Fundamentally, we consider the Appellant's account to be inherently plausible.

(18)  Taking all of the above factors into account, our overarching finding is that the core elements of the
Appellant's case are believable. We shall apply the relevant legal rules to this framework accordingly.

**Legal Framework**

(19)  The main component of the legal framework within which this appeal is to be determined is the Council of
Europe Convention on Action Against Trafficking in Human Beings (the “Trafficking Convention”). As explained in
[SHL v Secretary of State for the Home Department [2013] UKUT 00312and [2013] Imm AR 875, at [31]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58TR-0JP1-F0JY-C1SB-00000-00&context=1519360)

“This is a Council of Europe measure, signed by the United Kingdom Government in 2007 and ratified [on 17
December] 2008. It entered into force on 1st February 2008, having received the necessary 10 ratifications. It has
_been ratified by the vast majority of the Council of Europe Member States.”_

In the same passage, the main features of the Convention are summarised thus:

“Where the relevant authority has identified a victim of trafficking, the person concerned may qualify for a residence
_permit under Article 14. The Convention is a comprehensive measure, focusing particularly on the protection of_
_victims of trafficking and the safeguarding of their rights_ _It is also designed to prevent and deter trafficking and to_


-----

_prosecute the perpetrators thereof. It embraces all kinds of exploitation, sexual exploitation, forced labour and_
_kindred abuses, whether national or transnational and irrespective of whether related to organised crime. It_
_establishes an independent monitoring mechanism for the purpose of securing compliance with its provisions by the_
_Parties.”_

In the United Kingdom, the Secretary of State is the competent authority (infra).

(20)  Following ratification on 17 December 2008, the Trafficking Convention was given effect in the United
Kingdom from 01 April 2009. Unusually, it was not incorporated in legislation. Rather, it was given effect through
the mechanism of Government policy. The two main policies, an “Action Plan” (March 2007) and an updated
“Action Plan” (July 2008) have recently been supplanted by the composite policy document “Victims of **_Modern_**
**_Slavery: Competent Authority Guidance (Version 2), Effective from 31 July 2015”._**

(21)  The two main features of the regime thus established are the so-called “Competent Authority” (“the
_Authority”) and the National Referral Mechanism (“NRM”). The former is the alter ego of the Secretary of State for_
the Home Department and it operates mainly through the United Kingdom Human Trafficking Centre. Various
agencies have specific responsibilities in this discrete sphere. These include in particular the childrens' services of
local authorities, the Safeguarding Children Boards, the Refugee Council and the various Police Services. The
NRM, in its current incarnation, is a three stage process which, following extension with effect from 31 July 2015,
now embraces victims of slavery, servitude and forced or compulsory labour as well as trafficking.

(22)  The Trafficking Convention is the central component of the legal framework. Article 4 defines “trafficking” in
the following terms:

_“a. "Trafficking in human beings" shall mean the recruitment, transportation, transfer, harbouring or receipt_
_of persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of_
_the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve_
_the consent of a person having control over another person, for the purpose of exploitation. Exploitation shall_
_include, at a minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced_
_labour or services, slavery or practices similar to slavery, servitude or the removal of organs;_

_b. The consent of a victim of “trafficking in human beings” to the intended exploitation set forth in_
_subparagraph (a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been_
_used;_

_c. The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation_
_shall be considered "trafficking in human beings" even if this does not involve any of the means set forth in_
_subparagraph (a) of this article;_

_d. "Child" shall mean any person under eighteen years of age;_

_e. “Victim” shall mean any natural person who is subject to trafficking in human beings as defined in this_
_article.”_

In this context, it is appropriate to consider the Explanatory Report relating to the Convention. This states, at [3]:

_“Trafficking in human beings, with the entrapment of its victims, is the modern form of the old worldwide_
_slave trade. It treats human beings as a commodity to be bought and sold, and to be put to forced labour, usually in_
_the sex industry but also, for example, in the agricultural sector, declared or undeclared sweatshops, for a pittance_
_or nothing at all. Most identified victims of trafficking are women but men also are sometimes victims of trafficking in_
_human beings. Furthermore, many of the victims are young, sometimes children. All are desperate to make a_
_meagre living, only to have their lives ruined by exploitation and rapacity.”_

The report continues, at [76]


-----

_“For there to be trafficking in human beings, ingredients from each of the three categories (action, means,_
_purpose) must be present together. There is, however, an exception regarding children: under Article 4(c)_
_recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation is to be regarded_
_as trafficking in human beings even if it does not involve any of the means listed in Article 4(a). Under Article 4(d)_
_the word “child” means any person under 18 years of age.”_

The concepts of abuse and vulnerability are explained thus, at [83]:

_“By 'abuse of a position of vulnerability' is meant abuse of any situation in which the person involved has_
_no real and acceptable alternative to submitting to the abuse. The vulnerability may be of any kind, whether_
_physical, psychological, emotional, family-related, social or economic. The situation might, for example, involve_
_insecurity or illegality of the victim's administrative status, economic dependence or fragile health. In short, the_
_situation can be any state of hardship in which a human being is impelled to accept being exploited. Persons_
_abusing such a situation flagrantly infringe human rights and violate human dignity and integrity, which no one can_
_validly renounce.”_

(23)  In the context of this appeal there are certain other significant provisions of the Trafficking Convention.
Article 10(2) provides:

_“Each Party shall adopt such legislative or other measures as may be necessary to identify victims as_
_appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure that, if_
_the competent authorities have reasonable grounds to believe that a person has been victim of trafficking in human_
_beings, that person shall not be removed from its territory until the identification process as victim of an offence_
_provided for in Article 18 of this Convention has been completed by the competent authorities and shall likewise_
_ensure that that person receives the assistance provided for in Article 12, paragraphs 1 and 2.”_

By Article 13(1) it is provided:

_“1 Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when_
_there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be sufficient for_
_the person concerned to recover and escape the influence of traffickers and/or to take an informed decision on_
_cooperating with the competent authorities. During this period it shall not be possible to enforce any expulsion order_
_against him or her. This provision is without prejudice to the activities carried out by the competent authorities in all_
_phases of the relevant national proceedings, and in particular when investigating and prosecuting the offences_
_concerned. During this period, the Parties shall authorise the persons concerned to stay in their territory.”_

Article 14 states:

_“1. Each Party shall issue a renewable residence permit to victims, in one or other of the two following_
_situations or in both:_

_a. the competent authority considers that their stay is necessary owing to their personal situation;_

_b. the competent authority considers that their stay is necessary for the purpose of their co-operation with_
_the competent authorities in investigation or criminal proceedings._

_2. The residence permit for child victims, when legally necessary, shall be issued in accordance with the_
_best interests of the child and, where appropriate, renewed under the same conditions._

_3. The non-renewal or withdrawal of a residence permit is subject to the conditions provided for by the_
_internal law of the Party._

_4. If a victim submits an application for another kind of residence permit, the Party concerned shall take_
_into account that he or she holds, or has held, a residence permit in conformity with paragraph 1._


-----

_5. Having regard to the obligations of Parties to which Article 40 of this Convention refers, each Party shall_
_ensure that granting of a permit according to this provision shall be without prejudice to the right to seek and enjoy_
_asylum.”_

Article 15 provides:

_“1 Each Party shall ensure that victims have access, as from their first contact with the competent_
_authorities, to information on relevant judicial and administrative proceedings in a language which they can_
_understand._

_2 Each Party shall provide, in its internal law, for the right to legal assistance and to free legal aid for_
_victims under the conditions provided by its internal law._

_3 Each Party shall provide, in its internal law, for the right of victims to compensation from the_
_perpetrators._

_4 Each Party shall adopt such legislative or other measures as may be necessary to guarantee_
_compensation for victims in accordance with the conditions under its internal law, for instance through the_
_establishment of a fund for victim compensation or measures or programmes aimed at social assistance and social_
_integration of victims, which could be funded by the assets resulting from the application of measures provided in_
_Article 23.”_

We shall revisit these provisions and address Article 18 separately infra.

(24)  In the growing domestic jurisprudence belonging to this field, it has been held that the threshold in play,
namely that of merely suspecting without being able to prove, is particularly low: see R (Minh) v Secretary of State
for the Home Department _[2015] EWHC 1725 (Admin). The standard of proof applicable to this threshold is the_
balance of probabilities. It was further held in Minh, at [126], that the function of the Competent Authority is
inquisitorial in nature.

(25)  The second element of the legal framework is Article 4 ECHR which, by virtue of the _[Human Rights Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
_[1998,is a provision of domestic law. This provides, in material part:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_

“1.No one shall be held in slavery or servitude.

_2.        No one shall be required to perform forced or compulsory labour.”_

Third, there is Council Directive 2011/36/EU on Preventing and Combating Trafficking in Human Beings and
Protecting The Victims (the “Trafficking Directive”). Finally, there is the United Nations Protocol to Prevent,
Suppress and Punish Trafficking in Persons, Especially Women and Children (the “Palermo Protocol”). Since 01
November 2015 the domestic law framework has included the **_[Modern Slavery Act 2015. By section 52 of this](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
enactment public authorities are obliged to notify the Secretary of State if they suspect that a person is a victim of
slavery or human trafficking. Various offences are created.

(26)  We turn our attention to some of the leading judicial decisions in this field. In Rantsev v Cyprus and Russia

[2010] 51 EHRR 1, one of the main legal issues which arose was that Article 4 ECHR does not expressly
encompass human trafficking. The specific complaints before the ECtHR was that the Applicant's daughter had
been trafficked from Russia to Cyprus and that both the Russian and Cypriot authorities were in breach of Article 4.
The Court acknowledged that it had not previously decided whether the proscription of slavery, servitude and forced
and compulsory labour enshrined in Article 4 extended to human trafficking: see [272] – [273]. It drew on its
previous decision in Siliadin v France [2006] 43 EHRR 16 which had, inter alia, embraced the definition of slavery in
the Geneva Convention on Slavery (1926) which required the exercise of a genuine right of ownership of the victim
and reduction of the status of the victim to an “object”: see [122]. In [281] the Court states:


-----

“The Court considers that trafficking in human beings, by its very nature and aim of exploitation, is based on the
_exercise of powers attaching to the right of ownership. It treats human beings as commodities to be bought and sold_
_and put to forced labour, often for little or no payment, usually in the sex industry but also elsewhere…._

_It implies close surveillance of the activities of victims, whose movements are often circumscribed …_

_It involves the use of violence and threats against victims, who live and work under poor conditions.”_

Highlighting the threat which trafficking poses to the human dignity and fundamental freedoms of its victims and its
incompatibility with democratic societies and the values expounded in the ECHR, the Court concluded that it is
embraced by Article 4 ECHR: [282].

(27)  Having made this landmark conclusion, the ECtHR then turned its attention to the specific requirements of
Article 4 ECHR. We summarise [283] – [289] of its judgment thus:

(a) Article 4 is on a par with Articles 2 and 3 as enshrining “one of the basic values of the democratic societies
_making up the Council of Europe”. It makes no provision for exceptions or derogation._

(b) The spectrum of safeguards contained in national legislation “…. must be adequate to ensure the practical and
_effective protection of the rights of victims or potential victims of trafficking”. This includes adequate criminal law_
measures and the need for appropriate provisions within the state's immigration rules.

(c) Article 4 encompasses “a specific positive obligation on Member States to penalise and prosecute effectively
_any act aimed at maintaining a person in a situation of slavery, servitude or forced or compulsory labour”. This,_
however, is but one aspect of the state's general undertaking to combat trafficking arising out of the Trafficking
Convention and the Palermo Protocol.

(d) Operational measures to protect victims or potential victims of trafficking may arise in certain circumstances.

(e) In common with Articles 2 and 3, Article 4 entails a procedural obligation to investigate “situations of potential
_trafficking”, which is not dependent upon a complaint from the victim._

(28)  Another important member of the developing ECtHR jurisprudence in this sphere is its decision in CN v
United Kingdom [2013] 56 EHRR 24, which involved a complaint of domestic servitude infringing Article 4 ECHR.
In [80], the Court made the important pronouncement that domestic servitude 
“… involves a complex set of dynamics, involving both overt and more subtle forms of coercion, to force
_compliance.”_

As a result, the investigation of such complaints “…. requires an understanding of the many subtle ways an
_individual can fall under the control of another”. In brief compass, the main criticism of the State's investigation in_
this case was that it was too blunt and simplistic. Notably, the Court adjudged the International Labour
Organisation's indicators of forced labour as “a valuable bench mark”: see [35]. Notably, in its consideration of the
concept of “penalty”, the Court acknowledged that this need not necessarily take the form of physical violence or
restraint. Rather, this can assume a more subtle mantle, usually of a psychological nature, embracing conduct such
as threats to denounce a victim to the police or immigration authorities: see [77].

(29)  In R v SK _[2011] EWCA Crim 1691 [2013] QB 82, the Court of Appeal highlighted that the concepts of_
slavery, servitude and forced or compulsory labour in Article 4 ECHR share a common denominator, namely that
“… the victim is subject to a degree of enforced control”: see [40]. In [41], the Court emphasised the broad
spectrum of conduct which may be encompassed by these different concepts:

“One person may exploit another in many different ways.”

Turning its attention to “the menace of a penalty”, the Court stated, in [42]:


-----

“Where 'forced or compulsory labour' is concerned, the menace of a penalty can be exerted in various ways. It can
_be direct; it can also be indirect. Constraint can be mental or physical. It can be imposed by force of circumstances._
_Where it is alleged that one person has been compulsorily employed by another, the level of pay he or she has_
_received, if any, may have evidential importance. It may point to coercion; it may bear on an employee's ability to_
_escape from his or her employer's control. On its own, however, a derisory level of wages is not tantamount to_
_coercion.”_

We shall revisit this discrete issue of compulsion infra.

(30)  As cases such as R v SK show, one of the interesting features of the United Kingdom jurisprudence is the
combination of decisions belonging to both the civil and criminal fields. This is illustrated in Attorney General's
Reference Nos 37, 38 and 65 of 2010 [2010] EWCA Crim 2880, in which certain restaurant owners were convicted
of the criminal offence of trafficking. They contested their innocence on the basis that the victims had returned to
Pakistan following the expiry of their work permits and had, subsequently, returned to the United Kingdom where
they resumed employment with the Defendants. The Court of Appeal made the following notable observation, in

[18]:

“The unspoken but clear explanation for the workers' preparedness to return to the risk of further subjection and
_helplessness was the contrast between the economic circumstances of the families they left behind and even the_
_degraded expectation of a job in the UK …. The return of the workers does not constitute evidence that the_
_conditions to which_ [they] _were subjected were acceptable but, in the circumstances of the present case, is_
_evidence of further exploitation by the offenders of personal circumstances of which they knew they could take_
_advantage.”_

Notably, it was further held that, having been deceived by promises of attractive wages and working conditions in
the United Kingdom, the victims, all adult males –

“… had been subjected to conditions of neglect, abuse, deprivation and economic exploitation …. [and] …..

_They were not prisoners but were effectively trapped and controlled, being unable to work legally_
_elsewhere … and being unable to leave the country and return home.”_

See [3] and [21].

(31)  The decision of the Court of Appeal in R v Connors and Others [2013] EWCA Crim 324 is especially notable
for the following observations of the Lord Chief Justice on what he described as “the troublesome crime of
_exploitation of labour”, at [5]:_

_“The problem has been with us for some time, and has been growing. Unhappily different forms of_
_exploitation are found in the sex industry, the construction industry, agriculture and residential care. That list is not_
_comprehensive. Those who are exploited are always and inevitably vulnerable, and just because they are so_
_vulnerable, profoundly reluctant to report what has happened or is happening to them. The Asylum and Immigration_
_Act 2004 criminalised the exploitation of labour when it was connected to trafficking in human beings, but not_
_otherwise. Therefore it did not prevent vulnerable but untrafficked individuals from being subjected to forced or_
_compulsory labour. The Gang Masters' Licensing Act 2004 established a system for licensing those who employed_
_workers in specified industries. Nevertheless, this legislation, too did not address the entire problem. The end result_
_was that many men and women continued to remain vulnerable to exploitation without any counter-balancing_
_protection against exploitation.”_

Having noted the reform effected by section 71 of the Coroners and Justice Act 2009, the Court drew particular
attention to the decision of the ECTHR in Siliadin v France and its earlier decision in SK.

(32)  In R (Atamewan) v Secretary of State for the Home Department [2013] EWHC 2727 (Admin) and [2014] 1
WLR 1959, the Complainant challenged a decision by the competent authority to the effect that while he may have
been, historically, a victim of trafficking, he was no longer so, with the result that the Secretary of State had no legal


-----

obligations to provide protection or assistance. The Court of Appeal held that the Secretary of State's Guidance
was incompatible with the Trafficking Convention, due to a misinterpretation of the latter.

(33)  At this juncture we record that in developing their arguments Ms Cronin and Ms Poynor on behalf of the
Appellants relied on the principle enunciated in R (Ullah) v Special Adjudicator [2004] UKHL 26 and [2004] 2 AC
323, at [20]:

_[“In determining the present question, the House is required by section 2(1) of the Human Rights Act 1998](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y15B-00000-00&context=1519360)_
_to take into account any relevant Strasbourg case law. While such case law is not strictly binding, it has been held_
_that courts should, in the absence of some special circumstances, follow any clear and constant jurisprudence of_
_the Strasbourg court: R (Alconbury Developments Ltd) v Secretary of State for the Environment, Transport and the_
_Regions [2001] UKHL 23, [2003] 2 AC 295, paragraph 26. This reflects the fact that the Convention is an_
_international instrument, the correct interpretation of which can be authoritatively expounded only by the Strasbourg_
_court. From this it follows that a national court subject to a duty such as that imposed by section 2 should not_
_without strong reason dilute or weaken the effect of the Strasbourg case law. It is indeed unlawful under section 6 of_
_the 1998 Act for a public authority, including a court, to act in a way which is incompatible with a Convention right. It_
_is of course open to member states to provide for rights more generous than those guaranteed by the Convention,_
_but such provision should not be the product of interpretation of the Convention by national courts, since the_
_meaning of the Convention should be uniform throughout the states party to it. The duty of national courts is to keep_
_pace with the Strasbourg jurisprudence as it evolves over time: no more, but certainly no less.”_

The further ingredient in the argument is that since the decision of the Authority is justiciable before this Tribunal, a
challenge to such decision by judicial review is inappropriate, having regard to the well known exhaustion of
alternative remedies principle.

**Trafficking Issues in the IAC Tribunals**

(34)  At the outset, we recall that the decisions of the Secretary of State which were challenged by appeal to the
FtT were the refusal of his asylum claim and the corresponding decision to remove him from the United Kingdom.
Given the date of these decisions, 01 August 2013, the statutory appeal provisions governing the two appeals
which have followed and the remaking decision in which this complete Tribunal is now engaged, the relevant
statutory provisions are the following:

Section 82, 2002 Act

(i) Section 82 of the Nationality, Immigration and Asylum Act 2002 (the “2002 Act”) which, both before and after the
[reforms effected by the Immigration Act 2014,with effect from 20 October 2014, made provision for a right of appeal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
against the refusal of a protection claim. Prior to 20 October 2014, section 82 provided:

_“(1) Where an immigration decision is made in respect of a person he may appeal to the Tribunal._

_(2) In this Part “immigration decision” means—_

_(a) refusal of leave to enter the United Kingdom,_

_(b) refusal of entry clearance,_

_(c) refusal of a certificate of entitlement under section 10 of this Act,_

_(d) refusal to vary a person's leave to enter or remain in the United Kingdom if the result of the refusal is_
_that the person has no leave to enter or remain,_

_(e) variation of a person's leave to enter or remain in the United Kingdom if when the variation takes effect_
_the person has no leave to enter or remain,_

_(f) revocation under section 76 of this Act of indefinite leave to enter or remain in the United Kingdom,_


-----

_[(g) a decision that a person is to be removed from the United Kingdom by way of directions under section](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y0CX-00000-00&context=1519360)_
_[10(1)(a), (b), (ba) or (c) of the Immigration and Asylum Act 1999 (c. 33) (removal of person unlawfully in United](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y0CX-00000-00&context=1519360)_
_Kingdom),_

_(h) a decision that an illegal entrant is to be removed from the United Kingdom by way of directions under_
_paragraphs 8 to 10 of Schedule 2 to the Immigration Act 1971 (c. 77) (control of entry: removal),_

_[(ha) a decision that a person is to be removed from the United Kingdom by way of directions under section](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C690-TWPY-Y0RW-00000-00&context=1519360)_
_[47 of the Immigration, Asylum and Nationality Act 2006 (removal: persons with statutorily extended leave),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C690-TWPY-Y0RW-00000-00&context=1519360)_

_(i) a decision that a person is to be removed from the United Kingdom by way of directions given by virtue_
_of paragraph 10A of that Schedule (family),_

_(ia) a decision that a person is to be removed from the United Kingdom by way of directions under_
_paragraph 12(2) of Schedule 2 to the Immigration Act 1971 (c. 77) (seamen and aircrews),_

_(ib) a decision to make an order under section 2A of that Act (deprivation of right of abode),_

_(j) a decision to make a deportation order under section 5(1) of that Act, and_

_(k) refusal to revoke a deportation order under section 5(2) of that Act._

_(3A) Subsection (2)(j) does not apply to a decision to make a deportation order which states that it is made_
_[in accordance with section 32(5) of the UK Borders Act 2007; but–](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y17N-00000-00&context=1519360)_

_(a) a decision that section 32(5) applies is an immigration decision for the purposes of this Part, and_

_(b) a reference in this Part to an appeal against an automatic deportation order is a reference to an appeal_
_against a decision of the Secretary of State that section 32(5) applies._

_(4) The right of appeal under subsection (1) is subject to the exceptions and limitations specified in this_
_Part.”_

Section 84, 2002 Act

(ii) Section 84 of the 2002 Act which, both before and after the aforementioned date, has made provision for
appealing on the grounds that the removal of the Appellant from the United Kingdom would breach the United
Kingdom's obligations under the Refugee Convention and/or would breach the United Kingdom's obligations in
relation to persons eligible for humanitarian protection and/or would be unlawful under section 6 of the Human
Rights Act 1998. Prior to to 20 October 2014, section 84 provided:

_(1) An appeal under section 82(1) against an immigration decision must be brought on one or more of the_
_following grounds—_

_(a) that the decision is not in accordance with immigration rules;_

_(b) that the decision is unlawful by virtue of Article 20A of the Race Relations (Northern Ireland) Order_
_[1997 or by virtue of section 29 of the Equality Act 2010 (discrimination in the exercise of public functions etc) so far](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-73HV-00000-00&context=1519360)_
_as relating to race as defined by section 9(1) of that Act;_

_[(c) that the decision is unlawful under section 6 of the Human Rights Act 1998 (c. 42) (public authority not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)_
_to act contrary to Human Rights Convention) as being incompatible with the appellant's Convention rights;_

_(d) that the appellant is an EEA national or a member of the family of an EEA national and the decision_
_breaches the appellant's rights under the Community Treaties in respect of entry to or residence in the United_
_Kingdom;_


-----

_(e) that the decision is otherwise not in accordance with the law;_

_(f) that the person taking the decision should have exercised differently a discretion conferred by_
_immigration rules;_

_(g) that removal of the appellant from the United Kingdom in consequence of the immigration decision_
_[would breach the United Kingdom's obligations under the Refugee Convention or would be unlawful under section 6](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)_
_of the Human Rights Act 1998 as being incompatible with the appellant's Convention rights._

_(2) In subsection (1)(d) “EEA national” means a national of a State which is a contracting party to the_
_Agreement on the European Economic Area signed at Oporto on 2nd May 1992 (as it has effect from time to time)._

_(3) An appeal under section 83 must be brought on the grounds that removal of the appellant from the_
_United Kingdom would breach the United Kingdom's obligations under the Refugee Convention._

_(4) An appeal under section 83A must be brought on the grounds that removal of the appellant from the_
_United Kingdom would breach the United Kingdom's obligations under the Refugee Convention._

(35)  The Trafficking Convention features in the decision of the Upper Tribunal in SHL (supra). One feature of the
matrix of the appeal to the Upper Tribunal in SHL was that the Authority had made a formal decision that the
Appellant was not a victim of trafficking. The Secretary of State, on the same date, made a separate decision
rejecting the Appellant's claim for asylum. This was challenged, unsuccessfully, by appeal to the FtT. In deciding
the appeal, this Tribunal stated, at [33]:

“…… there is no right of appeal to this Tribunal against the Respondent's trafficking decision: see Part (v) of the
_[Nationality, Immigration and Asylum Act 2002. Secondly, the Trafficking Convention cannot be invoked as a free](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)_
_standing source of rights, obligations and legal effects and consequences in domestic law, as it is an_
_unincorporated international treaty.”_

The decision continues:

“A corollary of this principle is that a failure by a public authority to take into account the provisions of an
_unincorporated international treaty is not of itself a ground for impugning the exercise of a discretionary power: R v_
_Ministry of Defence, ex parte Smith [1996] QB 517, page 558 (per Sir Thomas Bingham MR). It is, of course,_
_established that unincorporated international instruments have a role in certain contexts, a paradigm example being_
_the presumption that Parliament does not intend to legislate contrary to the United Kingdom's international_
_obligations …._

_Furthermore, a decision may be impugned where a public authority purports to apply an unincorporated_
_international treaty provision but errs in doing so.”_

The Tribunal decided that none of these principles was of any avail to the Appellant, noting that it would have been
open to him to challenge the Secretary of State's trafficking decision by judicial review and stating, at [34]:

“We are of the opinion that back door challenges to trafficking decisions made by the Respondent under the
_Trafficking Convention are not permissible in appeals of the present kind. They lie outwith the competence of the_
_First-tier and Upper Tribunals.”_

The essence of the decision was that the jurisdiction of this Tribunal is statutory and does not encompass a direct
challenge of this kind.

(36)  The decision in SHL was the subject of comment by the Court of Appeal in AS (Afghanistan) v Secretary of
State for the Home Department _[2013] EWCA Civ 1469 and [2014] Imm AR 513. Before turning to consider this_
decision in a little detail, it is appropriate to highlight two features of SHL. First, the Appellant was attempting to
mount a direct, frontal challenge to the negative trafficking decision of the Authority. Second, the Secretary of


-----

State's policy guidance did not feature in the matrix of the appeal. The Tribunal considered that this was not legally
possible.

(37)   In AS (Afghanistan), Longmore LJ formulated the issue to be addressed in the following terms, at [1]:

“The question in this appeal is the extent to which (if at all) Judges of the Immigration and Asylum Chamber should
_regard as conclusive decisions of the 'Competent Authority' determining that an appellant before them has or has_
_not been a victim of trafficking.”_

There were two decisions in the matrix. The first was the Secretary of State's decision rejecting the Appellant's
asylum claim. The second was the decision of the Authority that the Appellant was not the victim of human
trafficking. The Appellant challenged the asylum refusal decision by appeal to the FtT. The appeal was dismissed.
On further appeal to the Upper Tribunal, the question arose whether the FtT had erred in law by failing to make a
finding on the trafficking issue. It was held that the FtT “….had no jurisdiction to review the trafficking decision of
_the UKBA”: see [9]. No error of law was demonstrated and the appeal was dismissed._

(38)  At [11], Longmore LJ records his acceptance of the Respondent's submission that a decision of the Authority
is not an immigration decision (within the meaning of the applicable legislation): “…. and the only remedy … was by
_way of judicial review”. However, the Court ruled that in immigration appeals the Tribunal is competent to take into_
account a positive trafficking decision where relevant to the decision under appeal (normally a removal decision).
Longmore LJ continues, at [14]:

“If the First tier Tribunal is entitled to take into account a decision that an appellant is (or has been) a victim of
_trafficking it seems odd that, if a perverse decision has been reached that an appellant has not been a victim_
**_of trafficking, the Tribunal cannot consider whether the facts of the case do, in fact, show that the appellant was a_**
_victim of trafficking.”_

(our emphasis)

In thus holding, the Court reasoned that the decision in Secretary of State for the Home Department v Abdi [1996]
Imm AR 148 is authority for the proposition that a failure by the Secretary of State to apply her own policy is an
error of law. The Court further held that there is no obligation on the appellant to challenge a negative trafficking
decision by judicial review, stating at [14]:

“The FTT Judge should consider the matter for himself.”

The Court expressed its conclusion in the following terms, at [17]:

“….. First tier Tribunal judges are competent to consider whether the Secretary of State has complied with her
_policy in relation to trafficking. If asked to consider that question, they should then decide whether she has in fact_
_complied with her policy since that is (or may be) relevant to her removal decision._

_[18]        …… No doubt, if a conclusive decision has been reached by the Competent Authority, First_
_Tier Tribunals will be astute (save perhaps in rare circumstances) to allow an appellant to re-run a case already_
_decided against him on the facts. But where, as here, it is arguable that, on the facts found or accepted, the_
_Competent Authority has reached a decision which was not open to it, that argument should be heard and taken_
_into account.”_

(39)  We are satisfied that in the final part of this passage the Court is referring to the standard of perversity (or
Wednesbury irrationality) mentioned twice in earlier passages.  The effect of the decision in AS (Afghanistan) is
that in appeal proceedings the Appellant may, in certain circumstances, mount an indirect challenge to a negative
trafficking decision of the Authority. We are satisfied that a challenge of this kind is not confined to perversity (or
irrationality) grounds. Rather, it is clear from a consideration of [12] – [18] as a whole that where a removal decision
has been preceded by a negative trafficking decision made in breach of the Secretary of State's policy guidance,
the removal decision will be erroneous in law and, therefore, embraced by the “not in accordance with the law”
ground of appeal in section 82 of the 2002 Act (supra) We further consider that in principle there is no reason


-----

why the Tribunal's consideration of negative trafficking decisions should not encompass, in cases where
appropriate, other recognised public law misdemeanours such as the intrusion of immaterial considerations, leaving
material evidence or considerations out of account, procedural unfairness and bad faith.

(40)  We give effect to the approach formulated immediately above in the following way. On behalf of the
Appellant it is submitted that the issue of whether the Appellant is a trafficking victim is relevant to the immigration
decision under appeal, namely the Secretary of State's removal decision. The specific argument advanced is that
this Tribunal should determine that the Appellant's removal would be contrary to section 6 of the Human Rights Act
1998 if either (a) he is at risk of retrafficking in Pakistan or (b) he has been denied the benefits and protections
which would have flowed from a decision that he was a child trafficking victim and a lawful investigation of his claim
to be such a victim.

(41)  In their able submissions, Ms Cronin and Ms Poynor, on behalf of the Appellant, developed this argument in
the following way. They submitted that trafficking and the positive duties enshrined in Articles 12, 13, 14 and 15 of
the Trafficking Convention have the status of positive obligations under Article 4 ECHR. To remove the Appellant
would infringe Article 4 and, by virtue of section 6 of the Human Rights Act, would therefore not be in accordance
with the law, thereby impelling that his appeal be allowed. Article 4 establishes rights which are absolute,
unqualified and fundamental, described as the “basic values of a democratic society” in Rantsev, at [62] (supra). It
is acknowledged, for the reasons given by this Tribunal in SHL, the obligations contained in Articles 12 – 14 of the
Convention are not justiciable per se. This, however, it is contended, presents no barrier in light of the protections
afforded by the Human Rights Act and the decision in Rantsev that it is not necessary to identify whether the
offending conduct constitutes slavery, servitude or forced labour and that trafficking is embraced by Article 4 ECHR.
As noted in [29] above, counsels' submissions further drew attention to the decision of the House of Lords in (Ullah)
where it was held that United Kingdom Courts should, in the absence of some special circumstance, follow any
clear and constant jurisprudence of the Strasbourg Court: see [20].

(42)  It is convenient to reproduce the following passage in the written submission of Mr Wilding on behalf of the
Secretary of State:

“The Respondent accepts that the Tribunal (be it First-tier or Upper) generally can consider whether a person has
_been trafficked for the purpose of assessing the factual matrix of a case leading to any assessment of risk on_
_return. The starting point for such consideration will of course be the decision of the Competent Authority on_
_whether the Appellant has been trafficked. The Respondent agrees that the issue as_ [to] whether someone has
_been trafficked or not can go towards the question of risk on return; in fact in many cases it may well be an_
_important fact finding exercise going to the very heart of risk on return.”_

Next, attention is drawn to the status of the Trafficking Convention as an unincorporated international treaty. This is
followed by the passage:

“Therefore, as the present appeal is one against the SSHD's decision to remove the Appellant to Pakistan, the only
_relevance of the [Trafficking Convention] is whether the Appellant has been trafficked as part of his narrative as to_
_why he is at risk on return to Pakistan. Nothing therefore turns on the trafficking issue if he is not at risk on return_
_…..  The_ [Upper Tribunal] _cannot consider the provisions of_ [the Trafficking Convention] _which do not go to the_
_question of whether the Appellant has been trafficked.”_

The specific provisions of the Convention highlighted in this context are Articles 12 – 16.

(43)  While the Respondent's submissions also highlighted that the Appellant did not challenge either of the
trafficking decisions by judicial review, there was no suggestion – correctly in our view – that this was in some way
fatal. While both parties drew our attention to the decision in Nguyen (Anti-Trafficking Convention: respondent's
duties) _[[2015] UKUT 00170 (IAC) and [2015] Imm AR 886, we consider this to be an illustration of the Upper](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FPM-N5S1-F0JY-C04H-00000-00&context=1519360)_
Tribunal's alertness to the need to give effect to the “not in accordance with the law” dimension of the decision of
the Court of Appeal in AS (Afghanistan): see especially [41] – [42]. The Respondent's submissions further sought
to confine the decision in Rantsev, contending that (our summary) the essence of the violation of Article 4 found
was the failure of Cyprus to establish a national law framework to combat trafficking to provide protective measures


-----

for trafficking victims and to investigate trafficking allegations. It was submitted that the Secretary of State has
acquitted this duty via the criminal law legislation and the creation of the NRM.

(44)  Giving effect to the binding decision of the Court of Appeal in AS (Afghanistan), we conceive our duty to be to
determine whether the immigration decision under challenge in this appeal, namely the decision to remove the
Appellant from the United Kingdom and return him to Pakistan in the wake of the anterior refusals of his asylum and
trafficking claims, is vitiated by any material error of law in the negative trafficking decisions. In proceeding thus we
are conscious of the error of law decision of this Tribunal outlined in [2] above. The factual substratum of our
decision is set forth in [10] – [17] above. It was further acknowledged that the Tribunal is empowered to make
findings of fact bearing on the Appellant's case that he was a victim of trafficking.

(45)  Article 4 ECHR is justiciable before this Tribunal as it is one of the Convention Rights protected by the
Human Rights Act and having regard to the provisions of section 82 of the 2002 Act (supra). Bearing in mind the
decision of the House of Lords in Ullah, we can conceive of no reason not to give full effect to the decision of the
ECtHR in Rantsev. In this case the Strasbourg Court decided unambiguously that human trafficking falls within the
embrace of Article 4 ECHR. Bearing in mind that we are remaking the decision of the FtT, the question for this
Tribunal is whether the Appellant has demonstrated that to remove him from the United Kingdom would be in
breach of the prohibition against slavery, servitude, forced or compulsory labour and human trafficking and,
therefore, in contravention of Article 4 ECHR. This, in the evolution of this appeal, has emerged as the crucial
question.

(46)  We agree with Ms Cronin that this Tribunal is better equipped than the Authority to make pertinent findings.
The decisions of the Authority were the product of a paper exercise, entailing no live evidence. In contrast, we have
the distinct advantage of having heard the Appellant's viva voce evidence and, further, we have received evidence
not available to the Authority. Linked to this is the Secretary of State's submission, with which we concur, that the
Appellant's credibility is central to the disposal of this appeal.

(47)  The factual matrix to which we apply the relevant legal rules and principles is set forth in [10] – [17] above.
We have made an overarching finding that the core elements of the Appellant's case are believable. The
Appellant's life is divisible into three phases. Prior to his father's death, when he was aged around 11/12, the
Appellant evidently had a relatively normal, stable and happy childhood. His father's death was a watershed.
During the following four years approximately, prior to his departure from Pakistan, the Appellant's life was shaped
by forced labour, neglect, isolation and physical abuse at the hands of his cousins. His mother was weak and under
the influence of others. Ultimately she abandoned him in his early teenage years. This second phase of the
Appellant's life culminated in his departure for the United Kingdom. At this stage there was no parent or parental
figure in his life and, given his age and events during the previous four years, he was obviously vulnerable.

(48)  At this juncture we conduct the exercise of making certain further findings. We find that the Appellant's
journey to the United Kingdom was arranged by his step grandmother, he was accompanied by her and the
arrangements which materialised upon his arrival were made by her. At this time he was heavily influenced by and
dependent upon his step grandmother. She deceived the Appellant into travelling to the United Kingdom. He was
not acting voluntarily. He was, rather, under the control of a significantly older person whom he viewed as having
been instrumental in attempts to disinherit him. We consider this to be a classic case of subtle, psychological
compulsion.

(49)  His arrival in the United Kingdom heralded the beginning of the third phase in the Appellant's life. He had
been deceived into believing that he had been brought to the United Kingdom to be in education. The contrast
between the vision which this would have engendered and the ensuing reality was acute. This would have
exacerbated his vulnerability. We readily infer that the labour which followed had been arranged by his grandmother
and that she profited financially from the transaction. This was a callous arrangement motivated bilaterally by
financial gain.

(50)  Contrary to the promises made the Appellant's life did not entail attending an educational institution and
mixing, socially and otherwise, with his peers. Rather, he was plunged into an adult world of work, business and
fit H b bj t f h d ill l l b H thl l l it d b th h l d hi


-----

He found himself alone in a foreign country with an alien language and culture. He was bereft of parental and family
support and his life was devoid of any parental figure. We consider that he was exploited from the moment of his
departure to the United Kingdom, within days of his 16th birthday until his encounter with the police some 15
months later. We find that, during the initial phase, the Appellant received no pay for his work. The stamp of
compulsion applied to his labour, where he worked, the hours he worked, his accommodation and those with whom
he shared accommodation and associated. The Appellant had no true freedom of choice at any stage.

(51)  We take account of the fact that the Appellant did not have a single, fixed employment during the period
under scrutiny. However, as appears from the preserved findings rehearsed in [12] above, his “mobility” was limited,
it was confined to the Asian food industry; it was facilitated by fellow adult employees; and, finally, it was plainly
motivated by a naïve and probably desperate hope of finding a better way of living. Moreover, as the preserved
findings make clear, he was, properly analysed, acting under compulsion and manipulation at all times. He was not
truly free in any real sense. He was, rather, a desperate, frightened and coerced teenager. Accordingly the factors
of mobility and more than one employment do not alter our assessment above.

(52)  To borrow the phraseology of Rantsev, the Appellant was at the material time a commodity who had been
bought and sold and put to forced labour for little payment, living and working under poor conditions: see [281].
Servitude and compulsory labour were the hallmarks of his existence. In Article 4 terms, his human dignity was
relentlessly violated and he was denied a fundamental freedom.

(53)  It is necessary to evaluate the outworkings of the assessment and conclusions above. In the context of
these proceedings, arguably the most important feature of the Rantsev decision is the Strasbourg's Court
assessment of the procedural, or adjectival, dimension of Article 4. Ms Cronin was right to press this discrete point.
The obligations on the State are to ensure the practical and effective protection of the rights of trafficking victims,
actual or potential, and to penalise and prosecute effectively any acts aimed at maintaining a person in a situation
of slavery, servitude or forced or compulsory labour: see [283] –[289] of Rantsev. The nexus here with the
Trafficking Convention, the Palermo Protocol and the EU Trafficking Directive is evident. Furthermore, there is a
specific procedural obligation to investigate situations of potential trafficking which are not dependent upon a
complaint from the victim.

(54)  In the Appellant's case, the first opportunity which the State had to discharge its aforementioned obligations
arose at the time of his encounter with the police. The Appellant's case, unchallenged on this issue, is that he has
at all times been co-operative with the police and, indeed, he remains willing to co-operate fully with them. We
consider that the most elementary of enquiries at this stage viz late 2012 would have elicited from him an account
including the circumstances of his arrival in the United Kingdom and details of subsequent employers and work
conditions. This should, in principle, have resulted in prosecutions for offences under, _inter alia, the Slavery Act_
2015, subject of course to the application of the established criteria for prosecution. However, on the evidence
before us, there is no indication of even the most elementary of police enquiries.

(55)  The second opportunity presented to the State to discharge its procedural obligations under Article 4 arose
when the Authority became seized of the Appellant's trafficking complaint. Yet another opportunity arose when the
Authority was required to review its initial negative decision. We refer to our summary of these decisions in [3] – [5]
above. Given our assessments and findings above, both decisions of the Authority are manifestly unsustainable.
They are infected by a failure to conduct proper enquiries and to amass relevant and available evidence. They are
further undermined by a failure to properly examine and assess the realities of the Appellant's life during the period
of some four years before his departure from Pakistan. Further, the Authority failed to properly analyse the factors
of the Appellant's pay, accommodation and mobility and failed to identify the elements of fear and coercion in his
work circumstances.

(56)  In addition, in its assessment that the Appellant worked due to economic necessity, the Authority failed to
recognise that this was not inconsistent with continuing exploitation, manipulation and forced labour. Further, the
Authority placed disproportional weight on the failure of this frightened, isolated mid-teenager recently exposed to
the culture and language of an alien country to make a formal complaint to the police. Finally, we consider that its


-----

approach to the issue of respite and recovery was hopelessly inadequate. In our judgment, these inadequate and
cursory decisions would plainly have been vulnerable to successful challenge by judicial review.

(57)  As the decision in AS (Afghanistan) makes clear, the Wednesbury principle is of continuing relevance at this
stage. The effect of our foregoing analysis and conclusions is that both decisions of the Authority are unsustainable
by reference to the three limbs of the Wednesbury principle, that is to say they are infected by failing to take into
account material facts and evidence, together with the intrusion of distorted factors and assessments and,
ultimately, irrationality, which is the synonym of the AS (Afghanistan) terminology of “perversity”.

(58)  At this juncture we must consider the effect of our above conclusions. We remind ourselves of the essential
elements of the framework of the appeal before us, which are: the Secretary of State has refused the Appellant's
application for asylum and, having done so, is proposing to remove him to Pakistan and the Competent Authority
(effectively the Secretary of State) has refused the Appellant's application to be recognised as a victim of trafficking.
We have held that this latter decision is unsustainable in law in the sense outlined above. We have also identified a
breach of Article 4 ECHR.

(59)  If the Authority had made a lawful decision the Appellant would have been recognised as a victim of
trafficking. This would have entitled him to a “recovery and reflection period” of at least 30 days, per Article 13(1) of
the Trafficking Convention. At this remove, the loss of this benefit is irreparable. The Appellant would have
qualified for a renewal residence permit under Article 14 if the Authority had considered his stay necessary “owing
_to_ [his] _personal situation”. We consider it highly probable that the Authority, duly armed with all appropriate_
information, directing itself properly in law and acting rationally would have found this condition to be satisfied. In
accordance with Article 14(4), the grant of a residence permit would have been a material consideration in
subsequent applications by the Appellant for leave to remain. He has, accordingly, been deprived of a valuable
benefit.

(60)  Furthermore, the decision to remove him from the United Kingdom is not in accordance with the law for the
discrete reason that none of these factors was taken into account. This was due to the unlawful decisions of the
Authority. We note that our analysis and conclusions on the Trafficking Convention issues mirror closely those of
the Administrative Court in Amatewan (supra) As this decision demonstrates, the effect of our analysis and
conclusions above is that, in substance, the Appellant now has the status of trafficking victim. In this particular
case, this is very much a current and enduring status.

(61)  The unlawful decisions of the Authority give rise to another significant consequence. By Article 10(2) of the
Trafficking Convention, victims of trafficking shall not be removed from the territory of the state concerned until the
process enshrined in Article 18 has been completed and the victim has received the assistance provided for in
Article 12(1) and (2). In accordance with the latter provisions, a lawful trafficking decision would have entitled the
Appellant to a range of services and benefits including appropriate accommodation, psychological support,
counselling and legal advice. Recognition of and provision for his specific “safety and protection needs” would also
have been required.

(62)   Further, Article 18 of the Convention would have been triggered. This provides, under the rubric
“Criminalisation of Trafficking in Human Beings”:

“Each Party shall adopt such legislative and other measures as may be necessary to establish as criminal offences
_the conduct contained in Article 4 of this Convention, when committed intentionally.”_

Article 10(2), in somewhat infelicitous language, describes this as an “identification process as victim of an offence”.
We construe this as a clear reference to the universally recognised criminal law processes of investigation,
prosecution and punishment. We would add that, in this respect, a distinction is to be made between the status of
trafficking victim and the status of victim of a criminal offence.

(63)  Accordingly, by virtue of Article 10(2) of the Convention, there exists, by reason of our condemnation in law
of the decisions of the Authority, a prohibition against removing the Appellant from the United Kingdom at this point
in time. The Secretary of State's removal decision is, in consequence, unlawful. Notably, in Atamewan (supra) the


-----

Court identified the UK Border Agency as the public authority which was under a positive duty to initiate an effective
investigation by the police. This duty was considered to be unaffected by the circumstance that the victim had made
no complaint to the police and the absence of continuing police investigations.

(64)  The same conclusion is reached by the different route provided by Article 4 ECHR. The Appellant is not
simply the historical victim of treatment proscribed by this provision. He is, rather, the continuing victim of an
enduring breach by the State of its investigative and procedural obligations identified in [27] above. Within the
framework of section 6 of the Human Rights Act, the public authorities who, to date, have failed to discharge these
obligations are UKBA, the Authority and the police service. Furthermore, it is inconceivable that an effective police
investigation and any ensuing prosecution could be conducted without the full assistance and co-operation of the
Appellant. Realistically, this will not be feasible if he is removed to Pakistan. Accordingly, to remove him to
Pakistan would contravene Article 4 ECHR. The Secretary of State's removal decision is unlawful on this further
ground.

(65)  Accordingly, on the grounds and for the reasons elaborated above, the Secretary of State's decision to
remove the Appellant from the United Kingdom is not in accordance with the law and is contrary to section 6 of the
Human Rights Act, within the framework of section 84(1)(c) and (e) of the 2002 Act.

(66)  One discrete aspect of the Appellant's case is that if he is removed to Pakistan this will expose him to a risk
of re-trafficking. In our judgment the evidential foundation necessary for making this finding is lacking. Having
regard to his age (now 19), his increased maturity and the positive aspects of his experiences during the last four
years, which are likely to have fortified him as a person and will equip him to identify and avoid risks of this kind, we
are satisfied that this case is not made out. Furthermore, on the hypothesis of his return to Pakistan, we are
confident that the Appellant will be able to locate and re-establish himself in a manner which will distance himself
sufficiently from the three persons concerned, his step-grandmother and her two nephews, to efficaciously eliminate
such risk of re-trafficking as may arise. There is nothing in the evidence, including the experts' reports (of which
more, infra),warranting a different assessment.

(67)  We turn to examine the protection dimension of the Appellant's case. It is common case that the Appellant is
a member of a particular social group, namely his family. It is also agreed, having regard to our findings, that the
Appellant would be at risk of persecution for a Refugee Convention reason at the hands of the three persons
concerned. However, we discern no basis upon which to conclude that it would be either unreasonable or
impractical for the Appellant to locate and re-establish himself in Pakistan in the manner suggested immediately
above. In particular, we take into account that the Appellant has no enduring links with his direct and immediate
family in his home area; he has no enduring relationships with any relatives there; he has no employment or
education to return to there; he has only one enduring friendship in the area; and, finally, if it were necessary for him
to resort to litigation and he were minded to do so, in relation to the inheritance of his deceased father's lands, there
is no evidence that he must permanently re-establish himself in the area of his former home for this purpose. In
short, the availability of safe internal relocation undermines the Appellant's asylum application fatally.

(68)  Finally, one of the features of the Appellant's case was his reliance upon four expert reports. These were
generated by, respectively, an expert in anthropology, an expert in the laws of Pakistan, an expert in child trafficking
and exploitation and an expert in labour exploitation. On behalf of the Secretary of State, Mr Wilding criticised
some of this evidence. He suggested that it was mere advocacy and that there were passages in the reports more
akin to skeleton arguments than expert commentary and opinion. He further highlighted that none of the experts
had interviewed the Appellant.

(69)  As a perusal of this judgment will confirm, we have made our findings and conclusions favourable to the
Appellant without reference to any of the expert evidence. The reason for this is that we did not consider it
necessary to do so. However, while declining to descend into superfluous detail, we consider that there is some
force in the criticisms levelled. Had it been necessary to do so, we would have examined them in appropriate detail.
In the circumstances, it suffices to highlight the detailed treatment of the duties of expert witnesses in the decision
of this Tribunal in MOJ and Others (Return to Mogadishu) Somalia CG _[[2014] UKUT 00442 (IAC), at [23] – [27].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DDJ-W7M1-F0JY-C2YF-00000-00&context=1519360)_
We have reproduced these passages in an appendix to this judgment. We consider that, henceforth, those


-----

engaging expert witnesses should, in every case, ensure that the expert is provided with a copy of this section of
the MOJ decision, as a matter of course, at the initial stage of receiving instructions. Each expert's report should, in
turn, make clear that these passages have been received and read by the mechanism of a simple declaration to
this effect.

**SUMMARY OF CONCLUSIONS**

(70)  We summarise our conclusions thus:

(a) Having regard to the decision of the ECTHR in Rantsev, Article 4 ECHR, which outlaws slavery, servitude and
forced or compulsory labour, encompasses also human trafficking.

(b) Trafficking decisions are not immigration decisions within the compass of the 2002 Act, with the result that
judicial review provides the appropriate mechanism for direct challenge.

(c) Tribunals must take into account, where relevant, a decision that an appellant has been a victim of trafficking.

(d)  Where satisfied that a negative trafficking decision is perverse, Tribunals are empowered to make their own
decision on whether an appellant was a victim of trafficking.

(e)  Tribunals are also empowered to review a trafficking decision on the ground that it has been reached in
breach of the Secretary of State's policy guidance.

(f)  While, in principle it seems that other public law misdemeanours can also be considered by Tribunals, this
issue does not arise for determination in the present appeal.

(g)  Tribunals may well be better equipped than the Competent Authority to make pertinent findings relating to
trafficking.

(h)  The procedural obligations inherent in Article 4 ECHR are linked to those enshrined in the Trafficking
Convention, Articles 10(2) and 18 in particular.

(i)  Any attempt to remove a trafficking victim from the United Kingdom in circumstances where the said procedural
obligations have not been discharged will normally be unlawful.

(71)  Mindful of recent legislative changes we add the following. By virtue of the amendments to sections 82 and
[84 of the Nationality, Immigration and Asylum Act 2002 by the Immigration Act 2014, an appellant will no longer be](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)
able to rely on a 'not in accordance with the law' ground when challenging the refusal of a protection or human
rights claim. Recourse will, however, still be available, via the new section 84(2), to advancing an appeal on the
basis that a decision that breaches the trafficking elements of Article 4 ECHR will be unlawful under section 6 of the
Human Rights Act 1998.

**DECISION**

(72)  We re-make the decision of the FtT by allowing the appeal under section 84(1)(c) and (e) of the 2002 Act.

**Bernard McCloskey**

THE HON. MR JUSTICE MCCLOSKEY

PRESIDENT OF THE UPPER TRIBUNAL

IMMIGRATION AND ASYLUM CHAMBER

**Date:          15 February 2016**

**APPENDIX**


-----

**[MOJ and Others (Returns to Mogadishu) Somalia CG [2014] UKUT 00442 (IAC), [23] – [27]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DDJ-W7M1-F0JY-C2YF-00000-00&context=1519360)**

[23] We consider it appropriate to draw attention to this subject, given the prevalence and importance of
expert evidence in Country Guidance cases. Mindful that substantial quantities of judicial ink have been
spilled on this subject, we confine ourselves to highlighting and emphasising what appear to us to be
amongst the most important considerations. The general principles are of some vintage. In National Justice
CIA Naviera SA v Prudential Assurance Company Limited [1993] 2 Lloyds Reports 68, Cresswell J stated,
at pp 81 – 82:

“The duties and responsibilities of expert witnesses in civil cases

_include the following:_

_1.            Expert evidence presented to the court should be, and should be seen to be, the_
_independent product of the expert uninfluenced as to form or content by the exigencies of litigation …._

_2.            An expert witness should provide independent assistance to the Court by way of objective_
_unbiased opinion in relation to matters within his expertise …. An expert witness in the High Court should_
_never assume the role of an advocate …_

_3.            An expert witness should state the facts or assumption upon which his opinion is based._
_He should not omit to consider material facts which could detract from his concluded opinion. …._

_4.            An expert witness should make it clear when a particular question or issue falls outside_
_his expertise._

_5.            If an expert's opinion is not properly researched because he considers that insufficient_
_data is available, then this must be stated with an indication that the opinion is no more than a provisional_
_one. In cases where an expert witness who has prepared a report could not assert that the report_
_contained the truth, the whole truth and nothing but the truth without some qualification, that qualification_
_should be stated in the report …._

_6.            If, after exchange of reports, an expert witness changes his view on a material matter_
_having read the other side's expert's report, or for any other reason, such change of view should be_
_communicated (through legal representatives) to the other side without delay and when appropriate to the_
_Court.”_

This code was duly approved by the Court of Appeal: see [1995] 1 Lloyds Reports 455, at p496. It has
[been considered in a series of subsequent report cases: see, for example, Vernon v Bosley (No 2) [1997] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-6084-00000-00&context=1519360)
_[All ER 577, at page 601. In the latter case, Evans LJ stated, at page 603:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-6084-00000-00&context=1519360)_

“…. Expert witnesses are armed with the court's readiness to receive the expert evidence which it needs in
_order to reach a fully informed decision, whatever the nature of the topic may be. But their evidence ceases_
_to be useful, and it may become counter-productive, when it is not marshalled by reference to the issues in_
_the particular case and kept within the limits so fixed.”_

Judicial condemnation of an expert who does not appreciate his responsibilities is far from uncommon:
[see, for example, Stevens v Gullis [2000] 1 All ER 527, where Lord Woolf MR at pp.532-533 stated that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J70-TWP1-61FH-00000-00&context=1519360)
expert in question had:

“… demonstrated by his conduct that he had no conception of the requirements placed upon an expert
_under the CPR ….. 19  It is now clear from the rules that, in addition to the duty which an expert owes to a_
_party, he is also under a duty to the court.”_

24.  The requirements of CPR 31 also featured in Lucas v Barking Hospitals NHS Trust [2003] EWCA Civ
_1102, where the emphasis was on CPR 31 and CPR 35. These provide (inter alia) that:_

(i) a party may apply for an order for inspection of any document mentioned in an expert's report which
has not already been disclosed,

(ii) every expert's report must state the substance of all material instructions, whether written or oral, on
th b i f hi h th t itt d


-----

(iii) such instructions are not privileged against disclosure.

Laws LJ made the following noteworthy observation:

“[42] As it seems to me the key to this case …. is the imperative of transparency, a general theme of the
_CPR but here specifically applied to the deployment of experts' reports. Thus the aim of rule 35.10(3) and_
_(4) is broadly to ensure that the factual basis on which the expert has prepared his report is patent.”_

25.  Thus in the contemporary era the subject of expert evidence and experts' reports is heavily regulated.
The principles, rules and criteria highlighted above are of general application. They apply to experts giving
evidence at every tier of the legal system. In the specific sphere of the Upper Tribunal (Immigration and
Asylum Chamber), these standards apply fully, without any qualification. They are reflected in the Senior
President's Practice Direction No 10 (2010) which, in paragraph 10, lays particular emphasis on a series of
duties. We summarise these duties thus:

(i) to provide information and express opinions independently, uninfluenced by the litigation;

(ii) to consider all material facts, including those which might detract from the expert witness' opinion;

(iii)  to be objective and unbiased;

(iv)  to avoid trespass into the prohibited territory of advocacy; 20

(iv) to be fully informed;

(vi)  to act within the confines of the witness's area of expertise; and

(vii)  to modify, or abandon one's view, where appropriate.

26.  In the realm of expert testimony, important duties are also imposed on legal practitioners. These too
feature in the aforementioned Practice Direction. These duties may be summarised thus:

(i)  to ensure that the expert is equipped with all relevant information and materials, which will include
information and materials adverse to the client's case;

(ii)  to vouchsafe that the expert is fully versed in the duties rehearsed above;

(iii) to communicate, promptly, any alterations in the expert's opinion to the other parties and the Tribunal,
and

(v) to ensure full compliance with the aforementioned Practice Statement, any other relevant Practice
Statement, any relevant Guidance Note, all material requirements of the Rules and all case management
directions and orders of the Tribunal.

These duties, also unqualified in nature, are a reflection of the bond between Bench and Representatives
which features throughout the common law world.

27.  The interface between the role of the expert witness and the duty of the Court or Tribunal features in
the following passage in the judgment of Wilson J in Mibanga v Secretary of State for the Home
Department [2005], EWHC 367:

“[24] It seems to me to be axiomatic that a fact finder must not reach

_his or her conclusion before surveying all the evidence relevant_

_thereto…._

_The Secretary of State argues that decisions as to the credibility of an account are to be taken by the_
_judicial fact finder and that, in their reports, experts, whether in relation to medical matters or in relation to_
_in-country circumstances, cannot usurp the fact finder's function in assessing credibility. I agree. What,_
_however, they can offer is a factual context in which it may be necessary for the fact finder to survey the_
_allegations placed before him; and such context may prove a crucial aid to the_

_decision whether or not to accept the truth of them. ……_


-----

_It seems to me that a proper fact finding enquiry involves explanation as to the reason for which an expert_
_view is rejected and indeed placed beyond the spectrum of views which could reasonably be held.”_

To this we would add that, as the hearing of the present appeals demonstrated, this Tribunal will always
pay close attention to the expert's research; the availability of empirical data or other information bearing
on the expert's views; the quality and reliability of such material; whether the expert has taken such
material into account; the expert's willingness to modify or withdraw certain views or conclusions where
other evidence, or expert opinion, suggests that this is appropriate; and the attitude of the expert, which will
include his willingness to engage with the Tribunal. This is not designed to be an exhaustive list. No
enduring links with his direct and immediate family in his home area.

**End of Document**


-----

