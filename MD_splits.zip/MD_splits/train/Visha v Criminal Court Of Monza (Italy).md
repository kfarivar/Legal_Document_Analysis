# Visha v Criminal Court Of Monza (Italy) [2019] EWHC 400 (Admin)

QBD, ADMINISTRATIVE COURT

CO/4447/2018

Rafferty LJ, Carr J

Wednesday, 20 February 2019

20/02/2019

J U D G M E N T

MRS JUSTICE CARR:

Introduction

1 This is the judgment of the Court.

2 The Appellant is a 31‑year old Albanian. This is his appeal pursuant to section 26 of the Extradition Act 2003

("the 2003 Act") against the decision of District Judge Jabbitt ("the Judge") on 1 November 2018 to order his
extradition pursuant to an accusation European Arrest Warrant issued by the Respondent on 20 February 2014 and
certified by the National Crime Agency on 22 April 2018 ("the EAW"). He has been and remains in custody
following his arrest on the day of certification. The EAW seeks the surrender of the Appellant in order to prosecute
him for offences arising out of his alleged involvement in a criminal gang committing offences that include murder,
exploitation and the facilitation of prostitution and burglary.

3 Permission to appeal was granted by Ouseley J on 4 February 2019 on a single ground, namely that it is
arguable that the procedure identified in _Aranyosi and Caldararu [2016] QB 921("Aranyosi") should have been_
followed on the basis of a real risk of a breach of the Appellant's rights under Article 3 of the European Convention
on Human Rights (“Article 3”) ("the ECHR") upon his surrender because of general overcrowding (“the Article 3
issue”). An application to renew those grounds in respect of which permission was refused and to advance a new
ground on abuse of process has been withdrawn.

4 The Appellant submits that the Judge fell into error in his treatment of the Article 3 issue. The Appellant having
adduced evidence of a serious and growing problem of prison overcrowding in Italian prisons, the Judge was wrong

to apply the so‑called "international consensus test" and to proceed without any response or reply from the Italian

judicial authorities on this issue, still less any assurance. Further, fresh evidence which post‑dates the conclusion

of the case below reveals that the conditions at the prison in which it is said to be likely that the Appellant would be
held are "undoubtedly not Article 3 compliant". The Appellant submits that the Judge's conclusions are wholly
undermined by this fresh evidence.

5 The appeal has been heard on an expedited basis in the light of concerns that the relevant custody time limits in
Italy will shortly expire (on 22 April 2019). The Italian authorities have indicated that the Appellant would need to
arrive in Italy by the beginning of March 2019 in order to ensure that the relevant parties can be served in time for
the necessary preliminary hearing.


-----

6 Time is, therefore, of the essence. This judgment is being delivered immediately at the conclusion of the hearing
before us. We would wish to express our gratitude at the outset to both counsel who have worked under pressure

and have nevertheless provided high‑quality and helpful submissions on both sides.

7 Yesterday, on the eve of the hearing, the Respondent served an application to admit two assurances to which we
will turn in due course. Much of the submission before us today was naturally focussed on those assurances. Their
thrust is to identify where the Appellant would be detained upon extradition and to indicate that he will be
guaranteed at least threesquare metres of personal space in accordance with Article 3.

The EAW

8 The EAW, as supplemented by further information provided by the Respondent on 17 August and 6 September
2018, seeks the surrender of the Appellant in order to prosecute him for the following four offences:

"i) Criminal association ‑ between July 2013 and 14 November 2013 in association with Dorjan Vishaj, Albert Ruci,

Pellumb Hamza, Shpresin Vishaj, Besjan Mehemti, Vasilica Carmen Zaharia, Adison Shabani, Artur Vashaj and
Sekret Vishaj in view of committing offences of exploitation and facilitation of prostitution, as well as burglaries, the
Appellant specifically:

a) facilitated and exploited the prostitution activity of Ardita Ismajlukaj on the territory of the municipality of Lomazzo
and Appiano Gential (CO);

b) took and got from the workplace the prostitute Mbarine Ismajlukaj thus facilitating her prostitution on behalf of the
organisation;

c) paid to the criminal organisation part of the proceeds obtained from the exploitation of the prostitute Ardita
Ismajlukaj and the sum due for the location occupied by her to prostitute herself;

d) took part in the meetings with the other members in the bingo hall of Vetermate con Minoprio (CD);

e) took part in the control of the 'places' to avoid that they be occupied by women unconnected with the
organisation.

This is contrary to Article 416 §2 and 4 of the Criminal Code. The maximum sentence is 15 years' imprisonment.

ii) Exploitation ‑ between July 2013 and 14 November 2013 at Appiano Gentile and Lomazzo (in complicity with

Dorjan Vishaj) the Appellant received from her the proceeds of prostitution. He also took her and made others take
her to the workplace and provided her with the means to 'exercise her activity". The offence is aggravated as the
Appellant consistently hit Ardita Ismajlukaj causing injuries to her teeth. This is contrary to Article 110 of the
Criminal Code and Article 3n.8 and 4n1 Law 20 February 1958 n.75. The maximum sentence is 12 years'
imprisonment.

iii) Facilitation of prostitution ‑ between July 2013 and 14 November 2013 in Appiano Gentile and Lomazzo, the

Appellant facilitated the prostitution of Mbarime Ismajlukaj by taking her to and from the workplace. This is contrary
to Article 3 n.8 of Law 20 February 1958 n.75. The maximum sentence is one of six years' imprisonment.

iv) Murder ‑ on 14/15 November 2013 in the car park of a supermarket in Seveso he murdered Leka Selim by

stabbing him to death with a knife (in the face, chest and abdomen). The murder is aggravated by 'malice
aforethought' because the applicant went to the meeting with the victim armed with a knife. This is contrary to
Articles 575, 577 n.3 of the Criminal Code. The maximum sentence is one of life imprisonment."

9 The Framework List has been ticked in order to designate the conduct for offences 1 and 2 as "participation in a
criminal organisation" and "murder".

Procedural History


-----

10 The enforceable decision in Italy was made on 2 January 2014. On 10 February 2014 the Appellant was
declared a fugitive. The EAW was issued on 20 February 2014 and certified on 22 April 2018. In the meantime,
the trial due to start on 1 October 2015 was suspended because the Appellant was untraceable at the time.

11 On 21 April 2018 the Appellant was arrested in respect of domestic human trafficking offences. Whilst he was
in custody, checks revealed the existence of the EAW and he was arrested pursuant to the EAW the next day. He
was subsequently charged with conspiring with others to require others to perform forced labour and arrange the
travel of others for the purposes of exploitation.

12 The extradition proceedings were opened formally on 23 April 2018. The case was adjourned pursuant to

section 8(a) of the 2003 Act (because of the modern slavery and people‑trafficking charges). The Appellant was

remanded in custody. On 22 May 2018 the Appellant and his co‑defendant appeared in Newcastle Crown Court on

the domestic charges. The case was adjourned for trial in September 2018 but by July last year the domestic
charges had been discontinued. Thus, on 3 July 2018 the extradition case resumed with a hearing fixed for 18
September 2018. That hearing then had to be adjourned due to technical difficulties. The full hearing finally
commenced on 1 October 2018. It was adjourned in order to allow the Appellant to submit further materials which
he did on 25 October 2018. Judgment was then delivered on 1 November. The Appellant's extradition was
ordered. He lodged this appeal on 7 November 2018.

The Hearing and Judgment below

13 The Appellant did not give oral evidence at the hearing, although his brother Vladimir Visha did. His brother

was to describe a blood‑feud in Albania between the Appellant's family and that of the murder victim Leka, which is

not relevant for present purposes. The Appellant relied upon a report on "Detention in Italy" prepared by
Associazione Antigone ("Antigone") dated 31 July 2018. Antigone is a small NGO established in 1991 dealing with
human rights protection in the Italian penal and penitentiary system. It has unrestricted access to the Italian prison
estate and is funded by the Italian Prison Ombudsman. Mr Scandurra, Antigone's director of research, gave
evidence to the Judge via Scopia link.

14 In his ruling the Judge rehearsed the law and the evidence before him, going on to make his findings of fact. He
accepted that the Appellant has Hepatitis B and D, and that there was a blood feud between the Visha and Leka
families. The Appellant had left Italy in an attempt to put himself beyond the reach of the victim's family and the
Italian police. Italian prison conditions are poor, as they are in much of the prison estate in the UK and other EU
countries.

15 Having made his findings of fact, the Judge went on to refer to the decision of this court in Elashmawy v Italy

[2015] EWHC 28 Admin ("Elashmawy") which dealt with Italian prison conditions in particular. He referred to the
doubt there expressed that a single expert report would be sufficient to require a review; it would require an
international consensus or the considered view of the European Court of Human Rights (“the ECtHR”) or that of the
Committee of Ministers.

16 In the light of that decision, the Judge considered the evidence. He referred to the evidence from Antigone and
Mr Scandurra in particular as follows: (1) Mr Scandurra could not say where the Appellant might be held; it could be
Monza but he was likely to be moved around. There are 18 facilities in Lombardy, all overcrowded with an average
occupancy rate of 146%. (2) Prison cells vary in size. Modern cells can be 12 square metres but are designed for
more than one prisoner. There are normally two persons per cell although about a third now have three prisoners.
In some cells prisoners are kept in a space less than three square metres. Some cells conform to national
standards and some do not. The minimum cell space under Italian law is six square metres for multiple occupancy.
His organisation does not include cell furniture in measuring cell space. (3) The usual time spent out of cells was
eight hours. (4) In general, new prisons have been built since the pilot judgment in 2013 in _Torreggiani v Italy_
(2009) (App. No. 43517/09, 46882/09, 55400/09) ("Torreggiani"). (5) Health care varies. Generally, doctors are
available but it is difficult to access specialised medical care. In Lombardy, health care is managed better than in
other areas. (6) There are 2,509 Albanians in the Italian prison estate. Vulnerable prisoners are placed in


-----

protective parts of the prison. Mr Scandurra could not comment on the risks to the Appellant since he himself had
never come across the issue of blood feuds. He said that the safety of prisoners was important to the prison
authorities. (7) There is a new complaint system for prisoners but it was too early to say if it would be effective.

17 The Judge found that the evidence did not demonstrate that there was a real risk that the Appellant's personal
cell space would fall below three square metres or that he would not have access to adequate medical care. There
was no evidence to show that the Appellant was at particular risk within the Italian prison estate. The Antigone
report recorded that the Italian authorities were extremely aware and sensitive to the topic of blood feuds and set
out specific measures that can be put in place. Mr Scandurra had not encountered the issue at all. Solitary
confinement is with the consent of the prisoner.

18 In relation to the Antigone report, he stated (at paragraphs 50 and 51):

"50. [Antigone] is, I am sure, a well‑respected organisation, but this evidence, as a single expert report is insufficient

to rebut the presumption that Italy as an EU state will comply with the ECHR. The prison conditions in Italy, as in
many EU states, including the UK are poor, but the evidence does not represent an international consensus of the
type envisaged in Krolik.

51. I am unable to conclude that this evidence amounts to clear, cogent and compelling evidence or powerful
evidence, plainly not amounting to something like an international consensus."

19 Having confirmed that extradition would also not be disproportionate, the Judge duly ordered extradition of the
Appellant pursuant to section 21A(5) of the 2003 Act.

Grounds of Appeal

20 Mr Hawkes for the Appellant places the Aranyosi procedure at the heart of this appeal. He submits that this
Court must adopt that process, leaving us either to allow the appeal outright or at the very least to request further
information. The assurances, to which we will come in due course, he submits, do not meet the test identified in
_Hungary v Fenyvesi [2009] EWHC 231 Admin (“Fenyvesi”), and the assurances are, in any event, deficient in other_
respects. Mr Hawkes submits that there are substantial grounds to believe that the Appellant is at real risk, if
extradited, of being in severely overcrowded conditions in breach of Article 3.

21 The Antigone Report described a significant number of prisons in Italy which it inspected in 2017 and 2018
which provided less than three square metres per prisoner, despite the Italian law mandating nine square metres
per single cell with an extra six square metres for each additional prison. Antigone considers that the Appellant
would be held in Lombardy if extradited. In Lombardy's 18 prisons all but one were over 100% overcrowded, with
the overcrowding rising to 196.5% in one facility. The average overcrowding rate in Lombardy's prisons is 146%.
As at 31 March 2017 in one of the prisons, Monza, prisoners were afforded cell space of less than three square
metres and the prison was overcrowded overall by 185%. That level had fallen to 157% by 31 July 2018 according
to the Ministry of Justice. But since judgment, allegedly fresh evidence, which Mr Hawkes seeks to adduce on this
appeal, confirms that the overcrowding levels at Monza are now dangerously high. The Antigone Report, submits
Mr Hawkes, shows that despite efforts to reduce the prison population surrounding the judgment of Torreggiani in
January 2013 the Italian prison population has risen steadily since the end of 2015. The Italian authorities have not
built many new prisons but have rather focussed on refurbishing existing prisons.

22 As will be seen below, at least without further explanation, some of these statements are misleading, particularly
in relation to the figures on cell space per detainee. The Appellant's written submissions also suggested that the
Antigone Report stated that the Appellant would be held at Monza. That is incorrect. It only stated that he might be
held there.

23 The Appellant submits that the Judge should have asked himself whether he was presented with evidence
which required further information from the requesting state following the guidance in _Aranyosi. This is, as Mr_
Hawkes put it, the key issue. Mr Hawkes submits that the Judge fell into error in his treatment of the decision in
_Elashmawy_ He applied too high a test namely that the evidence of the single expert would be insufficient to


-----

require a review and that it would require an international consensus or the like. The Appellant relies on Purcell and
_Pengel v Belgium [2017] EWHC 1981 Admin ("Purcell and Pengel") where, at [18], Hamblen LJ stated that he did_
not consider that there was an "evidential threshold" to be reached before inquiries are to be made of a requesting
authority.

24 It is submitted that the Judge ought to have sought information in order to clarify precisely to which prison the
Appellant would be sent and that Monza would be excluded as a destination. It was not fanciful, submitted Mr
Hawkes, that the Appellant might yet end up in Monza. The background of Torreggiani and systemic failure there
identified in 2013 followed by the decision of the court in Badre v Italy [2014] EWHC 614 (Admin) should have given
the Judge more than enough to make him pause for thought. Added to that, one sees the rising level of the prison
population in Italy. The Judge should have had (and thus should have sought) specific and precise evidence. He
failed to do so.

Section 21A, Article 3 and Prison Conditions: The Law

25 Article 3 provides:

"No one should be subjected to torture or to inhuman or degrading treatment or punishment."

26 Article 3 is absolute. It is not a qualified right unlike those contained in Articles 8 to 11 of the ECHR. A
requested person must show that there are strong or substantial grounds for believing that there is a real risk of
treatment contrary to Article 3 (see R v Special Adjudicator ex p Ullah _[2004] UKHL 26 and Saadi v Italy (2009) 49_
EHRR 30, paragraph 140). There is a body of relevant and recent case law dealing with prison overcrowding in the
extradition context, in particular _Ananyev v Russia (2012) 55 EHRR 18,_ _Mursic v Croatia (2017) 65 EHRR 1_
("Mursic") and Aranyosi. In the domestic context reference can also be made to Yaser Mohammed v Comarca de
_Lisboa Oeste_ _[2017] EWHC 3237 (Admin),_ _Yaser Mohammed (No. 2)_ [2018] EWHC 225 (Admin), _Shumba and_
_Others v Public Prosecutor in Nanterre County Court, France and Others_ _[2018] EWHC 1762 (Admin) (“Shumba”)_
and Shumba (No. 2) [2018] EWHC 3130 Admin.

27 It is sufficient for present purposes to draw on the summary of the relevant principles to be found at [34] to [39]
in Shumba:

"34. Article 3 can in principle apply where a Contracting State proposes to extradite a person to another state,
whether or not that other state is itself a party to the ECHR. As it happens France is, like the United Kingdom, a
party to the ECHR.

35. There must be substantial grounds for believing that, if extradited, the Appellant faces a real risk of being
subjected to inhuman or degrading treatment.

36. Once such evidence has been adduced by the Appellant it is for the requesting state to dispel any doubts about
it: see Saadi v Italy (2009) 49 EHRR 30, at paras. 129 and 140.

37. There is a presumption that parties to the ECHR, such as France, are willing and able to fulfil their obligations,
in the absence of 'clear, cogent and compelling' evidence to the contrary. However, that presumption can be
rebutted where that evidence comes from an internationally recognised source or is specific to an individual.

38. There may also be a duty on the Court in this jurisdiction to request further information from the state concerned
where this is necessary to dispel any doubts.

39. In the context of prison overcrowding, there will be a strong presumption of a breach of Article 3 if any of the
following criteria are absent:

(1) a private sleeping place within a prison cell;

(2) at least 3m2 of floor space per prisoner; and


-----

(3) an overall surface area of the cell which is such as to allow the detainees to move freely between the furniture
items."

28 It is relevant to note that the in‑cell sanitary facilities should not be counted in the overall surface of the cell

though it should include space occupied by furniture. What is important is whether detainees have a possibility to
move around within the cell normally (see Mursic at [114]).

29 In Mursic at [138] the Grand Chamber commented that the strong presumption will normally be capable of being
rebutted only if the following factors are cumulatively met:

"(1) the reductions in the required minimum personal space of 3 sq. m are short, occasional and minor…;

(2) such reductions are accompanied by sufficient freedom of movement outside the cell and adequate out‑of‑cell

activities…;

(3) the applicant is confined in what is, when viewed generally, an appropriate detention facility, and there are no
other aggravating aspects of the conditions of his or her detention…."

30 The approach to be taken in EAW cases where the executing court determines on the evidence that there is a
real risk of a breach was set out in Aranyosi from which the following key points can be derived:

(1) where an executing member state is in possession of evidence of a real risk of inhuman and degrading
treatment for those returned to a requesting state an assessment of the risk must be made such that return does
not result in inhuman and degrading treatment;

(2) the executing member state must initially rely on information that is objective, reliable specific and properly
updated on the detention conditions prevailing in the issuing member state and that demonstrates that there are
deficiencies which may be systemic or generalised or which may affect certain groups of people or which may affect
certain places of detention;

(3) however, a finding that there is a real risk of a breach of Article 3 in a requesting state as a result of the general
conditions of detention cannot lead in itself to the refusal to execute a European arrest warrant;

(4) the key issue is whether there are substantial grounds to believe in the case of a specific person before the
court that there is a risk of an Article 3 breach;

(5) should such substantial grounds exist, the requested state must, pursuant to Article 15(2) of the Framework
Decision, urgently request supplementary information as to the conditions the requested person will be detained in
upon return;

(6) the request for information may include inquiries regarding national or international procedures in existence for
monitoring detention conditions which make it possible for them to be assessed;

(7) a time limit may be fixed for a reply taking into account the need to observe the time limit set down in Article 17
of the Framework Decision;

(8) if, in light of the information provided, it is still found that a real risk of inhuman treatment exists then the
extradition request must be postponed but it cannot be abandoned;

(9) where a request for further information has been made, the executing judicial authority must postpone its
decision on the surrender of the individual concerned until it obtains the supplementary information that allows it to
discount the existence of such a risk. If the existence of that risk cannot be discounted within a reasonable time,
the executing judicial authority must decide whether the surrender procedure should be brought to an end.

31 Aranyosi was considered in Grecu and Another v Romanian Judicial Authorities [2017] EWHC 1427 and applied
in Dzgoev v Prosecutor General's Office of the Russian Federation [2017] EWHC 735 Admin, Kirchanov and Others


-----

v Bulgaria [2017] EWHC 827 Admin and Mohammed v Portugal [2017] EWHC 3237 Admin. In Kirchanov, the
requesting judicial authority was given the opportunity to fortify assurances where previous assurances had been
breached. They were permitted a number of attempts over a number of weeks to provide information which
eventually satisfied the court. In addition, the Divisional Court heard argument on Article 3 in respect of French
prison conditions in Grant v Public Prosecutor of Argentan, France [2018] EWHC 1630 Admin (“Grant”). The
relevant prisons in that case were running at over capacity. However, the fact that they were overcrowded by
reference to French prison standards did not, so the court found, mean that Mr Grant's personal space would be
reduced below three square metres. Consequently, the appeal was dismissed. In respect of the relevant test, the
Divisional Court stated (at [28]):

"The Judge noted the decision of the Court of Justice of the European Union in Re Criminal Proceedings against
_Aranyosi and Caldararu [2016] 3 CMLR 13 as establishing that (i) the Article 3 prohibition is absolute; (ii) where the_
executing judicial authority is in receipt of evidence said to demonstrate a real risk of a breach of Article 3, that
evidence 'must be assessed'; (iii) objective information, such as documents produced by the Council of Europe, as
well as judgments from other member states, are to be considered; (iv) if a real risk is identified, there must be a
further assessment to ascertain if the defendant will be exposed to that risk, and (v) in the course of that
assessment, the executing and issuing judicial authorities must request and provide any further relevant
information."

32 In _Jane v Prosecutor General's Office, Lithuania [2018] EWHC 1122 Admin (“Jane”) at [17] and [18] the_
Divisional Court stated:

"17. Because of the principle of mutual trust between member states, membership of the Council of Europe is a
highly relevant factor in deciding whether an extradited person would, in fact, be likely to suffer treatment contrary to
article 3 if extradited to another member state, see Targosinki v Poland _[2011] EWHC 312 (Admin) at paragraph 5._
There is a general presumption that a member state will comply with its international obligations, including those
arising from article 3 of the ECHR. That presumption may be rebutted by clear, cogent and compelling evidence,
something approaching an international consensus, see Krolik v Poland [2012] EWHC 2357; [2013] 1 WLR 490at
paragraph 3. For example, if there has been a pilot judgment of the European Court of Human Rights ("ECtHR")
against the requesting state identifying structural or systemic problems the presumption will be rebutted. Such
judgments have recently been issued against states including Italy and the Russian Federation. Where the
presumption is rebutted, the burden of proof shifts to the requesting state, which must, on the basis of clear and
cogent evidence, satisfy the Court that, in the case of the requested person, extradition will not result in a real risk
of inhuman or degrading treatment.

18. Prison conditions are unlikely to be static and to make a conclusion about the real risk test the Court has to
examine the present and prospective position as best as it can on the materials available, see Elashmawy v Italy

_[2015] EWHC 28 (Admin) at paragraph 90. The view of any Court, including the ECtHR on prison conditions in a_
country can only be definitive at the time that the view is expressed; although, where it has been established that
there is an international consensus that prison conditions in a certain state do not comply with article 3 of the
ECHR, then in the absence of evidence that there has been a material change in those conditions, a court is likely
to consider itself bound by that earlier finding. In any event, once the initial presumption of compliance has been
rebutted, then clear and cogent evidence adduced on the part of the requesting state may demonstrate that the
previous view about the prison conditions generally or a particular prison can no longer be maintained, see
_Elashmawy at paragraphs 90 and 91."_

33 Thus, the Divisional Court underlined the importance of the principle of mutual trust between member states
and the general presumption that a member state will comply with its international obligations, including those
arising from Article 3. That presumption may be rebutted by clear, cogent and compelling evidence, something
approaching an international consensus, the Divisional Court adopting the wording in Krolik v Poland [2012] EWHC
2357; [2013] 1 WLR 490 at [3] (“Krolik”).

34 We do not consider that the Divisional Court in Purcell and Pengel took a different approach to that identified in
_Shumba,_ _Jane and_ _Grant. As set out above, at [18] in_ _Purcell and Pengel Hamblen LJ stated that he did not_


-----

consider that there was an "evidential threshold" to be reached before inquiries are made of a requesting authority.
It may not be necessary to speak in terms of a particular evidence threshold but, as Hamblen LJ went on to say,:

"The court must obviously be satisfied that there is a need to seek further information."

Article 3: the merits

35 We begin our consideration of the merits set against the general legal background above but also bearing in
mind the decision in _Elashmawy where Italian prison conditions were considered in particular. The court_
considered what the cogent evidence before it established as to the prison conditions then at the time of the
judgment in January 2015 and in the near future. At [101] it held that there were no substantial grounds for
believing that there was a real risk that the appellant, if surrendered, would be subjected to an inhuman or
degrading treatment or punishment by reason of prison conditions in Italy, taking the evidence overall. The court
went on to say (at [104]):

"This judgment must be regarded as definitive of the issue of Article 3/prison conditions in Italy unless and until
cogent further evidence impels a review of the position or demonstrates that the general conclusions we have
reached cannot apply to the particular circumstances of an individual case, for which a particular, specific
assurance may be needed. We doubt very much that a single expert report could impel such a review. It will, in
general, require something like an international consensus or the considered view of the ECtHR or that of the
Committee of Ministers."

36 The Judge is criticised in this case for proceeding on the basis that an international consensus was required or

the considered view of the ECtHR or that of the Committee of Ministers. True it is that _Elashmawy pre‑dated_

_Aranyosi, but the later authority of Jane confirms that the Krolik principles are still very much alive. Whether or not_
it is right to say that an international consensus is necessary before a review is required and whether or not any
such test should only be applied at the end of a process rather than at an intermediate stage, the central question
for present purposes is whether the evidence before the Judge was such that he was obliged to seek further
information. That assessment fell to be made against the background of _Elashmawy which is, on any view,_
significant context and against the presumption of compliance.

37 This is essentially the approach the Judge took, for he asked himself whether there was clear, cogent and
compelling or powerful evidence to justify a refusal of extradition at that stage without more. He was asking himself
whether there was a need for further information.

38 The focus of course must be on whether the Judge's overall conclusion was wrong (see Love v Government of
_United States of America and Liberty [20180 EWHC 172 Admin, paragraph 26). In our judgment the Judge was_
entitled to conclude that the evidence before him was not such as to oblige him to seek further information and
entitled to proceed on the basis that there was no need for any further steps to be taken before extradition to Italy
could be ordered.

39 First, Mr Scandurra and Antigone could not indicate where the Appellant would be held. Monza was a
possibility but no more. As for Monza, the Antigone Report referred to a visit by the Observatory on 31 March 2017
and reported that there was less than three square metres per detainee. Two points can be made. First, no details
are provided as to how many detainees were affected or for how long. But critically in this regard, Mr Scandurra's
evidence confirmed that all of the overcrowding statistics provided by Antigone were based on the Italian national
standard of six square metres per prisoner. Antigone and the Italian national legislation also exclude furniture as
well as the sanitary facilities from measurements. As already indicated, Mursic proceeds on the basis that furniture

‑ though not the in‑cell sanitary facility ‑ may be included in cell space measurements. The mere fact of

overcrowding did not mean that an individual prisoner's personal space would reduce to below three square metres.
Nor was there before the Judge any specific evidence of the lack of free movement.

40 Thus, the evidence as it was presented before the Judge did not establish substantial or sufficient grounds for
him to find it necessary to proceed to seek further information in these circumstances. Subject to the question of


-----

fresh evidence, we are not persuaded the Judge erred in proceeding as he did or that he was obliged to seek
further evidence.

Application to adduce Fresh Evidence

41 As indicated, the Appellant now seeks to rely upon fresh evidence in the form of a further report by Antigone
which was published on its website on 5 November 2018 ("the 2018 Report") and which relates to an inspection
undertaken by four prison monitors from Antigone at Monza on 9 July 2018. He also seeks to rely on a witness
statement prepared by Mr Scandurra in which Mr Scandurra comments on the 2018 Report.

42 The 2018 Report states as at the date of inspection there was severe overcrowding at Monza with 203%
occupancy. Further detail is given about the use of a third camp bed installed under bunk beds with three prisoners
or detainees in a cell at any one time. When the third bed is brought out at night, it was said, it was then impossible
to walk around the cell at all.

43 In his statement Mr Scandurra confirmed that the data collected on 9 July 2018 was uploaded to Antigone
immediately after inspection but it was only published after checking and completion on 5 November 2018. Mr
Scandurra, in his statement, also identifies discrepancies in the information provided on the ground as to prison
capacity and the information provided for official channels via the Ministry of Justice. He suggests that the official
overcrowding rate is lower than the reality.

44 Mr Hawkes for the Appellant submits that this fresh evidence demonstrates that the conditions at the prison at
which it is likely that the Appellant would be held are undoubtedly not Article 3 compliant.

45 Section 27(4)(a) of the 2003 Act permits this court to consider evidence that was not raised or available at the
extradition hearing. The relevant principles for such admission are set out in Fenyvesi (supra). There, at paragraph
4 the court identified the underlying policy that fresh evidence may be received when it is just to do so or perhaps
when it would be unjust not to do so. It posed three questions which the court should ask itself (at [6]):

"The discretion to admit fresh evidence afforded by statute and rule in criminal and civil appeals respectively,
although it remains a discretion, is not unregulated. Intrinsically the principles of justice would expect the court to
ask why the evidence was not adduced at first instance, and whether there is a good reason or excuse for not doing
so – for the policy is that litigants should normally adduce their whole case and evidence at first instance. The court
would also be expected to ask what part the fresh evidence would play, if it were adduced; and in particular whether
it is credible and whether it would or might lead to a different outcome of the case. The appeal court might also be
expected to consider how it would itself deal with the fresh evidence if it were admitted. Would it hear the fresh
evidence orally and subject to cross examination? Or would it make a paper assessment of the fresh evidence to
Judge how it fits in with evidence which was adduced at first instance, which, if that was oral evidence, the appeal
court would not itself hear orally? Or would the appeal court, if it allowed the appeal, remit the matter to the lower
court for rehearing or reconsideration? Or would the appeal court, exceptionally, itself conduct a full rehearing?"

46 At [32] and [33] the court went on to consider the meaning of evidence being "not available at the extradition
hearing":

"32. In our judgment, evidence which was 'not available at the extradition hearing' means evidence which either did
not exist at the time of the extradition hearing, or which was not at the disposal of the party wishing to adduce it and
which he could not with reasonable diligence have obtained. If it was at the party's disposal or could have been so
obtained, it was available. It may on occasions be material to consider whether or when the party knew the case he
had to meet. But a party taken by surprise is able to ask for an adjournment. In addition, the court needs to decide
that, if the evidence had been adduced, the result would have been different resulting in the person's discharge.
This is a strict test, consonant with the parliamentary intent and that of the Framework Decision, that extradition
cases should be dealt with speedily and should not generally be held up by an attempt to introduce equivocal fresh
evidence which was available to a diligent party at the extradition hearing. A party seeking to persuade the court
that proposed evidence was not available should normally serve a witness statement explaining why it was not
available. The Appellants did not do this in the present appeal.


-----

33. The court, we think, may occasionally have to consider evidence which was not available at the extradition
hearing with some care, short of a full rehearing, to decide whether the result would have been different if it had
been adduced. As Laws LJ said in _The District Court of Slupsk v Piotrowski_ _[[2007] EWHC 933 (Admin) at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG31-DYBP-P0VD-00000-00&context=1519360)_
paragraph 9, section 29(4)(a) does not establish a condition for admitting evidence, but a condition for allowing the
appeal; and he contemplated allowing fresh material in, but subsequently deciding that it was available at the
extradition hearing. The court will not however, subject to human rights considerations which we address below,
admit evidence, and then spend time and expense considering it, if it is plain that it was available at the extradition
hearing. In whatever way the court may deal with questions of this kind in an individual case, admitting evidence
which would require a full rehearing in this court must be regarded as quite exceptional.”

47 As the court went on to explain at [34], the operation of these principles is not as stringent in cases such as the
present concerning human rights.

48 Mr Hawkes says that the November report could not have been obtained earlier. The evidential hearing took
place on 1 October. The judgment was dated 1 November. The report was not published until 5 November 2018.
Whilst Mr Scandurra may have been aware of the data uploaded on or about 1 July 2018, he did not make either
the court or the Appellant and his advisers aware of the existence of that data. They only became aware of it after
publication; that was the trigger for this application. Mr Hawkes submits that the Appellant was entitled to rely on
his expert's declaration as to having brought before the court on 1 October all matters that were material for the
court's consideration.

49 Miss Brown, for the Respondent, submits that the fresh evidence does not satisfy the requirements of Fenyvesi.

50 We have come to the conclusion that, notwithstanding the degree of latitude to be afforded in cases involving
human rights, it would not be just to admit and not unjust to refuse to admit this fresh evidence. There is a debate
to be had as to whether or not the fresh evidence was “available” to the Appellant at the time of the hearing within
the meaning of Fenyvesi. Certainly, his expert had access to the information. And it is surprising, at the very least,
if this evidence really is as striking as the Appellant now submits it to be, that Mr Scandurra did not see fit to refer to
it in October. Nor does Mr Scandurra's most recent witness statement provide any explanation for what is now, on
behalf of the Appellant, contended to be significant material.

51 The answer, however, to the application is a very short one, because fundamentally the fresh evidence cannot
be said to have the impact contended for by the Appellant. As indicated, it relates only to Monza Prison which is
only one of 18 prisons in Lombardy where it was then thought the Appellant might have been detained. Monza was
only ever a possible destination upon extradition. Now, in the light of the assurances received and to which we will
shortly turn, it cannot be said that Monza is even that.

52 In those circumstances the evidence is of peripheral value at best. It certainly does not justify abrogating from
the general policy that all relevant evidential matters should be placed before the court at the original hearing in the
interests of speed and finality.

The Assurances

53 If more were needed - and for the reasons set out above, we do not consider that it is - the position can and
must now be considered in the light of the assurances given by the Italian Ministry of Justice on 13 and 19 February
2019 (“the assurances”).

54 Assurances form an important part of extradition law. The Respondent emphasises that the provision of
assurances by the Italian authorities in this case is unique and specific to the facts of this case. It is by no means
accepted on the part of the Italian authorities that assurances are generally necessary in relation to Italian prison
conditions. The assurances here have been provided in the light of the remarks of Ouseley J when granting
permission (when he alluded to the possibility of assurances being sought in advance of the appeal in the light of
the procedural time constraints in Italy).


-----

55 On 11 February 2019 the Crown Prosecution Service requested an assurance from the Italian authorities with
the following questions:

"1. Where will the Appellant be detained before trial?

2. Where will the Appellant be detained during trial?

3. If he were to be convicted where will the Appellant be detained after the trial?

4. What are the current occupation rates in the establishments where the Appellant could be detained?

5. Would the Appellant be guaranteed at least three square metres of personal space including furniture but
excluding the sanitary facilities during any period of detention in Italy?"

56 On 13 February 2019 the Italian Ministry of Justice replied, stating that a prison where the Appellant is going to
be detained is determined by the Appellant's air route. If he is surrendered at Rome Airport he will be transferred
on a provisional basis to Rebbibia NC Prison and later transferred to a prison in Lombardy. If he is surrendered at
Milan he will be immediately transferred to a prison in Lombardy. Clarification followed on 19 February with the
Italian Ministry of Justice further particularising that whenever in Lombardy the Appellant would be in those prisons
located in Pavia, Cremona or Como. If convicted and when the sentence becomes final, he will be detained in a
prison also taking into account his family background.

57 The assurance on 13 February 2019 also stated in terms as follows:

"Please note that in Rebbibia (the prison in Rome) and/or when the prisoner is located in Lombardy where the
Appellant will be detained the personal space guaranteed to each inmate amounts to at least three square metres
in accordance with Article 3 of the European Convention on Human Rights. In the prisons specified above, the
hygienic and sanitary conditions are closely monitored by this administration. At present, the prisons across the
national territory comply with the requirements of Article 3 of the European Convention of Human Rights."

58 Mr Hawkes submits that these assurances fail to allay the substantial grounds for believing that the Appellant

would be held in non‑Article 3 compliant conditions. The tardiness of the assurances themselves supports what he

submits is a cavalier attitude by the Italian authorities to the Appellant's plight.

59 We say immediately that, in accordance with the guidance in Fenyvesi, we accede to the Appellant's application
to submit fresh evidence that is responsive to these assurances. By reference to that material, Mr Hawkes submits
first that the prisons in Lombardy are amongst the most overcrowded in the country. Como is one of the most
overcrowded prisons in Italy, almost as bad as Monza, with 197% overcrowding. Reference is made to an April
2018 report by Antigone and a tabular report from Antigone with population and overcrowding statistics from
January 2019. Again, reference is made to inmates not having three square metres of personal space. Pavia and
Cremona are also overcrowded, albeit to a lesser extent. Mr Hawkes submits that the assurances are too
generalised to be of any real value. We know nothing, he says, about the attenuating factors about the prison
regime. No offered explanation has been given for the lateness of the assurances. He submits that, had the Judge
been presented with these assurances, he would have been obliged either to discharge the Appellant without more
or to seek further information. That is precisely, he says, what the Court should now do. He emphasises that the
Court should not be held hostage to any accelerated timetable, something which we should put out of our minds.

60 In respect of assurances and whether they constitute fresh evidence, the position has been made clear in
_Chawla v Government of India [2018] EWHC 1050 Admin at [44]:_

"An assurance is not evidence as such: it is not evidence about actual conditions, but merely a diplomatic
assurance that a particular individual will be detained in circumstances in which the court can be satisfied that no
risk of impermissible treatment will arise…..the Court may consider undertakings or assurances at any stage of the
proceedings, including on appeal….and the Court may consider a later assurance even if an earlier assurance was
held to be insufficient…”


-----

61 We also bear in mind the decision of the Divisional Court in Georgiev v Bulgaria [2018] EWHC 359 Admin at [8]:

"…vii) The information provided may include assurances from the requesting contracting state, designed to provide
a sufficient guarantee that the person concerned will be protected from treatment that would breach article 3. In the
evaluation of such assurances, relevant factors include the nature of the relationship between the requesting and
requested judicial authorities and the states of which they are a part, the human rights situation in that other
jurisdiction, the subject matter of the assurance and the nature of the risk involved. It also has to be conducted in
the light of the principle of mutual recognition and trust between those authorities and states: where the requesting
state is a signatory to the ECHR and a Member State of the European Union, there is a strong presumption that it is
willing and able to fulfil its human rights obligations and any assurances given in support of those obligations. An
assurance given by such a state must be accepted unless there is cogent reason to disbelieve it will not be fulfilled.

viii) In particular, assurances have to be evaluated against four conditions (identified by Mitting J in BB at [5], and
approved in Zagrean at [52] as being consistent with Strasbourg jurisprudence in the form of Othman) which must
generally be satisfied if the court is to rely upon them, namely:

'(i) the terms of assurances must be such that, if they are fulfilled, the person returned will not be subjected to
treatment contrary to article 3;

(ii) the assurances must be given in good faith;

(iii) there must be a sound objective basis for believing that the assurances will be fulfilled;

(iv) fulfilment of the assurances must be capable of being verified….”

62 We are not troubled by Mr Hawkes' submission as to lateness of the assurances. Ouseley J clearly envisaged
the possibility of assurances being given by Italy in the light of the granting of permission. The authorities make it
clear that assurances can be taken into account at any stage. Miss Brown for the Respondent has explained the
timeline and the thinking behind the provision of assurances for the purposes of this appeal.

63 The Italian authorities were asked particular questions and answered the questions posed in the manner that
they did. When taken together, the assurances make it clear that the Appellant will be going to one of the three
prisons in Lombardy identified, namely Pavia, Cremona or Como, and not Monza.

64 Applying the criteria identified in the authorities to the assurances now before us, we reach the following
conclusions.

65 First, it is clear that if the assurances are fulfilled then their terms mean that the Appellant will not be subject to
treatment contrary to Article 3. Secondly, there is no suggestion that the assurances have been given on any basis
other than in good faith. Thirdly, there is a sound objective basis for believing that the assurances will be fulfilled.
Italy is a signatory to the ECHR and a member state of the European Union. There is a strong presumption that it is
both willing and able to fulfil its human rights obligations and any assurances given in support of those obligations.
There is no good reason to step behind the assurances given to this court. As Miss Brown put it, it is not for us to
carry out an audit of the position in Italy. We bear in mind Mr Hawkes' submissions in relation to the evidential
hurdles facing an Appellant presented with assurances such as these. But the fresh responsive evidence from
Antigone does not indicate clearly how it has reached its measurements, and in particular whether or not again
furniture is included or excluded. Moreover, the fresh evidence relates to findings made from visits either in May
2017 or at some stage in 2018. By contrast, the assurances are literally up to date.  Finally, the fulfilment of the
assurances is capable of being verified. The Italian authorities permit inspections by NGOs such as Antigone.
Furthermore, the evidence of Antigone is that there exists a complaints system, albeit in its early days.

66 In conclusion, the assurances are given in good faith by a friendly member state. We do not consider or
conclude that they are given lightly or without proper consideration. They are specific to the Appellant. We are not
persuaded that there is any sufficient good reason not to take them at face value. Nor is there any reason for this
court, on appeal, to seek further information.


-----

Conclusion

67 For all these reasons, the appeal will be dismissed. We should emphasise that in reaching these conclusions,
we have in no way been held hostage by reference to time limits. Rather, we have done what we consider to be
right in all the circumstances by reference to established principle and on the basis of the material and arguments
that have been put before us.

-
Transcribed by Opus 2 International Ltd.

(Incorporating Beverley F. Nunnery & Co.)

Official Court Reporters and Audio Transcribers

5 New Street Square, London EC4A 3BF

Tel: 020 7831 5627   Fax: 020 7831 7737

admin@opus2.digital

__________

This transcript has been approved by the Judge.

**End of Document**


-----

