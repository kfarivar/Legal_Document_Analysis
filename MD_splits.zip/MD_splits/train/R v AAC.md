# R v AAC [2023] EWCA Crim 15

Court of Appeal, Criminal Division

Thirlwall LJ, Johnson J and HJJ Mayo

17 January 2023Judgment

Benjamin Newton (instructed by Birds Solicitors) for the Appellant

Andrew Johnson (instructed by Crown Prosecution Service) for the Respondent

Hearing date: 20 December 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down by release to The National Archives on 17 January 2023 at 2pm

**Mr Justice Johnson:**

**Introduction**

1. On 7 September 2012, in the Crown Court at Isleworth, the appellant pleaded guilty to 21 dishonesty
offences relating to applications for identity documents and state benefits, resulting in the receipt of almost
£280,000. On 22 November 2012, she was sentenced to 27 months' imprisonment. She appeals against
conviction with the leave of the single judge who also granted the necessary extensive extension of time.
The appellant contends that she was a victim of human trafficking, that there was a close nexus between
the offences and her status as a victim of trafficking, that a prosecution was not in the public interest and
that it was an abuse of the process of the court. She applies to adduce a large volume of material as fresh
evidence pursuant to section 23 of the Criminal Appeal Act 1968. We have considered all the material
adduced by the appellant, including her own evidence, to enable us to rule on both the application to
adduce fresh evidence, and the substantive appeal, at the same time.

**The background**

_Crown's case as to the identity document offences and benefit frauds_

2. The Crown's case was that over a period of 14 years the appellant, using a variety of false identities,
obtained numerous social security benefits to which she was not entitled. She created or used at least six
different identities to obtain various forms of benefit. In respect of each identity, a genuine birth certificate
was fraudulently obtained and was then used to apply for a British or Irish passport. These were then used
to apply for benefits.

3. In November 1998, an application was made for a passport using the appellant's true name. The
application was supported by identity documents that contained false details. In September 1999, the
appellant obtained a national insurance number using the same false details.


-----

4. On 11 August 2003, the appellant submitted a passport application in another name, supported by
Portuguese identity documents. On 18 December 2003, the appellant applied for a national insurance
number using this passport.

5. In 2004 the appellant was convicted of an offence relating to a false passport. Immediately after her
release from custody after serving a sentence for that offence, she made further claims for benefits using a
false identity. Between 2004 and 2009, she made claims for incapacity benefit, income support, housing
benefit, council tax benefit and disability living allowance. Similar false representations were made on a
later housing benefit claim form. During that period, she also applied for an Irish passport, using false
information.

6. In February 2008, the appellant applied for a driving licence using an Irish passport which had been
obtained using false details. In November 2008, she applied for a driving licence in another false name,
again using an improperly obtained Irish passport. The appellant used the same false details to make a
claim for employee support allowance and disability living allowance.

7. In April 2009, the appellant made a claim for income support using false details. In August 2010, she
obtained a replacement passport using false details.

8. On 24 September 2010, the appellant filled out a disability living allowance form. She did not disclose
that she was using numerous other names and that she was a failed asylum seeker. As a result, she
received disability living allowance to which she was not entitled. She also received employee support
allowance, to which she was not entitled, using the same name.

9. A co-defendant was prosecuted with the appellant. The Crown's case was that the co-defendant was
related to the appellant, but the Crown could not say whether they were siblings or cousins. The offences
committed by the co-defendant were similar and were said to be carried out in a similar way.

_The criminal proceedings_

10. During searches of premises connected to the appellant, letters were found seeking copies of birth
certificates and also partially completed passport applications in another identity.

11. The appellant was represented by a solicitor and counsel in the criminal proceedings. Her current
representatives make no criticism of their conduct of the case. The appellant told them that she had been
subject to abuse in the course of her marriage but did not say anything to suggest that she was a victim of
trafficking. She initially indicated that she wished to plead not guilty, but after being given advice as to the
strength of the prosecution case, and the credit that would be accorded for a guilty plea, she pleaded guilty
to all counts on the indictment.

12. The appellant provided a written basis of plea in which she said that the applications for the passport
and national insurance number in 1998/99 were made at the behest of her husband.

13. In sentencing the appellant, the judge observed that although, on her written basis of plea, the
appellant's husband had been involved in the initial offending, the benefits claims were not made until
years later by which time the appellant was separated from her husband.

_Allegations of human trafficking_

14. In November 2012 the appellant was served with a notice of liability to deportation. On 3 January 2013
she submitted representations in which she made claims for asylum and human rights protection and said
that she was a victim of trafficking. She was referred to the National Referral Mechanism. The competent
authority decided that there were no reasonable grounds to believe that she was a victim of trafficking. Her
asylum application was refused, and a deportation order was made. An application for reconsideration of
the asylum decision was refused, as was an application to revoke the deportation order. The appellant
appealed against those decisions.

15. In the course of the appeal to the First-tier Tribunal, the Home Office conceded that the appellant
should be granted leave to remain in the United Kingdom pending the conclusion of proceedings regarding


-----

her son in the Family Court. She was granted six months' discretionary leave to remain. She was granted a
further period of leave which expired on 31 July 2017. She made an application for an extension of that
period of leave to remain.

16. In 2017 the appellant was interviewed by the Metropolitan Police in connection with an investigation
into an organised criminal network involved in trafficking and prostitution offences. She said that she, along
with others, was trafficked and forced into prostitution.

17. Thereafter, the appellant provided further details to the police and to her immigration solicitors. Her
case was referred back to the National Referral Mechanism. This time, in a decision dated 27 April 2019, it
was assessed, on the balance of probabilities, that the appellant was a victim of trafficking. The reasons for
the decision were: “Based on the information I have to hand, I cannot disprove [the appellant's] account of
being forced to prostitution and criminality.” There was no further analysis of the appellant's account.

18. On 19 June 2022, the First-tier Tribunal (Immigration and Asylum chamber) allowed the appellant's
appeal against the refusal to grant asylum. The Home Office did not contest the appellant's account of
what had happened to her, and did not challenge her credibility.

_The appellant's account_

19. The appellant has provided accounts on a number of occasions. At a directions hearing in June 2022,
this court made a direction for a composite statement to be compiled. Instead, we were presented with a
composite bundle of the accounts the appellant had previously provided. This included two detailed
interviews conducted under the “achieving best evidence” procedures, a witness statement she made in
the immigration proceedings, a statement she made to the police and a statement she made for the
purposes of this appeal. We summarise what we take to be the appellant's core account as follows.

20. The appellant was born in Morocco. She was promised to be married to a cousin from an early age,
but did not wish to marry him. She married another man. In 1998 she came to the United Kingdom with her
husband, using a British passport which was in her name and which she believed (wrongly) to be a
legitimate document (she thought she was entitled to a British passport because her husband was British).
They lived in a flat in London. She was not permitted to leave the flat without her husband. Her husband
was sexually demanding. When the appellant resisted, he became physically abusive. He assaulted her,
breaking her fingers. He also gave her what she now believes was a form of mind-altering drug. A cousin
of her husband (“REG”) came to the house and raped her. Her husband blamed her for the rape. She ran
away. She met a woman who took her to a police station where she attempted to report the physical
abuse. She was told to come back the following day when an interpreter would be present. When she left
the police station, she had nowhere to go. She wandered the streets. Her husband found her and took her
home. He threatened to throw acid in her face if she ran away again.

21. The appellant's husband told her that she was to work as a prostitute, and that if she did not obey she
would be sent back to Morocco. She was taken to a flat where she worked as a prostitute with two other
women. REG was always either present or close by. He gave the three women pills and alcohol. She ran
away after 5 weeks. She called a relative in Morocco. After that, another woman purported to help her, but
whilst walking with her in the street the appellant's husband approached them and told the appellant that
he was married to that other woman. They took the appellant to a flat where the appellant's husband
repeatedly raped the other woman in front of the appellant. The appellant spent the next 3 years under the
control of her husband and REG. In 2003, she was arrested twice, once for using a false credit card and
another time when she went to collect a passport in her name. In 2004, she was taken to Malaga where
she was forced to engage in sex work. She returned to the United Kingdom in May 2004 using a false
passport. She was identified as having previously been known to the immigration authorities, arrested,
charged and convicted. She served a sentence of imprisonment. When released from prison, she was
collected by REG. She worked for him during the day and was forced to engage in prostitution at night.

22. In 2007 she was introduced to KB. She was told that her husband owed KB money. She was forced to
engage in prostitution by KB. Then, she was introduced by KB to FEO. She says:


-----

“It was during this period that [FEO] filled out benefit forms. I recall during this time that they were making
multiple benefit applications, but I didn't know that there were multiple applications in my identity. It was
only later after I was arrested that I saw that my photograph was there on many different forms. I had a
bank account but no control over it. When money was put into the bank account [FEO] or [KB] would take it
straight out, or tell me to go and take the money out and give it to [FEO]. I heard that this money eventually
went to [KB]. [KB], [FEO] and [my husband] also made me, and many other people vote in the UK in local
elections for… various people on their instructions, and often using multiple identities, so that people were
voting several times each. They would tell us which names we had to select, and I was even told that they
were using identities of dead people. I believe they were making a lot of money from this somehow.”

23. In 2010, KB moved the appellant to Swiss Cottage. She continued to be forced to engage in
prostitution. She became pregnant by a client. She hoped this would provide a means of escape, but the
client refused to engage with her. KB and FEO were angry when they found out about the pregnancy. The
appellant persuaded her husband to allow her to keep the baby on the basis that she would give the baby
to her sister after it was born. Following the birth of her baby son, the appellant cared for him until her
arrest in March 2012.

24. The appellant says that when she was arrested for these offences she did not tell the truth about the
control she was under or what had been going on because she was too afraid. She was scared her son
would be put into foster care. She made only limited disclosure about what had happened to her. She said
that she had been assaulted and made to participate in sex videos. She did not go into detail about how
she had come to the United Kingdom. She said that she wished to plead not guilty, that some of the
handwriting on the claim forms was not hers, and that she had sometimes been made to sign documents.
She had never gone to a bank. She was not advised in relation to modern slavery or human trafficking.
She eventually pleaded guilty when she was given advice about the strength of the prosecution case and
the impact on sentence of a guilty plea.

25. In custody she came to trust a prison officer and told that officer a little about her past. The officer
contacted the Salvation Army, and this resulted in the first referral to the National Referral Mechanism.
When she was released from custody, the appellant went to stay with her brother. As a result of enquiries
made by her brother, the appellant was contacted by the Metropolitan Police as part of an investigation into
trafficking and prostitution.

26. In her oral evidence, the appellant said that she had signed some of the documents that resulted in her
prosecution, but not others. When she had signed documents, that had been at the instruction of her
husband and FEO. She had no choice but to sign the documents. She was under their control. If she had
refused she would have been beaten up. Effectively, she was deprived of free will or agency. Her will was
entirely suborned by her husband and FEO. It was clear that the appellant did not wish to talk about some
aspects of the relationship between her and her husband and FEO. Neither advocate sought to press her
on those issues. She did not receive any benefit from the offences. She did not have access to the bank
account into which monies were paid. She was just given small amounts of money - £20 or £40 at a time,
and never more than £60. She pleaded guilty because she feared that if she gave evidence about her
exploitation and forced prostitution her baby son would be taken away, and also because of the advice she
was given about the strength of the Crown's case and the reduced sentence for plea. She said that she
was not told that she should only plead guilty if she was guilty. In cross-examination she denied knowledge
of a person whose identity had been used in the benefit offences. In a note of instructions that she had
given to her solicitor she is recorded as saying that person was her cousin. She explained that this was a
mistake, and that her cousin was one of the other people whose identity had been used.

_Additional fresh evidence_

27. Besides the evidence she gives, the appellant also seeks to rely on the decision of the competent
authority accepting that she is a victim of trafficking, the decision of the First-tier tribunal, documentation
from the confiscation proceedings (which shows that the signature for the bank account into which the
proceeds of the fraud were paid does not match the appellant's signature) and police documentation


-----

relating to an ongoing investigation into trafficking and prostitution (in respect of which the appellant is a
potential witness).

[28. The decision of the competent authority is admissible on appeal: R v AAD [2022] EWCA Crim 106 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)

[78]. We do not, however, consider it provides any assistance. It simply accepts the appellant's account at
face value without any scrutiny. By contrast, the clear and detailed decision of the First-tier Tribunal (Judge
Cohen) is helpful. Judge Cohen sets out the detail of the immigration history and the appellant's evidence.
She records that the Home Office accepted that the appellant was a victim of trafficking. She noted that the
Home Office had not identified any adverse credibility findings. Judge Cohen found that the appellant's
account was “entirely plausible, credible and largely consistent.” She considered that medical evidence
that had been provided supported the appellant's account (in particular, the appellant's fingers showed the
consequences of what her husband had done to her, and a psychiatric report diagnosing post-traumatic
stress disorder was consistent with her account). She found that the appellant “was [forced] into
prostitution in the UK and subject to significant abuse at the hands of her traffickers and whilst undertaking
sex work.”

_The appeal and Crown's response_

29. The appellant's application for leave to appeal against her convictions was lodged on 20 July 2020.
The single Judge granted leave on 15 January 2021. On 22 February 2021, the court was informed that, as
a result of the investigation by the Metropolitan Police, material may be held that needed to be disclosed to
the appellant and a that a review of the material was being undertaken. The disclosure exercise was
completed on 7 May 2021. After the disclosure exercise was completed, amended grounds of appeal were
served on 14 June 2021. At this point, appeals raising issues concerned with victims of trafficking were
awaiting the decision in _AAD. Judgment in that case was given on 3 February 2022. The appellant was_
invited to submit amended grounds of appeal. These were submitted on 3 March 2022, and an amended
Respondent's Notice was submitted on 28 March 2022. Directions were given for the appeal on 21 June
2022.

30. Benjamin Newton, on behalf of the appellant, contends that being a victim of trafficking was integral to
the appellant's involvement in the offences of which she has been convicted. If the indicators of trafficking
had been identified, and if appropriate and pro-active enquiries had been made and further investigations
conducted, the Crown Prosecution Service would have discontinued the prosecution. If it had not done so
then the court would have been obliged to stay the criminal proceedings as an abuse of the process.

31. Andrew Johnson, for the Crown, accepts that there is credible evidence that the appellant is a victim of
trafficking. He submitted it was for the court to assess the appellant's evidence as to the connection
between the trafficking and the offending, and the reasons why the appellant pleaded guilty. If the court
rejected the appellant's account then the appeal should be dismissed. Conversely, he submitted that even
if the appellant's account is accepted the appeal should be dismissed because the appellant should not be
permitted to advance a defence that was not relied on at trial and, in any event, the appellant has not
demonstrated that she was subject to the requisite degree of compulsion.

**The law**

32. The applicable legal principles are well established as a result of many decisions of this court,
including, most recently, AAD.

33. Article 4 of the Council of Europe Convention on Action against Trafficking in Human Beings defines
trafficking to mean “the recruitment, transportation, transfer… of persons by means of forms of coercion,
…, of the abuse of power or of a position of vulnerability…to achieve the consent of a person having
control over another person, for the purpose of exploitation. Exploitation shall include, at a minimum, the
exploitation of prostitution of others or other forms of sexual exploitation…” Article 26 requires state party
signatories to the Convention to “provide for the possibility of not imposing penalties on victims [of
trafficking] for their involvement in unlawful activities, to the extent that they have been compelled to do so.”


-----

34. Section 45 of the Modern Slavery Act 2015 gives effect to article 26 of the Convention. It creates a
general defence (with limited exceptions) where a person is compelled to commit an offence, the
compulsion is attributable to slavery or relevant exploitation and a reasonable person would have no
realistic alternative.

35. The offences in the present case took place before the 2015 Act was passed. The statutory defence
therefore has no application. It follows that it is not necessary to consider the test for setting aside a guilty
plea where a defence is available: R v BXR [2022] EWCA Crim 1483 at [8].

36. Instead, effect is given to article 26 by a combination of prosecutorial discretion and the abuse of
process jurisdiction. On appeal, the issue is whether a conviction is unsafe. In this context, a conviction is
unsafe if (1) the circumstances are sufficient to reduce the appellant's culpability below a point where it is in
the public interest to prosecute, or (2) the appellant would, or might well, not have been prosecuted if the
true position had been known (the two formulations being indistinguishable): _R v GS_ _[2018] EWCA Crim_
_1824 at [76(v)] (and for a recent application of the test, see BXR at [16] and [47])._

37. In 2013, the Crown Prosecution Service provided guidance as to the application of the public interest
test in trafficking cases. This guidance postdates the appellant's conviction, but it can be taken as
representing the Crown's general approach to the public interest test at the time of these proceedings. That
guidance says that where an offence has been committed as a result of compulsion arising from trafficking,
the public interest in the prosecution should be considered:

“The means of trafficking used in an individual case may not be sufficient to give rise to a defence of
duress, but how the person was trafficked will be relevant when considering whether the public interest is
met in deciding to prosecute or proceed with a prosecution. In assessing whether the victim was compelled
to commit the offence, prosecutors should consider whether:

(1) the offence committed was a direct consequence of, or in the course of trafficking and

(2) whether the criminality is significantly diminished or effectively extinguished because no realistic
alternative was available but to comply with the dominant force of another.

Where a victim has been compelled to commit the offence, but not to a degree where duress is made out,
it will generally not be in the public interest to prosecute unless the offence is so serious or there are other
aggravating factors.”

38. Where a conviction is based on a guilty plea the test on appeal remains that of whether the conviction
[is unsafe: Criminal Appeal Act 1968, section 2(1). Necessarily, the fact that an appellant pleaded guilty is a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVT0-TWPY-Y0D5-00000-00&context=1519360)
relevant consideration. The circumstances in which a conviction might be regarded as unsafe,
notwithstanding a guilty plea are not necessarily closed: R v Tredget _[[2022] EWCA Crim 108 at [153]. They](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
include cases where (1) the plea was equivocal or unintended: _Tredget_ at [154], (2) there is a legal
obstacle to trial, for example where the prosecution is an abuse of process: Tredget at [160], and (3) it is
established that the appellant did not commit the offence: _Tredget_ at [162]. We agree with a submission
advanced by Mr Johnson that trafficking cases do not form a separate category where convictions
following a guilty plea may be regarded as unsafe. If, however, a conviction is unsafe based on the GS test
(see paragraph 36 above) then it falls within _Tredget category (2). So although trafficking cases do not_
form a separate category, many of the cases that have been found to fall within the scope of _Tredget_
category (2) have been cases where the defendant was a victim of trafficking.

**Discussion**

_The appellant's evidence_

39. The Crown did not challenge the appellant's account that she was a victim of trafficking, exploitation
and enforced prostitution. Much of the cross-examination focussed on whether and why she had
committed the offences, the reasons why she had pleaded guilty, and exploration of potential
inconsistencies in some details of her account.


-----

40. We accept the appellant's core account. It has remained broadly consistent through her ABE
interviews, her witness statements and the oral evidence she gave to us. The written instructions she
provided to her solicitor, under conditions of legal professional privilege, included (consistent with the
evidence she now gives) that she had been raped. We can well understand why she was not forthcoming
about the broader exploitation and forced prostitution. She had had only 1 or 2 meetings with her solicitor
and barrister. She was, unsurprisingly, preoccupied about keeping her son. We noticed (as did Judge
Cohen) that her fingers still showed the signs of previous injury, consistent with the account she gives
about what her husband did to her. The appellant's evidence in the immigration proceedings (which was
accepted by Judge Cohen) mentioned that her husband was in court at the time of the criminal
proceedings. That is consistent with her account of the control that he exercised, and reinforces the point
that it would have been difficult for her to give evidence in those proceedings about what had been
happening.

41. The appellant's oral evidence was as compelling for what she did not say – and the areas that she
obviously did not wish to address – as for what she did say. The fresh evidence contains accounts of
exploitation and prostitution of others at the hands of the same people who were controlling the appellant.
That evidence is untested. Even if it is taken at face value it does not directly support the appellant's
account of what happened to her. It does, however, paint a picture of a group of young vulnerable women
who had few or no connections in this country and who were subject to brutal, humiliating and oppressive
forms of exploitation and control, including forced prostitution. It is easy to understand why the appellant
did not feel able to explain what had happened to her until she found a prison officer who she felt she could
trust.

42. The inconsistency as to which alias was the name of the appellant's cousin is likely to be due to a
simple mistake in the recording of the instructions she gave to her lawyers. It does not throw doubt on her
core account. More troubling is the fact that her sister was charged with similar offences, committed in a
similar way and over a similar time period, and yet on the appellant's account her sister was not a victim of
trafficking. Mr Newton was not able to explain what might otherwise appear a remarkable coincidence. Nor
can we. It is not necessary to speculate (although we note that the sentencing judge accepted, in the
sister's case, that the underlying false passport application may well have been made by her husband). For
the reasons we have given we accept the appellant's account, despite this unresolved feature of the
evidence.

_Is the appellant a victim of trafficking?_

43. The Crown accept that the appellant is a victim of trafficking. We have accepted the appellant's
account. It follows that we consider that the Crown's concession is rightly made, and we find that she was a
victim of trafficking.

_Was the appellant acting under compulsion / what was the nexus between the offending and the_
_trafficking?_

44. It follows from our acceptance of the appellant's account that, when she signed documents and took
other steps that were said to constitute the commission of the offences with which she was charged, she
was acting under the compulsion of her husband and FEO. There is a clear and strong nexus between the
trafficking and the offending.

45. The fact that the appellant does not accept that she signed some of the documents on which the
Crown rely, and that she cannot now say which documents she did and did not sign, need not, in our
judgment, complicate the analysis. The Crown's case was that the appellant had signed the documents.
Assuming, against the appellant, she did sign the particular documents that founded any particular charge,
she did so under the total control of others. We agree with Mr Newton that it would be unjust if her position
on this appeal were weakened because, in respect of some documents, she had not signed them at all
(rather than that she had signed them under compulsion). In respect of those charges where the appellant
did not sign the underlying documents, it follows that she did not commit the offences. Her convictions in


-----

respect of those matters are unsafe, and the case falls within the third of the three categories where an
appeal may be allowed notwithstanding a guilty plea: R v Tredget _[[2022] EWCA Crim 108 at [162].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_

_Would the CPS have prosecuted / was the prosecution in the public interest?_

46. Mr Johnson rightly observed that these offences were committed over a long period of time and the
taxpayer was defrauded out of a considerable sum of money. Ordinarily, there is a strong public interest in
the prosecution of such offending. He submitted, again rightly, that the assessment of where the public
interest lies, when making a decision to prosecute, is a matter of judgement on which, in some cases,
different prosecutors might legitimately reach different conclusions. He submitted that in this case, even if
the CPS had known that the position was as the appellant now states, a decision to prosecute would have
been valid, and would not have been overturned on public law grounds. He accepted, however, that the
decision might well have been that the appellant should not be prosecuted. That is sufficient for these
purposes (see paragraph 36 above).

47. We would go further. The length of time over which the offences were committed cuts both ways. That
is because it reflects the length of time over which the appellant was controlled and exploited. We consider
that the appellant's culpability for the offending was effectively extinguished by the context in which the
offences were committed. Her will was entirely overborne, she had no real choice, and she was compelled
to act as she did. There was no public interest in prosecuting the appellant. The public interest fell firmly
against a prosecution and in favour of providing protection to the appellant. The case therefore falls within
the second of the three categories recognised where an appeal may be allowed notwithstanding a guilty
plea: Tredget at [160].

_Application to adduce fresh evidence_

48. Although the decisions of the competent authority are admissible in these proceedings they would not
be admissible in the underlying criminal proceedings. Having considered them on a provisional basis we do
not consider them to be probative of any issue in the case, and we do not consider it is necessary or
expedient in the interests of justice to receive them in evidence. We do not therefore exercise our power to
allow them to be admitted as fresh evidence on the appeal.

49. We reach the opposite conclusion in respect of the remaining material, particularly the accounts of the
appellant, the decision of Judge Cohen, the material from the confiscation proceedings and the material
produced by the police in relation to the ongoing investigations. The underlying facts that are set out in that
material appear to us to be capable of belief. For the reasons we have given, they afford grounds for
allowing the appeal. We accept that there is a reasonable explanation for the failure to adduce the
evidence in the proceedings. Judge Cohen's decision, the confiscation documents and the police material
were not available at the time of those proceedings. The control that had been, and to an extent still was
being exercised over the appellant (to the point that her husband was sitting in court) provides a
reasonable explanation for the appellant's failure then to adduce the account that she now gives. In all
these circumstances, we consider it is necessary and expedient, in the interests of justice, to receive this
material as fresh evidence. Having done so, we have concluded that the convictions are unsafe. We
therefore allow the appeal.

**Anonymity**

50. When this court made directions for the substantive appeal, it also made an interim order for
anonymity. As a result, the appellant's name was anonymised for this hearing. The court also made it clear
that the appellant would need to justify a continued claim for anonymity.

51. We have considered the guidance of the Vice President of the Court of Appeal (Criminal Division) in R
_v L and R v N_ _[[2017] EWCA Crim 2129 at [9] - [15]. The starting point is the importance of the principle of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
open justice. Anonymity orders can only be justified when they are strictly necessary. The requirement for
open justice includes the names of parties to court proceedings being public. The proceedings in the
Crown Court took place without any order for anonymity or any reporting restriction, and it is not suggested
that this has resulted in any adverse consequences for the appellant


-----

52. However, the appellant did not, in the Crown Court, give the account that she now gives about being a
victim of trafficking. That account involves her contention that she is the victim of serious sexual offences.
[She has a statutory right not to be identified as the victim of those offences: Sexual Offences (Amendment)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ80-TWPY-Y1NG-00000-00&context=1519360)
_[Act 1992, section 1. More broadly, we are persuaded that it is right to make a reporting restricting order in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ80-TWPY-Y1NG-00000-00&context=1519360)_
respect of her identity as the appellant in these proceedings. The incursion into the open justice principle
by a grant of anonymity is small. It has not been suggested that the public understanding of this case
would be appreciably enhanced by knowledge of the appellant's identity. There has been no submission on
the part of the press, or anyone else, that the appellant's identity should be revealed. We have found that
the appellant is a victim of trafficking, including as a victim of forced prostitution. Her account involves
allegations of serious sexual offences. Publication of her name, as the appellant in these proceedings,
would be a significant interference with her right to respect for her private and family life. That interference
is not, in the circumstances of this case, necessary or proportionate to secure the ends of open justice and
the rights, including the rights of the press, of freedom of expression.

**Outcome**

53. We allow the appeal and quash the appellant's convictions.

**End of Document**


-----

