Cross Society intervening) [2015] 3 All ER 827

# R (on the application of Gudanaviciene and others) v Director of Legal Aid Casework and another (British Red Cross Society intervening) [2015] 3 All
 ER 827

[2014] EWHC 1840 (Admin), [2014] EWCA Civ 1622

QUEEN'S BENCH DIVISION (ADMINISTRATIVE COURT)

COLLINS J

13–16 MAY, 13 JUNE 2014

COURT OF APPEAL, CIVIL DIVISION

LORD DYSON MR, RICHARDS AND SULLIVAN LJJ

27–29, 31 OCTOBER, 15 DECEMBER 2014

**Legal aid — Civil legal aid — Exceptional cases funding — Lord Chancellor's guidance that exceptional**
**cases funding only available in very limited cases where failure to do so being breach of human right to fair**
**hearing and access to court — Guidance stating that failure to provide legal aid in immigration cases not**
**breach of human right to family life — Whether guidance misstating effect of domestic legislation,**
**Convention jurisprudence and EU law — Legal Aid, Sentencing and Punishment of Offenders Act 2012, s 10**
**— Human Rights Act 1998, Sch 1, Pt I, arts 6, 8 — Charter of Fundamental Rights of the European Union, art**
**47.**

[The Director of Legal Aid Casework refused the applications of six claimants for civil legal aid pursuant to s 10[a] of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
the Legal Aid, Sentencing and Punishment of Offenders Act 2012, which governed 'exceptional cases funding'
('ECF'). Civil legal aid could be granted in 'exceptional' cases where (for the purposes of s 10(3)(a)) failure to
provide legal aid would be a breach of an individual's rights under the European Convention for the Protection of
Human Rights and Fundamental Freedoms 1950 (as set out in Sch 1 to the Human Rights Act 1998), or a breach of
an individual's enforceable EU rights; or where (for the purposes of s 10(3)(b)) it was appropriate to grant legal aid
'in the particular circumstances of the case, having regard to any risk that failure to do so would be such a breach'.
The Director also made his decisions in the light of the Lord Chancellor's Exceptional Funding Guidance (NonInquests) ('the guidance'). Paragraph 6 of the guidance provided that s 10(3)(b) was to be used for 'rare cases', and
para 7 stated that it would not be appropriate to fund under s 10(3)(b) 'simply because a risk (however small) exists
of a breach of the relevant rights. Rather, section 10(3)(b) should be used in those rare cases where it cannot be
said with certainty whether the failure to fund would amount to a breach of the rights … but the risk of breach is so
substantial that it is nevertheless appropriate to fund in all the circumstances of the case. This

1

a Section 10, so far as material, is set out at [4] of the judgment of Collins J and at [8] of the judgment of the Court of Appeal,
below

**[*828]**


-----

Cross Society intervening) [2015] 3 All ER 827

may be so, for example, where the case law is uncertain (owing, for example, to conflicting judgments)'. Paragraph
9 stated that the European Court of Human Rights ('ECtHR') had recognised that 'there are very limited
circumstances in which the failure of the State to provide civil legal aid may amount to breach of an individual's
rights under the European Convention on Human Rights', and para 10 stated that there was a very high threshold
for a breach of art 6(1) of the Convention, which provided a right to a fair hearing and access to a court for the
determination of a person's civil rights and obligations. That point was reiterated in para 12 which stated that 'in
certain very limited circumstances, legal aid may be required in order to guarantee the effective right of access to a
court in civil proceedings'. In that context, para 18 stated: 'The overarching question to consider is whether the
withholding of legal aid would make the assertion of the claim practically impossible or lead to an obvious
unfairness in proceedings. This is a very high threshold.' Paragraphs 19–25 set out the factors to be considered,
which were broadly the importance of the issues at stake; the complexity of the procedures, law or evidence; and
the capability of the applicant to present their case effectively. Paragraph 59 stated that proceedings relating to
immigration status did not involve the determination of civil rights and obligations, implying that art 6(1) of the
Convention would not be engaged. Paragraph 60 stated that the 'Lord Chancellor does not consider that there is
anything in the current case law that would put the State under a legal obligation to provide legal aid in immigration
proceedings in order to meet the procedural requirements of Article 8' of the Convention, which provided a right to
respect for family life. The six claimants (G, R, B, E, IS and LS) each brought separate proceedings, seeking judicial
review of the Director's decision, and the six claims were heard together. The judge granted judicial review in each
of the six cases that were before him. The judge held that the guidance was unlawful, in that it misstated the
circumstances in which ECF had to be made available under s 10(3) of LASPO. The judge held that ECF was
required under s 10(3)(a) when the applicant could establish 'to a high level of probability' that without it there would
be a breach of his procedural rights under the Convention or EU law, and that the 'risk' of a breach referred to in s
10(3)(b) was a substantial risk that there would be a breach of the procedural requirements of the Convention or EU
law. The judge also held that the guidance was incompatible with art 6(1) of the Convention and art 47 of the
Charter of Fundamental Rights of the European Union, and that the guidance also misstated the circumstances in
which art 8 of the Convention required the provision of legal aid in civil cases generally and immigration cases in
particular. Applying what he considered to be the correct test to the facts of each case, he held that in the cases of
G, R, B and E the Convention required the provision of legal aid, and that in the cases of IS and LS the decisions
should be reconsidered by the Director. The Director and the Lord Chancellor appealed in respect of G, R, B, E and
LS. They did not pursue an appeal in the case of IS, and the Director formally determined that IS qualified for legal
aid.

**Held – (1) Section 10(3) of LASPO described the scope of the exceptional cases by reference to an individual's**
Convention or EU rights. Section 10(3)(a) obliged the Director to make an exceptional case determination if he was
of the opinion that it was necessary to make the services available because failure to do so would be a breach of
the individual's Convention or EU rights. Section 10(3)(b) gave him a discretion to make a determination if he
considered
**[*829]**

it 'appropriate' to do so having regard to the risk that failure to do so would be a breach. There was no warrant for
construing s 10(3)(a) as imposing a condition that an ECF determination should only be made where it could
definitely be said that refusal would be a breach; or where there was a 'high level of probability' that refusal would
be a breach. In deciding whether there would be a breach, the Director should apply the principles to be derived
from the case law. When determining whether a complaint of a breach of Convention rights had been established,
the ECtHR did not ask itself whether there had definitely been a breach or whether there had been a breach to a
high level of probability. It simply asked whether there had been a breach. That approach should inform the
meaning of the words 'would be a breach' in s 10(3)(a). Section 10(3)(a) spoke of the situation where a failure to
make civil legal services available would be a breach, not where there would be a real risk of a breach. The concept
of real risk had no part to play in the question under s 10(3)(a) whether the denial of legal aid would amount to a
breach of an individual's procedural rights under the Convention or under art 47 of the Charter. If the Director
concluded that a denial of ECF would be a breach of an individual's Convention or EU rights, he had to make an
exceptional funding determination. If he concluded that he could not decide whether there would be a breach, he


-----

Cross Society intervening) [2015] 3 All ER 827

was not required by s 10(3)(a) to make a determination. He had to then go on to consider whether it was
appropriate to make a determination under s 10(3)(b). In making that decision, he should have regard to any risk
that failure to make a determination would be a breach. The greater he assessed the risk to be, the more likely it
was that he would consider it to be appropriate to make a determination. However, the seriousness of the risk was
only one of the factors that the Director could take into account in deciding whether it was appropriate to make a
determination. He should have regard to all the circumstances of the case. In the instant case, the judge had erred
in saying that ECF was required under s 10(3)(a) of LASPO only when the applicant could establish 'to a high
degree of probability' that, without it, there would be a breach of his procedural rights under the Convention or EU
law. Nor had he been correct to say that the 'risk' of a breach referred to in s 10(3)(b) was 'substantial risk that there
will be a breach of' the procedural requirements of the Convention or EU law (see [29]–[32] of the judgment of the
Court of Appeal, below).

(2) The guidance was not compatible with art 6(1) of the Convention and art 47 of the Charter. The cumulative
effect of paras 7, 9, 10, 12 and 18 of the guidance was to misstate the effect of the ECtHR jurisprudence. Those
passages sent a clear signal to the caseworkers and the Director that the refusal of legal aid would amount to a
breach of art 6(1) only in rare and extreme cases. There were no statements in the case law which supported that
signal. The guidance correctly identified many of the particular factors that should be taken into account in deciding
whether to make an exceptional case determination, but their effect was substantially neutralised by the strong
steer given in those passages. The critical question was whether an unrepresented litigant was able to present his
case effectively and without obvious unfairness. The answer to that question required a consideration of all the
circumstances of the case, including the factors which were identified at paras 19–25 of the guidance. Those
factors had to be carefully weighed. Thus, the greater the complexity of the procedural rules and/or the substantive
legal issues, the more important what was at stake and the less able the applicant might be to cope with the stress,
demands and complexity of the proceedings, the more
**[*830]**

likely it was that art 6(1) would require the provision of legal services (subject always to any reasonable merits and
means test). The cases demonstrated that art 6(1) did not require civil legal aid in most or even many cases. It all
depended on the circumstances. The level of procedural protection provided by art 47 of the Charter corresponded
to that provided by art 6(1) of the Convention. Accordingly, what had been found in relation to art 6(1) of the
Convention applied with equal force to art 47(3) of the Charter (see [45], [56], [59] of the judgment of the Court of
Appeal, below); Airey v Ireland _[(1979) 2 EHRR 305, X v UK (1984) 6 EHRR 136, Steel v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0KR-00000-00&context=1519360)_ _[(2005) 18 BHRC 545,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W37F-00000-00&context=1519360)_
_[AK v Croatia [2013] ECHR 37956/11, P v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0M0-00000-00&context=1519360)_ _[(2002) 12 BHRC 615 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)_

(3) The guidance was not compatible with art 8 of the Convention in immigration cases. The effect of paras 59 and
60 of the guidance was that legal aid was not available in any immigration case, regardless of the circumstances.
That was not correct. There was no reason, in principle, why the art 8 test articulated by the ECtHR in cases should
not apply in immigration cases. The fact that immigration decisions did not involve the determination of civil rights
meant that art 6(1) of the Convention could not be invoked in relation to such decisions. But it did not follow that the
procedural obligations of art 8 did not apply to immigration decisions. Article 8 could apply in immigration cases and
was frequently engaged in immigration decisions. The procedural protections inherent in art 8 were necessary in
order to ensure that art 8 rights were practical and effective. The test for art 8 as it was stated in the ECtHR
jurisprudence (whether those affected had been involved in the decision-making process, viewed as a whole, to a
degree sufficient to provide them with the requisite protection of their interests) differed from the test for art 6(1)
(whether there had been effective access to court). The art 8 test was broader than the art 6(1) test, but in practice
it was doubtful whether there was any real difference between the two formulations in the present context. There
was no basis for applying the test in a manner which was materially different from the manner in which art 6(1)
would be applied if a determination of civil rights and obligations were involved. Further, it was more likely that
cases in which an applicant sought to rely on art 8 would therefore fall more naturally to be considered under the art
6(1) heading. That fairly reflected the approach of the ECtHR. Whether legal aid was required would depend on the
particular facts and circumstances of each, including (a) the importance of the issues at stake; (b) the complexity of
the procedural, legal and evidential issues; and (c) the ability of the individual to represent himself without legal


-----

Cross Society intervening) [2015] 3 All ER 827

assistance, having regard to his age and mental capacity. The following features of immigration proceedings were
relevant: there are statutory restrictions on the supply of advice and assistance; individuals might well have
language difficulties; and the law was complex and rapidly evolving (see [69]–[75] of the judgment of the Court of
Appeal, below); Airey v Ireland _[(1979) 2 EHRR 305, W v UK (1988) 10 EHRR 29 and P v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0KR-00000-00&context=1519360)_ _[(2002) 12 BHRC 615](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)_
considered.

(4) In the instant cases, the appeals in respect of G, R, and B would be dismissed and the appeals in the cases of
LS and E allowed (see [123], [124], [135], [172], [173], [180], [184] of the judgment of the Court of Appeal, below).
**Notes**

For the provision of civil legal aid in general, see 65 Halsbury's Laws (5th edn) (2015) para 4.
**[*831]**

[For the Legal Aid, Sentencing and Punishment of Offenders Act 2012, s 10, see 11(3) Halsbury's Statutes (4th edn)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
(2013 reissue) 1090.
**Cases referred to**

_[Airey v Ireland (1979) 2 EHRR 305, [1979] ECHR 6289/73, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0KR-00000-00&context=1519360)_

_[AK v Croatia [2013] ECHR 37956/11, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0M0-00000-00&context=1519360)_

_[Al-Nashif v Bulgaria (2003) 36 EHRR 655, [2002] ECHR 50963/99, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1CD-00000-00&context=1519360)_

_[Al-Skeini v UK (2011) 30 BHRC 561, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2FC-00000-00&context=1519360)_

_[Antonis P Lemos, The [1985] 1 All ER 695, [1985] AC 711, [1985] 2 WLR 468, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-61M4-00000-00&context=1519360)_

_Associated Provincial Picture Houses Ltd v Wednesbury Corp_ _[[1947] 2 All ER 680, [1948] 1 KB 223, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-60M0-00000-00&context=1519360)_

_Bundeswettbewerbsbehörde v Donau Chemie AG (Case C-536/11) [2013] 5 CMLR 658, ECJ._

_Chahal v UK_ _[(1996) 1 BHRC 405, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3X3-00000-00&context=1519360)_

_Chapman v UK_ _[(2001) 10 BHRC 48, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W38C-00000-00&context=1519360)_

_[Ciliz v Netherlands [2000] ECHR 29192/95, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X16T-00000-00&context=1519360)_

_DEB Deutsche Energiehandels– und Beratungsgesellschaft mbH v Bundesrepublik Deutschland (Case C-279/09)_

[2010] ECR I-13849, ECJ.

_Edgehill v Secretary of State for the Home Dept [2014] EWCA Civ 402, [2014] Imm AR 883._

_FV (Italy) v Secretary of State for the Home Dept [2012] EWCA Civ 1199,_ _[[2013] 1 All ER 1180, [2013] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57XB-55K1-DYBP-M2H3-00000-00&context=1519360)_
3339.

_[Holder v Law Society [2003] EWCA Civ 39, [2003] 3 All ER 62, [2003] 1 WLR 1059.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-603S-00000-00&context=1519360)_

_[Hounga v Allen [2014] UKSC 47, [2014] 4 All ER 595, [2014] 1 WLR 2889.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DMS-8XS1-DYBP-M3G0-00000-00&context=1519360)_

_[HR (Portugal) v Secretary of State for the Home Dept [2009] EWCA Civ 371, [2010] 1 All ER 144.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XH2-66M0-Y96Y-G0YB-00000-00&context=1519360)_

_[IR (Sri Lanka) v Secretary of State for the Home Dept [2011] EWCA Civ 704, [2011] 4 All ER 908, [2012] 1 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:548T-MHR1-DYBP-M145-00000-00&context=1519360)_
232.


-----

Cross Society intervening) [2015] 3 All ER 827

_John v Rees, Martin v Davis, Rees v John_ _[[1969] 2 All ER 274, [1970] Ch 345, [1969] 2 WLR 1294.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35S0-TWP1-61K4-00000-00&context=1519360)_

_LG (Italy) v Secretary of State for the Home Dept_ _[[2009] UKAIT 24, [2009] Imm AR 691.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W59-5V00-Y9GT-12J7-00000-00&context=1519360)_

_[M v Director of Legal Aid Casework [2014] EWHC 1354 (Admin), [2014] All ER (D) 40 (May).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C4S-6RS1-DYBP-N160-00000-00&context=1519360)_

_Maaouia v France_ _[(2000) 9 BHRC 205, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W2F5-00000-00&context=1519360)_

_[McVicar v UK (2002) 12 BHRC 567, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4VR-00000-00&context=1519360)_

_MG (Prison—Article 28(3)(A) of Citizens Directive) Portugal_ _[[2014] UKUT 392 (IAC), [2015] Imm AR 128.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D2B-87C1-F0JY-C03K-00000-00&context=1519360)_

_[Mundeba (s 55 and para 297(i)(f)) [2013] UKUT 88 (IAC).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57WP-PXK1-F0JY-C3KB-00000-00&context=1519360)_

_Munro v UK (1987) 10 EHRR 516, E Com HR._

_Office of Government Commerce v Information Comr (A-G intervening)_ _[2008] EWHC 774 (Admin), [2010] QB 98,_

[2009] 3 WLR 627.

_[Osman v UK (1998) 5 BHRC 293, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3RY-00000-00&context=1519360)_

_[P v UK (2002) 12 BHRC 615, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)_

_[Pepper (Inspector of Taxes) v Hart [1993] 1 All ER 42, [1993] AC 593, [1992] 3 WLR 1032, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60C0-00000-00&context=1519360)_

_Perotti v Collyer-Bristow (a firm)_ _[[2003] EWCA Civ 1521, [2004] 2 All ER 189.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6129-00000-00&context=1519360)_

_[Pine v Law Society [2001] EWCA Civ 1574, [2001] All ER (D) 359 (Oct).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWJ1-DYBP-N3XH-00000-00&context=1519360)_

_[R v Bouchereau (Case 30/77) [1981] 2 All ER 924n, [1978] QB 732, [1978] 2 WLR 250, [1977] ECR 1999, ECJ.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-608M-00000-00&context=1519360)_
**[*832]**

_[R v Lord Chancellor, ex p Witham [1997] 2 All ER 779, [1998] QB 575, [1998] 2 WLR 849, DC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-611G-00000-00&context=1519360)_

_R (on the application of Aguilar Quila) v Secretary of State for the Home Dept, R (on the application of Bibi) v_
_[Secretary of State for the Home Dept [2011] UKSC 45, [2012] 1 All ER 1011, [2012] 1 AC 621, [2011] 3 WLR 836.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:551R-1TF1-DYBP-M209-00000-00&context=1519360)_

_R (on the application of Atamewan) v Secretary of State for the Home Dept [2013] EWHC 2727 (Admin), [2014] 1_
WLR 1959.

_[R (on the application of Begum) v Head Teacher and Governors of Denbigh High School [2006] UKHL 15, [2006] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4JVS-BPY0-TWP1-617D-00000-00&context=1519360)_
_[All ER 487, sub nom R (on the application of SB) v Governors of Denbigh High School [2007] 1 AC 100, [2006] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4JVS-BPY0-TWP1-617D-00000-00&context=1519360)_
WLR 719.

_R (on the application of CN) v Lewisham London BC, R (on the application of ZH) v Newham London BC (Secretary_
_[of State for Communities and Local Government, interested party) [2014] UKSC 62, [2015] 1 All ER 783, [2014] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FBK-BWY1-DYBP-M3R4-00000-00&context=1519360)_
WLR 1548.

_[R (on the application of Howard League for Penal Reform) v Lord Chancellor [2014] EWHC 709 (Admin), [2014] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BS9-H8J1-DYBP-N1JS-00000-00&context=1519360)_
_[ER (D) 168 (Mar).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BS9-H8J1-DYBP-N1JS-00000-00&context=1519360)_

_R (on the application of Jarrett) v Legal Services Commission_ _[[2001] EWHC Admin 389,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MK2-6NB1-F0JY-C48Y-00000-00&context=1519360)_ _[[2001] All ER (D) 111](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SPK-6M50-TWP1-718C-00000-00&context=1519360)_
_[(Jun).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SPK-6M50-TWP1-718C-00000-00&context=1519360)_


-----

Cross Society intervening) [2015] 3 All ER 827

_[R (on the application of Munjaz) v Mersey Care NHS Trust [2005] UKHL 58, [2006] 4 All ER 736, [2006] 2 AC 148,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MBK-0BW0-TWP1-60YS-00000-00&context=1519360)_

[2005] 3 WLR 793.

_R (on the application of Sandiford) v Secretary of State for Foreign and Commonwealth Affairs [2014] UKSC 44,_

_[[2014] 4 All ER 843, [2014] 1 WLR 2697.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DPM-YP81-DYBP-M407-00000-00&context=1519360)_

_R (on the application of Tabbakh) v Staffordshire and West Midlands Probation Trust [2013] EWHC 2492 (Admin),_

[2014] 1 WLR 1022.

_R (on the application of the Refugee Legal Centre) v Secretary of State for the Home Dept [2004] EWCA Civ 1481,_

[2005] 1 WLR 2219.

_RB (Algeria) v Secretary of State for the Home Dept, U (Algeria) v Secretary of State for the Home Dept, Othman v_
_[Secretary of State for the Home Dept [2009] UKHL 10, [2009] 4 All ER 1045, [2010] 2 AC 110, [2009] 2 WLR 512.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X7K-7490-Y96Y-G39K-00000-00&context=1519360)_

_Sapkota v Secretary of State for the Home Dept [2011] EWCA Civ 1320, [2012] Imm AR 254._

_Secretary of State for the Home Dept v MG (Case C-400/12) [2014] 1 WLR 2441, ECJ._

_Senigo Longue v France App No 19113/09 (10 July 2014, unreported), ECt HR._

_[Soering v UK (1989) 11 EHRR 439, [1989] ECHR 14038/88, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)_

_[Steel v UK (2005) 18 BHRC 545, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W37F-00000-00&context=1519360)_

_Stewart-Brady v UK (1997) 24 EHRR CD 38, E Com HR._

_[Tanfern Ltd v Cameron-MacDonald [2000] 2 All ER 801, [2000] 1 WLR 1311, CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-615V-00000-00&context=1519360)_

_Tuquabo-Tekle v Netherlands [2005] 3 FCR 649, ECt HR._

_[Turek v Slovakia (2007) 44 EHRR 861, [2006] ECHR 57986/00, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2CC-00000-00&context=1519360)_

_[Union of India v E B Aaby's Rederi A/S [1974] 2 All ER 874, [1975] AC 797, [1974] 3 WLR 269, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-61HT-00000-00&context=1519360)_

_W v UK_ _[(1988) 10 EHRR 29, [1987] ECHR 9749/82, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0K8-00000-00&context=1519360)_

_X v UK (1984) 6 EHRR 136, E Com HR._

_YS v Minister voor Immigratie, Integratie en Asiel; Minister voor Immigratie, Integratie en Asiel v M (Joined cases C-_
_141/12 and C-372/12) [2015] 1 WLR 609, ECJ._
**[*833]**
**ApplicationsR (on the application of Gudanaviciene) v Director of Legal Aid Casework and another**

Teresa Gudanaviciene brought proceedings seeking judicial review of the decision of the Director of Legal Aid
[Casework to refuse her application for legal aid pursuant to s 10 of the Legal Aid, Sentencing and Punishment of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
Offenders Act 2012 and in the light of the Lord Chancellor's Exceptional Funding Guidance (Non-Inquests). On 30
January 2014, Turner J ordered that her case be listed together with other cases, raising similar issues. The facts
are set out in the judgment of Collins J.
_R (on the application of IS) v Director of Legal Aid Casework and another_

IS brought proceedings seeking judicial review of the decision of the Director of Legal Aid Casework to refuse her
[application for legal aid pursuant to s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012 and in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
the light of the Lord Chancellor's Exceptional Funding Guidance (Non-Inquests). On 30 January 2014, Turner J


-----

Cross Society intervening) [2015] 3 All ER 827

ordered that her case be listed together with other cases, raising similar issues. The facts are set out in the
judgment of Collins J.
_R (on the application of Reis) v Director of Legal Aid Casework and another_

Cleon Reis brought proceedings seeking judicial review of the decision of the Director of Legal Aid Casework to
[refuse her application for legal aid pursuant to s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
2012 and in the light of the Lord Chancellor's Exceptional Funding Guidance (Non-Inquests). On 30 January 2014,
Turner J ordered that her case be listed together with other cases, raising similar issues. The facts are set out in the
judgment of Collins J.
_R (on the application of B) v Director of Legal Aid Casework and another_

B brought proceedings seeking judicial review of the decision of the Director of Legal Aid Casework to refuse her
[application for legal aid pursuant to s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012 and in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
the light of the Lord Chancellor's Exceptional Funding Guidance (Non-Inquests). On 30 January 2014, Turner J
ordered that her case be listed together with other cases, raising similar issues. The facts are set out in the
judgment of Collins J.
_R (on the application of Edgehill) v Director of Legal Aid Casework and another_

Jacqueline Elizabeth Edgehill brought proceedings seeking judicial review of the decision of the Director of Legal
[Aid Casework to refuse her application for legal aid pursuant to s 10 of the Legal Aid, Sentencing and Punishment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
of Offenders Act 2012 and in the light of the Lord Chancellor's Exceptional Funding Guidance (Non-Inquests). On
30 January 2014, Turner J ordered that her case be listed together with other cases, raising similar issues. The
facts are set out in the judgment of Collins J.
_R (on the application of LS) v Director of Legal Aid Casework and another_

LS brought proceedings seeking judicial review of the decision of the Director of Legal Aid Casework to refuse her
[application for legal aid pursuant to s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012 and in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
the
**[*834]**

light of the Lord Chancellor's Exceptional Funding Guidance (Non-Inquests). On 30 January 2014, Turner J ordered
that her case be listed together with other cases, raising similar issues. The facts are set out in the judgment of
Collins J.

_Richard Drabble QC, Ranjiv Khubber and Joseph Markus (instructed by Turpin Miller LLP) for the first claimant._

_Philipa Kaufmann QC and Chris Buttler (instructed by Public Law Project) for the second claimant._

_Tim Buley and Alistair Mills (instructed by Duncan Lewis & Co) for the third claimant._

_Paul Bowen QC and Alison Pickup (instructed by Islington Law Centre) for the fourth claimant._

_Ashley Underwood QC and Adam Tear (Solicitor Advocate) instructed by Duncan Lewis & Co) for the fifth claimant._

_Paul Bowen QC and Catherine Meredith (instructed by ATLEU) for the sixth claimant._

_Martin Chamberlain QC, Sarah Love and Malcolm Birdling (instructed by the Treasury Solicitor) for the defendants._

COLLINS J.

**[1] These six claims have been heard together pursuant to an order of Turner J made on 30 January 2014. Each**
challenges the refusal of the Director of Legal Aid Casework (whom I will refer to as the Director) to grant legal aid
[to the claimants. They raise common issues concerning the availability of legal aid in immigration cases under s 10](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
of the Legal Aid, Sentencing and Punishment of Offenders Act 2012 ('LASPO'). A number of discrete issues have


-----

Cross Society intervening) [2015] 3 All ER 827

been identified. Some are common to a number of the claims and some depend on the circumstances of one or two
of the claims but all will arise in many applications for legal aid by or on behalf of immigrants who wish to obtain a
particular decision, usually from the Home Office or an entry clearance officer, or are pursuing an appeal against an
adverse decision or are responding to an appeal against a favourable decision. The claimants contend that the
policy adopted by the Director which applies guidance issued by the Lord Chancellor is wrong in law in being too
restrictive. Further, each claimant asserts that in his or her case, having regard to the circumstances, the refusal to
grant legal aid was wrong.

**[2] Permission had been granted in one of the claims. The others were to be treated as 'rolled up hearings'. I**
granted permission in those claims which needed it subject to an undertaking to pay the necessary court fee. This
judgment deals with each claim on its merits.

**[3] Part 1 of LASPO deals with legal aid. Its effect has been to limit the circumstances in which civil legal aid can be**
granted. Section 9 of LASPO provides:

'(1) Civil legal services are to be available to an individual under this Part if—

(a) they are civil legal services described in Part 1 of Schedule 1, and

**[*835]**

(b) the Director has determined that the individual qualifies for the services in accordance with this Part (and
has not withdrawn the determination).'

Section 9(2) enables the Lord Chancellor to add, vary or omit services in Sch 1. The need for an individual to qualify
is directed largely at merits and means and is dealt with in s 11 of LASPO. I am not concerned with means in these
cases and only with merits insofar as I can properly reach a conclusion on the facts of a particular claim that to
refuse legal aid on merits grounds would be perverse.

**[4] Section 10 of LASPO is central to these cases. It is headed 'Exceptional cases' and so far as material provides:**

'(1) Civil legal services other than services described in Part 1 of Schedule 1 are to be available to an individual
under this Part if subsection (2) … is satisfied.

(2) This subsection is satisfied where the Director—

(a) has made an exceptional case determination in relation to the individual and the services, and

(b) has determined that the individual qualifies for the services in accordance with this Part,

(and has not withdrawn either determination).

(3) For the purposes of subsection (2), an exceptional case determination is a determination—

(a) that it is necessary to make the services available to the individual under this Part because failure to do so
would be a breach of—

[(i) the individual's Convention rights (within the meaning of the Human Rights Act 1998), or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

(ii) any rights of the individual to the provision of legal services that are enforceable EU rights, or

(b) that it is appropriate to do so, in the particular circumstances of the case, having regard to any risk that
failure to do so would be such a breach.'

**[5] Section 11 confers upon the Lord Chancellor the duty to set the criteria which the Director must apply in**
regulations. The material factors that must be reflected in the criteria are set out in s 11(3). They include a cost
benefit assessment, the availability of resources, the appropriateness of applying those resources having regard to


-----

Cross Society intervening) [2015] 3 All ER 827

present and future demands, the importance for the individual and the nature and seriousness of the matters for
which he requests the services, the individual's prospects of success if the services relate to a dispute, the
individual's conduct and the public interest. Section 11(5) provides:

'The criteria must reflect the principle that, in many disputes, mediation and other forms of dispute resolution
are more appropriate than legal proceedings.'

**[6] The availability of civil legal services for immigration is dealt with in paras 28–32 of Pt 1 of Sch 1 to LASPO.**
Paragraphs 28 and 29 cover victims of domestic violence. Paragraph 30 is the most material being concerned with
rights to enter and remain. Subparagraph (1) permits a grant in relation to—

'Civil legal services provided in relation to rights to enter, and to remain in, the United Kingdom arising from—

**[*836]**

(a) the Refugee Convention;

(b) Article 2 or 3 of the Human Rights Convention;

(c) the Temporary Protection Directive;

(d) the Qualification Directive.'

Apart from the general exclusions specified in Pts 2 and 3 of Sch 1 (to which it is not necessary to refer), there is a
specific exclusion of services for an attendance at an interview conducted on behalf of the Secretary of State with a
view to reaching a decision on a claim in respect of the rights set out in sub-para (1) unless regulations provide
otherwise.

**[7] The Refugee Convention (United Nations Convention relating to the Status of Refugees 1951 (Geneva, 28 July**
1951; TS 39 (1954), Cmd 9171)) and the Human Rights Convention (European Convention for the Protection of
Human Rights and Fundamental Freedoms 1950 (as set out in Sch 1 to the Human Rights Act 1998) (ECHR)) need
no explanation. The Qualification Directive is _[Council Directive 2004/83/EC (on minimum standards for the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9PT3-GXFD-84B8-00000-00&context=1519360)_
qualification and status of third country nationals or stateless persons as refugees or as persons who otherwise
need international protection and the content of the protection granted) (OJ 2004 L304 p 12), which has been given
[effect by the Refugee or Person in Need of International Protection (Qualification) Regulations 2006, SI 2006/2525.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-4WS0-TX08-H0GW-00000-00&context=1519360)
The Temporary Protection Directive refers to _[Council Directive 2001/55/EC (on minimum standards for giving](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9P33-GXFD-82V2-00000-00&context=1519360)_
temporary protection in the event of a mass influx of displaced persons and on measures promoting a balance of
efforts between member states in receiving such persons and bearing the consequences thereof) (OJ 2001 L212 p
12), which deals with minimum standards for temporary protection if there is a mass influx of displaced persons.

**[8] Section 1 of LASPO requires the Lord Chancellor to secure that legal aid is made available in accordance with**
Pt 1 of the Act. It enables him to do 'anything which is calculated to facilitate, or is incidental or conducive to, the
carrying out of the Lord Chancellor's functions under this Part' (s 1(4)). Section 4 of LASPO requires the Lord
Chancellor to designate a civil servant as Director and provide for his assistance. Section 4(3) obliges the Director
to—

'(a) comply with directions given by the Lord Chancellor about the carrying out of the Director's functions under
this Part, and

(b) have regard to guidance given by the Lord Chancellor about the carrying out of those functions.'

**[9] The Lord Chancellor has issued guidance in accordance with s 4 of LASPO. It makes clear, as is obviously**
appropriate, that applications must be considered on a case by case basis. However, the guidance lays down some
principles which the Director is to apply and some of those are said by the claimants to be unlawful. Paragraph 6 of
the guidance notes that s 10(3)(b) does not provide a general power to fund cases which fall outside the scope of


-----

Cross Society intervening) [2015] 3 All ER 827

legal aid. It is, it is said, 'to be used for rare cases' where the risk of the breach of material rights 'is such that it is
appropriate to fund'. Paragraph 7 states:

'The purpose of section 10(3) of the Act is to enable compliance with ECHR and EU law obligations in the
context of a civil legal aid scheme that has refocused limited resources on the highest priority cases.
Caseworkers should approach section 10(3)(b) with this firmly in mind. It would not therefore be appropriate to
fund simply because a risk (however

**[*837]**

small) exists of a breach of the relevant rights. Rather, section 10(3)(b) should be used in those rare cases
where it cannot be said with certainty whether the failure to fund would amount to a breach of the rights set out
at section 10(3)(a) but the risk of breach is so substantial that it is nevertheless appropriate to fund in all the
circumstances of the case. This may be so, for example, where the case law is uncertain (owing, for example,
to conflicting judgments).'

**[10] This, it is submitted by the claimants, is too restrictive. It applies an approach to s 10(3) which is not expressly**
provided for by LASPO. No doubt Parliament intended to limit legal aid in immigration cases only to those where
there was at least a risk (the context of which is to be determined in these claims) of a breach of material rights, but
that limitation should not go beyond what the law, as explained in decisions of the European Court of Human Rights
('ECtHR'), the Court of Justice of the European Union ('CJEU') and domestic cases, provides. In particular, it is
submitted that the reference to certainty is not appropriate since the requirement that the breach is 'so substantial'
will mean that only cases where the risk of breach is overwhelming can succeed. That the approach of the Director
in accordance with the guidance has had that effect is apparent from the fact that only 1% of the non-inquest
applications for exceptional case funding ('ECF') have succeeded since LASPO came into effect in April 2013.

**[11] Paragraphs 9 and 10 refer to art 6 of the ECHR and make the point that there is no specific right under art 6 for**
legal aid in civil proceedings since art 6(3) only applies to criminal proceedings. Paragraph 10 reads:

'Caseworkers will need to consider, in particular, whether it is necessary to grant funding in order to avoid a
breach of an applicant's rights under Article 6(1) ECHR. As set out below, the threshold for such a breach is
very high.'

Article 6 applies only if the case involves the determination of civil rights and, it is said, the test to be applied by
caseworkers is—

'will withholding of legal aid make assertion of the claim practically impossible or lead to an obvious unfairness
in the proceedings?'

This is, as is said, a very high threshold.

**[12] The guidance sets out various matters which should be taken into account in judging the importance or**
seriousness of what is at stake both for the applicant and more generally. Factual, legal or procedural complexity is
material. Relevant considerations explicitly referred to include whether the degree of emotional involvement that the
applicant is likely to have is incompatible with the degree of objectivity expected of advocates in court. In practical
terms that is highly likely to be the situation in most appeals by immigrants who wish to enter or remain. Whether
the applicant has any relevant skills or experience is a material consideration. Again, in all but a very small fraction
of cases an applicant will lack skills and experience. On the other side of the coin, the court's or tribunal's familiarity
with having to deal with litigants in person is material. In addition, the ability of an applicant to understand English
and any disabilities he may suffer are material. If the applicant lacks capacity within the meaning of the _[Mental](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)_
_[Capacity Act 2005, the caseworker must consider how capable his litigation friend is to present his case.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)_
**[*838]**

**[13] Article 8 of the ECHR is referred to in paras 26–28 of the guidance. Reference is made to two ECtHR cases,**
_[Airey v Ireland (1979) 2 EHRR 305 and P v UK (2002) 12 BHRC 615. These I will have to consider when dealing](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)_


-----

Cross Society intervening) [2015] 3 All ER 827

with what is required in immigration cases to meet any procedural obligations which exist to enable art 8 rights to be
properly protected. Paragraph 28 makes the point that in those cases (which were not immigration cases) the
ECtHR found a breach of art 6 in the failure to provide legal aid and so '[i]t is likely that cases in which an applicant
seeks to rely on Article 8 would therefore fall more naturally to be considered under the Article 6(1) heading'.

**[14] In paras 59 and 60 under the heading 'Immigration' it is said that proceedings relating to the immigration status**
of immigrants and decisions relating to their entry, stay or deportation do not involve the determination of civil rights
and obligations. Thus art 6 will not apply. Paragraph 60 reads:

'The Lord Chancellor does not consider that there is anything in the current case law that would put the state
under a legal obligation to provide legal aid in immigration proceedings in order to meet the procedural
requirements of Article 8 ECHR.'

**[15] The test of practical impossibility or obvious unfairness set out in the guidance derives from a decision of the**
European Commission of Human Rights in X v UK (1984) 6 EHRR 136. Mr Chamberlain QC referred to a number
of domestic cases in which that test was, he submitted, if not explicitly approved, accepted and certainly not
disapproved. The claimants contend that that test is not only not reflected in any subsequent ECtHR jurisprudence
but is not consistent with what the court has stated. That goes to whether the level required to justify legal aid is set
too high in the guidance. The other issue in relation to art 8 is whether, despite the non-applicability of art 6 in
immigration cases, the procedural requirements of art 8 may require the grant of legal aid in certain circumstances.

**[16] The claimants Gudanaviciene and Reis are both EU nationals who are appealing against decisions that they**
should be deported following convictions of criminal offences. They therefore have enforceable EU rights within s
10(3)(a)(ii) of LASPO. The claimant S is a victim of trafficking ('VOT') and asserts that he has such a right which
should apply to grant him legal assistance to establish that he is such a victim. This assertion is not accepted by Mr
Chamberlain. The guidance refers specifically to such EU rights in paras 30–34. Article 47 of the Charter of
Fundamental Rights of the European Union applies. This provides, under the heading 'Right to an effective remedy
and to a fair trial':

'Everyone whose rights and freedoms guaranteed by the law of the Union are violated has the right to an
effective remedy before a tribunal in compliance with the conclusion laid down in this Article.

Everyone is entitled to a fair and public hearing within a reasonable time by an independent and impartial
tribunal previously established by law. Everyone shall have the possibility of being advised, defended and
represented.

Legal aid shall be made available to those who lack sufficient resources insofar as such aid is necessary to
ensure effective access to justice.'

**[17] The guidance states in para 31 that the explanations to the Charter provide that the content of art 47 is 'the**
same as that of Article 6(1) ECHR'. The explanation in relation to art 47(3) states:
**[*839]**

' … it should be noted that in accordance with the case law of the ECtHR, provision should be made for legal
aid where the absence of such aid would make it impossible to ensure an effective remedy … '

Reference is made to Airey v Ireland as support for that. The attack on the approach to art 6 requirements in the
guidance is thus equally material in relation to art 47(3). The claimants further pray in aid art 19 of the Treaty on
European Union ('TEU'). This deals with the CJEU but contains under para (1) this:

'Member States shall provide remedies sufficient to ensure effective legal protection in the fields covered by
Union law.'

I do not think this really adds anything to art 47.


-----

Cross Society intervening) [2015] 3 All ER 827

**[18] The issues said to be common to several of the claimants' pleaded cases include consideration as to whether**
art 8 of the ECHR either alone or in conjunction with art 14 (prohibition of discrimination) requires the provision of
legal aid to avoid a breach where art 6 does not also apply and, if so, in what circumstances. The second relates to
the circumstances in which art 47 of the Charter requires the provision of legal aid and how, if at all, there is a
difference from what art 6 of the ECHR requires. Thirdly, the question is posed whether the Lord Chancellor's
guidance properly identifies and reflects the procedural requirements of art 8 of the ECHR and art 47 of the Charter.
Fourthly, what are the proper ingredients of the tests to be applied in s 10(3)(a) and (b) of LASPO? Finally, does the
Lord Chancellor's guidance properly state the tests to be applied in making an exceptional case determination? The
issues clearly overlap. It is desirable to deal with them before going to the facts of each individual claim since they
will obviously help to determine whether the decision made was in accordance with the law. However, it must be
borne in mind that even if the approach adopted was wrong, relief will not be granted if it is clear that the decision
would be the same on the correct approach.

**[19] The 'overarching question' posed in the guidance is 'whether the withholding of legal aid would make the**
assertion of the claim practically impossible or lead to an obvious unfairness in proceedings'. This is said to be a
very high threshold. As I have said, it is based on _X v UK_ (1984) 6 EHRR 136. In setting out this test, the
Commission referred to _Airey v Ireland_ _[(1979) 2 EHRR 305. Airey's case concerned the need for a party to a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0KR-00000-00&context=1519360)_
marriage to apply to the High Court for a decree of judicial separation but legal aid was not available. The litigation
in question involved complicated points of law, a need to prove a matrimonial offence and, as must be obvious, an
emotional involvement on the part of a petitioner that was scarcely compatible with the degree of objectivity
required by an advocate in court (see para 24). That meant that the possibility to appear in person did 'not provide
the applicant with an effective right of access'.

**[20] The court considered (at paras 31–32) whether there was a breach of art 8 as well as art 6. It decided that**
there was since, in addition to the primarily negative undertaking not to interfere in a disproportionate fashion with
art 8 rights, respect for private or family life obliged the state to make a means of protection effectively accessible in
order to avoid any breach. The court did not indicate what that test should be beyond saying that the means of
protection must be effectively accessible (art 8) or there must be effective access to a court (art 6).
**[*840]**

**[21]** _[P v UK (2002) 12 BHRC 615 concerned removal of S from her parents based on her mother P's conviction in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)_
the United States of endangering her young son's health and an adjudgment that she suffered from Munchausen's
syndrome. She chose, it seems, to represent herself before the High Court, but the ECtHR found that there had
been a breach of art 8 in respect of the applicants (C was her husband) as regards S's removal at birth and the
subsequent care and adoption procedures. The court observed (at para 119):

'… whilst art 8 contains no explicit procedural requirements, the decision-making process involved in measures
of interference must be fair and such as to afford due respect to the interests protected by art 8.'

**[22] The court cited a passage from** _W v UK (1988) 10 EHRR 29, another case concerning restriction and_
termination of rights of access by a parent to his child. The law then in force provided no statutory remedy whereby
the applicant could contest the isolated issue of the decision to restrict or terminate his access to his child, save by
judicial review which did not give an appeal on fact. The court in W v UK stated (at para 62):

'It is true that Article 8 contains no explicit procedural requirements, but this is not conclusive of the matter …
the court is entitled to have regard to [the decision-making] process to determine whether it has been
conducted in a manner that, in all the circumstances, is fair and affords due respect to the interests protected
by Article 8.'

There is no reference to _X v UK and the test is fairness and whether, as the court observes (at para 64), 'the_
parents have been involved in the decision-making process, seen as a whole, to a degree sufficient to provide them
with the requisite protection of their interests'.


-----

Cross Society intervening) [2015] 3 All ER 827

**[23] In** _Steel v UK_ _[(2005) 18 BHRC 545, the court considered an application by the two London Greenpeace](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W37F-00000-00&context=1519360)_
activists who had been defendants in a libel claim by McDonalds which had lasted for some 313 days and for which
legal aid had been unavailable. The court said this:

'59. The court recalls that the [ECHR] is intended to guarantee practical and effective rights. This is particularly
so of the right of access to court in view of the prominent place held in a democratic society by the right to a fair
trial … It is central to the concept of a fair trial, in civil as in criminal proceedings, that a litigant is not denied the
opportunity to present his or her case effectively before the court and that he or she is able to enjoy equality of
arms with the opposing side …

60. Article 6(1) leaves to the state a free choice of the means to be used in guaranteeing litigants the above
rights. The institution of a legal aid scheme constitutes one of those means but there are others, such as for
example simplifying the applicable procedure …

61. The question whether the provision of legal aid is necessary for a fair hearing must be determined on the
basis of the particular facts and circumstances of each case and will depend inter alia upon the importance of
what is at stake for the applicant in the proceedings, the complexity of the relevant law and procedure and the
applicant's capacity to represent him or herself effectively.

62. The right of access to a court is not, however, absolute and may be subject to restrictions, provided that
these pursue a legitimate aim and are proportionate … It may therefore be acceptable to impose conditions on

**[*841]**

the grant of legal aid based, inter alia, on the financial situation of the litigant or his or her prospects of success
in the proceedings … Moreover, it is not incumbent on the state to seek through the use of public funds to
ensure total equality of arms between the assisted person and the opposing party, as long as each side is
afforded a reasonable opportunity to present his or her case under conditions that do not place him or her at a
substantial disadvantage vis-à-vis the adversary … '

It is to be noted that the court referred to Airey v Ireland and P v UK but not to X v UK. And again the court said (at
para 71) that in the circumstances the opportunity to present their case effectively before the court was prevented
by the refusal of legal aid.

**[24] The ECtHR has more recently confirmed the need to recognise that art 8 has its procedural requirements. The**
case in question is _AK v Croatia_ _[[2013] ECHR 37956/11, judgment having been given on 8 January 2013 and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0M0-00000-00&context=1519360)_
became final on 8 April 2013. The case concerned the divesting of the applicant AK of her parental rights in respect
of her son L. The court recognised (at para 63) that the views of a child's natural parents must be available to the
authority which makes the relevant decision and any court to which an appeal lies. This means, the court said:

'The decision-making process must … be such as to ensure that their views and interests are made known to,
and duly considered by, the local authority and that they are able to exercise in due time any remedies
available to them.'

The applicant AK had a mild mental disability, a speech impediment and a limited vocabulary. Thus her interests
were not adequately protected since she had been required to appear unrepresented in the proceedings which
divested her of her parental rights. Having regard to the serious consequence to her right to family life, the failure to
grant representation meant that there was a breach of art 8 since the decision could not be regarded as necessary
for the purposes of art 8(2).

**[25]** _R (on the application of Begum) v Head Teacher and Governors of Denbigh High School [2006] UKHL 15,_

_[[2006] 2 All ER 487, [2007] 1 AC 100concerned a contention that the claimant's art 9 rights had been breached by](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4JVS-BPY0-TWP1-617D-00000-00&context=1519360)_
the prohibition against her attendance at school wearing a 'jilbab'. Lord Bingham of Cornill, having cited from the
decision of the ECtHR in Chapman v UK _[(2001) 10 BHRC 48 the statement that the court must examine whether](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W38C-00000-00&context=1519360)_
the decision-making process was fair and such as to afford due respect to the interests of the individual


-----

Cross Society intervening) [2015] 3 All ER 827

safeguarded by art 8, made clear (at [29]) that a court must provide the individual with a fair opportunity to put his
case.

**[26] Mr Chamberlain cited a number of domestic cases in which the X v UK test was, he submitted, accepted in**
[relation to art 6. In R (on the application of Jarrett) v Legal Services Commission [2001] EWHC Admin 389, [2001]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MK2-6NB1-F0JY-C48Y-00000-00&context=1519360)
_[All ER (D) 111 (Jun), counsel for the claimant did not argue that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4SPK-6M50-TWP1-718C-00000-00&context=1519360)_ _X v UK test was erroneous and it was_
accordingly applied by Burton J. In _Pine v Law Society_ [2001] EWCA Civ 1574, _[[2001] All ER (D) 359 (Oct), the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWJ1-DYBP-N3XH-00000-00&context=1519360)_
same counsel again did not challenge the X v UK approach. Indeed, as is clear from the judgment of Sir Andrew
Morritt V-C, who gave the only reasoned judgment, counsel positively accepted that the relevant principle was that
[in X v UK (see [28]). In Holder v Law Society [2003] EWCA Civ 39, [2003] 3 All ER 62, [2003] 1 WLR 1059it was](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-603S-00000-00&context=1519360)
accepted by Carnwath LJ, following Pine, that the X v UK test was appropriate. Again, the contrary was not argued.
**[*842]**

**[27] In Perotti v Collyer-Bristow (a firm)** _[[2003] EWCA Civ 1521, [2004] 2 All ER 189, the court was concerned with](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6129-00000-00&context=1519360)_
an application for leave to appeal by a litigant in person who, as Chadwick LJ observed, was an experienced litigant
who had often in the past appeared in the Court of Appeal to present his applications in person. Chadwick LJ
observed that, while an indication by a court and in particular the Court of Appeal that legal representation was
necessary in order to ensure a fair hearing would be likely to lead to a grant of legal aid, the court could not direct
the Legal Services Commission to make a grant. He said (at [29]) that it was not in doubt that one aspect of the
right to a fair hearing was effective access to the court. Having cited the Commission's observations in _X v UK,_
Chadwick LJ continued:

'[31] Miss Moore [as advocate to the court] suggests in her written submissions, in my view correctly, that the
obligation on the state to provide legal aid arises if the fact of presenting his own case can be said to prevent
him from having effective access to the courts. But a litigant who wishes to establish that without legal aid his
right of effective access will have been violated has a relatively high threshold to cross.

[32] It is, in my view, important to have in mind that however much this court, and indeed any other court, would
welcome the assistance that can be given by a legally qualified and competent advocate, the test is not
whether (with such assistance) this court would find it easier to reach the decision which it has to reach on the
facts of the case. This court, and other courts, have ample experience of cases in which the material is not
presented in an ideal form; and have not found it impossible to reach just decisions in such cases. The test
under art 6(1), as it seems to me, is whether a court is put in a position that it really cannot do justice in the
case because it has no confidence in its ability to grasp the facts and principles of the matter on which it has to
decide. In such a case it may well be said that a litigant is deprived of effective access; deprived of effective
access because, although he can present his case in person, he cannot do so in a way which will enable the
court to fulfil its paramount and over-arching function of reaching a just decision. But it is the task of courts to
struggle with difficult and ill-prepared cases; and courts do so every day. It is not sufficient that the court might
feel that the case could be presented better; the question for the court is whether it feels that the case is being,
or will be, presented in such a way that it cannot do what it is required to do—that is to say, reach a just
decision. If it cannot do that the litigant is effectively deprived of proper access to the courts.'

**[28] It seems to me to be clear that the key considerations are that there must be effective access to a court and**
that there must be overall fairness in order that the requirements of art 6 are met. One aspect of effective access
must be the ability of a party to present all necessary evidence to make his case and to understand and be able to
engage with the process. So much is apparent from _AK v Croatia. It must be borne in mind that both before a_
tribunal and a court the process is adversarial. Thus the tribunal cannot obtain evidence where there are gaps in
what an applicant has been able to produce. Equally, it may have difficulties if there is defective written material put
before it in appreciating whether there is any substance to a claim or even if any particular human rights claim is
properly raised. I think the words 'practically impossible' do set the standard at too high a level, but, as Chadwick LJ
indicated, the threshold is relatively high. No doubt it would generally be better if an appellant were
**[*843]**


-----

Cross Society intervening) [2015] 3 All ER 827

represented, but that is not the test. Nevertheless, the Director should not be too ready to assume that the tribunal's
experience in having to deal with litigants in person and, where, as will often be the case, the party's knowledge of
English is non-existent or poor, the provision of an interpreter will enable justice to be done.

**[29] A further relevant consideration in immigration cases is the difficulty in finding advisers who can lawfully give**
advice having regard to _Pt V of the Immigration and Asylum Act 1999 and in particular s 84 which, by s 84(1),_
provides:

'No person may provide immigration advice or immigration services unless he is a qualified person.'

This covers a barrister or solicitor or a person authorised by a designated qualifying regulator or those who are
registered or exempted by the Office of the Immigration Services Commissioner at the appropriate level. A criminal
offence is only committed by those who give immigration advice or provide services in the course of a business
carried on (whether or not for profit), but this has been given a wide scope. The reasons are obvious. Without
access to properly accredited advisers, immigrants, who are in many cases vulnerable and unfamiliar with the
English language, will be made the prey of unscrupulous so-called advisers. This is an aspect of the new situation
following LASPO which has not been covered in the guidance and which is an important consideration when legal
aid is refused on the basis that other services or assistance are available.

**[30] Mr Chamberlain submits that there is no case law whether domestic or from Europe which requires that legal**
aid be granted for the purpose of meeting the procedural requirements of art 8 in immigration cases in particular.
The starting point for this submission is the decision of the Grand Chamber of the ECtHR in _Maaouia v France_
_[(2000) 9 BHRC 205. Article 1 of Protocol 7 to the ECHR contains procedural guarantees applicable to the expulsion](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W2F5-00000-00&context=1519360)_
of aliens. This had been ratified by France. This meant, the court stated (at para 37), that the 'states clearly
intimated their intention not to include such proceedings within the scope of art 6(1)'. The UK has not ratified
[Protocol 7 nor is art 13 of the ECHR included in the Human Rights Act 1998. Thus there are no specific procedural](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
guarantees which apply in immigration cases. The court said (at para 38):

'In the light of the foregoing, the court considers that the proceedings for the rescission of the exclusion order,
which form the subject matter of the present case, do not concern the determination of a “civil right” for the
purposes of art 6(1). The fact that the exclusion order incidentally had major repercussions on the applicant's
private and family life or on his prospects of employment cannot suffice to bring these proceedings within the
scope of civil rights protected by art 6(1) of the [ECHR] … '

**[31] It is to be noted that in the explanatory note to Protocol 7, this is said in para 6:**

' … it is stressed that an alien lawfully in the territory of a member State of the Council of Europe already
benefits from certain guarantees when a measure of expulsion is taken against him, notably those which are
afforded by Articles 3 … and 8 …, in connection with Article 13 … '

[While art 13 is not specifically applied by the Human Rights Act 1998, it was](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
**[*844]**

regarded as unnecessary since domestic law provided sufficient protection for individuals. But the existence of art 1
of Protocol 7 and art 13 has meant that the ECtHR has not needed to decide whether the procedural requirements
of art 8 need to be applied. It is only because the UK has not ratified Protocol 7 and has not incorporated art 13 that
the submission that art 8 procedural requirements cannot be relied on in immigration cases can be made. But there
are procedural requirements in order to make art 8 rights effective and there is no reason in my view to believe that
they are excluded when the reasoning which led to the decision in Maaouia, which was concerned only to decide
whether art 6(1) applied is taken into account.

**[32] The House of Lords considered the implications of the exclusion of immigration decisions from the scope of art**
6 in _RB (Algeria) v Secretary of State for the Home Dept, U (Algeria) v Secretary of State for the Home Dept,_
_[Othman v Secretary of State for the Home Dept [2009] UKHL 10 [2009] 4 All ER 1045 [2010] 2 AC 110 The three](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X7K-7490-Y96Y-G39K-00000-00&context=1519360)_


-----

Cross Society intervening) [2015] 3 All ER 827

cases considered together involved deportation based on danger to national security. The contention on the
appellants' behalf was that there was a real risk that their art 3 rights would be breached if they were returned or (in
the case of the appellant Othman, better known as Abu Qatada) a flagrant breach of arts 5 and 6 would occur. It
was submitted that the Special Immigration Appeals Commission ('SIAC') procedure which enabled reliance to be
placed on closed material without any knowledge by those to be deported of even the gist of material allegations
was unfair and unlawful.

**[33] The arguments put forward by the claimants were that the risk of breaches of arts 3, 5 and 8 meant that there**
had to be conformity with art 6 rights in deciding on deportation. The whole purpose of the claims was to try to
engage art 6 since anything less would, it was recognised, be likely to mean that the SIAC procedure was upheld.
This was largely because in Chahal v UK _[(1996) 1 BHRC 405 the ECtHR decided that, albeit there needed to be an](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3X3-00000-00&context=1519360)_
'effective remedy' to protect art 3 rights, that remedy did not need to be compliant with art 6. Indeed, in Chahal the
court had implicitly recognised the acceptability of closed hearings as carried out by SIAC. Indeed, SIAC was
brought into being following the decision in Chahal and the recognition that the existing procedure involving scrutiny
by what were called 'the three wise men' was inadequate.

**[34] Mr Chamberlain has contended that the argument presented by Mr Rabinder Singh QC in the appeal went no**
further than submitting that there was a need for safeguards equivalent to those provided by art 6 because of the
effect on the various human rights which were involved. But that was not the basis of his argument as understood
by their Lordships. Thus Lord Hoffmann said (at [175]):

' … It is clear that the criterion for the [ECtHR] in deciding whether art 6 is engaged is the nature of the
proceedings and not the articles of the [ECHR] which are alleged to be violated. If the proceedings concern
deportation, art 6 is not engaged, whatever might be the other articles potentially infringed by removal to
another country.'

While RB (Algeria) v Secretary of State for the Home Dept was concerned with deportation, it is clear from Maaouia
that the exclusion of art 6 applies to all immigration cases.

**[35] Lord Hope of Craighead expressed his views in much the same way as Lord Hoffmann. He stated (at [230]):**
**[*845]**

'There remains however the question whether the use of closed material fails to meet the minimum standard of
procedural fairness that is to be expected of any such tribunal in a democratic society …'

He analysed the procedures and decided that they did provide a fair balance between the need to protect the public
interest and the need to provide the applicant with a fair hearing. But he recognised that there do exist minimum
standards. In the absence of specific application of art 13 or Protocol 7, those minimum standards must be applied
to decide whether the interference with private or family life is proportionate because necessary in a democratic
society. It follows that there may be cases in which a failure to grant legal aid may breach minimum standards so
that para 60 of the guidance is erroneous. If legal aid is needed to provide that the procedure is effective and fair in
dealing with art 8 rights it will have to be provided. No doubt the threshold is a relatively high one, but, as I have
already indicated, it is not in my view as high as suggested by X v UK.

**[36] Article 47(3) of the Charter provides that legal aid shall be provided in so far as necessary to ensure effective**
access to justice. This is a clear recognition that legal aid may be required and so goes to that extent beyond art 6,
since art 6 only requires legal aid in criminal cases. In the explanation, as I have already stated, this is said in
relation to art 47(3):

'With regard to the third paragraph, it should be noted that in accordance with the case law of the ECtHR,
provision should be made for legal aid where the absence of such aid would make it impossible to ensure an
effective remedy … There is also a system of legal assistance before the CJEU.'


-----

Cross Society intervening) [2015] 3 All ER 827

_Airey v Ireland is referred to as an authority for the first sentence. The use of the word 'impossible' could be argued_
to set a very high threshold. But I do not believe it was intended to do more than indicate that what has to be
considered is whether without legal assistance the remedy could be made effective. In addition, I think fairness
must be a factor to be taken into account. That that is what is meant is consistent with the explanation of art 47(1)
which is said to be based on art 13 of the ECHR but to go further because 'in Union law the protection is more
extensive since it guarantees the right to an effective remedy before a court'.

**[37] The claimants have submitted that art 47(3) confers a right which goes beyond what art 6 requires. If art 6 is**
correctly construed in X v UK, I would agree, but in my view, as I have said, it is not. The observations of Advocate
General Jääskinen in Bundeswettbewerbsbehörde v Donau Chemie AG (Case C-536/11) [2013] 5 CMLR 658 (para
47) are cited. He says:

'Pursuant to Article 19(1) [of the TEU], Member States are bound to provide remedies “sufficient to ensure
effective legal protection in the fields covered by Union law”. In other words, in the light of that Treaty provision,
the standard of effective judicial protection for EU based rights seems to be more demanding than the classical
formula referring to practical impossibility or excessive difficulty. In my opinion this means that national
remedies must be accessible, prompt and reasonably cost effective.'

**[38] In DEB Deutsche Energiehandels– und Beratungsgesellschaft mbH v Bundesrepublik Deutschland (Case C-**
_279/09) [2010] ECR I-13849, the CJEU_
**[*846]**

considered the approach which should apply in granting legal aid in the context of the right to a fair trial. The court
referred to the ECtHR's approach under art 6 of the ECHR, stating (at para 45) that it was important for a litigant not
to be denied the opportunity to present his case effectively before the court. For this proposition, Steel v UK was
cited. The court said (at para 46):

'Ruling on legal aid in the form of assistance by a lawyer, the ECtHR has held that the question whether the
provision of legal aid is necessary for a fair hearing must be determined on the basis of the particular facts and
circumstances of each case and will depend, inter alia, upon the importance of what is at stake for the
applicant in the proceedings, the complexity of the relevant law and procedure and the applicant's capacity to
represent himself effectively …'

The ECtHR cases of _Airey v Ireland, McVicar v UK_ _[(2002) 12 BHRC 567,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4VR-00000-00&context=1519360)_ _P v UK_ and _Steel v UK are cited in_
support of those observations. There is no reference to X v UK.

**[39] It is, I think, apparent that art 47(3) does not set a standard which is lower than that applicable to art 6.**
However, provided that the effectiveness and fairness criteria are properly applied, it does not necessarily set a
higher standard. And there is further support for the view that X v UK sets too high a threshold.

**[40] I come now to consider what is the correct approach to s 10(3) of LASPO. In their joint skeleton argument on**
the matters common to a number of the claims, the claimants said that it was likely to be relatively unusual for the
Director to be satisfied that the s 10(3)(a) test was met and so s 10(3)(b) assumed critical importance. In argument,
that was resiled from to an extent. It was submitted that, since s 10(3) was concerned with procedure intended to
prevent a breach of ECHR rights, the 'breach' referred to in s 10(3) must refer to a breach of the procedural
requirements inherent in any article and not breach of the substantive right itself. Mr Chamberlain accepted that s
10(3) was concerned with procedural rights. Since the procedural requirements exist in order to make effective the
protection provided by the relevant article, the ultimate question must be whether denial of legal aid would either
cause or produce a risk of causing a breach of a requirement needed to avoid a breach of the substantive right
conferred by the relevant article.

**[41] In a decision given on 2 May 2014, Coulson J considered the proper approach to s 10(3). The case in question**
is _M v Director of Legal Aid Casework [2014] EWHC 1354 (Admin),_ _[[2014] All ER (D) 40 (May). It was not an](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C4S-6RS1-DYBP-N160-00000-00&context=1519360)_
immigration case. Since Coulson J found in the claimant's favour because the merits criteria had not been properly


-----

Cross Society intervening) [2015] 3 All ER 827

applied, any conclusions on the correct approach to exceptional funding were not needed. However, since the issue
might arise if the Director refused legal aid on the basis that the claimant's application did not fall within the scope of
Pt 1 of Sch 1 to LASPO, he believed it sensible to deal with the issue. Thus I suppose his conclusions may strictly
be regarded as obiter dicta, but they were based on full argument and so carry considerable weight.

**[42] There had been argument about what was meant by an exceptional case. He decided that it covered cases**
which fell outside Pt 1 of Sch 1 and so were an exception to the general regime which limited a right to legal aid
(subject to means and merits which include cost considerations) to cases falling within Pt 1. Thus exceptional has
no wider meaning. This construction is not challenged by Mr Chamberlain.
**[*847]**

**[43] Coulson J considered that cases falling within s 10(3)(a) would be extremely rare since they would require the**
defendant to be able to identify, in advance, a case where the non-provision of civil legal aid would, without
qualification, be a breach of the applicant's ECHR rights. He continued (at [59]):

' … That requires complete certainty on the part of the defendant at the outset and therefore requires a very
high threshold.'

**[44] It is difficult to see that, if certainty is the appropriate test, s 10(3)(a) could ever apply. It does not seem to me**
that certainty is the appropriate test nor does the language used in s 10(3)(a) require it. In order to establish a
breach of a human right, an individual has to establish on the balance of probabilities that such a breach has
occurred. ECtHR jurisprudence suggests that a high level of probability is required. I see no reason why that should
not be applied in s 10(3)(a) since Parliament must be taken to have appreciated that that was how breaches could
be established. This seems to me to be the correct approach if s 10(3)(a) is to have any sensible application. Thus
if the Director is satisfied that legal aid is in principle needed when its refusal would to a high level of probability
result in a breach, s 10(3)(a) is met and means and merits will determine whether legal aid is to be granted and to
what extent. It may for example not be necessary to grant legal aid for more than advice, particularly as the
obtaining of advice from a competent solicitor may save further cost by persuading the individual that he has no
case or enabling him to present his application in a way which enables the decision-maker or court to deal with it
expeditiously and without the cost incurred in seeing whether a litigant in person does have valid points.

**[45] Coulson J considered s 10(3)(b). Mr Bowen QC (who represented the claimant in that case as he has two of**
the claimants in these cases) had submitted that the real risk test which was applied where, for example, there was
said to be a risk of a breach of a human rights article if a person were to be removed to another country was the
correct test to apply. Coulson J rejected this submission on the ground that it set too low a threshold. He was
influenced by a decision of Cranston J in _R (on the application of Tabbakh) v Staffordshire and West Midlands_
_Probation Trust [2013] EWHC 2492 (Admin), [2014] 1 WLR 1022._

**[46]** _Tabbakh's case concerned an attack on the policy applicable in guidance about the imposition of additional_
licence conditions to be applied to violent prisoners when released from custody. It was said that this policy created
an unacceptable risk of a breach of the procedural requirements of art 8. Cranston J carried out a detailed analysis
of the various authorities which had considered the lawfulness of a policy or actions said to give rise to a risk of
breach of an article. He drew a distinction between art 3 and other cases. Following _R (on the application of_
_[Munjaz) v Mersey Care NHS Trust [2005] UKHL 58, [2006] 4 All ER 736, [2006] 2 AC 148, in art 3 cases, having](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MBK-0BW0-TWP1-60YS-00000-00&context=1519360)_
regard to the nature of the article, a significant risk of a breach was set. That same test would be appropriate in
considering other articles such as art 2 and art 4 which had no possibility of derogation.

**[47] However, in relation to such articles as art 8, a higher threshold was appropriate. In removal cases, the ECtHR**
has recognised the need for there to be a risk of a flagrant breach. Cranston J relied on observations of Sedley LJ
in R (on the application of the Refugee Legal Centre) v Secretary of State for the Home
**[*848]**

_Dept [2004] EWCA Civ 1481, [2005] 1 WLR 2219where he said (at [7]) that potential unfairness was susceptible to_
judicial intervention to 'obviate in advance a proven risk of injustice [inherent] in the system itself'


-----

Cross Society intervening) [2015] 3 All ER 827

**[48] The case of Tabbakh (which is I was told under appeal[1] ) concerned an attack on government guidance. I have**
to construe the provisions of a statute on the assumption that Parliament would be aware of the relevant law and
would not enact provisions, unless making it clear that that was intended, which ran an unacceptable risk of a
breach of the procedural requirements of an article. The word 'risk' in s 10(3)(b) is not qualified.

**[49] I have already considered the procedural requirements of art 8, but I should, I think, refer specifically to the**
decision of the Court of Appeal in _IR (Sri Lanka) v Secretary of State for the Home Dept [2011] EWCA Civ 704,_

_[[2011] 4 All ER 908, [2012] 1 WLR 232. Maurice Kay LJ gave the only reasoned judgment. He identified from](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:548T-MHR1-DYBP-M145-00000-00&context=1519360)_
immigration and national security cases (IR involved national security being an appeal from SIAC) a 'clear and
consistent approach'. He cited Al-Nashif v Bulgaria (2003) 36 EHRR 655 in which, having stated that there must be
a measure of legal protection in domestic law against arbitrary interferences by public authorities with the rights
safeguarded by the ECHR, the court continued (at para 123):

'Even where national security is at stake, the concepts of lawfulness and the rule of law in a democratic society
require that measures affecting fundamental human rights must be subject to some form of adversarial
proceedings before an independent body competent to review the reasons for the decisions and relevant
evidence, if need be with appropriate procedural limitations on the use of classified material.'

And in Turek v Slovakia (2007) 44 EHRR 861, the court made clear that the court was concerned to ensure that
procedural protection was practical and effective.

**[50] In national security cases, the art 8 procedural requirements do not equiparate with those of arts 5 and 6. That**
is because of the need, recognised by the ECtHR, to have some means of relying on classified material. But in
general immigration cases, I see no good reason to apply a lower procedural standard nor does it seem to me that
a risk of breach need be any higher than comprehended in the real risk test routinely applied by the ECtHR. But, as
I have said, in articles from which derogation is possible the risk can properly be considered to be the risk of a
flagrant breach which does apply a somewhat higher test than a real possibility or a risk that is more than fanciful. If
legal aid is refused, there must be a substantial risk that there will be a breach of the procedural requirements
because there will be an inability for the individual to have an effective and fair opportunity to establish his claim.
That principle will apply whether there are court or tribunal proceedings or a decision from the Home Office. It
follows that I do not entirely accept Coulson J's conclusion in _M v Director of Legal Aid Casework that the test_
whether the refusal would impair the very essence of the right leads to a conclusion that the grant of legal aid will
only rarely be appropriate. The very essence is that in procedural terms it can be put forward in an effective manner
and there is a fair process.

**[51] It follows from what I have so far said that in my view the guidance is defective in that it sets too high a**
threshold and fails to recognise that art 8 does

2

apply even in immigration cases and, despite the exclusion of art 6, carries with it procedural requirements which
must be taken into account. Neither _Maaouia nor_ _RB (Algeria) v Secretary of State for the Home Dept disallows_
that.

**[52] Having set out what I believe to be the correct approach to be applied by the Director, I must consider each of**
the six claims. Some will require consideration of other general matters, but all have an art 8 claim. It is important in
considering art 8 to bear in mind that rights of family members, particularly children, must be taken into account.
Indeed, it has been made clear in the Supreme Court that the interests of a child are a primary consideration and
Parliament recognised and gave effect to this in _[s 55 of the Borders, Citizenship and Immigration Act 2009 by](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7W77-8620-Y97X-70TF-00000-00&context=1519360)_

[1 Editor's note: see [2014] EWCA Civ 827, [2014] 1 WLR 4620.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CG3-TRT1-F0JY-C1K9-00000-00&context=1519360)

**[*849]**


-----

Cross Society intervening) [2015] 3 All ER 827

requiring that the need to safeguard and promote the welfare of children who are in the United Kingdom be taken
into account in an immigration decision.

**[53] Before coming to the circumstances of each case, I should say that two grounds relied on in the case of IS**
(see [63]ff, below) were not for consideration in this hearing. These assert that the operation of the scheme puts
[unacceptable obstacles in the path of applicants and that there is a breach of the Equality Act 2010. I simply note](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
that an application for ECF can only result in payment for any adviser if ECF is granted and, since that has only
occurred in 1% of cases, solicitors are not prepared to take on such cases. This may well not be cost-effective as I
have already indicated. There are also complaints that the process for applying for ECF is too complicated. Those
issues will have to be dealt with in subsequent hearings.

**[54] Teresa Gudanaviciene. I shall refer to this claimant as TG. She is a national of Lithuania who came to this**
country in 2010 to work here. She was in a relationship with a partner who had a drink problem and was abusive
and violent towards her. In September 2012 she was convicted of an offence of wounding her partner with intent
[contrary to s 18 of the Offences against the Person Act 1861. She had stabbed her partner with a kitchen knife and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9240-TWPY-Y0D9-00000-00&context=1519360)
it was obviously fortunate that she had not killed him. However, it is apparent from the judge's sentencing remarks
that the jury had, it would seem in a rider to its decision, said that she had been under pressure and had been
provoked by her partner's conduct. The judge said that having regard to this and her family responsibilities he would
pass a sentence which was 'about six to twelve months lighter' than he had originally envisaged. He imposed a
sentence of 18 months' imprisonment.

**[55] The Secretary of State for the Home Department decided that the claimant should be deported. Regulation**
[19(3) of the Immigration (European Economic Area) Regulations 2006, SI 2006/1003 enables removal to be carried](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW6-XH50-TX08-H0KD-00000-00&context=1519360)
out if the Secretary of State has decided that it is justified 'on grounds of public policy, public security or public
health in accordance with regulation 21'. Regulation 21(5) provides that any such decision must comply with the
principle of proportionality and must be based exclusively on the person's personal conduct. Regulation 21(5)(c)
provides:

'the personal conduct of the person concerned must represent a genuine, present and sufficiently serious
threat affecting one of the fundamental interests of society.'

And reg 21(5)(e) states that a person's previous criminal convictions do not in themselves justify the decision.

**[56] The claimant has a two-year-old daughter of whom her former partner is the father. The decision to deport**
recognised the need to safeguard the
**[*850]**

child's welfare in accordance with s 55 of the 2009 Act. Her daughter is in foster care. The only report is in the form
of a statement from a senior social worker whose report was made at a time when the claimant was still in prison:
she has since been granted bail. The view expressed was that her father had problems in relating to his daughter
and children's services had concerns for her safety and development should she be placed with her father. While
there had been no opportunity to make a full assessment of the claimant's capability as a carer of her daughter,
such contact sessions as had been possible showed that the claimant appeared to be the most obvious choice of
sole carer.

**[57] Risk of harm from the claimant has not been properly assessed. The Home Office has relied on a report which**
goes no further than to indicate that when she was received into prison following her conviction, she was assessed
because of the nature of the offence as a medium risk of serious harm. Reliance has also been placed on the
emotional harm to her daughter from the offence but that is hardly all the fault of the claimant having regard to the
abusive and violent conduct of her former partner. In para 30 of the decision to deport this is said:

'It is considered that the combination of your criminal conduct in terms of the risk of serious harm to the public
and your propensity to reoffend make it reasonable to strike a fair balance between the best interests of your


-----

Cross Society intervening) [2015] 3 All ER 827

daughter and the weight attached to the necessary action of deportation. It is considered that this can be
achieved by expecting you to return to Lithuania and maintain relationship with your child and partner by
modern means of communication.'

**[58] The flaws in this reasoning are all too obvious. There is no evidence that the claimant has a propensity to**
reoffend. She has been living in a safe house for victims of domestic violence and completed courses designed to
assist such victims. Further life with her former partner is not likely. The suggestion that she can maintain a
relationship with her daughter from Lithuania is hardly in the daughter's best interests. It must be apparent that she
has a very strong case so far as merits of the appeal are concerned.

**[59] I should add that she has very poor command of English and, as must be obvious, she will be emotionally**
involved in the appeal so that she cannot approach it in an objective fashion. Her application for legal aid was
refused in July 2013. She requested a review through her solicitors and the refusal was maintained in a decision of
26 July 2013. It is to be noted that the Home Office had requested an oral hearing of the appeal.

**[60] The reasons for refusal set out in the 26 July 2013 letter are in my view thoroughly unsatisfactory. It is said that**
the issues are not complex and the tribunal 'will take account of the relevant case law and legislation, including EU
law and the facts of the case'. But the test under reg 21(5)(c) is key and it will be necessary to produce evidence to
deal with the risk of harm. That does not now exist to any meaningful extent and it is difficult to follow how without
assistance the claimant can be expected to obtain the necessary evidence, let alone make representations on the
issue. Furthermore, there is no evidence as to whether the daughter will be able to be cared for if she were to go to
Lithuania with her mother and what provision will be made for her daughter's future here. All this additional
evidence cannot be obtained by the tribunal, particularly as the proceedings are adversarial. The suggestions in the
refusal letter that 'any further evidence in respect of your client's family or criminal case is accessible by your client
and can be submitted to the First Tier Tribunal
**[*851]**

for their consideration' and '[y]our client can with the assistance of an interpreter, further address any question of
the First Tier Tribunal and provide further factual information towards the proportionality of the decision to deport'
are little short of absurd. It reflects the flawed guidance on the high level of the threshold and the exclusion of art 8.

**[61] A matter relied on by Mr Chamberlain in his skeleton argument was that the strong merits of the appeal**
suggested the claimant was less likely to be disadvantaged by the absence of professional representation. That in
my judgment is a very dangerous argument since it suggests the more meritorious a case the less need there is for
legal assistance. The dictum of Megarry J concerning awareness of open and shut cases which turned out not to be
[so is cautionary (see John v Rees, Martin v Davis, Rees v John [1969] 2 All ER 274 at 309, [1970] Ch 345 at 402).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-35S0-TWP1-61K4-00000-00&context=1519360)
So far as the daughter's rights are concerned, reliance is placed on the observation of the initial refusal letter of 12
July 2013 which stated:

'The consequences of deportation in the applicant's case could impact upon her relationship with her child, if
father is awarded a residence order and remains in the UK.'

It is not realistic to suggest that the father would be a satisfactory carer. Further, it is said that the possible severing
of relations with the claimant's daughter is not supported by the material put before the Director.

**[62] The decision in TG's case shows how the very high threshold applied by the guidance can produce a perverse**
decision. Even on that high threshold, the decision was in my judgment unreasonable in Wednesbury terms (see
_Associated Provincial Picture Houses Ltd v Wednesbury Corp_ _[[1947] 2 All ER 680, [1948] 1 KB 223) but, on the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-60M0-00000-00&context=1519360)_
correct approach, it is indefensible. It is accepted that if as a matter of law I were to take the view that an adverse
decision could not be made I should direct the Director to grant legal aid (subject to the means test being satisfied,
as I think it is) since the merits test is clearly met. Unless proper evidence is obtained on risk of harm and in relation
to the future care of the claimant's daughter, she will not obtain a just result and on the evidential matters the


-----

Cross Society intervening) [2015] 3 All ER 827

tribunal cannot help her. Furthermore, competent solicitors may be able to persuade the Home Office that the
decision should be withdrawn so that costs are saved to an even greater extent.

**[63] IS. IS has an anonymity order which should in my view be maintained. The reasons for it will become apparent**
when I set out the circumstances of his case. I am concerned only with his claim that the refusal of ECF in his case
breaches or risks the breach of his art 8 rights.

**[64] The claimant is a 59-year-old Nigerian. He is blind and his mental condition is such that he lacks capacity and**
so the Official Solicitor has acted as his litigation friend. He is not able to say when he arrived in the UK or whether
he entered lawfully or unlawfully or, it may be, overstayed. The claimant is incapable of looking after himself. He
was evicted from his privately rented accommodation and has had to bring community care proceedings against his
local authority. His ability to access such necessary assistance depends on establishing his immigration status, in
particular in showing he is here lawfully. He apparently believes he has been here for about 13 years, but has no
passport. He needs advice from a qualified person as to how he should endeavour to obtain any necessary leave to
remain in the UK. The Official Solicitor has confirmed in a statement in the case that he is unable to provide such
advice or services and so applied for ECF from the Director.
**[*852]**

**[65] The Official Solicitor in his statement asserts that the guidance when dealing with persons lacking litigation**
capacity is erroneous (see para 25). One question posed is:

'Will a litigation friend be acting for the applicant? How capable is the litigation friend of presenting the case on
the applicant's behalf?'

It is necessary to establish whether an individual does lack capacity and that will normally require a medical report
which must be paid for by someone. Furthermore, a litigation friend is not an advocate and cannot act as such,
certainly in immigration cases, without the necessary authorisation. A friend is unlikely, unless a lawyer, to have a
right of audience.

**[66] The application submitted to the Director on behalf of IS on 12 June 2013 stated that the application to the**
Home Office would depend on complex points of law relating to arts 3 and 8 of the ECHR. Article 3 was said to
arise in relation to the availability of necessary care in Nigeria were he to be refused leave to remain. This, it was
said, would require medical reports and expert evidence. Arguments based on art 8 would also require medical
evidence and proof that removal would be disproportionate.

**[67] The response of the Director on 23 June 2013 pointed out that rights to remain arising from art 3 of the ECHR**
were within s 30(1)(b) of Pt 1 of Sch 1 to LASPO, thus legal aid might be available provided the merits and means
tests were met. But legal aid by reference to art 8 was refused on a merits basis. The claimant's advisers sought a
review on 2 July 2013. In para 12 this was said:

'There is no-one to assist IS with the Article 8 aspects of his immigration application … We have been unable
to find an immigration solicitor who is willing to make the Article 3 arguments because, although they are in
scope, they are closely bound up with the Article 8 aspects of the claim, the work for which would be unfunded.
It is for this reason that we set out the Article 3 ECHR arguments in our grounds, although the application is
only for funding for the Article 8 ECHR aspects of this claim.'

**[68] The decision on review was adverse. It was said in a letter of 16 July 2013 that the claimant should be**
immediately referred to an immigration lawyer so that a lawyer could proceed with an application for regularisation
of his immigration status on art 3 grounds, but 'on the information submitted it has not been demonstrated that you
have any viable art 8 claim'. In any case, the guidance was relied on to assert that the procedural requirements of
art 8 did not give rise to an obligation to provide legal aid.

**[69] A further application for ECF was submitted in September 2013 but refused on 11 September 2013. It was said**
that the claimant's art 8 rights were not at stake because he was not at risk of deportation. That is somewhat


-----

Cross Society intervening) [2015] 3 All ER 827

inconsistent with the apparent acceptance that his art 3 rights did justify legal aid. Article 3 rights were, in the
absence of removal, no more at risk than his art 8 rights.

**[70] The reality is, as Mr Low-Beer of the Public Law Project recognises, that an art 3 claim is very weak having**
regard to the threshold set by the relevant authorities. Indeed, any immigration solicitor would, I suspect, advise that
it could not be pursued. The reality is that art 8 is the only basis which can prevail to show that IS needs to be
allowed to remain rather than be removed. Whether he has family or any possibility of support in Nigeria is
obviously of importance. The Home Office may possibly have some records of his entry (if
**[*853]**

it was initially lawful) and investigations are needed to discover as much as possible about his past in this country. It
is to be noted that he has made a claim against the local authority in relation to homelessness in which it is said that
he was unable to look after himself and lived in a filthy flat infested with bedbugs, rodents and cockroaches and he
survived by begging.

**[71] It is clear that no solicitor could properly obtain legal aid in relation to an art 3 claim which he knew had no**
validity to enable work to be done which would also be material to a possibly valid art 8 claim. But the claimant's
circumstances show that he clearly needs some expert immigration advice to enable him to put a proper application
to the Home Office. That advice cannot be given by a person who is not authorised under s 84.

**[72] Mr Chamberlain submitted that the decision of the Director was not unlawful since it was based on the**
information placed before him which raised an art 3 claim. Thus he was entitled to point out that that meant the
application was in scope and the work which would be required to pursue an art 3 claim included in particular
medical evidence and material which would also be relevant to an art 8 claim. While I recognise the force of that so
far as it goes, the refusal to include the art 8 claim so that all necessary work could be done was based on the
erroneous view that the procedural requirements were not included. The need for a full consideration of the basis
upon which IS could make an application is apparent.

**[73] The decision to refuse was essentially based on the guidance and the erroneous view that art 8 could not be**
engaged since he was not at risk of removal. I have already indicated why the guidance in respect to art 8 is wrong.
In these circumstances, I will quash the decision and require a reconsideration in the light of the fuller evidence now
available to the Director. I can only say that I believe that legal aid should be granted to this extremely vulnerable
person since without it he will not be able to achieve an effective exercise of his art 8 rights. However, I do not think
I can go so far as to say that a refusal would necessarily be unlawful, but good reasons for it will be needed.

**[74] S. The claimant, a Nigerian citizen, was violently assaulted in a family dispute following his father's death. He**
was badly injured and his brother was killed. The assailants were given short prison sentences and the claimant
was anxious to leave Nigeria before their release, fearing further violence. His uncle arranged with an agent for him
to travel to the UK on a false passport. He arrived here in January 2004 and was introduced by the agent to a
restaurant owner, Comfort Afolabi. She used his fear of the authorities and threats to inform that he was here
unlawfully and so would be returned to Nigeria to compel him to work for her in appalling circumstances. He was
paid very little—certainly insufficient to provide for a living wage—and slept on a mattress in the cooler room of the
restaurant. He met a lady who is now his partner and by whom he has had three children. His partner and the
children have been given indefinite leave to remain and the third child is considered to be a British citizen.

**[75] In the circumstances, he contended that he was a VOT. The circumstances in which he was required to work**
for Ms Afolabi amount to slave labour. Encouraged by his partner, he escaped from the restaurant in January 2009
and went to live with his partner. Ms Afolabi apparently died in the summer of 2009. His fear of being deported if he
approached the authorities led him to delay taking any action until April 2013 when he approached the AntiTrafficking and Labour Exploitation Unit ('ATLEU'),
**[*854]**

which operates in North London. ATLEU was acting for his partner in relation to support for her children and her
immigration position She too was a VOT


-----

Cross Society intervening) [2015] 3 All ER 827

**[76] An application for ECF was made by ATLEU on his behalf on 17 June 2013. This was said to be for the**
purposes of preparing an application under art 8 of the ECHR and making a referral to the competent authority to
enable a positive decision in relation to his claim to be a VOT. It was said that a failure to grant ECF would breach
or create a risk of breach of his art 4 and 8 rights and violate his EU law rights as a VOT. The application followed a
request from the Public Law Project (to which ATLEU had referred his case) for a preliminary view on ECF. There
was a negative response. A review was carried out and the answer remained negative. The reasons were given in
a letter of 28 June 2013.

**[77] The points made were first that from the advice received from ATLEU, the claimant would have all necessary**
information to apply to be recognised as a VOT. While an asylum application was a probability, legal aid for it was
premature. Secondly, it was said that, since there was no removal indicated, art 8 rights in relation to his children
and partner did not arise and reliance was placed on para 60 of the Lord Chancellor's guidance. So far as art 4 was
concerned, there was a satisfactory mechanism available to protect him once he was regarded as a VOT.

**[78] The procedure in place for establishing whether an individual is a VOT is important. The Council of Europe**
Convention on Action against Trafficking in Human Beings (2005) (CETS no 197) ('CAAT') was ratified by the UK in
2009 and required measures to be put in place to protect VOTs. It included the need under art 10 to adopt 'such
legislative or other measures as may be necessary to identify victims as appropriate in collaboration with other
Parties and relevant support organisations'. If there are reasonable grounds to believe that a person has been a
VOT, he or she must not be removed until the identification process as victim of an offence is completed and the
state must ensure that he or she receives the assistance provided for by art 12(1) and (2). Article 12(1) sets out a
number of forms of assistance which must at least be provided. These include:

'… (d) counselling and information, in particular as regards their legal rights and the services available to them,
in a language they can understand;

(e) assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders …'

**[79] In order to establish that there are reasonable grounds to believe a person has been a victim of trafficking, an**
application must be made through what is referred to as the National Referral Mechanism ('NRM'). A referral via the
NRM can only be made by an organisation which is designated as a first responder. These comprise the Home
Office, local authorities, Health and Social Care Trusts, the police, the National Crime Agency, the Gangmasters
Licensing Authority, the Salvation Army, Barnardo's and the NSPCC. In addition, there are five organisations of a
charitable nature which assist persons such as the claimant. It is obvious that many of this limited number of first
responders have no specific immigration experience where that may be needed and so no ability to give
immigration advice lawfully. Further, as the claimant's solicitors' evidence shows, considerable difficulty existed in
finding a first responder prepared to assist, which caused an unacceptable delay.
**[*855]**

**[80] The competent authority in a case such as this where there are immigration considerations, the claimant being**
an illegal entrant and so in need in due course of leave to remain, is the Home Office. It is in those circumstances
easy to understand why someone such as the claimant who fears for his safety if returned to the country of his
nationality and who knows he is here unlawfully is reluctant to inform the Home Office of his presence for fear of
being detained or removed. It is not clear whether he would have a claim for humanitarian protection. All would
depend upon the full circumstances of what occurred in Nigeria to make him leave the country and whether
adequate protection would be available. In addition, since he now has a family life with his partner and children who
have indefinite leave to remain, his art 8 rights are very much in issue.

**[81] While the UK has ratified the CAAT, it has not been directly incorporated into domestic law. However, there is a**
[European Parliament and Council Directive 2011/36/EU (on preventing and combating trafficking in human beings](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)
and protecting its victims) (OJ 2011 L101 p 1) ('the Anti-Trafficking Directive'). This is of course binding in domestic
law. It is aimed at ensuring that those responsible for trafficking are able to be prosecuted successfully and that


-----

Cross Society intervening) [2015] 3 All ER 827

victims are given all necessary assistance to achieve that aim. As soon as there are reasonable grounds for
believing that a person is a VOT, he or she should be given assistance and support whether or not willing to act as
a witness in any prosecution. In addition, victims should be given access without delay to legal counselling (see
recital (19) and art 12(2)). Article 12(2) states that legal counselling must include for the purpose of obtaining
compensation. Article 17 requires member states to ensure that VOTs have access to existing schemes of
compensation to victims of violent crimes of intent. Thus the death of the trafficker in this case and so the possible
lack of any person who can be prosecuted does not mean that there is no purpose in legal advice and counselling.
The claimant, if it is concluded that he is a VOT, may well be entitled to compensation if he claims it.

**[82] Article 12(1)(d) of the CAAT, which I have already cited, applies to a victim who is defined in art 4(e) as 'any**
natural person who is subject to trafficking in human beings as defined in the article'. The definition, which is very
similar in art 2 of the Anti-Trafficking Directive, includes forced labour or services and so the claimant, if his
evidence is accepted (and it is not suggested that it should not be) is a VOT. Reasonable grounds for so believing
have already been found to exist.

**[83] Mr Chamberlain submits that the Anti-Trafficking Directive and, in so far as it can be relied on, the CAAT by art**
12 (which is the relevant article in both) applies only to those who are regarded as victims and does not confer any
rights, in particular any right to legal advice or representation, for the purposes of establishing that a person is a
VOT. I have no doubt that that submission is correct. However, that does not mean that in a given case legal advice
may not be needed to ensure that an individual is able to pursue in an effective way an application to receive the
status of a VOT.

**[84] I do not doubt that one such as the claimant who is here unlawfully will have fears about how he should make**
his claim without the risk of being removed or at least detained with a view to removal. Any art 8 or other ECHR
rights are likely to be a material consideration so far as his future prospects of living here are concerned, particularly
if he may have an art 3 claim to avoid removal. Nevertheless, the application to be regarded as a VOT is not directly
allied with an immigration issue. Since there is a prohibition on removal of one
**[*856]**

who is reasonably believed to be a VOT, it would clearly be unlawful to seek to remove an applicant. In my view,
that should be made clear to all applicants. Furthermore, it would almost certainly be wrong to seek to detain a
victim of trafficking, unless there were very exceptional circumstances in accordance with Chapter 55.10 of the
Home Office Enforcement Instructions and Guidance.

**[85] Mr Bowen submits that art 4 of the ECHR includes a procedural obligation to investigate whether there has**
been a breach. That is no doubt correct, but it does not in my view assist the claimant in a case such as this. A
breach of art 4 is only justiciable within the _[Human Rights Act 1998 if a public authority is in breach. This would](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
mean there was a failure to take reasonable steps to ensure not only that trafficking be identified and prevented but
also that those responsible be prosecuted. But I am not persuaded that legal aid is necessarily required to enable
the requisite protection to be given.

**[86] While I fully appreciate the concerns of the claimant and the need to consider his immigration situation and**
whether asylum should be claimed, as I have said, whether or not he is a VOT is a separate issue. No doubt it may
be sensible for the whole immigration situation to be considered, in particular as the decision-maker on the VOT
question will be the Home Office which is also concerned with immigration issues. That is something which in my
view should be considered by the Director. The refusal was based on the guidance which, as I have said, puts the
threshold far too high.

**[87] Mr Bowen sought to rely on a report of the Joint Committee of Parliament on the draft** **_Modern Slavery Bill_**
(Cm 8770), published on 8 April 2014. This, it was said, confirmed the experience of the claimant's solicitor that
those in the Home Office who were to deal with applications by persons claiming to be a VOT were not adequately
trained. However, Mr Chamberlain objected to its admissibility on the ground that to rely on it would be a breach of
art 9 of the Bill of Rights (1688) and of parliamentary privilege. Reliance is placed for this contention on a decision


-----

Cross Society intervening) [2015] 3 All ER 827

of Stanley Burnton J in Office of Government Commerce v Information Comr (A-G intervening) _[2008] EWHC 774_
_(Admin), [2010] QB 98, [2009] 3 WLR 627. While the report, being a public document, can be noted, it is not_
permissible to consider arguments as to the correctness or acceptability of the matters raised in the report. It seems
to me that Mr Chamberlain's objection is well founded. In any event, concerns about the present position in relation
to dealing with VOTs are not directly material in deciding whether the refusal to grant legal aid is lawful in given
circumstances. I note the evidence from the claimant's solicitor about the difficulties in filling out the necessary
forms. This can obviously be taken into account by the Director. But otherwise I do not think even if it were
admissible the report would assist.

**[88]** I have carefully considered whether the errors in the approach of the Director do require the decision to be
quashed. I cannot say that a decision to refuse based on the correct approach would necessarily be wrong in law,
but there are powerful arguments based on the vulnerability of the claimant which show that legal aid was not only
desirable but necessary to enable his overall rights, which could not be completely divorced from the VOT
application, to be made effective. I think the Director should reconsider this claimant's case and so I shall quash the
decision to refuse legal aid.

**[89] Reis. The claimant is a Portuguese national now 28 years old. He entered this country with his mother in**
December 1998 when he was 12 years old and has lived here ever since. He has since about 2002 committed a
**[*857]**

considerable number of criminal offences which have increased in seriousness. His first custodial sentence appears
to have been one of nine months and two weeks in a young offenders' institution in 2006 for various offences
committed, some while on bail, for driving vehicles taken without consent dangerously and while disqualified. In
2007 he was again convicted of driving whilst disqualified and received a suspended prison sentence. He breached
this order and in June 2008 was sentenced to 20 months' imprisonment for burglary and theft. He was then warned
by the Home Office that deportation would not be pursued then, but that he must note that it had been considered.
He took no notice. In November 2009 he was convicted of aggravated vehicle taking, causing damage to a vehicle
in excess of £5,000, and driving whilst disqualified. For these offences, he was sentenced to 15 months'
imprisonment. The damage to the vehicle was caused when he attempted to escape from the police and was
involved in a high speed chase. While the offences are not of the most serious and he did not commit any offence
which directly involved violence to an individual, nonetheless the offending was persistent and its seriousness
increased.

**[90] The Recorder who sentenced him in 2009 referred to his appalling record and concluded:**

'It is clear that you … are easily influenced by friends and criminally minded peers and it is also clear that you
have shown a significant ability to act without any consideration towards others and other people's property to
the extent that you put other road users at significant personal risk.'

**[91] On 29 July 2010 the Secretary of State for the Home Department notified the claimant that she had decided to**
make a deportation order. It was asserted that he had not resided here, having regard to his custodial sentences,
for at least five years so that he was not entitled to the level of protection appropriate to that. The First-tier Tribunal
accepted that he had but nonetheless dismissed his appeal. His application for leave to appeal to the Upper
Tribunal was refused. He sought judicial review of that refusal raising a point which had not been clearly made that
he qualified for the highest level of protection by virtue of ten years' residence. Leave was granted by Walker J,
following refusal on the papers by me, in May 2012. On 13 May 2013 the Secretary of State for the Home
Department agreed to reconsider the question of deportation and so the judicial review was brought to an end. On
20 May 2013 she decided to make a deportation order.

**[92] The Immigration (European Economic Area) Regulations 2006 govern the removal of EU citizens as stated in**
the case of TG. Regulation 15 concerns a permanent right of residence. Regulation 15(1)(a) gives a permanent
right of residence to such as the claimant if he has resided in the UK in accordance with the regulations for a


-----

Cross Society intervening) [2015] 3 All ER 827

continuous period of five years. It is accepted that the claimant qualifies under this provision. Regulation 21 sets out
the basis upon which deportation of permanent residents can be achieved. Regulation 21(3) provides:

'A relevant decision may not be taken in respect of a person with a permanent right of residence under
regulation 15 except on serious grounds of public policy or public security.'

But greater protection is afforded to those who have resided here for at least ten years by virtue of reg 21(4) which,
so far as material, provides:
**[*858]**

'A relevant decision may not be taken except on imperative grounds of public security in respect of an EEA
national who—

(a) has resided in the United Kingdom for a continuous period of at least ten years prior to the relevant
decision … '

If the claimant is only entitled to the five-year protection, he will obviously be more readily regarded as one whose
deportation would be proportionate, as indeed the First-tier Tribunal decided on his original appeal. The key
question is whether and the extent to which time spent in custody can properly be regarded as counting towards a
continuous period of residence.

**[93] Even at the lowest level when five years have not elapsed, the deportee must present a genuine and**
sufficiently serious threat to the requirements of public policy: see _R v Bouchereau (Case 30/77)_ _[[1981] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-608M-00000-00&context=1519360)_
_[924n, [1978] QB 732. There are a number of domestic authorities which have decided that time spent in prison](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-608M-00000-00&context=1519360)_
does not count towards an accumulation of five years: see for example HR (Portugal) v Secretary of State for the
_[Home Dept [2009] EWCA Civ 371, [2010] 1 All ER 144. In LG (Italy) v Secretary of State for the Home Dept](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7XH2-66M0-Y96Y-G0YB-00000-00&context=1519360)_ _[[2009]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W59-5V00-Y9GT-12J7-00000-00&context=1519360)_
_[UKAIT 24, [2009] Imm AR 691, Carnwath LJ extended this approach to the ten-year period, even for someone who](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W59-5V00-Y9GT-12J7-00000-00&context=1519360)_
had acquired permanent residence here by virtue of five years' continuous residence. In FV (Italy) v Secretary of
_[State for the Home Dept [2012] EWCA Civ 1199, [2013] 1 All ER 1180, [2013] 1 WLR 3339, the Court of Appeal](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57XB-55K1-DYBP-M2H3-00000-00&context=1519360)_
decided that in order to determine whether an EEA national had resided in the UK for a continuous period of at least
ten years a qualitative assessment of whether he was genuinely integrated was needed. A period of imprisonment
would be a relevant factor but would not necessarily defeat an individual's claim. Aikens LJ approached the
question on the basis that if a person is integrated before any period of imprisonment, that imprisonment should not
defeat a ten-year claim. Rafferty LJ expressly agreed with him.

**[94] It is not for me in these proceedings to decide the issue. Mr Chamberlain has submitted that the law is now**
clear following the decision of the CJEU in Secretary of State for the Home Dept v MG (Case C-400/12) [2014] 1
WLR 2441. It is necessary to count back from the decision to deport so that the decisive criterion is whether the EU
citizen has resided continuously in the member state for the preceding ten years. Since the court had decided that
the imposition of imprisonment showed that the individual had not respected the values of the host state, permanent
residence could not be established unless there were five years out of prison. The court said:

'35. As for the question of the extent to which the non-continuous nature of the period of residence during the
ten years preceding the decision to expel the person concerned prevents him from enjoying enhanced
protection, an overall assessment must be made of that person's situation on each occasion at the precise time
when the question of expulsion arises …

36. In that regard, given that, in principle, periods of imprisonment interrupt the continuity of the period of
[residence for the purposes of article 28(3)(a) of Directive 2004/38, such periods may—together with the other](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:633G-4803-GXFD-83C5-00000-00&context=1519360)
factors going to make up the entirety of relevant considerations in each individual case—be taken into account
by the national authorities responsible for applying article 28(3) of that Directive as part of the overall
assessment required for determining whether the integrating links

**[*859]**


-----

Cross Society intervening) [2015] 3 All ER 827

previously forged with the host member state have been broken, and thus for determining whether the
enhanced protection provided for in that provision will be granted …'

It follows that to assess whether there has been ten years' continuous residence prior to the decision to deport (in
the case prior to May 2013) the First-tier Tribunal will have to consider all the circumstances to decide whether
enhanced protection has been established.

**[95] The claimant came here in December 1998. He had thus been here for some 141/2 years before the decision**
to deport him. It is common ground that he has a right of permanent residence. The issue in his case may therefore
turn on whether the ten years prior to May 2013 is interrupted by any periods of imprisonment. The guidance issued
by the CJEU is not in my view as clear as Mr Chamberlain submits and there is a difficult question to be determined
on the facts of the claimant's case. Those and his attitudes must be carefully assessed.

**[96] There is an art 8 claim based on his fatherhood of a child. He has split up from his partner. There can be no**
doubt that that claim is extremely weak and I do not think it is such as to justify legal aid.

**[97] The reasons for refusing legal aid include the assertions that the claimant had had legal representation at his**
previous hearings and it was 'speculative to think that previous errors will be repeated'. In addition, it is said that
proceedings before the First-tier Tribunal 'are not complex either in law or procedure'. That observation I find
remarkable and it suggests that the author has never had experience of observing appeals before the First-tier
Tribunal. The reality is, having regard both to the possibility of difficulties in dealing with contentious factual matters
and, in immigration law which is taking up a substantial part of the Court of Appeal's caseload, there can be
considerable complexity.

**[98] The refusal was based on an application of the guidance which set too high a threshold. This will on any view**
be a difficult appeal and I am entirely satisfied that without legal assistance there is a real prospect of the claimant
not receiving justice. It follows that I quash the refusal and I propose to direct in this case that legal aid be granted
for the hearing before the First-tier Tribunal.

**[99] B. B is an Iranian national who arrived in the UK in March 2013. She claimed asylum fearing persecution for**
her political activities on behalf of Kurds. She was granted refugee status on 15 April 2013 and given five years
leave to remain. Following her departure from Iran, her husband and son, who was born on 2 June 1997, were
arrested and interrogated. They were beaten and threatened and ordered on release to give the authorities
information about the claimant.

**[100] The claimant was understandably very anxious about her husband and son. She spoke no English and was**
dependent on assistance from the Iranian and Kurdish Women's Rights Organisation ('IKWRO'). They advised her
that she might be able to apply for family reunion so that her husband and son could join her in the UK. IKWRO
were unable to assist her in making an application since it was not licensed to do so and, following advice from
IKWRO, she met with her present solicitor. Her solicitor recognised that there might be difficulties in that her son
had no passport and there were no facilities available in Iran to enable a visa to allow entry to the UK to be obtained
there. The claimant was extremely upset and worried and her inability to
**[*860]**

communicate in English made things even more difficult for her. Her solicitor was aware from the Legal Aid
casework website that family reunion was said not to be in scope for the purpose of grant of legal aid. Nevertheless,
the view was taken that that might be wrong and that in any event the claimant needed legal assistance to enable
her to have any real prospect of achieving family reunion.

**[101] If her son approached the Iranian authorities to obtain a passport, the claimant was afraid, not without good**
reason, that he would be arrested and ill-treated. Thus the only way he could apply for the necessary
documentation to enable him to achieve entry to the UK was to go unlawfully to Turkey and apply there. This he did
with his father and applications for entry clearance were made in Ankara. The applications were prepared by the
claimant's solicitor on instructions from the claimant. Since the claimant's son was in Turkey unlawfully, he was


-----

Cross Society intervening) [2015] 3 All ER 827

afraid to leave the friend's address where he was staying and was extremely distressed. The applications for entry
clearance were made in August 2013 but a decision was not made until 15 December 2013 when the claimant's
husband was granted an entry clearance but their son was refused. Apart from the inexcusable delay in dealing
with the application having regard to the circumstances in which the applicants were living in Turkey, the decision
was extraordinary and an appeal was lodged. Islington Law Centre assisted in this. Fortunately, before an appeal
was heard, on 13 February 2014 the claimant's son was granted the necessary entry clearance. Notwithstanding
that, he has not been granted the necessary exit permits by the Turkish authorities. However, there is little that the
UK authorities can do about that.

**[102] Paragraph 30 of Pt 1 of Sch 1 to LASPO provides, so far as material, in the case of a refugee for—**

'(1) Civil legal services provided in relation to rights to enter, and to remain in, the United Kingdom arising
from—

(a) the Refugee Convention …

(d) the Qualification Directive.'

On 26 June 2013 the claimant's solicitor applied for legal aid to cover advice and assistance on the ground that
para 30(1)(a) applied. The application was expanded on 2 August 2013 raising in addition art 8 of the ECHR and art
23 of the Qualification Directive, with which I will deal in due course. On 6 August 2013 Mr Sidhu, the Development
Manager of the Legal Aid Agency, replied saying by reference to debates in Parliament during the passage of the
LASPO Bill that para 30(1)(a) did not cover family reunion. Since family reunion was not directly within the Refugee
Convention and para 30(4) of Pt 1 of Sch 1 to LASPO defined the Refugee Convention to mean the Convention
and the Protocol to it, family reunion was not in scope.

**[103] On 12 August 2013 the claimant's solicitor made it clear that there was in addition an application for ECF.**
This was refused on 19 August 2013. Review was refused on 15 September 2013. So far as art 8 was concerned, it
was said that her claim would not be practically impossible. So far as her inability to understand English and,
because of her distressed state, to follow the application form and to overcome the difficulties arising from her son's
unlawful presence in Turkey was concerned, it was said that the claimant's cousin, who understood English, would
help her. There was in addition the facile observation that she was able to provide her solicitor with instructions.
**[*861]**

**[104] The UN Conference following the Refugee Convention noted that the unity of the family was an essential right**
of a refugee and recommended that governments should take the necessary measures for the protection of a
refugee's family especially with a view to ensuring that family unity was maintained. This recommendation has been
implemented in the UK by a provision in the Immigration Rules, now contained in para 352A-F.

**[105] The words which are central to the claimant's main submission that family reunion is in scope are 'arising**
[from'. Mr Chamberlain sought to rely on Pepper (Inspector of Taxes) v Hart [1993] 1 All ER 42, [1993] AC 593to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60C0-00000-00&context=1519360)
enable him to put before me extracts from Hansard which he submitted showed that it was Parliament's intention to
exclude family reunion from the scope of legal aid. In order to enable reference to Hansard, there must be an
ambiguity in the provision in question. Furthermore, if there is an ambiguity so that ministerial observations can be
referred to, they must clearly show the intention on which it is sought to rely.

**[106] I am satisfied that there is no ambiguity. The expression 'arising from' is one which has a wide meaning and is**
to be contrasted with wording such as 'conferred by' or 'contained in'. If it had been intended to limit the scope of
access to legal aid as contended for by Mr Chamberlain, a narrower expression could and should have been used.
A person who is recognised as a refugee has a right conferred by the Immigration Rules for family unity. As a
matter of ordinary English, that right arises from the Convention since the Convention enabled that person to
achieve the status of refugee. It is to be noted that the width of the words 'arising out of' (which are no different in
meaning) has been confirmed by the House of Lords in a contractual situation in for example Union of India v E B
_[Aaby's Rederi A/S [1974] 2 All ER 874 [1975] AC 797](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-61HT-00000-00&context=1519360)_


-----

Cross Society intervening) [2015] 3 All ER 827

**[107] Mr Chamberlain argued that narrower wording such as 'conferred by' would be inappropriate since the**
Convention had not been formally adopted into domestic law. Thus, he submitted, it could not confer any
enforceable rights. That argument carries no weight since all that any narrower wording could do would be to make
clear that only rights specifically contained within the Convention would be in scope for the purposes of legal aid. It
follows that anything contained in Hansard is not admissible and that family reunion is in scope.

**[108] I have of course seen the material on which Mr Chamberlain seeks to rely. I confess to great surprise at the**
Minister's statement that family reunion legal aid cost £5 million a year. The fact that it is in scope does not mean
that it should be granted in every case. Many are no doubt straightforward and some refugees will be competent to
deal with the necessary paperwork. But there are cases, and I am satisfied that this is one, in which an extremely
vulnerable individual is faced with a difficult situation in relation to her son, a difficulty made all too apparent by the
initial refusal by the entry clearance officer. The amount sought to cover the advice and assistance is modest, I am
told some £234. I am bound to say that even if I were wrong in deciding that it is in scope, this is a case in which
ECF should have been granted. The application of the unduly high threshold led to a wrong decision. Even if the
guidance had been correct, to refuse in the circumstances was in my view unreasonable.

**[109] I should deal briefly with other matters raised. Assuming I could take account of Hansard, reliance is placed**
by Mr Chamberlain on the answer to an amendment proposed by Mr Simon Hughes MP (now ironically a minister in
the Ministry of Justice) which sought to bring family reunion explicitly into
**[*862]**

scope. The minister said that the cases should not require specialist advice and so it was 'not therefore necessary
for them to remain within the scope of legal aid'. Mr Hughes raised the matter again, pointing out that some family
reunion cases were not straightforward. An obvious example is if there are problems in proving a relationship in
particular in relation to adopted children if the adoption was somewhat informal. Attempts to have a similar
amendment adopted in the Lords were unsuccessful. However, so far as Mr Hughes was concerned, a letter from
Lord McNally was relied on. So far as possibly complex family reunion cases were concerned, he said this:

'You also raised the issue of … appeals in immigration cases and complex family reunion cases. As you know,
we have had to make difficult choices about legal aid. Our references to the scope of the scheme are designed
to refocus civil legal aid on the most serious cases in which legal advice and representation is justified. This
means making some legal aid remain for asylum matters, which may be a matter of life and death. But,
fundamentally, we do not think that most immigration matters justify legal aid.'

**[110] All this no doubt shows that the minister believed that the words used excluded family reunion. But the matter**
was left in the air in the House of Lords. Mr Chamberlain relies on what Lord McNally wrote to Mr Hughes. That is in
my view insufficient to show that Parliament, which means both Houses, intended to exclude family reunion. It may
be that it was appreciated that no amendment was needed having regard to the words used. The intention of
government is not necessarily the same as that of Parliament. Thus even if recourse to Hansard is permissible a
clear and unequivocal intention is not established.

**[111] In the alternative, Mr Bowen sought to rely on the Qualification Directive. Recital (12) states that the best**
interests of the child should be a primary consideration when implementing the Directive. That is enacted in art
20(5). Article 23 is headed 'Maintaining family unity'. Article 23(1) provides:

'Member states shall ensure that family unity can be maintained.'

The rest of art 23 deals with the treatment of family members who are limited by the definition in art 2 to those
family members present in the same member state as the refugee.

**[112] Mr Bowen relies on art 23(1) contending that there is contained in it an obligation on the member state to**
ensure that family members who are outside the state in which the individual has been granted refugee status are
allowed to enter to join him or her. I have been referred to the travaux preìparatoires which do not assist Mr Bowen


-----

Cross Society intervening) [2015] 3 All ER 827

in this regard. No doubt it is expected that family reunion will be achieved but the Directive does not directly give
any rights in that respect.

**[[113] It is to be noted that Council Directive 2003/86/EC (on the right to family reunification) (OJ 2003 L251 p 12)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9PB3-GXFD-83C3-00000-00&context=1519360)**
provides for family reunification and provides by arts 2(d) and 13(1), that once an application meets the conditions
which can be imposed (for example, possible health considerations and proof of the necessary relationship), the
state must authorise entry of the family members in the UK. The UK has not opted into that Directive. However, its
existence indicates that it was not considered necessary to include those rights in the Qualification Directive.
**[*863]**

**[114] The art 8 rights of the claimant's son have been relied on by Mr Bowen as a material consideration. Since he**
is not in the jurisdiction Mr Chamberlain has submitted that his rights under the ECHR are not justiciable in this
country. In Tuquabo-Tekle v Netherlands [2005] 3 FCR 649, the ECtHR held that the refusal to admit a 15-year-old
daughter breached the art 8 rights of the whole family, including her. It seems to me that to exclude consideration of
the rights of a child of the family who has not gained entry to join his parent when considering art 8 is artificial.
Section 55 of the 2009 Act only applies to children in the UK, but, as Blake J observed in Mundeba (s 55 and para
_297(i)(f))_ _[[2013] UKUT 88 (IAC), it is inevitable when considering whether a child should be excluded his or her](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57WP-PXK1-F0JY-C3KB-00000-00&context=1519360)_
welfare and best interests will inevitably have to be assessed.

**[115] I have no doubt that legal aid to cover the advice and assistance was in scope and should have been**
granted. Furthermore, even if I am wrong about that, it should have been granted by way of ECF if the correct
approach had been applied. Thus I am minded to direct that it be granted to allow the claimant's solicitors to receive
the modest amount for the advice and assistance given.

**[116] Edgehill. The claimant, a Jamaican national, was admitted to the UK on 14 September 1998 as a visitor. She**
was granted leave to remain as a student until 31 January 2001. In March 2007 she applied for leave to remain on
the ground of UK ancestry, asserting that she had been born in the UK but sent to Jamaica where she was brought
up by a couple whom she believed to be her parents. The application was refused and the claimant thereupon
became an overstayer. She did not leave the UK. She said she was joined by various children, one of them had a
son born here in May 2008 who is a British citizen.

**[117] She kept in touch with the Home Office and she applied for a certificate under** _[s 10 of the Nationality,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61H0-TWPY-Y07W-00000-00&context=1519360)_
Immigration and Asylum Act 2002 that she was entitled to remain here. This was refused on 7 March 2012. She
appealed. In her notice of appeal which she filled out without legal assistance, she said, under the heading in the
form asking her to state if the Home Office had suggested she could live safely in another part of her country of
origin, that she disagreed. She said:

'I have no home in another country all my family are here and I have nowhere to go. Also my parents brought
me to Jamaica and left me there and this is my home.'

**[118] That box in the form had no application since the Home Office had not suggested she could live safely in**
another part of her native country. However, the First-tier judge, who dismissed her appeal, did spot that it 'alluded
to her Article 8 rights'. He said he would in any event have considered them, but, because no evidence had been
produced and there was no attendance before him, he dismissed her appeal on 4 June 2012. She was granted
leave to appeal to the Upper Tier, but her appeal was dismissed on 7 February 2013.

**[119] In answering her art 8 claim, the Upper Tribunal Immigration and Asylum Chamber ('UTIAC') considered her**
length of residence (which exceeded 14 years) and had regard to para 276ADE of the Immigration Rules which
came into force on 9 July 2012 and required that an applicant had lived continuously in the UK for at least 20 years
in order to establish an art 8 claim based on private life. It said:

'… Article 8 appeals are decided on the facts as at the date of the hearing and, whilst this was a decision made
before the new Rules came into effect


-----

Cross Society intervening) [2015] 3 All ER 827

**[*864]**

and therefore have no direct application and not retrospective, we consider it appropriate to give weight to the
new Rules as being an expression of the legislature's views as to where the public interest lies.'

**[120] Leave to appeal to the Court of Appeal was sought following refusal of leave by an UTIAC judge. Ground 2**
raised the 14-year point, but somewhat indirectly. Beatson LJ noted that the case raised a question of principle
warranting a decision by the Court of Appeal. There was another case with which it was to be joined which raised a
similar point. In due course, the claimant's appeal was allowed and the other appellant's dismissed since it did not
on the facts cover the same ground. The claimant is due to have a fresh appeal before the tribunal.

**[121] Following Beatson LJ's grant of leave, an application for ECF was made on 19 September 2013. This was**
refused on 14 October 2013. First, it was said that art 8 was not engaged since leave had not been granted on the
grounds specifically relating to art 8. However, that is to misunderstand the position since the correct approach to
14 years' residence would impact on the art 8 claim. There was also refusal on the merits since, it was said, the
other case raised the same point. A review was sought, but on 30 October 2013 the refusal was upheld. The author
accepted that the merits test was met save in one respect, namely that the Court of Appeal would not be
considering grounds relating directly to art 8. That maintains the same error as in the previous decision. But the
author asserts that Beatson LJ stated that the appeal raised a question of principle not a point of law and that
therefore there was no legal complexity. That is an extraordinary assertion since the point of principle obviously
turns on the correct approach in law.

**[122] Mr Tear represented the claimant before the Court of Appeal ([2014] EWCA Civ 402, [2014] Imm AR 883) and**
now seeks to be paid for his work. There can be no doubt that the claimant was entirely unable to argue her appeal
in person. Success was by no means certain, albeit probable, and the Home Office was concerned to try to uphold
the UTIAC's approach. I am clearly of the view that if the Court of Appeal gives leave to appeal, it will (provided the
case is one which can attract ECF) prima facie be a case in which legal aid should be granted. The point at issue
was not entirely straightforward and would affect other cases. In this case I am entirely satisfied that it should have
been granted and that the reasons for refusal are flawed.

**[123] Mr Underwood sought to argue that art 6 applied because the art 8 rights were civil rights. But it is clear, as I**
have indicated, from _Maaouia and_ _RB (Algeria) v Secretary of State for the Home Dept that it does not apply in_
immigration cases such as the claimant's. That argument I reject.

**[124] Mr Chamberlain argued that representation was not needed in most cases before the tribunal or a court since**
the case could be decided on written material. Any judge will recognise the value of oral argument however detailed
the written material may be and the English legal tradition has been based on oral advocacy. That in itself does not
mean that there should always be a need for representation. However, the important consideration is that justice for
a party should so far as possible be ensured and so an individual should have an effective and fair hearing.
Furthermore, the written material may well be defective if it has been, as will often be likely, put forward without
legal advice.

**[125] It must in addition be remembered that it is a fundamental principle that anyone in the UK is subject to its laws**
and is entitled to their protection.
**[*865]**

Thus there must be a fair and effective hearing available and the guidance, as the facts of some of the cases I have
dealt with show, produces unfairness.

**[126] Mr Chamberlain has placed some reliance on observations of Laws J in R v Lord Chancellor, ex p Witham**

_[[1997] 2 All ER 779 at 788, [1998] QB 575 at 586. That case involved a challenge to the imposition of fees to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-611G-00000-00&context=1519360)_
enable a claim to be lodged with the court which were said to breach the constitutional right of access. Laws J
observed:


-----

Cross Society intervening) [2015] 3 All ER 827

'Mr Richards [counsel for the Lord Chancellor] submitted that it was for the Lord Chancellor's discretion to
decide what litigation should be supported by taxpayer's money and what should not. As regards the expenses
of legal representation, I am sure that is right. Payment out of legal aid of lawyers' fees to conduct litigation is a
subsidy by the state which in general is well within the power of the executive, subject to the relevant main
legislation, to regulate. But the impost of court fees is, to my mind, subject to wholly different considerations.
They are the cost of going to court at all, lawyers or no lawyers.'

**[127] Those observations concerned whether legal aid should be available for particular types of litigation. For**
example, defamation was excluded. Laws J was not considering a case where Parliament had indicated that
particular litigation could attract legal aid. In that case, the question whether without legal aid a claim could be dealt
with fairly and effectively was of fundamental importance. Thus I do not think his observations assist Mr
Chamberlain.

**[128] I am conscious that I have not referred in detail to all arguments nor to but a few of the very many authorities**
put before me. The authorities ran to over 5,000 pages. The individual claims were also very substantial. But I hope
I have dealt with the main points which I needed to decide.

**[129] In the circumstances, the decision of the Director in each of the claims is quashed. I have indicated in**
individual claims whether I was of the view that legal aid should have been granted, but I will leave open to Mr
Chamberlain to submit that in any in which I have indicated that view I should not so order. The Lord Chancellor's
guidance is in the respects I have indicated in my judgment unlawful. I think that the appropriate relief would be a
declaration that in those respects it is unlawful, but I will leave counsel to make submissions as to the order I should
make.

Applications allowed.
**AppealsR (on the application of Gudanaviciene) v Director of Legal Aid Casework and another**

The Director of Legal Aid Casework and the Lord Chancellor appealed against the judgment of Collins J dated 13
June 2014 ([2014] EWHC 1840 (Admin)) in which he granted judicial review of the Director's decision to refuse
[legal aid to Teresa Gudanaviciene under s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
applying the Exceptional Funding Guidance (Non-Inquests) issued by the Lord Chancellor. The British Red Cross
Society joined the proceedings as an intervener. The facts are set out in the judgment of the court.
**[*866] R (on the application of IS) v Director of Legal Aid Casework and another (British Red Cross Society**
_intervening)_

The Director of Legal Aid Casework and the Lord Chancellor appealed against the judgment of Collins J dated 13
June 2014 ([2014] EWHC 1840 (Admin)) in which he granted judicial review of the Director's decision to refuse
legal aid to IS under _[s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012, applying the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)_
Exceptional Funding Guidance (Non-Inquests) issued by the Lord Chancellor. The British Red Cross Society joined
the proceedings as an intervener. The facts are set out in the judgment of the court.
_R (on the application of Reis) v Director of Legal Aid Casework and another (British Red Cross Society intervening)_

The Director of Legal Aid Casework and the Lord Chancellor appealed against the judgment of Collins J dated 13
June 2014 ([2014] EWHC 1840 (Admin)) in which he granted judicial review of the Director's decision to refuse
[legal aid to Cleon Reis under s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012, applying](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
the Exceptional Funding Guidance (Non-Inquests) issued by the Lord Chancellor. The British Red Cross Society
joined the proceedings as an intervener. The facts are set out in the judgment of the court.
_R (on the application of B) v Director of Legal Aid Casework and another (British Red Cross Society intervening)_

The Director of Legal Aid Casework and the Lord Chancellor appealed against the judgment of Collins J dated 13
June 2014 ([2014] EWHC 1840 (Admin)) in which he granted judicial review of the Director's decision to refuse
legal aid to B under _[s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012, applying the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)_


-----

Cross Society intervening) [2015] 3 All ER 827

Exceptional Funding Guidance (Non-Inquests) issued by the Lord Chancellor. The British Red Cross Society joined
the proceedings as an intervener. The facts are set out in the judgment of the court.
_R (on the application of Edgehill) v Director of Legal Aid Casework and another (British Red Cross Society_
_intervening)_

The Director of Legal Aid Casework and the Lord Chancellor appealed against the judgment of Collins J dated 13
June 2014 ([2014] EWHC 1840 (Admin)) in which he granted judicial review of the Director's decision to refuse
[legal aid to Jacqueline Elizabeth Edgehill under s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)
2012, applying the Exceptional Funding Guidance (Non-Inquests) issued by the Lord Chancellor. The British Red
Cross Society joined the proceedings as an intervener. The facts are set out in the judgment of the court.
_R (on the application of LS) v Director of Legal Aid Casework and another (British Red Cross Society intervening)_

The Director of Legal Aid Casework and the Lord Chancellor appealed against the judgment of Collins J dated 13
June 2014 ([2014] EWHC 1840 (Admin)) in which he granted judicial review of the Director's decision to refuse
legal aid to LS under _[s 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012, applying the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C2BT-00000-00&context=1519360)_
Exceptional Funding Guidance (Non-Inquests) issued by the Lord Chancellor. The British Red Cross Society joined
the proceedings as an intervener. The facts are set out in the judgment of the court.
**[*867] Martin Chamberlain QC, Sarah Love and Malcolm Birdling (instructed by the Treasury Solicitor and Legal**
_Aid Agency Central Legal Team) for the appellants.Richard Drabble QC, Ranjiv Khubber and Joseph Markus_
(instructed by Turpin Miller LLP) for Gudanaviciene.Phillippa Kaufmann QC and Chris Buttler (instructed by Public
_Law Project) for IS.Richard Drabble QC, Tim Buley and Alistair Mills (instructed by Duncan Lewis & Co) for_
Reis.Paul Bowen QC and Alison Pickup (instructed by Islington Law Centre) for B.Ashley Underwood QC and
_Adam Tear (instructed by Duncan Lewis & Co) for Edgehill.Paul Bowen QC and Catherine Meredith (instructed by_
_ATLEU) for LS.Guy S Goodwin-Gill and Samantha Knights (instructed by Freshfields Bruckhaus Deringer LLP) for_
the British Red Cross Society.

_Judgment was reserved._

15 December 2014. The following judgment of the court was delivered.

_TABLE OF CONTENTS_

Paragraph

INTRODUCTION [1]

LASPO [6]

The Guidance [11]

The issues [24]

GROUND 1: THE PROPER INTERPRETATION OF SECTION 10(3) OF LASPO [25]

The submissions [25]

Discussion [29]


GROUND 2: IS THE GUIDANCE COMPATIBLE WITH ARTICLE 6 OF THE CONVENTION
AND ARTICLE 47 OF THE CHARTER?



[33]


The ECtHR jurisprudence on art 6 [35]

Discussion [41]

The CJEU jurisprudence [57]


GROUND 3: IS THE GUIDANCE COMPATIBLE WITH ARTICLE 8 OF THE CONVENTION
IN IMMIGRATION CASES?



[60]


The appellants' submissions [60]

Discussion [64]

The case of IS [78]


-----

Cross Society intervening) [2015] 3 All ER 827

GROUND 4: THE CASE OF MS GUDANAVICIENE [81]

GROUND 6: THE CASE OF LS [92]


Does art 12(2) of the Trafficking Directive confer a right to legal aid at the stage left out of
scope by LASPO?



[102]


The application of art 8 to LS's case [110]

GROUND 7: THE CASE OF MR REIS [125]

GROUND 8: THE CASE OF B [136]

Is an application for family reunion in scope for legal aid? [139]

The application of art 8 to B's case [155]

GROUND 9: THE CASE OF MS EDGEHILL [174]

SUMMARY OF CONCLUSIONS [181]

**[*868] INTRODUCTIONLORD DYSON MR.**

**[1] This is the judgment of the court to which each of its members has contributed.**

**[2] These appeals all concern decisions by the Director of Legal Aid Casework ('the Director') to refuse applications**
[for civil legal aid. The decisions were made under the Legal Aid, Sentencing and Punishment of Offenders Act 2012](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C45S-00000-00&context=1519360)
('LASPO') and in the light of the Lord Chancellor's Exceptional Funding Guidance (Non-Inquests) ('the Guidance').
In each case, the Director decided to refuse applications for exceptional case funding ('ECF') under s 10 of LASPO.

**[3] On 30 January 2014, Turner J ordered that the cases be listed together inter alia, because they raised common**
issues as to the circumstances in which the European Convention for the Protection of Human Rights and
Fundamental Freedoms 1950 (as set out in Sch 1 to the Human Rights Act 1998) ('the Convention') and the Charter
of Fundamental Rights of the European Union (OJ 2000 C364 p 1) ('the Charter') required the provision of legal aid
in civil cases.

**[4] Collins J ([2014] EWHC 1840 (Admin)) granted judicial review in each of the six cases that were before him. As**
we shall explain, the appellants have not pursued an appeal in the case of IS. But they appeal the decisions in the
cases of Gudanaviciene, LS, Reis, B and Edgehill. The judge held that the Guidance was unlawful in that it
misstated: (i) the circumstances in which legal aid in civil cases must be made available under s 10(3) of LASPO;
(ii) the test for determining when art 6 of the Convention and art 47 of the Charter require the provision of legal aid
in civil cases; and (iii) the circumstances in which art 8 of the Convention requires the provision of legal aid in civil
cases generally and in immigration cases in particular. Applying what he considered to be the correct test to the
facts of each case, he concluded in the cases of Gudanaviciene, Reis, B and Edgehill that the Convention required
the provision of legal aid; and in the cases of IS and LS that the decisions should be reconsidered by the Director.
In the case of B, he also found that civil legal aid should be made available because the services to which the
application related were 'in scope' ie they fell within para 30 of Pt 1 of Sch 1 to LASPO.

**[5] We shall summarise the issues that arise on these appeals after we have set out the relevant statutory material.**
**LASPO**

**[6]** Part 1 of LASPO deals with legal aid. Its effect is to limit the circumstances in which civil legal aid can be
granted. Section 9 of LASPO provides:

'(1) Civil legal services are to be available to an individual under this Part if—

(a) they are civil legal services described in Part 1 of Schedule 1, and

(b) the Director has determined that the individual qualifies for the services in accordance with this Part (and
has not withdrawn the determination).'

**[*869]**


-----

Cross Society intervening) [2015] 3 All ER 827

**[7]** The civil legal services described in Pt 1 of Sch 1 are therefore in scope for legal aid, subject to specific
exclusions in Pts 2 and 3. Paragraphs 30 and 32 of Pt 1 are relevant to the appeals in respect of B and LS
respectively. We will set out the material parts of those paragraphs when considering their cases.

**[8]** Section 10 of LASPO is central to these appeals. It is headed 'Exceptional cases' and so far as material
provides:

'(1) Civil legal services other than services described in Part 1 of Schedule 1 are to be available to an individual
under this Part if subsection (2) … is satisfied.

(2) This subsection is satisfied where the Director—

(a) has made an exceptional case determination in relation to the individual and the services, and

(b) has determined that the individual qualifies for the services in accordance with this Part,

(and has not withdrawn either determination).

(3) For the purposes of subsection (2), an exceptional case determination is a determination—

(a) that it is necessary to make the services available to the individual under this Part because failure to do so
would be a breach of—

[(i) the individual's Convention rights (within the meaning of the Human Rights Act 1998), or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

(ii) any rights of the individual to the provision of legal services that are enforceable EU rights, or

(b) that it is appropriate to do so, in the particular circumstances of the case, having regard to any risk that
failure to do so would be such a breach.'

**[9] The explanatory notes to s 10(3) state:**

'107. It will be necessary to make legal services available to an individual where the withholding of such
services would clearly amount to a breach of Article 6 … There will be a breach of the enforceable EU rights of
the individual to the provision of legal services where the withholding of such services would be clearly contrary
to the rights reaffirmed by Article 47 of the Charter of Fundamental Rights …

108. Subsection (3)(b) provides that an exceptional case determination may also be made where the Director
considers that the failure to provide legal services would not necessarily amount to a breach of an individual's
rights, but that it is nevertheless appropriate for the services to be made available, having regard to the risk of
such a breach occurring.'

**[10] Section 4 of LASPO requires the Lord Chancellor to designate a civil servant as Director. Section 4(3) obliges**
the Director to:

'(a) comply with directions given by the Lord Chancellor about the carrying out of the Director's functions under
this Part, and

(b) have regard to guidance given by the Lord Chancellor about the carrying out of those functions.'

**The Guidance**

**[11]** Paragraph 1 of the Guidance provides that the Director must have regard to the Guidance in determining
whether civil legal services are to be
**[*870]**


-----

Cross Society intervening) [2015] 3 All ER 827

made available under s 10(2) and (3) of LASPO and that as, in practice, applications will be considered by
caseworkers on the Director's behalf, the guidance is addressed to caseworkers. Paragraph 2 states that—

'[t]his guidance sets out some of the factors that caseworkers should take into account in deciding exceptional
funding applications under section 10(2) and (3) of the Act. It is not intended to be an exhaustive account of
those factors. In particular, it is not intended to replace the need for consideration of representations in
individual cases and new case law that arises. Applications should be considered on a case by case basis.'

**[12] As regards s 10(3)(b) of LASPO, the Guidance states:**

'6. Section 10(3)(b) does not provide a general power to fund cases that fall outside the scope of legal aid. It is
to be used for rare cases and provides that an exceptional case determination may be made where the risk of
the breach of the rights set out in section 10(3)(a) is such that it is appropriate to fund.

7. The purpose of section 10(3) of the Act is to enable compliance with ECHR and EU law obligations in the
context of a civil legal aid scheme that has refocused limited resources on the highest priority cases.
Caseworkers should approach section 10(3)(b) with this firmly in mind. It would not therefore be appropriate to
fund simply because a risk (however small) exists of a breach of the relevant rights. Rather, section 10(3)(b)
should be used in those rare cases where it cannot be said with certainty whether the failure to fund would
amount to a breach of the rights set out at section 10(3)(a) but the risk of breach is so substantial that it is
nevertheless appropriate to fund in all the circumstances of the case. This may be so, for example, where the
case law is uncertain (owing, for example, to conflicting judgments).'

**[13] Section A is entitled 'The right to legal aid under the ECHR'. The Guidance states:**

'9. Whereas Article 6 ECHR provides a specific right to legal assistance in the context of criminal proceedings,
the Convention contains no such specific right in relation to civil proceedings. Rather, the ECtHR has
recognised that there are very limited circumstances in which the failure of the State to provide civil legal aid
may amount to breach of an individual's rights under the European Convention on Human Rights.

10. Caseworkers will need to consider, in particular, whether it is necessary to grant funding in order to avoid a
breach of an applicant's rights under Article 6(1) ECHR. As set out below, the threshold for such a breach is
very high.'

**[14] Under the heading 'Article 6(1) ECHR', the Guidance states:**

'12. Article 6(1) guarantees the right to a fair hearing and the right of access to the court for the purposes of the
determination of a person's civil rights and obligations. In certain very limited circumstances, legal aid may be
required in order to guarantee the effective right of access to a court in civil proceedings.'

**[15] Under the sub-heading 'Will there be a breach of Article 6(1)?' appears the following:**
**[*871]**

'18. Assuming that the proceedings in question involve the determination of a civil right or obligation,
caseworkers should then go on to consider whether the failure to provide legal aid would be a breach of the
applicant's rights under Article 6(1) ECHR.

**The overarching question to consider is whether the withholding of legal aid would make the assertion**
**_of the claim_** **_practically impossible_** **_or lead to an_** **_obvious unfairness_** **_in proceedings. This is a very high_**
threshold.' (Original emphasis.)

**[16] At paras 19 and following, the Guidance sets out the factors that should be taken into account. Paragraph 19**
states that no one of the factors is necessarily determinative and each case needs to be assessed on its particular
facts and in the light of representations made by applicants.


-----

Cross Society intervening) [2015] 3 All ER 827

**[17]** Thus para 20 is headed '(a) How important are the issues at stake?' It states that caseworkers need to
consider 'whether the consequences of the case at hand are objectively so serious as to add weight to the case for
the provision of public funds'. Examples are given.

**[18] Paragraph 21 is headed '(b) How complex are the procedures, the area of law or the evidence in question?'**
Examples are given of factual complexity, procedural complexity and legal complexity.

**[19]** Paragraphs 22–25 are headed '(c) How capable is the applicant of presenting their case effectively?' This
section includes:

'22. Caseworkers should consider whether the applicant would be incapable of presenting their case without
the assistance of a lawyer. When considering this factor, caseworkers will need to bear in mind their
assessment of case complexity, as this may affect the weight that needs to be given to some of the matters
listed below.

23. In doing so, caseworkers should bear in mind that:

  - there is no requirement to provide legal aid to ensure total equality of arms between an applicant and
opponent, so long as each side is afforded a reasonable opportunity to present their case under conditions that
don't place them at a substantial disadvantage compared to the opponent;

  - most courts and, in particular, tribunals are well used to assisting unrepresented parties in presenting or
defending their cases against an opponent who has legal representation.'

**[20]** Examples are then given of the questions that should be addressed in determining whether an applicant is
capable of presenting his case effectively. Paragraph 24 states that, in the case of a child applicant, certain
questions (which are set out) may be relevant. Paragraph 25 states that where the applicant is an adult who lacks
capacity within the meaning of the Mental Health Act 2005 the caseworker should consider certain questions (which
are set out).

**[21] The heading to paras 26–28 is 'Article 8 ECHR'. It states:**

'26. Applicants may seek to argue that the provision of legal aid is necessary in order to avoid a breach of the
applicant's rights under Article 8 ECHR (right to respect for private and family life).

[27. In the cases of [Airey v Ireland (1979) 2 EHRR 305] and [P v UK (2002) 12 BHRC 615], the ECtHR found](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)
that the lack of an accessible legal procedure in certain types of family law proceedings did amount to a breach
of Article 8 ECHR. Although caseworkers should consider each

**[*872]**

application on its individual facts, it would normally only be in circumstances closely analogous to these cases
that the failure to provide legal aid would amount to a breach of Article 8 ECHR.

28. In those cases, the ECtHR also found that the failure to provide legal aid amounted to a breach of Article
6(1) ECHR. It is likely that cases in which an applicant seeks to rely on Article 8 would therefore fall more
naturally to be considered under the Article 6(1) heading.'

**[22] Section B is entitled 'Enforceable EU rights to the provision of legal services'. Paragraphs 30–34 give guidance**
as to how to deal with claims that civil legal services should be made available by virtue of art 47 of the Charter.

**[23]** Section C is entitled 'Specific case types'. Paragraph 39 states that the Annex sets out further guidance in
relation to specific types of case that may arise in applications for exceptional funding. The guidance given in
relation to immigration cases is of particular relevance to the present appeals. It provides:


-----

Cross Society intervening) [2015] 3 All ER 827

'59. Proceedings relating to the immigration status of immigrants and decisions relating to the entry, stay and
deportation of immigrants do not involve the determination of civil rights and obligations.

60. The Lord Chancellor does not consider that there is anything in the current case law that would put the
State under a legal obligation to provide legal aid in immigration proceedings in order to meet the procedural
requirements of Article 8 ECHR.'

**The issues**

**[24] We will consider the issues in the order in which they are raised by the appellants' grounds of appeal. Ground**
1 concerns the proper interpretation of s 10(3) of LASPO. The issue in ground 2 is whether the Guidance is
compatible with art 6 of the Convention and art 47 of the Charter. The issue in ground 3 is whether the Guidance is
compatible with art 8 of the Convention in immigration cases. Ground 4 relates to the case of Ms Gudanaviciene.
Ground 5 relates to the case of IS and is no longer pursued. Grounds 6–9 relate respectively to the cases of LS, Mr
Reis, B and Ms Edgehill.
_Ground 1: The proper interpretation of s 10(3) of LASPOThe submissions_

**[25]** Collins J held that (i) ECF is required under s 10(3)(a) when the applicant can establish 'to a high level of
probability' that without it there would be a breach of his procedural rights under the Convention or EU law (at [44]);
and (ii) the 'risk' of a breach referred to in s 10(3)(b) was a 'substantial risk that there will be a breach of the
procedural requirements of' the Convention or EU law (at [50]). Mr Chamberlain QC submits that, although the
judge did not say so in terms, he also appears to have concluded that, where a 'substantial risk' of a breach is
established, the Director is under a duty to make an ECF determination.

**[26] Mr Chamberlain submits that the judge made the following errors. First, s 10(3)(b) confers a discretion; it does**
not impose a duty. Secondly, there is no warrant for adding a gloss to the wording of s 10(3)(a) and introducing the
nebulous concept of satisfaction 'to a high degree of probability'. The correct test for the application of s 10(3)(a) is
that it applies only where it is _clear that, without funding, there would be a breach. This flows from the statutory_
words 'necessary' and 'would be a breach'. It is reinforced by the explanatory notes: '[I]t will be necessary to make
legal services available to an individual where
**[*873]**

the withholding of such services would clearly amount to a breach …' (Emphasis added.) Thirdly, even if s 10(3)(b)
does impose a duty to fund whenever a risk of the relevant kind can be identified, the subsection does not require
there to be a 'substantial risk' or a 'real prospect' of a breach. Construing the 'exceptional cases' provision as
requiring no more than a 'real prospect' of a breach would undermine the statutory purpose of s 10, namely to
provide civil legal aid only in _exceptional cases (outside the 'in scope' categories identified in Pt 1 of Sch 1). Mr_
Chamberlain submits that Coulson J expressed the point correctly in _M v Director of Legal Aid Casework [2014]_
_[EWHC 1354 (Admin), [2014] All ER (D) 40 (May) (at [71]):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C4S-6RS1-DYBP-N160-00000-00&context=1519360)_

'In my judgment, Mr Eadie QC was right to say that the test for “risk” required by s 10(3)(b) must be considered
by reference to the aim and purpose of LASPO itself. LASPO aims to make civil legal aid available in the
particular cases identified in Pt 1 of Sch 1, and not otherwise, unless the provision of legal aid is necessary or
appropriate within the definitions at s 10(3). Those exceptional cases will therefore be limited; in my view, they
can only arise either where it could definitely be said that a refusal of legal aid would give rise to a breach of
the Convention; or where there was a significant risk or a very high risk of such a breach. However it is
expressed, it must be a “very high threshold”: see the judgment of the Divisional Court in R (on the application
_of Howard League for Penal Reform) v Lord Chancellor [2014] EWHC 709 (Admin),_ _[[2014] All ER (D) 168](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BS9-H8J1-DYBP-N1JS-00000-00&context=1519360)_
_[(Mar) (at [44]) … Any lesser test would, in my judgment, be contrary to the purpose and scheme of LASPO](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BS9-H8J1-DYBP-N1JS-00000-00&context=1519360)_
because, instead of the specific and defined cases in Pt 1 of Sch 1, it would create an almost limitless category
of “exceptional cases”.'

**[27]** Fourthly, the judge was wrong to apply a 'substantial risk' or 'real risk' test. This is the test applied by the
European Court of Human Rights ('ECtHR') in relation to extradition or deportation cases and in the context of the


-----

Cross Society intervening) [2015] 3 All ER 827

operational duty to protect citizens from the criminal acts of third parties: see, for example, Soering v UK (1989) 11
[EHRR 439 and Osman v UK (1998) 5 BHRC 293. It is not applied to impose a duty on a state to ensure that those](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3RY-00000-00&context=1519360)
within its jurisdiction are not exposed to a real risk of a breach of procedural rights by the organs of that very state.
The contracting states are obliged to ensure that they do not breach Convention rights.

**[28] Mr Drabble QC (supported by Mr Bowen QC) submits that the definition of the in scope categories set out in Pt**
1 to Sch 1 is neutral in the sense that it tells one nothing about the width of s 10(3)(a) and (b). He contends that the
question whether a refusal of legal aid _would be a breach of an individual's Convention rights or enforceable EU_
rights must be answered by applying the approach to be derived from the ECtHR and the Court of Justice of the
European Union ('CJEU') case law respectively. There is no basis for saying that s 10(3)(a) requires a high
threshold or a high standard of proof. Section 10(3)(b) caters for those cases where it is not possible to decide
whether there would be a breach but there is a risk ('any risk', not a substantial risk) of a breach.
_Discussion_

**[29] We respectfully disagree with the passage in the judgment of Coulson J that we have quoted at [26], above.**
The fact that s 10 is headed 'Exceptional cases' and that it provides for an 'exceptional case determination' says
nothing
**[*874]**

about whether there are likely to be few or many such determinations. Exceptionality is not a test. The criteria for
deciding whether an ECF determination should or may be made are set out in s 10(3) by reference to the
requirements of the Convention and the Charter. In our view, there is nothing in the language of s 10(3) to suggest
that exceptional case determinations will only rarely be made.

**[30] Section 10(3) carefully describes the scope of the exceptional cases by reference to an individual's Convention**
or EU rights. Unsurprisingly, s 10(3)(a) obliges the Director to make an exceptional case determination if he is of the
opinion that it is necessary to make the services available because failure to do so would be a breach of the
individual's Convention or EU rights. Section 10(3)(b) gives him a discretion to make a determination if he considers
it 'appropriate' to do so having regard to the risk that failure to do so would be a breach. Whether the denial of legal
aid would be a breach of Convention or EU rights can only be judged by reference to the principles enunciated by
the ECtHR and the CJEU to which we shall come shortly.

**[31] We see no warrant for construing s 10(3)(a) as imposing a condition that an ECF determination should only be**
made where it can definitely be said (Coulson J's formulation) that refusal would be a breach; or where there is a
'high level of probability' that refusal would be a breach (Collins J's test). There is no need to add a gloss to the
wording of the statute 'would be a breach'. In deciding whether there would be a breach, the Director should apply
the principles to be derived from the case law (some of which is mentioned at para 27 of the Guidance). There is no
need for elaboration. When determining whether a complaint of a breach of Convention rights has been
established, the ECtHR does not ask itself whether there has definitely been a breach or whether there has been a
breach to a high level of probability. It simply asks whether there has been a breach. In our view, this approach
should inform the meaning of the words 'would be a breach' in s 10(3)(a). We do not consider that the word 'clearly'
in the explanatory notes (see para [9], above) takes the argument any further. We should add that we accept the
submission of Mr Chamberlain that the 'real risk of a breach' is a concept which has no part to play in the exercise
envisaged by s 10(3). Section 10(3)(a) speaks of the situation where a failure to make civil legal services available
would be a breach, not where there would be a real risk of a breach. The concept of real risk has no part to play in
the question whether the denial of legal aid would amount to a breach of an individual's procedural rights under the
Convention or under art 47 of the Charter.

**[32]** In short, therefore, if the Director concludes that a denial of ECF would be a breach of an individual's
Convention or EU rights, he must make an exceptional funding determination. But as we shall see, the application
of the ECtHR and CJEU case law is not hard-edged. It requires an assessment of the likely shape of the proposed
litigation and the individual's ability to have effective access to justice in relation to it. The Director may conclude
that he cannot decide whether there would be a breach of the individual's Convention or EU rights. In that event, he


-----

Cross Society intervening) [2015] 3 All ER 827

is not required by s 10(3)(a) to make a determination. He must then go on to consider whether it is appropriate to
make a determination under s 10(3)(b). In making that decision, he should have regard to _any risk that failure to_
make a determination would be a breach. These words mean exactly what they say. The greater he assesses the
risk to be, the more likely it is that he will consider it to be appropriate to make a determination. That is because, if
the risk eventuates, there will be a breach.
**[*875]**

But the seriousness of the risk is only one of the factors that the Director may take into account in deciding whether
it is appropriate to make a determination. He should have regard to all the circumstances of the case.
_Ground 2: Is the guidance compatible with art 6 of the Convention and art 47 of the Charter?_

**[33] So far as material, art 6 of the Convention provides:**

'1. In the determination of his civil rights and obligations … everyone is entitled to a fair and public hearing
within a reasonable time by an independent and impartial tribunal established by law …'

**[34] Article 47 of the Charter provides:**

'Everyone whose rights and freedoms guaranteed by the law of the Union are violated has the right to an
effective remedy before a tribunal in compliance with the conditions laid down in this Article.

Everyone is entitled to a fair and public hearing within a reasonable time by an independent and impartial
tribunal previously established by law. Everyone shall have the possibility of being advised, defended and
represented.

Legal aid shall be made available to those who lack sufficient resources in so far as such aid is necessary to
ensure effective access to justice.'

_The ECtHR jurisprudence on art 6_

**[35] It is necessary to examine a few cases. The first decision in which the ECtHR recognised that art 6 can require**
the provision of civil legal aid in certain circumstances was Airey v Ireland (1979) 2 EHRR 305. The court said:

'24. … The Convention is intended to guarantee not rights that are theoretical or illusory but rights that are
practical and effective. This is particularly so of the right of access to the courts in view of the prominent place
held in a democratic society by the right to a fair trial. It must therefore be ascertained whether Mrs. Airey's
appearance before the High Court without the assistance of a lawyer would be effective, in the sense of
whether she would be able to present her case properly and satisfactorily.

Contradictory views on this question were expressed by the Government and the Commission during the oral
hearings. It seems certain to the Court that the applicant would be at a disadvantage if her husband were
represented by a lawyer and she were not. Quite apart from this eventuality, it is not realistic, in the Court's
opinion, to suppose that, in litigation of this nature, the applicant could effectively conduct her own case,
despite the assistance which, as was stressed by the Government, the judge affords to parties acting in
person.

In Ireland, a decree of judicial separation is not obtainable in a District Court, where the procedure is relatively
simple, but only in the High Court. A specialist in Irish family law, Mr. Alan J. Shatter, regards the High Court as
the least accessible court not only because “fees payable for representation before it are very high” but also by
reason of the fact that “the procedure for instituting proceedings … is complex particularly in the case of those
proceedings which must be commenced by a petition”, such as those for separation.

Furthermore, litigation of this kind, in addition to involving complicated points of law, necessitates proof of
adultery, unnatural practices or, as in

**[*876]**


-----

Cross Society intervening) [2015] 3 All ER 827

the present case, cruelty; to establish the facts, expert evidence may have to be tendered and witnesses may
have to be found, called and examined. What is more, marital disputes often entail an emotional involvement
that is scarcely compatible with the degree of objectivity required by advocacy in court.

For these reasons, the Court considers it most improbable that a person in Mrs. Airey's position … can
effectively present his or her own case. This view is corroborated by the Government's replies to the questions
put by the Court, replies which reveal that in each of the 255 judicial separation proceedings initiated in Ireland
in the period from January 1972 to December 1978, without exception, the petitioner was represented by a
lawyer …

The Court concludes from the foregoing that the possibility to appear in person before the High Court does not
provide the applicant with an effective right of access …

26. … It would be erroneous to generalise the conclusion that the possibility to appear in person before the
High Court does not provide Mrs. Airey with an effective right of access; that conclusion does not hold good for
all cases concerning “civil rights and obligations” or for everyone involved therein. In certain eventualities, the
possibility of appearing before a court in person, even without a lawyer's assistance, will meet the requirements
of Article 6 para. 1; there may be occasions when such a possibility secures adequate access even to the High
Court. Indeed, much must depend on the particular circumstances.

In addition, whilst Article 6 para. 1 guarantees to litigants an effective right of access to the courts for the
determination of their “civil rights and obligations”, it leaves to the State a free choice of the means to be used
towards this end. The institution of a legal aid scheme—which Ireland now envisages in family law matters …
constitutes one of those means but there are others such as, for example, a simplification of procedure. In any
event, it is not the Court's function to indicate, let alone dictate, which measures should be taken; all that the
Convention requires is that an individual should enjoy his effective right of access to the courts in conditions not
at variance with Article 6 para. 1 …

The conclusion appearing at the end of paragraph 24 above does not therefore imply that the State must
provide free legal aid for every dispute relating to a “civil right”.

To hold that so far-reaching an obligation exists would, the Court agrees, sit ill with the fact that the Convention
contains no provision on legal aid for those disputes, Article 6 para. 3(c) dealing only with criminal proceedings.
However, despite the absence of a similar clause for civil litigation, Article 6 para. 1 may sometimes compel the
State to provide for the assistance of a lawyer when such assistance proves indispensable for an effective
access to court either because legal representation is rendered compulsory, as is done by the domestic law of
certain Contracting States for various types of litigation, or by reason of the complexity of the procedure or of
the case.'

**[36] In X v UK (1984) 6 EHRR 136, the applicant was involved in an employment dispute with his employer. His**
union refused to support his complaint before the industrial tribunal. He therefore invoked his rights under
**[*877]**

art 6(1) of the Convention saying that, without legal representation, he could not have a fair hearing. His complaint
was dismissed as manifestly unfounded. The Commission said at para 3 of its judgment:

'… the Commission recalls that unlike the situation concerning criminal proceedings (cf. Art 6(3)(c)) the
Convention does not guarantee as such a right to free legal aid in civil cases. Only in exceptional
circumstances, namely where the withholding of legal aid would make the assertion of a civil claim practically
impossible, or where it would lead to obvious unfairness of the proceedings, can such a right be invoked by
virtue of Art. 6(1) of the Convention (cf Airey v Ireland, 2 EHRR 305).'

**[37] In the subsequent Strasbourg case law, there seems to have been no further reference to X v UK, but there**
has been regular reference to, and application of, the approach set out in Airey v Ireland: see, for example, Munro v


-----

Cross Society intervening) [2015] 3 All ER 827

_[UK (1987) 10 EHRR 516, Stewart-Brady v UK (1997) 24 EHRR CD 38, McVicar v UK (2002) 12 BHRC 567, P v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4VR-00000-00&context=1519360)_
_[(2002) 12 BHRC 615, Steel v UK (2005) 18 BHRC 545 and AK v Croatia [2013] ECHR 37956/11.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)_

**[38]** In _P v UK, the principles were expressed with a slightly different emphasis. At para 89, the court said that_
failure to provide an applicant with the assistance of a lawyer may breach art 6(1) where—

'such assistance is indispensable for effective access to court … by reason of the complexity of the procedure
or the type of case …

Thus, though the pursuit of proceedings as a litigant in person may on occasion not be an easy matter, the
limited public funds available for civil actions renders a procedure of selection a necessary feature of the
system of administration of justice, and the manner in which it functions in particular cases may be shown not
to have been arbitrary or disproportionate, or to have impinged on the very essence of the right of access to
court.'

**[39] At para 90, the court said:**

'Secondly, the key principle governing the application of art 6 is fairness. In cases where an applicant appears
in court notwithstanding lack of assistance of a lawyer and manages to conduct his or her case in the teeth of
all the difficulties, the question may nonetheless arise as to whether this procedure was fair. There is the
importance of ensuring the appearance of the fair administration of justice and a party in civil proceedings must
be able to participate effectively, inter alia, by being able to put forward the matters in support of his or her
claims. Here, as in other aspects of Article 6, the seriousness of what is at stake for the applicant will be of
relevance to assessing the adequacy and fairness of the procedures.'

**[40] In Steel v UK, the court said:**

'61. The question whether the provision of legal aid is necessary for a fair hearing must be determined on the
basis of the particular facts and circumstances of each case and will depend, inter alia, upon the importance of
what is at stake for the applicant in the proceedings, the complexity of the relevant law and procedure and the
applicant's capacity to represent him or herself effectively.

62. The right of access to a court is not, however, absolute and may be subject to restrictions, provided that
these pursue a legitimate aim and are

**[*878]**

proportionate. It may therefore be acceptable to impose conditions on the grant of legal aid based, inter alia, on
the financial situation of the litigant or his or her prospects of success in the proceedings. Moreover, it is not
incumbent on the State to seek through the use of public funds to ensure total equality of arms between the
assisted person and the opposing party, as long as each side is afforded a reasonable opportunity to present
his or her case under conditions that do not place him or her at a substantial disadvantage vis-à-vis the
adversary.'

_Discussion_

**[41] Mr Chamberlain submits that an analysis of the facts in Airey, P v UK and Steel v UK gives a good indication of**
the types of circumstances required to establish that a failure to provide legal aid gives rise to a breach of art 6(1).
He says that such an analysis justifies the statement at para 18 of the Guidance that art 6(1) imposes a 'very high
threshold'.

**[42] It is clear that para 18 of the Guidance is based on X v UK. Mr Drabble submits that there is no support for the**
_X v UK test and that it is an aberration within an otherwise consistent strand of Strasbourg authority. We accept that_
the precise words adopted in _X v UK have not been adopted elsewhere in the Strasbourg jurisprudence. In_
particular, the phrase 'practical impossibility' does not appear elsewhere. Rather, the key question is said to be
whether legal aid is necessary for 'effective access to the court'. The cases set out the kind of factors which are


-----

Cross Society intervening) [2015] 3 All ER 827

relevant for a resolution of this issue. But the phrase 'obvious unfairness' (as a summary) is wide enough to capture
the guidance given in the jurisprudence. Indeed, as we have seen, the ECtHR said in P v UK at para 90 that the
'key principle governing the application of art 6 is fairness'. Accordingly, we do not accept that the X v UK test is an
aberration. There is no real inconsistency between it and the test which is set out, admittedly in more detail, in the
_Airey line of authority. This should not be surprising, since the Commission in X v UK referred to and purported to_
apply _Airey. The_ _Airey approach (as developed in the subsequent case law) is consistent with, but more_
comprehensive than, the X v UK approach. It should be regarded as articulating the relevant law.

**[43] It is in any event wrong to focus solely on para 18 of the Guidance. As we have seen, paras 19–24 set out in**
some detail the factors that should be taken into account in determining whether the withholding of civil legal aid
would be a breach of art 6(1). We have summarised these at [17]–[20], above. They fairly reflect the factors that the
Strasbourg jurisprudence states are relevant to an assessment of whether the failure to provide civil legal aid would
be a breach of art 6(1). We do not understand Mr Drabble and Mr Bowen to contest this. They do not identify any
particular factors which have been omitted.

**[44] They do, however, say that the Guidance fails accurately to reflect the art 6(1) jurisprudence because it sets**
the bar too high for the grant of ECF. It is necessary to repeat the relevant passages. Paragraph 7 states that s
10(3)(b) of LASPO should be used 'in those rare cases where it cannot be said with certainty whether the failure to
fund would amount to a breach'. The only example given of a case where funding may be appropriate is where the
case law is uncertain '(owing, for example, to conflicting judgments)'. In our view, this misinterprets s 10(3)(b). The
discretion conferred by this provision is not so severely circumscribed. There is no basis for saying that it may only
be exercised in such rare circumstances. The extreme nature of the single example
**[*879]**

that is given shows how rarely the Guidance contemplates that it will be appropriate to make an exceptional case
determination under s 10(3)(b). Paragraph 9 states that the ECtHR has recognised that there are 'very limited'
circumstances in which the failure to provide legal aid may amount to a breach of Convention rights. Paragraph 10
states that the threshold for a breach of an applicant's rights under art 6(1) is 'very high'. Paragraph 12 states that in
certain 'very limited' circumstances, legal aid may be required in order to guarantee right of access to a court in civil
proceedings. Paragraph 18 states that the X v UK test is a 'very high threshold'.

**[45] In our judgment, the cumulative effect of these passages is to misstate the effect of the ECtHR jurisprudence.**
As we have seen, the Guidance correctly identifies many of the particular factors that should be taken into account
in deciding whether to make an exceptional case determination, but their effect is substantially neutralised by the
strong steer given in the passages that we have highlighted. These passages send a clear signal to the
caseworkers and the Director that the refusal of legal aid will amount to a breach of art 6(1) only in rare and
extreme cases. In our judgment, there are no statements in the case law which support this signal. For the reasons
stated earlier, we do not consider that the reference in X v UK to 'exceptional circumstances' provides support for it.

**[46]** The general principles established by the ECtHR are now clear. Inevitably, they are derived from cases in
which the question was whether there was a breach of art 6(1) in proceedings which had already taken place. We
accept the following summary of the relevant case law given by Mr Drabble: (i) the Convention guarantees rights
that are practical and effective, not theoretical and illusory in relation to the right of access to the courts (Airey
(1979) 2 EHRR 305 (para 24), _Steel v UK_ _[(2005) 18 BHRC 545 (para 59)); (ii) the question is whether the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W37F-00000-00&context=1519360)_
applicant's appearance before the court or tribunal in question without the assistance of a lawyer was effective, in
the sense of whether he or she was able to present the case properly and satisfactorily (Airey (1979) 2 EHRR 305
(para 24), McVicar _[(2002) 12 BHRC 567 (para 48) and Steel v UK (2005) 18 BHRC 545 (para 59)); (iii) it is relevant](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4VR-00000-00&context=1519360)_
whether the proceedings taken as a whole were fair (McVicar _[(2002) 12 BHRC 567 (para 50), P v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4VR-00000-00&context=1519360)_ _[(2002) 12](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)_
_[BHRC 615 (para 91)); (iv) the importance of the appearance of fairness is also relevant: simply because an](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)_
applicant can struggle through 'in the teeth of all the difficulties' does not necessarily mean that the procedure was
[fair (P v UK (2002) 12 BHRC 615 (para 91)); and (v) equality of arms must be guaranteed to the extent that each](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)
side is afforded a reasonable opportunity to present his or her case under conditions that do not place them at a
[substantial disadvantage vis-à-vis their opponent (Steel v UK (2005) 18 BHRC 545 (para 62)).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W37F-00000-00&context=1519360)


-----

Cross Society intervening) [2015] 3 All ER 827

**[47] Although the Strasbourg case law does not contain statements which provide explicit support for the very high**
threshold articulated in the Guidance, Mr Chamberlain submits that the outcomes of the cases demonstrate that the
threshold is indeed very high. It is, therefore, necessary to return to the cases. In _Airey the applicant wished to_
petition for a judicial separation in the Irish High Court. She lacked the means to employ a lawyer and legal aid was
not available. The ECtHR held that there had been a violation of art 6(1). At the relevant time, divorce was
constitutionally prohibited and a judicial decree of separation was required for a spouse to be relieved of the duty of
cohabitation. Decrees of separation were obtainable only in the High Court and the evidence was that in each of the
255 separation proceedings initiated in Ireland in the seven years prior to the hearing in Strasbourg, the petitioner
was represented
**[*880]**

by a lawyer. We have set out the relevant parts of the court's reasons for concluding that there had been a violation
of art 6(1). The court concluded on the facts of that case that it was 'most improbable' that a person in Mrs Airey's
position could effectively present her case. Mr Chamberlain submits that this was an extreme case. We would not
dissent from this assessment.

**[48] As we have seen, X v UK involved an employment dispute which the applicant wished to bring to an industrial**
tribunal. The Commission was of the opinion that the applicant could have brought his case without legal
representation. Of particular significance is the statement at para 4 that industrial tribunal proceedings 'are
designed to be conducted in a practical and straightforward manner without too much emphasis on formalities'. The
contrast with Airey is striking.

**[49] In Munro, the applicant was denied legal aid to pursue libel proceedings arising from a finding by the industrial**
tribunal that he had been constructively dismissed. The Commission distinguished Airey, holding that the applicant
had not shown that he was hindered in his access to court by the absence of legal aid. One of the factors that
influenced the Commission was that there had already been a hearing before the tribunal which considered the
same substantive issues as would have been considered in the defamation proceedings.

**[50] In McVicar, the applicant was the defendant in libel proceedings brought by a comparatively wealthy individual.**
The applicant complained that the denial of legal aid violated his art 6(1) rights. He was faced with the burden of
having to prove that the allegations he had made were true. In order to do so, (i) he called witness and expert
evidence some of which was excluded as a result of his failure to comply with the rules of court and (ii) he crossexamined the plaintiff's witnesses and experts in the course of a trial which lasted more than two weeks. He had no
formal legal training, but he was a well-educated and experienced journalist who was said to be capable of
formulating a cogent argument. In this respect, his position could be contrasted with that of Mrs Airey. The court
considered that the rules pursuant to which the evidence was excluded were clear and unambiguous. So far as the
law of defamation was concerned, the court did not consider it to be sufficiently complex to require a person in the
applicant's position to have legal assistance. The court took other factors into account including the fact that an
individual's emotional involvement in a defamation case is less than that in an application for judicial separation. In
all the circumstances, the applicant was not prevented from presenting his defence effectively by reason of his
ineligibility for legal aid.

**[51] In P v UK, before the birth of P's child S, the local authorities expressed concern about her previous conviction**
in the United States and sought to initiate care proceedings in relation to the unborn child. P was suffering from a
mental illness known as Munchhausen's syndrome. On the birth of S, the child was removed from P and her
husband C and freed for adoption. Initially, P was represented by counsel. But the judge permitted the lawyers to
withdraw from the case. The outcome of the proceedings was that S was ordered to be removed from the care of P
and C. The ECtHR decided that there had been a breach of art 6(1). It held that the proceedings were of
'exceptional complexity' extending over a period of 20 days; the documentation was voluminous; there was 'highly
complex expert evidence' relating to the fitness of P and C to parent their daughter; and the hearing raised difficult
points of law. In short (see para 95):
**[*881]**


-----

Cross Society intervening) [2015] 3 All ER 827

'The complexity of the case, along with the importance of what was at stake and the highly emotive nature of
the subject-matter, [led the] Court to conclude that the principles of effective access to court and fairness
required that P receive the assistance of a lawyer.'

**[52] In Steel v UK, the applicants were refused legal aid to contest a libel claim. Although they had some help from**
volunteer lawyers, they represented themselves for the bulk of the proceedings which lasted 303 days. Damages
were awarded against them. Their complaint that their art 6(1) rights had been violated was upheld by the ECtHR.
The court applied the _Airey test to the facts of the case. As regards what was at stake for the defendants, the_
proceedings were not determinative of important family rights and relationships, but the defendants were acting to
protect their right to freedom of expression and the financial consequences for them of losing were high when
compared to their low incomes. The proceedings were on a different scale of magnitude from those in McVicar. The
case was also legally far from straightforward. The court took into account the considerable latitude afforded to the
applicants by the domestic courts. However, in an action of this complexity, neither the sporadic help given by
volunteer lawyers nor the extensive judicial assistance and latitude granted to the applicants as litigants in person
'was any substitute for competent and sustained representation by an experienced lawyer familiar with the case and
with the law of libel' (para 69). Finally, the court said:

'[T]he disparity between the respective levels of legal assistance enjoyed by the applicants and McDonald's
was of such a degree that it could not have failed, in this exceptionally demanding case, to have given rise to
unfairness, despite the best efforts of the judges at first instance and on appeal.'

**[53] The last ECtHR authority to which we should refer is AK v Croatia. This case concerned proceedings by which**
AK was divested of her parental rights in respect of her son L. She had a mild mental disability, a speech
impediment and limited vocabulary. The court first considered the complaint of a breach of art 8 and concluded that
there had been a breach. It then addressed the complaint of a breach of art 6(1) and held that no separate issue
arose in relation to art 6(1). The finding of a breach was based on the importance of the proceedings for AK's right
to respect for her family life and the fact that she could not properly understand the full legal effect of the
proceedings and adequately argue her case.

**[54]** We have been referred to some domestic authorities. The only one which we should mention is _Perotti v_
_Collyer-Bristow (a firm)_ _[[2003] EWCA Civ 1521, [2004] 2 All ER 189. The Court of Appeal had to consider in what](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6129-00000-00&context=1519360)_
circumstances art 6(1) prevented a court from continuing to hear a case in which one side was unrepresented. The
principal judgment was given by Chadwick LJ. The court held that on the facts of that case the claimant would not
be denied effective access to the courts if he were not represented. Chadwick LJ said (at [31]) that a litigant who
wishes to establish that without legal aid his right to effective access will have been violated 'has a relatively high
threshold to cross'. He said (at [32]):

'The test under art 6(1), as it seems to me, is whether a court is put in a position that it really cannot do justice
in the case because it has no confidence in its ability to grasp the facts and principles of the matter on which it
has to decide. In such a case it may well be said that a litigant is

**[*882]**

deprived of effective access; deprived of effective access because, although he can present his case in person,
he cannot do so in a way which will enable the court to fulfil its paramount and over-arching function of
reaching a just decision. But it is the task of courts to struggle with difficult and ill-prepared cases; and courts
do so every day … If it cannot [reach a just decision] the litigant is effectively deprived of proper access to the
courts.'

**[55] The phrase 'relatively high threshold' (itself somewhat vague) should be contrasted with the phrase 'very high**
threshold' which is used in the Guidance. It is also to be noted that Chadwick LJ makes no reference to factors such
as the importance of what is at stake and overall fairness. We should add that, in using the phrase 'a just decision',
we think that Chadwick LJ must have intended to include both procedural justice (fairness) and substantive justice


-----

Cross Society intervening) [2015] 3 All ER 827

(reaching the correct result). We do not consider that the decision in Perotti adds to what can be derived from the
Strasbourg jurisprudence.

**[56]** It can therefore be seen that the critical question is whether an unrepresented litigant is able to present his
case effectively and without obvious unfairness. The answer to this question requires a consideration of all the
circumstances of the case, including the factors which are identified at paras 19–25 of the Guidance. These factors
must be carefully weighed. Thus the greater the complexity of the procedural rules and/or the substantive legal
issues, the more important what is at stake and the less able the applicant may be to cope with the stress, demands
and complexity of the proceedings, the more likely it is that art 6(1) will require the provision of legal services
(subject always to any reasonable merits and means test). The cases demonstrate that art 6(1) does not require
civil legal aid in most or even many cases. It all depends on the circumstances. It should be borne in mind that,
although in the United Kingdom we have an adversarial system of litigation, judges can and do provide assistance
to litigants in person. The outcomes in X v UK, Munro and McVicar show that it is not a requirement of art 6(1) that
legal services be provided in all but the most straightforward of cases. On the other hand, the outcomes in Airey, P
_v UK, Steel v UK and_ _AK v Croatia do not show that legal services are required only in such extreme cases as_
these. In short, we do not accept the submission of Mr Chamberlain that these decisions justify the passages in the
Guidance which we have criticised at [44]–[45], above.
_The CJEU jurisprudence_

**[57] Mr Chamberlain submits that (i) in situations where a Charter right corresponds with a Convention right, it was**
the intention of the Praesidium that the protections conferred by the former were to be co-extensive with the
protections conferred by the latter (as interpreted by the case law of the ECtHR); and (ii) art 47(2) and (3) of the
Charter were intended to correspond with art 6(1) (save that the former were not limited in scope to situations
involving the determination of civil rights and obligations). It follows that the level of procedural protection provided
by art 47 of the Charter corresponds to that provided by art 6(1) of the Convention.

**[58]** Mr Drabble does not seriously take issue with this, although he points out that the EU law principle of
effectiveness may be wider than the requirements of art 6 of the Convention and he draws attention to the
observations of Advocate General Jääskinen in _Bundeswettbewerbsbehordev v Donau Chemie AG_ (Case _C-_
_536/11) [2013] 5 CMLR 658 (para 47). We doubt_
**[*883]**

whether there is any material difference between art 47(3) of the Charter and art 6(1) of the Convention for present
purposes. It is to be noted that art 52(3) of the Charter provides that, in so far as the Charter contains rights which
correspond to rights guaranteed by the Convention, the meaning and scope of those rights shall be the same as
those laid down by the Convention. We are reinforced in the view that there is no such difference by what was said
by the CJEU in _DEB Deutsche Energiehandels– und Beratungsgesellschaft mbH v Bundesrepublik Deutschland_
(Case _C-279/09) [2010] ECR I-13849 at paras 45–53 of its judgment. After reviewing some of the ECtHR_
jurisprudence, the court said:

'60. In that connection, it is for the national court to ascertain whether the conditions for granting legal aid
constitute a limitation on the right of access to the courts which undermines the very core of that right; whether
they pursue a legitimate aim; and whether there is a reasonable relationship of proportionality between the
means employed and the legitimate aim which it is sought to achieve.

61. In making that assessment, the national court must take into consideration the subject-matter of the
litigation; whether the applicant has a reasonable prospect of success; the importance of what is at stake for
the applicant in the proceedings; the complexity of the applicable law and procedure; and the applicant's
capacity to represent himself effectively. In order to assess the proportionality, the national court may also take
account of the amount of the costs of the proceedings in respect of which advance payment must be made and
whether or not those costs might represent an insurmountable obstacle to access to the courts.'


-----

Cross Society intervening) [2015] 3 All ER 827

**[59] It follows that what we have said in relation to art 6(1) of the Convention applies with equal force to art 47(3) of**
the Charter.
_Ground 3: Is the guidance compatible with art 8 of the Convention in immigration cases?The appellants'_
_submissions_

**[60] Mr Chamberlain submits as follows. There is no Strasbourg authority which has decided that art 8 alone**
requires the provision of civil legal aid in an immigration case. There is a good reason for this. The decision of the
Grand Chamber of the ECtHR in Maaouia v France _[(2000) 9 BHRC 205 makes it clear that decisions relating to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W2F5-00000-00&context=1519360)_
entry, stay and deportation of immigrants do not involve the determination of civil rights. They are, therefore, outside
the scope of art 6(1) of the Convention. This is so notwithstanding that the decisions in question may 'incidentally
ha[ve] major repercussions on the applicant's private and family life or on his prospects of employment' (para 38).

**[61] The implications of the decision by the ECtHR to exclude immigration decisions from the scope of art 6(1) were**
considered by the House of Lords in RB (Algeria) v Secretary of State for the Home Dept, U (Algeria) v Secretary of
_[State for the Home Dept, Othman v Secretary of State for the Home Dept [2009] UKHL 10, [2009] 4 All ER 1045,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X7K-7490-Y96Y-G39K-00000-00&context=1519360)_

[2010] 2 AC 110. This case concerned an appeal by three individuals who were subject to deportation proceedings
on national security grounds, all of whom alleged that their deportation would be contrary to their rights under art 3.
They challenged the fact that the Special Immigration Appeals Commission ('SIAC') had used closed material in
reaching its conclusions. They accepted that art 6 did not apply since the deportation
**[*884]**

orders did not involve the determination of civil rights. They argued, however, that since their substantive rights
under art 3 were at stake, they were entitled to have the issue of the interference with those substantive rights
determined in accordance with a procedure that satisfied art 6. This argument was rejected. In his skeleton
argument, Mr Chamberlain submits that, if reliance on art 3 did not suffice to confer on the appellants in _RB_
procedural guarantees akin to those which would have arisen under art 6 (had the determination of a civil right been
at stake), it is difficult to envisage circumstances in which reliance on art 8 could achieve a similar result.

**[62] Despite this apparently uncompromising approach, Mr Chamberlain accepts that (i) in general, the procedural**
obligations of art 8 can require the provision of civil legal aid if that is necessary in order to ensure that those
affected by the decision to be taken are involved in the decision-making process as a whole to a degree that is
sufficient to provide them with the requisite degree of protection of their interests; and (ii) in particular, these art 8
procedural obligations can in principle exist in immigration cases. He submits that the focus of the procedural
aspect of art 8 is on the decision-making process viewed as a whole, as opposed to the right to a fair hearing per se
(which is the focus of art 6(1)). Collins J was, therefore, wrong to say at para [50] of his judgment that in general
immigration cases (as opposed to national security immigration cases) there was no good reason to apply a lower
procedural standard for art 8 than for art 6.

**[63] Mr Chamberlain submits that it follows that paras 26–28 of the Guidance regarding the procedural obligations**
imposed by art 8 and their application in an immigration context are correct. He accepts, however, that paras 59
and 60 of the Guidance are incorrect and will need to be amended. The Lord Chancellor has not proposed an
amended version of these paragraphs. Mr Chamberlain told us that an amendment will be formulated in the light of
any guidance that we give in this judgment.
_Discussion_

**[64]** The principal contrary submissions were advanced by Ms Kaufmann QC in her skeleton argument in the
appeal of IS. Although the appellants have withdrawn their appeal in the case of IS, Ms Kaufmann's submissions
remain before us because they were adopted by Mr Bowen on behalf of his clients. It will also be necessary to refer
to the facts of IS because they are illustrative of the kind of case in which the appellants accept that the procedural
obligations imposed by art 8 require the provision of civil legal aid.

**[65] It is not in dispute that in non-immigration cases there are procedural requirements inherent in art 8. In W v UK**
(1988) 10 EHRR 29 (para 64), the ECtHR said:


-----

Cross Society intervening) [2015] 3 All ER 827

'In the Court's view, what therefore has to be determined is whether, having regard to the particular
circumstances of the case and notably the serious nature of the decisions to be taken, the parents have been
involved in the decision-making process, seen as a whole, to a degree sufficient to provide them with the
requisite protection of their interests. If they have not, there will have been a failure to respect their family life
and the interference resulting from the decision will not be capable of being regarded as “necessary” within the
meaning of Article 8.'

**[66] This statement of the law has often been repeated by the ECtHR. Effective involvement in the decision-making**
process may require the grant of
**[*885]**

legal aid. We have already considered some of the relevant authorities in our consideration of the art 6(1) issue. In
_Airey v Ireland, having decided that there was a breach of art 6(1), the ECtHR went on to hold that the applicant_
was denied an 'effectively accessible' legal procedure to enable her to petition for a judicial separation and that this
[also constituted a breach of art 8. In P v UK (2002) 12 BHRC 615, having decided that there was a breach of art](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41J-00000-00&context=1519360)
6(1), the ECtHR said:

'136. The court does not propose to attempt to untangle these opposed considerations, which raise difficult and
sensitive issues concerning S's welfare. It considers rather that the complexity of the case, and the fine
balance which had to be struck between the interests of S and her parents, required that particular importance
be attached to the procedural obligations inherent in art 8 of the convention. It was crucial for the parents in this
case to be able to put forward their case as favourably as possible, emphasising for example whatever factors
militated in favour of a further assessment of a possible rehabilitation, and for their viewpoints on the possible
alternatives to adoption and the continuation of contact even after adoption to be put forward at the appropriate
time for consideration by the court.

137. The lack of legal representation of P during the care proceedings and of P and C during the freeing for
adoption proceedings, together with the lack of any real lapse of time between the two procedures, has been
found above to have deprived the applicants of a fair and effective hearing in court. Having regard to the
seriousness of what was at stake, the court finds that it also prevented them from being involved in the
decision-making process, seen as a whole, to a degree sufficient to provide them with the requisite protection
of their interests under art 8 of the convention. Emotionally involved in the case as they were, the applicant
parents were placed at a serious disadvantage by these elements, and it cannot be excluded that this might
have had an effect on the decisions reached and eventual outcome for the family as a whole.'

**[67] In the result, the court found that there had been a breach of art 8. As Ms Kaufmann says, although the ECtHR**
adopted the formula of 'sufficient involvement in the decision-making process' (W v UK) rather than 'effective
access' (Airey), the effect was the same in that case.

**[[68] In AK v Croatia [2013] ECHR 37956/11, the court started with a consideration of art 8. Having found a violation](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0M0-00000-00&context=1519360)**
of art 8, it held that no separate issue arose under art 6. As we have already said, AK had mild mental disability,
speech impediment and limited vocabulary. A welfare centre issued proceedings to divest AK of her parental rights
in respect of her son L. She was unrepresented in the proceedings. At para 63, the court repeated the formulation
set out in W v UK and held that, in the absence of legal representation, there was a breach of art 8. At para 72 it
said:

'… the national authorities should have ensured that, in view of the importance of the proceedings at issue for
her right to respect for her family life, the first applicant's interests were adequately protected in the
proceedings at issue. That the first applicant could not properly understand the full legal effect of such
proceedings and adequately argue her case and thus protect her rights and interests as the biological mother
of L is evidenced by her above-described personal circumstances.'

**[*886]**


-----

Cross Society intervening) [2015] 3 All ER 827

**[69] There is no reason in principle why the art 8 test articulated by the ECtHR in cases such as W v UK should not**
apply in immigration cases. So much is now common ground. The fact that immigration decisions do not involve the
determination of civil rights means that art 6(1) cannot be invoked in relation to such decisions. But it does not
follow that the procedural obligations of art 8 do not apply to immigration decisions. Mr Chamberlain is right to
concede that art 8 can apply in immigration cases. Article 8 is frequently engaged in immigration decisions. The
procedural protections inherent in art 8 are necessary in order to ensure that art 8 rights are practical and effective.
The necessity for this is at least as important in immigration cases as in any other cases. Indeed, the W v UK test
[has been applied by the ECtHR in immigration cases: see Ciliz v Netherlands [2000] ECHR 29192/95 at para 66](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X16T-00000-00&context=1519360)
and Senigo Longue v France App No 19113/09 (10 July 2014, unreported) at para 63.

**[70] It is true that the test for art 8 as it is stated in the Strasbourg jurisprudence (whether those affected have been**
involved in the decision-making process, viewed as a whole, to a degree sufficient to provide them with the requisite
protection of their interests) differs from the test for art 6(1) (whether there has been effective access to court). The
art 8 test is broader than the art 6(1) test, but in practice we doubt whether there is any real difference between the
two formulations in the context with which we are concerned. There is nothing in the Strasbourg jurisprudence to
which our attention has been drawn which suggests that the ECtHR considers that there is any such difference. In
practice, the ECtHR's analysis of the facts in the case law does not seem to differ as between art 6(1) and art 8.
This is not surprising. The focus of art 6(1) is to ensure a fair determination of civil rights and obligations by an
independent and impartial tribunal. Article 8 does not dictate the form of the decision-making process that the state
must put in place. But the focus of the procedural aspect of art 8 is to ensure the effective protection of an
individual's art 8 rights. To summarise, in determining what constitutes effective access to the tribunal (art 6(1)) and
what constitutes sufficient involvement in a decision-making process (art 8), for present purposes the standards are
in practice the same.

**[71]** As Ms Kaufmann submits, the significance of the cases lies not in their particular facts, but in the principles
they establish, viz: (i) decision-making processes by which art 8 rights are determined must be fair; (ii) fairness
requires that individuals are involved in the decision-making process, viewed as a whole, to a degree that is
sufficient to provide them with the requisite protection of their interests: this means that procedures for asserting or
defending rights must be effectively accessible; and (iii) effective access may require the state to fund legal
representation.

**[72] Whether legal aid is required will depend on the particular facts and circumstances of each case, including: (a)**
the importance of the issues at stake; (b) the complexity of the procedural, legal and evidential issues; and (c) the
ability of the individual to represent himself without legal assistance, having regard to his age and mental capacity.
The following features of immigration proceedings are relevant: (i) there are statutory restrictions on the supply of
[advice and assistance (see s 84 of the Immigration and Asylum Act 1999); (ii) individuals may well have language](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y0C4-00000-00&context=1519360)
difficulties; and (iii) the law is complex and rapidly evolving (see, for example, Sapkota v Secretary of State for the
_Home Dept [2011] EWCA Civ 1320, [2012] Imm AR 254, at [127] per Jackson LJ)._
**[*887]**

**[73] We can now turn to the relevant parts of the Guidance. We have set out paras 26–28 at [21], above. It is to be**
inferred that these paragraphs are not intended to apply to immigration cases. That must follow from the fact that
paras 59 and 60 expressly deal with immigration and state that legal aid is not required in immigration proceedings.
The effect of paras 59 and 60, therefore, is that legal aid is not available in any immigration cases, regardless of the
circumstances. For the reasons that we have given, this is not correct.

**[74] It is nevertheless worth making two points about paras 26–28. First, we do not accept that it would normally**
only be in circumstances 'closely analogous' to Airey and P v UK that failure to provide legal aid would amount to a
breach of art 8. There is no support for this statement in the Strasbourg jurisprudence which has repeatedly applied
the test stated in W v UK. There is no basis in the case law for applying this test in a manner which is materially
different from the manner in which art 6(1) would be applied if a determination of civil rights and obligations were
involved. The W v UK test requires a consideration of all the circumstances of the case. Secondly, we agree with
the statement in para 28 that 'it is likely that cases in which an applicant seeks to rely on Article 8 would therefore


-----

Cross Society intervening) [2015] 3 All ER 827

fall more naturally to be considered under the Article 6(1) heading'. For the reasons we have given above, we
consider that this fairly reflects the approach of the ECtHR.

**[75]** Paragraph 59 is plainly correct: immigration decisions do not involve the determination of civil rights and
obligations. But para 60 is wrong as Mr Chamberlain has conceded. For the reasons that we have given, the W v
_UK test should be applied in immigration proceedings._

**[76] What guidance is it appropriate to give as to the circumstances in which art 8 requires the provision of legal aid**
in immigration cases? We have already set out at [72], above some of the relevant circumstances. In addressing
these, it will often be helpful to take into account the factors set out at paras 19–24 of the Guidance in relation to art
6(1). In carrying out this exercise in relation to art 8, the decision-maker should not apply a 'very high threshold' for
the reasons that we have given in rejecting such a threshold in relation to art 6(1).

**[77] Deportation cases are of particular concern. It will often be the case that a decision to deport will engage an**
individual's art 8 rights. Where this occurs, the individual will usually be able to say that the issues at stake for him
are of great importance. This should not be regarded as a trump card which usually leads to the need for legal aid.
It is no more than one of the relevant factors to be taken into account. The fact that this factor will almost invariably
be present in deportation cases is not, however, a justification for giving it reduced weight.
_The case of IS_

**[78] As we have said, it is now conceded that the judge was right to allow the application for judicial review of the**
refusal to grant ECF in the case of IS. IS is a Nigerian national who has lived in the United Kingdom for at least 13
years. He is blind, has profound cognitive impairment and is unable to care for himself. He lacks litigation capacity
and is represented through the Official Solicitor. Legal aid was sought to enable him to apply to the Home Office to
regularise his immigration status and thereby qualify for mainstream community care and health services. The
application was refused by the Director on the grounds that art 8 was not engaged.

**[79] Collins J quashed the decision to refuse legal aid on the grounds that (i) the Guidance on art 8 was wrong; and**
(ii) the Director had wrongly found that art 8 was not engaged. The judge said (at [73]): 'I can only say that I believe
**[*888]**

that legal aid should be granted to this extremely vulnerable person since without it he will not be able to achieve an
effective exercise of his art 8 rights.' He did not, however, find that a refusal would necessarily breach art 8 and
remitted the matter to the Director for reconsideration. On 18 August 2014, the Director formally determined that IS
qualified for legal aid to regularise his immigration status.

**[80] The case of IS is extreme. It is impossible to see how a man suffering from his disabilities could have had any**
meaningful involvement in the decision-making process without the benefit of legal representation.
**GROUND 4: THE CASE OF MS GUDANAVICIENE**

**[81] The factual background to the case of Teresa Gudanaviciene (referred to by Collins J as TG) is set out in paras**

[54]–[56] of Collins J's judgment:

'[54] I shall refer to this claimant as TG. She is a national of Lithuania who came to this country in 2010 to work
here. She was in a relationship with a partner who had a drink problem and was abusive and violent towards
[her. In September 2012 she was convicted of an offence of wounding her partner with intent contrary to s 18 of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9240-TWPY-Y0D9-00000-00&context=1519360)
the Offences against the Person Act 1861. She had stabbed her partner with a kitchen knife and it was
obviously fortunate that she had not killed him. However, it is apparent from the judge's sentencing remarks
that the jury had, it would seem in a rider to its decision, said that she had been under pressure and had been
provoked by her partner's conduct. The judge said that having regard to this and her family responsibilities he
would pass a sentence which was “about six to twelve months lighter” than he had originally envisaged. He
imposed a sentence of 18 months' imprisonment.


-----

Cross Society intervening) [2015] 3 All ER 827

[55] The Secretary of State for the Home Department decided that the claimant should be deported. Regulation
19(3) of the Immigration (European Economic Area) Regulations 2006, _[SI 2006/1003 enables removal to be](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW6-XH50-TX08-H0KD-00000-00&context=1519360)_
carried out if the Secretary of State has decided that it is justified “on grounds of public policy, public security or
public health in accordance with regulation 21”. Regulation 21(5) provides that any such decision must comply
with the principle of proportionality and must be based exclusively on the person's personal conduct.
Regulation 21(5)(c) provides:

“the personal conduct of the person concerned must represent a genuine, present and sufficiently serious
threat affecting one of the fundamental interests of society.”

And reg 21(5)(e) states that a person's previous criminal convictions do not in themselves justify the decision.

[56] The claimant has a two-year old daughter of whom her former partner is the father. The decision to deport
recognised the need to safeguard the child's welfare in accordance with s 55 of the 2009 Act. Her daughter is
in foster care. The only report is in the form of a statement from a senior social worker whose report was made
at a time when the claimant was still in prison: she has since been granted bail. The view expressed was that
her father had problems in relating to his daughter and children's services had concerns for her safety and
development should she be placed with her father. While there had been no opportunity to make a

**[*889]**

full assessment of the claimant's capability as a carer of her daughter, such contact sessions as had been
possible showed that the claimant appeared to be the most obvious choice of sole carer.'

**[82]** The deportation decision referred to in para [55] of Collins J's judgment was made on 10 December 2012.
Paragraph 30 of the decision letter said:

'It is considered that the combination of your criminal conduct in terms of the risk of serious harm to the public
and your propensity to reoffend make it reasonable to strike a fair balance between the best interests of your
daughter and the weight attached to the necessary action of deportation. It is considered that this can be
achieved by expecting you to return to Lithuania and maintain relationship with your child and partner by
modern means of communication.'

**[83]** TG is an EU citizen. She appealed under the Immigration (European Economic Area) Regulations 2006, _[SI](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW6-XH50-TX08-H0KD-00000-00&context=1519360)_
_[2006/1003 ('the EEA Regulations') to the First-tier Tribunal. It is common ground that her case falls within art 47 of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW6-XH50-TX08-H0KD-00000-00&context=1519360)_
the Charter. She applied for ECF on 22 May 2013. Her application was refused on 12 July and the refusal was
confirmed, following a review, on 26 July 2013.

**[84] Collins J considered that the flaws in the Secretary of State's decision were 'all too obvious':**

'[58] … There is no evidence that the claimant has a propensity to reoffend. She has been living in a safe
house for victims of domestic violence and completed courses designed to assist such victims. Further life with
her former partner is not likely. The suggestion that she can maintain a relationship with her daughter from
Lithuania is hardly in the daughter's best interests. It must be apparent that she has a very strong case so far
as merits of the appeal are concerned.'

**[85] In para [59] Collins J said that TG 'has very poor command of English and, as must be obvious, she will be**
emotionally involved in the appeal so that she cannot approach it in an objective fashion'.

**[86] Against this background, Collins J said that the reasons given by the Director in the review decision letter for**
refusing ECF were 'thoroughly unsatisfactory':

'[60] … It is said that the issues are not complex and the tribunal “will take account of the relevant case law and
legislation, including EU law and the facts of the case”. But the test under reg 21(5)(c) is key and it will be
necessary to produce evidence to deal with the risk of harm. That does not now exist to any meaningful extent


-----

Cross Society intervening) [2015] 3 All ER 827

and it is difficult to follow how without assistance the claimant can be expected to obtain the necessary
evidence, let alone make representations on the issue. Furthermore, there is no evidence as to whether the
daughter will be able to be cared for if she were to go to Lithuania with her mother and what provision will be
made for her daughter's future here. All this additional evidence cannot be obtained by the tribunal, particularly
as the proceedings are adversarial. The suggestions in the refusal letter that “any further evidence in respect of
your client's family or criminal case is accessible by your client and can be submitted to the First Tier Tribunal
for their consideration” and “Your client can with the assistance of an interpreter, further address any question
of the First Tier Tribunal and provide further factual information

**[*890]**

towards the proportionality of the decision to deport” are little short of absurd. It reflects the flawed guidance on
the high level of the threshold and the exclusion of art 8.'

**[87] Collins J concluded that the Director should be directed to grant legal aid to TG:**

'[62] The decision in TG's case shows how the very high threshold applied by the Guidance can produce a
perverse decision. Even on that high threshold, the decision was in my judgment unreasonable in Wednesbury
terms (see _Associated Provincial Picture Houses Ltd v Wednesbury Corp_ _[[1947] 2 All ER 680, [1948] 1 KB](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-60M0-00000-00&context=1519360)_
223) but, on the correct approach, it is indefensible. It is accepted that if as a matter of law I were to take the
view that an adverse decision could not be made I should direct the Director to grant legal aid (subject to the
means test being satisfied, as I think it is) since the merits test is clearly met. Unless proper evidence is
obtained on risk of harm and in relation to the future care of the claimant's daughter, she will not obtain a just
result and on the evidential matters the tribunal cannot help her. Furthermore, competent solicitors may be able
to persuade the Home Office that the decision should be withdrawn so that costs are saved to an even greater
extent.'

**[88] Mr Chamberlain submitted that Collins J gave undue prominence to the question of TG's ability to approach**
her appeal objectively, which is but one factor in the assessment under art 6(1) of the Convention (and likewise
under art 47 of the Charter), and was unduly and unfairly pejorative as to the extent to which the First-tier Tribunal,
with the help of an interpreter, would be able to hear her appeal fairly on the material before it. The key question in
TG's appeal was whether her personal conduct represented 'a genuine, present and sufficiently serious threat
affecting one of the fundamental interests of society' (see reg 21(5)(c) of the EEA Regulations). This was a question
of fact which the tribunal would readily be able to determine given that all of the relevant facts were patent from the
material already before the tribunal, viz: TG had only one criminal conviction, and that one conviction was for
criminal conduct which was not at the most severe end of the scale, and which was directed against one person,
her former partner, in the context of a tumultuous and violent relationship which had now ended.

**[89] Mr Drabble QC supported the judge's reasoning and submitted that TG required legal aid in order to enable her**
to properly present her case to the tribunal. Collins J had accepted that TG had a very poor command of English.
This meant that she would not be able to read the appeal materials, let alone understand and be able to construct
cogent submissions on the key issues in the appeal. The Home Office appeal bundle was produced only in English.
While the tribunal would provide an interpreter, it would not provide translation services. TG would not be able to
produce a written statement of her evidence in accordance with the tribunal's practice let alone obtain, marshal and
evaluate relevant evidence to the appeal. She would not be able to produce a skeleton argument, outlining her
arguments on the law and the facts. She would not be able to read or understand the leading authorities applicable
to the deportation of EU citizens, and her difficulties would be compounded by the fact that one of the key issues in
the appeal would be the implications for the best interests of her daughter if she were removed. Her emotional
involvement in these issues meant that TG would not be able to objectively consider relevant matters.
**[*891]**

**[90]** In our judgment, without legal aid TG would not be able to present her case effectively and without obvious
unfairness. It is not in dispute that TG's appeal to the tribunal is of vital importance to her and her daughter. There is
some force in Mr Chamberlain's submission that TG's case is a straightforward one. Collins J concluded that the


-----

Cross Society intervening) [2015] 3 All ER 827

flaws in the Secretary of State's decision are 'all too obvious'. Mr Chamberlain's submission that the key question in
TG's appeal was whether her personal conduct represented 'a genuine, present and sufficiently serious threat
affecting one of the fundamental interests of society' is correct, as is his submission that this is a question of fact. It
is also true that this is the kind of factual question which the tribunal would readily be able to determine if all of the
relevant evidence was placed before it. Mr Chamberlain's submission overlooks the fact that in order to ensure that
all of the relevant evidence is placed before the tribunal TG will have to be able to identify this key question; and to
produce evidence, and make submissions as to present risk. TG could not safely assume that the Secretary of
State's contentions in the deportation decision that there was a 'risk of serious harm to the public and … [a]
propensity to reoffend' would be rejected, and her appeal would succeed simply upon the basis of the facts which
were patent from the material already before the tribunal.

**[91] There is another key question on which it is essential that evidence is obtained: is TG capable of caring for her**
daughter, and if so, what would be in the best interests of her daughter? We do not accept Mr Chamberlain's
submission that Collins J gave undue prominence to the question of TG's ability to approach her appeal objectively,
and was unduly and unfairly pejorative as to the extent to which the tribunal, with the help of an interpreter, would
be able to hear the appeal fairly on the material before it. There can be little doubt that if the only evidence as to
TG's ability to care for her daughter, and as to what would be in her daughter's best interests was given by TG
herself, that evidence would be criticised before the tribunal by the Secretary of State's representative as lacking in
objectivity. The fact that there would be an interpreter at the hearing of the appeal would not overcome the
difficulties that TG, with her very poor command of English, would face in preparing her case, in identifying the key
issues (above) and obtaining the evidence in relation to those issues, prior to the hearing. The process before the
tribunal is an adversarial one. While the tribunal is able to, and does, assist those appellants who are
unrepresented, it is able to do so only upon the basis of the evidence that is placed before it. It is plain that, without
legal advice, TG would not begin to know how to prepare her appeal, and in the absence of such preparation would
be unable to present it effectively.
**Ground 6: the case of LS**

**[92]** LS's case falls to be considered within the framework of international legal instruments directed towards the
prevention and combatting of trafficking in humans and the protection and promotion of the rights of victims of
trafficking ('VOTs'). The instruments of particular relevance are the Council of Europe Convention on Action against
Trafficking in Human Beings (2005) (CETS no 197) ('the Trafficking Convention') and European Parliament and
_[Council Directive 2011/36/EU (on preventing and combating trafficking in human beings and protecting its victims)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_
(OJ 2011 L101 p 1) ('the Trafficking Directive').

**[93] Article 10(2) of the Trafficking Convention requires member states to adopt such legislative or other measures**
as may be necessary to identify VOTs,
**[*892]**

and in particular to 'ensure that, if the competent authorities have reasonable grounds to believe that a person has
been victim of trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence … has been completed by the competent authorities'. It also imposes a
requirement, to which we will return, in respect of the provision of assistance to such a person.

**[94]** In fulfilment of its international obligations, the United Kingdom has established the National Referral
Mechanism ('NRM') as the means of identifying whether an individual is a VOT. The NRM process involves the
following stages:

(i) An organisation designated as a 'first responder', having identified a potential VOT, completes a detailed referral
form containing the individual's personal details, a series of tick boxes setting out 'indicators' (general indicators,
indicators of forced labour, indicators of domestic servitude, indicators of sexual exploitation), and a section for
evidence to support the reasons for referral. The completed form must be signed by the individual to confirm his or
her consent to the referral (if the person is an adult). Bodies authorised to act as first responders include local


-----

Cross Society intervening) [2015] 3 All ER 827

authorities, police forces and a number of charitable organisations such as the Salvation Army, Migrant Help,
Kalayaan, Barnardos and the NSPCC.

(ii) The completed referral form is transmitted to a 'competent authority'. There are two competent authorities,
namely the UK Human Trafficking Centre ('UKHTC') and UK Visas and Immigration ('UKVI'), formerly the UK
Border Agency. Referral forms are sent in the first instance to UKHTC, which either deals with the matter itself or
forwards the papers to be dealt with by UKVI. It appears that UKVI deals with cases where there are immigration
issues involving individuals from outside the European Economic Area.

(iii) The relevant competent authority decides whether there are 'reasonable grounds' to believe that the individual is
a VOT. The threshold applied by the case worker is whether from the information available so far he or she
suspects (but cannot prove) that the individual is a potential VOT. There is a target of five days for a decision on
that question. If the decision is affirmative, the individual is allocated a place within safe accommodation, if required,
and is granted a recovery and reflection period of 45 days. As described below, an affirmative decision also
engages a right to legal aid in relation to the making of applications for leave to enter or remain in the United
Kingdom.

(iv) An affirmative reasonable grounds decision is followed by a period of further information gathering. The
competent authority then reaches a 'conclusive determination' as to whether the individual is or is not a VOT. The
target is to reach such a decision within the 45-day recovery and reflection period.

**[95] A fuller account of the international legal framework and of the system operating in the United Kingdom is to be**
found in the judgment of the Divisional Court in _R (on the application of Atamewan) v Secretary of State for the_
_Home Dept [2013] EWHC 2727 (Admin), [2014] 1 WLR 1959; see also the judgment of Lord Hughes in Hounga v_
_[Allen [2014] UKSC 47, [2014] 4 All ER 595, [2014] 1 WLR 2889(at [60]–[66]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DMS-8XS1-DYBP-M3G0-00000-00&context=1519360)_
**[*893]**

**[96] The effect of s 9(1) of LASPO is that legal advice and assistance in relation to VOTs or those claiming to be**
VOTs is within scope for legal aid in the circumstances set out in para 32 of Pt 1 of Sch 1. Paragraph 32 reads in
material part:

'Victims of trafficking in human beings

(1) Civil legal services provided to an individual in relation to an application by the individual for leave to enter,
or to remain in, the United Kingdom where—

(a) there has been a conclusive determination that the individual is a victim of trafficking in human beings, or

(b) there are reasonable grounds to believe that the individual is such a victim and there has not been a
conclusive determination that the individual is not such a victim.'

Paragraph 32(6)–(8) makes clear that the references to 'reasonable grounds to believe' and to a 'conclusive
determination' are to the corresponding decisions made by a competent authority under the NRM process
described above.

**[97] Paragraph 32 does not provide for the grant of legal aid for advice and assistance to a person claiming to be a**
VOT prior to an affirmative reasonable grounds decision. That stage remains out of scope. The only way in which
legal aid may be made available for it is by the grant of ECF.

**[98] That brings us to LS's application for ECF, the background to which is summarised as follows in paras [74]–**

[76] of Collins J's judgment:

'[74] The claimant, a Nigerian citizen, was violently assaulted in a family dispute following his father's death. He
was badly injured and his brother was killed. The assailants were given short prison sentences and the
claimant was anxious to leave Nigeria before their release fearing further violence His uncle arranged with an


-----

Cross Society intervening) [2015] 3 All ER 827

agent for him to travel to the UK on a false passport. He arrived here in January 2004 and was introduced by
the agent to a restaurant owner, Comfort Afolabi. She used his fear of the authorities and threats to inform that
he was here unlawfully and so would be returned to Nigeria to compel him to work for her in appalling
circumstances. He was paid very little—certainly insufficient to provide for a living wage—and slept on a
mattress in the cooler room of the restaurant. He met a lady who is now his partner and by whom he has had
three children. His partner and the children have been given indefinite leave to remain and the third child is
considered to be a British citizen.

[75] In the circumstances, he contended that he was a VOT. The circumstances in which he was required to
work for Ms Afolabi amount to slave labour. Encouraged by his partner, he escaped from the restaurant in
January 2009 and went to live with his partner. Ms Afolabi apparently died in the summer of 2009. His fear of
being deported if he approached the authorities led him to delay taking any action until April 2013 when he
approached the Anti-Trafficking and Labour Exploitation Unit (“ATLEU”), which operates in North London.
ATLEU was acting for his partner in relation to support for her children and her immigration position. She too
was a VOT.

[76] An application for ECF was made by ATLEU on his behalf on 17 June 2013. This was said to be for the
purposes of preparing an application under art 8 of the ECHR and making a referral to the competent authority
to enable a positive decision in relation to his claim to

**[*894]**

be a VOT. It was said that a failure to grant ECF would breach or create a risk of breach of his art 4 and 8
rights and violate his EU law rights as a VOT. The application followed a request from the Public Law Project
(to which ATLEU had referred his case) for a preliminary view on ECF. There was a negative response. A
review was carried out and the answer remained negative. The reasons were given in a letter of 28 June 2013.'

**[99] The application for ECF and the reasons for refusal are considered in greater detail below. The Anti-Trafficking**
and Labour Exploitation Unit ('ATLEU') had in fact provided legal services to LS prior to the application and it
continued to do so following the refusal. It provided such services at risk, on the basis that it could recover payment
(backdated as appropriate) if but only if ECF were eventually granted.

**[100] A request for a referral was made first to Islington London Borough Council, the local housing authority. It was**
met with a response from a housing officer that it was not her job to make a referral and she had never heard of
such a thing. That prompted a pre-action protocol letter to the council, threatening judicial review of the refusal to
refer. The problem was resolved, however, by ATLEU making contact with the Salvation Army which agreed to
make the referral. The referral led to an affirmative 'reasonable grounds' decision, engaging a right to legal aid
pursuant to para 32(1)(b) of Pt 1 of Sch 1 to LASPO. That was followed, however, by a conclusive determination
that LS was not a VOT, at which point the right to legal aid pursuant to para 32(1)(b) came to an end. It took the
competent authority much longer to reach the reasonable grounds decision and the conclusive determination than
the respective targets of five and 45 days.

**[101] The challenge to the refusal of ECF takes one back to the start of the process we have just described. The**
two relevant grounds of challenge advanced before Collins J were (i) that art 12(2) of the Trafficking Directive
conferred a right to legal aid for advice and assistance in relation to an NRM referral at the early stage left out of
scope by LASPO, and (ii) that the grant of legal aid at that stage was necessary to avoid a breach of LS's rights
under art 8 of the ECHR. The judge found against LS on the construction of art 12(2) of the Trafficking Directive. It
is contended by way of a respondent's notice that he was wrong to do so. As to art 8, the judge found that the
refusal of ECF was based on the Guidance which put the threshold far too high. He could not say, however,
whether a decision to refuse based on the correct approach to art 8 would necessarily be wrong. He therefore
quashed the decision and directed its reconsideration. The appellants contend that art 8 did not require the grant of
legal aid and that the judge was wrong to quash the decision.
_Does art 12(2) of the Trafficking Directive confer a right to legal aid at the stage left out of scope by LASPO?_


-----

Cross Society intervening) [2015] 3 All ER 827

**[102] The case advanced by Mr Bowen QC on behalf of LS is that art 12(2) of the Trafficking Directive confers an**
entitlement to legal aid for advice and assistance in relation to an NRM referral. That provision reads:

**'Article 12**

**_Protection of victims of trafficking in human beings in criminal investigation and proceedings …_**

2. Member States shall ensure that victims of trafficking in human beings have access without delay to legal
counselling, and, in accordance

**[*895]**

with the role of victims in the relevant justice system, to legal representation, including for the purpose of
claiming compensation. Legal counselling and legal representation shall be free of charge where the victim
does not have sufficient financial resources.'

**[103] In our judgment, the provision does not confer the right for which Mr Bowen contends. First, as is made clear**
by the heading to the article and by the content of the directly related recital (19), art 12 is concerned essentially
with criminal investigations and proceedings. Whilst in that context it extends to claims to compensation (and the
recital indicates that it also covers claims for compensation against the state), it is not a provision of general
applicability. It has no application to the present case, which does not involve criminal investigations or criminal
proceedings or (at least as regards the application for ECF) a claim to compensation. The process of referral to a
competent authority to establish status as a VOT is an altogether different context.

**[104] Secondly, art 11 of the Trafficking Directive spells out when assistance and support must be provided to a**
person claiming to be a VOT:

**'Article 11**

**_Assistance and support for victims of trafficking in human beings_**

1. … [criminal proceedings]

2. Member States shall take the necessary measures to ensure that a person is provided with assistance and
support as soon as the competent authorities have a reasonable-grounds indication for believing that the
person might have been subjected to any of the offences referred to in Articles 2 and 3 …

5. The assistance and support measures referred to in paragraphs 1 and 2 shall be provided on a consensual
and informed basis, and shall include at least standards of living capable of ensuring victims' subsistence
through measures such as the provision of appropriate and safe accommodation and material assistance, as
well as necessary medical treatment including psychological assistance, counselling and information, and
translation and interpretation services where appropriate.'

Thus, by the express wording of art 11, confirmed by the content of the directly related recital (18), the requirement
is to provide assistance and support measures once a reasonable grounds decision has been made. Had the
intention been to require such measures prior to a reasonable grounds decision, art 11 would have so provided.

**[105] Thirdly, that interpretation of the Directive accords with the provisions of the Trafficking Convention, to which**
the Directive is intended in part to give effect. Chapter III of the Trafficking Convention is headed: 'Measures to
protect and promote the rights of victims, guaranteeing gender equality.' It includes the following provisions:

'Article 10—Identification of the victims …

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure that,


-----

Cross Society intervening) [2015] 3 All ER 827

if the competent authorities have reasonable grounds to believe that a person has been victim of trafficking in
human beings, that person shall not be removed from its territory until the identification process as victim of an

**[*896]**

offence provided for in Article 18 of this Convention has been completed by the competent authorities and shall
likewise ensure that that person receives the assistance provided for in Article 12, paragraphs 1 and 2 …

_Article 12—Assistance to victims_

1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least …

d. counselling and information, in particular as regards their legal rights and the services available to them, in a
language that they can understand;

e. assistance to enable their rights to be presented and considered at appropriate stages of criminal
proceedings against offenders …

2. Each Party shall take due account of the victim's safety and protection needs …'

Thus, the primary obligation to ensure the provision of relevant counselling and assistance applies by art 12(1) to
'victims': this plainly refers to persons whose VOT status has been established ('victim' is defined by art 4(e) as 'any
natural person who is subject to trafficking in human beings as defined in this article'). The obligation is extended by
art 10(2) so as to cover persons in respect of whom the competent authorities have reasonable grounds to believe
that they are victims. It is not, however, extended to any earlier stage of the process.

**[106] Fourthly, in recognition of the difficulty of a submission that anyone claiming to be a VOT should be entitled to**
legal aid for advice and assistance at an earlier stage of the process, Mr Bowen submitted that such a right exists
where there is a 'credible suspicion' or 'credible information' that the person concerned is a VOT. That, however,
introduces a test which is not to be found either in the Trafficking Directive or in the Trafficking Convention and
which it would be difficult to apply in practice. By contrast, a reasonable grounds decision by a competent authority
provides a clear-cut basis for engaging the duty to provide advice and assistance in accordance with both
instruments.

**[107] Mr Bowen's skeleton argument renewed at some length an argument which had been rejected by Collins J,**
that a right to legal aid arises as a component of the state's duty to investigate credible claims of human trafficking
pursuant to art 4 of the ECHR (the prohibition of slavery and forced labour) and art 5 of the Charter (the equivalent
prohibition, including in art 5(3) an express prohibition of trafficking in human beings). In his oral submissions,
however, Mr Bowen indicated that he was now relying on those provisions as part of the context for the
interpretation of art 12(2) of the Trafficking Directive, not as engaging a separate entitlement to legal aid. We have
taken them into account accordingly but we do not consider them to give any material support to the interpretation
for which Mr Bowen contends.

**[108] Mr Bowen's skeleton argument also contained an argument that, if a right to legal aid at the referral stage is**
not conferred directly by art 12(2) of the Trafficking Directive, the right may arise under art 47(3) of the Charter and
art 41 of the Charter. In his oral submissions he indicated that he was not dropping the argument but he did not
want to press it. In our judgment, the argument takes LS nowhere. The provisions of the Charter in question cannot
give rise to some form of implied right under the Directive. If art 47(3) is considered as an independent source of
rights, it is difficult to see how LS, as a Nigerian national who came to the United Kingdom from Nigeria, could rely
**[*897]**

on it; but even if he could, it would add nothing material to the position under art 8 of the ECHR, upon which we can
therefore concentrate. Article 41 is of no assistance, since it is addressed to EU institutions and cannot be relied on


-----

Cross Society intervening) [2015] 3 All ER 827

against national authorities (see _YS v Minister voor Immigratie, Integratie en Asiel; Minister voor Immigratie,_
_Integratie en Asiel v M (Joined cases C-141/12 and C-372/12) [2015] 1 WLR 609)._

**[109] Mr Bowen submitted that the interpretation of the Trafficking Directive for which he contended was acte clair**
in his favour, but he requested a reference for a preliminary ruling under art 267 TFEU if and to the extent that we
considered the matter not to be acte clair. In our judgment, his interpretation of art 12(2) of the Trafficking Directive
is clearly wrong and there is no other material issue of interpretation on which a decision is needed. In those
circumstances the question of an art 267 reference does not arise.
_The application of art 8 to LS's case_

**[110] We turn to the application of art 8 of the ECHR, which was the basis on which Collins J decided the case in**
LS's favour.

**[111] For that purpose it is necessary to say a little more about the application for, and refusal of, ECF. A detailed**
request for a preliminary view was submitted in May 2013 by the Public Law Project on behalf of LS. It stated that
he required exceptional funding for legal advice on preparing an application under art 8 and in approaching social
services to make a referral through the NRM for a reasonable grounds decision on whether he was a VOT. If he
made an art 3 or asylum claim he was likely to be detained and fast tracked. It was in his best interests to approach
the authorities for a decision on whether he was a VOT before making such a claim. On balance it would be best to
apply for ECF so that a number of steps could be taken, including: (a) an approach to social services to make a
referral under the NRM; (b) obtaining evidence in support of the art 8 claim; (c) seeking evidence to support a
possible art 3 claim; and (d) an application, supported by evidence, under art 3 and/or for asylum, and under art 4
and art 8. ECF would be required for (a) and (b), but (c) and (d) would be in scope for legal aid if an affirmative
reasonable grounds decision was taken in time.

**[112] The request advanced arguments as to entitlement to legal aid under the Trafficking Directive. It also pointed**
out that victims of trafficking are likely to be vulnerable and may require support and encouragement to overcome
their fear of approaching the authorities. It argued that the identification of historic victims of trafficking was a
complex matter and that it was necessary for LS to have legal advice and assistance in preparing his NRM referral.

**[113] The arguments under art 8 focused on family life and in particular on the risk of LS being permanently**
separated from his partner and their two children (with a third due), all of whom had recently been granted indefinite
leave to remain. It was said that the 'status' of LS and his partner as VOTs (though that, of course, in relation to LS,
had not been established) raised complex issues for the purposes of art 8 and the maintenance of immigration
control, that there were complex issues surrounding the children's best interests and his partner's support needs,
that expert advice was needed to ensure that LS's application took account of the content of, and evidence in
support of, the applications of his partner and the children, and that there might be relevant social services records
to be retrieved and analysed. LS was said to be a destitute VOT unlawfully present in the United Kingdom; the point
**[*898]**

was again made that VOTs are vulnerable; and it was also stated that they may suffer from mental health concerns
which should be explored by professionals.

**[114] The request for a preliminary view resulted in a negative decision. This was followed by a formal application**
by ATLEU in the same terms as the request for a preliminary view, and by an application by the Public Law Project
for an internal review of the decision on the preliminary view. The applications were dealt with by way of a review
decision dated 28 June 2013 maintaining the refusal. The decision letter was signed by the head of the exceptional
cases team, himself a qualified lawyer. Under the heading of merits criteria, he considered that LS, having been
advised by ATLEU on the best way forward, would now have the requisite knowledge to approach social services to
make an NRM referral. Under the heading of exceptional criteria, he gave the following reasons in relation to art 8:

'I have had regard to the applicant's family situation. I note that he has two minor children, aged 2 and 4, and a
third due. I note that his ex-partner and the children have been granted [indefinite leave to remain]. However, I
note that the applicant is first proposing to approach the authorities for a decision on whether he is a victim of


-----

Cross Society intervening) [2015] 3 All ER 827

trafficking before making an asylum claim. I note that there are no asylum proceedings underway at this stage
and there is currently no deportation decision, which would affect the applicant's Article 8 rights. At this point in
time, Article 8 is therefore not engaged.

In any event, even if Article 8 were engaged, I do not consider that this would give the applicant a right to legal
aid funding. I refer you to paragraph 60 of the Lord Chancellor's Guidance …'

**[115] Collins J found that LS's art 8 rights were very much in issue at the stage for which ECF was sought and that**
the decision was flawed by reliance on the Guidance. But the arguments before the judge ranged much wider than
the particular errors in the decision, covering a variety of points foreshadowed in the application for ECF. They led
him to observe, when quashing the decision and directing its reconsideration, that 'there are powerful arguments
based on the vulnerability of the claimant which show that legal aid was not only desirable but necessary to enable

[LS's] overall rights, which could not be divorced from the VOT application, to be made effective' (para [88]). On
behalf of the appellants, Mr Chamberlain takes issue with those arguments and submits that the judge should have
concluded that art 8 did not require the grant of ECF and should therefore have declined to quash the decision.

**[116] One issue arises out of the accepted fact that many VOTs are vulnerable and may be reluctant to come**
forward to identify themselves as such without some encouragement. Mr Chamberlain deals with that by pointing to
the existence of a wide range of charities with considerable expertise in dealing with approaches from vulnerable
people, including a number of charities which are themselves first responders. Mr Bowen submits, however, that
such encouragement needs to come from a legal adviser with whom the individual is able to build up a relationship
of trust, and that the solicitor within ATLEU who dealt with LS was able to provide him with the reassurance he
needed only because she had the expertise to give him relevant legal advice. Such advice can lawfully be given
only by a qualified solicitor or barrister or by a person accredited to Level 2 of the competency
**[*899]**

levels established by the Office of the Immigration Services Commissioner ('the OISC'); yet none of the first
responders is registered with OISC to the necessary level.

**[117] A related question is whether expert legal advice is needed at an early stage so that a person claiming to be a**
VOT can make an informed decision as to whether to seek an NRM referral at all. By such a referral (for which a
signed consent is required, if an adult) the individual makes himself or herself known to the competent authority and
may be at risk of detention and removal if at the end of the process he or she is not found to be a VOT. For
someone in LS's position the relevant competent authority would be UKVI, which would also be responsible for
taking any immigration decision; and there is some evidence (which does not appear to be contentious and to which
we therefore think it permissible to refer although it is drawn from a Select Committee report) that UKVI makes
affirmative conclusive determinations of VOT status in a far lower percentage of cases than does UKHTC. Mr
Bowen submits that all this underlines the importance of receiving advice about available options before agreeing to
a referral. Matters that such advice would need to address include the NRM process itself, the evidence required to
establish VOT status, the rights that would follow from establishing VOT status, any additional or alternative bases
on which leave to remain might be sought (such as asylum and arts 3, 4 and 8 of the ECHR), and the overall
likelihood of detention and removal, including timescales. It is submitted that these issues engage complex
questions of law and policy guidance and that balancing the risks and the potential benefits involves a complex
calculus requiring expert advice.

**[118] Those submissions can be illustrated by the evidence of Miss Kate Roberts of Kalayaan, one of the first**
responders. She states that the present regime leaves Kalayaan in an invidious position. It is authorised to identify
potential VOTs and to make an NRM referral yet it is not able to give potential VOTs with irregular immigration
status advice on issues of the kind referred to above. She continues:

'24. As a result we are increasingly finding that it is not possible for our clients to access any immigration
advice prior to a referral into the NRM. In our experience clients who have breached the immigration rules in


-----

Cross Society intervening) [2015] 3 All ER 827

escaping their alleged traffickers … are understandably reluctant to consent to a referral into the NRM before
they have some understanding of potential future immigration options.

25. As Kalayaan's OISC exemption does not cover advice at this level and legal aid is denied until a
Reasonable Grounds decision has been made many of those who we internally identify as trafficked do not
consent to a referral and lose contact with us, going underground, potentially to be further exploited. It is likely
that were these individuals able to access legal aid and the resulting advice prior to an NRM referral they would
be more likely to instruct a solicitor, consent to a referral and thus remain (to some extent) visible and
supported. There remains a large discrepancy between numbers of clients who Kalayaan staff internally
identify as trafficked (86 new clients in 2013) and those referred into the NRM (21 referrals during 2013).'

**[119] Mr Chamberlain points out that the NRM process has been established to comply with the United Kingdom's**
obligation under the Trafficking Convention to identify VOTs. In his submission, the argument that people who ex
hypothesi are genuine VOTs require legal aid at an early stage so as to have
**[*900]**

expert advice on the risks they face if their VOT claims are rejected would risk undermining the very reason for
having an NRM process. Mr Bowen responds with the submission that a genuine VOT will be more likely to enter
the NRM process if given specialist legal advice and that it is the lack of such advice that is likely to cut across the
United Kingdom's obligations under the Trafficking Convention.

**[120] A further issue concerns the actual process of NRM referral. Mr Chamberlain submits that it is possible for a**
person in the position of LS to present himself to a first responder and seek a referral without legal advice. The
process is not overly complex or legalistic. The form requires completion of basic personal details, the ticking of
boxes identifying the presence of relevant indicators, and the provision of supporting evidence. Even if, as a matter
of practice, referrals are often accompanied by expert evidence and/or representations, there is no reason why a
first responder cannot make a referral in the absence of either, simply on the basis of the individual's own account
of his history and the first responder's observations from any interview conducted with the individual. LS himself has
been in the United Kingdom for about a decade and speaks English, so that it would have been possible for him to
provide the relevant information. The fact that ATLEU encountered difficulty in getting the local authority to make a
referral on LS's behalf, with a consequent delay in the referral process, does not support the proposition that the
process is inherently complex and requires legal assistance, nor does the fact that in his case there were
subsequent delays in reaching a reasonable grounds decision. The reasonable grounds decision itself is an initial
assessment on the basis of the form and any readily available evidence. The threshold is a low one and legal aid is
available thereafter if the threshold is crossed.

**[121] Mr Bowen, on the other hand, submits that the requirement for legal advice and assistance extends to the**
referral process itself, both for the purpose of identifying a first responder willing and able to make the referral (a
point illustrated by the local authority's denial of responsibility) and in order to ensure that a properly reasoned and
evidenced case in support of VOT status is put forward to the competent authority. He also submits that the need
for such advice and assistance does not diminish after the referral, all the more so if, as happened in LS's case,
there is going to be a long delay before a reasonable grounds decision is taken.

**[122] In summary, Mr Bowen submits in respect of the specific case that given what was at stake for LS and his**
children, the complexity of the law and policy guidance and his inability to navigate the process without advice and
assistance, he was precluded from effective participation in the decision-making process without specialist advice
and assistance from an experienced legal adviser, which was available to him only by the route of ECF. Refusal of
ECF breached or ran a risk of breaching his art 8 rights. Mr Chamberlain, by contrast, submits that it was possible
for LS to access and participate in the NRM process without legal advice or assistance and that the refusal of ECF
was lawful.


-----

Cross Society intervening) [2015] 3 All ER 827

**[123] In our judgment, although the Director's decision in respect of LS was flawed by its reliance on the Guidance,**
his conclusion that failure to provide legal aid would not be a breach of LS's Convention rights was correct. Our
reasons, in summary, are as follows.

(i) The issue of VOT status and the related issues of family life under art 8 are plainly of great importance to LS. We
take the view, however, that an
**[*901]**

individual in his position does not require legal advice and assistance in order to be involved in the VOT decisionmaking process, seen as a whole, to a degree sufficient to provide him with the requisite protection of his interests
under art 8. The identification of a first responder willing and able to make a referral may not be free from difficulty
but there is nothing to show that the particular problem experienced in LS's case is a widespread one. The referral
form is designed to identify relevant issues and to prompt the provision of supporting evidence without the need for
legal advice or assistance: a first responder can reasonably be expected to be able to complete it through
questioning of the individual. Complex issues can no doubt arise but there was no particular complexity about this
case. The process up to and including the making of a reasonable grounds decision is relatively straightforward,
and an affirmative reasonable grounds decision engages a right to legal aid thereafter. Legal advice and assistance
in relation to the referral process may be very helpful and lead to a fuller submission but it cannot be said to be
necessary in circumstances such as those of LS.

(ii) A more difficult question (though this line of argument was not in fact the basis of LS's application for ECF) is
whether an individual needs legal advice at the pre-referral stage in order to encourage him to come forward and in
order to enable him to make an informed decision on whether to agree to a referral. There is force in the argument
that without legal advice some (perhaps many) potential VOTs will keep away from the NRM process when they
would otherwise have entered it. It would be surprising, however, if art 8 required legal aid to be made available in
the ordinary course to enable a person claiming to be a VOT to decide whether to enter the NRM process with a
view to making good the claim. It would be all the more surprising in circumstances where the relevant international
instruments make an affirmative reasonable grounds decision the trigger for the provision of legal aid. We do not
consider that there is any general requirement to provide legal aid at the prior stage or that the particular
circumstances of LS's case necessitated it.

**[124] We therefore take the view that Collins J was wrong to quash the decision and to direct reconsideration of the**
application for ECF. The appropriate course would have been to refuse relief as a matter of discretion. We allow the
appeal accordingly.
**GROUND 7: THE CASE OF MR REIS**

**[125] The factual background to the case of Cleon Reis is set out in paras [89]–[91] of Collins J's judgment:**

'[89] The claimant is a Portuguese national now 28 years old. He entered this country with his mother in
December 1998 when he was 12 years old and has lived here ever since. He has since about 2002 committed
a considerable number of criminal offences which have increased in seriousness. His first custodial sentence
appears to have been one of nine months and two weeks in a young offenders' institution in 2006 for various
offences committed, some while on bail, for driving vehicles taken without consent dangerously and while
disqualified. In 2007 he was again convicted of driving whilst disqualified and received a suspended prison
sentence. He breached this order and in June 2008 was sentenced to 20 months' imprisonment for burglary
and theft. He was then warned by the Home Office that deportation would not be pursued then, but that he
must note that it had been considered. He took no notice. In November 2009 he was

**[*902]**

convicted of aggravated vehicle taking, causing damage to a vehicle in excess of £5,000, and driving whilst
disqualified. For these offences, he was sentenced to 15 months' imprisonment. The damage to the vehicle
was caused when he attempted to escape from the police and was involved in a high speed chase. While the


-----

Cross Society intervening) [2015] 3 All ER 827

offences are not of the most serious and he did not commit any offence which directly involved violence to an
individual, nonetheless the offending was persistent and its seriousness increased.

[90] The Recorder who sentenced him in 2009 referred to his appalling record and concluded:

“It is clear that you … are easily influenced by friends and criminally minded peers and it is also clear that you
have shown a significant ability to act without any consideration towards others and other people's property to
the extent that you put other road users at significant personal risk.”

[91] On 29 July 2010 the Secretary of State for the Home Department notified the claimant that she had
decided to make a deportation order. It was asserted that he had not resided here, having regard to his
custodial sentences, for at least five years so that he was not entitled to the level of protection appropriate to
that. The First-tier Tribunal accepted that he had but nonetheless dismissed his appeal. His application for
leave to appeal to the Upper Tribunal was refused. He sought judicial review of that refusal raising a point
which had not been clearly made that he qualified for the highest level of protection by virtue of ten years'
residence. Leave was granted by Walker J, following refusal on the papers by me, in May 2012. On 13 May
2013 the Secretary of State for the Home Department agreed to reconsider the question of deportation and so
the judicial review was brought to an end. On 20 May 2013 she decided to make a deportation order.'

**[126] Mr Reis is an EU citizen. He appealed to the First-tier Tribunal under the EEA Regulations. It is common**
ground that his case falls within art 47 of the Charter. Collins J said that the key question in Mr Reis's appeal was
whether he was entitled to the protection afforded to EU citizens who have resided in the United Kingdom for a
continuous period of five years, or to the greater protection afforded to EU citizens who have resided in the United
Kingdom for at least ten years, and the answer to that question depended upon whether, and the extent to which,
Mr Reis's time spent in custody in the United Kingdom could properly be regarded as counting towards a
continuous period of residence (para [92]).

**[127] Having referred to a number of domestic authorities which considered this issue (para [93]), Collins J**
considered Mr Chamberlain's submission that the law was now clear following the decision of the CJEU in
_Secretary of State for the Home Dept v MG (Case C-400/12) [2014] 1 WLR 2441. Collins J set out paras 35 and 36_
of the judgment in MG and said (at [94]):

'It follows that to assess whether there has been ten years' continuous residence prior to the decision to deport
(in the case prior to May 2013) the First-tier Tribunal will have to consider all the circumstances to decide
whether enhanced protection has been established.'

**[128] In paras [95] and [96] he said:**
**[*903]**

'[95] … The guidance issued by the CJEU is not in my view as clear as Mr Chamberlain submits and there is a
difficult question to be determined on the facts of the claimant's case. Those and his attitudes must be carefully
assessed.

[96] There is an art 8 claim based on his fatherhood of a child. He has split up from his partner. There can be
no doubt that that claim is extremely weak and I do not think it is such as to justify legal aid.'

**[129] In para [97] he dealt with the Director's reasons for refusing ECF for the appeal to the First-tier Tribunal as**
follows:

'The reasons for refusing legal aid include the assertions that the claimant had had legal representation at his
previous hearings and it was “speculative to think that previous errors will be repeated”. In addition, it is said
that proceedings before the First-tier Tribunal “are not complex either in law or procedure”. That observation I
find remarkable and it suggests that the author has never had experience of observing appeals before the
First-tier Tribunal. The reality is, having regard both to the possibility of difficulties in dealing with contentious


-----

Cross Society intervening) [2015] 3 All ER 827

factual matters and, in immigration law which is taking up a substantial part of the Court of Appeal's caseload,
there can be considerable complexity.'

**[130] Collins J concluded in para [98] that in the case of Mr Reis—**

'[t]he refusal was based on an application of the Guidance which set too high a threshold. This will on any view
be a difficult appeal and I am entirely satisfied that without legal assistance there is a real prospect of the
claimant not receiving justice. It follows that I quash the refusal and I propose to direct in this case that legal aid
be granted for the hearing before the First-tier Tribunal.'

**[131] Following the decision of Collins J, Mr Reis was granted legal aid for his appeal against the Secretary of**
State's decision on 20 May 2013 to make a deportation order. His appeal was heard on 12 September 2014 and
the tribunal's determination allowing the appeal was promulgated on 1 October 2014.

**[132] Mr Chamberlain submitted that, looking at the circumstances as they existed at the hearing of the appeal from**
the decision of Collins J, the principal legal issue, whether or not it was ever complex, had been resolved by the
CJEU's decision in MG and the decision of the Upper Tribunal in MG when the hearing was completed following the
CJEU's judgment: MG (Prison—Article 28(3)(A) of Citizens Directive) Portugal _[[2014] UKUT 392 (IAC), [2015] Imm](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D2B-87C1-F0JY-C03K-00000-00&context=1519360)_
AR 128. The tribunal hearing Mr Reis's appeal would have had the benefit of the written submissions that had
already been put forward by those acting on his behalf at earlier stages in the proceedings. Those submissions
would have identified and explained the points of law in issue, and the fact that there were several legal points was
far from unusual in a case before the First-tier Tribunal. The kind of points raised in Mr Reis's appeal were, he
submitted 'very much the bread and butter of many First-tier Tribunal hearings'.

**[133] Mr Drabble submitted that the decision to deport was of immense significance to Mr Reis. The effect of the**
decision would have been to separate him from his wife, from his wife's daughter, and from his own son, all of them
British citizens who could not be expected to relocate to Portugal. There were
**[*904]**

two main reasons why Mr Reis required legal representation in his appeal. Firstly, following the decision of the
CJEU in MG there was considerable uncertainty regarding the applicability of the 'imperative grounds' test for the
deportation of EU citizens. In para [42] of its determination in MG the Upper Tribunal had identified:

'a possible tension in the text of the answers given by the Court and an apparent contradiction between:

(1) its seemingly categorical statement in the first part of paragraph 33 that “periods of imprisonment cannot be
taken into account for the purposes of granting the enhanced protection provided for in Article 28(3)(a) …”; and

(2) its seemingly defeasible statement in the second half of the same sentence (reinforced in paragraphs 35–
36) that “in principle, such periods interrupt the continuity of the period of residence for the purposes of that
provision.” '

**[134] Secondly, Mr Reis needed assistance with the preparation of evidence, in particular with an expert report**
concerning his risk of reoffending if he remained in the United Kingdom (where he had the support of his family)
compared with the risk if he was returned to Portugal. The determination of the tribunal allowing the appeal
demonstrated that the Director's assessment that the merits of Mr Reis's claim were poor rather than borderline was
irrational. Moreover, it was to be noted that the tribunal had said in para 53 of its determination that: 'This has been
a case involving complex legal submissions and I wish to note that I have been greatly assisted by the appellant
being represented by counsel under the legal aid scheme.'

**[135] Our conclusions in relation to Mr Reis are as follows. The decision to deport him was of immense significance**
to him, and to his family, all of whom are British citizens. We accept Mr Chamberlain's submission that the fact that
there were several legal points in issue in Mr Reis's appeal was far from unusual in a case before the tribunal.
However, the litigation culminating in the decision of the CJEU in _MG demonstrates that the key question in Mr_


-----

Cross Society intervening) [2015] 3 All ER 827

Reis's case—whether an individual in his position is entitled to the enhanced protection afforded to EU citizens who
have resided in the United Kingdom for a continuous period of ten years—is a particularly complex legal issue. Mr
Chamberlain founded the appeal in Mr Reis's case upon the proposition that such complexity as there was had now
been resolved by the CJEU's decision in MG and the subsequent decision of the Upper Tribunal in that case. We
do not accept that submission. The Upper Tribunal in MG identified an area of uncertainty that remained following
the CJEU's decision. Moreover, we now have the inestimable benefit of hindsight. We know that the tribunal when
determining Mr Reis's appeal said that it had involved 'complex legal submissions' and expressly noted that it had
been 'greatly assisted' by Mr Reis being represented by counsel. Had the appeal not involved complex legal
submissions Mr Reis might well have been able to effectively represent himself, but given the complexity of the key
legal issue he was not able to do so.
**GROUND 8: THE CASE OF B**

**[136] The factual background to B's case is summarised in paras [99]–[101] of Collins J's judgment:**

'[99] B is an Iranian national who arrived in the UK in March 2013. She claimed asylum fearing persecution for
her political activities on behalf of

**[*905]**

Kurds. She was granted refugee status on 15 April 2013 and given five years leave to remain. Following her
departure from Iran, her husband and son, who was born on 2 June 1997, were arrested and interrogated.
They were beaten and threatened and ordered on release to give the authorities information about the
claimant.

[100] The claimant was understandably very anxious about her husband and son. She spoke no English and
was dependent on assistance from the Iranian and Kurdish Women's Rights Organisation (“IKWRO”). They
advised her that she might be able to apply for family reunion so that her husband and son could join her in the
UK. IKWRO were unable to assist her in making an application since it was not licensed to do so and, following
advice from IKWRO, she met with her present solicitor. Her solicitor recognised that there might be difficulties
in that her son had no passport and there were no facilities available in Iran to enable a visa to allow entry to
the UK to be obtained there. The claimant was extremely upset and worried and her inability to communicate in
English made things even more difficult for her. Her solicitor was aware from the Legal Aid casework website
that family reunion was said not to be in scope for the purpose of grant of legal aid. Nevertheless, the view was
taken that that might be wrong and that in any event the claimant needed legal assistance to enable her to
have any real prospect of achieving family reunion.

[101] If her son approached the Iranian authorities to obtain a passport, the claimant was afraid, not without
good reason, that he would be arrested and ill-treated. Thus the only way he could apply for the necessary
documentation to enable him to achieve entry to the UK was to go unlawfully to Turkey and apply there. This
he did with his father and applications for entry clearance were made in Ankara. The applications were
prepared by the claimant's solicitor on instructions from the claimant. Since the claimant's son was in Turkey
unlawfully, he was afraid to leave the friend's address where he was staying and was extremely distressed.
The applications for entry clearance were made in August 2013 but a decision was not made until 15
December 2013 when the claimant's husband was granted an entry clearance but their son was refused. Apart
from the inexcusable delay in dealing with the application having regard to the circumstances in which the
applicants were living in Turkey, the decision was extraordinary and an appeal was lodged. Islington Law
Centre assisted in this. Fortunately, before an appeal was heard, on 13 February 2014 the claimant's son was
granted the necessary entry clearance. Notwithstanding that, he has not been granted the necessary exit
permits by the Turkish authorities. However, there is little that the UK authorities can do about that.'

**[137] Islington Law Centre originally applied for legal aid on the basis that an application for family reunion was in**
scope pursuant to para 30(1)(a) of Pt 1 of Sch 1 to LASPO. It subsequently applied in the alternative for ECF,
primarily by reference to art 8. Both applications were refused.


-----

Cross Society intervening) [2015] 3 All ER 827

**[138] Collins J held that (i) an application for family reunion was in scope and legal aid should therefore have been**
granted to cover advice and assistance in respect of the applications on behalf of B's husband and son, and (ii) if an
application for family reunion was not in scope, legal aid should nevertheless have been granted by way of ECF.
The appellants contend that the judge was
**[*906]**

wrong on both points. An alternative basis on which legal aid was sought, by reference to the Qualification Directive
[of the European Union (Council Directive 2004/83/EC (on minimum standards for the qualification and status of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9PT3-GXFD-84B8-00000-00&context=1519360)
third country nationals or stateless persons as refugees or as persons who otherwise need international protection
and the content of the protection granted) (OJ 2004 L304 p 12) ('the Qualification Directive'), was rejected by the
judge and, although raised by a respondent's notice, has not been pursued before us.
_Is an application for family reunion in scope for legal aid?_

**[139] By s 9(1) of LASPO, immigration cases falling within para 30 of Pt 1 of Sch 1 are within scope for legal aid.**
Paragraph 30 reads:

'Immigration: rights to enter and remain

(1) Civil legal services provided in relation to rights to enter, and to remain in, the United Kingdom arising
from—

(a) the Refugee Convention;

(b) Article 2 or 3 of the Human Rights Convention;

(c) the Temporary Protection Directive;

(d) the Qualification Directive …'

**[140] The present issue is whether rights to family reunion are rights 'arising from' the Refugee Convention.**

**[141] The written submissions on behalf of the intervener, the British Red Cross Society, contain a detailed analysis**
of the right of a refugee to family reunion. They point out that a right to family unity is entrenched in international
human rights and humanitarian law and that there is strong support for the view that it is also customary
international law. Whilst the body of the Refugee Convention contains no explicit reference to family unity or family
reunion, the Final Act of the Conference which adopted the Convention included a Recommendation B referring to
the unity of the family as 'an essential right of the refugee' and recommending governments 'to take the necessary
measures for the protection of the refugee's family especially with a view to (1) ensuring that the unity of the
refugee's family is maintained'. The argument advanced is that the refugee's right to family reunion arises directly
from his or her recognition as a refugee under the Convention and reflects his or her special status: 'the right to
family reunion is inherently linked to status—it is a right which arises from the Convention and which, in its practical
form, would not exist but for recognition of status'.

**[142] Similarly, Mr Bowen argues on behalf of B that a refugee's right to family reunion 'arises from' the Refugee**
Convention because (i) it follows from recognition of refugee status under the Refugee Convention, (ii) it would not
exist but for the Refugee Convention, and (iii) it is given effect domestically through the Immigration Rules, the
relevant provisions of which were introduced expressly to give effect to the policy agreed at the Conference which
adopted the Refugee Convention. He submits that 'arising from' is plainly wider than terms such as 'contained in',
['conferred by' or 'under'. For example, s 82 of the Immigration and Asylum Act 1999 defines 'claim for asylum' as a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y162-00000-00&context=1519360)
claim that it would be contrary to the UK's obligations 'under' the Refugee Convention for the claimant to be
removed from, or required to leave, the United Kingdom: had Parliament intended para 30 of Pt 1 of Sch 1 to
LASPO to be limited in the same way, a similar term would have been used. Thus, rights 'arising from' the Refugee
Convention, within the meaning of
**[*907]**


-----

Cross Society intervening) [2015] 3 All ER 827

para 30, include not only those that are contained in the Refugee Convention but also those that are contingent on
the recognition of refugee status under the Refugee Convention.

**[143] Collins J accepted that line of argument, holding that as a matter of ordinary English, the refugee's right to**
family reunion 'arises from the Convention since the Convention enabled that person to achieve the status of
[refugee' (para [106]). He referred to Union of India v E B Aaby's Rederi A/S [1974] 2 All ER 874, [1975] AC 797as](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-61HT-00000-00&context=1519360)
confirming the width of the words 'arising out of' (which he considered to be no different in meaning). That was a
charterparty case in which the House of Lords held that a dispute concerning a claim for general average was a
dispute 'arising out of' the charterparty.

**[144] For the appellants, Mr Chamberlain submits that the meaning of 'arising from' depends on context and that**
the decision in the Union of India case therefore provides no real assistance. As Lord Brandon of Oakbrook said in
_[The Antonis P Lemos [1985] 1 All ER 695 at 700, [1985] AC 711 at 727, in relation to the words 'arising out of':](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-61M4-00000-00&context=1519360)_

'I would readily accept that in certain contexts the expression “arising out of” may, on the ordinary and natural
meaning of the words used, be the equivalent of the expression “arising under”, and not that of the wider
expression “connected with”. In my view, however, the expression “arising out of” is, on the ordinary and
natural meaning of the words used, capable, in other contexts, of being the equivalent of the wider expression
“connected with”. Whether the expression “arising out of” has the narrower or the wider meaning in any
particular case must depend on the context in which it is used.'

**[145] Mr Chamberlain submits that in the present context the expression 'arising from' clearly has a narrow**
meaning. A right 'arises from' an instrument referred to in para 30 if and only if it is contained in that instrument, not
by reason of some looser connection. The expression 'arising from' (rather than, for example, 'under') has been
used simply because each of the instruments in question has to be implemented in domestic law—the Refugee
[Convention by means of the Immigration Rules, the Human Rights Convention by means of the Human Rights Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
_[1998,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_ and the Temporary Protection Directive and the Qualification Directive by means of regulations and other
measures. The use of 'arising from' makes sense in that context. The fact that LASPO lays down a set of carefully
defined and restrictive conditions as to the matters in scope for legal aid also tells in favour of a narrow
interpretation.

**[146] On that basis it is submitted that a refugee's right of family reunion is not a right 'arising from' the Refugee**
Convention. The right is not contained in the Refugee Convention. The Refugee Convention makes no reference
whatsoever to it. It is not enough that the right is recognised in international law and is referred to in the Final Act of
the Conference which adopted the Refugee Convention.

**[147] In our judgment, the interpretation of 'arising from' for which the appellants contend is the correct one. The**
expression is evidently capable of having a narrower or a wider meaning but in the present context, for the reasons
given by Mr Chamberlain, we think that Parliament must have intended the narrower meaning, with the
consequence that the right of family reunion is excluded from the matters in scope. On this issue, therefore, we
reach the opposite conclusion from that reached by Collins J.
**[*908]**

**[148] Mr Chamberlain has sought to rely in addition on various Parliamentary materials as demonstrating the**
correctness of the appellants' position on the issue. Collins J took the view that there was no ambiguity in the
expression 'arising from' and that the materials in question were therefore not admissible on the principles in
_[Pepper (Inspector of Taxes) v Hart [1993] 1 All ER 42, [1993] AC 593, but that even if they were admissible they](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60C0-00000-00&context=1519360)_
were insufficient to show that Parliament intended to exclude the right of family reunion from scope under para 30.
As it seems to us, however, the best that might be said in B's favour is that the expression is ambiguous, opening
the door to consideration of the Parliamentary materials; and if those materials are taken into consideration, they
point strongly to the conclusion, which we would reach in any event, that the legislative intention was to exclude the
right of family reunion from scope. The materials in question are as follows.


-----

Cross Society intervening) [2015] 3 All ER 827

**[149] In the House of Commons debate on 31 October 2011, at the report stage of the LASPO Bill, consideration**
was given to an amendment tabled by Mr Simon Hughes MP seeking to bring some refugee family reunion cases
into scope for legal aid. The premise of the proposed amendment and of the debate on it was that such cases were
not at present in scope under the Bill. Mr Jonathan Djanogly MP, at that time Parliamentary Under-Secretary of
State for Justice, resisted the amendment but, in response to a request by Mr Hughes, promised to look again at
the point and to come back to him. He said that he would write to Mr Hughes about that and other immigration
matters raised in the debate.

**[150] We have not seen any subsequent letter to Mr Hughes from Mr Djanogly. On 1 December 2011, however, Mr**
Hughes had a meeting with Lord McNally, Minister of State and Deputy Leader of the House of Lords, to raise
concerns about the LASPO Bill, including the issue of appeals in immigration cases and complex family reunion
cases. In a subsequent letter to him, dated 14 December 2011, Lord McNally referred to the difficult choices the
government had had to make about legal aid and stated that the reforms to the scope of the scheme were designed
to refocus civil legal aid on the most serious cases in which legal advice and representation was justified; this meant
making sure that legal aid remained for asylum matters, which might be a matter of life and death, but
'fundamentally, we do not think that most immigration matters justify legal aid'. The letter amounted in our view to a
refusal on behalf of the government to countenance bringing family reunion cases into scope.

**[151] The matter was pursued in the House of Lords. On 18 January 2012, at the committee stage, Lord Thomas of**
Gresford moved a specific amendment to the LASPO Bill to bring family reunion cases into scope (734 HL Official
Report (5th series) col 675). Whilst resisting the amendment on behalf of the government, Lord Wallace of
Tankerness undertook to look again at the issue of complex cases (col 678). It is evident, however, that the
government's position did not change. On 12 March 2012 an amendment was moved by Lord Thomas the effect of
which would have been to enlarge the criteria for ECF by the addition of a general 'interests of justice' criterion (736
HL Official Report (5th series) col 118). Family reunion cases were cited as an example of complex immigration
cases where such a provision was needed. The amendment was resisted by Lord Wallace and was withdrawn (col
132).

**[152] In our view it is plain from those materials, looked at as a whole, that Parliament intended the expression**
'arising from' in para 30 of Pt 1 of Sch 1 to LASPO to have the narrower meaning for which the appellants contend.
The
**[*909]**

amendments to which we have referred were moved on the basis that the rights 'arising from' the Refugee
Convention did not include the right of family reunion. The debates on them proceeded on that basis. There was no
suggestion that the amendments were unnecessary because the right of family reunion fell within scope on the
present wording of the Bill. There was no material change to the wording. This was not just the _executive_
expressing a view about the meaning of the legislation. It was Parliament's understanding of that meaning.

**[153] After the hearing of the appeal, Mr Chamberlain drew our attention to the judgment of Lord Carnwath in R (on**
_the application of CN) v Lewisham London BC, R (on the application of ZH) v Newham London BC (Secretary of_
_State for Communities and Local Government, interested party) [2014] UKSC 62,_ _[[2015] 1 All ER 783, [2014] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FBK-BWY1-DYBP-M3R4-00000-00&context=1519360)_
WLR 1548, rejecting an attempt by the Secretary of State to rely on ministerial statements made in response to a
proposed amendment to a Bill before Parliament. Lord Carnwath stated:

'[86] … The special exception allowed by _Pepper v Hart is directed at ministerial statements in support of_
legislation, and even then the circumstances in which reference is permissible are closely defined. It provides
no support for reference to such a statement in relation to proposed legislation which was not in the event
adopted.'

**[154] That observation must be read in context. The case concerned the construction of a 1977 statute which was**
the subject of long-standing Court of Appeal authority. The Secretary of State sought to rely on the fact that in the
course of a debate on a Bill in 2008 an amendment reversing the effect of that authority was proposed but was


-----

Cross Society intervening) [2015] 3 All ER 827

defeated. That is plainly a very different situation from the present, where the proposed amendments were to the
Bill that became the very statute the construction of which is in issue, and where the ministerial statements in
question were made in response to those proposed amendments. We do not read Lord Carnwath's observation as
precluding reliance on the Parliamentary materials to which we have referred in this case.
_The application of art 8 to B's case_

**[155] Our conclusion that the right of family reunion is not in scope for legal aid makes it necessary to consider the**
alternative basis on which Collins J found in B's favour, by reference to the application for ECF pursuant to art 8.

**[156] The letter of 2 August 2013 from Islington Law Centre requesting ECF is an impressive document. It**
explained that the centre was assisting B and her husband and son to prepare and submit applications to the visa
application centre in Turkey. It set out the factual background. It stated that without legal advice B had no idea how
to secure her family's entry into the United Kingdom. She did not speak English but was receiving some practical
and emotional assistance from IKWRO, which had been able to assist her through interpreting for her and helping
her to complete a benefits claim but had referred her for specialist legal advice on the basis that it did not have the
required expertise to advise and assist in family reunion applications.

**[157] In relation to the importance of the issues at stake, the letter said that the consequence of the family reunion**
applications being refused, or being unable to proceed due to a lack of legal advice and assistance, would be the
loss of any possibility of meaningful contact between the three family members
**[*910]**

concerned. It listed various factors in the history of the case and the personal circumstances of members of the
family as highlighting the importance and gravity of the issues at stake.

**[158] On the question of complexity, the letter referred to the legal provisions governing family reunion and**
described the procedure for making entry clearance applications as 'a complex and time-consuming process
involving multipart evidential preparation without which family reunion applicants can be readily refused'. In the
ordinary course the applicants and sponsor would be expected to provide proof of marriage, proof of parentage,
proof of a de facto pre-flight family relationship which was still subsisting, and proof of the sponsor's United
Kingdom refugee status. From the centre's experience the most common cause of refusals in family reunion
applications was a failure to provide adequate evidence to the overseas visa post, particularly as regards subsisting
family life. Because of the particular factual matrix in B's case, it was envisaged that there could be grounds for
refusal if additional evidence was not provided along with legal submissions by a specialist legal adviser. The
issues identified were that (a) the family did not have access to all documentation required to satisfy the
requirements of the rules, on account of their separation and dispersal, (b) the son was a 16-year-old now living
separately from his parents and it could be contended that he was living an independent life, so that assistance was
required with preparing a witness statement to set out what had happened, and submissions were required on the
point of continued dependency; and (c) evidence was needed on the psychological/psychiatric impact of separation
on members of the family. In addition, the family would need legal advice and assistance in order to make a
concurrent application to expedite the family reunion applications, on the basis of factors including the best interests
of the son.

**[159] The letter submitted that B and her family were not in a situation where they could act for themselves and**
engage meaningfully in the required proceedings. The husband was at that time hiding in Iran and it was not clear
when he would be able to go to Turkey. The son was traumatised and suffering from mental health problems in
Turkey where he was also in hiding. They had no financial resources. B did not speak English, had no experience
of United Kingdom immigration law and was herself in poor psychological health and without financial or practical
resources. Without legal advice and assistance she and her family would either (i) submit applications that were
likely to be refused or (ii) not submit applications at all. Either consequence would occasion a breach of art 8.

**[160] A separate letter from IKWRO, dated 30 August 2013, confirms that B could not manage the family reunion**
application herself: 'She did not have the first clue.' IKWRO was registered with OISC at Level 1 (see para [116],


-----

Cross Society intervening) [2015] 3 All ER 827

above for an explanation of OISC requirements) and to have given her legal advice would have been beyond its
competence. That is supported by the witness statement of Mr James of OISC, which makes clear that a person
must be accredited at Level 2 in order to provide legal advice and assistance in relation to refugee family reunion.

**[161] The application for ECF was refused. The refusal was then the subject of a review decision, dated 13**
September 2013, by the head of the exceptional cases team. The decision letter stated that regard had been had to
the Guidance. It expressed the opinion that B would not be incapable of submitting an application form without the
assistance of a lawyer. As to the statement that she was precluded from participation in the process because she
did not speak
**[*911]**

English, the letter noted that she was able to provide Islington Law Centre with her instructions and that the cousin
with whom she was staying had provided a well-written letter which illustrated that the cousin understood the
English language; the Centre did not appear to have considered or addressed why the cousin could not assist B to
submit the application. As to the assertion of procedural and evidential complexities, it was evident that the
evidence had been straightforward to collate 'as you have been able to attain and analyse “certified translations” of
your client's husband passport and marriage certificate'. The decision-maker was satisfied that withholding legal aid
would not make the assertion of her claim practically impossible or lead to an obvious unfairness, and that therefore
there would be no breach or risk of a breach of B's art 8 rights.

**[162] By this time Islington Law Centre had already submitted to the entry clearance officer in Turkey, on 12 August**
2013, applications on behalf of B's husband and son for leave to enter the United Kingdom on the basis of refugee
family reunion with B. The applications consisted of a covering letter explaining the background and making
submissions about missing information and documents; completed online standard forms of application for entry
clearance, including an appendix relating specifically to refugee family reunion; a supporting statement by B; and
copies of available documents.

**[163] Decisions on the applications were not made until 5 December 2013, when the husband's application**
succeeded but the son's application was refused. The reasons for refusal were:

'You have not fully completed your Annex 4 of your application form, but according to your claimed father's
application form you last saw your sponsor in February 2013. You claim to have lived with your parents from
birth in the same place until your sponsor left. You have provided a birth certificate, however apart from this,
you have not provided any evidence that you were or are in a relationship with your sponsor. You have
provided no photographs of the two of you together or any evidence of any contact at all between the two of
you. I acknowledge that you have provided your sponsor's Screening interview, but this does not mention you
by name. If you had been in a relationship since you were born I would expect there to be overwhelming
evidence of this. I am therefore not satisfied that you have been part of a family unit of your father at the time
he left his country of his habitual residence in order to seek asylum.'

**[164] We have already quoted the passage in Collins J's judgment where he observed that the delay in dealing with**
the applications was 'inexcusable' and that the decision in respect of B's son was 'extraordinary' (para [101] of his
judgment). Islington Law Centre lodged an appeal to the First-tier Tribunal on the son's behalf, with grounds of
appeal and supporting documents. It also put in a request for fee remission and a request for an expedited appeal
hearing. In addition, however, it sought urgent reconsideration of the entry clearance officer's decision. That
resulted in a change of mind and the grant of entry clearance without the need to pursue the appeal before the
tribunal.

**[165] That, in summary, is the factual material that led Collins J to the view that ECF should have been granted if**
the correct approach had been applied.

**[166] In challenging that conclusion, Mr Chamberlain stresses that the procedural requirements of art 8 are focused**
on involvement in the decision-making process and that in this case ECF was sought in relation to the making of
_applications for family reunion In essence the application_


-----

Cross Society intervening) [2015] 3 All ER 827

**[*912]**

process involves (a) checking online what the procedure is for the particular country in question (for most countries,
it is to fill in an online application for a visa), (b) submitting the online application and getting a reference number,
and (c) making an appointment to attend in person at a visa application centre. No more than a limited amount of
internet searching is necessary to find the right forms. The forms themselves ask specific and directed questions in
plain English and seek factual information. The appendix dealing specifically with refugee family reunion
applications refers at the outset to guidance on the Home Office website about supporting documents (ie what
evidence one should submit with the application) and includes guidance notes at the end in relation to the individual
questions. There is no need to address submissions on points of law. As to the point that B herself does not speak
English, the evidence does not establish that there is nobody to whom B can turn for assistance in relation to the
English forms. Mr Chamberlain also points to the existence of third-sector organisations capable of helping with
tasks such as translating from the website, booking appointments with visa application centres and collating
documents. He suggests that even if B needed more than practical assistance, there are over 100 organisations
registered to provide not-for-profit immigration advice at Level 2 and above, and he points out that B was assisted in
the event by Islington Law Centre (though he does not dispute the Centre's evidence that it is a charity of limited
resources and needs ordinarily to be funded if it is to provide such advice and assistance).

**[167] So far as concerns the appeal against, and request for reconsideration of, the refusal of entry clearance for**
B's son, Mr Chamberlain makes the point that the decision on ECF was made in relation to the application for entry
clearance, not in relation to the steps to be taken following a refusal of entry clearance. In any event, however, he
submits that if an application is refused, reasons are given, there is a right of appeal on the merits and the applicant
knows what points it is necessary to address in an appeal. For example, the refusal decision in respect of B's son
explained in plain language the deficiencies in the evidence provided. There was no point of law and no need for a
lawyer. Similarly, in relation to matters such as fee remission, expedition and reconsideration, the issues are
administrative, not legal, and it is simply a case of asking for something in plain language and explaining why it is
needed.

**[168] A further submission by Mr Chamberlain, generating a sub-issue of its own, is that Collins J fell into error in**
considering that B's son, who was living at the material time with family friends in Turkey, enjoyed rights as against
the United Kingdom under art 8: the son was outside the jurisdiction of the United Kingdom for ECHR purposes.
The decision of the Strasbourg court in Tuquabo-Tekle v Netherlands [2005] 3 FCR 649 does not stand as authority
to the contrary because the Netherlands government was estopped on procedural grounds from raising the
[question of jurisdiction. The decision in Al-Skeini v UK (2011) 30 BHRC 561 confirms that, save for certain defined](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2FC-00000-00&context=1519360)
and established exceptional categories, it is only individuals within the territorial jurisdiction of a contracting state
who are within that state's jurisdiction for the purposes of the Convention. B's son was not within the territory of the
United Kingdom and did not fall within any of the exceptional bases, including in particular that relating to acts of
diplomatic and consular agents, the narrow scope of which was recently confirmed by the Supreme Court in R (on
_[the application of Sandiford) v Secretary of State for Foreign and Commonwealth Affairs [2014] UKSC 44, [2014] 4](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DPM-YP81-DYBP-M407-00000-00&context=1519360)_
_[All ER 843, [2014] 1 WLR 2697.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DPM-YP81-DYBP-M407-00000-00&context=1519360)_
**[*913]**

**[169] On behalf of B, Mr Bowen submits by reference to the decision of the Strasbourg court in Senigo Longue v**
_France (cited at [69], above) that a decision whether to permit family reunion engages B's substantive art 8 rights—_
a point that is not in dispute. As to the relevance of the art 8 rights of B's son, he submits that there are many cases
in which the courts have reached decisions on art 8 grounds where the people concerned are outside the
jurisdiction. He cites the decision of the Supreme Court in _R (on the application of Aguilar Quila) v Secretary of_
_State for the Home Dept, R (on the application of Bibi) v Secretary of State for the Home Dept [2011] UKSC 45,_

_[[2012] 1 All ER 1011, [2012] 1 AC 621as a recent example and submits that this court is bound to follow the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:551R-1TF1-DYBP-M209-00000-00&context=1519360)_
reasoning in that case.

**[170] He makes the undisputed point that legal aid may in principle be required at the application stage, as**
illustrated by the fact that the appellants have conceded IS's appeal (see [78] [80] above) He submits that if legal


-----

Cross Society intervening) [2015] 3 All ER 827

advice is necessary to ensure effective participation in the decision-making process, the right to receive free legal
advice can arise at the outset of the process, before any application is made: there can be no participation at all if
the individual cannot identify the correct application form and fee, the procedure for making the application and the
evidence required to support it. It is self-evident that a need for immigration legal advice may arise in practice prior
to the making of an application. The law and policy are extremely complex. The provision of legal advice in this area
is regulated by statute, with criminal sanctions for those who provide it without authorisation. It is incoherent to
suggest that an ordinary individual can always navigate a process without the benefit of advice that would, if given,
be subject to that statutory regulation. The only question, therefore, is whether such advice is necessary on the
particular facts, having regard to what is at stake, the complexity of the particular procedure and the individual's
ability to navigate the process without advice. That is a merits question which Collins J decided in B's favour. For
this court to interfere with the judge's assessment, the appellants would need to show that the judge's decision was
so unreasonable as to have 'exceeded the generous ambit within which a reasonable disagreement is possible'
(Tanfern Ltd v Cameron-MacDonald _[[2000] 2 All ER 801, [2000] 1 WLR 1311(at para 32)), a threshold that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-615V-00000-00&context=1519360)_
appellants do not even begin to cross.

**[171] Mr Bowen goes on to address the detail of the appellants' arguments on the merits, without prejudice to his**
primary case that this court should not interfere with the judge's assessment. He submits that on the material set
out in the application for ECF, B clearly needed legal advice and assistance. The process is far from being so
simple that all that was required was a little help with English and an internet connection. Identifying the correct
application form and the correct appendix to it is not straightforward. Neither the guidance on the Home Office
website nor the questions and guidance in the form itself tell an applicant about the substantive and evidential
requirements for a family reunion application. The experience of the Islington Law Centre was that the most
common cause of refusals is a failure to provide evidence to the overseas visa post, which was indeed the reason
why entry clearance was refused in the case of B's son. The lack of a passport added complexity to the son's case.
The refusal of entry clearance meant that an appeal was necessary. The fact that the grounds of appeal were very
strong did not remove the need for legal advice and assistance, which was also required in relation to the
applications to the tribunal for fee remission and expedition and the making of representations to the entry
clearance officer to reconsider the
**[*914]**

refusal decision. If legal advice is needed, it must be given by a person accredited to OISC Level 2, and there is no
evidence that third-sector organisations have the competence and capacity to give such advice on a widespread
basis without legal aid. The fact that Islington Law Centre provided legal advice and assistance to B at risk, pending
clarification of whether family reunion applications are within scope for legal aid and/or whether ECF should be
granted, takes the appellants nowhere. For all those reasons Collins J was correct to find that, if family reunion
applications are not in scope, ECF was necessary in order to avoid a breach of B's rights under art 8.

**[172] Our conclusions in relation to B's case are as follows. We accept that family reunion is generally a matter of**
vital importance for refugees and that it was so for B herself. The particular circumstances of B, her husband and
her son gave rise to issues of particular complexity. It is striking that even though the application on behalf of the
son was prepared with legal advice and assistance, it was refused at first on the ground of failure to satisfy the entry
clearance officer that the son was part of the family unit—one of the areas of potential difficulty identified in the
application for ECF. The resulting appeal and request for reconsideration added to the overall procedural
complexity of the exercise. In relation to all of this, B was wholly unable to represent herself or her other family
members. It was not simply that she was unable to speak English but that '[s]he did not have the first clue', as it was
graphically put by IKWRO. Without legal advice and assistance it was impossible for her to have any effective
involvement in the decision-making process. The Director ought therefore to have concluded that failure to provide
legal aid would amount to a breach of her Convention rights. This alternative basis for Collins J's order directing the
grant of legal aid was correct.

**[173] We have reached that conclusion without needing to decide the jurisdictional issue concerning the art 8 rights**
of B's son. It can make no practical difference in the present case whether one looks at the position simply from the
perspective of B's art 8 rights or whether one adds in the son's art 8 rights: the ECF decision does not turn on it. In


-----

Cross Society intervening) [2015] 3 All ER 827

any event, however, we share the view expressed by Collins J at para [114] of his judgment as to the artificiality of
excluding the interests of a child outside the jurisdiction when considering a refugee reunion case under art 8.
**Ground 9: The case of Ms Edgehill**

**[174] The factual background to the case of Ms Edgehill is set out in paras [116]–[121] of the judgment of Collins J:**

'[116] The claimant, a Jamaican national, was admitted to the UK on 14 September 1998 as a visitor. She was
granted leave to remain as a student until 31 January 2001. In March 2007 she applied for leave to remain on
the ground of UK ancestry, asserting that she had been born in the UK but sent to Jamaica where she was
brought up by a couple whom she believed to be her parents. The application was refused and the claimant
thereupon became an overstayer. She did not leave the UK. She said she was joined by various children, one
of them had a son born here in May 2008 who is a British citizen.

[117] She kept in touch with the Home Office and she applied for a certificate under _[s 10 of the Nationality,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61H0-TWPY-Y07W-00000-00&context=1519360)_
Immigration and Asylum Act 2002 that she was entitled to remain here. This was refused on 7 March 2012.
She appealed. In her notice of appeal which she filled out without legal

**[*915]**

assistance, she said, under the heading in the form asking her to state if the Home Office had suggested she
could live safely in another part of her country of origin, that she disagreed. She said:

“I have no home in another country all my family are here and I have nowhere to go. Also my parents brought
me to Jamaica and left me there and this is my home.”

[118] That box in the form had no application since the Home Office had not suggested she could live safely in
another part of her native country. However, the First-tier judge, who dismissed her appeal, did spot that it
“alluded to her Article 8 rights”. He said he would in any event have considered them, but, because no
evidence had been produced and there was no attendance before him, he dismissed her appeal on 4 June
2012. She was granted leave to appeal to the Upper Tier, but her appeal was dismissed on 7 February 2013.

[119] In answering her art 8 claim, the Upper Tribunal Immigration and Asylum Chamber (“UTIAC”) considered
her length of residence (which exceeded 14 years) and had regard to para 276ADE of the Immigration Rules
which came into force on 9 July 2012 and required that an applicant had lived continuously in the UK for at
least 20 years in order to establish an art 8 claim based on private life. It said:

“… Article 8 appeals are decided on the facts as at the date of the hearing and, whilst this was a decision made
before the new Rules came into effect and therefore have no direct application and not retrospective, we
consider it appropriate to give weight to the new Rules as being an expression of the legislature's views as to
where the public interest lies.”

[120] Leave to appeal to the Court of Appeal was sought following refusal of leave by an UTIAC judge. Ground
2 raised the 14-year point, but somewhat indirectly. Beatson LJ noted that the case raised a question of
principle warranting a decision by the Court of Appeal. There was another case with which it was to be joined
which raised a similar point. In due course, the claimant's appeal was allowed and the other appellant's
dismissed since it did not on the facts cover the same ground. The claimant is due to have a fresh appeal
before the tribunal.

[121] Following Beatson LJ's grant of leave, an application for ECF was made on 19 September 2013. This
was refused on 14 October 2013. First, it was said that art 8 was not engaged since leave had not been
granted on the grounds specifically relating to art 8. However, that is to misunderstand the position since the
correct approach to 14 years' residence would impact on the art 8 claim. There was also refusal on the merits
since, it was said, the other case raised the same point. A review was sought, but on 30 October 2013 the
refusal was upheld. The author accepted that the merits test was met save in one respect, namely that the
Court of Appeal would not be considering grounds relating directly to art 8. That maintains the same error as in


-----

Cross Society intervening) [2015] 3 All ER 827

the previous decision. But the author asserts that Beatson LJ stated that the appeal raised a question of
principle not a point of law and that therefore there was no legal complexity. That is an extraordinary assertion
since the point of principle obviously turns on the correct approach in law.'

**[*916]**

**[175] In para [122] Collins J explained why he had concluded that the Director's reasons for refusing ECF were**
flawed:

'I am clearly of the view that if the Court of Appeal gives leave to appeal, it will (provided the case is one which
can attract ECF) prima facie be a case in which legal aid should be granted. The point at issue was not entirely
straightforward and would affect other cases. In this case I am entirely satisfied that it should have been
granted and that the reasons for refusal are flawed.'

In para [123] he rightly rejected a submission, pursued without much enthusiasm by Mr Underwood QC on behalf of
Ms Edgehill in this appeal, that art 6 applied to her case.

**[176] Ms Edgehill had been represented before the Court of Appeal by Mr Tear without the benefit of legal aid. Her**
appeal was successful, and the court remitted her appeal to the Upper Tribunal for re-determination: [2014] EWCA
_Civ 402, [2014] Imm AR 883._

**[177] Mr Chamberlain submitted that, Beatson LJ having identified the point of law in his grant of permission, the**
Court of Appeal was well able to deal with it. While the point of law would have been over the head of Ms Edgehill, it
was a relatively simple one, as evidenced by the brevity of the court's judgment and the fact that it was able to
dispose of the Secretary of State's submissions in a couple of paragraphs. Ms Edgehill's appeal had been listed to
be heard with another appeal (HB (Mauritius)) which raised the same point, and in which the appellant was
represented. It was apparent from the Court of Appeal's judgment that the points taken by the other appellant's
representative were the same as those taken on behalf of Ms Edgehill.

**[178] Mr Underwood submitted that Ms Edgehill could have had no concept of the point that was in issue in the**
Court of Appeal. She would have been in no position to put forward any argument in support of her appeal. If she
had been unrepresented that would have been tantamount to her not being in court at all while her appeal was
being heard. What was at stake for Ms Edgehill in this court was the lawfulness of a decision in respect of her art 8
rights and the application of immigration rules. In the context of family life comprising four children and a grandchild,
and against the backdrop of a stay of over 15 years, that was highly significant to her. The bases for the decisions
to refuse exceptional funding were woefully flawed. The Director's contention that, looking at the decision-making
process as a whole, Ms Edgehill was involved to the extent necessary to protect her interest disregarded the fact
that, until her case reached the Court of Appeal, she had wrongly lost her appeal against the Secretary of State's
decision at each stage of the appellate process. Only this court was able to put that right, and her previous
involvement in the appellate process was immaterial to the protection of her interests.

**[179] Mr Underwood submitted that the issue in Ms Edgehill's appeal was far from straightforward. In his judgment**
Jackson LJ had said that the interpretation of the Immigration Rules which had been advanced by counsel on
behalf of the Secretary of State was 'one of subtlety', which had not occurred to him when he was reading the
transitional provisions (para [25]), and Jackson LJ had admired 'the dexterity of the argument' advanced on behalf
of the Secretary of State (para [31]). The issues in the appeal of HB (Mauritius) were not the same, HB did not have
14 years' residence and her appeal, unlike
**[*917]**

Ms Edgehill's, was dismissed. Listing the two appeals together was good case management but it did not obviate
the need for Ms Edgehill to be represented in her appeal to the Court of Appeal.

**[180] Our conclusion is as follows. Ms Edgehill's appeal was of vital importance for her and her children. If her**
appeal to the Court of Appeal had not been listed with HB (Mauritius) it is clear that without legal aid she would not
have been able to have any meaningful involvement in the critical stage of the decision-making process in her case:


-----

Cross Society intervening) [2015] 3 All ER 827

the appeal to the Court of Appeal (her appeal having been wrongly rejected at the earlier stages of the process).
Although the Court of Appeal was able to dispose of the Secretary of State's submissions in a couple of
paragraphs, it praised 'the dexterity of the argument' advanced on behalf of the Secretary of State, and said that the
interpretation of the rules advanced on her behalf was 'one of subtlety'. Mr Chamberlain realistically accepted that
the point of law which had been identified by Beatson LJ would have been over the head of Ms Edgehill. However,
we do accept Mr Chamberlain's submission that the point of law on which Ms Edgehill's appeal succeeded was
being raised by HB, who was going to be legally represented before the Court of Appeal. While the circumstances
of the two appeals were not identical (HB's appeal was dismissed), the issue on which Ms Edgehill's appeal
succeeded was to be raised on behalf of HB. For this reason, while separate legal representation for Ms Edgehill
was no doubt desirable, a failure to provide her with legal aid would not have been a breach of her art 8 rights.
**SUMMARY OF CONCLUSIONS**

**[181] For the reasons we have given at [41]–[59], above in relation to ground 2, the Guidance is not compatible with**
art 6(1) of the Convention and art 47 of the Charter. It impermissibly sends a clear signal to caseworkers and the
Director that the refusal of legal aid will amount to a breach only in rare and extreme cases. For the reasons we
have given at [64]–[77], above in relation to ground 3, the Guidance is not compatible with art 8 of the Convention in
immigration cases. As is now conceded by the Lord Chancellor, para 60 of the Guidance wrongly states that there
is nothing in the current case law that would put the United Kingdom under a legal obligation to provide legal aid in
immigration proceedings in order to meet its procedural obligations under art 8.

**[182] To this extent, therefore, we agree with the general conclusions reached by Collins J. For the reasons given**
at [29]–[32], above, however, we do not agree with his statement that ECF is required under s 10(3)(a) of LASPO
only when the applicant can establish 'to a high degree of probability' that without it there would be a breach of his
procedural rights under the Convention or EU law. Nor do we agree with his statement that the 'risk' of a breach
referred to in s 10(3)(b) is a 'substantial risk that there will be a breach of the procedural requirements of' the
Convention or EU law.

**[183] Accordingly, we have considered the five live appeals afresh for ourselves applying Convention and EU law**
principles to the facts of each case.

**[184] For the reasons stated at [90]–[91], above, the appeal in the case of Ms Gudanaviciene is dismissed. For the**
reasons stated at [123]–[124], above, the appeal in the case of LS is allowed. For the reasons stated at [135],
above, the appeal in the case of Mr Reis is dismissed. For the reasons stated at [172]–[173], above, the appeal in
the case of B is dismissed. For the reasons stated at [180], above, the appeal in the case of Ms Edgehill is allowed.
**[*918]**

**[185] Finally, we note that an important strand of the submissions of Mr Chamberlain is that, to some extent at**
least, courts (and in particular specialist tribunals) are able to adopt an inquisitorial approach and in that way ensure
that litigants in person enjoy effective access to justice. We accept that this will be possible in many cases. But
these appeals show that there are cases where this is not possible. We would point out that, in some
circumstances, legal advice to the litigant in person may be more important than legal representation at the hearing
for ensuring effective access to justice. We suggest that consideration be given to whether, in an appropriate case,
ECF be provided for early legal advice even where it is not considered to be necessary for representation at the
hearing.

Order accordingly.

Charlotte Hennessey Solicitor (non-practising).

**End of Document**


-----

