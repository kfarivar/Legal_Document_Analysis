# Director of Public Prosecutions v M [2020] EWHC 3422 (Admin)

Queen's Bench Division, Administrative Court (London)

Simler LJ and Davis J

15 December 2020Judgment

**Mr Ben Douglas-Jones QC (instructed by Crown Prosecution Service Appeals and Review Unit) for**
the Appellant

**Ms Brenda Campbell QC and Mr Sam Parham (instructed by** **Ms Chloe Hartnell of** **Hodge Jones &**
**Allen Solicitors) for the Respondent**

Hearing dates: 24 November 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lady Justice Simler and Mr Justice William Davis:**

**Introduction**

1. This is an appeal by way of case stated pursuant to section 111 of the Magistrates' Courts Act 1980 and
section 28A of the Senior Courts Act 1981. The Director of Public Prosecutions appeals against the
decision of District Judge (Magistrates' Court) Susan Holdham sitting at Wimbledon Youth Court on 4
December 2019 to acquit the Respondent, a 15 year old boy to whom we shall refer as M, of charges of
possession of a bladed article, possession of a Class A drug (heroin) and possession of a Class A drug
(cocaine). The District Judge's decision to acquit M was based on the statutory defence in Section 45(4) of
the Modern Slavery Act 2015 (“the 2015 Act”).

2. The issue of law is whether the Respondent discharged the evidential burden which lay on him in
raising the statutory defence. In particular, the Appellant's case is that the District Judge erred in her
approach to the admissibility of the conclusive grounds decision of the Single Competent Authority (“SCA”)
that M was a victim of **_modern slavery and in her further conclusions that the offence was a direct_**
consequence of trafficking for the purposes of exploitation, and a reasonable person with the same
characteristics in the same situation would have committed the offence.

**The facts**

3. On 16 May 2019 M went into a branch of Kentucky Fried Chicken in Tooting. He was with two 15-yearold males (to whom we shall refer as MP and KM) and a young female whose identity is not known. The
group was observed by police officers going into the premises. MP and KM were known to the police as
gang members and habitual knife carriers. M was not recognised by the officers. The police officers
decided to stop and search MP and KM. When they went into the premises M was sitting with MP and KM.
As they did so MP threw away a cannabis joint.

4. All three were searched. KM was found to have a small quantity of cannabis in his possession. Save
for the cannabis which he had thrown away, MP had nothing of significance in his possession. M had 5
wraps of cocaine 2 wraps of diamorphine (heroin) and a hunting knife in his possession


-----

5. M was arrested. Either on the way to the police station or on arrival at the police station M initially told
police officers that he had the knife with him in order to cut steak. Thereafter he said that he had found the
knife and that he had planned to hand it in. When he was interviewed under caution, M made no
comment.

6. As well as the knowledge of the police officers as to the background of MP and KM, each had multiple
previous findings of guilt. KM had 15 such findings relating to 33 separate offences including possession
of a bladed article and possession of drugs. MP had 4 findings of guilt relating to 8 offences including
possession of a bladed article and possession of drugs.

7. At trial the prosecution relied on the evidence of P.C. Wright, one of the officers who had observed the
group going into Kentucky Fried Chicken, and of D.C. Jones, the arresting officer. P.C. Wright's evidence
was read. He was the officer who gave evidence of the background of MP and KM. He had dealt with
both young men in the past. He gave evidence of their gang connections including the fact that they were
in dispute with other gangs.

8. D.C. Jones had observed M whilst he was in custody. He had no concerns about M at that point. M
appeared to be unconcerned about being in a police station. He was laughing and joking with MP and KM
who also were in custody. He had the opportunity to raise concerns with D.C. Jones had he wished to do
so but M said nothing to the officer. D.C. Jones only became aware of any possibility of exploitation when
he later spoke to M's father. D.C. Jones had been working in the local gangs' unit for two years. In that
time he had not made any referrals via the National Referral Mechanism (“NRM”). That was something
dealt with by an independent police officer.

9. In addition to the evidence of the police officers, a set of 14 facts was agreed in accordance with section
10 of the Criminal Justice Act 1967. The admitted facts included the following:

i) On the 23 May 2019 M was referred to NRM by Lewisham Children's Social Care.

ii) On 1 July 2019 a senior practitioner with Lewisham Children's Social Care informed the SCA that M
regularly went missing from home, that during his missing episodes he had been picked up in Crawley,
West Sussex and that he had gone missing again after his arrest on 16 May 2019.

iii) M had no findings of guilt or cautions.

iv) On 21 August 2019 the SCA made a positive conclusive grounds decision that, on a balance of
probabilities, M had been recruited, harboured and transported for the purposes of criminal exploitation, the
full minute of the decision being exhibited.

10. The full minute of the SCA decision was a five-page document. It recorded the sources of information
on which the decision maker had relied, namely Lewisham Children's Social Care and the Metropolitan
Police. It set out in summary form the factual matters taken into account by the decision maker. These
were: police information about the behaviour of M when in custody (the evidence of DC Jones); concerns
of the authorities about the effect of M's parents' background and history on his development; M having
been stabbed in an incident in March 2018; M having gone missing from home since that incident; a social
services report in June 2019 to the effect that M did not want to return to live with his mother and that he
felt safe when he went missing because his friends looked after him; positive behaviour at home and at
school after June 2019 and since being rehoused in local authority care; police confirmation that M was
vulnerable due to age and had made no financial gain from gang involvement.  The full minute then
analysed the effect of those matters on the actions of M. It acknowledged that not all children involved in
criminality will have been trafficked. However, taking all matters into account, the decision maker
concluded on a balance of probabilities that M had been targeted by gang members for the purposes of
criminal exploitation. The decision summary was that M was a victim of modern slavery for the purposes
of criminal exploitation.

**The decision of the District Judge**

11. The judge considered all of the evidence put before her including the full minute of the SCA decision.
Sh f d th f ll i tt f ti l l i f f l i th t M h d b l it d


-----

i) M, who was of good character, was in the company of MP and KM who were known to the police with
previous findings of guilt recorded against them. The judge cited verbatim part of the evidence of P.C.
Wright.

ii) MP and KM only had small amounts of cannabis in their possession which raised the real possibility that
M was holding the knife and the Class A drugs for them.

iii) M regularly went missing from home. He was a missing person when arrested on 16 May 2019. He
had no connection with the Tooting area.

iv) The information provided to the SCA by the Metropolitan Police confirmed that M was vulnerable due to
his age and background. There were no signs of any benefit from criminal activity.

12. The judge also had regard to matters which the prosecution argued were factors tending to suggest
that M had not been exploited:

i) His explanations for having the knife were incredible. Having given those explanations to the police, he
made no comment in interview and he did not give evidence.

ii) His behaviour at the police station as described by D.C. Jones gave no indication that M had been the
subject of exploitation.

13. In relation to the SCA decision the judge referred to _R v Joseph and others [2017] EWCA Crim 36;_

[2017] 1 Cr. App. R. 33 at [21(viii)]:

“…the decision of the competent authority as to whether a person had been trafficked for the purposes of
_exploitation is not binding on the court but unless there was evidence to contradict it or significant_
_evidence that had not been considered, it is likely that the criminal courts will abide by the decision {see_
_L(C) at [28]).”_

She referred also to the Crown Prosecution Service guidance issued in 2015 which set out that, in relation
to those under 18, it was not necessary for compulsion to be demonstrated in order to establish the
statutory defence. Rather, it was necessary for the commission of the offence to be a direct consequence
of trafficking for the purposes of exploitation. The judge noted the guidance for Home Office staff
employed by the SCA in relation to cases of exploitation involving those under 18, guidance which was
repeated in the SCA decision.

14. The judge recorded that the prosecution had not argued that, in order to meet the evidential burden
which lay on him in relation to the statutory defence, M had to give evidence. Nor did they suggest that he
had to have provided some explanation in his police interview. The judge said that she would have
rejected such an argument had it been made. She found that the evidence adduced – the full minute of the
SCA decision, the evidence of the police officers and the admitted facts – was sufficient to satisfy the
evidential burden.

15. The judge went on to consider the relevant provisions of the **_[Modern Slavery Act 2015. We shall](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
return to the detail of these provisions hereafter. It is appropriate to set out here the terms of section 45(4)
of the 2015 Act i.e. the sub-section applicable to M:

_(4) A person is not guilty of an offence if –_

_(a) the person is under the age of 18 when the person does the act which constitutes the offence,_

_(b) the person does that act as a direct consequence of the person being, or having been, a victim of_
_slavery or a victim of relevant exploitation, and_

_(c) a reasonable person in the same situation as the person and having the person's relevant_
_characteristics would do that act._

She then rehearsed the findings of the SCA after which she dealt with the legal burden which lay on the
prosecution in these terms:


-----

_The Crown had not made me sure the act of possessing the knife and the drugs were not a direct_
_consequence of being a victim of relevant exploitation, bearing in mind that (M) had no previous_
_convictions, was a missing person at the time of arrest, had no known connection with Tooting where he_
_was arrested and was in possession of the items whilst the known gang members who “were known to be_
_habitual knife carriers” and “in dispute with other gangs” only had a small amount of cannabis on them._

She further concluded that, given the fact that M had turned 15 only two months before his arrest, she
could not be sure that a reasonable person of his age and characteristics would not have possessed the
items. Thus, the prosecution had not disproved the statutory defence and M was acquitted.

**The stated case**

16. The question posed on the 30 January 2019 for the opinion of the court is:

_In the circumstances of this case, where the Respondent did not give evidence and did not provide an_
_explanation in interview, had the Respondent sufficiently discharged the evidential burden in respect of_
_[Section 45(4)(b) and (c) of the Modern Slavery Act 2015?](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_

**The competing arguments**

17. The grounds of appeal dated 7 February 2020, state that the District Judge made an error of law
because she relied on the SCA decision which was opinion evidence on the part of the decision maker. In
any event the judge was wrong to find that the evidence before her was sufficient to discharge the
evidential burden which lay on M to establish the statutory defence.

18. In his skeleton argument and in oral submissions before us Mr Ben Douglas-Jones QC on behalf of
the Appellant said that the SCA decision was inadmissible. It was non-expert opinion evidence and was
hearsay. The decision was the product of a review of extraneous material by a Home Office employee
who was not an expert. Insofar as the decision contained evidence of fact rather than opinion, that
evidence was equivocal and untested. Mr Douglas-Jones argued that the validity of the SCA decision was
further undermined because at one point when dealing with M's lack of financial gain it failed to apply the
correct standard of proof (balance of probabilities). Rather, the decision stated that “it is suspected” that M
was committing offences on behalf of third parties.

19. Mr Douglas-Jones accepted that a conclusive grounds decision of the SCA can and will be admitted
by a court when considering an application to stay a case as an abuse of process by reference to a review
of the prosecutorial process. He said that in fact such an application would be most unlikely in any
proceedings to which the statutory defence applied. It will also be admissible when the Court of Appeal
Criminal Division is considering the safety of a conviction in a case where it is said that a person's
trafficking status has not been considered at trial either properly or at all. However, no SCA decision can
be admissible in a criminal trial. The function of any SCA decision is to meet the Convention obligations of
the UK (to which we shall refer hereafter), namely to have a procedure which can identify victims of
trafficking so that the person concerned is not removed before their status is confirmed. It was never
intended to be used as evidence in criminal proceedings. In M's case the prosecution agreed to the SCA
decision being placed before the judge. This was limited to treating the factual basis for the decision as
agreed facts. The decision itself was not agreed.

20. Mr Douglas-Jones submitted that those responsible for making SCA decisions were not experts. He
observed that no SCA decision complied with the requirements of Part 19 of the Criminal Procedure Rules.
He said that a tribunal of fact in criminal proceedings – whether the jury in the Crown Court or a District
Judge or lay justices in the magistrates' court or the youth court – was well suited to making the decisions
of fact required in relation to the statutory defence in the 2015 Act. Expert evidence might assist the fact
finder in making the decisions of fact. But expert evidence in that context can only be of value if the facts
are established by evidence from the defendant. Mr Douglas-Jones drew a parallel with psychiatric or
psychological evidence.

21. In relation to the conclusion of the District Judge on the facts of this case, Mr Douglas-Jones argued
that all the judge had was hearsay evidence that in general terms M may have been a victim of trafficking


-----

There was no evidence of any material weight to show that M's criminal acts were a direct consequence of
his status or that a reasonable person of his age would have carried out those acts. He said that, before
the introduction of the 2015 Act, when any issue of trafficking fell to be dealt with by an application to stay
proceedings as an abuse of process, the more serious the criminality, the greater the level of compulsion
would be required for a prosecution not to be justified. Thus, where the issue was whether a defendant
had satisfied the evidential burden to raise the statutory defence under section 45 of the 2015 Act, that
burden will be higher in cases of serious criminality. In the context of the offences with which M was
charged, the evidence did not satisfy the burden which lay on him.

22. On behalf of M Ms Brenda Campbell QC and Mr Sam Parham provided a skeleton argument and
made oral submissions before us. They argued that the judge's decision that M had discharged the
evidential burden was justified given the circumstantial evidence available to her. For instance, the judge
was entitled to take into account the incongruity of two known gang members having no incriminating items
whereas a vulnerable child in their company did. There was no requirement upon M to give evidence or to
have provided an explanation in interview. Such a requirement would leave the most vulnerable trafficked
child who was too frightened to give a positive account without the protection afforded by the 2015 Act. Ms
Campbell submitted that the prosecution in M's case was able to challenge the proposition that there was a
nexus between the exploitation and the offence and that a reasonable person in M's position would have
acted as he did. The judge considered the evidence relied on by the prosecution. Having carried out a
reasoned review of the law and the facts, she concluded that the evidential burden had been discharged
and that the prosecution had failed to disprove the statutory defence. Ms Campbell argued that this court
should be loath to overturn a robust assessment of the evidence as made in this case.

23. Ms Campbell submitted that the admissibility of the SCA decision does not arise in the appeal.
Pursuant to section 10 of the Criminal Justice Act 1967 it was admitted as a fact that the SCA had made a
conclusive grounds decision in M's favour, the minute of the decision being exhibited. It is said that it is not
open now for the Appellant to dispute its admissibility. Moreover, insofar as the judge relied on the
decision, it was only one factor in her decision. The circumstantial evidence available to her was more
than sufficient to discharge the evidential burden. Thus, it is unnecessary to resolve the question of the
admissibility of the SCA decision.

24. Ms Campbell argued in the alternative that, if it is necessary for the court to determine the issue of
admissibility of the SCA decision, the correct conclusion is that the decision was and is admissible. She
relied on these matters. First, the SCA is the agency vested with the responsibility of determining whether
a person has been trafficked. The agency is an expert case-working unit staffed by trained officials with
access to multi-agency sources. Second, in the abuse jurisdiction SCA decisions are admitted and
afforded weight. It would be an affront to withhold a decision of the SCA from a factfinder when the
prosecution is challenging the conclusion reached by the SCA. Third, SCA decisions are admitted by the
Court of Appeal Criminal Division and various statutory tribunals in the context of a factual decision in
relation to a person's trafficked status. There is no reason why they should not similarly be admissible in a
criminal trial when that status is in issue. Fourth, expert evidence can be based on a body of experience of
the kind available to an SCA decision maker. Ms Campbell submitted that police officers who provide
evidence about methods of drug dealing or the organisation of gangs provide expert evidence. The SCA
decision maker falls into the same general category of expertise.  Finally, Ms Campbell argued that the
consequence of the SCA decision being inadmissible would be delay and diversion of resources.
Disclosure from third parties would be required. Other evidence would have to be called. This would be
avoided by the admission of the SCA decision.

**The National Referral Mechanism**

25. In December 2008 the United Kingdom ratified the Council of Europe Convention on Action against
Trafficking in Human Beings (“ECAT”) with a view to its implementation with effect from 1 April 2009.
Article 10.1 of ECAT provides as follows:

_Each Party shall provide its competent authorities with persons who are trained and qualified in preventing_
_and combating trafficking in human beings in identifying and helping victims including children and shall_


-----

_ensure that the different authorities collaborate with each other as well as with relevant support_
_organisations, so that victims can be identified in a procedure duly taking into account the special situation_
_of women and child victims and, in appropriate cases, issued with residence permits under the conditions_
_provided for in Article 14 of the present Convention._

ECAT has not been incorporated into UK law but its obligations have been implemented by a variety of
measures. In order to meet its obligations under Article 10 of ECAT the UK Government created the
National Referral Mechanism. It has no legislative basis but is a set of administrative measures prescribed
by the Secretary of State. It provided for Competent Authorities responsible for making what were termed
conclusive decisions on whether a person had been trafficked for the purposes of exploitation. At that
point the Competent Authorities consisted of a unit within the National Crime Agency and units within the
Home Office Immigration and Visa Section. An initial referral of a potential victim of trafficking would be
made to a Competent Authority. Referrals would be made by an authorised first responder – police,
immigration officials, medical staff, local authority social services departments, specified voluntary
organisations. An official within the relevant unit would make a “reasonable grounds” decision i.e, a
determination that the person referred might have been trafficked. The Competent Authority having
notified the first responder and other interested parties of its reasonable grounds decision then would go on
to make a conclusive grounds decision. The conclusive grounds decision would be made applying the
balance of probabilities as the standard of proof.

26. The organisational position changed in April 2019 as described in the Home Office guidance issued in
May 2019.

_As part of the National Referral Mechanism Reform Programme, the Home Office launched the new Single_
_Competent Authority (SCA) on 29 April 2019. From this date, the SCA became responsible for all NRM_
_decisions regardless of an individual's nationality or immigration status. This expert case working unit sits_
_in the Home Office, and replaced the competent authorities previously located in UK Visas & Immigration,_
_Immigration Enforcement and the National Crime Agency. This change creates a single process for all_
_NRM referrals._

The system of a two-stage decision process did not change. The organisational change occurred shortly
before the referral in M's case which is why the decision in his case was made by the SCA.

27. Section 49(1) of the 2015 Act requires the Secretary of State to issue statutory guidance as follows:

_The Secretary of State must issue guidance to such public authorities and other persons as the Secretary_
_of State considers appropriate about—_

_(a) the sorts of things which indicate that a person may be a victim of slavery or human trafficking;_

_(b) arrangements for providing assistance and support to persons who there are reasonable grounds to_
_believe may be victims of slavery or human trafficking;_

_(c) arrangements for determining whether there are reasonable grounds to believe that a person may be a_
_victim of slavery or human trafficking._

The most recent iteration of the statutory guidance is dated April 2020. The statutory guidance does not
itself have the status of law but represents a formal statement of government policy and practice. The
guidance states that it is aimed both at those involved in making a referral to the National Referral
Mechanism and the decision makers within the Mechanism. The guidance refers to the decision makers
as “trained specialists”. Chapter 3 (Identifying potential victims of modern slavery) sets out indicators of
trafficking. The chapter is aimed at first responders and it provides a relevant check list. It may be a guide
to the factors considered by the SCA decision maker but it is not to be read as a comprehensive recitation
of the circumstances to be considered by such a decision maker. Annex E “provides detailed guidance for
staff at the SCA”. The Annex is concerned with the proper approach to decision making i.e. assessing
credibility, relevance of consistency, effect of gender and culture, appropriate sources of expert advice,
rather than an exposition of the factual matters which go to identifying a victim of trafficking. The published


-----

material allows the reader to understand the framework to be applied in any trafficking decision. It is not a
substitute for the experience of someone dealing with such decisions regularly.

**The Legal Framework**

28. This appeal concerns the application of the statutory defence in section 45 of the 2015 Act as follows:

(1) A person is not guilty of an offence if –

_(a) the person is aged 18 or over when the person does the act which constitutes the offence,_

_(b) the person does that act because the person is compelled to do it,_

_(c) the compulsion is attributable to slavery or to relevant exploitation, and_

_(d) a reasonable person in the same situation as the person and having the person's relevant_
_characteristics would have no realistic alternative to doing that act._

_(2) A person may be compelled to do something by another person or by the person's circumstances._

_(3) Compulsion is attributable to slavery or to relevant exploitation if –_

_(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes_
_relevant exploitation, or_

_(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant_
_exploitation._

_(4) A person is not guilty of an offence if –_

_(a) the person is under the age of 18 when the person does the act which constitutes the offence._

_(b) the person does that act as a direct consequence of the person being, or having been, a victim of_
_slavery or a victim of relevant exploitation, and_

_(c)  a reasonable person in the same situation as the person and having the person's relevant_
_characteristics would do that act._

_(5) For the purposes of this section –_

_'relevant characteristics' means age, sex and any physical or mental illness or disability;_

_'relevant exploitation' is exploitation (within the meaning of section 3) that is attributable to the exploited_
_person being, or having been, a victim of human trafficking._

We are concerned with section 45(4) of the 2015 Act. It requires consideration of whether there was
exploitation within the meaning of sections 2 and 3 of the Act, the relevant sub-sections being as follows:

_Section 2_

_(1) A person commits an offence if the person arranges or facilitates the travel of another person (“V”) with_
_a view to V being exploited._

_(2) It is irrelevant whether V consents to the travel (whether V is an adult or a child)._

_(3) A person may in particular arrange or facilitate V's travel by recruiting V, transporting or transferring V,_
_harbouring or receiving V, or transferring or exchanging control over V…._

_Section 3_

_(1) For the purposes of section 2 a person is exploited only if one or more of the following subsections_
_apply in relation to the person.…._

_(5) The person is subjected to force, threats or deception designed to induce him or her—_

_(a) to provide services of any kind,_

_(b) to provide another person with benefits of any kind or_


-----

_(c) to enable another person to acquire benefits of any kind._

_(6) Another person uses or attempts to use the person for a purpose within paragraph (a), (b) or (c) of_
_subsection (5), having chosen him or her for that purpose on the grounds that—_

_(a) he or she is a child, is mentally or physically ill or disabled, or has family relationship with a particular_
_person, and_

_(b) an adult, or a person without the illness, disability, or family relationship, would be likely to refuse to be_
_used for that purpose._

In this case the issue was whether someone had recruited M and thereby facilitated his travel with a view
to M providing services in the context of illicit drugs and any associated weapon. Because M was under 18
it was not necessary for him to show any force, threats or deception being used to induce him to provide
services. Rather, the question was whether he had been chosen because he was a child and an adult
would have been likely to refuse to provide the services.

29. The 2015 Act came into force on 31 July 2015. Prior to that there was no statutory provision which
transposed into the law of England and Wales the obligations of the UK under international conventions
relating to human trafficking where there was a nexus between the commission of a crime and the
trafficking. Those obligations were given effect by a series of decisions of the Court of Appeal Criminal
Division and the proper exercise of prosecutorial discretion by the Crown Prosecution Service. The legal
regime established thereby is summarised in Joseph and others at [20].

30. It is not necessary for us to rehearse the regime in any detail, not least because it has been replaced
by the 2015 Act. In brief, the criminal court's role was to police the exercise of prosecutorial discretion
when a defendant had been trafficked for the purpose of exploitation and there was a nexus between the
trafficking and the commission of the crime. Where the Crown Prosecution Service failed to give proper
consideration to the effect of trafficking, the court would exercise its power to stay the proceedings. The
power would not be exercised in the absence of a nexus between the offence and the trafficking. Even if
there were a nexus, the appropriateness of prosecution would depend on factors such as the gravity of the
offence and the degree of continuing compulsion.

31. The starting point for any consideration by a court of whether proceedings should be stayed would be
whether the defendant had been trafficked for the purposes of exploitation. The status of a conclusive
grounds decision was discussed in R v L(C) [2013] 2 Cr. App. R. 23 at [28]:

_Neither the defendants nor the interveners accept that the conclusive decision of UKBA (or whichever_
_department becomes a competent authority for these purposes) is determinative of the question whether or_
_not an individual has been trafficked. They, of course, are concerned with the impact of a decision adverse_
_to the individual. We are asked to note that the number of concluded decisions in favour of victims of_
_trafficking is relatively low, and it seems unlikely that a prosecutor will challenge or seem to disregard a_
_concluded decision that an individual has been trafficked, but that possibility may arise. Whether the_
_concluded decision of the competent authority is favourable or adverse to the individual it will have been_
_made by an authority vested with the responsibility for investigating these issues, and although the court is_
_not bound by the decision, unless there is evidence to contradict it, or significant evidence that was not_
_considered, it is likely that the criminal courts will abide by it._

This point was reinforced in _Joseph and others_ at [20(vii)] as rehearsed by the District Judge. It is
important to recall that the context of what was said about a conclusive grounds decision in these cases
was the exercise by a judge of their abuse of process jurisdiction. The court in each case was not
considering admissibility in the context of a jury trial.

32. In relation to the position as it applied prior to the 2015 Act the most recent authority of the Court of
Appeal Criminal Division is _R v S(G)_ [2018] EWCA Crim 1828; [2019] 1 Cr. App. R. 7. S had been
convicted in November 2007 of importing a Class A drug and had been sentenced to 7 years'
imprisonment. She appealed some 9 ½ years out of time on the basis that no consideration was given at
the time of her trial to her status as a trafficked person and its effect on her criminal liability. One limb of


-----

her case was that a Competent Authority in 2015 had made a conclusive grounds decision that she had
been trafficked and that she was a victim of forced labour. This decision had followed a First-tier Tribunal
(FTT) judgment to the same effect in immigration proceedings.

33. The court in S(G) was asked to admit the FTT judgment and the conclusive grounds decision as fresh
evidence pursuant to section 23 of the Criminal Appeal Act 1968. The evidence was so admitted. Gross
LJ said this at [68]-[69]:

_68 Applying s.23 of the 1968 Act, the receipt of this material is expedient in the interests of justice. Its_
_essence is the recognition, essentially undisputed by the Crown, that the defendant was a VOT. It would_
_not be in the interests of justice to proceed with the application (and any appeal) without having regard to_
_the FTT Decision and the CA Minute to this effect. The evidence is capable of belief; it may afford a ground_
_for allowing the appeal; it post-dates the trial and so could not have been adduced at trial._

_69 Before us, no question arises as to the admissibility of these materials as such. That is not the case as_
_to their admissibility at trial, where, to put it no higher, the admissibility of both the decisions in question_
_and the underlying reasoning must be regarded as unlikely on what may be broadly (if very loosely)_
_described as Hollington v F. Hewthorn & Co Ltd [1943] K.B. 587grounds. That said:_

_i) had the FTT Decision and the CA Minute been available at the time of trial, we regard it as_
_overwhelmingly likely that, in the interests of justice and fairness, the Crown would have been required to_
_make admissions as to their recognition of the defendant as a VOT—so that, in practical terms, any_
_admissibility difficulties at trial would have been resolved; and_

_ii) whatever the difficulties of admissibility at trial, we would not regard them as outweighing our conclusion,_
_on the basis of all the other relevant factors for the purposes of s.23, that the materials comprising the first_
_part should be admissible before us. We proceed accordingly._

34. It follows that the admissibility in a trial of a conclusive grounds decision of the SCA was not clearly
and finally determined in the authorities concerned with cases prior to the introduction of the statutory
defence. Those authorities concerned the exercise of the power to stay proceedings. By definition that
exercise could not involve a jury considering any evidence. In S(G) it was regarded as unlikely that either
the conclusive grounds decision or its underlying reasoning would be admissible at trial despite the fact
that the decision had been received as fresh evidence which may afford a ground for allowing the appeal.
It was said that the issue of admissibility in practical terms would not have arisen because the prosecution
would have been required to make admissions as to their recognition of the appellant as a victim of
trafficking. Arguably it is not clear how the prosecution could have been so required were their case to
have been that the appellant was not a victim of trafficking though this was put forward as the means by
which to admit the Competent Authority's decision at trial. In the result the court in _S(G)_ found that the
appellant had not been subjected to such a degree of compulsion as to excuse her from criminal liability.
That was the point argued by the prosecution notwithstanding its acceptance of the content of the
conclusive grounds decision in relation to the trafficked status of S. The conclusive grounds decision did
not purport to determine the issue of whether the status of the trafficked person absolved them from
criminal responsibility.

35. The first appellate consideration of a conclusive grounds decision in the context of the statutory
defence under the 2015 Act came in _R v N [2019] EWCA Crim 984. N was an adult. He had pleaded_
guilty in July 2016 at the Crown Court to an offence of production of cannabis. He was sentenced to a
short period of imprisonment. Following sentence he was given notice of deportation. He appealed
approximately 22 months out of time. By then N had made an asylum claim which had been allowed by
the First-tier Tribunal. The Tribunal's decision included a finding that N was a victim of trafficking, that
finding being based on a conclusive grounds decision of the Competent Authority. In his appeal N applied
to adduce the conclusive grounds decision as fresh evidence supporting a statutory defence under the
2015 Act. In his case the defence was said to arise under section 45(1), N being an adult. Pursuant to
section 23 of the Criminal Appeal Act 1968 the Court of Appeal received that decision together with the
Tribunal decision. The judgment at [8] states simply “….The documents are relevant and admissible.”


-----

36. The court in R v N allowed the appeal. The reasoning was as follows: there was no dispute but that N
was a victim of trafficking at the time of his offence; this was not recognised by anyone at the time of
conviction and sentence; had the matter been properly investigated there would have been a referral under
the National Referral Mechanism which would have led to a conclusive grounds decision in N's favour; on
receipt of that decision the prosecution would have decided that they could not defeat the statutory defence
and they would have offered no evidence. Thus, the court did not have to consider how the material would
have been admissible at trial. It was admissible in the appeal to show how the case would have proceeded
had it been available at the time of the conviction. It was unnecessary to consider how the conclusive
grounds decision might have been admitted before the jury because the case never would have proceeded
that far.

37. The only other appellate consideration of section 45 which is of any possible assistance is _R v DS_

_[2020] EWCA Crim 285. DS was 17 in July 2018 when allegedly he was in possession of drugs with intent_
to supply. The 2015 Act was in force. The statutory defence applicable to him, like M, was as set out in
section 45(4). However, in the Crown Court DS applied prior to the trial to stay the proceedings as an
abuse of process. His case was that he was a homeless young person who was exploited by a “county
line” drug dealing network. The SCA had made a conclusive grounds decision that he was a victim of
trafficking. N argued that he should not have been prosecuted. The judge in the Crown Court acceded to
the defence application and stayed the proceedings by reference to the regime summarised in Joseph and
_others. The prosecution appealed this terminating ruling._

38. The court allowed the prosecution's appeal for the reasons summarised at [40].

_In our judgment, the result of the enactment of the 2015 Act and the section 45 statutory defence is that the_
_responsibility for deciding the facts relevant to the status of DS as a Victim of Trafficking is unquestionably_
_that of the jury. Formerly, there was a lacuna in that regard, which the courts sought to fill by expanding_
_somewhat the notion of abuse of process, which required the Judge to make relevant decisions of fact._
_That is no longer necessary, and cases to which the 2015 Act applies should proceed on the basis that_
_they will be stayed if, but only if, an abuse of process as conventionally defined is found. By way of_
_summary only, this involves two categories of abuse, as is well known. The first is that a fair trial is not_
_possible and the second is that it would be wrong to try the defendant because of some misconduct by the_
_state in bringing about the prosecution. Neither of these species of abuse affected this case, and it should_
_not therefore have been stayed._

The outcome of the appeal did not require the court to address the nature of the evidence which might be
relevant and admissible in the trial. All that was decided was that DS should be tried. The question of how
the statutory defence was to be approached evidentially did not arise. It was said that the Crown
Prosecution Service guidance properly reflects the law. That guidance requires the prosecution to take
account of a conclusive grounds decision of the SCA when deciding whether a defendant is a victim of
trafficking and whether their status has a close nexus to the offending. Equally, the prosecution can and
should examine the cogency of the evidence on which the SCA had relied. This guidance is concerned
with the pre-trial prosecutorial decision.

39. As to the admissibility of the conclusive grounds decision at trial the court in DS said this at [43]:

_Whether the decision of the Authority is admissible at all before the jury is an issue which has been briefly_
_canvassed before us, but we do not think it is right for us to express any view. This is an appeal under_
_[section 58 of the Criminal Justice Act 2003 and the issue we have to decide, and the only issue we can](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9KP0-TWPY-Y0D5-00000-00&context=1519360)_
_properly decide, is whether the decision to stay these proceedings (a) was wrong in law, or (b) involved an_
_error of law or principle, or (c) was a ruling that it was not reasonable for the Judge to have made. He was_
_not asked to rule on this admissibility issue, and we ought not to do so either._

Thus, there is no authoritative guidance as to the admissibility of a conclusive grounds decision of the SCA
in a trial where the defendant seeks to raise the statutory defence in section 45 of the 2015 Act.

40. A positive conclusive grounds decision of the Competent Authority may be relevant in immigration
proceedings in the Immigration and Asylum Chamber whether in the First Tier Tribunal or in the Upper


-----

[Tribunal e.g. where a protection claim under the Nationality, Immigration and Asylum Act 2002 is in issue.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)
The proper approach to such a decision in the Immigration and Asylum Chamber was considered by the
President of the Chamber sitting with two Upper Tribunal judges in DC(Albania) [2019] UKUT 00351 (IAC)
at [36]:

_Where the CA has made a positive “conclusive grounds” decision, this will point strongly in the appellant's_
_favour in the protection appeal, given the higher standard of proof applied by the CA in coming to that_
_decision. But….it will not necessarily be determinative. The evidence before the tribunal may, for example,_
_show that the appellant has lied because it has subsequently emerged he was fingerprinted in Greece at a_
_time when, according to the appellant's account, he was being trafficked in Afghanistan._

The President made clear that the same rationale applied to a negative conclusive grounds decision i.e.
such a decision would not prevent the claimant from establishing by other evidence that, contrary to the
view of the Competent Authority, they had been trafficked. However, a positive conclusive grounds
decision was admissible in the tribunal's fact finding exercise in relation to trafficking in the protection
appeal.

41. In MS (Pakistan) v Secretary of State for Home Department _[2020] UKSC 9 the Secretary of State had_
refused MS's application for asylum and made a removal direction. Prior to the Secretary of State's
decision the Competent Authority had made a negative conclusive grounds decision in relation to the
question of whether MS had been trafficked. MS appealed against the Secretary of State's decision. In
allowing his appeal, the Upper Tribunal decided that it was entitled to make its own decision in relation to
MS's trafficked status. The Court of Appeal in 2018 held that the tribunal could only go behind the
Competent Authority's decision if it was perverse or irrational in public law terms.

42. Before the Supreme Court the Secretary of State did not support the conclusion of the Court of
Appeal. As Lady Hale observed at [11]:

“…it is now common ground that the tribunal is in no way bound by the decision reached under the NRM,
_nor does it have to look for public law reasons why that decision was flawed.”_

The Supreme Court agreed with the position that had been reached by the parties. Lady Hale said at [15]:

_“…The decision of the competent authority under the NRM process was an essentially factual decision_
_and, for the reasons given, both the FTT and the UT were better placed to decide whether the appellant_
_was the victim of trafficking than was the authority. The more difficult question is the precise relevance of_
_that factual determination to the appeal before the tribunals.”_

This “more difficult question” was not addressed further by the Supreme Court since it was not necessary
for the resolution of the appeal before the court. In consequence, we are not assisted by any general
consideration of the admissibility of an SCA decision by the Supreme Court.

**Discussion**

Admissibility of SCA conclusive grounds decision

43. For the reasons set out at paragraph 23 above Ms Campbell argued that it is not necessary for us on
the facts of this case to determine the issue of admissibility of the SCA decision. We are not persuaded by
the second limb of Ms Campbell's argument. The case stated makes it clear that the District Judge took
account of the SCA decision. Moreover, immediately before she set out her final determination, she
recited the decision's core finding i.e. that M was a victim of criminal exploitation. It may be that the judge's
determination would have been the same irrespective of her consideration of the SCA decision. That is a
question to which we shall return. However, the issue of admissibility does arise given the terms of the
judge's decision making process as revealed in the case stated.

44. The point made by Ms Campbell in relation to the section 10 admission is problematic. Section 10(1)
of the 1967 Act is in these terms:


-----

_Subject to the provisions of this section, any facts of which oral evidence may be given in any criminal_
_proceedings may be admitted for the purpose of those proceedings by or on behalf of the prosecutor or_
_defendant, and the admission by any party of any such fact under this section shall as against that party be_
_conclusive evidence in those proceedings of the fact J._

The relevant admission made in the proceedings before the District Judge was as follows:

_On 21 August 2019 the SCA made a positive conclusive grounds decision and drafted a positive_
_conclusive grounds minute which is exhibited. This states at page 3: “To the balance of probabilities it is_
_accepted that you were recruited, harboured and transported for the purposes of criminal exploitation.”_
_The box on forced criminality is ticked._

On the face of it the only fact admitted was that the SCA had made a positive conclusive grounds decision
on the basis of the matter set out in a minute. It said nothing about the substance of the decision. It said
nothing about what the effect of the mere fact of the decision should be. Mr Douglas-Jones argued that the
prosecution at trial made it clear that the facts on which the decision was based were agreed but the
decision itself was not. The argument does not sit easily with the terms of the admission. The District
Judge in the case stated recorded the prosecution position as agreeing the facts upon which the decision
was made and agreeing the fact that a decision was made. What the prosecution did not agree was that
the decision was correct. We find that the admission left ambiguous the status of the SCA decision. On
the fact of it, if it was admitted as a fact that the decision was made, that must have involved admission in
evidence of the decision i.e. that M was a victim of criminal exploitation. That would not prove M's status
but it would be relevant and probative evidence on the issue. Yet the Judge's understanding of the position
is not consistent with that analysis. It is regrettable that the status of the SCA decision was not made clear
in the admission. Given the ambiguity we consider that we cannot accept Ms Campbell's submission and
avoid consideration of the admissibility of the decision on the basis that it was not contented by the
prosecution in the court below.

45. The core submission of the Appellant is that the SCA decision is non-expert opinion evidence. As
such it is not admissible. We do not understand Mr Douglas-Jones to have argued that expert evidence is
inadmissible per se on the question of trafficking or exploitation. Whether a person is a victim of
exploitation is a question of fact. It is not something which is immediately identifiable such as the colour of
a person's hair. Therefore, the fact finder in a criminal case will require evidence to assist in determining
the fact. Expert evidence is admissible when the subject matter is something on which the ordinary person
without particular experience in the relevant area could not form a sound judgment without the assistance
of a witness with such experience. The factors relevant to trafficking or exploitation are not necessarily
within the knowledge of the ordinary person. Expert evidence on which factors are relevant must be
admissible.

46. Moreover, assessment of the significance of a given set of factors present in a particular case may
properly be the subject of expert evidence. A person with the necessary expertise can give context to the
factors by reference to their wider experience of other cases. This may involve the expert giving evidence
on one of the issues in the case i.e. is the defendant a victim of trafficking or exploitation? Even if it is the
ultimate issue – which in most instances it will not be given the other limbs of the statutory defence – the
expert will be entitled to give the evidence. That occurs in many cases of homicide where the issue is
diminished responsibility. A psychiatric expert will give an opinion on whether the defendant's
responsibility was substantially diminished by his abnormal mental functioning and whether this was a
significant cause of the defendant acting as he did.

47. In the course of the hearing we asked whether an SCA decision that a person was or was not a victim
of trafficking or exploitation could be treated as analogous to a _Merton compliant age assessment as_
carried out in accordance with the guidance in B v Merton Borough Council [2003] 4 All ER 480. Such an
assessment will be carried out by two social workers who “should be properly trained and experienced”
(Home Office guidance “Assessing Age”). A Merton compliant age assessment involves the social workers
considering a variety of material including hearsay evidence and circumstantial evidence. The social
workers will reach a conclusion as to the person's age. The professional training of social workers does


-----

not give them any particular expertise in assessing age. Rather, it is the fact that they have had some
training in the relevant factors to be considered and they have experience in conducting assessments by
reference to the guidance which provides their expertise in this context.

48. Where age is in issue in relation to anyone brought before a criminal court, the court is obliged to
make “due inquiry” as to the age of the person: section 99 Children and Young Persons Act 1933. In
practical terms the “due inquiry” in any criminal proceedings very often will be to commission a _Merton_
compliant age assessment. An age assessment of this kind will be admissible in a court as evidence of
age when the court is determining the proper venue for the proceedings and venue is to be determined by
the age of the defendant: _M v Hammersmith Youth Court_ _[[2017] EWHC 1359 (Admin). The age](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NTV-JXY1-F0JY-C125-00000-00&context=1519360)_
assessment will not necessarily be determinative but it is nonetheless admissible. Where the age of a
defendant is in issue in the Crown Court, this will usually be in the context of sentencing. The issue of age
will be determined by the judge. The judge will admit the evidence of a Merton compliant age assessment.

49. Mr Douglas-Jones and Ms Campbell each provided helpful written submissions in relation to the status
of age assessment evidence. Mr Douglas-Jones argued that such evidence will only be admitted before
any trial in order to resolve the question of age. There is an analogy to be drawn with SCA decisions but
that is because SCA decisions similarly will only be admitted pre-trial when considering issues of abuse.
He submitted that age assessments are not admissible before a jury or other tribunal of fact. If age is
relevant in the fact finding exercise, it must be dealt with by the calling of relevant and admissible evidence.
This may be the same evidence as was considered in the _Merton compliant age assessment but the_
assessment itself is not admissible.

50. Ms Campbell also argued caution in drawing any parallel between age assessment evidence and SCA
decisions albeit for different reasons. She invited us to conclude that social workers conducting _Merton_
compliant age assessments have significantly less expertise than decision makers responsible for SCA
decisions. Thus, such assessments do not amount to expert evidence on the issue of age. She also
agreed with Mr Douglas-Jones when he argued that age assessments have a part to play in pre-trial
proceedings but not in any trial.

51. Neither Mr Douglas-Jones nor Ms Campbell pointed us to any authority where age had been in issue
at the trial and the admissibility of a Merton compliant age assessment had been considered. Clearly it is
not for us to determine whether a Merton compliant age assessment is admissible in a criminal trial. The
question does not arise in these proceedings. Nonetheless, we consider it appropriate to observe that,
although age usually is an issue which arises pre-trial, there are cases where age is a relevant fact to be
proved as one of the elements of the offence charged. Where the person concerned was born in and has
been domiciled at all times in the UK, proof by a variety of documentary means will be possible. That will
not apply if the person originates from a country with poor or non-existent public record keeping. In those
cases, it seems perverse that the fact finder should be deprived of the outcome of a detailed assessment
prepared by those with expertise (and we make clear that we do not accept Ms Campbell's point on the
comparative lesser expertise of social workers) when it may be impossible for the fact finder to form a
sound judgment without such evidence.

52. One objection Mr Douglas-Jones raised to the SCA decision was that, even if it could be regarded as
expert evidence, it depended on facts which could only be established by M giving evidence. He drew a
parallel with psychological or psychiatric evidence. We do not consider that this parallel was apposite
other than to demonstrate that his objection was erroneous. In _Bradshaw_ (1986) 82 Cr App R 79 the
position was explained thus:

…if the doctor's opinion is based entirely on hearsay and is not supported by direct evidence, the judge will
_be justified in telling the jury that the defendant's case (if that is so) is based upon a flimsy or non-existent_
_foundation and that they should reach their conclusion bearing that in mind._

This indicates that psychiatric evidence unsupported by direct evidence will be of little weight. It does not
mean that the evidence cannot be admitted. Brennan [2015] 1 WLR 2060is an example of a case in which
the defendant said nothing to the police in interview and did not give evidence. The unchallenged
psychiatric evidence supported a plea of diminished responsibility that evidence in part being based on


-----

what the defendant had told the psychiatrist. The conviction for murder was quashed by the Court of
Appeal Criminal Division. The precise basis for the conviction being quashed is irrelevant. What matters is
that an expert may base her report in part on hearsay evidence from a witness who could give evidence at
the trial.

53. We acknowledge that the SCA decision maker will not have prepared their minute of decision with a
view to its being used as expert evidence. That does not of itself prevent its admission in criminal
proceedings. The decision maker is always acting under a duty and will be aware of the likelihood that the
conclusive grounds decision will be used in proceedings of some kind, whether in a court or a tribunal. We
further acknowledge that the SCA decision maker will not have anticipated giving evidence in relation to
their conclusive grounds decision. In that context we see the force in the observations of Gross LJ in S(G)
as cited above. In practical terms the minute of the SCA decision will be introduced by an agreed fact –
which of course is what apparently happened in this case. That route involves an acceptance that the
decision is admissible.

54. We consider that the District Judge was entitled to receive and admit the findings of the SCA as
evidence that M had been recruited and harboured such that he had been trafficked within the meaning of
the 2015 Act and that he was a victim of criminal exploitation. The SCA decision maker had expertise in
relation to those issues. The judge was entitled to consider the findings and assess the extent to which
they were supported by evidence. Insofar as appropriate, she would have been able to reduce the weight
she gave to the findings. However, that is a question of weight rather than admissibility. In fact, the SCA
decision was based on a proper evidential foundation and it was not contradicted by other material
available to the judge.

55. In his skeleton argument Mr Douglas-Jones stated that, if an SCA decision were to be admissible in a
trial in relation to the application of the statutory defence in any given cases, this would have “significant
implications in terms of prosecutorial practice”. We do not agree. The weight of a conclusive grounds SCA
decision will vary. The prosecutor will be in a position to assess the weight of the decision just as the
prosecutor can assess the weight of other evidence relevant to the issue of a defendant's status as a victim
of trafficking or exploitation. The decision made by a prosecutor as to whether the defendant has satisfied
the evidential burden and, if so, whether the prosecution can disprove the statutory defence will depend on
an assessment of all of the available material. As the facts of this case amply demonstrate, a conclusive
grounds decision will not be determinative in the criminal context any more than it is in tribunal
proceedings.

The decision of the District Judge

56. Irrespective of the admissibility of the SCA decision, the question posed in the case stated is whether
M had sufficiently discharged the evidential burden in relation to the two elements of the statutory defence:
whether he committed the offences as a direct consequence of being a victim of exploitation; whether a
reasonable person in his position would have committed the offences. It should be noted that the SCA
decision could not and did not address the second element at all. The decision did not reach any direct
conclusion as to whether the offences were a direct consequence of M being a victim of exploitation. It is
not the function of the SCA to consider the consequences of a person being a victim of exploitation.

57. Mr Douglas-Jones contended that the District Judge had no more than generalised hearsay evidence
which did not go to M's specific circumstances. There was no satisfactory evidence of the offending being
the consequence of any exploitation or of the offences being ones which a reasonable person in M's
position would have committed. In respect of the latter point, the Appellant argues that the evidential
burden is particularly high where “the acts comprise the possession of a perniciously dangerous knife in a
public place (a family restaurant) and perniciously dangerous drugs for the purposes of supply (again in a
family restaurant).”

58. We do not accept that the evidence available to the District Judge on the two issues where it is said
that M could not satisfy the evidential burden was purely general in nature. The relevant direct evidence
was as follows: M was a missing child; he was in an area with which he had no connection; he had no


-----

previous convictions; he was with two boys with a significant criminal history involving drugs and knives.
This was not hearsay evidence. The hearsay evidence described M's troubled background by reference to
local authority and police records. The records were admissible under section 117 of the Criminal Justice
Act 2003.

59. The evidence showed that M travelled to Tooting when he had no apparent reason for doing so. As a
matter of fact he was in company with two boys with a history of criminal behaviour. There was sufficient
to allow the inference that M's presence in Tooting had been facilitated by them with a view to him being
exploited. The fact that M was in possession of the very kind of item which might be expected to be in the
possession of MP and/or KM when neither of them had a knife or any Class A drugs gave rise to an
inference that his offending was a direct consequence of his exploitation by MP and/or KM. It was for the
prosecution to disprove that inference. The matters relied on by the prosecution did not displace the
inference. The lying explanations given by M for his possession of the knife did not displace the conclusion
that he had been exploited. The child who is an exploited victim of trafficking may well realise that he has
committed an offence and, if apprehended, may try and avoid what he believes is his criminal liability. That
is of little consequence in determining whether the child has been exploited. The behaviour of M after his
arrest might have been of significance if he had been an adult and he had been relying on the statutory
defence in section 45(1) in the 2015 Act i.e. compulsion had been an element of the defence. Since he
was a child and had been exploited as such, his behaviour in relation to those by whom he had been
exploited was of marginal relevance.

60. Having determined that M had discharged the evidential burden in relation to the statutory defence the
District Judge was entitled to conclude on the basis of the evidence she had that M was a victim of
exploitation and that his offending was a direct consequence of that status. Her conclusion that the
prosecution had failed to prove the contrary was fully justified.

61. The District Judge concluded that the evidence was sufficient to discharge the evidential burden as to
whether a reasonable 15-year-old in the same situation as M would have had possession of the knife and
the drugs. As set out in the case stated the basis on which she did so was that M was only just 15 at the
time of the offences. The Appellant argues that this was a slender basis on which to reach that conclusion
given the seriousness of the offences. We accept that considering M's age in isolation would not be
sufficient. Section 45(4) of the 2015 Act can only apply if the defendant is under the age of 18. Whilst age
is significant, it must be considered in the light of the other available evidence. One could envisage a case
involving a 15 year old of maturity and intelligence from a settled background where, even though there
was evidence of exploitation, a person of that age in his situation would not commit criminal offences. In
fact, the judge in this case took into account the entirety of the evidence of M's background. She may not
have set it out again in the case stated when dealing with the question of the reasonable person. We are
satisfied that the judge had in mind all relevant matters appertaining to M's situation when making her
decision in relation to what a reasonable person would have done.

62. We accept that the seriousness of the offences will be a significant consideration when determining
what a reasonable person would have done where the defendant is an adult. The statutory defence in the
case of an adult as set out in section 45(1) of the 2015 Act involves compulsion. Moreover, the reasonable
person in section 45(1) (d) would have “no realistic alternative” to committing the crime. Those factors are
substantially a carry-over from the common law abuse jurisdiction where the seriousness of the offence
was of substantial relevance. Although the seriousness of the offence is not irrelevant where the
defendant is a child, it is of less significance. Even if he is a victim of exploitation, an adult is likely to have
an appreciation of the consequences of his actions whereas a child is more likely to behave without a
proper understanding of the nature and consequences of his actions. The Sentencing Council Guideline
Sentencing Children and Young People provides a full exposition of the factors affecting children as
offenders which it is unnecessary for us to do more than reference.

63. Mr Douglas-Jones's description of the offences with which M was charged overstates the case. He did
not have possession of Class A drugs with intent to supply, at least that it is not the offence with which he
was charged. The knife was undoubtedly dangerous. Whether the use of the term “perniciously” adds to
the case we doubt Sadly the carrying of knives by young men in South London is very widespread It is a


-----

serious offence to carry a knife. But the context in which M as a victim of exploitation had possession of
the knife was rather different in terms of his culpability.

64. The question posed in the case stated asks if M had sufficiently discharged the evidential burden. We
are satisfied that the answer to that question is yes. The Appellant invites us to go on to say that, even if
the evidential burden on M was discharged, the evidence was sufficient to discharge the legal burden on
the prosecution to disprove the statutory defence. That is not a matter raised by the case stated. Nor is it
raised in the grounds of appeal. Nonetheless we are satisfied that the evidence before the District Judge
was sufficient to justify her conclusion that the statutory defence had not been disproved.

65. Finally, Ms Campbell invited us to make an order anonymising the proceedings on an indefinite basis
under s. 11 of the Contempt of Court Act 1981, given M's age and the fact that the current order under s.45
of the Youth Justice and Criminal Evidence Act 1999 will cease to apply in 15 months.

66. We bear in mind the importance of the principle of open justice. We have concluded that such an order
should be made as being both necessary and proportionate. In reaching that conclusion we have regard to
M's current circumstances as a recognised victim of trafficking who has been acquitted of the criminal
charges brought against him. He is vulnerable and we accept that certain aspects of the information
referred to in the case papers, in the SCA's decision and alluded to above, raise sensitive, personal issues
bearing on his Article 8 rights. Having regard to the considerations identified in the authorities we have
concluded that it is necessary in the interests of justice for anonymity to be maintained indefinitely in all the
circumstances of this case, and make the order sought.

_._

**End of Document**


-----

