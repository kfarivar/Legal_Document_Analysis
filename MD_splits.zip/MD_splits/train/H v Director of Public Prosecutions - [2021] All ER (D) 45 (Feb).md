# H v Director of Public Prosecutions [2021] All ER (D) 45 (Feb)

[2021] EWHC 147 (Admin)

Queen's Bench Division (Divisional Court)

Lord Burnett CJ and Bryan J

29 January 2021

**Magistrates – Jurisdiction – Reopening case to rectify mistake etc.**
Abstract

_The appellant failed in his appeal, by way of case stated, against the district judge's decision to refuse the_
_[appellant's application for a direction that his case be heard again pursuant to s 142(2) of the Magistrates' Courts](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)_
_Act 1980. The appellant had entered unequivocal guilty pleas and had been sentenced by the Crown Court. He_
_[sought to set aside his guilty plea to enable him to adduce evidence and argue a defence under s 45 of the Modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
**_[Slavery Act 2015. In dismissing the appeal, the Administrative Court held that R v Douglas[2019] EWCA Crim 1545](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
_had established that once the Crown Court had passed sentence,_ _[MCA 1980 s 142(2) had no application. The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)_
_whole scheme of s 142 was to enable the magistrates' court to intervene when the impact of an order only affected_
_its own determinations._
Digest

The judgment is available at: [2021] EWHC 147 (Admin)

**Background**

The appellant, who was then 17, had entered unequivocal pleas of guilty before Canterbury Youth Court to offences
including possession of a bladed article (a knife) in a public place and possession of significant amounts of heroin
and cocaine with intent to supply (street dealing). He was committed to Canterbury Crown Court for sentence. A
pre-sentence report was obtained and on 2 August 2017, he was sentenced to a detention and training order of 18
months. In March 2018, the appellant was released from custody.

In April 2018, the National Crime Agency (the relevant body for the purposes of the legislation) reached a
'conclusive decision' (a term of art in the legislation) that he was the victim of modern slavery. That conclusion did
not bind the Crown Prosecution Service or a court. In May 2018, he was involved in an incident which led to
charges of dangerous driving and other related offences. The new offences were tried at the Crown Court and a
defence under s 45 of the **_[Modern Slavery Act 2015 was advanced. In April 2019, the jury returned a not guilty](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
verdict.

On the appellant's behalf, the Howard League for Penal Reform subsequently requested a retrospective National
Referral Mechanism assessment which was made and submitted by the Youth Offender Service. That was
concerned with aspects of **_modern slavery which could be separate from proceedings in a criminal court. The_**
appellant applied for a direction that his case be heard again pursuant to s 142 of the Magistrates' Court Act 1980
[(MCA 1980), which provided that a magistrates' court 'may vary or rescind a sentence or other order imposed or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJW0-TWPY-Y1F4-00000-00&context=1519360)
made by it when dealing with an offender if it appears to the court to be in the interests of justice to do so; ... (2)


-----

Where a person is convicted by a magistrates' court and it subsequently appears to the court that it would be in the
interests of justice that the case should be heard again by different justices, the court may so direct'.

The appellant submitted that it was in the interests of justice to have the earlier convictions set aside on the basis of
the decision that he was a victim of modern slavery and in the light of the subsequent acquittal in the Crown Court
on later charges. The judge concluded that he was being asked to use s 142 not to correct any error, defect or
mistake, but rather to exercise a general power of review, which he concluded was not permissible. He referred to
_R v Douglas [2019] EWCA Crim 1545 (R v D) as authority against the argument advanced by the appellant. He did_
not think that there had been an obvious injustice but would have reached the same conclusion if he thought
otherwise: there was an available remedy, namely an application to the Criminal Cases Review Commission.
Accordingly, the judge refused the application.

The appellant appealed by way of case stated. The judge stated two questions stated for the opinion of the High
Court.

**Issues and decisions**

[Whether the magistrates' court had any power to allow a plea of guilty to be vacated under MCA 1980 s 142 once](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)
the defendant had been sentenced in the Crown Court.

[The appellant submitted that the language of MCA 1980 s 142(2) was wide enough to encompass the mistake he](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)
contended for: the mistake had been his in failing to advance a defence in the Youth Court which had been
available to him. He submitted that the language of s 142 was wide enough for the effect of directing a new trial to
encompass setting aside the sentence subsequently imposed by the Crown Court.

_R v D had established that once the Crown Court had passed sentence,_ _[MCA 1980 s 142(2) had no](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)_
application. That was abundantly clear from the statutory language. The whole scheme of s 142 was to enable the
magistrates' court to intervene when the impact of an order only affected its own determinations. Section 142(A)
showed that a sentence imposed in the magistrates' court could not be varied or rescinded once a Crown Court had
determined an appeal against either sentence or conviction or there had been a determination of a case stated in
the High Court in connection with the case. _[MCA 1980 s 142(3) was to similar effect. The reference to the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)_
consequence of a direction under s 142(2) being that 'the conviction and any sentence or order imposed or made in
consequence thereof' was to no effect, in the context of that section, meant a sentence or order of the magistrates'
court. It was not accepted that Parliament had intended a mechanism designed to correct mistakes made in the
magistrates' court which could enable that court to set aside sentences imposed by the Crown Court or the Court of
Appeal: that was the position whether the court was dealing with an adult or a person under 18 (see [12] of the
judgment).

Further, the circumstances of the present case did not fall within the proper scope of s 142(2) at all. It would be
wrong to use s 142(2) to obtain a rehearing as a substitute to an appeal which a defendant was precluded by law
from pursuing. Those who unequivocally pleaded guilty in the magistrates' or Youth Court could appeal against
[conviction to the Crown Court. That was the effect of MCA 1980 s 108. A route to an appeal via the Criminal Cases](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJW0-TWPY-Y188-00000-00&context=1519360)
Review Commission was available (see [14], [15] of the judgment).

The answers to the questions posed by the judge were: (1) the magistrates' court had no power to allow a plea of
[guilty to be vacated under MCA 1980 s 142 once the defendant had been sentenced in the Crown Court; and (2)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)
the judge had been correct to refuse the application (see [13] of the judgment).

_R v Douglas_ _[[2019] EWCA Crim 1545 applied; Zykin v Crown Prosecution Service](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8WFG-YFK2-8T41-D1VB-00000-00&context=1519360)_ _[2009] EWHC 1469 (Admin) 173_
[JP 361 [2009] All ER (D) 303 (Oct) followed; R (on the application of Williamson) v City of Westminster Magistrates'](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7X09-RT00-Y96Y-H3SB-00000-00&context=1519360)
_Court_ _[2012] EWHC 1444 (Admin) [2012] 2 Cr App Rep 299 [2012] Crim LR 975_ _[[2012] All ER (D) 242 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55SD-GFV1-DYBP-N1YJ-00000-00&context=1519360)_
followed; R v Bolton Justices, ex p Scally; R v Bolton Justices, ex p Greenfield; R v Eccles Justices, ex p Meredith;
_R v Trafford Justices, ex p Durran-Jorda [1991] 1 QB 537_ _[[1991] 2 All ER 619 [1991] 2 WLR 239 considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-60RD-00000-00&context=1519360)_
_Skipaway Ltd v Environment Agency_ _[2006] EWHC 983 (Admin) [2008] LLR 178_ _[[2006] All ER (D) 68 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JST1-DYBP-N4V3-00000-00&context=1519360)_


-----

considered; Houston v Director Of Public Prosecution (2015) _[[2015] EWHC 4144 (Admin) considered; R v YY; R v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JGN-9471-F0JY-C1T2-00000-00&context=1519360)_
_Nori_ _[[2016] EWCA Crim 18 [2016] 1 Cr App Rep 435 [2016] All ER (D) 12 (Mar) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J6P-VDC1-DYBP-N2S6-00000-00&context=1519360)_

Francis FitzGibbon QC and Kate Aubrey-Johnson (instructed by the Howard League for Penal Reform) for the
appellant.

Benjamin Douglas-Jones QC and Andrew Johnson (instructed by Crown Prosecution Service) for the respondent.
Neneh Munu Barrister.

**End of Document**


-----

