# R v Kaminskas [2022] EWCA Crim 1905

Court of Appeal, Criminal Division

Macur LJ, Pepperall J, Ellenbogen J

8 December 2022Judgment

NON-COUNSEL APPLICATION

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

MR JUSTICE PEPPERALL:

1. On 24 July 2019, in the Crown Court at Northampton before Her Honour Judge Lucking KC and a jury,
the applicant was convicted of murder. He was sentenced to imprisonment for life and the judge directed
that he must serve a minimum term of 19 years less the 191 days that he had spent on remand. The
applicant now renews his applications for an extension of time, for leave to appeal against conviction and a
representation order following refusal by the single judge. The applicant is not represented and
accordingly his application has been considered on the papers by all three members of this Court.

**_The Facts_**

2. On 26 December 2018, the body of a Lithuanian national, Juosaz Meilunas, was found in an advanced

state of decomposition in a derelict flat in Kettering. Post‑mortem examination established that death had

been caused in around early October 2018 by blunt force injuries to the head. A table leg was found in the
flat. One end of the table leg contained areas of bloody skin and hair. Scientific analysis matched the skin
cells to the deceased's DNA profile. A second DNA profile matching the applicant was obtained from the
other end of the table leg.

3. The applicant, who was also a Lithuanian national, had been living at the flat during 2018. In police
interview, he said he had last lived at the flat in September 2018. He also said that he knew the deceased
but denied that he had killed him.

4. At trial, the prosecution relied on the following strands of evidence:

a. First, the evidence of the applicant's former partner that the applicant was living at the flat at the
relevant time;

b. secondly, cell-site evidence locating the applicant in Kettering at the relevant time;


-----

c. thirdly, the applicant's admission in interview with the police that he knew the deceased;

d. fourthly, the evidence of Kristina Lukosenkina, who identified the applicant as the man who had helped
up the deceased on 27 September 2018 after she had seen him fall over;

e. fifthly, evidence from the deceased's work place, his pattern of use of his mobile phone and from

post‑mortem examination that the deceased died in late September or early October 2018;

f. sixthly, scientific evidence linking both the applicant and the deceased to bloodstained clothing found at
the flat;

g. seventhly, the DNA evidence from the table leg;

h. eighthly, statements made by the applicant to two witnesses that there was a dead body in his flat and
to a third that he had killed a friend; and

i. ninthly, evidence that the applicant had used the deceased's bank card in the UK and in Lithuania.

5. In addition, the prosecution relied on bad character evidence that showed the applicant's propensity for
violence. First, the evidence of a former partner that in February to March 2017 the applicant had a short
temper, punched walls and hit her. Secondly, the evidence of Harry Rainbow of two incidents in February
and March 2018 when the applicant damaged cars, produced a knife when refused drugs by a dealer,
assaulted Mr Rainbow saying: "All I know is I need to kill you" before striking him to the back of the head
with a wine bottle. Thirdly, the evidence of Nigel Dexter that the applicant had attacked him shortly after
the wine bottle incident. And, fourthly, the applicant's convictions for criminal damage and battery in April,
May, June and August 2018.

**_The Appeal_**

6. In seeking leave to appeal against his conviction, the applicant takes the following points. First, that he
might have been the victim of "some sort of modern slavery". Secondly, that he is innocent. Thirdly, that
the prosecution witnesses had nothing to do with him for years. Fourthly, that he was badly represented
and the translator was "not working properly". The applicant, who elected not to give evidence at his trial,
is, he says, waiting to tell the court what happened and to prove his innocence. Fifthly, the applicant's
previous convictions were wrongly admitted in evidence. They were old convictions and their admission
was unfair because they were from a time when he was a different person. Sixthly, that the judge
misunderstood the applicant and made him "look bad" because she listened to other people talking about
him who did not know him. The witnesses were, he said, drug users who talked "nonsense". Seventhly,
that the witnesses gave evidence about things they could not have seen and that he is a good man, and
eighthly, that he did not understand much of his trial. All that happened, he said, was that the deceased
gave him his bank card and he then left and, when he returned, he found the deceased dead.

7. In view of the criticisms made of his legal representatives at trial, the applicant was invited to, and did,
waive his privilege. The responses from his former leading and junior counsel are contained in emails to
the Court and no additional response was made by his solicitors.

**_Discussion_**

8. This application was made 727 days out of time. In his grounds of appeal, the applicant states that
following sentence he was "stressed" and "needed time to calm down" and he was trying to get funding to
instruct a lawyer.

9. We are not satisfied that the applicant has established any good reason for such a long delay.
Nevertheless, we acknowledge that this is a case of the utmost gravity and that, if we conclude that the
appeal is properly arguable, it would be in the interests of justice to allow the appeal to be heard
notwithstanding the delay.

10. In refusing leave to appeal against conviction the single judge gave the following reasons:

i. "I have considered the papers in your case and your grounds of appeal.


-----

ii. Having seen the information provided by your counsel and solicitors, I see no arguable merit in your
suggestion that your solicitor did not represent you properly, or that the translator at trial did not do a good
job.

iii. I have considered the judge's ruling about your previous convictions and non‑conviction evidence, and

do not consider she was arguably wrong. This evidence was properly admitted in evidence because they
showed a propensity (tendency) for you to use physical aggression.

iv. Your other complaints indicate that you believe the jury made the wrong decision. However, that is not
a ground for an appeal, so long as the judge directed the jury properly, which in your case she did. The
evidence against you was strong.

v. I therefore do not consider it arguable that your conviction was unsafe."

**_Decision_**

11. We have carefully considered the grounds of appeal afresh. Having done so, we agree with the single
judge and conclude that for the reasons he gave there are no arguable grounds for appeal against
conviction. We therefore refuse the applications for an extension of time and for leave to appeal against
conviction.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

