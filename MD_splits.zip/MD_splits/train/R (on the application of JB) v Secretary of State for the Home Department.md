# R (on the application of JB) v Secretary of State for the Home Department

 [2021] EWHC 3417 (Admin)

Queen's Bench Division, Administrative Court (London)

Peter Marquand (sitting as a deputy judge of the High Court)

17 December 2021Judgment

**Chris Buttler QC and Ayesha Christie**

(instructed by Duncan Lewis Solicitors) for the Claimant

**Colin Thomann (instructed by Government Legal Department) for the Defendant**

Hearing dates: 7 October 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

……………………….

PETER MARQUAND

_Covid-19 Protocol: This judgment was handed down remotely by circulation to the parties' representatives_
_by email and release to Bailii. The date for hand-down is deemed to be on 17 December 2021._

**Peter Marquand:**

**Introduction**

1. The Claimant is a potential victim of **_modern slavery and an asylum seeker. During the Covid-19_**
pandemic he was in full board hotel accommodation. The issue to be determined is whether, on a proper
reading of the Defendant's policy on financial support to persons such as the Claimant, he was entitled to a
total payment of £65 per week inclusive of any financial support to which he was entitled as an asylum
seeker. The Defendant maintains that he was not entitled to that sum, but to a lesser amount.

**The Legal Framework**

2. I was referred to 2 authorities governing the proper interpretation by the court of policies such as those
at play in this case. It was agreed that a Wednesbury review by the court was not the right approach. In
_Regina (Raissi) v Secretary of State for the Home Department_ _[2008] EWCA Civ 72 the Court of Appeal_
was concerned with the interpretation of statements of policy in an ex-gratia compensation scheme and its
application to a person who had been detained in custody following a serious default on the part of the
detaining authorities. The Court of Appeal concluded that the appropriate test to interpret a policy
statement was what would be “a reasonable and literate” person's understanding of the policy (paragraphs


-----

108 and 123 of the judgment). Mr Thomann drew my attention to paragraph 121 where the Court of
Appeal commented on the judgment of Lord Bingham in re McFarland [2004] 1 WLR 1289:

“Lord Bingham, it could be said, was doing no more than interpreting the document in accordance with the
presumed intent of the maker, with the courts deciding what that intent was.”

3. Before the Supreme Court in _Mahad v Entry Clearance Officer_ _[2009] UKSC 16, there was no real_
dispute on the proper approach to the interpretation of statements of administrative policy in the
Immigration Rules. Lord Brown of Eaton-Under-Heywood JSC set out the position at paragraph 10 of the
judgment:

“Essentially it comes to this. The Rules are not to be construed with all the strictness applicable to the
construction of a statute or a statutory instrument but, instead, sensibly according to the natural and
ordinary meaning of the words used, recognising that they are statements of the Secretary of State's
administrative policy.”

The intention of the Secretary of State is to be: “discerned objectively from the language used, not divined
by reference to supposed policy considerations.”

4. I was also referred to the decision of Mr Justice Kerr in the Queen on the application of MD and EH v
_the Secretary of State for the Home Department_ _[[2021] EWHC 1370 (Admin) which considered the position](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62RV-1BY3-GXFD-8333-00000-00&context=1519360)_
of asylum seekers who were also victims of **_modern slavery (the situation of the claimants in the case)_**
[who did not receive financial support under the provisions of the “Modern Slavery Act 2015: Statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
Guidance for England and Wales” in respect of dependent children, as against victims of modern slavery
who were not asylum seekers who did. The court accepted the Defendant's evidence that the effect of the
policy that resulted in additional financial support being paid to victims of modern slavery who were not
asylum seekers was a mistake. Mr Justice Kerr found the different treatment unjustified under Article 14 of
the European Convention on Human Rights and awarded damages, notwithstanding that the claimants
received the level of financial support the Defendant intended them to receive, but the comparator group
received more than the Defendant intended as a result of the mistake. This was useful context as it
concerned the same policy document, but it was not necessary for me to rely on it to reach my decision.

5. Mr Thomann also relied on the principle of equality and referred to in _Matadeen and Others v MGC_
_Pointu and Others (Mauritius) [1998] UKPC 9 at page 109 C to D and the discussion in Regina (SC and_
_others) v Secretary of State for Work and Pensions and others (Equality and Human Rights Commission_
_intervening) [2021] UKSC 26 at paragraph 146. In summary, similar cases should be treated similarly and_
not doing so is indicative of an irrational decision. In the context of those cases, which concerned
challenges to decisions of public authorities resulting in different treatment, there is a discussion of the role
of the courts and parliament, with the care needed by the courts in applying tests of irrationality and
proportionality in cases involving economic and social policy (SC paragraph 146 and Matadeen page 109
E to G).

**The modern slavery support regime**

6. The Defendant is responsible for determining whether a person is a victim of modern slavery under the
National Referral Mechanism (NRM). A person will be considered a potential victim of modern slavery (“a
Potential Victim”) where there are “reasonable grounds” to do so. Having made such a decision, the
Defendant goes on to consider whether there are “conclusive grounds” that a person is a victim of modern
**_slavery (“a Victim”). The operation of the NRM is set out in the_** **_[Modern Slavery Act 2015: Statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
Guidance for England and Wales (“MSAG”).

7. Financial support is paid to Potential Victims (and Victims, but this case only concerns the Claimant as
a Potential Victim) in circumstances and at levels set out in the MSAG. At the material time, the relevant
parts of the MSAG (version 1.01) stated:

“15.36. The current rate of financial support payable by the Home Office to potential victims or victims of
**_modern slavery receiving VCC support depends on the accommodation they are in. The rates are as_**
follows:


-----

£65 per week for those in self-catered VCC accommodation

£35 per week for those in catered VCC accommodation

£39.60 per week for those receiving outreach support in other accommodation

…

Financial support for potential victims who are also receiving asylum support

15.37. The payment rates will be adjusted if the potential victim or victim of modern slavery receiving VCC
support is also an asylum seeker or failed asylum seeker receiving financial support under sections 95, 98
or section 4 of the Immigration and Asylum Act 1999 (“asylum support”). In these circumstances, the
individual will receive £65 per week, made up of payments from asylum support and a further payment
from the VCC to take the total payment to £65 per week.”

8. The reference to “VCC” in the extracts from the MSAG above is to the **_modern slavery Victim Care_**
Contract1. This is a contract between the Defendant and the Salvation Army, which amongst other
matters, outsources the provision of accommodation and financial support so that it is provided by the
Salvation Army and/or their subcontractors. Paragraph 6 of schedule 2 of the VCC, in force at the relevant
time, provided that the contractor (i.e., the Salvation Army or one of their subcontractors) must provide
“subsistence payments in cash” to a Potential Victim. For a Potential Victim accommodated by the
Defendant “and in receipt of subsistence payments through that service” the sum is specified as £65
“minus the amount of subsistence received [from the Defendant]”. A Potential Victim will be
accommodated by the Defendant when discharging her asylum functions. The other details of subsistence
payments are set out as follows:

- Service user in catered accommodation provided by the Contractor - £35

- Service user in self-catered accommodation provided by the Contractor - £65

- Service user not accommodated by the Contractor or the [Defendant] (e.g., living with friends or family) £35

9. The Defendant issued guidance to the Salvation Army and its subcontractors on 29 January and 6 April
2020 in the form of a frequently asked questions document (“FAQ”). The FAQ included the following:

“1. Subsistence for accommodation clients:

**a) Are we correct in understanding that Accommodation clients are entitled to and should get £65**
**pw subsistence regardless of benefits or income from work etc.?**

Yes – unless they are receiving support from the asylum support system, in which case their financial
support should be £65pw minus the NASS payment

**2. Subsistence for catered accommodation clients:**

**a) Are we correct in understanding that Catered Accommodation clients are entitled to and should**
**get £35 pw regardless of benefits or income from work etc.?**

Yes – unless they are receiving support from the asylum support system, in which case their financial
support should be £65pw minus the NASS payment.

…

**4. Subsistence for outreach NASS clients            :**

**a) Are we correct in understanding that Outreach NASS clients are entitled to and should get £65**
**pw minus the NASS payment? e.g. If client receiving £37.75 from NASS then they are only entitled**
**to the £27.25 top up from the VCC. This is regardless of any other income?**

This should be the position for all clients who are also receiving financial support from NASS, regardless of
where they are accommodated. Any other income should be declared to the asylum support system.”

[emphasis in the original]


-----

The reference to “NASS” is to the National Asylum Support Service. “Outreach” is a reference to support
provided under the VCC for those victims and Potential victims who are, for whatever reason, not in
accommodation provided pursuant to the VCC.

10. On 28 August 2020 the MSAG was updated to version 1.02 and paragraph 15.37 amended to
paragraph 15.38 with the following text:

“The payment rates will be adjusted if the potential victim or victim of modern slavery receiving MSVCC
support is also receiving support under sections 95, 98 or section 4 of the Immigration and Asylum Act
1999 (“asylum support”). In these circumstances, the individual is receiving asylum support because they
have been assessed as destitute or an assessment is being made on whether they are destitute. In both
cases support is provided by asylum support to meet their essential living needs. Generally, support to
cover essential living needs is provided through a payment of £39.63 per week, but in some cases
essential living needs are met through in-kind assistance, or a combination of in-kind assistance and
payments. A further payment will be made from the MSVCC of £25.37 (calculated as £65 per week minus
the current essential living rate of £39.63 provided by asylum support) to assist with their social,
psychological and physical recovery from exploitation.”

**The asylum support regime**

[11. The asylum support regime is governed by the Immigration and Asylum Act 1999 (“the IAA”). Section](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)
95 IAA permits the Defendant to provide, or arrange for the provision of, support for asylum seekers “…
who appear to the [Defendant] to be destitute or to be likely to become destitute…” Section 98 IAA permits
temporary support until the Defendant can determine whether support may be provided under section 95.
Under both sections 95 and 98 support may be provided by way of accommodation and subsistence, or
subsistence support only if accommodation is not required. Once a section 95 decision has been made
the level of support is governed by regulation 10 of the Asylum Support Regulations 2000/704 (“the
Regulation”). Regulation 10 provides that where the Defendant has decided asylum support should be
provided in respect of the “essential living needs of a person” then a weekly payment in cash is made in
the sum specified in the Regulation (£39.632 as of 22 February 2021). However, Regulation 10(5)
provides that where the Defendant has decided that accommodation should be provided by way of asylum
support and that also meets other essential living needs “(such as bed-and-breakfast, or half or full board)”
then the cash sum “shall be treated as reduced accordingly.”

12. In JM v Secretary of State for the Home Department _[2021] EWHC 2514 (Admin) Mrs Justice Farbey_
considered the level of asylum support for those in full board hotel accommodation in the circumstances of
the Covid-19 pandemic. The effect of the pandemic has meant that asylum seekers who would have been
accommodated in hotels on full board on a temporary basis have had to remain in hotels for longer periods
whilst in receipt of section 95 IAA support.  Mrs Justice Farbey concluded that the obligation under section
95 IAA was not overridden by the pandemic and she did not accept that temporary support could be
provided to someone who was eligible for section 95 support on an ongoing basis (paragraph 105). The
evidence was that before the pandemic those temporarily accommodated under section 98 IAA in full
board accommodation did not receive any cash to cover any essential living needs not met by the in-kind
provision (paragraph 32).

13. The claimant in JM had been accommodated in full board accommodation provided under section 95
IAA from 1 May 2020 to 1 February 2021. In October 2020, the Defendant made a policy decision to pay
£8 per week to those in full board asylum accommodation. The claimant's grounds were that in the period
prior to 19 October 2020 (the date of the policy decision) the defendant had failed to pay more than £5 per
week in cash support. The analysis concerned the decisions regarding essential living needs for transport
and communication. Mrs Justice Farbey held that the defendant's decision to allow nothing for travel
during the period of the pandemic when travel was restricted was lawful (paragraphs 117 and 120). From
1 July 2020 it was accepted by the defendant that travel was an essential living need. Although, this
decision was taken some months after that date, the allowance of £4.70 per week was back dated, so no
relief was granted (paragraph 123). However, Mrs Justice Farbey concluded that the defendant had failed
to meet the essential living needs in relation to communication, in cash or kind (paragraph 149).


-----

**Material facts**

14. The Claimant is a national of Ghana and in his witness statement said that he was trafficked to the
United Kingdom in March 2011. The Claimant says that he was held captive in a property in Birmingham
and forced to work for his captors. He was physically abused by being beaten. He escaped and travelled
to London, where he became street homeless. Subsequently, he was able to find accommodation and
assistance, but in November 2019 he was arrested as an illegal immigrant. Whilst in immigration detention
he was referred into the NRM, having described his experiences. On the 17 December 2019 a positive
reasonable grounds decision was made and he became entitled to support under the MSAG as a Potential
Victim. The Claimant also claimed asylum and was granted asylum support under section 95 IAA on 31
March 2020.

15. Having been released from immigration detention the Claimant lived with a friend, but his friend was
unable to continue accommodating him and on 25 March 2020 he was taken to temporary asylum
accommodation at a hotel. However, the effect of the Covid-19 pandemic meant that the Claimant
remained in the hotel some months after the section 95 IAA decision. He received three meals a day
whilst staying at the hotel. The Claimant also received weekly cash payments. In the hotel he received
£35 per week under the VCC. On 10 July 2020, the Claimant was told that payment would cease, which
they did. However, on 31 July 2020 the Claimant was told they would be re-instated and backdated to 13
July 2020. In his statement the Claimant says when he arrived in the hotel, he was told by staff that he
would receive £5 per week. However, he did not do so until the week commencing 10 August 2020. This
was the support for essential living needs under section 95 IAA, in addition to the accommodation and “in
kind” subsistence, i.e., the 3 meals a day.

16. The Defendant served a witness statement from Ms Jonet Tann dated 15 January 2021. Ms Tann
was the policy adviser on adult victims support policy in the Defendant's **_Modern Slavery Unit. She_**
describes various provisions including that: “until recently [full board accommodation] was generally only
used for those supported under section 98 [IAA]…” She states that if section 95 IAA support was granted,
the person would be moved to “dispersal accommodation” which was self-catered flats and houses and
receive a weekly subsistence payment (the £39.60 per week) to cover their essential living needs.
However, due to shortages in supply of accommodation, full board accommodation was provided more
commonly under section 95. She states that as of 27 October 2020 those in full board accommodation
received an additional payment of £8 per week to ensure all their essential living needs were met. She
states that: “the package of assistance provided is equal in value to the £39.60 per week subsistence rate
given to those in dispersal accommodation.” By “dispersal accommodation” she means those in selfcatered flats and houses.

17. Paragraph 27 of her statement is as follows:

“The [VCC] as originally drafted, stated that financial support would be provided to 'those accommodated
by the [Defendant] and in receipt of subsistence payments through that service.' This is taken to refer to
asylum seekers in receipt of subsistence from asylum support and was reflected as such in the [MSAG
version 1.01]. As asylum support subsistence payments were only available to those in self-catering
dispersal accommodation, this was taken to mean that those in full board or catered asylum
accommodation did not fall within the [VCC] or [MSAG version 1.01].”

18. Ms Tann refers to the question and answer numbered 1 in the FAQ set out in paragraph 8 above and
states in reference to it:

“This question was answered from the point of view that the current financial support payments do not take
account of benefits or income, but that any support received from the asylum support system is deducted.
The question refers to “Accommodation clients” i.e., those in VCC accommodation, therefore the answer
was in relation to that cohort, not referring to those in full board asylum accommodation. In practice, most
potential and confirmed victims in asylum full board accommodation were receiving £35 per week prior to
the changes in August 2020.”

She does not address the questions and answers numbered 2 and 4 in the FAQ in her statement.


-----

19. The Claimant asked Part 18 questions of the Defendant. In particular:

“4. In relation to §27 of the witness statement of Jonet Tann, which states that asylum support subsistence
payments were only available to those in self-catering dispersal accommodation, this was taken to mean
that those in full board or catered asylum accommodation did not fall within the [VCC] or [version 1.01 of
the MSAG].

a. In light of the proceedings in R (MK) v SSHD (CO/3086/2020) and R (JM) v SSHD (CO/4563/2020) and
the Secretary of State's concession in those proceedings that cash support must be paid to asylum
seekers in full board s.95 accommodation and must be back-paid to those who were not paid such cash
support, does the Secretary of State accept that Jonet Tann's evidence on this point is incorrect and that
the Secretary of State was, at all material times, legally required to provide some level of cash support to
asylum seekers in full board s.95 accommodation? If not, please explain how Jonet Tann's evidence can
be reconciled with the concessions in MK and JM.”

20. The Defendant's response was:

“My client's position is that paragraph 27, being predicated on the opening words “The [VCC] as originally
drafted” referring to the position as it stood under the [version 1.01 of the MSAG] and prior to the Covid19
pandemic, is correct. It is noted that the wording “pre August 2020” in the heading above paragraph 27 of
Jonet Tann's Witness Statement may have confused this point.

“The consensus within the Home Office was, and continues to be, that reference in the [VCC] or [version
1.01 of the MSAG] to those receiving asylum support “subsistence” or “financial support” refers to those in
receipt of the cash support (now £39.63 per week) referred to in Regulation 10(2) of the Asylum Support
Regulations 2000 – which as a matter of policy has only ever been provided to those in asylum “dispersal”
accommodation (i.e. flats and houses), not those in full-board accommodation whose essential needs were
met whilst in that type of accommodation. It is true that as a result of the COVID-19 pandemic, some
individuals in full-board accommodation may now be eligible for a payment, but not the cash support
provided for in Regulation 10(2).

“This is why Jonet Tann's witness statement explained that “those in full-board or catered asylum
accommodation did not fall within the [VCC] or [version 1.01 of the MSAG]”.”

21. The Claimant served a statement from Mr Ahmed Aydeed dated 16 August 2021 dealing with the
Defendant's evidence on the Part 18 response and a table showing the different levels of financial support
received by Victims and Potential Victims. Those with similar levels of financial support from VCC may be
in receipt of additional support from other benefits or sources of income. The Defendant served a
statement from Mr Mark Ryder dated 16 September 2021. Mr Ryder is an Adult Victims Support Policy
adviser within the **_Modern Slavery Unit of the Defendant. His statement responds to that of Mr Ahmed_**
and updates that of Ms Tann. Mr Ryder states that it is not disputed that an asylum seeker supported
under section 95 IAA receives assistance to cover their essential living needs pursuant to Regulation 10.
He states at paragraph 9 onwards:

“9. The position is that most asylum seekers supported under section 95 (in particular those in dispersal
accommodation) receive the payment referred to in Regulation 10(2) - that is £39.63 per week.

“10. The asylum seekers who do not receive the £39.63 payment (in practice those accommodated in
other arrangements) either receive a lower payment, or indeed no payment, depending on whether some
or all of their essential living needs are being met in kind, as provided for in Regulation 10(5).

“11. As is clear from its text, the letter of 12 February 2021 referred to Regulation 10(2) throughout, in
order to make the point that the Home Office's understanding is that reference to “subsistence” or “financial
assistance” in the old guidance and contract relating to victims of modern slavery refers to those in receipt
of the payment set out at Regulation 10(2).”

22. At paragraph 24 Mr Ryder states:


-----

“Ahead of the policy change it is my understanding that asylum seeking potential victims not
accommodated by the VCC and not in dispersal accommodation under asylum support, were paid a single
payment of £35 per week from the VCC as per section 6 of Schedule 2 of the previous VCC. The position
now is that support to potential victims may be provided through a combination of financial support and inkind assistance, meaning where an individual's essential living needs are met through full-board
accommodation, the financial support payment is less to reflect that – this is on the basis that financial
support in this instance would not be needed to purchase food and other essential living items which are
already covered by being in full-board accommodation. Whereas if a victim is in self-catered
accommodation, they would need the full amount of £65 a week as all essential living needs, food etc, are
not met by the accommodation provider.”

**The grounds**

23. The Claimant's case is that as a Potential Victim and someone in receipt of asylum support, he was
entitled to a total cash payment of £65 per week, not the £35 he was paid. The ground of challenge is that
the Defendant misunderstood paragraph 15.37 of the MSAG version 1.01 when determining the sums due
to the Claimant.  The Claimant accepts that the amendments in version 1.02 of the MSAG on 28 August
2021 mean he is not entitled to a total cash payment of £65 from that date.

24. Mr Justice Lane gave permission for judicial review by Order dated 14 October 2020.

**Discussion**

25. The Claimant's submissions may be shortly summarised as: an objective reading of the MSAG entitles
the Claimant to a total cash payment of £65 per week, less the cash payment received as asylum support.
The Defendant's submissions, which I have necessarily summarised, are that the MSAG needs to be
interpreted in context and with a purposive approach. In case of ambiguity, it is necessary to step back
and look at the matter in context.  Raissi needs to be applied carefully to determine the objective intent of
the policy, including looking at all of the MSAG. There is no express provision covering in-kind assistance
or how it is to be dealt with. Paragraph 15.37 of the MSAG is directed towards mere financial support and
not in-kind support or a mixture of both. The clear intent of the policy was that for someone like the
Claimant the sum paid would be £35 per week. The rule of equality is relevant in treating people in similar
circumstances equally.

26. It is clear from the evidence that before the pandemic a person claiming asylum and accommodated
under section 98 IAA would generally be placed in full board accommodation and not provided with any
additional financial assistance. After that temporary placement, if a section 95 IAA decision was made in
the person's favour, then they would be moved to “dispersal accommodation”, which was generally selfcatered. They would receive the payment referred to in Regulation 10(2), which is referred to in the
various pieces of evidence as £39.60 or £39.63.

27. The pandemic altered what generally happened because of a lack of self-catered accommodation.
Therefore, increasing numbers of people seeking asylum and in receipt of a positive section 95 IAA
decision remained in full board accommodation. As Mrs Justice Farbey concluded in _JM, and as I_
understand the Defendant accepted, a person receiving support under section 95 IAA is entitled to a cash
weekly payment for their essential living needs where those have not been met by the “in kind” provision of
the full board accommodation. As is accepted, the Claimant in this case should have received such a
weekly cash sum from the date of his section 95 IAA decision.

28. I have considered paragraph 15.37 in the context of the MSAG and from the point of view of a
reasonable and literate person's understanding of the policy. I have borne in mind that I am to read the
policy objectively from the language used and not with the strictness of construction of a statute or
statutory instrument.

29. There is no ambiguity in the policy and there is no lacuna. The policy is clear as it states that a person
who is both a Potential Victim and an asylum seeker receiving financial support under, in this case, section
95 IAA will receive a total of £65 per week. This sum is to be made up of payments from asylum support


-----

plus a further payment from the VCC. There is no basis to interpret “financial support” as meaning “the sum
due under Regulation 10(2)”. This is not the natural and ordinary meaning of that phrase. The
understanding of the person or persons who drafted the FAQ was consistent with the interpretation that I
have reached – see the answers to questions 2 and 4. It makes no difference that the Claimant did not
receive, as a matter of fact, the financial support under section 95 IAA that he was entitled to, in whole or
part, during the relevant period, not that I understand that to be an argument put forward by the Defendant.

30. The person or persons who drafted paragraph 15.37 of version 1.01 of the MSAG either intended it to
be interpreted in that way or they had in mind what generally happened. They anticipated and expected
that Potential Victims or Victims who were also asylum seekers, or failed asylum seekers, receiving
financial support under the IAA would be in self-catering accommodation. This is consistent with Ms
Tann's evidence and that of Mr Ryder as they both record what generally happened. Notwithstanding what
was in the mind of the person or persons drafting version 1.01 of the MSAG, the policy as drafted does not
reflect the “consensus” referred to in the Defendant's Part 18 response (see paragraph 20 above) or
paragraph 11 of Mr Ryder's statement quoted at paragraph 21 above. The Defendant may have hoped or
expected that is what the drafting stated or should state, but it does not. There is a very good reason why
a policy should be interpreted in the way set out in _Raissi and_ _Mahad. It is so that people to whom the_
policy applies can understand the policy from the document itself. If, because of the way a document has
been drafted, it becomes clear to the Defendant that the policy is not being implemented in the way that the
Defendant intended, then the solution is to change the policy. As stated above, the Defendant did change
the policy and the Claimant accepts from the date of that change that he is not entitled to the additional
payment to make his cash weekly sum £65 in total.

31. Looking at paragraphs 15.36 and 15.37 it might be considered that £35 per week for an asylum seeker
who is also a Potential Victim and in full board accommodation would seem “fair”. They look to be in a
similar situation to a Potential Victim who was in catered VCC accommodation, who received £35.
However, although that might seem fair it is not what version 1.01 of the MSAG stated at paragraph 15.37.
As the evidence that the Claimant provided demonstrated, the sums received by Potential Victims and
Victims in similar circumstances can vary considerably due to the impact of other benefits. There is no
reason to “second guess” what was stated in paragraph 15.37.

32. In SC and Matadeen the circumstances were different in that those challenging the decision of a public
authority sought to argue they had not been treated equally to others. In this case, the Defendant argued
that the rule of equality supports the reading the Defendant contends for in paragraph 15.37.  The rule of
equality as advanced by the Defendant is not relevant to the circumstances of this case. If the drafting of
the paragraph 15.37 was not clear or there was a lacuna it might help in interpretation. However, as I have
found, that was not the case. I do not consider the interpretation I have reached of paragraph 15.37 in the
context of the MSAG to be obviously wrong so as to justify reaching a different conclusion. The simple
position is that the practice that was followed in the Covid-19 pandemic, as set out in the Defendant's
evidence, did not match the drafting of paragraph 15.37. If paragraph 15.37 was not meant to do what it
states, then the change in circumstances was not anticipated by those who drafted it, or it was not drafted
with sufficient precision.

**Summary**

33. I have found for the Claimant. The Defendant's policy on financial support to potential victims of
**_modern slavery at the relevant time stated that such a person would receive a total of £65 per week, less_**
any financial support received as an asylum seeker.

**End of Document**


-----

