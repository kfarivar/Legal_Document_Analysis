# R (on the application of LH) v Secretary of State for the Home Department

 [2020] All ER (D) 113 (Jan)

[2019] EWHC 3457 (Admin)

Queen's Bench Division, Administrative Court (London)

Peter Marquand (sitting as a deputy judge of the High Court)

13 December 2019

**Immigration – Victim of trafficking – Review of decision**
Abstract

_The defendant Secretary of State had failed to consider a consultant psychiatrist's evidence and how it might_
_impact on the decision on the claimant's credibility, which had been irrational, did not follow the Secretary of State's_
_own policy and did not meet the requirement of rigorous or anxious scrutiny. Accordingly, the Administrative Court_
_held that the claimant succeeded in his application for judicial review of the Secretary of State's decision that he_
_was not the victim of trafficking and quashed the decision._
Digest

The judgment is available at: [2019] EWHC 3457 (Admin)

**Background**

The defendant Secretary of State previously issued a conclusive grounds decision, finding that the claimant
Vietnamese national was not the victim of trafficking on the basis that the claimant's credibility had been damaged
to the extent that his claim to have been exploited 'cannot be believed', and that his evidence was internally
inconsistent and limited weight was attached to it. The claimant requested the Secretary of State to reconsider that
decision. Her reconsidered decision also found that, notwithstanding new information, the claimant was not a victim
of trafficking. The claimant sought judicial review.

**Issues and decisions**

Whether the Secretary of State had sufficiently taken into account a psychiatric report diagnosing the claimant as
suffering from post-traumatic stress disorder and a report from an expert on Vietnam.

As a matter of principle, it was possible to incorporate previous reasoning and decisions by reference to them into a
subsequent decision. That was provided that it was clear that incorporation was to substantiate the new decision.
The reference in the 'Appeals against a Reasonable Grounds or Conclusive Grounds Decision' to the 'informal
arrangement' did not apply to the review of the decision. The reference to 'informality' was to the process leading up
to the reconsideration. It did not mean that the reconsideration itself should in some way be a lesser application of
the 'Victims of Modern Slavery – Competent Authority Guidance', or a less rigorous or anxious scrutiny. That would
be irrational (see [32] of the judgment).

The requirement on the Secretary of State was to consider, applying the relevant parts of the Competent Authority
Guidance and anxious scrutiny, what difference the new material made to the decision that was under
reconsideration. It did not mean, in every case, it was necessary for the Secretary of State to repeat the entire


-----

process that she had previously gone through. It would depend upon the facts and the nature of the new material
(see [33] of the judgment).

The Secretary of State's decision did not set out detailed reasons and, given the fundamental rights involved, it
should do so. It did not show by its reasoning that every factor which might tell in the claimant's favour had been
properly taken into account. That was the case even reading the Secretary of State's letter in a broad and commonsense way. There was no analysis in the letter, other than a wholesale rejection of the claimant's case based on a
blanket rejection of the claimant's credibility. The incorporation of the earlier decisions did not provide the necessary
reasoning, as they were directed at a different assessment, namely, the future risks to the claimant and
consideration of his asylum claim. That betrayed a failure to consider a consultant psychiatrist's evidence and how it
might impact on the decision on the claimant's credibility when applying 'How to Assess Credibility When Making a
Reasonable Grounds or Conclusive Grounds Decision'. Failing to do such analysis was irrational, did not follow the
Secretary of State's own policy and did not meet the requirement of rigorous or anxious scrutiny. Accordingly, the
claimant succeeded in his claim and the Secretary of State's decision would be quashed (see [41], [44] of the
judgment).

_KB & AH (credibility-structured approach)_ _[[2017] UKUT 491 (IAC) applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RTP-R1N1-F0JY-C0CS-00000-00&context=1519360)_

Chris McWatters (instructed by Duncan Lewis) for the claimant.

William Irwin (instructed by the Government Legal Department) for the Secretary of State.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

