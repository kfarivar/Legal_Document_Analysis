# R (on the application of NCH (Vietnam)) v Sefton Metropolitan Borough
 Council [2023] EWHC 1033 (Admin)

King's Bench Division, Administrative Court (Manchester)

Karen Ridge (sitting as a deputy judge of the High Court)

3 May 2023Judgment

**Samina Iqbal (instructed by Bhatia Best Solicitors) for the Claimant**

**Ifsa Mahmood (instructed by Sefton Council Legal Services) for the Defendant**

- - - - - - - - - - - - - - - - - - - - 
Hearing date: 14 April 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10am on 3rd May 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

**INTRODUCTION**

1. This is my judgment following the hearing of the Claimant's renewed application for permission to apply
for judicial review in relation to an age assessment. That application is accompanied by two further
applications. The first is a renewed application for an extension of time to issue proceedings. The second
is an application, dated 17 March 2023, for interim relief requiring the Defendant to provide accommodation
and support for the Claimant as a child pending final resolution of these proceedings or further order of the
Court.

**BACKGROUND**

2. The Claimant is a Vietnamese national who has claimed asylum and contends that he is a child. The
[Defendant is a local authority with functions, powers and duties under the Children Act 1989.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)

3. The Claimant contends that his date of birth is 1 May 2005 and that he is now 17 years old and is in fact
due to turn 18 years old in a matter of days. It appears that he left Vietnam by plane on the 16 or 17 June
2020 and flew to Russia before travelling through Poland, France and Belgium and arriving in the United
Kingdom in March 2021.

4. On arrival in this country, the Claimant says that he was kept in a warehouse for 10 days before being
released after his sister had paid a sum of money. He states he was homeless for three months and then
was detained by 4 men and made to care for cannabis plants. Approximately 10 days later the house in
which he was detained was raided by the police, and he was placed in foster care. He ran away and was
homeless.

5. In September 2021 the Claimant states that other men then forcibly took him to a cannabis farm in
Liverpool. A police raid of that cannabis farm took place on 23 September 2021 and the Claimant


-----

subsequently appeared at Liverpool Magistrates Court on 25 September 2021 facing a charge of cannabis
production. His defence raised the likelihood that he had been trafficked.

6. It transpires that a referral under the National Referral Mechanism was made by West Midlands Police
on 14 July 2021.  On 3 February 2022 the Claimant received a positive conclusion grounds decision
following that referral.

7. The Claimant was subsequently taken to the Defendant's Children's Services accommodation and a full
age assessment was undertaken. On 23 February 2022 the conclusion of that assessment was that the
Claimant was 18 years or older and that is the decision subject to challenge.

8. The assessment states the Claimant was informed of the decision on 17 February 2022 at the “Minded
Interview”. The Claimant says that he was given a copy of the assessment on or around 3 May 2022
through his Barnardo's support worker. The Claimant further states that correspondence took place with
Duncan Lewis solicitors who indicated they could assist him but on 6 May 2022 his solicitors stated that
they did not have capacity to take the case.

9. This claim was duly brought by Claim Form dated 5 July 2022, naming the Defendant as the relevant
local authority charged with the statutory duty of housing those under the age of 18 in the administrative
area of Sefton.

10. The application for permission comprised two grounds: the Defendant's age assessment was flawed
for reasons of procedural unfairness and a failure to ensure compliance with well-established principles on
age assessment.  The second ground relies upon an allegation that the Defendant failed to consider
relevant matters, namely the Claimant's experiences as a likely/potential victim of trafficking.

**PROCEDURAL HISTORY OF THE CLAIM**

11. The Claimant's application for permission, and the application for retrospective extension of time for
filing the claim, came before His Honour Judge Pearce sitting as a Judge of the High Court on 5 January
2023. He considered the matter on the papers and made an anonymity order in relation to the Claimant
and an order permitting the Claimant to conduct proceedings without the appointment of a litigation friend.
HHJ Pearce also refused the application for permission to apply for judicial review and refused the
application for an extension of time to file the claim.

12. The renewal application was made on 13 January 2023.

13. On the 17 March 2023 the Claimant filed an application for interim relief, asking that this application be
considered at the same time as the renewal application. On 23 March 2023 HHJ Sephton KC, sitting as a
judge of the High Court, directed that the Claimant's interim relief application be considered immediately
after the determination of the Claimant's oral reconsideration, which is be heard urgently and, in any event,
before 12 April 2023.

14. Whilst court time was made available on the 12 April 2023, the parties indicated that they could not
attend and therefore the hearing was fixed for 14 April 2023.

15. On the 14 April 2023 I heard oral submissions on behalf of both Claimant and Defendant and I
reserved judgment.

**TIMING OF THE CHALLENGE**

16. By virtue of CPR 3.1(2)(a) the court is permitted to extend the time limit even where this has already
expired. In this case the relevant decision was made on 23 February 2022 and the claim form was issued
on 5 July 2022.

17. The primary requirement in judicial review proceedings is to start the claim promptly, and, in any event,
within 3 months of the decision complained of.

18. The statement of Mr Scott Laing dated 28 June 2022 sets out the reasons for the late issue of the
claim. His firm was instructed after the originally instructed solicitors had indicated that they did not have


-----

capacity to act. Mr Laing's firm were approached on 13 May 2022, they took instructions, sent a pre-action
protocol letter on 20 May 2022, submitted a legal aid application and issued the claim on 28 June 2022.

19. In his Order, HHJ Pearce confirmed that the Claimant's current lawyers had acted with appropriate
expedition in pursuing the claim. The Judge did however go on to state that there was little explanation
before the court to explain the delay prior to their instruction. HHJ Pearce concluded that there was no
adequate explanation for the delay between the decision of the 23 February 2022 and the instruction of the
second set of solicitors on 13 May 2022.

20. It is clear from the documents that Ms Durose, the Independent Child Trafficking Guardian from
Barnardo's, had approached a previous firm of solicitors, Duncan Lewis, to act in this matter on behalf of
the Claimant as early as 18 February 2022. The email trail between Ms Durose and Duncan Lewis
solicitors highlights a series of contacts between Ms Durose and Duncan Lewis, including the sending of a
legal aid form by Duncan Lewis for the Claimant to sign on 10 March 2022; confirmation from Duncan
Lewis of receipt of the legal aid forms on 23 March 2022; an email from Ms Durose to Duncan Lewis on 4
May 2022 asking if they had all the information they needed for the claim; and finally an email from Duncan
Lewis solicitors to Ms Durose dated 6 May 2022 saying they did not have an active file as they were
awaiting proof of means.

21. It is clear from a close examination of the documents that there had been some misunderstanding or
miscommunication between Ms Durose, who was helping the Claimant, and Duncan Lewis solicitors who
had been instructed to act on his behalf. I am satisfied that, having instructed Duncan Lewis, Ms Durose
had, quite reasonably, anticipated that matters were in hand to commence the judicial review proceedings.

22. Ms Durose was doing all she could to progress matters expeditiously on behalf of a Claimant who did
not understand the English language or court processes and was potentially a vulnerable claimant and a
potential victim of trafficking as well as an asylum seeker. In all these circumstances it was evident that the
Claimant would need professional assistance to progress his claim. It is further evident that Ms Durose
acted with all due haste in instructing solicitors as soon as possible and in seeking to assist in the provision
of relevant information.

23. Having regard to the circumstances surrounding the delay in issuing proceedings, I am satisfied that a
good explanation has been provided for that delay and that it is appropriate to grant an extension of time
for filing the claim form up to and including 28 June 2022. To do so would not cause any substantial
hardship or prejudice to the Defendant or any other party and it would not be detrimental to good
administration.

**GROUNDS OF CHALLENGE**

**Ground 1**

24. The Claimant's first ground of challenge contends that the age assessment was flawed due to
procedural unfairness and a failure to ensure compliance with the principles established by R(B) v London
_[Borough of Merton [2003] 4 All ER 280; [2003] EWHC 1689 (Admin) and restated in subsequent caselaw.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61KV-00000-00&context=1519360)_
Those principles require the defendant to give the claimant, as soon as is possible, the opportunity to
explain any inconsistencies in his account or anything which is considered likely to result in an adverse
finding.

25. Both parties direct my attention to the Association of Directors of Children's Services (ADCS) Age
Assessment Guidance which states that:

_“Before reaching a decision that contradicts the stated age, you should discuss with the child or young_
_person the factors which have led you to form your opinion. The interpreter and the appropriate adult_
_should be present for that session to help the child or young person ask any questions or clarify_
_information. If the child or young person offers any further information or explanation, this should be_
_considered as part of the assessment before the final decision is made. Once all the information is_
_compiled, you should set out the factors that lead to your conclusion.”_


-----

26. The relevant test at permission stage is that outlined in R(A) v London Borough of Croydon, R(M) v
_London Borough of Lambeth [2009] UKSC 9), when the following guidance was given when considering_
whether permission for judicial review ought to be granted:

“We consider that at the permission stage in an age assessment case the court should ask whether the
_material before the court raises a factual case which, taken at its highest, could not properly succeed in a_
_contested factual hearing. If so, permission should be refused. If not, permission should normally be_
_granted, subject to other discretionary factors, such as delay. We decline to attach a quantitative adjective_
_to the threshold which needs to be achieved here for permission to be given.”_

27. The Claimant's case is that, during the assessment interviews, the basis on which the decision on age
assessment was going to be made was not fully explained to the Claimant such that he had an opportunity
to address any perceived inconsistencies or deficiencies in his case. Moreover, the Claimant points to
excerpts from the minded to interview which indicate that a concluded decision had been reached at the
point at which the inconsistencies were put to him. These include comments such as “the assessor
_reiterated how the decision in terms of his age had been formed” when discussing his height._

28. The Claimant further points out that he was told how the decision had been reached and that he “had
_not been consistent when providing an account of his story” but that the particularities of any inconsistency_
were not explained to him. For example, the Defendant relied upon its own research into the Vietnamese
education system which suggested that students in Grade 9 in Vietnam are 14 years old and the academic
year runs from August to May. The Claimant had originally reported that he left school after completing
Grade 9 in 2018. Applying its own research to this statement, the Defendant had concluded that the
Claimant's 18th birthday would have fallen on 1 May 2021.

29. The Claimant says that those details were not put to him in interview and, if they had been, he would
have informed the Defendant that he began grade 9 in January 2018 at the age of 13 because children
would start the new grade even if they were below the expected starting age and that the academic year in
Vietnam began in January.

30. Other areas which the Claimant alleges were not put in sufficient detail include findings regarding his
television viewing and shaving habits. It is submitted that he should have been afforded the benefit of the
doubt in relation to physical characteristics and demeanour in line with well-established principles. The
principle of providing the benefit of the doubt to children and young people presenting as such in the
absence of definitive evidence, is also stated in the ADCS Age Assessment Guidance.

31. The age assessment records that the Claimant was informed of the decision as to his age and given a
break to consider his response. He was told that the assessors considered that he had not been
consistent in his account, although no specific reasons are set out. Counsel for the Defendant reminds me
that the Merton case confirmed that a verbatim note of the interview is not required.

32. In addition, the Defendant relies upon the presence of an appropriate adult, a placement support
worker and a Vietnamese speaking interpreter and confirms that these attendees did not raise any issues
about the Claimant not being provided with sufficient reasons. However, given that these independent
adults would not necessarily have been aware of the matters in the minds of the assessors, it follows that it
is likely that they were not aware of the lack of particularity on the part of the Defendant. The lack of
objection on their part does not materially assist the Defendant in this regard.

33. Whilst I accept that a verbatim note is not required of the interview, for the process to be fair, the
Claimant must have a sufficiently clear indication of the concerns regarding his account and other issues,
to enable him to address those concerns. In this case the Claimant appears to have a response to the
concerns regarding the schooling timeline. This response was not provided but that may have been
because the discrepancy was not put in sufficient detail. It is not sufficient for the Defendant to say, in
general terms, there are inconsistencies in your account without informing the concerned individual as to
what those inconsistencies are.

34. For those reasons I conclude that there is an arguable case in relation to ground 1 and that permission
should be given


-----

Ground 2

35. This ground concerns the allegation that the Defendant failed to consider relevant matters, including
the Claimant's experiences as a likely or potential victim of trafficking/modern slavery.

36. On 14 July 2021, the Claimant was referred to the National Referral Mechanism by West Midlands
Police, as a potential victim of trafficking / modern slavery. He now has the benefit of a positive conclusive
grounds decision dated 3 February 2022. The decision notes that the Claimant “[has] given a generally
_detailed, plausible, and relatively consistent account in relation to [his] claimed exploitation”, and goes on_
to state that “[a]pplying the standard of proof 'on the balance of probabilities', it is accepted the potential
_victim was a victim of_ **_modern slavery in the United Kingdom during 2021 for the specific purposes of_**
_criminal exploitation.”_

37. The positive grounds decision goes on to recognise the degree of consistency regarding the
transportation and transfer of the Claimant to various properties. This is notwithstanding other recognised
inconsistencies and omissions in his account. The positive grounds decision further accepts that, as a
minor and an illegal entrant into the UK, it was likely that the Claimant would have found his arrest and
interview by the police to have been an intimidating experience and he may have been reluctant to disclose
his prior arrest for fear of repercussions.

38. The positive grounds decision was made after the date of the decision complained of. However, the
factual and contextual background in this case was known to the Defendant at the time the relevant
decision was made. The Defendant was aware that the Claimant had been arrested twice for working on
cannabis farms and had raised issues relating to ill-treatment. His status as a potential victim of trafficking
was known.

39. The ADCS guidance provides that social workers engaged in age assessments should look at the
situation holistically and consider the circumstances surrounding each young person. The Guidance
specifically acknowledges that children and young people who have been trafficked into the UK are likely to
have had adverse experiences which impacts their ability to engage openly in an age assessment process.
These are matters which should be borne in mind throughout the process.

40. This Claimant's status as a possible victim of trafficking required the Defendant to have regard to that
status and to consider any responses in light of his earlier experiences and their likely effects upon his
ability to engage in the process openly.

41. The Defendant concluded that the Claimant was perceived to be behaving in a deceitful manner with
regards to his television viewing habits. He was reported to watch adult news programmes when on his
own but when he became aware that he was being observed he would switch to cartoon channels. Other
examples of perceived deceitful behaviour are provided, including shaving and then denying that he had
shaved that day. The Defendant contends that details of this behaviour was provided by staff members
with experience of looking after the Claimant over a number of months and that all matters were examined
together.

42. I note that the professionals involved in the Claimant's care up to the point at which the age
assessment was undertaken were mindful of his status as a potential victim of trafficking. Support was
made available to him.

43. However, there is no reference in the age assessment to the Claimant being a possible victim of
trafficking or that his responses and the issues as to credibility had been considered in the context of the
likely trauma which may have been suffered by the Claimant as a trafficking victim. Such a reference
would have indicated that it remained in the minds of the decision makers at the appropriate time. Given
the contextual background to the assessment, and the likely effects of potential trafficking upon the
Claimant, these are important considerations in an age assessment process.

44. Against this background, I consider that it was incumbent upon the decision maker to remain mindful
at all times of the potentially traumatic experiences of the Claimant and to look at questions of credibility
and inconsistent accounts having regard to these matters. There is a positive duty imposed upon the


-----

decision maker by the guidance to do that. It is far from clear that this was the exercise undertaken. I
therefore conclude that permission should be given on ground 2.

45. Having regard to all matters I have therefore concluded that the documentation before the court does
raise a factual case on both grounds, which, taken at its highest, may succeed at a full hearing.

INTERIM RELIEF

46. The Defendant has assessed the Claimant's age as 18 years or older. The Claimant says that his age
is 17 years and 11 months and that, on his case, he is due to turn 18 years old very shortly. The
Defendant terminated its support and accommodation of the Claimant on the 13 March 2023. Since that
time the Claimant has been accommodated by the Salvation Army and Ms. Iqbal confirmed at the hearing
that that provision of that accommodation is likely to continue pending resolution of these proceedings.

47. The Claimant submits that if permission is granted, it is appropriate for interim relief to be granted
pending resolution of these proceedings because of the particular vulnerabilities of the Claimant and the
consideration of the 'balance of convenience'.

48. The Claimant relies upon principles set out in _R (KA & NBV) v LB Croydon [2017] EWHC 1723_
_(Admin) on the test for interim relief at §48 – “In my judgment, unless there has been unexplained and_
_inexcusable delay in applying for interim relief, in most, if not all cases, the 'status quo ante' in a case like_
_this is the status quo ante the impugned decision, not the status quo ante the application for interim relief_
_(cf the contrast between 'something that [the defendant] has not done before' and an 'established_
_enterprise' at p 408 G-H per Lord Diplock in American Cyanamid Co v Ethicon Limited [1975] AC 396). So,_
_in my judgment, where the application for interim relief is made as soon as reasonably practicable (taking_
_into account delays in obtaining legal aid) the 'status quo' is likely to be that the young person was_
_receiving support from the local authority.”_

49. In considering the grant of interim relief, the Court's starting point is the decision of the House of Lords
in _American Cyanamid v Ethicon [1975] AC 396. In summary that decision requires the court which is_
invited to grant interim injunctive relief to consider three issues:

     - Does the case of the party seeking injunctive relief show a serious issue to be tried? If not, the court goes
no further in considering the application. If there is:

    - Would damages be an adequate remedy to a party who is injured by the wrongful grant or refusal (as the
case may be) of an interim injunction?

-Where does the balance of convenience lie?

50. For reasons set out above, I have already concluded that there is a serious issue to be tried and
therefore the first limb is met.

51. In the sphere of public administrative law there is little doubt that either party would be harmed by the
wrongful grant or refusal (as the case may be) of injunctive relief in a way that cannot be adequately
compensated in damages. That is the position here. That deals with the second limb.

52. With regards to the third limb, the balance is between the harm that is done through the court refusing
relief to someone who is in fact under the age of 18 on the one hand and granting relief to someone who is
over the age of 18 on the other.

53. A local authority such as the Defendant has a statutory duty to house those under the age of 18 years.
The accommodation of someone such as the Claimant would entail resources being utilised for his
accommodation. In addition, children looked after by a local authority are highly likely to have significant
needs and will often be vulnerable. It would be wrong to house an adult with such children.

54. On the Defendant's own case he will be 18 years of age in a few days' time. He is currently being
accommodated by Barnardo's and Ms Iqbal indicated that that accommodation is likely to continue until
resolution of these proceedings.


-----

55. It follows from the above that, whilst I am satisfied that the Claimant makes out the basic threshold for
the granting of interim relief, namely an arguable case coupled with the fact that damages would not be an
adequate remedy if injunctive relief is wrongly refused, I am satisfied that the balance of convenience on
the facts of this case points in the direction of the refusal of interim relief.

56. I therefore dismiss the application for interim relief.

**CONCLUSION**

57. For the reasons set out herein, permission is granted to bring proceedings for judicial review pursuant
to grounds 1 and 2.

58. I would be grateful if the parties could agree a form of wording for directions to progress this matter
and provide a time estimate for the contested hearing.

**THE MERITS OF THE CLAIM/APPLICATION (CLAIMANT)**

**THE MERITS OF THE CLAIM/APPLICATION (DEFENDANT)**

**DISCUSSION**

**CONCLUSION**

**End of Document**


-----

