# For leave to apply for Judicial Review v Secretary Of State for the Home
 Department [2018] NIQB 71

QUEEN'S BENCH DIVISION

McCLOSKEY J

1 AUGUST 20181 AUGUST 2018

**McCLOSKEY J:**

**[1] This judgment addresses the single issue of whether there is merit in permitting the Applicant's claim to**
proceed, in pursuit of purely declaratory relief in circumstances where these proceedings have, by virtue of
supervening events, been rendered academic.

**[2] The broader framework within which the Applicant's legal challenge materialised is that of alleged human**
trafficking. The Applicant, a national of Romania aged 30 years, claimed that she was the victim of trafficking
relating to the circumstances in which (she asserted) she was coerced to travel to Northern Ireland in January 2017
by a (later) convicted human trafficker and to work as a prostitute thereafter.

**[3] Based on her affidavit, the Applicant's ordeal has been a gruelling one. Having worked as a prostitute for some**
months she earned enough money to repay her financial debt to the convicted trafficker which had arisen as the
result of a private car sale transaction in Romania. At this stage she returned to her native country, accompanied by
her cousin who, she claims, also worked as a prostitute for the trafficker. Months later both returned to Northern
Ireland, at which stage the (now convicted) trafficker was incarcerated as a sentenced prisoner. She was quickly
arrested by police and charged with offences of human trafficking, controlling prostitution for gain and
concealing/converting/transferring criminal property. These alleged offences related to the Applicant's
interaction/relationship with her cousin during their earlier sojourn in Northern Ireland. Following an initial refusal of
bail, the Applicant was granted bail by the High Court, on 19 February 2018.

**[4] It was in her interaction with the Northern Ireland criminal justice system, in the context outlined immediately**
above, that the Applicant claimed that she had been the victim of trafficking. The assertion of this claim triggered
the so-called National Referral Mechanism (“NRM”) whereunder the decision making agency was the National
Crime Agency (“NCA”). On 13 March 2018 this agency made a “negative reasonable grounds” decision. This, in
substance and effect, entailed NCA's assessment that there were no reasonable grounds for considering the
Applicant to be/have been a victim of modern slavery.

**[5] It is appropriate to interpose here that if this had been a positive “reasonable grounds” decision, the Applicant's**
case would have progressed to the second stage of the process for the purpose of securing a determination of
whether she was a victim of modern slavery. As will be apparent, the first stage of the NCA process operates as a
filter.

**[6] At this juncture the Applicant brought these judicial review proceedings, challenging the NCA's “negative**
reasonable grounds” decision. The case was allocated to a fast track and an early hearing was arranged. In this
context the “supervening events” noted in [1] above intervened, conveniently encapsulated in the NCA letter of 21
May 2018 to the Applicant, evidently written in response to the judicial review challenge–


-----

“The MSHTU competent authority has carefully considered your case. On 06/04/2018 it was decided that there
are reasonable grounds to believe that you are a victim of human trafficking. As a result of further
investigations into your case, the (Authority) has concluded that, based on the balance of probabilities, you
have been a victim of human trafficking.”

The highlighted word “are” is indicative of a voluntary rescission of the impugned decision. As the remainder of the
letter conveys, the Applicant's case was then progressed from stage 1 to stage 2 of the process, yielding a positive
result from her perspective.

**[7] The foregoing events rendered the judicial review challenge academic. The question raised by Ms Doherty QC**
(with Ms Doherty, of counsel), on behalf of the Applicant, is whether the case should be permitted by the Court to
proceed for the purpose of granting purely declaratory relief. This engages the principle, much favoured by public
authority respondents, in R v Secretary of State for the Home Department, ex p Salem [1999] 1 AC 450, where Lord
Slynn stated at p 456–

“My Lords, I accept, as both counsel agree, that in a cause where there is an issue involving a public authority
as to a question of public law, your Lordships have a discretion to hear the appeal, even if by the time the
appeal reaches the House there is no longer a _lis to be decided which will directly affect the rights and_
obligations of the parties _inter se. The decisions in the Sun Life case and_ _Ainsbury v Millington (and the_
reference to the latter in rule 42 of the Practice Directions applicable to Civil Appeals (January 1996) of your
Lordships' House) must be read accordingly as limited to disputes concerning private law rights between the
parties to the case.

The discretion to hear disputes, even in the area of public law, must, however, be exercised with caution and
appeals which are academic between the parties should not be heard unless there is a good reason in the
public interest for doing so, as for example (but only by way of example) when a discrete point of statutory
construction arises which does not involve detailed consideration of facts and where a large number of similar
cases exist or are anticipated so that the issue will most likely need to be resolved in the near future.”

In this jurisdiction this principle has been considered in decisions such as _Re E_ _[[2003] NIQB 39,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DRN-4S90-TWP1-H0JF-00000-00&context=1519360)_ _Re McConnell_

_[[2000] NIJB 116 and Re Nicholson [2003] NIJB 30.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TFY-8RF0-YB56-W4X8-00000-00&context=1519360)_

**[8] The governing principles are, in my estimation, uncomplicated. They are a reflection of the intrinsic juridical**
character of judicial review, being a form of legal challenge involving no lis inter-partes that eschews many of the
trappings of conventional private law litigation. Furthermore, Lord Slynn's formulation, in my view, is not to be
considered exhaustive or comprehensive. This too I consider harmonious with the essential tenets and
characteristics of judicial review.

**[9] Against the framework sketched above, I now summarise the parties' competing contentions. The core**
submission of the two Ms Dohertys on behalf of the Applicant, is that, in the academic litigation context which has
now materialised, this Court should nonetheless adjudicate on the discrete question of whether “the absence of a
review or appeal mechanism for victims or purported victims of human trafficking and/or **_modern slavery” is_**
unlawful.

**[10] The precise species of the asserted illegality is nowhere formulated with sufficient clarity or particularity in the**
further skeleton argument directed by the Court. Nor is this identifiable in the amended Order 53 Statement (dated
27 April 2018). While this is not fatal per se, it obviously has a significant bearing on how the Salem principle is to
be applied in the present context. Moreover, while this lacuna in no way precludes the Court from seeking to identify
the species of illegality which the claim for declaratory relief may engage, I have not found myself able to readily do
so.

**[11] I graft onto the analysis immediately above the cornerstone of the Respondent's resistance to the perpetuation**
of these proceedings for the purpose of securing declaratory relief, namely the extant – and extensive –
governmental review of the NRM which began in October 2017 and has a scheduled implementation date of March
2020. One of the “key objectives” of this exercise is to devise a reformed NRM which will–


-----

“… ensure quicker and more certain decision making that victims have confidence in.”

To this end (inter alia)–

“… an independent multi-agency panel will review all negative conclusive ground decisions which will provide
an additional layer of scrutiny to decisions.”

Separation from “the immigrations system” is a further, free standing aspiration, coupled with the creation of a team
of “continuous improvement experts” and the production of reconfigured guidance for decision makers.

**[12] All of the foregoing requires of the court a balancing exercise and the formation of an evaluative judgement. I**
consider that the perpetuation of these proceedings for the purpose of determining whether the declaratory relief
formulated on behalf of the Applicant, with the deficiencies noted above and in the extant factual circumstances
highlighted, would be inappropriate. In my judgement, the court should not inter-meddle, on a purely abstract basis,
in a context where relevant government policy is the subject of active review with no concrete outcome. While I
acknowledge that, as contended, the Applicant could conceivably become a **_modern slavery/human trafficking_**
victim in the future, this is a matter of pure conjecture and, in any event, she will be at liberty to have recourse to the
legal challenge pursued in the present case and to initiate the parallel, twin track, process of voluntary
reconsideration by NCA. To this I add that, on the basis of admittedly limited argument, there are no persuasive
indications that judicial review does not provide an adequate and efficacious remedy to the subject of a first-stage
“negative reasonable grounds” decision by NCA.

**[13] Furthermore, while I am conscious that Lord Slynn's formulation of principle in Salem does not purport to be,**
and is not, comprehensive, it is appropriate to take into account that neither of the illustrations which he provided,
namely a discrete point of statutory construction with foreseeable future repercussions or, indeed, any question of
law involving a predictably large number of future cases arises in the evidential matrix of the present case. To this I
must add that the legal right which is said to be infringed by the absence of an administrative review or appeal
mechanism for victims of human trafficking and/or **_modern slavery in Northern Ireland is far from clear, with the_**
result that I am unable to identify with any confidence the juridical basis upon which a declaratory order might be
made.

**_Conclusion_**

**[14] On the grounds and for the reasons elaborated above, I conclude, in the exercise of my discretion, that the**
perpetuation of these academic proceedings for the purpose of exploring the kind of declaratory relief canvassed on
behalf of the Applicant is not appropriate.

**_Order_**

**[15] This gives rise to the following Order–**

a A dismiss of the application for leave to apply for judicial review.

b A dismiss of the discrete application that the Court should, in academic circumstances, perpetuate the
proceedings for the purpose of granting declaratory relief.

c No order for costs inter-partes.

d An order that the Applicant's costs be taxed as an assisted person.

e Liberty to apply.

**End of Document**


-----

