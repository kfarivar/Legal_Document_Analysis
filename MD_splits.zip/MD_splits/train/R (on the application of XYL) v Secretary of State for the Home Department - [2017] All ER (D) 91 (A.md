# R (on the application of XYL) v Secretary of State for the Home Department

 [2017] EWHC 773 (Admin)

Queen's Bench Division, Administrative Court (London)

Judge Jonathan Swift QC sitting as a judge of the High Court

11 April 2017Judgment

**SHU SHIN LUH (instructed by WILSON SOLICITORS) for the CLAIMANT**

**BILAL RAWAT (instructed by GOVERNMENT LEGAL DEPARTMENT) for the DEFENDANT**

Hearing dates: 8 February 2017

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Deputy High Court Judge Jonathan Swift QC :**

1. The Claimant claims that she was unlawfully detained between 31 August 2016 and 15 September
2016.

**A.                        Facts and context**

2. The Claimant is a Chinese national. On 12 August 2016 she was arrested by Immigration Officers while
she was working at a massage parlour in Salford. On the same day a Removal Decision was made and
served on the Claimant informing her that she would be removed from the United Kingdom on or after 17
August 2016. That decision recorded that the Claimant had entered the United Kingdom at some point
between 26 March 2015 and 29 September 2015 on a visitor's visa, that had been valid for 6 months; that
she had overstayed since the expiry of that visa; and that she was unlawfully in the United Kingdom. On 13
[August 2016 the Claimant was detained under Immigration Act 1971 powers, pending her removal from the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
United Kingdom.

3. On 19 August 2016 the Claimant stated that she could not return to China, as she feared she would be
harmed by her husband, and that she had no sources of help or support in China. On 22 August 2016 the
Claimant stated that she wished to claim asylum. An asylum screening interview took place on 30 August
2016. At this interview the Claimant said that she had left China because she had been beaten by her
husband. She had then paid an agent to help her leave China who had told her to travel to the United
Kingdom on the pretence that she was a visitor. The Claimant stated that her passport had been taken by
people who met her on her arrival to the United Kingdom; and that those people had then taken her to a
massage parlour in Euston and forced her to work as a prostitute for two months. It was apparent from this,
and from some other information given by the Claimant at the asylum screening interview that the Claimant
might have been a victim of trafficking. A further interview took place (also on 30 August 2016) and at this
time the Claimant was asked to provide further information about how she had come to be in the United
Kingdom and what had happened to her on and after arrival. The Claimant stated that on arrival she had
been met by a man and a woman, taken to a massage parlour in Euston, and locked in a room. She was
imprisoned and forced to work as a prostitute; she was beaten. The Claimant said that in June 2015, after
abo t 2 months at the massage parlo r she escaped After then she had no contact either ith an one


-----

who worked at the massage parlour, or with the agent who had arranged for her to travel to the United
Kingdom.

4. Following the two interviews (and also on 30 August 2016) a National Referral Mechanism (“NRM”)
form was completed in respect of the Claimant, seeking a reasonable grounds determination as to whether
the Claimant had been a victim of trafficking. The referral was made by the Immigration Officer (Ms.
Tyacke) who had conducted the second interview on 30 August 2016. It appears that the NRM form was
sent to and received by the Competent Authority on 31 August 2016. The referral concerned the events
that had taken place immediately before and immediately following the Claimant's arrival in the United
Kingdom; it did not concern any events after her escape from the Euston massage parlour in June 2015
(and for the avoidance of doubt it did not relate to the Claimants' work at the massage parlour in Salford,
immediately prior to her arrest in August 2016).

5. The National Referral Mechanism is part of the arrangements made by HM Government to meet the
United Kingdom's obligations under the Council of Europe Convention on Action against Trafficking in
Human Beings (“the Anti-Trafficking Convention”). Article 10 of the Anti-Trafficking Convention requires the
State parties to make suitable arrangements to identify persons who are victims of trafficking. The AntiTrafficking Convention provides that “competent authorities” within each State party will have responsibility
for this task. The Explanatory Report to the Convention states that the competent authorities will be those
public authorities who may have contact with trafficking victims. The Anti-Trafficking Convention also
provides for specified forms of assistance to be provided to two classes of person: first to persons who are
or have been victims of trafficking; and second to persons who, on reasonable grounds, are believed to be
victims of trafficking. The Competent Authority Guidance published by the Home Office on 21 March 2016
describes the NRM as a victim identification and support process. This guidance identifies a number of
competent authorities within the Home Office, one of which is the Detained Asylum Casework Team. The
Competent Authority Guidance also refers to _“first responders”; these are specified statutory authorities_
and non-governmental organisations who have responsibility for identifying potential victims of trafficking.
The Home Office is one of these first responders, and this obviously includes Immigration Officers working
within detention centres. The Competent Authority Guidance states that the NRM mechanism is to be used
in any case in which the relevant first responder _“… suspects a person is a potential victim …” of_
trafficking. Such persons are identified by reference to a range of indicators set out in separate guidance
also published by the Home Office in March 2016 – _“Victims of_ **_Modern Slavery – Frontline Staff_**
_Guidance” (“the Frontline Staff Guidance”)._

6. In cases where any of the indicators are present there is an expectation that a referral will be made
using the NRM form. On receipt of a referral, the Competent Authority must make a reasonable grounds
decision – i.e. decide whether there are reasonable grounds to believe that the person is a victim of
trafficking. The reasonable grounds stage is an initial filter to identify victims of trafficking. Where a positive
reasonable grounds decision is taken, the Competent Authority then goes on to decide whether the person
is in fact a victim of trafficking (the so-called “Conclusive Grounds decision”). The Competent Authority
Guidance states that the “… expectation is that the Competent Authority will make a reasonable grounds
_decision within 5 working days of the NRM referral being received …”; the Guidance then goes on to say_
_“Reasonable grounds decisions for cases in immigration detention will be considered as soon as possible”._
For present purposes it is important to note that where a positive reasonable grounds decision is made in
respect of a person in immigration detention, the ordinary consequence will be that the person is released
from immigration detention. This is stated both in the Secretary of State's Guidance to Immigration Officers
(see Enforcement Instructions and Guidance, Chapter 9 at §9.9); and in the Competent Authority
Guidance. The former states as follows (so far as is material for present purposes):

“Competent Authorities will aim to complete an assessment of whether there are 'reasonable grounds to
believe' someone is a victim [of trafficking] within 5 days of referral. A positive decision with trigger a 45 day
'recovery and reflection' period during which time individuals will not be detained (unless their detention
can be justified on grounds of public order) and removal action will be suspended. …”

7. Although the Claimant's case was referred to the relevant Competent Authority (within the Detained
Asylum Casework Team) on 31 August 2016 the reasonable grounds decision was not taken until 15


-----

September 2016. The decision taken then (set out in a letter to the Claimant dated 15 September 2016),
was a positive reasonable grounds decision. Arrangements for the Claimant's release from detention were
put in place on the same day, and she was released.

8. Part of the documentary evidence for this hearing is the product of a subject access request made by
the Claimant under section 7 of the Data Protection Act 1998, directed to the Home Office. The
consequence of this is a large amount of documentation relating to the Claimant's arrest, detention and
release, including not only the GCID case record sheets, and detention review documentation ordinarily
available for claims of unlawful detention, but also various internal emails. All this runs to the better part of
400 pages; but as is to be expected, there are gaps in the paper trail. This is problematic, in particular
because the Secretary of State has not provided any witness evidence to give an overall narrative of how
the Claimant's case was handled between 31 August and 15 September 2016, and in particular, the steps
taken in respect of the reasonable grounds decision from the time the NRM form was provided to the part
of the Detained Asylum Casework team that acts as the relevant Competent Authority.

9. Doing the best that I can, the position seems to have been as follows. The NRM form was sent on 31
August 2016. Attached to that form was the record of the second interview which had been conducted with
the Claimant and which concerned matters relevant to whether or not she had been trafficked. The record
provided a fair amount of detail on what the Claimant said had happened to her on arrival in the United
Kingdom and in the two months following.

10. Also on 31 August 2016 the Claimant's asylum claim was accepted into the Detained Asylum
Casework system. The NRM form was received by a “Technical Specialist” within the Detained Asylum
Casework team. He sent an email on 31 August 2016 in which he stated the following:

“I can see from CID this applicant has only just been accepted into DAC. Is there any rough idea when the
asylum interview will be scheduled for. I appreciate this may be hard to say at this point but if I could be
kept updated so I can get this allocated to a CA to complete the Reasonable Grounds decision. The sooner
we can get the interview completed the better due to the RG timescales.”

Although the email does not say so in terms, I infer from it that a decision had already been taken that any
Reasonable Grounds decision would await the Claimant's Asylum Interview. There is no explanation before
me of the reasons for this decision.

11. By 6 September 2016, the Claimant's asylum interview had been scheduled for 9 September 2016, but
on 7 September, solicitors acting for the Claimant requested that the asylum interview be rescheduled.
This request was repeated in a letter dated 8 September 2016. The request was made on the basis that
the Claimant's asylum claim ought not to be progressed until a reasonable grounds decision had been
taken; and that until that time the Claimant should also be released from detention. At this time, the
Claimant's solicitors were under the impression that no NRM referral had taken place. The Home Office
replied to this letter on 9 September 2016, stating that the asylum interview was postponed until 15
September. That letter stated that the NRM referral had been made on 31 August 2016; it stated that the
Claimant would remain in detention for the present on the ground that she was considered a “high risk to
_abscond”; but also stated that in the event of a positive reasonable grounds decision, the Claimant would_
be released from detention. The CID record for this time is to the effect that the asylum interview was
postponed at the request of the Claimant's solicitors because they had had insufficient time to take
instructions from the Claimant.

12. On 9 September 2016, following the decision to reschedule the asylum interview, the reasonable
grounds decision was allocated to a caseworker (Ms. Przykuta), for her consideration on 16 September
2016, following the Asylum Interview. The caseworker was provided with the NRM form and was informed
that the asylum interview record would be sent to her. Thus, as at 9 September 2016, the position taken
was that the reasonable grounds decision could not be taken until the asylum interview had taken place.
Again, there is no evidence setting out the reasons for this decision.

13. On 10 September 2016 solicitors acting for the Claimant sent a letter before claim. That letter
challenged the decision to allocate the Claimant's case to the Detained Asylum Casework team in advance


-----

of the reasonable grounds decision. That letter made various points in support of the overall contention that
the Claimant's asylum claim should not be processed until the reasonable grounds decision had been
taken. Among those points was one to the effect that following the NRM referral the Claimant ought not to
have remained in detention, and that her continued detention was at odds with the Secretary of State's
policy as set out in Chapter 55 of the Enforcement Instructions and Guidance (“EIG”) and in particular
§55.10 of that guidance which concerns detention of persons who are regarded as vulnerable. EIG §55.10
identifies various classes of person as “suitable for detention in only very exceptional circumstances”. One
of these classes is “persons identified by the competent authorities as victims of trafficking (as set out in
_Chapter 9, which contains very specific criteria concerning detention of such persons)”. The Claimant's_
solicitors wrote again, to similar effect, on 12 September 2016. This time reference was made to the
Competent Authority Guidance in support of the proposition that no asylum interview (within the Detained
Asylum Casework or otherwise) should take place pending the Reasonable Grounds decision.

14. The response to the letter before claim was sent by Ms. Tyacke (the officer who had made the NRM
referral), on 12 September 2016. Amongst other matters, that letter stated that the Detained Asylum
Safeguarding Team, having received the NRM referral form _“felt it was necessary for an interview to be_
_conducted before a Reasonable Grounds decision could be made”. The letter went on to state that a_
reasonable grounds decision would be taken and communicated on 16 September 2016, the day after the
interview.

15. On 14 September 2016 the present judicial review proceedings were commenced claiming that it was
unlawful to detain the Claimant and consider her claim for asylum _“in circumstances where there is a_
_pending trafficking investigation under the NRM”. The Claim Form was accompanied by an application for_
interim relief in the form of an order preventing the Secretary of State progressing or determining the
Claimant's claim for asylum pending resolution of the judicial review claim. On 14 September 2016 Whipple
J granted the application for interim relief; and as a result the asylum interview scheduled for 15 September
2016 was cancelled. The GCID case record sheet suggests that in consequence of the interim relief, the
decision was taken (on 15 September 2016) to release the Claimant because no further action could be
taken on her asylum claim. However, given the views expressed in detention reviews prior to that date (and
most recently, on 8 September 2016) as to the risk that if released the Claimant would abscond, it seems
to me to be equally if not more likely that the reason for the decision to release the Claimant from detention
was that on 15 September 2016 the Competent Authority decided that there were reasonable grounds to
believe that she had been trafficked. The Claimant was informed of the reasonable grounds decision by
letter dated 15 September 2016. Also on 15 September 2016 the Home Office wrote to the Claimant's
solicitors enclosing a copy of the reasonable grounds decision, stating that the Claimant would be released
that afternoon.

**B.                        The Claimant's claims**

16. The Claimant's claim is that her detention after 31 August 2016, the date of NRM referral, was unlawful
at common law, because it was at odds with the Secretary of State's stated policies on immigration
detention. This is the context for the submission that once the NRM referral was made it was unlawful for
the Secretary of State to take any further step in consideration of the Claimant's asylum claim, and unlawful
to maintain the Claimant's detention. Alternatively, the Claimant contends that at some point after the NRM
referral, her detention became unlawful because of the time taken to complete the reasonable grounds
decision. As stated above (see paragraph 6), the guidance is to the effect that reasonable grounds
decisions are taken within 5 working days in all cases, and as soon as possible in cases where the person
concerned is in immigration detention. If the referral took place on 31 August 2016, the fifth working day
following was 7 September 2016; yet the reasonable grounds decision was taken on 15 September 2016.

17. Further, the Claimant contends that her detention after the date of the NRM referral was unlawful
[under the Human Rights Act 1998 because it was contrary to ECHR article 4. The basis for this claim is to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
the effect that adjectival obligations arise under ECHR article 4, including an obligation to “take operational
_measures” to protect victims or potential victims of trafficking. Detention following the NRM referral_
(contends the Claimant) amounted to a breach of that obligation; and/or the failure to take the reasonable


-----

grounds decision within the timescale stated by the Secretary of State's guidance amounted to a breach of
ECHR article 4.

**C.                              Analysis**

_(1)                    Was the Claimant's detention unlawful from 31 August 2016?_

18. In my judgment the Claimant's detention following the NRM referral was not inconsistent with the
Secretary of State's stated policies.

19. The first source of relevant policy statements is the Enforcement Instructions and Guidance. It is
common ground between the parties that the Claimant's detention was not inconsistent with EIG §55.10,
the part of Chapter 55, in force as at August 2016, which is headed _“Persons considered unsuitable for_
_detention” and which identifies categories of person who “are normally considered suitable for detention in_
_only very exceptional circumstances”. Version 20 EIG Chapter 55 was in force as at 30 August 2016. In_
that version, one of the categories considered unsuitable for detention was _“persons identified by the_
_competent authorities as victims of trafficking (as set out in Chapter 9, which contains very specific criteria_
_concerning detention of such persons)”. However, the Claimant did not fall within this class; as at 31_
August 2016 although she had been the subject of an NRM referral, she had not been identified as a victim
of trafficking. Even as at the time of her release from detention on 15 September 2016, the furthest the
Claimant's case had got was a reasonable grounds decision.

20. Nor is there anything in EIG Chapter 9 that requires the conclusion that the Claimant's detention
became unlawful because she was the subject of an NRM referral. Chapter 9 does not address detention
as a discrete topic. However, it is plain that Chapter 55 does anticipate that persons who are the subject of
an NRM referral detention might be detained in the ordinary course of events. Potential victims of
trafficking are only identified for distinct treatment, so far as concerns detention if they are the subject of a
positive reasonable grounds decision; when there is a positive grounds decision, the guidance states that
there should be no detention “unless ... detention can be justified on grounds of public order”.

21. For sake of completeness I mention Version 21 of EIG Chapter 55 that came into effect on 9
September 2016 (while the Claimant remained in detention). In this version, §55.10 has been re-titled
_“Adults at risk”, and cross-refers to a new Chapter 55b. The part of Chapter 55b which concerns victims of_
trafficking states as follows:

“Any decision made on the immigration detention of an individual who has received a positive reasonable
grounds decision under the National Referral Mechanism (NRM), and who has not yet received their
conclusive grounds decision or otherwise left the NRM, will be made on the basis of the modern slavery

policy set out in separate guidance

For full guidance relating to victims of **_modern slavery and the responsibilities of competent authorities_**
see: Victims of modern slavery – guidance for frontline staff.”

There is nothing in this iteration of the guidance either that rendered the Claimant's detention unlawful.
Chapter 55b simply redirects attention to the Frontline Staff Guidance.

22. There is one further matter to address, arising from the EIG. One aspect of the Claimant's claim is that
following the NRM referral, it was unlawful for the Secretary of State to continue to process the asylum
claim (which the Claimant had first asserted on 22 August 2016). This too (it is said) goes to the legality of
the Claimant's detention because if the Claimant's asylum claim could not be processed, there would be no
sufficient reason which warranted her detention under Immigration Act powers. It is clear that EIG Chapter
9 provides no support for this submission – §9.8.1 states that UKBA officers may be required to conduct
_“immigration status interviews” with persons who are the subject of an NRM referral, and the paragraph_
then provides guidance for the way in which such interviews should be conducted. If this is the position in
respect of an immigration status interview, I can see no reason why a like approach ought not to apply for
interviews on other matters, taking into account the possibility for adjustments equivalent to those
mentioned in the course of §9.8.1 so as to ensure that the interview does not cut across matters relevant to
the subject matter of the NRM referral. In short, what is required of the interviewer on such an occasion is


-----

sensible judgement. Further, so far as I can see §9.10 (the part of it headed _“Detained Fast Track ... &_
_Detained Non-Suspensive Appeal ... cases”) says nothing to suggest that if an NRM referral is made, no_
further steps can be taken in respect of an asylum claim. True it is, that the Detained Fast Track process
has now been removed and replaced, but that does not detract from the legality _per se, of continuing to_
consider an outstanding asylum claim while an NRM reasonable grounds determination is also pending.

23. The other guidance documents material to the Claimant's circumstances are the Frontline Staff
Guidance and the Competent Authority Guidance. The Frontline Staff Guidance is directed to all Home
Office frontline staff, not just immigration officers. The guidance is intended to assist those staff to identify
potential victims of modern slavery, refer cases appropriately to the NRM, and provide victims of modern
**_slavery with access to services they are entitled to receive. The guidance is structured around four “key_**
_steps”; the fourth of these steps is arranging accommodation for potential victims. The purpose of this step_
is to ensure that those who have been identified as potential victims of trafficking are removed from risk of
harm at the hands of their traffickers or others who facilitate **_modern slavery. What is to be done is_**
encapsulated in the following statement:

“Arranging accommodation may be done either:

- From the day of referral to the NRM where the individual is destitute

- From the day the competent authority makes a positive reasonable grounds decision in other cases

If the competent authority has reasonable grounds to believe someone is a victim of modern slavery the
Home Office is obliged to make sure their accommodation is appropriate and secure.

This means accommodation must meet their support needs and be secure enough to make sure victims
cannot be kidnapped by traffickers or modern slavery facilitators. ...”

None of this touches at all on the proposition that it was unlawful to detain the Claimant after the NRM
referral. The words in the first bullet point in the passage quoted above are not apt to describe the
Claimant's situation as at 31 August 2016. The Frontline Staff Guidance is not specific to persons subject
to immigration control, and that being so there is no reason why those words need to be understood to
apply to a person in the position of the Claimant. Moreover, giving those words that meaning would entail
reading this guidance as being inconsistent with the guidance on detention set out in the EIG. There is
neither need nor reason to do this.

24. The Competent Authority Guidance is primarily concerned with decisions to refer under the NRM,
reasonable grounds decisions, and conclusive grounds decisions. That being so, it is less likely that it will
have anything to say that is conclusive in respect of the use of immigration detention powers. However, the
following is stated (at pp. 56 – 58) in respect of cases where there has been a positive reasonable grounds
decision:

“If the Home Office is the Competent Authority they will need to consider additional next steps in live
immigration cases once a reasonable grounds decision has been taken ...

**... Action 7: consider whether a potential victim can be released from detention**

If the potential victim of trafficking or modern slavery is in immigration detention they will normally need to
be released on TA or TR by the Home Office unless in the particular circumstances, their detention can be
justified on grounds of public order.

_..._

Therefore a detained person is usually released from immigration detention if they receive a positive
reasonable grounds decision ...”

Again, the inference that is to be drawn from this, is that the Competent Authority Guidance makes no
assumption that referral to the NRM requires or gives rise to any presumption that immigration detention
will end. Rather, it is clear that – consistent with the other guidance already referred to – the presumption


-----

of release from immigration detention arises only once a positive reasonable grounds decision has been
taken.

25. Drawing these matters together, I can see nothing in the various guidance documents to the effect that
immigration detention must or ought usually to, come to an end if the person concerned is the subject of an
NRM referral. Moreover, there is no inherent inconsistency between lawful immigration detention – lawful in
accordance with the well-known _Hardial Singh principles – and a situation in which a person who is so_
detained is also the subject of an NRM referral. Put another way, the fact that there has been an NRM
referral does not mean that detention ceases to be for purposes permitted under 1971 Act powers
(regardless of what the position might be if at some point thereafter there is a conclusive grounds decision
in respect of the person detained). Nor does the fact of a referral mean that it is inevitable that the
detention will be for a period beyond that reasonably necessary. This point is underlined by the
requirement that a reasonable grounds decision may be expected in a short period of time – i.e. “as soon
_as possible” in situations where the person is in immigration detention. In this regard it is also relevant_
that, there is no inconsistency between the fact of an NRM referral and continuing consideration of an
asylum claim. As I have already stated there is nothing in the Secretary of State's guidance that indicates
that once an NRM referral has been made, consideration of an asylum claim must be put on hold; nor can I
see anything in the Trafficking Convention from which any such requirement could arise. The situation may
well be different if removal, following rejection of an asylum claim, was in prospect when a reasonable
grounds determination remained pending. But that is not this case at all. For all these reasons, the
Claimant's first ground of challenge fails.

_(2)                              Did the Claimant's detention become unlawful at some point after_
_31 August   2016?_

26. The Claimant's alternative case is that even if, as at 31 August 2016 her detention was not unlawful, at
some time after 31 August it became unlawful. The Claimant points to the statement at Chapter 9 of the
EIG (set out above at paragraph 6), and to the statement in the Competent Authority Guidance (at page
50) which provides:

“The expectation is that the Competent Authority will make a reasonable grounds decision within 5 working
days of the NRM referral being received at the UK Trafficking Centre…where possible.

Reasonable grounds decisions for cases in immigration detention will be considered as soon as possible.”

Neither statement mandates the period for a reasonable grounds decision that must be met in all cases,
regardless of circumstances. However, the statements are sufficient to establish working assumptions that
decisions will be made in five working days, and that decisions will be _“as soon as possible” where the_
person concerned is in immigration detention.

27. In this case the referral was on 31 August 2016, so the fifth working day following was 7 September
2016. It is clear that very soon after the referral a decision was taken to the effect that the reasonable
grounds decision would await the asylum interview (see above at paragraph 10). There is no evidence
explaining why that decision was taken in this case – for example what information was it that it was
thought might arise from the asylum interview that was not addressed on the NRM referral form. The
asylum interview was originally scheduled for 9 September, but was then postponed (at the request of the
Claimant's solicitors), and re-arranged for 15 September 2016. When that decision was taken it was also
decided that the reasonable grounds decision would not be considered until 16 September 2016 (see
above at paragraph 12). Again, the evidence available does not explain the reasons for that decision.

28. Conversely the evidence does not provide any narrative explaining the change of approach after the
commencement of proceedings on 14 September 2016 and Whipple J's Order made that same day. That
Order prevented the asylum interview from going ahead; but there is no explanation why the reasonable
grounds decision then came to be taken on 15 September, notwithstanding there had been no asylum
interview. It is, moreover, clear that the positive reasonable grounds decision that was taken, was taken on
the basis of information available either at the time of the NRM referral on 31 August 2016, or shortly after.
The Positive Reasonable Grounds Minute – a document completed as a record of the decision – identifies


-----

the documents taken into account for the purposes of the decision, in addition to the NRM referral form, as
being the asylum screening interview and a US State Department report on trafficking.

29. On the evidence as it stands there is no obvious reason why the positive reasonable grounds decision
taken on 15 September 2016 could not have been taken significantly earlier – and in accordance with the
working assumptions that I have referred to at paragraph 26 above, _“as soon as possible” or_ _“within 5_
_working days”. I do not regard either of these assumptions as giving rise to hard-edged rules, but where_
reasonable grounds decisions are not forthcoming in accordance with them, it is reasonable to expect
some explanation to be available. The documents in evidence in this case do not provide that explanation,
and there is no witness evidence from the Home Secretary to address what happened and why between
31 August and 15 September 2016.

30. At the hearing, Mr. Rawat, who is instructed for the Home Secretary asked for an adjournment in order
to try to obtain evidence explaining why at first the reasonable grounds decision had been delayed pending
the asylum interview, but then following the Order made by Whipple J on 14 September 2016, was then
taken even though no asylum interview had occurred. Ms. Luh, instructed by the Claimant, opposed that
application. In making his application Mr. Rawat explained, quite fairly, that before the hearing attempts
had been made to obtain this information, without success. That being so, and since it was also clear from
the Home Secretary's pleaded case that she was alert to the fact that what happened and why during the
period 31 August 2016 to 15 September 2016 was in issue in this case (see the Summary Grounds of
Defence at paragraph 16), I refused the application to adjourn. The evidence could and should have been
provided in advance of the hearing, and there was no good reason why it had not been so obtained; there
was no obvious reason to believe that an adjournment now would produce evidence, given that previous
attempts had failed; and in any event, an adjournment now would not be consistent with the principles set
out in the CPR Part 1 overriding objective, and in particular would entail a disproportionate use of Court
time on this litigation.

31. On the evidence that is available, my conclusion is that the reasonable grounds decision could and
should have been taken before 15 September 2016; I can see no reason why the decision could not have
been taken at least by 7 September 2016 – that is to say within the 5 working day window referred to in the
Competent Authority Guidance as the period within which reasonable grounds decisions will ordinarily be
made. I appreciate that the Claimant's argument on this part of her case is that the guidance provides that
where a person is in immigration detention, reasonable grounds decisions will be taken _“as soon as_
_possible”. However, that does not alter the conclusion I have reached in this case. The statements in the_
guidance are no more than targets; whether and when detention in any specific case became unlawful
must rest on an overall assessment of the matter; it is not for a court on this sort of issue, to determine the
line between lawful and unlawful action by seeking to micro-manage the way in which finite operational
resources ought to have been allocated. There was nothing on the facts of the Claimant's case that called
for the NRM referral to be treated as a matter of special urgency. Allowing for sensible latitude when
judging administrative processes my conclusion is that the reasonable grounds decision ought to have
been taken by 7 September 2016.

32. It follows from this that after 7 September 2016, the Claimant's detention became unlawful. It is clear
that a positive reasonable grounds decision will ordinarily result in release from immigration detention (see
both the EIG at Chapter 9, and also the Competent Authority Guidance). I consider that this is a statement
of policy which bears on the legality of detention, in the sense explained in R(Lumba) v Secretary of State
_for the Home Department [2012] 1 AC 245, and R(SK, Zimbabwe) v Home Secretary [2011] 1 WLR 1299._
On the facts of this case, the information available in respect of the Claimant as at 7 September 2016 was
the same as that which resulted in the positive reasonable grounds decision on 15 September 2016; thus
had the matter been addressed by 7 September 2016 the same positive reasonable grounds decision
would have been taken. On the facts of this case there was no suggestion that there were any public order
grounds that would warrant continuing detention notwithstanding the positive reasonable grounds decision.
Thus, on the facts here the timing of the positive reasonable grounds decision goes directly to the legality
of the Claimant's detention. For these reasons, my conclusion is that the Claimant was unlawfully detained
from 8 September 2016 to 15 September 2016, inclusive.


-----

_(3)                        The Claimant's claim under ECHR article 4_

[33. The argument that the Claimant's detention was unlawful under the Human Rights Act 1998 because it](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
was contrary to ECHR article 4 is that following the NRM referral on 31 August 2016 that detention
amounted to a breach of the obligation that arises under article 4 to “take operational measures” to protect
victims or potential victims of trafficking. In this case, the required operational measure was to release the
Claimant from detention once the NRM referral had been made. The Claimant also contends that the
failure to take the reasonable grounds decision within the timescale stated by the Secretary of State's
guidance amounted to a breach of ECHR article 4.

34. The obligation to take operational measures is one of a number of obligations which have been
identified as adjectival to the express prohibitions in article 4 against slavery, servitude, forced labour and
compulsory labour. The obligation under article 4 to take such operational measures is referred to at §286
of the judgment of the European Court of Human Rights in Ranstev v Cyprus and Russia (2010) 51 EHRR
1. The Court went on to state that the obligation arose when state authorities were aware or ought to have
been aware of circumstances giving rise to a credible suspicion that a person had been a victim of
trafficking or was at real and immediate risk of becoming a victim. That Court referred to and repeated the
obligation – in materially the same terms – at §106 of its judgment in J v Austria (Application No. 58216/12,
judgment 17 January 2017).

35. In _Secretary of State for the Home Department v H_ _[[2016] EWCA Civ 565 the Court of Appeal](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_
characterised the overall effect of these adjectival obligations in this way (per Burnett LJ at §29):

“Thus the focus of the procedural obligation under article 4 is to investigate cases of alleged trafficking and
to identify those responsible for crimes committed within the jurisdiction of the State Party in question with
a view to prosecution for offences which have occurred within that jurisdiction. It is also concerned with
immediate relief for those suffering harm and coercion. This latter aspect of the investigative obligation
would arise, for example, if a credible report were received that a factory of the sort in Russia described by
the Respondent were operating in this country.”

This is the proper extent of the ECHR article 4 obligation, and it is clear to me that that obligation does not
have anything material to say about the Claimant's complaint in this case, whether it is the complaint about
detention following the NRM referral, or the complaint based on undue delay in making the reasonable
grounds decision. The obligation to take operational measures is directed to preventing trafficking, to the
protection of victims of trafficking from further trafficking, and the protection of potential victims of trafficking
where there are grounds to suspect they may be at immediate risk of being trafficked. As at August 2016
the Claimant was neither in need of protection from those who may previously have trafficked her, nor was
she in need of protection against any imminent risk of being trafficked in future.

36. Further, any attempt by the Claimant to elide the scope of the obligation under ECHR article 4 with the
extent of the protection afforded to potential victims of trafficking under the Competent Authority Guidance,
must also fail. _First, so far as the Claimant's complaint is that she should not have been detained at all_
once the NRM referral had been made, for the reasons I have set out above there is no part of the
Guidance which can be read as meaning that immigration detention must cease once a referral has been
made. Second, so far as the Claimant's complaint is that her detention became unlawful because of the
time taken to take the reasonable grounds decision, although as I have concluded above, what happened
in this respect was contrary to the Guidance, that fact alone is not conclusive proof of a breach of ECHR
article 4. In H, Burnett LJ made it clear that the Guidance was directed to recognition of the obligations that
arise under the Anti-Trafficking Convention, and was not to be equated with the action required to avoid a
breach of ECHR article 4. On the facts of this case, there is nothing arising from the time taken to address
the reasonable grounds decision that, as a matter of substance can be characterised as amounting to a
breach of any of the obligations which are part and parcel of ECHR Article 4.

37. For these reasons, the claim based on ECHR article 4 fails.

**D.                        Conclusion**


-----

38. It follows from the above, that the Claimant's claim for unlawful detention succeeds only to the extent
that she was unlawfully detained between 8 September 2016 and 15 September 2016. The claim under the
Human Rights Act fails in its entirety.

**End of Document**


-----

