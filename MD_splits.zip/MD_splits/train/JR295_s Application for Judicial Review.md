# JR295's Application for Judicial Review [2024] NIKB 44

NORTHERN IRELAND KING'S BENCH DIVISION

HUMPHREYS J

31 MAY 202431 MAY 2024

**Immigration — Judicial Review — Application of provision — Applicants' claiming judicial review relating to**
**Illegal Migration Act 2023 (IMA) — Respondents applying for stay pending determination of appeal to Court**
**of Appeal — Respondents claiming that IMA commencement will lead to dual and inconsistent immigration**
**systems in UK in light of disapplication of statutory provisions in Northern Ireland — Whether court having**
**power to suspend disapplication of inconsistent domestic provision — Whether court should exercise**
**power — Illegal Migration Act 2023 — Rules of the Court of Judicature (Northern Ireland) 1980, SI 1980/346,**
**Ord 59, r 13 — Human Rights Act 1998.**

**HUMPHREYS J:**

**_The Court Order_**

**[[1] On 13 May 2024 I handed down judgment in these judicial review applications relating to the Illegal Migration](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)**
_[Act 2023 ('IMA'). On foot of that judgment, the parties have now agreed an order in the following terms:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_

“1. The Applicants' claims for judicial review are upheld on the grounds relying on the “Windsor Framework”
[and on the Human Rights Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

**Windsor Framework**

2. Sections 2(1), 5(1), 5(2), 6, 13(4), 22(2), 22(3), 25, 54 and 57 are declared to breach Article 2 of the Windsor
Framework of the EU-UK Withdrawal Agreement.

[3. The following sections of the Illegal Migration Act 2023 are disapplied in Northern Ireland:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)

a Section 2(1);

b Section 5(1);

c Section 5(2);

d Section 6;

e Section 13(4);

f Section 22(2);

g Section 22(3);

h Section 25;


-----

i Section 54; and

j Section 57.

**_[Human Rights Act 1998](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_**

4. Pursuant to _[section 4 of the Human Rights Act 1998, the following provisions of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0T1-00000-00&context=1519360)_ _[Illegal Migration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_
_[2023 are declared to be incompatible with the European Convention on Human Rights in the following ways:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:68T5-C2H3-RRXV-S31K-00000-00&context=1519360)_

a Sections 2(1), 5(1), 6(3) and 6(7) are incompatible with Article 3 ECHR insofar as they impose a duty to
remove.

b Sections 2(1), 5, 6, 22 and 25 are incompatible with Article 4 ECHR insofar as they relate to potential victims
of modern slavery or human trafficking.

c Sections 2(1), 5(1) and 6 are incompatible with Article 8 ECHR insofar as they relate to children.”

**[2] The Order also recites that JR295's application in respect of s 57 of the IMA is dismissed, and deals with the**
issues relating to costs.

**_The Stay Application: The Principles_**

**[3] The Respondents now apply to the court for a stay pending the determination of an appeal to the Court of**
Appeal, pursuant to Ord 59 r 13 of the Rules of the Court of Judicature (Northern Ireland) 1980 ('the Rules').

**[4] Order 59 r 13 states:**

“(1) Except so far as the court below or the Court of Appeal may otherwise direct–

a an appeal shall not operate as a stay of enforcement or of proceedings under the decision of the court
below;

b no intermediate act or proceeding shall be invalidated by an appeal.”

**[5] It is apparent from the authorities that no stay will be granted pending an appeal unless good reasons are**
demonstrated. It may, for instance, be granted when otherwise the appeal would be rendered academic (cf. Orion
_Properties v du Cane [1962] 1 LR 1085)._

**[6] The Respondents in this case contends that, once the IMA is commenced, the potential arises for dual and**
inconsistent systems of immigration in the United Kingdom in light of the disapplication of the statutory provisions in
Northern Ireland. It is argued that such is the unusual and novel nature of relief granted in these proceedings, this
court should stay the impact of its order until the issues are determined by the Court of Appeal or the Supreme
Court.

**[7] In R (Liberty) v SSHD [2018] EWHC 975 (Admin), Singh LJ emphasised the following important principles:**

i The disapplication of domestic legislation which is incompatible with EU law is the duty of the national court; and

[ii The jurisprudence relating to the sections 3 & 4 of the Human Rights Act 1998 is irrelevant and misleading in this](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0RX-00000-00&context=1519360)
context (see paras [63] to [69])

**[8] Recently, in R (Open Rights Group) v SSHD (no. 2) [2021] EWCA Civ 1573, the Court of Appeal in England &**
[Wales held that the “immigration exemption” in the Data Protection Act 2018 was contrary to art 23 of the GDPR.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5SF6-8TH1-JBXK-N0FS-00000-00&context=1519360)
The court recognised that the GDPR retained supremacy over domestic legislation and any conflict meant that:

“domestic legislation must be overridden, treated as invalid or, in the conventional language, disapplied” (para

[14])


-----

**[9] The question arose as to whether the court had power to suspend the disapplication of an inconsistent**
domestic provision and, if so, whether and in what circumstances it should be exercised. Following an analysis of
the jurisprudence, the court held:

i Such a power did exist;

ii It should be exercised only exceptionally and on the basis of “overriding considerations of legal certainty”; and

iii If it is exercised, it should only be on a temporary, time limited basis.

**[10] There may therefore be circumstances when it would be appropriate to afford the Government an opportunity**
to formulate a solution to the identified inconsistency or incompatibility within a fixed time period. However, such
relief is only to be granted where:

“the interests of legal certainty must be so compelling that it is necessary for them to take priority over the need
to implement the dominant legal provision, and disapply the subordinate law” (para [32])

**[11] It is evident therefore that there is a significant burden on a party seeking a stay or suspension of a court order**
for disapplication.

**_The Stay Application: The Merits_**

**[12] The legislative provisions challenged in these proceedings are not yet commenced. Neither at the substantive**
hearing nor for the purposes of this stay application, have the Respondents placed any material before the court
which indicates a timetable for the commencement. It has been suggested that the Home Office is keen to move to
commencement as soon as possible but such aspiration has not manifested itself into any legislative programme.

**[13] The court is aware that Parliament has been dissolved and whilst Ministers remain in office, there is no**
indication that any Minister intends to lay a commencement order.

**[14] There is no basis to contend that the Respondents' appeal would be rendered academic or nugatory by the**
absence of a stay. If the IMA's provisions are commenced in the interim, they will take effect in Northern Ireland in
due course if the Respondents' appeal is successful.

**[15] If, by contrast, the stay was granted and the statutory provisions commenced, this could cause irremediable**
harm to asylum seekers in Northern Ireland and to JR295 in particular. It could lead to removal and refoulement in
circumstances where the court had ruled that these provisions were in breach of the rights enjoyed under the
Windsor Framework, the Withdrawal Agreement and the Withdrawal Act.

**[16] This is not a case where some minor alterations to the legislation or the making of some regulations could**
cure the incompatibility which has been found. The provisions impugned are at the very heart of the IMA. In any
event, the Respondents are not proposing to consider some legislative solution but rather seek to challenge the
findings on appeal.

**[17] The remedy of disapplication in these cases is entirely orthodox and in keeping with established principles set**
out in _Liberty. The judgment is not unusual or novel as has been claimed by the Respondents. Disapplication of_
domestic law which is inconsistent with superior EU law has been part of our legal system and understanding for
well over a generation.

**_Conclusion_**

**[18] The Respondents have failed to satisfy me that either the appeal would be rendered academic or that the**
criteria laid down in Open Rights Group are met on the facts of this case. There is no evidence that this judgment
will cause any chaos or that the interests of legal certainty are so compelling that an exceptional approach should
be adopted.


-----

**[19] The Respondents' application for a stay is therefore refused and the Order will take immediate effect.**

Application dismissed.

**End of Document**


-----

