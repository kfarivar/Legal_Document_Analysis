Respondent 2022 Scot (D) 29/2

# MYRNA REBUJIO PASIAN Petitioner against THE SECRETARY OF STATE
 FOR THE HOME DEPARTMENT Respondent 2022 Scot (D) 29/2

[2022] CSOH 21

Court of Session (Outer House)

OPINION OF LORD BRAILSFORD

Petitioner: Caskie; Drummond Miller LLP for RH & Co

Respondent: McKinlay; OAG

24 February 2022

**OPINION OF LORD BRAILSFORD**
**Introduction**

[1]     The petitioner is an asylum seeker and claims to be a victim of human trafficking in the form of domestic
servitude. She seeks reduction of a “Conclusive Grounds” decision by the Competent Authority, who comes under
the auspices of the Secretary of State for the Home Department, that she is not a victim of trafficking. The
respondent is the Secretary of State and the Advocate General appears on her behalf.
**Legal framework**

[2]     On 17 December 2008, the UK ratified the Council of Europe Convention on Action against Trafficking in
Human Beings (“ECAT”). By virtue of Article 4(a) of the Convention, and the 2000 Palermo Protocol, ratified by the
UK on 9 February 2006, “human trafficking” is defined as:

“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having
control over another person, for the purpose of exploitation. Exploitation shall include, at a minimum, the
exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or services, slavery
or practices similar to slavery, servitude or the removal of organs.”

[3]     It is generally accepted, and is accepted by the parties in this case, that the essence of human trafficking
comprises:

“(a) An action – the person has been subject to the act of recruitment, transportation, transfer, harbouring or
receipt – which is achieved by

(b) a means – the threat or use of force or other form of coercion, of abduction, of fraud, of deception, of
abusive power, of a position of vulnerability, of giving or receiving payments or benefits to achieve the consent
of a person having control over another person – for the purpose of

(c) exploitation – sexual exploitation, forced labour or services, slavery or practices similar to slavery,
servitude, forced criminality or the removal of organs.”


-----

Respondent 2022 Scot (D) 29/2

[4]     Against that background, the National Referral Mechanism (“NRM”) operates by way of a three stage
process. First, it is open to the police, in their capacity as “first responder” to refer a case of suspected human
trafficking to a Competent Authority, and request that it assess whether there are reasonable grounds to suspect
that a person has been a victim of human trafficking. The respondent is such a Competent Authority.

[5]     Second, the Competent Authority conducts a Reasonable Grounds test, designed to act as a filter to
identify potential victims. The relevant standard of proof at that stage is “I suspect but cannot prove” that the person
is a victim of human trafficking. If at this second stage, a positive decision is made, certain obligations arise on the
part of the UK towards that person, with a corresponding degree of protection, by virtue, inter alia, of ECAT.

[6]     Third, in the event that the Competent Authority concludes that there are reasonable grounds to suspect
that a person is a victim of human trafficking, then a substantive Conclusive Grounds decision, as to whether the
person is in fact a victim, is taken. A Conclusive Grounds decision is reached by the respondent on the balance of
probabilities, that is to say that the respondent is satisfied that it is “more likely than not” that the person is a victim
of human trafficking. An adverse Conclusive Grounds decision is not subject to appeal. Nor can it be made subject
of an indirect challenge in the course of an appeal in terms of _[section 82(1) of the Nationality, Immigration and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-74HS-00000-00&context=1519360)_
Asylum Act 2002, as amended, against a removal direction, other than in limited circumstances (MS (Pakistan) v
_Secretary of State for the Home Department [2018] 4 WLR 63 at para 69). Thus, the only method of challenging a_
Conclusive Grounds decision is by way of judicial review.
**Background**

[7]     The factual background to the petition can be summarised as follows. The petitioner is a 52 year old Filipino
national. She entered into an arranged marriage aged 17 years old with a man ten years her senior and suffered
domestic abuse throughout the marriage. In 1991, she travelled to the Middle East to work as a domestic servant.
Between 1991 and 2011, the petitioner worked for four different families. She briefly returned to the Philippines in
1997 before returning to the Middle East. She remained in the Middle East until February 2011.

[8]     The family for whom she worked from 2008 relocated to Glasgow in February 2011 and the petitioner
joined them at their request. She was granted a domestic worker visa on 29 January 2011 and subsequently
entered the UK. She briefly left the UK for the Philippines in May 2011 and returned in August of the same year.
She has remained in the UK since her return.

[9]     The petitioner claims that she was exploited by the family from August 2011. She does not claim that she
was exploited at any time in the Middle East, nor during the time she worked for them in the UK prior to August
2011. The substance of the petitioner's trafficking claim is that (a) she worked from 6am until midnight, six days per
week, (b) she was paid an extremely low wage (c) she was locked inside the family home for significant periods and
unable to leave unaccompanied, (d) her passport was retained when she left the family home unaccompanied and
(e) the family demonstrated their control over her by locking her out of the family home on one occasion.

[10]     She has been residing with her partner in the UK since December 2011. The period that the claimed
exploitation relates to is therefore August until December 2011. The petitioner was encountered and arrested (on
suspicion of overstaying her visa) whilst at a flat in Glasgow on 16 June 2017. She claimed asylum on 23 June
2017. A referral was made to the NRM on 18 September 2017 for the Competent Authority to consider whether the
petitioner was a victim of human trafficking. The Competent Authority issued a positive Reasonable Grounds
decision on 21 September 2017.

[11]     The Competent Authority first issued a negative Conclusive Grounds decision on 22 February 2019.
Judicial review proceedings were raised in relation to that decision, which the respondent conceded and undertook
to reconsider. Expenses were also awarded against the respondent. Two further negative Conclusive Grounds
decisions followed on 25 October 2019 and 30 March 2020 respectively, both of which also resulted in petitions for
judicial review, a concession by the respondent and an undertaking to issue a reconsidered decision. The most
recent decision, which gives rise to the present petition, is undated but was served on the petitioner on 22
December 2020.
**The decision under review**


-----

Respondent 2022 Scot (D) 29/2

[12]     The respondent rejects the petitioner's claim on two bases. First, on credibility grounds. The credibility
issues identified by the respondent can be summarised briefly. The family's retention of the petitioner's passport
when leaving the house unaccompanied is not ipso facto proof of exploitation. It was not reasonable that the
petitioner would only have started being exploited from August 2011 when she had worked for the same family
since 2008 and, on her own account, had not been exploited previously. She had not sought assistance from the
police or other authorities despite having the opportunity to do so. She had indicated in her asylum interview that
she intended to find new employment in the Middle East upon completion of her contract with the family, which
suggested that she was not being forced to work for or remain with the family. The petitioner did not come forward
to the police until 2017 when she was encountered and arrested. She had been inconsistent regarding the date she
commenced employment, although the respondent accepts that she may have difficulty recalling certain facts and
this matter did not go to the core of the claim. The psychological evidence only spoke to the claimed exploitation
being one of the factors which may have impacted her mental health; there were other life events referred to by the
psychologist. The petitioner's credibility issues outweighed the external country information supporting her claim.

[13]     Second, an esto position – even if the petitioner was credible, the events she describes do not amount to
domestic servitude. Having regard to the three elements of trafficking, viz action, means and purpose, the petitioner
travelled to the UK, left and returned voluntarily. She is not a victim of “harbouring” and was lawfully resident while
working for the family. She was not psychologically or physically forced to remain in the UK. This is supported by
the fact that she was permitted access to a mobile phone and to meet friends unaccompanied. The respondent
does not accept the hours the petitioner claims to have worked. It was reasonable for her to care for the child in the
evening given she did not have to during the day. She had considerable freedom and could have sought assistance
from the police. Her claimed vulnerability was not a legitimate reason for not having done so. Exploitation is not to
be confused with working for low wages or in poor working conditions. She remained with the family for her own
economic benefit and was not overworked or humiliated. It is unclear to what extent she was limited access to food.
Even if the wages were low, she was paid and chose to remain with the employer. There was no force or coercion
and she could have chosen not to work. As per the respondent's policy, many of the conditions that might indicate
that a situation of domestic servitude existed were not present in her case.
**Submissions (i)** _Petitioner_

[14]     The petitioner challenges both bases of the respondent's decision. The errors alleged are voluminous and
can best be summarised in a series of short statements. First, relating to the findings made with respect to the
petitioner's credibility:

(a)   The respondent left out of account the petitioner's role as a domestic servant, which created a
situation of vulnerability and led to her exploitation.

(b)   In relying on the petitioner's 'stated intention' to find other employment once the contract ended, the
respondent left out of account that (i) this intention related to a time where she was a victim of trafficking,
(ii) the petitioner never sought alternative employment and (iii) in any event, this does not detract from her
claim.

(c)   The respondent had regard to an irrelevant matter being inconsistencies in the petitioner's account
regarding the date she commenced employment and, in so doing, left out of account that the respondent
had independent evidence verifying the relevant date, as well as that her mental health difficulties could
have affected her ability to recall such dates.

(d)   The respondent left out of account the extent to which the psychological evidence corroborated the
petitioner's claims that she was exploited. The respondent accepted that the petitioner being exploited was
_one of the reasons why she suffered mental health problems, but then concluded her presentation would_
be identical absent that experience, which was an assessment which the respondent was neither qualified,
nor entitled to make.

(e)   The respondent has failed to give adequate reasons and left out of account a relevant, and
potentially material, matter being the reason why the police have completed their enquiries regarding the


-----

Respondent 2022 Scot (D) 29/2

family. The petitioner called on the respondent to provide an explanation of this which she has failed to
answer.

(f)   The respondent left out of account the coercive behaviour employed by the family viz that the
petitioner was locked in the family home for significant periods and that she was vulnerable given her
lawful status in the UK was dependent on the family.

(g)   The respondent left out of account that the petitioner was locked outside the family home, despite
this being a significant matter in previous decisions, suggesting a one-sided and unbalanced decision
having been reached by the respondent.

(h)   The respondent left out of account that victims of trafficking may give “consent” to exploitation where
they feel they have no viable alternative and failed to give any reasons for concluding that the petitioner
had the means to obtain assistance from the police or other authorities.

(i)   The respondent reached perverse conclusions when concluding that (i) the work she was required to
carry out was not sufficiently onerous to amount to domestic servitude and (ii) it was reasonable for her to
be expected to care for the child in the evening.

(j)   In assessing whether the petitioner had a “choice” to report the matter to the police, the respondent
left out of account links between police and immigration authorities which may have made her reluctant to
do so. The respondent also left out of account that choices for those in domestic servitude may be very
narrow.

(k)   The respondent left out of account that there was no evidence that the petitioner remained with the
family for her own economic benefit, which ought to have been within the respondent's knowledge.

(l)   The respondent fails to explain the basis of her conclusion that all victims of trafficking will face
unbearable conditions.

[15]     Second, relating to the respondent's conclusion that the petitioner's account, even if accepted, does not
amount to domestic servitude:

(a)   The respondent fails to adequately explain why the petitioner's account, if accepted, did not amount
to harbouring.

(b)   The respondent fails to explain (i) why the family locking the petitioner out the family home was not a
humiliating action, (ii) why working from 6am until midnight was not exhausting hours, (iii) why being locked
inside the family home was not unbearable conditions and (iv) why being paid little or nothing did not
amount to domestic servitude.

(c)   The respondent left out of account that the petitioner's residence and continued employment was
entirely dependent on the employer's whim.

(d)   The respondent's overall conclusion is fundamentally undermined. She relies on facts which she has
misconceived to be contradictions and implausibilities when they are not, which is unlawful.

[16]     Third and finally, the petitioner challenges the fairness of the decision-making process in the following
respects:

(a)   The respondent did not put the inconsistencies in the petitioner's account to her to provide her with
an opportunity to explain. This approach is unfair and unlawful: _Balajigary_ v _Secretary of State for the_
_Home Department [2019] 1 WLR 4647and GK (India) v Secretary of State for the Home Department 2020_
SLT 1315. The petitioner's asylum interview does not cure this procedural unfairness.

(b)   The respondent gave inadequate reasons by providing no indication of what the positive aspects
were supporting the petitioner's account and how these had been balanced.

_(ii)_ _Respondent_


-----

Respondent 2022 Scot (D) 29/2

[17]     For the respondent, it is contended that the decision was one which she was entitled to reach on the
evidence before her. In response to the complaints made by the petitioner, the respondent submits as follows.

(a)   The respondent had regard to the (i) the fact that traffickers can exert control in a variety of ways, (ii)
the full circumstances of where such control can arise and

(iii)   the petitioner's full account including being locked outside the family home. She was entitled to have
regard to it being unlikely that the family previously employed the petitioner in conditions, which on her own
account, were not domestic servitude.

(b)   The respondent was entitled to have regard to the petitioner's answers in her asylum interview not
being consistent with her being held in conditions of domestic servitude. The asylum interview, at questions
152 to 154, also suggests that she did not seek alternative employment in the Middle East because she
settled with a new partner in Scotland from December 2011.

(c)   The respondent did not treat the inconsistencies regarding the petitioner's date of commencing
employment as material. The respondent acknowledged that the petitioner might face difficulty recalling
such facts and there is no basis for the petitioner's submission that these matters enhance her credibility.

(d)   The decision letter does not accept that the petitioner's claimed exploitation is one of the reasons for
her mental health issues. The psychologist proceeded on an acceptance that the petitioner had been
exploited. The respondent merely summarised the psychologist's report. In any event, it was not the sole
reason for her mental health difficulties and the respondent was entitled to conclude that it did not
corroborate her claim to have been exploited.

(e)   The petitioner does not explain why the police having completed their enquiries is a relevant matter.
It would not support her claim. The contents of previous decisions, which have been reduced, are not
relevant.

(f)   The respondent recognised that employers of domestic servants can seek to exercise control in
various ways.

(g)   The respondent acknowledged that there were reasons why the petitioner may be reluctant to report
to the authorities, but her failure to do so was nonetheless a relevant factor she was entitled to have regard
to given she had the means and opportunity.

(h)   More generally, the omission of reference to a particular issue does not amount to an error of law.

(i)   The respondent did not impose a test of “unbearable conditions” in relation to trafficking claims. This
was simply mentioned, with reference to the respondent's policy, as being a factor which can amount to
domestic servitude.

(j)   For the petitioner to succeed in a challenge to one of the respondent's esto findings, she must
establish an error regarding the respondent's assessment of her credibility. If she cannot do so, any error in
relation to the former is immaterial.

(k)   The petitioner had an initial screening interview, an asylum interview and the opportunity to make
revisals in respect of both. The same factual matters were relevant to her asylum and trafficking claims.
These documents were considered as part of the Conclusive Grounds decision.

(l)   The respondent identified precisely the material supportive to the petitioner's claim at page 10 of the
decision letter, noted as “the external country information”.

(m)   The petitioner's submission that the respondent decided to refuse the trafficking claim then sought
reasons for doing so is without basis, given statistics indicate that 89% of all Conclusive Grounds decisions
in 2020 were positive.

**Analysis and conclusion**

[18]     The parties do not dispute that, in determining whether the respondent erred in reaching a Conclusive
Grounds decision I must apply a test of “anxious scrutiny” The respondent must apply the same test in reaching


-----

Respondent 2022 Scot (D) 29/2

her decision. This proposition comes from inter alia the judgment of Peter Marquand, sitting as Deputy High Court
Judge, in R (LH) v Secretary of State for the Home Department [2019] EWHC 3457 (Admin) at paragraph 15. It is
further common ground that a failure to carry out such an analysis is irrational: LH (supra) at paragraph 41.

[19]     Starting with the alleged errors in relation to the respondent's credibility findings, the petitioner argues that
the respondent either left out of account relevant matters, had regard to irrelevant matters or reached certain
perverse conclusions. Dealing with these in reverse order, first, there is no merit in the petitioner's submission that
the respondent reached perverse conclusions. Her submission is bound to fail standing the findings in fact made by
the respondent which the petitioner does not challenge. The respondent did not accept how onerous the work was.
The conclusions reached by the respondent do not come close to perversity and were reasonably open to her on
the evidence.

[20]     Second, the respondent did not treat the inconsistencies in the petitioner's account regarding the date she
commenced employment with the family as material. This is clear from the terms of page 8 of the decision (in the
petitioner's first inventory of productions at no 6/1 of process). The respondent also acknowledged the difficulties
the petitioner may face in recalling this information. As to the respondent's assessment of the psychological
evidence, I find that she was entitled to give the weight to it that she did. The weight to be given to that evidence
was ultimately a matter for the respondent and she was not bound to find the petitioner's claims of trafficking were
corroborated by it. Finally, the respondent did not require that the petitioner show she had been working in
“unbearable conditions” to be considered a victim of trafficking. She merely referred to her policy which notes that
this will often, but not always, be found in situations of domestic servitude.

[21]     Third, an overall reading of the respondent's decision confirms that she did not leave out of account the
majority of the matters it is alleged that she did and as stated in para [14] hereof viz. (a) the connection between the
petitioner's role, her vulnerability and her exploitation, (b) various matters when assessing the petitioner's “stated
intention”, (d) the psychological evidence and extent to which this could corroborate her account, (f) the coercive
behaviour employed by the family, (g) the incident whereby the petitioner was locked outside the family home, (h)
the circumstances in which victims of trafficking may consent to exploitation and (j) the links between police and
immigration authorities and how this may have affected the petitioner's “choice”. In relation to (k) being that the
respondent left out of account that there was no evidence the petitioner remained with the family for her own
economic benefit, that was the inevitable conclusion for the respondent standing the other conclusions regarding
the petitioner's credibility.

[22]     Notwithstanding my opinion that none of the above matters amount to an error of law, I find that there is
merit in the error alleged by the petitioner at (e), as narrated in para [14] hereof. This ground relates to the reasons
why the police completed their enquiries into the family regarding the petitioner's allegations of trafficking. It is not in
dispute that this was not mentioned in the decision under review. Indeed, the fact that the police had even
completed their enquiries was not mentioned in that decision at all. The reasons for this are unclear. In the context
of these judicial review proceedings, the respondent has averred that the petitioner has not explained the relevance
of the police's reasons for completing their enquiries to her case (Answer 24). There is nothing to suggest that the
decision-maker was of this view or whether she simply overlooked this matter. In any event, the respondent's
submission runs into three difficulties.

[23]     First, the Competent Authority has deemed the police's completion of their enquiries sufficiently relevant
for inclusion in previous decisions (pages 47 and 83 of petitioner's first inventory). Whilst the respondent may argue
that the contents of past decisions, which have been reduced, are irrelevant, they have been lodged in process.
Whilst not subject to review in these proceedings, it would be illogical to ignore their contents entirely. This is
particularly so where the petitioner avers that the respondent has failed to have regard to relevant matters and
where the respondent appears to have altered her view as to the matters which are relevant without providing any
explanation for doing so.

[24]     Second, the petitioner provided sufficient notice to the respondent that the police's reasons were relevant.
Pausing at this juncture, I acknowledge that the decision refers to correspondence sent to the petitioner by the


-----

Respondent 2022 Scot (D) 29/2

respondent requesting further information prior to the decision, in relation to which it is noted no response was
received. Nonetheless, there was sufficient notice in the petitioner's second petition for judicial review in the
following terms (page 58 of the petitioner's first inventory):

“16. …The Secretary of State does not disclose whether that was simply because the Petitioner's exploiters
had left the UK. The Secretary of State has failed to provide adequate reasons for her decision.”

The petitioner has subsequently called upon the respondent to ascertain the police's reasons and disclose these to
her. To date, the respondent has failed to do so. It is unclear what information the respondent already had
available: see, for example, section 11.20 of the respondent's guidance “Modern Slavery: Statutory Guidance for
England and Wales (under _[s49 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C273-00000-00&context=1519360)_ **_Modern Slavery Act 2015) and Non-Statutory Guidance for Scotland and_**
Northern Ireland” which refers to frequent information sharing between the police and the Competent Authority. At a
minimum, one can assume that the information would have been readily available to the respondent had she
wished to access it.

[25]     Third, and in any event, the relevance of this matter is self-evident. It is well-versed that anxious scrutiny
requires that decisions “show by their reasoning that every factor which might tell in favour of an applicant has been
properly taken into account”: _LH (supra)_ at paragraph 15(vi). Thus, the petitioner need either not show that the
police's reasons would definitely or even probably tell in her favour. I agree with the petitioner's averment at
Statement 25 of the petition. It is a matter which could either tell in the petitioner's favour or support the
respondent's conclusion. For example, if the family left the UK shortly after learning of the police's investigations of
them, one can see how that is clearly relevant to the credibility of the petitioner's claim. It may enable an inference
to be drawn as to the reason why the family left. On the other hand, if the police were not satisfied that the family
had exploited the petitioner, that would support the respondent's conclusion that she is not a victim of trafficking.
Given these possibilities, it is clearly a matter which is relevant to the petitioner's claim to be a victim of trafficking.
The difficulty at present is that there is no information either way. I am satisfied that this amounts to leaving out of
account a matter which is both relevant and potentially material to the petitioner's claim and which might have told
in her favour.

[26]     Having found the respondent has left a relevant matter out of account, it follows that I am satisfied that the
respondent has failed to apply anxious scrutiny and the decision is irrational. It is therefore unnecessary for me to
go on to consider the other errors advanced by the petitioner in relation to (a) the respondent's assessment that the
petitioner's claim, even if accepted, does not amount to domestic servitude and (b) the allegations of procedural
unfairness. Briefly, I am not of the opinion that any of the petitioner's averments in this regard establish an error of
law in the respondent's decision.

[27]     I shall accordingly grant the prayer of the petition and reduce the respondent's decision, served on the
petitioner on 22 December 2020, concluding that the petitioner is not a victim of trafficking.

**End of Document**


-----

