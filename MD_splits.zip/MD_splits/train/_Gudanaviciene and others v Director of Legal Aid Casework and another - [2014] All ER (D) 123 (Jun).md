# *Gudanaviciene and others v Director of Legal Aid Casework and another

 [2014] EWHC 1840 (Admin)

Queen's Bench Division, Administrative Court (London)

Mr Justice Collins

13 June 2014

**Legal aid — Entitlement — Immigration proceedings — Claimants challenging first defendant Director of**
**Legal Aid Casework's decisions refusing to grant legal aid for immigration proceedings — Claimants**
**contending second defendant Lord Chancellor's guidance unlawful — Whether guidance unlawful —**
**Whether refusal of legal aid wrong in claimants' circumstances — Legal Aid, Sentencing and Punishment of**
**Offenders Act 2012, s 10(3) — European Convention on Human Rights, arts 6, 8, 14 — Charter of**
**Fundamental Rights of European Union, art 47.**
Judgment

JUDGMENT: APPROVED BY THE COURT FOR HANDING DOWN (SUBJECT TO EDITORIAL CORRECTIONS)

MR JUSTICE COLLINS:

1. These six claims have been heard together pursuant to an order of Turner J made on 30 January 2014. Each
challenges the refusal of the Director of Legal Aid Casework (whom I will refer to as the Director) to grant legal aid
to the claimants. They raise common issues concerning the availability of legal aid in immigration cases under
Section 10 of the Legal Aid, Sentencing and Punishment of Offenders Act 2012 (LASPO). A number of discrete
issues have been identified. Some are common to a number of the claims and some depend on the circumstances
of one or two of the claims but all will arise in many applications for legal aid by or on behalf of immigrants who wish
to obtain a particular decision usually from the Home Office or an entry clearance officer or are pursuing an appeal
against an adverse decision or are responding to an appeal against a favourable decision. The claimants contend
that the policy adopted by the Director which applies guidance issued by the Lord Chancellor is wrong in law in
being too restrictive. Further, each claimant asserts that in his or her case having regard to the circumstances the
refusal to grant legal aid was wrong.

2. Permission had been granted in one of the claims. The others were to be treated as 'rolled up hearings'. I granted
permission in those claims which needed it subject to an undertaking to pay the necessary court fee. This judgment
deals with each claim on its merits.

3. Part 1 of LASPO deals with legal aid. Its effect has been to limit the circumstances in which civil legal aid can be
granted. Section 9 of LASPO provides:
“(1) Civil legal services are to be available to an individual under this Part of –

(a) they are civil legal services described in Part 1 of Schedule 1 and

(b) the Director has determined that the individual qualifies for the services in accordance with this Part
(and has not withdrawn the determination.”

S.9(2) enables the Lord Chancellor to add, vary or omit services in Schedule 1. The need for an individual to qualify
is directed largely at merits and means and is dealt with in Section 11 of LASPO. I am not concerned with means in


-----

these cases and only with merits insofar as I can properly reach a conclusion on the facts of a particular claim that
to refuse legal aid on merits grounds would be perverse.

4. Section 10 of LASPO is central to these cases. It is headed “Exceptional cases” and so far as material provides:
“(1) Civil legal services other than services described in Part 1 of Schedule 1 are to be available to an
individual under this part if subsection (2) … is satisfied.

(2) This subsection is satisfied where the Director –

(a) has made an exceptional case determination in relation to the individual and the services, and

(b) has determined that the individual qualifies for the services in accordance with this Part,

(and has not withdrawn either determination).

(3) For the purposes of subsection (2), an exceptional case determination is a determination –

(a) that it is necessary to make the services available to the individual under this Part because failure to do
so would be a breach of –

[(i) the individual's Convention rights (within the meaning of the Human Rights Act 1998), or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

(ii) any rights of the individual to the provision of legal services that are enforceable EU rights, or

(b) that it is appropriate to do so, in the particular circumstances of the case, having regard to any risk that
failure to do so would be such a breach.”

5. Section 11 confers upon the Lord Chancellor the duty to set the criteria which the Director must apply in
Regulations. The material factors that must be reflected in the criteria are set out in s.11(3). They include a cost
benefit assessment, the availability of resources, the appropriateness of applying those resources having regard to
present and future demands, the importance for the individual and the nature and seriousness of the matters for
which he requests the services, the individual's prospects of success if the services relate to a dispute, the
individual's conduct and the public interest. S.11(5) provides:
“The criteria must reflect the principle that in many disputes, mediation and other forms of dispute
resolution are more appropriate than legal proceedings.”

6. The availability of civil legal services for immigration is dealt with in Paragraphs 28 to 32 of Schedule 1 to
LASPO. Paragraphs 28 and 29 cover victims of domestic violence. Paragraph 30 is the most material being
concerned with rights to enter and remain. Sub-paragraph (1) permits a grant in relation to:
“Civil legal services provided in relation to rights to enter, and to remain in, the United Kingdom arising from
–

(a) The Refugee Convention;

(b) Article 2 or 3 of the Human Rights Convention;

(c) The Temporary Protection Directive;

(d) The Qualification Directive.”

Apart from the general exclusions specified in Parts 2 and 3 of Schedule 1 (to which it is not necessary to refer),
there is a specific exclusion of services for an attendance at an interview conducted on behalf of the Secretary of
State with a view to reaching a decision on a claim in respect of the rights set out in sub-paragraph (1) unless
regulations provide otherwise.

7. The Refugee and Human Rights Conventions need no explanation. The Qualification Directive is Council
Directive 2004/83/EC, which has been given effect by the Refugee or Person in Need of International Protection
[(Qualification) Regulations 2006 (SI 2006/2525). The Temporary Protection Directive refers to Council Directive](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-4WS0-TX08-H0GW-00000-00&context=1519360)
2001/55/EC which deals with minimum standards for temporary protection if there is a mass influx of displaced


-----

8. Section 1 of LASPO requires the Lord Chancellor to secure that legal aid is made available in accordance with
Part 1 of the Act. It enables him to do 'anything which is calculated to facilitate, or is incidental or conducive to, the
carrying out of the Lord Chancellor's functions under this Part' (s.1(4)). Section 4 of LASPO requires the Lord
Chancellor to designate a civil servant as Director and provide for his assistance. Section 4(2) obliges the Director
to :
“ (a) comply with directions given by the Lord Chancellor about the carrying out of the Director's functions
under this Part, and

(b) have regard to guidance given by the Lord Chancellor about the carrying out of those functions.”

9. The Lord Chancellor has issued guidance in accordance with s.4 of LASPO. It makes clear, as is obviously
appropriate, that applications must be considered on a case by case basis. However, the guidance lays down some
principles which the Director is to apply and some of those are said by the claimants to be unlawful. Paragraph 6
notes that s10(3)(b) does not provide a general power to fund cases which fall outside the scope of legal aid. It is, it
is said, “to be used for rare cases” where the risk of the breach of material rights 'is such that it is appropriate to
fund'. Paragraph 7 states:
“7. The purpose of section 10(3) of the Act is to enable compliance with ECHR and EU law obligations in
the context of a civil legal aid scheme that has refocused limited resources on the highest priority cases.
Caseworkers should approach section 10(3)(b) with this firmly in mind. It would not therefore be
appropriate to fund simply because a risk (however small) exists of a breach of the relevant rights. Rather,
section 10(3)(b) should be used in those rare cases where it cannot be said with certainty whether the
failure to fund would amount to a breach of the rights set out at section 10(3)(a) but the risk of breach is so
substantial that it is nevertheless appropriate to fund in all the circumstances of the case. This may be so,
for example, where the case law is uncertain (owing, for example, to conflicting judgments).”

10. This, it is submitted by the claimants, is too restrictive. It applies an approach to s.10(3) which is not expressly
provided for by LASPO. No doubt Parliament intended to limit legal aid in immigration cases only to those where
there was at least a risk (the context of which is to be determined in these claims) of a breach of material rights, but
that limitation should not go beyond what the law as explained in decisions of the ECtHR, the CJEU and domestic
cases provides. In particular, it is submitted that the reference to certainty is not appropriate since the requirement
that the breach is 'so substantial' will mean that only cases where the risk of breach is overwhelming can succeed.
That the approach of the Director in accordance with the Guidance has had that effect is apparent from the fact that
only 1% of the non-inquest applications for exceptional case funding (ECF) have succeeded since LASPO came
into effect in April 2013.

11. Paragraphs 9 & 10 refer to Article 6 of the ECHR and make the point that there is no specific right under Article
6 for legal aid in civil proceedings since Article 6(3) only applies to criminal proceedings. Paragraph 10 reads:
“Caseworkers will need to consider, in particular, whether it is necessary to grant funding in order to avoid
a breach of an applicant's rights under Article 6(1) ECHR. As set below, the threshold for such a breach is
very high.”

Article 6 applies only if the case involves the determination of civil rights and, it is said, the test to be applied by
caseworkers is:
“will withholding of legal aid make assertion of the claim practically impossible or lead to an obvious
unfairness in the proceedings?”

This is, as is said, a very high threshold.

12. The guidance sets out various matters which should be taken into account in judging the importance or
seriousness of what is at stake both for the applicant and more generally. Factual, legal or procedural complexity is
material. Relevant considerations explicitly referred to include whether the degree of emotional involvement that the
applicant is likely to have is incompatible with the degree of objectivity expected of advocates in court. In practical
terms that is highly likely to be the situation in most appeals by immigrants who wish to enter or remain Whether


-----

the applicant has any relevant skills or experience is a material consideration. Again, in all but a very small fraction
of cases an applicant will lack skills and experience. On the other side of the coin, the court's or tribunal's familiarity
with having to deal with litigants in person is material. In addition, the ability of an applicant to understand English
and any disabilities he may suffer are material. If the applicant lacks capacity within the meaning of the _[Mental](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)_
_[Capacity Act 2005,the caseworker must consider how capable his litigation friend is to present his case.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)_

13. Article 8 of the ECHR is referred to in Paragraphs 26 to 28 of the Guidance. Reference is made to two ECtHR
cases, Airey v Ireland (1979 – 80) 2 EHRR 305 and PC&S v UK (2002) 35 EHRR 31. These I will have to consider
when dealing with what is required in immigration cases to meet any procedural obligations which exist to enable
Article 8 rights to be properly protected. Paragraph 28 makes the point that in those cases (which were not
immigration cases) the ECtHR found a breach of Article 6 in the failure to provide legal aid and so “it is likely that
cases in which an applicant seeks to rely on Article 8 would therefore fall more naturally to be considered under the
Article 6(1) heading.”

14. In paragraphs 59 and 60 under the heading “Immigration” it is said that proceedings relating to the immigration
status of immigrants and decisions relating to their entry, stay or deportation do not involve the determination of civil
rights and obligations. Thus Article 6 will not apply. Paragraph 60 reads:
“The Lord Chancellor does not consider that there is anything in the current case law that would put the
State under a legal obligation to provide legal aid in immigration proceedings in order to meet the
procedural requirements of Article 8 ECHR.”

15. The test of practical impossibility or obvious unfairness set out in the Guidance derives from a decision of the
European Commission of Human Rights in X v UK (1984) 6 EHRR 136. Mr Chamberlain, Q.C. referred to a number
of domestic cases in which that test was, he submitted, if not explicitly approved, accepted and certainly not
disapproved. The claimants contend that that test is not only not reflected in any subsequent ECtHR jurisprudence
but is not consistent with what the court has stated. That goes to whether the level required to justify legal aid is set
too high in the Guidance. The other issue in relation to Article 8 is whether, despite the non-applicability of Article 6
in immigration cases, the procedural requirements of Article 8 may require the grant of legal aid in certain
circumstances.

16. The claimants Gudanaviciene and Reis are both EU nationals who are appealing against decisions that they
should be deported following convictions of criminal offences. They therefore have enforceable EU rights within
s.10(3)(a)(ii) of LASPO. The claimant S is a victim of trafficking (VOT) and asserts that he has such a right which
should apply to grant him legal assistance to establish that he is such a victim. This assertion is not accepted by Mr
Chamberlain. The Guidance refers specifically to such EU rights in Paragraphs 30 to 34. Article 47 of the EU
Charter of Fundamental Rights applies. This provides, under the heading “Right to an effective remedy and to a fair
trial”:
“(1) Everyone whose rights and freedoms guaranteed by the law of the Union are violated has the right to
an effective remedy before a tribunal in compliance with the conclusion laid down in this Article.

(2) Everyone is entitled to a fair and public hearing within a reasonable time by an independent and
impartial tribunal previously established by law. Everyone shall have the possibility of being advised,
defended and represented.

(3) Legal aid shall be made available to those who lack sufficient resources insofar as such aid is
necessary to ensure effective access to justice.”

17. The Guidance states in Paragraph 31 that the explanations to the Charter provide that the content of Article 47
is 'the same as that of Article 6(1) ECHR'. The explanation in relation to Article 47(3) states:
“it should be noted that in accordance with the case law of the ECtHR provision should be made for legal
aid where the absence of such aid would make it impossible to ensure an effective remedy …”


-----

Reference is made to Airey v Ireland as support for that. The attack on the approach to Article 6 requirements in the
Guidance is thus equally material in relation to Article 47(3). The claimants further pray in aid Article 19 of the
Treaty on European Union (TEU). This deals with the Court of Justice but contains under Paragraph 1 this:
“Member States shall provide remedies sufficient to ensure effective legal protection in the fields covered
by Union law.”

I do not think this really adds anything to Article 47.

18. The issues said to be common to several of the claimants' pleaded cases include consideration as to whether
Article 8 of the ECHR either alone or in conjunction with Article 14 (prohibition of discrimination) requires the
provision of legal aid to avoid a breach where Article 6 does not also apply and, if so, in what circumstances. The
second relates to the circumstances in which Article 47 of the Charter requires the provision of legal aid and how, if
at all, there is a difference from what Article 6 of the ECHR requires. Thirdly, the question is posed whether the Lord
Chancellor's guidance properly identifies and reflects the procedural requirements of Article 8 of the ECHR and
Article 47 of the Charter. Fourthly, what are the proper ingredients of the tests to be applied in s.10(3)(a) and (b) of
LASPO? Finally, does the Lord Chancellor's guidance properly state the tests to be applied in making an
exceptional case determination? The issues clearly overlap. It is desirable to deal with them before going to the
facts of each individual claim since they will obviously help to determine whether the decision made was in
accordance with the law. However, it must be borne in mind that even if the approach adopted was wrong, relief will
not be granted if it is clear that the decision would be the same on the correct approach.

19. The 'overarching question' posed in the Guidance is 'whether the withholding of legal aid would make the
assertion of the claim practically impossible or lead to an obvious unfairness in proceedings.' This is said to be a
very high threshold. As I have said, it is based on X v UK. In setting out this test, the Commission referred to Airey v
_Ireland. Airey's case concerned the need for a party to a marriage to apply to the High Court for a decree of judicial_
separation but legal aid was not available. The litigation in question involved complicated points of law, a need to
prove a matrimonial offence and, as must be obvious, an emotional involvement on the part of a petitioner that was
scarcely compatible with the degree of objectivity required by an advocate in court (see paragraph 24 of the
judgment at (1979) 2 EHRR 315). That meant that the possibility to appear in person did “not provide the applicant
with an effective right of access”.

20. In paragraphs 31 and 32, the court considered whether there was a breach of Article 8 as well as Article 6. It
decided that there was since, in addition to the primarily negative undertaking not to interfere in a disproportionate
fashion with Article 8 rights, respect for private or family life obliged the State to make a means of protection
effectively accessible in order to avoid any breach. The court did not indicate what that test should be beyond
saying that the means of protection must be effectively accessible (Article 8) or there must be effective access to a
court (Article 6).

21. _PC&S v UK (2002) 35 EHRR 1075 concerned removal of S from her parents based on her mother P's_
conviction in the United States of endangering her young son's health and an adjudgment that she suffered from
Munchhausen's syndrome. She chose, it seems, to represent herself before the High Court, but the ECtHR found
that there had been a breach of Article 8 in respect of the applicants (C was her husband) as regards S's removal at
birth and the subsequent care and adoption procedures. In Paragraph 119 (p.1107) the court observed:
“… whilst Article 8 contains no explicit procedural requirements, the decision making process involved in
measures of interference must be fair and such as to afford due respect to the interests protected by Article
8.”

22. The court cited a passage from _W v UK (1988) 10 EHRR 29, another case concerning restriction and_
termination of rights of access by a parent to his child. The law then in force provided no statutory remedy whereby
the applicant could contest the isolated issue of the decision to restrict or terminate his access to his child, save by
judicial review which did not give an appeal on fact. In Paragraph 62 (p.119) the court stated:
“It is true that Article 8 contains no explicit procedural requirements, but this is not conclusive of the matter
… [.] the court is entitled to have regard to [the decision making] process to determine whether it has been


-----

conducted in a manner that, in all the circumstances, is fair and affords due respect to the interests
protected by Article 8.”

There is no reference to X v UK and the test is fairness and whether, as the court observes in Paragraph 64, “The
parents have been involved in the decision-making process, seen as a whole, to a degree sufficient to provide them
with the requisite protection of their interests.”

23. In Steel & Morris v UK (2005) 41 EHRR 22, the court considered an application by the two London Greenpeace
activists who had been defendants in a libel claim by McDonalds which had lasted for some 313 days and for which
legal aid had been unavailable. In Paragraphs 59 to 62 on pages 427 and 428 the court said this:
“59. The Court recalls that the Convention is intended to guarantee practical and effective rights. This is
particularly so of the right of access to court in view of the prominent place held in a democratic society by
the right to a fair trial. It is central to the concept of a fair trial, in civil as in criminal proceedings, that a
litigant is not denied the opportunity to present his or her case effectively before the court and that he or
she is able to enjoy equality of arms with the opposing side.

60. Article 6(1) leaves to the state a free choice of the means to be used in guaranteeing litigants the
above rights. The institution of a legal aid scheme constitutes one of those means but there are others,
such as for example simplifying the applicable procedure.

61. The question whether the provision of legal aid is necessary for a fair hearing must be determined on
the basis of the particular facts and circumstances of each case and will depend, inter alia, upon the
importance of what is at stake for the applicant in the proceedings, the complexity of the relevant law and
procedure and the applicant's capacity to represent him or herself effectively.

62. The right of access to a court is not, however, absolute and may be subject to restrictions, provided
that these pursue a legitimate aim and are proportion ate. It may therefore be acceptable to impose
conditions on the grant of legal aid based, inter alia, on the financial situation of the litigant or his or her
prospects of success in the proceedings. Moreover, it is not incumbent on the State to seek through the
use of public funds to ensure total equality of arms between the assisted person and the opposing party, as
long as each side is afforded a reasonable opportunity to present his or her case under conditions that do
not place him or her at a substantial disadvantage vis-à-vis the adversary.”

It is to be noted that the court referred to Airey and PC&S v UK but not to X v UK. And again in paragraph 71 the
court said that in the circumstances the opportunity to present their case effectively before the court was prevented
by the refusal of legal aid.

24. The ECtHR has more recently confirmed the need to recognise that Article 8 has its procedural requirements.
The case in question is _AK & L v Croatia (Application No: 37965/11), judgment having been given on 8 January_
2013 and became final on 8 April 2013. The case concerned the divesting of the applicant AK of her parental rights
in respect of her son L. In Paragraph 63 the court recognised that the views of a child's natural parents must be
available to the authority which makes the relevant decision and any court to which an appeal lies. This means, the
court said:
“The decision-making process must … be such as to ensure that their views and interests are made known
to, and duly considered by, the local authority and that they are able to exercise in due time any remedies
available to them.”

The applicant AK had a mild mental disability, a speech impediment and a limited vocabulary. Thus her interests
were not adequately protected since she had been required to appear unrepresented in the proceedings which
divested her of her parental rights. Having regard to the serious consequence to her right to family life, the failure to
grant representation meant that there was a breach of Article 8 since the decision could not be regarded as
necessary for the purposes of Article 8(2).

25. R(SB) v Governors of Denbigh High School [2007] 1 AC 807concerned a contention that the claimant's Article 9
rights had been breached by the prohibition against her attendance at school wearing a 'jilbab'. Lord Bingham at


-----

Paragraph 29, having cited from the decision of the ECtHR in Chapman v UK (2001) 33 EHRR 399 the statement
that the court must examine whether the decision making process was fair and such as to afford due respect to the
interests of the individual safeguarded by Article 8, made clear that a court must provide the individual with a fair
opportunity to put his case.

26. Mr Chamberlain cited a number of domestic cases in which the _X v UK test was, he submitted, accepted in_
relation to Article 6. In R(Jarrett) v Legal Services Commission _[[2001] EWHC Admin 389, counsel for the claimant](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MK2-6NB1-F0JY-C48Y-00000-00&context=1519360)_
did not argue that the X v UK test was erroneous and it was accordingly applied by Burton J. In Pine v Law Society

[2001] EWCA Civ 154 the same counsel again did not challenge the _X v UK approach. Indeed, as is clear from_
paragraph 28 of the judgment of the Vice-Chancellor, who gave the only reasoned judgment, counsel positively
accepted that the relevant principle was that in X v UK. In Holder v Law Society [2003] 1 WLR 1059it was accepted
by Carnwath LJ, following Pine, that the X v UK test was appropriate. Again, the contrary was not argued.

27. In _Perotti v Collyer-Bristow_ _[2003] EWCA Civ 1521, the court was concerned with an application for leave to_
appeal by a litigant in person who, as Chadwick LJ observed, was an experienced litigant who had often in the past
appeared in the Court of Appeal to present his applications in person. Chadwick LJ observed that, while an
indication by a court and in particular the Court of Appeal that legal representation was necessary in order to ensure
a fair hearing would be likely to lead to a grant of legal aid, the court could not direct the Legal Services
Commission to make a grant. He said (Paragraph 29) that it was not in doubt that one aspect of the right to a fair
hearing was effective access to the court. Having cited the Commission's observations in _X v UK, Chadwick LJ_
continued in Paragraphs 31 and 33:
“31. Miss Moore suggests in her written submissions, in my view correctly, that the obligation on the state
to provide legal aid arises if the fact of presenting his own case can be said to prevent him from having
effective access to the courts. But a litigant who wishes to establish that without legal aid his right of
effective access will have been violated has a relatively high threshold to cross.

32. It is, in my view, important to have in mind that however much this court, and indeed any other court,
would welcome the assistance that can be given by a legally qualified and competent advocate, the test is
not whether (with such assistance) this court would find it easier to reach the decision which it has to reach
on the facts of the case. This court, and other courts, have ample experience of cases in which the material
is not presented in an ideal form; and have not found it impossible to reach just decisions in such cases.
The test under Article 6(1), as it seems to me, is whether a court is put in a position that it really cannot do
justice in the case because it has no confidence in its ability to grasp the facts and principles of the matter
on which it has to decide. In such a case it may well be said that a litigant is deprived of effective access;
deprived of effective access because, although he can present his case in person, he cannot do so in a
way which will enable the court to fulfil its paramount and over-arching function of reaching a just decision.
But it is the task of courts to struggle with difficult and ill-prepared cases; and courts do so every day. It is
not sufficient that the court might feel that the case could be presented better; the question for the court is
whether it feels that the case is being, or will be, presented in such a way that it cannot do what it is
required to do – that is to say, reach a just decision. If it cannot do that the litigant is effectively deprived of
proper access to the courts.”

28. It seems to me to be clear that the key considerations are that there must be effective access to a court and that
there must be overall fairness in order that the requirements of Article 6 are met. One aspect of effective access
must be the ability of a party to present all necessary evidence to make his case and to understand and be able to
engage with the process. So much is apparent from AK & L v Croatia. It must be borne in mind that both before a
tribunal and a court the process is adversarial. Thus the tribunal cannot obtain evidence where there are gaps in
what an applicant has been able to produce. Equally, it may have difficulties if there is defective written material put
before it in appreciating whether there is any substance to a claim or even if any particular human rights claim is
properly raised. I think the words 'practically impossible' do set the standard at too high a level, but, as Chadwick LJ
indicated, the threshold is relatively high. No doubt it would generally be better if an appellant were represented, but
that is not the test. Nevertheless, the Director should not be too ready to assume that the tribunal's experience in
having to deal with litigants in person and, where, as will often be the case, the party's knowledge of English is nonexistent or poor the provision of an interpreter will enable justice to be done


-----

29. A further relevant consideration in immigration cases is the difficulty in finding advisers who can lawfully give
advice having regard to Part V of the Immigration and Asylum Act 1999 and in particular s.84 which, by s.84(1),
provides:
“No person may provide immigration advice on immigration services unless he is a qualified person.”

This covers a barrister or solicitor or a person authorised by a designated qualifying regulator or those who are
registered or exempted by the Office of the Immigration Services Commissioner at the appropriate level. A criminal
offence is only committed by those who give immigration advice or provide services in the course of a business
carried on (whether or not for profit), but this has been given a wide scope. The reasons are obvious. Without
access to properly accredited advisers, immigrants, who are in many cases vulnerable and unfamiliar with the
English language, will be made the prey of unscrupulous so-called advisers. This is an aspect of the new situation
following LASPO which has not been covered in the Guidance and which is an important consideration when legal
aid is refused on the basis that other services or assistance are available.

30. Mr Chamberlain submits that there is no case law whether domestic or from Europe which requires that legal
aid be granted for the purpose of meeting the procedural requirements of Article 8 in immigration cases in
particular. The starting point for this submission is the decision of the Grand Chamber of the ECtHR in Maaouia v
_France (2001) 33 EHRR 1037. Article 1 of Protocol 7 to the ECHR contains procedural guarantees applicable to the_
expulsion of aliens. This had been ratified by France. This meant, the court stated in Paragraph 37 of the judgment,
that the 'States clearly intimated their intention not to include such proceedings within the scope of Article 6(1)'. The
[UK has not ratified Protocol 7 nor is Article 13 of the ECHR included in the Human Rights Act 1998. Thus there are](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
no specific procedural guarantees which apply in immigration cases. The court in Paragraph 37 said this (p.1045):
“In the light of the foregoing, the court considers that the proceedings for the rescission of the exclusion
order, which form the subject-matter of the present case, do not concern the determination of a 'civil right'
for the purposes of Article 6(1). The fact that the exclusion order incidentally had major repercussions on
the applicant's private and family life or on his prospects of employment cannot suffice to bring these
proceedings within the scope of civil rights protected by Article 6(1) of the Convention.”

31. It is to be noted that in the explanatory note to Protocol 7, this is said in Paragraph 6:
“… it is stressed that an alien lawfully in the territory of a Member State of the Council of Europe already
benefits from certain guarantees when a measure of expulsion is taken against him, notably those which
are afforded by Articles 3 … and 8 …, in connection with Article 13 …”

While Article 13 is not specifically applied by the 1998 Act, it was regarded as unnecessary since domestic law
provided sufficient protection for individuals. But the existence of Article 1 of Protocol 7 and Article 13 has meant
that the ECtHR has not needed to decide whether the procedural requirements of Article 8 need to be applied. It is
only because the UK has not ratified Protocol 7 and has not incorporated Article 13 that the submission that Article
8 procedural requirements cannot be relied on in immigration cases can be made. But there are procedural
requirements in order to make Article 8 rights effective and there is no reason in my view to believe that they are
excluded when the reasoning which led to the decision in Maaouia which was concerned only to decide whether
Article 6(1) applied is taken into account.

32. The House of Lords considered the implications of the exclusion of immigration decisions from the scope of
Article 6 in _RB(Algeria) v Secretary of State for the Home Department [2010] 2 A.C. 110. The three cases_
considered together involved deportation based on danger to national security. The contention on the appellants'
behalf was that there was a real risk that their Article 3 rights would be breached if they were returned or (in the
case of the appellant Othman, better known as Abu Qatada) a flagrant breach of Articles 5 and 6 would occur. It
was submitted that the SIAC procedure which enabled reliance to be placed on closed material without any
knowledge by those to be deported of even the gist of material allegations was unfair and unlawful.

33. The arguments put forward by the claimants were that the risk of breaches of Articles 3, 5 and 8 meant that
there had to be conformity with Article 6 rights in deciding on deportation. The whole purpose of the claims was to
try to engage Article 6 since anything less would it was recognised be likely to mean that the SIAC procedure was


-----

upheld. This was largely because in Chahal v UK 23 EHRR 413 the ECtHR decided that, albeit there needed to be
an 'effective remedy' to protect Article 3 rights, that remedy did not need to be compliant with Article 6. Indeed, in
Chahal the court had implicitly recognised the acceptability of closed hearings as carried out by SIAC. Indeed, SIAC
was brought into being following the decision in Chahal and the recognition that the existing procedure involving
scrutiny by what were called 'the three wise men' was inadequate.

34. Mr Chamberlain has contended that the argument presented by Mr Rabinder Singh Q.C. in the appeal went no
further than submitting that there was a need for safeguards equivalent to those provided by Article 6 because of
the effect on the various human rights which were involved. But that was not the basis of his argument as
understood by their Lordships. Thus in Paragraph 175 on p.241, Lord Hoffmann said:
“It is clear that the criterion for the European Court in deciding whether Article 6 is engaged is the nature of
the proceedings and not the Articles of the Convention which are alleged to be violated. If the proceedings
concern deportation, Article 6 is not engaged, whatever might be the other Articles potentially infringed by
removal to another country.”

While RB was concerned with deportation, it is clear from Maaouia that the exclusion of Article 6 applies to all
immigration cases.

35. Lord Hope expressed his views in much the same way as Lord Hoffmann. At Paragraph 230 on p.255, he
stated:
“There remains however the question whether the use of closed material fails to meet the minimum
standard of procedural fairness that is to be expected of any such tribunal in a democratic society.”

He analysed the procedures and decided that they did provide a fair balance between the need to protect the public
interest and the need to provide the applicant with a fair hearing. But he recognised that there do exist minimum
standards. In the absence of specific application of Article 13 or Protocol 7, those minimum standards must be
applied to decide whether the interference with private or family life is proportionate because necessary in a
democratic society. It follows that there may be cases in which a failure to grant legal aid may breach minimum
standards so that Paragraph 60 of the Guidance is erroneous. If legal aid is needed to provide that the procedure is
effective and fair in dealing with Article 8 rights it will have to be provided. No doubt the threshold is a relatively high
one, but, as I have already indicated, it is not in my view as high as suggested by X v UK.

36. Article 47(3) of the Charter provides that legal aid shall be provided in so far as necessary to ensure effective
access to justice. This is a clear recognition that legal aid may be required and so goes to that extent beyond Article
6, since Article 6 only requires legal aid in criminal cases. In the explanation, as I have already stated, this is said in
relation to Article 47(3):
“With regard to the third paragraph, it should be noted that in accordance with the case law of the ECtHR,
provision should be made for legal aid where the absence of such aid would make it impossible to ensure
an effective remedy … There is also a system of legal assistance before the CJEU.”

_Airey v Ireland is referred to as an authority for the first sentence. The use of the word 'impossible' could_
be argued to set a very high threshold. But I do not believe it was intended to do more than indicate that what has to
be considered is whether without legal assistance the remedy could be made effective. In addition, I think fairness
must be a factor to be taken into account. That that is what is meant is consistent with the explanation of 47(1)
which is said to be based on Article 13 of the ECHR but to go further because 'in Union law the protection is more
extensive since it guarantees the right to an effective remedy before a court.'

37. The claimants have submitted that Article 47(3) confers a right which goes beyond what Article 6 requires. If
Article 6 is correctly construed in X v UK, I would agree, but in my view, as I have said, it is not. The observations of
A-G Jaaskiner at paragraph 47 of Case C-536/11 _Bundeswettbrewerbsbehorde v Donau Chemie [2013] CMLR 19_
are cited. He says:
“Pursuant to Article 19(1) [of the TEU], Member States are bound to provide remedies 'sufficient to ensure
effective legal protection in the fields covered by Union law


-----

In other words, in the light of that Treaty provision, the standard of effective judicial protection for EU based
rights seems to be more demanding than the classical formula referring to practical impossibility or
excessive difficulty. In my opinion this means that national remedies must be accessible, prompt and
reasonably cost effective.”

38. In what I shall call DEB v Germany [2011] 2 CMLR 529, the CJEU considered the approach which should apply
in granting legal aid in the context of the right to a fair trial. The court referred to the ECtHR's approach under Article
6 of the ECHR, stating (Paragraph 45) that it was important for a litigant not to be denied the opportunity to present
his case effectively before the court. For this proposition, Steel v UK was cited. In Paragraph 46, the court said:
“Ruling on legal aid in the form of assistance by a lawyer, the ECtHR has held that the question whether
the provision of legal aid is necessary for a fair hearing must be determined on the basis of the particular
facts and circumstances of each case and will depend, inter alia, upon the importance of what is at stake
for the applicant in the proceedings, the complexity of the relevant law and procedure and the applicant's
capacity to represent himself effectively.”

The ECtHR cases of _Airey, McVicar v UK_ (2002) 35 EHRR 22, PC & S and Steel are cited in support of those
observations. There is no reference to X v UK.

39. It is, I think, apparent that Article 47(3) does not set a standard which is lower than that applicable to Article 6.
However, provided that the effectiveness and fairness criteria are properly applied, it does not necessarily set a
higher standard. And there is further support for the view that X v UK sets too high a threshold.

40. I come now to consider what is the correct approach to Section 10(3) of LASPO. In their joint skeleton argument
on the matters common to a number of the claims, the claimants said that it was likely to be relatively unusual for
the Director to be satisfied that the 10(3)(a) test was met and so 10(3)(b) assumed critical importance. In argument,
that was resiled from to an extent. It was submitted that, since s.10(3) was concerned with procedure intended to
prevent a breach of Convention rights, the 'breach' referred to in s.10(3) must refer to a breach of the procedural
requirements inherent in any article and not breach of the substantive right itself. Mr Chamberlain accepted that
s.10(3) was concerned with procedural rights. Since the procedural requirements exist in order to make effective
the protection provided by the relevant Article, the ultimate question must be whether denial of legal aid would
either cause or produce a risk of causing a breach of a requirement needed to avoid a breach of the substantive
right conferred by the relevant Article.

41. In a decision given on 2 May 2014, Coulson J considered the proper approach to s.10(3). The case in question
is _M v Director of Legal Aid and Casework_ _[2014] EWHC 1354 (Admin). It was not an immigration case. Since_
Coulson J found in the claimant's favour because the merits criteria had not been properly applied, any conclusions
on the correct approach to exceptional funding were not needed. However, since the issue might arise if the
Director refused legal aid on the basis that the claimant's application did not fall within the scope of Part 1 of
Schedule 1 to LASPO, he believed it sensible to deal with the issue. Thus I suppose his conclusions may strictly be
regarded as obiter dicta, but they were based on full argument and so carry considerable weight.

42. There had been argument about what was meant by an exceptional case. He decided that it covered cases
which fell outside Part 1 of Schedule 1 and so were an exception to the general regime which limited a right to legal
aid (subject to means and merits which include cost considerations) to cases falling within Part 1. Thus exceptional
has no wider meaning. This construction is not challenged by Mr Chamberlain.

43. Coulson J considered that cases falling within s.10(3)(a) would be extremely rare since they would require the
defendant to be able to identify, in advance, a case where the non-provision of civil legal aid would, without
qualification, be a breach of the applicant's Convention rights. He continued in Paragraph 59:
“That requires complete certainty on the part of the defendant at the outset and therefore requires a very
high threshold.”

44. It is difficult to see that, if certainty is the appropriate test, s.10(3)(a) could ever apply. It does not seem to me
that certainty is the appropriate test nor does the language used in s 10(3)(a) require it In order to establish a


-----

breach of a human right, an individual has to establish on the balance of probabilities that such a breach has
occurred. ECtHR jurisprudence suggests that a high level of probability is required. I see no reason why that should
not be applied in s.10(3)(a) since Parliament must be taken to have appreciated that that was how breaches could
be established. This seems to me to be the correct approach if s.10(3)(a) is to have any sensible application. Thus
if the Director is satisfied that legal aid is in principle needed when its refusal would to a high level of probability
result in a breach, s.10(3)(a) is met and means and merits will determine whether legal aid is to be granted and to
what extent. It may for example not be necessary to grant legal aid for more than advice, particularly as the
obtaining of advice from a competent solicitor may save further cost by persuading the individual that he has no
case or enabling him to present his application in a way which enables the decision maker or court to deal with it
expeditiously and without the cost incurred in seeing whether a litigant in person does have valid points.

45. Coulson J considered s.10(3)(b). Mr Bowen, Q.C. (who represented the claimant in that case as he has two of
the claimants in these cases) had submitted that the real risk test which was applied where, for example, there was
said to be a risk of a breach of a human rights Article if a person were to be removed to another country was the
correct test to apply. Coulson J rejected this submission on the ground that it set too low a threshold. He was
influenced by a decision of Cranston J in R(Tabbakh) v Staffordshire and West Midlands Probation Trust [2014] 1
WLR 1022.

46. Tabbakh's case concerned an attack on the policy applicable in guidance about the imposition of additional
licence conditions to be applied to violent prisoners when released from custody. It was said that this policy created
an unacceptable risk of a breach of the procedural requirements of Article 8. Cranston J carried out a detailed
analysis of the various authorities which had considered the lawfulness of a policy or actions said to give rise to a
risk of breach of an Article. He drew a distinction between Article 3 and other cases. Following R(Munjaz) v Mersey
_Care NHS Trust, [2006] 2 A.C. 148., in Article 3 cases having regard to the nature of the Article, a significant risk of_
a breach was set. That same test would be appropriate in considering other Articles such as 2 and 4 which had no
possibility of derogation.

47. However, in relation to such Articles as 8, a higher threshold was appropriate. In removal cases, the ECtHR has
recognised the need for there to be a risk of a flagrant breach. Cranston J relied on observations of Sedley LJ in
_R(Refugee Legal Centre) v Secretary of State for the Home Department [2005] 1 WLR 2219where he said that_
potential unfairness was susceptible to judicial intervention to “obviate in advance a proven risk of injustice …
inherent in the system itself”.

48. The case of Tabbakh (which is I was told under appeal) concerned an attack on government guidance. I have to
construe the provisions of a statute on the assumption that Parliament would be aware of the relevant law and
would not enact provisions, unless making it clear that that was intended, which ran an unacceptable risk of a
breach of the procedural requirements of an Article. The word 'risk' in s.10(3)(b) is not qualified.

49. I have already considered the procedural requirements of Article 8, but I should, I think, refer specifically to the
decision of the Court of Appeal in IR(Sri Lanka) v Secretary of State for the Home Department [2012] 1 WLR 232.
Maurice Kay LJ gave the only reasoned judgment. He identified from immigration and national security cases (IR
involved national security being an appeal from SIAC) a 'clear and consistent approach'. He cited _Al-Nashif v_
_Bulgaria (2002) 36 EHRR 655 in which, having stated that there must be a measure of legal protection in domestic_
law against arbitrary interferences by public authorities with the rights safeguarded by the Convention, the court
continued at Paragraph 123:
“Even where national security is at stake, the concepts of unlawfulness and the rule of law in a democratic
society require that measures affecting fundamental rights must be subject to some form of adversarial
proceedings before an independent body competent to review the reasons for the decisions and relevant
evidence, if need be with appropriate procedural limitations on the use of classified material.”

And in _Turek v Slovakia (2006) 44 EHRR 861 the court made clear that the court was concerned to ensure that_
procedural protection was practical and effective.


-----

50. In national security cases, the Article 8 procedural requirements do not equiparate with those of Articles 5 and
6. That is because of the need, recognised by the ECtHR, to have some means of relying on classified material. But
in general immigration cases, I see no good reason to apply a lower procedural standard nor does it seem to me
that a risk of breach need be any higher than comprehended in the real risk test routinely applied by the ECtHR.
But, as I have said, in Articles from which derogation is possible the risk can properly be considered to be the risk of
a flagrant breach which does apply a somewhat higher test than a real possibility or a risk that is more than fanciful.
If legal aid is refused, there must be a substantial risk that there will be a breach of the procedural requirements
because there will be an inability for the individual to have an effective and fair opportunity to establish his claim.
That principle will apply whether there are court or tribunal proceedings or a decision from the Home Office. It
follows that I do not entirely accept Coulson J's conclusion in M that the test whether the refusal would impair the
very essence of the right leads to a conclusion that the grant of legal aid will only rarely be appropriate. The very
essence is that in procedural terms it can be put forward in an effective manner and there is a fair process.

51. It follows from what I have so far said that in my view the Guidance is defective in that it sets too high a
threshold and fails to recognise that Article 8 does apply even in immigration cases and, despite the exclusion of
Article 6, carries with it procedural requirements which must be taken into account. Neither Maaouia nor RB
disallows that.

52. Having set out what I believe to be the correct approach to be applied by the Director, I must consider each of
the six claims. Some will require consideration of other general matters, but all have an Article 8 claim. It is
important in considering Article 8 to bear in mind that rights of family members, particularly children, must be taken
into account. Indeed, it has been made clear in the Supreme Court that the interests of a child are a primary
consideration and Parliament recognised and gave effect to this in Section 55 of the Borders, Citizenship and
Immigration Act 2009 by requiring that the need to safeguard and promote the welfare of children who are in the
United Kingdom be taken into account in an immigration decision.

53. Before coming to the circumstances of each case, I should say that two grounds relied on in the case of IS were
not for consideration in this hearing. These assert that the operation of the scheme puts unacceptable obstacles in
[the path of applicants and that there is a breach of the Equality Act 2010. I simply note that an application for ECF](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
can only result in payment for any adviser if ECF is granted and, since that has only occurred in 1% of cases,
solicitors are not prepared to take on such cases. This may well not be cost effective as I have already indicated.
There are also complaints that the process for applying for ECF is too complicated. Those issues will have to be
dealt with in subsequent hearings.

54. **Teresa Gudanaviciene. I shall refer to this claimant as TG. She is a national of Lithuania who came to this**
country in 2010 to work here. She was in a relationship with a partner who had a drink problem and was abusive
and violent towards her. In September 2012 she was convicted of an offence of wounding her partner with intent
contrary to s.18 of the Offences against the Person Act 1861. She had stabbed her partner with a kitchen knife and
it was obviously fortunate that she had not killed him. However, it is apparent from the judge's sentencing remarks
that the jury had, it would seem in a rider to its decision, said that she had been under pressure and had been
provoked by her partner's conduct. The judge said that having regard to this and her family responsibilities he would
pass a sentence which was “about six to twelve months lighter” than he had originally envisaged. He imposed a
sentence of 18 months imprisonment.

55. The Secretary of State for the Home Department decided that the claimant should be deported. Regulation
19(3) of the Immigration (European Economic Area) Regulations 2006 enables removal to be carried out if the
Secretary of State has decided that it is justified 'on grounds of public policy, public security or public health in
accordance with Regulation 21'. Regulation 21(5) provides that any such decision must comply with the principle of
proportionality and must be based exclusively on the person's personal conduct. Regulation 21(5)(c) provides:
“the personal conduct of the person concerned must represent a genuine, present and sufficiently serious
threat affecting one of the fundamental interests of society. “

And Regulation 21(5)(e) states that a person's previous criminal convictions do not in themselves justify the
decision


-----

56. The claimant has a two year old daughter of whom her former partner is the father. The decision to deport
recognised the need to safeguard the child's welfare in accordance with s.55 of the 2009 Act. Her daughter is in
foster care. The only report is in the form of a statement from a senior social worker whose report was made at a
time when the claimant was still in prison: she has since been granted bail. The view expressed was that her father
had problems in relating to his daughter and children's services had concerns for her safety and development
should she be placed with her father. While there had been no opportunity to make a full assessment of the
claimant's capability as a carer of her daughter, such contact sessions as had been possible showed that the
claimant appeared to be the most obvious choice of sole carer.

57. Risk of harm from the claimant has not been properly assessed. The Home Office has relied on a report which
goes no further than to indicate that when she was received into prison following her conviction, she was assessed
because of the nature of the offence as a medium risk of serious harm. Reliance has also been placed on the
emotional harm to her daughter from the offence but that is hardly all the fault of the claimant having regard to the
abusive and violent conduct of her former partner. In paragraph 30 of the decision to deport this is said:
“It is considered that the combination of your criminal conduct in terms of the risk of serious harm to the
public and your propensity to reoffend make it reasonable to strike a fair balance between the best
interests of your daughter and the weight attached to the necessary action of deportation. It is considered
that this can be achieved by expecting you to return to Lithuania and maintain relationship with your child
and partner by modern means of communication.”

58. The flaws in this reasoning are all too obvious. There is no evidence that the claimant has a propensity to
reoffend. She has been living in a safe house for victims of domestic violence and completed courses designed to
assist such victims. Further life with her former partner is not likely. The suggestion that she can maintain a
relationship with her daughter from Lithuania is hardly in the daughter's best interests. It must be apparent that she
has a very strong case so far as merits of the appeal are concerned.

59. I should add that she has very poor command of English and, as must be obvious, she will be emotionally
involved in the appeal so that she cannot approach it in an objective fashion. Her application for legal aid was
refused in July 2013. She requested a review through her solicitors and the refusal was maintained in a decision of
26 July 2013. It is to be noted that the Home Office had requested an oral hearing of the appeal.

60. The reasons for refusal set out in the 26 July 2013 letter are in my view thoroughly unsatisfactory. It is said that
the issues are not complex and the tribunal 'will take account of the relevant case law and legislation, including EU
law and the facts of the case'. But the test under Regulation 21(5)(c) is key and it will be necessary to produce
evidence to deal with the risk of harm. That does not now exist to any meaningful extent and it is difficult to follow
how without assistance the claimant can be expected to obtain the necessary evidence, let alone make
representations on the issue. Furthermore, there is no evidence as to whether the daughter will be able to be cared
for if she were to go to Lithuania with her mother and what provision will be made for her daughter's future here. All
this additional evidence cannot be obtained by the tribunal, particularly as the proceedings are adversarial. The
suggestions in the refusal letter that “any further evidence in respect of your client's family or criminal case is
accessible by your client and can be submitted to the First Tier Tribunal for their consideration” and “Your client can
with the assistance of an interpreter, further address any question of the First Tier Tribunal and provide further
factual information towards the proportionality of the decision to deport” are little short of absurd. It reflects the
flawed guidance on the high level of the threshold and the exclusion of Article 8.

61. A matter relied on by Mr Chamberlain in his skeleton argument was that the strong merits of the appeal
suggested the claimant was less likely to be disadvantaged by the absence of professional representation. That in
my judgment is a very dangerous argument since it suggests the more meritorious a case the less need there is for
legal assistance. The dictum of Megarry J concerning awareness of open and shut cases which turned out not to be
so is cautionary. So far as the daughter's rights are concerned, reliance is placed on the observation of the initial
refusal letter of 12 July 21013 which stated:
“The consequences of deportation in the applicant's case could impact upon her relationship with her child,
if father is awarded a residence order and remains in the UK.”


-----

It is not realistic to suggest that the father would be a satisfactory carer. Further, it is said that the possible severing
of relations with the claimant's daughter is not supported by the material put before the Director.

62. The decision in TG's case shows how the very high threshold applied by the Guidance can produce a perverse
decision. Even on that high threshold, the decision was in my judgment unreasonable in Wednesbury terms but, on
the correct approach, it is indefensible. It is accepted that if as a matter of law I were to take the view that an
adverse decision could not be made I should direct the Director to grant legal aid (subject to the means test being
satisfied, as I think it is) since the merits test is clearly met. Unless proper evidence is obtained on risk of harm and
in relation to the future care of the claimant's daughter, she will not obtain a just result and on the evidential matters
the tribunal cannot help her. Furthermore, competent solicitors may be able to persuade the Home Office that the
decision should be withdrawn so that costs are saved to an even greater extent.

63. I.S. IS has an anonymity order which should in my view be maintained. The reasons for it will become apparent
when I set out the circumstances of his case. I am concerned only with his claim that the refusal of ECF in his case
breaches or risks the breach of his Article 8 rights.

64. The claimant is a 59 year old Nigerian. He is blind and his mental condition is such that he lacks capacity and
so the Official Solicitor has acted as his litigation friend. He is not able to say when he arrived in the UK or whether
he entered lawfully or unlawfully or, it may be, overstayed. The claimant is incapable of looking after himself. He
was evicted from his privately rented accommodation and has had to bring community care proceedings against his
local authority. His ability to access such necessary assistance depends on establishing his immigration status, in
particular in showing he is here lawfully. He apparently believes he has been here for about 13 years, but has no
passport. He needs advice from a qualified person as to how he should endeavour to obtain any necessary leave to
remain in the UK. The Official Solicitor has confirmed in a statement in the case that he is unable to provide such
advice or services and so applied for ECF from the Director.

65. The Official Solicitor in his statement asserts that the Guidance when dealing with persons lacking litigation
capacity (paragraph 25) is erroneous. One question posed is:
“Will a litigation friend be acting for the applicant? How capable is the litigation friend of presenting the case
on the applicant's behalf?”

It is necessary to establish whether an individual does lack capacity and that will normally require a medical report
which must be paid for by someone. Furthermore, a litigation friend is not an advocate and cannot act as such,
certainly in immigration cases without the necessary authorisation. A friend is unlikely, unless a lawyer, to have a
right of audience.

66. The application submitted to the Director on behalf of IS on 12 June 2013 stated that the application to the
Home Office would depend on complex points of law relating to Articles 3 and 8 ECHR. Article 3 was said to arise in
relation to the availability of necessary care in Nigeria were he to be refused leave to remain. This it was said would
require medical reports and expert evidence. Arguments based on Article 8 would also require medical evidence
and proof that removal would be disproportionate.

67. The response of the Director on 23 June 2013 pointed out that rights to remain arising from Article 3 of the
ECHR were within Section 30(1)(b) of Part 1 of Schedule 1 to LASPO, thus legal aid might be available provided
the merits and means tests were met. But legal aid by reference to Article 8 was refused on a merits basis. The
claimant's advisers sought a review on 2 July 2013. In paragraph 12 this was said:
“There is no-one to assist IS with the Article 8 aspects of his immigration application … We have been
unable to find an immigration solicitor who is willing to make the Article 3 arguments because, although
they are in scope, they are closely bound up with the Article 8 aspects of the claim, the work for which
would be unfunded. It is for this reason that we set out the Article 3 ECHR arguments in our grounds,
although the application is only for funding for the Article 8 ECHR aspects of this claim.”

68. The decision on review was adverse. It was said in a letter of 16 July 2013 that the claimant should be
immediately referred to an immigration lawyer so that a lawyer could proceed with an application for regularisation


-----

of his immigration status on Article 3 grounds, but “on the information submitted it has not been demonstrated that
you have any viable Article 8 claim.” In any case, the Guidance was relied on to assert that the procedural
requirements of Article 8 did not give rise to an obligation to provide legal aid.

69. A further application for ECF was submitted in September 2013 but refused on 11 September 2013. It was said
that the claimant's Article 8 rights were not at stake because he was not at risk of deportation. That is somewhat
inconsistent with the apparent acceptance that his Article 3 rights did justify legal aid. Article 3 rights were, in the
absence of removal, no more at risk than his Article 8 rights.

70. The reality is, as Mr Low-Beer of the Public Law Project recognises, that an Article 3 claim is very weak having
regard to the threshold set by the relevant authorities. Indeed, any immigration solicitor would, I suspect, advise that
it could not be pursued. The reality is that Article 8 is the only basis which can prevail to show that IS needs to be
allowed to remain rather than be removed. Whether he has family or any possibility of support in Nigeria is
obviously of importance. The Home Office may possibly have some records of his entry (if it was initially lawful) and
investigations are needed to discover as much as possible about his past in this country. It is to be noted that he
has made a claim against the local authority in relation to homelessness in which it is said that he was unable to
look after himself and lived in a filthy flat infested with bedbugs, rodents and cockroaches and he survived by
begging.

71. It is clear that no solicitor could properly obtain legal aid in relation to an Article 3 claim which he knew had no
validity to enable work to be done which would also be material to a possibly valid Article 8 claim. But the claimant's
circumstances show that he clearly needs some expert immigration advice to enable him to put a proper application
to the Home Office. That advice cannot be given by a person who is not authorised under s.84.

72. Mr Chamberlain submitted that the decision of the Director was not unlawful since it was based on the
information placed before him which raised an Article 3 claim. Thus he was entitled to point out that that meant the
application was in scope and the work which would be required to pursue an Article 3 claim included in particular
medical evidence and material which would also be relevant to an Article 8 claim. While I recognise the force of that
so far as it goes, the refusal to include the Article 8 claim so that all necessary work could be done was based on
the erroneous view that the procedural requirements were not included. The need for a full consideration of the
basis upon which IS could make an application is apparent.

73. The decision to refuse was essentially based on the Guidance and the erroneous view that Article 8 could not
be engaged since he was not at risk of removal. I have already indicated why the Guidance in respect to Article 8 is
wrong. In these circumstances, I will quash the decision and require a reconsideration in the light of the fuller
evidence now available to the Director. I can only say that I believe that legal aid should be granted to this
extremely vulnerable person since without it he will not be able to achieve an effective exercise of his Article 8
rights. However, I do not think I can go so far as to say that a refusal would necessarily be unlawful, but good
reasons for it will be needed.

74. S. The claimant, a Nigerian citizen, was violently assaulted in a family dispute following his father's death. He
was badly injured and his brother was killed. The assailants were given short prison sentences and the claimant
was anxious to leave Nigeria before their release, fearing further violence. His uncle arranged with an agent for him
to travel to the UK on a false passport. He arrived here in January 2004 and was introduced by the agent to a
restaurant owner, Comfort Afolabi. She used his fear of the authorities and threats to inform that he was here
unlawfully and so would be returned to Nigeria to compel him to work for her in appalling circumstances. He was
paid very little – certainly insufficient to provide for a living wage – and slept on a mattress in the cooler room of the
restaurant. He met a lady who is now his partner and by whom he has had three children. His partner and the
children have been given indefinite leave to remain and the third child is considered to be a British citizen.

75. In the circumstances, he contended that he was a victim of trafficking (VOT). The circumstances in which he
was required to work for Ms Afolabi amount to slave labour. Encouraged by his partner, he escaped from the
restaurant in January 2009 and went to live with his partner. Ms Afolabi apparently died in the summer of 2009. His
fear of being deported if he approached the authorities led him to delay taking any action until April 2013 when he


-----

approached the Anti-Trafficking and Labour Exploitation Unit (ATLEU), which operates in North London. ATLEU
were acting for his partner in relation to support for her children and her immigration position. She too was a VOT.

76. An application for ECF was made by ATLEU on his behalf on 17 June 2013. This was said to be for the
purposes of preparing an application under Article 8 of the ECHR and making a referral to the competent authority
to enable a positive decision in relation to his claim to be a VOT. It was said that a failure to grant ECF would
breach or create a risk of breach of his Article 4 and 8 rights and violate his EU law rights as a VOT. The application
followed a request from the Public Law Project (to which ATLEU had referred his case) for a preliminary view on
ECF. There was a negative response. A review was carried out and the answer remained negative. The reasons
were given in a letter of 28 June 2013.

77. The points made were first that from the advice received from ATLEU, the claimant would have all necessary
information to apply to be recognised as a VOT. While an asylum application was a probability, legal aid for it was
premature. Secondly, it was said that, since there was no removal indicated, Article 8 rights in relation to his
children and partner did not arise and reliance was placed on Paragraph 60 of the Lord Chancellor's Guidance. So
far as Article 4 was concerned, there was a satisfactory mechanism available to protect him once he was regarded
as a VOT.

78. The procedure in place for establishing whether an individual is a VOT is important. The Council of Europe
Convention on Action against Trafficking in Human Beings (CAAT) was ratified by the UK in 2009 and required
measures to be put in place to protect VOTs. It included the need under Article 10 to adopt 'such legislative or other
measures as may be necessary to identify victims as appropriate in collaboration with other Parties and relevant
support organisations'. If there are reasonable grounds to believe that a person has been a VOT, he or she must
not be removed until the identification process as victim of an offence is completed and the state must ensure that
he or she receives the assistance provided for by Article 12(1) and (2). Article 12(1) sets out a number of forms of
assistance which must at least be provided. These include by s.12(1)(d) and (e):
“(d) counselling and information, in particular as regards their legal rights and the services available to
them, in a language they can understand.

(e) assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders.”

79. In order to establish that there are reasonable grounds to believe a person has been a victim of trafficking, an
application must be made through what is referred to as the National Referral Mechanism (NRM). A referral via the
NRM can only be made by an organisation which is designated as a First Responder. These comprise the Home
Office, local authorities, HSC Trusts, the police, the NCA, the Gangmaster Licensing Agency, the Salvation Army,
Barnardo's and the NSPCC. In addition, there are five organisations of a charitable nature which assist persons
such as the claimant. It is obvious that many of these limited number of first responders have no specific
immigration experience where that may be needed and so no ability to give immigration advice lawfully. Further, as
the claimant's solicitors' evidence shows, considerable difficulty existed in finding a first responder prepared to
assist, which caused an unacceptable delay.

80. The competent authority in a case such as this where there are immigration considerations, the claimant being
an illegal entrant and so in need in due course of leave to remain, is the Home Office. It is in those circumstances
easy to understand why someone such as the claimant who fears for his safety if returned to the country of his
nationality and who knows he is here unlawfully is reluctant to inform the Home Office of his presence for fear of
being detained or removed. It is not clear whether he would have a claim for humanitarian protection. All would
depend upon the full circumstances of what occurred in Nigeria to make him leave the country and whether
adequate protection would be available. In addition, since he now has a family life with his partner and children who
have indefinite leave to remain, his Article 8 rights are very much in issue.

81. While the UK has ratified the CAAT, it has not been directly incorporated into domestic law. However, there is a
Directive of 5 April 2011 (2011/36/EU) on preventing and combating trafficking in human beings and protecting its
victims. This is of course binding in domestic law. It is aimed at ensuring that those responsible for trafficking are


-----

able to be prosecuted successfully and that victims are given all necessary assistance to achieve that aim. As soon
as there are reasonable grounds for believing that a person is a VOT, he or she should be given assistance and
support whether or not willing to act as a witness in any prosecution. In addition, victims should be given access
without delay to legal counselling (Preamble Article 19 and Article 12(2)). Article 12(2) states that legal counselling
must include for the purpose of obtaining compensation. Article 17 requires Member States to ensure that VOTs
have access to existing schemes of compensation to victims of violent crimes of intent. Thus the death of the
trafficker in this case and so the possible lack of any person who can be prosecuted does not mean that there is no
purpose in legal advice and counselling. The claimant, if it is concluded that he is a VOT, may well be entitled to
compensation if he claims it.

82. Article 12(1)(d) of the CAAT, which I have already cited, applies to a victim who is defined in Article 4(e) as “any
natural person who is subject to trafficking in human beings as defined in the article.” The definition, which is very
similar in Article 2 of the Directive, includes forced labour or services and so the claimant, if his evidence is
accepted (and it is not suggested that it should not be) is a VOT. Reasonable grounds for so believing have already
been found to exist.

82. Mr Chamberlain submits that the Directive and, insofar as it can be relied on, the CAAT by Article 12 (which is
the relevant Article in both) applies only to those who are regarded as victims and does not confer any rights, in
particular any right to legal advice or representation, for the purposes of establishing that a person is a VOT. I have
no doubt that that submission is correct. However, that does not mean that in a given case legal advice may not be
needed to ensure that an individual is able to pursue in an effective way an application to receive the status of a
VOT.

83. I do not doubt that one such as the claimant who is here unlawfully will have fears about how he should make
his claim without the risk of being removed or at least detained with a view to removal. Any Article 8 or other ECHR
rights are likely to be a material consideration so far as his future prospects of living here are concerned, particularly
if he may have an Article 3 claim to avoid removal. Nevertheless, the application to be regarded as a VOT is not
directly allied with an immigration issue. Since there is a prohibition on removal of one who is reasonably believed
to be a VOT, it would clearly be unlawful to seek to remove an applicant. In my view, that should be made clear to
all applicants. Furthermore, it would almost certainly be wrong to seek to detain a victim of trafficking, unless there
were very exceptional circumstances in accordance with Home Office Enforcement Instructions & Guidance,
Chapter 55.10.

84. Mr Bowen submits that Article 4 of the ECHR includes a procedural obligation to investigate whether there has
been a breach. That is no doubt correct, but it does not in my view assist the claimant in a case such as this. A
[breach of Article 4 is only justiciable within the Human Rights Act 1998 if a public authority is in breach. This would](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
mean there was a failure to take reasonable steps to ensure not only that trafficking be identified and prevented but
also that those responsible be prosecuted. But I am not persuaded that legal aid is necessarily required to enable
the requisite protection to be given.

85. While I fully appreciate the concerns of the claimant and the need to consider his immigration situation and
whether asylum should be claimed, as I have said whether or not he is a VOT is a separate issue. No doubt it may
be sensible for the whole immigration situation to be considered, in particular as the decision maker on the VOT
question will be the Home Office which is also concerned with immigration issues. That is something which in my
view should be considered by the Director. The refusal was based on the Guidance which, as I have said, puts the
threshold far too high.

86. Mr Bowen sought to rely on a report of the Joint Committee of Parliament on the draft **_Modern Slavery Bill_**
published on 8 April 2014. This, it was said, confirmed the experience of the claimant's solicitor that those in the
Home Office who were to deal with applications by persons claiming to be a VOT were not adequately trained.
However, Mr Chamberlain objected to its admissibility on the ground that to rely on it would be a breach of Article 9
of the Bill of Rights and of Parliamentary privilege. Reliance is placed for this contention on a decision of Stanley
Burnton J in Office of Government Commerce v Information Commissioner _[2008] EWHC 774 (Admin). While the_
report, being a public document, can be noted, it is not permissible to consider arguments as to the correctness or


-----

acceptability of the matters raised in the report. It seems to me that Mr Chamberlain's objection is well founded. In
any event, concerns about the present position in relation to dealing with VOTs are not directly material in deciding
whether the refusal to grant legal aid is lawful in given circumstances. I note the evidence from the claimant's
solicitor about the difficulties in filling out the necessary forms. This can obviously be taken into account by the
Director. But otherwise I do not think even if it were admissible the report would assist.

87. I have carefully considered whether the errors in the approach of the Director do require the decision to be
quashed. I cannot say that a decision to refuse based on the correct approach would necessarily be wrong in law,
but there are powerful arguments based on the vulnerability of the claimant which show that legal aid was not only
desirable but necessary to enable his overall rights, which could not be completely divorced from the VOT
application, to be made effective. I think the Director should reconsider this claimant's case and so I shall quash the
decision to refuse legal aid.

88. **Reis. The claimant is a Portuguese national now 28 years' old. He entered this country with his mother in**
December 1998 when he was 12 years' old and has lived here ever since. He has since about 2002 committed a
considerable number of criminal offences which have increased in seriousness. His first custodial sentence appears
to have been one of 9 months and 2 weeks in a young offenders' institution in 2006 for various offences committed,
some while on bail, for driving vehicles taken without consent dangerously and while disqualified. In 2007 he was
again convicted of driving whilst disqualified and received a suspended prison sentence. He breached this order
and in June 2008 was sentenced to 20 months imprisonment for burglary and theft. He was then warned by the
Home Office that deportation would not be pursued then, but that he must note that it had been considered. He took
no notice. In November 2009 he was convicted of aggravated vehicle taking, causing damage to a vehicle in excess
of £5000, and driving whilst disqualified. For these offences, he was sentenced to 15 months imprisonment. The
damage to the vehicle was caused when he attempted to escape from the police and was involved in a high speed
chase. While the offences are not of the most serious and he did not commit any offence which directly involved
violence to an individual, nonetheless the offending was persistent and its seriousness increased.

89. The Recorder who sentenced him in 2009 referred to his appalling record and concluded:
“It is clear that you … are easily influenced by friends and criminally minded peers and it is also clear that
you have shown a significant ability to act without any consideration towards others and other people's
property to the extent that you put other road users at significant personal risk.”

90. On 29 July 2010 the Secretary of State for the Home Department notified the claimant that she had decided to
make a deportation order. It was asserted that he had not resided here, having regard to his custodial sentences,
for at least 5 years so that he was not entitled to the level of protection appropriate to that. The First Tier Tribunal
accepted that he had but nonetheless dismissed his appeal. His application for leave to appeal to the Upper Tier
Tribunal was refused. He sought judicial review of that refusal raising a point which had not been clearly made that
he qualified for the highest level of protection by virtue of 10 years residence. Leave was granted by Walker J,
following refusal on the papers by me, in May 2012. On 13 May 2013 the Secretary of State for the Home
Department agreed to reconsider the question of deportation and so the judicial review was brought to an end. On
20 May 2013 she decided to make a deportation order.

91. The Immigration (European Economic Area) Regulations 2006 govern the removal of EU citizens as stated in
the case of T.G. Regulation 15 concerns a permanent right of residence. Regulation 15(1)(a) gives a permanent
right of residence to such as the claimant if he has resided in the UK in accordance with the regulations for a
continuous period of 5 years. It is accepted that the claimant qualifies under this provision. Regulation 21 sets out
the basis upon which deportation of permanent residents can be achieved. Regulation 21(3) provides:
“A relevant decision may not be taken in respect of a person with a permanent right of residence under
Regulation 15 except on serious grounds of public policy or public security.”

But greater protection is afforded to those who have resided here for at least 10 years by virtue of Regulation 15(4)
which so far as material provides:

-----

“(4) A relevant decision may not be taken except on imperative grounds of public security in respect of an
EEA national who –

(a) has resided in the United kingdom for a continuous period of at least ten years prior to the relevant
decision.”

If the claimant is only entitled to the 5 year protection, he will obviously be more readily regarded as one whose
deportation would be proportionate, as indeed the First Tier Tribunal decided on his original appeal. The key
question is whether and the extent to which time spent in custody can properly be regarded as counting towards a
continuous period of residence.

92. Even at the lowest level when five years have not elapsed, the deportee must present a genuine and sufficiently
serious threat to the requirements of public policy: see R v Bouchereau [1981] 1 All ER 924. There are a number of
domestic authorities which have decided that time spent in prison does not count towards an accumulation of 5
years: see for example _HR (Portugal) v Secretary of State for the Home Department [2010] 1 WLR 158. In LG_
(Italy) in the UTIAC, Carnwath LJ extended this approach to the 10 year period, even for someone who had
acquired permanent residence here by virtue of 5 years continuous residence. In FV (Italy) v Secretary of State for
_the Home Department [2013] 1 WLR 3339, the Court of Appeal decided that in order to determine whether an EEA_
national had resided in the UK for a continuous period of at least 10 years a qualitative assessment of whether he
was genuinely integrated was needed. A period of imprisonment would be a relevant factor but would not
necessarily defeat an individual's claim. Aikens LJ approached the question on the basis that if a person is
integrated before any period of imprisonment, that imprisonment should not defeat a 10 year claim. Rafferty LJ
expressly agreed with him.

93. It is not for me in these proceedings to decide the issue. Mr Chamberlain has submitted that the law is now
clear following the decision of the CJEU in Secretary of State for the Home Department v MG (Case C-400/12). It is
necessary to count back from the decision to deport so that the decisive criterion is whether the EU citizen has
resided continuously in the Member State for the preceding 10 years. Since the Court had decided that the
imposition of imprisonment showed that the individual had not respected the values of the host state, permanent
residence could not be established unless there were 5 years out of prison. In Paragraphs 35 and 36 the Court said
this:
“35. As for the question of the extent to which the non-continuous nature of the period of residence during
the 10 years preceding the decision to expel the person concerned prevents him from enjoying enhanced
protection, an overall assessment must be made of that person's situation on each occasion at the precise
time when the question of expulsion arises.

36. In that regard, given that, in principle, periods of imprisonment interrupt the continuity of the period of
residence for the purposes of Article 28(3)(a) of Directive 2004/38, such periods may – together with the
other factors going to make up the entirety of relevant considerations in each individual case – be taken
into account by the national authorities responsible for applying Article 28(3) of that directive as part of the
overall assessment required for determining whether the integrating links previously forged with the host
Member State have been broken, and thus for determining whether the enhanced protection provided for in
that provision will be granted.”

It follows that to assess whether there has been 10 years continuous residence prior to the decision to deport (in
the case prior to May 2013) the First Tier Tribunal will have to consider all the circumstances to decide whether
enhanced protection has been established.

94. The claimant came here in December 1998. He had thus been here for some 14 ½ years before the decision to
deport him. It is common ground that he has a right of permanent residence. The issue in his case may therefore
turn on whether the 10 years prior to May 2013 is interrupted by any periods of imprisonment. The guidance issued
by the CJEU is not in my view as clear as Mr Chamberlain submits and there is a difficult question to be determined
on the facts of the claimant's case. Those and his attitudes must be carefully assessed.


-----

95. There is an Article 8 claim based on his fatherhood of a child. He has split up from his partner. There can be no
doubt that that claim is extremely weak and I do not think it is such as to justify legal aid.

96. The reasons for refusing legal aid include the assertions that the claimant had had legal representation at his
previous hearings and it was “speculative to think that previous errors will be repeated”. In addition, it is said that
proceedings before the First Tier Tribunal “are not complex either in law or procedure”. That observation I find
remarkable and it suggests that the author has never had experience of observing appeals before the First Tier
Tribunal. The reality is, having regard both to the possibility of difficulties in dealing with contentious factual matters
and, in immigration law which is taking up a substantial part of the Court of Appeal's caseload, there can be
considerable complexity.

97. The refusal was based on an application of the Guidance which set too high a threshold. This will on any view
be a difficult appeal and I am entirely satisfied that without legal assistance there is a real prospect of the claimant
not receiving justice. It follows that I quash the refusal and I propose to direct in this case that legal aid be granted
for the hearing before the First Tier Tribunal.

98. B. B is an Iranian national who arrived in the UK in March 2013. She claimed asylum fearing persecution for her
political activities on behalf of Kurds. She was granted refugee status on 15 April 2013 and given five years leave to
remain. Following her departure from Iran, her husband and son, who was born on 2 June 1997, were arrested and
interrogated. They were beaten and threatened and ordered on release to give the authorities information about the
claimant.

99. The claimant was understandably very anxious about her husband and son. She spoke no English and was
dependent on assistance from the Iranian and Kurdish Women's Rights Organisation (IKWRO). They advised her
that she might be able to apply for family reunion so that her husband and son could join her in the UK. IKWRO
were unable to assist her in making an application since it was not licensed to do so and, following advice from
IKWRO, she met with her present solicitor. Her solicitor recognised that there might be difficulties in that her son
had no passport and there were no facilities available in Iran to enable a visa to allow entry to the UK to be obtained
there. The claimant was extremely upset and worried and her inability to communicate in English made things even
more difficult for her. Her solicitor was aware from the Legal Aid casework web site that family reunion was said not
to be in scope for the purpose of grant of legal aid. Nevertheless, the view was taken that that might be wrong and
that in any event the claimant needed legal assistance to enable her to have any real prospect of achieving family
reunion.

100. If her son approached the Iranian authorities to obtain a passport, the claimant was afraid, not without good
reason, that he would be arrested and ill-treated. Thus the only way he could apply for the necessary
documentation to enable him to achieve entry to the UK was to go unlawfully to Turkey and apply there. This he did
with his father and applications for entry clearance were made in Ankara. The applications were prepared by the
claimant's solicitor on instructions from the claimant. Since the claimant's son was in Turkey unlawfully, he was
afraid to leave the friend's address where he was staying and was extremely distressed. The applications for entry
clearance were made in August 2013 but a decision was not made until 15 December 2013 when the claimant's
husband was granted an entry clearance but their son was refused. Apart from the inexcusable delay in dealing
with the application having regard to the circumstances in which the applicants were living in Turkey, the decision
was extraordinary and an appeal was lodged. Islington Law Centre assisted in this. Fortunately, before an appeal
was heard, on 13 February 2014 the claimant's son was granted the necessary entry clearance. Notwithstanding
that, he has not been granted the necessary exit permits by the Turkish authorities. However, there is little that the
UK authorities can do about that.

101. Paragraph 30 of Schedule 1 to LASPO provides so far as material in the case of a refugee for:
“(1) Civil legal services provided in relation to rights to enter, and to remain in, the United Kingdom arising
from –

(a) the Refugee Convention; …

(b) the Qualification Directive.”


-----

On 26 June 2013 the claimant's solicitor applied for legal aid to cover advice and assistance on the ground that
Paragraph 30(1)(a) applied. The application was expanded on 2 August 2013 raising in addition Article 8 of the
ECHR and the Qualification Directive Article 23, with which I will deal in due course. On 6 August 2013 Mr Sidhu,
the Development Manager of the Legal Aid Agency, replied saying by reference to debates in Parliament during the
passage of the LASPO Bill that paragraph 30(1)(a) did not cover family reunion. Since family reunion was not
directly within the Refugee Convention and Paragraph 30(4) of Schedule 1 to LASPO defined the Refugee
Convention to mean the Convention and the Protocol to it family reunion was not in scope.

102. On 12 August 2013 the claimant's solicitor made it clear that there was in addition an application for ECF. This
was refused on 19 August 2013. Review was refused on 15 September 2013. So far as Article 8 was concerned, it
was said that her claim would not be practically impossible. So far as her inability to understand English and,
because of her distressed state, to follow the application form and to overcome the difficulties arising from her son's
unlawful presence in Turkey was concerned, it was said that the claimant's cousin, who understood English, would
help her. There was in addition the facile observation that she was able to provide her solicitor with instructions.

103. The UN Conference following the Refugee Convention noted that the unity of the family was an essential right
of a refugee and recommended that Governments should take the necessary measures for the protection of a
refugee's family especially with a view to ensuring that family unity was maintained. This recommendation has been
implemented in the UK by a provision in the Immigration Rules, now contained in Paragraph 352A-F.

104. The words which are central to the claimant's main submission that family reunion is in scope are “arising
from”. Mr Chamberlain sought to rely on Pepper v Hart [1993] A.C. 593to enable him to put before me extracts from
Hansard which he submitted showed that it was Parliament's intention to exclude family reunion from the scope of
legal aid. In order to enable reference to Hansard, there must be an ambiguity in the provision in question.
Furthermore, if there is an ambiguity so that ministerial observations can be referred to, they must clearly show the
intention on which it is sought to rely.

105. I am satisfied that there is no ambiguity. The expression “arising from” is one which has a wide meaning and is
to be contrasted with wording such as 'conferred by' or 'contained in'. If it had been intended to limit the scope of
access to legal aid as contended for by Mr Chamberlain, a narrower expression could and should have been used.
A person who is recognised as a refugee has a right conferred by the Immigration Rules for family unity. As a
matter of ordinary English, that right arises from the Convention since the Convention enabled that person to
achieve the status of refugee. It is to be noted that the width of the words “arising out of” (which are no different in
meaning) has been confirmed by the House of Lords in a contractual situation in for example Union of India v EB
_Aaby's Rederi A/S [1975] A.C.797._

106. Mr Chamberlain argued that narrower wording such as “conferred by” would be inappropriate since the
Convention had not been formally adopted into domestic law. Thus, he submitted, it could not confer any
enforceable rights. That argument carries no weight since all that any narrower wording could do would be to make
clear that only rights specifically contained within the Convention would be in scope for the purposes of legal aid. It
follows that anything contained in Hansard is not admissible and that family reunion is in scope.

107. I have of course seen the material on which Mr Chamberlain seeks to rely. I confess to great surprise at the
Minister's statement that family reunion legal aid cost £5 million a year. The fact that it is in scope does not mean
that it should be granted in every case. Many are no doubt straightforward and some refugees will be competent to
deal with the necessary paperwork. But there are cases, and I am satisfied that this is one, in which an extremely
vulnerable individual is faced with a difficult situation in relation to her son, a difficulty made all too apparent by the
initial refusal by the entry clearance officer. The amount sought to cover the advice and assistance is modest, I am
told some £234. I am bound to say that even if I were wrong in deciding that it is in scope, this is a case in which
ECF should have been granted. The application of the unduly high threshold led to a wrong decision. Even if the
Guidance had been correct, to refuse in the circumstances was in my view unreasonable.

108. I should deal briefly with other matters raised. Assuming I could take account of Hansard, reliance is placed by
Mr Chamberlain on the answer to an amendment proposed by Mr Simon Hughes, MP (now ironically a Minister in
th Mi i t f J ti ) hi h ht t b i f il i li itl i t Th i i t id th t th


-----

should not require specialist advice and so it was “not therefore necessary for them to remain within the scope of
legal aid”. Mr Hughes raised the matter again, pointing out that some family reunion cases were not straightforward.
An obvious example is if there are problems in proving a relationship in particular in relation to adopted children if
the adoption was somewhat informal. Attempts to have a similar amendment adopted in the Lords were
unsuccessful. However, so far as Mr Hughes was concerned, a letter from Lord McNally was relied on. So far as
possibly complex family reunion cases were concerned, he said this:
“You also raised the issue of … appeals in immigration cases and complex family reunion cases. As you
know, we have had to make difficult choices about legal aid. Our references to the scope of the scheme
are designed to refocus civil legal aid on the most serious cases in which legal advice and representation is
_justified. This means making some legal aid remain for asylum matters, which may be a matter of life and_
death. But, fundamentally, we do not think that most immigration matters justify legal aid.”

109. All this no doubt shows that the minister believed that the words used excluded family reunion. But the matter
was left in the air in the House of Lords. Mr Chamberlain relies on what Lord McNally wrote to Mr Hughes. That is in
my view insufficient to show that Parliament, which means both Houses, intended to exclude family reunion. It may
be that it was appreciated that no amendment was needed having regard to the words used. The intention of
government is not necessarily the same as that of Parliament. Thus even if recourse to Hansard is permissible a
clear and unequivocal intention is not established.

110. In the alternative, Mr Bowen sought to rely on the Qualification Directive. Paragraph 12 of the Preamble states
that the best interests of the child should be a primary consideration when implementing the Directive. That is
enacted in Article 20(5). Article 23 is headed 'Maintaining family unity'. Article 23(1) provides:
“Member states shall ensure that family unity can be maintained.”

The rest of Article 23 deals with the treatment of family members who are limited by the definition in Article 2 to
those family members present in the same member State as the refugee.

111. Mr Bowen relies on Article 23(1) contending that there is contained in it an obligation on the Member State to
ensure that family members who are outside the state in which the individual has been granted refugee status are
allowed to enter to join him or her. I have been referred to the travaux preparatiores which do not assist Mr Bowen
in this regard. No doubt it is expected that family reunion will be achieved but the Directive does not directly give
any rights in that respect.

112. It is to be noted that Council Directive 2003/86/EC provides for family reunification and provides by Articles
2(d) and 13(1), that once an application meets the conditions which can be imposed (for example, possible health
considerations and proof of the necessary relationship), the State must authorise entry of the family members in the
UK. The UK has not opted into that Directive. However, its existence indicates that it was not considered necessary
to include those rights in the Qualification Directive.

113. The Article 8 rights of the claimant's son have been relied on by Mr Bowen as a material consideration. Since
he is not in the jurisdiction Mr Chamberlain has submitted that his rights under the ECHR are not justiciable in this
country. In Tuquabo-Tekle v Netherlands _[[2006] 1 FLR 798 the ECtHR held that the refusal to admit a 15 year old](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G0F9-00000-00&context=1519360)_
daughter breached the Article 8 rights of the whole family, including her. It seems to me that to exclude
consideration of the rights of a child of the family who has not gained entry to join his parent when considering
Article 8 is artificial. Section 55 of the 2009 Act only applies to children in the UK, but, as Blake J observed in
Mundeba _[[2013] UKUT 00088, it is inevitable when considering whether a child should be excluded his or her](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:57WP-PXK1-F0JY-C3KB-00000-00&context=1519360)_
welfare and best interests will inevitably have to be assessed.

114. I have no doubt that legal aid to cover the advice and assistance was in scope and should have been granted.
Furthermore, even if I am wrong about that, it should have been granted by way of ECF if the correct approach had
been applied. Thus I am minded to direct that it be granted to allow the claimant's solicitors to receive the modest
amount for the advice and assistance given.


-----

115. Edgehill. The claimant, a Jamaican national, was admitted to the UK on 14 September 1998 as a visitor. She
was granted leave to remain as a student until 31 January 2001. In March 2007 she applied for leave to remain on
the ground of UK ancestry, asserting that she had been born in the UK but sent to Jamaica where she was brought
up by a couple whom she believed to be her parents. The application was refused and the claimant thereupon
became an overstayer. She did not leave the UK. She said she was joined by various children, one of them, had a
son born here in May 2008 who is a British citizen.

116. She kept in touch with the Home Office and she applied for a certificate under s.10 of the Nationality,
Immigration and Asylum Act 2002 that she was entitled to remain here. This was refused on 7 March 2012. She
appealed. In her notice of appeal which she filled out without legal assistance, she said, under the heading in the
form asking her to state if the Home Office had suggested she could live safely in another part of her country of
origin, that she disagreed. She said:
“I have no home in another country all my family are here and I have nowhere to go. Also my parents
brought me to Jamaica and left me there and this is my home.”

117. That box in the form had no application since the Home Office had not suggested she could live safely in
another part of her native country. However, the First-tier judge, who dismissed her appeal, did spot that it “alluded
to her Article 8 rights”. He said he would in any event have considered them, but, because no evidence had been
produced and there was no attendance before him, he dismissed her appeal on 4 June 2012. She was granted
leave to appeal to the Upper Tier, but her appeal was dismissed on 7 February 2013.

118. In answering her Article 8 claim, the UTIAC considered her length of residence (which exceeded 14 years) and
had regard to Paragraph 276 ADE of the Immigration Rules which came into force on 9 July 2012 and required that
an applicant had lived continuously in the UK for at least 20 years in order to establish an Article 8 claim based on
private life. It said:
“… Article 8 appeals are decided on the facts as at the date of the hearing and, whilst this was a decision
made before the new Rules came into effect and therefore have no direct application and not retrospective,
we consider it appropriate to give weight to the new Rules as being an expression of the legislature's views
as to where the public interest lies.”

119. Leave to appeal to the Court of Appeal was sought following refusal of leave by an UTIAC judge. Ground 2
raised the 14 year point, but somewhat indirectly. Beatson LJ noted that the case raised a question of principle
warranting a decision by the Court of Appeal. There was another case with which it was to be joined which raised a
similar point. In due course, the claimant's appeal was allowed and the other appellant's dismissed since it did not
on the facts cover the same ground. The claimant is due to have a fresh appeal before the Tribunal.

120. Following Beatson LJ's grant of leave, an application for ECF was made on 19 September 2013. This was
refused on 14 October 2013. First, it was said that Article 8 was not engaged since leave had not been granted on
the grounds specifically relating to Article 8. However, that is to misunderstand the position since the correct
approach to 14 years residence would impact on the Article 8 claim. There was also refusal on the merits since, it
was said, the other case raised the same point. A review was sought, but on 30 October 2013 the refusal was
upheld. The author accepted that the merits test was met save in one respect, namely that the Court of Appeal
would not be considering grounds relating directly to Article 8. That maintains the same error as in the previous
decision. But the author asserts that Beatson LJ stated that the appeal raised a question of principle not a point of
law and that therefore there was no legal complexity. That is an extraordinary assertion since the point of principle
obviously turns on the correct approach in law.

121. Mr Tear represented the claimant before the Court of Appeal and now seeks to be paid for his work. There can
be no doubt that the claimant was entirely unable to argue her appeal in person. Success was by no means certain,
albeit probable, and the Home Office was concerned to try to uphold the UTIAC's approach. I am clearly of the view
that if the Court of Appeal gives leave to appeal, it will (provided the case is one which can attract ECF) prima facie
be a case in which legal aid should be granted. The point at issue was not entirely straightforward and would affect


-----

other cases. In this case I am entirely satisfied that it should have been granted and that the reasons for refusal are
flawed.

122. Mr Underwood sought to argue that Article 6 applied because the Article 8 rights were civil rights. But it is
clear, as I have indicated, from Maaouia and RB that it does not apply in immigration cases such as the claimant's.
That argument I reject.

123. Mr Chamberlain argued that representation was not needed in most cases before the tribunal or a court since
the case could be decided on written material. Any judge will recognise the value of oral argument however detailed
the written material may be and the English legal tradition has been based on oral advocacy. That in itself does not
mean that there should always be a need for representation. However, the important consideration is that justice for
a party should so far as possible be ensured and so an individual should have an effective and fair hearing.
Furthermore, the written material may well be defective if it has been, as will often be likely, put forward without
legal advice.

124. It must in addition be remembered that it is a fundamental principle that anyone in the UK is subject to its laws
and is entitled to their protection. Thus there must be a fair and effective hearing available and the Guidance, as the
facts of some of the cases I have dealt with show, produces unfairness.

125. Mr Chamberlain has placed some reliance on observations of Laws J in _R v Lord Chancellor ex p Witham_

_[[1997] 2 All ER 779. That case involved a challenge to the imposition of fees to enable a claim to be lodged with the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-611G-00000-00&context=1519360)_
court which were said to breach the constitutional right of access. At page 788, Laws J observed:
“Mr Richards [Counsel for the Lord Chancellor] submitted that it was for the Lord Chancellor's discretion to
decide what litigation should be supported by taxpayer's money and what should not. As regards the
expenses of legal representation, I am sure that is right. Payment out of legal aid of lawyers' fees to
conduct litigation is a subsidy by the State which in general is well within the power of the executive,
subject to the relevant main legislation, to regulate. But the impost of court fees is, to my mind, subject to
wholly different considerations. They are the cost of going to court at all, lawyers or no lawyers.”

126. Those observations concerned whether legal aid should be available for particular types of litigation. For
example, defamation was excluded. Laws J was not considering a case where Parliament had indicated that
particular litigation could attract legal aid. In that case, the question whether without legal aid a claim could be dealt
with fairly and effectively was of fundamental importance. Thus I do not think his observations assist Mr
Chamberlain.

127. I am conscious that I have not referred in detail to all arguments nor to but a few of the very many authorities
put before me. The authorities ran to over 5000 pages. The individual claims were also very substantial. But I hope I
have dealt with the main points which I needed to decide.

128. In the circumstances, the decision of the Director in each of the claims is quashed. I have indicated in
individual claims whether I was of the view that legal aid should have been granted, but I will leave open to Mr
Chamberlain to submit that in any in which I have indicated that view I should not so order. The Lord Chancellor's
Guidance is in the respects I have indicated in my judgment unlawful. I think that the appropriate relief would be a
declaration that in those respects it is unlawful, but I will leave counsel to make

**End of Document**


-----

