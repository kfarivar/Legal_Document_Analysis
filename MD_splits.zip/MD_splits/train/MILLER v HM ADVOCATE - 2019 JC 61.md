# MILLER v HM ADVOCATE 2019 JC 61

[2019] HCJAC 7

High Court of Justiciary

Lord Justice-General (Carloway), Lord Menzies and Lord Drummond Young

23 January 2019

**Justiciary — Crime — Servitude — Complainer forced to carry out work and subjected to assaults, threats**
**of violence and forcible return when he left — Whether held in servitude — Whether misdirection — Human**
**Trafficking and Exploitation (Scotland) Act2015(asp 12), sec 4(1)(a).**

**SECTION 4 of the Human Trafficking and Exploitation (Scotland) Act 2015 (asp 12) (ʻthe 2015 Actʼ) provides, inter**

_alia, “(1) A person commits an offence if– (a) the person holds another person in slavery or servitude and the_
circumstances are such that the person knows or ought to know that the other person is so held, or (b) the person
requires another person to perform forced or compulsory labour and the circumstances are such that the person
knows or ought to know that the other person is being required to perform such labour. (2) In subsection (1) the
references to holding a person in slavery or servitude or requiring a person to perform forced or compulsory labour
are to be construed in accordance with Article 4 of the Human Rights Convention”.

The appellant and his co-accused ran businesses involving tarring, paving and developing sites for caravans. The
complainer undertook work for the appellant and was provided with accommodation by him. The complainer gave

evidence at trial that the appellant regularly assaulted him and that the appellantʼs threats of violence prevented him

from leaving. After the complainer travelled from Scotland to York, he was traced by the appellant and threatened
with violence if he did not return. The complainer was returned to Scotland against his will by the appellant and the
co-accused in a motorcar and, shortly after his return, he contacted the police. The trial judge directed the jury that
there was no evidence that the complainer had been held in a state of slavery but that it was open to them, on the
evidence, to conclude he had been held in servitude, contrary to **SEC 4(1)(A) of the 2015 Act. The appellant was,**
thereafter, convicted of assaulting and abducting the complainer, as well as having held him in servitude, under
deletion of the words “refuse to allow him to leave”.

On appeal, the appellant argued, inter alia, that the judgeʼs removal of slavery from the juryʼs consideration and the

deletion by the jury of the words “refuse to allow him to leave” were inconsistent with a finding of servitude and
more akin to a finding of forced labour, and that the trial judge had misdirected the jury by failing to give adequate
directions on what was required to constitute servitude.

_Held that: (1) where a person was forced to live under anotherʼs control on that personʼs property, held against his_

will and forced to carry out work for little or no money, he was kept in a state of servitude (paras 19, 20); (2) what
mattered was not that the complainer could not leave but rather that he was compelled to come back, live on the

site and perform the required labour, and the juryʼs deletion of the words “refuse to allow him to leave” was not fatal

where the person considered that he had no option but to stay or that, if he left, as had occurred, he would be found
and brought back (para 23); and appeal against conviction refused and appeal against sentence allowed.

Siliadin v France (2006) 43 EHRR 16 considered.


-----

**[*62]**

Cases referred to:

Attorney-Generalʼs Reference (Nos 2, 3, 4 and 5 of 2013) sub nom Connors and ors v R [2013] EWCA Crim 324 ;

[2013] 2 Cr App R (S) 71 ; [2013] Crim LR 611

CN and V v France (67724/09) [2012] ECHR 374

Prosecutor v Kunarac and ors (IT-96-23 and IT-96-23/1-A) ICTY (AC), 12 June 2002, unreported

[R v SK [2011] EWCA Crim 1691 ; [2013] QB 82; [2012] 3 WLR 933; [2012] 1 All ER 1090; [2011] 2 Cr App R 34;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:551R-1TF1-DYBP-M31M-00000-00&context=1519360)

[2012] Crim LR 63

R v Zielinski [2017] EWCA Crim 758

Rantsev v Cyprus and Russia (25965/04) [2010] ECHR 22 ; (2010) 51 EHRR 1 ; 28 BHRC 313

Reid v Scot of Harden (1687) Mor 9505

[Siliadin v France (73316/01) [2005] ECHR 545 ; (2006) 43 EHRR 16 ; [2005] 20 BHRC 654](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)

Van Droogenbroeck v Belgium (A/50) (1982) 4 EHRR 443 ; [1982] IHRL 34 and (7906/77) (1980) Series B No 44
(EComHR)

Textbooks etc referred to:

Chambers Twentieth Century Dictionary (Kirkpatrick ed, Chambers, Edinburgh, 1983)

Clayton, R, and Tomlinson, H, The Law of Human Rights (2nd ed, Oxford University Press, Oxford, 2009), paras
9.17–9.20

Gallagher, AT, “The International Legal Definition of Trafficking in Persons: Scope and application” in Revisiting the
Law and Governance of Trafficking, Forced Labor and **_Modern Slavery (Kotiswaran ed, Cambridge University_**
Press, Cambridge, 2017), pp 88–92

Justinian, Digest, Bk 48.15.6.2

League of Nations, Convention to Suppress the Slave Trade and Slavery (no 1414) (ʻthe Slavery Conventionʼ)

(1927)60League of Nations Treaty Series254

Shorter Oxford English Dictionary (6th Stevenson ed, Oxford University Press, Oxford, 2007)

United Nations, Convention against Transnational Organized Crime and the Protocols Thereto (ʻthe Palermo

Convention/Protocolʼ) (V.05-90366) (UN, New York, December 2000) (Online:

https://www.unodc.org/documents/treaties/UNTOC/Publications/TOC%20Convention/TOCebook-e.pdf (25 March
2019))

United Nations Office on Drugs and Crime, Issue Paper: Abuse of a position of vulnerability and other “means”
within the definition of trafficking in persons (V.13-82591) (UNODC, Vienna, April 2013), para 2.1 (Online:
https://www.unodc.org/documents/human-trafficking/2012/UNODC_2012_Issue_Paper__Abuse_of_a_Position_of_Vulnerability.pdf (25 March 2019))

The cause called before the High Court of Justiciary, comprising the Lord Justice-General (Carloway), Lord
Menzies and Lord Drummond Young, for a hearing, on 23 January 2019.


-----

_Eo die, the court refused the appeal for the reasons set forth in the opinion of the Court which was subsequently_
delivered by the Lord Justice-General (Carloway)—

**Opinion of the Court—**
**Introduction**

[1] On 9 February 2018, at the High Court in Glasgow, the appellant was convicted, along with Robert McPhee, of
two charges, as follows:
**[*63]**

ʻ(28) on 29 and 30 December 2016 at an address in York … and Curryside Piggery, Deas Road, Shotts you …

did abduct [KDW] … and did force him into a motor vehicle … detain him against his will, and did assault …

[KDW], convey him to … Curryside Piggery, all to his injury; and

(29) between 1 November … and 30 December 2016 … at Curryside Piggery … you … did hold another
person, namely [KDW] … in servitude in that you did force him to live under your control at … Curryside
Piggery and hold him against his will, force him to carry out work for little or no pay, and the circumstances
were such that you knew or ought to have known that … [KDW] was so held:

CONTRARY to the Human Trafficking and Exploitation (Scotland) Act 2015 [(asp 12)], section 4(1)(a).ʼ

In returning their verdict on charge (28) the jury deleted the words ʻand lock him in a trailerʼ. On charge (29), the jury

deleted the words ʻrefuse to allow him to leaveʼ. The trial judge had already removed a libel of ʻslaveryʼ and the

words ʻkeep him in squalid conditionsʼ from the juryʼs consideration. On 15 March 2018, the judge imposed an

extended sentence of nine yearsʼ imprisonment (six years custodial) in respect of charge (28) and seven years

concurrent on charge (29).
**Evidence**

[2] The appellant is the son-in-law of his co-accused, Mr McPhee. They ran businesses involving tarring and paving

and, in the appellantʼs case, developing a site for caravans. All were members of the travelling community, who

lived sometimes in caravans and sometimes in houses. The complainer, namely KDW, was a young and vulnerable
man. He was aged 20 years. He had only recently been released from detention and was on licence. Early in crossexamination about his criminal record, the complainer said that he suffered from mental instability and had
previously been compulsorily detained because of this. On being asked about the nature of his instability, he had
said that he had a split personality disorder, depression, anxiety, post-traumatic stress disorder, attention deficit
hyperactivity disorder and drug-induced psychosis. The complainer was not a member of the travelling community,
but had worked with another travelling person in England. When work became scarce with that person, it was
arranged that the complainer should go and work for a relative of the person, namely Mr McPhee.

[3] According to the complainer, everything went well for a short time. Matters took a turn for the worse. He would
be slapped about or locked in a shed if his work was not satisfactory. The complainer said that he wanted to leave,
but could not do so. He was threatened by the appellant that he would be skinned alive if he left. He regarded the
appellant as the person who controlled where he lived and worked and what he was paid. The complainer said that
he was paid erratically; £20 per day for four days, although he worked every day. What he would get paid was
never certain. Sometimes he was not paid at all. He was provided with accommodation in a caravan owned by the
appellant.

[4] At Christmas 2016, the complainer was staying in York with a girlfriend and her family. He had gone to York in
order to get away from the appellant and Mr McPhee. He had left the caravan by climbing out of the window and
persuading his father to pay his train fare to York. The appellant had found out where he was and had threatened
him with violence if he did not return to Scotland. The appellant and Mr McPhee went to York, located the


-----

complainer, forced him into a car, and took him back to Scotland against his will. There were recordings of
telephone calls between the complainer and the appellant when the appellant was
**[*64]**

looking for the complainer in York. The trial judge described these as ʻchillingʼ. The appellant said, for example,

ʻYou had better come out … I will skin you aliveʼ and ʻIʼm coming to get you, just tell me where you areʼ. Mr McPhee

was present in the car when these conversations were going on and could be heard in the background.

[5] Soon after he had been taken back to Scotland, the complainer contacted the police and told them of his
whereabouts. He was able to do this as he had a mobile phone. He arranged to hand himself in for a breach of bail
charge in England. He had climbed out of the caravan window again to go into town and meet the police.

[6] The appellant gave evidence essentially to the effect that nothing had been against the complainerʼs will. He had

been allowed to leave the caravan and go to the local pub and shops. There was independent testimony to support
this. The complainer could come and go as he pleased. Had he had any difficulties about anything, he could have
spoken to people in the community or to the authorities without any difficulty. The complainer had gone to York at
Christmas for a few days. He had asked the appellant to collect him, which he had done. At some point the
complainer said that he wanted more time in York and had refused to tell the appellant where he was. The appellant

had lost his temper because he thought that the complainer was ʻmucking him aboutʼ. He denied threatening him or

forcing him to return to Scotland against his will.

**Judgeʼs charge**

[7] The trial judge defined assault and abduction for the jury. Her directions in that respect were not under
challenge. What was under challenge were the directions in respect of charge (29); holding a person in a state of

servitude, contrary to SEC 4(1)(A) of the Human Trafficking and Exploitation (Scotland) Act 2015 (ʻthe 2015 Actʼ). In

this regard the judge had also to define slavery or servitude, contrary to sec 47(1)(a) of the Criminal Justice and
Licensing (Scotland) Act 2010 (asp 13) which had been the subject of an earlier charge (22), pre-dating the 2015
**ACT, and involving Mr McPhee and another complainer.**

[8] The trial judge said this:

ʻWhat does “slavery or servitude” mean? In both Acts of Parliament, Parliament has laid down that they are to

be construed in accordance with the European Convention on Human Rights. The words “slavery or servitude”
are not given any special definition for the purposes of these Acts, so they are ordinary words in the English
language, but in my telling you what they mean I am told that I have got to have regard to the European
Convention on Human Rights and the law that has been developed under that Convention. …

[T]he Convention says that no one is to be held in slavery or servitude, and it does, in the cases that have been
decided under the Convention, give the definition of slavery and it is “the status or condition of a person over
whom any or all of the powers attaching to the rights of ownership are exercised”. So the definition of slavery
involves … rights of ownership.

The definition of servitude is where there is an obligation to provide oneʼs services imposed by the use of

coercion, including an obligation to live on another personʼs property and the impossibility of altering that

condition. And the law says that this definition includes the idea that the person who is held in servitude …

feels that his situation is permanent and he canʼt change it. It is enough that those feelings are engendered and

kept alive by the person who is responsible for the situation.ʼ

[9] The trial judge directed the jury that there was no evidence upon which they could hold that the complainer had
been held in a state of slavery. She continued:
**[*65]**


-----

ʻThe situation is different for servitude. I do not say for a moment that the evidence proves people were held in

servitude because … itʼs for you to decide what is proved, but I do say that you could decide … on the

evidence, depending on the view that you take of the facts, that people were held in servitude in terms of these
charges. …

Obviously there are plenty of people who work, for example, in hotels, and … live in for their jobs, and of

course theyʼre not held in servitude. They go to their work, they stay there overnight and they get paid. That

does not mean that they are held in servitude. And the reason for that is that the definition includes an element

of coercion, which means people being forced to work by some means. Now itʼs a very wide definition, and so

the forcing could be physical force, or the threat of it, or it could be more subtle than that. It could be not getting

paid the right amount that you think youʼre due. It could be not getting fed if they donʼt work. …

[T]he definition also imports into it a feeling of the person concerned not being able to alter the situation.ʼ

[10] The trial judge gave an example of a young girl being brought to the United Kingdom and forced to work in a
house. This was derived from SILIADIN V FRANCE. She then continued:

ʻAs regards … charge 29 … itʼs got the two extra bits where you have to consider any personal attributes of the

person that make him more vulnerable than other people, personal circumstances of the person and examples

are given in the act of being a child, or the personʼs age, or the personʼs family relationships or health. They are

examples. They are not exclusive, there could be other things, but these are examples to give you the flavour

of the sorts of things youʼve got to consider … so thatʼs the first thing, the personal circumstances. And the

second one is the consent of a person to any of the acts does not preclude a determination that he … is held in
servitude.

Now what does that mean? Well, it could mean that if the set up is such that a person feels that he is coerced
to work, that he has to stay in the property where he is sleeping, if he feels, with some basis, not in imagination,

but with some basis that he canʼt get out, then it may not be necessary for him to be threatened and reminded

of that every morning first thing, because it may be that thatʼs the set up and some threat of violence now and

again would suffice. …

[S]o … a matter of fact and degree in light of all the evidence … the fact that somebody actually does get away

doesnʼt mean that theyʼve never been held in servitude …

So itʼs all a matter of fact and a matter of degree for you to decide. Now, of course, you know what counsel

says … that this is ridiculous, because the evidence showed that people were free to come and go …

So various counsel have said how can you be in servitude if youʼre out and about? Youʼre either canvassing at

peopleʼs houses or youʼre laying tarmac or monoblocs and you can just walk away. …

But, in this case, what is being suggested here is that these people in these two charges, 22 and 29, were held

in servitude because they felt threatened if they didnʼt, and youʼve got to consider all of the evidence in the

case, as Iʼve told you several times, and so the suggestion is that their evidence is to the effect that they

thought that they had to work, they got paid some times and not other times, they werenʼt very sure how much

they were supposed to be paid. They could walk away but they thought there were consequences if they did.
They thought that they would be found and brought back, and they thought that there would be violence visited
on them if they did that. …


-----

[I]tʼs a matter for you to decide whether or not you feel that that amounts to being held in servitude in the way in

which I have defined it for you. As I said to you, itʼs not straightforward. Now, it requires quite a bit of thought

and, as regards the second one, thatʼs charge 29, because thatʼs a later Act, 2015, itʼs got the two extra bits

where you have to consider any personal attributes of the person that make him more vulnerable than other
people, personal

**[*66]**

circumstances of the person and examples are given in the Act of being a child, or the personʼs age, or the

personʼs family relationships or health. They are examples. Theyʼre not exclusive, there could be other thingsʼ.

**SubmissionsAppellant**

[11] The grounds in the note of appeal against conviction were that the trial judge misdirected the jury: (1) by failing
to give adequate directions on what was required to constitute servitude; and (2) by advising that a vulnerability of
the complainer, namely his mental health difficulties, was a relevant factor without directing the jury that they would
have to be satisfied that the appellant had been aware of the vulnerability at the time. On the first element, the

contention, as developed in oral submission, shifted from there being a misdirection to a suggestion that the judgeʼs

removal of ʻslaveryʼ and the juryʼs deletion of ʻrefuse to allow him to leaveʼ were inconsistent with a finding of

servitude, but more akin to forced labour.

[12] The offences of keeping a person in a state of slavery or servitude or of compulsory or forced labour were
subtly different. Forcing a person into a state of slavery was an offence under the Roman Lex Fabia (DIGEST, Book

48.15.6.2 (Callistratus)) and in early Scots law (REID V SCOTT OF HARDEN (the ʻtumbling lassieʼ)). Indicia of slavery

included:

ʻ[C]ontrol of someoneʼs movement, control of physical environment, psychological control, measures taken to

prevent or deter escape, force, threat of force or coercion, duration, assertion of exclusivity, subjection to cruel

treatment and abuse, control of sexuality and forced labourʼ (PROSECUTOR V KUNARAC AND ORS, para 119).

[13] Servitude had to be construed in accordance with Art 4 of the European Convention on Human Rights. In terms

of SILIADIN V FRANCE (paras 123, 124), what was prohibited was a ʻparticularly serious form of denial of freedomʼ. It

included, in addition to the obligation to perform services, the obligation for the serf to live on another personʼs

property and the impossibility of altering his condition (VAN DROOGENBROECK V BELGIUM (1980), paras 78–80 and
Commission decision, 5 July 1979, DR 17, para 59). Servitude meant an obligation to provide services imposed by
the use of coercion and was linked with the concept of slavery (see also CN AND V V FRANCE, para 91; ATTORNEY
**_GENERALʼS REFERENCE (NOS 2,_** **_3,_** **_4 AND 5 OF 2003)). Servitude embraced the totality of the status or condition of a_**

person. It was distinguishable from slavery in that it did not involve ownership but less extensive forms of restraint.
It meant an obligation to provide services imposed by the use of coercion (see R V SK, para 7).

[14] Accordingly, servitude was defined as requiring that a person was coerced into living on another personʼs

property in order to perform services for him or others in circumstances in which he was made to feel that it was
impossible for him to alter his status. Put another way, servitude was an obligation to provide services imposed by
the use of coercion and was linked with the concept of slavery. It was less restrictive than slavery, but more
restrictive than forced or compulsory labour. It differed from slavery in that slavery represented ownership.
Servitude was a less extensive form of restraint but, in addition to the performance of services, it
**[*67]**

required the person to live on anotherʼs property in circumstances in which it was impossible for the person to alter

his condition.


-----

[15] Although the trial judgeʼs definition of servitude was consonant with its definition under Art 4 of the European

Convention, she had not explained the distinction between servitude and forced or compulsory labour. That was a
significant omission because the jury ought to have been directed that this was not a case where the allegation was
merely that there was forced or compulsory labour. There had to be an element of control. There was evidence,
which the judge did not mention during the crucial part of her directions, that the complainer was a regular in a local
pub and free to move around as he pleased. The jury had deleted part of the indictment involving the appellant
refusing to allow the complainer to leave. The jury received no directions as to how to proceed if they found that the
complainer was free to come and go as he pleased (RANTSEV V CYPRUS AND RUSSIA, para 276).

[16] The judge also misdirected the jury regarding the significance of the appellantʼs personal circumstances; that is

to say his vulnerability. The evidence regarding his mental health vulnerability had come spontaneously from the
complainer when he was in the witness box. The trial judge ought to have directed the jury that they could only take
into account personal circumstances where there was evidence that the appellant knew or ought to have known

about them. The international treaties suggested that knowledge of a personʼs vulnerability went to criminal intent. A

person with the relevant knowledge could use it to manipulate or control the vulnerable person (Palermo Protocol to

the UN **CONVENTION AGAINST TRANSNATIONAL ORGANIZED CRIME (2000), Art 3; GALLAGHER, ʻThe International Legal**

Definition of Trafficking in Personsʼ in Kotiswaran, Revisiting the Law and Governance of Trafficking, Forced Labor

_and_ **_Modern Slavery, pp 88–92). If that factor was relevant, knowledge had to be proved. The Crown had not_**
founded upon any vulnerability, but it had arisen in the evidence and the trial judge ought to have dealt with it.

There had been no evidence that the appellant had been aware of the complainerʼs mental health problems.

_The Crown_

[17] The Advocate-depute maintained that the trial judge had correctly directed the jury on servitude having regard
to SILIADIN V FRANCE and CN AND V V FRANCE. There was a hierarchy of severity in relation to compulsory labour,

servitude and slavery (ATTORNEY-GENERALʼS REFERENCE (NOS 2, **_3,_** **_4 AND 5 OF 2003), para 7, citing CLAYTON AND_**

**TOMLINSON, The Law of Human Rights, paras 9.17–9.20). Slavery involved being in the legal ownership of another.**

Servitude embraced the totality of the personʼs condition or status, but it did not involve ownership. It meant an

obligation to provide services by the use of coercion. It was different from compulsory labour as it also included the

obligation to live on the otherʼs property and the impossibility of changing the situation. The focus of the appeal had

been on the deletion of that part of the libel relating to refusing to allow the complainer to leave. This was not
destructive of the charge.

[18] The trial judge had not been asked to direct the jury that the personal circumstances of the complainer were
relevant only if the appellant knew of them. The section only provided that in assessing whether a person had been
a victim, the court had to have regard to his vulnerabilities (see also UNITED NATIONS OFFICE ON DRUGS AND CRIME,
_Issue Paper: Abuse of a position of vulnerability, para 2.1)._
**[*68]**

**SECTION 4(3) of the 2015 Act set out an objective test about the personal circumstances of the complainer. Whether**
the appellant had been aware of them was irrelevant. Vulnerability had not been founded upon by the Crown and

there had been no suggestion that the appellant had been aware of the complainerʼs mental health problems.

**Decision**

[19] The essence of the offence in **SEC** **4(1)(A) of the 2015 Act and its predecessor, sec 47(1)(a) of the Criminal**

Justice and Licensing (Scotland) Act 2010, is that the accused ʻholds another person in slavery or servitudeʼ. The

two terms are thereby distinguished despite, as the trial judge astutely recognised, the fact that both **_CHAMBERS_**

**_DICTIONARY and the_** **_SHORTER_** **_OXFORD_** **_ENGLISH_** **_DICTIONARY define_** ʻservitudeʼ as the state or condition of being a

slave. The section also distinguishes between servitude and being required to perform forced or compulsory labour.
All of these terms are to be found in Art 4 of the European Convention. SECTION 4(2) of the 2015 Act directs that


-----

they are to be construed ʻin accordance withʼ the Article. Regard is to be had to ʻany personal circumstances … that

may make the person more vulnerable than other persons.ʼ (Art 4(3).) The statute thus introduces certain somewhat

complicating features into what might otherwise be a straightforward question in a case such as the present.

[20] The broad question for the jury was whether the appellant deliberately kept the complainer ʻin servitudeʼ. The

circumstances giving rise to that state were libelled as being that the appellant: (1) forced the complainer to live
under his control at the piggery; (2) held him against his will; and (3) forced him to carry out work for little or no pay.
Although it is compulsory, in terms of SEC 4(2) AND (3), to construe the reference to servitude in accordance with Art
4 of the European Convention and to have regard to any vulnerabilities of the complainer, it is difficult to conceive of
a person not being in a state of servitude if, as the jury found in fact, the three elements of the libel were

established. If a person is forced to live under anotherʼs control on that personʼs property, held against his will and

forced to carry out work for little or no money, he is being kept in a state of servitude. A simple direction to that
effect may have sufficed.

[21] The trial judge nevertheless took time to explain the wider meaning of servitude, first by distinguishing it from
slavery; consideration of which she withdrew from the jury. As the judge correctly reasoned, slavery carries with it
connotations of ownership, which might not be present in servitude. This is suggested by the classic definition of
slavery in the **SLAVERY** **CONVENTION (1926) (see** **_SILIADIN V_** **_FRANCE, para 122). Servitude, according to_** **_SILIADIN_**

(para 123), involves ʻa particularly serious form of denial of freedomʼ (VAN DROOGENBROECK V BELGIUM (1982), para

58), including:

ʻ[I]n addition to the obligation to provide certain services to another … the obligation for the “serf” to live on

another personʼs property and the impossibility of altering his conditionʼ. (VAN **_DROOGENBROECK V_** **_BELGIUM_**

(1980), para 79.)

Servitude means (SILIADIN, para 124):

ʻ[A]n obligation to provide oneʼs services that is imposed by the use of coercion, and is to be linked to the

concept of “slavery” ʼ.

**[*69]**

Servitude involves ʻaggravatedʼ forced or compulsory labour in which the person feels that his ʻcondition is

permanent and … unlikely to changeʼ (CN AND V V FRANCE, para 91). It is sufficient if the personʼs understanding is

brought about or kept alive by those responsible for the situation (ibid).

[22] It was not disputed that there was sufficient evidence that the appellant had kept the complainer in a state of
servitude. That would seem clear from the periodic confinement of the complainer and a requirement upon him to
work for little reward; all fenced by threats of violence. The trial judge had, as her report reveals, carefully
considered the Convention jurisprudence. She directed the jury accordingly, using the guidance and the specific
words provided by **_SILIADIN V_** **_FRANCE,_** **_VAN_** **_DROOGENBROECK V_** **_BELGIUM and_** **_CN AND_** **_V V_** **_FRANCE. There was no_**
need for the judge to explain the distinction between servitude and forced labour. That may have served only to
confuse. The appellant was not charged with forcing labour on his own.

[23] The evidence that the complainer was a regular in the local pub and shops was before the jury. The judge did
not require to remind the jury of this, as no doubt that had just been done in the defence speech. The jury would
have understood this, hence their deletion of the reference to refusing to allow the complainer to leave. The point
was not that he could not leave, it was that he was compelled to come back, live on-site and perform the required
labour. That was presumably the economic motivation behind keeping him in serfdom. His ability to wander about

the local village and countryside did not change his servitude status. The juryʼs deletion of the words ʻrefuse to allow

him to leaveʼ was not fatal in a situation where the person considered that he had no option but to stay or that, if he


-----

left, he would, as occurred in this case, be found and brought back. The first ground of appeal accordingly falls to
be rejected.

[24] **SECTION** **4 of the 2015 Act somewhat unnecessarily expressly requires the accused to be aware that the**
complainer is being held in a state of servitude, but that is all. The provision relative to taking into account any
vulnerabilities of the complainer might be seen as obvious. Equally, whether the appellant was aware of them may
have been a consideration which the jury might have had regard to, if the appellant had professed ignorance of
them. However, in circumstances in which the Crown were not founding upon an abuse of a vulnerable person (a
fact which would have to have been libelled) there was no need for a specific direction on the point. Whether, at the
time, the complainer had mental health difficulties was not a material part of the case, although it might be ventured
that without the existence of some vulnerabilities it is difficult to conceive of a situation where keeping a person in
servitude could persist for long. The second ground of appeal also falls to be rejected.

[25] The appeal against conviction is according refused.
**Sentence**

[26] Leave to appeal was granted only in respect of the seven years imposed on charge (29). The basis for the
appeal is that the period is excessive having regard to the duration of the libel (two months). The trial judge noted

the appellantʼs record of previous convictions, which extended from 2004 to 2017 and included an offence in

England in 2004 of threatening behaviour and a conviction at Falkirk Sheriff Court in 2005 for assault and
abduction, albeit in a domestic context. The criminal justice social work report described the appellant as a married
man with five
**[*70]**

children. He had been involved in developing a caravan site, where he lived with his family, for holiday use. The
judge considered that the charges, of which the appellant had been convicted, showed that his attitude was that he
was entitled to tell the complainer what to do and where to live. He backed up his instructions with violence. The
judge regarded keeping a man in servitude for a period of two months as a serious matter. In selecting the sentence

of seven years, it would appear that the trial judge took into account the complainerʼs mental instability as a

vulnerability.

[27] The court is conscious of the words of Lord Judge CJ in ATTORNEY-GENERALʼS REFERENCE (NOS 2, **_3,_** **_4 AND 5_**

**_OF 2003) (para 10) (cited by Davis LJ in R V ZIELINSKI, para 18) that:_**

ʻSentences in this class of case must make clear, not merely that the statutory minimum wage should not be

undermined, but much more important, that every vulnerable victim of exploitation will be protected by the
criminal law, and they must also emphasise that there is no victim, so vulnerable to exploitation, that he or she
somehow becomes invisible or unknown to or somehow beyond the protection of the law. Exploitation of fellow
human beings in any of the way criminalised by the legislation represents deliberate degrading of a fellow
human being or human beings. It is far from straight forward for them even to complain about the way they are
being treated, let alone to report their plight to the authorities so that the offenders might be brought to justice.
Therefore when they are, substantial sentences are required, reflective, of course, of the distinctions between

enslavement, serfdom, and forced labour, but realistically addressing the criminality of the defendants.ʼ

A significant sentence of imprisonment was inevitable, although that selected on this charge was at the high end of

the spectrum, given the limited timescale and the complainerʼs relative freedom of movement. In all the

circumstances, and in the absence of evidence that the appellant was aware of the complainerʼs mental problems,

the court will reduce the seven years selected and substitute six years, to run concurrently with the same custodial
term on charge (28).

The Court refused the appeal against conviction and quashed the sentence of seven yearsʼ imprisonment quoad

the statutory charge and substituted therefor a custodial sentence of six yearsʼ imprisonment


-----

**End of Document**


-----

