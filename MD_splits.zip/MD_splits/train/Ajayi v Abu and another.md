# Ajayi v Abu and another [2017] EWHC 3098 (QB)

Queen's Bench Division

Judge Alison Hampton (sitting as a Judge of the High Court)

1 December 2017Judgment

**Anna Beale (instructed by ATLEU ) for the Claimant**

**Oliver Hyams (instructed by Bloomfield Solicitors) for the Defendants**

Hearing dates: 21 – 24, 27th November & 1st December 2017

- - - - - - - - - - - - - - - - - - - - 
**Judgment**

**Her Honour Judge Alison Hampton :**

**Introduction**

1. The Claimant is a native of Nigeria who came to the UK to work with the Defendants' family in 2005.
The circumstances in which she came to the UK and her treatment whilst she worked for and was
accommodated by the Defendants is the subject matter of these proceedings.

2. The Claimant claims she is the victim of human trafficking. This is denied by the Defendants. In
[addition, the Claimant has made a claim under the National Minimum Wage Act 1998 (the 1998 Act), as](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)
she claims that she was paid less than the statutory rate set under the 1998 Act throughout her
employment. Alternatively, she claims damages for breach of contract on the grounds that she has
consistently received less remuneration than documents setting out her Terms and Conditions of her
employment provided for.

3. The Claimant seeks compensation as the victim of trafficking. The United Kingdom has ratified the
Council of Europe Convention on Action Against Trafficking in Human Beings, (The Trafficking
Convention). Article 15 of the Trafficking Convention provides that the internal law of the ratifying nations
should provide a right of victims to compensation from the perpetrators. The Supreme Court held in
_Hounga v Allen [2014] 1 WLR 2889that this obligation not only required the United Kingdom to ensure that_
victims of trafficking have a right to compensation for the trafficking itself, but also a right to compensation
for related acts of discrimination. The court also held that there is also a strong presumption in favour of
interpreting English law in a way which does not place the United Kingdom in breach of an international
obligation. In _Rantsev v Cyprus and Russia [2010] 51 EHRR 1, the European Court of Human Rights_
recognised that Article 4 of the ECHR prohibits human trafficking and Article 13 requires convention states
to provide a domestic remedy for violations of the ECHR rights. Section 3 of the Human Rights Act 1998
requires domestic courts to give effect to primary and subordinate legislation in a way which is compatible
with Convention rights. Accordingly, if the court finds that the Claimant is the victim of trafficking, she is
entitled to compensation.

4. The Claimant also claims that her treatment in the hands of the Defendants amounts to harassment
[within the meaning of the Protection from Harassment Act 1997 (the 1997 Act).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)


-----

5. One of the issues raised by these proceedings has already been determined at a single issue trial by
Master McCloud. She found that the Defendants were not entitled to rely on Regulation 57 (3) of the
National Minimum Wage Regulations 2015, which affords an exemption to payment of the national
minimum wage, for a worker residing in the family home of the worker's employer in certain circumstances.
The Master determined that the Defendants were not entitled to rely upon that exemption. Accordingly the
Defendants have conceded that the Claimant is entitled to some award under the 1998 Act, but the court
must determine the amount.

6. The Defendants have also raised a limitation defence to any sums outstanding, or damages payable for
any part of the Claimant's cause of action which arose before 28 October 2009. (The Claim Form was
issued on 28 October 2015). The Defendants deny that the Claimant has been trafficked within the
meaning of the Trafficking Convention or that she has been harassed within the meaning of the 1997 Act.
They assert that the Claimant was treated as a niece, throughout the nine and a half years of her
employment by them, and that she has brought this claim in an effort to reinforce her desire to obtain
permission to remain in the United Kingdom.

**History**

7. The Claimant and the second Defendant are distantly related. The Claimant first started to work for Mrs
Abu's sister, Mrs Eluwole, in Nigeria in 1998, when she was probably in her mid teens. There is some
uncertainty about the Claimant's age. A declaration made by the Claimant for the purposes of her first entry
to the United Kingdom gave a date of birth in February 1974. The Claimant has subsequently obtained a
naming certificate, which gives a date of birth in May 1982. In the circumstances of the case, I find that the
latter date is probably more accurate.

8. The Claimant was one of two domestic workers employed by Mrs Eluwole who at that time worked in a
bank. She told the court that her husband was a stock broker. The arrangement was made by Mrs
Eluwole's mother and the Claimant's mother, who are cousins. Mrs Eluwole lived in Lagos Nigeria. The
Claimant came from poor circumstances in a rural village.

9. Whilst in the Eluwole family, the Claimant was required to assist with caring for the children of the
family, housework and helping with animals kept on the compound. Mrs Eluwole also arranged for her to
be apprenticed to a local hairdresser with a view to the Claimant eventually following that profession. It is
clear from her evidence that the Claimant never found this training very satisfactory. The Claimant was not
paid any wage by Mrs Eluwole, but her accommodation, food and any other needs were catered for within
the family home. Mrs Eluwole confirmed that this is not an unusual arrangement in Nigeria.

10. The Defendants visited Nigeria for a family funeral in 2004 when they met the Claimant. There is an
issue between the parties as to whether there was any discussion or agreement between the Defendants
and Mrs Eluwole, that Mrs Eluwole would arrange for the Claimant to travel to the UK to live with the
Defendants' family and work as a domestic worker for them.

11. It is not in issue that in late summer 2005, Mrs Eluwole and her three children travelled to the UK
accompanied by the Claimant, for a family holiday at the Defendants' home. The Claimant's visa obtained
for that visit (p706), describes her as a Domestic Worker (visitor) and has endorsed the words
“accompanying the Eluwole family”. It is the Defendants' case that the Claimant accompanied the family in
order to assist Mrs Eluwole with child care. Mrs Eluwole made arrangements for the Claimant to apply for
a Nigerian passport and a visa to travel to the United Kingdom. The Claimant spoke very little English at
that stage and Mrs Eluwole arranged for an interpreter to assist the Claimant at the British High
Commission, when she applied for her visa.

12. When they arrived in the United Kingdom, it is the Claimant's perception that Mrs Eluwole spoke with
immigration officials on her behalf. This is denied by Mrs Eluwole who says that as she has a British
passport, she went to a different passport channel at the airport and only encountered the Claimant at the
baggage reclaim stage. Whilst the Eluwole family were staying at the Defendants' home, a two bedroom
property in Greenwich, arrangements were made for the Claimant to remain in the United Kingdom with the
Defendants' family as a domestic worker. It is the Defendants' case that this arrangement arose because


-----

Mrs Eluwole learned that she was being made redundant whilst she was on holiday in the United Kingdom.
As the Claimant was enjoying her time with the Defendants' family, it was suggested that she should stay
in the United Kingdom with them, to work as a domestic worker and to assist with childcare. The
Defendants offered to make arrangements for the Claimant to learn English. The Claimant described this
as going to school. The Defendants enrolled her in successive English for Speakers of Other Languages
(ESOL) evening classes for four hours per week at colleges in Greenwich, and after the family moved, in
Bexley. I find that the Claimant's belief that she was to go to any form of full-time education, was an
assumption made by her and not a promise made by the Defendants. A full list of the college courses
attended by the Claimant, which were arranged for her and paid by the Defendants, is set out in paragraph
51 of Mrs Abu's witness statement. The Claimant accepted in her evidence that the list was accurate.
These courses included a Citizenship course in 2012, a Computing course in 2014 and a Caring for
Children Level 1 between September 2014 and January 2015. The Claimant accepts that the Defendants
paid the modest fees for these courses, either directly, or by providing the Claimant with the necessary
funds and purchased books and other learning materials for the Claimant.

13. The Claimant remained in the Defendants' home with their three children, a daughter born in October
2001, a son, who is autistic who was born in February 2004, and another daughter born in November 2007
until March 2015. The Claimant moved with the Defendants' family from Greenwich to Belvedere during
2007, although the children continued to go to school or nursery in Greenwich until the end of 2007.

14. In November 2007 the Defendants' third child was born. Mrs Abu was on maternity leave between
October 2007 and May 2008 and thereafter worked for two days per week from home. Throughout the
period that the Claimant lived with the Defendants' family, Mr Abu worked full time although there were
periods of paternity and sick leave.

15. It is the Claimant's case that throughout her time with the Defendants' family she provided childcare,
taking the children to school with occasional assistance from Mr or Mrs Abu or friends or neighbours whose
children attended the same schools. She also took domestic work, cleaning, laundry and cooking, not only
for the children but the rest of the household. She attended church regularly, generally with the
Defendants' family until 2012 when she started to attend another church in Dartford. Thereafter the whole
family started to worship there. Regular church attendance and a social life centred on church activities
has been a feature of the evidence in this case.

16. The Claimant also accompanied the Defendants' family on family holidays. These were modest affairs
on the south coast where the family stayed in a caravan. I have been provided with a photograph of a
cheerful looking family, including the Claimant by the sea. It is the Claimant's case that during such
holidays, although it was a change from domestic routine at home, she was expected to assist with
childcare and cooking for the family. It was not an independent holiday providing the Claimant with a break
from her usual duties.

17. It is the Defendants' case that the Claimant became moody and difficult whilst Mrs Abu was expecting
her third child. It's the Claimant's case that her experience in working for Mrs Eluwole in Nigeria was that
when Mrs Eluwole was expecting her third child her working days had become longer and more arduous.
She was concerned that the arrival of a third child in the Abu family would have the same effect. It is also
the case, that whatever the Claimant may have been promised, she was clearly expecting a more intensive
educational programme than 4 hours per week on an ESOL course.

18. Throughout the period during which the Claimant lived with the Defendants' family, Mrs Abu completed
the necessary paperwork required by the Home Office to extend the Claimant's stay in the United
Kingdom. In the early years of her residence with the family, the Claimant's command of English was not
sufficient for her to complete, read or understand these documents herself. Many of the relevant
documents dating back to November 2005, have been disclosed by the Home Office. A letter dated 14
November 2005 expressed in the first person by the Claimant, but actually written by Mrs Abu on the
Claimant's behalf is headed “Notification of change of employer” (page 478). Mrs Abu accepted in her
evidence that she produced this document, together with most of the correspondence, and completed the
relevant application forms required in successive years to renew the Claimant's visa to stay in the United


-----

Kingdom. The letter of 14 November 2005, refers to Mr and Mrs Abu as being the Claimant's “new
employers”. It states:

“they have offered me an improved and better contract and conditions of employment”. The letter goes on
“the Abu family requires a domestic worker to mainly meet their childcare and domestic responsibilities
because they are both in full time employment and they have both faced a lot of inconveniences over the
years with regards to finding adequate childcare. I have been able to assist mainly in handling their
domestic responsibilities whilst they are both at work. I have agreed to work for them as a domestic
worker”.

A formal application to extend the Claimant's stay was enclosed with that letter.

19. In addition a letter of the same date, signed by Mrs Abu on behalf of both Defendants to the
Immigration & Nationality Directorate states:

“we write to confirm that we are the employer of (the Claimant). We have employed her as a domestic
worker in our home as stated in the enclosed contract of employment duly signed by us. We confirm that
we wish to continue employing her in accordance with the terms of the signed contract. We also confirm
that we would comply with all relevant laws in the United Kingdom relating to employment and wages” (my
emphasis).

The letter makes a further reference to the terms of the contract. Accompanying these letters was a letter
of the same date addressed to the Claimant signed by Mrs Abu stating that it enclosed 2 copies of “our
standard agreements in addition the Standard Terms and Conditions of employment for the position of a
domestic worker”. A document entitled “Standard Terms and Conditions” was enclosed with the
correspondence. There are a number of similar documents in the Home Office papers. It is likely that the
one included the trial bundle at 707C is the earliest of these. It is signed both by the Claimant and by Mrs
Abu and provides, amongst other things that:

- The domestic worker will be living in our home as a member of our family.

- The domestic worker will have a separate fully furnished bedroom to herself and will share the bathroom
and toilet with the rest of the family (free accommodation).

…

- The domestic worker is expected to be working for 30 hours a week.

- The domestic worker is entitled to 2 days off a week preferably at the weekends, but it may vary from
week to week.

- The domestic worker will be paid £155 weekly for the 30 hours a week work, but additional hours will
attract £7.60 per hour (very occasional).

- The domestic worker is entitled to 5 weeks holiday a year with full pay preferably during the school
holidays.

- Either party are entitled to give one months' notice in writing to terminate the contract/agreement.

20. Mrs Abu said in her oral evidence that the document was downloaded from the internet. Similar letters
and Standard Terms and Conditions were sent to the Directorate over successive years for example: (page
502) December 2006; (page 520) December 2007; (page 538) December 2008. Mr Abu confirmed in his
oral evidence that Mrs Abu dealt with the relevant documentation, that these are her signatures and save
for signing when required, he did not get involved in producing the necessary paperwork. The various
examples of the Terms and Conditions are not dated, but in each case, the weekly pay provided for follows
the rates required by the National Minimum Wage Regulations as it increased from year to year. The first
Application to the Directorate signed by the Claimant on 14 November 2005 refers on page 11 of that
application (page 470) to net pay being £620 per month plus benefits.

21. It is the Claimant's case that never throughout her employment was she paid anything like the
amounts shown in the Terms and Conditions.


-----

22. In her witness statement at paragraph 15 (page 175) Mrs Abu stated that the documents entitled
Terms and Conditions “did not purport to be a contract of employment”. This assertion is surprising and
damaging to Mrs Abu's credibility. It is in direct contradiction to the description that she herself gave to the
Terms and Conditions, in successive applications completed by her, provided to the Claimant for signature
and then sent to the Directorate to extend the Claimant's visa in the United Kingdom. In that the
Defendants have accepted that the wages stated in the documents were never paid in full to the Claimant
(their case is that deductions were made for the cost of food and accommodation), it follows that a
deception was perpetrated by the Defendants, on the Claimant's behalf in these applications to the Home
Office, in successive years throughout the Claimant's employment by the Defendants.

23. It is also the Claimant's case that she was never given two independent days off during the week or
that she ever had five weeks' holiday, independent of the family, as provided for in the Terms and
Conditions. She accepts that she accompanied the Defendants' family on their caravan holidays and days
out, to the south coast. I have no doubt that during that period she would have enjoyed time by the sea and
on the beach with the Defendants and their children. I find that this did not amount to a holiday from her
work, as her duties with regard to childcare and assisting with the family with domestic tasks continued.
The Defendants did not assert and I find that the Claimant never had, or expected to have, five weeks of
free time independent of the family during any of the years that she worked for the Defendants.

24. In 2006 the Defendants assisted the Claimant to open a bank account. I note that a letter from the
Home Office dated 10 January 2007 (page 522) requests evidence of funds, for example bank statement
or wage slips. That provoked the response at page 524, produced on the Claimant's behalf by Mrs Abu,
which refers to difficulties opening a bank account and the fact that the Claimant did not receive a wage
slip. It is common ground that no wage slips were provided and that most payments which were made to
the Claimant were made in cash. The Defendants state, and the Claimant accepts, that the Defendants
also purchased study materials, clothing and other personal items for the Claimant from time to time.

25. The Claimant's evidence, which I accept, was that in her early years with the Defendants' family, she
was not able to read or understand the documents that she was signing. She says in her witness
statement at paragraph 88 (page 155) that she “… did not think about it as Mrs Abu filled in the forms and
I just got the opportunity to sign on the dining room table … I was not given much opportunity to read the
very lengthy form and I did not dare to ask for it. They knew that I did not read or write English properly and
they did not give me a chance to ask questions. I would never have asked questions – I trusted them.”
She goes on to say in the following paragraph, that in about 2012 she started to be able to read and
understand the document she was signing every year and began to realise that what the Defendants were
telling the Home Office was not true. I note from the Defendants' records of the Claimant's college
attendance, the Claimant did not start ESOL Elementary Level 2 until the academic year 2012/2013. I find
that this is a clear indication of the slow progress the Claimant made with her studies of the English
language.

26. Relations within the family became much more difficult after the Defendants made an application on
the Claimant's behalf in 2014 for indefinite Leave to Remain which was refused. On 13th March 2014 the
Claimant was requested by the Home Office to provide wage slips and bank accounts (page 662).
Enclosed with the documents disclosed by the Home Office is a document (Page 664) giving a breakdown
of earnings during the period January – April 2014. It is the Claimant's case that this document was
prepared by Mrs Abu, and I find that it was. It is also the Claimant's case that these figures do not
accurately state the sums of money which she was actually paid. The Claimant's application for indefinite
leave to remain was refused in a letter dated 24th April 2014 (page 680). That letter states that “you have
failed to submit any documentary evidence that you are paid £7.60 per hour as your contract states or that
you can maintain and accommodate yourself adequately without recourse to public funds”. That letter was
accompanied by a notice of a decision to remove the Claimant from the United Kingdom (page 684).

27. The Right of Appeal was exercised on the Claimant's behalf by the Defendants who enlisted the help
of a lawyer to assist. The Claimant describes the visit to the lawyer in her witness statement. She says that
the lawyer spoke Yoruba and it was at that point that the Claimant was shocked to learn that the
Defendants were representing that she was paid £800 per month £500 attributable to accommodation and


-----

food and £300 in cash. She says she was made to sign a document that confirmed that these were the
amounts that were being paid. I accept the Claimant's evidence that she was afraid of what would happen
if she did not sign it and that she felt under pressure. It was quite clear from the Claimant's oral evidence
that she was very uncomfortable with this process. As she stated in her witness statement and repeated in
court, as a Christian she knows it is wrong to lie.

28. She arranged a return visit to the lawyer on her own and said that the lawyer accused her of trying to
blackmail Mr and Mrs Abu. I find that the impression that she was given was, that if she did not tell the lies
and sign the documents as required, she was likely to be deported. I find that this was both a shock and
very considerable disappointment to the Claimant and led to a complete breakdown in trust between
herself and the Defendants. She had come to understand that she was working much longer hours than
the contracts that were being sent on her behalf stated. She believed she had been promised a British
passport (although I find this was a misunderstanding on her behalf, and that what was actually on offer
was indefinite leave to remain) and accordingly she was very unhappy and became less cooperative in the
family home.

29. An example of this is her conduct during periods of prayer within the family home. It was common
ground that the family would pray together in a circle facing inwards. At this time, the Claimant started to
face away from the family during prayers. Mrs Eluwole, who visited the family in October 2014,
reprimanded the Claimant for this practice asking her why “she was backing us”. The Claimant was clearly
resentful of the deceptions she considered had been perpetrated against her by the Defendants and very
worried about her immigration position.

30. The family, nevertheless, continued to attend church either together, although the Claimant also
attended separately. By this time, she had been undertaking voluntary cleaning work as a Sanctuary
Keeper at the church she attended. There was a church conference held during August 2014 which
continued for four days. The Claimant attended the conference and provided cleaning services. This kept
her out of the house for some time. During this period there was an altercation between the parties about
preparation of food during the period of the conference on the first day. On the second day, the
Defendants' family left the venue whilst the Claimant remained there and the Claimant had to find her own
way home, when she had expected to return home with the Defendants. I have heard differing accounts of
what happened during the conference and why, each commenting on the others behaviour in pejorative
terms. Indeed, a considerable period of time in the course of the evidence was spent on these incidents. It
is not necessary for me to make positive findings as to what actually happened. There was clearly a
misunderstanding, which I find was brought out by a failure to communicate within the family, exacerbated
by the increasingly hostile atmosphere.

31. The Defendants' evidence was that they were content for the Claimant to attend this conference and
carry out her duties as a sanctuary keeper and they did not attempt to prevent her going. This is
inconsistent with the impression given in the letter which terminated the Claimant's employment with the
Defendants dated 5th March 2015 (page 256) signed by both Defendants in which the following was stated
“on 10th August 2014, we spoke to you about the fact you left your duties between 6th and 9th August. The
conversation developed into a loud and bitter argument” (the dates being those of the church conference).
Each of the Defendants tried to explain the apparent contradiction between their evidence to the court and
the contents of this letter. I found their attempt to explain this inconsistency in the context of the case in
general unimpressive and damaging to their credibility and reliability as witnesses.

32. These incidents made a difficult situation worse. In the meantime the Claimant had applied for other
work. In April 2014, she registered with a website Findababysitter.com. At that point she discovered that
the terms of her visa were such that she believed she could not work for anyone else and could only work
as a domestic worker resident with her employer. The Claimant accepts that the Defendants also found
another position for her as a domestic worker in the potential employer's home. Although initially accepting
this position, she then refused to take it up. Her evidence was that the other lady was not very nice and she
was not happy with the conditions that she thought were on offer. She said, and I accept, that she no
longer trusted the Defendants who had told her to lie about what she was paid to the Home Office. She
was shocked by the situation in which she found herself and was scared


-----

33. In October 2014, Mrs Eluwole paid another visit to the Defendants. At some time in the course of that
visit there was contact between Mrs Eluwole's mother and the Claimant's mother in Nigeria which resulted
in some unpleasantness between those two ladies. It is clear from the evidence given by Mrs Eluwole that
the Claimant's mother was concerned that the Defendants were trying to make the Claimant leave their
home. There had also been intervention by another family member in Nigeria.

34. In due course there was a heated argument in mid-February 2015 in which Mrs Eluwole was involved.
The Claimant alleges she was assaulted by Mrs Eluwole, which is denied. Mr Akinwale, another relative,
first cousin of Mrs Abu and Mrs Eluwole, and a paternal cousin to the Claimant, who lived nearby was
asked to intervene. He gave evidence and told me that as a precaution he thought to get the police
involved, although the appointment with the police which was made was, in due course, cancelled. At
about this time the Defendants took the Claimant's house keys from her and removed a key to a shared
cupboard where food was stored which had always been available to her. The Defendants also complained
of the Claimant's refusal to take other employment. Mrs Abu agreed that she had made no enquiries as to
whether the refusal was reasonable. She accepted that she did not know the individual who had offered
her the job and had not spoken to that individual about it. She simply said that she had given the Claimant
the telephone number of the potential employer.

35. Mrs Abu maintained in her evidence that she was not aware that the Claimant was upset about being
asked to lie to the Home Office. She said that the Claimant did not tell her of this. She denied that there
was any talk of deportation. As for the removal of the Claimant's house key, she said at this time Mrs
Eluwole was staying with the family and there was always somebody around to let the Claimant in, if she
had been out.

36. Following the incident in mid-February, the Claimant's employment was terminated in the letter from
the Defendants dated 5th March 2015 to which I have already referred. The letter concluded with the
remarks “you are now required to leave our house as soon as possible. We will be forced to evict you and
call the police again if you do not leave our home”. The Claimant remained at the Defendants' home and
continued her activities with the church.

37. On 14th March 2015, she returned to the Defendants' home to find that all her belongings had been
packed up and placed out on the street. She knocked on the door and although she believes that the family
were in, she was not admitted. A neighbour took pity on her and took her into her home. That neighbour
contacted someone from the church who accommodated the Claimant for two to three days. The Claimant
had already been in touch with a charity which helps migrant domestic workers and had spoken to a
solicitor who worked with victims of trafficking. After the Claimant was evicted from the Defendants' home,
she called that solicitor and went to see her. She was then referred to the Salvation Army which runs a
referral line for potential victims of trafficking. They assisted the Claimant to complete the National Referral
Mechanism Form for victims of trafficking (page 356). In June 2015 the Claimant made an application for
asylum. By a letter dated 20th October 2016, the Home Office notified the Claimant that it had “concluded
there are not sufficient grounds, on the balance of probabilities, to believe that you have been a victim of
**_modern slavery (human trafficking) or slavery, servitude or forced/compulsory labour)” (page 410). The_**
Claimant, represented by Migrant Legal Action, challenged this decision and on 6th February 2017 issued
an application for Judicial Review. On 26th October 2017, the Claimant was notified by the Home Office
that “the Competent Authority has reconsidered your conclusive grounds decision (and) concluded that you
are a victim of human trafficking” (page 464).

**The proceedings**

38. In the meantime the Claimant, represented by the Anti-trafficking and Labour Exploitation Unit,
commenced this action on 28 October 2015. The Particulars of Claims seek compensation, in summary,
based on the assertions that the Claimant was trafficked into the UK; is the victim of harassment within the
meaning of the _[Protection from Harassment Act 1997; for breach of contract of the term implied into her](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)_
contract of employment with the Defendants, pursuant to section 17 of the 1998 Act, that she would be
paid at least the National Minimum Wage; that she was not allowed two days per week off or five weeks
holiday a year provided for in her contract and was required to work excessive hours She alleges that she


-----

has suffered psychiatric injury of a mild to moderate degree, namely a mixed anxiety and depressive
disorder.

[39. The Defendants deny all the pleaded grounds of the Claimant's claim and rely on the Limitation Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0N0-TWPY-Y018-00000-00&context=1519360)
_[1980.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0N0-TWPY-Y018-00000-00&context=1519360)_

40. After pleadings closed, the Claimant applied to strike out the Defendants' defence to the Minimum
Wage claim on 1 November 2016. After a further directions hearings the Master directed a single issue trial
on the Defendants' defence to the Minimum Wage claim. That trial proceeded on 18 July 2017 and that
aspect of the Defendants' defence was dismissed on 31 July 2017.

41. It can be seen from the Master's judgment that despite her direction that special measures should
apply to the single issue trial to assist the Claimant to give evidence, these were not arranged in advance
of the hearing. The start of this trial, disappointingly, was similarly hampered.

42. The Defendants argued at the single issue hearing that the Claimant fell within the scope of the family
workers' exemption pursuant to Regulation 57(3) of the National Minimum Wage Regulations. The Master
concluded in the course of her careful judgment that this defence was “doomed to fail”.

43. The Defendants are clearly bound by those findings (which I note are the subject of an appeal). So far
as any findings or observations about the case on other issues are concerned, the court is not bound by
the Masters observations that the Claimant was “kept in economic servitude” or “oppressive servitude”.
Nevertheless I agree with and adopt the conclusion referred to in paragraph 94 of her judgment, that it is
disturbing that a civil servant such as Mrs Abu should have represented to the Home Office for visa
purposes that the payment terms for the Claimant were as set out in the terms of conditions, whilst
knowing full well that they were not.

44. There remain significant issues which this court is required to determine. I summarise them as
follows:

i) Whether the Claimant was the victim of trafficking. This is relevant to all the other issues which arise in
the case, but also the question of the parties' credibility.

ii) As to the National Minimum Wage claim, when considering the quantum of that claim, what type of work
the Claimant was engaged in, what her hours were and what additional payment she is entitled to, and also
[whether part of the claim relating to the period before 28 October 2009 is time barred by the Limitation Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0N0-TWPY-Y018-00000-00&context=1519360)
_[1980. On this issue the Claimant relies on section 32(1)(b) and (2) of that Act.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-G0N0-TWPY-Y018-00000-00&context=1519360)_

iii) The Claimant's claim for breach of contract in that the Defendants failed to comply with the express
term as the payment of wages. In fact this issue really takes my determination no further.

iv) Whether the Defendants' conduct amounted to harassment within the meaning for the 1997 Act. The
facts relied upon amounting to harassment are set out in paragraph 49 of the Particulars of Claim. The
Claimant relies on the trafficking itself, exploitation of her vulnerable immigration status as well as specific
incidents when the family relationship started to break down badly in mid 2014.

v) Whether, if I find that there has been harassment or breach of contract, the Claimant has suffered
foreseeable injury as a result.

**The Evidence**

45. There are a number of factual issues that arise. I have dealt with some of those of above and I will
refer to them in the discussion which follows. All findings are made adopting the civil standard, namely the
balance of probabilities. In the evidence I have been referred to a number of incidents occurring during the
9½ years that the parties lived together in the same household. I do not propose to make a finding in
relation to each one, but deal only with those which are most relevant. The fact that I may not have referred
to one particular detail in the evidence, however, does not mean that I have disregarded it.

46. I have heard from the Claimant herself. She is the only witness called in support of her case as to the
factual circumstances of her employment and residence with the Defendants. The Defendants have given


-----

evidence and called other members of their circle of friends. Mrs Eluwole, Mrs Abu's sister who travelled
with the Claimant to the United Kingdom in 2005, also gave evidence. Mrs Enebeli, a teacher and friend of
the Defendants' family and Mrs Omolere another friend of the family, both of whom were also involved in
church activities in which the Claimant and the Defendants' family participated provided evidence. It is
noticeable that these ladies only saw the Claimant in the presence of the Defendants' family save on one
occasion when the Claimant came to Mrs Omolere's home early to assist her with a barbeque she was
holding to celebrate her daughters first birthday in June 2014.

47. Mr Akinwale, first cousin to Mrs Abu and Mrs Eluwole who lived near by and who was called upon to
mediate between the parties in February/March 2015 was also called to give evidence. It was asserted in
the course of the argument that as Mr Akinwale was a paternal cousin to the Claimant, he was a family
member from whom the Claimant could have sought help and friendship, when relationships became
difficult during 2014 and early 2015. I find that the Claimant's diffidence in relation to approaching him, was
entirely genuine. He was of an older generation. He was seen by the Claimant as a person in authority
over her. It was very clear from the evidence which I heard from the Claimant throughout her evidence, that
as a junior member of the family from a poor background, she was required by her culture and upbringing
to respect and obey older family members. When the Defendants called upon him to intervene, his
response was to call the police. The Claimant was already very anxious about her position, in particular the
fact she thought she was being asked to lie, and this would no doubt have reinforced her anxiety still
further.

48. It was suggested by Mrs Abu in her evidence, that when the Defendants put the Claimant out on the
street in March 2015, she could have gone to Mr Akinwale's home to seek help. I find on the evidence that
Mr Akinwale was not warned that this was likely to happen, nor did the Defendants ask him to provide
accommodation, temporary or otherwise. Mr Akinwale's evidence about whether he was in a position to
provide the Claimant with a home was confusing and contradictory. At first he said that the Claimant was
welcome to come to him at any time to talk, but not to live. Then when questioned again he said that the
home had lots of rooms and he had invited her to stay with his family in January 2015.

49. I have heard expert evidence from Dr McQuade, a director of Anti Slavery International. He provided
his opinion to the court on whether, in the circumstances of the Claimant's arrival in the United Kingdom
and subsequent employment by the Defendants, the Claimant could be said to be a victim of trafficking
within the meaning of the Council of Europe Convention. He has an impressive curriculum vitae and has
acted as an expert in other trafficking cases. He is clearly familiar with the criteria applied by the
International Labour Organisation as indicators of forced labour. Although at case management stage,
directions were given for a jointly appointed expert on trafficking to be instructed, at the Pre-Trial Review,
the Defendants abandoned reliance on Dr McQuade, but were refused permission to instruct a separate
expert. Accordingly the Claimant was given permission to call Dr McQuade and the Defendants have had
the opportunity to cross examine him.

50. I have also received a medical report on the Claimant's behalf from Professor Katona dated 25
January 2016. Permission was given to both parties to obtain psychiatric evidence, however the
Defendants have not obtained their own report.

**The Factual Witnesses and Findings of Fact (not dealt with above).**

51. The Claimant and the Defendants have provided evidence about the Claimant's arrival into the
Defendants' household over twelve years ago and the circumstances of her residence with them until
March 2015. Inevitably there are differences in recollections caused by the effect on memory by the
passage of time. The perceptions of parties also changed over time, and in my judgment have been
affected by the distressing circumstances in which the Claimant's residence came to and end. These were
obviously distressing to the Claimant. I accept Mrs Abu's evidence that tensions in the house had become
so bad by March 2015 that she was a loss to know what to do. She was also concerned about the welfare
of her children. This did not, however, in my judgment justify the eviction of the Claimant from the
Defendants' home in the circumstances described.


-----

52. It is judicial experience that those involved in disputes within family relationships or other close
personal or domestic relationships which have failed have a natural inclination to reinterpret past events in
either vengeful or self exculpatory terms. This is particularly so in the present case where the Claimant's
expectations of the life she was expected to lead in the United Kingdom, including her education, had not
been met, I find that she has a genuine and justified sense of grievance against the Defendants. I also find
that the Defendants feel a sense of grievance that the Claimant has turned against them, after they
provided her with a home and assisted her with education and the opportunity to remain in the United
Kingdom.

53. The Defendants are clearly distressed by the way in which relationships broke down between the
parties. They are clearly concerned about potential consequences of this court action not only financially
and professionally but, no doubt, it will affect their standing in the community in which they live. I find that
they were angered in 2014 and 2015 by the way in which the Claimant, for whom they had provided home,
food and assistance with education turned against them and was not prepared to engage with their attempt
to resolve the problems within the family or the community.

54. It is relevant in this context that an arrangement that a young person, possibly a relative, in poor
circumstances coming to work as a domestic worker within a family home, in return for bed and board and
some assistance with education, but without remuneration, is culturally acceptable within the Defendants'
community in Nigeria. When I ask Mrs Abu about this, her initial response was evasive, she confirmed that
it did happen but she only knew of one such arrangement, which was that made between the Claimant and
her sister. Mrs Eluwole confirmed without hesitation that this was an acceptable arrangement in Nigeria
and that it can work well. She had not been present when Mrs Abu gave her evidence.

55. Having read and heard the evidence of the Defendants themselves and Mrs Eluwole, I find, on the
balance of probabilities, that that was such an arrangement that the Defendants felt that they were
providing for the Claimant. I have no doubt that in some cases such an arrangement can be entirely
benign, providing a young person with a home and opportunities which would not otherwise be available.
However, such arrangements can go badly wrong as they have in this case, and the young person may be
far away from the family home in a situation where there are no friends or close family members to whom
they can turn. Moreover, to satisfy the Immigration Authorities, as Mrs Abu clearly was aware, it was
necessary to represent that the domestic worker was being paid in accordance with British employment
laws.

56. I find that the Defendants and Mrs Eluwole did not fully appreciate how isolating and oppressive the
arrangements in the family home came to be for the Claimant, as, I find, they gave no thought to it. Mrs
Eluwole gave me the distinct impression that the Claimant should have been grateful for the opportunity
afforded to her to reside in the United Kingdom and learn English. As the Claimant's understanding of
English gradually improved and she came to realise that the applications for her visas were untruthful, she
found her position more oppressive. I also find, that whatever the Defendants may have stated in
successive applications to the Home Office for the Claimant's visa to be renewed, it was never any part of
their express arrangement as discussed with the Claimant, to provide the Claimant with regular wages,
whether as to the interval at which any money would be paid or the amount. Nor did they provide any
regular payments. I find that they genuinely considered that their obligations had been discharged by
providing the Claimant with bed and board, clothing and sundries and paying her college fees, providing
her with occasional payment for e.g. bus fares, clothing and sundries, as a parent might with a young adult
daughter or an adult niece living in the same household.

57. The parties' expectations and obligations must be considered against the background of the Trafficking
Convention and the European Convention of Human Rights.

58. I have considered the Defendants' criticism of the Claimant's evidence, that it has been affected by her
own belief that she is a victim, reinforced by the Home Office conclusion, that she is the victim of
trafficking. I find that she has good reason to see herself in that light. The Claimant has been criticised by
the Defendants for failing to mention the hairdressing apprenticeship in which she was enrolled by Mrs
Eluwole when part of that household in Nigeria. I do not find this criticism to be fair. It is not an issue which


-----

directly affects this case although it is part of the background. The Claimant is not to be criticised for
making no reference to this in her witness statement.

59. The conclusion of the Home Office has also affected the evidence of the Defendants, both of whom I
find to be, understandably, defensive. Their evidence was self-exculpatory, tending to emphasise the
benefits they perceived they were providing for the Claimant, minimising the work that she provided for
them in the household and, on some details, unreliably vague. They can properly be criticised for the lack
of any records as to payments made to the Claimant, and any hours that she worked. They were under a
duty pursuant to section 9 of the 1998 Act to maintain such records. Mr Abu was at pains to point out that
this was a relaxed arrangement. That may be so, but that does not justify the deceitful letters to the Home
Office, setting out the terms of the Claimant's employment with them and the payments those terms
asserted were being paid to the Claimant when these did not reflect the reality of their arrangement with
the Claimant.

60. I also accept that the Claimant's circumstances whilst resident with the Defendants were not all bad. I
have seen some photographs, inevitably only a snapshot in time, of family parties in which the Claimant
appears to be enjoying herself and is being included within family and church gatherings. She was not a
modern-day Cinderella confined to a kitchen or her own room, either physically or by lack of suitable
clothing, whilst the rest of the household went out to enjoy themselves. In some respects the Claimant's
evidence has overstated her position. She was somewhat evasive about the question of her personal
freedom to come and go from the home. She accepts that she had a key to the property until it was
confiscated from her in February 2015. She was also provided with mobile telephones throughout her
residence, the most recent of which she regularly used without restriction, in the period when relationships
were breaking down, because as she said she was seeking help. She was understandably very wary of
questions asked by the Defendants' counsel that she may have thought emphasised her freedoms to come
and go, go to college, make friends and acquaintances either at college or at church or in other
circumstances. She was guarded when she was asked about a male friend, although this individual is
referred to in her own witness statement. I accept that she developed friendly relationships with neighbours
with whom she shared the school run, or who assisted the Claimant by taking the Defendants' daughter to
school whilst the Claimant waited at the Defendants' home a for a school bus to take the Defendants' son
to his special school.

61. Nevertheless, these acquaintances were superficial and to some extent brief. I find on the balance of
probabilities that when the Claimant started to form a friendship with a woman from the Jehovah's
Witnesses organisation, when the family was still in Greenwich, so in the earlier part of her residence with
the Defendants, she was discouraged from pursuing this. I accept the Claimant's evidence that the
Defendants advised her not to talk to, or trust, people outside the immediate family or friendship group. At
this stage of her residence with the Defendants the Claimant had limited English and limited opportunities
to make friends for herself. She is an intelligent young woman in a vulnerable situation – she heeded such
warnings, which did not need to be repeated. Accordingly, until a much later stage, after the Claimant's
English improved and she joined the Winners Church in 2012, the Claimant genuinely considered, as I find
the Defendants had intended, that her social circle should be restricted to the Defendants' family group and
friends. The Claimant remained throughout a junior member of the Defendants' household and subject to
their direction.

62. Some of the assertions made by the Defendants in seeking to emphasise the freedom afforded to the
Claimant did not stand up to scrutiny on cross-examination. For example, Mr Abu in paragraph 37 of his
witness statement (P 168) asserted that the Claimant had a friend across the street with whom she spent
time as soon as she left the children at school. He went on that the Claimant would be at the friend's house
for the most part of the day except when she had to go out for something or go to college.

“This I have witnessed on many occasions”.

When it was put to him that in fact generally he had been working full time and he was asked on how many
occasions had he observed this arrangement, he had to concede that it was only five or six times over a
period of four-to-five years. The effect was that he was exaggerating his evidence to overemphasise the


-----

freedom afforded to the Claimant. I found Mr Abu's evidence on the Claimant's duties, and the demands
made upon her, to be particularly unsatisfactory. For example, he asserted at one point that the whole
family shared in the ironing, including himself. When pressed, he had to concede the Claimant did 50% of
the ironing. He said that in the early days, after the Claimant had taken the Defendants' daughter to school
and their son remained at home, as the son was autistic and withdrawn the Claimant had little to do. He
completely failed to take into account that if the Claimant had not been there, some form of paid help would
have been required to care for his son, who did not go to full time education until September 2008. Before
then he had attended nursery for differing periods. I accept the Claimant's evidence that although assisted
from time to time by members of the Abu family, it was her duty, as stated in her terms and conditions and
which she fulfilled, to take both children to nursery or to school.

63. So far as other witnesses are concerned, I am satisfied they have done their best to give a truthful
account of the matters upon they were asked to give evidence. They paint the picture of a contented family
group, with no suggestion the Claimant was unhappy or being oppressed in the Defendants' household. It
is part of human experience that there is the natural tendency, except when in the company of very close
friends, for family members to avoid revealing tensions and problems to friends and acquaintances outside
the family group, particularly in social situations. It is noticeable that the two witnesses from outside the
family, Mrs Enebeli and Mrs Omolere only spoke of contact with the Claimant when part of the Defendants'
family group with the exception of the birthday party for Mrs Omolere's daughter referred to above.

64. It is part of the evidence, and I accept, that the Claimant has never been subjected to physical restraint
or abuse at the hands of the Defendants. Such physical assault as she complains of, preceded her
residence with the Defendants, when part of the Eluwole household. I note that the only time she
complains of being struck when living with the Defendants, was when Mrs Eluwole became involved in an
argument in December 2014. I find that if the Claimant was an untruthful witness, or given to exaggeration,
she might have made such allegations to bolster her case; she has not done so. In addition, she has not
stated that she was never paid by the Defendants. She accepts that they paid her college fees. Where
these were paid from her own bank account, the Defendants provided the funds. She readily disclosed the
fact that she did receive payments both to Prof. Katona who has provided psychiatric report and to Dr
McQuade. She has difficulty quantifying the sums as no records were kept. She accepts that not all the
money she was paid was banked.

65. The Claimant was plainly a nervous witness and was clearly cowed in the presence of the Defendants
and their witnesses, all of whom she knew. She was very anxious whilst giving her evidence. No doubt part
of that anxiety is created by her uncertain immigration status. I reject the assertion made on behalf of the
Defendants that she is pursuing this litigation as a means to improve her prospect of obtaining leave to
remain in the United Kingdom permanently. I reject the inference that her evidence has been tailored to
achieve that objective.

66. Overall, I have found the Claimant's evidence as to the circumstances of her life with the Defendants'
family to be truthful but she has, to a certain extent, minimised the amount of freedom that she was allowed
to attend college on her own and, towards the latter end of her period with the Defendants, attend church
services and activities. I find that as the Claimant's English improved and she became more confident, she
was able to spend more time in church activities and to engage in voluntary work such as the Sanctuary
Cleaners group at the Winners Church.

**The hours worked by the Claimant**

67. Determining the number of hours that the Claimant worked for the Defendants is a challenging
exercise as none of the parties have kept any records. Mr Abu told me that it was a relaxed arrangement.

68. I do not accept that it is realistic to find that the Claimant has worked 12 hours per day, seven days per
week for the whole period of her employment with the Defendant, as asserted by the Schedule of Special
Damages composed on her behalf by her legal advisors. Nevertheless, I find that she worked far longer
than the six hours per day for five days a week provided for in her contract.


-----

69. Prior to the period of maternity leave taken by Mrs Abu, I find that Mrs Abu was out of the home,
according to her own evidence, for a period of approximately 10 hours, allowing for an eight-hour working
day and travelling time. From time to time she would be away from the home for longer periods when she
undertook the family shopping on her way home from work. Once the family moved to Belvedere, Mrs Abu
was out of the house for approximately 11 hours. Whilst Mr Abu was in the house for about an hour after
Mrs Abu's departure for work, during the week he did not return home until after Mrs Abu's arrival in the
evenings. In any event, it was part of the Claimant's duties to get the children ready for school. After the
period of maternity leave between October 2007 and May 2008, Mrs Abu started to work from home for,
generally, two days a week. During that period, although Mrs Abu was on hand to deal with any particular
difficulties which might arise, for example with regard to her autistic son, I find that the arrangement was
that the Claimant remained very much on duty to care for the children and deal with housework during the
working day.

70. I find on the balance of probabilities that whilst not actively engaged in taking or collecting the children
to or from school or nursery, the Claimant was expected to busy herself about the house in domestic tasks.
Although Mrs Abu may have operated the washing machine, I find that the Claimant was expected to assist
with laundry by hanging clothes out on the line and undertaking the bulk of the ironing. I have already
commented upon how Mr Abu, in his evidence, tended to minimise the Claimant's tasks.

71. Once Mrs Abu worked from home for two days a week, I find that she played a greater part in taking
the children to or collecting them from school. I also find that there were periods when Mr Abu was on sick
leave or on holiday, when he also participated from time to time in school runs.

72. I find that the Claimant's duties did not finish once the children were at home. The terms and
conditions of her employment devised by the Defendants themselves required the Claimant to ensure the
children changed out of school uniform and were provided with warm food when they got home. I find from
the Claimant's account that she also assisted with preparing the children for bed.

73. I accept the Claimant's evidence that if she wished to go to a church activity at the weekends she
would do extra work on Fridays to accommodate her absence. I find that in the circumstances of the
Claimant's employment and residence with the Defendants, she had no choice but to comply with the
expectations of the household. This included not only childcare and the school run, but also assistance
with housework and cooking for the family. Those expectations arose not just because of the unspoken
expectations arising from the parties' social and cultural background, but because, I find on the balance of
probabilities, the Claimant would be criticised for not assisting. It is particularly relevant in this regard that
after the difficulties which arose in regard to the Claimant's attendance at the church conference between 6
and 9 August 2014, the Defendants considered that the Claimant had “left your duties”, as they stated in
the letter terminating her employment dated 5 March 2015 (pg 256). One of the dates referred to was a
Saturday. The letter and the Defendants' unconvincing attempts to explain the apparent contradiction
between the content of that letter and their assertions that there was a relaxed arrangement as to their
expectations of the Claimant in the performance of household tasks, were particularly damaging to the
Defendant's credibility.

74. The conclusions which I draw as to the hours worked by the Claimant cannot be precise on the
evidence presented to me. A decision is required, and the court must make a finding using the evidence
available. I find on the balance of probabilities that the Claimant worked for at least 10 hours per day during
the working week during most of the period of her employment with the Defendants until relationships
seriously broke down in late 2014. There may have been days when she worked shorter hours; this is
compensated for on days when she worked longer in order to accommodate her activities, in particular with
the church, at the weekend. She will have had a limited degree of leisure when the younger children were
at nursery, and thereafter when they commence full-time education. Nevertheless I find that the Claimant
was expected to undertake housework when the children were not at home. Any free time during the
working day was balanced by the expectation that the Claimant would engage in the preparation of meals
for the children during the week and generally for the family at the weekend. She was also expected to
help with clearing up after family meals.


-----

75. She did not of course have any duties with regard to taking the children to school or nursery during the
weekends. I do not consider it is appropriate to include church attendance or other activities at the
weekend, with the family as part of the working day, noting that when the Claimant decided to attend a
different church in 2012, she was not prevented from doing so. Nevertheless, she was expected to assist
with childcare, housework and food preparation at the weekends. Accordingly I attribute five hours on
Saturdays and Sundays to the Claimant's hours of work.

76. Thus, when calculating the sums outstanding to her following the Master's decision on her entitlement
to additional payment under the 1998 Act, I find that from the commencement of her employment until early
September 2014, the Claimant's usual hours of work were 60 hours per week.

77. Thereafter, the relationships with between the parties seriously broke down. I note that one of the
reasons for argument in early 2015, was that the Claimant was no longer working for the Defendants. Mrs
Eluwole visited the family in October 2014 and remained for some time. I find on the balance of
probabilities that the Claimant's working time in the household diminished considerably between
September and the end of January 2015 to approximately 20 hours per week over the whole period. I note
that the Defendants have not asserted that the Claimant refused to assist at all with the children during that
period.

**Was the Claimant a victim of trafficking?**

78. I accept the Claimant's evidence that during the whole period she was subject to a degree of control
imposed by the Defendants which amounts in the circumstances to intimidation. The intimidation was not
physical in the sense of threats to personal safety, but the Claimant lived with the fear that if she did not
conform with the Defendants' requirements she would lose her position and this would result in her return
to Nigeria. The intimidation was subtle and in some respects unspoken.

79. For example, I accept the Claimant's evidence that she overheard remarks made by Mr Abu during
telephone conversations that the Claimant had “no choice but to behave”, in response to enquiries made
by Mrs Eluwole in the occasional telephone call. I find the Claimant's detail about this aspect of the
evidence is such that this is an accurate recollection. The tendency of both Defendants to minimise the
contributions the Claimant made to childcare and domestic work, their deceitfulness on other matters, in
particular the terms and conditions of employment, and their dealing with the Home Office are such that I
find their evidence to be unreliable on these and other details in the case.

80. The parties are agreed upon the relevant law, which I have referred to briefly above. I have been
assisted by the evidence of Dr McQuade, who referred in his report to the list of indicators of forced labour
published in guidance notes by the International Labour Organisation (which were referred to in the
Supreme Court decision in Hounga v Allen [2014] 1 WLR 2889). In fact the notes have been revised since
that decision and there are now 11 indicators. These are set out in paragraph 32 of his report (page 231)
and are abuse of vulnerability; deception; restriction of movement; isolation; physical and sexual violence;
intimidation and threats; retention of identity documents; withholding of wages; debt bondage; abusive
working and living conditions and excessive overtime. Dr McQuade concluded from his interview with the
Claimant and the other information presented to him that six of the 11 indicators were present.

81. I take into account that the Claimant was never physically abused, nor was she ever locked into the
family home. She was never kept completely penniless; she received cash payments from time to time.
She had the freedom to go to college and in the latter years to attend voluntary work at church. She also
attended a course for voluntary workers, with the encouragement of Mrs Abu. Nevertheless, the control on
an individual does not require physical restraint, violence, or the threat of violence, to be effective and
coercive. I have considered the indicators of forced labour referred to in Dr McQuade's report. The ILO
guidance notes state that the presence of a single indicator may imply the existence of forced labour.
However, in other cases it is necessary to look for several indicators which, when taken together, point to a
forced labour case. I have considered the six indicators identified by Dr McQuade, with reference to my
findings in the present case.


-----

82. I find that there was abuse of vulnerability. The Claimant was always in a vulnerable situation in the
Defendants' household as a migrant on a visa which she believed bound her to work in the Defendants
household, a belief reinforced by remarks she said (and I accept) were made by the Defendants. The
ILO's guidance notes state as to the concept of vulnerability:

'…[That it can occur] “when an employer takes advantage of a worker's vulnerable position, for example, to
impose excessive working hours or to withhold wages that a forced labour situation may arise. Forced
labour is also more likely in cases of multiple dependency on the employer, such as when the worker
depends on the employer not only for his or her job but also for housing, food…'

83. I find that the Claimant was in such a position. That the expectation of both herself and the Defendants
was that she was 'on duty' in the household for approximately 10 hours per day, was never afforded two
complete days off in each week, and was never provided with five weeks of holiday independent of the
Defendants' family, amounts to excessive working hours. She was never paid the wage provided for in her
terms and conditions.

84. As to isolation, I do not find that this was established to the extent provided for in the ILO guidance
notes. Although there is some evidence of complaint by the Defendants about the Claimant's use of a
telephone, and monitoring of her telephone calls, she was not kept behind closed doors. She did not have
any means of communication confiscated. She was able to attend college, and in the latter years attend a
different church to that which was attended by the Defendants' family, contrary to the wishes of the
Defendants that the family should attend the same church. It is to be noted, however, that the Defendants'
attitude to this situation was to join the same church at a later stage.

85. The withholding of wages has been established by the decision of Master McCloud.

86. There were abusive working and living conditions for limited periods during the Claimant's
employment. She had, as the Defendants' accept, lack of private living space when the family lived in a
two-bedroom property in Greenwich. Thereafter, when they moved to Belvedere, although the Claimant
had her own room and a degree of privacy, the son's clothing was kept in that room. The Claimant was not
able to secure that room to keep herself private. When the family had visitors in 2014/2015 the Claimant
was required to vacate that room and use a playroom instead during winter months. The playroom had
been converted from a former garage, and although I find the Claimant's complaints about its conditions to
be, to some degree, overstated, it was an invasion of her privacy that she was required to vacate the room
that the Defendants had previously allocated to her.

87. As to intimidation and threats, the ILO guidance notes include not only threats of physical violence
(which are not relevant in this case). A threat can involve denunciation to immigration authorities, loss of
wages or access to housing etc. They can also include insulting or undermining workers as being a form of
psychological coercion. In the present case, the intimidation and threats to and undermining of the
Claimant's position was insidious and subtle. There was not a direct threat of denunciation to immigration
authorities. However, I find that the Defendants had explained to the Claimant that her visa permitted her
only to work as a domestic worker within a family home. I find that comments, such as she had no choice
but to behave, that she should not trust people outside the family, and references to other families who had
sent bad and disrespectful girls home were in fact made. I find that they were intended to persuade the
Claimant to conform to the family's expectations and they increased the Claimant's sense of vulnerability
and dependence on the Defendants. I find that the Defendants must have been aware of this.

88. I find that the Claimant was exposed to excessive overtime. Although I have not found a constant 12hour working day to have been established, nevertheless I find that the Claimant's hours grossly exceeded
those set out in the terms and conditions devised by the Defendants and I have commented on lack of free
time above.

89. The consequences of Master McCloud's decision taken together with the successive applications to
the Home Office to extend the Claimant's visa, and then for permission for permanent leave to remain,
necessarily lead to a finding that the Defendants engaged in deceptive practices.


-----

90. Furthermore, the Defendants accept that when the Claimant first arrived in the United Kingdom her
command of English was limited. They must have been aware that the documents that they required her to
sign for the purposes of the Home Office could not be read and understood by her. In that she was simply
presented with these documents and asked to sign them, the Defendants perpetrated the deception as to
the Claimant's working conditions and entitlement to pay against the Claimant, as well as against the Home
Office. This deception increased her vulnerability. Whilst I note that Dr McQuade observes that this
deception does not sit neatly within the ILO guidelines, it is nevertheless indicative of intent to exploit the
Claimant.

91. Article 2.1 of the Trafficking Directive defines the process of trafficking as involving the:

“recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or
transfer of control over those persons, by means of the threat or use of force or other forms of coercion, of
abduction, or fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or
receiving of payments or benefits to achieve the consent of the person having control over another person,
for the purpose of exploitation”.

Broken down, Dr McQuade helpfully identifies three factors, the act, the means and the purpose which
must be satisfied for trafficking to have occurred (page 234). Article 2.3 of the Trafficking Directive refers
to forced labour or services.

92. Whilst I have not been satisfied on the balance of probabilities that arrangements were made during
the family visit to Nigeria in 2004 for the Claimant to travel to the United Kingdom, I am satisfied that once
she arrived in the United Kingdom and arrangements were made for her to stay with the Defendant family
the act, namely the harbouring of the Claimant or the transfer of control over the Claimant from Mrs
Eluwole to the Defendants within the meaning of Article 2.1, was established.

93. As to the means, I accept there was no physical force or threat. The coercion was much more subtle.
Psychological bonds were imposed upon the Claimant by the expectations of the Defendants, the
Claimant's experience, the parties' social background and cultural expectations with which the Defendants
were undoubtedly familiar. The Claimant was chained without physical chains. Her position in the
Defendants' household was vulnerable, with the ever-present worry of being returned to Nigeria if she did
not conform. This situation established the means.

94. The purpose of this arrangement was to exploit the Claimant's services for the provision of childcare
and general domestic help in the Defendants' household for limited payment. The Claimant provided
services of value to the Defendants which enabled them to work full-time, whilst the Claimant cared for
their children. In addition the Claimant not only looked after herself within the home; she undertook
household tasks as described above for the Defendants, sharing with and, I find, relieving them of the
burden of such tasks. She did more than might have been expected of an adult family member. She was in
every respect a domestic worker, whose services the Defendants secured without fully complying “with all
the relevant laws in the United Kingdom relating to employment and wages etcetera”, as they falsely
represented to the Home Office (e.g. page 556).

95. Accordingly I am satisfied that the Defendants abused the Claimant's position of vulnerability to keep
her in a position of effective economic servitude. And that the facts required to establish forced labour and
therefore trafficking of the Claimant are proved within the meaning of the Trafficking Convention.

**The claim under the National Minimum Wage Act/breach of implied terms of contract.**

96. I have set out my findings as to the hours worked above. I am satisfied that the 30 hours per week
referred to in the Claimant's terms and conditions amounts to “salaried hours worked” within the meaning
of the classifications under the National Minimum Wage Regulations 1999. Given that those terms and
conditions provided for additional hours to attract a wage of £7.60 per hour, I find that additional work
constituted “time work” for the purposes of the regulations.

97. Section 28(3) of the 1998 Act provides that where in civil proceedings a person seeks to recover on a
claim in contract an amount described as additional remuneration in section 17(1) (that is, the


-----

underpayment of the national minimum wage as calculated under that section) it is presumed for the
purpose of the proceedings that the worker in question was remunerated at a rate less than the national
minimum wage unless the contrary is established. Accordingly, the burden of proof of the amounts the
Claimant was paid and the hours for which she was paid rests on the Defendants. The Defendants had a
statutory duty to maintain records under section 9 of the 1998 Act and the regulations made under that Act.
They have failed to do so. Mr Abu sought to excuse this by saying that this was a relaxed arrangement.

98. Given the lack of any reliable documentation or precise evidence as to the hours the Claimant worked
and the precise amounts she was paid, it is impossible to make a precise calculation of the amount to
which she is entitled under the 1998 Act following the Master's judgment. The court can only do its best
using the material which is available.

99. The Claimant has conceded that she did receive some payments from time to time. In his witness
statement for the trial, the First Defendant maintained that the Claimant was paid a minimum of £200 every
month outside of other cash payments in the middle of the month which amounted to about £300 per
month. Mrs Abu did not quantify the amounts paid to the Claimant. In cross-examination both Defendants
denied that any part of the alleged £200 payment was made to the Claimant for expenses such as college
fees, visas and payments to the Claimant's mother. The Defendants produced a table of payments made
on the Claimant's behalf included in the trial bundle at page 340. The total amount is £7,190.60 over 9½
years, namely £63 per month.

100. Mrs Abu said that her bank statements would not show withdrawals for cash payments to the
Claimant because these were made by her husband from his account and he would hand them over to her.
Mr Abu produced his bank statements on the 4th day of the trial for the first time. They were heavily
redacted. They did not cover the complete period. Whilst they show cash withdrawals made, usually, after
his own pay was received, the withdrawals vary and there are only thirteen single withdrawals of £200. Mr
Abu's explanation for the multiple withdrawals on a single day was that he would call Mrs Abu and find out
how much cash she needed to make up the Claimant's pay of £200. The explanation is inconsistent with
Mrs Abu's account of how the cash was made up, to pay to the Claimant and is of no assistance to the
court. The Defendants have been unable to provide any convincing explanation as to why they simply did
not pay the Claimant by bank transfer once a bank account had been set up for her in 2006. Mr Abu said
that the Claimant preferred to be paid in cash. However he admitted that she had never said so. There is
evidence in both Mr Abu's and the Claimant's bank statements that he did on occasion transfer money to
the Claimant.

101. Accordingly I find that the Defendants have failed to prove on the balance of probabilities that the
Claimant was regularly paid £200 per month, or indeed any specific regular sum in the course of her
employment save for a short period between May and July 2014.

102. The Claimant, by contrast, has accepted that minimal payments were made to her. She has been
able to account for £3,730 of payments and volunteered that she received cash payments of £200 for a few
months in 2014 following the visit to the solicitor. It is noted that a withdrawal of an exact amount of £200
does appear in Mr Abu's bank statements in each of the months from May to July 2014.

103. Other than the accommodation offset provided for in the 1999 Regulations, only payments made
directly to the Claimant may be offset against the Defendants' minimum wage liability. Pursuant to
regulation 9(a) of the 1999 Regulations, sums paid for visas, courses, books and other items cannot be
offset against the national minimum wage liability. In relation to such payments, the First Defendant
accepted that the Claimant had never asked him to pay sums to her mother on her behalf. Accordingly, I
disregard any such payments, the precise amount and number of which have not been proved in any
event, with the exception of one payment of £95.

104. Noting the Claimant's concession that she did receive cash payments from time to time from the
Defendants, I find on the balance of probabilities that these will have exceeded the figure for which she has
been able to account, but it is impossible to say by how much. Accordingly the court must fall back on the
burden of proof imposed upon the Defendants by the 1998 Act, which has not been discharged.
Conversely the Court must guard against overcompensating the Claimant I find on the balance of


-----

probabilities that it is likely that over the course of the nine and a half years that the Claimant worked for
the Defendants she will have received payment in cash of approximately £100 per month over the whole
period, rising to £200 per month, for three months during May to July 2014. The figure of £3730 which she
can account for, is included in this figure. Accordingly, from the payments due to be made to the Claimant
under the 1998 Act, the payments I find were probably made are to be deducted.

**Breach of Contract**

105. So far as the claim for breach of contract is concerned, I note the provisions of section 17 of the 1998
Act which effectively implies into a contract a right for additional remuneration as defined in that section.
The claim for breach of contract does not add anything to the Claimant's claim under the 1998 Act, save
that I find there was a breach of the terms and conditions in failing to provide the Claimant with free time
and holidays as provided for, and failure to provide private accommodation. Any further compensation will
be dealt with in the claim for personal injury and distress referred to below.

**Limitation**

106. As the Claimant's claim for a minimum wage is a claim in contract the primary limitation period is
provided for in section 5 of the Limitation Act 1980 and is six years. Accordingly as the Claimant's claim
was issued on 28 October 2015 any claim in respect of a breach prior to 28 October 2009 is, prima facie,
time barred under that section. However, on the evidence which I have heard, I find that the Claimant is
entitled to rely on section 32(1)(b) and (2) of the 1980 Act.

107. Section 32(1)(b) provides that:

“(1) … Where in the case of any action for which a period of limitation is prescribed by this Act, either—

(a)…

(b) any fact relevant to the plaintiff's right of action has been deliberately concealed from him by the
Defendant or…

the period of limitation shall not begin to run until the plaintiff has discovered the fraud concealment or
mistake (as the case may be) or could with reasonable diligence have discovered it.”

108. Section 32(2) of the 1980 Act provides that:

“For the purposes of sub-section (1) deliberate commission of a breach of duty in circumstances in which it
is unlikely to be discovered for some time amounts to a deliberate concealment of the facts involved in that
breach of duty.”

109. Section 32 will operate to delay the date on which time starts to run where a Defendant is guilty of
deliberate wrongdoing and conceals or fails to disclose it in circumstances where it is unlikely to be
discovered for some time: see Cave v Robinson Jarvis & Rolfe [2003] 1 AC 384 at 394E. I find that the
Defendants deliberately withheld from the Claimant the fact that they were representing to the Home Office
that they were complying with UK employment laws when plainly they were not. They knew that she was
unable to read, write or sufficiently understand English in order to comprehend the terms and conditions
documents which she signed over successive years. Even by September 2009, the Claimant was still
assessed at Pre-Entry ESOL level by the Adult Education College in Bexley. (Page 656).

110. Mrs Abu admitted in cross-examination that she knew she was obliged to pay the Claimant the
minimum wage by the Home Office requirements. She accepted that she did not believe the Defendants
were exempt from that obligation because the Claimant was a member of the family. I find there was a
deliberate breach of duty which was not disclosed to the Claimant and this was committed in
circumstances where the Claimant was unlikely to discover it for some time. I accept the Claimant's
evidence given in her witness statement that she did not truly understand the effect of the document she
was signing until about 2012, but in any event, I find that such understanding did not arise until after
October 2009.

**H** **t**


-----

111. In considering whether the Defendants have engaged in conduct which amounts to harassment to
the Claimant, I take into account my findings that the Claimant has been the victim of trafficking and that
there was an unequal power relationship between the parties. The claim is brought under sections 1 and 3
of the Protection from Harassment Act 1997 (the 1997 Act). Section 1-1 provides that a person must not
pursue a course of conduct

a) Which amounts to harassment of another

b) Which he knows or should know amounts to harassment of the other.

Section 3 of the Act provides for a victim to bring a claim in Civil Proceedings for damages. Section 7 of the
1997 Act provides guidance into interpretation which I have taken into account.

112. I have also been assisted by the remarks of the Court of Appeal in the decision of _Veakins v Kier_
_Islington Ltd (2009) EWCA Civ 1288. Kay LJ referred to the earlier Judgment of Lord Nicholls in Majrowski_
_[v Guy's and St Thomas' NHS Trust (2006) IRLR 695 in which it was observed that “courts are well able to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1CV-00000-00&context=1519360)_
recognise the boundary between conduct which is unattractive, even unreasonable, and conduct which is
oppressive and unacceptable”. Kay LJ went on to observe that “courts have been enjoined to consider
whether the conduct complained of is 'oppressive and unacceptable' as apposed to merely unattractive,
unreasonable or regrettable. The primary focus is on whether the conduct is oppressive and unacceptable
albeit the court must keep in mind that it must be of an order which “would sustain criminal liability”.

113. I find that much of the behaviour relied upon by the Claimant as amounting to harassment whilst
being unattractive, regrettable and sometimes unreasonable does not cross the boundary into conduct
which I find to be oppressive and unacceptable until the later stages of the Claimant's employment by the
Defendants.

114. The first event which I find amounts to harassment within the meaning of the 1997 Act, is the
confiscation of the Claimant's keys to the house, following an argument in mid February 2015. There had
been an earlier argument resulting from Mrs Abu and Mrs Eluwole learning about contact between their
mother and the Claimant's mother in Nigeria, in which they considered that the Claimant's mother had
insulted their own mother. There was a heated argument. After the argument tensions continued and the
Defendants told the Claimant on 13th February that they were proposing to terminate her employment. On
16th February 2015 the arguments between the parties became so bad that Mr Akinwale was asked to
intervene. His evidence was that he called the police, because he was concerned about the behaviour on
both sides. I also find, on his evidence that he was seeking to pre-empt an allegation of mistreatment of the
Claimant by the Defendants.

115. I should make it clear that I make no finding that there was any use or threat of violence from the
Defendants against the Claimant. Nevertheless the removal of keys had the effect of causing alarm and
distress to the Claimant. This was her only home in the United Kingdom. She had no other accommodation
to go to. While she had made friends and acquaintances at college and at church, there was no one to
whom she could reasonably be asked to return for help in these circumstances, although her telephone
usage indicates that she was making a number of calls. In addition, her lack of regular payment from the
Defendants was such that she had very little by way of financial means to assist her if she had to find
alternative accommodation. Although Mrs Abu had made enquires as to alternative employment for the
Claimant, the Claimant did not find the terms on offer to be acceptable. Mrs Abu accepted that she made
no enquires herself as to whether the employment was suitable for the Claimant.

116. Thereafter I find the Defendants' letter of dismissal of the Claimant dated 5th March 2015 was part of
a course of conduct calculated to cause the Claimant alarm and distress. Whilst I accept that the
Defendants were entitled to dismiss the Claimant as her employers, the terms of the letter, which required
her to leave the house, when the Defendants must have known that the Claimant had no access to or
means to pay for, alternative accommodation was oppressive. The Defendants had, I find, informed the
Claimant on more than one occasion that her visa required her to work as a domestic worker in a domestic
household and that if she did not do so she would have to leave the United Kingdom. I find that the terms
of the letter and the requirement that the Claimant leave the family home, bearing in mind the unequal


-----

relationship between the parties and the Claimant's vulnerability as to finding alternative accommodation,
amounted to harassment.

117. Finally, the placing of the Claimant's belongings on the street and locking her out on the 14th March
was an act of cruelty. It was also harassment within the meaning of the 1997 Act. The Claimant was a
young woman in vulnerable position. However strained Mrs Abu may have felt the atmosphere in the
house had become, simply packing up the Claimant's belongings and putting them out on the street,
without warning, whilst the Claimant was out of the house, so that she returned, finding herself unable to
gain entrance even though the family were within, was calculated to cause alarm and distress.

118. Accordingly I find that the Defendants have pursued a course of conduct between December 2014
and 14th March 2015 which amounts to harassment within the meaning of the 1997 Act and the Claimant
is entitled to damages.

**Quantum**

119. I am satisfied that the Defendants are in breach of the Claimant's contract in failing to pay her in
accordance with their own terms and conditions or to give her opportunities for independent days off and
holidays. I also take into account the remarks of the Supreme Court in the decision of Hounga v Allen and
the requirements of Article 15 of the Trafficking Convention that the United Kingdom should provide a right
of victims to compensation from the perpetrators of trafficking.

120. I am satisfied that the acts of harassment that I have found to be proved gave rise to acute distress
for the Claimant, the effects of which she still experienced when examined by Professor Katona in January
2016. It is unfortunate that there has been no update to that report. I note however that Professor Katona
observes in paragraph 8 of his report that subject to being provided with a secure environment and
treatment, the Claimant's prognosis is excellent. Regrettably, so far, the Claimant has not received such
formal treatment. This case bears some similarity with the decision in NAWA v Yousuf 2010, unreported,
although the conditions in which the Claimant was expected to work was not as bad as they were in that
case. I accept the Claimant's submissions that some guidance as to the measure of damages to be
adopted can be found in the decision of the Court of Appeal in Vento v Chief Constable of West Yorkshire
_Police_ (2003) ICR 818which have been revised in the Presidential Guidance on Employment Tribunal
Awards etc published by Judge Simon and Judge Doyle on 5th September 2017.

121. I find that the Claimant is entitled to damages for injury to feelings and psychiatric injury at a level in
the lower half of the top band of the Vento Guidance. Accordingly, for the injury to feelings arising from the
trafficking, and the breach of contract, I make an award of £30,000. I make an additional award of £9,000
for the psychiatric injury amounting to £39,000 in all.

**Disadvantage in the Labour Market**

122. Noting that the prognosis for the Claimant's psychiatric injury is good and that the Claimant is as
much at a disadvantage from her uncertain immigration status and lack of formal qualifications as she is
from the circumstances which give rise to these proceedings, I do not consider that the Claimant is entitled
to an award for disadvantage in the labour market.

**Special Damages**

123. The Claimant seeks £3,500 being the cost of Cognitive Behavioural Therapy Treatment as
recommended by Professor Katona. This figure has not been challenged and accordingly I make an award
in that sum.

**Conclusion**

124. For the reasons stated, I find that the Claimant has been the victim of trafficking. She has also been
subjected to harassment within the meaning of the 1997 Act. The Claimant is entitled to an award of
£39,000 in general damages for the reasons given in paragraph 120 above.


-----

125. The Claimant is also entitled, as the Master found, to an award under the National Minimum Wage
Act 1997 which should be calculated on the basis of my findings given in paragraphs 76, 77 and 103
above. Due to pressure of time, I have not been able to carry out and check appropriate calculations. I
invite the parties to make and agree the appropriate figures.

126. I invite the parties to agree upon and calculate the appropriate rates and award of interest in order to
provide the final Judgment sum.

**End of Document**


-----

