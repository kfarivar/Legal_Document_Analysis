428 (IAC)

# FB and another v Secretary of State for the Home Department (Public Law
 Project intervening) [2018] UKUT 428 (IAC)

UK Upper Tribunal (Immigration and Asylum Chamber)

Lane J and Judge O'Connor

31 October 2018Judgment

For the Applicants: Ms S Naik QC and Mr A Bandegani,

instructed by Duncan Lewis Solicitors

For the Respondent: Mr S Kovats QC and Mr C Thomann,

instructed by the Government Legal Department

For the Intervener:  Ms C Kilroy and Ms A Pickup, instructed by the Public Law Project

_The Secretary of State's “removal window” policy, as set out in Chapter 60 of the General Instructions of_
_21 May 2018, was, as a general matter, compatible with access to justice but was legally deficient, both in its_
_treatment of cases where a removal window is deferred and in the lack of information regarding place and route of_
_removal._

**JUDGMENT**

**_A. Introduction_**

1. A nation state has a right to control who comes onto its territory. In states that observe the rule of law, the right
is to be exercised compatibly with that rule. A state may, in addition, decide to circumscribe its powers of control by
means of domestic legislation or as a result of obligations under international treaties, to which the state is a party.

2. These “rolled-up” judicial reviews concern challenges to the way in which the respondent seeks to secure the
removal from the United Kingdom of those whom he considers have no legal basis for entering or remaining in this
country. Specifically, the applicants, who were each to be removed by the respondent in November 2017, assert
that the respondent cannot lawfully operate a “removal window” policy, as set out in Chapter 60 of the General
Instructions (Judicial reviews and injunctions), published by the respondent. In both cases, the Upper Tribunal
granted a stay on removal, following which the applications were directed to be dealt with on a “rolled-up” basis.
The Tribunal also granted permission to the Public Law Project (PLP) to intervene in the proceedings.

3. The present cases concern removal under section 10 of the Immigration and Asylum Act 1999. Before looking at
that power, however, mention needs to be made of sections 3 and 5 of the Immigration Act 1971 (read with section
32 of the UK Borders Act 2007). Section 3(5) of the 1971 Act provides that a person who is not a British citizen is
liable to deportation if the respondent deems his deportation to be conducive to the public good or another person
to whose family he belongs is or has been ordered to be deported. A person liable to deportation may be the
subject of a deportation order, made under section 5, requiring that person to leave and prohibiting him from
entering the United Kingdom.


-----

428 (IAC)

4. Section 10 of the 1999 Act is entitled “Removal of certain persons unlawfully in the United Kingdom”. So far as
relevant for present purposes, it provides as follows:
“(1) A person may be removed from the United Kingdom under the authority of the Secretary of State or an
immigration officer if the person requires leave to enter or remain in the United Kingdom but does not have it.

…

(7) For the purposes of removing a person from the United Kingdom under subsection (1) … the Secretary of State
or an immigration officer may give any such direction for the removal of the person as may be given under
paragraphs 8 to 10 of Schedule 2 to the 1971 Act.

…”

5. In substance, paragraphs 8 to 10 of Schedule 2 to the 1971 Act enable an immigration officer to give directions
to the captain of a ship or aircraft, requiring the captain to remove the person concerned from the United Kingdom
in that ship or aircraft. Directions may also be given to the owners or agents of the ship or aircraft, requiring them to
remove the person from the United Kingdom in any ship or aircraft specified or indicated in the directions, being a
ship or aircraft of which they are the owners or agents. Such owners or agents may, additionally, be given
directions requiring them to make arrangements for the person's removal to a country or territory specified by the
Secretary of State, being either:
“(i) a country of which he is a national or citizen; or

(ii) a country or territory in which he has obtained a passport or other document of identity; or

(iii) a country or territory in which he embarks in the United Kingdom; or

(iv) a country or territory to which there is reason to believe that he would be admitted.” (paragraph 8(1)(c)).

6. The challenges brought by the applicants, supported by the PLP, are directed at Chapter 60. The relevant
version of Chapter 60, for our purposes, is that published on 21 May 2018. Although this was after the date on
which the current proceedings commenced, it was effectively common ground (and we consider) that this latest
version is the one that requires to be substantively examined.

**_B. An overview of Chapter 60_**

7. The 21 May 2018 version of Chapter 60 is set out in full in the Annex to this decision. It is, however, convenient
at this point to highlight its salient features, for the purposes of this case. In doing so, we are not helped by the fact
that this version, unlike its predecessor, is not numbered internally.

8. The guidance begins by stating that the “Version includes some additional interim clarification concerning
Deferral of Removal …”. We accept the respondent's evidence that the provisions in question are “interim”, only in
the sense that the respondent does not intend to revert to the position where no such “clarification” is made.
Whether, in the circumstances, the term “interim” was helpful is, perhaps moot.

9. The guidance describes certain types of event that could be subject to judicial review. These comprise a failure
to act; the setting of removal directions; the refusal to accept that further submissions amount to a fresh claim; a
decision to certify a claim as clearly unfounded; and detention.

10. Under the heading “Notice of removal” it is stated that notice of removal may be given in three different forms:
“• Notice of a removal window – the person is given notice of a period, known as the removal window, during which
they may be removed.


-----

428 (IAC)

- Notice of removal directions – the person is given notice of removal directions and thus knows the exact date of
departure.

- Limited notice of removal – a more restricted version of the removal window form of notification.”

11. A notice of removal window makes it plain that the “window” is a period “during which removal may proceed
without further notice”. A notice of removal window is said to be suitable for persons being removed under section
10 of the 1999 Act and those being deported under section 3 of the 1971 Act.

12. A notice of a removal window will give a “notice period”. When the notice period ends, the removal window
begins and a person “may be removed during the removal window”.

13. The notice period begins when the notice is given to the person concerned, at the time the notice is given. A
notice of removal window is not to be given to a person who has leave to enter or remain or to a person who is able,
within the relevant time limit, to file an in-country notice of appeal or administrative review, or where such is
pending.

14. As already stated, the removal window says when the notice period ends. The removal window “will run for a
maximum of three months” from the time the notice of liability for removal or deportation decision letter is served. If,
however, a removal window has not expired, it can be extended “by way of reminder for a further 28 days”.

15. The guidance states that if a person “makes an asylum, human rights or EU free movement claim, involving
issues of substance which had not been previously raised and considered, or a further application for leave, the
window ends”.

16. Where a removal window has expired, or where removal is not via one of the “safe countries” listed in section
3.2 and which was not notified in the original notice, then a fresh removal window has to be notified, with the result
that a new notice period will begin. The form concerned (RED.0004 (Fresh)) may specify a “range of potential
transit points”.

17. The guidance then turns to the requirement for notice of liability for removal to be accompanied by an
“Immigration Factual Summary”, which must have a chronology of the case history of the person concerned,
including details of whether any appeal rights were exercised in past applications for judicial review. Both the notice
of liability for removal or deportation decision letter must be copied to any legal representative, where the
respondent has details of such, or where a person asks for a specified representative to be sent copies.

18. If a person is detained or arrested for removal later on the same day but states that their circumstances have
changed or that they wish to access legal advice, the guidance states that they will not be removed whilst they are
seeking such advice, or have representations outstanding. Where representations do not amount to a fresh
protection or human rights claim and have either already been considered or had not previously been considered
but would not create a realistic prospect of success “in terms of leading to an outcome other than removal from the
UK”, the individual in question can be removed on the same day “once we have considered the outstanding
representations”.

19. The guidance says that certain categories are not suitable for a removal window. These include “family cases”
(which are defined); cases where a person has made a protection or human rights claim, or appeal, which is
pending; and where the Home Office has evidence, beyond a self-declaration, that a person is suffering from a
condition listed as a risk factor in the adults at risk in immigration detention policy, or some other condition that
would result in the person being regarded as an adult at risk under that policy.

20. The guidance then deals with the requirements to be met in connection with giving a notice of removal
directions. These include the fact that the person concerned “must be given adequate notice that removal has been
scheduled”. In the case of a detainee, notice should ideally be given as soon as removal directions have been set.


-----

428 (IAC)

21. Reference has already been made to the notice period, prior to the opening of the removal window. If the
person concerned is not detained, the notice period is seven calendar days. Otherwise, subject to exceptions
described in the section of the guidance entitled “Consideration of deferral of notice period”, the period must be one
of the following:
“• normal enforcement cases – minimum 72 hours (including at least two working days).

- third country cases and cases where the decision certified the claim … minimum five working days (unless the
case has already been reviewed by JR …)”.

22. The guidance then goes into detail, by reference to examples, regarding what is meant by a minimum of 72
hours with at least two working days. We then reach the part of the guidance entitled “Consideration of deferral of
notice period”. This section is new, in that it does not correspond to anything in existence before 21 May 2018. The
section is heavily relied on by the respondent in contending that the notice of removal policy is lawful. As we shall
see, the primary position of the applicants and the PLP is that the policy is fundamentally unlawful and cannot be
rescued by this section. However, if contrary to that primary position, it is possible for the respondent to operate a
notice of removal window policy, the applicants and the PLP contend that the section is, in any event, deficient.

23. The section begins as follows:
“Whether or not they are detained, individuals must be allowed a reasonable opportunity to access legal advice and
have recourse to the courts. The purpose of the notice period is to enable individuals to seek legal advice. If,
during the notice period, an unrepresented person is yet to instruct a legal representative you [the case worker]
must always consider deferring the removal window for an additional period.

It is reasonable to expect individuals who are aware that they have not been successful in an immigration claim
and/or appeal and/or that outstanding representations may be or have been rejected to act promptly in seeking
legal advice. Each case for deferral must be considered on its individual merits. The key consideration is whether
the person has had a reasonable opportunity to access legal advice and recourse to the courts.”

24. The section then deals with three specific matters: Change of legal representatives; access to legal advice in
detained cases; and access to relevant documentation. So far as concerns the change of legal representative, the
guidance states that a delay caused by this may be unavoidable and consideration should be given based on the
merits of the case, such that it may be reasonable to defer removal “for an additional period” where the person
concerned has “unavoidably lost contact with previous representatives”. On the other hand, it is stated that deferral
should not normally be considered where there is no clear reason provided for the change of representatives (and
the case worker has asked for reasons); or where there is cause to believe that the motive for the change is to bring
about a postponement of removal: “For instance, multiple changes in representative within a short period”.

25. Access to legal advice for detainees is provided by legal advice “surgeries”, held in Immigration Removal
Centres (IRC). There is a requirement to inform detainees of the availability of these surgeries during the induction
process within the first 24 hours after arrival in the IRC. Detainees also have the right to be informed of the duty
solicitor scheme that operates in the individual IRC, along with relevant details. IRC welfare officers direct
detainees to information concerning how to find an alternative solicitor or other immigration adviser; provide
information about the Law Society and Legal Services Commission “in a language that [the detainee] can
understand”; and provide copies of the Bail for Immigration Detainees (BID) notebook.

26. It is said that a request for an appointment with a surgery may be made at any time and that it is reasonable to
expect an individual to make use of the 72 hour notice period at the earliest opportunity, should they wish to use the
services of the surgery.

27. The section acknowledges that the 72 hour notice period may not always be sufficient:
“Generally speaking, if an unrepresented person (in detention) wishes to obtain legal advice and cannot be given an
appointment at an LAA ad ice s rger ithin the initial 72 ho rs notice period the remo al indo sho ld normall


-----

428 (IAC)

be deferred to enable an appointment to be arranged. However, any request for an appointment that necessitates
deferral and continued detention should be carefully considered on its merits. Consideration should be given
whether the individual:

- was properly notified of access to legal advice

- made their request at the earliest reasonable opportunity

- cooperated with any attempt to arrange a consultation

- delayed their request in order to thwart removal”.

28. The final part of the section, concerning access to relevant documentation, states that legal representatives
“need access to relevant documents and case papers in order to properly advise their client”. It is acknowledged
that there may be circumstances where an individual does not readily have access to documents, such as when
they have been detained at a reporting event or have been outside the UK for a significant period.

29. Any refusal decision, notice of liability to removal and immigration factual summary “will be provided to the
representatives on request” either when the individual is detained or at the point that he or she seeks legal advice
on a “same day removal”. In most cases, it is considered that the Immigration Factual Summary will provide the
necessary key facts and case history.

30. The next section of the guidance concerns what are called third country and non-suspensive appeal cases. As
already observed, a minimum five working days' notice must be given here, on the basis that “this is likely to be
their first opportunity for legal redress”. The case worker must “satisfy yourself that they have the opportunity to
access the courts before their departure is enforced”.

31. Special arrangements arise in particular cases, including charter flights. Here, the normal means of challenge
is said to be “injunctive relief” and the person concerned will be given a minimum of five working days' notice of
removal “so they have the opportunity to take legal advice”. The purpose is to “minimise the number of last minute
applications for injunctive relief to the High Court in England and Wales, the Court of Session in Scotland or the
High Court in Northern Ireland and to encourage people to inform the Home Office at the earliest opportunity of any
further submissions they want to make”.

32. Under the heading “Where a second period of notification is not needed” the guidance indicates that a person
who is given notice of removal directions, where the removal fails or is deferred, may not have to be given a further
period of notice for removal “within ten days of the failed or deferred removal”. The ten day provision need not be
operated in the case of those who are still subject to a notice of removal window (although it may do so, such as
where the originally scheduled removal was “towards the end of the removal window”).

33. The guidance then deals with the circumstances in which the bringing of a judicial review will, and will not,
result in the suspension of removal.

**_C. Form RED.0001_**

34. Although we have already had cause to mention form RED.0004, the primary form of notice used by the
respondent in connection with the removal window process is RED.0001. It is convenient to look at this form, as it
was completed and served on the applicant FB on 1 October 2017.

35. The form begins with the heading “NOTICE OF IMMIGRATION DECISION – NOTICE OF REMOVAL”. It told
FB that he was a person without leave to enter or remain in the United Kingdom, who had not given reasons why he
should be granted such leave, and that he was therefore “liable for removal”. The reasons for that decision were
then given.

36. The form said:

-----

428 (IAC)

“If you do not leave the United Kingdom as required you will be liable to enforced removal to Afghanistan. We may
remove you via a transit point in an EU Member State – Dubai, India, Turkey.

You may be detained or placed on reporting conditions.

If you wish to seek legal advice you must do so now.”

37. It appears that the references to Dubai, India and Turkey were intended to be references to transit points
outside EU Member States, one or more which the respondent intended to use in order to effect removal to
Afghanistan.

38. RED.0001 contains a number of boxes, one of which is to be ticked. The one marked in the case of FB was as
follows:
“You will not be removed before 05.10.2017 15.45. After this time, and for up to three months from the date of this
notice, you may be removed without further notice.”

39. The form continued by stating that FB had no lawful basis to remain in the UK “and you should leave as soon
[as possible. By remaining here without lawful basis you may be prosecuted for an offence under the Immigration](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
_[Act 1971,the penalty for which is a fine and/or up to six months' imprisonment”.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_

40. Under the heading “IF YOU HAVE FURTHER REASONS FOR WANTING TO STAY IN THE UK” the form said
“If you have reasons to stay in the United Kingdom, you must state them. This requirement is being given under
Section 120 of the Nationality, Immigration and Asylum Act 2002. If you do not tell us as soon as reasonably
practicable and you tell us later without good reason, you will lose any right of appeal you may have or otherwise
qualify for if we refuse your claim”. Although the form does not say so, this passage is plainly a reference to section
[96 (earlier right of appeal) of the Nationality, Immigration and Asylum Act 2002.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)

41. RED.0001 continued, in FB's case, by stating that he must now tell the respondent about any reasons or
grounds he had for wishing to remain in the United Kingdom.

42. It appears that FB was also given a sheet headed “Additional information”, telling him that he was able to
engage a solicitor; that a list of solicitors was available from the library [at the Detention Centre]; and that
“appointments to see legal advisers are available in the centre. Please speak to an officer if you wish to make an
appointment”. It was stated that solicitors attended Campsfield House Immigration Detention Centre every
Tuesday, Wednesday and Thursday. The document also said that FB “may use the internet to help you find a
solicitor; the suggested starting point is the Law Society website: www.lawsociety.org.uk”.

43. FB was also given Form RED.0003, headed “STATEMENT OF ADDITIONAL GROUNDS under section 120 of
the Nationality, Immigration and Asylum Act 2002”. This form contained information on what to do, if FB considered
that he had reasons for remaining in the United Kingdom, which were not merely a repeat of those already given to
the respondent.

**_D. An overview of the challenges to Chapter 60_**

44. Following that overview of Chapter 60 and the forms, it is necessary to return to the challenges of the
applicants and the PLP. Their primary submission is that the respondent cannot lawfully operate a removal window
policy, of the kind described in Chapter 60.

45. According to the applicants and the PLP, the reason for this is as follows. In R (Anufrijeva) v Secretary of State
for the Home Department and Another _[2003] UKHL 36, the House of Lords held that constitutional principle_
requires an administrative decision which is adverse to an individual, to be communicated to the individual before it
can have the character of a determination with legal effect, so enabling the individual to challenge the decision in
the courts, if so wished. In the absence of express language or necessary implications to the contrary, general


-----

428 (IAC)

statutory words cannot override such a fundamental right but, rather, will be presumed by a court to be subject to
them.

46. In R (UNISON) v Lord Chancellor _[2017] UKSC 51, the Supreme Court held that the constitutional right of_
access to justice is inherent in the rule of law. That right has long been recognised and can only be curtailed by
clear and express statutory words. Any hinderance or impediment by the executive with the right requires clear
parliamentary authorisation and any statutory provision authorising such an intrusion would be interpreted as doing
so only to the extent reasonably necessary to fulfil a particular objective in question.

47. In R (Medical Justice) v Secretary of State for the Home Department [2010] EWHC 1925 (Admin), Silber J held
that, on the basis of the evidence before him, the respondent's policy of giving less than 72 hours' notice of
directions for the removal of an individual at a specific time, to a specific place, was unlawful, as being contrary to
the principle of access to justice. Silber J's judgment was upheld in the Court of Appeal.

48. According to the applicants and the PLP, this case law is dispositive of the matter, in their favour. The giving of
removal directions, following a notice of liability to removal under section 10 of the 1999 Act, is a discrete
administrative decision, of the kind described in Anufrijeva. The judgment of the Court of Appeal in the Medical
Justice case binds the Upper Tribunal to find that the giving of less than 72 hours' notice of removal directions
violates the principle of access to justice and is thus unlawful. Given that the respondent's notice of removal
window policy is predicated on the basis that, whilst the window is open, as a general matter no notice at all needs
to be given of the removal directions, the notice of removal window policy in Chapter 60 must be unlawful.

49. The applicants and the PLP further contend that the Medical Justice cases did not include a finding that a
minimum 72 hours' notice of removal directions was lawful. They say this issue remained unresolved, following the
Court of Appeal judgment. In the light of the contraction in the availability of legal aid, in the years following the
Medical Justice cases, the applicants submit that 72 hours' notice is incompatible with access to justice. In the
course of oral submissions, a minimum period of five days was identified as a possibly suitable period.

50. Even if, contrary to the submissions of the applicants and the PLP, a notice of removal policy could be lawfully
operated, along the lines set out in Chapter 60, the applicants and the PLP contend that, even in its current form,
Chapter 60 is legally defective. In particular, there is uncertainty as to when a removal window ends and there is
otherwise a material lack of clarity in the section dealing with deferral of the removal window. The provisions are
not phrased in “mandatory” language, which the applicants and the PLP consider to be vital. Caseworkers are
given inappropriate discretion concerning deferral of removal. The length of the removal window and the possibility
of further such windows are capable of having a seriously adverse effect upon the individuals concerned.

51. We shall return to these challenges, and the respondent's response to them, in more detail. First, it is
necessary to look at the evidence that has been adduced by the parties, both as to the background to the present
position and as regards its practical effects “on the ground”.

**_E. The evidence_**

_Julia Dolby_

52. The background to what is described as the development of the 72 hour policy is set out at paragraphs 7 to 17
of Silber J's judgment in Medical Justice. It also features in the witness statement of Thakur Rakesh Singh of the
PLP and in the statement of Julia Dolby, of the respondent's Removals, Enforcement and Detention Policy Team;
Illegal Migration, Identity, Security and Enforcement Policy, Borders, Immigration and Citizenship Systems Policy
and Strategy Group.

53. Ms Dolby's statement, however, deals both with this background and the events which followed, leading to the
current policy. It is, therefore, convenient to draw upon Ms Dolby's statement.

54. Ms Dolby describes the respondent's enforcement policy as being founded on the expectation that those with
no right to be in the United Kingdom sho ld ret rn home The respondent e pects s ch persons to lea e ol ntaril


-----

428 (IAC)

but where they do not, Immigration Enforcement will seek to enforce their departure. She says that such returns
are only enforced “where both the Home Office and the courts are satisfied that an individual has no right to remain
in the UK”.

[55. Before the changes introduced by the Immigration Act 2014,which amongst other things, re-cast section 10 of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
the 1999 Act, individuals being removed were notified of their removal by way of an enforcement decision, which
set out the reasons why they were subject to enforcement action, followed by a notice of removal directions setting
out the arrangements for their removal, including the date of removal. That date “had to be set after a minimum of
72 hours … or unless an asylum/human rights refusal had been certified, when five working days must be given,
after the individual was notified that removal directions have been set, in order to allow them time to access justice”.

56. The 72 hour period came about as follows. The respondent had previously entered into an arrangement with
the High Court – known as the “Concordat” – which was intended to avoid the need for last minute injunctions. The
respondent would agree to defer removal on threat of a judicial review, working on the assumption that such
challenges were arguable ones that needed to be examined. The result, however, was that it was necessary to
release from detention those threatening judicial review, since their claims took so long to resolve. It became
apparent to the respondent that some detainees were threatening judicial review “simply to get out of detention, and
in most instances the threatened JR was never lodged”.

57. This led the respondent to develop an approach whereby persons were detained and removed very quickly; but
that resulted in a reduction of access to lawyers and legal remedy, with the result that the “courts held that the
practice was a denial of access to justice”.

58. A new policy of providing 72 hours' notice before removal was discussed with the then President of the
Queen's Bench Division and the previous Chief Executive of what was then the UK Border Agency in 2006/2007.
The resulting policy required a change to be made to the Civil Procedure Rules. The change was aimed at
reducing the impact of weak claims, designed to disrupt detention and removal. This attracted criticism from
stakeholders.

59. In the event, the policy reflected in the changed Civil Procedure Rules was for a minimum notice period of 72
hours, rather than 48 hours suggested by the respondent; but with the requirement that any judicial review lodged
within that period must include the full grounds. The thinking behind this was that the judicial review could be
disposed of “in a matter of days”. The policy came into effect in April 2007.

60. As originally framed, the policy contained certain exceptions to the 72 hour notice period, such as where there
were risks of an unaccompanied asylum seeking minor absconding or a risk of self-harm. Subsequently, further
exceptions were added. However, in 2010, the Medical Justice litigation concluded that “a reasonable period
between arrest and removal was required for those subject to removal to access legal advice”. Following
subsequent discussions with the judiciary, the respondent amended the Operational Guidance “to say that 72 hours
must always be provided between an individual being served immigration papers and the actual removal of the
offender” and that the period started when “removal directions” were served.

61. Following the legislative changes introduced in the _[Immigration Act 2014,amendments were made to the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
enforced removal process. Individuals who had no leave to enter or remain, would be notified of their liability to
removal and told that if they had reasons to stay in the United Kingdom, they must state them at the earliest
opportunity, pursuant to section 120 of the 2002 Act.

62. Ms Dolby says that:
“The minimum 72 hour notice period was brought forward to the time when the individual was notified of their
liability to removal in order to allow sufficient time for the Secretary of State to consider any issues raised at an
earlier point rather than waiting until the actual removal directions … had been made and then potentially having to
cancel the removal.”


-----

428 (IAC)

63. Ms Dolby said that the thinking behind this was concern that the previous policy, where an individual was given
notice of removal directions, led to the submission of late claims that could reasonably have been raised and
considered earlier in the process and that in some cases this was being used as an attempt to frustrate or delay
removal. Thus:
“The aim was to make it clear at the refusal stage that people should not be waiting until the last possible moment
before removal before seeking legal advice and submitting their claims. In addition, notifying the individual of the
precise time and date of their removal directions was on occasion leading to disruption on the part of some
detainees in immigration removal centres … or to information being circulated on social media by action groups
who are seeking to disrupt the removal, for example, by preventing access to or egress from the IRCs, contacting
airlines, or seeking to prevent flights from departing.”

64. The three month removal window was introduced on 6 April 2015. This followed a threat of challenge to an
earlier version of the policy, by the PLP on behalf of Medical Justice, who objected to “having a completely unending period from when a person was first given notice of their liability to removal”.

65. In addition to introducing a three month removal window, the minimum notice period was amended from being
not within the first 72 hours for all cases to being 72 hours if detained or seven calendar days, if not detained. The
respondent's rationale was that the 72 hour policy was appropriate for the “detained environment where there is
access to a “legal surgery””. By contrast, in the “non-detained environment, the Home Office accepted that we
needed to give individuals more time to seek legal advice”.

66. The new removal policy included the practice of arresting a person and removing him or her “without them
always being detained overnight in an immigration removal centre, sometimes called …same-day removal or
Operation Perceptor cases after the initial pilot, which would not take place until after a person had been notified of
their liability to removal and the seven day non-detained (notice period) had expired”.

67. Same-day removal is, Ms Dolby says, used only for those who are deemed suitable for the three month
removal window and further consideration must be given to any health conditions or vulnerabilities. In same-day
removal cases, the individual is always interviewed as to their current position, including health, domestic
circumstances, and whether they have representatives or solicitors or any outstanding applications. The response
of the individual will inform whether the same-day removal will proceed. Individuals concerned are provided with
access to a telephone, with available credit, for the purpose of consulting a legal representative.

68. Ms Dolby says:
“If the individual says that they intend to submit a protection claim and this is a first-time claim, then removal will
automatically be deferred until after the claim has been decided and any appeal rights exhausted. If the individual
has previously made a protection claim, this will be referred to the Operational Support and Certification Unit
(OSCU) who will consider the claim and decide whether or not this amounts to a fresh protection claim and if not,
whether it has already been considered; or has not been previously considered but will not create a realistic
prospect of success.

If so, then the individual “can proceed to be removed on the same day once OSCU have considered the
outstanding representations.”

69. Ms Dolby reiterates that where an individual has signalled a wish to make a first-time protection claim, or has
made such a claim, then removal “will be deferred to enable that claim to be considered”. If the claim is refused
with a right of appeal in the United Kingdom, then a fresh removal window cannot be opened until the individual has
exhausted his or her appeal rights. If, on the other hand, the claim is certified under section 94 or 96 of the 2002
Act, then the individual will be given a notice period of at least five working days, for the purpose of deciding
whether to bring a judicial review to challenge the certification decision.


-----

428 (IAC)

70. Ms Dolby's statement ends by describing aspects of the new section of Chapter 60 concerning the
“Consideration of deferral of notice period”. We shall return to this later.

71. The applicants have submitted a number of witness statements, together with exhibits, including a
questionnaire prepared in connection with these proceedings, and the responses to it.

_Toufique Hossain (1)_

72. Toufique Hossain, a partner and director of public law at Duncan Lewis Solicitors, describes the relevant work
that his firm provide in this area. Duncan Lewis has contracts with the Legal Aid Agency to provide advice and
representation at legal advice surgeries in a number of IRCs, including those at Campsfield, Harmondsworth and
Yarl's Wood.

73. Mr Hossain points out that IRCs do not have an out-of-hours legal advice cover. Detainees routinely wait for up
to a week and may in the worst cases wait two to three weeks for appointments with surgeries. Caseworkers
operating at the surgeries “must be realistic about their ability to assist somebody in the timeframe available, with
regard to their other commitments”. In fact, the SRAs code of conduct requires a solicitor to take on a case only
where the firm has the resources, skills and procedures available, such that it is possible to provide a service that is
competent, timely and relevant.

74. Notwithstanding these difficulties, Mr Hossain's team is, he says, “capable of taking on and dealing with urgent
cases where there appear to be merits, even if it means working within a very tight and until the last minute
timeframe”. He goes on to say the following:
“Experienced practitioners in this area will know that right up until the client is on the runway on the plane, it is
possible to be granted an injunction and prevent somebody from being refouled to their country of origin. Indeed,
recently we have obtained an injunction after a client was put on a flight for Afghanistan via Istanbul and the Home
Office had to arrange for him to be brought back from Istanbul (see exhibit “TH1”)”.

75. As we shall see, a similar case (evidenced in the witness statement of Jamie Bell) has been the subject of
detailed analysis and criticism by the Lord Chief Justice in SB (Afghanistan) [2018] EWCA Civ 215.

76. Mr Hossain describes the changed legal aid landscape, so far as immigration is concerned, since the Medical
Justice cases. In particular, difficulties have arisen with the LAA, concerning the Chapter 60 policy. Since the
notice of removal window stipulates a three month period in which removal can take place “the LAA has mistakenly
considered that an emergency application is not appropriate in most circumstances. This is based on the
misunderstanding of the new form of removal notice …”.

77. Since 2010, functions previously delegated to legal aid practitioners, have been, in fact, taken back “in-house”
by the LAA. Accordingly, an application to the LAA needs to be made for funding on an emergency basis.

78. Obtaining the relevant papers is also difficult and, according to Mr Hossain, likely to take 24 to 48 hours at
least. In some cases the client may be able to provide contact details of the previous representatives but, even
then, the speed with which the previous solicitor processes the request “can vary greatly, even when the urgency is
explained”. Requests for documentation from the Home Office are often refused on the grounds that the proper
means of obtaining disclosure is by making a subject access request, even though the current target for processing
such requests is 40 days and a minimum of two weeks is usually expected.

79. Mr Hossain then describes the process of taking instructions, reaching conclusions that enable the individual
“to make a threat of proceedings” and issuing proceedings. As regards issuing proceedings, Mr Hossain says that
relevant members of the Bar “are in high demand” and also experience capacity issues. Finding counsel who has
the required expertise to further the client's interests can prove very difficult for urgent matters. This is compounded
by legal aid cuts.


-----

428 (IAC)

80. Misunderstandings regarding Chapter 60 are not confined to the LAA, in Mr Hossain's view. Difficulties have
been encountered with the Administrative Court Office:
“with court staff refusing to seal claim forms on the same day where a notice of removal window is provided. Our
clerks have reported that the problem arises because the court staff do not appreciate that the notice of removal
window is a form of removal directions and therefore such applications are urgent. This confusion would appear to
be caused by the misleading language and the absence of a date and time of removal, without which our clerks
have trouble explaining the urgency to court office staff.”

81. Mr Hossain says that although “many legal representatives are by now aware that as the client can be removed
from the date the window opens, that date should effectively be treated as the date of removal … There are still
likely to be others who do not appreciate this urgency or who choose to delay because no confirmation of a
scheduled flight has been received”. Prioritising cases is, in any event, challenging and so, when presented with a
removal window case, “even a non-negligent legal representative may choose to make a calculated decision to
prioritise another urgent matter”.

82. Mr Hossain is concerned by the uncertainty, stemming from Chapter 60, as to when a removal window ends.
In a recent case, a client made an asylum claim, after being given a notice of removal window, but was then served
with a further such notice, which the respondent wrongly said “will sit alongside the claimant's asylum claim”.

83. In general, Mr Hossain says that the Chapter 60 policy “is routinely misapplied”, which suggests a number of
things to him, including that the policy has inherent uncertainty and confusion contained in it.

84. Mr Hossain concludes his first statement by saying that it is clearly desirable and would assist individuals if the
“standard, obligatory notification letters sent to both parties when the removal window has come to an end for a
Chapter 60 reason”. That would permit legal representatives to identify a breach or act as necessary if such a letter
is not received.

_Pierre Makhlouf_

85. Pierre Makhlouf, Assistant Director of Bail for Immigration Detainees (BID) describes his charity as existing “to
challenge immigration detention in the UK”. Demand for BID's services has increased as legal aid has been
“systematically reduced through successive cuts”. Mr Makhlouf describes a number of BID research papers. For
instance, in 2017, 69% of those questioned had legal representation at the time of interview but 70% were not taken
on as a legal aid client. 49% were said not to be able to access the 30 minutes of free legal advice that they were
entitled to in the detention centre, while 63% reported being blocked when accessing websites. One in ten had
never had a legal representative throughout their period of detention.

86. Mr Makhlouf considers that Chapter 60 “is having an impact on the grant of bail and may be prolonging
detention”. Many detainees will, he says, be removed “without ever being legally represented for the purposes of
challenging their removal, or at all, despite their best efforts to obtain a representative”.

_Theresa Schleicher_

87. Theresa Schleicher, a case work manager at Medical Justice, describes the background to the removal window
policy. Although “appearing on its face to be an improvement on the previous policy”, which had no end point, “we
were again concerned about the effects” and “have since continued to monitor the effects of the policy through our
case work”.

88. Medical Justice continues to be concerned that Chapter 60 significantly limits access to justice in that “even
though detainees receive notice of the start of their removal window, reminding them to submit any challenge to the
decision to remove them from the UK in the time before the beginning of the removal window, in practice this was
often not possible, particularly in the large number of cases when only 72 hours is given”. Prioritising clients within
removal windows is, she says, difficult: “We are simply not able to prioritise the most urgent cases and in most
cases are nable to sec re legal representation before the start of a remo al indo Man clients are not then


-----

428 (IAC)

removed during the early part of their removal window or at all. But some are removed before they are able to
access legal advice”.

89. Ms Schleicher says that issues such as fitness to fly and mental illness fluctuate, so that an up-to-date
assessment is important. Medical Justice's task is complicated by the lack of clarity about when a removal window
ends. There are inadequacies, she says, in the procedures for operating Rules 34 (Medical examination upon
admission and thereafter) and 35 (Special illnesses and conditions (including torture claims)) of the Detention
Centre Rules 2001.

90. Towards the end of her statement, Ms Schleicher notes the evidence, which we shall next describe, of
Professor Katona and Dr Bell, regarding the uncertainty that is created by being in the removal window. She says:
“We often observe an increase in anxious and distressed calls from our clients while they are on a removal window.
Many of those with existing mental illness report an increase in their psychological symptoms”.

_Professor Katona and Dr Bell_

91. Professor Katona and Dr Bell have provided a joint statement. They gave evidence in the Medical Justice
case. Professor Katona is Professor of Psychiatry at University College London, whilst Dr Bell is a Consultant
Psychiatrist at the Tavistock Clinic.

92. Their clinical experience indicates that it is “necessary for an individual served with a removal notice to have
time to assimilate the decision and to undertake any associated grieving process, supported by their family and
treating clinical team, in order to reduce the risk of harm”. It is of particular concern that asylum seekers are said to
have “increased levels of psychopathology and mental illness and are about ten times more likely to have posttraumatic stress disorder in age matched general populations”.

93. The statement has this to say:
“14. Those who have been served with removal windows live with the day-to-day fear that they will suddenly be
removed, never knowing when the moment will arrive because of the policy of withholding the date and time of
removal from them. Those in the community, live with a similar fear that they will be detained to facilitate removal,
compounding this day-to-day fear. An individual's ability to prepare mentally for removal will in our view be
hampered significantly if they do not have a definite removal date to prepare for and work towards.”

94. The situation for those in detention is said by the authors to be “more difficult still, due to the adverse conditions
created by detention itself”. This “daily mental duress carries a risk of provoking overwhelming distress and
psychological damage heightened by the state of vigilance, which is greater the longer it continues”.

95. The authors do not consider that the safeguards contained in the current Chapter 60 policy are sufficient. They
echo the views of others regarding the problems with the Rule 34/35 procedures. They complain about the levels of
discretion left to the respondent's staff, in operating various of the safeguards. They end by saying that those
subject to the removal window “face the uncertainty of not knowing whether tomorrow will be the day they are to be
removed. This means that every day, because any day might be the day of removal, the individual is faced with a
very high degree of stress which would be intolerable and harmful for most individuals let alone those who are
already suffering from mental disturbance”.

_Sian Evans_

96. Sian Evans, co-ordinator of asylum services for Women Against Rape (WAR), describes the work of WAR. In
her experience “Women invariably did not understand that the opening of a window for removal meant that they
were in immediate danger from that date. They saw it more as a window in which they should try to get help before
they were removed. This is as a result of the confusing form of the notice, as well as not having the implications of
the window explained to them in a manner and/or language that they understand, often exacerbated by problems
with concentration, anxiety and fear which may make it more difficult for them to take in information in stressful
sit ations”


-----

428 (IAC)

_Elisabeth Walsh_

97. Elisabeth Walsh, a case worker of the Unity Centre in Glasgow, described a Nigerian woman, well-known to
the centre as having suffered “increased panic attacks and episodes of anxiety or severe depression, including
suicidal thoughts” as a result of being given a notice of removal window. Other clients have been confused about
whether they might be detained upon reporting and, if so, whether they would be put on a plane the same or the
next day. Ms Walsh also gives descriptions of persons whom, she says, were removed whilst they had outstanding
claims for asylum.

_Sheona York_

98. Sheona York, Immigration and Asylum Solicitor and Reader in Law at Kent Law Clinic, says that, in her
experience, it is extremely difficult for a person who is threatened with removal, and who does not already have a
competent immigration solicitor acting for them, to gain access to adequate legal advice and collect the evidence
they need to prepare a judicial review, which would not fall foul of criticisms made in the “Hamid” cases. She also
describes the difficulties that have arisen, as a result of the contraction of legal aid provision.

_Mariah Carey_

99. Mariah Carey, Co-ordinator of the Verne Visitors Group, describes, in similar terms to those of other witnesses,
difficulties encountered by those in detention at the Verne in obtaining legal advice. One individual, who was the
subject of two failed attempts to remove him, “has never found a lawyer to take his case, probably because they are
unwilling and/or unable take on such a complex case knowing that they may be unable to obtain funding …”.
Another person, who was told that there was no legal aid available for EEA nationals, eventually was able, through
the intervention of a visitor, to obtain exceptional case funding to enable a legal aid solicitor to act.

100. It should be noted that the Verne has subsequently closed as a detention centre.

_Jamie Bell_

101. Jamie Bell, a solicitor with Duncan Lewis, produced in September 2017 a witness statement concerning his
client, SB, the claimant in the case of SB (Afghanistan), to which we shall turn in due course.

_Lisa Incledon_

102. Lisa Incledon, of Medical Justice, states that in the experience of her organisation, “many detainees with
removal windows have not been able to obtain urgent appointments prior to the beginning of the removal window,
suggesting that even if a detainee is able to approach a welfare officer to request a next day legal advice
appointment the reality is that one is unlikely to be available for days”.

_Nicola Burgess_

103. Nicola Burgess, Legal Director of the Joint Council for the Welfare of Immigrants, describes JCWI's activities.
She also sets out a number of examples of cases with which she has been concerned. MA, a citizen of Nigeria,
was “evidently emotionally distressed from the time the notice [of removal window] was served. MA was only able
to obtain legal assistance after ten days of the window period had elapsed”, and “was therefore at real risk that he
could have been removed without accessing legal help”.

104. Another case involved a person who could not be removed in November 2017, since he was assessed as
unfit to fly due to uncontrolled blood pressure. Although the medical team at the detention centre advised that he
needed a 24 hour assessment of blood pressure before he could be assessed as fit to fly, he was served in January
2018 with a further notice of removal window, which said that his removal would not take place for at least five
working days. It is said that no end point for the removal window was provided. He later was given a third removal
window and eventually an injunction to prevent his removal was granted by the High Court.


-----

428 (IAC)

105. A third example, regarding FN, led Ms Burgess to say this:
“34. Upon receipt of the fresh claim, the respondent did not confirm that the removal window would be closed.
However, it was apparent that he was considering the submissions as further information was sought and so no
steps to apply for judicial review were taken. For clarity and to avoid the need for recourse to the Tribunal,
practitioners would be assisted if the respondent did provide express confirmation in such circumstances. In my
view it is also inappropriate for a removal window to be appended to a section 120 notice. It should be a
standalone decision, served after an applicant has had an opportunity to respond to a section 120 notice and only
once any representations had been fully and finally considered.”

_Pierre Makhlouf (2)_

106. The second statement of Pierre Makhlouf was filed in order to respond to provisions in the respondent's
detailed grounds of defence. These stated that case workers will consider requests by unrepresented applicants for
deferral of removal in order to enable them to obtain representation; that if an unrepresented person was successful
in securing a legal surgery appointment, they will not be removed until the appointment had taken place; that
requests for extra time by solicitors would be considered and removal deferred where there was a genuine need;
and that the Home Office would provide documentation in urgent cases where it could not easily or promptly be
obtained from other sources.

107. Mr Makhlouf was “not aware of any published policy that substantiates these claims, nor any existing
mechanism for detainees or a legal representative to ensure that the approach described … takes place”. It is
noted that this statement was issued prior to the publication of the current version of Chapter 60.

_Sian Evans (2)_

108. Sian Evans of WAR filed a second statement. This describes the case of Ms M who “as a result of inaction

[of] her lawyer … was detained in Yarl's Wood. Duncan Lewis Solicitors stepped in at the last minute to challenge
her imminent removal but her previous lawyer withheld her papers … She was unfairly accused by the judge of
deliberate delaying tactics to try to bounce him into stopping her flight. Bouyed by letters of support from over 100
people including Mariam Margolyes, Ms M refused to go with the guards to the airport. She was subsequently
released and made a fresh claim last August”.

109. Eventually, Ms M was removed from the United Kingdom. It turned out that she “had been asked by her
solicitor to provide evidence from her children that she found too embarrassing and difficult to obtain. Sadly the
only barrister her solicitor had managed to reach … was of the view that nothing more could be done because of
the missing evidence. There was no time to obtain a second opinion from alternative Counsel”.

110. The statement goes on to say that “Poor or no legal representation plays a part in nearly every failure of rape
victims' claims” and that it “is plainly inadequate to rely on the work of competent and committed lawyers to say that
justice can still be obtained in the short timescales allowed by the policy. Such lawyers are few and far between (in
part because of legal aid cuts). In addition, the efforts of law firms such as Duncan Lewis to act swiftly has recently
been criticised in the courts which complained about action being taken where there had not been sufficient time to
prepare”. This is, presumably, a reference to the Court of Appeal judgment in SB (Afghanistan).

_Toufique Hossain (2)_

111. Toufique Hossain's second statement deals with the questionnaire, to which reference has been made.
Practitioners were asked various questions on matters germane to the removal window policy. Those who
responded indicated that there was “considerable confusion” caused by the notice of removal window; that it was
not their understanding or experience that clients who requested a legal surgery appointment would not be removed
until this had taken place; that, on average, responses indicated that more than 72 hours' notice was required to “do
all the necessary work to properly apply for an urgent injunction; that there were problems obtaining the central
paperwork; and that there was often a cautious approach taken on cases where the removal window was already


-----

428 (IAC)

open and/or that the client had limited paperwork”. The majority of respondents indicated that it was not their
understanding that unrepresented individuals could make requests for further time, although some answered yes,
indicating in their comments that such requests would not in any event be heeded. All respondents said that, for
clients within the removal window who were given a decision by the respondent refusing to treat further
submissions under paragraph 353 as a fresh claim, there was “generally insufficient” time between service of the
decision and actual removal to do anything of value.

112. Mr Hossain's statement describes further recent examples of individual cases. Overall, Mr Hossain considers
that these cases “illustrate a worrying tendency to maintain a removal window in place pending consideration of an
outstanding barrier”. In one case, EM, the respondent's decision was served on the same morning as the planned
removal. The decision was negative and EM was removed. Conversely, in the case of LM, a decision was made in
the evening before the date of planned removal. The decision was positive and removal was deferred. In both
cases, Mr Hossain says the individuals were not afforded any additional time to access the courts and that nothing
short of an injunction would convince the respondent to defer removal in such circumstances.

_Thakur Rakesh Singh_

113. Thakur Rakesh Singh of the PLP describes the background to the 72 hours' policy and the Medical Justice
litigation. He also describes the PLP's concerns regarding the original, open-ended removal window and certain
training slides produced by the respondent for the use of caseworkers.

114. Mr Singh's statement predates the publication of the current version of Chapter 60. It ends with a description
(together with exhibits) of four case studies. AT, a failed asylum seeker, had married a Gambian national with ILR in
the United Kingdom who was pregnant with his child when he was detained with a view to removal. He was unable
to secure legal advice prior to the opening of the removal window. He was unable to secure legal advice prior to his
removal to the Gambia.

115. MLF was detained for same day removal but was not allowed to have a telephone in order to contact a
lawyer. Although he tried to make a protection claim, he was told this had to be done by attending the Asylum
Screening Unit.

116. A suffered from severe mental health problems and was given a limited notice of removal. He was detained
but did not understand he was about to be removed. He was subject to same day removal despite the fact that his
condition precluded this.

117. Headley was unable to obtain access to legal advice whilst in detention with a view to removal. His wife,
however, contacted the PLP, who secured an injunction on his behalf.

_New evidence_

118. At the hearing on 25 July 2018, the applicants and the PLP sought to rely upon four items of new evidence: a
new report by Stephen Shaw CBE of July 2018 entitled “Assessment of government progress in implementing the
report on the welfare in detention of vulnerable persons”; The Joint Committee [of the House of Commons and
House of Lords] on Human Rights (JCHR) 10th report of Session 2017-19, “Enforcing Human Rights” (19 July
2018); an undated report from Refugee Action entitled “Tipping the Scales – Access to Justice in the Asylum
System”; and a report of July 2018 by BID entitled “Adults at Risk: The ongoing struggle for vulnerable adults in
detention – and the evaluation of the “Adults at Risk” Policy and Practice”.

119. The Tribunal gave directions, at the conclusion of the hearing, for the filing of written submissions in respect of
this new material. The respondent's submissions are dated 9 August 2018; those of the PLP are dated 21 August
2018; and those of the applicants are dated 31 August 2018. On 17 September 2018, the respondent submitted
the government's response to the JCHR report. The applicants and the PLP have made further written submissions
on the Government's response.


-----

428 (IAC)

120. The Shaw report recommends increasing internet access for detainees to enable them to pursue and support
their immigration claims as well as to prepare for their return home. Shaw considers that, overall, conditions in the
immigration detention estate have improved since his earlier review. Safeguarding teams do not have specific
enforced removal targets and value involuntary removals as much as enforced removals.

121. The JCHR report makes clear that there is concern about the scope of legal aid, which is the subject of a
[review currently being undertaken by government into the operation of the Legal Aid, Sentencing and Punishment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C45S-00000-00&context=1519360)
_[of Offenders Act 2012 (LASPO). The JCHR report identifies what it considers to be a new need for a broader](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C45S-00000-00&context=1519360)_
review into access to justice, immigration advice and assistance “going beyond matters which might be seen as
purely legal”. The JCHR report examined the Immigration Rules in the context of Article 8 ECHR claims. It noted
that non-asylum and immigration cases were taken out of the scope of legal aid, subject to narrow exceptions for
some applications by victims of domestic violence, trafficking and modern slavery. Applications for leave to enter
or remain based on Article 8 claims were amongst those taken out of scope. The report noted “striking examples of
how migrant children are affected”. It recommended that the government consider whether immigration cases
engaging Article 8 should be brought back within the scope of civil legal aid.

122. The government's response was that on 12 July 2018, the Minister responsible for legal aid announced an
intention to lay an amendment to the LASPO to bring immigration matters concerning unaccompanied and
separated children within the scope of legal aid. Otherwise, under current legislation, legal aid is said to be
available in all asylum cases for all age groups and for immigration cases “where someone is challenging a
detention decision. Legal aid for other immigration matters is available via the ECF Scheme, which is intended to
ensure legal aid is accessible in all cases where there is a breach of human rights”.

123. The Refugee Action report found that organisations working with vulnerable people were facing “huge barriers
to finding them government-funded legal assistance” and the “gaps in the legal aid provision exist across the
country, undermining access to justice for those claiming asylum”. No reference was made to Chapter 60.

124. The applicants point to passages in the report recording that over half of legal aid providers in the areas of
asylum and immigration were lost between 2005 and 2018 and that 21 dispersal areas for asylum seekers were
described as “advice deserts”.

125. The BID report, according to the respondent “makes clear that it is opposed to all immigration detention”.
Criticisms are made regarding those being held in prisons, rather than IRCs (which is not the case with either of the
present applicants).

126. Overall, the stance of the applicants towards the new material, upon which they seek to rely, is that this
“should be viewed in the round” and is “probative of the genuine difficulties faced by those in need of legally aided
advice and representation including those in immigration detention”. The PLP's stance is, essentially, to the same
effect.

**_F. Paragraph 353, SB (Afghanistan) and the “Hamid” jurisdiction_**

127. We have already encountered various references to paragraph 353 of the Immigration Rules. This provides
as follows:
**“Fresh Claims**

353. When a human rights or [protection] claim has been refused or withdrawn or treated as withdrawn under
paragraph 333C of these Rules and any appeal relating to that claim is no longer pending, the decision maker will
consider any further submissions and, if rejected, will then determine whether they amount to a fresh claim. The
submissions will amount to a fresh claim if they are significantly different from the material that has previously been
considered. The submissions will only be significantly different if the content:

(i) had not already been considered; and


-----

428 (IAC)

(ii) taken together with the previously considered material, created a realistic prospect of success, notwithstanding
its rejection.

This paragraph does not apply to claims made overseas.”

128. As established in the somewhat extensive case law (of which WM (DRC) v Secretary of State for the Home
Department [2006] EWCA Civ 1495 remains the most useful guide), it is for the respondent to determine whether
the requirements of a fresh claim had been made out, applying anxious scrutiny to the material, and asking himself
the question whether a hypothetical First-tier Tribunal could realistically allow an appeal brought by reference to it.

129. Paragraph 353A explains the consequences of making further submissions:
“353A. Consideration of further submissions shall be subject to the procedures set out in these Rules. An applicant
who has made further submissions shall not be removed before the Secretary of State has considered the
submissions under paragraph 353 or otherwise.”

130. The significance of paragraph 353A, for our purposes, lies in the fact that the respondent's policy is such that
he will not remove a person who has made submissions said to come within the ambit of paragraph 353, until those
submissions have been considered. There is no “cut off” point in the Rules, beyond which the obligation in
paragraph 353A ceases to apply.

131. We can now turn, as we said we would, to the case of SB (Afghanistan). The judgment of the Court of
Appeal, given by Lord Burnett of Maldon CJ, sets out the facts of SB's case, in considerable detail.

132. In essence, SB was detained and served with a notice of removal on 4 July 2017, which told him that he
would not be removed before 17.00 on 10/07/17 but that after this time and for up to three months he may be
removed without further notice. Representations by a firm of solicitors, acting for SB, were made on his behalf on
19 July 2017 but the respondent on 25 July decided that these did not constitute a fresh claim within paragraph
353. Removal directions were set for 26 August but the pilot of the aircraft due to fly to Istanbul refused to carry SB
and removal was aborted.

133. There was then press coverage of SB's abortive removal, which was said to have given rise to a sur place
asylum claim by him. On 7 September, the Kent Refugee Asylum Network (KRAN) contacted Duncan Lewis
Solicitors and asked if they would act for SB.

134. In the morning of 12 September 2017, SB was notified that he was to be removed by plane to Istanbul at
11.30am that day, for onward transit to Kabul. Representations made on SB's behalf by the journalist who had
been responsible for the press coverage were considered but rejected by the respondent in the morning of 12
September, with the decision letter being sent to Duncan Lewis. Again, the respondent took the view that the
submissions did not give rise to a fresh claim.

135. Just after mid-day on 12 September, the flight to Istanbul closed its doors, with SB on board.

136. Jamie Bell of Duncan Lewis and Mr Knight of Counsel, instructed by Duncan Lewis, prepared a judicial review
challenge in respect of SB's removal. This was based on the assertion that section 77 of the 2002 Act prohibited
SB's removal whilst an asylum claim was under consideration; paragraph 353A had similar effect; and that Chapter
60 stated that SB's removal window had, in fact, ended because he had made an asylum claim that had been
certified by the respondent.

137. As the Court of Appeal observed at paragraph 25 of its judgment, the assertion regarding certification and the
effect on the removal window was untrue. SB's Article 8 claim had not been certified by the respondent. Rather, it
had been rejected by the First-tier Tribunal on appeal. The grounds of claim suggested that the FtT had only
considered SB's case by reference to Articles 2 and 3 of the ECHR and the Refugee Convention.


-----

428 (IAC)

138. As a result, Morris J, who granted an interim injunction “out-of-hours” by reference to these grounds, did so as
a result of a mistaken representation on the part of those acting for SB.

139. Paragraphs 54 to 58 of the judgment needs to be set out in full:
“54. The making of last minute representations to the Secretary of State, which are claimed to amount to a "fresh
claim" for asylum or leave to remain for the purposes of para. 353 of the Immigration Rules, and the making in
parallel of an application for urgent interim relief to prevent the removal of an immigrant pending consideration of
those representations, can be highly disruptive of attempts by the Secretary of State to remove individuals who in
truth have no right to be here. Where a removal which is planned and in progress is stopped at the last moment,
there may be a significant delay before the Secretary of State can set up suitable new arrangements for removal.
Also, it is likely that the substantial cost of the aborted removal will be wasted.

55. The courts have had experience of some applications for interim relief being made by legal advisers where
there is no real merit in them, but as an abuse of process to disrupt the removal operations and to buy more time in
the UK for their clients. The courts have therefore already had occasion to give guidance emphasising the
professional obligations of legal advisers to make applications for interim relief to prevent removal promptly and with
a maximum of notice which is feasibly possible to be given to the Secretary of State: see, in particular, R (Madan) v
_Secretary of State for the Home Department and the_ _Hamid_ case, both referred to in the Administrative Court
Guide.

56. It is unnecessary to set out again in this judgment the guidance which has already been given so clearly in
those cases. We take this opportunity, however, to reiterate the importance of that guidance. The basic principles
are clear: (i) steps to challenge removal should be taken as early as possible, and should be taken promptly after
receipt of notice of a removal window of the kind which SB received on 4 July 2017 in this case; and (ii) applications
to the court for interim relief should be made with as much notice to the Secretary of State as is practicably feasible.

57. In the present case, the Secretary of State makes no suggestion that Duncan Lewis, Mr Bell and Mr Knight
acted deliberately to manipulate the court process to try to secure the non-removal of their client, SB, at the last
minute and then to secure his return to the UK. It appears to us that, having been instructed by SB very late in the
day, they acted honestly and in good faith under pressure of time to try to secure the non-removal of their client, in
circumstances where it appeared to them there were good grounds to seek to make "fresh claim" submissions
pursuant to para. 353 of the Immigration Rules, by reason of the new documents and the sur place press coverage.
Nonetheless, things were not done properly and we find it necessary to make some criticisms to which we will
return. But this case illustrates the particular difficulties which can arise when a new set of legal advisers come on
the scene at the last minute. The duty of candour is directed in the most part to ensuring that matters unfavourable
to the applicant are drawn to the attention of the judge. There are many late applications for injunctive relief which
are based on little more than an assertion that something may turn up if the new advisers are given time to
investigate. Such applications should get nowhere. Yet there is a strong imperative for those instructed late in the
day to make no representations or factual assertions which do not have a proper foundation in the materials
available to them. Gaps in knowledge should not be filled by wishful thinking. In almost all such cases there will
have been extensive engagement between the putative applicant and the immigration authorities and often the
independent appellate authorities. So too in many cases there will have been dialogue between the authorities and
previous lawyers. There will be a large reservoir of information available. Without access to that information it
behoves those who come on to the scene at the last minute to take especial care in the factual assertions they
make.

58. SB's position remains opaque. It is true that he has been subject to the restrictions inherent in being detained
to await removal. However, at no time has he provided any witness statement to explain when the new documents
were provided to KRAN and to him, how they came to be produced, when he was aware of the press coverage
about his case, why an application for interim relief was not made immediately the new documents and information
about the press coverage were available, and why he did not provide the full set of immigration decisions about his
case and copies of his judicial review application JR/7131/17 to Duncan Lewis when he instructed them in


-----

428 (IAC)

September 2017. This is so despite the Secretary of State calling for an explanation from him. SB has offered no
explanation for the delay in making an application for interim relief to prevent action pursuant to the removal notice
of 4 July 2017, after he had the new documents and the press coverage had occurred. He has offered no
explanation for failing to brief Duncan Lewis properly and failing to provide them with all the relevant documents in
his case. Nor is there any description of his dealings with his previous solicitors. The suspicion, at least, is that
there is no good explanation and that he deliberately sought to instruct Duncan Lewis late in the day and with
minimal information in the hope that he would maximise his chances of securing relief to prevent his removal.”

140. The Court of Appeal had this to say about paragraph 353A (section 77 of the 2002 Act):
“70. The two other grounds for relief relied upon are, first, that section 77 of the 2002 Act and para. 353A of the
Immigration Rules prohibited removal by reason of the representations sent by Duncan Lewis to the Secretary of
State by email at 11.19 am on 12 September and, secondly, the removal window had come to an end by virtue of
para. 2.1 of Chapter 60 of the EIG.

71. As to the first of these grounds, section 77 and para. 353A impose obligations on the Secretary of State not to
remove an individual in certain circumstances. They are both to be read in the public law context as obligations
related to fair and proper administration of the regime of immigration controls, which depend upon the Secretary of
State being given notice of an asylum claim at a time and in a manner which affords her officials a reasonable
opportunity to take on board that a claim for asylum has been made and to appreciate therefore that it is "pending"
(section 77); or that further submissions amounting to a human rights or protection claim have been made that
require consideration (para. 353A), so as to have a viable opportunity to take steps to comply with the obligations
so imposed. The obligations imposed by these provisions are not in the nature of strict obligations which apply
regardless of whether the Secretary of State has had a sufficient opportunity to examine a document received from
a person facing removal. It is only following proper consideration that the relevant official can reasonably be
expected to appreciate that it constitutes what can fairly be described as a claim for asylum; or can fairly be
described as "further submissions" to assert a human rights or protection claim. The nature of the task necessarily
involves the need to compare the new submissions with what has gone before. There needs to be time having
done so, for the Secretary of State of her own motion to stop a removal which was in the process of being carried
out in the event that the representations are accepted as satisfying criteria necessary to halt removal.

72.  It is not uncommon for voluminous late representations to be emailed to the Secretary of State very shortly
before removal is scheduled to occur. It should not be thought that they will operate as an automatic bar on
removal.

73. For present purposes, it is not necessary to examine in further detail what might be the limits to the obligations
in section 77 and para. 353A, because in our view it is clear that the sending by Duncan Lewis of the written
representations timed at 11.19 am on 12 September 2017 did not afford the Secretary of State a viable opportunity
to digest what was in that communication and then to put in motion the necessary steps to abort SB's removal then
in progress, on a flight scheduled to depart at 11.30 and in fact departing at 12.04.”

141. The Court of Appeal set aside the injunctive relief granted to SB by the High Court.

142. SB (Afghanistan) refers to the Administrative Court Judicial Review Guide 2017 in connection with the
“Hamid” jurisdiction. The relevant passages of the Guide are as follows:

“16.5 Abuse of the Procedures for Urgent Consideration

16.5.1 Where an application for urgent consideration or an out of hours application is made which does not comply
with this Guide and/or it is manifestly inappropriate, the Court may make a wasted costs order or some other
adverse costs order (see paragraphs 23.1 and 23.13 of this Guide respectively).

16.5.2 In R. (Hamid) v Secretary of State for the Home Department [2012] EWHC 3070 (Admin) (see paragraph
16.1.4 above) the Court held that where urgent applications are made improperly the Court may summon the legal


-----

428 (IAC)

representative to Court to explain his or her actions and would consider referring that person, or their supervising
partner (if different) to the relevant regulator. Examples (but not an exhaustive list) of applications which have been
held to be inappropriate under the Hamid rule are:

16.5.2.1 The claimant's solicitor had delayed making the urgent application until the last minute and had not
disclosed the full facts of the case in an attempt to use the urgent process to prevent his client's removal from the
UK.

16.5.2.2 The claimant's solicitor requested urgent interim relief against a decision that had been made three years
earlier.

16.5.2.3 A practitioner advanced arguments that his client was suicidal and psychotic when they knew or ought to
have known were false and/or inconsistent with their own medical evidence.

16.5.2.4 A practitioner lodged an application with grounds that were opaque and brief and failed to set out any of
the claimant's history of criminality.

16.5.3 Practitioners should be aware that the Court can identify those who are responsible for abusing the Court's
processes by making adverse costs orders (see paragraph 23.1 of this Guide) or by activating the Hamid procedure
outlined above which may lead to those practitioners being disciplined by their Regulator. If the Hamid procedure is
activated any orders made in relation to the referral may be published and placed in the public domain and any
such publication will include the explanation provided by the legal representative. Also see paragraph 12.10 of this
Guide on abuse of the Court's process. “

143. In R (Sathivel) v Secretary of State for the Home Department [2018] EWHC 913 (Admin) a Divisional Court
(Sharp LJ, Green J) gave judgment in related cases arising from the “Hamid” jurisdiction. The following paragraphs
are of particular relevance for our purposes:
“6. In 2018 the present Lord Chief Justice has expressed concern at the lack of the exercise of the duty of candour
on the part of practitioners in the context of last moment applications for injunctions to restrain removals. He also
reiterated the importance of the Hamid jurisdiction. See paragraph [20] below.

7. There are of course many highly professional practitioners in this complex and difficult field who successfully
reconcile the need to act in their client's interests with their duties to the Court. However, there is also a substantial
cohort of lawyers who consider that litigation is a tactic or strategy that can be used to delay and deter removal
proceedings.

8. We describe below some of the situations that too frequently confront the courts and tribunals.

9. First, most of the practitioners in this area do not have legal aid franchises. The clients are privately funded, and
they are frequently vulnerable and desperate. We sought information as to the level of fees demanded by the
solicitors in the cases before us. The sums vary; but they invariably run into multiples of thousands of pounds. To
raise funds to pay for legal assistance clients must often seek support from family and friends. The solicitors will
not generally act unless they are placed in funds beforehand. Some lawyers promise the highest quality of
representation and we have no doubt that there are solicitors and other representatives who do provide excellent
services. But there are other solicitors who having promised high quality specialist services then instruct paralegals
and unqualified persons to draft what would ordinarily be viewed as complex and specialised pleadings and court
documents (often prepared by counsel). The cases that are then advanced may be wholly lacking in merit. Judges
are presented with lengthy pleadings much of which is irrelevant and has been cut and paste from template
documents, often available on the internet.

10. Second, the incentive of some practitioners in initiating court or tribunal proceedings is simply to delay the
immigration process. They do this by exhausting every judicial or tribunal opportunity, irrespective of the merits of
the case. Buying time is valuable. Even a hopeless application or appeal takes time to determine and whilst that is
ongoing there is the possibilit of lodging repeat “fresh material” applications to the Home Office ith a ie to


-----

428 (IAC)

generating new Home Office decisions (rejecting the contention that there is fresh material relevant to the
applicants case) which then generates even more (unmeritorious) appeals which take up even more time to resolve
and allowing (yet again) yet more fresh material applications, and so on. It is commonplace for such cases to
continue for many years, and in extreme cases decades.  And the longer the case goes on the more scope there is
for an applicant to begin to develop an Article 8 “private life” claim, for example by getting married (sometimes
through a sham process) or having (or claiming to have) children. Where an applicant is detained pending removal
the longer that detention persists (which may be a consequence of the applications and appeals being pursued on
the individual's behalf) the greater the scope for the detained person to then argue on well-known “Hardial Singh”
grounds that it is no longer lawful to maintain detention. If a bail application succeeds the applicant might abscond.
Sometimes the applicant re-appears years later, and the process then starts again.

11. Third, when the Home Office sets a date and arrangements for removal a different dynamic sets in. Last
minute applications to restrain removal are made to the High Court, and often to the “out of hours” duty Judge
literally hours or even minutes before the removal flight departs the runway. Frequently the day before, or even the
day of, removal lawyers serve a new “fresh material” claim upon the Home Office and then argue before the duty
Judge that removal is unlawful pending determination by the Home Office of that new application and/or an appeal
therefrom. It is of the nature of these cases that the applicant may have been engaged in a Home Office and/or
appeal process for some years. There is often a lengthy history. However, what happens is that at the last moment
the applicant changes solicitors. The new solicitors draft the last-minute application seeking the restraining of
removal and they explain to the Judge that they have been instructed late on and that they have had no time to
obtain instructions (the client will be in detention). Frequently, the new lawyers do not have access to the prior
documentation and they have not (because of lack of time they argue) sought or obtained the documentation from
previous solicitors or the Operational Support and Certification Unit (“OSCU”) of the Home Office. For this reason,
arguments advanced to the Judge are based on details provided by the client who being in detention can give only
the barest of instructions over the phone. Judges complain that all too often the version of events provided to them
is materially inaccurate and/or incomplete. It is almost unheard of for the Defendant to be notified of the application
or to have a chance to advance submissions, even in writing.

12. All of the above scenarios are reflected in various ways in the facts of the cases before us. In the midst of all of
this it is crucial that the courts and tribunals retain the integrity of their processes. It is unacceptable that they
should be used as part of a continuing game played between applicants and the Home Office. If the processes of
the Court and tribunals are abused in this manner then those individuals who do, genuinely, have proper cases to
advance (and there are many) find that they sit in a long queue waiting to be heard. The judges who should be
devoting their time to resolving genuine and important disputes are distracted dealing with abusive cases. Justice is
delayed and can be denied.”

**_G. Discussion_**

(a) The primary position of the applicants and the PLP

144. Anufrijeva concerned the issue of whether income support should have been paid to the appellant between
particular dates. That depended upon whether, before the first of those dates, she had ceased to be an asylum
seeker. That in turn involved the question whether on or before the earlier date her claim for asylum had been
“recorded by the Secretary of State as having been determined (other than on appeal)” within the meaning of
particular regulations. Lord Steyn, with whom the majority of the House agreed, explained that the issue
crystallised into how the relevant regulations should be interpreted and whether “Parliament intended to authorise
the withdrawing of income support by an internal note on a departmental file with legal effect from a date before
notification of the decision” (paragraph 21).

145. At paragraph 25, Lord Steyn endorsed the observation of the Court of Appeal, concerning the interpretation of
the relevant regulation:
IMAGE NOT AVAILABLE


-----

428 (IAC)

146. This led Lord Steyn to hold as follows:
“26. The arguments for the Home Secretary ignore fundamental principles of our law. Notice of a decision is
required before it can have the character of a determination with legal effect because the individual concerned must
be in a position to challenge the decision in the courts if he or she wishes to do so. This is not a technical rule. It is
simply an application of the right of access to justice. That is a fundamental and constitutional principle of our legal
system …”

147. The applicants and the PLP contend that Anufrijeva means that the applicants have a legal right to be notified
of the removal directions that must be made pursuant to section 10 and Schedule 2, in order for actual removal to
be effected, and that notification of the removal window cannot constitute such notice.

148. One response that might be made to this submission is that the decision to refuse asylum was one that
affected the legal status of Ms Anufrijeva. If she had succeeded in her asylum claim, she would, as a refugee, have
had the rights that flow from the Refugee Convention. In accordance with the respondent's policy, she would have
been given leave to remain in the United Kingdom.

149. The making of a decision under section 10 of the 1999 Act is not of the same character. It can be made only
where the individual concerned has no leave to enter or remain. The decision does not, in short, alter an individual's
status, either directly or indirectly.

150. Although Mr Kovats QC did not advance such a response as a means of distinguishing Anufrijeva, it touches
on the following broader point. A person who receives an adverse decision from the respondent and who either
does nothing about it or appeals it unsuccessfully to the Tribunal, can in general be expected to know that he or she
lacks leave to enter or remain and so needs to depart the United Kingdom. If the person has been given a notice
under section 120 of the 2002 Act, he or she will also have been informed of the need to let the respondent know,
as soon as reasonably practicable, if the person's circumstances subsequently change, so as to give rise to
additional grounds for being permitted to enter or remain and/or for resisting removal.

151. The legislative scheme does not, therefore, confer any expectation that such grounds can be withheld until
steps are taken to remove; quite the opposite. This point needs to be kept in mind in considering the operation of
the principle of access to justice in the context of Chapter 60.

152.  Mr Kovats QC's response to Anufrijeva was that the circumstances of the present cases and those of
Anufrijeva are not remotely analogous. We agree. In order to be analogous, the respondent's policy in the present
cases would have to involve putting the applicants onto an aircraft in order to remove them from the United
Kingdom, without any prior notice that the respondent intended to remove them. That is manifestly not the position.
The form RED.0001 is, as its heading explains, a notice of removal which can take place at any point during the
window. A person who is given a RED.0001 is, accordingly, in nothing like the position of the appellant in
Anufrijeva. That case is not authority for the proposition that notice of an administrative decision has to be made in
a particular way; or in particular circumstances, regardless of the nature of the decision.

153. In oral submissions, the applicants and the PLP said that, if one compares the present version of section 10 of
the 1999 Act with that which existed prior to its replacement by the _[Immigration Act 2014,one sees that, for our](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
purposes, nothing very much has changed. In both the old and new versions of section 10(1), a power of removal
is given by the legislature.

154. In fact, that is not quite right. The old section 10(1) provided that “A person who is not a British citizen may be
removed from the United Kingdom, in accordance with directions given by an immigration officer”, if certain
circumstances existed. By contrast, the new section 10(1) provides an entirely free-standing power of removal,
under the authority of the Secretary of State or an immigration officer, in respect of a person who requires leave to
enter or remain but does not have it. It is not until one reaches subsection (7) of the section, in its new incarnation,
that one sees the Secretary of State or an immigration officer being given the power to make removal directions “for
the purposes of removing a person … under subsection (1) …”.


-----

428 (IAC)

155. That said, we are doubtful whether anything of substance turns on these differences and we accordingly
agree with the applicants and the PLP that the respondent cannot derive any material support for his removal
window policy from the change in the wording of section 10. Indeed, Mr Kovats QC did not seek to argue to the
contrary.

156. The real point at issue is whether the respondent can operate a removal window policy, whereby a person is
informed of a decision to remove, to take place during a specified timeframe. We have held that Anufrijeva does
not prevent this. We must now look at the other cases relied upon by the applicants and the PLP.

157. UNISON concerned the statutory instrument which imposed requirements to pay significant fees in order to
bring and conduct claims before Employment Tribunals and the Employment Appeal Tribunal. Having held that the
“constitutional right of access to the courts was inherent in the rule of law” (paragraph 66) and that “the value to
society of the right of access to the courts is not confined to cases in which the courts decide questions of general
importance” (paragraph 71), the Supreme Court noted “many examples … of judicial recognition of the
constitutional right of unimpeded access to the courts” (paragraph 76), before holding as follows:
“87. The Lord Chancellor cannot … lawfully impose whatever fees he chooses … . It follows from the authorities
cited that the Fees Order will be ultra vires if there is a real risk that persons will effectively be prevented from
having access to justice. That will be so because section 42 of the 2007 Act contains no words authorising the
prevention of access to the relevant tribunals. That is indeed accepted by the Lord Chancellor.

88. But a situation in which some persons are effectively prevented from having access to justice is not the only
situation in which the Fees Order might be regarded as ultra vires. As appears from such cases as Leech and Daly,
even where primary legislation authorises the imposition of an intrusion on the right of access to justice, it is
presumed to be subject to an implied limitation. As it was put by Lord Bingham in Daly, the degree of intrusion must
not be greater than is justified by the objectives which the measure is intended to serve.

89. There is an analogy between the latter principle and the principle of proportionality, as developed in the case
law of the European Court of Human Rights. These proceedings are not based on the _[Human Rights Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
_[1998,since the appellant is not a “victim” within the meaning of section 7(1) of that Act. Nevertheless, the case law](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
of the Strasbourg court concerning the right of access to justice is relevant to the development of the common law.
It will be considered in the context of the case based on EU law, on which it also has a bearing. To anticipate that
discussion, however, it is clear that the ability of litigants to pay a fee is not determinative of its proportionality under
the Convention. That conclusion supports the view, already arrived at by the common law, that even an
interference with access to the courts which is not insurmountable will be unlawful unless it can be justified as
reasonably necessary to meet a legitimate objective.”

158. At paragraph 91, the Supreme Court held that on the “evidence now before the court, considered realistically
and as a whole” the fees in question had not been set at a level that everyone could afford, in order to access the
tribunals, taking into account the availability of full or partial remission. “The question whether fees effectively
prevent access to justice must be decided according to the likely impact of the fees on behaviour in the real world”
(paragraph 93).

159. Looking at the matter in EU terms, a reference to the Charter of Fundamental Rights of the European Union,
the Court observed “the emphasis placed by the Strasbourg Court on the protection of rights which are not
theoretical and illusory, but practical and effective. This is consistent with the recognition in domestic law that the
impact of restrictions must be considered in the real world” (paragraph 109).

160. Before us, there was considerable dispute, in the course of oral submissions, as to whether any interference
with access to justice had to be specifically authorised by primary legislation, in order for it to be lawful, or whether
there is scope for saying that interferences which are not insurmountable may be lawful, without express wording, if
these can be “justified as reasonably necessary to meet a legitimate objective”, in the words of paragraph 89 of
Lord Reed's judgment in UNISON. In this regard, Ms Kilroy seized upon Mr Kovats QC's acceptance in the course


-----

428 (IAC)

of his oral submissions that Chapter 60 constitutes a restriction of access to justice, albeit that he said this was
proportionate.

161. It is, in our view, impossible to extrapolate from UNISON a universal proposition of what, precisely, access to
justice entails, regardless of the particular circumstances. Not only is there no suggestion in the judgments that the
Supreme Court embarked upon such a task; it would have been doomed to failure. This is because the question of
what access to justice entails depends upon the circumstances in question.

162. It is an integral feature of a power of removal, such as that conferred by section 10 of the 1999 Act (and the
deportation powers in the 1971 Act) that, if a person is to be removed under the power, the point must come when
his or her ability to access the courts and tribunals of the United Kingdom, in order to prevent the removal, will
disappear; and that, by the same token, during the period leading up to removal, that person's ability to access the
courts and tribunals will be progressively diminished. It is quite manifest, in our view, that section 10 authorises
such a state of affairs. If it did not, then the power of removal would effectively become meaningless.

163. The correct approach, therefore, is to view the respondent's policy, as contained in Chapter 60, as an attempt
by the respondent to articulate an appropriate relationship between access to justice and what are the inevitable
consequences of the power to remove a person from the United Kingdom.

164. Seen in this light, the power of removal is, in some respects, analogous to the powers contained in the rulemaking legislation of the courts and tribunals to impose time limits for bringing and progressing legal proceedings.
All such time limits are, obviously, a restriction on access to courts and tribunals. The question is whether such
time limits (and the associated relief from sanctions) are reasonably necessary, in the particular circumstances of
each type of case.

165. For this reason, we reject the submission that UNISON dooms the respondent's case to failure. We must,
therefore, turn to the Medical Justice cases. We have referred to this litigation above.

166. We reject the submission of the applicants and the PLP that the Upper Tribunal is bound by the principle of
_stare decisis to find that the removal window policy of the respondent is unlawful because it enables removal_
directions to be given to a person on less than 72 hours' notice. Medical Justice held that, on the evidence before
Silber J, the exceptions to the 72 hours' notice policy were unlawful. The position now is that the notification
process, as set out in RED.0001, provides at least 72 hours' notice of an intended removal during the removal
window period. Neither Silber J nor the Court of Appeal was required to consider the removal window process set
out in Chapter 60 and RED.0001, for the simple reason that it did not exist. This Tribunal is not, accordingly, bound
in the way which the applicants and the PLP contend.

167. The true effect of form RED.0001 is, we find, properly identified in the first statement of Mr Toufique Hossain
of Duncan Lewis. At paragraph 14(i), Mr Hossain describes the difficulties that his firm has encountered in
persuading the Administrative Court Office to seal claim forms on the same day where a notice of removal window
is provided. According to Mr Hossain, the clerks at Duncan Lewis “have reported that the problem arises because
the court staff do not appreciate that the notice of removal window is a form of removal directions and therefore
such applications are urgent”. As will be evident, we regard that description as entirely accurate: form RED.0001 is
a notice of removal.

168. At paragraph 14(iv) of the same statement, Mr Hossain notes that many legal representatives “are by now
aware that as the client can be removed from the date the window opens, that date should effectively be treated as
the date of removal”. Again, that is exactly how everyone concerned should view the position.

(b) 72 hours' notice period preceding the opening of the removal window

169. The applicants and the PLP submit that Silber J in Medical Justice did not make a finding that the 72 hour
notice period in respect of removal directions was lawful; merely, that nothing in his judgment should be taken to


-----

428 (IAC)

suggest that it was not. By the same token, they say, there is nothing in the judgment of the Court of Appeal that
provides support for the respondent on this issue.

170. We have seen from the evidence of Ms Dolby how the 72 hour notice period came about. Its pedigree is by
now a long one, judged by reference to the dynamic nature of immigration law and practice. Whilst we agree with
the applicants and the PLP that the Medical Justice cases do not contain any actual approbation of the 72 hours
policy, the fact that it was not challenged in that litigation or subsequently is, nevertheless, of some relevance.

171. The applicants and the PLP relied heavily upon the changed legal aid landscape, compared with 2010, in
order to advance the argument that 72 hours is not, now, adequate. As we have seen from the evidence, instances
are given where difficulties have been encountered in a detainee being able to access legal advice, whether
through a surgery in the IDC in which he or she is held, or otherwise. The questionnaire answers exhibited to
Toufique Hossain's second statement provide additional support in this regard. The applicants and the PLP also
relied upon the new evidence, including that of the JCHR report.

172. We have considered all the evidence carefully. We find that the respondent has demonstrated that the 72
hour period, as set out in Chapter 60, and which is subject to the exceptions contained therein for provision of
additional time in certain circumstances, constitutes a reasonable and proportionate response to the need to give
effect to access to justice in cases of removal from the United Kingdom.

173. So far as concerns the position regarding legal aid, we agree with Mr Kovats QC that, to a very significant
extent, this matter lies outside the remit of the present proceedings. The reductions that have occurred in the
availability of legal aid do not mean that an individual facing a removal is simply not able to engage a lawyer.

174. As we have seen from the “Hamid” cases and also from the applicants' witnesses, many who face removal
are, in fact, able to secure legal advice and assistance privately. The fact that some of those who provide such
services might do so in a professionally problematic manner does not mean that is true of the majority. The right of
access to justice does not include a right to see a lawyer who is the best or amongst the best the legal profession
has to offer. Still less does it include a right to resist removal indefinitely whilst a lawyer is identified who is willing to
take on the case, even though it may be an extremely weak one. That, however, seems to be the implication of
Mariah Carey's and Sian Evans' evidence. Sheona York's statement regarding the difficulty of finding a lawyer who
will not fall foul of the “Hamid” criticisms ignores the fact that, if there is even an arguable case to resist removal,
any lawyer should be able to put that case forward. What matters are the underlying merits (or lack of them).

175. There is no correlation, we find, between the criticisms in the witness evidence regarding the alleged adverse
effects of a lack of legal aid, and the suggestion of the applicants that a five day, rather than 72 hour, notice period
would be acceptable. Some of the evidence suggests that individuals have spent far longer than five days seeking
legally-aided assistance.

176. Mr Kovats QC categorised much of the evidence advanced by the applicants and the PLP as anecdotal. The
fact that this is so is not necessarily to be taken as a criticism of the witnesses who gave it. Rather, it is a function
of the fact that, by the time very many individuals find themselves in receipt of form RED.0001, they will already
have had legal representatives acting for them, but will nevertheless have failed in their appeals before the First-tier
Tribunal and become “appeal rights exhausted”. Many of the witnesses encounter the individual only at this point.

177. As is strikingly borne out in the judgment of the Court of Appeal in SB (Afghanistan) and in the judgment of the
Divisional Court in Sathivel, at this point, individuals who have previously had professional legal assistance
frequently switch to a new representative. The latter will often be unaware of the detailed immigration history of the
individual in question, including, importantly, the individual's interactions with courts and tribunals. That, however,
is not in itself a good reason for extending the 72 hour period, across the board.

178. Much of the applicants' evidence suffers from this difficulty. It pays no or insufficient regard to whether the
individual has had a legal adviser in the past; if so, when; and whether there has been any undisturbed judicial
pronouncement about issues that the individual is seeking to rely upon in order to defeat removal.


-----

428 (IAC)

179. Nicola Burgess seems to propose that the making of submissions in terms of paragraph 353 of the
Immigration Rules should have the effect of closing the removal window. That, however, would render the policy a
dead letter. As is evident from what we have said regarding the narrowing of access to lawyers, courts and tribunals
as removal draws near, the respondent must be able, in certain circumstances, to remove a person immediately
after a decision is made on such submissions or, in certain cases, before very belated submissions are even
considered: see SB (Afghanistan).

180. Thakur Rakesh Singh's case studies do not demonstrate a need to extend the period of 72 hours. As is plain
from the judgment of the Deputy Judge in AT's case, there was a “straight conflict of fact with regard to the issue of
the removal and whether sufficient notice was given. It is not a conflict I am in a position to resolve” (paragraph 95).
For the purposes of her judgment, the Deputy Judge found it neither necessary nor appropriate to determine the
issue (paragraph 96). In the case of A, William Davis J found that, although he could understand why the
respondent has the policy she does, it was at least arguable she had failed to apply it properly in A's case, given
that A's condition was such that he should not have been given a removal window decision (paragraphs 24 to 26).
In the case of Headley, which was settled by consent, there was an unusual factual issue as to whether the
claimant had indefinite leave to remain in the United Kingdom.

181. The applicants and the PLP contend that all their evidence needs to do is disclose some reliable instances
where the relevant time limits have prevented an individual's access to a lawyer. Once this is done, there will be a
real risk that access to justice is being unlawfully interfered with by Chapter 60. They rely in this regard on Medical
Justice and UNISON.

182. We do not accept this submission. If it were correct, then rules prescribing time limits would be at risk if it
could be shown that relief from sanction was wrongly withheld in a particular case. Unlike Medical Justice, in the
present cases Mr Kovats QC challenged the witness evidence, albeit in the broad sense of categorising it as
anecdotal. Having conducted our own analysis, we have concluded that the evidence (including the responses to
the questionnaire), taken in the round, does not show that the provisions in Chapter 60 regarding time limits are
operating in such a way as to amount to an unlawful restriction on access to justice.

183. We agree with Mr Kovats QC that neither FB's nor NR's case demonstrates that they were denied access to
justice by reference to operation of Chapter 60. FB had lost an appeal against refusal of international protection, as
long ago as February 2011, following which he was removed to Afghanistan. In October 2017, however, he
appeared at Wembley Police Station. On 5 October 2017 he was given more than 72 hours' notice of the start of
the removal window. FB had attended a legal surgery at Campsfield House on 3 October. We are not told whether
he showed the solicitor at the surgery the notices with which he had been served. We agree with the respondent
that the length of time it took FB to put forward a fresh protection claim was, in the circumstances, excessive.

184. NR claimed to have arrived in the United Kingdom in 2007 and had been through the Tribunal appeal process
no fewer than three times, before he made further representations to the respondent. By the time he was detained
for removal in January 2017 (after which he submitted yet more representations), NR had had the benefit of legal
assistance from a number of different sets of representatives. His apparent decision, in 2015, to move from
Duncan Lewis to another firm has not been explained. NR subsequently blamed that other firm for shoddy work on
his behalf. Such an allegation is, however, easily and often made in this jurisdiction and there is no evidence that
the firm in question has been given an opportunity to respond. The same is true of another firm, about which NR
also complains. Overall, we find that NR has not been denied access to justice, by reference to the operation of
Chapter 60.

185. In the applicants' evidence, the suggestion is made that SB (Afghanistan) is supportive of their case, in that,
since the tight timescales are imposed on representatives by the respondent, those representatives should not be
criticised for what happens or fails to happen at the last minute.

186. We can find no merit in this suggestion. As we have said, with any power of removal, there will inevitably
come a time when an individual is at the point of removal. Short of having a rule that precludes any submission
being made by or on behalf of the individual at that point (which would be problematic not least because of section


-----

428 (IAC)

6 of the Human Rights Act 1998), it must in theory be possible to assert, up to the last minute, that removal should
not go ahead. But that does not mean the individual is entitled, at that point, to have a lawyer advance any case the
individual sees fit to put; nor does it mean a lawyer will avoid judicial or professional censure for advancing a case
that is hopeless and/or in breach of the duty of candour.

187. On a related matter, the suggestion by the applicants and the PLP that all these issues can be dealt with by
means of professional regulation ignores the fact that the respondent's policy must deal with those who do not, for
whatever reason, use a lawyer at this stage.

188. We reject the challenge brought to the so called “same day removal” policy, otherwise known as Operation
Perceptor. We are satisfied from the evidence that this policy is, in fact, a justifiable aspect of the overall removal
window regime. The safeguards described in the respondent's evidence, including giving the individual access to a
telephone to contact legal representatives, etc are, in our view, reasonable and proportionate. We note from the
applicants' evidence that there may have been some failures in this regard. Again, however, the evidence does not
begin to show a real risk to access to justice.

(c) Is Chapter 60 nevertheless deficient in any respect?

189. The fact that we have found in favour of the respondent in respect of (a) and (b) above does not dispose of
the challenges brought by the applicants and the PLP. We therefore turn to what Ms Naik QC and Ms Kilroy had to
say about specific aspects of the current version of Chapter 60. In doing so, we have also had regard, once more,
to the witness and report evidence.

190. As we have seen, Mr Hossain makes reference to misunderstandings on the part of the Administrative Court
Office and other legal representatives, concerning the nature and significance of the opening of a removal window.
We do not consider that these matters demonstrate any legal deficiency in Chapter 60. Rather, they are to be seen
as demonstrating a likely need for relevant training in this area.

191. By the same token, the incidences given in the evidence of mistakes on the part of the respondent's
caseworkers in the operation of Chapter 60 come nowhere near demonstrating that the system is materially flawed.
Few if any systems work perfectly at all times and there is a dearth of evidence to show systematic failures are
occurring. Thus, for example, William Davis J, in holding that A should not have been given a notice of removal
window, given the state of his mental health, did not question the underlying policy; what concerned him was the
failure to apply it properly.

192. Ms Dolby's evidence explains the public benefits of the removal window policy. The fact that using a removal
window, rather than relying upon removal directions, requires there to be certain exceptions does not mean the
policy is thereby flawed to the point of unlawfulness.

193. Criticism is made of the section headed “Consideration of deferral of notice period” on the ground that the
respondent's caseworkers are given what is said to be inappropriate discretion in a number of areas.

194. First, in the beginning of the section, the caseworker has to consider each case for deferral on its individual
merits by reference to whether the person concerned has had a reasonable opportunity to access legal advice and
recourse to the courts.

195. A caseworker is also given the function of deciding whether to “defer removal” on the basis that the individual
has changed legal representative. Factors are set out, weighing for and against the exercise of discretion in the
individual's favour in this matter.

196. On the issue of access to legal advice in detained cases, the caseworker is, again, required to exercise
discretion, on an individualised basis, by reference to various matters, such as whether the request for legal advice
was made at the earliest reasonable opportunity.


-----

428 (IAC)

197. Finally, regarding documentation it is said to be in general reasonable to provide all relevant documents to
representatives although it is reasonably to be expected that, unless there has been a change of representative,
documents previously provided to an individual and/or their representative should have been retained. This means
that the caseworker may “reasonably request representatives to be specific in their request”. A request to release
all case papers, whatever their relevance, is said not to be reasonable and should be challenged.

198. There is, we find, nothing unlawful in the existence of these discretionary functions. The existence and history
of paragraph 353 and 353A constitute a good illustration of the way in which, as removal draws near, the
respondent's officers will be taking decisions which there will (quite lawfully) be little or no time to challenge or
otherwise question, before removal takes place. As we have said, that is an essential element of the removal
power.

199.  It is also noteworthy that similar discretionary decisions fall to be made in the part of Chapter 60 entitled
“When judicial review proceedings will not suspend removal”. This part has not been challenged by the applicants
or the PLP. Here, caseworkers must determine whether a previous judicial review or statutory appeal “has been
concluded on the same or similar issues”; whether a previous judicial review or statutory appeal has been
concluded “on the same evidence” even though the legal basis of the challenge is “different from that previously
brought”; and whether the current judicial review raises issues that “could reasonably have been raised at a
previous judicial review or statutory appeal”.

200. Given the point in the process that the decisions described in paragraphs 189 to 192 must be taken, they
plainly need to be dealt with by caseworkers who are in a position to know about both (a) the individual's
immigration history, including judicial decisions and previous interactions with lawyers; and (b) the individual's
present circumstances. The nature of the power of removal is such that, at this point, rapid decisions may need to
be made. The fact that these decisions touch upon access to justice issues does not mean they should be removed
from the relevant caseworkers or set in terms that are likely to be difficult to understand or apply.

201. By the same token, we are not persuaded that there is anything unlawful in the formulation of the third bullet
point under the heading “Those not suitable for removal window”, which relates to the Home Office having
evidence, beyond a self-declaration, that a person is suffering from a condition listed as a risk factor in the Adults at
Risk in Immigration Detention Policy or other condition that will result in the person being regarded as an adult at
risk under that policy. The applicants' witness evidence complains that this effectively puts the onus on the
individual. As regards individuals who are not in detention, that is entirely right. Unless and until a caseworker has
reasonable cause for concern (which may arise from his or her own observations of the individual), a person who is
not in detention will need to provide some evidence in this regard. So far as concerns persons in detention, the
position is somewhat different. The respondent owes them a significant duty of care which may, depending on the
facts, require a degree of proactivity on the respondent's part.

202. So far, we have not accepted the challenges made to the detailed provisions of Chapter 60, relating to
removal windows. We now turn to matters on which we agree with the applicants and the PLP.

203. Toufique Hossain, in his statements, criticises the terminology used in the section entitled “Consideration of
deferral of notice period”. In the first paragraph, reference is made to “deferring the removal window for an
additional period”. The second paragraph refers to each “case for deferral”. Under the heading “Change of legal
representative” he said that it may be reasonable “to defer removal for an additional period”. Under the heading
“Access to legal advice: detained cases”, it is said that “the removal window should normally be deferred”.

204. We find that there is a serious issue with the terminology concerning deferral. This goes beyond mere
linguistic quibbles and amounts to arbitrariness. There needs to be precision as to what is being deferred. If, as we
suspect is the intention, it is the commencement of the removal window, then that must be made plain. We also
agree with the applicants and the PLP (and their witnesses) that if the commencement of the removal window is to
be deferred, the individual (and his or her legal adviser, if there is one) must be given a written notice, which must
state when the removal window is to open and confirm that length of that window (lest there be any
misunderstanding as to whether the deferral “eats into” that period) The period before the window opens is as we


-----

428 (IAC)

have seen, a crucial one, since it is during it that the individual is expected to seek legal advice, if wanted. The
period is also important to the High Court and the Upper Tribunal in deciding whether a case is suitable for daytime
or out of hours “immediate” consideration.

205. We also agree with the applicants and the PLP that there is a material problem regarding the relationship
between the information regarding the place of removal, as set out in RED.0001, and what might feature in the
removal directions issued to a carrier etc during the removal window. Although RED.0001 will specify transit points
outside the EU, which are proposed to be used in returning the individual to a particular country, the applicants and
the PLP rightly point out that, in a case involving removal to a “safe” part of a country to which the individual may
otherwise have justified concerns about returning, it is not appropriate for the individual only to learn precisely
where he or she is to be sent within that country, upon receipt of removal directions, of which there will not
necessarily be any advance notice.

206. In this regard, the respondent cannot, we find, have it both ways. If, as we have found, the notice of removal
window is a sufficient notice of removal to render it unnecessary, as a general matter, to give any further advance
notice, then the relevant information about place and route needs to be given in RED.0001. We are not satisfied
that, as matters currently stand, the Chapter 60 policy deals lawfully with this issue.

207. The final matter with which we need to deal is the length of the removal window. Paragraph 11 of Ms Kilroy's
written submissions on behalf of the PLP reads as follows:
“11. … the provisions for extension of the removal window for up to four months, and subsequent referral for further
3 – or 4 – month period, mean that a person subject to the removal window policy may be liable to the same-day,
no-notice removal for many months, or even years, with only short periods of immunity from removal for 72 hours/7
days every 3 or 4 months. In other words, the Policy envisages that in a period of four months and subsequently for
a further three-or four-month period the individual may be exposed to the risk of limited or same day removal for
119 days out of 122 days, and that it would be possible in a period of a year to be exposed to same day removal for
356 out of 365 days. This could be the case even if the individual last had access to a court years earlier, and their
circumstances could have drastically changed.”

208. Professor Katona, Dr Bell and Ms Schleicher all expressed concern that the effects of being subject to a
removal window may have on an individual; particularly someone with vulnerabilities. As we have seen, the
respondent's policy makes provision for excluding persons with vulnerabilities from the removal window regime.
Despite the criticism advanced, we find that provision to be a lawful response, in that it provides an effective (albeit
not perfect) mechanism for taking such cases out of the removal window process.

209. However, paragraph 11 of Ms Kilroy's written submissions suggests that, as currently framed, Chapter 60 is
little different from the entirely open-ended regime from which the respondent retreated in 2015, following receipt of
a pre-action protocol letter from the PLP on behalf of Medical Justice.

210. The other point to note is that, the longer the removal window lasts, the greater will be the possibility of the
individual's circumstances undergoing a material change, as regards his or her Article 8 or international protection
position.

211. On its face, therefore, paragraph 11 appears to identify a problem. Unfortunately, however, our attention was
not drawn to the respondent's General Instructions (Liability to administrative removal non-EEA: Consideration and
notification (Version 3.0), published on 6 April 2017. This describes RED.0004 (Fresh) as a form which is served
when a new three month removal window is being set and that it “must only be served where there is a realistic
possibility of removal within the new period”.

212. The same document gives the following instruction to caseworkers regarding Form RED.0004 (Extension)
which, as its name implies, is used to extend the window by 28 days: “When it is known that removal is unlikely to
take place within 28 days you must not serve a RED.0004, instead allow the removal window to lapse. When it
then becomes known that removal is likely within a three month period serve a new RED.0004 (Fresh)”.


-----

428 (IAC)

213. It also appears from the document that RED.0004 (Fresh) “must not be used to keep the window open _ad_
_infinitum, but to extend it where removal is expected within that period, for instance, where removal is being re-_
arranged following a delay in receiving a travel document”.

214. It is regrettable that the parties did not draw the Tribunal's attention to these general instructions, since their
existence ameliorates the position described in paragraph 11 of Ms Kilroy's submissions; in particular, the
statement that the window should not be kept open ad infinitum.

215. In these circumstances, we do not consider that it is appropriate in these proceedings to grant any relief
concerning the matters raised in paragraph 11. The Tribunal will, however, expect the respondent to have serious
regard to whether a stronger test is necessary than that of a “realistic possibility of removal”, within the new or
extended period.

216. We grant permission to bring judicial review proceedings. We do not consider it necessary to quash any of the
respondent's decision-making in the case of FB or NR, whose challenges thereto are academic. The applicants
succeeded in resisting removal and have obtained access to justice. We have, however, found that aspects of
Chapter 60 are unlawful, for the reasons given in paragraphs 204 to 206 above. We will hear counsel on the issue
of relief and the form of any order.

**Direction Regarding Anonymity – Rule 14 of the Tribunal Procedure (Upper Tribunal)**
**Rules 2008**

Unless and until a Tribunal or court directs otherwise, the applicants are granted anonymity. No report of these
proceedings shall directly or indirectly identify them or any member of their families. This direction applies both to
the applicants and to the respondent. Failure to comply with this direction could lead to contempt of court
proceedings.

IMAGE NOT AVAILABLE

The Hon. Mr Justice Lane

President of the Upper Tribunal, Immigration and Asylum Chamber

**Postscript**

1) After the draft judgment was provided to the parties, on a confidential basis, the applicants suggested that the
procedural history of the Chapter 60 policy, as set out in the judgment, should be expanded in a number of respects
and that the applicants did not, in fact, accept that it was only the latest form of the policy which required to be
substantively examined in the proceedings (see paragraph 6 above).

2) We do not consider that it is appropriate at this point to accede to the applicants' suggestion. As the Tribunal's
directions of 4 October 2018 made plain, the purposes of circulating the draft judgment were strictly limited.
Circulation was not intended as an opportunity for the parties to suggest substantive re-writing.

3) Whether the previous version of the policy was unlawful may, of course, be relevant to the issue of costs, as to
which we shall hear submissions.

4) The PLP suggested certain changes to the Tribunal's description of Chapter 60 (which is, in any event, set out in
full in the Annex to the judgment); and the insertion of a comment regarding the quotation in paragraph 122 of the
judgment. Again, these suggestions went beyond the purposes of circulating the draft.

5) The PLP also submitted a note regarding the fact that the Tribunal's attention was not drawn to the instructions
described in paragraph 211 of the judgment. The Tribunal entirely accepts that counsel for PLP was unaware of the
instructions.


-----

428 (IAC)

**ANNEX**

Immigration returns, enforcement and detention

General Instructions

**Judicial reviews and injunctions**

**Version v15.0**

Contents

Contents 2

About this guidance 5

Contacts 5

Publication 5

Changes from last version of this guidance 5

Judicial reviews explained 6

Event types subject to JR 6

Pre-action protocol 6

Quick guide to Judicial Review process 8

Notice of removal 9

Notice of a removal window 9

Those not suitable for removal window 11

Notice of removal directions 11

Limited notice of removal 12

The notice period 12

Normal enforcement cases (administrative removal and deportation) 13

Consideration of deferral of notice period 14

Change of legal representative 14

Access to legal advice: detained cases 15

Access to relevant documentation 15

Deferral of removal 16

Claim form issued with detailed grounds 16

Claim form issued with statement of reasons for non-compliance with the Practice Direction 16

Out of hours claims prior to lodging with the court 16


-----

428 (IAC)

Withdrawing an application for judicial review 17

Cases where the removal window should not be used 17

Removal window used but found to be inappropriate 17

Family cases 17

Third country and Non-suspensive appeal (NSA) cases 18

Special arrangements (including charter flights) 19

Where standard notification may not be required when giving notice of removal 20

Exceptions to standard notification of removal 20

Port cases 20

Third country and NSA family cases subject to Ensured Return 20

NSA cases already reviewed by JR or following a failed removal 20

Where a second period of notification is not needed 21

Threat of judicial review 23

Special arrangements (including charter flights) 23

Port cases 23

When judicial review proceedings will not suspend removal 24

The qualifying criteria 24

When JR proceedings will always suspend removal 24

The merits and barrier tests 25

Is the JR bound to fail (the “merits test”)? 25

Are the issues raised in the JR a barrier to removal? (“the barrier test”) 25

Summary of process 26

Family cases 27

Fresh claims and/or further submissions 28

Handling JRs involving simultaneous injunction applications 30

Action when suspending removal 30

Action following a decision not to suspend removal 30

Process map 31

Stayed cases 32

Lead case has been resolved 32


-----

428 (IAC)

Judicial review challenges other than to removal 33

Removal directions deferred 34

Preparing the judicial review documentation 34

Permission to apply for judicial review granted 36

Expedited process 37

How to refer a case for expedition 37

Permission to apply for judicial review refused 39

Application to the Court of Appeal or Supreme Court 40

Injunctions in removal cases 41

Injunction confirmed 41

Out of hours and urgent injunctions 41

Injunction received, but it proves too late to halt the removal 42

Injunction received, but removal has already taken place 43

Information that must be recorded on file 43

Applications to the European Court of Human Rights 44

Rule 39 indications from the European Court of Human Rights 44

Judicial review in Scotland 45

Judicial review in Northern Ireland 47

Completing the Immigration Factual Summary 48

Immigration Factual Summary: functions 48

Immigration Factual Summary: completion 48

Basic data fields 48

Immigration history 49

About this guidance

This guidance is undergoing detailed review. This version includes some additional interim clarification concerning
Deferral of removal and the completion and service of the Immigration Factual Summary.

**Contacts**

If you have any questions about the guidance and your line manager or senior caseworker cannot help you or you
think that the guidance has factual errors then email Enforcement Policy.

If you notice any formatting errors in this guidance (broken links, spelling mistakes and so on) or have any
comments about the layout or navigability of the guidance then you can email the Guidance Rules and Forms team.


-----

428 (IAC)

**Publication**

Below is information on when this version of the guidance was published:

     - version 15.0

    - published for Home Office staff on 21 May 2018

**Changes from last version of this guidance**

Reformatted to latest format and style standards.

Updated guidance on Consideration of deferral of notice period.

**Related content**

Contents

Judicial reviews explained

This guidance sets out the Judicial Review process in enforcement cases. There is also more general guidance in
Judicial Review Guidance

Judicial review (JR) is the legal process that allows a person to challenge the lawfulness of a decision, action or
failure to act of a public body such as a government department.

Immigration removal cases, where there has been an asylum or human rights claim, should not usually reach the
stage of JR until after they have had access to the appeals system.

**Event types subject to JR**

Types of event that could be subject to JR are:

     - a failure to act - such as a delay in issuing a document or making a decision

    - the setting of removal directions – which usually means that the person believes their removal would
infringe their rights (e.g. rights under the Refugee Convention, European Convention of Human Rights or
European Community instruments)

     - a refusal to accept that further submissions amount to a fresh claim

     - a decision to certify a claim as clearly unfounded

     - detention

**Pre-action protocol**

The pre-action protocol sets out the steps that must be taken before commencing an application for JR. This
procedure normally only applies where removal directions have not been set or removal is not imminent. A
template response for a letter sent in an urgent case, where the pre
action protocol process is not appropriate can be found in section 2 of Judicial Review Guidance.

In non-urgent cases, a pre-action protocol provides you with an opportunity to consider these issues and to provide
a response in the hope that this will resolve any concerns and rectify any errors before the need to start JR
proceedings.

Where a claimant believes that a legal error has been made in the consideration of their case the claimant will be
able to make representations in a standard format to the defendant. If you receive these representations, you must
fully consider them and decide whether any action can be taken


-----

428 (IAC)

     - if you decide the representations made have merit you must try to rectify the problem without the need of
the JR process

     - if you decide the representations have no merit, you must use the opportunity to fully explain reasons for
your decision and to answer any queries the claimant has made

    - if you decide that some of the claim has merit but others do not, your response must fully cover the
reasons for this decision, with a full explanation of what you agree with and how you will rectify this and
why you do not accept other claims o you will have 14 days to respond in full to the matters.

**Related content**

Contents

Quick guide to Judicial Review process

The below flow chart explains the JR process and the relevant timescales involved. Including the involvement of
Government Legal Department (GLD) formerly known as Treasury Solicitors. For further written detail on the JR
process please see Judicial Review Guidance .

Notice of removal

Notice of removal may be given in three different forms:

    - Notice of a removal window - the person is given notice of a period, known as the removal window,
during which they may be removed

     - Notice of removal directions - the person is given notice of removal directions and thus knows the exact
date of departure

     - Limited notice of removal - a more restricted version of the removal window form of notification

Only one of the above forms is necessary in each case. In some cases, the enforcement officer may have
discretion as to which of the above forms of notice is considered suitable, in other cases removal may only be
possible with one form of notice.

**Notice of a removal window**

Under this form of notice the person is given notice of a removal window during which removal may proceed without
further notice. This form of notice is suitable for the following persons, subject to exceptions:

    - persons being removed under section 10 of the Immigration and Asylum Act 1999 as amended by the
_[Immigration Act 2014,the person will be given a “Notice of Liability for Removal”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_

     - persons being deported under sections 3(5) and (6) of the Immigration Act 1971 or section

[32 UK Borders Act 2007,the person will be given a “Deportation Decision Letter”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y0HC-00000-00&context=1519360)

When “Notice of Liability for Removal” or “Deportation Decision Letter” is given, it starts the notice period. The
person may not be removed during this period.

When the notice period ends, the removal window begins. A person may be removed during the removal window.

|Notice period or removal window|Action|
|---|---|


When does the notice period
begin?



- When the notice is given in person, the period begins at the time notice is given.

- When the notice is given by post, the period begins at 00:01h the day after it is
received Unless shown otherwise the date of receipt is two working days after the


-----

|FB and another v Secretary of|Page 36 of 67 State for the Home Department (Public Law Project intervening) [2018] UKUT 428 (IAC)|
|---|---|
||date on which the notice was posted. • The notice may not be given to a person with leave to enter or remain, or during the period within which an in country appeal or an administrative review may be lodged in time or is pending.|
|When does the notice|• The notice will specify the length of the notice period. The|

|Notice period or removal window|Action|
|---|---|
|period end?|minimum length of the notice period must comply with the policy at paragraph 2.4 below.|
|When does the removal window begin?|• The removal window begins when the notice period ends.|
|When does the removal window end?|• The removal window will run for a maximum of three months from the time the “Notice of Liability for Removal” or “Deportation Decision Letter” is served. • If a removal window has not yet expired, it can be extended by way of reminder for a further 28 days. This can be done by way of a removal reminder (RED0004 extension) which will also remind the individual of their obligation to raise any further issues with the Home Office • If the person makes an asylum, human rights or EU free movement claim, involving issues of substance which have not been previously raised and considered, or a further charged application for leave, the window ends.|


The “Notice of Liability for Removal” or “Deportation Decision Letter” must include:

     - the country of return

     - in relation to an asylum claim, details of the part of the country to which they will be removed

Where a removal window has expired, or removal will be via a third country transit point which is not one of the safe
countries listed in section 3.2 (Removal via a different route) and which was not notified in the original notice, a
fresh removal window should be notified using form

RED0004 (Fresh) and a new notice period will begin. A proposed third country transit point (or a range of potential
transit points) may be notified using this form.

**The “Notice of Liability for Removal” must be accompanied by the Immigration Factual Summary**
**(ICD. 2599):**

     - This must include a chronology of the case history, including details of whether any appeal rights were
exercised and past applications for JR, see also: Immigration Factual Summary

     - A RED0001 notice or other casework decision of the type outlined in Liability to administrative removal
(non EEA) - consideration and notification

The “Notice of Liability for Removal” or “Deportation Decision Letter” must be copied to any legal representative
where the Home Office has details of any representative actively involved in the case, or where a person asks that
a specified representative be sent copies.


-----

428 (IAC)

If someone has been given notice of a removal window, they need not always be taken into detention overnight
before removal.

If someone is detained/ arrested for removal later on the same day but states that their circumstances have
changed or that they wish to access legal advice, they will not be removed whilst they are seeking legal advice, or
they have representations outstanding. Where representations do not amount to a fresh protection or human rights
claim and have either:

    - already been considered

    - have not previously been considered but would not create a realistic prospect of success (in terms of
leading to an outcome other than removal from the UK)

the individual can proceed to be removed on the same day once we have considered the outstanding
representations. Where removal is deferred in accordance with 'Arranging Removal', they will be taken to an IRC if
detention is appropriate (see Detention guidance).

Removal will not automatically be deferred if a claim is made by a third party who is not an OISC accredited, or
otherwise appropriately qualified, representative or a Member of Parliament.

Those not suitable for removal window

The policy described in this section may not be used to give notice of removal to:

     - family cases

    - where the person has no leave but has made a protection (asylum or humanitarian protections) or
human rights claim, or appeal, pending

    - where the Home Office has evidence (beyond a self-declaration) that a person is suffering from a
condition listed as a risk factor in the Adults at risk in immigration detention policy or other condition that
would result in the person being regarded as an adult at risk under that policy

**Notice of removal directions**

Under this form of notice the person is given notice of removal directions which will specify the date of departure.
This form of notice is suitable for the removal and deportation of all persons irrespective of the power under which
they are being removed.

In most cases notice will usually be by service of form IS151D (or IS92 in port cases), with a copy of the removal
directions in the case. The notice period (see: notice period) runs from when notice is served up to the point of
departure.

Persons being removed must be given adequate notice that removal has been scheduled. Where the person is
detained, notice should ideally be given as soon as removal directions have been set. Where the person being
removed is not detained but the removal is to be enforced and removal directions have been set, they should ideally
be given notice as soon as possible after arrest. Where removal directions are being served on a person in an
Immigration Removal Centre (IRC), you must ensure that a copy of the removal directions and all other relevant
paperwork is faxed promptly to the IRC to serve on the individual. Unless exceptionally agreed with the Home
Office manager at the IRC, the notice of removal will be served on the person the same day only where it is
received by the IRC before 3pm.

When notice is given to a person being removed, it must be copied to their legal representatives where the Home
Office has details of any representative actively involved in the case, or where a person asks that a specified
representative be sent copies.

**Limited notice of removal**


-----

428 (IAC)

**Limited notice should not be used where a medical or social work professional has advised that it**
**may not be appropriate.**

Limited notice can be utilised in all cases (subject to the safeguarding exception detailed above) as an initial return
option or as a contingency where a return using alternative option has failed. It may be of particular use where noncompliance or disruption by the family has led to a previous failed return or where there is a reasonable likelihood of
future disruption or future noncompliance.

The exact details of the flight and time of departure may be withheld and limited notice given using form IS151G.
The individual or family should be informed that they will not be removed during the notice period, and no later than
21 days from when notice is given. In the absence of a copy of the removal directions, they should also be told the
country to which they are being removed and the route. This may be notified as a range of possible routes; for
example, that the flight will either be direct, or via a safe country, or any other named country you are considering
as a transit point. See Family Returns Process for further details regarding the application of this policy in family
cases. Family cases within this section deals with its application in charter cases and where there are other special
arrangements (where the minimum notice would normally be 5 days).

When notice is given to a person being removed, it must be copied to their legal representatives where the Home
Office has details of any representative actively involved in the case, or where a person asks that a specified
representative be sent copies.

**Notice of removal must also be accompanied by the Immigration Factual Summary (ICD. 2599).**
This must include a chronology of the case history, including details of whether any appeal rights were exercised
and past applications for JR.

See also: Immigration Factual Summary.

**The notice period**

Where notice is given of a removal window under this policy the notice period is 7 calendar days if at the point
notice is given the person is not detained.

Otherwise, subject to certain exceptions described in this guidance (see: deferral), the notice period must be of
the following minimum time periods:

    - normal enforcement cases – minimum 72 hours (including at least two working days)

     - third country cases and cases where the decision certified the claim (see section 2.4.3) - minimum five
**working days (unless the case has already been reviewed by JR: see NSA cases already reviewed)**

Normal enforcement cases (administrative removal and deportation)

Unless an exception applies, there are three rules to consider when calculating the minimum notice period:

    - a minimum of 72 hours must be given

     - this 72-hour notification period must always include at least two working days

    - the last 24 hours must include a working day unless the notice period already includes three working
days

The below table shows the latest times you can notify a person of their removal in normal enforcement cases,
assuming you want to immediately remove at the end of the notice period, taking into account the minimum 72
hours notice period and the provisions in terms of working days. In summary, the notification times are as follows:

If removing on a Monday:


-----

428 (IAC)

    - If you wish to remove before 10am on a Monday, notice must be given by 10am on Wednesday. This is
because the last 24 hours does not include a working day so the notice period must be extended to include
three working days. Those you intend to remove between 10am and 5pm on a Monday will need sufficient
time to access the courts on the Thursday and Friday of the preceding week so that they can challenge the
decision to remove them if necessary. Those due to be removed after 5pm on a Monday will, however,
have sufficient time to access the courts on the day of their removal, so removal directions can be set as
late as 10am (when the courts open) on the Friday prior to removal.

If removing on a Tuesday:

     - Individuals you intend to remove on a Tuesday may also need sufficient time to access the courts during
the preceding week. Those due to be removed before the courts open on a Tuesday or between 10:00am
and 5:00pm must be given sufficient time on the Friday before the planned removal to challenge the
decision to remove them if they so wish. However, those due to be removed after 5pm on a Tuesday will
have sufficient time to access the courts on the day of, and the day before, their removal, so you can serve
removal directions as late as the same time on the preceding Saturday (72 hours before removal).

If removing on a Wednesday, Thursday or Friday:

    - If you intend to remove a person on a Wednesday, a Thursday, or a Friday, unless there has been a
bank holiday, the weekend is of no consequence when calculating the minimum notice period. You must
ensure when giving notice of removal that the person has at least two working days before their removal to
challenge the decision to remove them in the courts if necessary.

If removing at the weekend:

    - The courts are shut at weekends, so individuals you intend to remove then or before the courts open on
a Monday must be given sufficient time in the preceding working days to challenge the decision to remove
them if they so wish. Those due to be removed at the weekend or before the courts open on a Monday
must therefore be notified of their

removal on the Wednesday prior to the planned removal, so that they have three working days to access the courts
if necessary.

This table does not take account of bank holidays, which must be considered as extra             non-working
days.

|Removal set for|Notify by latest|
|---|---|
|12:00am to 10.00am Monday|10:00am Wednesday|
|10.00am to 17:00pm Monday|Same time Thursday|
|17:00pm to 12:00am Monday|10:00am Friday|
|12:00am to 10:00am Tuesday|10:00am Friday|
|10:00am to 17:00pm Tuesday|Same time Friday|
|17:00pm to 12:00am Tuesday|Same time Saturday|
|Wednesday|Same time Sunday|
|Thursday|Same time Monday|
|Friday|Same time Tuesday|
|12:00am to 10:00am Saturday|Same time Wednesday|
|From 10:00am Saturday|10:00am Wednesday|
|Sunday|10:00am Wednesday|


-----

428 (IAC)

In addition to the above table and summary, you can use the removal notice calculator when considering the latest
time you can notify a person of their removal in normal enforcement cases.

There are occasions where the standard 72 hour notification period is not required (See: Notice of removal) which
you must consider before giving notice of removal.

Persons detained for removal must be given access to telephone facilities to enable instruction of and on-going
contact with representatives.

**Consideration of deferral of notice period**

Whether or not they are detained, individuals must be allowed a reasonable opportunity to access legal advice and
have recourse to the courts. The purpose of the notice period is to enable individuals to seek legal advice. If,
during the notice period, an unrepresented person is yet to instruct a legal representative you must always consider
deferring the removal window for an additional period

It is reasonable to expect individuals who are aware that they have not been successful in an immigration claim
and/or appeal and/or that outstanding representations may be or have been rejected to act promptly in seeking
legal advice. Each case for deferral must be considered on its individual merits. The key consideration is whether
the person has had a reasonable opportunity to access legal advice and recourse to the courts.

Change of legal representative

A delay caused by a change in legal representative may be unavoidable and consideration should be given based
on the merits of the case. It may be reasonable to defer removal for an additional period where the individual has
unavoidably lost contact with previous representatives, for instance, because the legal service has ceased business
or discontinued responsibility for other reasons. However, consideration must also be given to related factors.
Deferral should not normally be considered in cases where there is no clear reason provided (and you have asked
for reasons) for the change of representatives and/or there is cause to believe that the motive for the change is to
bring about a postponement of removal, for instance, multiple changes of representative within a short period.

Access to legal advice: detained cases

Individuals detained in Immigration Removal Centres have access to legal advice 'surgeries'. DSO 06/2013
provides that detainees must be told of the availability of Legal Aid Agency (LAA) surgeries during the induction
process within the first 24 hours. IRC welfare officers act in accordance with DSO 7/2013 to alert detainees to the
Duty Solicitor scheme that operates in the individual IRC, the timetable of provision and the mechanism for making
an appointment. They also:

     - direct detainees to information about how to find an alternative solicitor or other immigration advisor
accredited by the Office of the Immigration Services Commissioner

    - provide information about the Law Society and Legal Services Commission in a language that detainee
can understand

     - provide copies of the Bail for Immigration Detainees (BID) notebook

A request for an appointment with the surgery may be made at any time. It is reasonable to expect an individual to
make use of the 72-hour notice period allowed for legal consultation at the earliest opportunity should they wish to
do so.

Generally speaking, if an unrepresented person (in detention) wishes to obtain legal advice and cannot be given an
appointment at an LAA advice surgery within the initial 72-hours notice period, the removal window should normally
be deferred to enable an appointment to be arranged. However, any request for an appointment that necessitates
deferral and continued detention should be carefully considered on its merits. Consideration should be given
whether the individual:


-----

428 (IAC)

     - was properly notified of access to legal advice

     - made their request at the earliest reasonable opportunity

     - cooperated with any attempt to arrange a consultation

     - delayed their request in order to thwart removal

Access to relevant documentation

Legal representatives need access to relevant documents and case papers in order to properly advise their client.
There may be some circumstances where an individual does not readily have access to their documents; for
instance, because they have been detained at a reporting event or they have been outside the UK for a significant
period.

Any refusal decisions, notice of liability to removal and Immigration Factual Summary will be provided to the
representatives on request either when the individual is detained or at the point they seek legal advice on a same
day removal. In most instances, the Immigration Factual

Summary should be fully completed and will provide the necessary key facts and case history.

Where requested by representatives, it is reasonable to provide all relevant documents but, it should be noted, you
may reasonably expect that, unless there has been a change of representative, documents previously provided to
an individual and/or their representatives should have been retained. You may therefore reasonably request
representatives to be specific in their requests. A request to release all case papers, whatever their relevance, is
not reasonable and should be challenged.

**Deferral of removal**

It is not necessary to defer removal on a threat of JR, though it is important to satisfy yourself that the person
concerned has had the opportunity to lodge a claim with the courts (particularly in certified or third country cases
where there is no statutory in-country right of appeal). See: Consideration of deferral

The Home Office will only consider deferring removal if a JR application made in England and

Wales is properly lodged with the Administrative Court in accordance with Practice Direction 54A Section II of the
Civil Procedure Rules, or properly lodged with the Upper Tribunal in accordance with the Tribunal Procedures
(Upper Tribunal) Rules 2008 (as amended).

The JR application, as received by the Home Office, may take the following forms:

Claim form issued with detailed grounds.

The Home Office will normally defer removal where a JR application made in England and Wales has been properly
lodged with the Administrative Court or the Upper Tribunal in accordance with the relevant procedure rules.
However, removal will not automatically be deferred where there has been less than six months since a previous JR
or statutory appeal or the person is within the removal window, or the person is being removed by special
arrangements (including by charter flight) (see: Special arrangements).

Claim form issued with statement of reasons for non-compliance with the Practice Direction.

In cases where the claim form has been issued and the person has provided a statement of reasons for noncompliance with the Practice Direction, the court will notify the Home Office and the matter will be placed before a
judge for consideration as soon as practicable. In these circumstances, the Home Office will defer removal if:

    - the court decides that good reason has been provided for failure to comply (and gives a direction, for
example that detailed grounds be submitted by a specified date)


-----

428 (IAC)

     - permission to proceed to JR is granted

     - the court has not yet considered the matter by the time/date of removal, in such circumstances, it will be
necessary to defer removal until the court has reached a decision

Out-of-hours claims prior to lodging with the court.

Where it is not possible to file a claim due to the Administrative Court or Upper Tribunal office being closed, the
Home Office may defer removal if provided with a copy of detailed grounds and subject to a consideration of the
exceptions set out in section 6 of this guidance. The responsibility remains with the claimant to file the claim form as
soon as possible on the next day the Administrative Court or Upper Tribunal office is open and to notify the Home
Office that the claim form has been issued.

**Withdrawing an application for judicial review**

In some cases, a person with an outstanding JR application may ask to leave the UK. Where a person wishes to
make a voluntary departure, you must ask them to sign a disclaimer (form IS101). The person (or their legal
representative) must also contact the courts to withdraw their JR application so that the court file is closed. This
must be done before the person leaves the UK so that a Notice of discontinuance can be filed. See also: assisted
voluntary returns.

**Cases where the removal window should not be used**

Removal window used but found to be inappropriate

It is possible that notice of a removal window may have been served on a person before it is established that they
constitute a vulnerable group. If that has been done, the notice may not be relied upon to enforce removal. Instead
new notice of removal must be given in accordance with notice of removal .

Family cases

Since 1 March 2011, an end to end process has been in place for working with families with children (see :Family
Returns Process. This new process provides families with greater support and advice when considering their
options for voluntarily leaving the UK (Assisted Return). Where families are not prepared to return voluntarily they
may be given the opportunity to leave under their own steam (Required Return) before enforcement action
(Ensured Return) is considered.

As part of the Assisted Return stage of the new process, all families liable for return are given the opportunity to
attend a Family Return Conference to discuss their options for returning home and raise any legal challenges or
further submissions regarding their departure. Where necessary, families are then given a minimum of two weeks
after their Family Return Conference to think about how best to go home before the Home Office consider setting
removal directions.

In addition to the minimum two week Assisted Return reflection period, specific notification periods have been
established for giving notice of removal at the Required Return and Ensured Return stages of the family returns
process.

**Notifying a family of their Required Return**

In almost all cases, families who are not prepared to voluntarily leave the UK are given the opportunity to make a
Required Return which means they leave under their own steam without any enforcement action. In these cases,
the Home Office pursues a self check-in or assisted check-in return in which we give notice of removal with at least
two weeks notice while they remain living at home.

**Notifying a family of their Ensured Return**


-----

428 (IAC)

Families reach the Ensured Return stage of the new process only where the Assisted and

Required routes of return have failed or, in exceptional circumstances, where we consider a

Required Return is not appropriate. The standard notification times apply to families subject to Ensured Return
unless one or more of the exceptions in section 3 applies. If the family is subject to a limited notice removal, the
standard notification period will be used to provide the time and date before which they will not be removed.

See also: NSA family cases

Third country and Non-suspensive appeal (NSA) cases

Cases certified under a) s.94, s.94B or s.96 of the Nationality, Immigration and Asylum Act 2002 (the 2002 Act) and
b) EEA Regulation 24AA, as well as third country cases do not attract a statutory in-country right of appeal. When
you give notice of removal to a person in these cases, you must satisfy yourself that they have the opportunity to
access the courts before their departure is enforced. See: Consideration of deferral. If notice of removal is given at
the same time as the NSA or third country decisions this is likely to be their first opportunity for legal redress. A
minimum of 5 working days notice must therefore be given between giving notice of removal and the removal itself
(unless the case has already been reviewed by JR, or in some circumstances where the individual has received
such notice previously: see NSA cases already reviewed by JR or following a failed removal).

As the courts are shut at weekends, you will need to give notice of removal seven days before you intend to remove
the person in most third country and NSA cases. Where you intend to remove an individual on a Saturday or a
Sunday, you may, in some cases, actually need to give notice of removal as much as eight or nine days in advance
of removal if, for any reason, you are not able to give notice of removal the preceding weekend.

The below table shows the notification times for NSA and third country cases. It does not take account of bank
holidays which must be considered as extra non-working days.

**Removal** **Notify by latest:**
**directions set for:**

Monday Same time the preceding Monday (7 days before)

Tuesday Same time the preceding Tuesday (7 days before)

Wednesday Same time the preceding Wednesday (7 days before)

Thursday Same time the preceding Thursday (7 days before)

Friday Same time the preceding Friday (7 days before)

Saturday Same time the preceding Saturday (7 days before) or Friday of the previous week
(eight days before) if you are not able to serve removal directions at the weekend

Sunday Same time the preceding Sunday (7 days before) or Friday of the previous week
(9 days before) if you are not able to serve removal directions at the weekend

In addition to the above table and summary, you can use the removal notice calculator when considering the latest
time you can notify a person of their removal in third country and NSA cases.

There are instances where standard notification may not be required for NSA and third country cases (some family
cases for example), which you must consider before setting removal directions.

Special arrangements (including charter flights)

Chartered flights are subject to special arrangements because of the complexity, practicality and cost of arranging
an operation. For this reason, a JR application may not defer removal.

|Removal directions set for:|Notify by latest:|
|---|---|
|Monday|Same time the preceding Monday (7 days before)|
|Tuesday|Same time the preceding Tuesday (7 days before)|
|Wednesday|Same time the preceding Wednesday (7 days before)|
|Thursday|Same time the preceding Thursday (7 days before)|
|Friday|Same time the preceding Friday (7 days before)|
|Saturday|Same time the preceding Saturday (7 days before) or Friday of the previous week (eight days before) if you are not able to serve removal directions at the weekend|
|Sunday|Same time the preceding Sunday (7 days before) or Friday of the previous week (9 days before) if you are not able to serve removal directions at the weekend|


-----

428 (IAC)

Special arrangements may also apply in other cases. For example, where complex medical needs require a
significant number of medical escorts and special equipment. If you believe a case in which you are arranging
removal should be treated as a special arrangements case, you should consult OSCU before setting removal
directions.

Operational constraints will determine arrangements necessary for charter operations and other special cases.
Details concerning these arrangements will be communicated to the High Court by OSCU in advance of the date
planned for the operation. The person being removed will also be notified of these arrangements and that removal
will not necessarily be deferred in the event that a JR is lodged. Where removal is not deferred, the person
concerned will be advised in a letter to be provided by OSCU of the need to obtain an injunction to prevent removal.

Individuals being removed by special arrangements (including charter flights) who wish to legally challenge their
removal are normally required to seek injunctive relief as a JR application will not usually result in deferral of
removal. In these circumstances, the person will be given a minimum of five working days notice of removal so
they have the opportunity to take legal advice. The purpose of this extended period of notice of removal is to
minimise the number of last minute applications for injunctive relief to the High Court in England and Wales, the
Court of Session in Scotland or the High Court in Northern Ireland and to encourage people to inform the Home
Office at the earliest opportunity of any further submissions they want to make.

If individuals being removed by charter flight or special arrangements are not required to seek injunctive relief to
challenge removal, a JR application will usually continue to result in a deferral of removal. In these circumstances,
the standard 72 hours notice period applies rather than five working days.

To protect the safety of those on board a chartered aircraft to particular destinations it may be necessary, for
security reasons, to withhold the exact details of departure. In these cases, all those being removed by that flight
will be given limited notice of removal (ie they will still be given a minimum of five working days notice of removal
but will be informed that they will be removed no sooner than five working days and no less than 21 days from the
date where notice of removal is given).

.

As well as referring to the tables, you can use the removal notice calculator when considering the latest time you
can notify a person of their removal in charter flight and other special arrangement cases.

Where standard notification may not be required when giving notice of removal

This section details the circumstances in which you do not need to provide standard notification when giving notice
of removal. Standard notification of removal does not need to be given where either:

     - an exception applies

     - a second period of notification is not needed following a failed removal.

**Exceptions to standard notification of removal**

Below we detail the following exceptions to standard notification of removal. These are:

     - port cases where removal occurs within seven days of refusal

     - third country and NSA family cases subject to Ensured Return

Port cases

In port cases, if removal takes place within seven days of refusal, you do not need to provide 72 hours notice. You
must provide the standard 72 hours notification of removal in cases which are refused entry at port where removal
does not take place within seven days of refusal.


-----

428 (IAC)

If a human rights claim is raised in a port case where standard notification is not required, the Operational Support
and Certification Unit (OSCU) may, where the claim falls to be refused, be able to certify the claim without deferring
the removal directions. Such cases must be referred to OSCU who will decide whether such action is appropriate.

Third country and NSA family cases subject to Ensured Return

Families are liable for Ensured Return only where Assisted and Required Return have both failed or, exceptionally,
where we consider a Required Return is not appropriate. Therefore, any family that reaches this stage of the family
returns process will have already had opportunities following their Family Return Conference and, where
appropriate, when they were given notice of removal at the Required Return stage, to make an application for JR, if
they wanted to do so.

If a third country or NSA family case has reached the Ensured Return stage of the family returns process, you do
not need to provide a minimum of five working days notice because they will not need this longer notification period
to access the courts. Instead, you must provide standard notification (minimum 72 hours) of removal in these
cases.

NSA cases already reviewed by JR or following a failed removal

Where an NSA decision has already been challenged by way of JR and either all JR proceedings have been
concluded or the JR proceedings are no longer a legal barrier to removal (e.g. the court has made a finding of 'no
merit' or that renewal will not be a bar to removal) any subsequent removal directions will only require the standard
notice period of 72 hours, not five working days.

Where removal directions have been set for five working days in an NSA case and the individual either does not
challenge the removal during that period or their challenge does not result in deferral of their removal, but the
removal fails for other reasons (eg travel document issues or technical reasons), you should apply the ten days
policy where possible (see: Where second period of notification is not needed). Where this is not possible (eg travel
documents take longer than ten days to obtain) removal directions may be reset with 72 hours notice rather than
five days.

**Where a second period of notification is not needed.**

Where a person was given the required notice of removal but the removal fails or is deferred, it may not be
necessary to give a further period of notice when rearranging removal for within 10 days of the failed or deferred
removal.

Where a person has been given notice of a removal window or limited notice and an attempted removal fails,
removal may be rescheduled without further notice if it is within the removal window or limited notice period which
they have already been given, without the ten-day policy being applied. This does not prevent the ten-day policy
being applied (if it is appropriate to do so) if a removal fails towards the end of the removal window or limited notice
period.

**When could I apply this?**

The list below is not exhaustive and is subject to the circumstances outlined below at, 'When could I not apply this?'

     - the flight cannot depart as scheduled due to a technical fault with the aircraft or transport difficulties with
the relevant contractor including problems with the availability of aircraft, related aircrew or the scheduled
departure slot

    - the scheduled departure time of the flight has had to change for other reasons such as adverse weather
conditions, industrial action or other significant factors that can be reasonably deemed to be outside of the
Home Office's control


-----

428 (IAC)

    - the person has attempted to frustrate their removal by being non-compliant e.g. refusing to leave the
immigration removal centre or board the vehicle

    - where removal has been disrupted by another person's behaviour

    - removal was deferred following a JR of removal which has been concluded or the judge has given a
finding of 'no merit' or 'renewal should not act as a bar to removal' subject to the following conditions

**When could I not apply this?**

Appropriate notice must continue to be given in cases where there has been more than 10 days since the initial
deferral/cancellation or where there has been a significant change in circumstances, such as:

     - we are re-setting removal directions to a different country

     - further submissions (involving issues of substance which had not been previously raised and considered)
have been received and refused since the earlier removal direction failed

     - in certain circumstances if there has been a change of route, see below

**Removal via a different route**

If for operational reasons it is required to change the route of return to remove a place of transit you do not need to
allow a further period of notice when re-setting removal directions for within 10 days of the failed removal, providing
the place of final destination remains unchanged. For example, the alteration is from a flight from London to Abidjan
via Lagos to a direct flight from London to Abidjan.

If for operational reasons it is required to change the route of return to insert or amend a place of transit you must
give a new standard notice period unless the new place of transit is in a safe country. A new standard notice period
will not be required when the new place of transit is in Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, Finland,

France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Lithuania, Luxemburg, Malta, Netherlands,
Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden, or Switzerland.

For example, if the original removal directions were set from London to Abidjan via Lagos, you may alter the place
of transit (Lagos) to Paris without a new notice period. However, if you changed the transit point from Lagos to
Nairobi, a new notice period would be required.

See also: Country information

Threat of judicial review

All JR applications received in respect of cases where removal directions have been set must be referred to OSCU
who will consider on an individual case by case basis whether deferral of the removal directions is necessary.

JR applications relating to third country cases must be referred to the Third Country Unit (TCU) between 9am-5pm
Monday to Friday. Deferral of removal directions will be considered by TCU on a case by case basis.

Where there is a threat of JR, removal directions must remain in place until a Crown Office reference, Upper
Tribunal reference or injunction is obtained in accordance with 4.1 above. However, even if a complete JR claim is
submitted, removal directions can be maintained where certain exceptions apply and the JR would not be barrier to
removal (see: When JR will not suspend removal and Stayed Cases).

In all removal cases, if a person is unable to file a claim because the Administrative Court or Upper Tribunal office is
closed, you must still consider whether deferral is appropriate where a copy of detailed grounds is provided to the
Home Office and lodged with the court or tribunal at the earliest opportunity. A decision on whether to defer in these
circumstances will be taken by


-----

428 (IAC)

OSCU.

**Special arrangements (including charter flights)**

Where your case is scheduled to be removed by special arrangements, including charter flight, and a threat of JR is
received:

    - you must refer the case to OSCU immediately

    - OSCU will let you know if the removal can go ahead on a case by case basis

    - if OSCU decide not to defer removal, they will provide a letter for you to send to the person or his
representatives of this decision and the reasons, the letter will explain that removal will continue unless an
injunction is obtained

     - if an injunction is obtained, all enforcement action must be suspended immediately

**Port cases**

In port cases where removal directions are set for a date within seven days of refusal, you must defer removal when
a written threat of JR is received. The person must be given 48 hours to lodge their application with the
Administrative Court or Upper Tribunal, so any removal planned for within this period must be re-scheduled. You
must also inform the person that their removal will proceed if they do not properly lodge their application with the
court or tribunal (as set out in section 4 above) within this period. The 48 hours begins when you receive the written
threat of JR and must include at least one working day.

When judicial review proceedings will not suspend removal

**When should you refer to this section?**

This section tells you how to determine whether removal should be suspended in situations where removal
arrangements are in place, or Immigration Enforcement have made a removal request, and judicial review (“JR”)
proceedings have been brought against that removal. This guidance only applies to JR proceedings brought in
England and Wales.

**Special arrangements**

This section does not apply where the subject is being removed under 'special arrangements' provisions.

**The qualifying criteria**

Where JR proceedings against removal are brought, the removal will normally be suspended. However, in certain
circumstances it will not be necessary to suspend removal.

The first consideration is whether one or more of the following qualifying criteria are met:

    - there has been less than 6 months since a previous JR or statutory appeal has been concluded on the
same or similar issues - a JR will be on the same or similar issues unless it is brought on completely
different grounds, for example the previous JR or statutory appeal related to unlawful detention or was
purely procedural

    - there has been less than 6 months since a previous JR or statutory appeal has been concluded on the
same evidence, even though the legal basis of the challenge is different from that previously brought

    - there has been less than 6 months since a previous JR or statutory appeal has been concluded and the
issues being raised could reasonably have been raised at that previous JR or statutory appeal

    - the JR is brought while the person is within the removal window and as long as the person remains
within the removal window (unless another 'qualifying criteria' applies)


-----

428 (IAC)

    - there has already been an order refusing an injunction against removal in the JR and no subsequent
application for an injunction on removal has been granted

    - where a JR renewal application has been made but an application for injunction has already been
refused in relation to that same JR application or an order has been made that renewal is no bar to
removal (see also “Handling JRs involving simultaneous injunction applications”)

**When JR proceedings will always suspend removal**

Even where the qualifying criteria are met, removal will always be suspended in any of the following circumstances:

     - an injunction against removal is granted by the court or tribunal

     - this is the first JR challenge to a decision to certify a claim, the result of which being there is either no
appeal, or any appeal right is out of country only

     - permission has been granted in the JR

Removal may also be suspended where there is insufficient time before removal for OSCU to consider the merits
and barriers tests of a case that meets the qualifying criteria. In these cases removal will initially be suspended,
however where one of the qualifying criteria is met the litigation handling team will determine whether or not the JR
is bound to fail in the course of filing the AoS (see section “JR received when CID shows that removal
arrangements are in place or preparations are being made to put removal arrangements in place” below for further
details).

**The merits and barrier tests**

Where one or more of the qualifying criteria are met, and there are no reasons why removal must be suspended,
you should go on to consider whether the JR is bound to fail and /or whether any of the issues raised in the JR are
a barrier to removal.

Where the JR is bound to fail and does not raise any issues which are a barrier to removal then removal does not
need to be suspended.

Is the JR bound to fail (the “merits test”)?

You must consider whether the JR is bound to fail either before the decision is taken not to suspend removal or
before a decision is taken to arrange removal following a removal request. Examples of when a JR is bound to fail
are:

    - the grounds for JR are very weak, for example they do not make sense, are clearly standard grounds or
are generic (they do not refer to the specific circumstances of the Claimant, unless the claim is a “class
issue” namely multiple Claimants raising the same legal point)

     - the JR is obviously unarguable on the facts

     - there is clear authority on the legal point in issue

Concluding that a JR is not bound to fail does not mean that it is arguable and therefore that permission should be
granted.

Are the issues raised in the JR a barrier to removal? (“the barrier test”)

You must also consider whether the issues raised in the JR should be treated as a barrier to removal:

    - does the JR raise new grounds, for example a first time asylum or human rights claim or further
submissions that fall to be considered under paragraph 353 of the Immigration Rules? If so, refer to the
section “Fresh claims”


-----

428 (IAC)

    - does the JR rely on new and relevant evidence that has not previously been considered by the SSHD in
deciding a previous application or claim and (where a right of appeal was exercised against the refusal of
that previous application or claim) by the court in an appeal? If so, consider the nature of that evidence. If it
amounts to a first-time asylum or human rights claim or further submissions that fall to be considered under
paragraph 353, refer to the section “Fresh claims”

In OSCU, the decision on whether the JR meets the merits and barrier test, must be taken at a minimum HEO
grade and countersigned at a minimum SEO grade. This does not apply to the litigation handling team who will
work closely with GLD when applying the merit test.

**Summary of process**

**JR received when CID shows that removal arrangements are in place or preparations are being**
**made to put removal arrangements in place:**

The JR must be passed to OSCU who will:

    - check CID to confirm that removal arrangements are in place or preparations are being made for removal
arrangements

     - create a JR record on the JR screen in CID

     - consider whether one or more of the qualifying criteria are met, if yes, apply the merits and barrier test
and decide whether removal should be suspended

     - outcome = removal suspended: pass the JR to the litigation handling team to manage the litigation

    - outcome = removal not suspended: write to the person or their representatives to confirm that removal
will not be suspended. Pass the JR to the litigation handling team to manage the litigation

Where the applicant meets the qualifying criteria, but there was insufficient time before removal for OSCU to apply
the merits and barrier tests (resulting in removal being suspended) the litigation handling team will, in the course of
filing the AoS, apply the merits and barrier test. If the JR is bound to fail and there are no barriers to removal the
litigation handling team will notify the enforcement/removal team and provide them with a copy of the JR grounds
on request.

    - the enforcement/removal team should re-instate removal arrangements and write to the applicant
notifying them that the JR is not suspensive and they are commencing removal directions

     - the litigation handling team will serve the AoS

Where an injunction is granted at any stage in the process, removal must be suspended. In these circumstances, it
will not be appropriate for the litigation handling team to undertake a merits test within 21 days of service of the JR
(see section “Immigration Enforcement make removal request following receipt of a JR” and injunctions).

Where permission is granted in the JR removal will be suspended and the JR will be handled in accordance with
the usual JR process (refer to the Judicial Review guidance).

**Removal request made by Immigration Enforcement following receipt of a JR:**

The enforcement / removal team will assess whether the individual case meets the qualifying criteria. If it does,
using the relevant referral pro-forma, they will ask the litigation handling team to apply the merits and barrier test.
No further removal action will be taken until the litigation handling team has considered the JR.

**The litigation handling team will apply the merits and barrier test.**

Where the JR has merit and/or raises barriers to removal the litigation handling team will notify the
enforcement/removal team and continue to manage the JR in accordance with the usual JR process (refer to the


-----

428 (IAC)

Judicial Review guidance). The enforcement/removal team will write to the applicant notifying them that removal is
suspended.

Where the JR has no merit and raises no barriers to removal the litigation handling team will notify the
enforcement/removal team. The litigation handling team will serve the AoS and continue to manage the JR in
accordance with the usual JR process (refer to the Judicial Review guidance). The enforcement/removal team will
write to the applicant notifying them that the JR is not suspensive and they are commencing removal directions.

Where the AoS is served before the enforcement/removal team has written to the applicant and it has been more
than seven days since the AoS has been lodged, the enforcement/removal team should re-confirm with the litigation
handling team that the JR grounds have not been varied before they write out.

Where an injunction granted at any time in the process removal must be suspended (see: Injunctions).

Where permission granted on the JR removal will be suspended and the JR will be handled in accordance with the
usual JR process (refer to the Judicial Review guidance)

Family cases

Families will be notified when invited to the Family Return Conference that they have 5 working days from the date
of invitation to the Family Return Conference to bring a judicial review to challenge their removal from the United
Kingdom.

**JR received when CID shows that removal arrangements are in place or preparations are being**
**made to put removal arrangements in place:**

The JR will be passed to OSCU who will check CID to establish whether 5 working days have expired following the
invitation to the Family Return Conference. If so, OSCU will:

- consider whether the qualifying criteria are met – if yes o apply the merits and barrier test

o and decide whether the JR suspends removal

**Removal request made by Immigration Enforcement following receipt of a JR:**

The case working team will consider whether one or more of the qualifying criteria are met. If yes, using the relevant
referral pro-forma, they will ask the litigation handling team to apply the merits and barrier test.

Where the litigation handling team conclude that the JR has merit and/or raises barriers to removal they will notify
the enforcement/removal team and provide them with a copy of the JR grounds on request. The
enforcement/removal team will write to the applicant notifying them that removal is suspended.

Where the litigation handling team conclude that the JR has no merit and raises no barriers to removal they will
notify the enforcement/removal team and provide them with a copy of the JR grounds on request. The
enforcement/removal team will write to the applicant notifying them that the JR is not being treated as suspensive
and they are commencing removal directions. In both situations, the litigation handling team will continue to manage
the JR in accordance with the usual JR process (refer to the Judicial Review guidance).

Where an injunction is granted at any time in the process removal must be suspended. In these circumstances, the
injunction will be received by OSCU who will take the necessary actions to suspend removal.

Where permission is granted on the JR removal will be suspended and the JR will be handled in accordance with
the usual JR process (refer to the Judicial Review guidance)

Fresh claims and/or further submissions


-----

428 (IAC)

A JR is not the right vehicle for raising new matters to the SSHD (for example a first time protection claim, human
rights claim or further submissions that fall to be considered under paragraph 353 of the Immigration Rules).
However, a JR which meets the qualifying criteria test might raise such matters.

**JR received when CID shows that removal arrangements are in place or preparations are being**
**made to put removal arrangements in place:**

**Grounds raised in the JR amount to a first-time protection claim** _– where the grounds_
amount to a first time claim for asylum or humanitarian protection and the claimant has not previously made an
asylum or humanitarian protection claim (note that EU asylum claims are inadmissible unless there are exceptional
circumstances as defined in paragraph 326F Immigration Rules) OSCU will:

    - suspend removal

    - refer the protection claim to the Asylum Casework Directorate or to Criminal Casework Directorate for
deportation cases

     - refer the JR to the litigation handling team to be handled in accordance with the usual JR process (refer
to the Judicial Review guidance)

**Grounds raised in the JR amount to a first-time human rights claim – where the grounds raised in**
the JR amount to a human rights claim and the claimant has not previously made a human rights claim and had a
right of appeal against its refusal OSCU will:

    - suspend removal

     - consider the human rights claim

Where the claim can be certified so that no right of appeal arises (section 96) or the appeal right can only be
exercised from out-of-country (sections 94 and 94B) the JR will not suspend removal and OSCU will issue a
decision on the human rights claim including the relevant notice of liability to removal / deportation giving 5 days
notice of removal, and write to the person or their representatives to confirm that the judicial review will not suspend
removal.

Where a further JR challenging certification is received or the person amends their JR grounds to challenge the
certification decision within the 5 day notice period, removal should be suspended and the JR passed to the
litigation handling team to be handled in accordance with the usual JR process (refer to the Judicial Review
guidance). If no further JR is received within the 5 day notice period, removal can proceed.

Where the claim cannot be certified and there is an in country right of appeal against the refusal of the human rights
claim, OSCU will suspend removal and refer the JR to Litigation Operations to be handled in accordance with the
usual JR process (refer to the Judicial Review guidance) Grounds in the JR raise EEA rights – where a non-EEA
national claims to have a right of residence under the Immigration (European Economic Area) Regulations 2006 in
the judicial review, removal cannot take place until the grounds have been considered. OSCU will:

     - consider whether the qualifying criteria test is met

    - consider the EEA grounds

Where the EEA grounds do not demonstrate the person has a right of residence under EU law removal can
continue. The JR should be passed to the litigation handling team to be handled in accordance with the usual JR
process (refer to the Judicial Review guidance).

Where the judicial reviews grounds have some merit as to whether the person has a right of residence under EU
law, the removal will be suspended. OSCU will pass the case to the relevant caseworking team for further
consideration and the JR will be passed to the litigation handling team to be handled in accordance with the usual
JR process (refer to the Judicial Review guidance).


-----

428 (IAC)

**Ground raised in the JR amount to further submissions to be considered under paragraph 353**
**Immigration Rules - OSCU will:**

     - consider whether the qualifying criteria test is met

     - consider the further submissions

Where the outcome is that:

     - the further submissions will not lead to a grant of leave or amount to a fresh claim such that there is a
right of appeal against their rejection

     - will not lead to a grant of leave but do amount to a fresh claim but the claim can be certified so that there
is either no right of appeal, or any right of appeal can only be brought from out of country

OSCU will issue a decision on the further submissions and write to the person or their representatives to confirm
that removal will not be suspended.

Where the outcome is that the further submissions will lead to a grant of leave or amount to a fresh claim such that
there is an in country right of appeal against their refusal, removal must be suspended. OSCU will suspend removal
and refer the JR to the litigation handling team to be handled in accordance with the usual JR process (refer to the
Judicial Review guidance).

**Removal request made by Immigration Enforcement following receipt of a JR:**

In this situation, the JR will be handled by the litigation handling team.

Where either OSCU or the litigation handling team consider that the JR is not bound to fail, the
enforcement/removal team should treat the JR as a barrier and suspend removal.

Where OSCU or the litigation handling team consider that the JR is bound to fail and that there are no barriers to
removal then the process set out above should be followed except that the litigation handling team will not consider
the substantive claim but will pass it to the appropriate casework team for consideration.

**Handling JRs involving simultaneous injunction applications**

If a decision has been taken to suspend removal on the basis of a JR received simultaneously with an injunction
application, the guidance on injunctions should be followed. OSCU must confirm the suspension of removal to the
relevant court centre (Administrative Court or UTIAC) by email or telephone the duty clerk at the Administrative
Court out-of-hours on 020 7047 6260. UTIAC has no out-of-hours facilities.

The Administrative Court and UTIAC have standing instructions to telephone OSCU (or CCU outside OSCU's hours
of operation) in advance of considering an application for an injunction. They will do so where they have not
received confirmation of whether removal is to be suspended.

OSCU will advise the court whether removal is imminent and, if so, whether removal will be suspended as a result
of the JR.

**Action when suspending removal**

If a decision is made to suspend removal, you must cancel removal directions.

    - if removal arrangements are in place you must refer to the OSCU standard operating procedures for the
next steps to take, JR must be raised as a barrier to removal on the CID removals screen

    - if removal arrangements are not in place the JR must be raised as a barrier to removal on the CID
removals screen


-----

428 (IAC)

**Action following a decision not to suspend removal**

You must close the JR barrier on CID, update CID notes and write to the person or their representatives to let them
know that the removal will go ahead unless they obtain an injunction preventing removal. The letter must include
reasons why removal is not being suspended.

If an injunction is obtained, all enforcement action must be suspended immediately.

If a decision is made not to suspend removal but the removal fails for reasons unrelated to the JR proceedings,
then removal directions may be re-set (or the ten-day policy applied), provided that the reasons for the original
decision that removal should not be suspended are still applicable.

Applications for permission to JR in third country cases must be referred to TCU. TCU's hours of operation are
9am-5pm Monday to Friday. If the timing of removal means that the JR needs to be considered outside TCU's
hours of operation, contact OSCU or CCU as appropriate.

**Process map**

Does one or more of the following apply? •It has been less than six months since a JR was brought - oon the same
or similar issues oon the same evidence, even though the legal basis of the challenge is different from that
previously brought othe issues being raised could reasonably have been raised at that previous JR or statutory
appeal (one-stop provision) •the person is within the removal window •a JR renewal application has been made but
an application for injunction has already been refused in relation to that same JR application or an order has been
made that renewal is no bar to removal •there has been an injunction against removal refused Do any of the
following apply? •permission has been granted on the JR •there has been an injunction against removal granted by
the court/tribunal •this is the first JR challenge to a decision to certify a claim, the result of which being there is
either no appeal, or any appeal right is out of country only (unless an **The merits test -** is the JR bound to fail?
Yes NoNo Removal is suspended No Removal is not suspended No YeYeThe barrier test - are any of the issues
raised by the JR a barrier to removal?  Ye

Does one or more of the following apply?


It has been less than six months since a JR was brought


o

on the same or similar issues

o

on the same evidence

,

even though the legal basis of

the challenge is different f

rom that previously

brought

o


-----

428 (IAC)

the issues being raised could reasonably have been

raised at that previous JR or statut

ory appeal (one


stop

provision)


the pers

on is within the removal window


a JR renewal application has been made but an

application for injunction has already been

refused in

relation to that same JR application or an order has been

made th

at renewal is no bar to removal


there has been an injunction against removal refused

Do any of the following apply?


permis

sion h

as been granted on the JR


there has been an injunction against remova

l granted by

the court/tribunal


this is the first JR challenge to a decision to certify a claim,

the result of which being there is either no appeal or any


-----

428 (IAC)

appeal right is out of country

only (unless an

**The merits test**

**-**

is the JR

bound to fail?

Yes

No

No

Remov

al is

suspen

ded

No

Remov

al is

not

suspen

ded

No

Ye

Ye

**The barrier test**

**-**

are any

of the issues raised by the

JR a barrier to removal?

Ye

Stayed cases

Where the grounds for the JR have been resolved in a 'lead' case removal directions can be reset where:


-----

428 (IAC)

     - the person's application for JR was stayed as a result of the lead case

    - the application in that lead case has been dismissed or permission to JR in that lead case has been
refused

     - the person's grounds do not raise any issues additional to those which were the subject of the lead case

Additionally, the Home Office must consider whether it is appropriate to pursue removals in stayed cases, taking
into account:

     - any relevant court order

     - time given to provide the lead case with an opportunity to appeal

     - time given to provide stayed cases with an opportunity to amend their grounds

**Lead case has been resolved**

Once a lead case is resolved, the unit dealing with the case will inform appropriate business areas of the outcome
and implications. You must review your case against the lead case and decide whether the person's grounds raise
any issues additional to those in the lead case.

If you decide they do not, you may contact the GLD and ask them to write to the person to request that they either
withdraw their JR or apply to amend their grounds, making clear that removal directions will be re-set immediately if
there is no response. The person must be given at least 14 days to reply (or longer if necessary to comply with a
relevant court order). GLD will let you know the outcome.

If there is no application to amend grounds within the deadline, you may re-set removal directions to take effect no
sooner than 72 hours has expired and write to the person and their legal representative informing them of the new
removal directions.

You must instruct the GLD to inform the court or tribunal that removal directions have been set and removal will
continue.

If an application to amend the grounds is received you must consider deferring removal directions and also consider
whether the case can be expedited.

Judicial review challenges other than to removal

You must not automatically defer removal directions in these cases. You must only potentially suspend removal
when Article 6 (right to a fair trial) of the European Convention of Human Rights is cited and must decide this on a
case by case basis.

Removal directions deferred

If removal directions have been cancelled and JR proceedings have started you can get more information on next
steps from the following areas:

    - enforcement cases: Litigation Operations (Enforcement)(LOE)

    - third country cases: Third Country Unit between 9am-5pm Monday-Friday and OSCU at any other time

     - deportation cases: Litigation Operations Criminality and Detention (LOCDI)

If a JR has been received and you have deferred removal directions you must inform TCU in third country cases or
LOCDI in deportation cases. They will notify GLD and instruct them on the grounds for defence (it is important that
you ensure that GLD can obtain instructions or they will not be able to get the case before a judge quickly). For
enforcement cases, there is no need to notify LOE separately as OSCU pass enforcement cases to LOE once the


-----

428 (IAC)

decision has been made to defer RDs. LOE will consider if the case is suitable for expedition (see: Expedited
process).

Where summary grounds have been lodged and it is considered that the JR claim has no merit, GLD must be
instructed by the appropriate JR unit to notify the court of this, with a request that the application is expedited.
Where possible, detention can be maintained pending the outcome of the JR. See also: expedited process.

Removal directions must not be re-set until the appropriate JR unit has given authority to do so.

**Preparing the judicial review documentation**

Once instructed by the appropriate Home Office JR unit, GLD will draft an Acknowledgement of Service setting out
our argument. There are 21 days to do this once a claim has been issued. Under the expedited process, the JR
caseworker will normally instruct GLD to lodge our grounds of defence much earlier. The JR caseworker must
make sure the file is ready and be prepared to provide additional information to GLD.

The Acknowledgement of Service, summary grounds, and detailed grounds in JR proceedings are disclosable to
third parties so in each case you must decide whether sensitive information or material is included or whether you
make an objection to disclosure for example, where information is:

     - sensitive on grounds of security, policy, or some other ground of public interest

     - contains personal information relating to a third party

The JR caseworker must discuss this with GLD who will be able to advise on the duty of candour to the court and
tribunal.

Most applications are dealt with on the papers but the person may, if refused permission on the paper application
without a finding that the case is totally without merit, renew their request for permission orally. If permission for a
substantive JR is granted, the appropriate Home Office JR unit will consider if it is appropriate to continue to defend
the case and if so, will need to provide further instructions and more information to GLD. There are 35 days to
submit detailed grounds of defence.

Permission to apply for judicial review granted

If permission is granted either at the paper permission stage or oral hearing, the Home Office is required to lodge
our Detailed Grounds of defence within 35 days. A full 'substantive' hearing is listed. LOE, TCU, or LOCDI as
appropriate, in conjunction with GLD (and Home Office Legal Advisers in appropriate cases), will decide if the
challenge is resisted.

If permission to apply for JR is granted:

    - LOE, TCU, or LOCDI will inform the enforcement office or case owning team of the procedure to follow
and the likely time scale involved - especially when detention is a consideration

    - all enforcement action must be suspended immediately and must not be resumed until the application is
resolved, you must regularly review detention

GLD will instruct Counsel to represent the Home Office at the substantive hearing.

Expedited process

If your case falls into one of the categories detailed below, it may be suitable for expedition and you must refer the
case to LOE for enforcement challenges and LOCDI for Criminal Casework cases, to take a decision on expedition.
They, along with GLD, will let you know if the case is suitable to be put forward to the court to be dealt with quickly.

     - the claimant is in detention


-----

428 (IAC)

     - the claim is from a family being managed to departure through the family return process

     - the claim appears to be clearly without merit

     - the claim is an abuse of process

     - the issue of public safety arises

    - the decision-making process has previously been subject to accelerated timescales (e.g. NSA cases,
Detained)

     - there is a risk of self-harm

     - the claimant is or was to be removed as part of an enforcement operation (e.g. such as a special charter
flight)

    - for third country and CC cases expedition will be agreed directly with GLD. The JR caseworker must
notify LOE to ensure that the court's expedited quota is not exceeded)

The decision as to whether a case is expedited or not rests with the High Court.

**How to refer a case for expedition**

To enable LOE and GLD to make a decision on whether a particular case is expedited you must ensure that the
following key documents (if available) are included in your referral to OSCU for a decision in relation to deferral of
removal:

    - JR claim form and grounds

     - tribunal determination(s)

    - Reasons for Refusal Letter (RFRL)

     - any supplementary refusal letters

     - any submissions from the claimant

    - any other documents you consider appropriate

LOE officers will update CID notes when a decision regarding expedition has been made and will provide reasons
for rejecting any recommended cases from the expedited process. You must also ensure that the Home Office file
(or complete dummy file) is available as a matter of priority. Any delay in obtaining the file may lead to a case
**being rejected from expedition if further evidence from the file is needed to make a decision on expedition.**
JR caseworkers will aim to lodge an Acknowledgement of Service and grounds of defence within seven days where
expedition is deemed appropriate and the person is detained.

Where the Home Office has lodged grounds with a request to expedite, we can normally expect an outcome from
the court or tribunal within two weeks (from the date of lodging grounds).

Cases must only be expedited where we are confident that we can complete removal quickly if the permission
application is refused. Normally detention is maintained while a JR permission application is expedited as it is
considered removal is still imminent. If you do not believe there is a real likelihood of a quick removal you must
inform LOE (LOCDI in criminal cases) explaining why.

Permission to apply for judicial review refused

If permission to apply for JR is refused and the court or tribunal decides that the application for JR is clearly without
merit or that renewal is not a bar to removal, it will be made clear in the order refusing permission. In these
circumstances, the appropriate unit (LOE, TCU or LOCDI) will advise whether removal action can proceed. The
normal removal process must then be followed. You must apply the exceptions outlined in this chapter if
appropriate to do so


-----

428 (IAC)

If further submissions have been received, OSCU will notify the person and their legal representative if it is decided
that removal will not be deferred pending any application for oral renewal.

In other cases where permission on the papers is refused but oral renewal remains a possibility, LOE or TCU or
LOCDI will update CID, but will usually advise you not to re-set removal directions until the time limit for oral
renewal has passed unless there is a specific finding or order from the court or tribunal.

Where an application for injunction has been made and refused, or a JR was lodged within three months of
conclusion of a previous JR or appeal), OSCU may advise that oral renewal or the possibility of oral renewal should
not suspend removal.

Application to the Court of Appeal or Supreme Court

The Home Office or the claimant can seek to appeal against the decision of the Administrative Court or the Upper
Tribunal to the Court of Appeal and then to the Supreme Court.

If the claimant or their legal representative tells you that they intend to appeal to the Court of Appeal or the
Supreme Court you must contact the appropriate unit (OSCU or TCU or LOCDI) immediately. They will let you
know what to do next and advise whether or not to suspend enforcement action.

Where the application to the Court of Appeal or the Supreme Court concerns a challenge to a High Court or Upper
Tribunal Judge's decision to refuse to grant permission to apply for JR then removal directions can be maintained in
line with the judgment in Pharis - you must however refer these cases to OSCU in the first instance for their
confirmation of the position.

Injunctions in removal cases

An injunction is an order issued by a court requiring a party to do something or to refrain from doing something. In
removal cases, an injunction might be put in place to prevent the Home Office removing a person(s) from the United
Kingdom.

Where it is alleged by a person that an injunction against removal has been obtained, you must try to confirm this
with their legal representative (time permitting in writing or by fax). The written confirmation from the legal
representative may be no more than 'At [time] this evening Mr Justice X has granted an injunction over the
telephone barring removal – this is the phone number of the clerk of the judge who can be called to confirm the
existence of the order'. Where there is written confirmation or a verbal confirmation from a Duty Judge that an
injunction has been granted, this must be referred to OSCU immediately.

If there is any reason to believe an injunction may have been granted, you must contact OSCU who will check with
the Duty Judge to confirm verbally that an injunction has been issued.

OSCU is open 7am-9pm Weekdays and 7am-7pm at the Weekend. Outside of OSCU opening times, contact the
Command and Control Unit (CCU).

The removal must be stopped if enquiries confirm that an injunction has been issued.

**Injunction confirmed**

If the removal is imminent (the person is en-route to, or at, the port of embarkation) or is in progress (the aircraft is
on the ground and the doors are still open), the case owner [or CCU out of hours] must immediately take all
reasonable steps to ensure that the removal is stopped. In these cases, you must not wait until you have received
written confirmation of the injunction before cancelling the removal. You must:

    - if the removal is escorted: Immediately notify the Detainee Escorting and Population Management Unit
(DEPMU) that removal must be deferred, DEPMU will inform the escort officers


-----

428 (IAC)

     - if the removal is unescorted, immediately inform CCU

    - confirm to the legal representative or the High Court that the removal has been stopped and/or did not
proceed

You must clearly minute the file, CID records, and any other internal notes to confirm what action was taken to
attempt to stop the removal.

**Out of hours and urgent injunctions**

Claimants are served the Immigration Factual Summary when notice of removal is given which advises them that
any urgent application for an injunction preventing removal or order granting or refusing an injunction must be sent
to the Home Office team handling their case. The Immigration Factual Summary provides the appropriate
telephone and fax numbers to use. Outside of normal office hours (9am to 5pm weekdays) or during a public
holiday, the urgent application or order must be sent to CCU.

If an urgent injunction is not sent to CCU, but another Home Office premises, there is a risk that the information will
not be actioned prior to the person's scheduled removal and they will be removed from the United Kingdom despite
the injunction being granted.

You must keep OSCU updated of any developments on the case. Where an injunction is received but you are of
the opinion that the removal must not be pursued for other reasons, you must still inform OSCU that an injunction
has been issued.

OSCU operate between 7am and 9pm weekdays and from 7am to 7pm at weekends. Between those hours you
must forward any last-minute challenges to removal to OSCU to deal with.

You must ensure that, outside of your usual working hours and during weekends or bank/public holidays, legal
representatives know that urgent queries relating to any injunction against an imminent removal must be made to
the emergency hot line at CCU.

All answer-phone and voicemail messages for all areas must be updated to include the following:

**Team** **Message**
**or area**

LEOs/LITs/ ICE teams 'This office is now closed and will re-open at (insert time), for out of hours assistance, please
call the Command and Control Unit on 0161 261 1640'.

Other areas 'This office is now closed and will re-open at (insert time), for assistance with the service of
injunctions or last minute judicial reviews please call the Command and Control Unit on 0161
261 1640'.

**Injunction received, but it proves too late to halt the removal.**

Where a removal has already taken place, because the injunction arrived too late to halt the removal (for example
after the doors of the aircraft have closed):

    - you must inform the Court and OSCU as soon as possible that the person was removed

     - if you are able to quickly trace or contact the person (perhaps through their legal representatives in the
UK or, via DEPMU, any escorting officers who may be escorting them), you must make every effort to
assist their return to the UK

     - if it is not possible to return the person quickly, due to difficulties in tracing and/or organising their return,
you must continue to try to facilitate the return while ensuring that the court is kept aware of progress

|Team or area|Message|
|---|---|
|LEOs/LITs/ ICE teams|'This office is now closed and will re-open at (insert time), for out of hours assistance, please call the Command and Control Unit on 0161 261 1640'.|
|Other areas|'This office is now closed and will re-open at (insert time), for assistance with the service of injunctions or last minute judicial reviews please call the Command and Control Unit on 0161 261 1640'.|


-----

428 (IAC)

    - you must update CID regarding all actions taken, this must include times of events, such as telephone
calls from representatives or court staff, so that we are able to show that the Home Office has acted in a
timely fashion

     - the Grade 7 for the area that owns the case and has actioned it to the point of removal must notify the
Director for that area of work, the Director of OSCU and the Rapid Response Team (RRT) of the removal
immediately with all available information while further enquiries are being made and to put them on notice
that an urgent submission to the Minister will be prepared

     - immediately following the removal an urgent submission must be sent, via the relevant

Director General, to the Home Secretary, this must contain a chronology of events,

detailing the efforts made to halt the removal and why these were unsuccessful. It must also contain details of any
efforts being made to facilitate the person's return

**Injunction received, but removal has already taken place**

Where an injunction is received but removal was not prevented:

     - you must inform the court as soon as possible that the individual was removed

    - you must contact GLD and seek their advice

    - you must inform OSCU

     - the Grade 7 for the area that owns the case and has actioned it to the point of removal must notify the
Director for that area of work, the Director of OSCU and the Rapid Response Team (RRT) of the removal
immediately with all available information while further enquiries are being made and to put them on notice
that an urgent submission to the Minister will be prepared

     - immediately following the removal an urgent submission must be sent, via the relevant Director General,
to the Home Secretary, this must contain a chronology of events, detailing the efforts made to halt the
removal and why these were unsuccessful. It must also contain details of any legal advice received from
GLD

The case must be referred to LOE to review the full facts of the case to consider whether the order has been
obtained without any merit. If LOE believe this to be the case they can apply for the Court order to be discharged,
bearing in mind that a decision to make such an application must be made quickly and in consultation with Home
Office Legal Advisers and GLD. Note that you must continue to try to facilitate the individual's return whilst this
application is being processed.

Where, despite all efforts made, it is not possible to return the individual to the UK, LOE must approach the court
again to explain the full extent of steps taken, why return is not possible and to ask that the order is discharged. Any
decision not to pursue return must be taken at SCS level.

**Information that must be recorded on file**

When handling allegations of injunctions, you must maintain a clear record of all the actions taken on both the file
minutes and on CID. You must include the following details as part of your notes:

    - who informed you about the injunction and the time you were told/became aware

     - whether the injunction was confirmed by the legal representative or the Duty Judge and, if so, the time
confirmation was obtained

     - if no confirmation was received, the steps taken to confirm the existence or otherwise of the injunction


-----

428 (IAC)

    - details of other units or staff you contacted to cancel the removal in DEPMU or OSCU or CCU, include
the time these units were notified to cancel the removal and the time they confirmed removal was
cancelled (if times are different)

    - where an unlawful removal has taken place, details of all actions that have been taken to trace the
person and return them to the UK

Applications to the European Court of Human Rights

The _[Human Rights Act 1998 came into force on 2 October 2000, incorporating rights and freedoms guaranteed](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
under the European Convention on Human Rights into domestic law. A decision under section 82 of the Nationality
Immigration and Asylum Act 2002 can be appealed on human rights grounds. It is still possible for an application to
be made to the European Court of Human Rights (ECtHR), in Strasbourg, but it is unlikely that such an application
will be accepted until appeal rights have been exhausted.

An application made to the ECtHR does not in itself require the suspension of removal. However, when applying it
is possible to ask the Court, in effect, to order the suspension of removal action as an interim measure to allow the
Court to consider the substantive matter in full before removal takes place. The technical procedure to achieve this
is by making a request under Rule 39 of the Court's Rules. In response to such an application request, the ECtHR
will

(where appropriate) give a 'Rule 39 indication' indicating that the person must not be removed. This must be treated
in the same way as an injunction.

**Rule 39 indications from the European Court of Human Rights**

All enquiries relating to threats of, or applications for Rule 39 indications must be directed to the OSCU Duty Officer
in the first instance. Ongoing litigation (should a Rule 39 indication be granted) will be handled by Litigation
Operations.

A Rule 39 indication is similar to a High Court injunction but is made by the ECtHR. Where you have been notified
that a Rule 39 indication has been made, you must:

     - defer removal immediately

    - where the person is detained, make sure this development is considered in relation to any decision to
continue with detention

If a subject subsequently wishes to withdraw their Rule 39 application, that must be communicated to the Court,
The Court may wish to confirm this with the applicant, and you must take no action to enable removal of a subject
(including via voluntary departure) until you receive confirmation that the Court has accepted the application as
withdrawn.

Judicial review in Scotland

Judicial review (JR) in Scotland is pursued by means of a petition to the Court of Session in Edinburgh. There are
several differences in the way cases are handled in Scotland, not the least of which is the fact that there is no
permission to apply stage. If the court accepts the petition for JR they will grant First Orders. The granting of First
Orders allows the person bringing the case to serve the petition on the Office of the Advocate General (OAG).

Where a person has been granted First Orders and removal directions are in place, you must ask them for a copy
of the court order (interlocutor) granting First Orders and their petition for judicial review. You must then
immediately refer the case to Litigation Operations Scotland and Northern Ireland (Lit Ops SNI) or OSCU
(particularly when referring the case outside of normal office hours) who will provide advice on whether to defer
removal. Lit Ops SNI / OSCU will normally advise to suspend removal when a person has been granted First
Orders, but there are exceptions to this.


-----

428 (IAC)

Where a person has been granted First Orders, you must not automatically defer removal where:

    - there has been less than three months since a JR (in Scotland or elsewhere in the UK) or statutory
appeal has been concluded on the same or similar issues

    - there has been less than three months since a previous JR (in Scotland or elsewhere in the UK) or
statutory appeal has been concluded and the issues being raised could reasonably have been raised at
that previous JR or statutory appeal

     - an interim order to stay removal has already been refused, and no subsequent application for an interim
order has been granted

     - the person is being removed by special arrangements (including by charter flight).

    - removal is at the Ensured Return stage of the Family Returns Process

This list is not exhaustive, so you must always seek advice from Lit Ops SNI /OSCU when you are considering
whether to defer removal.

If an appeal is marked (called a reclaiming motion) against a decision of the Court of Session dismissing a petition
for JR that will not of itself prevent removal directions being set. Removal directions can be set if, after consultation
with the OAG, it is considered that an appeal is obviously lacking in merit. Generally, removal directions will not be
set within the 21 days during which a reclaiming motion can be marked. If a reclaiming motion is marked and
removal directions are subsequently set, the petitioner (via their legal representatives where applicable) must be
advised that in order to have their removal cancelled they must seek and obtain from the Inner House of the Court
of Session an interim order suspending those removal directions.

If you decide that removal will not be deferred, you must immediately notify the person or his legal representatives
in writing that removal will go ahead unless they obtain an interim order preventing removal. If an interim order is
granted, removal cannot take place until the petition is determined.

If a decision is made not to defer removal, in line with the exceptions set out in points 1 to 4, but the removal fails
for reasons unrelated to the JR proceedings, then removal directions may be re-set (or the ten-day policy applied),
provided that the reasons for the original decision that the JR should not suspend removal are still applicable.
Removal should be suspended if an interim order is obtained.

Judicial review in Northern Ireland

Judicial review (JR) in Northern Ireland is pursued by means of an application to the High Court of Justice. Leave
to apply for JR is made on an ex parte basis setting out the relief sought and the grounds of review relied upon.

Applications for JR in Northern Ireland must be brought to the attention of the Crown Solicitor's Office (CSO) via the
litigation team at Festival Court in Glasgow, who act on the Home Office's behalf in these cases, and who can
provide advice on how to proceed. Criminal cases are dealt with by LOCDI.

Completing the Immigration Factual Summary

**Immigration Factual Summary: functions**

An Immigration Factual Summary must, in all cases, be completed and served along with a notice of removal. It has
a number of functions:

     - it outlines to the person being removed all of the different actions which have been taken on their case
which have led to the setting of removal directions

     - should the person lodge an application for JR, their legal representative, OSCU, and the Administrative
Court or Upper Tribunal rely on the information contained within the summary in order to make a quick and


-----

428 (IAC)

informed decision concerning the person's case for JR and whether it is appropriate to maintain or defer
removal

     - additionally, the ECtHR relies on the information contained within the summary to assess the merits of an
application to them to impose interim measures under Rule 39 of the ECtHR's Rules of Court

     - it enables the Home Office to demonstrate to the court all of the steps that have been taken to address a
claim to remain in the UK, and to demonstrate that removal is now the appropriate course of action

**Immigration Factual Summary: completion**

The contents of the Immigration Factual Summary must be written clearly so that it can be understood by a person
outside the Home Office. It must be completed in plain English and without acronyms.

All fields must be completed. Most fields are self-explanatory, however some guidance is provided below.

Basic data fields

In the field entitled 'Legal Rep Address', if the person does not have a legal representative 'No legal representative
on record' must be recorded in that field and, where appropriate, 'The subject has been provided with a list of legal
representatives'.

In the field entitled 'Removal Date', do not record the date of departure if the person is being provided with only
'limited advance notification of removal'. Instead, you must record 'limited advance notice' in this field. The date
and time of departure must not be mentioned in the 'Immigration History' section of the form, but the reason for
giving 'limited advance notification of removal' must be stated in the 'Immigration History section'.

In the field entitled **'Other Litigation' all previous applications for JR; injunctions; and applications for interim**
measures under Rule 39 to the ECtHR must be recorded. The Administrative Court or Upper Tribunal office
reference number for each JR/injunction application must be recorded here in order to assist the Court. As an
example, 'The subject submitted an application for judicial review on dd/mm/yyyy (CO Ref: CO/00000/2011 or
Upper Tribunal ref: JR/00000/2014). Permission was refused on dd/mm/yyyy.'

It is important that wherever possible all of the information needed to complete the summary is obtained directly
from the Home Office file rather than from CID alone.

Immigration history

The more complete and accurate the immigration history the more able the Home Office will be to deal with
litigation quickly and effectively. An accurate Immigration Factual Summary will also reduce the likelihood of the
High Court granting last minute injunctions.

The Immigration History must be completed in chronological order.

The instructional text contained within the document will aid completion of the history and the guidance below
provides further assistance.

**Arrival in the UK**

     - record the most recent date of arrival in the UK, record the dates of any previous arrivals in the UK and
whether entry was made on a valid visa etc, or if leave to enter was refused

     - record any attempts at entering the UK illegally and method used (e.g. false passport, clandestine entry
in a lorry)

    - record any documents served to the person at the point of entry and the date on which the document
was served


-----

428 (IAC)

    - record any periods of Temporary Admission granted

    - record if the person has re-entered the UK post-removal or was returned from a third country under the
Dublin Convention

     - note if the person has entered in breach of an extant Deportation Order

**Departures or Removals from the UK**

     - record the date of any previous removals of the person from the UK

    - record the date of any voluntary departures made by the person from the UK

**Details of any valid leave held**

     - record the type and length of any previous leave held

     - if leave was curtailed, record the date of curtailment and the reason for the decision, note any documents
served to the person

**Claims made to the Home Office (asylum, human rights)**

     - note the date that the person made the claim and the nature of the claim (e.g. asylum, human rights)

    - record the outcome of the claim and the date of decision (e.g. refused asylum but granted exceptional
leave to remain (ELR), or certified as clearly unfounded under section 94 of the 2002 Act etc)

     - record if the refusal carried a right of appeal to the Tribunal or whether and why the claim did not carry a
right of appeal (for example claim certified under section 96 of the 2002 Act or refused under paragraph
353 of the Immigration Rules)

**Applications for leave to remain**

    - record the date of each application made to the Home Office and what type of application (for example
Leave to remain as a spouse, Leave to remain outside the Rules etc)

    - record the outcome of each application and, if appropriate period covered by the leave (for example
Leave to remain granted from dd/mm/yyyy to dd/mm/yyyy)

     - if the application was refused by the Home Office, state whether the refusal attracted a right of appeal
and whether the appeal was 'in country' or only exercisable from abroad

     - state if the application was refused and certified under either s94 or s96 of the 2002 Act

     - record the dates and outcome of any administrative review of a decision

**Appeals**

    - detail the date of any appeals made and the date and outcome of each appeal

     - detail all applications for permission to appeal to the First Tier Tribunal or Upper Tier Tribunal and the
outcome, prior to the existence of the Immigration and Asylum Chamber, applications for reconsideration
were made to the Asylum and Immigration Tribunal and/or to the High Court, and this must be reflected in
the Immigration Factual Summary if appropriate

     - record the date on which the person exhausted their appeal rights, also note if there are any remaining
appeals which may be exercised from outside the UK (for example following a refusal under section 94 of
the 2002 Act)

     - if the person had a right of appeal but did not exercise that right, record this information along with the
date on which they subsequently exhausted their appeal rights

**Further submissions**


-----

428 (IAC)

    - record the dates of all occasions when further submissions were made and the date of the outcome in
each instance, this includes any submissions made by Members of Parliament

     - if the further submissions attracted a right of appeal, record whether or not the appeal was exercised and
the outcome of the appeal

**Deportation Orders**

     - record the date when the person was notified of their Liability to Deportation and documents issued

    - record the date of Decision to Make a Deportation Order, note whether the person exercised a right of
appeal and the outcome of the appeal, record the date on which they exhausted their appeal rights

     - record the date that the Deportation Order was signed and served

     - if the person is subject to Automatic Deportation, record the date that the Decision to Make a Deportation
Order was served and whether there was a right of appeal to the Tribunal, date of appeal and outcome,
also note if there was a human rights or asylum claim refused in the Decision to Make a Deportation Order
which was certified under section 94 or section 96 of the 2002 Act

**Applications for JR and injunctions**

    - record the date of any applications for JR and/or injunctions, and record the outcome of those
applications together with the Administrative Court or Upper Tribunal office reference numbers

     - record if no JRs or injunctions have been sought in the 'Further Litigation' field

    - if removal is not being deferred despite a JR application state why (for example, there has been an
appeal within the last three months, removal via charter flight etc)

**Periods of detention and reasons for release**

Give details of:

     - all previous periods of detention and the reason for release

     - dates of service of IS96 and the reporting restrictions imposed

     - all incidents of failure to comply with reporting restrictions and the action taken

     - dates of all bail hearings and outcomes

**Dates of any periods of absconding Give details of:**

    - any periods where the individual has been classified as an absconder (see: Absconders and noncompliance)

**Removal directions**

    - record the date of any removal directions previously set and the reason for the failure to remove (for
example, the person was disruptive, illness, violence etc)

     - record the service date and time of removal directions, if less than standard notification is being provided,
state why, but do not record the date and time of the removal

     - state whether self check-in removal directions have been set previously and the reason for failure

     - where removal directions are set for removal by charter flight record the date that the assertive letter was
served

     - third country cases - state certified in accordance with third country legislation, claim to be considered by

[member state]


-----

428 (IAC)

**Disclaimers**

    - record the dates of any disclaimers signed by the person and the content of the disclaimer (withdrew a
right of appeal, agreed to depart voluntarily)

    - include any issues of non-compliance by the person in obtaining the Emergency Travel

Document (for example, failing to attend an interview or failing to complete documentation)

**Assisted Voluntary Return (AVR) and Facilitated Returns Scheme (FRS)**

     - record the date of when AVR was offered and how it was offered (e.g. face-to-face)

     - if a family is being returned you must state the date of any Family Return Conference(s) conducted

     - state if an AVR application was made but later withdrawn

    - for individuals subject to deportation, record if they have applied for FRS and the outcome of the
application

**Medical conditions**

    - record any known medical conditions (when diagnosed)

     - record if the Home Office has provided the person with medication

     - note any treatment they are currently receiving. Alternatively, state if treatment is not currently received

    - record any provisions that the Home Office has made for the removal of the person (for example,
medical escort, any additional medical equipment)

**Risk of self-harm or suicide**

     - note if there is a medical escort travelling with the person being removed

    - record if there is any evidence that the person has previously deliberately harmed themselves or has
attempted suicide

**End of Document**


-----

