# R v GS [2018] All ER (D) 90 (Aug)

[2018] EWCA Crim 1824

Court of Appeal, Criminal Division

EnglandandWales

Gross LJ, McGowan J and Judge Keith

31 July 2018

**Criminal law – Human trafficking – Prosecuting victims of trafficking in the public interest**
Abstract

_Criminal law – Human trafficking. Citable guidance was provided on the change in law relating to the prosecution of_
_victims of trafficking for their alleged criminality. The Court of Appeal, Criminal Division, dismissed the defendant's_
_application for leave to appeal against conviction for being knowingly concerned in the fraudulent evasion of the_
_prohibition on the importation of a controlled drug of Class A, because, having had regard to the change in law, it_
_could not be said that she had been under such a level of compulsion that her criminality or culpability in the_
_importation of Class A drugs had been reduced to or below a point where it was not in the public interest for her to_
_have been prosecuted._
Digest

The judgment is available at: [2018] EWCA Crim 1824

**Background**

In February 2007, the defendant Jamaican national arrived at London Heathrow airport on a flight from Trinidad.
She was stopped by customs officers and an x-ray revealed that she had been carrying inside her body 22
packages of cocaine. At trial, it was the defendant's case that she had been acting under duress, involving the
threat of serious injury or death to her and/or her young son, in the event that she had refused to comply with the
demand to smuggle drugs. In November, the defendant was convicted of being knowingly concerned in the
fraudulent evasion of the prohibition on the importation of a controlled drug of Class A. She was sentenced to seven
years' imprisonment.

Following her release from prison, the defendant was found a victim of trafficking (VOT) for the purposes of forced
criminality. In the present proceedings, the defendant applied for an extension of time, of approximately nine years
and seven months, for leave to appeal against conviction and to rely on fresh evidence. The fresh evidence
application consisted of: (i) the conclusion that the defendant had been a VOT (the first part); and (ii) medical
evidence which went to the defendant's mind state (the medical evidence).

Application for permission dismissed.

**Issues and decisions**

(1) Whether the present application was a 'change in law' case, so that the grant of leave required substantial
injustice to be shown.


-----

The present application was a 'change in law' case. First, there was a material change in the legal recognition of the
rights of VOTs between 2007 and the present time. Second, the provisions of art 26 of the Council of Europe
Convention on Action against Trafficking in Human Beings (ECAT) and _[art 8 of Directive (EU) 2011/36 had not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CM-00000-00&context=1519360)_
been in force in the present jurisdiction in 2007. Third, to the extent that Crown Prosecution Service guidance was
relevant, the contrast between the 2007 and 2013 Guidance had been stark. What had emerged was more than
simply a development in the existing law relating to VOTs. It could not seriously have been argued that, on the law
and practice as understood in 2007, it had been an abuse of process for the prosecution of the defendant to
proceed. The defendant's application (and any appeal) depended on a change in law. Accordingly, to obtain
exceptional leave, it had to be shown that to refuse leave would occasion substantial injustice (see [64] of the
judgment).

In applying the change in law test to the present facts, the defendant's conviction and sentence would impact on her
immigration status. As a refugee, she was granted leave to remain in the UK for five years running until late 2020.
At that point in time, her refugee status and any grant of further leave to remain would be at risk by reason of her
conviction and sentence of imprisonment for at least four years. In consequence, if the defendant was otherwise
capable of demonstrating an arguable case as to the unsafety of her conviction, she ought not to fail at the hurdle of
obtaining exceptional leave. The risk to her immigration status would constitute a substantial injustice if, in such
circumstances, she had been precluded from challenging her conviction by reason of the requirement to obtain
exceptional leave (see [65] of the judgment).

_R v Ordu_ _[[2017] EWCA Crim 4 distinguished.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MNW-82J1-F0JY-C4M8-00000-00&context=1519360)_

(2) Whether the fresh evidence, or any part of it, was admissible.

On the facts, the first part of the fresh evidence would be admitted. Receipt of that material was expedient in the
interests of justice. Its essence was the recognition that the defendant had been a VOT. It would not have been in
the interests of justice to proceed with the application (and any appeal) without having had regard to that evidence.
Among other things, the evidence was capable of belief; it might have afforded a ground for allowing the appeal; it
post-dated the trial, and so could not have been adduced at trial (see [67], [68] of the judgment).

The new medical evidence, however, would not be admitted. Its reception had not been necessary or expedient in
the interests of justice (see [70], [74] of the judgment).

(3) Whether the defendant's conviction was unsafe.

Neither art 26 of ECAT nor art 8 of the Directive conferred a blanket immunity from prosecution on VOTs.

Instead, the UK's international obligations required the careful and fact-sensitive exercise by prosecutors of their
discretion as to whether it was in the public interest to prosecute a VOT. That discretion was vested in the
prosecutor, not the court.

The decision as to whether an individual was a VOT did not bind prosecutors or the court, but would be respected
(subject to submissions as to their basis or limitations) unless there was good reason not to follow them.

There was no closed list of factors bearing on the prosecutor's discretion to proceed against a VOT. Generalisation
was best avoided. Nonetheless, factors obviously impacting on the discretion to prosecute went to the nexus
between the crime committed by the defendant and the trafficking. If there was no reasonable nexus between the
offence and the trafficking then, generally, there was no reason why, on trafficking grounds, the prosecution should
not proceed. If there were a nexus, in some cases the levels of compulsion would be such that it would not be in the
public interest for the prosecution to proceed. In other cases, it would be necessary to consider whether the
compulsion was continuing and what, if any, reasonable alternatives had been available to the VOT. There would
be cases where a decision to prosecute would be justified, but due allowance could be made for mitigating factors
at the sentencing stage.


-----

The question for the court went to the safety of the conviction. Namely, whether the case in question was one
where either: (i) the dominant force of compulsion, in the context of a very serious offence, was sufficient to reduce
the defendant's criminality or culpability to or below a point where it had not been in the public interest for the
defendant to be prosecuted; or (ii) the defendant would or might not have been prosecuted in the public interest. If
answered yes, then the proper course would be to quash the conviction (see [76] of the judgment).

In the present case, having had regard to the change in the law and the fresh evidence admitted, the defendant's
conviction had not been, even arguably, unsafe. It had been a case where, in the context of the importation of Class
A drugs, it could not be said that the defendant had been under such a level of compulsion that her criminality or
culpability had been reduced to or below a point where it was not in the public interest for her to be prosecuted. In
[short, even on the law as it presently stood (leaving s 45 of the Modern Slavery Act 2015 out of account), provided](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
only that a prosecutor had properly considered the defendant's position as a VOT in accordance with the law and
guidance to which the court had been referred, it could not be concluded that it would have been an abuse for the
defendant to have been prosecuted. Accordingly, the defendant's application would be refused. Nonetheless, the
court certified the judgment as citable in court (see [77], [82], [83] of the judgment).

_R v LM_ _[[2010] All ER (D) 202 (Oct) applied; R v N; R v E](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_ _[[2012] All ER (D) 128 (Feb) applied; R v L](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5513-TB01-DYBP-N1F7-00000-00&context=1519360)_ _[[2014] 1 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_
_[113 applied; R v Joseph](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_ _[[2017] All ER (D) 100 (Feb) applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_

Francis FitzGibbon QC (instructed by Scott-Moncrieff & Associates Ltd) for the defendant.

Ben Douglas-Jones QC (instructed by the Crown Prosecution Service) for the Crown.
Manveer Cheema Barrister.

**End of Document**


-----

