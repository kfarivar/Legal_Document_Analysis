transitional provisions, deportation) [2024] UKUT ....

# R (on the application of VLT (Vietnam)) v Secretary of State for the Home
 Department (Trafficking, DL policy, transitional provisions, deportation)

 [2024] UKUT 67 (IAC)

UK Upper Tribunal (Immigration and Asylum Chamber)

Upper Tribunal Judge Frances

8 February 2024Judgment

**Ms G Mellon and Ms E Doerr**

(instructed by Turpin Miller) for the applicant

**Mr M Biggs**

(instructed by the Government Legal Department) for the respondent

**- - - - - - - - - - - - - - - - - - - -**

**J U D G M E N T**

**- - - - - - - - - - - - - - - - - - - -**

**Order regarding anonymity**

**Pursuant to rule 14 of the Tribunal Procedure (Upper Tribunal) Rules 2008, the appellant is granted**
**anonymity. No-one shall publish or reveal any information, including the name or address of the applicant,**
**likely to lead members of the public to identify the applicant. Failure to comply with this order could**
**amount to a contempt of court.**

(1) _The policy guidance on Discretionary Leave, version 10, published on 16 March 2023 makes transitional_
_provisions in respect of victims of trafficking who received a positive conclusive grounds decision and had an_
_outstanding asylum claim before 30 January 2023._

(2) These transitional provisions were intended to give effect to Article 14(1)(a) ECAT and EOG and KTT v SSHD

_[2022] EWCA Civ 307 in respect of victims of trafficking who received a positive conclusive grounds decision and_
_had an outstanding asylum claim, based in a material part on a well-founded fear of being re-trafficked, before 30_
_January 2023._

(3) _The Discretionary Leave policy, version 10, is unlawful in so far as it provides that individuals subject to_
_deportation proceedings must not be considered under the transitional provisions (“the deportation carve out”)._

(4) The deportation carve out is unlawful in so far as it excludes individuals who are not a threat to public order or
_[foreign criminals within the meaning given by section 32(1) of the UK Borders Act 2007 from benefitting from the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y17N-00000-00&context=1519360)_
_transitional provisions._


-----

transitional provisions, deportation) [2024] UKUT ....

(5) _The deportation carve out is incompatible with the obligations in Article 14(1)(a) ECAT and contrary to the_
_[requirements of sections 63 and 65 of the Nationality and Borders Act 2022 currently in force.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3723-CGX8-02KH-00000-00&context=1519360)_

**Judge Frances:**

**Introduction**

1. The applicant is an asylum seeker and confirmed victim of trafficking. Having considered the Presidential
Guidance on Anonymity Orders, I make an order under Rule 14 of the Procedure Rules.

2. This application for judicial review is concerned with the interpretation of policy guidance in respect of victims of
trafficking who received a positive conclusive grounds decision and had an outstanding asylum claim before 30
January 2023. The applicant in this case was also subject to a deportation order.

3. The central issue is the interpretation of the policy guidance on Discretionary Leave, version 10, published on 16
March 2023 (DLP). Reference to the DLP is to this version of the policy guidance.

**Decision under challenge**

4. The applicant challenges the respondent's decision of 12 June 2023 refusing temporary permission to stay
under the policy guidance: Temporary Permission to Stay considerations for Victims of Human Trafficking or
Slavery, version 3.0, published on 8 June 2023 (VTSP). Reference to the VTSP is to this version of the policy.

5. The respondent considered the psychological report by Lisa Davies, the country information on Vietnam and the
current circumstances questionnaire (CCQ) and concluded the applicant was not taking medication or receiving
counselling and he could obtain treatment in Vietnam. The respondent refused temporary permission to stay (VTS)
because it was not necessary for the applicant to receive VTS for a medical reason. The respondent went on to
state that consideration had been given to part 9 of the Immigration Rules and VTS must be refused because
“previous behaviour is deemed not conducive to the public good”.

6. The applicant also seeks to challenge the respondent's response to the pre-action protocol letter dated 4 August
2023. I find this is not a challengeable decision. It explains why the applicant's case was considered under the
VTSP and not the DLP. I am satisfied the applicant challenges the decision of 12 June 2023 on the grounds the
respondent considered the wrong policy and/or failed to grant limited leave to remain under the DLP.

**Grounds**

7. The applicant challenges the decision of 12 June 2023 on 3 grounds (the applicant no longer relies on ground 2
alleging breach of a legitimate expectation):

a) Ground 1: The refusal to grant DL/decision to exclude the applicant from consideration for a grant of leave under
the DLP was in breach of Article 14(1)(a) of the Council of Europe Convention on Action against Trafficking in
Human Beings (ECAT) which was implemented at the relevant time by the DLP;

b) Ground 3: The DLP breaches Article 14(1)(a) of ECAT and Article 4 of the European Convention on Human
Rights (ECHR); and

c) Ground 4: The decision to refuse VTS was unlawful owing to the respondent's failure to take into account
material expert evidence and/or her erroneous approach to the evidence.

**Agreed facts**

8. The applicant's immigration history is complex and is set out in the chronology at pages 101 to 104 of the Trial
Bundle. The following relevant facts were agreed at the hearing at which the applicant relied on the respondent's
decision dated 23 September 2022 referred to below.


-----

transitional provisions, deportation) [2024] UKUT ....

9. The applicant is a national of Vietnam and is 57 years old. He was trafficked to the UK on three occasions, in
2009, 2015 and 2018, and forced to cultivate cannabis to repay a debt he owed. He was convicted of conspiracy to
produce cannabis and sentenced to 8 months' imprisonment on 26 June 2012. A deportation order was signed on
16 January 2013. The applicant claimed asylum on 1 June 2018 on the basis of a well-founded fear of being retrafficked on return to Vietnam.

10. On 29 May 2018, the applicant was referred to the National Referral Mechanism (NRM) and he received a
positive reasonable grounds decision on 27 June 2018. The Single Competent Authority (SCA) concluded the
applicant had given a consistent and plausible account corroborated by objective evidence. The SCA decided the
applicant was a victim of trafficking, in Vietnam, Laos, Thailand and the UK and issued a positive conclusive
grounds decision (CGD) dated 23 September 2022.

11. On 26 October 2022, the applicant made further submissions in respect of his deportation and the respondent
refused his protection and human rights claim on 15 August 2023. The applicant has a pending appeal against the
refusal to revoke his deportation order on asylum, humanitarian protection and human rights grounds. He fears
being re-trafficked on return to Vietnam. The applicant is not removable whilst his appeal is pending. He does not
have permission to work and is accommodated and supported by the Vietnamese community in the UK.

12. The applicant, through his solicitors, requested discretionary leave to remain (DL) by email on 10 November
2022. These representations were supported by a psychological report by Lisa Davies dated 21 July 2021. It is not
in dispute that the applicant was not assisting a public authority with their enquiries or claiming compensation.

**Relevant procedural history**

13. The applicant applied for permission to apply for judicial review on 15 September 2023. Expedition was granted
and time was extended on the same date. Upper Tribunal Judge Norton-Taylor granted permission on 16 October
2023. The respondent raised the issue of jurisdiction in the summary grounds of defence (SGD). Judge NortonTaylor was of the view that there was no challenge to the Immigration Rules or legislation and therefore the Upper
Tribunal had jurisdiction. The respondent did not rely on this issue in his skeleton argument or at the hearing before
me.

**Chapter III ECAT**

14. Article 14 (1) of the ECAT provides:

“1.  Each Party shall issue a renewable residence permit to victims, in one or other of the two following situations or
in both:

(a) the competent authority considers that their stay is necessary owing to their personal situation;

(b) the competent authority considers that their stay is necessary for the purpose of their co-operation with the
competent authorities in investigation or criminal proceedings.”

15. Article 13 of the ECAT provides for a 'recovery and reflection period' of at least 30 days when there are
reasonable grounds to believe that the person concerned is a victim of trafficking. Article 13(3) provides an
exception to the duty to provide the relevant recovery period where “grounds of public order prevent it.” Article
14(1)(a) contains no exception on grounds of public order equivalent to that set out in Art 13(3).

**Relevant authority**

16. In EOG and KTT v SSHD _[2022] EWCA Civ 307 (KTT), Underhill LJ (with whom Dingemans LJ and Sir_
Geoffrey Vos MR agreed) considered justiciability as a preliminary issue and reviewed a number of cases in which
the respondent's guidance about the treatment of victims of modern slavery and trafficking had been challenged
on the basis they did not give proper effect to the requirements of chapter III of ECAT. It was recognised in all these
cases that ECAT was not incorporated into UK law and did not have 'direct effect'. However, insofar as guidance


-----

transitional provisions, deportation) [2024] UKUT ....

intended to, and purported to, give effect to ECAT and failed to do so, that would be a justiciable error of law and a
decision based on that error would be unlawful ([25]-[30]).

17. Underhill LJ found that Linden J's analysis of this issue at [15]-[59] of his judgment (R (KTT) v SSHD [2021]
_EWHC 2272 (admin)) was convincing and made two points in clarification. Firstly, many of the obligations imposed_
by ECAT were in general terms and it was a matter for the Government (subject to public law constraints) in what
manner it chooses to implement them. It was always open to the Government, since ECAT was unincorporated, to
make it clear that it has chosen not to give effect to it. As a matter of constitutional principle such a decision could
not be challenged in the domestic courts. Secondly, the conclusion that the guidance was unlawful was not the only
possible outcome. Where the guidance was ambiguous it may be enough for the court to hold that a construction
which complies with ECAT should be preferred to one which did not ([32]-[34]).

18. Underhill LJ at [37] concluded that in principle there were two questions in cases of this kind: “(1) whether the
guidance is in the relevant respects intended by the Secretary of State to give effect to the requirements of ECAT
and (2) whether it in fact does so.”

19. In considering the first question, Underhill LJ noted there were a large number of revised versions of the
original guidance. The version relevant in KTT's case included a statement that this guidance is based on ECAT
and the sections dealing with the grant of DL on grounds of personal circumstances plainly corresponded to Article
14(1)(a) of ECAT. Underhill LJ found that it was plain that the intention was to give effect to Article 14 (1)(a) ([68]
[77]).

20. Underhill LJ again endorsed the reasoning of Linden J when considering whether the guidance, as applied in
KTT's case, did give effect to Article 14(1)(a) and concluded that it did not do so. In summary, Article 14(1)(a) of
ECAT required a grant of leave to remain to allow an established victim of trafficking to pursue an asylum claim
which is related to the claimant's situation as a victim of trafficking. The relevant guidance in force at the time did
not provide for this situation.

21. The Court of Appeal upheld the order of Linden J:

“1.  On their true construction, versions 2, 3 and 4 of the Defendant's policy “Discretionary Leave for Victims of
**_Modern Slavery” (“the MSL policy”) require the defendant's decisions on the grant of leave to remain to be made in_**
accordance with Article 14(1)(a) ECAT, which requires the grant of a residence permit to a confirmed victim of
**_modern slavery if their stay in the UK is necessary owing to their personal situation._**

2.  The statutorily-protected stay in the United Kingdom of a confirmed victim of trafficking pending the resolution of
an asylum claim made by them which is based on a fear of being re-trafficked is capable of constituting a stay
which is necessary owing to their personal situation within the meaning of Article 14(1)(a) ECAT.”

**_[Nationality and Borders Act 2022 (NABA)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_**

22. Sections 65 of the provides:

“Leave to remain for victims of slavery or human trafficking

(1) This section applies if a positive conclusive grounds decision is made in respect of a person—

(a) who is not a British citizen, and

(b) who does not have leave to remain in the United Kingdom.

(2) The Secretary of State must grant the person limited leave to remain in the United Kingdom if the Secretary of
State considers it is necessary for the purpose of—


-----

transitional provisions, deportation) [2024] UKUT ....

(a) assisting the person in their recovery from any physical or psychological harm arising from the relevant
exploitation,

(b) enabling the person to seek compensation in respect of the relevant exploitation, or

(c) enabling the person to co-operate with a public authority in connection with an investigation or criminal
proceedings in respect of the relevant exploitation.

(3) Subsection (2) is subject to section 63(2).

…

(6) Subsection (7) applies if the Secretary of State is satisfied that—

(a) the person is a threat to public order, or

(b) the person has claimed to be a victim of slavery or human trafficking in bad faith.

(7) Where this subsection applies—

(a) the Secretary of State is not required to grant the person leave under subsection (2), and

(b) if such leave has already been granted to the person, it may be revoked.

(8) Leave granted to a person under subsection (2) may be revoked in such other circumstances as may be
prescribed in immigration rules.

(9) Subsections (3) to (7) of section 63 apply for the purposes of this section as they apply for the purposes of that
section.”

23. Section 63 provides in material part:

“Identified potential victims etc: disqualification from protection

(1)￿￿A competent authority may determine that subsection (2) is to apply to a person in relation to whom a positive
reasonable grounds decision has been made if the authority is satisfied that the person—

(a)￿￿is a threat to public order, or

(b)￿￿has claimed to be a victim of slavery or human trafficking in bad faith.

(2)￿￿Where this subsection applies to a person the following cease to apply—

(a)￿￿any prohibition on removing the person from, or requiring them to leave, the United Kingdom arising under
section 61 or 62, and

(b)￿￿any requirement under section 65 to grant the person limited leave to remain in the United Kingdom.

(3)￿￿For the purposes of this section, the circumstances in which a person is a threat to public order include, in
particular, where—

…

(f)￿￿the person is a foreign criminal within the meaning given by section 32(1) of the UK Borders Act 2007
(automatic deportation for foreign criminals);…”

**Immigration Rules**


-----

transitional provisions, deportation) [2024] UKUT ....

24. Appendix: Temporary Permission to Stay for Victims of Human Trafficking or Slavery (IR-VTS) commenced on
30 January 2023. The suitability requirements for temporary permission to stay as a victim of modern slavery or
human trafficking are that:

“VTS 2.1. The applicant must not fall for refusal as a threat to public order (as defined in Section 63 of the
Nationality and Borders Act 2022), or as a person who has claimed to be a victim of Human Trafficking or Slavery in
bad faith (as per Section 63 of the Nationality and Borders Act 2022).”

25. The eligibility requirements for temporary permission to stay provide that:

“VTS 3.1. The requirements to be met by a person for permission to stay on the grounds of being a confirmed victim
[of Human Trafficking or Slavery are (as set out in Section 65 (2) (a) to (c) of the Nationality and Borders Act 2022),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)
that the grant of permission to stay is necessary for the purpose of: 
(a) assisting the person in their recovery from any physical or psychological harm arising from the relevant
exploitation; or

(b) enabling the person to seek compensation in respect of the relevant exploitation, or

(c) enabling the person to co-operate with a public authority in connection with an investigation or criminal
proceedings in respect of the relevant exploitation.

VTS 3.2. For the purpose of VTS 3.1 the following apply:

(a) “physical or psychological harm” means harm of a type that results in physical trauma to the person; or
psychological harm that causes mental or emotional trauma or that causes behavioural change or physical
symptoms that require psychological or psychiatric care and where the physical or psychological harm arises from
the “relevant exploitation”; and

(b) “assisting the person in their recovery” for psychological or physical harm means that the applicant requires
support either through the National Referral Mechanism or other services to assist in their recovery from their
exploitation (this support does not need to accomplish recovery); and

(c) “seeking compensation” means that the person must have made an application for compensation in respect of
the relevant exploitation; and

(d) “an investigation or criminal proceedings” means an investigation by the public authorities or criminal
proceedings within the UK which has been confirmed by the relevant public authority or by the Criminal Prosecution
Service; and

(e) “relevant exploitation” means the conduct resulting in the positive conclusive grounds decision.

VTS 3.3. Permission to stay is not necessary for the purpose of VTS 3.1(a), as set out in Section 65 (4) (a) of the
_[Nationality and Borders Act 2022:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_

(a) if the Secretary of State considers that the applicant's need for assistance is capable of being met in a country
or territory of which they are a national or citizen; or one to which they may be removed in accordance with an
agreement between that country or territory and the UK (which may be, but does not need to be, an agreement
contemplated by Article 40(2) of the Trafficking Convention).

VTS 3.4 Permission to stay is not necessary for the purpose of VTS 3.1(b) as set out in Section 65 (4) (b) of the
_[Nationality and Borders Act 2022,if the applicant is capable of seeking compensation from outside the UK, and it](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_
would be reasonable for them to do so in the circumstances.”

**Policy Guidance**


-----

transitional provisions, deportation) [2024] UKUT ....

26. The policy guidance on DL was published in June 2013 and has been updated on numerous occasions since
then. The DLP version 10 was published on 16 March 2023 and the section on **_modern slavery and human_**
trafficking cases was updated to implement caselaw (KTT).

27. The policy guidance on VTS was first published on 30 January 2023 and VTSP version 3 was published on 8
June 2023. The relevant versions of both policies, DLP and VTSP, post-date the coming into force of sections 63
and 65 of NABA 2022 on 30 January 2023.

DLP

28. The DLP provides that it must be read in conjunction with other key guidance, in particular and including the
VTSP. It states (at page 6 of 30):

“Individuals with a positive conclusive grounds decision whose outstanding asylum claim or further submissions
(which is based in a material part on a claim to a well-founded fear of re-trafficking/real risk of serious harm due to
re-trafficking) has not been finally determined before 30 January 2023 should be considered for DL. DL will normally
be granted in these circumstances on the grounds that their 'stay in the UK is necessary' to pursue their asylum
claim or further submissions. Cases on or after 30 January 2023 – this includes individuals who received a positive
conclusive grounds decision before 30 January 2023 but did not claim asylum or lodge further submissions until
after 30 January 2023 (or vice versa) – will be considered under the Temporary Permission to Stay considerations
for Victims of Human Trafficking or Slavery policy.”

29. The section on modern slavery and human trafficking cases states that from 30 January 2023 those with a
CGD may be eligible for VTS based on the criteria in section 65 NABA 2022. The DLP then goes on the consider
pre-30 January 2023 cases and states:

“Individuals who before 30 January 2023, had both a positive conclusive grounds decision and had made an
asylum claim or further submissions, based in a material part on a claim to a well-founded fear of re-trafficking/real
risk of serious harm due to re-trafficking, which had not been finally determined, were potentially entitled to DL had
their applications for leave been determined under the Home Office policies prior to 30 January 2023.”

…

“Individuals who meet the requirements above may be entitled to DL because the Home Office policies in force at
the time implemented Article 14 (1)(a) of the Council of Europe Convention on Action against Trafficking in Human
Beings 2005 (ECAT).

The Court of Appeal in the case of EOG & KTT v Secretary of State for the Home Department [2022] EWCA Civ
_307 (17 March 2022), referred to as 'KTT', determined that the Home Office approach to applications for Modern_
**_Slavery Discretionary Leave was not in accordance with Article 14 (1)(a) of ECAT (which the policy was found to_**
commit to implementing). Article 14 (1)(a) of ECAT leads states to consider whether the victim's “stay is necessary
owing to their personal situation". The Court found that a confirmed victim of trafficking, who has an outstanding
asylum claim which is trafficking-related, requires a consideration of leave to remain in the UK because their 'stay in
the UK is necessary', owing to their personal situation as a victim of trafficking, in order to pursue that asylum
claim.”

30. In considering when to grant DL, the DLP states:

“Under this policy, those individuals who were eligible for consideration of leave to remain under the KTT judgement
prior to 30 January 2023, will not have their applications for DL determined under Temporary Permission to Stay
considerations for Victims of Human Trafficking or Slavery. Instead, where:

- a competent authority made a positive conclusive grounds decision prior to 30 January 2023; and


-----

transitional provisions, deportation) [2024] UKUT ....

- the individual had prior to 30 January 2023 articulated an asylum claim or further submissions which were
trafficking-related as set out above; and

- the individual's asylum claim or further submissions have at the present date not yet been finally determined (this
means that they are still awaiting a decision or still have in-country appeal rights to exercise)

you must consider granting DL. DL will normally be granted in these circumstances.

This leave will either be curtailed or varied once the asylum or further submissions decision has been finally
determined. Any future application for an extension of leave will be determined under Temporary Permission to
Stay considerations for Victims of Human Trafficking or Slavery.”

31. The DLP states that DL does not need to be considered where the individual falls to be refused under part 9 of
the immigration rules (general grounds of refusal) or is subject to deportation proceedings. In respect of deportation
cases the DLP states (at page 14 of 30):

“Where the individual is currently subject to deportation proceedings, either by way of an extant deportation order or
where a deportation decision has been made and deportation continues to be pursued, they must not be
considered under the DL policy for **_modern slavery (including human trafficking) cases pre-30 January 2023._**
Instead they will be considered under Temporary Permission to Stay considerations for Victims of Human
Trafficking or Slavery upon application.” ('the deportation carve out')

VTSP

32. The VTSP clearly states under the section on 'policy intention' that it represents a shift in policy intention as
regards how the Secretary of State complies with its obligations under ECAT. It states:

“As discussed in the section below on The Council of Europe Convention on Action against Trafficking in Human
Beings (ECAT) this guidance represents a shift in our policy intention as regards how the Secretary of State
complies with obligations regarding grants of renewable residence permits to victims of **_modern slavery under_**
ECAT.

As set out below, ECAT is clear that under Article 14 signatory states can elect whether to grant a residence permit
in the circumstances described in 14(1)(a) or 14(1)(b) or in both.

From the date of this guidance the Secretary of State will grant VTS in the circumstances described in Article
14(1)(b) as mirrored in s65(2)(c) of the Nationality and Borders Act 2022 (NAB Act). The Secretary of State will also
grant VTS in compliance with section 65 of the NAB Act. This is not because she considers that, other than
s65(2)(c) as discussed above, this is required by ECAT (or any other international obligations), but because she
has been bound to do so by Parliament as a matter of domestic law.”

33. In the section dealing with International Obligations: ECAT it states:

“Historically the Secretary of State's policy intention was to grant leave in both situations (14(1)(a) and 14(1)(b)).
However, the Secretary of State has decided to change the policy approach as follows with effect from the date of
this Guidance. From this date the UK will fulfil its obligations regarding grants of renewable residence permits to
victims of modern slavery through the grant of temporary permission to stay (VTS) as follows:

- the Secretary of State will grant VTS in the circumstances described in Article 14(1)(b) and accordingly s65(2)(c)
of the Nationality and Borders Act (NAB Act) mirrors ECAT Article 14(1)(b)

- the Secretary of State will also grant VTS in compliance with section 65 of the NAB Act - this is not because she
considers that, other than s65(2)(c) as discussed above, this is required by ECAT [or any other international
obligations], but because she has been bound to do so by Parliament as a matter of domestic law.


-----

transitional provisions, deportation) [2024] UKUT ....

References in this guidance to when VTS leave may be granted for reasons beyond those in 65(2)(c) of the NAB
Act are not intended to fulfil A14(1)(a) but is a matter of domestic policy only as set out in s65 of the NAB Act.”

**Conclusions on the interpretation of policy**

34. In KTT, the Court of Appeal considered the statutory guidance on modern slavery and the guidance entitled
“Discretionary leave considerations for victims of modern slavery” referred to as the MSL policy. The court upheld
the order of Linden J that versions 2, 3 and 4 of the MSL policy require decisions on a grant a leave to be made in
accordance with Article 14(1)(a) ECAT.

35. The situation has moved on since then and the legal landscape has changed with the coming into force of
section 65 NABA 2022 on 30 January 2023. The criteria for granting permission to stay in relation to confirmed
victims of modern slavery and trafficking are set out in the IR-VTS and the VTSP. It is not in dispute that the VTSP
expresses a clear intention not to implement the obligations in Article 14(1)(a) of the ECAT from 30 January 2023.

36. The applicant challenges the refusal of VTS on the grounds that the VTSP does not apply and he should have
been considered and granted DL under the DLP. The DLP version 10 published on 16 March 2023 post-dates the
coming into force of section 65 NABA 2022 and the first publication of the VTSP. I am not persuaded that the
VTSP, in light of section 65 NABA 2022, is the starting point because both policies remain in force and the DLP
states it must be read in conjunction with other key guidance including the VTSP.

37. The principles at [37] of KTT apply and I first have to consider whether the DLP evinces an intention to give
effect to the requirements of ECAT and secondly whether it in fact does so.

Does the DLP intend to give effect to Article 14(1)(a) ECAT ?

38. The VTSP demonstrates a distinct shift in policy intention whereas the DLP expresses no such intention
notwithstanding it was published after section 65 NABA 2023 came into force.

39. In addition, the DLP identifies two categories of **_modern slavery cases. Post-30 January 2023_** **_modern_**
**_slavery cases will be considered under the VTSP (VTS Cases) based on the criteria in section 65 NABA 2022. Pre-_**
30 January 2023 modern slavery cases will be considered under the DLP (DLMS Cases).

40. The DLP makes specific provision for individuals who have received a positive CGD and made an asylum
claim, based in material part on a well-founded fear of re-trafficking, before 30 January 2023 which has not been
finally determined (DLMS Cases). The DLP states at the outset (page 6) that DL will normally be granted in these
circumstances on the grounds that their 'stay in the UK is necessary' to pursue their asylum claim.

41. The respondent accepts these are transitional provisions, but submits there was no clear commitment to Article
14(1)(a) ECAT in the DLP and no basis for that inference. To do so would be inconsistent with the VTSP which
expressly takes the position that the respondent does not intend to apply Article 14(1)(a) as in KTT.

42. The DLP states that DLMS Cases were potentially entitled to DL had their applications for leave to remain been
determined under Home Office policies prior to 30 January 2023 and that they may be entitled to DL because those
policies implement Article 14(1)(a) ECAT. The DLP then sets out the decision in KTT confirming that DLMS Cases
required consideration for a grant of leave because their stay in the UK was necessary, owing to their personal
situation as a victim of trafficking, in order to pursue their asylum claim.

43. I do not accept that the use of the words 'potentially entitled' or 'may be entitled' merely acknowledges that
DLMS Cases could have qualified for DL but did not because their applications were not decided before 30 January
2023. I am not persuaded that these are benevolent transitional provisions that might have resulted in a grant of
leave under KTT, had they been decided sooner. The DLP was updated on 16 March 2023 to implement case law
in relation to the section on modern slavery and human trafficking cases. There is no reason for these transitional
provisions if they do not apply to decisions made on DLMS Cases after 30 January 2023.


-----

transitional provisions, deportation) [2024] UKUT ....

44. Nor am I persuaded that these words indicate that the respondent did not intend to apply ECAT or KTT. The
DLP makes clear on page 6 that DL will be granted in line with the judgment in KTT. Under the heading 'when to
consider DL' the DLP states that those individuals who were eligible for consideration of leave under the KTT
judgment prior to 30 January 2023 will not have their applications determined under the VTSP. The DLP specifically
states that DL must be considered and will normally be granted to individuals in DLMS Cases. Therefore, section 65
NABA 2022 does not prevent DLMS Cases from benefitting from the judgment in KTT.

45. I am of the view that properly interpreted the DLP provides that DLMS cases should be decided in accordance
with Article 14(1)(a) given the lack of an express intention to the contrary and the clear and explicit reference to
ECAT and KTT. I find the DLP was intended to give effect to Article 14(1)(a) ECAT in respect of pre-30 January
2023 modern slavery and human trafficking cases.

Does the DLP give effect to Article 14(1)(a)?

46. Having committed to giving effect to Article 14(1)(a) in respect of pre-30 January 2023 cases, the DLP 'carves
out' an exception for those DLMS Cases who are subject to deportation proceedings (the deportation carve out).

47. Mr Biggs submits, on a correct interpretation of the DLP, the transitional provisions do not evince a commitment
to apply ECAT and KTT on the facts of this case because the respondent's current approach is explicitly contrary to
KTT. The respondent had to follow Parliament's decision to adopt a particular interpretation of the ECAT provisions
and the point is only justiciable if the policies, properly interpreted, require Article 14(1)(a) to be applied. Even if the
deportation carve out was unlawful under ECAT, ECAT was not part of domestic law and the DLP did not evince a
commitment to apply Article 14(1)(a). The applicant cannot benefit from the transitional provisions because of the
deportation carve out.

48. Ms Mellon submits the transitional provisions demonstrated a commitment by the respondent to comply with
Article 14(1)(a) in respect of those who had a positive CGD and an outstanding asylum claim before 30 January
2023. Accordingly, following KTT, the respondent was not entitled to exclude the applicant because he was subject
to deportation proceedings. She submits the policy in force before the DLP did not exclude those subject to
deportation proceedings and section 65 NABA 2022 did not fetter the respondent's ability to grant leave in
trafficking cases on a broader basis than section 65 requires.

49. Ms Mellon submits the policy prior to 30 January 2023 demonstrated a commitment to comply with Article
14(1)(a) ECAT and it was clear that the intention of the DLP, when viewed objectively, was to honour Article
14(1)(a). It was for the Tribunal to review whether the respondent correctly implemented Article 14(1)(a) and to
conclude that the deportation carve out was unlawful because it had no basis in ECAT. It was not the respondent's
case that he had made a policy decision to comply with ECAT save for deportation cases nor does he argue ECAT
allows for a public order exemption.

50. The respondent accepts in the response to the pre-action protocol letter dated 4 August 2023 that under the
**_modern slavery DL guidance which was in place prior to 30 January 2023, Foreign National Offenders (FNOs)_**
should not normally benefit from DL because it is a Home Office Policy to remove foreign criminals from the UK as
soon as possible. Leave was to be considered on a case by case basis. The respondent goes on to state that:

“Therefore, the current discretionary leave policy sets out that those who are subject to deportation proceedings
should have their entitlement to leave considered under the new Temporary Permission to Stay policy post 30
January in line with current legislation, section 65 of the Nationality and Borders Act and Appendix: Temporary
Permission to Stay for Victims of Human Trafficking or Slavery (VTS) in the Immigration Rules.”

51. This letter makes clear that FNOs will be considered under section 65 of NABA 2022 and the Immigration
Rules introduced on 30 January 2023 which allows for leave to remain not to be granted where the public order
disqualification applies.


-----

transitional provisions, deportation) [2024] UKUT ....

52. There is no public order exception in Article 14(1)(a) as in Article 13 ECAT which provides for a recovery and
reflection period after a reasonable grounds decision. This is recognised in the explanatory note to section 63 of
NABA 2022. Section 63(3)(f) provides that a threat to public order includes where a person is a foreign criminal
within the meaning of section 32(1) of the UK Borders Act 2007. A foreign criminal includes a person who is
convicted of an offence and sentenced to a period of imprisonment of at least 12 months.

53. The public order disqualification in the VTSP states that the respondent is not required to grant permission to
stay where the person is a threat to public order and refers to the specific criteria in section 63(3) to (7) NABA 2022.

54. The deportation carve out in the DLP makes no reference to the definition of a foreign criminal or whether an
individual poses a threat to public order. It makes no reference to the public order disqualification in respect of NRM
support and is inconsistent with the **_Modern Slavery Statutory Guidance on Public Order Disqualification_**
(referenced at page 13 of the VTSP).

55. The DLP provides for a grant of DL to DLMS Cases where the victim's stay is 'necessary owing to their
personal situation'. Imposing a blanket requirement not to be subject to a deportation order fails to give effect to the
obligation in Article 14(1)(a) to consider whether the applicant's stay is necessary owing to their personal situation
and is contrary to the transitional provisions in respect of DLMS Cases implementing KTT.

56. The deportation carve out excludes those who would benefit from the transitional provisions in the DLP even
though they are not foreign criminals or a threat to public order as defined under the policy in force prior to 30
[January 2023, the VTSP (post-30 January 2023), the UK Borders Act 2007 or NABA 2022. The deportation carve](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CJ00-TWPY-Y0HC-00000-00&context=1519360)
out excludes DLMS Cases on suitability grounds which have no foundation in the IR-VTS or the VTSP.

57. I conclude that the deportation carve out in the DLP goes beyond the scope of the public order disqualification
and is unlawful because it is incompatible with the obligations in Article 14(1)(a) ECAT and the requirements in
sections 63 and 65 NABA 2022 currently in force.

**Conclusions on the grounds of application**

Ground 1

58. The DLP intends to comply with Article 14(1)(a) ECAT in respect of DLMS Cases and the decision to exclude
the applicant from consideration under the DLP was contrary to Article 14(1)(a) ECAT and unlawful. The transitional
provisions in the DLP clearly intend to implement the judgment of KTT and there is no lawful basis for exclusion
from those provisions on the grounds the applicant is subject to deportation proceedings.

59. It is not in dispute the applicant had a positive CGD and a pending asylum claim based on a well founded fear
of being re-trafficked before the 30 January 2023. His application for leave to remain was made in November 2022.

60. On the agreed facts the applicant comes within the cohort of DLMS Cases and would qualify for consideration
for DL under the DLP and a grant of DL following KTT. The respondent refused to consider and/or grant leave
under the DLP because of the applicant's deportation order. However, the CGD finds that the applicant was subject
to forced criminality which resulted in a single conviction for which he was sentenced to 8 months' imprisonment.
The applicant is not a threat to public order.

61. The respondent submits that the applicant does not fall within the cohort of DLMS Cases because he is subject
to deportation and therefore the VTSP and IR-VTS apply. However, the applicant would not be refused on grounds
of suitability under these provisions.

62. Under section 63 NABA 2022, the applicant is not a foreign national offender and section 32 of the UK Borders
Act 2007 does not apply. The applicant would not be excluded from a grant of leave to remain under the VTSP or
IR-VTS on suitability grounds notwithstanding his deportation order dated 16 January 2013.


-----

transitional provisions, deportation) [2024] UKUT ....

63. Therefore, there is no lawful basis to exclude the applicant from the benefit of the transitional provisions in the
DLP on the basis of his extant deportation order which does not meet the current threshold for public order
disqualification. I find the applicant's personal situation brings him within the transitional provisions of the DLP and
the decision to refuse DL and/or refuse to consider DL under the DLP was unlawful.

Ground 3

64. The applicant also succeeds under ground 3 in so far as the transitional provisions in the DLP evince an
intention to comply with the obligations in Article 14(1)(a) ECAT and the deportation carve out in respect of the
cohort of DLMS Cases fails to do so. However, notwithstanding the DLP fails to give effect to ECAT and the
decision refusing to consider or grant leave under the DLP was unlawful, this did not involve the direct enforcement
of an unincorporated treaty because ECAT was not the source of the obligation: [32] KTT.

65. The applicant seeks a declaration that the DLP is contrary to Article 4 and unlawful under section 6 of the
Human Rights Act 1998 (HRA). I am of the view such a declaration is not necessary for the reasons given above.

66. With both of these points in mind, I go on to consider whether the decision to refuse the applicant a residence
permit on account of the deportation order breaches Article 4 ECHR. I can therefore deal with the remainder of
ground 3 briefly.

67. Article 4 of the European Convention of Human Rights (ECHR) materially provides that:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.”

68. It is settled law that the positive obligations under Article 4 ECHR include the duty in certain circumstances to
take operational measures to protect victims or potential victims of trafficking : Rantsev v Cyprus and Russia (2010)
51 EHRR 1 and SM v Croatia (2021) 72 EHRR 1. The Article 4 positive obligations must be construed in light of
ECAT and protection measures include assisting victims with their physical, psychological and social recovery VCL
and AN v UK (2021) 73 EHRR 9.

69. Ms Mellon submits the operational duty under Article 4 includes the duty to assist recovery. There is a risk of
re-trafficking for those who have been trafficked in the past and who remain in the UK without leave seeking asylum
which is an inherently insecure position. Article 14(1)(a) as interpreted in KTT, requires that recognised victims of
trafficking whose asylum claims are pending must be granted a period of leave. She submits that Article 4
interpreted in the light of ECAT, imposes the same obligation.

70. Ms Mellon refers to R (TDT (Vietnam)) v SSHD [2018] EWCA Civ 1397 in her skeleton argument and accepts
there is no automatic read across, but in her submission that is exactly what she is asking the Tribunal to do.
Applying the dicta at [31], the obligations under Article 4 ECHR and the obligations under the transitional provisions
in the DLP, which intend to comply with the obligations in Article 14(1)(a), have to be analysed separately. In my
view, the application of the DLP was not a mechanism by which the UK satisfied its procedural obligations under
[Article 4: SSHD v Minh [2016] EWCA Civ 565.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)

71. Having reviewed the Strasbourg case law and considered [54] of R (AB) v SSHD [2021] UKSC 28, I am not
persuaded that the obligation imposed by Article 14(1)(a), as interpreted by KTT, can be derived from the
operational duty recognised in Rantsev, TDT and VCL.

72. I am persuaded by the respondent's submission that Article 4 does not have the effect of incorporating Article
[14(1)(a) ECAT adopted by KTT into domestic law via the HRA 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

**Ground 4**

73. The refusal of VTS was unlawful because the respondent applied the wrong policy for the reasons given above.


-----

transitional provisions, deportation) [2024] UKUT ....

74. I am fortified in this view by the letter from the SCA dated 7 March 2023 (page 155 of the trial bundle) that a
decision would be made on applicant's application for limited leave to remain once policies had been reviewed in
the light of KTT. If the VTSP first published on 30 January 2023 was applicable there was no need to await further
review of the DLP.

75. I note that the decision of 12 June 2023 makes reference to part 9 of the immigration rules. This is
misconceived. The VTSP on page 9 makes clear that this is relevant to the cancellation of permission to stay. A
grant of VTS is made under the criteria in IR-VTS. The refusal on the basis that VTS must be refused because
“previous behaviour is deemed not conducive to the public good” is clearly wrong and demonstrates the decision
maker's misunderstanding of the relevant applicable rules and policy.

**Summary**

76. The transitional provisions in the DLP applicable to DLMS Cases were intended to commit the respondent to
making decisions on DL in accordance with Article 14(1)(a) ECAT and KTT. The respondent has failed to do so.
The decision of 12 June 2023 is therefore in breach of the DLP and unlawful.

77. The case of XY v SSHD [2024] EWHC 81 Admin was handed down on 23 January 2024. It was concerned with
the policy guidance on Discretionary Leave Considerations for Victims of Modern Slavery, version 4 published on 8
December 2020 and raised different issues to those argued in the applicant's case.

**Permission to appeal**

78. The respondent applied for permission to appeal on the following grounds:

“The Upper Tribunal erred in its interpretation of the transitional provisions within the policy guidance on
discretionary leave, version 10, published on 16 March 2023 (the “DLP”). Whether or not the transitional provisions
within the DLP, properly construed, apply article 14(1)(a) of ECAT as interpreted in (EOG and KTT v SSHD [2022]
_EWCA Civ 307 (“KTT”)) in cases to which the transitional provisions apply, the DLP is clear that article 14(1)(a) of_
ECAT as interpreted in KTT does not to apply in cases covered by the deportation 'carve out'. In other words, such
cases simply fall outside the scope of the relevant transitional provisions, on their correct construction. Properly
interpreted as a whole the DLP transitional provisions therefore do not and cannot provide that the KTT
interpretation of article 14(1)(a) of ECAT must be applied in the applicant's case, given that he falls within the
deportation 'carve out', and therefore falls outside the scope of the relevant transitional provisions. There is no
principle of interpretation that could allow the Tribunal to construe the DLP transitional provisions without regard to,
or so as to override, that clear limitation of their scope.”

79. The respondent does not challenge my conclusion that the transitional provisions under the DLP intended to
give effect to Article 14(1)(a) ECAT and the judgment in KTT. The respondent submits that Article 14 (1)(a) ECAT
as interpreted in KTT does not apply in deportation cases and the applicant falls within the deportation carve out.

80. This argument has no merit because the deportation carve out is unlawful for the following reasons. The
respondent is seeking to exclude the applicant from the benefit of the transitional provisions in the DLP (which
implements Article 14(1)(a) and KTT) and decide his application under the less favourable provisions in the VTSP
(which does not implement Article 14(1)(a) and KTT) for reasons which are not sustainable under the VTSP or
indeed NABA 2022 and the IR-VTS.

81. I refuse permission to appeal because there is no arguable case that I have erred in law or there is some other
reason that requires consideration by the Court of Appeal.

~~~~0~~~~

**End of Document**


-----

