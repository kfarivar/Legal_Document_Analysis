# R v Bakayoko [2020] EWCA Crim 539

CA, CRIMINAL DIVISION

201904518/A3

Bean LJ, Bryan J, HHJ Potter

Tuesday 17 March 2020

17/03/2020

1. LORD JUSTICE BEAN: Lassina Bakayoko was born in Mali in 1992 or 1993. He entered the United Kingdom in
or around 2009 claiming asylum. The claim appears to have been rejected in 2011. Since that time he has
remained in the United Kingdom illegally. He appeals with the leave of the single judge against a sentence of 15
months' imprisonment imposed on him on 15 November 2019 by Mr Recorder Flint QC in the Crown Court at Wood
Green following his conviction by the jury on three charges, one of fraud and two of possession of an identity
document with improper intention.

2. He had been employed at [a restaurant] for a period beginning in November 2018. He had given his name as
Christophe Bah and had produced a French identity document in that name in order to obtain employment. That
was the fraud which was the subject of count 1. The possession of that identity document No 160642333997 was
the subject of count 2.

3. On 27 February 2019 he attempted to cash two cheques from his employer, was asked to provide identification
and handed over the false ID card in the name of Christophe Bah to which we have referred. The shop assistant
suspected that it was a fake, ran a check which showed that it was invalid and called the police. The appellant left
the shop.

4. Two months later on 20 April 2019 he was arrested at the restaurant. He was found to be in possession of a
further false French identity card No 180934855128. That document was the subject of count 3.

5. The appellant made no comment in interview but subsequently claimed he had been forced to take the card and
to work by a man named Mohammed whom he had met at a mosque. Before the jury he contested all three
charges on this basis, since section 45 of the **_[Modern Slavery Act 2015 can provide a defence in such](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
circumstances. The jury evidently disbelieved him since he was convicted on all three counts.

6. The sentencing judge had a psychiatric report available to him from Dr Frank Farnham, a consultant forensic
psychiatrist with the North London Forensic Service among other qualifications. He was given an account by the
appellant of traumatic experiences in Cote D'Ivoire, a country in which he had lived between the ages of 5 and 15 or
16, including the murder of his father and brother, the kidnap of his sister, the untimely death of his mother from a
stroke and the appellant himself suffering serious injuries when he was beaten up by gunmen who had killed his
father and brother. Dr Farnham wrote:

i. "... if Mr Bakayoko's account of his experiences in the Cote D'Ivoire are accurate then he is highly likely to have
developed PTSD as a result and his clinical presentation is in keeping with this diagnosis. In my opinion Mr
Bakayoko's mental illness and social isolation is likely to render him liable to be overly dependent on others and to
be the victim of exploitation and coercion."


-----

7. In passing sentence, the judge said that he did not know whether the account advanced by the defendant as to
why he had to leave the Ivory Coast was true or not and did not have to adjudicate on it, but noted that the Home
Office had rejected the asylum claim as unfounded. He noted that in the course of the trial some glaring
inconsistencies had emerged in the account given by the defendant to different people. The judge said:

i. "I have no doubt however that being an illegal entrant to any country must create a worrying and stressful
atmosphere but you seem to have managed and endured that [for more than eight years] and you have avoided
deportation to Mali following the failure of your application for asylum to this country and you have also succeeded
in avoiding coming to the attention of the authorities from ... May 2011 until April of this year [2019].

ii. In my judgment that has the hallmark of a level of sophistication and know‑how in managing to obtain

appropriate documentation with an intention to put you beyond suspicion of being an illegal entrant. As I say, I find
support for that conclusion from the fact that, as I have observed, you had in your possession a replacement false
identity card within a matter of months. In my judgment, Mohammed was a work of fiction. A front you created to
hide behind your criminality. No mention was made of any compulsion for you to do what you did when you were
arrested and the jury has clearly rejected your account or concluded that you did have realistic alternatives to do
what you did.

iii. ... Your use of those identity cards permitted you to obtain work and facilitated your ability to remain in the
United Kingdom in breach of immigration control. You have not, however, committed other criminal offences or
otherwise come to the attention of the authorities."

8. The judge said that he had been referred to a number of reported cases in many of which the offender had had
the sense, as the judge put it, to plead guilty and admit his role. Addressing the defendant, he said:

i. "You have done neither. You entered illegally; attempts ... were made to deport you and you made the decision
to avoid capture and you have managed to lie low for many, many years. When you were caught you created an
elaborate charade through which the jury have clearly seen."

9. The judge referred to the fraud sentencing guideline where the starting point of 26 weeks' custody and a range
of up to one year's custody. He noted that in his view count 3 aggravated the situation because the defendant had
obtained a new ID card as a replacement for the one that had been seized. He also noted that the defendant had a
girlfriend who was pregnant with their child. He then imposed sentences of six months' imprisonment on count 1,
nine months concurrent on count 2 and six months consecutive on count 3, making a total of 15 months.

10. Mr Wright submits that the total sentence was excessive and in particular that the judge was wrong to make the
sentence on count 3 consecutive. He has supplied us with the same print out of a number of cases to which the
judge was referred. In his grounds of appeal he submitted that the judge failed to have proper regard to what is
undoubtedly the leading case of Ovieriakhi [2009] EWCA Crim. 452, in which Lord Judge, LCJ giving the judgment
of this court reviewed the authorities on sentencing for possession of false identity documents. He said at
paragraphs 15 and 16:

i. "At one end of the scale is the use or possession for use of false passports for the purpose of evading, or
enabling others to evade, the controls on entry into the United Kingdom. Such evasion may at worst be for terrorist
or other malign purposes, or at least for the purpose of securing the entry of someone into the United Kingdom
which would otherwise be forbidden. The documents may be possessed by those whose business it is to help
others to circumvent the rules on entry. At the other end of the scale is the use by someone who is lawfully in the
United Kingdom of a document other than a passport for the purpose of obtaining employment or a bank account.
Attention must also be paid to the difference in maximum sentence between a case involving intent and one of
mere possession: see R v Oliveira [2006] 2 Cr App R(S) 115, [2005] EWCA Crim 3187.

ii. Wherever the case is on the spectrum, a custodial sentence is likely, save in exceptional circumstances, for the
reasons stated in Carneiro. In cases in which a false passport is to be used for the purpose of securing entry into
the United Kingdom, the guidance contained in Kolawole applies. Where, however, a false passport is used to


-----

obtain work or a bank account, its use does not enable the offender to obtain entry to the United Kingdom and for
that reason it may properly be treated less severely than the use of a passport which does, or may, have that effect.
What the use of a passport to obtain work does, however, do is to facilitate the offender remaining in the United
Kingdom in breach of immigration controls. For that reason a custodial sentence is usually required. But it can
justifiably be less, particularly if the offender is of good character and has done no more than use or try to use it to
seek employment in order to maintain himself/herself or his/her family."

11. We cannot agree with the submission of Mr Wright that it was wrong in principle to make the sentence on count
3 consecutive. In any event, what this court is concerned with is the total sentence rather than the means by which
it was reached. The judge could have imposed longer but concurrent sentences on the three counts. We are
unable to say that the total sentence of 15 months in this case following a contested trial, as almost none of the
reported authorities have been, was excessive. It follows that this appeal against sentence must be dismissed.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

