(Admin)

# R (on the application of DA and others) v Secretary of State for the Home
 Department [2020] EWHC 3080 (Admin)

Queen's Bench Division, Administrative Court (London)

Fordham J

13 November 2020Judgment

**Chris Buttler and Zoe McCallum (instructed by Duncan Lewis) for the Claimants**

**Jack Holborn (instructed by the Government Legal Department) for the Defendant**

-------------------------
Hearing date: 13th November 2020

Judgment as delivered in open court at the hearing

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that no official shorthand note shall be taken of this Judgment and that copies of this version as handed
down may be treated as authentic.

.............................

THE HON. MR JUSTICE FORDHAM

Note: This judgment was produced for the parties, approved by the Judge, after using voice-recognition software
during an ex tempore judgment in a Coronavirus remote hearing.

**MR JUSTICE FORDHAM :**

Directing a Rolled-Up Hearing

1. I will start with what I am going to do in this case. (1) I will direct a two-day rolled up hearing of the
application for judicial review. (2) I give permission for the Claimants to amend their grounds for judicial
review by close of play today to deal explicitly (or more explicitly) with the self-standing argument that the
abridged screening interview process at the heart of this case is unlawful because implemented pursuant
to an unpublished policy. (3) I will direct that the Defendant have until 4pm 4 December 2020 to file and
serve Detailed Grounds of Resistance and any evidence relied on. (4) The two-day hearing will be listed for
Wednesday 16 and Thursday 17 December. The parties will need to liaise as to what sensible provision
needs to be made for the period of 10 days between 4 and 14 December to ensure that all the necessary
material and submissions and authorities will be before this Court in good time prior to the hearing.
Everyone is confident that that can work, subject to one point to which I will come, and so am I, even on
that one point. I will need the parties to liaise though because I wish to include within the Order, if possible,
further directions for skeleton arguments and reply from the Claimants. As it seems to me at the moment,


-----

(Admin)

there is a lot to be said for the Detailed Grounds of Resistance to be able to stand as the Defendant's
skeleton with provision for a supplementary skeleton and for any reply to stand as the Claimant's skeleton
argument.

Ordering Interim Relief

2. I am also going to grant interim relief. The interim relief that I grant is narrower and more tailored than
was sought by the Claimants. The fact that I am giving any interim relief means, however, that I am not
accepting the Defendant's submissions, although one aspect of the interim relief constituted a 'fallback'
position on the part of Mr Holborn. As interim relief:

i) First, I am going to order that asylum screening interviews in all cases must involve the asking of
question 3.1 (why have you come to the UK?) and question 3.3 (please outline your journey to the UK?) on
pages 66 and 67 of the Defendant's April 2020 Asylum Screening and Routing Policy Guidance. Mr
Holborn has submitted that interim relief, even so designed, would materially impede the ability to comply
with the very tight directions for an expedited hearing. He relies on the facts: that change would need to be
implemented; that these are difficult times; and that the same people implementing the changes will be
involved in defending and providing evidence in relation to the process. I do not underestimate the
difficulties under which everyone is working at the present time. However, I cannot accept that the narrow
form of interim relief to which I have referred would have such a consequence as to undermine the ability
to prepare properly within the stated time frame. Indeed, the fact that I have been able to identify so
truncated an expedited timeframe for the Court to resolve the substantive issues in this case, has been a
strong and material factor in my decision not to make a broader Order for interim relief today.

ii) So far as the other two aspects of the application for interim relief are concerned, I am going to make an
Order though not quite of the nature as was sought by the Claimants. They wished me to give an order
which was by way of a direction requiring an instruction to caseworkers. The two points which would be
embodied in that instruction are both points which the Secretary of State accepts before me are correct:
one is a question of law based on Court of Appeal authority; and the other concerns the relevance of a
particular factor as expressed in the Secretary of State's own skeleton argument before me. That, at least,
is the focused nature of the order which I am contemplating. I would certainly not be prepared to go any
wider: I accept Mr Holborn's submission that to do that would be unjustifiably to go into contentious areas
at an interim stage. However, on the two key points – namely (1) that the test for an NRM referral to the
competent authority is the one articulated at paragraph 31(1) and 33(1) of R (TDT (Vietnam)) v SSHD

_[2018] EWCA Civ 1395 [2018] 1 WLR 4922and (2) that “there is evidence of a particular risk to migrants of_
being forced into modern slavery whilst in Libya” – these are both matters, in my judgment, which call for
an order for interim relief today. The design of that Order will be as follows. The Secretary of State shall
confirm to the Court that she has taken steps to satisfy herself that those conducting asylum screening
interviews are aware of those two key points.

3. I am satisfied, in the context of an expedited rolled up hearing at which this Court will be able within
about 6 weeks from today to resolve the disputed substantive issues in the case – as I have said the two
points to which I have just referred are not in and of themselves disputed – there is a sufficiently arguable
case to warrant the grant of interim relief. I am also satisfied that the balance of convenience and justice –
positing the alternative implications of doing so or not doing so, of giving less by way of interim relief or
giving more by way of interim relief, in the context of the possible outcomes at a substantive hearing –
justify as necessary the Order that I have outlined. I promised the parties, for practical reasons, to begin
my judgment today with my description of the outcome and the Order that I will be making. That may have
the advantage for those capable of multi-tasking – of whom I do not claim to be one – to be reflecting on
the design of the precise terms of the order.

4. I say, immediately, that the two questions which are the content – and sole content – of the interim relief
which today requires that further questions be asked in all screening interviews are two questions
identified, within the Secretary of State's own published asylum screening guidance, as questions which
are relevant to the detection as a first responder of whether the individual facing potential detention and


-----

(Admin)

removal directions with certification of a protection claim is a potential victim of trafficking. I will use the
word 'trafficking' broadly to include also 'modern slavery'. In particular question 3.3 (please outline your
journey to the UK?) is identified in the materials before the Court for its direct relevance and the troubling
concern arising from it being unasked. Mr Buttler showed me, in his submissions in his reply, a passage
which listed the key questions identified by the Secretary of State herself as relevant questions so far as
the identification at an early stage of potential victims of trafficking is concerned. He recognised that, from
that list, the most relevant unasked question for the purposes of the substance of his submissions before
me today is question 3.3 (the journey question). His submissions and their logic ranged more broadly but,
in my judgment, that narrower submission focuses on what really matters most, given its practical
implications for everyone concerned, including the Secretary of State and her decision making officials. It
(and the other question) identify the appropriately tailored, but significant, adjustment which in my judgment
the strong prima facie case before me and interests of justice require as interim relief. Among the wealth of
informed evidence before me was a critique by the Helen Bamber Foundation which addressed the asylum
screening questionnaire and its various implications and which included within it an assessment of what
were said to be the key problems with asking a direct question about exploitation (ie. question 2.5) and
stopping there. Emphasis is placed in that material on the significance in particular of the 'journey'
question. That evidence and other materials before me go much further, as does Mr Buttler and as he will
at the substantive hearing of this case. I have to strike the just and appropriate balance and do what I
judge to be necessary and appropriate for the purposes of interim relief in the meantime.

Introduction

5. Rather like a film that tells its story in 'flashback', it is now necessary for me to go back to the beginning
in fleshing out in more detail the reasons why I have arrived at the Order which I have already described.
This claim for judicial review challenges the practice that is taken in asylum screening interviews and its
implications for identifying or not identifying potential victims of trafficking. It does so in the context of a
particular group called by Mr Buttler the 'Libya Risk Group'. It recognises that the logic of its challenge
really extends though to everyone so far as the asylum screening interviews are concerned. The challenge
raises as an integral part of it the question of the 'risk indicator' arising out of transit through Libya and has
at its heart the function of applying the appropriate legal threshold of making referrals to the relevant
competent authority. The case came before Swift J who on 4 November 2020 directed this hearing of
interim relief.

Permission for judicial review

6. Although everybody in their submissions addressed arguability of the claim in the context of interim
relief, permission for judicial review was not directed to be before this Court and I am not dealing today with
that question. I am quite sure Mr Holborn identified the right way to deal with this case as far as that is
concerned as being directing the 'rolled up hearing' for permission with the substantive hearing
immediately to follow if permission is granted.

Mode of hearing

7. The mode of hearing was Microsoft Teams. As a result of being able to access a public court hearing
through laptops and tablets, this public hearing has been observed (at the time of delivering this judgment)
by 19 people. Counsel on both sides were satisfied that this mode of hearing did not prejudice the interests
of their clients at least not to an extent as to render the hearing unfair. I agree with them. I am satisfied that
this hearing could deliver, and has delivered, a fair hearing for the parties. Moreover in my assessment this
mode of hearing better promoted the open justice principle than would an in-person hearing in a physical
court. I accept that the press plays an important role as 'the eyes and ears of the public' in scrutinising legal
process and would pursuant to the regulations be able to rely on the working exception (SI 2020 No. 1200
regulation 6(4)(a)) to enable them to travel to be present in Court. There are as it seems to me real
difficulties as to whether a member of the public would be able to rely on the exception for 'participation' in
a hearing (Regulation 6(4)(e)): I can see that that exception might fall to be interpreted broadly,


-----

(Admin)

consistently with the constitutional open justice principle. I have not heard any arguments, and do not need
to, about whether that be might be right: it would not help anyone so far as this hearing today in this case is
concerned; and in any event it is important to consider the practical realities faced by the public. This case
and its start time were published in the daily cause list. An email address was given which any member of
the public or press could use. If they have access to a computer to send an email they could through
access to that same computer have logged in and observed this hearing as many did. By having a remote
hearing we eliminated any risk to any person from having to travel to a Court and being present in one. I
am quite satisfied that the mode of hearing was necessary, appropriate and proportionate.

Adjournment

8. At the start of the hearing Mr Holborn applied to adjourn today's hearing. The basis for that adjournment
was his stated concern that, for the purposes of the arguability today of the claim the Claimants – through a
skeleton argument filed yesterday – were relying on one of the main grounds for judicial review now being
put in a different way. The difference was between the submission that 'the impugned practice is a
departure from the Defendant's published policy' on the one hand (which Mr Holborn accepts is pleaded)
and the submission that 'the impugned practice is one in pursuance of an unpublished policy' on the other
hand. Mr Buttler cut the knot by confirming that for the purposes of today he was quite content to put his
case on the basis of the first of those formulations. He does not accept that the second formulation is
absent – at least by necessary implication – in his pleading. The point is certainly on the face of it in the
supporting witness statement in support of the claim made by Mr Hossain his instructing solicitor. But all of
that can be dealt with without need for further ado by the Claimants spelling the point out, so that
everybody is happy, in an amendment later today for which I prospectively give permission it being obvious
what the point is and that relying on it moving forward can cause no injustice (nor in fairness did Mr
Holborn suggest the contrary). In those circumstances, there was no need for further time for the
Defendant to 'regroup' and consider what different material or submissions it might want to make to this
Court on the question of interim relief in the light of the pursuit of that alternative characterisation of one of
the key grounds for judicial review. It was in those circumstances and for that reason that I refused the
application to adjourn.

The Unasked Screening Questions

9. In relation to the issue of what questions are currently asked (and not asked) at an asylum screening
interview during the Covid-19 pandemic, my order for interim relief rests on the following essential
conclusions. (1) In my judgment, and on the basis of the material currently before the Court and the
submissions that have currently been made to the Court, it is strongly arguable that the Home Secretary is
acting unlawfully in curtailing asylum screening interviews by asking a narrower set of questions than those
which are identified in her published policy guidance. (2) There is a strong prima facie case, in particular,
that the omission in that interview of two questions (questions 3.1 and 3.3), which are explicitly identified in
the published policy guidance as relevant to the identification at an early stage of potential victims of
trafficking, is contrary to law. (3) In my judgment these arguments are strongly arguable on the basis that
this is a departure without good reason from the Secretary of State's published policy guidance. (4) In my
judgment they are also strongly arguable on the basis that there is in any event no good reason for that
curtailed practice sufficient to be able to uphold it as lawful. (5) So far as concerns the balance of
convenience and justice, notwithstanding the expedited timetable and the prospect of resolution on their
substantive merits of the arguments before the Court by the end of the calendar year, there is in my
judgment a serious risk of injustice and irreversible harm from these questions continuing to be unasked
and unanswered: resolution at the end of the day, were the Claimants to succeed, would not be able to
secure or remedy that injustice and harm. (6) In particular there are, in my judgment, on the face of it real
risks that – through the absence of the asking of these questions – potential victims of trafficking who
would otherwise be detected at the early stage of the screening interview will not be. (7) The implications,
under the process being operated by the Secretary of State start with detention and the prospect that
individuals who would not have been detained had these questions been asked will have been. I am not
satisfied (nor in fairness does Mr Holborn s ggest) that someone in that position ere the Claimants to


-----

(Admin)

succeed at the end of the year, can be regarded simply as properly dealt with through an order for
compensation for the loss in the meantime of their liberty. (Had that argument been advanced I would have
rejected it and Mr Holborn is right not to advance it.) (8) More than that, though, there is in my judgment on
the face of it the serious risk that individuals who would be picked up as potential victims of trafficking will
go unnoticed through the absence of these questions being asked, with the prospect of their having their
protection claims speedily certified and their being removed (as is the Secretary of State's understandable
policy position in relation to anyone in respect of whom she does not have reason to conclude is a potential
victim of trafficking), depending of course on the other considerations which inform certification decisions
and decisions to set removal directions. The whole point of the screening process which I will come on to
describe, on the Secretary of State's own evidence, is this: it processes people in order then to put them
(unless they are released) into detention with a view to a proposed decision to remove them. (9) I am not
prepared for the risk to be run, even in the interim period to the substantive hearing in this case, from those
questions being unasked by the Secretary of State, given those implications. (10) I have had close regard,
as Mr Holborn rightly insisted that this Court must, to the operational implications for the Secretary of State
of this Court making an interim order with 'operational' implications. However, I am quite satisfied that the
real and substantial change that the asking of these two additional questions will mean is a real and
substantial protective change that is needed in the interim in the interests of justice. (11) It is relevant to
recognise that at the moment many, – though certainly not all – screening interviews are being conducted
by telephone during the pandemic. I accept for the purposes of this application for interim relief, on the
evidence, that screening interviews are running on the truncated basis at around 15 to 18 minutes long. I
also accept that were I to make the order that Mr Buttler is seeking today – that is, that the entirety of the
screening interview as set out in the Secretary of State's published guidance must be followed – that, on
the evidence, would be likely to double the length of the interview. As is obvious, the imposition of two
questions – questions which are already fully familiar to everyone involved in this process and indeed
which appear on the very form that they currently use within the process – will involve additional time in the
interview. I accept that there will be a knock-on effect from that additional time. In my judgment that burden
is necessary and fully justified. Indeed, the fact that it is a 'substantial' change in my judgment is the whole
point because it is an area of enquiry – on the face of the Secretary of State's own published policy
guidance – which is of importance in the context of recognising potential victims of trafficking.

The Context

10. I am going to say a little more about the context. The legal framework to deliver protection for victims
of trafficking – and indeed driving the 'dual' imperative which also includes being able to identify and deal
with perpetrators of trafficking and **_modern slavery – involves a duty of enquiry or 'obligation of_**
identification' as Mr Buttler put it, together with appropriate follow-up including in an appropriate case
notification to the single competent authority. That legal framework promotes protective outcomes for
relevant individuals in delivering the rights that they have under the law as reflected in the relevant
published policy instruments. Those outcomes can include state support for an appropriate period. They
include a legal bar on removal for any individual in respect of whom, following a referral, a 'positive
reasonable grounds decision' is made. They also include protective outcomes so far as detainability is
concerned: partly linked to that removal bar (and therefore the prospect of imminent removal) but partly as
a freestanding protection. The threshold for a referral is the one identified in the Court of Appeal authority
TDT, to which I referred at the start of this judgment. All of these protective outcomes, and this important
duty of enquiry and follow-up, arise under the umbrella of ECAT (Council of Europe Convention on Action
Against Trafficking in Human Beings) and Article 4 of the ECHR (European Convention on Human Rights).
Importantly (see TDT at paragraph 23) the implementation of international obligations in this area has been
regarded as something which is delivered through the promulgation of published policy guidance
instruments. Public law requires that published policy guidance instruments be adhered to, absent a good
reason for departure.

[11. Under statutory guidance (Modern Slavery Act 2015 – Statutory Guidance for England and Wales)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
issued by the Home Office under the **_[Modern Slavery Act 2015 there are important provisions which](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**


-----

(Admin)

identify general indicators of **_modern slavery (see chapter 3) and emphasise the importance of the_**
journey that an individual has taken to come to this country as well as the significance of what are called
“known patterns of **_modern slavery”. That statutory guidance emphasises the importance of the role of_**
“first responders” (see paragraph 4.7) and identifies Home Office Border Force and immigration authorities
as first responders owing those duties (see paragraph 4.10). That statutory guidance, moreover, expressly
refers to the Home Secretary's published policy guidance on asylum screening (Asylum Screening and
Routing), making explicit reference to “the Asylum Screening Pro Forma [which] provides for questions
relating to **_modern slavery” (see paragraph 12.40). That “Pro Forma” is the form containing the_**
“questions” which, in the event, the Secretary of State has curtailed in the screening interview process.
That includes the questions (questions 3.1 and 3.3) which, as I have identified, themselves make explicit
reference to potential victims of trafficking.

12. Turning to the Secretary of State's published asylum screening guidance (Asylum Screening and
Routing) it is of note that this document was most recently updated and published for Home Office staff on
2 April 2020. On the evidence before this Court what is described as “a reduced contact model” involving
some questions being unasked – and one of them at least pre-filled in by the interviewer – was
implemented from 30 March 2020 in the light of the pandemic. The April 2020 published guidance sets out
in detail the appropriate functions of the screening process. It repeatedly makes reference to 'identifying
appropriate routes' for the screened individual within the asylum process, with appropriate 'signposting' for
'appropriate services' and 'referral' for 'safeguarding', 'vulnerability', 'modern slavery' or 'trafficking'
reasons. The importance of obtaining information in the screening interview is emphasised throughout the
document. The obligation – for it is framed as such – is to assess the possible need for intervention and
signposting, including for potential victims of **_modern slavery. The questionnaire is described, again in_**
mandatory terms. The referral function is emphasised. The significance of screening is as 'a framework of
basic questions that should be asked of all claimants'. Reference is made to circumstances in which it may
not be possible to complete a screening interview: that on the guidance is framed as being linked to
individual cases where there are particular needs or circumstances. I will not prolong this judgment further
by setting out relevant questions. It suffices to say that the guidance recognises that certain so-called 'soft
questions' are relevant to open up the dialogue with the individual; there is then a direct question about
whether there has been 'exploitation'; and then further questions including the two to which my Order will
refer (questions 3.1 and 3.3). I repeat: the guidance expressly states that those questions are linked to
indicators of trafficking. They are also clearly linked to aspects such as the 'Libya risk' point which also
forms part of my Order today. The guidance explains how 'suitability for detention' is also to be approached
by the interviewer.

The 'Abridged Interview'

13. The new practice of 30 March 2020 appears only, so far as I can see from the material before the
Court today, to have come to light in a very indirect way. HM Chief Inspector of Prisons for example issued
a report (Detention Facilities: Tug Haven, Kent Intake Unit, Frontier House, Yarl's Wood and Lunar House)
which described what had been discovered on unannounced visits to detention facilities in (I think) August
2020. In particular, the Report records how “almost all screening interviews were [being] conducted by
telephone” and that the interview process had been abridged with fewer questions being asked (paragraph
2.22). The Report expressed concern by making a recommendation (paragraph 2.11) that: “The Home
Office should ensure that detainees' vulnerability is thoroughly assessed at the earliest stage and that their
identified needs are met”. It is not necessary, for the purposes of this judgment, to go into the materials
which led the Claimant's solicitors and the others who have given evidence before this Court to reach the
conclusion, which troubled them, that there appeared to be a curtailed asylum screening practice in place.

14. In due course a witness statement before this Court from the Head of Asylum Intake and Special
Operation in Immigration Protection at the Home Office, dated 10 November 2020, states in terms that
there is “currently an abridged interview which can be undertaken by telephone, in order to reduce contact
time between officials and Claimants for the safety of both”. The witness statement states that “process
changes have been made to reduce contact time between officials and asylum claimants depending on the


-----

(Admin)

circumstances of the claimant in the presence of Covid 19 symptoms to ensure that claims can be
registered safely”. It says that the abridged interview “retains the initial softer questions that may indicate
whether the claimant is a victim of trafficking and the direct question in part 2 – question 2.5 [ie. the
exploitation question]”. The witness statement states that the new practice serves to “ensure that asylum
claimants are screened and their biometrics captured in line with the UKVI Operating Mandate”. One
interesting feature of the witness statement is that it refers explicitly to: “The published Home Office
guidance on Asylum Screening and Routing” and stated that that guidance is “clear regarding the
importance of seeking to identify victims of modern slavery, including trafficking and exploitation”.

15. Mr Holborn invites me to accept at face value, as I do, that that evidence is telling me that the rationale
for the introduction of this abridged interview is health protection through the reduction of contact time
during the pandemic. He also tells me, and I accept, that this is a new practice which the Home Secretary
has implemented since March not simply as a response to those arriving in small boats across the Channel
but in all asylum screening cases, albeit that given the effect of the pandemic on travel routes the principal
focus is on the influx of arriving or intercepted boats. As it seems to me, the description of the 'Covid safety'
rationale raises a series of important questions as to the justification of this 'abridged interview', looking at
the alternatives open to the Secretary of State and particularly in the context of a telephone interview. It is
not necessary or appropriate for me to begin to grapple with how those questions would fall to be resolved.
They are a matter for the court when it has full argument and full evidence at the substantive rolled up
hearing.

16. In a letter of response at the pre-action stage in another case there is possibly a clearer description of
the practice that has been introduced. That letter dated 29 October 2020 gives the date of 30 March 2020
and the introduction of a “reduced contact model in light of the Covid pandemic”. It refers to wishing to
“continue at pace” with “asylum registration” with “minimal on-site staffing and reduced floorspace”. It
explains that, in order to “ensure” those objectives, the “standard interview was reduced with certain
answers pre-filled where questions were to be omitted (eg. 3.2, 3.4) or where the answer was known (eg.
3.3 arrival details (not journey))”. I am not making any finding of fact but that explanation does appear to
chime with the evidence before the Court which is (a) which is documentation in which the 'journey
question' is answered with an entry that says 'arrived illegally by boat x days ago' and (b) where the
Claimants in their witness evidence state that they were not given opportunities to describe their journey
and indeed when they did describe their journey that they were not encouraged (I put it mildly) to continue
providing that information.

17. It is also of note that the published response by the Secretary of State to concerns raised by the
Immigration Law Practitioners Association (ILPA) apparently in October 2020 stated: “There is no
expedited process in place. All individual cases are assessed and processed in line with published
guidance”. Later on there was a description of the small boat arrivals and there was express reference to
the soft questions and question 2.5 being asked.

The Claimants

18. The factual context before this Court concerns three Claimants all anonymized pursuant to the Order
of Swift J. The first claimant is a 26-year-old from Eritrea who arrived on 7 September 2020 and had his
screening interview (in person) on 11 September 2020. On the evidence it lasted 15 minutes. His journey
question (question 3.3) answer was recorded as “arrived illegally by boat on 07/09/2020”. He says he said
at the interview that his journey had involved transiting through Libya where he had been “imprisoned and
sold”. He was detained. His protection claim was certified and he was given a notice of removal on 22
September 2020. Only after his solicitors Duncan Lewis came on the record and wrote a letter before claim
on 29 September 2020 was he then asked questions on 30 September 2020 about his journey. There was
subsequently an NRM referral which has led to a positive reasonable grounds decision. The position in
relation to the second and third claimants – who are 24 and 32 years old and from Sudan – was very
similar except that they were both interviewed by telephone. The second claimant's 'journey' question was
left blank and his evidence is that he was “stopped” from telling the interviewer about the journey. In his


-----

(Admin)

case he too is said to have been imprisoned and sold in Libya. He was detained, his claim certified and
given notice of removal. He was able to engage the same firm of solicitors, whose letter before claim
precipitated a change of approach. He too has a referral and positive reasonable grounds decision. So
does the third claimant, whose 'journey question' bore the same – no doubt – prewritten answer of 'illegal
arrival'. The claimants' case is that they were detained – for 19 days, one month and one month
respectively – longer than they would have been had they been dealt with on their case lawfully. Their case
is that the only reason why they were able to secure release and legal protection from removal, under the
criteria recognised by the Secretary of State as applicable to individuals in their situations, was because of
the action by their solicitors.

Further Points relating to the 'Abridged Interview'

19. I will make the following further observations before I turn to the two aspects of interim relief that relate
to information. Mr Buttler for the Claimants strongly submitted that this Court should require by way of
interim relief the full logic and force of the interview process described in the published policy guidance. He
submitted that I ought to grant interim relief and not restricted to the two questions which explicitly refer to a
link to potential victims of trafficking. So far as the legal position is concerned, Mr Buttler submitted that it
would not in law be possible for any 'general' (or 'blanket') practice to be adopted as a purported deviation
'for good reason' from published policy. If that point had stood alone I would not have accepted that it
constituted a 'strongly' arguable ground, though it may prove to be correct. I had in mind, and put to Mr
Buttler, the example of a 'general' change to telephone interviews during the Covid pandemic Mr Buttler's
position – and it is certainly arguable and he may prove to be correct about it – is that this kind of 'general'
change would be such a deviation from published policy that it would require a new policy guidance to be
published together with the appropriate scrutiny. I repeat, in that regard, that I have not – for the purposes
of interim relief today - allowed focus on putting the ground for judicial review in terms of the
implementation of an 'unpublished policy'. Mr Buttler submits that the policy of adopting truncated
screening interviews is unlawful, put in a number of ways. One of those involves it being 'a departure
without good reason from the published policy. Another engages the principle protecting against 'systemic
unfairness'. Another of Mr Buttler's submissions was that – even framing the issue in the most beneficial
way to the Secretary of State, namely positing a 'reasonableness review' of the new practice – the
abridged interview practice would not survive scrutiny given the following: its characteristics 'cutting across
the overarching aim of the asylum screening interview'; the impact on the individuals affected; and the
ease, relatively speaking, of being able to fix the disadvantage by reverting and holding to the published
policy guidance approach. That is a line of argument so far as reasonableness (or 'rationality') is concerned
which engages a modern set of principles for 'rationality review' found most recently in R (Pantellerisco) v
Secretary of State for Work and Pensions [2020] EWHC 1944 (Admin) at paragraphs 47 to 50, applying the
earlier case of Johnson v Secretary of State for Work and Pensions [2020] EWCA 7778. It comes to this.
Rationality review will consider the disadvantages of the alternatives that were open to the public authority
defendant, will evaluate them and the reasons given for the course taken and that not taken, and will
consider whether ultimately the public authority has struck “a reasonable balance”.

20. For his part, Mr Holborn emphasised the 'broad discretion' of the Secretary of State in the context of
implementing the international legal obligations. He submits that the Claimants would not be able to sustain
any argument that the 'abridged interview process' would itself be a breach of those obligations. He
submits that the case can only be a case concerning 'departure from published policy guidance'. He
submitted that there is no properly arguable basis of challenge in circumstances where the Defendant has
taken an 'operational judgment' decision, to adjust her own policy, in the pandemic. He emphasised, as is
illustrated by the first claimant's case, that some interviews are in person and not by telephone. He submits
that that is obviously an appropriate alternative. He raised the prospect that it might be 'inconsistent' and
indeed even 'arbitrary' for the Secretary of State to take a different position to telephone interviews than in
person interviews. Mr Holborn submitted that there are necessarily going to be 'contact' implications, both
of in person interviews and indeed of telephone interviews. Although the Court does not currently have
evidence which addresses that topic I agree with Mr Holborn that it is not difficult to think of ways in which


-----

(Admin)

that could be true. For example if the individual in the 'telephone room' needs to be accompanied; or if
there is a queue of people more efficiently dispatched if everybody knows that the timeslot for an interview
is 15 minutes. Mr Holborn submits for the purposes of interim relief that what I have before me today is an
'operational' matter, which engages 'efficiency of resources', in circumstances where there is a 'massive
pressure on the system', and the need for 'balance'. Mr Holborn strongly relies on other safeguards within
the system including a document (Preliminary Information Questionnaire) given to those whose interviews
are 'abridged', which urges them to set out (“in English”) in full any information relating to their journey
(question 3c). He submits that that safeguard, together with what was elicited from the abridged screening
interview, constitutes an appropriate safeguard and will adequately identify any 'red flag' relating to
potential victim of trafficking. He characterised this as an 'operationally legitimate hybrid process'.
Ultimately, Mr Holborn submits that, even if the Court is satisfied that there are reasonably arguable
grounds, the imposition by interim relief of this 'administrative burden' of 'operational change' – particularly
in the context of a heavily expedited substantive hearing – is unjustified.

21. I am not persuaded by Mr Holborn's submissions. I have already explained the essential reasons why
the other safeguards in the system do not allay my concerns. The published policy guidance is deliberately
framed to emphasise the importance of the screening interview process. I am not persuaded that the
provision of the 'Preliminary Information Questionnaire' document required to be filled in (in English)
allowing a 'journey' question to be answered, for the purpose of consideration of the protection claim, goes
anywhere near providing a suitable protection when viewed alongside the departure from the published
policy guidance. Nor can I currently see the justification for that, if it is designed to be a 'protective
mechanism', when compared with the mechanism of asking two further questions at the interview. I accept
that there will be implications 'operationally'. I also accept that there will be implications, so far as 'contact'
and Covid is concerned, in relation to arrangements for interviews. In the end, I have to evaluate the
burden and implications of adding two questions to the current interview (with all of its current implications
for contact) and I have to balance that against the implications of not doing so, in the context which I have
described. Although he strongly resisted this course, Mr Holborn adopted as his 'fallback' position an order
which required the additional questioning but not the full gamut of the screening interview described in the
published guidance documents. For all the reasons I have given, I am satisfied that the appropriate course
which is necessary and justified, on the balance of convenience and justice, against the backcloth of
strongly arguable grounds for judicial review, is the tailored but immediate interim relief that I have
described.

Two authorities

22. I mention two of the authorities, in particular, because they are relevant in the light of Mr Holborn's
submissions about inappropriate judicial activism (that is my paraphrase) in an area of Home Office policy
implementation.

i) In the case of R (NN) v SSHD [2019] EWHC 1003 (Admin) this Court granted interim relief in the context
of victims of trafficking who had been recognised in the system but were having their support curtailed.
That was a Home Office policy matter. The Court was satisfied though, in all the circumstances, that
interim relief was justified. Moreover, the Court made the 'class order' for interim relief that extended
beyond the particular claimants before the Court (which the Secretary of State has accepted in principle
this Court has jurisdiction to make). The Court in NN emphasised the 'serious risk of irreparable harm' that
it considered would arise, if interim relief were not granted, but if the claimants proved to be vindicated at
the substantive hearing.

[ii) In R (Medical Justice) v SSHD [2010] EWHC 1425 (Admin) this Court also ordered interim relief. That](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)
interim relief involved a direct interference with a published policy on the part of the Secretary of State. The
Court was satisfied, in the light of the strength of the legal arguments, on the balance of convenience and
justice, that that course was justified and appropriate. That was a case in which the court recognised that
the individuals concerned were being 'deprived of an important opportunity'. It was a case in which the
Court evaluated the nature of the impact on the Defendant if interim relief were ordered. It was a case in


-----

(Admin)

which the Court considered the impugned policy that it had before it, alongside an instrument which in
principle it regarded as worthy of stronger weight namely in that case a statutory instrument.

23. In my judgment, the present case is a case not only of 'serious risk of irreparable harm', but of
'deprivation of an opportunity'; it has an impact which although more than minimal is in my judgment not
over-intrusive given the circumstances and implications; it is a case that involves giving primacy, at least at
the interim stage, to the relevant instrument: that instrument is the April 2020 published guidance
document which deals with screening interviews and their importance and function so far as questions
relating to potential victims of trafficking are concerned.

Lawful Detention?

24. Mr Holborn submitted that detention would not necessarily be unlawful at the end of the day, even if
the Secretary of State has acted unlawfully. That may be right, though it is at least strongly arguable in my
judgment that in that situation decisions 'bearing on the detention' would prove to have been unlawful. The
Court would need to evaluate those arguments and decide the consequences.

Unjustified Durability?

25. Mr Holborn relied on what he said would be a very unsatisfactory outcome, if interim relief had the
consequence that an individual achieved a greater 'durability' in the United Kingdom than the law entitled
them to, and became undetainable or irremovable in the interim, only for the Secretary of State
subsequently to be vindicated at a substantive hearing. In my judgment, that is an argument which could
bite on an application for interim relief were it being sought to reach into a legally controversial area. For
example, if Mr Buttler were inviting this to Court to order that: 'in all Libyan transit cases NRM referrals
must be made.' The Order being sought, and the Order I am making, goes nowhere near doing that. It is
very important, in my judgment, to remember that the only individuals that will achieve any protection, so
far as state support or detention or removability are concerned, as a result of my order for interim relief, will
be those who have been assessed by the primary decision-makers – namely the Home Secretary's own
officials – applying the relevant criteria under the relevant legal instruments. My order for interim relief does
no more than hold those decision-makers to two key questions that are currently unasked but which are
contained in the published guidance. It also ensures that the Secretary of State can satisfy herself, and this
Court, that decision-makers are aware of two important uncontentious points, to which I now turn.

The Other Aspect of Interim Relief

26. So, I turn finally to those two uncontentious points. In my judgment, it is strongly arguable on the
evidence before this Court that something has gone wrong, at least in the 'Libya Risk Group' cases, so far
as the screening interview and referrals are concerned. In my judgment, the balance of convenience and
justice strongly supports this Court ensuring that it has the confidence that the Secretary of State no doubt
expresses, namely that decision-makers are aware of the substance of the relevant legal test for a referral
and secondly that they are aware of the risk recognised by the Secretary of State so far as Libya is
concerned. There is no question of requiring the communication of any contentious point.

27. Mr Holborn resists any order, even for the communication of two non-contentious points. He does so
on the following basis. He submits that this is a 'training matter' for the Secretary of State; that there is no
arguable unlawfulness on the evidence before the court so far as steps to 'train' informed decision makers
are concerned; that it is a matter for the Secretary of State to deal with appropriate 'training and
information' for her decision-makers; and that it is, in principle, an area in which this Court should have no
role; but even if there could be a justification for this Court requiring that information is communicated to
decision-makers, there is no justification for doing so in this case; that even an email to be read by all those
who are involved would be an 'intrusion' and 'operational burden' that cannot in justice be justified.

28. I cannot accept Mr Holborn's submission that there is no properly arguable ground engaging these two
points; nor the submission that the balance of convenience and justice does not justify interim relief on the
matters. I am formulating this part of the Order, deliberately, in a way which calls on the Secretary of State


-----

(Admin)

to confirm to this Court that she has satisfied herself that decision-makers are aware of these two specific
points. That leaves to her the question of how she communicates them and ensures that they have been
communicated – but they must be communicated or have been communicated – and it is important that
this Court is put in a position to share the confidence that decision-makers are aware of them. I have in
mind, moreover, that this is a case in which I am making an Order for interim relief which does involve a
change (regarding the questions being asked). In those circumstances, there need not be any additional
form of communication beyond the one that already says 'you must ask the two questions in my published
policy guidance', to which can be added 'and I need to be sure that you are aware of these two important
points'. I was anxious to consider, with Mr Holborn's help, whether there could be any distortion from
communicating a specific point or set of points, which might give a misleading impression that other
aspects of other cases are not equally important. In my judgment, there is no realistic prospect of any
distortion of that kind. In any event, by leaving matters in the hands of the Secretary of State, she will be
able to guard against any such prospect.

Order

29. I finish where I started. It is for all these reasons that I am making the Order that I identified at the
outset of this judgment. Having had the assistance of Counsel I ordered: (1) The Defendant shall ensure as
soon as possible but at the latest by 4pm Monday 16 November 2020 that Asylum Screening Interviews in
all cases must involve asking Question 3.1 (“why have you come to the UK?”) and Question 3.3 (“please
outline your journey to the UK”) set out at pages 66-67 of the Asylum Screening and Routing Guidance
(version 5, 2 April 2020). (2) The Defendant shall by 4pm Friday 20 November 2020 file and serve a list of
those individuals who after 2pm 13 November 2020 were interviewed without those Questions being
asked. (3) The Defendant shall confirm to the Court by 4pm on 16 November 2020 that she has taken
steps which satisfy her that those conducting asylum screening interviews are aware of the following two
points: (a) The test for an NRM referral to the Single Competent Authority is “any suspicion” that a person
has been trafficked, as set out at paragraphs 31(1) and 33(3) of R (TDT (Vietnam)) v Secretary of State for
_the Home Department_ _[2018] EWCA Civ 1395 [2018] 1 WLR 4922. (b) There is evidence of a particular_
risk to migrants of being forced into modern slavery whilst in Libya. (4) A rolled-up hearing shall be listed
to determine the application for permission to apply for judicial review and, if granted, the substantive claim
for judicial review on 16-17 December 2020, time estimate 2 days. (5) The Claimants shall, by 4pm on 13
November 2020, file and serve an amended statement of facts and grounds to include a challenge to the
application of an unpublished policy that is contrary to the published asylum screening policy. (6) The
Defendant shall file and serve, by 4pm on 4 December 2020, detailed grounds of defence and any
evidence. Those detailed grounds of defence shall stand as the Defendant's skeleton argument. (7) The
Claimants shall file and serve a reply by 4pm on 10 December 2020, which shall stand as the Claimants'
skeleton argument. (8) The Claimants shall file an agreed hearing bundle, together with an agreed list of
essential pre-reading, by 4pm on 10 December 2020. (9) The Defendant shall, if so advised, file and serve
a short supplementary skeleton in response by midday on 14 December 2020, with any additional
authorities to be sent to the Claimants. (10) The Claimants shall file and serve an agreed bundle of
authorities by 4pm on 14 December 2020. (11) Costs reserved.

13.11.20

**End of Document**


-----

# R (on the application of DA and others) v Secretary of State for the Home
 Department

_[[2020] EWHC 3080 (Admin), [2020] All ER (D) 101 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61C7-9213-GXFD-8401-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 13/11/2020**

# Catchwords & Digest

**IMMIGRATION - TRAFFICKING – RELEVANT QUESTIONS**

The claimants applied for judicial review challenging the practice that was taken in asylum screening
interviews and its implications for identifying or not identifying potential victims of trafficking. In the course of those
proceedings, the claimants applied for interim relief, requesting, among other things, that the court give an order
which was by way of a direction requiring an instruction to caseworkers. In granting the interim relief sought, albeit
in a narrower and more tailored form, the Administrative Court ordered, among other things, that: (1) asylum
screening interviews in all cases should involve the asking of question 3.1 (why have you come to the UK?) and
question 3.3 (please outline your journey to the UK?) as set out in the defendant Home Secretary's published policy
guidance on asylum screening (Asylum Screening and Routing), as updated in April 2020; (2) that the Secretary of
State should confirm to the court that she had taken steps to satisfy herself that those conducting asylum screening
interviews were aware of two key points, namely that: (i) the test for an NRM referral to the competent authority was
the one articulated at paras 31(1) and 33(1) of R (on the application of TDT, by his litigation friend Topteagarden) v
[Secretary of State for the Home Department [2018] All ER (D) 38 (Jul); and (ii) 'there is evidence of a particular risk](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)
to migrants of being forced into modern slavery whilst in Libya'.

# Cases considered by this case


R (on the application of Pantellerisco and others) v Secretary of State for Work and
Pensions

_[[2020] EWHC 1944 (Admin), [2020] PTSR 2289, [2020] All ER (D) 145 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60FW-X9H3-GXFD-80DP-00000-00&context=1519360)_
Considered

Secretary of State for Work and Pensions v Johnson and others

_[[2020] EWCA Civ 778, [2020] PTSR 1872, [2020] All ER (D) 117 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:606D-8KG3-CGXG-0369-00000-00&context=1519360)_
Considered


20/07/2020

AdminCt

22/06/2020

CACivD


-----

R (on the application of NN) v Secretary of State for the Home Department; R (on the
application of LP) v Secretary of State for the Home Department

_[[2019] EWHC 1003 (Admin), [2019] All ER (D) 104 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VJB-V2K2-8T41-D0R8-00000-00&context=1519360)_
Followed

R (on the application of TDT, by his litigation friend Topteagarden) v Secretary of State
for the Home Department (Equality and Human Rights Commission intervening)

_[[2018] EWCA Civ 1395, [2018] 1 WLR 4922, [2018] All ER (D) 38 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_
Applied

Medical Justice (R on the application of) v Secretary Of State For The Home
Department

_[[2010] EWHC 1425 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_
Followed

**End of Document**


17/04/2019

AdminCt

19/06/2018

CACivD

21/05/2010

AdminCt


-----

