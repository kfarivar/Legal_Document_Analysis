# Koceku v Republic of Albania

_[[2024] EWHC 1028 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6C0J-S2P3-RX1P-60WD-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 10/05/2024**

# Catchwords & Digest

**EXTRADITION - INTERFERENCE WITH FAMILY LIFE – PROPORTIONALITY ASSESSMENT**

The Administrative Court dismissed the appellant’s appeal against the district judge’s decision to send the
appellant’s case to the Secretary of State further to _[s 87(3) and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DG0-TWPY-Y0GY-00000-00&context=1519360)_ _[s 103(1)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DG0-TWPY-Y01M-00000-00&context=1519360)_
ground of appeal was that the district judge was wrong to find that extradition would be a proportionate interference
with the appellant’s rights under art 8 of the European Convention on Human Rights. The appellant, an Albanian
national, relied on an appeal by the prosecution in the case against him in Albania, in which a suspended sentence
was sought based on a legal mistake. The appellant also submitted that evidence that he had been the victim of
**_modern slavery and was a vulnerable individual tipped the art 8 balance in his favour. The court held that the test_**
for allowing an appeal under Part 2 of the Act was set out in s 104(2)-(4). The High Court could only allow an
appeal if the first instance judge ought to have decided a question before him differently, and had he done so, it
would have required him to discharge the appellant. The judge’s approach to the proportionality assessment in the
appellant’s case was correct, and although the Albanian prosecution’s stance made the case unusual, it did not
weigh particularly heavily against extradition. Further, the finding on modern slavery
assist the appellant.

# Cases considered by this case

R v Brecani

_[[2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62R7-7X53-GXFD-802D-00000-00&context=1519360)_
Applied

Love v Government of the United States of America

_[[2018] EWHC 172 (Admin), [2018] 2 All ER 911, [2018] 1 WLR 2889, [2018] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SD9-VPH1-DYBP-M3X5-00000-00&context=1519360)_
_[20 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RK4-GY11-DYBP-N50H-00000-00&context=1519360)_
Considered

Polish Judicial Authorities v Celinski; Slovakian Judicial Authority v Cambal; R (on the
application of Inglot) v Secretary of State for the Home Department


19/05/2021

CACrimD

05/02/2018

DC

06/05/2015

DC


-----

_[[2015] EWHC 1274 (Admin), [2016] 3 All ER 71, [2016] 1 WLR 551, [2015] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K1J-TNN1-DYBP-M44Y-00000-00&context=1519360)_
_[37 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FXK-J7M1-DYBP-N4WD-00000-00&context=1519360)_
Applied
Miraszewski and others v District Court In Torun, Poland and another

_[[2014] EWHC 4261 (Admin), [2015] 1 WLR 3929, [2014] All ER (D) 208 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DW4-ND41-DYBP-N3JB-00000-00&context=1519360)_
Considered

HH v Deputy Prosecutor of the Italian Republic, Genoa; PH v Deputy Prosecutor of the
Italian Republic, Genoa; F-K (FC) v Polish Judicial Authority

_[[2012] UKSC 25, [2013] 1 AC 338, [2012] 4 All ER 539, [2012] 3 WLR 90, (2012)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56WY-KBP1-DYBP-M4NC-00000-00&context=1519360)_
[Times, 02 July, [2012] All ER (D) 130 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55XX-3X21-DYBP-N4W5-00000-00&context=1519360)
Applied

Szombathely City Court v Fenyvesi

_[[2009] EWHC 231 (Admin), [2009] 4 All ER 324, [2009] All ER (D) 202 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7WW4-W0S0-Y96Y-G155-00000-00&context=1519360)_
Considered

**End of Document**


17/12/2014

QBD

20/06/2012

SC

19/02/2009

AdminCt


-----

