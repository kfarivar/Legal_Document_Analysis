# Balogh and others v Hick Lane Bedding Ltd [2021] All ER (D) 132 (Mar)

[2021] EWHC 1140 (QB)

Queen's Bench Division

EnglandandWales

Master Davison

9 March 2021

**Damages – Modern slavery – Assessment of damages in modern slavery civil claims brought against**
**former employer**
Abstract

_In circumstances where the claimant Hungarian nationals had been the victims of_ **_modern slavery, and where_**
_judgment in default had been granted in their favour in respect of their civil claims against the defendant company_
_(their former employer), the Queen's Bench Division gave judgment on the assessment of damages in the three_
_cases, which had been ordered to be case-managed and tried together._
Digest

The judgment is available at: [2021] EWHC 1140 (QB)

**Background**

The proceedings concerned the assessment of damages in three cases of modern slavery, which were ordered to
be case-managed and tried together.

The claimants (L, T and N) were Hungarian nationals who were trafficked into the UK in 2012 and 2013, having
been recruited by a man (O) or by persons connected or associated with him. In each of case, the claimant had
been put to work in the defendant company's factory premises in West Yorkshire. Mr R was the Managing Director
and the majority shareholder of the defendant, which traded under the name 'Kozeesleep' and which manufactured
bed frames and mattresses.

Mr R was convicted of conspiring with O and another person to arrange or facilitate travel within the UK for
[exploitation, contrary to s 1(1) of the Criminal Law Act 1977 (CLA 1977). The claimants brought civil claims against](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BGB0-TWPY-Y04M-00000-00&context=1519360)
the defendant based on the duties which the defendant had owed to them and their employer, principally: that it had
failed to pay them their wages and provide them with a safe place and system of work, and that it had intimidated,
harassed and exploited them.

Judgment in default was entered in favour of each claimant and they were entitled to have damages assessed in
accordance with those judgments.

**Issues and decisions**

(1) The court considered what damages the claimants were entitled to receive and, in particular, it assessed
damages in the case of L.


-----

L, aged 42 had been employed for 14 days, from 18 November 2013 to 2 December 2013. He had been housed in
squalid and overcrowded conditions and, after two days, he had been put to work in the loading area of the factory
and, later, on the machines inserting springs into the mattresses. He had been given no training or safety
instructions or equipment and he had worked very long hours. L had been paid £10 per week, plus two packets of
tobacco. L had been treated with a total lack of respect and consideration, amounting to cruelty.

In the present case, each claimant was entitled to general damages under the following heads: (i) because they had
been subjected to the intentional torts of intimidation and harassment, which had deprived them of their personal
autonomy in circumstances closely akin to false imprisonment, they were entitled to an award of damages reflecting
those circumstances. (ii) They were entitled to awards for pain, suffering and loss of amenity, consequent on their
psychiatric injuries. (iii) They were entitled to an award for 'sub-clinical' distress, anxiety and injury to feelings. That
fell to be assessed by reference to the well-known Vento guidelines (see [17] of the judgment).

For the avoidance of doubt, the court did not regard an award of aggravated damages as appropriate because such
an award could only be made in order to compensate the claimants for the affront to their feelings and their dignity
caused by the defendant's high-handed and oppressive conduct. However, that injury was already reflected in the
award made under the _Vento guidelines and to award anything further would, therefore, involve double counting_
(see [18] of the judgment).

A separate question was whether general damages should consist of distinct awards for each of the heads the
present court had identified, or a single rolled-up (or 'global') award. In the circumstances of the present cases, to
make separate awards would involve very substantial overlap and, therefore, double recovery. For each claimant, it
had been a single, lived experience, albeit that it had impacted on them in a variety of ways. The court proposed to
identify, for each claimant, the relevant bracket for each head of loss and then make a single award, leaving out
only exemplary damages, which would be assessed separately (see [19] of the judgment).

In addition to general damages, the claimants were entitled to claim financial losses, comprised of: (i) the wages
they had earned and had been entitled to receive, but had not received at Kozeesleep; (ii) past loss of earnings
caused by psychiatric injury; (iii) future loss of earnings attributable to psychiatric injury; and (iv) the costs of
medical treatment (see [20] of the judgment).

In the case of L, when he had seen Dr J, he had been suffering from complex PTSD, caused by his experiences at
the hands of the defendant. An alternative diagnosis was adjustment disorder with depression and anxiety. He
stood in need of at least 12 sessions of cognitive behavioural therapy (CBT). The prognosis then was for
improvement over an 18-month to 2-year period, and a period of 2 to 3 years to recover his working capacity (see

[23] of the judgment).

L had been able to work in sheltered employment for a short period, doing gardening work. He had earned around
£5,988 in all. Otherwise, he had not worked. He appeared entitled to his loss of earnings to date and for two-and-ahalf years into the future (see [26] of the judgment).

L fell into the 'moderately severe' bracket of the Guidelines for post-traumatic stress disorder and/or a general
psychological damage. Those brackets were respectively £21,730 to £56,180 and £17,900 to £51,460. His
symptoms were not sufficiently disabling and the prognosis was not sufficiently bleak to place him into the 'severe'
bracket, which was the next bracket up. However, he did have two separate conditions and, therefore, he fell above
the midpoint of the 'moderately severe bracket (see [27] of the judgment).

Additionally, he suffered the loss of his personal autonomy and the impact on his liberty and freedom of action,
which were the result of the intentional torts. That was akin to a period of false imprisonment. The duration, in L's
case, had been 14 days (see [28] of the judgment).

For injury to feelings, L would fall into the middle Vento guideline. The duration of the tortious behaviour had not
been such as to place him into the top band, which was reserved for a 'lengthy campaign of discriminatory
harassment' (see [29] of the judgment).


-----

An appropriate global award, reflecting those three heads, was £60,000 (see [30] of the judgment).

The conduct of the defendant merited an award of exemplary damages of £5,000 per claimant. That had to be
added to the total, making a grand total of general damages, in L's case, of £65,000. The court would have made a
higher award for exemplary damages, but the relevant conduct for which the defendant was vicariously liable had
already been met with a prison sentence and the company was insolvent. It seemed to be relevant to take both
those things into account (see [31] of the judgment).

L's financial losses, and those of the other claimants, had been calculated on the basis of the median pay for
elementary process plant occupations, which was £23,830 gross, or £19,846 net. The claimants' lost earnings at
the time they had actually been working at Kozeesleep had been calculated on the basis of the prevailing national
minimum wage. Both those approaches were fair. In L's case that produced awards as followed: for his lost
earnings, while he had been at Kozeesleep, the court awarded £1,679; for his past loss of earnings, the court
awarded £136,243; and for his future loss of earnings, which would extend two-and-a-half years into the future, the
court awarded £51,798 (see [32] of the judgment).

In addition, the court awarded L the costs of the medical treatment that he stood in need of. That cost was £8,400
(see [33] of the judgment).

_[Rookes v Barnard [1964] AC 1129 [1964] 2 WLR 269 [1964] 1 All ER 367 considered; Vento v Chief Constable of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP80-TWP1-609R-00000-00&context=1519360)_
_West Yorkshire Police_ _[2002] EWCA Civ 1871_ _[[2003] IRLR 102](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1YX-00000-00&context=1519360)_ _[[2002] All ER (D) 363 (Dec) considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWJ1-DYBP-N3CH-00000-00&context=1519360)_ _AT v_
_Dulghieru_ _[[2009] EWHC 225 (QB)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7V26-43M0-Y96Y-H40J-00000-00&context=1519360)_ _[[2009] All ER (D) 194 (Feb) considered; R (on the application of MK) v Secretary](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7V26-43M0-Y96Y-H40J-00000-00&context=1519360)_
_of State_ _[2010] EWCA Civ 980_ _[[2010] All ER (D) 26 (May) considered; R v Rafiq (Mohammed) and Another (2016)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YD6-4HD0-Y96Y-H2V9-00000-00&context=1519360)_

_[[2016] EWCA Crim 1368 considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KPY-7221-F0JY-C3NV-00000-00&context=1519360)_ _Komives v Hick Lane Bedding Ltd and others_ _[[2020] EWHC 3288 (QB)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61F6-29X3-GXFD-83KX-00000-00&context=1519360)_
considered.

(2) The court assessed damages in the case of T

T, aged 55, had been employed with the defendant for 67 days, from 20 July 2013 to 25 September 2013. He had
three children of school age in Hungary to support. He had had to share accommodation with 13 other people, all or
most of whom were being similarly exploited. His room at the accommodation had been shared with four others. He
had been put to work in the loading bay and treated with the same contempt for even the most basic standards to
be expected of an employment relationship.

The diagnosis and prognosis for T was much the same as for L. T was suffering from PTSD in the severe range,
with an alternative diagnosis of adjustment disorder with depression and anxiety (see [34] of the judgment).

Unlike L, T had carried out further work in a commercial environment, both in the UK, for 21 months, and in
Hungary, for 9 months, when he had briefly returned there. Due, no doubt, to funding difficulties, T had not
undertaken the CBT that had been recommended by Dr J. The court inferred that the prognosis remained broadly
the same as that given by Dr J, namely a return to a reasonable level of functioning and employability within a
period of about 18 months. T was placed in the same bracket of the guidelines as L, but at a lower point in that
range due to T's lower impairment to his working capacity and slightly better prognosis, and due, also, to the fact
that he did not have the co-morbidity of a psychotic condition (see [35], [36] of the judgment).

In T's case, the conditions of modern slavery had endured for two months. The analogy with false imprisonment
extended to and embraced the principle that the impact of the passage of time should be placed on a tapering or
reducing scale (see [37] of the judgment).

For his injury to feelings, T would fall towards the top of the middle band of Vento (see [38] of the judgment).

An appropriate global award of general damages in T's case, reflecting the much longer period of modern slavery,
but taking into account the fact that the main impact of that would be felt in the early part of the relevant period,
would be £65,000. In addition, T was entitled to an award of exemplary damages in the sum of £5,000. The grand
total of general damages, in his case, was £70,000 (see [39] of the judgment).


-----

The approach to T's loss of earnings had been to give credit for his periods of employment since his ordeal at the
same rate as that claimed. That was because he had been unable to produce wages records for those periods. The
partial loss of earnings he had suffered was attributable to the psychiatric injuries and that he would suffer a further
18 months or so of lost earnings (see [40] of the judgment).

Turning to the quantification of those losses, for his lost earnings while at Kozeesleep, the court awarded £9,160;
for his past loss of earnings, and taking into account the earnings which the court had mentioned, both in the UK
and in Hungary, a sum of £107,208 would be awarded; and for 18 months future loss of earnings, taking into
account the present discount rate, the sum of £29,881 would be awarded (see [41] of the judgment).

For his treatment costs, the court awarded £1,980 (see [41] of the judgment).

(3) The court assessed damages in the case of N.

N, aged 46, had been employed with the defendant for around three weeks, between December 2012 and January
2013. Unlike L and T, he had been recruited to work for the defendant having first been trafficked into the UK to
work at a warehouse in Sheffield, where he had been mistreated. He had been introduced to O on the promise of
better employment. However, he had been accommodated similarly to the others and subjected to the same
degrading work and working conditions.

N had been diagnosed as suffering from a mixed anxiety and depressive disorder, attributable to his experiences of
**_modern slavery. Dr O's view was that the prognosis was good, especially if he underwent a brief course of_**
cognitive behavioural therapy (see [43]of the judgment).

When N had seen Dr S, which had been nearly three years later, he had been continuing to suffer from mixed
anxiety and depression and, at that time, he had met the criteria for a diagnosis of mild post-traumatic stress
disorder. His condition had become chronic. However, with treatment, Dr S expected an improvement over a period
of two years. She suggested a phased return to work (see [44] of the judgment).

Although N's psychiatric injury was not as bad as those of his fellow claimants, because of the persistence of his
symptoms and the relatively cautious prognosis he did not fall into the 'less severe' bracket of either the PTSD or
the general psychiatric damage sections of the guidelines. He was in the 'moderate' category, for which the
brackets wee respectively £7,680 to £21,730, and £5,500 to £17,900. His period of modern slavery was around 21
days, meriting an award somewhere between that to L and that to T. Finally, he, too, fell into the middle _Vento_
bracket (see [45] of the judgment).

An appropriate global award in his case would be £50,000, to which the court added £5,000 for exemplary
damages, making a grand total of general damages of £55,000 (see [46] of the judgment).

For his lost earnings at Kozeesleep, the court awarded the sum of £2,324. For his past loss of earnings, the sum of
£142,231 would be awarded. As for future loss of earnings, the court had carefully considered Dr S's report. Her
suggestion was of a phased return to work over a period of 6 months, increasing, thereafter, to full-time working.
That did not support a future loss of earnings claim of 2½ years, which was what was set out in the schedule of loss
and in the claimants' counsel's very helpful table at page 2 of his skeleton argument. Taken in conjunction with the
general prognosis, the court would award future loss of earnings extending to 12 months and that came to £19,846
(see [47] of the judgment).

Finally, in N's case, the court awarded the costs of medical treatment, which were £3,325 (see [48] of the
judgment).

James Robottom (instructed by Anti Trafficking and Labour Exploitation Unit) for the claimants.

The defendant did not appear and he was not represented.
Carla Dougan-Bacchus Barrister.


-----

**End of Document**


-----

