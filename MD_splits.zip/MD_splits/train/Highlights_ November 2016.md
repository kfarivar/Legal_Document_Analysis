# Highlights: November 2016

This month we report the decision of the Court of Justice of the European Union in _Kratzer v R+V Allgemeine_
_Versicherung AG_ _[[2016] IRLR 888. The claimant is a lawyer with many years professional experience. I have been](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W0RF-00000-00&context=1519360)_
told that he is a well-known serial litigant in Germany. It is alleged that he applies for jobs in which he is not
sincerely interested and when he receives a negative response, he brings discrimination proceedings, some of
which are settled out of court by the employer. This is a phenomenon by no means unknown in UK employment
law. In the case referred to the CJEU, the claimant alleged that he was discriminated against by an insurance
company on grounds of his age when he unsuccessfully applied for a trainee post. The advertisement stipulated
that applicants should be university graduates who had either completed their degree within the past year or would
complete it in the coming months. When the claimant learned that all of the training posts had been awarded to
women, he added a claim of sex discrimination. There was a finding of fact by the national court that the claimant's
application for a trainee position was not submitted with a view to obtaining employment in that post but only in
order to obtain the formal status of an “applicant” for employment, “with the sole purpose of claiming
compensation”. The reference asked whether in such circumstances, could the claimant be regarded as seeking
“access to employment” within the meaning of the Framework Employment Equality _[Directive 2000/78 and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9P23-GXFD-82PK-00000-00&context=1519360)_
[recast Equal Treatment Directive 2006/54? It is no surprise that the Court of Justice rules that “a factual situation](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9RX3-GXFD-81RS-00000-00&context=1519360)
with characteristics such as those” is “in principle, outside the scope” of the Directives. The CJEU explains that the
Directives “apply to a person seeking employment, and also in regard to the selection criteria and recruitment
conditions of that employment …” Someone in the claimant's position “clearly is not seeking to obtain the post for
which he formally applies” and therefore could not rely on the protection of the Directives because he was not
seeking “access to employment”. Furthermore, such a person could not be regarded as a “victim” within the
meaning of the Directives or as a “person injured” having sustained “loss” or “damage”.

Where an employee has become disabled and has been reassigned to a new and less well-paid position, is it a
**reasonable adjustment for the employer to be required to protect the employee's pay? That is the main issue in**
_G4S Cash Solutions (UK) Ltd v Powell_ _[[2016] IRLR 820. The claimant was given work in a new role at his existing](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W25K-00000-00&context=1519360)_
rate of pay after he had a back injury. After some months, however, the employer said it was only prepared to
employ him in this role at a reduced rate of pay. When the claimant refused to accept these terms, he was
dismissed. He claimed disability discrimination. An employment tribunal found that it would have been a reasonable
adjustment for the employer to continue to offer the employee the alternative role with no reduction in pay.
Dismissing an appeal by the employer, HH Judge David Richardson says that there is no reason why the duty of
reasonable adjustment “should be read as excluding any requirement upon an employer to protect an employee's
pay in conjunction with other measures to counter the employee's disadvantage through disability. The question will
always be whether it is reasonable for the employer to have to take that step.” He adds that “many forms of
measure which it will be reasonable for an employer to have to take will involve a cost to the employer. It may be
direct, in the form of provision, training or support. It may be indirect, in that measures will render the disabled
person's employment less productive so that the employer is, in effect, subsidising the employee's wages when
compared with those of a non-disabled person.” Looked at that way, he concludes, “I see no reason in principle why
pay protection, which is no more than another potential form of cost for an employer, should be excluded as a 'step'
… I do not expect that it will be an everyday event for an employment tribunal to conclude that an employer is
required to make up an employee's pay long-term to any significant extent – but I can envisage cases where this
may be a reasonable adjustment for an employer to have to make as part of a package to get an employee back to
work or keep an employee in work.” Finally, the judge pointed out that circumstances may change so that an


-----

adjustment that is reasonable at one time may become unreasonable in the future because the employer's financial
position has changed or because the alternative job is no longer needed.

A vocational placement is a standard part of the educational course for many professionals. The issue in Blackwood
_v Birmingham & Solihull Mental Health NHS Foundation Trust_ _[[2016] IRLR 878 is whether a student can bring a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W1TK-00000-00&context=1519360)_
claim in the employment tribunal alleging discrimination in connection with a **work placement that is part of her**
studies. As part of the claimant's university course to become a nurse, she had a placement with the Trust. The
placement was withdrawn, however, because she was unable to comply with the shift patterns as a result of her
childcare responsibilities. She sought to bring indirect sex discrimination proceedings in the employment tribunal
against the Trust, as the provider of the work placement. Both the employment tribunal and the EAT held that there
was no jurisdiction because the claim should have been brought in the county court under the Equality Act's
provisions on discrimination in education rather than under the employment provisions. They held that the exclusion
in s.56(5) applied.

This excludes claims of discrimination in vocational training where it concerns “training or guidance for students of
an institution to which s.91 applies in so far as it is training or guidance to which the governing body of the institution
has power to afford access.” The EAT held that the claim should have been brought against the university under
s.91, which provides a remedy in the county court for discrimination by further and higher education institutions,
because the university had the “power to afford access” to the training at the Trust. However, s.91 only directly
covers discrimination by the institutions themselves and not by the training provider. This leads the Court of Appeal
to allow the claimant's appeal and to rule that where a student experiences discrimination during the course of a
placement, they can bring a claim directly against the work placement provider. Giving the only reasoned decision,
Lord Justice Underhill points out that unless the Act was interpreted to allow this, there would be a lacuna in the
statutory protection contrary to EU discrimination law. To avoid this, he holds that the court would apply the
_Marleasing_ principle so as to redraft s.56(5) to read: “This section does not apply to discrimination in relation to
training or guidance for students of an institution to which s.91 applies to the extent that the student is entitled under
that section to make a claim as regards that discrimination.”

**Restricted reporting orders are the issue in Fallows v News Group Newspapers Ltd** _[[2016] IRLR 827. Mr Fallows](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W13H-00000-00&context=1519360)_
was Elton John's hairdresser. He brought proceedings in the employment tribunal against Sir Elton and others
alleging unfair dismissal and sex discrimination. Part of his claim included an allegation of sexual misconduct within
the meaning of _[s.11(6) of the Employment Tribunals Act 1996. In due course, a restricted reporting order (RRO)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6190-TWPY-Y045-00000-00&context=1519360)_
was made but the parties then settled the claim and the claim was withdrawn. On the application of News Group
Newspapers (NGN), the employment judge then revoked the RRO. On appeal, the main issues of principle before
the EAT were whether the RRO automatically expired on withdrawal of the claim and whether the employment
judge had jurisdiction to reconsider an RRO which was extant notwithstanding that the claims had been withdrawn
on being settled. Mrs Justice Simler holds that an RRO does not lapse automatically following settlement and
withdrawal of the claim, as distinct from promulgation of a decision where it does lapse automatically. In any event,
as a result of the changes made by the 2013 Employment Tribunals Rules of Procedure, a tribunal has power in an
appropriate case to make an order that outlasts the proceedings. “Permanent protection may or may not be
appropriate in a given case, but where it is sought it requires particularly careful consideration. It is likely to be a
rare case where the Article 8 rights at stake are so strong that it is necessary to grant indefinite restrictions as the
means of striking the balance between Article 8 rights on the one hand and the principle of open justice and rights
of freedom of expression on the other.” She also rules that a tribunal retains jurisdiction even after withdrawal of a
claim to consider whether to vary or revoke an RRO. Were this not the case, a temporary RRO would become
permanent when a claim was withdrawn.

How protected are “protected conversations”? _Faithorn Farrell Timms LLP v Bailey_ _[[2016] IRLR 839 is the first](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W081-00000-00&context=1519360)_
[EAT decision to give guidance on s.111A of the Employment Rights Act 1996 as amended, which stipulates that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:58T2-W571-DYCN-C2MY-00000-00&context=1519360)
“evidence of pre-termination negotiations is inadmissible” in unfair dismissal proceedings. The claimant was
employed as a part-time office secretary. She contended that it had been made clear that part-time working was no
longer an option and initiated discussions about a settlement agreement for termination of her employment. This did
not result in agreement and she brought a claim of constructive unfair dismissal and sex discrimination. In her ET1


-----

she referred to the employer's conduct towards her during the period when a settlement was being discussed and
sought to rely on this as evincing bullying and discrimination in breach of the trust and confidence term. In its ET3,
the employer had not objected but itself had referred to the material in question. Later, however, it objected to the
claimant's reliance on what it said was privileged material at common law, or alternatively material rendered
inadmissible by s.111A. The employment tribunal ruled that the material in question was generally admissible,
subject to redaction of specific references to any offer. On appeal, however, HH Judge Eady QC in the EAT points
out that it is a requirement of without prejudice privilege that there is a dispute between the parties. She notes that
this threshold requirement has not always proved easy to determine and that therefore it has been removed in
respect of unfair dismissal claims by s.111A. “Section 111A has to be viewed independently of common law without
prejudice principles: its construction is to be informed by the language Parliament chose to use, not the language of
the case law that underpins without prejudice privilege.” Adopting that approach, she rules that what is rendered
inadmissible by s.111A is “evidence of any offer made or discussion held with a view to terminating the employment
on agreed terms and … that must extend to the fact of the discussions, not simply to their content.” This extends
beyond the relevant discussion between employer and employee but also encompasses discussions within the
employer, such as between different managers or between a manager and a human resources adviser. If evidence
of such discussions were ruled admissible, “it would run counter to the purpose of s.111A”. This privilege, she
holds, cannot be waived, unlike under the common law without prejudice rule. “I am unable to see how [s.111A] can
be read so as to permit agreement to the admission of evidence otherwise rendered inadmissible by this provision.”

If a manager making a decision to dismiss has been misled by another manager as to the true and unlawful reason
for dismissal can the unlawful reason be imputed to the decision-maker and therefore to the employer? This is
considered by the EAT in Royal Mail Group Ltd v Jhuti _[[2016] IRLR 854. The case concerned a marketing specialist](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W1K2-00000-00&context=1519360)_
who claimed that she had been dismissed after making protected disclosures to a manager

about the behaviour of a work colleague, which she considered to be in breach of regulatory requirements. The
manager to whom she made the disclosure was not the manager who dismissed her. The dismissing manager
genuinely believed that the claimant was being dismissed for poor performance and she was unaware of her
protected disclosures. The employment tribunal directed itself in accordance with the Court of Appeal's decision in
the age discrimination case of CLFIS (UK) v Reynolds and held that in order for the dismissal to be for making the
protected disclosure and thus automatically unfair, the dismissing manager must herself have been motivated by
the protected disclosures. On appeal, however, Mr Justice Mitting says that there is “no read across from
[discrimination principles”. Section 103A of the Employment Rights Act 1996 as amended refers to “the reason (or, if](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y0ND-00000-00&context=1519360)
more than one, the principal reason) for the dismissal” and there is “no binding statement in the authorities that the
mind of that person or those persons must in all circumstances be equated with that of the employer.” Instead, he
says, “as a matter of law, a decision of a person made in ignorance of the true facts whose decision is manipulated
by someone in a managerial position responsible for an employee, who is in possession of the true facts, can be
attributed to the employer of both of them.” That principle applied to this case. Clearly Mr Justice Mitting is not in a
position to challenge the binding authority of Lord Justice Underhill's highly restrictive view in _CLFIS of employer_
liability for discrimination, but this case represents a refusal to extend that reasoning to other strands of employment
law.

Does the ACAS Code of Practice on Disciplinary and Grievance Procedures apply where dismissal is for “some
other substantial reason”? The claimant in Phoenix House Ltd v Stockman _[[2016] IRLR 848 was an accountant who](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W07P-00000-00&context=1519360)_
was dismissed on grounds that there had been an irretrievable breakdown in the working relationship. The
employment tribunal held that this view was outside the range of reasonable responses and that the dismissal was
therefore unfair. It went on to hold that the Code of Practice applied and therefore increased unfair dismissal
[compensation by 25% for non-compliance with the Code, as permitted by s.207A of the Trade Union and Labour](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7TF9-W580-Y97X-73B3-00000-00&context=1519360)
Relations (Consolidation) Act 1992 as amended. Mr Justice Mitting in the EAT decides that the Code, and thus the
uplift, does not apply. “In my judgment, clear words in the Code are required to give effect to that sanction,
otherwise an employer may well be at risk of what is in reality a punitive element of a basic and compensatory
award in circumstances in which he has not been clearly forewarned by Parliament and by ACAS that that would be
the effect of failing to heed the Code. The Code does not in terms apply to dismissals for some other substantial
reason. Certain of its provisions, such as for example investigation, may not be of full effect in any event in such a


-----

dismissal.” Thus, the EAT in this case takes a similar view to that of a different division of the Appeal Tribunal in
_Holmes v Qinetiq, which held that the ACAS Code and the uplift provisions do not apply to ill health dismissals._

In what is understood to be the first time that a UK company has been held civilly liable to victims of trafficking, the
High Court has upheld a claim for compensation by six workers trafficked from Lithuania. In _Galdikas v DJ_
_Houghton Catching Services Ltd_ _[[2016] IRLR 859, Mr Justice Supperstone finds that the defendant gangmasters,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W0RH-00000-00&context=1519360)_
who ran a business providing labour to poultry farms, failed to pay the claimants the minimum wages required
under the Agricultural Wages Order, including the rates for night work and travelling time. The claimants were paid
for the number of chickens caught rather than for time worked or time spent travelling. Note that the Agricultural
Wages Order, which provided ultimate protection in this case, continues to apply to workers employed in England
before 1 October 2013, but does not apply to workers employed since then, as a result of the abolition of the
Agricultural Wages Board. Note also that the **_[Modern Slavery Act 2015 contains reporting obligations requiring](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
larger companies to report on the steps they are taking to ensure that modern slavery is not taking place in their
supply chains (as well as in any part of their business).

_Theedom v Nourish Trading Ltd t/a CSP Recruitment_ _[[2016] IRLR 866 is an interesting case in which the claimant](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M0D-72N1-DYPB-W072-00000-00&context=1519360)_
recruitment consultant sued his former employer and his former manager for **libel** in respect of emails sent
following the termination of his employment. These said that he had been “dismissed for gross misconduct”
because he had regularly supplied commercially important confidential information about CSP's business and its
customers' businesses to his ex-colleague and girlfriend and to CSP's commercial rivals in breach of his contractual
obligations. Some of the emails added that his misconduct was so serious that there were reasonable grounds to
suspect that it also amounted to a criminal offence. Mr Justice Warby holds that the defendants had a defence to
the action because, in accordance with _[s.2(1) of the Defamation Act 2013, “the imputation conveyed by the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:589D-C9M1-DYCN-C18C-00000-00&context=1519360)_
statement complained of is substantially true.” The judge finds that the claimant's conduct gave his employer
[reasonable grounds for suspecting him of offences contrary to s.4 of the Fraud Act 2006, which makes it an offence](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0FT-00000-00&context=1519360)
for a person who occupies a position in which he is expected to safeguard, or not to act against, the financial
interests of another person, to dishonestly abuse that position with the intention of making a gain or causing a loss
to another. “Mr Theedom's position was one in which he was expected both to safeguard and not to act against the
financial interests of CSP. His conduct … could reasonably be considered an 'abuse' of that position” and he could
reasonably be suspected of intending, by abuse of his position, to secure gains for his partner, her colleague and
their employer. “His conduct could reasonably found suspicion that he was acting dishonestly.” The judge adds:
“This was misconduct which would have justified prosecution.” This suggests that the framework of the criminal law
covers a comparatively junior employee working in competition in breach of his contract of employment.

Michael Rubenstein

Michael@rubensteinpublishing.com

**End of Document**


-----

