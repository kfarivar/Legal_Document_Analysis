# JR247's Application to Apply for Judicial Review [2024] NIKB 72

NORTHERN IRELAND KING'S BENCH DIVISION

COLTON J

13 SEPTEMBER 202413 SEPTEMBER 2024

**COLTON J:**

**_Introduction_**

**[1] The Applicant was born in Lagos, Nigeria on 20 February 1975. She fled Nigeria to avoid female genital**
mutilation.

**[2] In November 2019 she entered the United Kingdom via Manchester to London where she became a victim of**
sexual exploitation/forced sex work.

**[3] On 27 February 2020 she escaped the house in which she was held and travelled to Belfast. She claimed**
asylum in this jurisdiction on 5 March 2020. Ultimately, she was granted refugee status on 20 January 2023.

**[4] The Applicant had issued judicial review proceedings on 4 November 2022 challenging the Respondent's**
failure at that time to have made a decision regarding her asylum claim.

**[5] Leave was granted by the court on 7 November 2022. The Applicant was granted anonymity in these**
proceedings on the grounds that she was a victim of **_modern slavery for the specific purposes of sexual_**
exploitation when she made her asylum claim.

**[6] After the decision was made to grant the application on 20 January 2023 the Respondent argued that the**
application for judicial review was now academic and should be dismissed.

**[7] The Applicant maintained that she was entitled to seek a declaration and damages on the ground that the**
historic delay violated her rights under art 8 of the European Convention on Human Rights (“ECHR”) as enacted in
[the Human Rights Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

**[8] As of January 2023 the court had dealt with multiple judicial review applications arising from delays in**
determining asylum claims. Generally speaking it was the court's practice to grant leave after which a final decision
was usually made prior to a full hearing. This resulted in claims being withdrawn.

**[9] However, in light of an increasing number of applications and the Applicant's insistence on seeking a**
declaration and damages the court felt it was appropriate to grant leave, notwithstanding that a decision had been
made. As there had been no judicial consideration of the issues raised in this application in this jurisdiction the court
felt it appropriate to deal with the matter given the number of similar cases which were arising.

**_Factual background_**

**[10] From the Applicant's perspective the important dates are as follows:**


-----

|Col1|Page 2 of 19 JR247's Application to Apply for Judicial Review [2024] NIKB 72|
|---|---|
|5 March 2020|The applicant claims asylum.|
|29 July 2020|The applicant submits her preliminary information questionnaire (PIQ).|
|8 October 2020|The respondent sends a letter that states that it had not been possible to determine the claim within 6 months and states there would be further contact within 6 months.|
|29 October 2020|The applicant has her substantive asylum interview. At that time it was agreed that the case would be referred to the National Referral Mechanism (“NRM”) for a determination of whether she was a victim of modern slavery.|
|13 October 2021|A conclusive grounds decision was made that the applicant was a victim of sexual exploitation/forced sex work.|
|9 June 2022|The applicant's solicitor writes to the respondent asking for an asylum decision.|
|6 September 2022|The applicant's solicitor writes to the respondent asking for an asylum decision. At this point concerns were raised about the impact on the mental health of the applicant arising from delay.|
|5 October 2022|The applicant's solicitor writes to the respondent asking for an asylum decision. The applicant's solicitor sends a letter in accordance with the pre-action protocol (PAP).|
|11 October 2022|The respondent sends a PAP reply.|
|4 November 2022|Judicial review proceedings issued.|
|20 January 2023|Applicant granted refugee status.|
|27 January 2023|Leave granted to apply for judicial review.|



**[11] The Respondent has filed an affidavit from a Mr Elliott, Senior Case Worker, employed by the Respondent**
which sets out the full history of the application from the Respondent's perspective as follows:

|Date|Event|
|---|---|
|20/02/1975|Applicant born in Lagos, Nigeria|
|02/07/2002|Visa application for Family Visit made – Visa Application Form (VAF): 335021. Withdrawn same day|
|03/07/2002|Visa application for Visit visa made – VAF: 335249. Refused on 13/08/2002|
|30/05/2019|Visa application for Family Visit made – VAF: 1461453. Granted on 21/06/2019. Expiry date 21/12/2019.|
|25/07/2019|Flew from Nigeria to UK using visa.|
|October 2019|Returned to Nigeria.|
|15/11/2019|Flew from Nigeria to Manchester via Doha, arriving the following day. Travels from Manchester to London by train, is met by a woman she was introduced to through the church in Nigeria, and falls into exploitation by this woman.|
|27/02/2020|Escapes the house she was held in, is assisted by strangers to Belfast.|
|March 2020|Beginning of restricted working conditions during the first lockdown.|
|03/03/2020|Contacted Asylum Intake Unit to make appointment to claim asylum.|
|05/03/2020|Asylum claim raised. Ownership with SSC Belfast. Screening interview completed. All paperwork provided, including Preliminary Information Questionnaire (PIQ) forms. Application Registration Card requested. Reporting conditions set for 3-monthly appointments. Screening indicates National Referral Mechanism (NRM) referral made prior to claim.|
|10/03/2020|Ownership with Asylum Routing Team Croydon, then Glasgow & Belfast Asylum Intake Team. The Applicant applies for Section 95 support, denied due to funds and property in Nigeria.|
|11/03/2020|Safeguarding referral sent for pain in leg and back, walking with a limp.|
|18/03/2020|Access to support granted as the applicant explains no access to Nigerian bank or property in order to sell it.|
|20/03/2020|Representative added – Phoenix Law Representatives request a 4 week extension for PIQ. Extension granted, blank form provided.|
|30/03/2020|Applicant moves into asylum support accommodation.|
|06/05/2020|6 week extension for PIQ agreed, until 17/06/2020.|


-----

|Col1|Page 3 of 19 JR247's Application to Apply for Judicial Review [2024] NIKB 72|
|---|---|
|24/06/2020|Email sent to Phoenix law to chase PIQ return.|
|26/06/2020|Applicant's representative Phoenix Law requests further extension as cannot see clients. Extension agreed until 29/07/2020.|
|09/07/2020|Pre-interview triage by Belfast Asylum Team. Rated as Amber as PIQ outstanding.|
|13/08/2020|Email sent to rep to chase PIQ, requesting return date of 28/08/2020.|
|23/09/2020|Email from rep stating applicant has not received ARC card. Reply sent with instructions for reporting lost ARC card.|
|24/09/2020|PIQ, statement and photos uploaded to Home Office storage platform – notes indicate had been received 27/07/2020 but not actioned.|
|28/09/2020|Email from rep requesting substantive interview date and stating if no response within 7 days then will raise pre- action protocol.|
|08/10/2020|Asylum delay letter issued to Phoenix Law/applicant's rep.|
|09/10/2020|Replacement ARC request through correct channel, new card issued.|
|21/10/2020|Notification sent for substantive interview booked for 29/10/2020 at 9.00am.|
|29/10/2020|Substantive interview complete. Paper copy of transcript provided to rep. Medical consent form saved to file. The Applicant submitted news articles, added to file. Safeguarding referral sent, medical consent form attached. Post-interview triage sheet sent to team leader, request sent to workflow for interview audio to be sent to legal rep. NRM referral discussed and consented to at interview, referral made.|
|30/10/2020|NRM line opened on SSHD's system.|
|04/11/2020|NRM Positive Reasonable Grounds decision made.|
|05/11/2020|Reps requesting interview audio.|
|11/11/2020|Reps email to state The Applicant has not received ARC card. Reply sent with instruction for reporting lost ARC card.|
|27/11/2020|Email sent to reps with interview audio attached.|
|30/11/2020|Replacement ARC requested through correct channel – previous delivery report notes delivery was unsuccessful, address is confirmed as correct, new card issued.|
|01/12/2020|Case is assigned to Decision Maker at Glasgow Asylum Team.|
|03/12/2020|Case returned to Performance team, NRM's Conclusive Grounds (CG) decision is outstanding and therefore a barrier to Asylum decision.|
|01/07/2021|Reps email to state the applicant has still not received ARC. Reply sent to explain first was undelivered due to property being high-risk as an HMO, second request for ARC was not reported as failed, requested reps to again submit through proper channels and address will be changed to reps address for this delivery.|
|08/07/2021|ARC request received, issued to rep's address.|
|22/07/2021|Reporting event conducted. Claimant accompanied by support worker from women's aid|
|02/08/2021|Ownership changes to Asylum National Workflow, National Case Progression Team, due to current triage status (pending NRM CG).|
|02/09/2021|National Case Progression Team - Barrier Review completed. Email sent to NRM for update. Next review scheduled for 26/11/2021.|
|18/09/2021|Belfast Case Progression review – NRM outstanding.|
|13/10/2021|Reported lost ARC received through proper channels, replacement requested. NRM Conclusive Grounds (CG) decision made.|
|21/10/2021|NRM CG decision letter uploaded to Home Office Storage Platform.|
|15/12/2021|Mitigating Circumstances interview complete at Reporting Event – minor information collected: medical, address, changes to family in UK.|
|08/01/2022|Appointment with NRM Hub.|
|09/03/2022|Mitigating Circumstances interview complete at Reporting Event.|
|08/06/2022|Mitigating Circumstances interview complete at Reporting Event.|
|10/06/2022|Email from reps requesting timeline for decision and advising they will take legal action if no response within 7 days. Response sent.|


09/09/2022 Email from reps requesting decision 'this month' as delay unreasonable and impacting The


-----

|Col1|Page 4 of 19 JR247's Application to Apply for Judicial Review [2024] NIKB 72|
|---|---|
||Applicant's mental health.|
|11/10/2022|PAP response sent by email from Lit Ops, advising that timescales cannot be provided at present.|
|07/11/2022|JR petition received.|
|14/11/2022|Asylum Mersey respond to Lit Ops advising, barring complexities, decision target date is 14/02/2023.|
|22/11/2022|Mersey Barrier Review complete. Change of circumstances form requested.|
|03/12/2022|Rep's email with completed change of circumstances form. Mersey order file for scanning.|
|08/12/2022|File received into Mersey, placed in hold for scanning.|
|08/01/2023|Mersey complete Triage. Case progressed to Decision Ready, assessed as Green.|
|15/01/2023|Mersey PAP/JR team email the decision-making unit stating target date is less than a month away so can case be allocated to a decision maker or reallocated to another decision-making unit to meet the target.|
|16/01/2023|Ownership with Newcastle Asylum Team, allocated to DM. Biometric Enrolment letter sent to the applicant.|
|17/01/2023|Lit Ops contact Newcastle. Original date proposed was 14/02 but was amended to 14/01. Newcastle took on case expecting deadline of 14/02 but agreed to prioritise case.|
|20/01/2023|Ownership DM changes, still with Newcastle. Asylum granted by Newcastle Asylum Team, expiring 19/01/2028. Email sent to Newcastle Admin team requesting paperwork issued same day due to JR deadline.|
|24/01/2023|Biometric Residence Permit requested to Phoenix Law address.|



**[12] Against this background the Applicant's case is that the Respondent has a legal duty to avoid delay in making**
asylum decisions and that such delay has resulted in a breach of her art 8 rights. The legal issues will be discussed
further below.

**[13] Turning to the facts of this case, the Applicant says there has been an initial unexplained delay between 27**
July 2020 and 24 September 2020, that is the date between which the PIQ was lodged and actually uploaded to the
Home Office's storage platform.

**[14] The Applicant then complains about the delay between 29 October 2020, when the substantive interview took**
place and 21 October 2021 when the NRM decision was made. The Applicant says that the Respondent was wrong
to delay assessing the substantive claim pending the NRM decision and that it should have adopted a parallel
process in respect of the applications. She also says that the NRM decision in itself was delayed excessively.
Finally, the Applicant complains of the delay between 21 October 2021 and the final decision of 20 January 2023.

**[15] It is the Applicant's case that properly analysed no substantive steps were taken to assess the claim after 29**
October 2020 until 21 October 2021. Thereafter, apart from a “mitigating circumstances interview” which was
completed on 15 December 2021 there is a further culpable delay until the final decision was made in January
2023. The Respondent argues that it is plain from the history set out in Mr Elliott's affidavit that this was an active
and live claim. At all times the Home Office maintained contact with the Applicant's solicitor and ensured that the
Applicant received the benefits to which she was entitled pending a final decision. She says it was entirely
reasonable to await the decision from the NRM before finally deciding the claim. After receipt of the NRM decision
there were three separate “mitigating circumstances” interviews, on 15 December 2021, 9 March 2022 and 8 June
2022, all of which were relevant to making the complex decision in this case.

**[16] That said, it is clear that there were periods during which no apparent progress was made in this claim. The**
Applicant accepts that there was an initial delay between 5 March 2020 and the lodging of the PIQ on 22 July 2020,
which was due to difficulties encountered by the Applicant's solicitors arising from the Covid-19 pandemic. This was
entirely reasonable and has been explained by Ms Marmion (the Applicant's solicitor) in her affidavit. That said, the
court recognises that the restrictions imposed under the Covid-19 restrictions also had an impact on the
Respondent and her abilities to make a decision.


-----

**[17] The court asks the question “What were the reasons for any delays?”**

**[18] In this regard, Mr Elliott avers that:**

“5. The court will no doubt be aware of the backdrop of pressure on the SSHD in terms of the significant
increase in asylum claims as well as victims of modern slavery in the last 10 years. By way of example the
National Referral Mechanism publishes its statistics on a quarterly basis and updates its annual figures at
**_Modern Slavery: National Referral Mechanism and Duty to Notify statistics UK, Quarter 4 2022 – October to_**
December - GOV.UK (www.gov.uk). As is evident from the statistic such applications reports have steadily
increased since 2004. The most recent update for Quarter 4 2022 October to December noted:

**Key results**

there were 4,418 potential victims of **_modern slavery referred to the Home Office in quarter 4 2022,_**
representing a 4% decrease compared to the preceding quarter (4,581) and a 33% increase from quarter 4
2021 (3,331)

the number of referrals received this quarter is the second-highest since the NRM began in 2009

around three-quarters of referrals (78%; 3,453) were sent to the Single Competent Authority (SCA) for
consideration and the rest (22%; 965) were sent to the Immigration Enforcement Competent Authority (IECA)

Albanian nationals were the most commonly referred nationality, followed by UK nationals which recorded their
highest quarterly number since the NRM began

4,548 reasonable grounds and 2,103 conclusive grounds decisions were issued this quarter; of these, 85% of
reasonable grounds and 84% of conclusive grounds decisions were positive

the Home Office received 1,307 reports of adult potential victims via the DtN process, the highest quarterly
number since the DtN began.”

**[19] Whilst the court has received the full chronology in relation to this case, it would have been helpful to obtain**
more detailed figures and explanations from the Respondent as to the difficulties encountered in respect of delays
in determining asylum claims. At one stage it was suggested in the correspondence that this was due to putting in
[place mechanisms to deal with the new system to be implemented as a result of the Nationality and Borders Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)
_[2022 which came into force on 22 June 2022, the effect of which was to create different statuses of asylum](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_
seekers. However, this has not featured in the Respondent's affidavit evidence or in the submissions made by Ms
Murnaghan in seeking to justify any delays.

**[20] Ms Marmion has provided the court with some useful information in relation to delays in decision making in**
asylum seeking decisions. She refers to a paper published by the Migration Observatory at Oxford University
published on 5 April 2023 dealing with the UK's asylum backlog. This paper demonstrated that there has been a
significant increase in the backlog of asylum claims. It is stated in the paper that:

“A decline in the number of decisions made on asylum claims has been an important driver of backlog growth.”

**[21] This paper provides a valuable insight into the backlog of asylum claims. The points include:**

- On 31 December 2022, there were around 132,000 asylum applications awaiting an initial decision in the UK
comprising around 161,000 people.

- At the end of 2021, the UK had the second largest asylum backlog in Europe after Germany.

- Asylum applications increased in 2021/2022, which added to an existing backlog.

- A decline in the number of decisions made on asylum claims has been an important driver of backlog.


-----

- The time it takes for an asylum application to receive an initial Home Office decision has increased substantially
in recent years.

- The decline in casework or decision-making has no definitive explanation, but plausible reasons include
administrative issues and policy changes.

**[22] The paper includes the following commentary:**

“The increase in asylum applications in recent years thus explains only part of the backlog. Another part of the
explanation is that fewer decisions have been made by asylum caseworkers despite a growing number of staff.
For example, if the Home Office had maintained the same number of decisions it was making in 2016 (around
31,000 per year) in the six years ending September 2022, the backlog would be almost 37,000 lower by 30
September 2022 – or 32% smaller. If, over the same period it had increased decision-making capacity to
40,000 decisions per year (which is roughly the number of applications received in 2015) the backlog would be
about 82,000 lower and stand at 35,400 rather than 117,400 – a 70% decrease.

If caseworkers take longer to make decisions that does not necessarily mean that they are performing less
well. Decisions that are made more quickly could be less accurate. As explained in the next section a variety of
reasons explains lower decision-making.

Even without longstanding problems processing sufficient numbers of applications, there would always have
been a spike in the backlog in the year ending September 2022 due to the above average increase in asylum
applications that year. However, roughly half (48%) of the backlog built up before July 2021, during a period
when asylum applications were not unusually high by recent UK standards.”

**[23] The report notes that a 2021 inspection of the UK's asylum casework by the independent Chief Inspector of**
Borders and Immigration highlighted a number of issues in the UK asylum processing. These included inadequate
training for decision-makers, the reliance on excel spreadsheets, low morale and relatively high staff turnover.

**[24] Reference was also made to Covid-19 where the paper commented:**

“While decisions in decision-making preceded the pandemic, the Immigration Inspector also found in his report
on asylum casework that Covid-19 caused an additional decline in caseworker productivity in 2020, resulting
from fewer face to face interviews with asylum applicants in 2020, fewer initial decisions were made (14,304)
than in any calendar year since 1991.

A low average number of decisions per caseworker continued in 2021 and 2022. It is not clear to what extent
this continued, low rate of decisions is a hangover from Covid and its associated policies.”

**[25] The paper also referred to the new rules on admissibility introduced in January 2021 aimed to remove asylum**
seekers from the UK where the Home Office believes they could and should have applied for asylum in another
country and also the suspension of the detained fast tracked process.

**_Delay/the legal framework_**

**[26] The Applicant submits firstly that the delay in determining her asylum claim was a violation of reg 333A of the**
Immigration Rules and/or Home Office policy and secondly that the delay violated her rights under art 8 of the
[ECHR protected by the Human Rights Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

**[27] The Immigration Rules governing asylum applications are made pursuant to** _[s 1(4) of the Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y0R5-00000-00&context=1519360)_
1971. Rule 333A of the Immigration Rules (“Rule 333A”), states that:

“The Secretary of State shall ensure that a decision is taken on each application for asylum as soon as
possible, without prejudice to an adequate and complete examination.

Where a decision on an application for asylum has not been taken within:


-----

a six months of the date it was recorded; or

b without any revised timeframe notified to an applicant during or after the initial six-month period in
accordance with this paragraph, and

c where the applicant has made a specific written request for an update,

the Secretary of State shall inform the applicant of the delay and provide information on the timeframe within
which the decision on their application is to be expected. The provision of such information shall not oblige the
Secretary of State to take a decision within the expected timeframe.”

**[28] Rule 333A gave effect to Council Directive 2005/85/EC (“the Procedures Directive”) on minimum standards on**
procedures in Member States for granting and withdrawing refugee status.

**[29] Article 23 is entitled “Examination procedures” and provides:**

“1. Member States shall process applications for asylum in an examination procedure in accordance with the
basic principles and guarantees of Chapter II.

2. Member States shall ensure that such a procedure is concluded as soon as possible, without prejudice to an
adequate and complete examination.

3. Member States shall ensure that, where a decision cannot be taken within six months, the applicant
concerned shall either:

a be informed of the delay; or

b receive, upon his/her request, information on the time-frame within which the decision on his/her application
is to be expected. Such information shall not constitute an obligation for the Member State towards the
applicant concerned to take a decision within that time-frame.

4. Member States may prioritise or accelerate any examination in accordance with the basic principles and
guarantees of Chapter II, including where the application is likely to be well-founded or where the applicant has
special needs.”

**[30] Rule 333A is reflected in the Respondent's own service standard obligations for adults which provides in**
relation to asylum applications that after the screening exercise “you will usually get a decision on your application
within six months.”

**[31] In similar vein, the government's information booklet for asylum applications provides at s 4:**

“We will aim to make a decision on your claim within six months, but this is not always possible and there may
sometimes be delays. We will, however, seek to prioritise claims based on individual circumstances.”

**[32] Plainly, r 333A does not impose specific time limits within which the Respondent must reach a decision on an**
asylum case. The Respondent's policy clearly permits a flexible approach permitting it to carry out “an adequate
and complete examination” of each asylum claim.

**[33] In his submissions the focus of Mr Southey's arguments was on an alleged breach of the Applicant's rights**
under art 8 ECHR which entitled her to an award of damages.

**_Does the applicant's claim come within the ambit/scope of Article_** **_8?_**

**[34] In answering this question the court reminds itself of the “Ullah” principle, reaffirmed by the Supreme Court in**
_Regina (AB) v Secretary of State for Justice [2022] AC 487. There, the court was dealing with an alleged breach of_
art 3 of the ECHR in the context of a young offender being placed in “single unlock” within the prison. Lord Reed,
delivering the judgment of the court said:


-----

“56. An important additional rationale, which follows from the objective of the Human Rights Act as explained in
_Ullah and_ _Denbigh High School, was identified by Lord Brown of Eaton-under-Heywood in_ _R (Al-Skeini) v_
_Secretary of State for Defence (The Redress Trust intervening) [2007] UKHL 26; [2008] AC 153, para [106]._
Referring to Lord Bingham's statement that domestic courts should keep pace with the Strasbourg
jurisprudence, 'no more, but certainly no less', he commented:

'I would respectfully suggest that last sentence could as well have ended: 'no less, but certainly no more.'
There seems to me, indeed, a greater danger in the national court construing the Convention too generously in
favour of an applicant than in construing it too narrowly. In the former event the mistake will necessarily stand:
the member state cannot itself go to Strasbourg to have it corrected; in the latter event, however, where
Convention rights have been denied by too narrow a construction, the aggrieved individual _can have the_
decision corrected in Strasbourg.'”

57. As Lord Brown explained, the intended aim of the Human Rights Act - to enable the rights and remedies
available in Strasbourg also to be asserted and enforced by domestic courts - is particularly at risk of being
undermined if domestic courts take the protection of Convention rights further than they can be fully confident
that the European court would go. If domestic courts take a conservative approach, it is always open to the
person concerned to make an application to the European court. If it is persuaded to modify its existing
approach, then the individual will obtain a remedy, and the domestic courts are likely to follow the new
approach when the issue next comes before them. But if domestic courts go further than they can be fully
confident that the European court would go, and the European court would not in fact go so far, then the public
authority involved has no right to apply to Strasbourg, and the error made by the domestic courts will remain
uncorrected.

58. The approach to this issue laid down in _Ullah,_ _Denbigh High School and_ _Al-Skeini has been repeatedly_
endorsed at the highest level. For example, in _R (Animal Defenders International) v Secretary of State for_
_Culture, Media and Sport_ _[2008] UKHL 15; [2008] AC 1312, Baroness Hale of Richmond stated at para [53]:_

['The Human Rights Act 1998 gives effect to the Convention rights in our domestic law. To that extent they are](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
domestic rights for which domestic remedies are prescribed: In Re McKerr [2004] 1 WLR 807. But the rights
are those defined in the Convention, the correct interpretation of which lies ultimately with Strasbourg: R (Ullah)
_v Special Adjudicator [2004] 2 AC 323, para [20]. Our task is to keep pace with the Strasbourg jurisprudence as_
it develops over time, no more and no less.'”

**[35] Bearing this in mind, I turn to the authorities relied upon by the parties in this application.**

**[36] Although Mr Southey sought to extract general principles from cases concerning delay in the context of**
breaches of art 5, I do not consider that they assist the court in deciding this application. In Noorkoiv v Secretary of
_State for the Home Department [2002] 1 WLR 3284the Court of Appeal was dealing with delays in decisions of the_
Parole Board which had the effect of extending the Applicant's period of detention.

**[37] The Court of Appeal held that it was the obligation of the State to organise its legal system to enable it to**
comply with Convention requirements.

**[38] The court “… drew a distinction between general faults in or under funding of the system which provide no**
defence even in relation to art 6(1), and 'the practical realities of litigious life in a reasonably well organised legal
system.'”

**[39] The court rejected the Respondent's argument that it could rely on a lack of resources to excuse delays which**
would otherwise be in breach of art 5(4) of the Convention.

**[40] In** _James v United Kingdom [2013] 56 EHRR 12, the ECtHR was critical of the failure to anticipate the_
demands arising from fresh legislation when finding that a lack of resources violated art 5(4).


-----

**[41] In the court's view there is a fundamental difference between the obligations imposed on the State under art 5**
in respect of delays affecting a person's liberty and delays allegedly affecting a citizen's art 8 rights. I do not
consider that an analogy between a period of delay in deciding an asylum application and the manner in which
authorities approach cases relating to detention and the obligations under art 5 an apt one.

**[42] Turning then to the jurisprudence on art 8 as per Pretty v United Kingdom [2002] 35 EHRR 1 at [61] art 8 is “a**
broad term not susceptible to exhaustive definition.”

**_Article 8 legal framework_**

**[43] The question of whether a person's right to respect for their private life, guaranteed by art 8(1) ECHR has**
been, or may be, infringed is intrinsically fact and context sensitive.

**[[44] In Said v Secretary of State for the Home Department [2023] NICA 49, the Court of Appeal considered art 8](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:69RK-RSW3-RS6B-030V-00000-00&context=1519360)**
ECHR in the context of an applicant who had lodged further submissions under the Immigration Rules, having had
his asylum claim refused. His complaint related to the loss of his Application Registration Card (“ARC”) which is a
document certifying his status as an asylum applicant or testifying that he is allowed to remain in the United
Kingdom while an asylum application is pending.

**[45] The court was critical of the evidence adduced by the Applicant to establish an alleged infringement of his art**
8 rights.

**[46] On the issue of the ambit of art 8 the court observed as follows:**

“[52] We remind ourselves of the decision of the House of Lords in _R (Countryside Alliance) v HM Attorney_
_General and Another_ _[2007] UKHL 52 and Lord Bingham's concise exposition of the private life element of_
Article 8(1) at para [10]:

'… the purpose of the article is in my view clear. It is to protect the individual against intrusion by agents of the
state, unless for good reason, into the private sphere within which individuals expect to be left alone to conduct
their personal affairs and live their personal lives as they choose.'

The House decided unanimously that the activity of fox hunting did not fall within the scope of this Convention
right inter alia because of its public character and the lack of analogy with any of the categories summarised in
para [53] infra. We refer also to the analysis of Lord Hope at para [54] and that of Lord Rodger of Earlsferry at

paras [90]‑[109].

Baroness Hale, for her part, evaluated article 8 at para [116] thus:

'Article 8, it seems to me, reflects two separate but related fundamental values. One is the inviolability of the
home and personal communications from official snooping, entry and interference without a very good reason.
It protects a private space, whether in a building, or through the post, the telephone lines, the airwaves or the
ether, within which people can both be themselves and communicate privately with one another. The other is
the inviolability of a different kind of space, the personal and psychological space within which each individual
develops his or her own sense of self and relationships with other people. This is fundamentally what families
are for and why democracies value family life so highly. Families are subversive. They nurture individuality and
difference. One of the first things a totalitarian regime tries to do is to distance the young from the individuality
of their own families and indoctrinate them in the dominant view. Article 8 protects the private space, both
physical and psychological, within which individuals can develop and relate to others around them. But that
falls some way short of protecting everything they might want to do even in that private space; and it certainly
does not protect things that they can only do by leaving it and engaging in a very public gathering and activity.'

[53] A detailed essay on article 8 jurisprudence is unnecessary. It suffices to say that the supermarket incident
of which the appellant complains and its asserted impact on him are remote from the themes and concepts
which have habitually featured in the article 8 jurisprudence: the person's inner circle; one's inner sanctum; how


-----

to live one's personal life; establishing and developing relationships with others; freedom from unjustified State
intrusion; unjustified prohibitions on working; protection of the physical and moral integrity of the person; one's
personal sexuality; personal identity; and social life. This is not designed to be an exhaustive list. Furthermore,
this court is mindful of the elasticity in the concept of respect for one's private life and the potential for
expansion of established categories. None of this points in the direction of any conclusion other than that article
8 ECHR is inapplicable.”

**[47] In Regina (MK) (Iran) v Secretary of State for the Home Department [2010] 1 WLR 2059, the Court of Appeal**
considered a delay in the determination of an asylum claim.

**[48] In that case the Claimant entered the United Kingdom from Iran via Greece, in September 2004 and claimed**
asylum. Since the Greek authorities accepted that under Council Regulation (EC) No:343/2003 they were
responsible for determining the claim, the Secretary of State directed the Claimant's removal to Greece. The
Claimant was subsequently assessed to be a minor and, in April 2005, the Secretary of State accepted that since
the Claimant was an unaccompanied child, he had responsibility under the Regulation for determining the claim.
Nothing of substance was done by the Home Office in 2005 to progress the claim, during which time the Claimant
[was detained for two months under the Mental Health Act 1983. In January 2006, the Claimant's solicitors wrote to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y0F8-00000-00&context=1519360)
the Secretary of State alleging that the delay in processing the claim was exacerbating the Claimant's mental health
problems. In October 2007, the claim still not having been determined, the Claimant sought judicial review of the
Secretary of State's refusal or failure to determine his claim within a reasonable period.

**[49] The Claimant argued that he had a right to a hearing within a reasonable time and that his claim amounted to**
a “civil right” which he was entitled to have determined within a reasonable time, pursuant to art 6 of the
Convention.

**[50] The Claimant failed. Although the claim was not based on an alleged infringement of art 8 it might be thought**
that the Applicant MK had suffered more than the Applicant in this case. The approach of the court as explained by
Carnwath LJ is instructive:

“Illegality

34. It was not in dispute that, at least under domestic law, the Secretary of State was under a public law duty to
decide the asylum application within a reasonable time. Both parties, as I understood them, accepted what I
said in Home Secretary v S _[2007] EWCA Civ 546 para [51]:_

'The Act does not lay down specific time-limits for the handling of asylum applications. Delay may work in
different ways for different groups: advantageous for some, disadvantageous for others. No doubt it is implicit
in the statute that applications should be dealt with within 'a reasonable time.' That says little in itself. It is a
flexible concept, allowing scope for variation depending not only on the volume of applications and available
resources to deal with them, but also on differences in the circumstances and needs of different groups of
asylum seekers. But (as was recognised by the White Paper) in resolving such competing demands fairness
and consistency are also vital considerations.'”

**[51] The question of delay in the context of immigration decisions had been referred to in some of our domestic**
decisions although none are directly on point.

**[52] A case frequently relied upon by the Respondents in rebutting allegations of delay is the decision of Mr Justice**
Collins in the case of FH and others, R (On the application of) v Secretary of State for the Home Department [2007]
EWHC 1571. That case concerned ten applications which were heard together. The Applicants were persons who
had their initial claims refused and who had brought fresh claims based upon further evidence which were said to
justify a fresh consideration.

**[53] The delays ranged from two to three years. No decisions had been made on the fresh claims. Two of the**
cases were regarded as exceptional and did not require adjudication from the court. The outstanding claims were
dismissed.


-----

**[54] In his judgment, Mr Justice Collins accepted that there was an obligation on the Secretary of State to**
determine applications within “a reasonable time.” He referred to the judgment of Carnwath LJ quoted above.

**[55] He set out his approach at para [11] as follows:**

“11. As was emphasised by Lord Bingham, the question was whether delay produced a breach of Article 6(1).
Here the question is whether the delay was unlawful. It can only be regarded as unlawful if it fails the
_Wednesbury test and is shown to result from actions or inactions which can be regarded as irrational._
Accordingly, I do not think that the approach should be different from that indicated as appropriate in
considering an alleged breach of the reasonable time requirement in Article 6(1). What may be regarded as
undesirable or a failure to reach the best standards is not unlawful. Resources can be taken into account in
considering whether a decision has been made within a reasonable time, but (assuming the threshold has
been crossed) the defendant must produce some material to show that the manner in which he has decided to
deal with the relevant claims and the resources put into the exercise are reasonable. That does not mean that
the court should determine for itself whether a different and perhaps better approach might have existed. That
is not the court's function. But the court can and must consider whether what has produced the delay has
resulted from a rational system. If unacceptable delays have resulted, they cannot be excused by a claim that
sufficient resources were not available. But in deciding whether the delays are unacceptable, the court must
recognise that resources are not infinite and that it is for the defendant and not for the court to determine how
those resources should be applied to fund the various matters for which he is responsible.”

**[56] In his conclusion, he held at para [30]:**

“30. It follows from this judgment that claims such as these based on delay are unlikely, save in very
exceptional circumstances, to succeed and are likely to be regarded as unarguable. It is only if the delay is so
excessive as to be regarded as manifestly unreasonable and to fall outside any proper application of the policy
or if the claimant is suffering some particular detriment which the Home Office has failed to alleviate that a
claim might be entertained by the court.”

**[57] As Mr Southey points out, this case was determined on the basis of Wednesbury irrationality although Collins**
J indicated that this approach would not be different from that when considering alleged breach of the reasonable
time required in art 6(1) of the Convention.

**[58] In** _EB (Kosovo) v Secretary of State for the Home Department_ [2009] 1 AC 1159, the House of Lords
considered the case of an applicant who entered the United Kingdom in September 1999 aged 13. He claimed
asylum four days later. Following delay on the part of the Home Department, which the Secretary of State accepted
had not been reasonable, the Applicant's claim was refused in April 2004, and a letter was sent to him informing
him of the Secretary of State's intention to remove him. Had his application been decided before his 18th birthday
on 10 December 2003, when he had ceased to be an unaccompanied minor, he would probably have been granted
exceptional leave to remain. He lived with his uncle, and his girlfriend had moved in with them. He and she had
expressed an intention to remain together and marry. He resisted removal in reliance on his right under art 8 of the
Convention.

**[59] The Claimant was successful. In dealing with the question of delay, Lord Bingham dealt with the matter as**
follows:

“Delay

13. In Strbac v Secretary of State for the Home Department _[2005] EWCA Civ 848, [2005] Imm AR 504, para_

[25], counsel for the applicant was understood to contend, in effect, that if the decision on an application for
leave to enter or remain was made after the expiry of an unreasonable period of time, and if the application
would probably have met with success, or a greater chance of success, if it had been decided within a
reasonable time, and if the applicant had in the meantime established a family life in this country, he should be
treated when the decision is ultimately made as if the decision had been made at that earlier time. For reasons
given by Laws LJ, the Court of Appeal rejected this submission, for which it held Shala v Secretary of State for


-----

_[the Home Department [2003] EWCA Civ 233, [2003] INLR 349 to be no authority. While I consider that Shala](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JT01-DYBP-N2VM-00000-00&context=1519360)_
was correctly decided on its facts, I am satisfied that the Court of Appeal was right to reject this submission. As
Mr Sales QC for the respondent pointed out, there is no specified period within which, or at which, an
immigration decision must be made; the facts, and with them government policy, may change over a period, as

they did here; and the duty of the decision‑maker is to have regard to the facts, and any policy in force, when

the decision is made. Mr Drabble QC, for the appellant, did not make this submission, and he was right not to
do so.

14. It does not, however, follow that delay in the decision-making process is necessarily irrelevant to the
decision. It may, depending on the facts, be relevant in any one of three ways. First, the applicant may during
the period of any delay develop closer personal and social ties and establish deeper roots in the community
than he could have shown earlier. The longer the period of the delay, the likelier this is to be true. To the extent
that it is true, the applicant's claim under article 8 will necessarily be strengthened. It is unnecessary to
elaborate this point since the respondent accepts it.

15. Delay may be relevant in a second, less obvious, way. An immigrant without leave to enter or remain is in a
very precarious situation, liable to be removed at any time. Any relationship into which such an applicant enters
is likely to be, initially, tentative, being entered into under the shadow of severance by administrative order.
This is the more true where the other party to the relationship is aware of the applicant's precarious position.
This has been treated as relevant to the quality of the relationship. …

16. Delay may be relevant, thirdly, in reducing the weight otherwise to be accorded to the requirements of firm
and fair immigration control, if the delay is shown to be the result of a dysfunctional system which yields
unpredictable, inconsistent and unfair outcomes. …”

**[60] The court determined that the Tribunal which had originally refused the Applicant's claim had not adequately**
addressed the human problems raised by the Applicant's appeals and the matter be remitted to the Tribunal for a
fresh hearing at which, when considering the overall proportionality of ordering his removal, the relevance of the
delay in the resolution of his claim and the manner of its handling should be considered. This case is authority for
the proposition that delay in the immigration process might engage art 8. It can be seen from the facts of that case
that the Applicant was able to point to specific factors relating to his family and private life which had been affected
by delay and which resulted in an order for his removal from the UK. Importantly had the application been
determined earlier the application would probably have met with success.

**[61] An important case is that of BAC v Greece, App No: 11981-15; [2018] 67 EHRR 27. There, the ECtHR was**
considering a claim based on a delay in an asylum decision.

**[62] The facts were that the Applicant was a Turkish national who fled to Greece in 2002. Upon arriving in Greece,**
he made a request for asylum, citing evidence that he had suffered torture in Turkey. Despite the Greek Advisory
Board on Asylum issuing a favourable opinion in respect of the Applicant's claim for asylum on 29 January 2003,
and contrary to the established procedure according to which a decision ought to be made within 24 hours, the
Minister for Public Order failed to make a decision on whether the Applicant ought to be granted international
protection. No such decision had been made by the time the Applicant had communicated his complaint to the
court, twelve years after the Advisory Board's favourable opinion, nor had a decision been taken when the court
considered the matter.

**[63] In the absence of any decision by the Minister between 2003 and 2015, the Applicant was permitted to remain**
in Greece with “tolerated status” only.

**[64] Importantly, the Applicant established that he was unable to obtain gainful employment, but rather worked in**
construction without the requisite permit. He indicated that he had wished to enrol in university but was unable to do
so. He had also been unable to open a bank account or obtain a tax reference number, which were pre-conditions
for engaging in gainful employment. Nor had he even been able to secure a driving licence. As regards his private


-----

life, his cohabitation with his wife had not become legally or materially possible until 2008 on the basis that she had
obtained a short-term work permit in Greece, rather than in accordance with the legal provision on family reunion.

**[65] In this regard, the court held that it was clear that in this situation the uncertainty experienced by the Applicant**
as regards his status far surpassed that of an applicant awaiting the completion, within a reasonable time, of his or
her asylum procedure. (My underlining).

**[66] In its judgment the court said as follows:**

“36. The court emphasises that it has affirmed on many occasions that under Article 8 of the Convention the
positive obligation of the State inherent in an effective respect for private life may involve the adoption of an
effective and accessible procedure designed to secure respect for private life, and in particular the introduction
of a statutory framework setting up an enforceable judicial mechanism to protect individuals' rights and, if
necessary, of appropriate specific measures. Even though the boundaries between the State's positive and
negative obligations under the Convention do not lend themselves to precise definition, the applicable
principles are nonetheless similar. (My underlining)

37. Those positive obligations also include the competent authorities' duty to examine the person's asylum

request promptly, in order to ensure that his or her situation of insecurity and uncertainty is as short‑lived as

possible.

38. The court first of all draws a distinction between the present case and that of ME v Sweden, in which the
applicant complained, _inter alia, about the anxiety, uncertainty and tension caused by the authorities' initial_
decision to return him to Libya. The court struck the case out of the list (Article 37(1)(b) of the Convention)
because the authorities had in the meantime issued him with a permanent residence permit.”

**[67] At this stage I interject that** _ME assists the Respondent in this case because it indicates that the European_
Courts will not entertain a claim based on delay if a positive decision has, in fact, been made after the initiation of
proceedings. ME concerned a challenge to a decision to remove the Applicant who was relying on a breach of his
art 3 ECHR rights.

**[68] There, the court determined that:**

“32. The court observes at the outset that, according to its established case-law in cases concerning the
expulsion of an applicant from a respondent state, once the applicant no longer risks being expelled from that
state, it considers the case to have been resolved and strikes it out of its list of cases whether or not the
applicant agrees.”

At para [36] the court said:

“36. Contrary to what the applicant suggests, in examining this question the court does not need to inquire
retrospectively into whether a real risk engaging the State's responsibility under article 3 of the Convention
existed when the Swedish immigration authorities refused his asylum request or when the Chamber adopted its
judgment. These are historical facts but they do not shed light on the applicant's current situation, in which the
impugned risk has been removed, this latter circumstance is decisive for the court's finding that the matter has
been resolved …”

**[69] Ms Murnaghan points out that if the court took such a view in the context of an art 3 case, then it is difficult to**
see how it could come to a different conclusion in the context of an art 8 case such as this when a positive decision
has been made in favour of the Applicant.

**[70] In any event, returning to BAC the court continued at para [39]:**

“39. Secondly, the court notes that the applicant's situation is also different from one where the authorities
refused to grant a residence permit to applicants who were illegally settled in the host country and were hoping


-----

to confront those authorities with family life as a fait accompli (see the case-law cited in the _Jeunesse v the_
_Netherlands judgment). In the present case, the issue at stake is the failure of the Minister for Public Order, for_
twelve years, to decide on the applicant's request for asylum, even though the Advisory Board on Asylum had
issued a favourable opinion and the Greek judicial authorities, including the Court of Cassation, had rejected a
request for extradition from the Turkish authorities. It is clear that in this situation the uncertainty experienced
by the applicant as regards his status far surpassed that of an applicant awaiting the completion, within a
reasonable time, of his or her asylum procedure.

40. In the instance case, the court considers that the alleged violation of Article 8 of the Convention also
originated, not in any removal or expulsion order, but in the situation of insecurity and uncertainty experienced
by the applicant over a long period, that is to say from 21 March 2002 – when he lodged his appeal against the
decision to reject his asylum application – to the date of delivery of the present judgment.”

**[71] The court then went on to look at the actual prejudice and difficulties encountered by the Applicant arising from**
the delay. The court went on to conclude:

“45. The court finds unjustified the failure of the Minister for Public Order to decide on the applicant's asylum
request, for which no reasons had been given and which had continued for more than twelve years (and is still
ongoing), even though the domestic authorities had come down in favour of granting the applicant asylum and
had rejected the request for extradition submitted by the Turkish authorities.

46. Accordingly, the court holds that in the circumstances of the present case the competent authorities failed
in their positive obligation under Article 8 of the Convention to establish an effective and accessible procedure
to protect the right to private life by means of appropriate regulations to guarantee that the applicant's asylum
request is examined within a reasonable time in order to ensure that his situation of insecurity is as short-lived
as possible (see also paragraph [37] above). There has therefore been a violation of Article 8.”

**[72] The question of the obligation under art 8 in the immigration context was considered by the Court of Appeal in**
_R(FWF) v The Secretary of State for the Home Department [2021] 1 WLR 3781._

**[73] In that case, the court was considering asylum claims in the context of “take charge requests” pursuant to art**
21 of Parliament and Council Regulation (EU) No: 604/2013 – Dublin III Regulations. There, the court considered
the potential positive and negative obligations arising from art 8. Laing LJ in delivering the judgment of the court
said:

“144. The distinction between positive and negative obligation cases may be difficult to apply to borderline
cases, as the Supreme Court has recognised in many recent decisions, and as the Strasbourg Court
acknowledged in Osman v Denmark 61 EHRR 10. But wherever the line may be drawn, the facts of this case
are clearly some distance from it. Absent Dublin III, it could not be argued that by failing to admit Rs to the
United Kingdom, the Secretary of State was interfering with their article 8 rights, as they had no right to be in
the United Kingdom, and the Secretary of State was not responsible for the fact that they were in France and
their brother was in the United Kingdom, or for the fact that their brother, with whom they had never lived,
appears to be the only surviving and identifiable member of their family. I consider that this is a case in which, if
article 8 applied, it could only impose a positive obligation on the Secretary of State, that the 'in accordance
with the law' criterion would not apply to the discharge of that positive obligation, and that there is no
Strasbourg case which begins to suggest that family reunion preceded by the delay which occurred in this
case, could be a breach of any positive obligation. I accept the Secretary of State's submission that whether or
not the Secretary of State complied with any positive obligation depends on the overall outcome. If article 8
imposed any positive obligation on the Secretary of State in this case, he complied with it.

_If Rs can rely on article 8 in the context of Dublin III, did the delay in this case interfere with Rs' article 8 rights?_

145. I will assume that my answer to the previous question is wrong, that the Rs can rely on article 8 in this
context, and that the question is whether the delay in this case was an interference with the Rs' article 8 rights.
This question was considered by UTJ Blum in _KF (Application No: JR/16421/2019) (Unreported) 8 October_


-----

2019. The facts were similar to the facts in this case, except that in _KF, the delay in effecting the transfer_
breached the long-stop time limit in Dublin III. When the TCR was made in this case, the Rs had never lived
with NF. He left Afghanistan before they were born. Their contact with him, before they came to France, was
very limited. There was some delay before they were transferred from France to the United Kingdom, but it did
not exceed the Dublin III long-stop limit. They are now in the United Kingdom and living with NF. For reasons
which are similar to those given by UTJ Blum in KF, I do not consider that the delay in this case did interfere
with the Rs' article 8 rights. I consider that this conclusion is the only decision on this issue which a reasonable
judge could reach.”

**[74] Ms Murnaghan placed particular emphasis on the decision in Anufrijeva v Southwark LBC [2004] QB 1124.**

**[75] In that case the Claimants were seeking damages from their local council for breach of their right under art 8**
on the ground that the Respondent council had failed to discharge its duty to provide them with accommodation that
met the special needs of one member of the family.

**[76] The second claimant, an asylum seeker from Libya, arrived in the United Kingdom in February 2000 and was**
granted asylum in May 2001. He sought damages from the Respondent under s 8 of the 1998 Human Rights Act on
the ground that maladministration in the handling of his asylum application had caused delay and that he had
received inadequate financial support during much of that period. He had been caused psychiatric injury by the
stress of his experience which he alleged had infringed his right to private life under art 8.

**[77] A third claimant, an asylum seeker from Angola, arrived in the United Kingdom in 1996. In January 2001 he**
was granted asylum and he applied for permission for his family to join him but his family was not given permission
to enter the United Kingdom until November 2001. He claimed damages contending that much of the delay was
attributable to maladministration which had infringed his rights under art 8.

**[78] The Claimants were unsuccessful before the Court of Appeal.**

**[79] In the court's judgment, Lord Woolf CJ asked the question “In what circumstances does maladministration**
constitute a breach of art 8?

**[80] On this issue the court said:**

“44. We consider this question in relation to the particular type of maladministration that has taken place in
each of the three appeals before us the failure, in breach of duty, to provide the claimant with some benefit or
advantage to which the claimant was entitled under public law. Such failure may have come to an end before
the trial. If not, it is likely to be brought to an end as a consequence of a finding of breach of duty made at the
trial, so that what is likely to be in issue is the consequences of delay.

45. In so far as Article 8 imposes positive obligations, these are not absolute. Before inaction can amount to a
lack of respect for private and family life, there must be some ground for criticising the failure to act. There must
be an element of culpability. At the very least there must be knowledge that the claimant's private and family
life were at risk - see the approach of the ECtHR to the positive obligation in relation to Article 2 in Osman v
_United Kingdom (1998) 29 EHRR 245 and the discussion of Silber J in_ _N_ _[[2003] EWHC 207 (Admin) at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWK1-DYBP-N1NY-00000-00&context=1519360)_
paragraphs [126] to [148]. Where the domestic law of a State imposes positive obligations in relation to the
provision of welfare support, breach of those positive obligations of domestic law may suffice to provide the
element of culpability necessary to establish a breach of Article 8, provided that the impact on private or family
life is sufficiently serious and was foreseeable.

46. Where the complaint is that there has been culpable delay in the administrative processes necessary to
determine and to give effect to an Article 8 right, the approach of both the Strasbourg Court and the
Commission has been not to find an infringement of Article 8 unless substantial prejudice has been caused to
the applicant. In cases involving custody of children, procedural delay has been held to amount to a breach of
Article 8 because of the prejudice such delay can have on the ultimate decision - thus in H v United Kingdom
(1987) 10 EHRR 95 the court held at p122, para [89], Article 8 infringed by delay in the conduct of access and


-----

adoption proceedings because the proceedings 'lay within an area in which procedural delay may lead to a de
_facto determination of the matter in issue', which was precisely what had occurred._

…

47. We consider that there is sound sense in this approach at Strasbourg, particularly in cases where what is in
issue is the grant of some form of welfare support. The Strasbourg Court has rightly emphasised the need to
have regard to resources when considering the obligations imposed on a State by Article 8. The demands on
resources would be significantly increased if States were to be faced with claims for breaches of Article 8
simply on the ground of administrative delays. Maladministration of the type that we are considering will only
infringe Article 8 where the consequence is serious.”

**[81] On the question of whether damages should be awarded in established breaches of art 8, the court went on to**
say:

“75. We have indicated that a finding of a breach of a positive obligation under Article 8 to provide support will
be rare and will be likely to occur only where this impacts severely on family life. Where such a breach does
occur, it is unlikely that there will be any ready comparator to assist in the assessment of damages. There are
good reasons why, where the breach arises from maladministration, in those cases where an award of
damages is appropriate, the scale of such damages should be modest. The cost of supporting those in need
falls on society as a whole. Resources are limited and payments of substantial damages will deplete the
resources available for other needs of the public including primary care. If the impression is created that
asylum seekers whether genuine or not are profiting from their status, this could bring the Human Rights Act
into disrepute.

76. Similar considerations apply to delay in processing asylum claims or the procedure for admitting the
relatives of refugees. Those admitted are likely, at least initially, to require support. In view of the numbers
involved, some delay in the processing of asylum claims is inevitable and, at times, in the interest of the asylum
seekers themselves, the process is understandably lengthy. The factors that weigh against recognising
administrative delay as engaging Article 8 militate equally in favour of either no award or modest awards where
Article 8 is engaged.”

**[82] The court was clearly laying down a marker on potential claims based on breaches of art 8 rights in the**
context of delays in processing asylum claims. Thus, at para [80] the court said:

“80. The reality is that a claim for damages under the HRA in respect of maladministration, whether brought as
a free-standing claim or ancillary to a claim for other substantive relief, if pursued in court by adversarial
proceedings, is likely to cost substantially more to try than the amount of any damages that are likely to be
awarded. Furthermore, as we have made plain, there will often be no certainty that an entitlement to damages
will be established at all.”

**[83] The court went on to suggest as follows in relation to proceedings which includes a claim for damages for**
maladministration under the HRA:

“(i) The courts should look critically at any attempt to recover damages under the HRA for maladministration by
any procedure other than judicial review in the Administrative Court.

(ii) A claim for damages alone cannot be brought by judicial review (CPR or 54. 3(2)) but in this case the
proceedings should still be brought in the Administrative Court by an ordinary claim.

(iii) Before giving permission to apply for judicial review, the Administrative Court judge should require the
claimant to explain why it would not be more appropriate to use any available internal complaint procedure or
proceed by making a claim to the Parliamentary Commissioner for Administration or Local Government
Ombudsman at least in the first instance. …


-----

(iv) If there is a legitimate claim for other relief, permission should if appropriate be limited to that relief and
consideration given to deferring permission for the damages claim, adjourning or staying that claim until use
has been made of ADR, whether by a reference to a mediator or an ombudsman or otherwise, or remitting that
claim to a district judge or master if it cannot be dismissed summarily on grounds that in any event an award of
damages is not required to achieve just satisfaction.

(v) It is hoped that with the assistance of this judgment, in future claims that have to be determined by the
courts can be determined by the appropriate level of judge in a summary manner by the judge reading the
relevant evidence. The citing of more than three authorities should be justified and the hearing should be
limited to half a day except in exceptional circumstances.

(vi) There are no doubt other ways in which the proportionate resolution of this type of claim for damages can
be achieved. We encourage their use and do not intend to be prescriptive. What we want to avoid is any
repetition of what has happened in the court below in relation to each of these appeals and before us, when we
have been deluged with extensive written and oral arguments and citation from numerous lever arch files
crammed to overflowing with authorities. The exercise that has taken place may be justifiable on one occasion
but it will be difficult to justify again.”

**_Conclusion_**

**[84] From a review of the authorities, I conclude as per EB and BAC that delay in determining an asylum claim may**
result in a breach of an asylum seeker's art 8 rights. The obligation on the State is to provide a statutory framework
under which asylum claims are assessed and which provide an enforceable judicial mechanism to protect any
individual rights under that system. Such obligations include a duty to examine claims in a reasonable time.

**[85] What amounts to a reasonable time is fact specific. It is not for the courts to be prescriptive in terms of any**
time limits in this context. There is no specified period within which, or at which, an immigration decision must be
made.

**[86] What is important is that the system provides consistent and fair outcomes.**

**[87] Turning to the facts of this case, the Applicant focuses on the insecurity inherent in her situation and, in**
particular, the interference with her right to establish and develop relationships with other human beings and the
outside world. In truth, this is a general assertion, which could be made in respect of any asylum seeker awaiting a
decision. The Applicant points to no relevant or significant relationships, unlike _BAC, or the Applicant in_ _EB. The_
only specific issue she raises is that of her mental health.

**[88] True it is that mental stability has been held to fall within the scope of art 8. In** _Bensaid v United Kingdom_

[2001] 33 EHRR 10, the Applicant was an Algerian national who was a schizophrenic suffering from a psychotic
illness. He arrived in the UK as a visitor in 1989 and married a UK citizen in 1993. Since 1994 and 1995 he has
been receiving treatment for his medical condition. On the basis that the marriage had been one of convenience,
however, the Home Secretary decided to remove him. Relying on arts 3 and 8 of the Convention the Applicant
claimed that his proposed expulsion to Algeria placed him at risk of inhuman and degrading treatment and would
violate his right to respect for his private life. The court in its assessment acknowledged at para [47] that:

“Mental health must also be regarded as a crucial part of private life associated with the aspect of moral
integrity. Article 8 protects a right to identity and personal development, and the right to establish and develop
relationships with other human beings and the outside world. The preservation of mental stability is in that
context an indispensable precondition to effective enjoyment of the right to respect for private life.”

**[89] However, on the facts of that case it held that the implementation of the decision to remove the Applicant did**
not violate art 8 of the Convention.


-----

**[90] Turning to the facts of this case on the issue of mental health I note that the first time the issue of the**
Applicant's mental health was raised on her behalf was in a letter of 8 September 2022. All that was said at that
time was “this delay is unreasonable and impacting her mental health.”

**[91] In her initial screening interview, the Applicant was asked about whether she had any medical conditions. She**
referred to the fact that she had been bitten by a dog and which had caused a significant injury to her leg. In relation
to potential mental health issues, she stated:

“I don't sleep very well. I will be awake all through the night. I might have depression. I don't know. I'm always
worried.”

**[92] True it is that after the substantive interview on 20 October 2020, a note made by the interviewer said that the**
Applicant was “displaying signs of trauma, no professional assessment made, I would point out there are symptoms
there, she did answer she has no mental health issues, but I would imagine there is potential PTSD, those displays
of trauma were apparent throughout the interview, due to her getting extremely upset and also talking about
flashbacks.”

**[93] In relation to any other evidence before the court on this issue, the Applicant simply avers that:**

“28. Since 13 October 2021, there has been a heightened urgency of my asylum claim and this delay has a

great effect on my own mental health and well‑being.

29. The delay has only exacerbated these problems.

30. I highlighted these problems to the proposed respondent in my SAI (see Q12-Q14).

31. I have discussed these problems with my GP, and I feel my life is currently in a state of limbo. I have been
prescribed sleeping tablets from my GP which is under review.”

**[94] Having considered this evidence, it is difficult to see that the Applicant has established a sufficient evidential**
basis for saying that there has been infringement with her art 8 rights.

**[95] The Respondent recognised her potential vulnerability and mental health issues and immediately referred her**
to the NRM procedure. Whilst she has been awaiting a decision, she has been provided with accommodation and
an ARC card. The Respondent has been in regular contact with her solicitor who has been assiduous in looking
after the Applicant's needs. There is no suggestion that she has been denied any access to health services, indeed,
the opposite appears to be the case. The sort of substantial prejudice envisaged in Anufrijeva is plainly absent.

**[96] The circumstances of this case are markedly different from the situation in** _BAC. There the uncertainty_
experienced by the Applicant “far surpassed that of an applicant” awaiting the completion within a reasonable time
of his or her asylum procedure. In _BAC, despite a positive indication, the Applicant was still awaiting a decision_
more than twelve years after his claim. During that time, he pointed to very specific prejudice he suffered as a result
of the restrictions on his status. Importantly, at the time of the court's decision he was still awaiting a decision.

**[97] In this case, notwithstanding any delay, the Applicant has received a positive outcome. This alone weighs**
strongly against any finding of a breach of art 8.

**[98] It may well be that the decision in this case should have been taken earlier. Plainly the evidence establishes**
that there is a significant backlog in the determination of asylum applications. This appears to be attributable to a
number of factors including the volume of applications and available resources to deal with them. The Applicant has
been a victim of that backlog. The court has received an account of how her claim was dealt with from which it is
clear that there were delays in deciding her application. Quicker, more effective decisions would be desirable.
Quicker decision-making would undoubtedly improve the overall situation regarding claims for asylum. It is not,
however, for this court to set out timescales or direct that additional resources be provided to ensure quicker
decisions. The State has provided a statutory framework under which asylum claims are assessed and which


-----

provide an enforceable judicial mechanism to protect any individual rights under that system. That system produces
fair and consistent outcomes which are subject to consideration and review by Tribunals and ultimately the High
Court.

**[99] In conclusion, I am not satisfied that the Applicant has established a breach of her art 8 rights arising from any**
delay in determining her asylum application. The application for judicial review is therefore dismissed.

**_Guidance_**

**[100] In terms of overall guidance in relation to claims alleging a breach of art 8 rights in the context of delays in**
making decisions in asylum claims, it seems to the court that the following principles should be applied:

i In certain circumstances delays in making decisions may give rise to a breach of an asylum seeker's art 8 rights.

ii The court cannot be prescriptive about what constitutes an unlawful period of delay.

iii An important factor will be whether an actual decision has been made. If a decision has been made, then it
would only be in exceptional circumstances that a breach of art 8 will be established. If a decision is pending then
the court will have to make an individual assessment of the period of delay, the reasons for any delay and whether
a decision is imminent. Any delay must be so excessive as to be regarded as manifestly unreasonable. In a case
such as BAC it was easy for the court to determine that the relevant delay was inexcusable.

iv In order to establish a breach of art 8 in any case, the Applicant will need to point to specific evidence-based
factors which demonstrate an interference with art 8 rights, above and beyond what one would expect of any
person awaiting such an important decision. Any impact on private or family life must be serious. This could include
factors pointing to serious deprivation such as homelessness, lack of medical attention required in respect of
significant health issues, impact on the welfare of children and significant interference with family or personal
relationships.

**End of Document**


-----

