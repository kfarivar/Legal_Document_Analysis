# R (on the application of IS (Bangladesh)) v Secretary of State for the Home
 Department [2023] EWHC 3353 (Admin)

King's Bench Division, Administrative Court (London)

Lang J

19 December 2023Judgment

**If this Transcript is to be reported or published, there is a requirement to ensure that no reporting**
**restriction will be breached. This is particularly important in relation to any case involving a sexual offence,**
**[where the victim is guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)**
**order has been made in relation to a young person.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

MR D HUTCHEON (instructed by Duncan Lewis Solicitors) appeared on behalf of the Claimant.

MR J FLETCHER (instructed by the Government Legal Department) appeared on behalf of the Defendant.

_________

**JUDGMENT**

MRS JUSTICE LANG:

1 In considering the balance of convenience I remind myself of the defendant's own policy approach to
balancing the relevant factors. The Adults at Risk in Immigration Detention policy (April 2023) strengthens
the presumption against detention of those who are particularly vulnerable to harm in detention. However,
risk factors to the individual have to be balanced against immigration control factors and public protection
issues, where a foreign national offender is being deported for serious offences.

2 The section in the policy headed “Balancing risk factors against immigration control factors” (internal
p.22) states:

“…An individual should be detained only if the immigration factors outweigh the risk factors such as to
displace the presumption that individuals at risk should not be detained…

Evidence assessment

As in any case of potential detention, in order to detain there must be a realistic prospect of removal within
a reasonable period. In cases of adults at risk in which this condition is met, the following is a guide to
balancing any identified risk issues relating to the individual concern against the immigration
considerations. In all cases, the primary consideration should be based on the length of time for which
detention is expected to be required and the likely impact of the length of detention on the individual, given
the evidence of risk.”

3 The policy guidance for individuals at Level 3 is as follows (internal p.23):


-----

“Where on the basis of professional and/or official documentary evidence, detention is likely to lead to a
risk of harm to the individual if detained for the period identified as necessary to effect removal, they should
be considered for detention only if one of the following applies:

- removal has been set for a date in the immediate future, there are no barriers to removal, and escorts
and any other appropriate arrangements are (or will be) in place to ensure the safe management of the
individual's return and the individual has not complied with voluntary or ensured return

- the individual presents a significant public protection concern, or if they have been subject to a 4 year
plus custodial sentence, or there is a serious relevant national security issue or the individual presents a
current public protection concern

It is very unlikely that compliance issues, on their own, would warrant detention of individuals falling into
this category. Non-compliance should be taken into account if there are also public protection issues or if
the individual can be removed quickly.

…..

In each case the length of likely detention will be a key factor in determining whether an individual should
be detained.

As part of the determination of whether an individual should be detained, consideration must be given to
whether there are alternative measures, such as residence or reporting restrictions, which could be taken
to ensure an individual's compliance whilst removal is being planned or arranged and to reduce to the
minimum any period of detention that may be necessary to support that removal – for example, by
detaining much closer to the time of removal.”

4 In considering the specific criteria for Level 3, the first bullet point does not apply as it is not possible to
set a removal date for the immediate future as there are barriers to removal. The only applicable factor in
the second bullet point is the public protection concern.

5 I accept that there is convincing evidence that the claimant is not fit for detention and that detention
exacerbates the symptoms of his mental illness. His mental health problems and history of self-harm and
suicidal ideation has been identified by a number of doctors over the years, whose opinions I have referred
to in my previous ruling. Most recently, Dr Farooq, the Brook House GP, completed a r.35(3) report
advising:

“His mental health is NOT stable in this environment. He has previously tried to commit suicide, he has
previously self-harmed. I DO have concerns in terms of a deterioration of severity in relation to his mental
and physical health on the basis of his available records and current presentation of PTSD, ADHD,
depression and EUPD.”

6 The opinion of Dr Galappathie, Consultant Forensic Psychiatrist, dated 19 October 2023 was that the
claimant is not fit to be detained because he suffers from significant mental health problems and he has a
significant history of self-harm and suicidal ideation, both in the past and on numerous recent occasions
since being in detention. In his opinion, detention is having a negative impact on the claimant's mental
health. He states:

“In my opinion, detention has led to him experiencing worsening depression leading to psychotic
symptoms, thoughts about self-harm and suicide, worsening anxiety-related symptoms, worsening of his
PTSD, distress as a result of having ADHD whilst in detention and feeling frustrated and has led to
frequent incidents of self-harm and attempted suicide attempts.”

7 On 16 November 2023 Dr Galappathie wrote to the IRC Health Care Manager indicating his opinion that
the claimant's mental state had deteriorated still further. He had suicidal thoughts following the suicide of
another detainee and was assessed as “at high risk of impulsively attempting to commit suicide”. He noted
that the lack of specialist one-to-one psychological therapy was a risk factor for suicide.

8 Dr Galappathie prepared an updating report on 18 December 2023 which confirms the previous
diagnosis, the prognosis and recommendations. I have also seen recent medical records.


-----

9 The claimant has now been in immigration detention for nearly five months and, on the evidence, his
appeal is not going to be finally determined in the near future. There is still no hearing date for the
directions hearing or the substantive appeal at the FtT.

10 Since the last hearing the Home Office has determined the claimant's NRM application and has
concluded that there are Reasonable Grounds to conclude that he is a victim of **_modern slavery. The_**
next stage is a more detailed assessment to decide if there are Conclusive Grounds to believe that he is a
victim of modern slavery. The standard form letter from the Home Office dated 7 December 2023 states
that the Conclusive Grounds decision will not be made for at least 30 days. The defendant's instructions
from its client is that it could be completed as quickly as six weeks if the case is prioritised. The claimant's
experience is that the process takes months. The objective evidence from the Home Office statistics is
that the average waiting time is 530 days.

11 The letter from the Home Office states that:

“If a positive conclusive grounds decision is made, the Home Office will automatically consider whether he
qualifies for temporary permission as a 'victim of trafficking and slavery' (“VTS”). VTS permission is issued
when a person needs to stay in the UK because they are assisting public authorities with their inquiries,
pursuing compensation or to assist recovery from exploitation.”

12 Therefore I consider that the positive Reasonable Grounds decision is a further factor which is likely to
lead to delay in removing the claimant from the UK. By s.61 of the Nationality and Borders Act 2022, the
claimant cannot be removed from the UK until a Conclusive Grounds decision is made.

13 The claimant submits that the NRM process may also delay the progress of the FtT asylum appeal,
which may have to adjourned pending the conclusive grounds decision. That is a matter for the FtT to
decide. I note that on the previous directions hearing there was a postponement to allow the NRM
application to be made which suggests that an adjournment is possible.

14 In assessing the balance of convenience I have to take into account and weigh in the balance possible
risks of re-offending, the possible risks of absconding and the risks to the public, all of which are set out in
my previous ruling. I consider that his deteriorating mental illness, and the risk of self-harm and suicide if
he remains in detention, outweigh the public protection risks for two main reasons.

15 First, there are outstanding barriers to his deportation. The FtT appeal and the NRM Reasonable
Grounds decision mean that deportation is not going to be possible in the near future. Given that he has
already spent five months in detention, I consider that the overall length of detention will be unreasonably
long, having regard to his vulnerability.

16 Second, I consider that public protection concerns can be adequately addressed by bail conditions,
together with the conditions of his licence and supervision by his probation officer.

17 Under the terms of his licence he must–

a) be of good behaviour and not behave in a way which undermines the purpose of the licence period;

b) not commit any offence;

c) keep in touch with his supervising officer in accordance with instructions given by the supervising
officer;

d) receive visits from the supervising officer in accordance with instructions given by the supervising
officer;

e) reside permanently at an address approved by the supervising officer and obtain prior permission for
supervising officer for any stay of one more nights at a different address;

f) not undertake work, or a particular type of work, unless it is approved by the supervising officer and
notify the supervisor in advance of any proposal to undertake work or a particular type of work; and

g) not travel outside the UK… except with the prior permission of the supervising officer or for the purpose
f i i ti d t ti l


-----

h) tell the supervising officer if they use a name which is different to the name/s that appear on their
licence;

i) tell the supervising officer if they change or add any contact details, including any phone number or
email.

18 The parties have agreed bail conditions in principle. They are as follows:

a) The claimant is not allowed to work.

b) The claimant is not allowed to study.

c) The claimant must reside at an address approved by the Probation Service.

d) The claimant must report to a police officer or immigration officer at a reporting centre (to be identified)
weekly on Friday between 1400 and 1600.

e) The claimant must comply with electronic monitoring conditions.

19 The parties have not reached agreement on the issue of accommodation. On 7 December 2023, the
defendant wrote to the claimant refusing his application for support under s.95 of the Immigration and
Asylum Act 1999 as a destitute asylum seeker. The reason for refusal was the finding that the claimant
has “a strong support network of friends and relatives in London” who could provide support to him to meet
his accommodation and essential living needs. However, in the application form the claimant's solicitor
stated:

“My client has his parents and siblings in the United Kingdom, however, Probation had previously refused
to consent to this address. He has now been convicted of a drugs offence in which he alleges that he was
trafficked in the same area. It is anticipated that accommodation provided by his family members will not
be suitable for Probation.”

20 The decision letter states that the National Probation Service were contacted and the claimant's
offender manager stated:

“There is nothing to suggest that [he] cannot reside with family members. I have not been able to conduct
any risk management plan as I have been unable to interview him, however, should he provide me with a
family address I am more than happy for this to be agreed, subject to police and home checks.”

21 The claimant has lodged an appeal to the First-tier Tribunal against this decision and the hearing is
listed for 3 January 2024. The claimant submits that the positive Reasonable Grounds decision supports
his contention that his family home is not a suitable address because it is in the area where he claims to
have been trafficked.

22 It is a condition of the claimant's licence that he must reside in the accommodation approved by the
Probation Service. In my view, this means that the probation officer ought to be allowed to undertake a risk
management assessment, including an interview with the claimant at Brook House, and to be provided a
home address or other address which can be checked for suitability.

23 In the course of that assessment, the probation officer ought also to consider whether the claimant
could be accommodated in level 2 or level 3 bail accommodation pursuant to para.9 of Schedule 10 to the
Immigration Act 2016, as described at internal p.93 of the Home Office guidance “Immigration bail” version
18.0” (30 November 2023). In my view, this is a separate power to the provision of accommodation and
support under s.95 of the Immigration and Asylum Act 1999 and different criteria apply. Destitution may be
a basis for para.9 of Schedule 10 support, but it is not the only basis. The claimant refers to the case of
_Humnyntskyi v Secretary of State for the Home Department [2021] 1 WLR 320in support._

24 I am concerned by the email exchange in which the claimant's solicitor asks the Probation Service to
confirm that they would be able to attend Brook House to assess the claimant and that they would have
sight of the NRM referral documents. The response from the Probation Service dated 18 December 2023
states:


-----

“At the moment, we are currently a red site, which means that we do not have a capacity to attend sites to
carry out an assessment. I have a record of [his] past convictions, but anything else relating to his
immigration would not be made available to me.”

In my view, this means that the Probation Service will not have sufficient information to discharge their
duties effectively.

25 A further potential route forward is an application for accommodation and other support pursuant to
s.50A of the Modern Slavery Act 2015 and the defendant's Statutory Guidance on Modern Slavery (“the
Guidance”) from para.15.10 onwards. Following a Reasonable Grounds decision, the claimant must be
subject of a full risk assessment and a needs-based assessment, the latter of which identifies the support
required to address his needs (Guidance para.8.7, 8.15 and 8.18).  Under the **_Modern Slavery Victim_**
Care Contract (“MSVCC”) the defendant will accommodate victims seeking bail from immigration detention,
including where electronic monitoring is a condition of their release “if the needs based or risk assessment
identifies a needs for MSVCC accommodation owing to a risk to their safety from traffickers (para.15.23)”.
Moreover, “where it is identified that a victim needs accommodation in accordance with para.15.22 to
para.15.23 but a risk assessment determines they would pose a risk to existing residents or staff in
MSVCC accommodation, the MSVCC will provide alternative non-shared accommodation (15.25 of the
Guidance)”.

26 However, the MSVCC Referral Team has sent an email to the claimant's solicitor which is less than
helpful. It is dated 15 December 2023. It states that:

“As the claimant is currently detained in an immigration removal centre that establishment must provide
him with access to the support they require. Unfortunately, the MSVCC Referral Team was unable to act
on your request and will only liaise with the IRC once they make us aware of [his] planned release date.
We can only accept this information directly from HMP/IRC. Upon receipt of a planned release date for

[the claimant] we will then liaise with the relevant IRC to facilitate a smooth transition into the National
Referral Mechanism. This process will include conducting an Initial Risk Assessment before he is released
and putting a plan in place to mitigate any identified risks upon release…..”

27 The claimant's solicitor wrote to the defendant on 18 December, asking him to liaise with the MSVCC
Referral Team about the claimant on the basis of an assumed release. There is no reply as yet.

28 In view of these difficulties with the Probation Service and the MSVCC Referral Team, I consider that
the claimant should join the Probation Service as a defendant or interested party to this claim so that any
unreasonable delay in obtaining accommodation can be addressed by this court. It would be a matter for
the claimant to make the necessary application to amend the legal aid certificate. However, I will make an
order now, if requested to do so by the claimant, on the basis that the first step would be for the claimant's
solicitors to seek to amend Legal Aid.

29 I propose to make an order granting bail, with effect from a date to be determined, subject to
conditions.

__________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge._**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_


-----

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

