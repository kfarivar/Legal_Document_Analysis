# R (on the application of B) v Secretary of State for the Home Department

 [2022] EWHC 1422 (Admin)

Queen's Bench Division (Administrative Court)

Choudhury J

25 May 2022Judgment

MS S. NAIK QC and MR A. BANDEGANI (instructed by Wilsons Solicitors LLP) appeared on behalf of the
Claimant.

MR E. BROWN QC and MS H. MASOOD (instructed by the Government Legal Department) appeared on
behalf of the Defendants.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

(Transcript prepared from poor quality audio and without access to documents)

MR JUSTICE CHOUDHURY:

1 The claimant, BA, seeks judicial review of decisions made by the defendants during and after the
evacuation of Kabul, Afghanistan in August 2021.

2 The claimant's sister, BG, a former Judge in Afghanistan, was evacuated on 26 August 2021, along with
another of the claimant's sisters, AG, when they were "called forward" for evacuation. The claimant was
not, however, called forward and remained in Afghanistan. The decision not to call forward the claimant
was reconsidered by the defendants on 17 November 2021 and again on 21 February 2022. The principal
target of the claimant's application is the latter February 2022 decision which is said to be unlawful, tainted
by procedural unfairness, including by the decision makers applying an unpublished policy. The
defendants resist the claims.

3 There are three defendants in this case I shall refer to them either by specific initials or simply as "the
defendants" collectively.

**Background.**

4 "Operation Pitting" was the name given to the UK military evacuation of British Nationals and certain
groups of Afghan nationals from Afghanistan after the Taliban regained power. Operation Pitting
commenced on 13 August 2021, and ended on 28 August. It was designed to implement the
Government's policy decision to evacuate British and Afghan nationals who qualified under the Afghan


-----

Relocations and Assistance Policy ("ARAP").  ARAP was launched on 1 April 2021, and was designed
primarily to enable the Government to support current or former locally employed staff members ("LES"),
but was extended to include a category of "special cases" which, in August 2021, comprised those who:

". . . worked in meaningful enabling roles alongside HMG in extraordinary and unconventional contexts and
whose responsible HMG unit built a credible case for consideration under the scheme".

5 After the evacuation had begun, Ministers indicated a willingness to also evacuate certain other groups
of Afghan Nationals provided there was capacity on evacuation flights, and provided it did not hinder the
priority evacuation of British Nationals and those qualified under ARAP. Spare capacity of UK Military
Aircraft leaving Afghanistan was extremely limited, and the number of individuals wishing to relocate to the
UK far exceeded the capacity that was available.

6 Ministers decided, nonetheless, to utilise such capacity that existed to evacuate as many eligible
individuals as possible in the time available. That decision required rapid determinations to be made about
which other Afghan Nationals to evacuate. A number of cohorts of Afghan Nationals were identified and
agreed, including some journalists, women's rights activists and Government officials, and a small group of
"extremely vulnerable individuals".  Evacuation under this route became known as LOTR or "Operation
Pitting LOTR", the acronym denoting "Leave Outside The Rules", even though the decision to evacuate did
not, by itself, confer any such leave, that being something granted by the first defendant, SSHD, to
individuals arriving in the UK having been so evacuated. LOTR is a residual statutory power contained in
[the Immigration Act 1971,which confers upon the SSHD discretion to grant leave to enter or to remain in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
the UK outside the immigration rules.

7 The situation in Kabul during the short period when Operation Pitting LOTR was conducted has been
described as "extremely perilous and uncertain". The evidence of Phillip Hall from the second defendant,
the Foreign Commonwealth & Development Office ("FCDO") who assisted in the Afghanistan Crisis Centre
from 16 August 2021, describes the situation as follows:

"Operation Pitting . . . took place in truly exceptional circumstances with the Afghan National Army and
Government collapsing faster than expected leaving no civilian control, contested security, and the Taliban
control of all territory including the capital, Kabul, and access to the airport. Only the airport itself was
under NATO military control. Until around 22 August 2021 the United States of America was trying to
persuade the Taliban to allow the evacuation to continue beyond the end of August, meaning there was
uncertainty over how long Operation Pitting would continue.

Decisions were taken under very challenging, constantly changing, circumstances and plans had to be
adapted, including when, on 25 August, a terrorist threat to the airport necessitated an amendment to
travel advice. The new travel advice advised against travel to the airport.

On 26 August a suicide bomber killed a large number of civilians and US Military personnel outside Kabul
Airport. Operation Pitting ended on 28 August 2021 when the final British Military personnel withdrew from
Afghanistan."

The description above is not disputed, nor is the fact that Government officials, both here and in
Afghanistan, worked day and night during this period to progress the evacuation of as many eligible people
as possible in these exceptionally difficult circumstances.

8 However, there has been considerable criticism of Government action generally in relation to the
evacuation from Kabul; indeed, there was negative press coverage on the morning of the first day of the
hearing upon the publication yesterday of the House of Commons Foreign Affairs Select Committee
Report, entitled "Missing in action: UK leadership and the withdrawal from Afghanistan." The Select
Committee was highly critical of the actions taken and the lack of preparedness of officers, including Sir
Philip Barton. However, it is not for this court to express any view on such actions on the part of the
Government more generally; its focus is much narrower, and that is to consider whether there was any
unlawfulness in respect of the specific decisions under challenge. No doubt, in the course of these very
difficult and challenging circumstances in August 2021, many decisions were taken which appeared harsh


-----

and unfair to those adversely affected.  However, those are not considerations that can affect the analysis
of the court when it comes to the legality of the decisions under challenge.

9 Operation Pitting LOTR was not an application-based process, whereby individuals seeking to be
evacuated applied to the FCDO for consideration; instead, decisions were taken primarily by FCDO as to
which Afghanistan Nationals from amongst the agreed cohorts would be “called forward” for evacuation,
that being the process by which individuals were informed that they would be evacuated by the
Government from Afghanistan to the UK. From 23 August 2021 decision-making Panels were established
for this purpose. Panel members comprised senior FCDO officials working in the Crisis Centre. Mr Hall, in
his evidence, states that the Panels:

". . . aimed for good decision making in full knowledge that it was not possible in the time available to
subject each application to the level of scrutiny that we would normally have applied for an ARAP or other
decision. If we were to give some people a chance of evacuation on a UK military flight . . . we had to take
decisions rapidly and on the basis of the information we had. . . If we had developed a more sophisticated
and rigorous process and gathered more information, we would have taken no decisions in time for
evacuation."

10 Once a decision by the FCDO was taken that someone should be called forward, that person would be
subject to security checks and clearance by the Home Office. Those approved for evacuation were issued
call-forward instructions by the military team working in FCDO's Crisis Centre instructing them to come to
the airport. As already stated, FCDO did not grant individuals LOTR as such, or a visa to enter the UK.
Individuals who were evacuated were granted LOTR, specifically leave to enter for six months by the
SSHD on arrival in the UK. The usual requirements for entry clearance were temporarily relaxed between
15 and 28 August 2021.

11 Operation Pitting LOTR was in operation for a very limited time during the evacuation. Individuals were
called forward for evacuation from around 21 August 2021 and continued until Operation Pitting ended on
28 August when the final British military personnel withdrew from Afghanistan. Once Operation Pitting
ended Operation Pitting LOTR also came to an end. The normal policies and processes for relocation and
resettlement in the UK then resumed as formalised in the Home Office Afghanistan resettlement and
immigration policy statement of 13 September 2021.

**The Evacuation of BG.**

12 Individuals or "principals" evacuated under Operation Pitting LOTR could be accompanied by
immediate family members, i.e. one spouse, civil partner or durable partner, and dependent children under
18. In some exceptional cases additional family members were also called forward and allowed to travel at
the same time as the principal: where a family unit that included an unmarried child over the age of 18
would be split if that child was unable to travel; where a single elderly parent who lived with, and was cared
for by, the principal faced being left alone without any care provision; and where the principal was a single
female and required a chaperone. Risks faced by the additional family member were not taken into
account. Additional family members were evacuated based on family ties and individual vulnerabilities
rather than because they were at any specific risk.

13 Prior to the Taliban taking over Afghanistan, BG was a judge in Parwan Province in Afghanistan. She
was a judge at the Primary Court, and had started working as a judge in the field of elimination of violence
against women about four years previously. For one year before that she was a judge in the General
Criminal Court. BG had received eight years of mentoring from lawyers in the USA, then earlier in 2021,
when Afghan women judges became members of the global Women Judges' Association ("WJA") a
mentoring scheme of judges in the UK was established.  As part of that mentoring scheme 11 female
Afghan judges were twinned with British female judges who were part of the UK Association of Women
Judges. BG was amongst that 11.

14 Life as a female Afghan judge was, as is made clear from BG's evidence, fraught with danger even
before the Taliban takeover. BG had even been issued by the Afghan Government with a firearm for her


-----

safety. She gave this to her brother, the claimant, who was working for her as a bodyguard when the
Taliban assumed control.

15 BG made an online ARAP application on 21 August 2021. ARAP is, and was at all material times,
administered by the third defendant, the MOD, who received applications for ARAP through the online
application portal. BG's ARAP application, which was "lost" for some months, has not yet been considered
and remains among the cases awaiting a decision. BG came to the attention of FCDO on the evening of
20 August 2021 before she had made her ARAP application. This was when an MP shared with Lord
Ahmad a list of 11 judges twinned with British judges under the WJA mentoring scheme. On 22 August
2021 a member of Lord Ahmad's private office contacted BG requesting her passport details and details of
any dependents travelling with her. BG replied by stating:

"Please find my further information. I am single and lives (sic) with my parents, brothers and sisters. I just
sent you two dependents travelling members of my family."

The two dependents listed in the attachment to this email were AG, described in the email as BG's sister,
and the claimant BA, described as BG's brother.

16 The names of the 11 judges and their family members were sent to the Home Office for security
checks. All those on the lists where dates of birth had been included passed security checks and were
cleared to travel by the Home Office. This was conveyed to the FCDO by the Home Office in an email sent
on 24 August 2021. In the early hours of the morning of 24 August 2021, a Panel was convened to
consider the cases. The Panel was chaired by Mr Hall. BG and AG were approved for evacuation by the
Panel; however, BA was not.

17 The Panel's decisions and the reasons for them were not recorded in any great detail. As Mr Hall
states in his evidence:

"Given the pace required the names of those agreed for calling forward were simply relayed to the Military
Team to give them a chance of contacting the individuals."

Mr Hall does, however, provide an account of his recollection of the reasons for the decisions made in
respect of BG, AG and BA. He was able to do so because BG's case was recalled as being distinctive,
because she was a judge seeking to have two adult siblings accompany her. Mr Hall said this:

"The Panel considered that on the basis of the information available AG (BG's sister) and another single
female, should be permitted to accompany BG.  The Panel used their discretion to evacuate BG's sister
but were not under any duty to do so considering the policy only required such evacuation in exceptional
circumstances. This meant that BG was accompanied and that BA, a single male, rather than AG, a single
female, was left in Afghanistan. The Panel had no information about risk to either AG or BA. The risk to
BA was not considered."

BG and AG were called forward by the Military Team on the morning of 24 August 2021, just a few hours
before the cut off point for all call forwards at 10.00 British Standard Time.

18 On 25 August 2021 an official at the Rapid Deployment Team at the Baron Hotel, the evacuation
handling centre, emailed to ask for confirmation that the claimant and AG had been authorised for
evacuation. The Afghanistan Crisis Response Team replied confirming that AG was cleared for travel, but
the claimant was not, and there is an email to that effect.  BG and AG were therefore evacuated on 26
August 2021 on one of the final flights to leave Afghanistan. The claimant remained in Afghanistan.

**Events Following the End of Operation Pitting.**

19 On 21 October 2021 the claimant's solicitor sent a letter before action accompanied by witness
statements from BG and BA dated 18 and 19 October 2021, stating that BA had informally acted as BG's
bodyguard and was at risk. On 17 November 2021 the Government Legal Department ("GLD") wrote to
BA's representatives, Wilsons Solicitors, stating:

"My clients are reconsidering the decision which was made in respect of BA due to the very specific facts
of his case and will serve the result of that reconsideration by letter within seven days of today."


-----

Mr Brown QC, who appears for the defendants with Ms Masood, submits that the FCDO made this offer to
reconsider as a gesture of goodwill considering the exceptional circumstances of the evacuation and the
lack of documentary record of the reasons for the decision.

20 A Panel was convened further to that letter on 22 November 2021 and its decision recorded that it
considered whether BA qualified for call forward for evacuation under Operation Pitting LOTR. It took
account of the further witness statements from BG and BA, and concluded that BA did not qualify to be
called forward. Risk to BA was not specifically considered because risk was said not to be a consideration
during Operation Pitting.

21 BA issued this judicial review claim in December 2021, challenging, amongst other matters, the Panel's
decision of 22 November 2021. It was alleged that the Panel took into account irrelevant considerations
and failed to take account of all relevant considerations, including in particular, the risks that the claimant
faced, and continues to face, in Afghanistan. Permission was refused on the papers. However, permission
was granted by Fordham J at an oral hearing on 21 December 2021 in respect of five separate Grounds
including an allegation that the defendants had erred by not taking account of the risks to the claimant in
refusing his evacuation.

22 On 8 February 2022, the GLD wrote to Wilsons stating that the FCDO was prepared to agree to
withdraw and remake the reconsideration of 22 November 2021, this time taking account of risk. It stated
that a new decision would be served within 14 days of the date of that letter. In the light of that offer to
issue a new decision taking account of risk, the claimant was invited to withdraw his claim. However, by
letter dated 9 February 2022, Wilsons confirmed that BA was not prepared to withdraw his claim. The
same letter listed and enclosed further material including additional witness statements and a report on the
situation in Afghanistan prepared by Mr Tim Foxley, dated 9 February 2021 ("the Foxley Report"). Wilsons
requested confirmation that FCDO would take this further material into account when making its decision.
In a further letter a request was made that the FCDO also have regard to a BBC short film produced on 10
February 2022. By letter dated 11 February 2022, GLD stated that this further material would not be
considered; instead:

"The decision would be remade on the facts and evidence before the decision maker in August 2021 and
the decision making Panel on 22 November 2021."

It also stated that further evidence as to events, post-dating the evacuation, would not be taken into
account.

23 The Panel was convened on 16 February 2022, made up of staff from the Afghanistan Task Force.
The Panel had regard to certain items of guidance to which I shall return in due course. The Panel
considered that the risk faced by BA, and the nature of his relationship to the principal did not render him
eligible to be called forward as an additional family member during Operation Pitting LOTR. It is this
decision, the February 2022 decision, that Ms Naik QC, who appears for the claimant with Mr Bandegani,
describes as the "target" of the claim.

**The Grounds of Claim.**

24 Four Grounds of claim are pursued. These are:

Ground 1 - The defendants were obliged but failed to decide whether the claimant was an additional family
member of a person relocated under ARAP. Ms Naik submits that, as an ARAP application was made (as
the defendants now concede) and a decision on this application will be made in due course, Ground 1 falls
to be resolved in the claimant's favour.

Ground 2 -  In deciding the question of risk, the Panel applied an unpublished guidance document
inconsistent with the terms of published policies, thus rendering this decision unlawful.

Ground 3 - In all the circumstances of the case the Panel's decision was procedurally unfair.

Ground 4 - The Panel was obliged but failed to take account of all relevant matters including evidence of
circumstances and events that took place after the evacuation ended, but prior to the date of the Panel's


-----

decision. In particular the February 2022 decision failed to take account of two further witness statements
and the expert opinion of Mr Foxley OBE set out in the Foxley Report.

I shall deal with each ground in turn.

**Ground 1 – Failure to Deal with the ARAP Application.**

**_Submissions._**

25 Ms Naik's skeleton argument states that Ground 1 is not addressed save to observe that, despite a
seven-month delay on the defendants' part in acknowledging and agreeing what the claimant had asserted,
namely, that he should be considered as an ARAP dependent, no timetable has yet been offered for
decision, nor any acknowledgement of any procedural failing or its relevance to the application. On that
basis Ms Naik submits that Ground 1 falls to be determined in BA's favour. These points were not
developed orally.

26 Mr Brown submits that the straightforward answer to this claim is that BG was considered and called
forward under Operation Pitting LOTR not ARAP, and that there was, therefore, no basis on which the
claimant should have been considered as an ARAP dependent. He submits that whilst BG has a right to
continue with her outstanding ARAP application that does not change the basis on which she was
evacuated during Operation Pitting. Mr Brown further submits that there was no procedural irregularity as
the ARAP applications are being considered in the order that they were received through the online portal.

**_Ground 1 – Discussion._**

27 While it would appear surprising that BG's ARAP application could be "lost" by the defendants in their
systems for so many months without that affecting her position in the queue for consideration, that aspect
of the defendants' case is supported by evidence which it would not be appropriate to gainsay in these
proceedings. What is apparent is that BG was evacuated under Operation Pitting LOTR, and not under
ARAP. That much appears now to be accepted. Therefore, insofar as the claim under Ground 1 is that
there was a failure to consider the claimant's case under ARAP, that claim cannot succeed. BG's ARAP
application was entered into the portal, along with all of the other tens of thousands of applicants. That
application, and consequently BA's position as a dependent of BG under the ARAP scheme, will, it would
appear, be considered in due course. Although it is now almost ten months since the application was
made there is no claim that the delay itself gives rise to any claim, or that there was any breach of policy,
duty or legitimate expectation that the application would be considered sooner. Ms Naik does make the
point that the failure to consider BG's application sooner is relevant to the decisions under challenge.
However, that point was not developed in oral submissions and it is difficult to understand how the
reconsideration decisions of the defendants in November 2021 and February 2022 could realistically have
been affected by knowledge of an ARAP application having been made.  In conclusion, therefore, and
contrary to what Ms Naik submits, Ground 1 falls to be dismissed. There has not been any failure to
consider the ARAP application.

**Ground 2.**

**_Submissions_**

28 Whilst Ground 2 in the amended grounds relied principally upon a claim that the second defendant had
applied the wrong guidance document, and consequently applied the wrong test, to determine BA's
position, the skeleton argument also suggested that FCDO perpetrated a 'Lumba' error (R(Lumba) v SSHD

[2012] 1 AC 245), in that it had relied on an unpublished policy that was inconsistent with the published
one.

29 As to the claim that the wrong guidance document was applied Ms Naik submitted that the test to be
applied in all LOTR cases was that contained in the LOTR Principal Guidance of February 2018 ("the
Principal Guidance"). Accordingly, it is sufficient that there are "exceptional circumstances" involving
"unjustifiably harsh consequences" constituting "compelling, compassionate grounds".  Reliance is placed
on the views expressed by Fordham J in granting permission that the test to be applied is to be found in
the Principal Guidance and not in a "reference document that is not exhaustive" (See permission decision


-----

of Fordham J at paragraph 24). Ms Naik submits that, instead of applying the Principal Guidance, FCDO
applied other incorrect tests drawn from two other guidance documents, namely the FCDO's Interpretation
of LOTR Guidance, dating from August 2021 ("the Interpretation Guidance"), and a document entitled
"Factors Under Consideration by FCDO ARAP/LOTR Panel when considering applications for additional
family members" ("the Factors Guidance").

30 Ms Naik's principal point in relation to these guidance documents is that they are for use in ARAP
cases, were not appropriate and should not have been used in the circumstances faced by BA.
Furthermore, she submits that the tests for the assessment of risk contained in these documents refer to
there being a "high, immediate specific" risk of harm which imposes a higher threshold than the one set out
in the applicable Principal Guidance.

31 Ms Naik's Lumba point is that the principal guidance read with the Additional Guidance on the eligibility
of additional family members under the Afghan Locally Employed Staff Relocation Schemes (version 1)
dating from 4 June 2021 ("the Additional Guidance") is inconsistent with the unpublished Factors Guidance
in that the test for risk in the Additional Guidance is easier to satisfy. Furthermore, as the content of the
Factors Guidance was unknown to BA, she submits he would have been unable to make meaningful
representations to the decision-maker in August 2021 when his case for being called forward was first
considered, or at the stage of either of the subsequent reconsideration decisions in November 2021 and
February 2022. For these reasons, it is submitted, the FCDO's decision in February 2022 falls to be
quashed.

32 Mr Brown submits that the decision now under challenge, i.e. the February 2022 decision, is a specific,
bespoke decision taken in light of BA's particular circumstances. There was, and is, no precise policy
document governing that situation, which is why the FCDO had regard to the closest policy documents
available to guide their decision. That was a matter for the FCDO to decide, and it gives rise to no public
law unfairness. As for Ms Naik's _Lumba point, Mr Brown submits that this is not a pleaded ground of_
challenge, and that, in any event, it is wrong to suggest that the Factors Guidance, which she accepts was
unpublished, was applied instead of a published one. At most, he submits the decision makers had regard
to the Factors Guidance, along with other analogous guidance documentation, to guide their decision
making in this bespoke process implemented specifically for BA. This was not, therefore, a _Lumba_
situation. In any event, he submits there is no material inconsistency between the tests in the Factors
Guidance and the Additional Guidance as alleged.

**Ground 2 – Discussion.**

33 Mr Brown is correct to describe the decision-making process in February 2022, that being the decision
under challenge, as being a bespoke one designed to take account of BA's particular circumstances. After
BA had not been called forward in August 2021 the defendants undertook to remake the decision to
determine whether BA qualified to be called forward during the evacuation in August 2021. The
opportunity afforded to BA by the remaking of that decision is clearly not one afforded to all others who
wished to be, but had not been, called forward for evacuation during those frantic days in August 2021
when Operation Pitting LOTR was in play.  The FCDO clearly has the discretion to remake the decision
and there is no issue about that. Nor is there any issue that, having so decided, the decision-making
process still has to be fair and in accordance with the usual principles of natural justice. The FCDO could
not realistically argue, nor does it seek to do so, that the discretionary nature of the process obviated the
need for such fairness. (See R(Citizens UK v SSHD) [2018] 4 WLR 123at paragraph 86 per Singh LJ).

34 The bespoke nature of the decision did not, of course, mean that the decision makers had a completely
free hand to decide the matter without the benefit of any guidance or framework to their decision making.
A Panel that was convened to remake the decision in February 2022 said this as to the framework for its
decision making:

"In reconsidering the decision not to call forward BA for evacuation during Operation Pitting, the Panel had
regard to a number of documents as set out in the letter dated 10 November 2021 to the solicitor
representing BA: a document entitled 'FCDO Interpretation of LOTR Guidance'. The disclosure bundle
was not specifically designed for the decision whether to call forward someone for evacuation during


-----

Operation Pitting. However, its principles were used to aid decision making on extended family members
to be evacuated under the Operation Pitting LOTR arrangements. The Panel also had regard to the
document entitled 'Factors under Consideration by FCDO ARAP LOTR Panel when considering
applications for additional family members for LOTR'. This document was utilised as a framework to guide
the assessment of risk but the document was not directly applied as it would be if this decision was taken
in relation to an additional family member of an ARAP principal."

The Panel therefore clearly recognised that whilst the Interpretation Guidance had not been specifically
designed for evacuation decisions during Operation Pitting, the principles therein could be used to aid
decision making on a similar question, namely whether or not additional family members ought to be called
forward along with the principal applicant. Similarly with the Factors Guidance, it was recognised this could
not be applied directly as this was not a decision in respect of an ARAP application; however, it was used
to guide the assessment of risk in BA's case.

35 In my judgment none of that is remotely unlawful. Ms Naik's submissions are based on the premise
these guidance documents were applied directly to BA's decision when they were designed for another
purpose, namely consideration of the position of additional family members under an ARAP application.
However, that premise is clearly incorrect: the documents were used to guide and aid decision-making in a
context where there was no specific guidance directly applicable to the exceptional circumstances in play
as at August 2021.

36 Whilst the Principal Guidance upon which BA now relies is applicable to all LOTR cases, the defendant
is entitled to develop specific bespoke policy guidance on the exercise of discretion to grant LOTR in
particular circumstances.  The evidence before me from Janet Gordon-Smith, Head of Armed Forces,
Afghan Communications Domestic Abuse and YCS New Policies in the Human Rights and Family Unit,
which is unchallenged, refers, for example, to policies on discretionary relief for victims of human trafficking
and **_modern slavery, Grenfell survivors and Grenfell relatives, and others.  The additional guidance in_**
respect of additional family members seeking LOTR, in conjunction with an ARAP applicant, is a further
such example.

37 As Ms Gordon-Smith's evidence further states, publication of such guidance can be helpful in ensuring
that the right factors and criteria are taken into account, and that there is fairness and consistency in the
exercise of the discretion in similar cases seeking LOTR.  The existence of such guidance recognises the
fact that the overarching Principal Guidance cannot possibly cover all scenarios, some of which may not
have been anticipated, or which would be too unwieldy to include in a single guidance document, and that
further detailed guidance in respect of new and emerging situations may, from time to time, be necessary.
The situation in August 2021 was one of exceptional urgency as the evidence of Mr Hall referred to above
describes. It clearly would have been unfeasible to have drawn up detailed policy guidance and to have it
approved in time to enable a decision to be taken in time to evacuate Afghan Nationals before evacuation
flights ceased.  The decision-makers at that time had worked on the drafting of the Interpretation Guidance
and had that in mind when taking the decisions that they did, under extremely challenging circumstances,
as to which family members of those called forward should also be called forward. The Interpretation
Guidance was not specific to the making of the call forward decisions, but it was, to use a colloquialism, the
next best thing at the time.

38 The Interpretation Guidance which was applicable where a principal was eligible under ARAP sets out
the parameters for determining whether additional family members should be granted LOTR. It identifies
two factors to be considered in respect of such additional family members. The first is risk, as to which the
Interpretation Guidance states as follows:

"The risk to the applicant has been assessed by ATREU prior to LOTR. LOTR takes the position that the
risk (of targeted harm) to additional dependents is lower than that for the applicant except where specific
credible threats are more documented. In some cases LOTR may seek an additional assessment risk from
the employment partners, a focal person or line manager."

As at August 2021 when consideration was given as to whether or not BA should be called forward, there
was no information as to risk and it was not therefore considered


-----

39 The second factor is the specific vulnerabilities of the additional family member which have led to
exceptional dependence on the principal. There are several categories of family member identified in the
Interpretation Guidance, and guidance is provided as to the criteria to be applied in respect of each. One
of those categories is in respect of "Unmarried female staff member seeking a chaperone". The Panel
used its discretion in August 2021 to call forward BG's sister, AG, as a chaperone on the basis that a
chaperone could, in exceptional circumstances, be permitted to accompany a lone female principal. This is
clearly an example of applying the Interpretation Guidance by analogy. That application is not challenged.

40 Another category is "dependent sibling – male". As to that category, which is the only one that could
realistically have applied to BA, the guidance states that the application would be endorsed where all the
following criteria are met:

(i) The male sibling cohabits with the sponsor, is unmarried and has never been married.

(ii) The male sibling has no other adult male blood relative in Afghanistan with whom they are in contact.

(iii) The male sibling requires long term care due to illness and disability.

(iv) There are relevant exceptional circumstances.

BA accepts that he does not satisfy these cumulative requirements. There was no other basis on which
BA would have been likely to be called forward as at 24 August 2021.

41 Of course, the decision now under challenge is that taken in February 2022. On that occasion the
FCDO sought to remake the decision taken in August, but this time expressly considering the issue of risk.
As stated above it did so by having regard to the Interpretation Guidance and Factors Guidance. In my
judgment, there is nothing unlawful about the defendants' approach in this regard. Whilst those policies
were designed for a different purpose, the principles and criteria established in relation to LOTR for
additional family members, under ARAP did bear some similarity to the situation which BA found himself in
as at August 2021, even though BG was not being considered as an ARAP applicant. It was not wrong or
unlawful in any public law sense to have regard to that material.

42 Ms Naik complains, however, that by doing so the defendant applied a harsher test for risk than that
which would have been applied if the Principal Guidance read with the Additional Guidance had been
applied. She submits that that was unfair.  I reject that submission. The Principal Guidance does not refer
expressly to risk. Instead it provides:

"LOTR on compelling compassionate grounds may be granted where the decision maker decides that the
specific circumstances of the case include exceptional circumstances. These circumstances will mean that
a refusal would result in unjustifiably harsh consequences for the applicant or their family, but which do not
render refusal a breach of ECHR Article 8, Article 3, refugee convention or other obligations."

The three key phrases in that passage, namely "compelling compassionate grounds", "exceptional
circumstances" and "unjustifiably harsh consequences" do not expressly identify risk to life and limb as a
factor, although clearly such risk could be encompassed within them, and in particular within the last one.
However, that would give decision makers little or no guidance as to the level of risk that would be required
to be established in order to justify the granting of LOTR. The defendant is entitled to develop further
guidance for decision-makers as to the specific level of risk to be considered in particular circumstances.
The Additional Guidance states that its purpose is as follows:

"This guidance tells you about the eligibility criteria for additional dependents and family members of
Afghan locally employed staff (LES) who wish to relocate to the United Kingdom but who do not qualify
under the Immigration rules."

43 In a section headed "Assessment of AFMs: relationship and risk" the Additional Guidance provides,
_inter alia:_

"Key factors when assessing the suitability for leave outside the rules (LOTR) include the proximity of the
family relationship, the family circumstances of the individuals involved, including the nature and extent of


-----

any dependency, and the way in which the LES employment has led to any risk to the family member and
what those risks are judged to be.

Documents produced to demonstrate any risk faced by additional family members as a result of the LES
employment must be assessed by the Afghan Threat and Risk Evaluation Unit (ATREU) in the British
Embassy Kabul.

Once ATREU has reached a decision, each additional family member who is to be considered by UKVI
under the exceptional criteria must complete an application form and have their biometrics taken. That
information is then forwarded to UKVI along with copies of all supporting documents."

I deal here in passing with one of Ms Naik's submissions, which is that the reference to assessment by
ATREU highlights the unsuitability of using the document for the February 2022 decision because ATREU
did not, by then, exist. However, that does not preclude having regard to the guidance to guide decisionmaking where there is no specific policy addressing the circumstances surrounding the evacuation of
Kabul in August 2021.

44 In a further section dealing with the Consideration of Exceptional Circumstances, the Additional
Guidance sets out what is to be taken into account in the assessment of security concerns.

"There may be exceptional circumstances where the work of the LES has led to specific threats or
intimidation of members of their family who have not normally qualified for relocation under the Immigration
Rules.

If the LES makes the request for additional family members to accompany them on that basis the
employing department, normally the MOD or FCDO, must obtain all available and relevant information to
enable the ATREU to make an assessment of the level of risk faced by those family members.

If the risk is assessed as high and immediate ATREU may recommend to the Home Office that they are
included with the LES for relocation alongside family members qualifying under the Immigration Rules.

The assessment must confirm that the risk is specific to the additional family members, and related to the
work undertaken by the LES in order for relocation to be considered."

One can see, therefore, that under this guidance the assessment of risk is a relevant factor. Persons could
be recommended for inclusion if the risk faced is assessed as high and immediate, specific to the
additional family member and related to the work undertaken thereby. It is guidance which is clearly
intended to elaborate upon the broad definition of exceptional circumstances referred to in the Principal
Guidance, and deals specifically with the circumstances pertaining to ARAP applications in 2021.

45 The Factors Guidance sets out the specific factors to be considered when reviewing applications under
the Additional Guidance. It is to be read together with the Additional Guidance and other guidance. It
identifies the "central question" as being:

". . . whether taking into account the overall context it is established that the risk to each family member
resulting from the LES's employment is such that the circumstances are 'exceptional' so as to justify their
relocation to the UK with LES outside the usual rules."

46 There is then a table setting out where decision makers should look for information or material in order
to form their assessment and how to approach their decision. At the head of the table there is the following
statement:

"Security concerns. Is the risk to the additional family member(s) assessed as “high”, “immediate”, and
“specific”, and “related to the work undertaken by the LES”?"

These quoted words and passages are obviously drawn directly from the wording in the Additional
Guidance shown above with underlining. Both documents, therefore, seek to apply the same risk
threshold. The table goes on to set out the factors to be taken into account in assessing the general threat
against a principal, the general threat against family members, and then whether there is a high,
immediate, specific threat against family members and whether that threat was linked to the applicant's


-----

work for HMG. Against that threshold, the February 2022 Panel considered that BA did not meet the
criteria. (See paragraph 11(a) of the February 2022 decision).

47 Ms Naik makes a number of submissions in relation to this guidance in support of her contention that
an inconsistent and/or inappropriate higher standard of risk was applied in assessing the situation in
February 2022. First, it is said that the test to be applied is that in the Principal Guidance. However, as
explained above, that would give decision makers very little guidance as to the level of risk that would be
required to be shown before the discretion could be exercised in a person's or an additional family
member's favour. When pressed to identify what threshold ought to have been required if not the 'high,
immediate, specific' threshold in the Factors and Additional Guidance, Ms Naik suggested that a general or
credible threat, as referred to in the first two entries in the table in the Factors Guidance, would suffice.
However, it is clear that the Factors Guidance is designed to take the decision maker through a series of
decision-making stages, first determining whether there is a general threat and culminating in an
assessment of whether there is a specific threat that is high and immediate. There is nothing to suggest
that the decision-maker can stop, having identified a mere general threat, and then exercise discretion in
the additional family member's favour. That would be inconsistent with the Factors Guidance which
indicates at the start of the table that the key question is whether the risk to the AFM (additional family
member) is high and specific in relation to the work undertaken by the LES.  It would also be inconsistent
with the Additional Guidance which does not refer to a general threat as being sufficient.  Finally, merely
being satisfied by the existence of a general threat would not, in the circumstances pertaining in
Afghanistan at the time, amount to an exceptional circumstance within the meaning of the Principal
Guidance.

48 Ms Naik then submits that the Additional Guidance in fact sets out two different tests applicable in two
different scenarios at different points in time. This submission was not developed orally to any extent. It is,
in my judgment, without merit. It appears to be based on a misreading of the Additional Guidance. There
is nothing in the wording of the Additional Guidance which would lead the reasonable reader to conclude
that two different tests are to be applied. The Additional Guidance merely states that there may be
exceptional circumstances where specific threats or intimidation exist, and that where that is the case an
assessment is to be made to determine whether that risk is high, immediate, etc. Clearly, the words "if the
risk is assessed as high and immediate" in the Additional Guidance refer back to the risk, identified at the
outset of the section, of specific threats or intimidation. In other words, there is just a single test in all cases
where reliance is placed on threats or intimidation.

49 Ms Naik's final point, related to the previous one, is that the test of “specific threat or intimidation” is
less onerous than that of “high, specific and immediate” required under the Factors Guidance. This point
falls away because, as set out in the preceding paragraph, the Additional Guidance does not set out two
tests; it is merely that the later passages identify the level which the specific threat or intimidation must
reach before the discretion can be exercised.

50 The second part of Ms Naik's challenge under Ground 2 is that the defendant perpetrated a _Lumba_
error. In that case, as is well-known, the SSHD applied an unpublished policy containing a blanket rule,
admitting of no exceptions, which was wholly inconsistent with a published policy. That was considered to
be unlawful. Ms Naik suggests that the Factors Guidance is a similarly inconsistent unpublished policy.

51 This ground is not expressly pleaded in the amended grounds. It was first raised in this way in the
skeleton argument.  Permission would not ordinarily be granted for a substantial amended ground such as
this so late in the day, particularly when the claimant has already amended his grounds following the grant
of permission.  No good reason has been submitted for its late inclusion. It is clearly a point that could
have been raised in the amended grounds lodged on 18 March 2022.  That said, I do not exclude the point
by reason of its late introduction.  It seems to me to be related to other points made by the claimant in
respect of the policies he said were applied. I can deal with the point on the merits.

52 In my judgment the point is without merit for the following reasons: whilst the defendant acknowledges
that the Factors Guidance is unpublished, it was not "applied" directly in reaching the February 2022
decision. It was merely a document to which the defendant had regard to aid its decision making. But, in


-----

any event, the real difficulty for Ms Naik in getting this point off the ground is that, as I found, there is no
inconsistency between the Factors Guidance and the Additional Guidance. In fact, the former sets out a
test for risk that is taken directly from the latter, as indicated by the use of quotation marks around key
words and passages.

53 For these reasons Ground 2 fails and is dismissed.

**Grounds 3 and 4.**

54 These grounds assert procedural unfairness. In particular it is said that the February 2022 decision
was unfair in that:

(i) The Panel proceeded on the basis that it was remaking the decision made in August 2021 when, in fact,
no "legally adequate decision had, in fact, been made." (See skeleton argument at paragraph 46)

(ii) Risk was assessed by reference to the unpublished Factors Guidance as a result of which BA was
unable to make representations and/or adduce information relevant to the Panel's decision; and

(iii) The Panel failed to consider further evidence provided by BA, and on his behalf, including in particular
the Foxley report.

The first of these points can be dealt with very briefly. The contention that there was no decision in respect
of BA as at August 2021 is unsustainable. There was a clear decision that BG and AG would be called
forward and that BA would not. That decision is clearly documented as set out in an email dated 25
August 2021 confirming that AG was clear to travel and that BA was not. The absence of written reasons,
which is explained by the circumstances at the time, does not mean that there was no decision.

55 The second point is related to the Lumba point made under Ground 2. Whilst the Factors Guidance
was not published, it was not a secret policy. The February 2022 Panel expressly referred to having taken
it into account, and a copy of it was, I understand, disclosed to BA subsequently. It was taken into
account, as already set out, in order to aid decision making. It was not directly applied as it was designed
to consider additional family members of ARAP applicants. It also reflected the test for risk set out in the
published Additional Guidance. As such, any representations that BA was able to make with the Additional
Guidance in mind would have been equally relevant to the Factors Guidance. It is difficult to see, in these
circumstances, what representations were not made that would have been made if the Factors Guidance
had been made available prior to the February 2022 decision, or how such representations could have
made any difference to the decision. Ms Naik did not attempt to identify any specific such representations.
In the circumstances I see no arguable basis for contending that there was any substantive unfairness, or
that BA was prejudiced by the Panel having regard to the Factors Guidance.

56 It is the third point which is, perhaps, Ms Naik's principal point on this ground, and this relates to the
defendant's refusal to take account of the Foxley report, or any evidence of post-evacuation developments.
In explaining its decision the defendant said this in its letter dated 11 February 2022:

"We can now confirm that our client, the FCDO, does not agree to take into account the evidence
referenced in these letters when remaking the decision of 22 November 2021. The decision of 22
November 2021, which my client has agreed to remake, reconsidered the decision not to call forward your
client during the evacuation, taken in August 2021. In particular, the decision making Panel considered
whether your client qualified to be called forward for evacuation in August 2021 during the Operation Pitting
LOTR arrangements which ended with the evacuation on 28 August 2021.

The Panel considered your client's relationship with, and dependency on, his principal, BG, but did not take
into account the risk/security threat your client claimed he faced as a result of his role as BG's bodyguard.

As set out in our letter of 8 February 2022, having regard to various matters, including the grant of
permission by Fordham J on 21 December 2021, my client agrees to remake that decision taking into
account risk. However, this decision will be remade on the facts and evidence that were before the
decision maker in August 2021, and the decision making Panel on 22 November 2021. My client is not
prepared to take into account new evidence which was not before the decision makers, and which refers to


-----

alleged events and incidents post-dating the evacuation (such as the alleged incident described at
paragraphs 12ff of BA's witness statement dated 19 January 2022).

We do not consider this would be appropriate, particularly when the decision we made is whether your
client qualified to be called forward during the evacuation in August 2021 under arrangements which have
since ended."

57 There is no direct response to that letter in the papers before me. There is an email from the claimant's
advisers to the Administrative Court in which it is said that:

"There remains a dispute between the parties as to the ambit of the reconsideration specifically whether
evidence served on her on 9/10 February should be taken into account. The defence solicitors have
confirmed that the FCDO does not intend to take into account that evidence."

58 It is noteworthy that no specific issue was taken with the defendant's proposal to “remake” the decision
as to whether BA qualified to be called forward during the evacuation in August 2021. Ms Naik submits
that it is unfair to restrict evidence in the way that the defendant did. Given the circumstances that
pertained as at 23 to 24 August 2021, she submits it was plainly unrealistic for the claimant to have been
able to adduce any evidence of risk, even assuming he was aware that the LOTR process existed, which
he did not. As the Panel had regard to its own expertise and knowledge of Afghanistan, it was unfair not to
consider the Foxley Report, which provides expert opinion relevant to the issues of risk which the Panel
was considering. Ms Naik's skeleton argument appears to cast some doubt on the experience and
knowledge claimed by the Panel, although this was not a point pursued with any vigour, or at all, in oral
submissions.

59 Mr Brown submits that in this particular context where a bespoke procedure was developed to remake
the August 2021 decision, it was open to the defendant to adopt the procedures that it did. There was a
rational explanation for deciding the matter by reference to what the evidence was at August 2021, and
there was no obligation to consider evidence of developments thereafter, or the Foxley Report. As stated
by Mr Hall:

"The Panel was intended to ensure that we had taken the correct decision in August 2021 [not to call BA
forward for evacuation] rather than to provide BA with a new opportunity to adduce new evidence and
additional information."

There is, says Mr Brown, no unfairness in any of this. Insofar as BA wishes to rely on any up-to-date
evidence, or the Foxley Report, he can do so in the context of any of the established routes for seeking
leave to enter the UK.

**Grounds 3 and 4 – Discussion.**

60 In Lloyd v McMahon [1987] AC 625, Lord Bridge said at 702H:

"My Lords, the so-called rules of natural justice are not engraved on tablets of stone. To use the phrase
which better expresses the underlying concept, what the requirements of fairness demand when anybody,
domestic, administrative or judicial, has to make a decision which will affect the rights of individuals
depends on the character of the decision-making body, the kind of decision it has to make and the
statutory or other framework in which it operates . . ."

In the present case the particular context was, as already discussed, that of a bespoke procedure to
remake a decision made in difficult circumstances in August 2021. It was open to the defendant to
approach that decision on the basis of the evidential position as it was, or could reasonably and realistically
have been, as at that point in time, but having regard to a matter, namely risk, that was not considered the
first time around. I accept Mr Brown's submission that there was no obligation in these circumstances to
take into account evidence of the position after the evacuation window. Clearly such evidence would not
have been available at the time, and to take it into account now would involve making a fresh decision in
different circumstances, rather than remaking the decision based on the position as it was in August 2021.


-----

61 Ms Naik submits that the defendant's approach could give rise to an absurdity in that if the risk position
had materially altered since August 2021, the defendant could have decided to grant LOTR to someone
who was no longer deserving. That, of course, is a hypothetical situation and in the circumstances is a
somewhat unlikely one. Decision makers do sometimes have to reach decisions, or choose to reach
decisions on the basis of the position as it was at a given point in time, and in doing so eschewing
subsequent developments. That is not intrinsically unfair; it all depends on the purpose and context of the
relevant decision. Ms Naik's unlikely scenario of the undeserving applicant does not make it so. Insofar as
the risk position has materially worsened, then of course it would be open to BA to make an application
under established routes, and no unfairness would arise by having been refused LOTR under the terms of
this bespoke process to remake the August 2021 decision.

62 The Panel was entitled to have regard to its own knowledge and experience of the situation in
Afghanistan. In doing so, the Panel in February 2022 was effectively recreating the situation into August
2021, which comprised a Panel, including Mr Hall, who had relevant experience and knowledge of
Afghanistan. That did not oblige the Panel to have regard to the Foxley Report, or to evidence of
subsequent developments. Ms Naik submits that there was inconsistency in the defendant's position and
that the Panel did take account of evidence provided in October 2021 as to BA's family situation and the
risks he faced. However, such evidence was largely, if not entirely, comprised of evidence as to the
situation as it would have been in August 2021. The nature of BA's familial connections would be the
same, as would evidence as to the nature of the work he did for BG, which gave rise to the risk relied upon.
There is no inconsistency on the part of the defendant taking such evidence into account whilst
disregarding evidence of subsequent developments.  The Panel gave careful consideration to the specific
threat faced by BA. It concluded that, whilst there was evidence of a general threat to judges, there was no
evidence of any specific threat to BA linked to, or as a result of, BG's work. That was a conclusion that the
Panel was, in my judgment, entitled to reach.

63 Grounds 3 and 4, therefore, also fail and are dismissed.

_______________

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the Judgment or
part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

