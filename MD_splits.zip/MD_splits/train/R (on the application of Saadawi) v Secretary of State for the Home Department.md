# R (on the application of Saadawi) v Secretary of State for the Home
 Department [2017] EWHC 3032 (Admin)

Queen's Bench Division, Administrative Court (London)

Judge Markus QC (sitting as a High Court Judge)

29 November 2017Judgment

**Ms Catherine Robinson (instructed by Lupins) for the Claimant**

**Mr William Hansen (instructed by Government Legal Department) for the Respondent**

Hearing date: 7 November 2017

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Upper Tribunal Judge Markus QC:**

1. In this judicial review the Claimant challenges the Defendant's decision dated 23 May 2016 that he is
not a victim of human trafficking.

2. The facts relating to his claim that he was a victim of human trafficking are largely set out in the
Claimant's witness statement of 11 November 2015 which he submitted in support of his asylum claim and
which are not materially in dispute, at least for the purpose of these proceedings.

3. The Claimant is an Egyptian national, born on 15 October 1989. His father died in January 2011. The
Claimant is the eldest son of his family and, when he completed his military service in 2011, he tried to find
a job to support the family. He was unable to find a job in Egypt but heard of one with a businessman in
Qatar. The Claimant stated in his witness statement: “I was so desperate that I did not really see any
choice in the matter so I accepted the job. As the eldest son, it was my responsibility to help the family.”
The businessman arranged the Claimant's travel to Qatar.

4. In Qatar the Claimant worked initially for the businessman, called Abdullah, and for a while for
Abdullah's relative, Mansour. He worked long hours for little and irregular payment, and he had no days off
or holidays. The Claimant said that he wanted to leave but felt unable to do so because he needed the
money to send to his family.

5. After some time, Abdullah told the Claimant that he was going to the UK and wanted the Claimant to
come with him. He told the Claimant that he would be paid more and would have less work to do. In his
statement the Claimant commented that Abdullah was a powerful man, from the royal family in Qatar, and
“there was no saying no to those people”. The Claimant was issued with an Overseas Domestic Worker
Visa for a Private Household on 28 October 2013, valid until 28 April 2014.

6. In November 2013 the Claimant followed Abdullah to the UK, was met at the airport and was taken to
Abdullah's flat. The Claimant gave his passport to Abdullah, so that Abdullah could “sort out the
paperwork”, and never saw it again. The Claimant did not have a bedroom and slept on the floor. Each
day he worked from 6am until the early hours of the following morning. He prepared food, cleaned, washed
and ironed for Abdullah and two other people who were staying in the flat. He did not have fixed working


-----

hours. He had no day off or holidays. He was paid £140 per month but not until March or April 2014.
Abdullah said he would pay more later. In April 2014 the Claimant made enquiries about the money he
was owed and Abdullah told him that they would be travelling back to Qatar in June and he would be paid
then. At around the same time the Claimant enquired about his visa, which was due to expire. Abdullah
was annoyed but said that he would take care of it all and the Claimant need not worry.

7. On an occasion in June 2014 Abdullah and the Claimant argued about work and Abdullah hit the
Claimant on the head with his shoe. Abdullah's relatives stopped him from hurting the Claimant more. The
Claimant said that he was crying from pain but also because he was humiliated. The Claimant said, in his
statement, that “Abdullah was threatening me that he would put me in prison and that he would make me
pay, either in this country, Qatar or Egypt.” The Claimant told Abdullah he did not want to work for him any
more and Abdullah said that he would report the Claimant to the Egyptian authorities and he would be
arrested.  The relatives tried to calm down Abdullah and the Claimant went to bed. The next day the
Claimant left because of his fear that Abdullah would act on his threats and because of the humiliation he
had suffered.

8. The Claimant spoke no English, did not know the area and had less than £50. He lived on the streets
for about three months. He then met someone who helped him and gave him somewhere to live. The
Claimant applied for a job in a restaurant but was arrested by enforcement officers and was then detained.
He claimed asylum on 16 July 2015. Whilst in detention the Claimant tried to self-harm and was taken to
hospital on 6 August 2015. The Claimant was released from detention on 10 August 2015.

9. On 13 November 2015 the Claimant consented to being referred into the National Referral Mechanism.
The Defendant was the competent authority responsible for the decision-making under that procedure. On
24 November 2015 the Defendant decided that there were reasonable grounds to believe that the Claimant
was a potential victim of human trafficking.  On 23 May 2016 the Defendant reviewed the case and
decided that, on the balance of probabilities, there were not sufficient grounds to believe that the Claimant
had been a victim of trafficking. That is the decision which is the subject of this claim. Permission to apply
for judicial review was granted at an oral hearing on 13 December 2016 by Natalie Lieven QC sitting as a
deputy high court judge.

10. In the meantime, on 3 June 2016 the Defendant had refused the Claimant's asylum claim. The Firsttier Tribunal (Immigration and Asylum Chamber) (“FTT”) heard that appeal on 21 August 2017 and, by
decision promulgated on 31 August 2017, dismissed it.  A decision on the Claimant's application for
permission to appeal to the Upper Tribunal is pending.

11. A preliminary issue arose, which I dealt with at the outset of the hearing before me on 7 November, as
to whether the hearing should proceed in the light of the pending application for permission to appeal to the
Upper Tribunal. The Secretary of State submitted that I should adjourn the case so as to avoid the risk of
inconsistent decisions but the Claimant wanted the hearing to proceed. I decided to proceed with the
hearing. Although there was overlap between the subject-matter of the judicial review and the appeal, they
concerned different decisions and the issues were not the same. There was a risk of inconsistent
decisions whichever case was decided first, but this case was ready to proceed, and it was right that the
Claimant should have his claim determined.

**Legal and policy framework**

12. On 17 December 2008 the UK ratified the Council of Europe Convention on Action against Trafficking
in Human Beings (“the Convention”). The purposes of the Convention are set out in Article 1:

“a. to prevent and combat trafficking in human beings, while guaranteeing gender equality;

b. to protect the human rights of the victims of trafficking, design a comprehensive framework for the
protection and assistance of victims and witnesses, while guaranteeing gender equality, as well as to
ensure effective investigation and prosecution;

c. to promote international cooperation on action against trafficking in human beings.”

13 Th d fi iti f h t ffi ki i A ti l 4 i l d


-----

“a. 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt
of persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of
deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other
forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or
the removal of organs.

b. The consent of a victim of “trafficking in human beings” to the intended exploitation set forth in
subparagraph (a) of this article shall be irrelevant where any means set forth in subparagraph (a) have
been used;”

14. The Council of Europe's Explanatory Report to the Convention includes the following:

“74. In the definition, trafficking in human beings consists in a combination of three basic components,
each to be found in a list given in the definition:

     - the action of: “recruitment, transportation, transfer, harbouring or receipt of persons”;

     - by means of: “the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of
the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person”;

     - for the purpose of exploitation, which includes “at a minimum, the exploitation of the prostitution of others
or other forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery,
servitude or the removal or organs”. “

…

83. By abuse of a position of vulnerability is meant abuse of any situation in which the person involved has no real
and acceptable alternative to submitting to the abuse. The vulnerability may be of any kind, whether physical,
psychological, emotional, family-related, social or economic. The situation might, for example, involve insecurity or
illegality of the victim's administrative status, economic dependence or fragile health. In short, the situation can be
any state of hardship in which a human being is impelled to accept being exploited…

84. A wide range of means therefore has to be contemplated: … or abusing the economic insecurity or
poverty of an adult hoping to better their own and their family's lot. However, these various cases reflect
differences of degree rather than any difference in the nature of the phenomenon, which in each case can
be classed as trafficking and is based on use of such methods.

85. The purpose must be exploitation of the individual…

…

89.  Nor does the Convention define “forced labour”…

90. Article 4 ECHR prohibits forced labour without defining it. The authors of the ECHR took as their
model the ILO Convention concerning Forced or Compulsory Labour (No. 29) of 29 June 1930, which
describes as forced or compulsory “all work or service which is exacted from any person under the menace
of any penalty and for which the said person has not offered himself voluntarily.” In the case _Van der_
_Mussele v Belgium (judgment of 23 November 1983, Series A, No. 70, paragraph 37) the Court held that_
“relative weight” was to be attached to the prior-consent criterion and it opted for an approach which took
into account all the circumstances of the case. In particular it observed that, in certain circumstances, a
service “could not be treated as having been voluntarily accepted beforehand.” It therefore held that
consent of the person concerned was not sufficient to rule out forced labour. Thus, the validity of consent
has to be evaluated in the light of all the circumstances of the case.

…

95. The ECHR bodies have defined “servitude”. The European Commission of Human Rights regarded it
as having to live and work on another person's property and perform certain services for them whether


-----

paid or unpaid, together with being unable to alter one's condition (Application No. 7906/77, D.R.17 p.59;
see also the Commission's report in the Van Droogenbroeck case of 9 July 1980, Series B, Vol. 44 p.30,
paragraphs 78 to 80). Servitude is thus to be regarded as a particular form of slavery, differing from it less
in character less than in degree. Although it constitutes a state or condition, and is a “particularly serious
form of denial of freedom” (Van Droogenbroeck case, judgment of 24 June 1982, Series A, No.50, p.32,
paragraph 58), it does not have the ownership features characteristic of slavery.”

15. The National Referral Mechanism (“NRM”) is a non-statutory framework for identification of and support
for victims of human trafficking. It was introduced in 2009 to meet the UK's obligations under the
Convention. It has since been amended following the **_[Modern Slavery Act 2015. Referrals are made to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
one of two Competent Authorities. The Competent Authority for immigration purposes is the Home Office.
There is a two stage process under the NRM. First the Competent Authority must decide if there are
reasonable grounds to believe that a person has been victim of trafficking. Cases which pass that test are
subject to a substantive “Conclusive Grounds” decision as to whether the person is in fact a victim. If a
negative decision is reached at either stage, the Convention imposes no further impediment to the person's
removal from the UK. Where there is a conclusive decision that the person is a victim of trafficking, that
does not necessarily give rise to a right to remain in the UK. Article 14 of the Convention provides that a
renewable residence permit shall be issued to victims in two situations: to co-operate with the authorities
for the purpose of criminal proceedings or investigation; and where the Competent Authority considers their
stay is necessary owing to their personal situation.

16. The Home Office has produced guidance on the Convention designed to provide information for staff
in competent authorities to help them decide whether a person referred under the NRM is a victim of
trafficking. The Guidance in force at the time of the decision in this case was 'Victims of modern slavery –
Competent Authority guidance', version 3.0 dated 21 March 2016.

17. The Guidance states that

“The essence of human trafficking is that the victim is coerced or deceived into a situation where they are
exploited.”

18. Referring to Article 4(a) of the Convention, the Guidance notes that human trafficking consists of three
basic components: action, means and exploitation, and repeats the definition of each in paragraph 74 of
the Explanatory Report (cited at paragraph 14 above). In relation to exploitation, the Guidance includes
the following:

“Trafficking: exploitation – forced labour

…

For forced labour within the home, see the domestic servitude section.

As with other forms of trafficking related exploitation, a high level of harm and control or coercion is needed
to trigger the UK's obligation under the Council of Europe Convention on Action against Trafficking in
Human Beings.

Forced labour represents a severe violation of human rights and is a restriction of human freedom.

The International Labour Organisation (ILO) defines forced work as:

'All work or service which is exacted from any person under the menace of any penalty and for which the
person has not offered himself voluntarily.'

This definition is a useful indication of the scope of forced labour for the purposes of human trafficking.
Siliadan v France 2005 (Application no. 73316/01) European Court of Human Rights took this as the
starting point for considering forced labour threshold and held that for forced labour, there must be work:

- exacted under the menace of any penalty which is performed against the will of the person concerned,
that is, for which the person has not offered themselves voluntarily

Forced labour cannot be equated (considered) simply with either:


-----

     - working for low wages and/or in poor working conditions

     - situations of pure economic necessity, as when a worker feels unable to leave a job because of the real
or perceived absence of employment alternatives

…

Trafficking: exploitation – domestic servitude

Domestic servitude often involves people working in a household where they are:

      - ill treated

     - humiliated

     - subjected to exhausting working hours

     - forced to live and work under unbearable conditions

     - forced to work for little or no pay

The problems of domestic workers held in servitude are made worse by the fact it is often very difficult for
them to leave their employers and seek help. Abusive employers create physical and psychological
obstacles by, for example, instilling fear in the domestic slave by threatening them, or their relatives, with
further abuse or deportation, or by withholding their passport.”

19. The Guidance includes a section headed “Myths about modern slavery”. It states that it is a myth that
a person is not being coerced if they did not take opportunities to escape, because the reality is that there
are many reasons why someone may choose not to escape an exploitative situation including the belief
that the trafficker will fulfil their promise. It also states that it is a myth that a person is not a victim of
trafficking if they say they have a better life than previously. The reality is that some people are willing to
tolerate their situation because they may perceive it as a 'stepping stone' to a better future and may
compare it favourably to experiences at home, this does not mean that they are not a victim of trafficking.

**The decision**

20. The Conclusive Grounds decision in this case referred to and cited from relevant passages of the
Convention and its Explanatory Report, the Guidance and the International Labour Organisation's Forced
Labour Convention. There is no suggestion by the Claimant that the Defendant misdirected herself as to
the legal framework or the components of human trafficking. The decision referred to objective evidence
(the US State Department Trafficking in Persons report) which confirmed that modern slavery is prevalent
in Egypt, Qatar and the UK and that they are countries where individuals are subject to exploitation.

21. The decision letter noted that the Claimant had provided an internally consistent account of his
employment. The underlying facts relied on by the Claimant were accepted. The letter noted the three part
definition of trafficking (action, means and purpose) and then explained the decision as follows:

“Action – part 'a'

In order to be considered to meet part 'a' you must have been subjected to an act of
transportation/recruitment/transfer/

harbouring/receipt.

You state that you were offered employment in Qatar by a man named [Abdullah]. He arranged your
journey and you subsequently travelled to Qatar to work for him. For the first three months you worked for
his cousin Mansour. You then worked for Abdullah in Qatar for seven or eight months before travelling to
the UK to work for him here. You therefore claim you were subjected to acts of recruitment, transportation,
transfer and receipt.

It is, therefore, considered that you meet part 'a' of the definition.

Means – part 'b'


-----

In order to be considered a victim of trafficking you must have been
transported/recruited/transferred/harboured/received:

“by means of threat or use of force or other form of coercion/of abduction/of fraud or deception/of abuse of
power/of a position of vulnerability/of giving or receiving payments or benefits to achieve the consent of a
person having control of another person”.

You state that you were unable to find employment in Egypt and as the eldest male in your family you felt it
was your role and responsibility to support your family. Consequently you agreed to move to Qatar to take
up employment with Abdullah. You therefore state that you were recruited, transported, transferred and
received whilst in a position of vulnerability.

It is therefore considered that you meet part 'b' of the definition.

Purpose – part 'c'

In order to be considered to meet part 'c' you must have been subjected to an act of
recruitment/transportation/transfer/

harbouring or receipt for the purpose of exploitation.

In applying part 'c' consideration must be given to whether you were
recruited/transported/transferred/harboured/received for the purpose of forced labour.

22. The decision letter referred to the definitions of forced labour, including that it must be work exacted
under the menace of penalty which is performed against the will of the person concerned, and that it does
not equate simply with working for low wages or in poor working conditions or situations of pure economic
necessity, and continued as follows:

“You state that you preformed a variety of work including washing cars, carrying the shopping, building
tents at picnics and feeding the animals. You detail that you worked long exhausting hours on a daily basis
and were not awarded any time off. You further detail that you were not regularly paid on time and would
be paid when your employer chose to pay you. You therefore claim you were subjected to forced labour.

However, in considering this it is noted that by your own admission you accepted the job with no
knowledge of what it would be and without even knowing what your salary would be. You detail that you
did so because you were the eldest son so felt it was your responsibility to help your family.

You further detail that despite that fact you were paid whenever your employer felt like it you felt you had
no choice other than to stay as you needed whatever money you could get to send to your family.

In considering your account in line with the definition of forced labour highlighted above, it is not accepted
that the work was exacted under menace of penalty or performed against your will. It is believed that
although the working conditions were poor and your wages were low, that there was nothing to stop you
from leaving this employment other than the fact you felt there were no other employment alternatives. As
such you remained in this employment out of a duty to try and support your family.

It is, therefore, considered that you do not meet part 'c' of the definition of forced labour.”

23. The letter next addressed whether the Claimant was recruited, etc, for the purpose of domestic
servitude. It referred to the definitions of domestic servitude and that the problems are made worse by the
fact it is often very difficult for the worker to leave and seek help because employers create physical and
psychological obstacles by, for example, instilling fear in the domestic slave by threatening them with
further abuse or deportation or by withholding their passport. The letter summarised the work which the
Claimant was required to do and explained the conclusion on the issue as follows:

“… it is considered that whilst your employment conditions were far from ideal you were in no way forced
into doing this work or forced to remain in this employment. You chose to remain in this employment due
to the lack of viable employment alternatives and due to the fact you felt a responsibility to provide for your
family.


-----

In considering the incident where your employer beat you, it is believed that this was a one off incident in
which he lost control and is not believed to be part of any controlling measures to keep you in employment.
Furthermore, the fact his relatives held him back and calmed him down shows they did not tolerate this
behaviour and this reaffirms the belief that it was not used as any sort of method to control you.

It is noted that you were able to maintain contact with your family during your employment through a SIM
card provided to you by your employer. It is also considered that after your employer beat you and you
decided you could no longer remain in that situation, that you were simply able to walk away and leave his
employment.

It is therefore considered that there was no force involved to keep you in this employment and it is believed
that you undertook this employment through your own free will. As such it is not accepted that you were
subjected to domestic servitude.

It is, therefore, considered that you do not meet part 'c' of the definition for domestic servitude.”

**Discussion and conclusion**

24. Ms Robinson, on behalf of the Claimant, contends that the facts clearly showed that the Claimant was
exploited by way of forced labour or domestic servitude and any other decision is irrational. She submits
that the decision fails correctly to apply the Guidance, including the ILO guidance.

25. Ms Robinson highlights the following aspects of the Claimant's factual case: he felt that he had no
effective choice but to work for Abdullah, given his responsibility for his family and that Abdullah was a
powerful man; he felt he had to accept the job in the UK because of the offer of more money; Abdullah had
kept the Claimant's passport and became angry when asked what was to happen about extending his visa;
the Claimant was not paid in the UK until April and then only extremely low wages; the amount of work,
lack of holiday or time off; and the sleeping arrangements. She submits that he could not be treated as
having consented to the situation. According to the “common myths” section of the guidance, it was not
open to the Defendant to take into account that the Claimant could have left, as he had felt that he had no
option but to work for Abdullah and because he had hoped that he would receive the wages due.

26. Ms Robinson referred to the decision of the European Court of Human Rights in Van Der Mussele v.
Belgium (1984) 6 EHRR 163, which said at paragraph 37 that work will not have been given voluntarily
where the burden imposed “was so excessive or disproportionate to the advantages attached”. She notes
that this test was approved in Chowdury v. Greece (application no 21884.15). She says that in the present
case the burden of the work imposed on the Claimant was wholly disproportionate to any benefit conferred.

27. Moreover, she submits that the Defendant's conclusion that the Claimant's work was not extracted
under menace of penalty was irrational. She says the Defendant has failed to consider that the Claimant
was subject to a subtle form of force in that he was dependent on his employer for his visa and his
employer was a powerful man to whom he could not say no. The Claimant had said that he felt insulted
and humiliated by Abdullah.

28. On behalf of the Defendant, Mr Hansen accepts that the subject-matter of this case calls for high
intensity of review or “anxious scrutiny”: R (BG) v. Secretary of State for the Home Department _[2016]_
_EWHC 786 (Admin). He submits that, applying that degree of scrutiny, the decision was not irrational. In_
particular, he referred me to BG at [56]-[58] in which Mr Justice Cranston explained the correct approach
as follows:

“56. The intensity of judicial review always varies with the context. Here the subject matter and the possible
engagement of a person's Article 4 ECHR rights mean that this is an area where the intensity of review is
high. Anxious scrutiny has been used as the term to characterise that standard. But anxious scrutiny must
be applied in a realistic manner, taking account of the decision-making context. As Munby J expressed it
on one occasion, anxious scrutiny does not mean that the court “should strive by tortuous mental
gymnastics to find error in the decision under review when in truth there has been none”: _R (on the_
_[application of Sarkisian v. Immigration Appeal Tribunal [2001] EWHC Admin 486, [18]. Moreover, anxious](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0CC-00000-00&context=1519360)_
scrutiny can work both ways and the cause of those genuinely trafficked is not helped, for example, by


-----

undue credulity towards those advancing contrived or inconsistent stories: cf. R (on the application of YH
_[(Iraq)) v. Secretary of State for the Home Department [2010] EWCA Civ 116; [2010] 4 All ER 448, [24], per](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
Carnwath LJ.

57. In this case the complaint is not about the Secretary of State's policies but about how policies
compliant with Article 4 ECHR were applied in the claimant's case. So anxious scrutiny is used in
considering the grounds on which the decision itself may be reviewable. In _R (AA)(Iraq) v. Secretary of_
_State for the Home Department [2012] EWCA Civ 23 the Court of Appeal considered whether a trafficking_
decision was flawed on the Wednesbury ground of review: [62], [67]. From the outset, Wednesbury review
has been applied with variable intensity, depending on the subject matter. It is also hornbook law that a
decision-maker must take into account relevant considerations. That was recognised in Wednesbury itself:
_Associated Provincial Picture Houses Ltd v. Wednesbury Corporation_ [1948] 1 KB 223, 233–234. This
ground of review means the decision-maker must take into account considerations which are legally
relevant, not every consideration.

58. In R (on the application of YH (Iraq)) v. Secretary of State for the Home Department Carnwath LJ (with
whom Moore-Bick LJ and Etherton LJ agreed) said that the standard of anxious scrutiny meant “the need
for decisions to show by their reasoning that every factor which might tell in favour of an applicant has
been properly taken into account”: [24]. That passage was invoked in R (FM) and R (SF). In my view this is
nothing more than a traditional ground of judicial review, but applied with anxious scrutiny. Carnwath LJ
refers to factors “properly” taken into account, in other words those legally relevant. It is not the law that a
decision is flawed because every single factor in a party's favour, however trivial or incidental, has not been
taken into account. Rather, what a competent authority must do in this type of case is to take into account
relevant considerations expressly identified in the policies as well as those which, albeit not expressly
identified, are obviously material to a person's case.”

29. The issue for this court is whether, applying anxious scrutiny, it was properly open to the Defendant to
conclude on the balance of probabilities that the Claimant was not trafficked on the basis that the work was
not exacted under menace of penalty and was not involuntary. Ms Robinson does not dispute that this is
the task of the court, but her submissions have not in substance addressed the issue in that way. Rather,
she has in essence attempted to reargue the merits of the Claimant's case on the evidence that he was
trafficked.

30. The Defendant properly directed herself that “menace of penalty” need not be physical and could take subtler
forms. She found that there was none in this case. Ms Robinson says that the Defendant failed to address the
penalty which was constraining the Claimant, that being the risk of being in the UK illegally if he did not cooperate
with his employer. The problem with this submission is that it was not how the Claimant's case was presented and
the Claimant's evidence did not suggest that that was the position. Although the Claimant had asked Abdullah
about the extension of his visa and although Abdullah had reacted angrily, he also told the Claimant that he would
sort it out. There was no indication that the Claimant cooperated with Abdullah's wishes because of his concerns
about his visa and his immigration status. When he decided that he wanted to leave he did so without any apparent
concern in that regard. Moreover there can be no proper criticism of the Defendant's decision that the timing and
circumstances of the beating and threats on the Claimant's last day could not have been part of any controlling
measure to keep him in employment. The explanation given in the letter is clearly rational. The other factors relied
on by Ms Robinson (poor pay, living conditions, excessive work load, etc) could not have amounted to menace of
penalty.

31. As for the question of consent, the Defendant accepted the Claimant's explanation that he worked for
Abdullah because of his duty to support his family but did not accept that this, in the circumstances of the
case, negated his free will. I reject Ms Robinson's submission that the finding of vulnerability should have
been carried through to that on exploitation. The Defendant found the Claimant was vulnerable because
he could find no work in Egypt and was desperate to support his family. This vulnerability and the fact that
the Claimant ended up working in poor conditions for low wages does not of itself mean that he was
trafficked for the purpose of exploitation by way of forced labour or domestic servitude. As the Guidance
makes clear, working for low wages or in poor conditions and situations of economic necessity, are not to


-----

be equated with forced labour. In this case, the Defendant concluded that, regardless of what the work
involved or the pay, the Claimant was willing to take it so that he could help his family.

32. In Van der Mussele the Court did not lay down a general principle that a disproportionate burden
would always amount to forced labour. It is necessary to have regard to all the circumstances of the case.
The Defendant did so here.

33. The other cases referred to by Ms Robinson are examples of the application of the established
principles to the particular facts. In Siliadin v. France (2006) EHRR 16 the applicant was a 15 year old girl
when she started to work for her employers. She worked non stop for 15 hours a day without any rest days
and without pay, without education, without identity documents and without her immigration status having
been reconciled. She escaped once but returned, in obedience to her uncle, on the understanding that her
immigration status would be regularised. The situation persisted for several years. The European Court of
Human Rights found that, although the applicant was not threatened by a penalty, she was in an equivalent
situation in terms of the perceived seriousness of the threat. The court took into account that the applicant
was an adolescent girl in a foreign land, unlawfully present and in fear of arrest. Her employers nurtured
that fear by the fact that she had no resources and no friends or family to help, while leading her to believe
that they would regularise her stay. The Court said that she was “clearly deprived of her personal
autonomy”. The facts of that case are very far indeed from those here.

34. Mr Robinson also relies on Chowdury to show that prior consent does not exclude the classification of
forced labour particularly because a situation can change so that what started as being voluntarily offered
might cease to be so. The Defendant made no error in that regard. The decision letter addressed the
Claimant's circumstances at the outset and during the period of his employment. The facts of Chowdury,
where the workers were made to work in extreme physical conditions, subject to constant humiliation,
guarded with armed guards, and at risk of arrest, detention and deportation, simply serve to underline the
weakness of the Claimant's case.

35. Domestic servitude is an aggravated form of forced labour. In fairness to Ms Robinson she did not
press this aspect of her case with great enthusiasm and, in my judgment, she was right not to do so. The
Court in Siliadin said that includes “in addition to the obligation to provide services to another ... the
obligation on the 'serf' to live on the other's property and the impossibility of changing his status”. The facts
did not indicate that it was made very difficult for the Claimant to change his status. On the contrary, on
the first occasion that he wished to leave his employer, he did.

36. The decision letter shows that the Defendant properly directed itself as to the legal criteria in the light
of the guidance, and considered the relevant factors. The Claimant disagrees with the Defendant's
interpretation of the facts. I am satisfied, however, that the Defendant's decision was clearly within the
range of decisions open to a rational decision-maker.

37. Consequently, this claim is dismissed.

**End of Document**


-----

