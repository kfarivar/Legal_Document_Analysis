# R v Brecani [2021] All ER (D) 62 (May)

[2021] EWCA Crim 731

Court of Appeal, Criminal Division

EnglandandWales

Lord Burnett CJ, Fulford LJ and Jeremy Baker J

19 May 2021

**Evidence – Admissibility – Admissibility, at criminal trial, of Single Competent Authority's decision that**
**defendant victim of modern slavery**
Abstract

_Case workers in the Single Competent Authority established by the Home Office were not experts in human_
_trafficking or_ **_modern slavery (whether generally or in respect of specified countries) and, for that fundamental_**
_reason, they could not give opinion evidence in a trial on the question whether an individual was trafficked or_
_exploited. Accordingly, the Court of Appeal, Criminal Division, in dismissing the defendant's appeal against his_
_conviction for conspiracy to supply cocaine, held that a judge had been right to exclude: (i) a conclusive grounds_
_decision which the Single Competent Authority had made, for administrative purposes and on the balance of_
_probabilities, and which had concluded that the defendant was a victim of_ **_modern slavery; and (ii) the Annex_**
_attached to it. Further, the court held that the judge had also been right to exclude evidence from an expert witness_
_who the defendant had commissioned, concerning his defence of_ **_modern slavery under_** _[s 45(4) of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_ **_Modern_**
**_Slavery Act 2015. The court held that the defendant's conviction was safe. Further, it refused leave to appeal_**
_based on the ground that defendant's case should have been severed from the trial of his co-defendants, holding_
_that it was desirable for co-defendants in a broad alleged conspiracy to be tried together, and that the judge's_
_decision could not be criticised._
Digest

The judgment is available at: [2021] EWCA Crim 731

**Background**

The Home Office was charged, for administrative purposes, with determining whether a person was a victim of
**_modern slavery. It had established a Single Competent Authority with case workers who considered the question_**
at two stages. The first was to decide whether there were reasonable grounds to suspect that a person might be a
victim of modern slavery. The second was to make a 'conclusive grounds' decision, on the balance of probability,
whether a person was or was not a victim of modern slavery.

The defendant, then aged 17, was convicted of conspiracy to supply cocaine and he was sentenced to three years'
detention. The defendant had applied for his case to be severed from the trial of 13 co-defendants, to await the
conclusive grounds decision of the competent authority. However, the judge had been unpersuaded.

Prior to his conviction, the defendant had relied on _[s 45(4) of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_ **_[Modern Slavery Act 2015 (MSA 2015) as a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
defence, contending that he had done the act 'as a direct consequence of [his] having been, a victim of slavery or a
victim of relevant exploitation' and that 'a reasonable person in the same situation … and having [his] relevant


-----

characteristics would do that act.' 'Relevant characteristics' meant 'age, sex and any physical or mental illness or
disability'; and 'relevant exploitation' was exploitation which was 'attributable to the exploited person being, or
having been, a victim of human trafficking' (s 45(5)).

The prosecution had had to disprove the s 45 defence, to the criminal standard. The trial had been underway before
the conclusive grounds decision had been made. On receipt of that decision, the prosecution had reviewed the
matter and had decided to continue with the prosecution. In the event, the judge had excluded both the conclusive
grounds decision and the expert evidence of Mr B, whom the defendant had commissioned.

The defendant's application for leave to appeal against conviction was referred to the full court by the single judge.

**Issues and decisions**

(1) Whether a conclusive decision, made for administrative purposes by the Single Competent Authority (applying
the balance of probabilities), that a person was a victim of modern slavery was admissible in evidence in a criminal
trial. If so, whether the conclusive grounds decision in the present case (see [12] of the judgment) and its Annex
should have been admitted at the trial. Further, whether the expert evidence of Mr B should also have been
admitted.

The judge had been right to exclude the conclusive grounds decision, the Annex attached to it and Mr B's evidence.
Leave to appeal on those evidential grounds would be granted, but the appeal would be dismissed. On an objective
view of the evidence, the s 45 defence had been comprehensively demolished by the prosecution. There was no
question that the conviction was safe (see [76] of the judgment).

The conclusive grounds decision in the present case was a statement of opinion based on the decision maker's
evaluation of the evidence placed before her. The Annex contained a summary of that evidence and an exploration
of the inconsistencies patent in it. Save for limited purposes (discussed in Blackstone Criminal Practice 2021 at
F11.2 and F11.3), non-expert opinion evidence was not admissible in a criminal trial. The general rule was that
witnesses could give evidence of what they saw, heard, perceived etc. By contrast, expert opinion was admissible
in criminal proceedings at common law if: (i) it was relevant to a matter in issue in the proceedings; (ii) the witness
was competent to give that opinion; and (iii) it was needed to provide the court with information likely to be outside
the court's own knowledge and experience (see [43], [44] of the judgment).

In R v Turner[1975] 1 All 1975] 1 All ER 70, Lawton LJ had held that an expert's opinion had been admissible to
furnish the court with scientific information which had been likely to have been outside the experience and
knowledge of a judge or jury and that, if on the proven facts, a judge or jury could form their own conclusions
without help, then the opinion of the expert was unnecessary. Lawton LJ had made two other observations of
importance. First, that the facts on which an expert founded an opinion had to be proved by admissible evidence. In
many cases, some of those facts were likely to be admitted by the prosecution or defence as the case might be, or
allowed in via hearsay provisions. However, when an expert report contained a controversial account from the
defendant that might not be so. Second, before a court could assess the value of an opinion it had to know the facts
on which it was based (see [44], [45] of the judgment).

[A number of primary and secondary legislative provisions governed the admissibility of expert evidence. Section 30](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YG0-TWPY-Y1FY-00000-00&context=1519360)
[of the Criminal Justice Act 1988 (CJA 1988) provided that an expert report was admissible in criminal proceedings](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FC00-TWPY-Y0VP-00000-00&context=1519360)
whether or not the author gave oral evidence, but if the expert did not testify in court, then the leave of the court was
required to admit a report. In making that decision, the court was required to have regard to factors set out in the
section. The admissibility of expert evidence was governed by Pt 19 of CrimPR (see [46] of the judgment).

The opinion of the case worker, if admissible, would be relevant to the decision the jury had to make. The first of the
three general criteria for admissibility would be satisfied (see [44], [51] of the judgment).

The next criterion was whether relevant expertise had been demonstrated. The old authorities talked of 'men of
science' and much of the discussion about expertise revolves around recognised disciplines in science or medicine.
Yet it was well recognised that it was possible to become an expert by practice and experience. There were


-----

circumstances in which police officers, for example, could give evidence about gangs and drugs if they
demonstrated the necessary expertise through experience (see [52] of the judgment).

In the present case, and in respect of decisions by case workers assigned to the Competent Authority generally, no
information was available on which it was possible to determine whether and in what area the case worker might be
an expert (see [53] of the judgment).

In respectful disagreement with the Divisional Court in _Director of Public Prosecutions v M[2020] EWHC 3422_
(Admin),the present court did not consider that case workers in the Competent Authority were experts in human
trafficking or **_modern slavery (whether generally or in respect of specified countries) and, for that fundamental_**
reason, they could not give opinion evidence in a trial on the question whether an individual was trafficked or
exploited. It was not sufficient to assume that, simply by virtue of the fact that because administrators were likely to
gain experience in the type of decision-making they routinely undertook, they could be treated as experts in criminal
proceedings. The position of those decision-makers was far removed, for example, from experts who produced
reports into air crashes for the Air Accident Investigation Branch of the Department of Transport which were
admissible in evidence in civil proceedings. Moreover, none of the requirements of CrimPR 19, designed, in part, to
ensure that the person giving evidence was an expert, understood he or she was acting as such and understood
the obligations of an expert to the court, had been complied with (see [54] of the judgment).

The evidence would have to be truly expert and not a vehicle to enable the expert to stray into the territory of the
jury by expressing his or her personal opinion about whether an account was credible or inconsistencies immaterial.
As the present case vividly illustrated, the conclusion on whether the prosecution had disproved the s 45 defence
would call for an assessment of all the relevant evidence which the jury was well-placed to make. In the right case,
that evidence might include expert evidence of societal and contextual factors outside the ordinary experience of
the jury (see [58] of the judgment).

There were further impediments to the admissibility of the conclusive grounds decision and attached Annex beyond
the lack of expert status of the case worker. First, in so far as it relied on, and in the Annex recited, evidence given
by the defendant in various accounts, including his explanations of inconsistencies, it was all hearsay, in respect of
which no application had been made, nor would one have succeeded. Second, and perhaps more fundamentally,
the various accounts given by the defendant which featured in the Annex were uninfluenced by the material
contained in his phone; nor was the case worker's opinion informed by that material. An opinion based on the
defendant's various descriptions of his journey and treatment which had taken no account of that material had been
based on misinformation about the facts and had failed to take account of clearly relevant matters. As such, it had
been valueless and inadmissible, even if relevant expertise had been established (see [45], [61] of the judgment)

Yet more fundamentally, the decision of the jury whether the prosecution had negatived the s 45 defence had
required its members to have been sure that the account given by the defendant in his evidence in chief (and thus
the core account on which the case worker had proceeded) had been untrue. That was not an issue on which the
evidence of the case worker could have given them any assistance. They had been well placed to form their own
conclusions without help from the case worker, given the nature of the evidence in the case (see [62] of the
judgment).

Furthermore, on the facts, Mr B had not demonstrated sufficient knowledge of modern slavery in the context of the
present case or that he had considered the range of facts necessary for reaching an informed opinion. Mr B had not
met the applicant when he provided his first report (2 March 2020). Instead, for the relevant history he had been
dependent on a clinical psychological report by Dr M, dated 14 February 2020. the material provided to the court in
the present case had afforded an insufficient basis to determine that Mr B possessed, by virtue of study or
experience, sufficient knowledge of **_modern slavery, as opposed to other specialist subjects, that meant his_**
opinion on the present subject would be of value to the jury (see [70]-[75] of the judgment).

_[R v Turner [1975] QB 834, [1975] 2 WLR 56, [1975] 1 All ER 70 applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KN0-TWP1-60PG-00000-00&context=1519360)_


-----

_R v MK (also known as D); R v Gega (also known as Maione)_ _[[2018] EWCA Crim 667, [2018] 3 WLR 895, [2018] 3](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SWS-B301-DYBP-M1GG-00000-00&context=1519360)_
_[All ER 566, [2018] All ER (D) 10 (Apr) applied](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SWS-B301-DYBP-M1GG-00000-00&context=1519360)_

_Director of Public Prosecutions v M_ _[[2020] EWHC 3422 (Admin), [2021] 1 WLR 1669 not followed](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61HR-GVX3-GXFD-8184-00000-00&context=1519360)_

_R (on the application of B) v Merton London Borough Council_ _[2003] EWHC 1689 (Admin),_ _[[2003] 4 All ER 280,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61KV-00000-00&context=1519360)_

_[[2003] All ER (D) 227 (Jul) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JWK1-DYBP-N3M0-00000-00&context=1519360)_

_R v N; R v E_ _[[2012] EWCA Crim 189, [2012] 3 WLR 1159, [2012] All ER (D) 128 (Feb) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5513-TB01-DYBP-N1F7-00000-00&context=1519360)_

_Rogers v Hoyle [2015] QB 265, considered_

_R (on the application of M) v Hammersmith Magistrates' Court and Another (2017)_ _[[2017] EWHC 1359 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NTV-JXY1-F0JY-C125-00000-00&context=1519360)_
considered

_R v GS_ _[[2018] EWCA Crim 1824, [2018] 4 WLR 167, [2018] All ER (D) 90 (Aug) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_

_R v DS_ _[[2020] EWCA Crim 285, [2021] 1 WLR 303, [2021] 1 All ER 1233 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:627S-BFT3-GXFD-80RS-00000-00&context=1519360)_

_VCL and another v United Kingdom_ _[[2021] ECHR 77587/12, [2021] All ER (D) 87 (Feb) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:622N-S9J3-GXFD-841G-00000-00&context=1519360)_

(2) Whether leave to appeal should be granted on the ground that the judge should have severed the indictment
and delayed the defendant's trial.

Leave to appeal would be refused on the present ground. It was desirable for co-defendants in a broad alleged
conspiracy to be tried together, not least to avoid witnesses having to give the same evidence on multiple
occasions. Delaying the trial of all would have been unacceptable, particularly as defendants, including the
defendant, had been remanded in custody awaiting trial. In the judge's view, that last feature had been especially
potent, given that the defendant was not an adult. While it would be desirable, and the prosecution would accept,
that a trial should normally await a conclusive grounds decision, there would be cases where competing factors
drove a different conclusion. So much was recognised by the Strasbourg court. The present case was one where
the judge had had to balance a range of factors. His decision had been entirely understandable. The decision had
eventually come while the trial had been in progress and it had been considered by the prosecution in accordance
with the relevant prosecutorial guidance and the relevant authority. It followed that thejudge's conclusion on the
present issue could not be criticised (see [11] of the judgment).

_R v Joseph_ _[[2017] EWCA Crim 36, [2017] 1 WLR 3153, [2017] All ER (D) 100 (Feb) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MVY-VXX1-DYBP-N4DD-00000-00&context=1519360)_

_VCL and another v United Kingdom_ _[[2021] ECHR 77587/12, [2021] All ER (D) 87 (Feb) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:622N-S9J3-GXFD-841G-00000-00&context=1519360)_

Nicholas Lobbenberg QC (instructed by GT Stewart Solicitors and Advocates) for the defendant.

Benjamin Douglas-Jones QC and Rebecca Austin (instructed by The Crown Prosecution Service) for the Crown.
Carla Dougan-Bacchus Barrister.

**End of Document**


-----

