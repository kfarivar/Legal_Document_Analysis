# R v AH [2022] EWCA Crim 1024

Court of Appeal, Criminal Division

Davis LJ, Wall J, and HHJ Montgomery

21 June 2022Judgment

Non-counsel application.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

HER HONOUR JUDGE MONTGOMERY:

1 We have considered whether or not the applicant in this matter should be identified or his details
anonymised in the giving of this judgment. For the reasons that will become clear in consequence of our
refusal to renew his application for leave to appeal, we do not believe that his name should be removed
from the record, and it may be published accordingly.

2 On 28 January 2016 in the Crown Court at Canterbury the applicant (then [an age]), pleaded guilty to
two counts of possession with intent to supply Class A drugs at Counts 1 and 2 of the indictment, and one
count of acquiring criminal property at Count 3. On 15 March 2016 before the same court the applicant
was sentenced to 3 years and 9 months' detention in a young offender institution, concurrent, on Counts 1
and 2. He received no separate penalty in respect of the Count 3. On the same date he received a further
12 months' detention, consecutive to the above, for unrelated matters committed for sentence and
consequently not the subject of this application.

3 The applicant now seeks to renew his application for an extension of time in excess of six years from the
date of his convictions to seek permission to appeal against those convictions after refusal by the single
judge.

The offences

4 On 28 January 2015 plain clothes officers noted a stationary vehicle in Fleming Way, Folkestone, which
was suspected of being involved in supply of the Class A drugs. Uniformed officers were called to the
scene. The applicant was found in the back seat of the vehicle. On the back seat, next to the applicant
and in the footwell at his feet there were a number of bags containing around 60 small wraps of cocaine
and heroin. In total, the approximate value of the drugs was around £1,500. The other occupants of the
vehicle were found to be in possession of further drugs and mobile telephones. When the applicant was


-----

searched in custody, he was also found to be in possession of £320 in cash, which was tucked into his
sock. He gave a "no comment" interview.

5 He pleaded not guilty upon first arraignment, lodging a defence statement asserting that he had been
acting under duress, but changed his pleas to guilty before trial.

6 While the applicant was serving his sentence, deportation proceedings were commenced against him.
On 31 January 2020 the applicant, having by then served his sentence, was detained by the immigration
authorities for removal from the United Kingdom. This led to a referral to the National Referral Mechanism
(hereafter NRM) by immigration solicitors in February 2020. On 6 October 2020 the NRM reached a
conclusive grounds decision that the applicant had been a victim of trafficking at the time of his offending in
2015.

Grounds of appeal

7 1. In his application for permission to appeal against conviction the applicant contends that he has been
confirmed as a victim of trafficking exploited by a criminal gang between 2012 and the end of 2015.

2. When the offences were committed in January 2015, he was [an age] and acting under compulsion due
to his status as a victim of trafficking to supply drugs.

3. A referral should have been made to the NRM at an early stage of the proceedings and certainly no
later than service of the defence statement. Had that been done and the conclusion reached then that was
reached in 2020, the CPS would have been under a duty to review the case. If they had decided to
proceed, then an application to stay should have been made.

4. It is submitted that this chain of events would in one way or another have led to the applicant not facing
trial on these matters.

5. It is therefore submitted that the convictions are unsafe.

The respondent's notice

8 The respondent acknowledges that the applicant was at the material time a victim of trafficking and that
there was a nexus between the trafficking and criminal acts and that the indications of trafficking were
present and overlooked. The Crown and/or the defence should have identified the need for a referral to
the single competent authority (hereafter SRA) via the NRM. The respondent concedes that the
prosecutorial decision that was made was made in the absence of an acknowledgement that the applicant
was a victim of trafficking. However, they do not concede that this is a case where the CPS would or might
well not have prosecuted the applicant, as it is not a case where his criminality or culpability was
extinguished or significantly diminished so that the prosecution would not have been in the public interest.
Therefore, it is not a case where there was any abuse of process in maintaining the prosecution.

Discussion

9 By the European Convention on Action Against Trafficking in Human Beings, (hereafter ECAT) Article
26, the UK:

"[...] shall, in accordance with the basic principles of its legal system provide for the possibility of not
imposing penalty on victims for their involvement in unlawful activity to the extent that they have been
compelled to do so".

10 The UK now provides protection for victims of trafficking under Article 26 in England and Wales through
section 45 of the Modern Slavery Act of 2015. Section 45 is not retrospective. For offences committed
before section 45 came into force, such as these, protection is provided exclusively through the Crown

Prosecution Service non‑prosecution guidance on "Suspects in a Criminal Case who might be Victims of

Trafficking or Slavery" (R v AAD and Ors _[[2022] EWCA Crim 106).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_

11 Where the prosecutorial decision concerning charge or the maintenance of a prosecution was or is
impeachable on the grounds of public law, it could historically and can now, following AAD, be challenged
through an application for a stay of the proceedings based on a species of abuse of process which gives a


-----

power of review of the prosecutorial decision to the crown court and could give rise to a conviction being
unsafe. An application for leave to appeal will succeed if this court sees fit to receive fresh evidence of: (1)
an appellant's trafficking status; (2) the nexus of trafficking to the criminal act, and (3) finds that the
dominant force of compulsion in the context of the offence was sufficient to reduce the defendant's
criminality or culpability to or below a point where it was not in the public interest for him to be prosecuted
(R v G(S) [2019] 1 Cr App R 7), and/or that the "Prosecutorial judgment has not been properly carried out,
and had it been properly carried out, would or might well have resulted in a decision not to prosecute", (R v
_LM and Ors_ _[2010] EWCA Crim 2327)._

12 A conclusive grounds decision via the NRM may be received by the court de bene esse where it
considers the safety of a conviction where a person's trafficking status has been overlooked in the court or
in the context of abuse proceedings in the crown court when reviewing the decision of a prosecuting
authority. It is then necessary to consider that in the context of the offender's circumstances and the
offence.

13 The applicant was by 2015 [an age]. He had started offending four years before being recruited in
2015 for the county lines supply of drugs. He had supportive parents who he did not tell about his
offending, notwithstanding the support that they had offered in the past. He appeared not to have sought
any assistance from the youth offending service officers, who will have supervised his earlier referral
orders, his solicitors or the authorities. After his arrest for the instant offences he was not so adversely
affected by the influence of others that he was too traumatised or too afraid to raise the defence of duress.
Unlike many county lines offenders, he made significant amounts of money from his criminal activities,
£500 to £700 per week, plus a supply of cannabis for his own use. He was not threatened to work extra
days. He was paid extra money or in clothing, such as tracksuits or trainers to do so. He accepted that he
was persuaded by those enticements. However, he also described that when he had tried "occasionally"
to leave, threats were made about finding him.

The single judge's refusal

14 All of these matters were considered by the single judge, who provided detailed reason for his refusal
to extend time. Whilst accepting the very proper concessions made by the respondent, he concluded:

"Even if the court admitted and accepted the fresh evidence upon which you now seek to rely, your
conviction is not arguably unsafe. Yours is not a case where the dominant force of compulsion was
sufficient to reduce your criminality to a point where it was not in the public interest for you to be
prosecuted, or that you might well not have been prosecuted in the public interest.

I take account of the fact that you were a child at the time, that you were seventeen and a half when you
committed the index offences. You commenced offending four years earlier. You had caring parents who
tried to support you, including sending you away from the area. You had reasonable opportunities to
remove yourself from your situation, including seeking help from the YOS when you were under
supervision. You continued to offend and volunteered to do extra work dealing drugs for additional reward.

Your attitude to your offending was described by the writer of the pre‑sentence report dated 14/1/16

prepared for the further offences as 'blasé'. There is no merit in an appeal. I refuse your application for an
extension of time."

15 We concur with his view and his reasons. We have received and considered the "fresh evidence" of
the conclusive grounds for finding the applicant to have been a victim of trafficking de bene esse. We too
have placed that finding into the context of the offending and the applicant's circumstances. This is not a
case where his criminality or culpability was extinguished or significantly diminished so that the prosecution
would not have been in the public interest. Nor is this a case where the Crown Prosecution Service would
or might well not have prosecuted the applicant. It is not a case where there was any abuse of process in
bringing or maintaining the prosecution. The applicant cannot satisfy the requirement upon him to
demonstrate that that his guilty pleas fall into any of the categories of cases in which a conviction following
a guilty plea might be found unsafe, as discussed in _R v Tredget_ _[[2022] EWCA Crim 108. We have](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
indicated we do not concur with the assertion that the applicant's convictions are unsafe. While we


-----

consider the explanation adequately explains the delay of over six years and the extension of time is
allowed, it is clear from what we have said that we consider the appeal to have no substantive merit, and
refuse leave to renew it.

__________

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the Judgment or
part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

