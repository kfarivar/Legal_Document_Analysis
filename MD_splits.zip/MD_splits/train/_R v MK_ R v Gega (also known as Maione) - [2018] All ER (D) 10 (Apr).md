# *R v MK; R v Gega (also known as Maione) [2018] All ER (D) 10 (Apr)

[2018] EWCA Crim 667

Court of Appeal, Criminal Division

EnglandandWales

Lord Burnett CJ, Andrews and Martin Spencer JJ

28 March 2018

**Criminal law – Defences – Defence for slavery or trafficking victims who commit an offence**
Abstract

_Criminal law – Defences._ _[Section 45 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_ **_Modern Slavery Act 2015 did not implicitly require the defendant to_**
_bear the legal or persuasive burden of proof of any element of the defence. The Court of Appeal, Criminal Division,_
_held that the burden on a defendant was evidential; it was for the defendant to raise evidence of each of the_
_elements and for the prosecution to disprove one or more of them to the criminal standard in the usual way._
Digest

The judgment is available at: [2018] EWCA Crim 667

**Background**

The defendants were Albanian nationals who claimed to have been victims of trafficking. The defendant in the first
action, MK, was convicted of conspiracy to supply a class A drug (cocaine) and of being in possession of an identity
document with improper intention. The defendant in the second action, PG, was convicted of a single count of
possession of an identity document with improper intention. The defendants sought to rely on the statutory defence
[afforded to victims of trafficking under s 45 of the Modern Slavery Act 2015 (s 45).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)

The judges concluded that, first, a defendant bore an evidential burden to raise the issue whether she was a victim
of trafficking or slavery. Second, having successfully done so, it was for the prosecution to prove, beyond
reasonable doubt, that she was not. Third, if the prosecution succeeded in that, the s 45 defence would not avail the
defendant. Fourth, however, if the prosecution failed in that respect, the legal or persuasive burden of proof in
respect of the other elements of the defence fell on the defendant. Therefore, if the defendant was over 18 years
old, she must prove on the balance of probabilities that: (i) she was compelled to commit the offence; (ii) the
compulsion was as a direct consequence of her being or having been a victim of slavery or relevant exploitation;
and (iii) a reasonable person in the same situation as her and having her relevant characteristics would have no
realistic alternative to doing the act which constitutes the offence. MK appealed against her conviction and her
sentence, and PG appealed against her conviction.

**Issues and decisions**

(1) Whether the legal (or persuasive) burden of proof rested on the defendant when a defence was raised under s
45, or whether the defendant bore only an evidential burden with the prosecution having to disprove to the criminal
standard one or more of the elements of the defence.


-----

Even if the prosecution had proved the ingredients of the criminal offence to the criminal standard, s 45 stated that
a person 'is not guilty', and so was innocent of the offence, if all the specified elements under s 45 were established.
That was the language of a defence, not an excuse or proviso. The status of a person as a victim of trafficking or
slavery did not automatically exempt her from criminal liability, or permit the commission of acts that would
otherwise be criminal. The opening words of the section were a strong indication that imposing a reverse legal or
persuasive burden would be tantamount to requiring a defendant to prove specific elements establishing her
innocence (see [25] of the judgment).

While it was correct to say that the defence was only available to a person who was or had been a victim of slavery
or human trafficking, the structure of s 45 only introduced that issue at a later stage of the analysis: in the case of
an adult defendant, after it had been established that the person was aged over 18 and that they had done the act
which constituted the offence under compulsion. It was s 45(1)(c) which posed the question whether the act done
under compulsion had been a direct consequence of the person being or having been a victim of slavery or human
trafficking (see [26] of the judgment).

That subsection raised two issues, namely: (i) whether the defendant was or had been a victim of slavery or human
trafficking; and (ii) if so, whether there was a direct causal link between the defendant's status as a victim and the
act done under compulsion (see [27] of the judgment).

If the legal burden of proof was reversed, there was a danger of frustrating Parliament's objective that victims
(including children) of trafficking or slavery should be protected against the further stigma of a criminal conviction for
an offence committed in consequence of their initial victimisation (see [36] of the judgment).

While, in some cases, it might be that the defendant was best placed to identify the circumstances of her personal
situation in order to bring herself within an exception relying on the elements of compulsion (where required), and
the direct link between the commission of the act and the defendant's current or former status as a victim of slavery
or trafficking. However, that did not affect the overall question of where the legal burden lay (see [37], [38] of the
judgment).

Further, the defence under s 45 was not established solely on the basis of evidence about what the defendant had
done and why the defendant had done it. There was an objective element, set out in s 45(1)(d) (or section 45(4)(c)
as applied to a child). That final element of the defence was the safeguard against a defendant being absolved from
liability for what otherwise would be a serious criminal offence simply because the jury could not be sure that her
account of being exploited and victimised was untruthful. It also served to safeguard against the twin dangers that:
(i) the defence under s 45 would be perceived as affording an easy means for an unscrupulous defendant to avoid
liability by making up a story about being trafficked or enslaved; and (ii) the apparent ease with which defendants
could set up a defence under the section would result in their controllers being encouraged, rather than
discouraged, to continue their exploitation, and through them commit offences (see [39] of the judgment).

Furthermore, reversing the persuasive burden on the issue of age would also appear to undermine the approach to
child victims required by _[art 13(2) of Directive (EU) 2011/36. Parliament could not have intended that such a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CV-00000-00&context=1519360)_
defendant should not have the benefit of any reasonable doubt on the issue of age. As the legal burden of proof in
respect of age rested on the prosecution, that was yet another indication that Parliament had not intend to shift the
burden of proof of the other elements of the defence under s 45 (see [42], [44] of the judgment).

Section 45 did not bear the interpretation urged by the prosecution upon, and accepted by, the judges below. It did
not implicitly require the defendant to bear the legal or persuasive burden of proof of any element of the defence.
The burden on a defendant was evidential. It was for the defendant to raise evidence of each of the elements and
for the prosecution to disprove one or more of them to the criminal standard in the usual way (see [45] of the
judgment).

_R v Edwards_ _[[1974] 2 All ER 1085 distinguished; Woolmington v DPP](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-618W-00000-00&context=1519360)_ _[[1935] All ER Rep 1 applied; R v DPP, ex p](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-20DC-00000-00&context=1519360)_
_Kebilene_ _[[1999] All ER (D) 1170 applied; R v Hunt](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DXH-MH00-TWP1-70RV-00000-00&context=1519360)_ _[[1987] 1 All ER 1 considered; R v Lambert](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4S32-G3C0-TWP1-61MM-00000-00&context=1519360)_ _[[2001] 3 All ER 577](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4HV7-56D0-TWP1-60CD-00000-00&context=1519360)_
considered; R v Makuwa _[[2006] All ER (D) 324 (Feb) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JT01-DYBP-N2J5-00000-00&context=1519360)_


-----

(2) Whether the defendants' convictions had been unsafe.

There was no suggestion by the prosecution that MK's conviction had been safe if the judge's direction on the
burden and standard of proof was wrong. Therefore, MK's appeal would be allowed and the conviction quashed
(see [50] of the judgment).

Despite the error in the direction to the jury concerning the burden of proof in relation to s 45, the evidence against
PG had been overwhelming and the conviction was safe. It was fanciful to suppose in her case that the niceties of
the legal burden of proof could have made any difference. In those circumstances, the appeal would be dismissed
(see [56] of the judgment).

Amjad Malik QC and Glenn Harris for MK.

Andreas O'Shea for PG.

John McGuinness QC and Ben Douglas-Jones QC for the Crown.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

