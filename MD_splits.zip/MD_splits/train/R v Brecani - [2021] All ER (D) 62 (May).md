# R v Brecani [2021] EWCA Crim 731

Court of Appeal, Criminal Division

Lord Burnett CJ, Fulford LJ and Jeremy Baker J

19 May 2021Judgment

**Nicholas Lobbenberg QC (instructed by GT Stewart Solicitors and Advocates) for the Applicant**

**Benjamin Douglas-Jones QC and Rebecca Austin (instructed by The Crown Prosecution Service) for**
the Respondent

Hearing date: 21 April 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**The Lord Burnett of Maldon CJ:**

1. Is a conclusive decision made for administrative purposes by the Single Competent Authority (part of
the Home Office), on written materials applying the balance of probabilities, that a person is a victim of
**_modern slavery admissible in evidence in a criminal trial? The second issue is whether expert evidence of_**
Craig Barlow commissioned by the appellant should have been admitted at trial. The judge excluded both.
A further question concerns whether the judge should have severed the indictment and delayed the trial of
the appellant.

2. On 26 March 2020 the appellant was convicted of conspiracy to supply cocaine, a class A drug. He
was then aged 17. There were 13 co-defendants, ten of whom pleaded guilty to the same count, two were
convicted and one acquitted. The appellant was sentenced to three years' detention. He relied upon
section 45(4) of the Modern Slavery Act 2015 (“the 2015 Act”) as a defence, namely that he did the “act
as a direct consequence of [his] being, or having been, a victim of slavery or a victim of relevant
exploitation” and that “a reasonable person in the same situation … and having [his] relevant
characteristics would do that act.” “Relevant characteristics” means “age, sex and any physical or mental
illness or disability”; and “relevant exploitation” “is exploitation (within the meaning of section 3) which is
attributable to the exploited person being, or having been, a victim of human trafficking”: section 45(5).
The criteria for the application of the defence to adults are slightly different: section 45(1).

3. It is for the prosecution to disprove the section 45 defence to the criminal standard: _R v MK [2018]_
_EWCA Crim 667, [2019] QB 86._

4. The application for leave to appeal against conviction has been referred to the full court by the single
judge.

**The Modern Slavery Defence and Single Competent Authority**

5. In _R v Joseph and others [2017] EWCA Crim 36; [2017] 1 Cr App R 33, this court set out the_
background of international conventions dealing with the scourge of human trafficking and **_modern_**
**_slavery. It summarised the approach in domestic law, before the introduction of a statutory defence by the_**
2015 Act, to prosecuting those who had been trafficked. The courts had developed the common law of


-----

abuse of process in the context of prosecutorial discretion, to satisfy the international obligations of the
United Kingdom to refrain from prosecuting some victims of modern slavery in circumstances where there
was a sufficient nexus between the commission of the offence and relevant trafficking or exploitation: see
the Introduction and General Principles between [1] and [41]. At [3] the court noted that the 2015 Act sets
out clearly “the conditions which have to be satisfied respectively for adults and children where there is a
nexus between the trafficking and the crime committed.” The defence does not apply to the serious
offences specified in schedule 4, but conspiracy to supply Class A drugs is not one of them.

6. A person who establishes that he or she has been trafficked into the United Kingdom is treated
differently for immigration purposes from others and may be entitled to various forms of support. The
Home Office has established a National Referrals Mechanism to encourage official and charitable
organisations to refer trafficking cases for consideration. The Home Office is charged for administrative
purposes with determining whether a person has been trafficked or is a victim of modern slavery. It has
established a Single Competent Authority with case workers who consider the question at two stages. The
first is to decide whether there are reasonable grounds to suspect that a person may be a victim of
**_modern slavery. Temporary consequences relating to the treatment of the person flow from a positive_**
decision at this stage. The second is to make a “conclusive grounds” decision on the balance of probability
whether a person is or is not a victim of modern slavery.

7. The volume of cases considered by the Competent Authority is large. Official statistics show that in
2016 there were 3,804 referrals; in 2018, 6,986; in 2019, 10,627 and in 2020, 10,613. The Home Office
has issued guidance extending to 189 pages covering all aspects of **_modern slavery: see “Modern_**
**_Slavery: Statutory Guidance for England and Wales (under s. 49 of the_** **_Modern Slavery Act 2015) and_**
Non-Statutory Guidance for Scotland and Northern Ireland Version 2.1” of March 2021. At para 7.1 it
indicates that a reasonable grounds decision should be made within five days of a case being referred to
the Competent Authority with the conclusive grounds decision following no sooner than 45 days thereafter.
At para 14.77 that is explained further as requiring a conclusive grounds decision as soon as possible after
45 calendar days. Annex A sets out details of many kinds of exploitation commonly encountered, including
many specific to children. Annex E, starting at page 109, gives guidance to case workers on how to make
the decisions.

“Assessing credibility and other evidence during the decision-making process

14.1. SCA staff need to assess whether a potential victim's account of modern slavery is credible when
making a Reasonable Grounds and Conclusive Grounds decision.

14.2. Good practice in working with victims who have experienced trauma should be observed. See the
section on working with vulnerable people for more information. However, the need to take into account the
impact trauma is likely to have on the individual's ability to recall events does not remove the need to
assess all information critically and objectively when considering the credibility of a case.”

What follows is a comprehensive guide on a large range of factors that can inform the assessment of
credibility. At 14.93 the balance of probabilities is explained and at 14.94 the possibility of asking written
questions of the person concerned, or even conducting an interview, is described. All decisions are
checked with a second pair of eyes (para 14.113).

8. Annex H is concerned with the section 45 defence. It explains how the conclusion of the Competent
Authority may affect prosecutorial discretion whether to prosecute, cross refers to the Crown Prosecution
Service (“CPS”) prosecutorial guidance in suspected modern slavery cases, notes the different standards
of proof and observes that the criteria for the defence are not the same as the factors which inform a
conclusive grounds decision. It reminds decision makers to keep the CPS and court abreast of any
decision-making concerning someone who is or might be prosecuted.

9. The Competent Authority has struggled to keep up in the face of the expanding case load and
unwelcome delays have developed in the system. In this case, for example, there was a gap of 4½ months
between the reasonable grounds and conclusive grounds decisions although part of that delay was caused
by the appellant's solicitors seeking an extension of time and being given four extra weeks to provide


-----

information. The delays have had an impact on criminal proceedings. The CPS will ordinarily wait to know
the outcome of a referral to the Competent Authority before deciding to charge or continue proceedings
where it is suggested that the offence was committed because of relevant trafficking or coercive behaviour.
Moreover, it is not uncommon for the first intimation that a person has been a victim of modern slavery to
arise after being charged with a criminal offence (that is what happened in this case) or after the first
appearance at court and for the matter to be referred to the Competent Authority only then. The usual
expectation is that the criminal proceedings will then await the outcome of the referral because that
outcome will be considered by the CPS in deciding whether to proceed. The CPS is not bound by a
decision of the Competent Authority: _Joseph_ at [39]; see also _VCL and AN v United Kingdom_ App. Nos
77587 and 74603/12, 16 February 2021 at [162]. The Fourth Section of the Strasbourg Court confirmed
that as a matter of Convention law the prosecuting authority is not bound by such a decision but would
need a good reason to disagree with it. The court also indicated that “any decision on whether or not to
prosecute a potential victim of trafficking should – insofar as possible – only be taken once a trafficking
assessment has been made by a qualified person”. The “qualified person” referred to is an official within a
competent authority. The applicants in Strasbourg had been the two appellants in _R v N; R v Le_ _[2012]_
_EWCA Crim 189; [2013] Q.B. 379; [2012] 1 Cr. App. R. 35, and VCL, whose case was referred back to the_
Court of Appeal by the Criminal Cases Review Commission, was one of the appellants in Joseph.

10. In the case before us the trial was underway before the conclusive grounds decision was made. The
CPS was aware of the appellant's likely defence to the conspiracy. The prosecution had explored his
circumstances in detail, including a full examination of his phone, and both the specialist prosecutor who
dealt with potential modern slavery cases and counsel were confident that the prosecution could disprove
the defence. On receipt of the conclusive grounds decision, they reviewed the matter but decided to
continue with the prosecution.

**Severance**

11. The appellant applied for his case to be severed from the trial of the other defendants who were
contesting the matter, to await the conclusive grounds decision of the competent authority. The judge was
unpersuaded. It is desirable for co-defendants in a broad alleged conspiracy to be tried together, not least
to avoid witnesses having to give the same evidence on multiple occasions. Delaying the trial of all would
have been unacceptable particularly as defendants, including the appellant, were remanded in custody
awaiting trial. This last feature was, in the judge's view, especially potent given that he was not an adult.
Whilst it will be desirable, and the prosecution would accept, that a trial should normally await a conclusive
grounds decision there will be cases where competing factors drive a different conclusion. So much was
recognised by the Strasbourg Court in _VCL_ at [161]. This was one such case where the judge had to
balance a range of factors. His decision was entirely understandable.  The decision eventually came while
the trial was in progress and was considered by the prosecution in accordance with the relevant
prosecutorial guidance and the decision of the Strasbourg Court in Joseph. We do not think that the judge's
conclusion on this issue can be criticised. We refuse leave to appeal on this ground.

**The Conclusive Grounds Decision**

12. The decision is dated 3 March 2020 and was contained in a letter signed by a named “NRM Decision
Maker”. It referred to the earlier “reasonable grounds” decision of 14 September 2019 in the appellant's
case and continued:

“We have now assessed their case in more detail and based on the evidence we received, have decided
there are Conclusive Grounds to accept they are the victim of modern slavery.

Our Decision

We found the following types of exploitation occurred:

1. Forced Criminality in Albania from 2016 – 2019

2.  Forced Criminality in Albania and the UK in 2019”


-----

13. The letter continued by setting out some of the support available to the appellant and referred to a
“Decision Annex” which contained more detail about the decision. That set out the documents considered
by the decision maker. It then contained a section entitled “Modern Slavery Case Summary” which
summarised the account provided by the appellant through various intermediaries. It referred to a United
States Department of State report about Albania. It then considered in detail the appellant's account of
being forced into criminal activity in Albania and in the United Kingdom which it described as “plausible” but
noted a substantial number of inconsistencies in his accounts. It repeatedly used the phrase “the
explanation provided is considered to be a reasonable clarification of this inconsistency, and therefore, it is
held to not damage your credibility” or other similar words that suggest that the inconsistency in question
was not being held against him. Having set out the evidence the Annex concluded by saying that, overall,
his account was accepted. It was accepted that the appellant had been recruited in Albania by Jetmir
Cenaj, transported to the United Kingdom and kept in houses in both “Birmingham and Southend/Dartford”.
It was further accepted that he was forced into criminality against his will and was not paid.  The
conclusion was that “it is accepted the PV was a victim of modern slavery in Albania and in the UK during
2019 for the specific purpose of forced criminality.” PV, we infer, means “potential victim”.

**The facts as they emerged**

14. The trial concerned the activities of an organised crime group which, over the course of about six
months between 18 February and 21 August 2019, was involved in the supply of over £660,000 worth of
cocaine in Southend, Essex.

15. The individual at the head of the group was Vegim Sokoli, who had two right-hand men, Artur Gashi
and Jetmir Cenaj. They operated the graft phone which customers used to text in to order their drugs, and
which cell site evidence showed was normally based in Gravesend, Kent. Artur Gashi and Jetmir Cenaj
had three trusted lieutenants, Elidon Haxhiaj, Mohammed Rashid and Mohammed Uddin, below whom
was a series of seven runners, including the appellant.

16. Vegim Sokoli, in respect of whom there was an outstanding warrant of arrest, was an Albanian
national, as were Artur Gashi, Jetmir Cenaj and some of the runners, including the appellant.

17. At trial both Sali Veshi and the appellant accepted that they had acted as runners in the conspiracy,
either delivering the cocaine directly to the customers in Southend, or ferrying cocaine and monies to and
from other runners and those higher up the chain. Sali Veshi's defence was one of duress rather than, as
with the appellant, that his involvement in the conspiracy was as a direct consequence of having been the
victim of human trafficking under section 45(4) of the Modern Slavery Act 2015.

18. The appellant, together with Artur Gashi and Jetmir Cenaj, had been arrested on 21 August 2019 at 2,
Humber Road, Dartford, Kent. A search of the premises revealed a compressed block of just under half a
kilo of 87% purity cocaine with a street value of about £40,000.

19. The appellant was interviewed in the presence of a solicitor and an appropriate adult. He made no
comment during the interviews.

20. In his evidence at trial the appellant explained that whilst he was attending school in Albania he had
been approached by two young males on three separate occasions. On the first occasion he smoked some
cannabis which they had offered him. When they returned the next day they beat him up and he had to go
to hospital. He complained to the police. On the third occasion the two individuals asked him why he had
complained to the police and said that he would have to sell cannabis for them, before again beating him
up.

21. As a result, the appellant said that he began to sell cannabis for these two individuals and stopped
attending school. It was whilst this was happening that he said that he had first met Jetmir Cenaj. He
suggested that instead of being forced to sell cannabis in Albania, the appellant should come to the United
Kingdom, where he was living. He told the appellant that he would be looked after by the social services
and he could go to school. The appellant said that he discussed this with his family, who were initially
reluctant but then changed their minds and agreed to allow him to travel to the United Kingdom.  He was


-----

told to get 150 euros, a phone and some clothes. The appellant said that he had to beg his parents (a
doctor and a civil servant) to allow him to travel illegally to England.

22. He said that Jetmir Cenaj made the arrangements for the journey. He went to the bus station in
Albania, where a bus driver had prepared a place for him in the luggage compartment in which he stayed
over the course of the next three days. He was only allowed out for food, water and using the lavatory until
they arrived in Brussels. The bus driver took him to a hotel room where he remained for a week. He was
then taken to meet a lorry driver who drove him for about five hours to Calais where he was arrested by the
border police. The appellant said that on his release by the border police, he texted Jetmir Cenaj who
arranged for another man to take him to Rotterdam. There they met another lorry driver in the back of
whose lorry he was ferried over to England. The appellant left the vehicle in London.

23. Once in London the appellant said that he texted Jetmir Cenaj who arranged for two men to pick him
up and take him to a house in Mitcham, Surrey. Once there he was not allowed out and was told that he
had to repay the £15,000 cost of his travel to the United Kingdom. The appellant said that when he queried
this with Jetmir Cenaj, he was told that he would have to work cultivating cannabis in a house in
Birmingham. The appellant said that he thought that if he did not agree to this something bad would
happen to him. He was taken to Birmingham where he stayed in a locked house cultivating cannabis for a
period of about seven weeks, only being allowed out occasionally in the presence of others.

24. At the end of this period, and following a burglary at the property, he was told that he had to go to
another house, this time in Southend. He travelled there by taxi which was paid for by Jetmir Cenaj. He
was kept there for a couple of days before being told that he had to travel to another house in Dartford.
Once again his taxi fare was paid by Jetmir Cenaj. It was there that Jetmir Cenaj explained to him that he
would have to take cocaine to Southend and bring back money with him to the house in Dartford. The
appellant said that although he did not want to do this, he eventually agreed as a result of threats of
violence made by Jetmir Cenaj. He said that he would kill both him and his family if he did not do as he
was told until he had paid off his debt.

25. During cross-examination the appellant was tested on inconsistent accounts he had given about his
travel arrangements to the United Kingdom and what had happened to him since arriving.

26. When the appellant spoke to his social worker in September 2019 he had said that after having been
arrested in Calais, he had travelled to Rotterdam via Brussels, but subsequently when he spoke to officers
specialising in the detection of **_modern slavery, he had said that after his arrest in Calais he had gone_**
straight to Rotterdam.

27. Moreover, when he initially spoke to his social worker he said that he had only been in the United
Kingdom for about two months, including two weeks in London and two weeks in Birmingham. He said
that his family did not know where he was, whilst in subsequent conversations with his social worker and
others he had said that not only was he in contact with his cousin whilst he was here, but he had paid for
the taxi which transported him from London to Birmingham where he had stayed with his cousin for about a
week. In evidence the appellant asserted that he had been frightened when he was talking to the social
worker, who he agreed was there to assist him, and that consequently he had provided a false account to
the social worker.

28. In a more recent witness statement in February 2020, the appellant had stated that he had been
detained in a house in Mitcham for a period of about three weeks.

29. The appellant was also asked questions about the downloads from his mobile phone (not available to
others he had spoken to or the Competent Authority) which contradicted significant parts of his account of
his travel arrangements and both the conditions in which he was living whilst in the United Kingdom and his
attitude to those with whom he was in contact at that time.

30. The phone had no contact with anyone involved with the conspiracy until 26 May 2019, including three
different phones used by Jetmir Cenaj all of which had been in the United Kingdom since October 2017.


-----

31. On 19 April 2019, following his release by the border police in Calais, his phone was used to purchase
a train ticket to Paris. He could not explain that, nor why his phone was then used to track a route across
Paris to a coach station where, on 22 April 2019, it was used to purchase a ticket for a journey to Brussels
on the 23 April. A text was sent from the phone stating, “I got on the other bus. On my way to Brussels”.
There were screen shots on the phone of a hand holding a ticket from Calais to Paris on 19 April 2019; a
ticket for a second journey from Paris St-Lazare to Gaillon Aubervote and an annotated map of St Lazare;
an internet ticket in the appellant's name from Paris to Brussels via Lille and a hand holding his passport
(which he had asserted he left in Albania). The first time that the appellant's phone was cell sited in the
Netherlands was on 24 April 2019. On 27 April he sent his mother photographs of himself and his father in
Brussels. He claimed that the visit had taken place two years before and denied having taken the
photographs when he arrived in Brussels on 23 April. The phone was at the Hook of Holland on 25 April.
On the same day the appellant took a selfie video showing himself and another man smiling in the back of
a lorry. He also sent a message to his mother saying he had crossed the channel and was eating in a
restaurant near the house in which he was staying. He said he had money and had bought some clothes.
Between 25 April and 15 May his phone was cell sited not only in Mitcham but also in Tooting. He was in
contact with his family in Albania and with someone identified as “Uncle” on his phone but who he said was
a cousin. He had been in contact with Uncle when he was still on the Continent.

32. Between 15 May and 21 July the phone was cell sited in many locations across Birmingham and not
only the house.

33. In evidence the appellant denied that he had been in Paris and asserted that he knew nothing about
the use of his phone to purchase tickets to and from Paris. He denied that he made his way independently
from Calais to Paris and then to Brussels. He denied that he was making up being trafficked and the
simple explanation was that he came to the United Kingdom illegally to make money as a willing participant
in drug dealing.

34. The appellant was asked about a video which had been taken using his phone on 26 May 2019 whilst
he was in Birmingham, which appeared to show him as being happy and relaxed, rather than being
concerned about his “captivity”. He was also asked about a series of texts which were sent from his phone
on the evening of 17 June 2019, some of which were to members of his family, whilst others were making
arrangements for escorts to visit, including one which read “15 minutes for £50”. In evidence he
acknowledged sending messages to his family but he denied that he was responsible for those relating to
the escorts, asserting that someone else had used his phone to contact them. There were also messages
to escorts on 16 June. Photographs were exchanged of an escort, the appellant and another man. The
appellant's phone was also used to secure the services of escorts in Kent on 15 July and Birmingham three
days later. The phone contained images of the appellant facetiming a friend on 19 July apparently
enjoying himself.

35. The appellant was asked about a series of texts, which had been sent from his phone to his sister and
a friend, following the burglary at the house in Birmingham. He stated that “I wasn't caught, all their efforts
gone to waste.” and “… I was a guard, we could not finish it.” In evidence the appellant denied that these
texts suggested that he was a willing part of the venture and asserted that he wanted to reassure them that
he was alright following the burglary.

36. On 28 June the appellant had been in communication with Jetmir Cenaj's brother discussing trying to
secure a job with Jetmir in Southend and again on 9 July. There were other messages to him which did
not carry any hallmarks of a person under pressure or coercion.

37. Following initial denials, although the appellant conceded that his phone contained a smiling image of
himself taken in Southend holding a bundle of cash on 18 August 2019, he asserted that he had been
instructed to do this by those who were involved in the conspiracy. The appellant also admitted that he was
responsible for creating a note on his phone which read, “If you're caught this is what you say to the police”
namely, that he was coming to the United Kingdom because he had been forced to sell cannabis in
Albania. There was also a message saved on the phone before he left Albania with a script of what to say
to the police if he was arrested there for selling cannabis.


-----

38. The reality was that the content of the appellant's phone coupled with cell site evidence completely
undermined his defence under section 45 of the 2015 Act.

**Is the Conclusive Grounds decision admissible?**

39. The competing arguments are straightforward. Mr Lobbenberg QC submits that the Conclusive
Grounds decision is admissible as expert evidence and relies upon _DPP v M [2020] EWHC 344 Admin;_

[2021] 1 WLR 1669(Simler LJ and William Davis J) to that effect.

40. Mr Douglas-Jones QC for the prosecution argues that applying first principles relating to the
admissibility of expert evidence, neither the bare conclusive grounds decision, nor the underlying narrative,
were admissible in evidence before the jury. There is no basis upon which the case worker who made the
conclusive grounds decision can be regarded as an expert; the evaluation of the evidence was within the
ordinary knowledge of a jury, essentially determining credibility; and the decision was based on patently
partial and incomplete evidence. He recognises that the material was important for the purposes of the
CPS deciding whether a prosecution should be brought or continued and does not seek to disturb wellestablished practice of such information being placed before courts considering abuse of process, or the
safety of convictions when the defence was not raised. He submits that DPP v M was wrongly decided to
the extent that it concluded that such evidence was admissible.

_Discussion_

41. The question of the admissibility of the conclusive grounds decision was raised in passing in R v DS

[2021] 1 WLR 303, [2020] EWCA Crim 285 but not argued or decided: see [43]. In R v S(G) [2019] 1 Cr
App R 7, [2018] EWCA Crim 1824 the appellant sought to rely upon fresh evidence in this court in support
of an application for leave to appeal against a conviction from 2007. He sought to demonstrate that he had
been a victim of trafficking. The fresh evidence included a decision of the First-tier Tribunal which
accepted that he had been a victim of trafficking, a minute from the Competent Authority to the same effect
and a letter from the Home Office. In giving judgment of the court Gross LJ explained at [67] and [68] that
these materials could be admitted applying the test for fresh evidence found in section 23 of the Criminal
Appeal Act 1968 but continued, at [69], that no question of admissibility at trial had been raised where “to
put it no higher, the admissibility of both the decisions in question and the underlying reasoning must be
regarded as unlikely …" He added that it would have been likely on the facts of that case that, whatever
the technical admissibility at trial, had the decision been known at the time there would have been an
admission that the appellant had been recognised as a victim of trafficking. The issue of principle remains
undecided at this level.

42. In the trial of the appellant the central issue was whether the factual circumstances surrounding his
involvement in the conspiracy were such that the jury could be sure that involvement was not as a direct
consequence of his being, or having been, a victim of slavery or a victim of relevant exploitation. A
subsidiary issue concerned the conduct in those circumstances of a reasonable 17-year-old boy in the
same situation. The evidence available to the prosecution was such that there was no question of making
any admissions touching those issues.

43. The conclusive grounds decision, quoted in full at [12] above, is a statement of opinion based upon the
decision maker's evaluation of the evidence placed before her. The Annex contains a summary of that
evidence and an exploration of the inconsistencies patent in it.

44. Save for limited purposes (discussed in Blackstone Criminal Practice 2021 at F11.2 and F11.3), nonexpert opinion evidence is not admissible in a criminal trial. The general rule is that witnesses may give
evidence of what they saw, heard, perceived etc. By contrast, expert opinion is admissible in criminal
proceedings at common law if (i) it is relevant to a matter in issue in the proceedings; (ii) the witness is
competent to give that opinion; and (iii) it is needed to provide the court with information likely to be outside
the court's own knowledge and experience. (see Criminal Practice Direction V Evidence 19A: Expert
Evidence (CPD V Evidence 19A)). As Lawton LJ put it in R v Turner [1975] QB 834 at 841D to E:


-----

“The foundation for these rules was laid by Lord Mansfield in Folkes v Chard (1782) 3 Douglas KB 157 and
was well laid. 'The opinion of scientific men upon proven facts' he said 'may be given by men of science
within their own science.' An expert's opinion is admissible to furnish the Court with scientific information
which is likely to be outside the experience and knowledge of a judge or jury. If on the proven facts a judge
or jury can form their own conclusions without help, then the opinion of the expert is unnecessary. … The
fact that an expert has impressive scientific qualifications does not by that fact alone make his opinion on
matters of human nature and behaviour within the limits of normality any more helpful that that of jurors
themselves; but there is a danger that they may think it does.”

45. In the same case at page 840 Lawton LJ made two other observations of importance. First, that the
facts on which an expert founds an opinion must be proved by admissible evidence (840B). In many cases
some of those facts are likely to be admitted by the prosecution or defence as the case may be, or allowed
in via hearsay provisions. But when an expert report contains a controversial account from the defendant
that may not be so. Secondly, at 840E to F:

“Before a court can assess the value of an opinion it must know the facts upon which it is based. If the
expert has been misinformed about the facts or has taken irrelevant facts into consideration or has omitted
to consider relevant ones, the opinion is likely to be valueless. In our judgment, counsel calling an expert
should in examination in chief ask his witness to state the facts upon which his opinion is based. It is
wrong to leave the other side to elicit the facts by cross-examination.”

46. A number of primary and secondary legislative provisions govern the admissibility of expert evidence.
Section 30 of the Criminal Justice Act 1988 provides that an expert report is admissible in criminal
proceedings whether or not the author gives oral evidence but if the expert does not testify in court, then
the leave of the court is required to admit a report. In making this decision the court is required to have
regard to factors set out in the section. The admissibility of expert evidence is governed by Part 19 of the
Criminal Procedure Rules (“CrimPR”). In summary, part 19 sets out the expert's duty to the court (19.2),
the steps to be taken for the introduction of expert evidence (19.3), the duty to inform the expert that the
report has been served (19.5), the opportunity for the court to order a pre-hearing discussion of expert
evidence (19.6), the court's power to direct a single joint expert and the instructions to be provided to a joint
expert (19.7 and 19.8), the opportunity to withhold information from another party (19.9) and the power to
extend time (19.10).

47. CrimPR 19.4 prescribes the content of an expert's report. It provides:

“19.4.Where rule 19.3(3) applies, an expert's report must —

(a) give details of the expert's qualifications, relevant experience and accreditation;

(b) give details of any literature or other information which the expert has relied on in making the report;

(c) contain a statement setting out the substance of all facts given to the expert which are material to the
opinions expressed in the report, or upon which those opinions are based;

(d) make clear which of the facts stated in the report are within the expert's own knowledge;

(e) when the expert has based an opinion or inference on a representation of fact or opinion made by
another person for the purposes of criminal proceedings (for example, as to the outcome of an
examination, measurement, test or experiment) 
(i) identify the person who made that representation to the expert,

(ii) give the qualifications, relevant experience and accreditation of that person, and

(iii) certify that that person had personal knowledge of the matters stated in that representation;

(f) where there is a range of opinion on the matters dealt with in the report —

(i) summarise the range of opinion, and

(ii) give reasons for the expert's own opinion;


-----

(g) if the expert is not able to give an opinion without qualification, state the qualification;

(h) include such information as the court may need to decide whether the expert's opinion is sufficiently
reliable to be admissible as evidence;

(i) contain a summary of the conclusions reached;

(j) contain a statement that the expert understands an expert's duty to the court, and has complied and will
continue to comply with that duty; and

(k) contain the same declaration of truth as a witness statement.”

48. The requirement to give details of the expert's qualifications or relevant experience is needed to assist
the court to decide, if necessary, whether the evidence is admissible. CPR 19.4(1)(c) reflects the common
law position that the factual premises upon which the expert proceeds must be clear. All expert opinion is
dependent upon underlying factual premises. It is commonplace for the real issue in proceedings to be
determined by those underlying facts rather than the expert conclusion that flows from them. CPR
19.4(1)(f) requires an expert to confront that there may be a range of opinion and justify the conclusion
reached.

49. The Practice Direction draws together the applicable law relating to the admissibility of expert
evidence. PD 19A.4 recalls that reliability of an expert's opinion is a factor in determining admissibility and
then PD19A.5 sets out a series of factors to which a court should have regard, drawing heavily on the
report No. 325 of the Law Commission entitled: “Expert Evidence in Criminal Proceedings in England and
Wales” published in March 2011:

“19A.3 In the Law Commission report entitled 'Expert Evidence in Criminal Proceedings in England and
Wales', report number 325, published in March, 2011, the Commission recommended a statutory test for
the admissibility of expert evidence. However, in its response the government declined to legislate. The
common law, therefore, remains the source of the criteria by reference to which the court must assess the
admissibility and weight of such evidence; and CrimPR 19.4 lists those matters with which an expert's
report must deal, so that the court can conduct an adequate such assessment.

19A.4 In its judgment in R v Dlugosz and Others [2013] EWCA Crim 2, the Court of Appeal observed (at
paragraph 11):

'It is essential to recall the principle which is applicable, namely in determining the issue of admissibility, the
court must be satisfied that there is a sufficiently reliable scientific basis for the evidence to be admitted. If
there is then the court leaves the opposing views to be tested before the jury.'

Nothing at common law precludes assessment by the court of the reliability of an expert opinion by
reference to substantially similar factors to those the Law Commission recommended as conditions of
admissibility, and courts are encouraged actively to enquire into such factors.

19A.5 Therefore factors which the court may take into account in determining the reliability of expert
opinion, and especially of expert scientific opinion, include:

(a) the extent and quality of the data on which the expert's opinion is based, and the validity of the methods
by which they were obtained;

(b) if the expert's opinion relies on an inference from any findings, whether the opinion properly explains
how safe or unsafe the inference is (whether by reference to statistical significance or in other appropriate
terms);

(c) if the expert's opinion relies on the results of the use of any method (for instance, a test, measurement
or survey), whether the opinion takes proper account of matters, such as the degree of precision or margin
of uncertainty, affecting the accuracy or reliability of those results;

(d) the extent to which any material upon which the expert's opinion is based has been reviewed by others
with relevant expertise (for instance, in peer-reviewed publications), and the views of those others on that
material;


-----

(e) the extent to which the expert's opinion is based on material falling outside the expert's own field of
expertise;

(f) the completeness of the information which was available to the expert, and whether the expert took
account of all relevant information in arriving at the opinion (including information as to the context of any
facts to which the opinion relates);

(g) if there is a range of expert opinion on the matter in question, where in the range the expert's own
opinion lies and whether the expert's preference has been properly explained; and

(h) whether the expert's methods followed established practice in the field and, if they did not, whether the
reason for the divergence has been properly explained.”

50. Mr Douglas-Jones submits that the way in which the conclusive grounds decision and the Annex are
signed off makes it impossible to be sure who made the decision. We are prepared to assume for the sake
of argument that the named case worker was the decision maker. That named case worker hypothetically
would be called to give evidence in the trial to explain her decision, give evidence of the underlying factual
premises her opinion relied upon and be challenged in cross examination. A very few questions in crossexamination would have sufficed: (a) Does your conclusion depend upon accepting the defendant's
account? (b) You knew nothing of the evidence from his phone? (c) Do you accept that undermines your
conclusion? In reality, that position would never have been reached. Before calling the case worker as an
expert to give evidence, it would have been incumbent on the appellant's lawyers to alert her to the
evidence she did not consider and find out whether it would have affected her decision.

51. The opinion of the case worker, if admissible, would be relevant to the decision the jury had to make.
The first of the three general criteria for admissibility (see [44] above) would be satisfied.

52. The next criterion is whether relevant expertise had been demonstrated. The old authorities talk of
'men of science' and much of the discussion about expertise revolves around recognised disciplines in
science or medicine. Yet it is well recognised that it is possible to become an expert by practice and
experience. There are circumstances in which police officers, for example, can give evidence about gangs
and drugs if they demonstrate the necessary expertise through experience. The classic statement of the
test of admissibility of expert evidence, which has been followed in England and Wales, is found in _R v_
_Bonython (1984) 38 S.A.S.R. 45, a decision of the South Australian Supreme Court. King CJ observed_

“The […] question is whether the witness has acquired by study or experience sufficient knowledge of the
subject to render his opinion of value in resolving the issues before the court”.

53. In this case, and in respect of decisions by case workers assigned to the Competent Authority
generally, no information was available upon which it is possible to determine whether and in what area the
case worker might be an expert. Beyond an inference that decision making is approached via the
comprehensive guidance to which we have referred and that there must be some training provided, case
workers in the Competent Authority are junior civil servants performing an administrative function which
includes making reasonable grounds and conclusive grounds decisions. The guidance recognises that a
decision of the Competent Authority might be disclosed in criminal proceedings but nowhere is there any
suggestion that the decision maker might be called to give evidence, still less that in making the decision
the case worker is acting as an expert and might give evidence in chief and be cross-examined in a
criminal court as such.

54. In respectful disagreement with the Divisional Court in DPP v M we do not consider that case workers
in the Competent Authority are experts in human trafficking or **_modern slavery (whether generally or in_**
respect of specified countries) and for that fundamental reason cannot give opinion evidence in a trial on
the question whether an individual was trafficked or exploited.  It is not sufficient to assume that because
administrators are likely to gain experience in the type of decision-making they routinely undertake that,
simply by virtue of that fact, they can be treated as experts in criminal proceedings. The position of these
decision-makers is far removed, for example, from experts who produce reports into air crashes for the Air
Accident Investigation Branch of the Department of Transport which are admissible in evidence in civil
proceedings: see Rogers v Hoyle [2015] 1 QB 265 Moreover none of the requirements of CrimPR 19


-----

designed in part to ensure that the person giving evidence is an expert, understands he or she is acting as
such and understands the obligations of an expert to the court, were complied with.

55. DPP v M was a decision of the High Court on appeal by way of case stated from the Youth Court in
which the prosecution had admitted, pursuant to section 10 of the Criminal Justice Act 1967, that

“On 21 August 2019 the [Competent Authority] made a conclusive grounds decision that, on a balance of
probabilities, M had been recruited, harboured and transported for the purposes of criminal exploitation, the
full minute of the decision being exhibited.”

56. There was a lack of clarity about what the prosecution was seeking to admit. The minute (equivalent,
we infer, of the Decision Annex in our case) was placed before the judge without objection and thus she
took it into account in deciding whether the prosecution had negatived the defence under section 45 of the
2015 Act. The defendant did not give evidence. The question for consideration by the High Court was:

“In the circumstances of this case, where the [defendant] did not give evidence and did not provide an
explanation in interview, had [the defendant] sufficiently discharged the evidential burden in respect of
section 45(4)(b) and (c) of the Modern Slavery Act 2015?”

57. The prosecution had not argued before the District Judge that the defendant had failed to satisfy the
evidential burden in either of those respects. Having made the admission which we have quoted (whatever
it was intended to mean) and allowed the minute to go before the court it seems to us that the answer to
the question posed by the District Judge was inevitably “yes”. It followed that she was entitled on the
evidence placed before her by agreement to conclude that the defence was made out. On appeal the
prosecution took the opportunity to argue that both the decision and details in the minute were inadmissible
as non-expert opinion evidence based on unproven hearsay.  That was a difficult argument given the
circumstances in which the evidence went in by agreement. The court noted (at [44]) that in the case
stated the District Judge had described “the prosecution position as agreeing the facts upon which the

[conclusive grounds] decision was made”. In short, M's hearsay account contained in the minute had been
admitted by agreement. The court continued by observing that “it was regrettable that the status of the …
decision was not made clear in the admission”. In appeals by way of case stated the High Court proceeds
on the basis of the facts stated in the case.

58. Mr Douglas-Jones appeared at the appellate level for the prosecution in _DPP v M. At [45] the court_
noted that it was no part of his argument that expert evidence was never admissible on the question of
trafficking and exploitation. He readily accepted before us that there can be circumstances in which a
suitably qualified expert might be able to give evidence relevant to the questions that arise under the 2015
Act which are outside the knowledge of the jury, particularly to provide context of a cultural nature. That is
clearly correct. The evidence would have to be truly expert and not a vehicle to enable the expert to stray
into the territory of the jury by expressing his or her personal opinion about whether an account is credible
or inconsistencies immaterial. As the present case vividly illustrates, the conclusion on whether the
prosecution has disproved the section 45 defence will call for an assessment of all the relevant evidence
which the jury is well-placed to make. In the right case that evidence might include expert evidence of
societal and contextual factors outside the ordinary experience of the jury.

59. The Divisional Court accepted that the case worker was an expert because “the decision-maker had
expertise in relation to the question of whether M had been trafficked and exploited. That was so even
though the decision maker would not have prepared the minute for use as expert evidence in criminal
proceedings: see [53] and [54]. For the reasons we have given, we are unable to agree that expertise for
the purpose of being accepted as an expert in criminal proceedings can be inferred from the fact that a
person holds the job of case worker.

60. A significant part of the judgment dealt with an issue raised by the court with the parties concerning
[“Merton-compliant age assessments” (R(B) v Merton London Borough Council [2003] 4 All ER 280) which](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61KV-00000-00&context=1519360)
are admissible as evidence of age when the court is determining the proper venue for proceedings where
age is a determining factor: _R(M) v Hammersmith Magistrates' Court_ [2017] EWHC 1359 Admin. We
understand the concern of the court to avoid, by a side-wind, causing difficulties in a different area of


-----

occasional contention. The parties in _DPP v M_ do not appear to have developed submissions on age
cases. Questions can arise whether a prosecution should proceed in the youth or adult court. If there is
an issue, our understanding is that the age assessments are used to determine venue. There are many
offences where the age of the complainant or defendant is an ingredient of the offence, particularly sexual
offences. Counsel were not able to recall from their experience any examples when that issue had been
joined at trial and involved a Merton-compliant age assessment being tested. Similarly, at least in theory
there could be an issue raised by the section 45 defence whether a defendant is an adult or not. We make
clear that we have heard no argument on such age assessments and their evidential status and say
nothing about them.

61. There are further impediments to the admissibility of the conclusive grounds decision and attached
Annex beyond the lack of expert status of the case worker. First, in so far as it relied upon, and in the
Annex recited, evidence given by the appellant in various accounts, including his explanations of
inconsistencies, it was all hearsay in respect of which no application had been made, nor would one have
succeeded. Secondly, and perhaps more fundamentally, the various accounts given by the appellant
which featured in the Annex were uninfluenced by the material contained in his phone; nor was the case
worker's opinion informed by that material. An opinion based upon the appellant's various descriptions of
his journey and treatment which takes no account of that material was, to paraphrase _Turner_ (see [45]
above) based on misinformation about the facts and failed to take account of clearly relevant matters. As
such it was valueless and inadmissible even if relevant expertise had been established.

62. Yet more fundamentally, the decision of the jury whether the prosecution had negatived the section 45
defence required its members to be sure that the account given by the appellant in his evidence in chief
(and thus the core account on which the case worker proceeded) was not true.  That was not an issue on
which the evidence of the case worker could give them any assistance. They were well placed to form
their own conclusions without help from the case worker given the nature of the evidence in this case.

63. Mr Lobbenberg did not suggest that there was anything in the recent decision of the Strasbourg Court
in VCL which compelled a different answer.

64. The Strasbourg Court is not generally concerned with rules of evidence but, in any event, the issues
considered by the court were different. The first issue was whether there was a breach of article 4 of the
European Convention on Human Rights (“ECHR”) (the anti-slavery provision) by reason of the way the
Vietnamese applicants had been prosecuted for involvement in cannabis farming. The issue for the court
arose from the difference of view taken by the CPS from that of the Competent Authority on the question of
trafficking in a context where both applicants had originally pleaded guilty but subsequently sought to
appeal: [113]. At [156] the court summarised the positive obligations that arise under article 4:

“It follows from the above that the general framework of positive obligations under Article 4 includes: (1) the
duty to put in place a legislative and administrative framework to prohibit and punish trafficking; (2) the
duty, in certain circumstances, to take operational measures to protect victims, or potential victims, of
trafficking; and (3) a procedural obligation to investigate situations of potential trafficking. In general, the
first two aspects of the positive obligations can be denoted as substantive, whereas the third aspect
designates the States' (positive) procedural obligation (see S.M. v. Croatia, cited above, § 306).”

65. It continued by emphasising the need for assessments to be made about the question whether
someone has been trafficked and, in a passage to which we have already referred, said that a prosecuting
authority must consider the conclusions that flowed from those assessments, that the prosecuting authority
was not bound by them but needed a good reason to disagree [162]. The Strasbourg Court went on to
hold that there had been a breach of the state's positive obligations under article 4 in both cases before it.
The critical feature was that the CPS had disagreed with the conclusion of the Competent Authority but for
no substantial reason. The court went on to consider various aspects of article 6 and the overall fairness of
the relevant proceedings and found them wanting on the factual circumstances that had developed.

**The Evidence of Mr Barlow**


-----

66. Mr Barlow provided two long reports. His overall conclusion was that the appellant's core account was
consistent with his being a victim of trafficking and being forced into criminality.

67. Mr Barlow provided a description of himself as an independent forensic social worker and
criminologist. He holds a Master of Science degree in forensic psychology and criminology, a Bachelor of
Arts degree in social science and a diploma in social work. He has completed his PhD research into the
trafficking of children for the purposes of criminal exploitation at the Wilberforce Institute at the University of
Hull. During his master's degree he studied offender profiling and as part of his degree programme he
studied professional judgment and decision making. He has been trained in risk assessment. He designed
the Systemic Investigation, Protection and Protection Strategy (“SIPPS”) for the London Borough of
Southwark, along with an adapted SIPPS for child sexual exploitation.

68. He explained: “I have conducted risk assessments relating to trafficking of human beings, sexual and
non-sexual violence and stalking harassment for a number of organisations in the public and voluntary
sectors throughout the UK. I have been an expert advisor to (sic) the prosecution and am a regular expert
witness for the criminal court in cases of criminal and sexual exploitation, human trafficking and modern
**_slavery and have regularly been an expert witness to the family courts concerning sexual and violence risk_**
and more recently trafficking risk.” Mr Barlow stated he is currently engaged as a consultant to the
Organisation for Security and Co-operation in Europe and the Office of Democratic Institutions and Human
Rights “as an expert in child trafficking and **_modern slavery”. Finally, he sets out that he works “as an_**
independent trainer and consultant to a number of organisations including Police Authorities”.

69. We observe that the court was provided, therefore, with limited details of Mr Barlow's expertise in the
subject of **_modern slavery. It amounts to having undertaken research into the subject for a PhD thesis._**
The judge was not furnished with any particularity of the extent to which, and the circumstances in which,
he has conducted risk assessments, acted as a consultant or provided advice or expert testimony in
relation to this subject.

70. In our view, the material provided to the court in the present case afforded an insufficient basis to
determine that Mr Barlow possessed, by virtue of study or experience, sufficient knowledge of **_modern_**
**_slavery – as opposed to other specialist subjects – that meant his opinion on this subject would be of value_**
to the jury in the present case.

71. This conclusion is reinforced by the extent and quality of the material on which his opinion was based.

72. Mr Barlow had not met the applicant when he provided his first report (2 March 2020). Instead, for the
relevant history he was dependent on a clinical psychological report by Dr Marriott dated 14 February 2020
and a “preliminary opinion report” by Dr Thullesen (a chartered psychologist and psychotherapist). He also
had the list of charges, the police report, some information about the telephone evidence and a report from
the police national computer. Dr Thullesen did not give evidence. Dr Marriott did. We interpolate to note
that the prosecution accepted that Dr Marriott's evidence on the narrow issue of the appellant's cognitive
functioning was admissible. Dr Thullesen did not meet the applicant and she did not hold herself out as an
expert for the purposes of the criminal proceedings. She made clear that she would not give evidence.
Her report, as with Mr Barlow, was dependent on untested hearsay evidence, important aspects of which
were contradicted by evidence from or concerning the appellant which emerged during the trial. Mr Barlow
based his conclusions, in part, on the description provided to him of the appellant's suggested introduction
to cannabis and involvement in the supply of this drug at school, along with the circumstances in which he
was abused there, leading to his premature departure. He accepted that he had seemingly been poorly
treated at home. Mr Barlow acted on Dr Marriott's conclusions as regards the applicant's low IQ
(“borderline learning disability”), that he had symptoms consistent with moderate anxiety and he met the
threshold for a diagnosis of post-traumatic stress disorder. He based his conclusions to a significant extent
on the entirety of the account given by the appellant of his journey to the United Kingdom and his
circumstances following his arrival. Having reviewed some of the literature concerning **_modern slavery,_**
particularly in the context of Albania, Mr Barlow identified certain factors that he suggested indicated the
victim's vulnerability to criminal exploitation and abuse.


-----

73. For his second report (9 March 2020), Mr Barlow had spent three hours with the appellant. In this
meeting, the latter provided a very different account of his time at school and his life at home (which
contradicted his earlier account of domestic violence), albeit he suggested he had been bullied at school
into selling cannabis. The appellant claimed he was effectively held in captivity for a week in an hotel in
Belgium, for three weeks in Mitcham and thereafter in Birmingham where he was put to work. He
suggested that he was threatened, shouted at, maltreated and abused whilst being kept under close
supervision. This description underpinned Mr Barlow's conclusions. He also relied upon the conclusive
grounds decision which, by then, was available.

74. With respect to Mr Barlow, there are persuasive reasons for suggesting he was substantially
misinformed about the facts and that his opinion was reached without consideration of core relevant
information. The contents of the appellant's iPhone revealed an entirely different history from that accepted
by Mr Barlow, including independent trips by the appellant across northern France prior to entering the
United Kingdom and thereafter travelling freely within this country. The digital record was devoid of any
suggestion of trafficking, including by way of relevant contact with the individuals who were suggested to
have recruited and exploited the appellant, and instead it tends to demonstrate a happy and carefree life
on his part. He maintained seemingly cheerful contact with his family and booked the services of escorts
for himself and a friend. It is striking that Mr Barlow was not asked to reconsider his conclusions in light of
this critical digital evidence, which was available to the applicant's representatives. Given none of this vital
material was reviewed by Mr Barlow, we regret to conclude that his opinion was rendered valueless.

75. For these reasons we are unpersuaded that Mr Barlow had demonstrated sufficient knowledge of
**_modern slavery in the context of the present case or that he had considered the range of facts necessary_**
for reaching an informed opinion.

**Conclusion**

76. The judge was right to exclude the conclusive grounds decision, the Annex attached to it and Mr
Barlow's evidence. We grant leave to appeal on these evidential grounds but dismiss the appeal. We
would add that on an objective view of the evidence the section 45 defence was comprehensively
demolished by the prosecution. There is no question that this conviction is safe.

**End of Document**


-----

