# Basfar (respondent) v Wong (appellant) [2022] IRLR 879

[2022] UKSC 20

Supreme Court

06072022

**_[987   Diplomatic Privileges Act](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_**

**_[999   Prevention of human trafficking](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_**

**_[1741   Rights and freedoms – slavery and forced labour](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N0DM-00000-00&context=1519360)_**

**_[4300   Tribunals](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B7M1-DYNP-N057-00000-00&context=1519360)_**

**_[4395   Jurisdiction](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5DDJ-M0T1-DYNP-N3V6-00000-00&context=1519360)_**
**The facts:**

Ms Wong was a national of the Philippines and a domestic worker in the household of Mr Basfar who was a
member of Saudi Arabia's diplomatic staff in the UK. She brought a claim against him for wages and breaches of
employment rights. She alleged that she had been employed in his household in Saudi Arabia and that, in 2016,
she had been brought to the UK to continue that work, having been provided with an employment contract to obtain
a visa. She further alleged that in the UK: she was confined at all times to his house except to take out the rubbish;
she was held virtually incommunicado; she was made to work from 7am to around 11.30pm each day, with no days
off or rest breaks; she was required to wear a door-bell at all times so that she was at the family's beck and call 24
hours a day; she was shouted at incessantly and regularly called offensive names; she was paid nothing apart from
a lump sum worth approximately £1,800 in respect of a trip to Jeddah; and she managed to escape in 2018. She
claimed that she was a victim of human trafficking who was exploited by Mr Basfar and his family. Mr Basfar applied
to have her claim struck out on the ground that he was immune from suit because of his diplomatic status.

Under the Diplomatic Convention, diplomatic agents were generally immune from the civil jurisdiction of the
receiving state. However, art 31(1)(c) provided an exception to that immunity for actions '… relating to any
professional or commercial activity exercised by the diplomatic agent in the receiving State outside his official
functions.' The parties agreed that the issue was whether Mr Basfar's employment of the claimant as a domestic
servant 'in assumed circumstances of **_modern slavery' was a commercial activity exercised by him outside his_**
official functions. The tribunal answered that question in the affirmative: Ms Wong's claim could have fallen within
the commercial activity exception to diplomatic immunity. It therefore refused to strike out the claim. The EAT
[([2020] IRLR 248) allowed Mr Basfar's appeal. Ms Wong was granted permission for a 'leapfrog' appeal to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YD0-JNY3-GXFD-81K8-00000-00&context=1519360)
present court.

One question raised was whether acts capable of amounting to human trafficking would have ended when Ms
Wong as recei ed at Mr Basfar's residence in the UK Ms Wong arg ed that the trafficking contin ed p ntil the


-----

moment of her alleged escape. Due to doubts raised as to whether there had been trafficking, the majority
considered what form of modern slavery was disclosed by the assumed facts: whether the claim could have been
characterised as relating to forced labour and/or domestic servitude.

The Supreme Court (Lord Briggs, Lord Hamblen, Lord Leggatt, Lord Stephens and Lady Rose) by a reserved
judgment given on 6 July 2022 allowed Ms Wong's appeal (Lord Hamblen and Lady Rose dissenting).
**The Supreme Court held:**

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_

The domestic worker's claims, on the assumed facts, would not have been barred by diplomatic immunity:

It would be contrary to the purpose of conferring immunity on diplomatic agents to interpret the words 'any …
commercial activity' in art 31(1)(c) as including activities incidental to the ordinary conduct of daily life in the
receiving state, such as purchasing goods for personal consumption or purchasing medical, legal, educational or
domestic services privately. Accordingly, immunity from the civil jurisdiction of the local courts is justified in relation
to such activities to ensure that diplomatic agents and their families can live in the receiving state without the
impediment arising from having to deal with civil claims against them. Because services such as dry cleaning and
domestic help are incidental to ordinary daily life, they fall within the rationale for immunity from the civil jurisdiction
of the receiving state, so that the art 31(1)(c) exception should not be construed as applying to actions relating to
them. However, exploiting a domestic worker by compelling her to work in circumstances of modern slavery is not
comparable to an ordinary employment relationship of a kind that is incidental to the daily life of a diplomat (and
their family) in the receiving state. There is a material and qualitative difference between those activities.
Employment is a voluntary relationship, freely entered into and governed by the terms of a contract. Subject to
contractual provisions about notice, employees are free to leave when they please, and cannot be compelled to
stay by injunction even if they leave in breach of contract. By contrast, the essence of modern slavery is that it is
not freely undertaken. Rather, the work is extracted by coercion and the exercise of control over the victim. This
usually involves exploiting circumstances of the victim which make them specially vulnerable to abuse. Those
constraints generally make it impossible or very difficult for the worker to leave. Personal profit is an element of
what may make a particular activity commercial. Accordingly, the activity of profiting from the forced labour of a
domestic worker who is held in a state of servitude falls outside the scope of the exception to diplomatic immunity in
art 31(1)(c). The term 'servitude' is generally understood to refer to a form of exploitation which lies on a scale of
gravity or severity between slavery and forced labour and involves coercion.

In the present case (all on the assumed facts), the extent of the control over Ms Wong's person and dominion over
her labour exercised by Mr Basfar was so extensive and despotic as to place her in a position of domestic
servitude. He had made a substantial financial gain from his exploitation of her labour, albeit not in cash but in
money's worth. The exploitation was a commercial activity practised for personal profit. It would have been not
merely wrong but offensive to suggest that conduct of the kind disclosed by the assumed facts was incidental to
daily life, let alone the daily life of an accredited diplomat. Compelling a migrant domestic worker to provide her
labour in circumstances of modern slavery could not have been reasonably likened to paying for dry cleaning or
ordinary domestic help. Unlike such day-to-day living services, such exploitation was an abuse of the diplomat's
presence in the receiving state and fell far outside the sphere of ordinary contracts incidental to the

daily life of the diplomat and family members which the immunity served to protect. Accordingly, on the assumed
facts, the claim brought by Ms Wong fell within the exception from immunity provided for in art 31(1)(c). It followed
that, if those facts were proved, Mr Basfar would not have immunity from the civil jurisdiction of the courts of the UK.
A hearing would be required to determine the truth of the allegations.

It was not necessary to resolve the difficult issue of taxonomy, for two reasons. The first was that, on the assumed
facts, Mr Basfar was plainly involved in trafficking Ms Wong, regardless of whether, strictly construed, trafficking
ceased 'at the door of the workhouse'. He clearly played a principal part in her recruitment, transport and receipt,
using the prohibited means and for the purpose of her exploitation. Secondly and more importantly, the conclusion
that his exploitation of her was a commercial activity did not depend upon which particular manifestation of modern


-----

**_slavery might best have described his conduct, using the classification to be derived from international_**
Conventions. It was sufficient that his treatment of her, on the assumed facts, amounted to a form of **_modern_**
**_slavery, whether it was forced labour, servitude or trafficking. That showed that the relationship between them was_**
not that of employment freely entered into, so as to have been an ordinary part of his daily life in the UK as a
resident diplomat. And it showed that his conduct amounted to a commercial activity practised (in so far as it
mattered) for personal profit. That said, the assumed facts of the present case made it a paradigm example of
domestic servitude.
**Cases referred to:**

_A Local Authority v AG_ _[[2020] EWFC 18, [2021] 1 All ER 257, [2020] Fam 311, [2020] 1 FLR 1265, [2020] 3 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61SB-3TB3-GXFD-84JX-00000-00&context=1519360)_
133

_A v Secretary of State for the Home Dept (No 2)_ _[[2005] UKHL 71, [2006] 1 All ER 575, [2006] 2 AC 221, [2006] 4](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4J84-TMG0-TWP1-61D2-00000-00&context=1519360)_
_[LRC 110, [2005] 3 WLR 1249](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-842V-00000-00&context=1519360)_

_Ajayi v Abu_ _[[2017] EWHC 3098 (QB), [2018] IRLR 1028](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TH7-TSJ1-DYPB-W02B-00000-00&context=1519360)_

_Reyes v Al-Malki_ _[[2017] UKSC 61, [2018] IRLR 267, [2019] AC 735, [2018] 1 All ER 629, [2017] 3 WLR 923; rvsg in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
_[part [2015] EWCA Civ 32, [2015] IRLR 289, [2016] 1 WLR 1785, [2016] 2 All ER 136, [2015] ICR 931](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)_

_Barnet London BC v AG_ _[[2021] EWHC 1253 (Fam), [2022] 2 All ER 168, [2021] Fam 404, [2022] 1 FLR 877, [2021]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:654C-44X3-CGX8-02WK-00000-00&context=1519360)_
3 WLR 875

_Chowdury v Greece (App no 21884/15) (judgment, 30 March 2017) ECtHR_

_CN v France (App no 67724/09) (judgment, 11 October 2012) ECtHR_

_Dispute regarding Navigational and Related Rights (Costa Rica v Nicaragua) [2009] ICJ Rep 213, ICJ_

_El-Hadad v Embassy of the United Arab Emirates (2000) 216 F 3d 29 US Ct of Apps (DC Cir)_

_Fonseca v Larren (30 January 1991, unreported) Portugal SC_

_Fothergill v Monarch Airlines Ltd_ _[[1980] 2 All ER 696, [1981] AC 251, [1980–84] LRC (Comm) 215, [1980] 3 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-6134-00000-00&context=1519360)_
209HL

_Fun v Pulgar (2014) 993 F Supp 2d 470 US DC_

_Gonzalez Paredes v Vila (2007) 479 F Supp 2d 187 US DC_

_Hounga v Allen_ _[[2014] UKSC 47, [2014] IRLR 811, [2014] 1 WLR 2889, [2014] 4 All ER 595, [2014] ICR 847](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D2X-VY01-DYPB-W2BN-00000-00&context=1519360)_

_Jones v Ministry of Interior of the Kingdom of Saudi Arabia (Secretary of State for Constitutional Affairs intervening),_
_Mitchell v Al-Dali_ _[[2006] UKHL 26, [2007] 1 All ER 113, [2007] 1 AC 270, (2006) 20 BHRC 621, [2006] 2 WLR 1424](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MSH-2RS0-TWP1-600Y-00000-00&context=1519360)_

_Jurisdictional Immunities of the State (Germany v Italy) [2012] ICJ Rep 99 ICJ_

_Montuya v Chedid (2011) 779 F Supp 2d 60 US DC_

_Park v Shin (2002) 313 F 3d 1138 US Ct of Apps (9th Cir)_

_Propend Finance Pty Ltd v Sing (1997) 111 ILR 611 CA_

_R (on the application of BG) v Secretary of State for the Home Dept_ _[[2016] EWHC 786 (Admin), [2016] All ER (D)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JHR-T581-DYBP-N21M-00000-00&context=1519360)_
_[74 (Apr)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JHR-T581-DYBP-N21M-00000-00&context=1519360)_


-----

_[R v Tang [2008] HCA 39, [2009] 2 LRC 592, (2008) 25 BHRC 35 Aus HC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-83C5-00000-00&context=1519360)_

_Ramos v US (4 May 1994, unreported) Portugal DC_

_[Rantsev v Cyprus (App no 25965/04) (2010) 28 BHRC 313, (2010) 51 EHRR 1 ECtHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

_Sabbithi v Al Saleh (2009) 605 F Supp 2d 122, US DC_

_[Siliadin v France (App no 73316/01) (2005) 20 BHRC 654, (2006) 43 EHRR 287, ECtHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

_Tabion v Mufti (1996) 73 F 3d 535, (1996) 107 ILR 452, US Ct of Apps (4th Cir)_

_US v Kozminski (1988) 487 US 931 US SC_

_[US v Public Service Alliance of Canada, Re Canada Labour Code [1993] 2 LRC 78, [1992] 2 SCR 50 Can SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JX4-YNV1-DYJ0-82K7-00000-00&context=1519360)_

_[Van der Mussele v Belgium (App no 8919/80) (1983) 6 EHRR 163, [1983] ECHR 8919/80 ECtHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_
**Appearances:**

Vienna Convention on Diplomatic Relations 1961 (the 'Diplomatic Convention'): art 31(1)(c)

_[Diplomatic Privileges Act 1964: s 2(1)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61B0-TWPY-Y0N2-00000-00&context=1519360)_

United Nations Convention against Transnational Organized Crime 2000

For diplomatic immunity see Harvey PIII [201]

For Ms Wong:

TIMOTHY OTTY QC, PAUL LUCKHURST, PROFESSOR PHILIPPA WEBB and ISHAANI SHRIVASTAVA,
instructed by Wilson Solicitors LLP

For Mr Basfar:

MOHINDERPAL SETHI QC, SOPHIA BERRY and BLÁTHNAID BRESLIN, instructed by Reynold Porter
Chamberlain LLP (London)

For Kalayaan (first intervener, written submissions only):

TOM HICKMAN QC and FLORA ROBERTSON, instructed by Deighton Pierce Glynn (London)

For the United Nations Special Rapporteur on Trafficking in Persons especially Women and Children (second
intervener, written submissions only):

PROFESSOR PAROSHA CHANDRAN, instructed by Duncan Lewis (London)
1

**LORD BRIGGS AND LORD LEGGATT (WITH WHOM LORD STEPHENS AGREES):**
**A. INTRODUCTION**

Ms Josephine Wong (a national of the Philippines) is a migrant domestic worker who worked in the household of Mr
Khalid Basfar, a member of the diplomatic staff of the mission of the Kingdom of Saudi Arabia in the United
Kingdom. Ms Wong claims that she is a victim of human trafficking who was exploited by Mr Basfar and his family
by being forced to work in circumstances of **_modern slavery. She has brought a claim against Mr Basfar in an_**
employment tribunal for wages and breaches of employment rights. Mr Basfar has applied to have Ms Wong's claim
against him struck out on the ground that he is immune from suit because of his diplomatic status.
2

Under the Vienna Convention on Diplomatic Relations 1961, diplomatic agents enjoy complete immunity from the
criminal jurisdiction of the receiving state and are also generally immune from its civil jurisdiction. There is, however,


-----

an exception for civil claims relating to 'any professional or commercial activity exercised by the diplomatic agent in
the receiving state outside his official functions'. The question raised on this appeal is whether exploiting a domestic
worker in the manner alleged constitutes 'exercising' a 'commercial activity' within this exception.
3

The Supreme Court has considered this question before in _Reyes v Al-Malki_ _[2017] UKSC 61,_ _[[2018] IRLR 267,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_

[2019] AC 735. The facts alleged in Reyes were similar to the facts alleged here, but with one important difference:
in _Reyes the diplomat's posting ended during the litigation. The Court of Appeal held that the diplomat had_
[immunity: [2015] EWCA Civ 32, [2015] IRLR 289, [2016] 1 WLR 1785. This Court allowed an appeal on the ground](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)
that, after a diplomat's functions as a member of the mission have come to an end, immunity for past acts continues
to subsist only for acts which were performed in the

exercise of those functions – which the alleged acts were not. Having reached that conclusion, there was no need
to decide whether, if he had still been in post, the diplomat would have had immunity. A minority of the Supreme
Court expressed a clear view that he would. But a majority of the Court considered this to be very much in doubt.
4

In this case the question necessarily arises for decision, as Mr Basfar is still in post. The employment tribunal held
that, on the facts alleged, Ms Wong's claim comes within the commercial activity exception to diplomatic immunity.
The tribunal therefore refused to strike out the claim. The Employment Appeal Tribunal (2020) _(2020)_
_[UKEAT/0223/19, [2020] IRLR 248, [2020] ICR 1185(Soole J sitting alone) allowed Mr Basfar's appeal against this](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YD0-JNY3-GXFD-81K8-00000-00&context=1519360)_
decision but issued a certificate that the case was suitable for an appeal by Ms Wong directly to the Supreme Court
'leapfrogging' the Court of Appeal. This Court subsequently granted permission for such a leapfrog appeal.
5

There is evidence that exploitation of migrant domestic workers by foreign diplomats is a significant problem, so that
the question raised on this appeal is one of general importance: see eg _Reyes_ _[[2018] IRLR 267, [2019] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
735(para [59]). To obtain a wider perspective, the Court has permitted two non-parties to intervene in the appeal by
making written submissions. They are: Kalayaan, a charity that supports migrant domestic workers, some of whom
have been trafficked; and the United Nations Special Rapporteur on Trafficking in Persons especially Women and
Children (the 'Special Rapporteur').
6
**B. THE ALLEGED FACTS**

The following facts are alleged by Ms Wong in her claim form. None of them has been admitted by Mr Basfar; but
for present purposes we must assume them to be true so as to test Mr Basfar's argument that, even if the facts
alleged are proved, the claim against him cannot succeed because he has diplomatic immunity.
7

Ms Wong alleges that she was first employed by the diplomatic household of Mr Basfar in November 2015 in Saudi
Arabia. On 1 August 2016 she was brought to the United Kingdom to continue working for him here. To obtain a
visa to enter the country, Ms Wong was provided with an employment contract stating that she was employed by Mr
Basfar to work a maximum of eight hours a day, with one day off each week and one month off each year; she was
to be provided with sleeping accommodation and paid the national minimum wage.
8

Ms Wong alleges that, after arriving in the UK, she was confined at all times to Mr Basfar's house except to take out
the rubbish. She was held virtually incommunicado, being allowed to speak to her family only twice a year using Mr
Basfar's mobile telephone. She was made to work from 7am to around 11.30pm each day, with no days off or rest
breaks, and was required to wear a door-bell at all times so that she was at the family's beck and call 24 hours a
day. She was shouted at incessantly and regularly called offensive names. When the family was at home, Ms Wong
was only allowed to eat their left-over food; if they were out, she could cook something for herself.
9


-----

After arriving in the UK, Ms Wong was paid nothing for seven months until Mr Basfar and his wife took her with
them to Jeddah on their holiday in July 2017: during this trip she was paid 9,000 Saudi Riyals (approximately
£1,800) for six months in one lump sum. This was a fraction of her contractual entitlement. After that, she was not
paid again.
10

Ms Wong endured these abusive conditions until 24 May 2018, when she managed to escape.
11
**C. THE LEGAL FRAMEWORK(1) Diplomatic Immunity**

The principle of legal immunity for diplomatic agents is a fundamental principle of national and international law,
rightly described in a recent case as 'one of the most important tenets of civilised and peaceable relations between
nation states': A Local Authority v AG _[[2020] EWFC 18, [2021] 1 All ER 257, [2020] Fam 311(para [38]) (Mostyn J).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61SB-3TB3-GXFD-84JX-00000-00&context=1519360)_
At the international level the relevant law is contained in arts 1, 22–24, 27–40 and 45 of the Vienna Convention on
Diplomatic Relations 1961 (the 'Diplomatic Convention'), to which 193 states are parties. _[Section 2(1) of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y0D1-00000-00&context=1519360)_
Diplomatic Privileges Act 1964 (the '1964 Act') incorporates these provisions into UK domestic law.
12

As recorded in the fourth recital to the Diplomatic Convention, the purpose of diplomatic privileges and immunities
'is not to benefit individuals but to ensure the efficient performance of the functions of diplomatic missions as
representing States'. To this end:

(i)   the premises of the mission are inviolable (art 22);

(ii)   all correspondence relating to the mission and its functions is inviolable and the diplomatic bag must
not be opened or detained (art 27);

(iii)   the person of a diplomatic agent is inviolable and he shall not be liable to any form of arrest or
detention (art 29);

(iv)   the premises of a diplomatic agent are inviolable, as are his papers, correspondence and (save in
cases where he is not immune from civil jurisdiction) his property (art 30);

(v)   a diplomatic agent enjoys immunity from the criminal jurisdiction and (with limited exceptions) the civil
and administrative jurisdiction of the receiving state (art 31(1));

(vi)   a diplomatic agent is not obliged to give evidence as a witness (art 31(2));

(vii)   diplomatic immunity may be waived only by the sending state and not by the individual (art 32);

(viii)   with limited exceptions, diplomatic agents are exempt from all dues and taxes in the receiving state
(art 34);

(ix)   the privileges and immunities enjoyed by a diplomatic agent extend to family members who form part
of his household (art 37); and

(x)   although such privileges and immunities normally cease when the functions of a diplomatic agent
have come to an end, immunity continues to subsist with respect to acts performed in the exercise of his
functions as a member of the mission (art 39(2)).

13
_(2) Article 31(1)(c)_

The key provision for present purposes is the exception to immunity from the civil jurisdiction of the receiving state
provided for in art 31(1)(c) of the Diplomatic Convention. This exception applies in the case of—

'an action relating to any professional or commercial activity exercised by the diplomatic agent in the receiving
State outside his official functions.'

14
_(3) The scope of official functions_


-----

In Reyes this Court unanimously held that the employment and alleged acts of maltreatment of the claimant by the
respondent diplomat were not performed 'in the exercise of his functions as a member of the mission' within the
meaning of art 39(2). As discussed by Lord Sumption (with whom the rest of the Court agreed on this point), a
diplomatic agent's 'functions as a member of the mission' in art 39(2) are the same as 'his official functions' in art
31(1)(c) and are, in each case, those functions which the diplomatic agent performs for or on behalf of the sending

[state: see [2018] IRLR 267, [2019] AC 735(para [20]). The acts alleged in Reyes were plainly not done for or on](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)
behalf of Saudi Arabia (see para [48]); and the same is equally true here.
15

It is not suggested that the alleged acts of Mr Basfar were a 'professional' activity. The question is whether they
were a 'commercial activity exercised' by him within the meaning of art 31(1)(c) of the Diplomatic Convention.
16
_(4) Principles of interpretation_

The text of an international convention is intended to be given the same meaning by all the states which become
parties to it. The provisions of the Diplomatic Convention enacted into UK law by the 1964 Act must therefore be
interpreted, not by applying domestic principles of statutory interpretation, but according to the generally accepted
principles by which international conventions are to be interpreted as a matter of international law: see Fothergill v
_Monarch Airlines Ltd_ _[[1980] 2 All ER 696, [1981] AC 251; Reyes](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-6134-00000-00&context=1519360)_ _[[2018] IRLR 267, [2019] AC 735(para [10]). Those](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
principles are set out in the Vienna Convention on the Law of Treaties 1969 (the 'Treaties Convention').
17

The general rule of interpretation is stated in art 31(1) of the Treaties Convention as follows:

'A treaty shall be interpreted in good faith in accordance with the ordinary meaning to be given to the terms of
the treaty in their context and in the light of its object and purpose.'

Article 31(3) provides that:

'There shall be taken into account, together with the context:

(a) any subsequent agreement between the parties regarding the interpretation of the treaty or the application
of its provisions;

(b) any subsequent practice in the application of the treaty which establishes the agreement of the parties
regarding its interpretation;

(c) any relevant rules of international law applicable in the relations between the parties.'

18

Article 32 of the Treaties Convention permits recourse to be had to supplementary means of interpretation,
including the preparatory work of the treaty and the circumstances of its conclusion, in order to confirm the meaning
resulting from the application of art 31 or if applying art 31 leaves the meaning ambiguous or obscure or leads to a
result which is manifestly absurd or unreasonable.
19
**D. THE ARGUMENTS(1) Ms Wong's case**

The arguments made on Ms Wong's behalf, like the claimant's case in Reyes, have relied heavily on a contention
that the facts alleged amount to 'trafficking in persons', as that term is defined in the United Nations Protocol to
Prevent, Suppress and Punish Trafficking in Persons Especially Women and Children, supplementing the United
Nations Convention against Transnational Organized Crime 2000 (the 'Palermo Protocol'). Mr Timothy Otty QC put
forward Ms Wong's case in the form of a syllogism:

(i)   Human trafficking is a commercial activity.

(ii) Ms Wong's claim relates to human trafficking (of her by Mr Basfar)


-----

(iii)   Consequently, her claim relates to a commercial activity allegedly exercised by Mr Basfar and so
falls within the exception from immunity provided in art 31(1)(c) of the Diplomatic Convention.

20
_(2) Mr Basfar's case_

For Mr Basfar, Mr Mohinderpal Sethi QC approached the issue from a different direction. Adopting the reasoning of
Lord Sumption's minority judgment in Reyes (on this point), he submitted:

(i)   The employment of a domestic servant at a diplomat's private residence does not constitute the
exercise of a commercial activity by a diplomatic agent within the meaning of the exception.

(ii)   It makes no difference if the domestic servant is a victim of human trafficking.

(iii)   Therefore, even if Ms Wong was trafficked by Mr Basfar, he has diplomatic immunity in relation to
her claim.

21

Mr Sethi QC also sought to advance an argument not made below that the facts alleged by Ms Wong do not come
within the definition of human trafficking set out in the Palermo Protocol. He further submitted that Ms Wong's claim
in the employment tribunal for wages and breaches of her employment rights is in any case not 'an action relating
to' human trafficking. In response, in written submissions filed at the Court's invitation after the hearing, counsel for
Ms Wong argued that, even if the facts alleged do not come within the definition of human trafficking, the claim can
properly be characterised as relating to (a) forced labour and/or (b) domestic servitude.
22
_(3) Human rights arguments_

In Reyes the similar allegation of human trafficking made in that case was relied on to argue that the 1964 Act and
the Diplomatic Convention should be interpreted to achieve consistency with rules of international law which require
states to prevent and provide effective remedies for human trafficking. In particular, reference was made to art 6(6)
of the Palermo Protocol, which requires each state party to ensure that 'its domestic legal system contains
measures that offer victims of trafficking in persons the possibility of obtaining compensation for damage suffered'.
A similar obligation is imposed on states which are parties to the Council of Europe Convention on Action against
Trafficking in Human Beings 2005 by art 15(3). The claimant also sought to rely on arts 4 and 6 of the European
Convention on Human Rights (the 'ECHR'). Article 4 of the ECHR prohibits slavery, servitude and forced or
compulsory labour. In _Rantsev v Cyprus (App no 25965/04)_ _[(2010) 28 BHRC 313, (2010) 51 EHRR 1, the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_
European Court of Human Rights held that, although not expressly referred to, human trafficking also falls within the
scope of art 4 and that member states have positive obligations under art 4 which include an obligation to put in
place a legislative and administrative framework to prohibit and punish human trafficking. Article 6 of the ECHR
confers a right of access to the courts. The claimant argued in _Reyes that the 1964 Act and the Diplomatic_
Convention must be interpreted in a way which does not place the UK in breach of these international obligations.
23

[In Reyes the Court of Appeal gave detailed reasons for rejecting these arguments: see [2015] IRLR 289, [2016] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)
WLR 1785(paras [35]–[76]). So did Lord Sumption in the Supreme Court: see _[[2018] IRLR 267, [2019] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
735(paras [40]–[45]). In short:

(i)   Domestic principles of statutory interpretation are not relevant in interpreting the provisions of the
Diplomatic Convention incorporated into UK law, which must be given their international meaning (see para

[16] above).

(ii)   There is no inconsistency between the international obligations of the UK to prohibit and create
liabilities for human trafficking and the immunity of diplomats in international law from the jurisdiction of the
local courts. The position is no different from cases involving torture or war crimes and crimes against
humanity, which are contrary to peremptory norms of international law (ius cogens) but where international
law jurisdictional immunities nevertheless apply: see Jones v Ministry of Interior of the Kingdom of Saudi
_Arabia (Secretary of State for Constitutional Affairs intervening), Mitchell v Al-Dali_


-----

_[2006] UKHL 26,_ _[[2007] 1 All ER 113, [2007] 1 AC 270(torture);](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MSH-2RS0-TWP1-600Y-00000-00&context=1519360)_ _Jurisdictional Immunities of the State_
_(Germany v Italy) [2012] ICJ Rep 99 (war crimes)._

(iii)   Restrictions on the right of access to a court which reflect the rules of diplomatic immunity
recognised in international law cannot in principle be regarded as disproportionate to the legitimate aim of
complying with a state's international law obligations to ensure the efficient performance of diplomatic
functions: see most recently _Barnet London BC v AG_ _[2021] EWHC 1253 (Fam),_ _[[2022] 2 All ER 168,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:654C-44X3-CGX8-02WK-00000-00&context=1519360)_

[2021] Fam 404(para [98]).

24

On this appeal counsel for Ms Wong have not pursued the arguments based on UK domestic law principles of
statutory interpretation or on arts 4 and 6 of the ECHR which were rejected in _Reyes. Despite this, the Special_
Rapporteur included such arguments in her written intervention. The Court granted the Special Rapporteur
permission to do so, but expressly without prejudice to the relevance of those arguments to the issues in the
appeal. It is seldom appropriate for an intervener to make submissions on matters which are not in issue between
the parties to the appeal. Exceptionally, if there is an important point of law which the parties have overlooked, it
may be justifiable to raise it so that the court can consider whether to invite argument from the parties on the point.
In this case, however, the decision of Ms Wong's representatives not to renew some arguments rejected in Reyes
was plainly deliberate. It is also to be commended. The result of the Special Rapporteur advancing those
arguments was that counsel for Mr Basfar understandably felt compelled to respond to them. It is sufficient to say
that the Special Rapporteur did not point to any alleged error in the reasoning in Reyes summarised above, and we
agree with that reasoning.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
25

There is in any case a further, and in our view fatal, objection to the attempt to rely on human rights law to interpret
art 31(1)(c) of the Diplomatic Convention, noted by Lord Sumption in Reyes at para [45]. This is that the exception
to diplomatic immunity created by art 31(1)(c) is not based on whether the relevant activity is contrary to
international law or violates human rights. The sole question is whether the activity is 'professional or commercial'.
Certainly, some commercial activities are contrary to rules of international law, for example dealing in illicit drugs.
But the fact that an activity is unlawful has no direct bearing on whether or not it is commercial.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
26

In these circumstances we do not find it helpful to begin, as counsel for Ms Wong did in their submissions, with the
international definition of human trafficking. We will consider that definition and other international law concepts
often grouped under the label of 'modern slavery' at a later stage of our analysis. But the critical questions are
what is meant by a 'commercial activity exercised' by the diplomatic agent and whether the conduct of Mr Basfar
alleged in this case falls within that description.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
27
**E. MEANING OF A 'COMMERCIAL ACTIVITY'(1) Employment of a domestic worker**

Applying the general rule of interpretation set out in art 31(1) of the Treaties Convention (see para [17] above), we
agree with Mr Basfar's contention that employing a domestic worker does not itself constitute the exercise of a
'commercial activity' by a diplomatic agent within the meaning of the exception.
28
Ordinary meaning

We do not accept that this conclusion can be reached just by considering the ordinary meaning of the words used in
art 31(1)(c) of the Diplomatic Convention. In particular, we cannot agree with the view expressed by Lord Sumption
in Reyes at para [21](2) that the ordinary meaning of 'exercising' a 'commercial activity' is restricted to 'carrying on


-----

a business' or 'setting up shop'. Certainly, the ordinary meaning of the words includes those concepts. But it is not
limited to them. For example, it would be perfectly consistent with ordinary usage to describe a person who is
employed as a shop assistant as 'exercising a commercial activity' even though he or she is working in someone
else's shop and is not carrying on a business. Nor do we understand the word 'exercée' in the French text to have
any materially different connotation from the English word 'exercised'.
29

As a matter of ordinary language, buying goods and services could be described as the exercise of a commercial
activity, irrespective of the purpose for which they are purchased. The same could be said of entering into a
contract of employment as an employer (or employee) and receiving (or supplying) personal services under such a
contract. To support this proposition, we rely not just on dictionaries or our own understanding of the English
language but on how similar language has been interpreted by courts in the United States and Canada in the
context of state immunity.
30
Comparison with state immunity

The United States Foreign Sovereign Immunities Act of 1976, which provides for the immunity of foreign states from
the jurisdiction of the domestic courts, contains an exception where 'the action is based upon a commercial activity
carried on in the United States by the foreign state': 28 USC 1605. There is a similar exception in s 5 of the
Canadian State Immunity Act 1985 for 'any proceedings that relate to any commercial activity of the foreign state'.
For the purposes of these exceptions, employment of an individual by the foreign state to perform nongovernmental functions has been held to be a 'commercial activity': see eg El-Hadad v Embassy of the United Arab
_Emirates_ (2000) 216 F 3d 29 (DC Cir 2000); _US v Public Service Alliance of Canada, Re Canada Labour Code_

_[[1993] 2 LRC 78 at 94–95, [1992] 2 SCR 50 at 79 (Supreme Court of Canada). Thus, it has been held by the US](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JX4-YNV1-DYJ0-82K7-00000-00&context=1519360)_
Ninth Circuit Court of Appeals that the act of hiring a personal domestic servant comes within the commercial
activity exception to state immunity: Park v Shin (2002) 313 F 3d 1138 (9th Cir).
31

The UK _[State Immunity Act 1978 contains (in s 4) a specific exception from state immunity for contracts of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y1K0-00000-00&context=1519360)_
employment made or to be performed in the UK. There is also (in s 3) an exception for proceedings relating to a
'commercial transaction' entered into by the foreign state. For this purpose the term 'commercial transaction'
includes 'any contract for the supply of goods or services' and any 'transaction or activity' entered into or engaged in
by a state otherwise than in the exercise of sovereign authority: see s 3(3).
32

In these enactments the concept of a 'commercial activity' therefore includes the employment of a domestic worker
(and purchasing goods or other services). We do not suggest that this interpretation can be transposed to the
context of diplomatic immunity. But what the law on state immunity shows is that the question whether purchasing
goods and services, and entering into a contract of employment, is to be regarded as exercising a 'commercial
activity' cannot be answered just by interrogating the ordinary meaning of those words. Those words, like any
ordinary English words, are capable of bearing different shades of meaning according to the context in which, and
purpose for which, they are being used. In the context of state immunity, exercising a 'commercial

activity' includes employing a private domestic servant or purchasing goods in a shop. Whether the words bear the
same meaning where they are used in art 31(1)(c) of the Diplomatic Convention is a question that can only be
answered by examining the context and, importantly, the purpose of that provision.
33

In Reyes _[[2018] IRLR 267, [2019] AC 735(para [65]), Lord Wilson commented that he could not 'readily explain why](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
proceedings relating to a contract of employment entered into by a foreign state, for performance in the UK, will not
in principle attract immunity in circumstances in which, if the contract is entered into by a diplomat, it will in principle
attract immunity'. The explanation, in our view, is that given by Lord Sumption, at paras [26]–[32] of his judgment in
_Reyes. Diplomatic immunity includes immunity for acts done for or on behalf of the sending state, and in that_
respect coincides with state immunity. But diplomatic immunity also extends more widely to provide personal


-----

protection to diplomatic agents (and their families) while they are present in the receiving state. As Lord Sumption
said at para [28]: 'Human agents have a corporeal vulnerability not shared by the incorporeal state which sent
them.' To fulfil the purpose identified in the fourth recital to the Diplomatic Convention of ensuring the efficient
performance of the functions of diplomatic missions, it is necessary to protect the freedom of individuals sent to
perform those functions to live and go about their ordinary daily lives in the receiving state without hindrance. This
explains why diplomatic agents enjoy privileges and immunities that apply even when they are not performing their
official functions. It also explains why such privileges and immunities for acts performed outside their official
functions only subsist while they are in post in the receiving state (see para [3] above).

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
34
Contracts incidental to daily life

Seen in this context, it would be contrary to the purpose of conferring immunity on diplomatic agents to interpret the
words 'any … commercial activity' in art 31(1)(c) as including activities incidental to the ordinary conduct of daily life
in the receiving state, such as purchasing goods for personal consumption or purchasing medical, legal,
educational or domestic services privately. Immunity from the civil jurisdiction of the local courts is justified in
relation to such activities to ensure that diplomatic agents and their families can live in the receiving state without
the impediment arising from having to deal with civil claims against them.
35

This view is supported by the decision of the US Fourth Circuit Court of Appeals in Tabion v Mufti (1996) 73 F 3d
535 (4th Cir), which held that a contract between a domestic worker and a diplomat for the performance of domestic
services was not within the scope of art 31(1)(c) of the Diplomatic Convention. The Court of Appeals accepted that,
looking solely at the words used, the phrase 'commercial activity' could logically encompass the dealings in
question. But the court held that, when examined in context, the phrase does not have so broad a meaning as to
include 'occasional service contracts' but relates only to trade or business activity engaged in for profit (p 537).
36

In reaching this conclusion, the court took account of a statement of interest submitted by the US State Department,
which asserted that the commercial activity exception 'focuses on the pursuit of trade or business activity' and 'does
not encompass contractual relationships for goods and services incidental to the daily life of the diplomat and family
in the receiving state'. The Court of Appeals appears to have taken the view that such contracts fall within the scope
of a diplomat's official functions. Thus, Circuit Judge Murnaghan, who gave the judgment of the court, said (at pp
538–539):

'Day-to-day living services such as dry cleaning or domestic help were not meant to be treated as outside a
diplomat's official functions. Because these services are incidental to daily life, diplomats are to be immune
from disputes arising out of them.'

_[987, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
37

Acts of purchasing services of the kind described are manifestly done in a private capacity and not for or on behalf
of the sending state. We therefore do not agree that they can properly be treated as falling within the scope of a
diplomat's official functions. But we do agree that, because services such as dry cleaning and domestic help are
incidental to ordinary daily life, they fall within the rationale for immunity from the civil jurisdiction of the receiving
state, so that the art 31(1)(c) exception should not be construed as applying to actions relating to them. We would
rest that conclusion on the ground that ordinary contracts incidental to daily life in the receiving state do not
constitute 'commercial activities' within the meaning of art 31(1)(c). This accords with the view of the leading
commentary on the Diplomatic Convention: Eileen Denza Diplomatic Law: Commentary on the Vienna Convention
_on Diplomatic Relations (4th edn, 2016) p 251._
38


-----

As noted by Lord Sumption in _Reyes at para [24],_ _Tabion v Mufti has consistently been followed at district court_
level in the United States: see _Gonzalez Paredes v Vila_ (2007) 479 F Supp 2d 187 at 191 (DDC); _Sabbithi v Al_
_Saleh (2009) 605 F Supp 2d 122 at 127–128 (DDC); Montuya v Chedid (2011) 779 F Supp 2d 60 at 63–64 (DDC);_
_Fun v Pulgar (2014) 993 F Supp 2d 470 at 474 (DNJ). Complaints were made in these cases that the claimant had_
been subjected to abusive working conditions and in two of them (Sabbithi v Al Saleh and _Fun v Pulgar) the_
claimants alleged that they were victims of human trafficking. In each case, however, the federal district court
simply held, following Tabion v Mufti, that the commercial activity exception to immunity was not applicable on the
ground that hiring domestic help is incidental to the daily life of a diplomat and therefore not a commercial activity
for the purpose of the exception. In none of these cases did the court address the question whether keeping a
person in circumstances of **_modern slavery can reasonably be equated with the ordinary hiring of a domestic_**
employee.
39
_(2) The profit element_

Article 42 of the Diplomatic Convention states:

'A diplomatic agent shall not in the receiving State practise for personal profit any professional or commercial
activity.'

In Reyes _[[2015] IRLR 289, [2016] 1 WLR 1785(paras [11]–[12], [16]–[17]), the Court of Appeal agreed with the view](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)_
of Laws J in _Propend Finance Pty Ltd v Sing (1997) 111 ILR 611 at 635, that the phrase 'professional or_
commercial activity' is intended to have the same meaning in both art 31(1)(c) and art 42 and that, in the words of
Laws J, 'the very rationale of art 31(1)(c) is to see to it that no immunity enures for the benefit of a diplomat where
for one reason or another his activities do not comply with the art 42 prohibition'. Lord Sumption in Reyes _[[2018]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
_[IRLR 267, [2019] AC 735(para [21](3)), took the same view, which he thought was confirmed by the drafting history](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RMT-04V1-DYPB-W2GV-00000-00&context=1519360)_
of the Diplomatic Convention: see para [38](1). Counsel for Mr Basfar have adopted this analysis.
40

We agree that there is a clear link between the two provisions and that, where a diplomatic agent prac

tises an activity incompatible with his diplomatic status in breach of art 42, art 31(1)(c) ensures that the diplomat will
not enjoy immunity from civil actions relating to that activity. To that extent, art 31(1)(c) is clearly intended to
complement art 42. We are not persuaded, on the other hand, that art 31(1)(c) goes no wider than art 42. In one
respect at least, the scope of art 31(1)(c) is undoubtedly wider, as the exception from immunity in art 31(1)(c)
applies (by art 37) to members of the family of a diplomatic agent forming part of his household, whereas the art 42
prohibition does not. Thus, art 42 does not prevent, for example, the spouse of a diplomatic agent from working in
paid employment or carrying on a business in the receiving state; yet there is no doubt that the spouse does not
have immunity from suit in respect of such activities. The inclusion in art 42 of the words 'for personal profit' also
indicates that art 42 was not intended to prohibit a diplomat from carrying on a professional or commercial activity
on a voluntary basis, for example teaching or helping out in a charity shop for no remuneration; whereas the
absence of those words in art 31(1)(c) suggests that a civil claim relating to such conduct would nevertheless fall
within the exception from immunity.
41

For present purposes, however, it is unnecessary to decide this point. This is because, as we explain below, we are
satisfied that, on the assumed facts, Mr Basfar's exploitation of Ms Wong was undertaken for his personal profit.
42
_(3) Exploitation of a domestic worker_

The next step in Mr Basfar's argument is to contend that, seeing as the ordinary employment of a domestic worker
by a diplomatic agent does not constitute the exercise of a commercial activity within the meaning of art 31(1)(c),
the same must be true where a domestic worker is trafficked and exploited by a diplomat.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_


-----

43

It is here that we part company with the argument. We cannot accept that exploiting a domestic worker by
compelling her to work in circumstances of modern slavery is comparable to an ordinary employment relationship
of a kind that is incidental to the daily life of a diplomat (and his family) in the receiving state. There is a material and
qualitative difference between these activities. Employment is a voluntary relationship, freely entered into and
governed by the terms of a contract. Subject to contractual provisions about notice, employees are free to leave
when they please, and cannot be compelled to stay by injunction even if they leave in breach of contract. By
contrast, the essence of **_modern slavery is that it is not freely undertaken. Rather, the work is extracted by_**
coercion and the exercise of control over the victim. This usually involves exploiting circumstances of the victim
which make her specially vulnerable to abuse. Those constraints generally make it impossible or very difficult for
the worker to leave. That is why, on the assumed facts, we describe Ms Wong's departure from service with Mr
Basfar as an 'escape'.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
44
Vulnerable characteristics

To elucidate this difference, we think it useful to start by identifying factors which make migrant domestic workers
specially vulnerable to abuse and which are present on the assumed facts of this case. We have found particularly
helpful in this regard the 'Independent Review of the Overseas Domestic Workers Visa' dated 16 December 2015,
commissioned by the UK government and undertaken by James Ewins QC, and the Report of the United Nations
Special Rapporteur on contemporary forms of slavery, including its causes and consequences, Gulnara Shahinian,
A/HRC/15/20, 18 June 2010, which focused on domestic servitude as a global human rights concern.
45

A major source of vulnerability is physical and social isolation. Someone who works alone and is cut off from family,
friends and other social support is inherently vulnerable to exploitation. A domestic worker living in her employer's
home in a foreign country may find herself in this position, exacerbated by language and cultural barriers. On the
assumed facts of this case, such physical and social isolation was deliberately maintained and magnified by Mr
Basfar and his family. Confining Ms Wong to their house for 24 hours a day and never allowing her even to set foot
outside (except to put out the rubbish) prevented her from making any contacts in the UK or having any human
interaction with anyone outside Mr Basfar's own household. Ms Wong's isolation was made even more complete by
not allowing her to have a mobile phone and permitting her to use her employer's phone to speak to her family only
twice a year.
46

The extreme dependency created by such total isolation was, on the assumed facts, augmented by psychological
abuse. This took the form of being shouted at incessantly, belittled by being called offensive names and humiliated
by being made to wear a door-bell and to be constantly at the family's beck and call. A further form of degradation
was feeding Ms Wong with the family's left-over food.
47

Dependency was yet further increased by withholding pay. Not only was making Ms Wong work without paying her
anything in the UK itself abusive but it acted as a further means of control and of preventing Ms Wong from leaving
the place of her exploitation. On a simple practical level it meant that, if she left the house, she had no money with
which she could pay for any food or shelter. It also locked her financially into continuing servitude by creating the
perception that, if she left, she would lose any prospect of eventually receiving at least some recompense for her
labour.
48

The other side of isolation is invisibility to the outside world. A domestic worker who is effectively incarcerated in the
household of her employer is in practice beyond the reach of public authorities or private charities who might be
able to help if they were aware of her situation.


-----

49

All the factors which make migrant domestic workers who live in their employers' homes vulnerable to exploitation
are compounded where the employer has diplomatic status. As described in the report of the Special Rapporteur, at
para 57:

'Migrant domestic workers employed by diplomats are a particular vulnerable group. Firstly, their visa status
typically depends on continued employment by the diplomat and they are therefore not free to change
employers in case of exploitation. Secondly, diplomatic immunities and privileges shield diplomats from the
enforcement of national legislation.'

50

It is true that the force of the second point partly depends on the answer given to the question raised by this appeal.
But on any view a diplomat who exploits a migrant domestic worker enjoys immunity from the criminal jurisdiction of
the receiving state. And even if the diplomat can in principle be sued in a civil action, a money judgment against the
diplomat may be difficult if not practically impossible to enforce. While the diplomat remains in post, art 31(3) of the
Convention precludes taking any measures of execution which would infringe the inviolability of the diplomat's
person or residence. And once the diplomat's posting ends and he leaves the country, there may be no realistic
prospect of enforcing a judgment against him in his home state. This also applies in the present case.

_[1741](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N0DM-00000-00&context=1519360)_
51

Putting these factors together, the extent of the control over Ms Wong's person and dominion over her labour
exercised by Mr Basfar on the assumed facts of this case was so extensive and despotic as to place her in a
position of domestic servitude.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
52
_(4) Making a personal profit_

So far we have been concentrating on the factors which enabled Mr Basfar to exercise a very high degree of control
over Ms Wong's person and labour and hold her in a form of modern slavery. But what is also critical for present
purposes is how Mr Basfar exploited such control for personal profit. This is not only because of the potential effect
of art 42, but also because personal profit is an element of what may make a particular activity commercial. On the
assumed facts, Mr Basfar and his family enjoyed the benefit of Ms Wong's services for almost two years, initially for
a fraction of her contractual entitlement to wages and latterly for no pay at all. That was a substantial financial
benefit. The deliberate and continuing course of conduct by which that benefit was gained is in our view properly
characterised as the exercise of a commercial activity.
53

Counsel for Mr Basfar disputed this on the basis that no money changed hands. According to this argument, if Mr
Basfar had made Ms Wong's services available to someone else in return for payment, the commercial activity
exception would have applied; but because he and his family enjoyed the benefit of her services themselves, it
does not. This argument seems to us unsustainable as a matter both of law and economics. Any realistic form of
economic measurement, not to say system of taxation, takes account of benefits in kind which have monetary
value. If, for example, as a term of her employment a company executive is provided with the free use of a car and
chauffeur, she enjoys an economic benefit which can be taxed and fairly valued at what it would cost to purchase
this service in the market. In the same way the monetary value of services derived from forced domestic labour can
be measured as the difference between the amount for which the worker would willingly have provided the services
or for which equivalent services could have been purchased in the labour market and the amount of money, if any,
and other emoluments actually paid for them.
54


-----

This is the basic methodology used by the International Labour Office ('ILO') to estimate profits from forced labour
in domestic work. The ILO was originally created as part of the Treaty of Versailles in 1919 and is now an agency of
the United Nations with 187 state members. As discussed in the ILO report 'Profits and Poverty: The Economics of
Forced Labour' (2014) p 25:

'… domestic services create an economic value added, and therefore the savings made by the employer on
expenditures count as profits.'

By comparing wages earned by domestic workers in reported cases of forced labour with what their counterparts
not in forced labour should earn from working freely, the report estimated that profits of nearly US$8b are extracted
annually from an estimated 3.4m domestic workers in forced labour worldwide.
55

In the present case an obvious starting-point for calculating the profits made by Mr Basfar from Ms Wong's labour
on the assumed facts is to compare the amount which Mr Basfar agreed in her contract of employment to pay her
with the amount actually paid. That is only the starting-point, however, as the contract stated that Ms Wong would
work eight hours a day, with one day off each week and one month off each year, whereas she was allegedly made
to work some 121/2 hours each day, with no days off and no annual leave, in abusive conditions. The cost of
purchasing an equivalent service in the labour market would be prohibitive, if anyone could be found who was
willing to provide it at all. In reality, an equivalent service would have required two employees, working in shifts.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
56

On any fair view of the matter, Mr Basfar has on the assumed facts made a substantial financial gain from his
exploitation of Ms Wong's labour, albeit not in cash but in money's worth. The exploitation has been a systematic
activity carried on over a significant period. It is accurately described as a commercial activity practised for personal
profit.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
57

That conclusion is confirmed by recalling the rationale for construing the words 'commercial activity exercised' by
the diplomatic agent as excluding a contract for ordinary domestic services, in contrast to the meaning given to
similar words in the context of state immunity. That rationale is the need to protect diplomats and their families from
hindrance in going about their daily lives in the receiving state. It would be not merely wrong but offensive to
suggest that conduct of the kind disclosed by the assumed facts of this case is incidental to daily life, let alone the
daily life of an accredited diplomat. Compelling a migrant domestic worker to provide her labour in circumstances of
**_modern slavery cannot reasonably be likened to paying for dry cleaning or ordinary domestic help. Unlike such_**
day-to-day living services, such exploitation is an abuse of the diplomat's presence in the receiving state and falls
far outside the sphere of ordinary contracts incidental to the daily life of the diplomat and family members which the
immunity serves to protect.
58
_(5) The travaux préparatoires_

It is not, in our view, necessary in this case to have recourse as a supplementary means of interpretation (pursuant
to art 32 of the Treaties Convention) to the preparatory work for the Diplomatic Convention. However, none of the
extensive references made by counsel for Mr Basfar to the preparatory work contradicts our conclusions resulting
from the application of art 31 of the Treaties Convention.
59

The discussion at the ninth session of the International Law Commission to which Lord Hamblen and Lady Rose
refer at para [116] of their judgment about unfair dismissal of domestic servants shows that the delegates did not
accept a proposal that there should be an exception to immunity from civil jurisdiction for ordinary employment
disputes There would have been no need for this proposal if such disputes fell within what became art 31(1)(c)


-----

That is consistent with our conclusion that employing a domestic servant is not itself a 'commercial activity'
exercised by a diplomatic agent within the meaning of art 31(1)(c). None of the preparatory work cited to us,
however, addressed the question whether a diplomatic agent should enjoy immunity from the civil jurisdiction of the
receiving state in an action relating to enslavement or exploiting forced labour for financial gain.
60

In _Reyes, at para [38], Lord Sumption extracted from his examination of the drafting history the point that the_
activities intended to be covered by art 31(1)(c) (and art 42) were 'activities involving the assumption by a
diplomatic agent of a dual status, by which incompatible occupations were being pursued by the same person'. The
expression 'dual status' is not used in any of the material to which Lord Sumption referred, but we agree with him
that a theme of the preparatory work mentioned by him was that engag

ing in a commercial activity outside the diplomat's official duties would be inconsistent with the dignity of a
diplomatic agent. For example, Lord Sumption quoted, at para [36], the report to the General Assembly on the tenth
session (ILC Yearbook 1958, Vol II, p 98, Commentary (7)) which commented on what became art 31(1)(c) in the
following terms:

'The third exception arises in the case of proceedings relating to a professional or commercial activity
exercised by the diplomatic agent outside his official functions. It was urged that activities of these kinds are
normally wholly inconsistent with the position of a diplomatic agent, and that one possible consequence of his
engaging in them might be that he would be declared persona non grata. Nevertheless, such cases may occur
and should be provided for, and if they do occur the persons with whom the diplomatic agent has had
commercial or professional relations cannot be deprived of their ordinary remedies.'

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
61

This reasoning accords with our view that exploiting the labour of a domestic worker for financial gain is a
commercial activity exercised by the diplomatic agent outside his official functions. Manifestly, such an activity is
wholly inconsistent with the position (and dignity) of a diplomatic agent. It is also a possible consequence of
engaging in the activity that the agent would be declared persona non grata. Nor if such cases occur is there a good
reason to deprive the victims of such exploitation of their ordinary civil remedies. As discussed above, the reason
why the normal employment of a domestic worker falls outside the scope of art 31(1)(c) is because it is an activity
that is incidental to the ordinary conduct of daily life, which is not itself a 'commercial activity' and for which personal
immunity is needed to ensure the efficient performance of the functions of diplomatic missions. The same cannot be
said about the activity of profiting from the forced labour of a domestic worker who is held in a state of servitude.
62
_(6) The rate of remuneration argument_

Although it did not convince the majority of this Court, the argument which chiefly led two Justices and the Court of
Appeal in _Reyes to express the view that exploiting a domestic servant is not a commercial activity was that the_
answer to this question cannot depend on the rate of remuneration which the individual is paid. In the Court of
Appeal Lord Dyson MR said, at para [34]: 'The fact that an employer derives economic benefit from paying his
employee wages that are lower than the market rate does not mean that he is engaging in a commercial activity.'
To similar effect, in his minority judgment in the Supreme Court, at para [46], Lord Sumption said that 'the
employment of a domestic servant to provide purely personal services cannot rationally be characterised as the
exercise of a commercial activity if she is paid less than the going rate or the national minimum wage, but not if she
is paid more'.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
63

These observations are clearly correct. It could not rationally be said that the defining characteristic of slavery –
whether in its traditional or modern form – is that a slave does not receive the national minimum wage or the market


-----

rate of remuneration for his services. That would be like saying that the essential difference between a prisoner and
a free person is that the rate of pay for prison work is less than the individual could earn in the outside world. While
true, it misses the critical distinction – which is between freedom and captivity. There are political and economic
theorists who argue that ordinary employment relationships involve the exploitation of labour – the most famous
example being Marx's theory of the appropriation of 'surplus value'. But such arguments command no general
consensus. What is internationally recognised is the distinction between the voluntary exchange of labour for
reward on the one hand and, on the other hand, work exacted through coercion in the form of slavery, servitude and
forced or compulsory labour.
64
_(7) 'Evolutionary' interpretation_

A question addressed in argument on the present appeal is whether the language of art 31(1)(c) should be given an
'evolutionary' interpretation which takes account of circumstances as they are now or a 'static' interpretation which
takes account only of circumstances which existed at the time when the Diplomatic Convention was concluded in
1961. This is itself a question of interpretation to be answered by applying arts 31 to 33 of the Treaties Convention.
As with domestic legislation, where a treaty is likely to remain in force for a long period of time, it is generally
reasonable to presume that the parties intended its language to be interpreted and applied in the light of the
circumstances which exist at the time when it is being applied. This presumption is particularly strong where the
words used are general or vague and refer to concepts that are fluid and may naturally be expected to alter over
time. As the International Court of Justice said in its judgment of 13 July 2009 in Dispute regarding Navigational and
_Related Rights (Costa Rica v Nicaragua) [2009] ICJ Rep 213, para 66:_

'… where the parties have used generic terms in a treaty, the parties necessarily having been aware that the
meaning of the terms was likely to evolve over time, and where the treaty has been entered into for a very long
period or is “of continuing duration”, the parties must be presumed, as a general rule, to have intended those
terms to have an evolving meaning.'

65

In the Navigational Rights case it was argued that the term 'comercio' (commerce) in a treaty made between Costa
Rica and Nicaragua in 1858 did not encompass transporting passengers in a river boat for profit on the ground that
such an activity did not fall within the scope of what was commonly called 'commerce' at that time. Applying the
general presumption expressed in the passage quoted above, the International Court of Justice held that, 'even
assuming that the notion of “commerce” does not have the same meaning today as it did in the mid-nineteenth
century, it is the present meaning which must be accepted for purposes of applying the treaty': para 70.
66
_(8) Developments of international law_

The International Court of Justice also noted in the Navigational Rights case, at para 64, that, where the meaning of
a term used in a treaty is capable of evolving, and is not fixed once and for all, this enables allowance to be made
for 'among other things, developments in international law'.
67

The principle that developments in international law since the conclusion of a treaty should be taken into account in
interpreting its terms is not only supported by the general presumption in favour of evolutionary interpretation; it is
also required by art 31(3)(c) of the Treaties Convention (quoted at para [17] above). In terms of structure, art 31
progresses from terms to context, through any agreements at the time of conclusion of a treaty, to subsequent
agreements, subsequent practice, and thence to relevant rules of international law. The juxtaposition, in particular,
in art 31(3) of the obligations to take into account (a) subsequent agreements, (b) subsequent practice and (c) 'any
relevant rules of international law applicable in the relations between the parties' logically indicates that
developments in international law subsequent to the conclusion of the

treaty are included: see Gardiner _Treaty Interpretation (2nd edn, 2015) pp 290, 298. This also reflects how art_
31(3)(c) has been understood and applied in case law: see eg the decisions referred to in A v Secretary of State for


-----

_the Home Dept (No 2)_ _[2005] UKHL 71,_ _[[2006] 1 All ER 575, [2006] 2 AC 221(para [29]) and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4J84-TMG0-TWP1-61D2-00000-00&context=1519360)_ _Rantsev v Cyprus_
[(App no 25965/04) (2010) 28 BHRC 313, (2010) 51 EHRR 1 (para 274), which take this for granted.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)
68
_(9) The relevance of developments in international law about modern slavery_

Lord Wilson in his judgment in Reyes, at para [67], said he was 'persuaded that, when agreeing to the terms of the

[Diplomatic] Convention, the parties would have rejected any suggestion that the proceedings brought by Ms Reyes
related to any commercial activity exercised by Mr Al-Malki'. He nevertheless considered that the meaning of art
31(1)(c) may have developed over the subsequent 56 years in accordance with the development of international
law over this period, 'in particular the emergence of an international prohibition against trafficking'.
69

Lord Wilson did not explain why he thought that the parties to the Diplomatic Convention would have rejected any
suggestion that the proceedings in Reyes fell within art 31(1)(c). For our part, we see no reason to draw such an
inference. But we also think that it is addressing the wrong question. In deciding whether the proceedings in Reyes
or in the present case fall within art 31(1)(c), the relevant question is not whether the parties to the Diplomatic
Convention, if informed of the facts of these cases, would have thought that they fell within art 31(1)(c). It is
whether, on the proper interpretation of the text which the parties adopted, the proceedings fall within the meaning
of that provision. To answer the latter question, the court must ascertain the common intention of the contracting
parties. But the process of identifying this intention is not one of trying to divine what was inside the minds of the
parties' representatives when they negotiated or signed the treaty (let alone what would then have been inside their
minds if they had been confronted with a question they did not in fact consider). It is simply a process of applying
arts 31 to 33 of the Treaties Convention. In the words of the International Law Commission, those provisions codify
'the means of interpretation admissible for ascertaining the intention of the parties': ILC Yearbook 1966, Vol II, pp
218–219, Commentary (5). Hence as it is put by one commentator, the 'intention of the parties' is:

'a construct to be derived from the articulation of the “means of interpretation admissible” in the process of
interpretation – and not a separately identifiable factor.'

See Bjorge The Evolutionary Interpretation of Treaties (2014) p 122; and also Gardiner Treaty Interpretation (2nd
edn, 2015) p 467.
70

Our interpretation of art 31(1)(c) does not assume or assert that the meaning of the words 'commercial activity
exercised by a diplomatic agent' has changed materially since the Diplomatic Convention was concluded in 1961.
We see no reason to suppose that it has. But nor in our view is it relevant to undertake a historical inquiry into what
the words meant in 1961 and whether or how their meaning and content has evolved since then. All that matters for
the purpose of this appeal is what meaning should be given now to the terms of art 31(1)(c) applying the principles
of interpretation codified in arts 31 to 33 of the Treaties Convention.
71

For reasons already given, we do not consider that international prohibitions against trafficking or other practices
similar to slavery are of any direct relevance to that question. As we have emphasised in commenting on the human
rights arguments advanced by the Special Rapporteur, the fact that an activity is illegal under international law or
violates human rights does not make it a 'commercial activity'. Nor do we suggest that the adoption of international
measures during the last 60 years to combat human trafficking and other forms of modern slavery and to secure
rights of compensation for victims has somehow caused such activities to become 'commercial activities'. If there is
a causal connection, it is the other way round. The adoption of such measures may reflect increased prevalence
and international awareness of such forms of exploitation of human beings for profit, as global migration has surged
and the world has become more inter-connected. An analogy might be drawn with money laundering. Money
laundering undoubtedly took place 60 years ago. But its scale, international awareness of it and the measures
taken to combat it have grown immensely in the period since then; and whatever the position might have been in
1961, it seems certain that a diplomat who profits by engaging in money laundering would today be regarded as
exercising a commercial activity.


-----

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
72

In interpreting and applying art 31(1)(c) of the Diplomatic Convention, the only relevance of international law
regarding trafficking and other forms of modern slavery, as we see it, is indirect. The critical distinction is between:
(1) ordinary domestic employment arrangements which are incidental to the daily life of a diplomat in the receiving
state and do not fall within art 31(1)(c); and (2) exploitation of a domestic worker for profit which amounts to a
'commercial activity' when practised by a diplomatic agent. We recognise that the distinction is not always a clear
one. But that does not make it any less real. On any view there is a fundamental factual as well as moral difference
between voluntary employment and slavery and between ordinary domestic service and domestic servitude. To
draw the distinction, criteria are needed; and to draw the distinction in interpreting and applying an international
convention, it is appropriate to derive those criteria from rules of international law applicable in the relations
between the parties. This is the respect, and in our view the only respect, in which rules of international law relating
to trafficking and other contemporary forms of slavery are relevant. For this purpose, for the reasons indicated at
paras [66]–[67] above, it is the present rules of international law to which it is necessary to have regard.
73
**F. MODERN SLAVERY IN INTERNATIONAL LAW**

The concepts of slavery, servitude and forced labour, together with human trafficking, are now often grouped
[together under the description of 'modern slavery'. The Explanatory Notes to the UK Modern Slavery Act 2015, at](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
para 4, describe modern slavery as 'a brutal form of organised crime in which people are treated as commodities
and exploited for criminal gain'. The United Nations also uses this concept, as exemplified by the existence since
2007 of a UN Special Rapporteur on 'contemporary forms of slavery'. So does the ILO, which has described
**_modern slavery as an 'umbrella term' that refers, essentially, to 'situations of exploitation that a person cannot_**
refuse or leave because of threats, violence, coercion, deception, and/or abuse of power': ILO 'Global Estimates of
**_Modern Slavery: Forced Labour and Forced Marriage' (2017) p 9. Underlying the use of the term 'modern slavery'_**
is the point that, in the words of Anti-Slavery International (the world's oldest international human rights
organisation):

'Today slavery is less about people literally owning other people – although that still exists – but

more about being exploited and completely controlled by someone else, without being able to leave.'

See Anti-Slavery International, 'What Is **_Modern Slavery?', quoted in G Gyulai, 'Slavery, Servitude and Forced_**
Labour in International Law: Should the Difference Still Matter?' (2021) 32 King's LJ 228 at 253.
74

The practices subsumed within the description 'modern slavery' are, however, the subject of separate legal
definitions.
75
_(1) Slavery_

The Convention to Suppress the Slave Trade and Slavery 1926 (the '1926 Slavery Convention') defines slavery, in
art 1(1), as 'the status or condition of a person over whom any or all of the powers attaching to the right of
ownership are exercised'. This represents the classic definition of slavery in international law and is reproduced, in
substance, in both the Supplementary Convention on the Abolition of Slavery, the Slave Trade, and Institutions and
Practices Similar to Slavery 1956 (art 7), and the definition of 'enslavement' in art 7(2)(c) of the Statute of the
International Criminal Court 1998.
76

The powers attaching to a right of ownership include the power to sell or otherwise transfer ownership and to use
what is owned as a possession, like livestock or furniture. Such 'chattel slavery' of human beings is nowadays rare,
but the language of the definition, with its reference to 'any' of the powers attaching to the right of ownership,
permits a more expansive interpretation. Thus, according to a report commissioned by the United Nations:


-----

'In the modern context, the circumstances of the enslaved person are crucial to identifying what practices
constitute slavery, including: (i) the degree of restriction of the individual's inherent right to freedom of
movement; (ii) the degree of control of the individual's personal belongings; and (iii) the existence of informed
consent and a full understanding of the nature of the relationship between the parties.'

See Abolishing Slavery and its Contemporary Forms, Office of the United Nations High Commissioner for Human
Rights (2002), para 21.
77
_(2) Forced Labour_

In the process of adopting the 1926 Slavery Convention, the Assembly of the League of Nations passed a number
of resolutions, including one which effectively requested the ILO to take over responsibility for addressing forced
labour, including 'the best means of preventing forced or compulsory labour from developing into conditions
analogous to slavery': League of Nations, Doc A.104.1926.VI, p 3. In 1930 the ILO adopted the Convention
Concerning Forced or Compulsory Labour (No 29), which has been ratified by 179 states. Article 2(1) of this
convention defines 'forced or compulsory labour' as 'all work or service which is exacted from any person under the
menace of any penalty and for which the said person has not offered himself voluntarily'.
78

Guidance given by the ILO supervisory bodies has helped to clarify each of the two elements of this definition: see
eg ILO, 'A Global Alliance against Forced Labour' (2005), paras 14–15 and Box 1.1. This guidance explains that the
'menace of any penalty' can take many different forms. Arguably, its most extreme form involves physical violence
or restraint. There can also be subtler forms of menace, sometimes of a psychological nature. Situations examined
by the ILO have included threats to denounce victims to the police or immigration authorities when their
employment status is illegal. Other penalties can be of a financial nature, including the non-payment of wages.
Indicators that the work is not being performed voluntarily include physical confinement in the work location,
deception or false promises about types and terms of work, retention of identity documents and withholding and
non-payment of wages.

_[1741](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:57YC-B771-DYNP-N0DM-00000-00&context=1519360)_
79
_(3) Servitude_

Unlike slavery and forced labour, the concept of servitude is not defined in an international convention, though it is
used in a number of international instruments including the Universal Declaration of Human Rights adopted by the
United Nations General Assembly in 1948, which states in art 4 that 'No one shall be held in slavery or servitude'.
The term 'servitude' is generally understood to refer to a form of exploitation which lies on a scale of gravity or
severity between slavery and forced labour and involves coercion. Thus, the US Supreme Court has interpreted the
phrase 'involuntary servitude', prohibited by the Thirteenth Amendment to the Constitution, to mean 'compulsion of
services through the use or threatened use of physical or legal coercion': see US v Kozminski (1988) 487 US 931 at
945. The European Court of Human Rights has held that, in art 4 of the ECHR, 'servitude' means an obligation to
[provide one's services that is imposed by the use of coercion: Siliadin v France (App no 73316/01) (2005) 20 BHRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)
_[654, (2006) 43 EHRR 287 (para 124). The Court has further described servitude as 'aggravated' forced or](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_
compulsory labour, distinguished by the fact or perception that it is impossible for the individual concerned to
change her situation: _CN v France (App no 67724/09) (judgment, 11 October 2012) (paras 90–91);_ _Chowdury v_
_Greece (App no 21884/15) (judgment, 30 March 2017) (para 99)._
80

To similar effect, a definition of 'servitude' included in the seventh revised draft of the Palermo Protocol, though not
in the final text, defined it as:

'the condition of a person who is unlawfully compelled or coerced by another to render any service to the same
person or to others and who has no reasonable alternative but to perform the service, and shall include
domestic servitude and debt bondage.'


-----

81
_(4) Human trafficking_

In contrast to slavery and forced labour, international consensus on a definition of human trafficking is much more
recent and was only arrived at in 2000 with the adoption of the Palermo Protocol, to which there are now 178 state
parties. Article 3 of the Palermo Protocol defines 'trafficking in persons' as meaning:

'the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having
control over another person, for the purpose of exploitation.'

'Exploitation' is stated to include:

'at a minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour
or services, slavery or practices similar to slavery, servitude or the removal of organs …'

Article 4(a) of the Council of Europe Anti-Trafficking Convention on Action against Trafficking in Human Beings
(2005) defines 'trafficking in human beings' in similar terms.
82

The definition of human trafficking has three elements:

(i)   the act: recruitment, transportation, transfer, harbouring or receipt of persons;

(ii)   the means (by which the act is done): threat or use of force, coercion, abduction, fraud, deception,
abuse of power or vulnerability, or giving or receiving

payments or benefits to a person to achieve the consent of a person who has control of the victim; and

(iii)   the purpose: exploitation, which includes the purpose of forced labour or slavery or servitude.

83
_(5) Is this a case of modern slavery?_

The application of these concepts to the facts of this case was not the subject of analysis in the proceedings below.
Ms Wong's ET1 claim form in the employment tribunal complied with the time-honoured rule that a party must plead
the material facts alleged and not their legal consequences. Apart from asserting that Ms Wong 'is a victim of
trafficking, who was exploited by [Mr Basfar] and his family', no reference was made to the legal characterisation of
her alleged treatment.
84

For the purpose of Mr Basfar's application to strike out the claim on the grounds of diplomatic immunity, the parties
agreed that the question for the tribunal was 'whether the respondent's employment of the claimant as a domestic
servant (in assumed circumstances of **_modern slavery) was a commercial activity exercised by the respondent_**
outside his official functions': see para 15 of the tribunal's judgment. The employment judge answered this question
in the affirmative, on the ground that this is what the majority of the Supreme Court would have decided in Reyes if
they had been required to determine this question. In the Employment Appeal Tribunal, Soole J reached a contrary
conclusion essentially on the basis that he should follow the clear view expressed by the Court of Appeal and the
minority of the Supreme Court in Reyes (on this point) in preference to the more tentative view expressed by the
majority of the Supreme Court. In neither judgment was there any substantive consideration of whether the facts
alleged amount to any of the various forms of modern slavery.
85

On the appeal to this court counsel for Ms Wong maintained that she is a victim of human trafficking and that she
was exploited in the UK by being held by Mr Basfar in domestic servitude. Mr Otty QC focused on the allegation of
trafficking and took the position that he did not need to rely on the concept of forced labour. He submitted that


-----

keeping Ms Wong in domestic servitude amounted to 'harbouring' her within the meaning of the Palermo Protocol
definition of trafficking.
86

For Mr Basfar, Mr Sethi QC submitted that Ms Wong should not be allowed on this appeal to rely on factual
allegations not pleaded in her claim form. For example, Ms Wong's written case mentions allegations that her
passport was held by Mr Basfar and that she was threatened with arrest if she ran away. Those allegations are not
pleaded. Nor is the fact that, since the Court heard oral argument, the Home Office has issued a 'conclusive
grounds' decision finding that Ms Wong was a victim of modern slavery – a matter on which counsel for Ms Wong
have also sought to rely in their written submissions filed after the hearing. We agree with the submission that this
Court should determine the appeal on the same agreed factual basis as the tribunals below. We have therefore not
included in our summary of the facts or taken into account in our assessment any factual allegations other than
those pleaded.
87

Mr Sethi QC also submitted that the facts pleaded by Ms Wong do not amount to trafficking within the international
definition. The high point of this argument is that, although Ms Wong asserts in her claim form that she is a 'victim of
trafficking' and alleges that she was brought from Saudi Arabia to continue working for Mr Basfar here and was
subjected to exploitation by Mr Basfar and his family in the UK, she does not expressly allege that she was
trafficked to the UK for the purpose of exploitation. Although not expressly stated, this is, however, clearly implicit in
the allegations made and is certainly an inference capable of being drawn from those allegations. We see no merit
in the suggestion that the claim form is defective for this reason.
88
The scope of 'harbouring'

The more substantial question raised on behalf of Mr Basfar is whether the acts capable of amounting to human
trafficking within the international definition ended when Ms Wong was received at Mr Basfar's residence in this
country or whether they continued while she worked there. Arguably, the former view is supported by the order in
which the acts that may constitute trafficking are listed in the definition. The list starts by referring to 'recruitment',
continues with 'transportation', 'transfer' and 'harbouring', and ends with 'receipt'. This can be read as intended to
capture what Lord Stephens described in oral argument as 'a consecutive series of activities' which ends with
arrival at a place or situation of exploitation.

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
89

In response, Mr Otty QC submitted that, on the assumed facts, the trafficking continued up until the moment of Ms
Wong's escape. He put this on the basis that, until that moment, Mr Basfar was 'harbouring' Ms Wong in his home,
by means of coercion and abuse of power or of a position of vulnerability, for the purpose of exploitation. All three
elements of the definition of human trafficking were therefore present. In support of this contention, Mr Otty QC
relied on a dictum in _R (on the application of BG) v Secretary of State for the Home Dept_ _[2016] EWHC 786_
_[(Admin), [2016] All ER (D) 74 (Apr) (para [49]), where Cranston J said:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JHR-T581-DYBP-N21M-00000-00&context=1519360)_

'Harbouring is not an everyday concept but I accept that it includes accommodating or holding a person at the
_place of exploitation or at a place prior to the exploitation.' (Emphasis added.)_

Mr Otty QC also cited a statement in the judgment of the European Court of Human Rights in Rantsev v Cyprus, at
para 281, that trafficking:

'implies close surveillance of the activities of victims, whose movements are often circumscribed … It involves
the use of violence and threats against victims, who live and work under poor conditions.'

It is implicit in this description that trafficking does not end on arrival at the place of exploitation but continues while
the victim is in a situation of exploitation.


-----

_[999](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:67HJ-0S33-RRKX-M00H-00000-00&context=1519360)_
90

A third source to which Mr Otty QC referred is the Explanatory Report to the Council of Europe Anti-Trafficking
Convention. However, this report explains that the list of actions contained in the definition of trafficking 'endeavours
to encompass the whole sequence of actions that leads to exploitation of the victim' (para 78). This tends to support
the view that trafficking, as defined, is concerned with the process by which a person is conveyed to a place where
exploitation will potentially take place rather than with what occurs at that place.
91

Because it seemed to us that arguments raised for the first time on this appeal cast doubt on whether the
exploitation of Ms Wong at Mr Basfar's residence in the UK comes within the internationally accepted definition of
'trafficking', the Court thought it right to seek further assistance from the parties on the form of **_modern slavery_**
disclosed by the assumed facts. To that end, the Court invited written submissions on whether, on the facts alleged,
the claim can properly be characterised as relating to forced labour and/or domestic servitude.
92

In their further written submissions counsel for Ms Wong argued that the alleged exploitation of Ms Wong in the UK
constituted domestic servitude (and a fortiori forced labour) and that those concepts are therefore applicable as well
as the concept of trafficking. Counsel for Mr Basfar argued the opposite and also submitted that Ms Wong 'should
not be permitted to run an entirely new and unpleaded case based on forced labour and/or domestic servitude
before the Supreme Court'.
93

We are unimpressed by the latter submission. Both parties were content to proceed below on the agreed basis that
Ms Wong was employed by Mr Basfar 'in circumstances of modern slavery' without further analysing the form of
**_modern slavery involved. It is Mr Basfar who introduced for the first time on this appeal an argument that the facts_**
alleged do not amount to 'trafficking'. If the proper legal characterisation of the facts alleged is to be considered, as
it should be, it is necessary to consider not only what is meant by 'trafficking' but also the concepts of 'forced labour'
and 'servitude', which are both forms of 'exploitation' within the Palermo Protocol definition. The fact that we do not
have the benefit of consideration of this subject by the tribunals below is not a reason to ignore it. The same can be
said about every point argued on this appeal (see para [84] above).
94
Academic commentary

There is a substantial body of academic learning on the concept of human trafficking in international law. Ms
Wong's case that the alleged facts fall within the scope of trafficking finds support in the work of Anne Gallagher
_The International Law of Human Trafficking (2010) p 30. Dr Gallagher argues that the references to 'harbouring' and_
'receipt' operate to bring not just the process but also the end situation of trafficking within the Palermo Protocol
definition. She bases this view on 'the plain meaning of the text' and says:

'The breadth of the action element has the effect of bringing, within potential reach of the definition, not just
recruiters, brokers, and transporters but also owners and managers, supervisors, and controllers of any place
of exploitation such as a brothel, farm, boat, factory, medical facility, or household.'

Dr Gallagher considers that this could potentially result in the concept of trafficking being extended to situations of
exploitation in which there was no preceding process. She gives as an example '[a] working environment that
changes from acceptable to coercively exploitative' (p 31).
95

Dr Gallagher's view is criticised by Vladislava Stoyanova in _Human Trafficking and Slavery Reconsidered:_
_Conceptual Limits and States' Positive Obligations in European Law (2017) at pp 33–42. Dr Stoyanova argues that_
the five actions enumerated in the definition of trafficking 'refer to a deceptive or coercive process that could
potentially lead to exploitation'. They are 'links in the chain of supply' and 'refer to the removal of affected persons


-----

from their home environment in order to be exploited for the gain of others in another location'. Among other
arguments, Dr Stoyanova makes the point (at p 38) that:

'if Gallagher's expanded vision of the definition of human trafficking is followed, then all the exploitative
practices included in the “purpose” element, including slavery, servitude and forced labour, have to be
relabelled as human trafficking, based on her interpretation of “harbouring” and “receipt”. The result would be
complete convergence between the concepts of trafficking, and of slavery, servitude and forced labour, which
would defeat the purpose for which these different concepts were introduced in international law.'

The interpretation contended for by Dr Stoyanova is shared by some other prominent legal scholars. For example,
Professor Jean Allain in _Slavery in International Law: Of Human Exploitation and Trafficking (2013) p 355,_
characterises human trafficking as 'the international supply chain into exploitation'.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
96
_(6) The question of taxonomy_

It is not, however, in our view necessary to resolve this difficult issue, for two reasons. The first is that, on the
assumed facts, Mr Basfar was plainly involved in trafficking Ms Wong, regardless of whether, strictly construed,
trafficking ceases (as is sometimes said) at the door of the workhouse. He clearly played a principal part in her
recruitment, transport and receipt, using the prohibited means and for the purpose of her exploitation. Secondly and
more importantly, our conclusion that his exploitation of her was a commercial activity does not depend upon which
particular manifestation of **_modern slavery may best describe his conduct, using the classification to be derived_**
from international Conventions. It is apt to bear in mind this observation of Gleeson CJ in the High Court of Australia
[in R v Tang [2008] HCA 39, [2009] 2 LRC 592, (2008) 25 BHRC 35 (para [29]):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-83C5-00000-00&context=1519360)

'It is unnecessary, and unhelpful, for the resolution of the issues in the present case, to seek to draw
boundaries between slavery and cognate concepts such as servitude, peonage, forced labour, or debt
bondage. … [These] concepts are not all mutually exclusive. Those who engage in the traffic in human beings
are unlikely to be so obliging as to arrange their practices to conform to some convenient taxonomy.'

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
97

It is sufficient that Mr Basfar's treatment of Ms Wong, on the assumed facts, amounted to a form of **_modern_**
**_slavery, whether it was forced labour, servitude or trafficking. This shows that the relationship between them was_**
not that of employment freely entered into, so as to be an ordinary part of Mr Basfar's daily life in the UK as a
resident diplomat. And it shows that his conduct amounted to a commercial activity practised (in so far as it matters)
for personal profit.
98
_(7) Does the claim 'relate to' the alleged commercial activity?_

It seems to us that the somewhat single-minded focus by the claimants in this case and in _Reyes on the term_
'human trafficking' to describe the matters complained of has had the effect of diverting attention from the
substance of the claims. Focusing on trafficking is open to the objection that the alleged trafficking of the claimant
was not itself a cause of loss to her or profit to the respondent, as any such loss and corresponding profit were the
result of exploitation at the claimant's place of work and not of the process by which she came to be there. On that
basis it might be said that, on the facts alleged, any acts of trafficking were not themselves a commercial activity
exercised by the respondent; nor do the claims 'relate to' trafficking, as they are founded on the alleged exploitation
of the claimants while they were working in the UK and not on the process by which they travelled to their place of
work.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
99


-----

There is some force in those objections when the emphasis is placed on the concept of human trafficking,
particularly if, as on one interpretation of the Palermo Protocol, trafficking ends where the exploitation which is its
purpose begins. But, on a proper analysis, the allegation of human trafficking is not essential to the claims made.
The gravamen of Ms Wong's claim is that she was exploited by being forced to work for Mr Basfar in the UK in
circum

stances of modern slavery. The case that the exploitation of her labour amounted to a commercial activity would
be just as cogent if Ms Wong had already been resident in the UK before working for Mr Basfar and had become an
employee of Mr Basfar in the UK freely but he had then treated her in the manner alleged after she entered his
service. Conversely, if Mr Basfar had engaged in trafficking by transporting Ms Wong to the UK using deception or
coercion for the purpose of exploitation but had then changed his mind and employed her on a regular and
voluntary basis, a claim for breach of her contract of employment would not, as it seems to us, fall within the art
31(1)(c) exception. On the facts alleged, the main relevance of the process by which Mr Basfar arranged for Ms
Wong's transfer to the UK to work for him (which amounted to trafficking under any interpretation of the Palermo
Protocol) is that it is an important part of the background which serves to explain how Ms Wong came to be in a
position of special vulnerability to his exploitation of her while in his domestic service.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
100

In cases of the present kind the forms of **_modern slavery primarily relevant, in our view, are likely to be forced_**
labour and servitude (which, as noted above, can be seen as an 'aggravated' form of forced labour). It is those
international law concepts which provide appropriate criteria for distinguishing between, on the one hand, the
voluntary employment of a domestic worker which is an ordinary incident of living in the receiving state and, on the
other hand, the exploitation of a domestic worker which is properly characterised as a commercial activity for the
purpose of art 31(1)(c) of the Diplomatic Convention. The assumed facts of the present case make it a paradigm
example of domestic servitude.
101
The potential for disputes

The allegations made in this case, and in other cases of alleged exploitation of domestic workers by diplomats, may
of course be disputed – in which event an evidential hearing is likely to be needed to determine whether or not the
action falls within the art 31(1)(c) exception to immunity. Particularly given the possibility that the allegation might be
spurious, such a hearing may itself be seen as liable to impede the functions of the mission to which the diplomat is
attached. In his judgment in the Court of Appeal in _Reyes_ _[[2015] IRLR 289, [2016] 1 WLR 1785(para [34]), Lord](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FJK-HTF1-DYPB-W314-00000-00&context=1519360)_
Dyson MR regarded the potential need to conduct 'a difficult fact-finding exercise' for this purpose as itself
constituting a reason for concluding that a case of the present kind does not relate to a 'commercial activity'. He
said it would be surprising if the parties to the Diplomatic Convention had intended that art 31(1)(c) should generate
such an inquiry.
102

We cannot agree with this reasoning. It is undoubtedly true that the efficient performance of the functions of
diplomatic missions would have received even greater protection if the immunity of diplomatic agents from the civil
jurisdiction of the receiving state had been entirely unqualified. In creating an exception from immunity for actions
relating to professional and commercial activities exercised outside a diplomat's official functions, the parties struck
a balance between the aim served by immunity and a competing interest in limiting opportunity for immunity to be
abused. It is inherent in the decision to create the exception that a fact-finding exercise may be required to decide
whether or not it applies in a particular case. One can imagine, for example, a civil claim made against a diplomat
alleging participation in a commercial fraud in which the diplomat denies involvement. Such an activity, if proved,
would clearly fall within the exception. But to resolve the dispute, a trial might be required. The same may be true,
even on the view of the minority of this Court in Reyes, in cases of alleged trafficking. Lord Sumption accepted, at
para [45], that a person who recruits or transports a trafficked person for money is likely to be exercising a
commercial activity, as is someone who receives a trafficked person for, say, prostitution. If an action involving such
an allegation were brought against a diplomat a trial might be needed to find the facts The possibility of such an


-----

inquiry is one which the parties to the Diplomatic Convention must be taken to have contemplated and accepted in
establishing the commercial activity exception. It cannot be a reason for excluding an allegation from the scope of
art 31(1)(c).
103
_(8) Jurisdiction of the employment tribunal_

A further point made on behalf of Mr Basfar is that an employment tribunal can only compensate a claimant for
claims that it has jurisdiction to hear and such claims do not include an action for trafficking. The same point could
be made about claims for compensation for subjection to servitude or forced labour, which equally are not claims
that an employment tribunal has jurisdiction to determine.

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
104

Ms Wong is not, however, claiming compensation for violation of her human rights through being trafficked or held
in servitude or required to perform forced labour. Those concepts are relevant only to rebut Mr Basfar's plea of
diplomatic immunity. There is no doubt that a court or tribunal has power to decide whether it has jurisdiction to
hear a claim. To decide whether or not the plea of immunity from the jurisdiction of the English courts is well
founded, it is necessary to determine whether Ms Wong's claim is an action 'relating to' a commercial activity
exercised by Mr Basfar outside his official functions. In their ordinary meaning, the words 'relating to' in art 31(1)(c)
require only that there should be a significant connection between the subject matter of the action and the
commercial activity exercised by the diplomatic agent, and not that the facts relied on to establish that the relevant
activity is 'commercial' should be limited to those which need to be proved as ingredients of the claimant's causes of
action. Such a connection is clearly present on the assumed facts of this case, as Ms Wong's allegations of
unlawful deductions from wages and failures to comply with the law relating to working time and the national
minimum wage arise directly from, and are part of, the exploitative conduct which is alleged for the purpose of
rebutting the plea of immunity to constitute a commercial activity.
105
_(9) The argument in terrorem_

Finally, we should notice an argument advanced on behalf of Mr Basfar that, if trafficked domestic workers who
have been forced to work for a diplomat in circumstances of modern slavery are allowed to make a civil claim in an
employment tribunal for wages wrongly withheld, British diplomats abroad might be exposed to retaliatory
measures. There are two problems with this argument. First, it is difficult to see how such a risk, even if genuine,
can affect the meaning of the phrase 'commercial activity' in art 31(1)(c). Second, there is no evidence to support
the existence of such a risk.
106

If the UK Government had considered this to be a real concern, it is to be expected that it would have intervened in
these proceedings to say so. The Secretary of State for Foreign, Commonwealth and Development Affairs has not
intervened on this appeal but did intervene by way of written submissions in the proceedings before the Court of
Appeal and the Supreme Court in _Reyes. In that intervention all that was said on this subject was that the court_
should

bear in mind that, if the protection granted by the Diplomatic Convention is eroded or restricted in this jurisdiction,
then the same limitations may well be applied to UK diplomats abroad. Such reciprocity is naturally to be expected.
It was not, however, suggested by the Secretary of State – and we see no reason to suppose – that the absence of
immunity during, as well as after, a diplomat's posting for an employment claim brought by a domestic worker who
claims to have been trafficked and held by the diplomat in conditions of modern slavery would impede the conduct
of British diplomacy. It is difficult to see how the theoretical possibility of such a claim could be thought to involve an
unacceptable interference with diplomatic functions any more than, for example, exposure to the possibility of a civil
action alleging participation in commercial fraud, which would on any view fall within the commercial activity
exception.


-----

_[987, 999, 1741, 4395](https://advance.lexis.com/api/document?collection=indexes-uk&id=urn:contentItem:5M7G-0WF1-DYNP-N339-00000-00&context=1519360)_
107
**G. CONCLUSION**

We conclude that, on the assumed facts, the claim brought by Ms Wong falls within the exception from immunity
provided for in art 31(1)(c) of the Vienna Convention on Diplomatic Relations. It follows that, if those facts are
proved, Mr Basfar does not have immunity from the civil jurisdiction of the courts of the United Kingdom. Unless
admissions are made, a hearing is therefore required to determine the truth of the allegations. Accordingly, we
would allow the appeal and reinstate the judgment of the employment tribunal refusing to strike out the claim.
108

**LORD HAMBLEN AND LADY ROSE:** The question raised by this appeal is whether a diplomat can assert his
immunity from suit as a defence to a claim brought by a domestic servant who worked for him and his family in his
residence here, in circumstances where he 'trafficked' her into the United Kingdom and where the treatment she
received at his hands and at the hands of his family was so harsh and unfair as to amount to exploitation. As has
been explained in the judgment of the majority, the answer to this question turns on whether, on the facts alleged,
Mr Basfar was exercising a commercial activity outside his official functions within the meaning of art 31(1)(c) of the
Diplomatic Convention.
109

There is much in the majority judgment with which we agree. First, we agree with the majority's conclusions on the
principles of interpretation in paras [16], [17] and [18]. We also agree with the majority's rejection of the human
rights arguments at paras [22] to [25], particularly with the conclusion that the exception to diplomatic immunity in
art 31(1)(c) is not based on whether the relevant activity is unlawful under international law or violates human rights:
para [25].
110

We agree that a comparison between state immunity and diplomatic immunity is unhelpful because the activities
which fall outside state immunity and which are sometimes described as 'commercial transactions' or 'commercial
activities' are much broader than the activities covered by the art 31(1)(c) exception. The distinction that is relevant
in state immunity is the distinction between the acts of the state, ius imperii and acts of a private character, ius
gestionis.
111

Most important, we would also conclude, as we understand the majority to conclude, that the normal employment of
a domestic worker (that is, employment not tainted by trafficking, forced labour or domestic servitude) does not
amount to 'commercial activity' within the exception. Our reasons for coming to that view, though, are rather
different from those of the majority. We do not agree that as a matter of ordinary language, a person exercises a
commercial activity when they buy goods or services for their personal use. The distinction between acting as a
consumer and acting as a business is an important distinction in many aspects of the law. We agree with Lord
Sumption's statement in Reyes at para [51] that 'There is no sense which can reasonably be given to art 31(1)(c)
which would make the consumption of goods and services the exercise [of] a commercial activity'.
112

The reason the normal employment of a domestic worker falls outside the definition of 'commercial activity' for the
purposes of art 31(1)(c) is because it is an activity that is incidental to the ordinary conduct of daily life and, further,
because the conduct of the daily life of the household is not itself a 'commercial activity'. A claim relating to that
employment is not, therefore, a claim relating to the exercise by the diplomatic agent of a commercial activity. To
put this another way, if a diplomat set up in business as an interior designer, that is likely to involve him or her in
employing people and buying in services and goods for use in the business. Any claims arising from those
employment contracts or acquisitions of goods and services for that business would fall within the exception. This
would not be because those transactions, looked at in isolation, amount themselves to the exercise of commercial
activity but because they are part and parcel of – and hence relate to – the exercise of the commercial activity,
being the interior design business. The question raised here is whether those transactions, whether one off or


-----

continuing, can themselves be commercial activity when they are not part and parcel of or incidental to some overall
professional or commercial activity.
113

We have concluded that they cannot. Where we disagree with the majority is in their conclusion that the conditions
under which a person is employed or how they came to be employed can convert employment which is not of itself
a 'commercial activity' exercised by her employer into such an activity falling within the exception. In summary our
conclusions are:

(i)   At the time that the Diplomatic Convention was concluded, the parties negotiating the terms were well
aware that domestic servants were engaged in diplomatic households. They were also well aware that
diplomatic agents sometimes engaged in egregious activities in breach of the laws of the receiving state.
They recognised, however, the importance of preserving diplomatic immunity despite the abuses that could
be expected to take place.

(ii)   In more recent years, the international community has demonstrated its abhorrence of trafficking,
**_modern slavery, forced labour and domestic servitude by entering into international instruments such as_**
the Palermo Protocol designed to eliminate these practices and ensure that those engaging in them are
punished. However, whether those developments have any effect on the meaning of the term 'commercial
activity' has to be ascertained by careful analysis of the relationship between the international instruments,
the development of jurisprudence in the state parties and the application of the principles underlying
diplomatic immunity. In our view, there is nothing that can be found in any of those sources to suggest that
the meaning of the term 'commercial activity' has been expanded so that it now includes trafficked
employment.

(iii)   The expansion of the exception in art 31(1)(c) to include trafficked employment or, more broadly, the
kinds of exploitative employment described by the majority, risks seriously undermining the scope of
diplomatic immunity. This is because of the uncertainty of the boundary between what is and what is not
covered and the intrusive nature of the enquiry that a tribunal will have to conduct in order to apply

the exception in this new way. It also risks exposing the United Kingdom's diplomats overseas to formal or
informal retaliatory measures.

(iv)   We do not consider that the appellant should be permitted to raise an alternative case based on
forced labour and domestic servitude at this very late stage in proceedings. We consider that the Supreme
Court should decide the case solely on the basis pleaded and on which the courts below proceeded; that
is, on the assumption that the facts alleged amounted to an allegation of human trafficking. In any event,
however, we do not consider that this altered focus changes the outcome of this case. Just as for human
trafficking, neither forced labour nor domestic servitude can constitute 'commercial activity' in
circumstances where they are not part and parcel of or incidental to some identifiable professional or
commercial activity.

114
**(1) Normal employment as 'commercial activity'**

It now seems to be beyond doubt that the normal employment of a domestic worker in the diplomatic household
does not amount to the exercise of a commercial activity on the part of the employer. This issue was considered in
detail by Lord Dyson MR in Reyes when it was argued on behalf of the claimant that normal employment was also
covered by the art 31(1)(c) exception. He examined the ordinary meaning of the phrase and concluded that as a
matter of ordinary language, a contract for the provision of services which are incidental to family or domestic daily
life is not 'commercial activity': para [14] of the Court of Appeal's judgment in Reyes. This view was confirmed by
the context of the phrase, in particular the link with art 42. As to the object and purpose of the phrase, it was clear
from the drafting history and the travaux préparatoires to which Lord Dyson referred that the participants in the
Vienna Conference: (i) did not consider that contracts of employment for the provision of domestic services at a
mission were already included within the concept of 'professional and commercial activities'; and (ii) did not favour
enlarging the scope of the exception to a diplomatic agent's immunity to include such contracts of employment.
Lord Dyson concluded:


-----

'[29] I cannot accept the broad interpretation of “commercial activity” for which Mr Otty [appearing for Ms
_Reyes] contends. It has little support in the jurisprudence or the commentaries. It would frustrate the principle_
of reciprocity and importance of diplomatic immunity. It would mean that there was no diplomatic immunity in
respect of any contract made between a diplomatic agent and another person for the supply by that other
person of goods or services for profit. Moreover, as Sir Daniel Bethlehem QC points out, effect has also to be
given to the important words “outside his official functions” in art 31(1)(c) of the 1961 Convention. There is no
immunity in the case of an action relating to “any professional or commercial activity exercised … outside his
official functions”. The employment of a domestic servant at a mission is an activity which is incidental to the
daily life of a diplomatic agent and enables him to perform his official functions.

[30] I conclude, therefore, that art 31(1)(c) does not deprive a diplomatic agent of immunity from civil suit by a
person employed at his official residence to carry out domestic services where the contract is not infected by
any allegation of trafficking. The next question is whether a contract of employment which is otherwise not a
commercial activity is rendered a commercial activity because the employee has been the subject of
trafficking.'

115

We agree with Lord Dyson that the signatories to the Diplomatic Convention were clearly aware that domestic
servants were employed in diplomatic residences. Article 1(g) defines 'members of the service staff' as members of
the staff of the mission in the domestic service of the mission; a 'private servant' is defined in art 1(h) as a person
who is in the domestic service of a member of the mission and who is not an employee of the sending State. These
definitions are important because other provisions of the Diplomatic Convention confer advantages on those falling
within those definitions. According to art 37(3), members of the service staff of the mission who are not nationals of
or permanently resident in the receiving State shall enjoy immunity in respect of acts performed in the course of
their duties. Domestic workers can claim exemption from dues and taxes on the payments they receive by reason
of their employment and the exemption from social security provision. Private servants also enjoy certain privileges;
see art 37(4).
116

We were also taken to extensive travaux préparatoires. These reveal that there was discussion about the role of
domestic staff in the context of considering how far they should share the immunities of the diplomatic family they
were serving. Beyond that, it appears that there was no intention to exempt employment issues generally from the
civil immunity jurisdiction. The Yearbook of the International Law Commission for 1957, Vol I records the
discussions of the ninth session considering the draft codification of the law relating to diplomatic immunity in May
1957. The issue of unfair treatment of domestic servants was raised as a possible additional exception to immunity
from jurisdiction by the Yugoslav delegate raising a point that had been put to him by the Yugoslav trade unions. He
suggested that some case law suggested that where diplomatic agents enter into contracts with domestic servants,
they thereby accepted the jurisdiction of the courts to deal with labour questions. He went on (p 95 of the 402nd
meeting on 22 May 1957):

'31. … However, in cases where diplomats were accused of dismissing servants without just cause or due
notice, the protocol department often intervened on the ground that the prestige of a foreign mission was at
stake. The only remedy then open to the aggrieved servant was to bring an action in the diplomat's own
country, a laborious and expensive matter seldom justified by the value of the claim involved. The problem was
further complicated by the fact that many States permitted their diplomatic agents to waive their immunity from
jurisdiction only with the prior consent of the ministry of foreign affairs. Thus, even if a diplomatic agent
accepted the jurisdiction of labour courts in a contract with a domestic servant, that acceptance might later be
shown to be invalid because he had not the prior consent of his minister of foreign affairs.

32. While it would be premature to talk of a definite rule that entry into a labour contract implied acceptance of
the jurisdiction of labour courts, there certainly was a marked trend in case law in that direction. The
Commission might consider whether to encourage that trend, or simply allow matters to take their course.'

117


-----

Mr Sandström, the Special Rapporteur, agreed that diplomatic immunity 'was often a source of inconvenience' but
this was not 'so great as to warrant making an exception to the rule'.
118

Lord Sumption in Reyes also emphasised the importance of considering reciprocity when construing the Diplomatic
Convention articles:

'[21](6) A wider scope for exception (c) would expose diplomatic agents in post in the United Kingdom (and
potentially British diplomatic agents abroad) to local proceedings not only in respect of their employment of
domestic servants but in respect of any transaction in the receiving

state for money or money's worth, save perhaps for those which were isolated or uncharacteristic. The
substantial effect would be to limit the immunity to acts done in the exercise of the diplomat's official functions,
even in the case of a diplomat in post. The immunity in respect of non-official acts would mean very little, for
every purchase that a diplomat might make in the course of his daily life from a business carried on by
someone else would be a commercial activity exercised by the diplomat for the purposes of art 31(1)(c). This
would be contrary to the carefully constructed scheme of the Convention for different categories of protected
person.'

119
**(2) Diplomatic immunity and egregious conduct by the diplomatic agent**

There are many instances in the travaux préparatoires where the conference delegates discuss abuses of immunity
by diplomatic agents. The choice whether to lift or retain the immunity against claims is nothing to do with the
disapproval or acceptability of such conduct. On the contrary, the discussions on the draft at the conference
frequently refer to the abuses of privilege that caused public protest in the delegates' home countries. There was
considerable debate about a proposal from the Netherlands to include a separate lifting of immunity for civil liability
for car accidents, particularly since the diplomat was likely to be insured: see p 171 of the UN Conference on
Diplomatic Intercourse and Immunities in spring 1961, Vol I. But despite such abuses there has been no revision or
cutting back of the protection afforded to diplomats from intrusive investigations into their non-commercial life. This
was explained by Professor Denza in the Introduction to her work _Diplomatic Law: Commentary on the Vienna_
_Convention on Diplomatic Relations_ (4th edn, 2016) ('Professor Denza's Commentary'). She describes the rules
protecting the sanctity of ambassadors and enabling them to carry out their functions as 'the oldest established and
the most fundamental rules of international law' forming 'a cornerstone of the modern international legal order'. She
went on:

'The second point which can be made is that the Convention has proved remarkably resilient to external
attacks. In the United Kingdom and in the United States in particular, the effect of a small number of appalling
or bizarre instances of abuse of diplomatic immunity during the 1980s, and of widespread resentment of the
flouting by diplomats and other privileged persons of parking restrictions, was a cry for revision of the
Convention or for new ways of combating perceived abuse. It would indeed have been possible, had the
political will been generally present, to have achieved some reduction of the protection given, in particular, to
the diplomatic bag. But Western governments were too well aware of the overall need for protection of their
diplomats and their missions abroad against terrorism, mob violence, and intrusive harassment from unfriendly
States to dispense with the essential armour provided by the Vienna Convention … The Convention was left
intact and in truth strengthened by the systematic re-examination it had undergone.'

120

Mr Otty QC drew our attention to the preamble of the Diplomatic Convention which states that the purpose of the
privileges and immunities conferred by the text 'is not to benefit individuals but to ensure the efficient performance
of the functions of diplomatic missions as representing States'. He asked how could it be said that the treatment
alleged by Ms Wong promoted the efficient performance of Mr Basfar's functions? We do not regard that as a
legitimate approach to construing the scope of the exception in art 31(1)(c). The preamble is intended to express
the underlying purpose of the Diplomatic Convention, but it cannot be relied on to restrict the extent of the


-----

diplomatic immunity to cover only those activities which might be said to increase their efficiency. We agree with
Lord Sumption in Reyes at para [12](3) that:

'Although the purpose of stating uniform rules governing diplomatic relations was “to ensure the efficient
performance of the functions of diplomatic missions as representing states”, this is relevant only to explain why
the rules laid down in the Convention are as they are. The ambit of each immunity is defined by reference to
criteria stated in the articles, which apply generally and to all state parties. The recital does not justify looking at
each application of the rules to see whether on the facts of the particular case the recognition of the
defendant's immunity would or would not impede the efficient performance of the diplomatic functions of the
mission.'

121

Thus, for example, art 41(3) provides 'The premises of the mission must not be used in any manner incompatible
with the functions of the mission as laid down in the present Convention or by other rules of general international
law or by any special agreements in force between the sending and the receiving State'. But that has not been
relied on to argue that if the premises are being used in an incompatible manner, that can affect the scope of the
immunities because the misconduct does not promote the efficient running of the mission. Conversely, the immunity
is lifted by the other paragraphs of art 31 in respect of activities which could not generally be regarded as
unacceptable or reprehensible, such as being the executor of an estate or an heir or legatee as a private person.
122
**(3) The 'trafficking dimension' at the time the Diplomatic Convention was concluded**

None of the parties in this appeal, or apparently in _Reyes, was able to point to any express discussion in the_
travaux préparatoires of the trafficking of domestic servants. But we are nevertheless satisfied that at the time the
Diplomatic Convention was concluded there was no intention on the part of the contracting states that the phrase
'commercial activity' could extend to a contract of employment where the worker was trafficked or otherwise
exploited. On this point we note that the Supreme Court in Reyes was unanimous. Lord Wilson, who expressed his
doubts about the answer proposed by Lord Sumption, accepted that when agreeing to the terms of the Diplomatic
Convention in 1961, the parties would not have regarded a claim brought by Ms Reyes as relating to any
commercial activity exercised by Mr Al-Malki. He said that he was persuaded that:

'… when agreeing to the terms of the 1961 Convention, the parties would have rejected any suggestion that
the proceedings brought by Ms Reyes related to any commercial activity exercised by Mr Al-Malki.' (Paragraph

[67].)

123

The doubts that the majority in the Supreme Court expressed in Reyes concerned whether the later developments
in international law demonstrating the determination of many states to take steps to punish and eliminate human
trafficking, particularly the adoption of the Palermo Protocol, could affect the interpretation of the exception so that it
could now be said to encompass trafficked employment. We turn then to consider the case put by Mr Otty QC to
this Court in the present proceedings as to the current meaning of the term and the conclusions arrived at by the
majority.
124
**(4) Has the meaning of 'commercial activity' changed over time?**

The case presented to the Supreme Court in Reyes and in this appeal as to the changing scope of the exception in
the light of international law develop

ments was a narrow one. As recorded by Lord Sumption in _Reyes, Ms Reyes had confined her argument to the_
proposition that the international obligation to recognise a crime and tort of human trafficking affected the scope of
the exception. It was not submitted before the Supreme Court in _Reyes that the exception had extended to_
trafficked domestic workers when the Diplomatic Convention was concluded in 1961 or that the exception extended
now to employment which did not fall within the definition of trafficking in the Palermo Protocol. Mr Otty QC's case
before us at the hearing was similarly narrow. He declined to be drawn on whether a domestic worker who could
t t bli h th t h h d b t ffi k d ithi th i f th P l P t l ld b bl t l th


-----

exception, since, he said, he did not have to argue anything that wide. Indeed, one of the issues in dispute at the
hearing was whether Ms Wong had sufficiently pleaded facts that amounted to trafficking within that definition. We
agree with the courts below and with the majority that the appeal should proceed on the basis that the pleaded facts
do allege trafficking within the meaning of the Palermo Protocol.
125

We would add that, in light of these pleaded and assumed facts concerned with trafficking, we do not consider that
Ms Wong should be permitted to raise an alternative case at this late stage based on forced labour and/or domestic
servitude. Ms Wong was invited by the Supreme Court to address this by written submissions subsequent to the
hearing, and so we make no criticism of her attempt to do so. However, Ms Wong's pleaded case and arguments
before the Employment Tribunal and Employment Appeal Tribunal were limited to human trafficking, as was the oral
argument before us. In oral submissions before this court Mr Otty QC expressly accepted that Ms Wong's case
rested on the international definition of trafficking being met. In our view, it would be inappropriate to allow Ms
Wong, following the hearing before this court, to advance for the first time this alternative case. We do not have the
benefit of the consideration of this case by the courts below and it would involve this court making effectively a first
instance determination, from which, moreover, there is no possibility of appeal.
126

In addition, we disagree with Ms Wong that the allegations made in her ET1 claim form are sufficient to permit her
claim nonetheless now to be characterised as relating to forced labour and/or domestic servitude.
127

Forced labour is defined in art 2(1) of the Forced Labour Convention 1930 (No 29) as 'all work or service which is
exacted from any person under the menace of any penalty and for which the said person has not offered himself
voluntarily'. It requires it to be demonstrated both that there is a threat of a penalty should the labour not be
performed and that the work is performed against the will of the person concerned (ie with an absence of consent or
free choice) – see, for example, the decision of the European Court of Human Rights ('ECtHR') in Van der Mussele
_[v Belgium (App no 8919/80) (1983) 6 EHRR 163, [1983] ECHR 8919/80 (para 34).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_
128

Servitude is the obligation to perform certain services imposed by the use of coercion and is linked with the concept
of slavery – see, for example, _Siliadin v France (App no 73316/01)_ _[(2005) 20 BHRC 654, (2006) 43 EHRR 287](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_
(para 124). It is a 'particularly serious form of denial of liberty' and 'corresponds to a special type of forced or
compulsory labour or, in other words, “aggravated” forced or compulsory labour' – see _CN v France (App no_
67724/09) (judgment, 11 October 2012), paras 89 and 91. As stated in that case at para 91, the distinguishing
feature between servitude and forced labour is the victim of servitude's feeling that their condition is permanent and
unlikely to change.
129

The ET1 and Ms Wong's Grounds of Complaint would not have been reasonably understood by Mr Basfar or his
legal representatives as relating to forced labour or domestic servitude. They assert that she is a 'victim of
trafficking'. They do not allege that she is a victim of forced labour, that there was a threat of penalty or that the
work was performed against her will. They do not allege that she is a victim of domestic servitude, or that there
were any aggravating factors which would turn a situation of forced labour into domestic servitude, that Ms Wong
felt her condition was permanent and unlikely to change, or that there were objective grounds for any such belief. In
our view Ms Wong could not succeed in a claim based on either forced labour or domestic servitude on the basis of
her claim as pleaded. This further persuades us that the claim should be limited to the assumed basis of human
trafficking as pleaded in the appellant's ET1 form. We focus therefore on solely the human trafficking context.
130

We need first to address the question whether the words 'commercial activity' are capable of changing their content
at all. Ms Wong relied on Dispute regarding Navigational and Related Rights (Costa Rica v Nicaragua) [2009] ICJ
Rep 213, para 64. In that case the International Court of Justice considered the meaning of the phrase 'for the
purposes of commerce' in the treaty between the two states, granting the right of free navigation to Costa Rica only


-----

for such purposes. Costa Rica argued that the phrase included tourism although no tourism existed at the time the
treaty was concluded. The Court referred to the Vienna Convention on the Law of Treaties 1969:

'64. … On the one hand, the subsequent practice of the parties, within the meaning of article 31(3)(b) of the
Vienna Convention, can result in a departure from the original intent on the basis of a tacit agreement between
the parties. On the other hand, there are situations in which the parties' intent upon conclusion of the treaty
was, or may be presumed to have been, to give the terms used – or some of them – a meaning or content
capable of evolving, not one fixed once and for all, so as to make allowance for, among other things,
developments in international law. In such instances it is indeed in order to respect the parties' common
intention at the time the treaty was concluded, not to depart from it, that account should be taken of the
meaning acquired by the terms in question upon each occasion on which the treaty is to be applied.'

131

The Court went on to hold that where the parties have used generic terms in a treaty, the parties necessarily having
been aware that the meaning of the terms was likely to evolve over time, and where the treaty has been entered
into for a very long period or is 'of continuing duration', the parties must be presumed, as a general rule, to have
intended those terms to have an evolving meaning.
132

Lord Sumption said at para [43] in _Reyes that there is nothing in the wording of the Diplomatic Convention from_
which one could discern that the concept of 'professional or commercial activity' was ambulatory:

'The expression does not express a general value whose content may vary over time. It is a fixed criterion for
categorising the facts, whose meaning and effect was extensively discussed during the drafting and negotiation
of the text. There is no reason to suppose that it refers today to anything other than what it referred to in 1961.'

133

On this point we respectfully doubt that conclusion to this extent: the phrase can have an ambulatory meaning in a
more limited sense. Businesses that did not exist in 1961 such as mining cryptocurrencies, designing computer
games or trading in financial derivatives might well, in our view, count as exercising a commercial activity even
though they were not activities that existed when the Diplomatic Convention was adopted. That is the sense in
which an ambulatory meaning was given to the term 'for the purposes of commerce' in the Costa Rica case so that
it included the transport of tourists on boats along the river even though no such tourism had taken place when the
treaty had been signed in 1858. It is not difficult to accept that the drafters of the Diplomatic Convention would
intend that the words could expand in their meaning over future years for that purpose.
134

Here, however, we are dealing with a different kind of ambulatory meaning. Human trafficking and the exploitation
of vulnerable workers did not start after 1961; it has always existed on varying scales. The question is whether the
adoption of measures by the international community exhorting countries to punish perpetrators and compensate
victims has changed the content of the phrase 'commercial activity' so that it now does encompass trafficking. It is
not possible simply to make the leap from the developments in the law as to human trafficking to a conclusion that
those developments have affected the meaning of words in an earlier international instrument. In addressing that
question, one must, as Lord Sumption said at para [42] of Reyes approach the matter using legitimate techniques of
interpretation, subject to principled limits. That much is also clearly established by the two cases in which similar
submissions were made: _Barnet London BC v AG_ _[2021] EWHC 1253 (Fam),_ _[[2022] 2 All ER 168, [2021] Fam](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:654C-44X3-CGX8-02WK-00000-00&context=1519360)_
404('Barnet') and Jones v Ministry of Interior of the Kingdom of Saudi Arabia (Secretary of State for Constitutional
_Affairs intervening), Mitchell v Al-Dali_ _[[2006] UKHL 26, [2007] 1 All ER 113, [2007] 1 AC 270('Jones').](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MSH-2RS0-TWP1-600Y-00000-00&context=1519360)_
135

In Barnet the argument before the Divisional Court (Sir Andrew Macfarlane P and Sir Duncan Ouseley (sitting as a
High Court judge)) concerned the effect, if any, of the adoption of the UN Convention on the Rights of the Child
(1989) (Cm 1976) on the scope of diplomatic immunity. More precisely, the issue before the court was whether the
positive obligations under art 3 ECHR, required a new exception which would apply where the diplomat was
d f b i hi hild i b h f th i t 3 i ht Th C t j t d b i i th t th UNCRC d


-----

the ECHR could have superseded the provisions of the Diplomatic Convention (which they referred to as the
'VCDR'):

'[115] … The parties to the VCDR would never have agreed to such a provision. The VCDR, codifying
customary international law, after extensive negotiations and consideration, leading to its specific text
governing international diplomatic relations, cannot have been superseded in any part by a Convention dealing
with the rights of children. Still more difficult is it to conclude that that has been achieved in so sensitive an
area, where the very purpose is to send diplomats and their families abroad safely, and entrust them to the
compliance with the VCDR by the receiving state, without so much as a word in the text of the later Convention
to the problem of diplomats' children. It is not possible to conclude that the UNCRC should be interpreted as
disturbing the VCDR, heedless of the real harm that would risk doing, and doing to the children of diplomats
abroad, as the UNCRC would be doing were the Applicant right. None of the Comments, for what they are
worth, suggested that either.'

136

This was a similar exercise to that which the House of Lords conducted in Jones. In that case the immunity invoked
was state immunity rather than diplomatic immunity but the approach is still instructive. The issue for the House was
to consider the balance currently struck in international law 'between the condemnation of torture as an international
crime against humanity and the principle that states must treat each other as equals not to be subjected to each
other's jurisdiction': para [1]. Lord Bingham of Cornhill described the new and important consensus of the nations of
the world as to the 'extreme revulsion' for the practice and fruits of torture, as expressed in the UN Convention
against Torture and Other Cruel, Inhuman or Degrading Treatment or Punishment 1984 (1990) (Cm 1775): para

[15]. The Torture Convention had come into force in June 1987 and both the UK and Saudi Arabia (with the
overwhelming majority of other states) were parties. It was also common ground that the proscription of torture in
the Torture Convention had, in international law, the special authority of ius cogens. The claimants' key submission
was that the proscription of torture by international law, having the authority it did, precluded the grant of immunity
to states or individuals sued for committing acts of torture. Such acts could not be governmental acts or exercises of
state authority entitled to the protection of state immunity ratione materiae.
137

Lord Bingham rejected that submission. He held that neither the prohibition on torture nor that on crimes against
humanity automatically overrode all other rules of international law. He said that it may very well be that the
claimants' contention would come to represent the law of nations but it could not be said to do so now. Lord
Hoffmann also rejected the submission that the fact that the prohibition on torture was ius cogens meant that it
overrode immunity:

'[45] To produce a conflict with state immunity, it is therefore necessary to show that the prohibition on torture
has generated an ancillary procedural rule which, by way of exception to state immunity, entitles or perhaps
requires states to assume civil jurisdiction over other states in cases in which torture is alleged. Such a rule
may be desirable and, since international law changes, may have developed. But … it is not _entailed by the_
prohibition of torture.'

He went on: (para [46]):

'Whether such an exception is now recognised by international law must be ascertained in the normal way from
treaties, judicial decisions and the writings of reputed publicists.'

138

Lord Hoffmann said further, at para [63], that international law is based on the consent of nations so that it is not for
a national court to 'develop' international law 'by unilaterally adopting a version of that law which, however
desirable, forward-looking and reflective of values it may be, is simply not accepted by other states'. He concluded
that there was nothing in either the Torture Convention or the United Nations Convention on Jurisdictional
Immunities of States and Their Property (2004) to indicate that a new exception was so recognised. He considered
judicial decisions of the International Criminal Court and the ECtHR and then national courts. Lord Rodger of
E l f d L d W lk f G ti th d L d C ll d ith b th L d Bi h d L d H ff


-----

139

The majority's judgment in the present appeal does not state that it is overruling the decision of the Divisional Court
in Barnet but it is difficult to see

how that decision can stand, assuming one regards child abuse falling within art 3 ECHR as being serious
misconduct which is widely condemned by the international community. It is true that the present appeal is different
from Barnet and Jones in that those cases were considering the insertion of a wholly new exception rather than a
new and wider interpretation of an existing exception. But the same principles must apply since the principle that
the words must mean the same for all signatories applies just as much to the proposed extension of meaning of an
existing exception as it does to the creation of a new exception. Further, the potential effect on diplomatic relations
– the risks of real harm to our diplomats abroad arising from disturbing the Diplomatic Convention to which the
Divisional Court referred in Barnet – is the same in both situations.
140

To adapt what Lord Hoffmann observed in para [46] of _Jones set out above to the facts of the present case,_
whether an exception to diplomatic immunity has come to be recognised by international law in the extension of the
phrase 'commercial activity' to the employment of a trafficked domestic worker must be ascertained from treaties,
judicial decisions and writings of reputed publicists.
141

So far as treaties are concerned, we consider that the same answer must be given as regards the effect of the
Palermo Protocol on the Diplomatic Convention as was given by the House of Lords in Jones as regards the effect
of the Torture Convention on the scope of state immunity. Mr Otty QC is not able to point to anything in the Palermo
Protocol that deals with the scope of diplomatic immunity. It cannot be the case that a treaty obligation to make
certain conduct a serious criminal offence is itself enough to require contracting states to lift immunity for that
conduct: the immunity of diplomats from criminal prosecution is complete and is not challenged in these
proceedings.
142

As to state practice, the jurisprudence from the courts of other parties to the Diplomatic Convention points very
firmly towards the continuing state practice being that the employment of trafficked domestic workers does not
amount to commercial activity for the purposes of art 31(1)(c).
143

We were taken to a series of cases in which the courts in the US have firmly rejected cases on similar facts to those
of Ms Wong. The primary authority to which these cases refer is an authority from the United States Tabion v Mufti
(1996) 73 F 3d 535, (1996) 107 ILR 452 ('Tabion'). We agree with Lord Sumption's comment in Reyes at para [22]
that decisions of the federal courts of the United States are a valuable source of law in this area, 'because of the
long-standing engagement of the US courts with international law and the existence of a highly developed body of
domestic foreign relations law belonging to the same tradition as our own'. In _Tabion the claimant worked as a_
domestic servant in the home of a Jordanian diplomat stationed in Washington. She brought an action alleging
breach of United States labour laws. The US Court of Appeals Fourth Circuit (on appeal from the District Court)
held that the term 'commercial activity' did not extend to include occasional service contracts but related only to
trade or business activities engaged in for personal profit. The Court concluded:

'Here, as in most cases invoking sovereign immunity, there may appear to be some unfairness to the person
against whom the invocation occurs. But it must be remembered that the outcome merely reflects policy
choices already made. Policymakers in Congress and the Executive Branch clearly have believed that
diplomatic immunity not only ensures the efficient functioning of diplomatic missions in foreign states, but
fosters goodwill and enhances relations among nations. Thus, they have determined that apparent inequity to a
private individual is outweighed by the great injury to the public that would arise from permitting suit against the
entity or its agents calling for application of immunity.' ((1996) 107 ILR 452 at 456.)

144


-----

Although Ms Tabion's claims included claims for low pay, long hours and false imprisonment, the case did not raise
squarely the question whether the conditions under which she worked affected whether her employment amounted
to 'commercial activity'. This was dealt with more directly in later cases. In Sabbithi v Al Saleh (2009) 605 F Supp 2d
122, the plaintiffs were domestic workers from India bringing an action against their former employers who were
Kuwaiti diplomats. They brought proceedings under the Trafficking Victims Protection Act of 2000 ('TVPA') and the
Fair Labor Standards Act. The plaintiffs had been employed by the defendants in their home in Kuwait prior to
moving to the US. It was alleged that in Kuwait they had worked long hours, seven days a week for small payment.
On coming to the US, they signed employment contracts promising to pay them considerably more and to comply
with US labour laws. These contracts were presented to the US Embassy in Kuwait for the purpose of obtaining
visas to authorise the plaintiffs to work in the defendants' home in the US. The plaintiffs claimed that once in the
US, the defendants did not comply with the terms of the contracts but maintained their exploitative treatment
depriving them of their passports, threatening them with physical harm and physically abusing one of them. When
they escaped and filed suit, Kuwait declined to waive immunity.
145

The arguments put forward by the plaintiffs in _Sabbithi relevant to the present appeal were (1) the defendants'_
alleged trafficking of the plaintiffs fell within the 'commercial activities' exception to immunity under the Diplomatic
Convention; (2) diplomatic immunity could not bar the plaintiffs' claims because the defendants' actions were so
egregious they violated ius cogens norms prohibiting slavery and slavery-like practices; and (3) the plaintiffs' claims
under the TVPA prevailed over the defendants' conflicting claims of diplomatic immunity according to the
'subsequent-in-time' rule. The District Court rejected those arguments. The court was not persuaded that the
defendants' alleged conduct constituted human trafficking and held that no ius cogens norm was at issue. But it
went on to say that, in any event, there was no evidence that the international community has come to recognise a
ius cogens exception to diplomatic immunity. The Court then went on to come to a different conclusion from the
Supreme Court in _Reyes, holding that the immunity extended after the defendants returned to Kuwait because it_
was part of the exercise of their diplomatic functions.
146

This has been the interpretation of art 31(1)(c) approved by the US courts in more recent cases. In 2011, the
claimant in Montuya v Chedid (2011) 779 F Supp 2d 60 alleged that she was brought to the US in August 2007 to
work in the home of the Lebanese ambassador as their domestic servant. She was forced to work long hours for
little pay and was verbally abused and insulted. She claimed she was not allowed to leave the defendants' home
and was illegally confined there. The court referred to the Sabbithi case and found the reasoning persuasive. The
court said in closing:

'The Court, moreover, is mindful that the [Convention] is not a unilateral document; what may prevent parties
from obtaining redress in our courts also serves to protect American diplomats and their families from what we
might consider as

legal abuses overseas. This balancing is a policy decision this Court should not challenge.' (Page 65.)

147

Finally as regards the US jurisprudence, the question of trafficking was raised squarely in Fun v Pulgar (2014) 993
F Supp 2d 470 (decision of the US District Court). There the plaintiff was offered work as a live-in domestic worker
for the family of a Peruvian diplomat working at the Permanent Mission of Peru to the United Nations. She was
supplied with an employment contract setting out favourable terms but once she arrived in the United States, the
defendants confiscated her passport and put her immediately to work. She alleged that the defendants' actions
created a human trafficking and alien harbouring enterprise in order to take advantage of her service as an
underpaid domestic servant. The plaintiff claimed damages and injunctive relief for being trafficked into the United
States by the defendants and forced to work against her will as their domestic servant for over six months. The
District Court still held that the claim did not relate to commercial activity within art 31(1)(c), applying Tabion. The
court did not regard the conditions under which she worked as capable of converting her employment into a
commercial activity.
148


-----

The only case on which Mr Otty QC could rely is the Portuguese case of _Fonseca v Larren (30 January 1991)_
reported in 'State Practice regarding State Immunities' edited by the Council of Europe. This was an appeal before
the Supremo Tribunal de Justiça. The report provided to us can be set out in its totality:

'The State's immunity from jurisdiction contained in the Vienna Convention on Diplomatic Relations aims at
ensuring the reciprocal independence of States and prevents States from being placed in the position of
defendants in the courts of another State. This rule is applicable also to the diplomatic agents of a State, but
only when the acts are practised on behalf of the State and for the purposes of the mission and not in case of
acts in their private capacity. Hiring a domestic servant for the private residence of a diplomat is an act outside
of the diplomatic functions of the agent and therefore not included in the immunity from jurisdiction.'

149

We have no reason to disagree with Lord Sumption's analysis of this case at para [33] of Reyes where, apparently
having access to a fuller report of the decision, he explained the result as arising from a principle of statutory
construction sanctioned by the Portuguese Civil Code which would not apply to a treaty in England. Curiously, the
page containing this report in the Court's appeal bundle contains a report of a later decision on 4 May 1994 in the
District Court of Lisbon in _Ramos v US_ (4 May 1994). In that case it appears that the Lisbon Court held that
'Portuguese courts are internationally incompetent to judge labour contracts entered into with the US Diplomatic
Mission in Portugal, since this State has not waived its immunity from jurisdiction.'
150

We accept that the Supreme Court in Reyes has already created a difference of interpretation by holding that the
employment of domestic workers is not part of the diplomat's official functions so that immunity for employment
related claims does not continue once the diplomat leaves office. The contrary conclusion has been reached by the
US Courts. Whether or not the majority judgment means that the US cases were wrongly decided is not the main
point here. The relevance of the US cases for present purposes is that they are very far from showing that there is
state practice to support a contention that the parties to the Diplomatic Convention have recognised that the
development of international law about trafficking and slavery has affected the meaning of the term 'commercial
activity' in the treaty to which they are all party.
151

As to writings of reputed international lawyers, we were shown nothing to suggest that legal writings recognise the
extension of the term 'commercial activity'. On the contrary, Professor Denza refers without criticism to the decision
of the US court in Tabion and to the application of that principle by the Court of Appeal in Reyes: see pp 251–252 of
her Commentary. She refers also in her Introduction to the resilience of diplomatic immunity in the face of evolving
human rights norms:

'There have been onslaughts on the protected status of diplomats, from those asserting that it cannot be
justified in the face of abuse of immunity and from those claiming that it must give way when it appears to
conflict with claims to access to justice or to human rights. In recent years diplomats have become conspicuous
and highly vulnerable targets for terrorist attack. In the face of these attacks the Convention has survived
unscathed. …

Subsequent developments in the functions of governments, the conduct of international relations, in trade,
travel, and communications altered in only marginal respects the main functions of diplomatic missions – to
represent the sending State and protect its interests and its nationals, to negotiate with the receiving State, to
observe, and to report. The basic rules which enabled those functions to be carried out have therefore
continued largely without change.'

152

We therefore agree with Lord Sumption's conclusion in Reyes that there is nothing either in the Palermo Protocol or
in the other international treaties, or in state practice or in academic writings to support the proposition that the
meaning of 'commercial activity' has changed since 1961 so that it now encompasses trafficked employment of the
kind Ms Wong alleges.
153


-----

For completeness, we add that even if Ms Wong's claim can be characterised and advanced as relating to forced
labour and/or domestic servitude (contrary to our conclusions at paras [125]–[129]), our view is that this makes no
difference to the question of whether Mr Basfar was engaged in 'commercial activity'. We consider that Ms Wong is
wrong to suggest that forced labour and domestic servitude amounts to a 'commercial activity' for the purposes of
art 31(1)(c) because a perpetrator makes financial savings by not paying the required rate for that labour. For the
reasons we have given above, in our view the correct approach is to consider whether the activity in which the
forced labour or domestic servitude is used can be considered a 'commercial activity'. The forced labour or
domestic servitude is not itself a 'commercial activity'. In the present case, Ms Wong's labour was clearly carried out
in a domestic setting rather than being put towards any kind of profit-making activity by Mr Basfar. The fact that, on
the assumed facts, Mr Basfar's treatment of Ms Wong was of an appalling nature does not mean that he was
engaged in a 'commercial activity'.
154

As Lord Sumption recognised in the context of human trafficking in Reyes at para [45], there is nothing inherent in
forced labour or domestic servitude that they be carried out in the exercise of a commercial activity. The
characterisation of working conditions as forced labour or domestic servitude does not depend on whether a
'commercial activity' is carried on by the perpetrator, nor on whether the perpetrator intends to make savings or a
profit, but rather on the perpetrator's treatment of the victim and whether it involves the denial of the personal
autonomy and dignity of the victim.
155
**(5) Problems arising from the majority's decision**

Ms Wong's appeal before the Court has been conducted on the basis that the facts she asserts in her pleaded case
before the Employment Tribunal are true. The majority judgment has set out those facts and, if true, they disclose
shocking and shameful mistreatment. The same was true of the facts assumed in Barnet that the diplomatic agent's
mistreatment of his children had been so severe as to amount to a breach of their art 3 Convention rights and in
_Jones where the claimants pleaded particulars of severe, systematic and injurious torture. Although this Court does_
not have to examine whether Ms Wong's allegations are true, that does not absolve us from the need to consider
the worrying difficulties that one can foresee arising from a decision that trafficked or other exploitative employment
is a 'commercial activity' for the purposes of the exception. We see these difficulties as arising on a number of
fronts:

(i)   The difficulty in defining what amounts to trafficking and the breadth of that definition;

(ii)   The intrusive nature of the enquiry that the tribunal would need to carry out to determine whether
immunity applied or not;

(iii)   The scope of the exception if it is extended beyond trafficking to cover other forms of slavery or
exploitative employment;

(iv)   The risks to the UK's diplomats abroad from the expansion of the exception.

156
_(a) The definition of trafficking_

As we have already noted, Mr Otty QC's submissions relied on the Palermo Protocol definition of human trafficking
for two purposes. The first was as showing the development of international law since the Diplomatic Convention
was adopted. We have dealt with that in the previous section of this judgment. The second was that the Palermo
Protocol provides a reasonably bright line for the purpose of defining the scope of 'commercial activity'. It is a
[definition that has already been reflected in statute in s 2 of the Modern Slavery Act 2015. This Court has already](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C254-00000-00&context=1519360)
had occasion, nonetheless, to comment on how difficult it is to determine whether the treatment of a particular
individual falls within the definition of trafficking or not. In Hounga v Allen _[[2014] UKSC 47, [2014] IRLR 811, [2014]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D2X-VY01-DYPB-W2BN-00000-00&context=1519360)_
1 WLR 2889Ms Hounga's claim for, amongst other things, unlawful race discrimination was met by a defence of
illegality by her employer who asserted that Ms Hounga had knowingly participated in presenting false documents
to the UK authorities in order to acquire a visa. The Supreme Court held that there was a public policy to which
barring Ms Hounga's claim would 'run counter' namely the prevention of human trafficking. This raised the question


-----

whether the evidence established that Ms Hounga had been trafficked. Lord Wilson JSC (with whom Baroness Hale
of Richmond DPSC and Lord Kerr of Tonaghmore JSC agreed) dealt with the question as follows:

'[49] The tribunal made no finding whether Miss Hounga was the victim of trafficking. No doubt it considered
that it had no need to do so. It is only at this third level of appeal that the issue crops up again; and this court's
duty to be fair to [the employer] demands that it should approach the issue with the utmost caution.
Nevertheless, although the court should remember, for example, that Miss Hounga was not actually locked into
the home, it is hard to resist the conclusion that Mrs Allen was guilty of trafficking within the meaning of the
definition in the Palermo Protocol. Thus, of the ILO's six indicators of forced labour, there might be argument
about the existence of the second (restriction of movement) but, on the tribunal's findings, there certainly
existed the first (physical harm or threats of it), the fourth (withholding of wages) and the sixth (threat of
denunciation to the authorities where the worker has an irregular immigration status). Judicious hesitation leads
me to conclude that, if Miss Hounga's case was not one of trafficking on the part of Mrs Allen and her family, it
was so close to it that the distinction will not matter for the purpose of what follows.'

157

Lord Wilson did not have to arrive at a definite conclusion as to whether Ms Hounga was trafficked since he
concluded that to uphold her employer's defence of illegality would run strikingly counter to the policy against
trafficking and in favour of the protection of its victims.
158

A useful illustration of the task that awaits courts and tribunals if they are required to determine whether a claimant
has been trafficked as a preliminary issue of jurisdiction in a claim against a diplomat can be seen in the case of
_Ajayi v Abu_ _[2017] EWHC 3098 (QB),_ _[[2018] IRLR 1028. Judge Alison Hampton was considering claims by Ms](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TH7-TSJ1-DYPB-W02B-00000-00&context=1519360)_
Ajayi for compensation for being the victim of human trafficking. The trial in the Queen's Bench Division lasted five
days and resulted in a judgment of 126 paragraphs. Her factual findings covered the period between when Ms Ajayi
first started work for the Abu family in the summer of 2005 until she was expelled from the household in March
2015. The judge heard evidence from the defendants, from members of the family and their friends, from a director
of Anti-Slavery International who provided his opinion to the court on whether Ms Ajayi could be said to be a victim
of trafficking, and from a psychiatrist. The judge prefaced her analysis of the factual witnesses and her findings of
fact by describing the difficulties facing her – difficulties which are likely to face any judge considering whether a
claimant has been the victim of trafficking:

'[52] It is judicial experience that those involved in disputes within family relationships or other close personal or
domestic relationships which have failed have a natural inclination to reinterpret past events in either vengeful
or self exculpatory terms. This is particularly so in the present case where the claimant's expectations of the life
she was expected to lead in the United Kingdom, including her education, had not been met, I find that she has
a genuine and justified sense of grievance against the defendants. I also find that the defendants feel a sense
of grievance that the claimant has turned against them, after they provided her with a home and assisted her
with education and the opportunity to remain in the United Kingdom.'

159

The judge found that Ms Ajayi had exaggerated her claim in some respects. She found that Ms Ajayi had never
been physically abused or locked into the family home. She had received cash payments from time to time and had
been free to go to college and to carry out voluntary work at church. But on the issue of whether her treatment
amounted to trafficking, the judge concluded that it did, since the control on an individual does not require physical
restraint, violence, or the threat of violence, to be effective and coercive. She found that the claimant was indeed
the victim of trafficking and harassment within the meaning of the 1997 Act.
160

It appears therefore that if the test for 'commercial activity' is indeed the test for human trafficking set out in the
Palermo Protocol, the circumstances in which immunity may be lifted are not limited to extreme cases of zero
payment, virtual imprisonment in the family home and physical abuse. It is no answer to this point to say that Ms


-----

Wong's allegations as set out at paras [8] and [9] of the majority judgment are at the more extreme end of what
amounts to

human trafficking. If trafficking and exploitation amount to exercising 'commercial activity' as the majority conclude,
the immunity may be lifted whenever the test is satisfied, not simply when it is satisfied in a particularly egregious
form. The Employment Tribunal may find, having investigated Ms Wong's allegations that some of what she claims
is exaggerated and that, for example, she was never made to wear a door-bell round her neck, that she was
provided with meals every day and allowed to speak to her family using Mr Basfar's phone once a month. Would Mr
Basfar's conduct still be such as to lift his immunity from suit? The majority judgment does not assist because there
is no indication which of the vulnerable characteristics and identifying factors listed in paras [45]–[51], singly or in
combination, need to be present before the employment relationship amounts to 'commercial activity'. The majority
judgment refers throughout to Ms Wong as a 'migrant' domestic worker. It is not clear – but it needs to be clear if
this test is to be applied by employment tribunals – whether the exception is limited to 'migrants'. If so then the
serious mistreatment of domestic workers engaged by the diplomat but who are resident in this country cannot
amount to 'commercial activity' even if they, like a typical migrant worker, have no network of supporters in this
country to whom they can turn for help.
161
_(b) The intrusive nature of the exercise in which employment tribunals will need to engage_

The judgment in the _Ajayi v Abu case illustrates the exercise on which tribunal judges will need to embark in_
deciding whether the 'commercial activity' exception applies. The issues covered in the judgment include: the
claimant's conduct during periods of prayer within the family home; the claimant's attendance at the family's church;
what percentage of the family's ironing was carried out by the claimant; to what extent Ms Ajayi did the school run
to collect the children. There was a dispute between the parties as to whether Ms Ajayi had ever been paid and, if
so, how much. This required an analysis of Mr Abu's bank statements. We cannot accept that the signatories of the
Diplomatic Convention envisaged that such an exercise was an appropriate one for courts and tribunals to
undertake in order to decide whether the exception in art 31(1)(c) applies.
162

It is no answer, in our judgment, to say that Mr and Mrs Basfar can rely on art 31(2) of the Diplomatic Convention
which prevents them from being compelled to give evidence. It cannot be the case that the exception is recognised
only because it is likely that future defendants will consider themselves unable to defend the proceedings because
of the intrusive examination of their home life that would be required to refute the allegations.
163
_(c) The wider definition of exploitation_

The majority's judgment extends the meaning of 'commercial activity' to employment relationships other than those
which fall within the definition of trafficking set out in the Palermo Protocol. The judgment refers to the international
concepts of servitude and forced labour as marking the dividing line between on the one hand the consensual
employment of a housekeeper or other domestic worker which is not to be treated as a commercial activity and 'a
form of modern slavery' which is. Underlying the majority's judgment is the assumption that there is a boundary
with servitude or forced labour on one side of it and voluntary employment on the other side. In our view there is,
rather, a broad spectrum between those who are in the fortunate position of working in congenial conditions and
being free to leave their jobs when they please on the one hand and victims of trafficking, servitude and forced
labour on the other. Many people in the UK and elsewhere work long, anti-social hours in unpleasant conditions
doing menial work for low pay and having to put up with rude, bullying employers. They cannot afford to leave their
jobs; they have families to feed and bills to pay and the alternatives open to them are very limited and unlikely to be
much better. But they are not generally regarded as 'slaves' or as working in 'forced servitude'.
164

We accept that the phrase 'commercial activity' chosen by the drafters of the 1961 Convention is vague. The state
parties must have expected there to be disputes about what was excepted and what was not. However, here the
uncertainty arises because the factors considered relevant are not in any other context regarded as indicia of


-----

whether an activity is 'commercial' or not, such as the degree of psychological abuse by one counterparty to the
other or restrictions on a counterparty's liberty.
165

The one aspect of the employment relationship which clearly is 'commercial' is the pay. Ms Wong accepts that she
was paid something although it was a small fraction of her contractual entitlement. But we accept that trafficking
and exploitation are not limited to situations where there is no payment at all. The majority refer to the element of
profit on the part of the employer that arises when he obtains the worker's services for less than he should pay.
This, the majority say, is an indicator of the commercial nature of the activity of employing an exploited domestic
worker although it does not appear that they regard it as a necessary element. They do not identify what degree of
disparity between the pay given to the claimant and an acceptable rate of pay is essential before the employer is
regarded as profiting unfairly thereby turning the relationship into the exercise of 'commercial activity' for the
purposes of art 31(1)(c).
166

In so far as lower than normal pay is relevant to the issue, it raises another area of uncertainty as to the correct
comparator for normal pay. The majority propose a comparison between the worker's actual pay and the amount for
which the worker would 'willingly' have provided the services or for which equivalent services could have been
purchased in the labour market. Such a test raises serious issues, for example whether the labour market under
consideration is the labour market in central London or the labour market in the sending state where Ms Wong was
initially employed and where the cost of living is substantially lower.
167
_(d) Reciprocity and risks of retaliation_

Professor Denza says in the Introduction to her Commentary:

'… reciprocity forms a constant and effective sanction for the observance of nearly all the rules of the
Convention. Every State is both a sending and a receiving State. Its own representatives abroad are in some
sense always hostages. Even on minor matters of privilege and protocol, their treatment may be based on
reciprocity. For the most part, failure to accord privileges or immunities to diplomatic missions or to their
members is immediately apparent and is likely to be met by appropriate countermeasures.'

168

The risks to which an expansive or unusual interpretation of the exception in art 31(1)(c) may expose the United
Kingdom's diplomats abroad has been commented on in various decisions. It was a point made in the evidence
lodged by the Foreign, Commonwealth and Development Office in Barnet. The court in that case was provided with
a witness statement of Ms MacMillan MVO, Deputy Director of the Protocol Directorate and Assistant Marshal of the
Diplomatic Corps. She referred to art 47(2) of the Diplomatic Convention. Article 47 provides that in the applica

tion of its provisions, the receiving state shall not discriminate as between States. But there is an exception in art
47(2) that discrimination shall not be regarded as taking place where the receiving State applies any of the
provisions of the present Convention restrictively because of a restrictive application of that provision to its mission
in the sending State. Ms McMillan's evidence was that the failure of a state to respect the immunities of diplomatic
staff in its own territories might expose its own diplomats to 'harsher treatment abroad, by way of reprisal' (para 51).
169

A restrictive application of the immunity granted by art 31 by this court may well be met by a restriction on the
immunity granted to UK diplomats in Saudi Arabia. No doubt, as Mr Otty QC submitted, it is most unlikely that UK
diplomats are involved in human trafficking or in treating their domestic staff in the way that Ms Wong alleges that
she has been treated. But the retaliation does not have to be limited to such a specific tit for tat. The court in Barnet
quoted from Ms MacMillan's evidence making this point:

'(1) The first is the reality that many of the 192 States Parties to the VCDR are not equipped with fair, effective
and independent judicial systems and law enforcement agencies. Our diplomatic staff (and their families) could
face politically motivated charges (and possibly arrest and detention) which would both put their safety and


-----

security at risk, but also prevent them from carrying [out] their vital work on behalf of the UK. This would be a
particular risk if the mission or instructions were politically unpopular in the relevant receiving State, or if the
conditions in that State deteriorated. These sorts of risks are precisely what the rules enshrined in the VCDR
were intended to avoid.

(2) Secondly, an exception to inviolability or immunity made unilaterally on one basis (for example, child
welfare) could easily be extended to encompass other factual situations (for example, public security, public
morality or blasphemy) and other provisions of the VCDR, not just by the courts and legislature in the UK, but
also by those of other States.' (Paragraph [55].)

170
**(6) Conclusion**

We, like the majority in this appeal, have every sympathy with the plight of trafficked domestic workers. We share
the dismay of Lord Wilson at the apparent proliferation of serious cases of domestic servitude here in the UK,
particularly in the homes of diplomats: see paras [59] and [68] of Reyes. But there are larger issues of international
comity at stake here. We were told during the hearing that Ms Reyes has been unable to enforce the judgment she
obtained against Mr Al-Malki after her appeal was allowed by the Supreme Court. The majority in the present
appeal accept, as they must, that even if Ms Wong succeeds in her tribunal claim, there will be nothing she can do
to enforce the judgment against Mr Basfar. The outcome of _Barnet shows that Ms Wong and those wishing to_
support her have alternative routes to achieve as much as they can hope to achieve from this litigation. The
Divisional Court in _Barnet records that after the Secretary of State had invited the sending state to waive the_
diplomatic immunity of the father and family, the sending state refused but recalled the father with immediate effect.
Shortly after, the Secretary of State informed the sending state that the father and the rest of the family were
personae non gratae and were required to leave the UK at the first opportunity.
171

All these steps can and should be taken within the parameters of the established international order and without
taking the unprecedented step that the majority judgment takes in this appeal.
172

We would therefore dismiss the appeal.

**End of Document**


-----

