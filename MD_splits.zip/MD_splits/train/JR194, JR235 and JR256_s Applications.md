# JR194, JR235 and JR256's Applications [2024] NIKB 46

NORTHERN IRELAND KING'S BENCH DIVISION

COLTON J

06 JUNE 202406 JUNE 2024

**Asylum seeker — Age assessment — Application for judicial review of common issues concerning age**
**assessments for applicant for asylum who claimed they were minors — Applicant also having raised issues**
**about delay in determining asylum claims — Present application dealt solely with question of age**
**assessments — Applicant was Somali national who claimed asylum in UK — Applicant submitted**
**statement of evidence to home office in support of trafficking claim — Applicant having claimed asylum in**
**several European countries during his travels before reaching united kingdom — Covid pandemic and**
**Brexit both having intervened resulting in delay — UK accepted it would deal with applicant case —**
**Immigration authorities in Finland claimed that applicant had applied for asylum with ID showing date of**
**birth in 2003 — Applicant having been denied asylum in Finland when he later applied using an ID with**
**1993 as year of birth — UK authorities determined that applicant was victim of modern slavery — Applicant**
**was informed by authorities that age assessment was being carried out — Applicant was granted refugee**
**status but year of birth was determined as 1993 which was refuted by applicant — Applicant challenged**
**delay in age assessment as well age assessment itself — Whether UK authorities erred in age assessment**
**— Whether applicant was being honest about evidence provided regarding his asserted year of birth of**
**2003.**

**COLTON J:**

**_Introduction_**

**[1] These judicial reviews were heard together as they raised common issues concerning age assessments for**
applicants for asylum who claimed they were minors. The cases of JR194 and JR235 also raised issues about
delays in determining their asylum claims. In this judgment I will deal solely with the question of age assessments.

**_JR194_**

**[2] The Applicant is a Somali national. He came to the attention of the authorities in the United Kingdom in August**
2019. He claimed asylum on 5 September 2019. He gave his date of birth as 22 April 2003. On 29 September 2019
he submitted his statement of evidence to the Home Office as the Single Competent Authority (“SCA”) in support of
a trafficking claim.

**[3] He submitted a statement in support of his asylum claim on 9 December 2019. This included an account of his**
travels through Europe before reaching the United Kingdom. It transpired the Applicant had claimed asylum in
several countries. Under Regulation (EU) No.604/2013 (“the Dublin III Regulations”), the first country in which he
claimed protection would have been deemed responsible for dealing with his case. However, the Covid pandemic
and Brexit both intervened. The UK accepted it would deal with the Applicant's case.


-----

**[4] In accordance with standard practice at that time a EURODAC search was undertaken. The search was based**
on the use of fingerprints. Everyone aged 14 years or over who claims asylum or international protection in
participating countries is fingerprinted.

**[5] The search revealed that his prints were taken in other participating States and recorded on the EURODAC**
system on the following dates:

- 9/6/15 - Finland (KEMI);

- 9/12/16 – Germany (Nuremberg);

- 15/2/17 – Germany (Hamburg);

- 18/10/17 – Germany (Neumünster);

- 8/9/18 – Sweden.

**[6] As a result of this information requests under art 34 of the Dublin III Regulations were made.**

**[7] The immigration authorities in Finland and Sweden confirmed that he claimed asylum there, and in Germany,**
before arriving in the UK.

**[8] On 29 September 2020, the Home Office received a reply from the Swedish authorities confirming the Applicant**
presented under a different identity, born on 22 April 2003 when he claimed asylum. Mr Henry has confirmed that
the Applicant's name is not contentious in this case, only his date of birth.

**[9] On 2 October 2020, the Home Office received a reply from the Finish authorities confirming that the Applicant**
was refused asylum there after presenting as an adult born on 1 September 1993. He absconded from Finland. The
Finnish authorities confirm the Applicant claimed asylum in Germany. Finland agreed to a take-back request made
by Germany, but the Applicant absconded before it could be actioned.

**[10] Meanwhile in this jurisdiction, on 1 April 2020, a Care Order pursuant to art 50 of the Children (Northern**
Ireland) Order 1995, in respect of the Applicant was made in favour of the Belfast Health and Social Care Trust
(“the Trust”) by HHJ Millar KC. This was on the basis that the Applicant was a child in accordance with his claimed
date of birth of 22 April 2003.

**[11] On 18 September 2020, the SCA decided the Applicant was “a victim of modern slavery” in 2013 and 2018.**

**[12] In November 2020, the Respondent informed the Applicant's social worker of the information from Finland and**
Sweden and asked that an age assessment be carried out.

**[13] The Trust reacted by emailing all of those involved with the Applicant in Northern Ireland on 27 November**
2020 setting out the information that had been provided by the Respondent. The email concluded:

“Could we devise a co-ordinated plan of how this information will be approached with (JR194).”

It did not include the Respondent in this discussion. On 27 November 2020, the Applicant's solicitor replied
providing the Trust with general observations about reasons why asylum seekers sometimes supply the wrong date
of birth to authorities. The email indicated that she would obtain clear instructions from the Applicant to confirm the
situation. In the correspondence the Applicant's solicitor wrote:

“Given that there has been no concerns regarding (JR194's) age since his arrival in the UK, I would strongly
advise the Trust to state to the Home Office that there are no concerns with [the applicants'] age.”

**[14] On 1 December 2020, the Applicant's solicitor wrote to the Applicant's social worker, the Trust and Barnardo's**
in the following terms:


-----

“Hi all

Further to my consultation with (JR194), I have had the following confirmed:

1 (JR194) states that he was also in Greece with the adult referred to in the below email. This adult advised
(JR194) to state that he was an adult, indeed, we believe the date of birth was given to the services on his
behalf. (JR194) states that the authorities queried whether he was younger than what was stated, and after
investigation, it was determined that he was a child.

2 The adult who was with him told (JR194) that if he were to say his true age, that would only cause problems
for him in the future. In Sweden and Finland, the adult once again pressured (JR194) into stating that he was
an adult.

3 In Sweden, (JR194) was on his own out getting milk one day and was arrested by the authorities
(presumably for having no status) and it was then that he stated his real age without the pressure of the adult
who was with him. (JR194) states that he was then age assessed in Sweden by a medical professional and
determined to be a child as he had stated.

All of the above confirms my previous suspicions that (JR194) was pressured by the adult that was with him to
state an incorrect age. Again, it is commonplace that young people in this position do claim that they are adults.
I would strongly advise against any age assessment in light of the above, and in light of the fact that no doubts
or queries were raised by any professionals in Northern Ireland about (JR194) since his arrival over a year ago.
I would also strongly advise the Trust to get back to the Home Office without delay, as I understand that
scheduling substantive interviews is imminent, and (JR194) has been waiting for an extremely long time for his
interview. It is to his credit that he has displayed such patience in what has been a frustrating and traumatising
wait for him. …”

**[15] On 16 December 2020, a social worker on behalf of the Trust attempted to send a one sentence email to the**
Home Office declining the request to conduct an age assessment. I say attempted because it emerged from the
affidavit evidence that the email, refusing to do the age assessment, was addressed to the wrong person and the
wrong email address. Thus, it never arrived with the Respondent. The court has now seen that email which
indicates that having spoken to the various individuals involved, including the Applicant's solicitor, the guardian ad
litem and the key worker, the social worker/Trust was not going to conduct an age assessment:

“There is no information to suggest an age assessment was required.”

**[16] The Respondent sent emails to the Trust on 22 April 2021, on 29 April 2021 and 6 May 2021 in respect of the**
request for an age assessment.

**[17] In the meantime the asylum application proceeded. In support of the application a psychiatric report was**
prepared by a Dr Labeeb Ahmed which was sent to the Respondent on 27 January 2021.

**[18] The Applicant had his asylum interview with the Respondent on 22 February 2021. The interview was**
conducted remotely because of public health issues arising from the Covid-19 pandemic. The interview commenced
but had to be terminated early because the Applicant became upset.

**[19] The Applicant draws the court's attention to the fact that when taking the basic information on the first page,**
the interviewer did not tick a box which signals that age is disputed.

**[20] Between May and September 2021, the Applicant's solicitor was in regular contact with the Home Office**
seeking an update on the Applicant's application.

**[21] On 14 October 2021, a pre-action protocol letter was written on behalf of the Applicant challenging the**
ongoing failure to make a decision in respect of the Applicant's claim. Proceedings were issued on 19 November
2021 and leave was granted on 3 December 2021.


-----

**[22] On 23 December 2021, the Respondent received further information from the Finnish authorities in the form of**
a school report, which contained a photograph of the Applicant. The date of birth on the report was 1 September
1993.

**[23] On 21 January 2022, the Respondent wrote to the Applicant's solicitor to request a further substantive**
interview with the Applicant. The Applicant's solicitor responded by stating that he had already been interviewed.
The Respondent replied, saying that the request had been made in error. Later that day the Respondent wrote once
more to the Applicant's solicitor asking for the substantive interview to take place. An interview slot had been
reserved for 24 January 2022 to allow the Applicant to address evidence provided by the Finnish authorities and to
address the Respondent's continued concerns over his age.

**[24] On 22 January 2022, the Applicant's solicitor emailed the Respondent to say that their legal representatives**
would not be able to accommodate an interview at such notice. Further, she advised she would need to take
instructions on whether the Applicant was fit for interview. As a consequence, the interview was cancelled.

**[25] On 25 January 2022, the Respondent wrote to the Applicant's solicitor asking for a consent form to share**
medical details. Given that it was not possible to convene the interview at such short notice, the Respondent sent
six questions in writing to the Applicant's solicitor on that date. Written questions and answers were to be used in
lieu of an interview. However, the six questions put in writing were not answered. Instead, the solicitor's response of
28 January 2022 referred to a decision of Mr Justice Friedman and the Respondent's Guidance document and
asked how both had been considered. The guidance document was published on 26 November 2021 entitled
“Eurodac and art 34 information for age assessment purposes.” It states that “a degree of caution should be
exercised using information obtained from Eurodac and art 34 of the Dublin III Regulation for age assessment
purposes. One credible explanation for conflicting accounts of age was stated to be:

“The claimant could be a potential victim of exploitation or **_modern slavery and had been coerced by the_**
perpetrators to claim to be an adult, to reduce the likelihood that their predicament would come to the attention
of authorities and impede their exploitation by the perpetrators.”

**[26] On 26 January 2022, the Applicant's solicitor responded with the consent form in relation to medical details.**

**[27] On 10 June 2022, the Respondent granted the Applicant's asylum claim and he was granted refugee status.**
She also determined that the Applicant's date of birth was not as asserted by him but rather the decision was made
on the basis that his date of birth was 1 September 1993.

**[28] On 27 September 2022 the Respondent's solicitor sent a letter to the Applicant's solicitor setting out the**
reasons for arriving at the conclusion in relation to the Applicant's age.

**[29] By these proceedings the Applicant challenges the delay in granting the Applicant refugee status until 10 June**
2022. The Applicant further challenges the decision regarding the Applicant's date of birth.

**_Age assessment_**

**_The applicable law_**

**[30] There is no dispute on the applicable law. In the cases of R(A) v Croydon London Borough Council (Secretary**
_of State for the Home Department) & Anor and R(N) v Lambeth London Borough Council (Secretary of State for the_
_Home Department) & Anor_ _[2009] UKSC 8 the Supreme Court considered the issue of age assessment in the_
context of the local authorities' statutory duty to provide accommodation to “any child in need.” The Claimants had
both sought asylum and asserted that they were aged under 18 years. Their ages were assessed as over 18 by
immigration officers and by social workers from the respective local authorities. The local authorities accordingly
[refused to provide accommodation for the Claimants under s 20(1) of the Children Act 1989 (“the 1989 Act”) since](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C1TN-00000-00&context=1519360)
they only had responsibility for accommodating “any child in need within their area who appears to them to require
accommodation.”


-----

**[31] Both claimants sought judicial review of the decisions as to their ages and the cases were heard together.**

**[32] The Supreme Court held that in enacting s 20(1) of the 1989 Act Parliament had intended that the question**
whether a child was “in need” was for the local authority to determine. The question whether a person was or was
not a child, was dependent entirely on the objective fact of a person's age and would be subject to ultimate
determination by the courts. Since the 1989 Act was an Act for and about children, the question whether a person
was a child was a fact precedent to the exercise of a local authority's powers under the Act and on that ground also
was a question for the court. The court held that it followed that although a local authority had to make its own
determination in the first place, such a decision, if remaining a matter of dispute, was for the court to decide by
judicial review.

**[33] Where issues remained about a disputed age it is for the court to determine that question “on the evidence**
available”.

**[34]** _[Section 55 of the Borders, Citizenship and Immigration Act 2009 provides that relevant statutory immigration](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7W77-8620-Y97X-70TF-00000-00&context=1519360)_
functions must be discharged:

“… [having] regard to the need to safeguard and promote the welfare of children who are in the United
Kingdom.”

**[35] The engagement of s 55 depends on whether someone is a child. In light of the decision in Croydon it is for**
the court to decide whether the Applicant is a child so that s 55 applies.

**[36] Further, art 8 of the European Convention on Human Rights entitles a person to have their date of birth**
correctly recorded in official documentation – _R(WA) (Palestinian Territories) v Secretary of State for the Home_
_Department [2021] 1 WLR 2117 at [77]. There is a clear public interest in accurate and evidence based records of_
dates of birth. Thus, even on his own case, JR194, in common with the other applicants is no longer a minor there
remains an important dispute between the parties on the issue of age.

**[37] Separate to the court's jurisdiction to determine the age of a claimed child, the court also has jurisdiction to**
determine whether the procedure used to assess age was fair _(R(HAM) v Brent London Borough Council_ [2022]
PTSR 1779 at [6]).

**[38] The court in** _HAM_ said that what fairness requires in this context is commonly referred to as a _“Merton-_
[compliant assessment” after the judgment in R(B) v Merton London Borough Council [2003] 4 All ER 280.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-61KV-00000-00&context=1519360)

**[39] In** _Merton_ the court was asked to give guidance on the requirements of the lawful assessment by a local
authority under the 1989 Act of the age of a young asylum seeker claiming to be under the age of 18 years.

**[40] The guidance outlined in** _Merton_ is comprehensive. The court's understanding is that it is accepted as
providing the best judicial guidance on how to approach age assessments by those authorities engaged in this
exercise. Hence the common reference to “Merton-compliant age assessments” by various statutory authorities
undertaking this task.

**[41] Some of the passages of the judgment are worth repeating here and are also relevant to the applications of**
JR235 and JR256. In his judgment Burton J sets out the background:

**“The background**

[20] In a case such as the present, the applicant does not produce any reliable documentary evidence of his
date of birth or age. In such circumstances, the determination of the age of the applicant will depend on the
history he gives, on his physical appearance and on his behaviour.

[21] There is no statutory procedure or guidance issued to local authorities as to how to conduct an
assessment of the age of a person claiming to be under 18 for the purpose of deciding on the applicability of
_Part III of the Children Act 1989_


-----

[22] The determination of an applicant's age is rendered difficult by the absence of any reliable anthropometric
test: for someone who is close to the age of 18, there is no reliable medical or other scientific test to determine
whether he or she is over or under 18. The Guidelines for Paediatricians published in November 1999 by the
Royal College of Paediatrics and Child Health states:

'In practice, age determination is extremely difficult to do with certainty, and no single approach to this can be
relied on. Moreover, for young people aged 15-18, it is even less possible to be certain about age. There may
also be difficulties in determining whether a young person who might be as old as 23 could, in fact, be under
the age of 18. Age determination is an inexact science and the margin of error can sometimes be as much as 5
years either side.

…

Overall, it is not possible to actually predict the age of an individual from any anthropometric measure, and this
should not be attempted. Any assessments that are made should also take into account relevant factors from
the child's medical, family and social history.'

[23] Different people living in the same country, with the same culture and diet, mature physically and
psychologically at different rates. It is difficult for a layman to determine the age of someone born in this country
with any accuracy. A general practitioner is very unlikely to have the knowledge or experience to improve on
the accuracy of an intelligent layman. To obtain any reliable medical opinion, one has to go to one of the few
paediatricians who have experience in this area. Even they can be of limited help, as in the instant case and is
referred to below.

[24] The difficulties are compounded when the young person in question is of an ethnicity, culture, education
and background that are foreign, and unfamiliar, to the decision maker.

…

[27] Of course, there may be cases where it is very obvious that a person is under or over 18. In such cases
there is normally no need for prolonged inquiry; indeed, if the person is obviously a child, no inquiry at all is
called for. The present is not such a case. The difficulty normally only arises in cases, such as the present,
where the person concerned is approaching 18 or is only a few years over 18. But the possibility of obvious
cases means that it is not possible to prescribe the level or manner of inquiry so as sensibly to cover all cases.

[28] Given the impossibility of any decision maker being able to make an objectively verifiable determination of
the age of an applicant who may be in the age range of, say, 16 to 20, it is necessary to take a history from him
or her with a view to determining whether it is true. A history that is accepted as true and is consistent with an
age below 18 will enable the decision maker in such a case to decide that the applicant is a child. Conversely,
however, an untrue history, while relevant, is not necessarily indicative of a lie as to the age of the applicant.
Lies may be told for reasons unconnected with the applicant's case as to his age, for example to avoid his
return to his country of origin. Furthermore, physical appearance and behaviour cannot be isolated from the
question of the veracity of the applicant: appearance, behaviour and the credibility of his account are all
matters that reflect on each other.

[29] In this context, as in others, it would be naïve to assume that the applicant is unaware of the advantages of
being thought to be a child. Draft Practice Guidelines for Age Assessment of Young Unaccompanied Asylum
Seekers state:

'Assessment of age is a complex task, which is a process and not an exact science. This is further complicated
by many of the young people attempting to portray a different age from their true age.'

It advises the decision maker/interviewer:

'It is also important to be mindful of the “coaching” that the asylum seeker may have had prior to arrival, in how
to behave and what to say '


-----

[30] The lack of a passport or other travel document may itself justify suspicion, as it did in the present case,
particularly if the applicant claims to have entered this country overtly, for example through an airport, in
circumstances in which a passport must be produced.”

**[42] In his judgment the judge also refers to other guidance including Home Office policy. In the discussion section**
of his judgment, he says:

“[36] The assessment of age in borderline cases is a difficult matter, but it is not complex. It is not an issue
which requires anything approaching a trial, and judicialisation of the process is in my judgment to be avoided.
It is a matter which may be determined informally, provided safeguards of minimum standards of inquiry and of
fairness are adhered to.

[37] It is apparent from the foregoing that, except in clear cases, the decision maker cannot determine age
solely on the basis of the appearance of the applicant. In general, the decision-maker must seek to elicit the
general background of the applicant, including his family circumstances and history, his educational
background, and his activities during the previous few years. Ethnic and cultural information may also be
important. If there is reason to doubt the applicant's statement as to his age, the decision maker will have to
make an assessment of his credibility, and he will have to ask questions designed to test his credibility.

[38] I do not think it is helpful to apply concepts of onus of proof to the assessment of age by local authorities.
Unlike cases under _[section 55 of the Nationality, Immigration and Asylum Act 2002, there is in the present](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-73N6-00000-00&context=1519360)_
context no legislative provision placing an onus of proof on the applicant. The local authority must make its
assessment on the material available to and obtained by it. There should be no predisposition, divorced from
the information and evidence available to the local authority, to assume that an applicant is an adult, or
conversely that he is a child. Of course, if an applicant has previously stated that he was over 18, the decision
maker will take that previous statement into account, and in the absence of an acceptable explanation it may,
when considered with the other material available, be decisive. Similarly, the appearance and demeanour of
the applicant may justify a provisional view that he is indeed a child or an adult. In an obvious case, the
appearance of the applicant alone will require him to be accepted as a child; or, conversely, justify his being
determined to be an adult, in the absence of compelling evidence to the contrary.

[39] However, the social services department of a local authority cannot simply adopt a decision made by the
Home Office. It must itself decide whether an applicant is a child in need: ie whether the applicant is a child,
and if so whether he or she is in need within the meaning of Part III of the Children Act 1989. A local authority
may take into account information obtained by the Home Office; but it must make its own decision, and for that
purpose must have available to it adequate information. …”

**_Consideration_**

**[43] A repeated theme of the Applicant's case is the suggestion that the Respondent raised the issue of the**
Applicant's age late in the day. In particular, reliance is placed on the fact that the record of the “minor asylum
interview” on 22 February 2021 did not tick a box opposite the entry “this date of birth is disputed” section. As
appears from the chronology above, this interview was not completed because of the Applicant's distress. As is also
clear, the Respondent had specifically requested an age assessment from the Trust in November 2020, something
of which the Applicant's representatives were fully aware. Despite reminders being sent by the Respondent to the
Trust there had still been no response at the time the interview was conducted.

**[44] The box should have been ticked, but I do not consider that this in any way suggests that the Respondent had**
a concluded view on the matter. The evidence points to the contrary.

**[45] That the Applicant suggests that there was some delay on behalf of the Respondent in raising this issue is**
further reflected in the email from the Applicant's guardian ad litem dated 14 March 2022 which was provided for
the purposes of the judicial review application. The letter properly supports the Applicant's claim for asylum and
refers to the distress caused to him by the delay in making the decision. The letter refers to shock that the


-----

Respondent is “now raising the issue of age.” This clearly misrepresents the situation, the issue of age was raised
in November 2020 along with requests for an age assessment.

**[46] The correspondence refers to concern that “the Home Office had produced information that (JR194) claimed**
asylum as an adult in Europe but have not sought clarification that an age assessment was completed by
professionals who were concerned that (JR194) was in fact a child, posing as an adult – despite this information
being known by all professionals.”

**[47] It is not clear to me to what age assessment she refers. The Respondent's complaint is that there has not**
been such an assessment.

**[48] The reasons for the Respondent's concern and for her decision had been set out in the detailed decision letter**
of 27 September 2022.

**[49] She relies on the information provided by the authorities in Finland. Information provided from the Finnish**
authorities was as follows:

“His identity in Finland is based only on his own statement. He stated to be a Somalia citizen, born on 1.9.93.
He has not presented any ID from his home country, but he did present a photocopy of a school report.

His application was studied on the merits in Finland, and he was not granted international protection nor any
other residence permit. He was asked to leave Finland within 30 days.

He absconded from Finland and Germany sent us a take back request on 20.3.2017 which was accepted on
the same date. Germany informed us that the applicant had absconded, and the time limit was extended.
Germany has not transferred him to Finland.”

As previously indicated, he came to the attention of the Finnish authorities on 9 June 2015.

**[50] If the Applicant's claimed date of birth is correct, then he would only have been twelve years of age when he**
claimed asylum in Finland. Mr Henry poses the question whether it is likely that the authorities there would have
treated the Applicant as an adult in his early twenties at that stage if he was, in fact, only twelve years old.

**[51] Prior to the issuing of these proceedings, the Applicant had provided no explanation to the Respondent for the**
information he provided to the Finnish authorities, even though his representatives and the Trust were aware of this
issue since November 2020.

**[52] The explanation is given in his rejoinder affidavit of 1 April 2022. In that affidavit he gives a full account of his**
journey through Europe. He confirms that he also sought asylum in Greece and Germany where he also gave his
date of birth as 1 September 1993.

**[53] In short, his explanation for this is that throughout his journey he was under the control of “Hassan.” He was**
an adult whom the Applicant trusted and who had been entrusted with his care by his older brother who had lost his
life during a boat journey.

**[54] He avers that Hassan exploited him for gain and made all decisions about his life.**

**[55] Hassan had forced him to work in a restaurant in Sweden without pay. He was instructed that when he arrived**
in Finland, Sweden, Germany and Greece, he was under the control of Hassan. The names and date of births he
put forward were at the behest of Hassan.

**[56] In relation to the school report and date of birth given to the Finnish authorities he avers that Hassan told him**
to give the authorities this date of birth because this was the initial date of birth that he gave the authorities in
Greece. His understanding was that it was feared his asylum claim would be rejected if the date of births were
different. The school report in question was forged by Hassan.


-----

**[57] In relation to his time in Sweden he said that he had been living there for a few months before encountering**
the authorities. He was stopped by the police where he says that when he was interviewed at the station, he gave
the date of birth as per Hassan's instructions. However, he says the police referred him to Children Services as they
did not believe him when he said he was an adult and had concerns that he was really a child. He says at para [42]
of his affidavit:

“42. The Swedish Social Services assessed me by looking at my height, weight, teeth and they asked
questions and encouraged me to tell the truth about my age. Social Services said they would help me if I told
the truth, so I did.

43. I told them the truth that I was born in 2003 and you can see the correct DOB recorded in the
aforementioned Swedish Migrationsverket letter. I was then referred to immigration where I claimed asylum as
a child. This was a few weeks after my encounter with the police. During this time, I was placed in a children's
home. Hassan was still in contact with me by phone, and actively encouraging me to change my position and
continue to lie and say I was an adult.”

**[58] Mr Henry queries the credibility of this account.**

**[59] He points out that the information provided by Sweden states:**

“The alien claimed asylum in Sweden on 8.9.18 but was already registered the following day as having
absconded. He has not been in contact with the Swedish authorities since his application here was launched.
The said application was subsequently written off on 20/9/18. When he applied for asylum in Sweden, he
stated to be a minor and that his application for asylum was denied by German authorities. The Swedish
migration agency did not investigate this claim any further.”

**[60] The reasons for the Respondent's concern are obvious.**

**[61] The Applicant points to further factors which support the claimed date of birth to be the correct one. The**
Applicant was made the subject of a care order by HHJ Miller on 1 April 2020. The court has absolutely no
information or documentation in relation to this application. The Respondent had no role in the application for the
care order. I consider that it is reasonable to assume that the court would have had no reason to challenge the view
of the Trust that the Applicant was a minor when the application was made. Of course, at that stage the
Respondent had not raised any issue about the Applicant's age as it had not received any information from the
other countries who had dealt with the Applicant.

**[62] The court works from the starting position that a care order should be definitive in relation to the age of the**
person subject to the order. That position must be subject to any additional evidence that is brought to the court's
attention, but which may not have been before the court making the order. However, importantly, it does confirm the
view of the Trust that the Applicant was, indeed, a minor when the application was made. That is certainly an
important and significant consideration.

**[63] The Applicant refers to a medical report provided by Dr Ahmed, in which he appears to accept the Applicant's**
date of birth. However, there is no analysis in the report concerning the Applicant's age and it is simply recorded,
presumably based on instructions.

**[64] The Applicant points to the fact that he was deemed by the SCA to be a victim of** **_modern slavery. That,_**
however, is not determinative of his age. It does, however, suggest that they were persuaded that his account of his
travels through Europe was credible.

**[65] I find this a troubling case. We are dealing here with a purported age difference of more than nine years. This**
is not the sort of case which should be a borderline one or cause any difficulties in terms of a proper age
assessment. Depending on which date of birth is correct, when he arrived in this jurisdiction, he was either 16 years
of age or approaching his 26th birthday. Making due allowances for the difficulties in assessing age, one would
have thought this should have been a fairly straightforward exercise.


-----

**[66] In this case I have concerns about how the Trust responded to the query raised by the Respondent in relation**
to the Applicant's age. In circumstances such as arise in this case, the Trust should not adopt an adversarial
approach with the Respondent. Both have an obligation to ensure, insofar as it is possible, that an accurate
assessment is made of the ages of asylum seekers. This can best be achieved by working together and sharing
information. This can be done without in any way undermining the Trust's obligation to ensure the best interests of
children and the welfare of minors.

**[67] I accept that the Applicant was a vulnerable person who required support and guidance. I accept that people**
in his position will often give false information to authorities either because they are under the influence of others or
because they mistakenly believe it might assist an asylum application.

**[68] The problem that arises in this sort of case is that frequently a challenge to an applicant's claimed age only**
arises after an applicant has claimed asylum and, as in this case, has been the subject of a care order. This can
cause understandable distress for an applicant who is genuinely a minor as claimed. Understandably, his legal
representatives in those circumstances urge the Trust to maintain its position in relation to the Applicant's age.

**[69] In this case, when confronted with the information which caused the Respondent to doubt the Applicant's date**
of birth, the first response from the Trust was to adopt “a co-ordinated approach” with the Applicant's solicitor, social
worker and guardian.

**[70] After this “co-ordinated approach”, the response was to send a one-line email to the wrong person and to the**
wrong address. I would have thought that the sender would have received an indication that the message had not
been sent.

**[71] Notwithstanding this, there was no response to further emails from the Respondent in respect of the request**
for an age assessment.

**[72] When these proceedings were issued the response was to feign surprise that this issue had been raised and**
to suggest that the Respondent had accepted the Applicant's date of birth because of a failure to tick a box in an
incomplete interview at a time when the Respondents were awaiting a response to their request for an age
assessment.

**[73] The court has no affidavit evidence from anyone on behalf of the Trust indicating that they had carried out an**
age assessment and were satisfied that his date of birth was correct, or alternatively that there was no basis for
challenging his asserted date of birth. It has, however, seen the correspondence between the Trust and those
caring for the Applicant including his legal representatives when the issue was raised.

**[74] The parties agree that it is for the court to decide the Applicant's date of birth on the evidence available. From**
that evidence it is clear that those employed by the Trust and those involved in the Applicant's care are satisfied
that his claimed date of birth is correct. The fact that a care order has been made in this case is very significant.
Significant evidence would be required to in effect upset that order.

**[75] I am conscious that I should be cautious about relying on information provided from authorities in other**
jurisdictions. Understandably, the information provided does not go into any significant detail. The court does not
have the benefit of evidence from those involved in dealing with the Applicant in the foreign jurisdictions.

**[76] Belatedly, in these proceedings, in addition to an account of his ordeal in travelling from Somalia to the United**
Kingdom, the Applicant specifically addresses the date of birth issue.

**[77] On balance, I am prepared to give the Applicant the benefit of the doubt. I do so on the basis that the Trust is**
clearly persuaded that the Applicant is a minor. Those involved in his care since his arrival in the United Kingdom,
have accepted his claimed date of birth, culminating in an application for a care order. I place weight on the Trust's
assessment and the court's care order. I do not consider that the evidence to the contrary is sufficient to displace
the reliance the court should place on the Trust's assessment.


-----

**[78] Whilst I have reservations and am critical of how the Trust has handled aspects of this matter, I am prepared**
to accept that the Applicant's date of birth is as claimed, namely 22 April 2003.

**_JR235_**

**[79] This application is brought by a mother (and her infant dependent son) anonymised to JR235.**

**_Background_**

**[80] The Applicant is an Eritrean national. She came to the attention of the authorities in the United Kingdom on 27**
December 2019 when she approached Mears Housing Association in Belfast, who had the contract in Northern
Ireland for providing asylum seekers with accommodation and support. She claimed that she was a child and was
treated provisionally as an unaccompanied minor. She presented with her own son. Her claimed date of birth was
17 December 2003.

**[81] After arriving in the UK, the Applicant and her son were placed by the Trust in a foster carer's home with a**
local family.

**[82] On 21 June 2020, the Applicant's solicitor served a Statement of Evidence Form (SEF) in relation to her**
application for asylum which included a typed statement. That statement set out her background and described her
journey from Eritrea to the United Kingdom.

**[83] She stated that when she was around one and half years old her mother left her home to work in Saudi**
Arabia. Her father was in the Eritrean army, and she only saw him once in her life when he was hospitalised. She
was left in the care of her maternal grandmother until her death in and around 2015.

**[84] Following her grandmother's death she left Eritrea and travelled via Sudan to join her mother in Saudi Arabia.**

**[85] She explained that she originally crossed from Eritea to Ethiopia and then on to Sudan before arriving in Libya.**
She was there for approximately eight-ten months during which time she was kidnapped and held captive. She was
repeatedly raped by her captors who were also smugglers. She left Libya when her mother gathered up enough
money to discharge a ransom demand. She travelled from Libya to Italy by way of a harrowing journey by boat.

**[86] When she arrived in France she was in a camp in Calais when she was again raped.**

**[87] After a while there she travelled to Germany. She did so via a lorry in the expectation that she would arrive in**
the UK but ended up in Germany.

**[88] In Germany she gave her age as an adult. She explains she did this to be safe and in order to get to the UK.**
She was told that if she said she was a child she would be placed in a children's home and would not be able to get
to the UK. She claims she attempted to get to the UK on a number of occasions but was caught by border guards
and returned to Germany.

**[89] She gave birth to her son whilst in Germany. Because of the birth of her son she had to remain in Germany**
longer than she had hoped. She describes flying to Ethiopia around 2018/2019 where she bathed in the holy waters
at St George's Church, Addis Ababa. Shortly after her son's first birthday she again travelled to Calais in the hope
that she would get a lorry to take her to the United Kingdom. She was told that it was less dangerous to fly on the
false documents she had relied on to claim asylum in Germany. She therefore returned to Berlin and friends booked
a flight for her from Berlin to Dublin.

**[90] She left Germany by plane and went to Dublin on 24 December 2019. She travelled by bus from Dublin to**
Belfast. Based on advice by those who arranged her transport, she disposed of her German travel and residence
documents before leaving for Northern Ireland.

**[91] The Applicant's foster family with whom she had been placed, raised concerns with the Trust that the**
Applicant was not, in fact, a child. The foster parents accessed her phone. As a result of material discovered on that


-----

phone, they were convinced that she was not a child as claimed. The Applicant complains that this was done
surreptitiously and without her consent. Nonetheless, that information raised sufficient concerns with the Trust that it
referred the matter to the Office of Care and Protection in the Family Division of the High Court.

**[92] On 24 June 2020, the solicitor for the Trust contacted the Respondent seeking information about the**
Applicant's circumstances. Specifically, the Respondent was asked whether she would have any objection to being
joined to the proceedings in the family court where the Home Office would be available to give evidence at a review
hearing or whether a formal subpoena would be required to attend any court hearing.

**[93] Regrettably, it does not appear that there was a direct response from the Respondent to this correspondence,**
but in an affidavit sworn on her behalf by Nicole Grey, it is averred that the Respondent sought to contact the Trust
on numerous occasions thereafter, to no avail.

**[94] In any event the Respondent was not involved in the subsequent family proceedings, something upon which I**
will comment further.

**[95] In the meantime the Respondent, in accordance with standard practice when someone claimed asylum in the**
UK at that time, made a EURODAC search using the Applicant's fingerprints.

**[96] On 13 July 2020, the Respondent received a response from the German authorities which indicated the**
fingerprints matched with the name Selam Y, (I have not given her full surname to protect her anonymity and will
adopt this approach throughout the judgment) DOB: 21 August 1992 and enclosed a copy of the ID document the
Applicant provided to the authorities in Germany. German authorities accepted her as such, granting her asylum on
19 September 2017. She was given a residence permit and a travel permit as an adult in accordance with the
information she provided.

**[97] This is the documentation which the Applicant obviously used to travel from Berlin to Dublin which she says**
was discarded after her arrival in the Republic of Ireland before travelling to the United Kingdom.

**[98] Returning to the Trust's concerns, these were set out in a lengthy affidavit from the social worker involved in**
the Applicant's care at that time. The affidavit is dated 19 June 2020.

**[99] The Respondent points out that this affidavit was not disclosed as part of the Ord 53 application in this case.**

**[100] Although lengthy, the substance of the affidavit bears setting out here.**

**[101] It states as follows:**

“2. I am the social worker assigned to the Y family for the young person, (JR235) Y. My colleague, Leah
Campbell, is the social worker for (NY) the son of (JR235). The Trust application is for a care order in respect
of (JR235) Y who has given her date of birth as 17 December 2003.

3. As a result of information provided to the Trust, there are concerns regarding the history that (JR235) has
given regarding her background circumstances and events leading to the birth of her son and her coming to
Northern Ireland. In addition, there are concerns raised which would lead the Trust to question the date of birth
provided by (JR235) which would mean that she is a 16-year-old child.

4. This affidavit addresses specifically the concerns in respect of the Trust's ability to satisfy the court that
(JR235) is a child and the evidence currently available to the Trust which would indicate that she is, in fact, an
adult.

5. When (JR235) came to Northern Ireland on 27 December 2020, she initially approached Mears Housing
Association in Belfast. (JR235) advised that she was 16 years old and was unaccompanied (see further details
below). (JR235) stated that she did not have any identification with her (although on her phone are
photographs of her residence permit and travel permit from Germany).


-----

6. (JR235) and (her son) were transported to Gateway by housing association staff. It is of significance, that
both (JR235) and (her son) were reported to be clean and well-presented. This was in the context of a history
of travelling on lorries to get to Ireland and having no luggage or clothing etc with them at this time. The only
belongings they had were the clothes they wore and a backpack containing baby foods. (JR235) had her
phone.

7. (JR235) indicated that she wanted to seek asylum in the United Kingdom. In accordance with protocol, I
understand that the Gateway team contacted the Belfast Asylum Office on 30 December 2019 to advise that
(JR235) is applying for asylum in the United Kingdom and to have this process commenced.

8. On 31 December, (JR235) and (her son) were taken for a LAC medical and (JR235) reported to the GP that
she was suffering from a number of matters to include memory loss.

9. On 14 January 2020, during a home visit, I discussed with (JR235) (in the presence of a Big Word telephone
interpreter) her account of her background and journey to Belfast as self-reported to Gateway Social Services.
This was then further discussed with (JR235) on 21 January 2020 in the presence of a face to face interpreter.
At this time, (JR235) made some amendments, ie corrected the spelling of her name from '(JR235) J' to
'(JR235) Y' and a minor detail about her father. This social history and reported journey to Belfast to include a
traumatic account of her life over the past four years is detailed in my initial social work report.

10. The PSNI were also contacted in relation to (JR235's) assertion that she was sexually abused in Libya, and
was raped in Calais (she would have been aged 13 at the time). (JR235) said that her son [] was born as a
result of that rape. (JR235) refused to speak with the police regarding the allegation of sexual abuse in Libya
and the rape in France advising that that was too upsetting for her. The case was therefore closed. There are
concerns as to whether (JR235) and her son were being 'trafficked' and this case is currently with the relevant
division of PSNI who deal with such matters.

11. The Trust would highlight the following information to support the assertion that (JR235) may not be a child.
Throughout, I refer to the young person as (JR235) – the name given to the Trust. However, her name may be
(JR235) as referred to in the formal official documentation issued in Germany.

12. Exhibits 1 and 2 are photographs taken from (JR235's) public Facebook account and which are time
stamped as being taken in 2014. At that date (JR235) would have been 10 years old. The photographs do not
appear to be those of a 10 year old child but of someone much older.

13. Exhibit 3 is a photograph taken from (JR235's) public Facebook account where her friend has posted a
'happy birthday' message to her profile page in August 2019. (JR235) asserts that she was born in the month
of December.

14. Exhibit 4 is a photograph of a German residence permit and also of a travel permit issued in Germany. Both
of these documents have a photograph of (JR235) on it with the name '(JR235) Y' and gives her date of birth
as 21 August 1992. This indicates that (JR235) is exactly 27 years old and will be 28 years old in August this
year.

15. The German Resident Permit was issued on 5 October 2017 in Germany and will expire on 4 October
2020.

16. In respect of these documents it would appear that (JR235) has claimed successfully for asylum in
Germany and has been granted a residence permit there. Although the permit issued on 5 October 2017, there
is the possibility that (JR235) was in the country for some time prior to this. The permit and travel documents
were issued to Selam as an adult. These are official documents and information provided to obtain these would
need to be a truthful account of the person's identity and date of birth. The date of birth now provided by
(JR235) would mean that she was 14 years old at the time she applied for that permit and travel document. It is
questionable that the authorities would have granted asylum to a 25-year-old adult if they had any suspicion
that she was, in fact, a child of fourteen.


-----

17. Exhibit 5 is a photograph taken from (JR235's) phone which is dated 10 March 2019 and shows her in a
graduation hat. Exhibit 6 appears to be a photograph taken in an educational setting. Despite requests for
information as to what educational establishments, (JR235) attended in Germany or elsewhere, there has been
no information provided in respect of this.

18. These photographs would indicate that (JR235) was accessing some form of schooling whilst residing in
Germany and this could be High School/Third level education.

19. Exhibits 7 and 8 are photographs of (JR235) blowing out candles on a cake. It is of significance that the
numbers 2 and 4 are placed on top of the cake and, therefore, indicating that this is a 24th birthday. (JR235) is
wearing a headband with happy birthday on it. The Trust's view is that this is a photograph of a 24th birthday
celebration in which (JR235) is clearly celebrating within her own environment where there are no pressures to
give false information/tell lies. I raise this in the context that (JR235) has asserted to her Independent Guardian
that she was told by others to give a false name and date of birth to the German authorities.

**Birth of (the applicant's son)**

20. (JR235) informed me that (her son) was born in Germany, but she could not remember much about his
birth. In discussing (JR235's) time spent in Germany she would become upset, and the discussion would have
to end with very little information being provided.

21. Exhibit 9 shows a photograph of (JR235) in a hospital bed with baby [] in her arms. Efforts to obtain details
from (JR235) of where the birth occurred have not been successful. From the date of birth given by (JR235),
she would have been 14 in December 2017 and then gave birth to (her son) the following February 2018. As a
child herself, it is expected that she would have given her true date of birth to the medical staff involved who
would have immediately alerted the relevant authorities. If a false date of birth was given it would have been
expected that the medical staff would have had concerns that she was a young child herself and would have
had social services' involvement.

22. Exhibits 10, 11 and 12 are photographs which were taken at the christening of (her son).

23. Exhibit 13 is a photograph of a poster displayed on the day of (her son's) christening. He is named there as

[]. The date of the christening appears to be from the poster as 30 March 2018.

24. Exhibit 14 was a photograph of (JR235) in which she is wearing rings on the wedding finger of her left
hand.

25. Exhibit 15 was a photograph of (JR235) and (her son) with the same man who appears in the christening
photographs. They are dressed up as a family in matching outfits for a special occasion.

26. Exhibits 16 and 17 show the same male person with (her son) and then with (JR235) and (her son).

27. It is my belief that the male person is Robel Gebremedhin, and he is (the applicant's son's) father. The
name Robel was given to the child when he was christened. I observed that Mr Gebremedhin's number was
saved on (JR235's) phone. I observed that he is in many photographs on (JR235's) phone dating back to when
(her son) was a baby, in his christening photographs, his first birthday party and up until the night before
(JR235) leaves for Ireland. (JR235) denies that he is the child's father.

**Family**

28. Exhibit 18 is a photograph of (JR235) and her sister with other family members. (JR235) claims to have
only one sister and it is not clear who the others are in the photograph.

29. Exhibit 19 contains two photographs – the before photograph appears to be taken from the photograph at
Exhibit 18 and the 'after' photograph shows (JR235) and the male person now. It is not known who this male is,
but the significance of this photograph is that it demonstrates that they are known to each other for a long


-----

period of time. They may be related to each other. The male is the adult male who travelled with (JR235) to
Dublin in December 2019 and is clearly known to her (see Exhibit 28).

30. Exhibits 20 and 21 are photographs of (JR235) and her mother. (JR235) told me that she had not seen her
mother since she was one and a half years' old.

31. Exhibit 22 was a photograph of (JR235's) sister and her mother which was taken with (JR235's) phone.

32. Exhibits 23 and 24 show (JR235) with whom we believe to be her grandmother (and sister in Exhibit 14).
(JR235) informed me that her grandmother died in 2015. (JR235) would have been 11 years old at the time.
(JR235) presents as much older than an 11-year-old child in both photographs.

33. Exhibit 25 shows a photograph of (JR235) and her sister, which I believe was taken in Ethiopia during a
visit (JR235) made there in December 2018. Exhibit 26 is a photograph of (JR235) with friends in Edna Mall
which was also taken in December 2018. The Edna Mall is in Addis Ababa in Ethiopia. (JR235) never informed
me of travelling to Ethiopia to visit her sister and she would have required the requisite travel permit to enable
her to do so.

**(JR235's) entry into Dublin**

34. (JR235) informed me that she travelled to Calais before she was successful in getting on a lorry that
travelled by boat to Dublin. (JR235) travelled with others in the lorry and when she arrived in Dublin she was
told to travel to Belfast. (JR235) travelled by bus to Belfast.

35. Exhibit 27 is confirmation of return flights from Berlin to Dublin and Dublin to Berlin. This is for (JR235) Y
and one infant. In addition to one small bag, a 20kg bag was also booked on going out and on the return
journey. (JR235) and (her son) were due to travel from Berlin to Dublin on 24 December 2019 at 18:05 and the
return flight from Dublin to Berlin is booked for Thursday 2 January 2019 at 17:40.

36. Exhibit 28 shows (JR235) and an adult male together on the Ryan Air flight to Dublin in December 2019.
This is the same male referred to above at para [29].

37. Exhibit 29 shows (JR235) and two other males and (her son) taken on 24 December before the flight to
Dublin.

38. Exhibit 31 is a photograph of a booking dated 23 December 2019 for Marilyn Mansion Bed and Breakfast in
Dublin. The arrival date is 24 December 2019 for two nights.

39. Exhibit 32 is a photograph taken on 25 December 2019 of (JR235) and a male person (same man as on
the flight) in the bed and breakfast in Dublin.

40. My colleague, Ms Campbell, contacted the Garda in Dublin to enquire whether they would be willing to call
out to the bed and breakfast establishment to obtain information on behalf of the Trust. The name of the bed
and breakfast together with (JR235's) name was provided. There was a request from the Garda for this to be
put in writing to them. Legal advice invited us to wait until consent was obtained to this information being
sought. Nothing was sent in writing, but we were informed that the officer from the Garda contacted the out-ofhours social work team at night (16 June) and the following information was noted and passed on to me:

'Garda Peter Byrne from Terenure Garda Station contacted RESWS wanting to pass on information, he will try
ringing you again in the morning, his number is [] or email [].

He wanted to let you know a person called (JR235) Y stayed at hostel called Marilyn Mansion 24/26
December, one other adult was with the person and a baby. They claimed to be German nationals, their
telephone number was [] and used an email address [] to book the hostel. He is not sure if this is the same
person you are enquiring about.'


-----

41. I am informed that a request was made to enable us to forward a photograph of (JR235) to the Garda to
show to the personnel at the B&B to confirm that this was the guest at their establishment, but consent was not
given for this to be done. I understand that it was felt that too much time had passed, and this would not be
reliable identification.

42. My colleague, Leah Campbell, has sent further written communication to the Garda for clarification of some
issues. To date there has been no response. Should a response be forthcoming then the original request and
that response will be lodged with the court.

43. In addition, we have contacted the appropriate agencies in Germany. It would appear from the limited
information to which I have access, that the family were not known to the social services there. They were
known to the Home Office there as (JR235) sought asylum under a residence permit which was granted. I am
waiting for further information and as and when that becomes available, I will provide copies of same to the
court and the other parties.”

**[102] The affidavit is signed by Ms Claire Doherty, the social worker allocated to the Applicant.**

**[103] On 17 October 2020, the Respondent made a request to the German authorities pursuant to art 34 of the**
Dublin III Regulations.

**[104] The Respondent received a response from the German authorities on 11 November 2020.**

**[105] The response indicated the Applicant using the name Selam Y and providing the date of birth of 21 August**
1993 sought international protection on 13 April 2017. She was granted asylum on 24 September 2017. She was
granted a residence permit and a travel permit under this name and date of birth.

**[106] The request also confirmed that the child [] was born on 19 February 2018 in Germany and was granted**
family refugee status on 30 August 2019 pursuant to an application made on 21 August 2019.

**[107] On the basis of this information, the Respondent made a re-admission request which was accepted by**
Germany on the basis of a return to a safe third country.

**[108] In the event this was not processed due to the end of the transition period arising from the UK's withdrawal**
from the European Union and the ongoing age dispute which is the subject matter of this application.

**[109] Returning to the Trust's involvement in the High Court, according to the affidavit from Ms Doherty, age**
assessment was undertaken by two social workers on behalf of the Trust (the Respondent was not aware of this
until much later).

**[110] This age assessment is a fundamental document in the context of this dispute. It was completed on 18**
September 2020.

**[111] It was undertaken by two social workers, one who is a senior practitioner in the Northern Health and Care**
Trust and another who is a social worker employed by the Gateway Belfast Health and Care Trust.

**[112] It was based on two interviews with the Applicant on 29 July 2020 and 19 August 2020.**

**[113] An independent guardian from Barnardo's was present to assist the Applicant and an interpreter was present**
on videolink.

**[114] In the course of the interviews the reason for the assessment was explained to JR235 in that significant**
doubt was raised in relation to her age after additional information and photos were obtained from her phone.

**[115] The age assessment indicates that assessing social workers referred to the guidelines laid out within the**
_Merton_ judgment [2003] and guidance to assist social workers undertaking age assessments for unaccompanied
asylum seeking children in Northern Ireland. The guidance is contained in “Working arrangements for the welfare


-----

and safeguarding of unaccompanied and separated children and young people.” Guidance identifies the _Merton_
case. It also provides that:

“Social workers and others contributing to the age assessment process should comply with the ADCS (Age
Assessment Guidance); guidance to assist social workers and their managers in undertaking age assessment
in England.” [October 2015]

**[116] The summary indicates that the social workers explored JR235 social history, family composition, education,**
development considerations, independent/self-care skills, health and information from documentation and other
sources.

**[117] The available sources of information which were taken into consideration were as follows:**

- Initial social work statement for the Family Proceedings Court dated 15.01.20.

- Statement completed by Phoenix Law with JR235 which was dated 15.06.20.

- Updated social work statement prepared for court dated 23.03.20 completed by Leah Campbell (social worker)
and Jemma Armstrong (Senior Social worker).

- Updated social work statement prepared for court dated 16.03.20 completed by Claire Doherty (social worker)
and Niall Rodgers (senior social worker).

- Affidavit completed by Claire Doherty (social worker) dated 16.06.20.

- Photographs obtained from JR235's mobile phone.

- Discussion with foster carer on 27.08.20 who is currently supporting JR235 and her son – her views are
contained throughout the report.

**[118] The decision is recorded as follows:**

“Based on the information available to the assessing social workers and in accordance with the guidelines it
was decided to give (JR235) the benefit of the doubt and, therefore, accept the age that she provided, which is
16 years old.”

**[119] The assessment provides a brief summary and analysis of reasons in the following terms:**

- JR235 provided an account for her journey from Eritrea to Northern Ireland. She was not able to provide and (sic)
reliable documentary evidence which supports her date of birth.

- JR235's initial account detailed that she arrived in Dublin via ferry, however, this was later discovered to be false
when photographs became available, which were located on her mobile phone and evidenced she had, indeed,
travelled to Dublin via a Ryan Air flight from Berlin.

- Questions arose in respect of photographs obtained from JR235's phone. She provided an account for these in
previous reports which were available to the assessing social workers. While some of the information may have
raised queries over both her age and credibility there was no evidence to prove that JR235 is not the age she
stated.

- Assessing social workers were mindful of the account provided by JR235 which indicated she had experienced
significant trauma and multiple adverse childhood experiences. Despite the difficulties experienced, JR235 engaged
with the age assessment process.

- Assessing social workers acknowledged that there are concerns about JR235's account, with inconsistencies and
lack of detail provided about significant periods in her life. However, it was notes (sic) this may be due to feelings of
insecurity, mistrust and other reasons which are not connected to her age.


-----

- Assessing social workers agreed that while age cannot be determined on appearance alone, that JR235's
physical appearance and/or demeanour did not strongly suggest that she was significantly over the age of 18.”

**[120] Presumably, based on this age assessment, on 10 December 2020 the Office of Care of Protection in the**
Family Division of the High Court issued a care order under art 50 of the Children (Northern Ireland) Order 1995. As
was the case with the age assessment, the Respondent was unaware of this order until after it was made.

**[121] The age assessment was first sent to the Respondent by the Applicant's social worker on 16 December**
2020.

**[122] On 8 February 2021, the Respondent wrote to the Trust's solicitor querying if any decision had been made by**
the High Court in respect of the Applicant's age.

**[123] On the same date the Trust's solicitor replied stating:**

“The court did not make any formal findings in relation to this girl's age, they simply took on board the age
assessment that was carried out and deemed her to be a child and have dealt with her on the basis that she is
subject to the Children's (Northern Ireland) Order 1995. The court order was made by the Honourable Mrs
Justice Keegan on Thursday 10 December 2020.”

**[124] The order confirmed that the child should remain in the care of the Trust. The Applicant's mother appears to**
have been a respondent. The order records that the time occupied was 10 minutes.

**[125] In or around the time that the Trust age assessment was disclosed to the Respondent, the Respondent**
draws the court's attention to the fact that the Applicant's solicitor was informed by the social worker that “I plan on
sharing the attached information sharing proforma which was completed by the age assessors.”

**[126] On 22 December 2020, the Applicant's solicitor made a number of comments on the age assessment. She**
was concerned that references to inconsistencies and “false” information could give rise to a negative credibility
assessment being made and could be damaging to the Applicant's claim.

**[127] As it transpired, the assessment had, in fact, been sent before these comments were received.**

**[128] Nonetheless, the Respondent says that the Trust were at all times liaising with the Applicant's solicitor, but**
not with it, despite its obvious interest in the Applicant's date of birth.

**[129] Thereafter, there were some discussions between representatives of the Respondent and representatives of**
the Trust. The Respondent raised concerns about not being kept informed, information not being shared, delay in
processing cases and the approach to age assessments generally.

**[130] On 3 June 2021, the Applicant's asylum interview was conducted remotely because of restrictions imposed**
arising from the Covid-19 pandemic.

**[131] The Applicant draws the court's attention to the fact that the box in relation to whether age is in dispute was**
not ticked on this occasion.

**[132] On 4 November 2021, the Applicant's solicitor emailed the Respondent asking when the decision would be**
made in relation to the application.

**[133] On 5 November 2021, the Respondent replied to say that the email had been passed on to the performance**
team. The reply indicated that the decision would be “with you” the following week.

**[134] On 15 November 2021, the decision maker writes to say that there was now a delay because of an issue**
which has arisen in relation to the Applicant's age which meant the matter had to be referred to a more senior
official.


-----

**[135] On the same date the Applicant's solicitor emailed the Respondent referring to the High Court's**
determination and the care order made on 10 December 2020.

**[136] On 20 December 2021, the Respondent sent an email to the Applicant's solicitor setting out their concerns**
about the age assessment, referring to the information from Germany and to the Respondent's age assessment
guidance.

**[137] The correspondent notes the order from the Office of Care and Protection but complains that it had not been**
involved in the proceedings and sought further information about the Applicant's partner Robel, and information
about him and the Applicant's family. It is confirmed that based on the available evidence it was disputing the
Applicant's claimed age.

**[138] On the same date the Applicant's solicitor responds by asking whether a decision has been made to dispute**
age. None of the information requested was provided.

**[139] Again, on the same date, the Respondent responds to say that it was providing an opportunity for the**
Applicant to respond to the queries raised before it made its decision on asylum.

**[140] On 7 January 2022, the Applicant's solicitor writes to the Respondent indicating that there was nothing wrong**
with the age assessment carried out by the Trust and that a care order had been made by the court on the basis of
a “Merton Compliant” age assessment.

**[141] The correspondence complained that it was too late for the Respondent to rely on the information obtained**
under art 34 of the Dublin III Regulations and that that information was not available at the time of the original
assessment.

**[142] It is not clear that this is correct. As is apparent from the original affidavit sworn by Ms Doherty the Trust**
certainly were aware of some of the material provided by the German authorities, including the German residence
and travel permits. They may not have had the confirmation of the date upon which the request for asylum was
made and confirmation that the Applicant was granted asylum there. This could be assumed on the basis of the
travel documentation which was available to the Applicant.

**[143] In its reply on 14 January 2022, the Respondent explained that the Trust had been in contact with the Home**
Office asking for information. The Home Office expressed concern that the authors of the age assessment would
not have been given the information from Germany. The Respondent pointed to evidence that contradicted the
Applicant's date of birth claim and invited a response.

**[144] On 3 February 2022, the Applicant's solicitor responded to say the High Court order is the “final decision” and**
is determinative of age. It was indicated that any decision finding a different age would be judicially reviewed.

**[145] On 12 May 2022, the Applicant's solicitor sent a pre-action protocol letter.**

**[146] On 27 May 2022, the Respondent replied indicating that the age assessment upon which the court order was**
based was not “Merton Compliant.”

**[147] The Respondent did not accept the age assessment of 18 December 2020.**

**[148] On 8 November 2022, the Applicant's asylum application was granted, but based on the name and date of**
birth provided to the German authorities. Thus, the Respondent says that the Applicant's name is Selam Y, and her
date of birth is 21 August 1992. It is this decision which is challenged by the Applicant in these proceedings.

**[149] The Applicant's response to the issues raised initially by the Trust, and subsequently, by the Respondent in**
respect of the age issue are dealt with in the statement dated 27 June 2020 (the age assessment refers to a
statement dated 13 June 2020). I have not seen any such statement and assume that it should be a reference to 27
June 2020.


-----

**[150] In relation to the suggestion that the father was Robel Gebremedhin, she states that he came to her**
assistance in the refugee camp outside Berlin. He spoke both her language and German. He helped interpret for
her in medical centres and around the camp where she received her ante-natal treatment. She says that when she
gave birth to her son in hospital, she is not sure if he was present but if he was it was simply to help her understand
what was happening.

**[151] They then became close friends, and she asked him to be her son's godfather. She accepts that they**
became boyfriend and girlfriend. She indicated she was willing to do a DNA test and that obviously that would
depend on co-operation from Robel.

**[152] In relation to the various photographs she says the photographs at Exhibits 1, 2, 3 and 5 of Ms Doherty's**
affidavit are photographs of her cousin.

**[153] She confirms that the travel and residence permits disclosed by the German authorities do relate to her. She**
says that on advice she gave the wrong name and date of birth when she was in Germany with a view to obtaining
residence status from where she could then travel to the United Kingdom. She feared she would be placed in foster
care if she gave her true name and date of birth.

**[154] In relation to Exhibits 7 and 8, she confirms that she is in the photographs but that they related to Robel's**
24th birthday. She says that she was “joking around with him” and he or a friend took the photographs of her
“pretending to blow out a cake and wearing the headband.”

**[155] She confirms that the photographs in Exhibits 9, 10, 11, 12 and 13 relate to her son's christening. Since**
Robel was her son's godfather, he is named in the notice referred to in Exhibit 13. Robel's name was inserted to
acknowledge his role as godfather.

**[156] She says that the ring in the photograph in Exhibit 14 is not a wedding ring. The photographs in Exhibit 15**
were taken close to her church on her son's first birthday. Robel is present as her son's godfather. The photographs
of Robel and her son are admitted.

**[157] Exhibits 18 and 19 relate to a family photograph and a “before and after” photograph of a childhood**
neighbour and herself.

**[158] Exhibit 20 is not a photograph of her and her mother, but a photograph of her mother with her cousin. She**
accepts being in the photograph with her mother in Exhibit 21.

**[159] Exhibit 22 is a photograph of her mother and her sister. She disputes being in the photographs in Exhibits 23**
and 24.

**[160] Exhibit 25 is a photograph of her and her sister in Ethiopia. Exhibit 26 is a photograph of her and her sister**
with some other friends of her sister.

**[161] Exhibits 27, 28, 29, 30 and 31 are not in dispute and confirm her travel from Berlin to Dublin.**

**[162] The court has seen the relevant exhibits, to include the identification documents, and the various**
photographs referred to by the Respondent.

**_The applicant's challenge_**

**[163] By these proceedings the Applicant challenges the Respondent's decision in relation to her name and to her**
date of birth (Salem Y and 21 August 1992).

**[164] The primary ground relied upon by the Applicant in challenging the Respondent's determination is based on**
the fact that a Care Order was made by the High Court in respect of the Applicant on 10 December 2020.


-----

**[165] The Trust had initially brought an application to the High Court to determine that the Applicant was an adult.**
The Trust changed its position because of an age assessment that was conducted on 18 September 2020. It was
undertaken by two social workers who did not previously have any dealings with the Applicant. They accepted the
age asserted by the Applicant. On that basis an application was made to the High Court seeking a care order which
was made on 10 December 2020.

**[166] The Applicant says that the court should accept the result of the age assessment carried out by the Trust and**
the making of the Care Order on 10 December 2020.

**[167] In challenging the determination the Applicant further points out that at her asylum interview on 3 June 2021**
the Respondent apparently had no issue with the age or name. The box marked “this date of birth is disputed” in the
statement of evidence form has not been ticked by the Respondent.

**_The court's consideration_**

**[168] The court's starting point is that weight must be placed on the Care Order that was made by the High Court**
on 10 December 2020. As indicated at the hearing the court should be able to accept these orders as being made
on the basis of reliable evidence.

**[169] That said the court is concerned about the basis upon which the application for a care order was brought to**
the court.

**[170] The Respondent was not a party to those proceedings.**

**[171] In common with the other applications the court emphasises that there should be proper communication**
between the Respondent and the relevant Trust when considering applications where there is a dispute about age.
In common with JR194, the Applicant's solicitor was keen to persuade the Trust to accept her client's claimed age.
She is perfectly entitled to do so, in accordance with her instructions and to draw the Trust's attention to any
information in support of the claimed age. That said, the Trust has a separate and onerous responsibility to carry
out a proper age assessment. The minimum standards of enquiry should require the Trust to engage properly with
the Respondent when legitimate concerns are raised. As stated in this judgment in relation to the other applications,
the Trust should not adopt an adversarial approach with the Respondent. It can comply with its obligations to take
into account the best interests of children and the welfare of minors by liaising with the Respondent when it has
relevant material or concerns about whether an asylum seeker is in truth a child.

**[172] In her submissions the Respondent refers to the Respondent's publication (the most recent version is 14**
January 2022) entitled “Assessing Age.” In particular, where there are disputes about an applicant's claimed age
the Respondent has issued an age assessment joint working guidance with local authorities in England. This is
discussed further in the case of JR256.

**[173] The Applicant's solicitor, Ms Marmion, correctly points out that this does not apply in Northern Ireland.**

**[174] She refers to two sets of policy documents issued by the Health and Social Care Board dealing with how**
Health and Social Care Trust staff should act when they encounter unaccompanied and separated young people
who arrive in Northern Ireland. These are “working arrangements for the welfare and safeguarding of
unaccompanied and separated children and young people” and “working arrangements for the welfare and
safeguarding of child victims of human trafficking and modern slavery.”

**[175] She highlights the fact that under this guidance the Trusts have responsibility for the provision of services to**
children, young people and families, and specific responsibilities for safeguarding children and child protection. The
guidance also identifies what is required to undertake an age assessment in accordance with _R(B) v London_
_Borough of Merton [2003] EWHC 1689 (Admin) – A “Merton Assessment.”_

**[176] That said, the Trust is under an onus to ensure that, as far as it is possible to do so, accurate and reliable**
assessments are made of the age of those claiming asylum. Assessment is obviously of importance. A child is


-----

clearly entitled to protection and support. Equally, it is important that adults are not placed with other children.
Asylum decisions should be taken as far as possible on reliable assessment as to age.

**[177] The Respondent in this case was not provided with the age assessment report upon which the care order**
was based until several months after it had already been completed and the High Court proceedings had
concluded. This should not have happened.

**[178] Returning to the court order, relied upon by the Applicant, it is clear from the record that this was a short**
hearing. The court has received an affidavit from the solicitor involved in representing the Applicant at that hearing.
The affidavit points out that age issues were only raised with the Trust when the male foster parent viewed
photographs of the Applicant via her phone without her consent. However, it is clear that the photographs were
viewed because the foster parents were concerned about the Applicant's asserted age.

**[179] The affidavit confirms that there was consideration about whether the Respondent should be joined as a**
notice party, but that this was resisted by the mother who was a respondent to the application. The affidavit does
not provide any of the papers that were provided before the family court as leave of the court would be required to
release all or any of the papers.

**[180] In relation to the mother, the Respondent points out that in her June 2020 statement the Applicant indicated**
that:

“I know that my mother is trying to access age vouching documents once she is able to freely travel. She has
been unable to do so because of the global pandemic and because she is given very little free time from work.”

No such documentation has been produced in the intervening years.

**[181] The affidavit provides no further light on the approach of the court other than to say that reliance was placed**
on the age assessment conducted by the Trust. The affidavit concludes as follows:

“12. The Trust held concerns at the initial stages when the child arrived and there were still enquiries being
made about entering jurisdiction an unknown history that was then complicated by phone material. The Trust at
the initial stages very often take a conservative and risk adverse approach to unaccompanied minors as they
cannot readily access information. Very often the burden of proof sits with the young person and that is exactly
that (sic) happened here.

13. In the course of family proceedings an extensive affidavit evidence with detailed explanations was provided
by the applicant and those working with the young person on the ground to include social worker, senior social
worker, guardian ad litem and independent guardian would have discussed matters and worked the case on
the ground and that is why concerns dissolved.

14. Furthermore, the age assessment supports the young person's account.

15. In light of these matters, the claimed age was agreed by all parties so that the case could proceed by
consent as all wanted a public law order. The court had the final report, care plan and all other material and
was satisfied that the Trust's application was right and proper and, therefore, made the orders.”

**[182] It is not clear what is meant by “all other material.”**

**[183] The Trust was put on notice of these proceedings and was an “interested party” in the application.**

**[184] In that capacity, the Trust served a short affidavit from Joanne Mayes, a senior social worker.**

**[185] The affidavit sets out the background as set out already, in this judgment. There is no indication that Ms**
Mayes was involved personally in this case. She refers to the age assessment report carried out on 18 September
2020 and says:


-----

“7. This age assessment was accepted by the Trust and was subsequently accepted by the High Court which
thereafter made a Care Order, which Order should only be made in respect of a child.”

**[186] There is no affidavit evidence from those who conducted the age assessment.**

**[187] I have given careful consideration to the age assessment upon which the Applicant relies, and which resulted**
in the care order in her favour. I have serious reservations about the assessment. I acknowledge that it was
conducted by two properly qualified social workers. I acknowledge that they had the benefit of interviewing the
Applicant personally. I note that based on the information available, they took the view that the Applicant should be
given “the benefit of the doubt.”

**[188] The assessment does identify issues concerning her credibility.**

**[189] In my view, however, the assessment fails to properly engage with those issues on which the Respondent**
relies in coming to her conclusion about the age and identify of the Applicant.

**[190] I repeat the comment I made at the hearing that it is astonishing to me that a difference in age of 10 years**
and four months in this case could not be obvious to those carrying out an age assessment.

**[191] One can well understand cases in which it can be difficult to make an accurate assessment of the date of**
birth but one would have thought that this was not such a case.

**[192] I accept that the Applicant is vulnerable and that she has suffered greatly on her journey through Europe to**
the United Kingdom. I accept that she was a victim of trafficking and was subject to serious sexual assaults. I
accept that she is a victim of modern slavery.

**[193] I accept that someone in that situation may well give inaccurate information to authorities, either under**
duress or through a mistaken belief that it will be of assistance to them. I accept that the process of claiming asylum
has been stressful for her.

**[194] I also accept, that in accordance with the Respondent's policy, care has to be taken when considering**
documentation obtained from other European states. The court does not have the benefit of affidavit evidence or
direct evidence from those involved in the decision making there.

**[195] That said in my view the evidence points overwhelmingly to the Applicant's correct date of birth being 21**
August 1992.

**[196] This is entirely consistent with the way she was treated in Germany when she was granted asylum on 19**
September 2017. I find it difficult to envisage that German authorities would have treated her as an adult, when she
was only 13 and, more importantly, when she received medical treatment in respect of the birth of her son. If she is
correct, she would only have been 14 at that time. Yet, according to her she was able to pass herself off as a 24year-old adult.

**[197] It is consistent with the ID card from Eritrea which I have seen. It is consistent with the travel and residence**
permits provided by the German authorities which the Applicant discarded on arrival in Dublin. I note that the
documents which the Applicant's mother was trying to access have never been produced.

**[198] It is consistent with those who were involved with the Applicant's care when she first arrived in the UK.**

**[199] All of the photographs and social media posts which I have seen overwhelmingly support the date of birth**
determined by the Respondent.

**[200] The only information in support of the Applicant's name and date of birth comes from her alone. It is**
unverified by any documentation.


-----

**[201] The age assessment upon which the Applicant was the subject of a care order conflicts with the initial view of**
the Applicant's own social worker and with the weight of the evidence.

**[202] It may well be that the motivation behind the information she gave the United Kingdom authorities was to**
ensure that the authorities here would not establish that she had already been granted asylum in Germany.

**[203] I have already said there are many reasons why those seeking asylum may give false information to**
authorities.

**[204] As indicated, I have started my examination of this case on the basis that the care order would be taken by**
the court as based on correct information. I would be extremely reluctant to come to a different conclusion. I can
well see how a court could make the order on the basis of the assessment which was provided and the fact that the
matter was being put forward on consent. In my view, the age assessment provided does not adequately grapple
with the issues I have identified above.

**[205] The authorities indicate that I must make a decision based on the evidence before me. Albeit with reluctance,**
I am in no doubt that that evidence overwhelmingly points in favour of the identity and date of birth determined by
the Respondent.

**[206] In light of the evidence before the court I have concluded that the Respondent is correct in its decision on the**
Applicant's name and date of birth.

**[207] Judicial review is therefore refused on this issue.**

**_JR256_**

**[208] This Applicant challenges the “continuing failure” by the Respondent to accept the Applicant's date of birth as**
17 February 2004. In this respect the Applicant relies upon an age assessment carried out on 2 December 2021 by
the Belfast Health and Social Care Trust and the Northern Health and Social Care Trust (“the NI Trusts”).

**_Background_**

**[209] The Applicant admitted entering the UK on 12 September 2020 and on 5 January 2021 came to the attention**
of Glasgow Social Services. In his affidavit supporting his application the Applicant avers that Scottish Social
Services accepted his asserted age. The court has seen an email from a social worker in Glasgow sent to the
Applicant's guardian here on 19 November 2021 in the following terms:

“Hi Catherine

No age assessment was carried out as we gave him the benefit of the doubt surrounding his age. However,
this was very borderline. Usually his guardian would deal with a referral to a legal rep. My memory is that
(JR256) did not engage with services although the guardian service did try very hard to support him. Hope that
helps.”

**[210] The Applicant avers that he left Scotland as “I was frustrated my asylum claim was not being processed.” He**
travelled to Manchester and presented himself at Townhall Police Station in Manchester on 29 January 2021. He
made an asylum application on 14 April 2021.

**[211] On 26 May 2021, Manchester City Council completed a** _Merton_ age assessment, and the Applicant was
assessed as being an adult at the time of entry to the UK with an assessed date of birth: 17 February 1998.

**[212] In his affidavit, the Applicant says that he did not feel comfortable with the interpreter who was instructed to**
assist him while in Manchester. He says that when the age assessment took place, he did not fully appreciate or
understand the implications of the assessment as they were not sufficiently explained to him and he did not have
the correct interpreter. He says he found this a difficult and distressing situation. He said that he did not agree to the
age assessment and did not wish to participate.


-----

**[213] As a result of his “frustrations” with social services in Manchester he left there and came to Northern Ireland.**

**[214] On 7 July 2021, he came to the attention of the authorities in Northern Ireland and was placed in foster care.**

**[215] The Respondent obtained the Glasgow and Manchester Social Service records on 14 July 2021.**

**[216] On 15 July 2021, the Respondent received a phone call from the allocated Northern Ireland social worker,**
Sinead Dougan, to state the Applicant had arrived in Northern Ireland and was in the care of social services as an
unaccompanied asylum-seeking child. On 16 July 2021, the Respondent spoke to Ms Dougan who stated the
Applicant had been moved out of his foster care accommodation due to age concerns raised by the foster carer.
Attempts were made to move him to supported accommodation. The Trust were informed on 7 August 2021 by Ms
Dougan that they were considering if they had grounds to undertake an age assessment as the solicitor for the
Applicant was clearly stating the Trust had no grounds to do an assessment. No decision had been made by the
Trust at this stage regarding conducting such an assessment.

**[217] The Respondent's safeguarding team requested an update on 20 September 2021 on the age assessment**
issue. Ms Dougan responded on 27 September 2021 indicating that the Trust was allowing the Applicant time to
settle in his current accommodation. The Trust was hoping to have a meeting that week with the Applicant's
independent guardian and solicitor to discuss the issue of the Trust completing its own age assessment.

**[218] The Respondent is critical of this approach and says the Trust should have followed the joint working**
instruction on the age dispute guidance agreed between the Respondent and the authorities in England & Wales,
referred to earlier in this judgment in relation to JR235, to liaise with Manchester City Council and do their own age
assessment, rather than have a meeting with the independent guardian and the Applicant's legal representative
before deciding whether to conduct an assessment. The Respondent highlighted that the extant age assessment
had assessed the Applicant as an adult at the relevant time.

**[219] On 5 October 2021, Ms Dougan confirmed that an age assessment would be conducted, and that the**
Respondent would be provided with the outcome.

**[220] In the interim the Applicant had come to the attention of the police and was arrested whilst at his**
accommodation on 2 November 2021 for the offences of criminal damage, possession of an offensive weapon, two
counts of assault on police and resisting police.

**[221] On 3 November 2021, in Magherafelt Magistrates' Court he was remanded into custody and sent to HMP**
Maghaberry. In court it was asserted by his legal representatives that he was 17 years of age, having been born on
17 February 2004 and should be sent to a youth facility.

**[222] Following a High Court bail application he was transferred to Hydebank.**

**[223] A judicial review application brought by the Applicant in relation to his detention was dismissed on 5**
November 2021. The Applicant was released from Hydebank pursuant to a High Court bail application on 24
November 2021 into the care of the Trust.

**[224] Whilst he was in Hydebank, the Respondent wrote to the Applicant's solicitor on 11 November 2021,**
indicating that the Applicant's age would not be accepted due to the Manchester age assessment.

**[225] A formal age assessment (AA) was carried out by the Trust in December 2021.**

**[226] That AA concluded that the Applicant's date of birth was 17 February 2004.**

**[227] The Respondent received an email from the Applicant's solicitor on 31 January 2022 informing it of the**
outcome. The Respondent was not provided with the actual assessment at this time.

**[228] On 1 February 2022, Ms Dougan contacted the Respondent to confirm that the NHSCT was accepting that**
the Applicant was a child. An email exchange took place on 7 February 2022 with the Respondent seeking the


-----

assessment and Ms Dougan confirming that she was still waiting on it to be completed. Later that day, Ms Dougan
emailed the Respondent attaching a single page age assessment outcome. This confirmed that the accepted date
of birth provided by the assessment was 17 February 2004.

**[229] The outcome of the assessment was disputed by the Respondent in an email sent to Ms Dougan on 8**
February 2022. In the correspondence the Respondent included the Manchester City Council AA as well as the joint
working guidance on the subject of age assessments and quoting from the relevant section on conflicting
assessments. The email included reasons in the following terms:

  - “This is not a Merton Compliant Age Assessment, and Merton Compliance is not referred to anywhere in the
letter.

  - There is a typo where the Trust have advised (JR256) will be 18 on 17 February 2004.'

  - The Trust have made no mention of the content of the Merton Compliant Age Assessment carried out by
Manchester City Council.

  - The Trust have failed to mention that (JR256's) claimed age was also questioned by Social Work in Glasgow,
and Police Scotland, before he absconded to Manchester.

   - You state:

'Despite the difficulties which he has experienced and the lack of engagement with the previous age
assessment in Manchester, (JR256) has engaged fully with the age assessment process.'

Given the limitations of your letter, we have no way of understanding how the Trust has reached this decision
which is imperative given no less than four other agencies are of the impression (JR256) is an adult.”

**[230] On 14 April 2022, Ms Dougan emailed an information sharing proforma for the Applicant to the Respondent.**
The correspondence did not reply to the points made in the email of 8 February 2022.

**[231] In relation to the criminal proceedings the prosecution was withdrawn, and the matter was disposed of by**
way of a youth diversion on 15 February 2022 at Dungannon Youth Court.

**[232] The Respondent reviewed the information sharing pro-forma and raised issues with Ms Dougan including**
that it gave no indication why and how the AA followed the Merton guidelines nor how it addressed the concerns
raised by other agencies. The Respondent pointed out that the Trust's refusal to provide the Respondent with a full
Merton compliant AA was causing delay in the Applicant's case.

**[233] The Respondent raised these concerns again on 24 February 2022.**

**[234] On 28 February 2022, in the absence of any response to its emails, the Respondent confirmed that it was**
relying upon the _Merton_ compliant AA carried out by Manchester City Council, in the absence of significant
evidence that undermines that assessment.

**[235] Thereafter, pre-action correspondence was exchanged, and the Applicant issued an application for leave to**
apply for judicial review on 19 July 2022 challenging the decision of the Respondent not to acknowledge and accept
the age assessment of the Trust undertaken in December 2021. The court agreed to hear this application along
with the applications of JR194 and JR235 on a “rolled-up basis.”

**[236] The Applicant's affidavit in support of the Ord 53 Statement exhibited the full AA document. This was the first**
time the Respondent had seen the full assessment.

**[237] At this stage I intervene to say that this document should have been provided prior to the issuing of**
proceedings. A common theme in these applications is the lack of communication between the Trust and the
Respondent in age disputed cases. This is unacceptable. This needs to change. The assessment of age should not


-----

be seen as an adversarial process as between the Trust and the Respondent. Both have a duty and obligation,
insofar as it is possible to do so, to make an accurate assessment of an asylum seeker's age. This can best be
achieved by working together and sharing information. This can be done without in any way undermining the Trust's
obligation to ensure the best interests of children and the welfare of minors.

**[238] The Respondent reviewed the full AA and maintained its position for the following reasons:**

a The matter was not referred to a SW manager despite this being requested by the Respondent.

b The Trust appear to have disregarded the multi-agency input from Manchester SW, Glasgow SW, police,
accommodation providers, the foster carer and the Respondent – all of whom had concerns over the Applicant's
age and levels of maturity.

c The Trust had disregarded the Manchester City Council AA.

d The Trust had not fulfilled its obligations under the joint working guidance. The Respondent's guidance states
that there should be communication between the two conflicted local authorities. It also details the process for
referring the matter to an SW manager. The Trust did not communicate with Manchester City Council SWs nor refer
the matter to an SW manager.

**_Delay_**

**[239] The Respondent raises an issue in relation to delay. As is clear from the chronology above, on 28 February**
2022 the Respondent confirmed it was relying on the AA carried out by Manchester City Council. Notwithstanding
that, these proceedings were not issued until 19 July 2022, almost five months post the decision. The Applicant
counters by saying that on 3 October 2022 the proposed respondent made a fresh decision which is challenged in
the Amended Ord 53 Statement of 4 October 2022. This is a reference to a position paper set out by the proposed
respondent in response to these proceedings.

**[240] Further, the Applicant argues that the failure to apply what he says is his correct date of birth is an ongoing**
breach which has continuing effect. The contested date of birth will be applied during the asylum decision-making.

**[241] In an affidavit sworn by the Applicant's solicitor she sets out the challenges involved in obtaining legal aid in**
this application.

**[242] As is apparent from the chronology the Respondent set out the reasons for its failure to accept the**
Applicant's claimed age in its letter of 28 February 2022.

**[243] The Applicant sent a detailed pre-action protocol letter setting out his case on 11 March 2022.**

**[244] The Respondent replied in detail on 5 April 2022. A further pre-action protocol letter was sent on 16 May**
2022, but curiously it does not refer to the Respondent's initial response. The letter added nothing of substance to
the original correspondence, something which the proposed respondent referred to when it replied on 19 May 2022,
confirming its original position.

**[245] Under the provisions of Ord 53 the proceedings challenging the proposed respondent's refusal to accept the**
Applicant's claimed age should have been issued before 28 May 2022.

**[246] I am not impressed by the argument that the proposed respondent's position paper of 3 October 2022**
constituted a fresh decision.

**[247] As Lewis LJ observed in R(AK) v Secretary of State for the Home Department [2021] EWCA Civ 119:**

“A claimant cannot avoid the application of the time-limits by writing to the defendant and then seeking to
characterise a response as a fresh decision.”


-----

**[248] The “fresh decision” relied upon by the Applicant in this case was a response to material which was provided**
in the affidavit supporting the Ord 53 Statement.

**[249] The proposed respondent is right to complain that this information, namely the full AA, was not sent prior to**
the issuing of proceedings in this application.

**[250] The Applicant was aware of the proposed respondent's decision on 28 February 2022 and from the pre-**
action protocol responses, on 5 April 2022 and 19 May 2022.

**[251] Of course, the court may extend time under Ord 53 r 4(1) where there is “good reason” to do so.**

**[252] In this case the Applicant points to the fact that the “ongoing failure” runs the risk of substantive hardship to**
the Applicant in the context of his asylum application. The ongoing impasse between the parties has undoubtedly
resulted in a delay in determination of the asylum claim, something which is important.

**[253] On balance, I have decided not to dismiss this application on the grounds of delay. This case has been listed**
with two others in the context of a pattern which appears to be emerging in this jurisdiction about disputes relating
to age assessments where the Respondent is challenging assessments made by the Trust. I consider that this is a
matter of public importance, worthy of consideration and review by the court. That, together with the ongoing nature
of this dispute persuade me that there is good reason to extend the time within which this application can be
brought under Ord 53 r 4(1).

**[254] That said, the issue of delay is something that can be taken into account in relation to both the substance of**
the application and any relief that the court may consider in due course.

**_The NI Trust's age assessment_**

**[255] The assessment was conducted by two appropriate social workers. In accordance with the appropriate**
guidance an interpreter was available for the Applicant. The assessment was conducted pursuant to three
interviews on 2 December 2021, 8 December 2021 and 17 December 2021. His independent guardian (Ms Turley
employed by Barnardo's) provided support during the interviews. Ms Turley informed the Trust that she considered
the Applicant's physical development to be in line with another young person she was working with from Somalia
who presented at the age of 17 and was subsequently accepted to be 17 by the receiving Trust and by the Home
Office. It was her assessment that the Applicant's physical appearance was consistent with his given age.

**[256] The assessment confirms that there was no formal documentation available to support the Applicant's**
claimed date of birth.

**[257] The assessment acknowledges previous concerns raised by foster carers, and social services in Glasgow**
and Manchester. The assessment notes that there had been meetings to discuss whether an age assessment
would be appropriate, and it was agreed that one would be completed. The assessment says:

“It was noted that the professional opinions of social services in Manchester could not be ignored due to the
NHSCT's duty to safeguard every young person.”

**[258] The assessment also acknowledged concerns about the Applicant's presentation and engagement with staff**
in his accommodation. It was acknowledged by those responsible for the accommodation that his appearance and
conduct may have been due to “emotional distress” but there were concerns that it may be because he was older
than his claimed 17 years. Staff within Tafelta Rise, where he was lodging, were of the opinion that the Applicant
physically appeared older and stronger than the average 17 year old.

**[259] The assessment sets out the information and documentation available to it. This included:**

   - “Statement completed by the applicant's solicitor.

  - Independent guardian report, completed by Ms Turley and dated 16 December 2021.


-----

  - Discussion with staff within Tafelta Rise, who provided accommodation to the applicant within Northern
Ireland.

  - French social services – Directorate for the Protection of unaccompanied Foreign Minors.

  - Records from Glasgow City Council Social “Work Services (13.09.20 - July 2021).”

**[260] From my reading of the assessment it does not appear that the assessors had access to the records, or the**
assessment made by the social services in Manchester. This is very surprising to say the least, given the issues
raised by the proposed respondent and the purported reason for the assessment in the first place.

**[261] The assessment records the Applicant's account of his social history and his family composition. He was**
born in Chad and lived close to the border of North Sudan and Chad. He sets out his background and explains that
he left his country after an attack on his home. However, the catalyst for his decision to leave was when he was told
by his uncle that he could be conscripted into the army in Chad and that he wanted to take him to safety. If the
Applicant's date of birth is correct, he would have only been approaching his thirteenth birthday at this time.

**[262] According to “social work records” the Applicant left Chad in 2018 and travelled to Libya then on to Italy,**
Switzerland, Belgium and France.

**[263] He describes a torrid and traumatic journey. The assessment records an account of his arrival to the UK, his**
experiences in Glasgow and Manchester and his arrival in Belfast.

**[274] The assessment records:**

“(JR256) was asked to engage in an age assessment whilst in Manchester; he did not engage as he reports he
did not understand what it was or why he was being asked to do it. (JR256) reports that he had not been
provided with an explanation of the assessment and he did not understand why they were asking him to talk
about his experiences that he found too difficult. (JR256) therefore opted not to engage in this assessment, and
he was subsequently deemed an adult.

(JR256) reports that he was being moved from his accommodation in Manchester which worried him and he
opted to leave, without permission. (JR256) got a ferry to Belfast where he wanted to claim asylum. According
to (JR256) he did not know anyone else in Northern Ireland.

On arrival (JR256) was placed in foster care for one weekend where some concerns were raised regarding his
age. (JR256) was then moved to supported accommodation; however, this placement ended abruptly after he
was arrested for criminal damage and possession of an offensive weapon. (JR256) was remanded into custody
for a short period of time before being moved to alternative accommodation.”

**[265] The assessment then briefly considers the Applicant's account of his education, development considerations,**
independent/self-care skills, health and medical assessment.

**[266] The conclusion of the assessment is in the following terms:**

**“10. Analysis of information gained**

(JR256) is a young person who has provided an account for his journey from Chad and his subsequent arrival
into Northern Ireland. (JR256) has not been able to provide any reliable documentary evidence which supports
his date of birth.

(JR256's) accounts have generally been consistent; however, there have also been some variations noted as
more information became available. Assessing Social Workers are mindful of the account provided by (JR256)
which indicates that he has experienced significant trauma and multiple adverse childhood experiences and his
trauma could affect his ability to recollect events/dates etc.


-----

Despite the difficulties which he has experienced and the lack of engagement with previous age assessments
in Manchester, (JR256) has engaged fully with the age assessment process. Assessing social workers spent
time explaining the reasons for this and why it needed to be done, which may have contributed to his decision
to engage as he reports the same clarification was not provided previously.

We need to acknowledge that there are concerns about (JR256's) account, with inconsistencies noted and
various professionals who have encountered him raising some queries about the date of birth provided
because of his physical presentation. Age cannot be determined on appearance alone, we are of the view that
his physical appearance and/or demeanour does not strongly suggest that he is significantly over the age of
18.

Based on the information that assessing social workers have available and in accordance with the guidelines,
we need to give (JR256) the benefit of the doubt and therefore accept the age she (sic) is providing. Based on
the date of birth, he is providing (JR256) will be 18 in February 2022.”

**_The applicant's case_**

**[267] Mr Southey, on behalf of the Applicant, contends that the court should accept this assessment and**
consequently declare the Respondent's challenged decision unlawful.

**[268] He points out that in accordance with Home Office guidance the assessment was carried out by two trained**
social workers, an interpreter was available, an appropriate adult was present and that it is recognised both in the
authorities and Home Office guidance that except in clear cases, age cannot simply be determined on the basis of
appearance.

**[269] The Applicant argues that the Manchester AA relied upon by the proposed respondent placed undue**
emphasis on the appearance of the Applicant. He argues that the Manchester AA has significant limitations. Thus,
the age assessment analysis states:

“Unfortunately, for the reasons noted in the transcripts of our assessment sessions, (JR256) hasn't felt able to
engage meaningfully in the age assessment process and so the narrative account of his background, early life,
family structure and journey to the UK cannot meaningfully be included as evidence within this assessment.”

**[270] The Applicant's non-engagement also meant that he was unable to address any adverse matters relied upon**
in the age assessment.

**[271] He is also critical of the apparent failure of the Manchester social workers to contact the French authorities as**
it was said that the Applicant left French care at age 16.

**[272] He argues that this must be contrasted with the AA carried out by the Trust here, who had the advantage of**
being able to engage with the Applicant. As a consequence, they were better informed. They had a full history and
had the benefit of hearing from the independent guardian who had personal contact with the Applicant.

**[273] The Applicant further argues that weight should be given to the fact that the criminal proceedings against the**
Applicant ended with a youth diversion. That disposal is only available for individuals under the age of 18 at the time
of the alleged offence and as such, therefore, it would appear that the Public Prosecution Service and the Youth
Court in this jurisdiction dealt with the Applicant on the basis that he was a child.

**_The Manchester City Council age assessment_**

**[274] This assessment was completed on 26 May 2021. It was undertaken by Tom Stephenson (Lead Age**
Assessment Social Worker) and Muna Salei (Second Age Assessing Social Worker). The detailed written
assessment sets out the respective qualifications of the assessing workers. It confirms there were five sessions in
total. At all times the Applicant was accompanied by an appropriate adult and by a Sudanese Arabic interpreter.
There were some limitations on attendance at the various sessions as a result of the restrictions arising from the
Covid-19 public health crisis.


-----

**[275] The assessment includes a transcript of the discussions for each session. At the first session it is recorded**
that introductions were carried out to ensure that the Applicant was aware of who everybody was and their role. The
purpose of the assessment and reason for it was discussed. The role of the social workers, appropriate adult and
interpreter was discussed. It was confirmed that the Applicant could understand and hear the interpreter. What is
described as after a “prolonged period explaining the process and discussing the reasons for the age assessment”
the Applicant “declined to engage in the process of questioning and left the age assessment session.” This failure to
engage continued despite the efforts of the social workers, the appropriate adult and the interpreter. The Applicant
did not turn up for the fourth session scheduled for Thursday 13 May as he had left his accommodation earlier in
the morning and was not available. The Applicant arrived at the fifth session on 24 May and informed the
professionals present that he had already given his answers and did not wish to engage with the age assessment
questions and process. He then then left the room.

**[276] The report is a lengthy and detailed one. It is explained that:**

“The age assessment was necessary due to concerns raised by different professionals including the referring
police officer in Scotland, social workers in Glasgow Children's Services and staff at Hazelcourt, (JR256's)
accommodation provider in Manchester, all of whom raised concerns that (JR256's) physical presentation
suggested he was significantly older than his reported age. This decision was also informed by social work
observation and information gathered through social work assessment.

The report confirms that as part of the preparation the assessors read all relevant background information on
file, assessments, reports and case notes held on Children Services computer system. In addition to the case
information, they refamiliarized themselves with the Association of Directors of Child Services (“ADCS”) Age
Assessment guidance. They also familiarised themselves with country reports and relevant information on
Chad, the applicant's country of origin. This included research on the ethnic, cultural and religious make-up of
the country and issues of political and religious conflict.

The report confirms that the ADCS guidance was followed.

The sources of information available to the panel were:

  - Glasgow City Council Social Work Services' case chronology (03/03/21).

  - Manchester City Council Children's Services Child and Family Assessment (08/04/21).

  - Initial health assessment undertaken by Manchester Community Paediatric Services (08/03/21).

  - Manchester City Council Social Work assessment tools – Care Plan (08/02/21), placement plan (15/02/21);
and Strengths and Difficulties questionnaire (23/03/21).

   - Opinion and observation offered by individual professionals.”

**[277] The assessment goes on to outline the views of those professionals. It quotes from an email from Sarah**
Hembrough (allocated social worker) at Manchester City Council Children's Services. She was the Applicant's
allocated Children's Social Worker at Manchester City Council since his care and support transferred from Glasgow
Local Authority. Her opinion was that:

“In terms of his physical presentation, I feel that (JR256) is of a build, height and features which is suggestive
that he is over the age of 18 years old.

In terms of his demeanour, in sessions held with him, (JR256) has presented as a mature and knowledgeable
person who at times presents as understanding the care and support system in the UK greater than would be
expected of a child who had only come to the UK in September 2020. For example, in my initial visit with
(JR256) he stated that he was aware of his rights eg towards housing, education and entitlements such as
money which was a surprise given that although he was supported by Glasgow this was a different
arrangement to a section 20 in England and the confidence that he stated these views was suggestive that he


-----

had been in the UK longer than expected and more confident than would be expected of a child. This was
furthered in other conversations when he spoke about being aware of his entitlement towards money for his
birthday in February 2021.

(JR256) presents as confident and self-reliant, for example, (JR256) has repeatedly said in sessions with him
that if he does not get something he has asked for that he will leave his placement, leave Manchester and/or
the UK and has evidenced his independence skills in leaving his placement in April 2021 where he left,
navigated public transport and travelled to Leeds when he was reported missing from his home. Whilst, in my
experience, UASCS have needed to develop independent skills in use of transportation to be able to travel to
the UK so it is not unexpected that he would be able to travel to Leeds independently. However, his dismissive
attitude towards the support provided is both suggestive that his expectations were higher than could be
achieved which could be indicative that he has experienced care and support elsewhere in the UK, has
experience with care and support overseas and/or has knowledge and grasped the system beyond what would
be expected of a child.”

**[278] Later in the correspondence she opines:**

“I feel that his presentation, demeanour and information that he has provided about himself and his journey to
the UK is suggestive that he is over the age of 18 years old.

The reason for this view is that there has been some plausibility concerns regarding the timeline (JR256) has
currently provided regarding his journey to the UK and view of the EU services would not withdraw service to a
16 year old as he suggested happened. (JR256's) behaviours could indicate that he is older than 18 years old
given his confidence in navigating the UK care system and maturity in responding to safeguarding concerns
raised and dismissive attitude to age-appropriate rules and boundaries being put in place.”

**[279] Lucy Hall was a social worker in Manchester City Council Children's Service who has experience in working**
with the Manchester Children's Service for eleven years. She records her initial shock concerning (JR256's)
presentation which “gave cause for me as an apprentice to reflect on my values as I struggled with the ethical
dilemma of believing (JR256) looks much older than 18 and how I had wanted to work with children.”

**[280] She then sets out the reasons why she believes JR256 was over 18. She indicates that she has worked and**
lives in a diverse community of central Manchester. She indicates that she worked voluntarily at Chrysalis Family
Centre in Moss Side for over 10 years which has a huge African attendance. She indicates that her work always
included children and that she is aware that some children can look older. Her initial view was that (JR256) looked
older than 25 and was not a child. This was because of his appearance and demeanour. He had a receding hairline
which suggested to her that he was an adult. He had a very matured face, and his demeanour was of an adult in
that he had an air of maturity and confidence which she had not seen in children. She explained that she has
worked with many unaccompanied asylum-seeking children. She also notes that JR256 stated that French police
issued him with a deportation notice as he did not want to claim asylum. She says that this suggests, as far as the
French were concerned, that JR256 was over 18. She says:

“I am worried that (JR256) is avoiding the asylum process intentionally, it may be because he is older than 18
and through this process this would be discovered. I believe this because in Glasgow the guardian made
attempts to meet with (JR256) and (JR256) was reported to be “very negative and defensive” and queried why
he was being asked for his date of birth and why he was asked what country he was from.

Thus, not engaging the guardian reported this was highly unusual. In Manchester (JR256) was allocated to a
solicitor and (JR256) refused to work with him, stating he wanted a different solicitor. While I understand how
trauma can affect unaccompanied asylum-seeking children (JR256) appears to be selective in who he is
engaging with and those he does not relative to the asylum process.”

**[281] There is a report from Ciara Courtney who was the team leader at the accommodation provider for (JR256)**
in Manchester. She echoes the concerns expressed by Lucy Hall in relation to (JR256's) appearance. She
describes him as being stocky by build and of average height. She considered his facial features to be mature in


-----

that he had a pronounced jawline, that his hairline was high on his head and receding evenly on both sides. She
describes that he presented with muscle definition on his legs and upper body and a fully filled out body shape. Her
view was confirmed by his demeanour and behaviour.

**[282] She records that he simply refused to engage with any attempts to assist him.**

**[283] There is then an account of his social history and family composition which has been collated through**
secondary sources during JR256's period in the care of Manchester City Council. Because he did not engage, the
assessors were not able to explore his wider social and family history in further detail. Part of that history records:

“In respect of (JR256's) journey to the UK, he said that his maternal uncle came and took him to where his
mother was, in the border city of Libya. After this he moved with his mother to a city named Btron inside Libya
and he was happy. (JR256's) uncle suggested he should join the army. (JR256) said that one of his family
members refused this as he had already lost some of the family. (JR256) said that his uncle managed to put
him in a boat heading towards Europe. (JR256) said this was when he was maybe 11 or 12. (JR256) said that
his uncle Jusef travelled with him on this trip. An Italian ship rescued (JR256) and took him to Italy.

(JR256) said he and his uncle were placed in a camp in Milano, in Italy. This was in 2016 when he was 11 or
12. (JR256) said that he stayed for three months and then moved to Switzerland. (JR256) got arrested when
he arrived in Switzerland, and they took him to a camp. The next morning he left the camp and got a train to
France. (JR256) was then placed in an organisation as a minor in Paris from February 2017 until 2019.
(JR256) said the organisation asked him to bring them a birth certificate and refused to issue him any papers
saying that they could not help him.”

**[284] It was recorded that the details of his departure from France were unclear.**

**[285] It is noted that “(JR256) has experienced a traumatic and protracted migrant journey to the UK. He is at risk**
of impaired emotional well-being and mental health as a result. This will be mitigated by access to education,
consistent supportive living environment and attention to the avoidance of social isolation.”

**[286] There are reports on his education, his independent self-care skills, health and medical assessment, physical**
appearance and demeanour and interaction during assessment.

**[287] This information is then analysed in detail. Ultimately, the age assessment is based on his engagement with**
the process and his behaviour, his physical appearance, the background information and history provided by
JR256.

**[288] It is recognised in the analysis that any assessment based on physical appearance is by its very nature**
subjective. The assessor has experience of working with asylum seekers from Chad who are aged 17 and
considers that JR256 appears older than his stated age and those he has worked with who were minors.

**[289] The assessor is aware that experiencing traumatic events and going through extended periods of difficulty**
during childhood and adolescence can lead to premature aging or an outward appearance of an increased
chronological age. It is recognised that this is particularly relevant. The assessor states:

“However, when I consider (JR256's) appearance alongside his life story, work and compare that to
unaccompanied minor asylum seekers from Chad that I have worked with, I do not consider this sufficient to
explain his appearance as a young man.”

**[290] The assessor says:**

“Despite all the challenges faced by (JR256) across his life course, so far, when considering his presentation
against my experience of working with other young people from Chad, or young people from other countries
experiencing multi-level systems breakdown or armed conflict, I remain of the view that he does not present as
a child. His demeanour, presentation and appearance are still demonstrative of someone aged over 18.”


-----

**[291] He notes JR256's claim that he had been supported in France as a child but had subsequently been asked to**
leave by the French authorities. That would have been at the age of 16. The assessor points out that country profile
information contradicts that account because unaccompanied asylum-seeking children are supported in France up
to the age of 18. Unfortunately, without an account from JR256 it was not possible to explore this with him further.

**[292] In relation to Mr Southey's criticism of the Manchester AA's failure to contact the French authorities (see para**

[271]), the court has seen the information that was subsequently supplied by the French authorities to the NHSCT.
It says as follows:

“Good morning

Checks carried out in our databases have revealed an individual named (IA), born 10/05/2004 from Chad. He
arrived on 27/12/2019 into the “PAJOL” Unaccompanied Children's Dedicated Shelter Service (Service de mise
à l'abri de Pajpol), and was put up at the hotel Saint-Sébastien (42, Rue Saint-Sébastien, 75011 Paris). He was
assessed by the team of the DEMIE [Dispositive d'evaluation de mineurs isolés étrangers-Red Cross-manage
_Assessment Scheme for Foreign Unaccompanied Minors] on 31/12/2019; in doubt, he was held to be a minor_
on 03/01/2020. He was eventually taken out of the scheme on 20/01/2020 due to the fact that he failed
repeatedly to appear at the hotel/shelter.

I am not in a position to ascertain that this is the same young person, but in view of the dates above, I would
say he is the one who comes closest.”

**[293] I am not persuaded that this advances the Applicant's case. Firstly, it will be noted that he gave a different**
Christian name, but this could well be a typographical error. More importantly, he gives a different date of birth,
namely 10 May 2004 as opposed to his claimed date of birth here of 17 February 2004.

**[294] Mr Kennedy points out that the date of arrival of this person was 27 December 2019. The Applicant's history,**
as provided by him to NHSCT, was that he left Chad in 2016 (elsewhere it is said to be 2018 according to social
work records and 2013 on his during life story work with his social worker in Manchester) and that he was first taken
to an organisation when he arrived in Paris and became separated from his uncle. The Applicant stated that he
remained with that organisation until 2018, leaving to go to Calais. He stated that in December 2019 he “returned to
the organisation” (this is taken from his ESA statement). If that is so, then Mr Kennedy argues that it is
inconceivable that he would only have been recorded by the Shelter Service as arriving on 27 December 2019. As
per para [280] above, Ms Hall indicates that if JR256 is correct that the police issued him with a deportation notice,
this would suggest, as far as the French were concerned, that he was over 18.

**[295] Mr Southey is critical of the NHSCT assessment and says that it places undue reliance on the Applicant's**
appearance.

**[296] In relation to physical appearance it should be noted that the difference here is one of six years which is quite**
significant in someone claiming to be aged 17.

**[297] Mr Kennedy, on behalf of the proposed respondent submits that the Manchester AA was entirely Merton**
Compliant. These sessions were conducted by appropriate persons and that appropriate assistance was provided
to the Applicant. The transcript of the sessions indicates that the Applicant indicated he could understand the
interpreter and that the interpreter spoke the same language and dialect as him.

**[298] At each of the sessions which he attended, the explanation for the process and reasons for it were fully**
explained. The Applicant had the opportunity to discuss anything with the appropriate adult or with his solicitor
outside of the sessions.

**[299] Clearly, the Manchester SW team complied with the Age Assessment guidance published by the Respondent**
on the proper approach to undertaking age assessments in England (ADCS).

**[300] I agree with his submission that it is not correct to say that the AA was determined simply based on**
appearance Account was taken of the history obtained and his behaviour along with the statements from three


-----

professionals who had significant contact with the Applicant during his time in Manchester and also the records and
information obtained.

**[301] There can be no doubt that the NHSCT had the benefit of co-operation and engagement from the Applicant.**
Thus, they were able to obtain an account of his history from the Applicant. This is important. That said, there
remain valid criticisms of the approach taken by the Trust. Paramount amongst them is the apparent failure to have
regard to the Manchester City Council AA and the multiple issues of concern raised by them and other agencies.

**[302] It appears that the Trust never raised any of the information from the Manchester AA with the Applicant**
during their assessments. The assessors simply accepted that the Applicant had not engaged with the Manchester
assessors on the mistaken basis that the nature and reason for the assessment were not properly explained to him.

**[303] It is clear that the Manchester Council complied with its own requirements under the guidance, namely the**
assessment must be carried out by two trained social workers in cases where whether the Claimant is an adult or a
child is objectively borderline, and therefore a more in-depth assessment of their age is necessary, an interpreter
must be provided if this is necessary, the individual must be offered the opportunity to have an independent
appropriate adult present, local authorities must comply with their own guidance when carrying out the assessment,
if the circumstances of the case are such that the individual is being reassessed, eg, if they are undergoing a
second age assessment it is preferable for those who undertook the first assessment not to take part in the second.
Except in clear cases where it is obvious that a person is over 18 and there is no need for prolonged enquiry, those
who are assessing the age cannot determine age solely based on the appearance of the Claimant.

**[304] All of these guidelines have been endorsed by various decisions of the courts.**

**[305] Again, the Manchester AA has complied with the guidance in relation to the conduct of the interviews.**

**[306] The court is faced with a dilemma.**

**[307] It has a detailed and in the court's view, a** _Merton_ Compliant Assessment, conducted by Manchester City
Council, which determined the Applicant's date of birth as 17 February 1998.

**[308] It has also had an age assessment carried out by the Northern Health and Social Care Trust which has**
concluded that the Applicant was a minor upon arrival in the UK. It accepted his asserted date of birth of 17
February 2004. Understandably, the Applicant says that this should be accepted and recognised by the proposed
respondent.

**[309] In terms of the proper approach by a Trust carrying out a second age assessment, I consider that the**
Respondent's guidance in relation to contested age assessments, whilst it may not have the force of law, is a
proper and meritorious approach. I understand, as indicated earlier in this judgment, it applies to England & Wales
but not to this jurisdiction.

**[310] The guidance makes the entirely sensible point that there should be communication between the two**
conflicting local authorities (in this case between the local authority in Manchester and the Trust in Northern
Ireland).

**[311] Where relevant the guidance provides:**

“6.1 Between the Home Office and a LA in most cases the Home Office opinion on age will be consistent with
the LA's. There may be some cases where it will differ, for example, if the Home Office believes that specific
information has not been properly taken into account. You can refer to Home Office LA Guidance for further
information (see Annex A). Different pieces of information will carry different weight depending on the
circumstances. You must explain the reasoning for giving greater weight to a particular piece of information. It
may be necessary for the Home Office and LA to liaise further in some cases. For example, where the
individual claims to be an adult, but other organisations have concerns that they may actually be a child. The
process for reaching agreement is outlined below:


-----

a The Home Office must first discuss the case with the LA pointing out contrary information they believe may
not have been appropriately considered by the LA.

b Where agreement cannot be reached, the case must be escalated to Assistant Director level at the Home
Office and Head of Service (or equivalent level) in the LA and a formal reconciliation reached between them as
soon as possible. The Home Office must alert its local safeguarding lead.

c If agreement is not possible at this level, the case must be escalated to Home Office asylum policy and to
the Director of Children's Services (DCS) to reach agreement. Whilst agreement has been sought the
individual must be supported in line with the LA assessment, if this is in line with case law, and safeguarding
must be considered.

d When consensus is reached the LA will formally notify the individual of the decision.

6.2 Conflicting LA age assessments

LA responsibility is tied to geographical boundaries so it is possible that an age assessment may be sought
from more than one LA. For example, where an asylum seeker moves to accommodation which is within a
different LA boundary. In some cases the assessments may not be in agreement. LAs must work together, and
[with other agencies, and be sure they prioritise safeguarding the individual and adhere to the Children Act 1989](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)
[and the Children Act 2004.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61K0-TWPY-Y0NN-00000-00&context=1519360)

The following is intended to reduce unnecessary repetition of the assessment process: existing lawful age
assessment LAs have a duty to assess whether someone is a child in need and may require an age
assessment. When an LA is approached for age assessment/it appears one may be required, it should check
with the Home Office whether any previous assessment has been carried out by another LA. If an assessment
has previously been completed, it must be established whether this was conducted lawfully (usually shown by
completion of the information sharing proforma). The LA must contact the other LA to request a copy of any
previous age assessments. If the Home Office has an existing lawful LA age assessment it must inform the
newly involved LA:

   - That there is an existing lawful age assessment.

  - Which LA carried out the assessment.

  - When the assessment was carried out.

**Conflicting age assessments**

If the Home Office becomes aware of conflicting assessments of age from different LAs it must notify the LAs
concerned for them to agree with LA should take responsibility. The Home Office will continue to follow the
case law compliant decision that had previously been notified to the Home Office unless and until new
information is submitted as part of a properly conducted assessment.”

**[312] As previously stated it appears to the court that the NHSCT's AA has not engaged with the findings of the**
Manchester AA. There is no consideration of that assessment apparent in the Trust's assessment. The Trust
records that the Applicant informed them that the need for an assessment was not explained to him during the
Manchester AA. The records of the interviews completely undermine this statement.

**[313] There does not appear to have been any contact between the NHSCT and those who conducted the**
Manchester AA. Rather, it appears to be accepted that the process was not explained to the Applicant.

**[314] The Trust appears to have rejected the views, opinions and observations of the various social workers and**
accommodation providers who had input to the age assessment. Those concerns were shared by those who
provided accommodation to the Applicant in this jurisdiction.


-----

**[315] There are concerns about the accuracy of the Applicant's history. By way of example, the Applicant's account**
that there was a concern that he would be joining the Chad army when he was 12 or 13 flies in the face of the
country information in relation to enlisting in the Chad army. The CIA World Book and UNHCR Ref World pages
confirm that 20 is the legal minimum age for compulsory military service. Of course, someone who has experienced
such a traumatic journey as that of the Applicant could understandably provide an inaccurate history.

**[316] I dealt with the Applicant's initial judicial review at a time when he was seeking bail and can confirm that no**
settled view was made by the court in relation to the Applicant's age. The concern was to release him from custody,
which was achieved. However, the transfer from the adult court to the youth court is not determinative of the issue
before this court. The court has limited information about what took place at the youth court, but there is no
suggestion that it undertook a detailed age assessment and presumably accepted at face value that the Applicant
was a minor.

**[317] In accordance with the authorities (discussed at paras [30]-[42] above) in light of the dispute between the**
parties it is for the court to determine the Applicant's age. There is no direct or reliable evidence as to when the
Applicant was born. In such circumstances, in accordance with the Court of Appeal's judgment in _R(WA_
_(Palestinian Territories)) v Home Secretary [2021] 1 LWR at para [41]:_

“Once it is recognised that a precise date of birth cannot be established by evidence, the best that can be done
is to assess age.”

**[318] If this matter were to be determined on traditional public law grounds, I would not grant relief to the Applicant.**
I do not consider that there is anything unlawful about the decision of the Trust to rely on the Manchester Age
Assessment. In the court's view, that assessment was Merton Compliant. I accept that it did have limitations
because of the lack of engagement by the Applicant.

**[319] The difficulty is that the authorities indicate that the court must determine age based on the evidence before**
it. I have serious reservations about the adequacy of the Age Assessment carried out in this jurisdiction. I am
conscious of the potential implications of the court's decision for the Applicant. However, age assessment will not
be determinative of his asylum claim. I accept also that the Applicant has had a horrid and traumatic journey to this
jurisdiction. I accept that trauma will affect his approach to both the age assessment in Manchester and in this
jurisdiction.

**[320] I am critical of the approach of the Trust to the age assessment it carried out. I consider that there should**
have been liaison with both the social services in Manchester and with the Respondent. It is simply unacceptable
that the age assessment in this case was only disclosed to the Respondent after these proceedings were issued.

**[321] The proceedings were served on NHSCT as a notice party by the Applicant. Pursuant to a case management**
direction by the court, the NHSCT were put on notice of the hearing. The Respondent sent a letter to the Applicant's
solicitor and the NHSCT setting out the issues the Respondent had identified with the NHSCT's AA.

**[322] The NHSCT has not taken the opportunity afforded to it by the Applicant, the court and the Respondent to set**
out its position in relation to the challenge to the AA it carried out.

**[323] Having carefully considered the competing age assessments, I prefer that carried out by Manchester City**
Council. I recognise that the age assessment carried out by the NHSCT had the benefit of engagement with the
Applicant. That said, I consider that there are significant limitations to the assessment carried out by the Trust. It
lacks the detail provided in the Manchester AA. The assessors appear to have accepted the Applicant's assertions
at face value and given him “the benefit of the doubt.”

**[324] It may well be that had there been closer co-operation between the Trust and the Respondent that an agreed**
position might have been reached. That said, the court is compelled to reach a decision based on the evidence
before it.


-----

**[325] Based on the evidence before me, I consider that the assessment by the local authority in Manchester is to**
be preferred. I consider that the detail and analysis in the Manchester AA is persuasive. I consider the Manchester
AA includes adequate and cogent reasons for its decision. The NHSCT AA, in my view, fails to engage properly
with the Manchester AA and the statements upon which it was based. Having acknowledged that there are
concerns about the Applicant's account the NHSCT AA states that “age cannot be determined on appearance
alone.” The assessment goes on to conclude “we are of the view that his physical appearance and/or demeanour
does not strongly suggest that he is significantly over the age of 18.”

**[326] Having reached that view, the assessment goes on to give JR256 “the benefit of the doubt.” I consider that**
this analysis contrasts unfavourably with the Manchester AA where the authors provide, in the court's view, detailed
and cogent explanations for the conclusions they have reached.

**[327] In light of the age assessment carried out in this jurisdiction, I grant the Applicant leave but refuse to grant**
judicial review on the substance of the application.

Order Accordingly.

**End of Document**


-----

