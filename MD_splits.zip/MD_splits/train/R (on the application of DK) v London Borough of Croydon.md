# R (on the application of DK) v London Borough of Croydon [2023] EWHC
 1833 (Admin)

King's Bench Division (Administrative Court)

Sir Ross Cranston (sitting as a High Court judge)

19 July 2023Judgment

**IRENA SABIC KC and ALEX GRIGG (instructed by Youth Legal) for the Claimant**

**HILTON HARROP-GRIFFITHS (instructed by Croydon LBC Legal) for the Defendant**

Hearing dates: 27 June, 7 July 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 19 July 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

**SIR ROSS CRANSTON:**

**INTRODUCTION**

1. The claimant, DK, is an Albanian national, aged 23. He came to the UK and claimed asylum as an
unaccompanied child. The defendant, the London Borough of Croydon (in this judgment called the
Council), accommodated and looked after him as a child in need under the _[Children Act 1989. In May](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
2021, when he was 21 years old, the Council refused to support him any longer. It explained that under
schedule 3 to the Nationality, Immigration and Asylum Act 2002 it no longer owed a duty to him under the
_[Children Act 1989 since his asylum claim had been rejected and there was no barrier to his returning to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
Albania.

2. The claimant challenges the lawfulness of that refusal to provide him with a personal adviser and a
pathway support plan as a care leaver on the basis that the Council failed to decide whether this denial of
support to him was compatible with his rights under the European Convention on Human Rights (“ECHR”
or “the Convention”). Specifically, the claimant submits, the Council should have conducted a “human
rights assessment” of his needs. It is also said that the Council's refusal to support him was not compatible
with his rights under articles 4 and 8 of the Convention. The claimant seeks a mandatory order for this
support.

**BACKGROUND**

3. On arrival in the UK in September 2015 the claimant claimed asylum as an unaccompanied child. On
his account he arrived in a lorry and then, with the help of some Albanians he met in a coffee shop, he
made his way to the Home Office in Croydon, where he made the asylum claim.

**Council's support until May 2021**


-----

[4. The claimant also applied to the Council, which looked after him under the Children Act 1989. He lived](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)
in foster care accommodation which the Council provided and had the benefit of advice and support from
its social workers. His social care records (which were examined by Kate Garbers in a report referred to
later in the judgment) offer the following summary of his experiences in the years from his arrival.

5. In October 2015 the claimant was referred to the Competent Authority under the National Referral
Mechanism for a determination of whether he had been trafficked into the UK. The Competent Authority
made a negative Conclusive Grounds decision in April 2016.

6. In 2017 the claimant was reported missing from care and working in a car wash. By April 2017 he had
moved into independent accommodation. There were reports that others were sleeping in his room while
he slept on a couch. In May that year adults were again found in his accommodation. The television had
been removed.

7. The claimant's evidence is that he was subject to “county lines” exploitation and was used by older men
to transport drugs. He was recorded in July 2017 as having two mobile phones, “an indication of a young
person involved in drug dealing”. Pathway plans throughout 2017 referred to the claimant as being easily
manipulated. He was returned to foster care. In November 2017 he was absent from his foster home at
least one night most weeks. He had money that he could not account for. “County lines” concerns were
raised but dismissed in April 2018, on the basis that he would have more money and be missing for longer
periods if that were the case.

8. When he turned 18, the Council arranged for him to move to accommodation in Plumsted, in south-east
London, opposite a police station. He told a social worker that he felt safer there, because of the proximity
to the police station. During this period he had the benefit of a “leaving care personal advisor”. In 2019 he
was evicted from his accommodation owing to anti-social behaviour and having non-residents on site.
Similar issues continued in his new accommodation. Drugs paraphernalia and concerns about gang
affiliation continued to be raised. In November 2019 a gang of masked men was said to have forced him
out of his accommodation.

9. The Home Office refused the claimant's asylum claim in April 2019. An appeal to the First-tier Tribunal
was dismissed in August 2019, and his appeal rights were exhausted in February 2020.

**Council's human rights assessment, May 2021**

10. In view of those Home Office decisions about his asylum claim, the Council conducted a human rights
assessment in May 2021. It was conducted according to the widely used template of the No Recourse to
Public Funds (NRPF) Network. (In this judgment references to a “human rights assessment” are to an
assessment along these lines.) The main assessment, dated by the team manager on 25 May 2021 (by the
claimant on 7 June 2021), stated that the Council could not continue supporting the claimant indefinitely
and that it was necessary to undertake a human rights assessment to determine reasons to either continue
or discontinue support.

11. After setting out key information about the claimant and his immigration status, the human rights
assessment stated that he was appeal rights exhausted and that its ability to continue to provide financial
support was restricted to only that which was necessary to avoid a breach of the claimant's human rights.
There was no legitimate reason for the claimant to remain in the UK from what he had told the assessing
officer. Steps should be taken to return him to Albania, making use of the Home Office Assisted Voluntary
Return Home Scheme, in order to better his future there. The team manager agreed with the assessment,
adding that a personal adviser was available to assist the claimant with the application process for Home
Office support as a failed asylum seeker.

12. Given the human rights assessment, the claimant was informed that he had to leave his Council
supported accommodation. He did so in early July 2021.

**Council's addendum human rights assessment, August 2021**


-----

13. Following this, in early August 2021 the claimant's solicitor informed the Council that the claimant had
lodged a fresh claim with the Home Office. She requested that the Council should revisit its human rights
assessment. In support of the request she submitted further information.

14. First, she had obtained a statement by Ms Flutra Shega, from the Shpresa Programme, a charity
assisting Albanian-speaking refugees and migrants in the UK. Ms Shega said that she regarded the
claimant as “easily led”. He presented with vulnerabilities and required intensive support. She had
concerns about his mental health. A young man from Albania must be desperate to reveal his mental
health issues, she explained, when these issues are hugely stigmatised within the Albanian community. He
was at risk of exploitation by gangs.

15. Secondly, there was a statement from Mr Clinton Walker, an outreach manager with a youth drop-in
centre in Croydon. He had worked with the claimant. He knew the claimant's mental health issues and was
especially concerned about his vulnerability to gang and street violence. Mr Walker said that because of
this he had offered the claimant a higher level of support.

16. Thirdly, Esme Madill of the Migrant and Refuge Children's Legal Unit at Islington Law Centre, who was
assisting the claimant with his asylum claim, wrote about her concern about his exploitation by others and
his mental health. She had instructed Dr Juliet Cohen, head of doctors at Freedom from Torture to prepare
a report.

17. Fourthly, there was a statement from Tilda Ferree, the part-time coordinator for Breaking the Chains, a
partnership project between the Migrant and Refugee Children's Legal Unit and the Shpresa Programme.
From her work with the claimant, Ms Ferree said, she believed that the claimant continued to be a very
vulnerable dependent young person who, without consistent proactive support, was at risk of disengaging
from professionals completely, with potentially harmful consequences to his mental and physical health.

18. Finally, there was a witness statement from the claimant himself. He said that he had mental health
issues, and that some four years previously he had experienced violence from a well-known gang. He
wanted to attend college to study engineering.

19. On 11 August 2021 the Council produced an “Addendum to Human Rights Assessment May 2021”.
This addendum assessment summarised and critiqued these submissions and decided to uphold its
decision to withdraw the claimant's support. The assessment concluded:

“No new information has been provided to persuade a change about the decision made in respect of this
HRA. A lot of assumptions have been made about [the claimant's] mental health but no professional
diagnosis has been provided. We note that there has also been a lot of assumptions about what life would
be like for [him] outside of the care of the local authority, with no evidence to support these concerns.”

20. The addendum human rights assessment then considered the implications of the claimant's
immigration status and the recent fresh claim application to the Home Office.

“In reaching our decision we have also considered the acknowledgement of receipt email from the home
office. The home office only acknowledged receipt of Further Submissions which they are yet to determine
whether it amounts to a fresh claim. Further submissions do not in themselves confer a new status on a
person. This would not change [his] immigration statuses listed under section 3.1(d) of NIA Act 2002.
Whilst this is being decided by the home office, leaving care services has no legal duty towards [him], as to
do so would be breaking the law by supporting someone who have exhausted all legal recourse to be in
the country. [He] is over 21 years of age, and is currently Appeal Rights Exhausted (ARE) and not in
education and therefore the local authority does not have a duty to support [him].”

**Home office and modern slavery applications**

21. As indicated in the Council's addendum human rights assessment, the claimant in July 2021 had made
submissions to the Home Office in furtherance of a fresh human rights claim. In November 2021 the Home
Office provided him with accommodation as a failed asylum seeker under section 4 of the Immigration and
Asylum Act 1999.


-----

22. At the request of the claimant's immigration solicitors, Islington Law Centre, Kate Garbers, the founder
and former director of the anti-slavery NGO, Unseen, completed an impressive report on trafficking and
**_modern slavery vis-à-vis the claimant in December 2021. She interviewed him and examined his case file._**
On that basis she concluded that there were indicators of his previously experiencing potential exploitation
and trafficking for the purpose of county line activity. Realistically, she noted, she could not know the full
picture. She went on to opine that there was also a risk of exploitation at that point as well.

23. Following a referral by his solicitors, in March 2022 the Salvation Army (a “first responder” under the
National Referral Mechanism), made a new trafficking referral. The claimant was provided with a support
worker through the National Referral Mechanism in early April 2022.

**Dr Cohen's reports**

24. Meanwhile, the claimant's immigration solicitors had arranged for the claimant to be assessed by Dr
Juliet Cohen, a forensic physician, who for many years worked at the NGO, Freedom from Torture. In her
first report in November 2021 she opined that the claimant required specialist psychological therapy to
recover from experiences of abuse in childhood, which needed to be in a secure and stable supportive
environment. She reported on the claimant's fear of returning to Albania, on his significant risk of being retrafficked, and on his mental health issues. He met the diagnostic criteria for PTSD and he had symptoms
of depression.

25. In a second report prepared in early May 2022, Dr Cohen found that the claimant continued to suffer
from PTSD and depression. His condition was very little improved from November 2021. She reported that
he was feeling safe in his accommodation and had a support worker, but he had run out of his
antidepressant medication and was not yet able to show any proactivity in seeking direct help himself from
his GP. She also reported that the claimant had told her that until very recently he continued to be forced to
carry packages for Albanian men and that he felt vulnerable and in fear of their threats to harm him if he
refused.

**Requests to Council for further human rights assessment**

26. The claimant's solicitors had written to the Council in January 2022, explaining the safeguarding
concerns and enclosing Dr Cohen's first report and Ms Garber's report on trafficking. The solicitors stated
that the claimant had been the victim of exploitation throughout his time in the UK, including while under
the Council's care, and that he remained at a significant risk of exploitation. He needed support from, at the
least, a personal advisor. The claimant's solicitors requested a fresh human rights assessment.

27. The Council failed to reply to this and to further emails in mid-February 2022 which had chased a
reply.

28. In a pre-action letter in early March 2022, the claimant's solicitors informed the Council that a judicial
review was proposed because of its failure to undertake a fresh human rights assessment. The letter
referred to the new material in the form of the reports of Dr Cohen and Ms Garbers. The letter reiterated
the background as set out previously. There was no reply from the Council.

29. In further pre-action correspondence in August 2022, the solicitors detailed the claimant's ongoing
issues. It identified the action that the Council was expected to take as being the provision under the
_[Children Act 1989 of a personal advisor and a pathway plan. The claimant was interested in pursuing](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
education.

30. The Council responded to the claimant's request on 9 September 2022. It stated that the claimant's
immigration status was appeal rights exhausted and the Home Office not having accepted his further
application as a fresh claim precluded the provision of support. The email added that the Council's position
could be revisited if there was further information. This is the decision under challenge in this judicial
review.

**LEGAL AND POLICY FRAMEWORK**


-----

31. A range of statutory and policy provisions are relevant to this claim. Fundamental to the case is
schedule 3 to the Nationality, Immigration and Asylum Act 2002, but alongside this are provisions of the
_[Children Act 1989 and other legislation.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_

**_[Nationality, Immigration and Asylum Act 2002, Schedule 3](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4X0-Y97X-74H4-00000-00&context=1519360)_**

32. Schedule 3 to the Nationality, Immigration and Asylum Act 2002 (“NIAA”) provides that local authorities
[must not provide support under, inter alia, the Children Act 1989's care-leaver provisions to individuals who](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)
are in the UK in breach of immigration laws. The objective of Schedule 3 is clear, “to discourage from
coming to, remaining in and consuming the resources of the United Kingdom certain classes of person who
can reasonably be expected to look to other countries for their livelihood.”: R (Kimani) v Lambeth London
_Borough Council_ _[2003] EWCA Civ 1150, [24], per Lord Phillips MR._

33. For present purposes the relevant parts of schedule 3 of the NIAA provide:

“1. (1) A person to whom this paragraph applies shall not be eligible for support or assistance under…

[(g) section 23CZB [or] 23CA of the Children Act 1989 (welfare and other powers which can be exercised in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)
relation to adults).

(2) A power or duty under a provision referred to in sub-paragraph (1) may not be exercised or performed
in respect of a person to whom this paragraph applies (whether or not the person has previously been in
receipt of support or assistance under the provision).

3. Paragraph 1 does not prevent the exercise of a power or the performance of a duty if, and to the extent
that, its exercise or performance is necessary for the purpose of avoiding a breach of—

(a) a person's Convention rights…

7. Paragraph 1 applies to a person if—

(a) he is in the United Kingdom in breach of the immigration laws within the meaning of section 50A of the
British Nationality Act 1981, and

(b) he is not an asylum-seeker.”

34. One exception to the prohibition on support under paragraph 3 of schedule 3 NIAA is where its
provision is required to avoid breach of the ECHR. R (Clue) v Birmingham City Council _[2010] EWCA Civ_
_460 concerned a family seeking welfare support from the local authority when they had an outstanding_
application for leave to remain. The local authority refused to provide support and accommodation relying
on schedule 3 NIAA. The applicable immigration policy in their case was that removal or deportation would
not normally be enforced where a child had lived in the UK continuously for seven years or more. The
Court of Appeal held where there was no outstanding application for leave to remain, a local authority was
entitled to have regard to the calls of others on its budget in deciding whether an interference with article 8
ECHR rights would be justified and proportionate: [73]. However, in this case the Council should first have
considered if the family was destitute. If they were satisfied that they were destitute:

“76…upon learning that the claimant had made an application for indefinite leave to remain on grounds
which expressly or implicitly raised article 8 of the Convention, they should then have considered whether
the application was abusive or hopeless. If they considered that the application was not abusive or
hopeless, they should not have refused assistance pending the determination of the application.”

35. In _R (on the application of de Almeida) v Kensington and Chelsea Borough Council [2012] EWHC_
1082 (Admin), _[127 BMLR 82, the local authority refused to provide assistance under the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56NK-0V01-DYJ0-B33T-00000-00&context=1519360)_ _[National](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVR0-TWPY-Y11X-00000-00&context=1519360)_
_[Assistance Act 1948 to a claimant who had a life expectancy of a year on the basis that he fell within one](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVR0-TWPY-Y11X-00000-00&context=1519360)_
of the prohibited categories in schedule 3 NIAA. Lang J held that the local authority's decision that the
claimant had no eligible needs under that Act was unlawful, and that its refusal to make arrangements for
the claimant under the Act was incompatible with his article 3 and 8 ECHR rights.

**Local authority duties to care leavers**


-----

36. The _[Children (Leaving Care) Act 2000 amended the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y13V-00000-00&context=1519360)_ _[Children Act 1989 to introduce obligations](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
requiring local authorities to support care leavers in their transition to adulthood. In R (G) v Southwark LBC

_[2009] UKHL 26 Baroness Hale said that the general aim of these responsibilities was “to provide a child or_
young person with the sort of parental guidance and support which most young people growing up in their
own families can take for granted but which those who are separated or estranged from their families
cannot”: [8]

37. Section 23C of the Children Act 1989 provides for obligations towards “former relevant children”.
These include individuals who (i) were being looked after the relevant local authority when they attained
the age of eighteen, and (ii) immediately before ceasing to be looked after, were an “eligible child”: s.
23C(1)(b). The obligations in section 23C persist until the former relevant child reaches the age of 21 or,
where relating to pursuit of education in accordance with an existing pathway plan, in some cases the age
of 25: s. 23C(6) and (7).

38. Section 23CZB provides for further obligations towards former relevant children aged over 21 but
under 25, who were formerly supported under section 23C. It provides:

“(2) If the former relevant child informs the local authority that he or she wishes to receive advice and
support under this section, the local authority has the duties provided for in subsections (3) to (6).

(3) The local authority must provide the former relevant child with a personal adviser until the former
relevant child—

(a) reaches the age of 25, or

(b) if earlier, informs the local authority that he or she no longer wants a personal adviser.

(4) The local authority must—

(a) carry out an assessment in relation to the former relevant child under subsection (5), and

(b) prepare a pathway plan for the former relevant child.”

39. Section 23CA applies to former relevant children over 21 but under 25 who are pursuing, or wish to
pursue, a programme of education or training. It is the duty of the responsible local authority to provide a
personal adviser: s. 23CA (2). The local authority must carry out an assessment of the needs of a person
with a view to determining what assistance (if any) it would be appropriate for them to provide to him and to
prepare a pathway plan for them: s. 23CA (3). The responsible local authority also has a duty to give
assistance to the extent that the person's educational or training needs require it, including contributing to
expenses incurred by the person in living near the place where they receive education or training, and
making a grant to enable them to meet expenses connected with the education and training: ss. 23CA (4)(5).

40. Further provision about the contents of pathway plans, and the role of personal advisors and pathway
plans is provided for in ss.23D and 23E and the Care Leavers (England) Regulations 2010.

41. Section 1 of the Children and Social Work Act 2017 lays down the “corporate parenting” principles of
local authorities. So far as possible, the local authority must stand in the place of a parent for those who
[lack a natural parent: R (Sabiri) v Croydon LBC [2012] EWHC 1236 (Admin), [52], per; R (CVN) v Croydon](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55MS-SR61-F0JY-C384-00000-00&context=1519360)
_LBC_ _[[2023] EWHC 464 (Admin), [53]-[54]. These corporate parenting principles apply to both looked-after](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67RG-F1J3-RRHR-H00V-00000-00&context=1519360)_
children and to young people leaving care: s 1(2).

42. General statutory guidance for local authorities in this regard is contained in _Applying corporate_
_parenting principles to looked-after children and care leavers, February 2018. As corporate parents, the_
guidance states, local authorities should have regard to the need to help the children they look after and
care leavers to secure the services they need. This is based on an understanding of the needs of these
children and young persons: 4.12. The guidance points out that to access and use services will often
require persistence: 4.14. Like any good parent, the guidance says, local authorities want the best
outcomes possible: 4.15. The guidance explains that in order to thrive, looked-after children and care
leavers need to feel and be safe, to have stability in their lives; for looked-after children this will mean


-----

having regard to the need to maintain, as far as possible, consistency: 4.19-4.20. Annex 2, “Categories of
Care Leaver”, states that in relation to victims of trafficking:

“14. Under the Care Leavers Regulations a care leaver's needs in relation to their status as a victim of
trafficking or an unaccompanied asylum seeking child must be considered when the local authority is
preparing an assessment of needs and to require that, where a child is a victim of trafficking or an
unaccompanied asylum seeking child the local authority must consider whether their related needs are
being met when reviewing the child's pathway plan.”

43. Where support obligations under the _[Children Act 1989 overlap with support available from other](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_
sources, the authorities suggest that local authorities cannot avoid their responsibilities as corporate parent
to children in need and care-leavers: see R (M) v Hammersmith and Fulham LBC _[2008] UKHL 14, [2008]_
1 WLR 535, [4]; R (G) v Southwark LBC _[2009] UKHL 26, [32]; R (O) v Barking and Dagenham LBC_ _[2010]_
_EWCA Civ 1101._

**Child victims of modern slavery, including trafficking**

44. Individuals who are referred for a trafficking assessment under the National Referral Mechanism are
entitled to limited support pending a decision on their case. It reflects the United Kingdom's obligations
under the _European Convention on Action Against Trafficking in Human Beings:_ _MS (Pakistan) v SSHD_

_[2020] UKSC 9, [20]. The support is currently provided by the Salvation Army under the Modern Slavery_
Victim Care Contract: _National referral mechanism guidance (adult),19 May 2022, para 6;_ **_Modern_**
**_Slavery: statutory guidance for England and Wales, 18 May 2023, Annex F, para 8. The support may_**
include “independent emotional and practical help”. The Statutory Guidance expressly envisages that
victims may seek support from various sources - of which support under the Modern Slavery Victim Care
Contract forms part - including a local authority: [8.5]. This support is intended to be temporary and not to
supplace support from other sources: [8.6].

45. _Care of unaccompanied migrant children and child victims of_ **_modern slavery, November 2017, is_**
statutory guidance issued to local authorities under section 7 of the Local Authority Social Services Act
1970. It begins with a caution that it covers a complex area of practice, exemplified by the many different
pieces of statutory and practice guidance, legislation, and resources available. Under the heading
“Planning transition to adulthood”, it states, with reference to schedule 3 NIAA:

“83…The extent of any care leaver duties on local authorities to provide support to former unaccompanied
children who have turned 18, exhausted their appeal rights, established no lawful basis to remain in the UK
and should return to their home country is subject to a Human Rights Assessment by the local authority.”

46. There is a reference to the type of support and advice available generally, but there is the warning
where a care leaver's outstanding application or appeal regarding their immigration status is refused:

“94…Subject to a Human Rights Assessment by the local authority, the care leaver may then cease to be
eligible for care leaver support under the restrictions on local authority support for adults without
immigration status (in Schedule 3 to 30 the Nationality, Immigration and Asylum Act 2002).”

47. The guidance adds that a template for human rights assessments is published by the No Recourse to
Public Funds Network: [94]. As regards financial support and accommodation for former unaccompanied
children, that will reflect their needs and immigration status: [96]. As to accommodation, that may form part
of the leaving care support, “[s]ubject to the Human Rights Assessment by the local authority under
Schedule 3 to the Nationality, Immigration and Asylum Act 2002”: [97]

**Home Office asylum support**

48. The Home Office provides support to asylum seekers under section 95 of the 1999 Act by means of
the provision of accommodation or the payment of sums to meet a person's essential living needs: s. 96. A
failed asylum seeker may be supported under section 4 of the 1999 Act and the attendant regulations.
Where persons make further submissions to renew their claim, they will become an “asylum seeker” again


-----

and entitled to support under section 95 if their submissions are accepted by the Home Office as a “fresh
claim”.

**GROUND 1: FAILURE TO CONDUCT HRA ASSESSMENT**

**The parties' submissions**

49. The claimant's case is that absent the provision of schedule 3 of the Nationality, Immigration and
Asylum Act 2002 (“NIAA”), the claimant would be entitled to support from the Council as a care leaver. He
is a “former relevant child” as defined by section 23C(1) of the Children Act 1989. Being under 25 he has
requested that the Council support him by providing a personal advisor and a pathway plan, and the
Council's obligations under section 23CZB CA 1989 are engaged. There is also his desire to pursue
education or training and the Council's obligations under section 23CA.

50. Although the claimant requested throughout 2022 that the Council provide him with support to which
he would ordinarily be entitled as a care leaver, it failed to engage, and then justified its refusal on 9
September 2022 because the claimant was appeal rights exhausted and thus could not be assisted
because of schedule 3 NIAA. Specifically, the claimant contended, the Council was obliged to determine
whether it was in fact obliged to meet that request. It could only do so, in circumstances where schedule 3
NIAA was engaged, by conducting a “full and lawful human rights assessment”.

51. At the hearing, the Council's case was that there is no statutory requirement to carry out a human
rights assessment nor any departmental guidance that advised that this should be done. All that the
claimant could point to was the practice guidance for local authorities issued by the No Recourse to Public
Funds Network. Moreover, the question posed by paragraph 3 of Schedule 3 NIAA could lawfully be
answered without a human rights assessment. Citing Lord Bingham in _R (SB) v Denbigh High School_

_[2006] UKHL 15, [29], the Council submitted that while it may well wish to assess for itself if there would be_
a breach of human rights if it did not act, and take into account representations in support, that could not be
converted into a requirement to do so, failing which its decision could not stand. The claimant was a failed
asylum seeker and would remain as such unless the Home Office accepted his further submissions as a
fresh claim under paragraph 353 of the Immigration Rules: _R (Mustafa) v Kent County Council & SSHD_

_[[2018] EWHC 2025 (Admin), [55], per UT Judge Markus KC.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SXV-S5P1-F0JY-C29R-00000-00&context=1519360)_

**Post-hearing**

52. At the hearing, the claimant produced for the first time the statutory guidance Care of unaccompanied
_migrant children and child victims of modern slavery, November 2017 and Applying corporate parenting_
_principles to looked-after children and care leavers, February 2018. As a result of considering this_
guidance, the Council changed its position. Shortly after the hearing, it informed the court that it was taking
advice on conceding the first ground and agreeing to conduct the human rights assessment requested by
the claimant, with the case to be stayed pending the outcome of that assessment. The Council then sent a
proposed consent order, in which it would agree to carry out a human rights assessment if the claim was
withdrawn.

53. In response the claimant sent a revised consent order proposing that a human rights assessment be
conducted, with the Council providing support on an interim basis pending its outcome. However, it
proposed, the court should proceed to give judgment on the first ground, although the claim would
otherwise be stayed pending the outcome of the assessment. The Council's response was that it did not
want the court to give judgement since it had conceded ground 1.

54. At a hearing on 7 July 2023 the parties restated their respective positions. They disagreed as to
whether judgment should be given on ground 1, but both agreed that the court should not give its judgment
on the second ground, pending the outcome of the human rights assessment given that ground 2 is fact
sensitive.

55. Having considered the matter I decided that judgment should be given on ground 1. In Jabbar v Aviva
_Insurance [2022] EWHC 912 (QB), Chamberlain J reviewed the authorities and approved the_


-----

considerations which Deputy Master Toogood had identified for this type of case where the parties had
settled a matter. These included the extent to which delivering judgment despite the settlement would be in
the public interest, along with the legitimate wishes of the parties. There was no need to demonstrate
exceptional circumstances: [26], [49]. In _R (DMA) v Secretary of State for the Home Department_ _[[2020]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61HP-VJ23-GXFD-846X-00000-00&context=1519360)_
_[EWHC 3416 (Admin), Robin Knowles J considered the authorities on the approach to giving judgment](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61HP-VJ23-GXFD-846X-00000-00&context=1519360)_
even though a matter had become academic. He said that it would be appropriate to decide an academic
claim where other similar cases were anticipated, and the decision in the instant case was not factsensitive: [326]-[332].

56. In this case the position is analogous to that in the DMA case. I accept the claimant's submission that,
while aspects of the claim turn on the claimant's facts, his case is of general application and it will be of
assistance to local authorities to know what they are obliged to do when confronted with requests for
human rights assessments, and to individuals seeking support to know what they can expect of local
authorities to whom they make requests.

**The point of public interest**

57. As formulated by the claimant at the 7 July 2023 hearing, the first ground is whether, as he contends,
a local authority such as the Council must conduct a human rights assessment when support is requested
by a person like him who, but for schedule 3 NIAA, would be entitled to support. In my view a local
authority's obligation is more nuanced than this bare submission would suggest.

58. What a local authority is required to do is to consider a request for the exercise of a power, or the
performance of a duty, when support is requested by a person who but for schedule 3 NIAA would be
entitled to support under, for example, section 23CZB or 23CA of the Children Act 1989. In applying the
prohibition in schedule 3, the local authority must consider that this does not prevent the exercise of a
power or the performance of a duty if and to the extent that this is necessary for the purpose of avoiding a
breach of a breach of a person's ECHR rights. It cannot adopt a blanket rule as the Council in this case
seemed to have done that it simply will not consider the request.

59. That does not require the local authority to undertake a human rights assessment when support is
requested. Nothing in the legislation requires this. Nor does the statutory guidance. My interpretation of the
passages regarding a human rights assessment in the guidance Care of unaccompanied migrant children
_and child victims of modern slavery, November 2017 is that an assessment will be triggered by specific_
events, for example where a former unaccompanied child who has turned 18 has exhausted their appeal
rights and so has no lawful basis to remain in the UK. If the local authority has already conducted a human
rights assessment, it may readily decide on a further request for support that there will be no breach of the
person's human rights by its refusal to exercise a power or to perform a duty in relation to support, in other
words, that the prohibition in schedule 3 NIAA applies.

60. In other cases, however, the local authority will need to conduct a human rights assessment, and a
blanket refusal on the basis of schedule 3 NIAA will not do. That is the position in circumstances such as
those in this case. Here there had been a human rights assessment of the claimant in May 2021, followed
by the addendum assessment some three months later in August 2021. That might have been the end of it.
The claimant was a failed asylum seeker and unless the Home Office accepted that he had fresh human
rights claim he remained a failed asylum seeker. However, in the circumstances the fresh human rights
claim for leave to remain did not seem either abusive or hopeless. The claimant's representatives had
produced additional evidence. This was sent to the Council and was not available at their previous human
rights assessments in 2021. There was Ms Garber's report on trafficking and **_modern slavery in_**
December 2021, and the two reports by Dr Cohen about the claimant's mental health and vulnerabilities
(November 2021, May 2022). There was also the positive reasonable grounds decision in early March
2022. All of this raised possible human rights issues under articles 4 and 8 ECHR.

61. Yet the Council seem to have taken the view that it was not obliged even to consider the claimant's
human rights issues because of schedule 3 NIAA. The fact is that the Council is the primary decision[maker in relation to requests for support under the Children Act 1989. It had received a request for support](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)


-----

from a care leaver. To decide whether it had to provide support notwithstanding schedule 3 NIAA 2, it could
not make that decision without considering whether the Convention exception in paragraph 3 applied. In a
case where there was significant new material bearing on the claimant's human rights – the positive
reasonable grounds decision, the expert report of the risk of trafficking and two reports on mental health,
coupled with all the previous material – the Council might well have decided that the way properly to
assess whether support was necessary in order to avoid a Convention breach was to undertake a human
rights assessment. That is what the Council in this case has now decided to do.

**GROUND 2: ARTICLES 4 AND 8 ECHR**

62. Ground 2 is that the Council is obliged to provide support as a result of the claimant's rights under
ECHR articles 4 and 8, and that its failure to do remains unlawful as contrary to section 6 of the Human
Rights Act 1998 and sections 23CZB and 23CA of the Children Act 1989. Both parties agree that now that
the Council has agreed to conduct a human rights assessment, the court should not give judgment on this
ground pending its outcome. Should that assessment conclude that no support is to be provided, and
should the claimant consider it appropriate to maintain his challenge to the lack of support in light of that
assessment, the court could then proceed to consider Ground 2, with the benefit of the human rights
assessment.

63. Given that there is to be no decision on the articles 4 and 8 issues, there is no firm basis for any
interim relief. In any event, the human rights assessment is to be completed imminently. I observe in
passing that in April 2022 the claimant was provided with a support worker through the National Referral
Mechanism.

**CONCLUSION**

64. For the reasons given earlier (1) the parties' agreement that the Council conduct a human rights
assessment is approved; (2) notwithstanding the agreement between the parties, providing judgment on
Ground 1 is justified and set out above; and (3) any judgment on Ground 2 is postponed pending the
outcome of the assessment.

**End of Document**


-----

