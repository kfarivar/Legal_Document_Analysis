# R v Ricketts [2023] EWCA Crim 1716

Court of Appeal, Criminal Division

Whipple LJ, Cutts J, HHJ Robinson

8 February 2023Judgment

**Mr D Perry appeared on behalf of the Applicant**

**____________________**

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

Wednesday 8[th] February 2023

**LADY JUSTICE WHIPPLE: I shall ask the Recorder of Norwich to give the judgment of the court.**

**THE RECORDER OF NORWICH:**

Introduction

1. This is an application for an extension of time in which to renew an application for leave to appeal against
conviction, following refusal by the single judge. Applications to renew a single judge's refusal of leave to appeal
must be made in time. However, in the circumstances of this case, if there is merit in the application for leave to
appeal, we would grant an extension of time. The delay was short, and there were unexpected difficulties in seeing
the applicant in custody.

2. On 1[st] March 2022, following a trial in the Crown Court at Taunton before Mr Recorder Trevaskis and a jury, the
applicant was convicted of two counts of conspiracy to supply a controlled drug of Class A between 12[th] July 2021
and 10[th] September 2021 (diamorphine and cocaine respectively).

3. On 27[th] June 2022, he was sentenced to five months' imprisonment on each count, concurrently. No complaint
is made about the sentence.

The facts

4. The allegations against the applicant were that he, together with Lamel Plomer-Roberts, was involved in a
county lines drugs line which operated between London and Yeovil Plomer-Roberts pleaded guilty to the


-----

conspiracies on 10[th] February 2022 and on 4[th] July 2022 he was sentenced to 29 months' imprisonment,
concurrently on each count.

5. The prosecution's case was that on 9[th] September 2021, the applicant was arrested at his home address in
Bulganak Road, Thornton Heath, Croydon. The police seized £585 in cash, some SIM cards and three mobile
phones, an iPhone XS registered to the applicant at an address in Angles Road Streatham (his previous address),
an unregistered BlackBerry pay-as-you-go phone and a Nokia phone. Each had a SIM card with a number ending
2919, 2219 and 4426 respectively.

6. On the same day Plomer-Roberts was arrested at his home address in Yeovil. The police seized £985 in cash
and two phones with numbers ending 2318 and 4511, as well as clingfilm and other drugs paraphernalia. He had
drugs secreted in his rectum which were later analysed to contain 148 street deals of crack cocaine and 133 street
deals of heroin.

7. Examination of the phones revealed that the applicant's 4426 number had been sending out bulk text messages
offering drugs for sale to users in Yeovil and inviting buyers to contact one of the phones belonging to PlomerRoberts. The 4426 number was nicknamed "the Supreme dugs line".

8. Cross IMEI checks were completed which identified the 2219 and 2919 numbers (SIM cards located in the
BlackBerry and iPhone XS respectively), as having also been used in the same handset as the 4426 Nokia phone.
As well as being found at his address, these three numbers were attributed to the applicant as a result of being colocated together on multiple occasions in London and Yeovil, being located at cell sites close to his home in London
and having contacts in common. The top contact of the number 4426 was the 2138 number found at PlomerRoberts' address. That 2318 number was frequently located near Plomer-Roberts' home address.

10. The prosecution's case was that the applicant was in charge of the drugs line and Plomer-Roberts was a
runner for him.

11. The applicant had two previous convictions for the supply of Class A drugs on 7[th] July 2017 and 26[th] July 2018.
The prosecution's case was that, having been to prison for two sets of drug dealing, the applicant now appeared to
be higher up in the hierarchy, organising the distribution of drugs and being in possession of various calculations
which highlighted profits to be made.

12. The prosecution's case relied upon maps showing the cell sites used by the various phones and extracts from
call schedules produced by PC Samuel Addy.

13. An application was made on behalf of the applicant to exclude this evidence on the ground that it was hearsay
by virtue of section 129 of the Criminal Justice Act 2003 ("the 2003 Act"). It was accepted that some raw phone
data had been made available to the defence on a memory stick, and that other raw phone data could be viewed by
arrangement at a police station. However, the material produced by PC Addy comprised extracts of phone
schedules that had been obtained by the application to the raw phone data of a computer programme known as
CSAS, which produced schedules that were in readable format. The prosecution had failed to serve any of these.
Thus the applicant's case was that the prosecution were unable to prove the source and accuracy of the material
produced for the trial, which it was argued was documentary hearsay.

14. That application was opposed on behalf of the prosecution on the ground that the phone evidence had been
served on the defence, albeit as unused material, or was available to them. They could have instructed their own
expert to look at the material, which had effectively been disclosed.

15. The Recorder gave a ruling in which he allowed the evidence produced by PC Addy to be admitted. He said:

"I find no grounds for concluding that the admission of this evidence will make the trial unfair for the

[applicant]; equally fairness requires that the prosecution be allowed to present its case, supported by
admissible evidence and subject to the following safeguards:


-----

The witness will be cross-examined on behalf of the defence, and any deficiencies in the evidence will be
identified;

Defence counsel will be able to make submissions to the jury, reminding them of those deficiencies and the
burden and standard of proof;

The jury will be directed that the evidence is not agreed, any deficiencies identified and the need for careful
consideration of the evidence as a whole, as well as the burden and standard of proof."

16. Accordingly, PC Addy gave evidence at trial based on the phone material, the contents of which we have
already summarised.

17. Expert evidence was given by PC Tracy Carpenter about drugs and drug dealing. She referred to a number of
notes on one of the phones attributed to the applicant, which she said indicated the sale of wholesale quantities of
drugs, such as £1,000 for 100 deals, 220 deals of crack cocaine, and 175 deals of heroin. Her evidence was that
these represented records kept by someone in control of large numbers of street deals and someone who was
more than just a runner. She agreed that county lines drugs operations used vulnerable people, but said that such
people did not buy thousands of pounds worth of drugs.

18. The applicant's defence, as set out in his Defence Statement, was that he was the victim of modern slavery.
He said that his exploitation began when he was 16 and in a Pupil Referral Unit, against a background of a
disrupted and abusive childhood that made him vulnerable. He was targeted by two individuals, "S" and "K", who
supplied him with cannabis and then pressurised him into selling cannabis in order to pay the debt that he had
accrued. This quickly progressed to him being forced to supply Class A drugs. He was twice stabbed by
individuals who were rivals of "S" and "K". They exploited his fear by telling him that they were taking him to a
place of safety, and took him to Somerset. He was taken to the home of a drug user, where he was forced to live in
unhygienic conditions, without proper sleep. He had to sell drugs in the West Country and bring them down from
London for that purpose. His debt was continually and artificially inflated, including as a result of a sham robbery,
when he had drugs or money taken by police, and also when he consumed some of the drugs himself. He was
threatened into having to work more in order to repay it.

19. The first time he was in custody for drug dealing, "K" kept in touch. On his release, the applicant was forced to
resume his activities with them. Following his second release from custody, he tried to avoid "S" and "K", but after
a while "S" contacted him and was very angry. He threatened the applicant that his debt was now even greater.
"S's" associates attacked the applicant, and his pregnant girlfriend was threatened, so he agreed to hold the drugs
phone again. On each arrest he felt unable to disclose his situation to the authorities for fear of repercussions.

20. The applicant gave evidence in accordance with his defence statement. He admitted that the three phones
were in his possession and control. He called the drugs line "Supreme" to attract more business. He knew the bulk
texts were offers to sell drugs and that there was someone in Yeovil to deliver them. His jobs were to collect
money, wrap up drugs and send out bulk messages. He had only co-operated until he could get out. He said that
the notes on his phone referring to the sale of large quantities of drugs had been made by him at the behest of his
exploiters and did not mean he had a trusted role; he was just a runner.

21. The applicant also called evidence from two experts. Dr Ronald Lyle, a clinical psychologist, said that the
applicant had a low average IQ and a tendency towards ADHD; he suffered from high levels of anxiety and was
more likely than the average person to respond to pressure from others. He considered that the applicant was
suffering from PTSD at the time of the offences as a result of abuse from his father and the earlier attacks on him.

22. Dr Grace Robinson gave evidence about criminal exploitation and county lines drug supply. She said that to
distance themselves from detection the organisers give the drugs line phones, drugs and paraphernalia to
vulnerable people. Debt bondage, violence and threats are common means of compulsion. It would not be unusual
for a runner to be given a phone for three months, and exploiters do tell victims to make notes for them.

23. The Recorder directed the jury that the fact that Plomer-Roberts had pleaded guilty to a conspiracy did not
mean that the applicant was also guilty They had to be sure that the relevant conspiracy existed and that the


-----

applicant had joined it. He gave detailed directions as to the defence of modern slavery, and directed the jury that
they had to be sure that each element of the defence did not apply.

24. The jury retired on the afternoon of 28[th] February and were later sent home overnight. They retired again the
next morning, 1[st] March, and returned with unanimous verdicts shortly before lunch. The applicant was convicted
on both counts.

The appeal

25. The single ground on which the application for leave to appeal against conviction is renewed is that the
Recorder was wrong to admit the phone evidence of PC Addy when the material on which it was based had not
been served. In the absence of that evidence, there was no case to answer, and the conviction is unsafe.

26. In his submissions in the proposed grounds of appeal on behalf of the applicant, which have been helpfully
elaborated orally today, Mr Derek Perry submitted that the case against the applicant depended almost exclusively
on telephone evidence, without which there was no case against him. That evidence comprised data received from
the service providers and that obtained from the handsets themselves, coupled with similar data pertaining to
phones said to be attributable to the co-defendant Plomer-Roberts, and included call, message, cell site and other
data.

27. The prosecution sought to present its case through presentational documents created by the CSAS software
system. The key witness statements of PC Addy, who had been involved in the search of the property at which the
applicant was living, but who was also the analyst in relation to the phone evidence, contained assertions pertaining
to phone evidence which were plainly derived from material which he referred to as exhibits by number, but those
exhibits had not been served. What had been served were a small number of documents generated by the CSAS
software, which consisted of maps showing dots indicating cell locations, and also containing extracts of
call/message data in tabular form, superimposed onto the maps. Mr Perry submitted that the inadequacy of the
phone evidence was raised at an early stage, but that the prosecution declined to serve as evidence on which it
relied either the raw phone data or the schedules on which PC Addy's material was based. The fact that the
prosecution had made available the raw data did not detract from the fundamental point that the material was not
served as evidence upon which the prosecution relied. PC Addy's material was not evidence in its own right and
was not based on material which had been served as evidence. Therefore, the prosecution could not rely on it.

28. In his written submissions, Mr Perry also argued that PC Addy's evidence was documentary hearsay, which
was not agreed. For that purpose he relied upon section 129 of the 2003 Act, which provides:

"(1) Where a representation of any fact —

(a) is made otherwise than by a person, but

(b) depends for its accuracy on information supplied (directly or indirectly) by a person,

the representation is not admissible in criminal proceedings as evidence of the fact unless it is proved that
the information was accurate.

…"

Mr Perry submitted that the implication of section 129 is clear. The presentational documents placed before the
jury, and upon which the prosecution constructed its case, were documentary hearsay. Their accuracy had not
been proved by service of the material upon which they were based, and they were not agreed. They ought not to
have been admitted. PC Addy's evidence of what the material showed was likewise hearsay, albeit in general
rather than documentary form.

Discussion

29. We have considered these submissions carefully. We start with the hearsay issue. Although it is true that the
evidence the prosecution put before the jury had been supplied by a person (PC Addy), in our judgment it is not
arguable that the material was inadmissible hearsay The prohibition on hearsay is set out in section 114(1) of the


-----

2003 Act: a statement not made in oral evidence in the proceedings is admissible as evidence of any matter stated
if, but only if, one of the listed exceptions applies.

30. Section 115(2) provides:

"A statement is any representation of fact or opinion made by a person by whatever means …"

Where computer evidence is concerned, there is a distinction. To the extent to which a computer is used merely to
perform functions such as calculation, no question of hearsay is involved in receiving evidence of what the
computer "said". By contrast, if a computer is used to record information that is supplied by a person, the hearsay
rule would come into play if it is sought to use a print-out from the computer to prove what the person said was true.

31. It appears that the raw phone records that had been served as unused material were produced by a computer,
without any human input, so are not hearsay. They were automated records of phone calls or downloads of a
telephone handset. Mr Perry did not suggest otherwise. Therefore, they are not a representation of fact by a
person for the purposes of section 115(2) and do not depend for their accuracy on information supplied by a person
for the purpose of section 129.

32. As to the information produced by PC Addy – documents J/6 and J/7 on the digital case system – his
description of the process in his statement (on page I/6) indicates that it involved the application of an automated
computer programme, CSAS, which simply rearranged the raw phone data into a standard and legible format.
Therefore, the product of that application was not a representation of fact by a person and did not depend for its
accuracy on information supplied by a person. It follows that sections 115 and 129 do not apply to that either. All
that PC Addy had done was to produce extracts of that material in his evidence. In our judgment, that is not a
representation of any fact which depends for its accuracy on information supplied by a person (our emphasis).

33. The information on which PC Addy relied in evidence was supplied first by the computer which produced the
raw phone data, and then by the application of the CSAS programme, neither of which depended on human input.
An analogy would be an exhibit comprising an automated computer printout, where the prosecution only served and
relied upon every other page of the printout. Further, insofar as any human input was involved, the material would
be admissible as a business document pursuant to s.117 of the 2003 Act.

34. For these reasons we take the view that the evidence relied upon by the prosecution cannot be said to be
inadmissible hearsay and could be adduced in principle, subject to the court's discretion to exclude it under section
78 of the Police and Criminal Evidence Act 1984. Put another way, Mr Perry did not suggest that if all of the
schedules produced by the application of the CSAS programme were served as exhibits, any of them would be
inadmissible, whether or not they were hearsay. Indeed, he said orally that if the schedules had been served, that
would be that, his argument would fall away.

35. In our judgment, the more fundamental issue is the fairness of the prosecution's position and whether the
applicant's conviction in these circumstances could be said to be unsafe.

36. Mr Perry's central point was that because neither the raw phone data, nor the schedules produced by the
CSAS programme was served as evidence on which the prosecution relied, it was wrong for them to be able to rely
on PC Addy's evidence, which derived from that material.

37. We are not persuaded that that is correct. First, the prosecution did not rely upon the raw phone data.
Therefore, it was not required formally to serve it. The prosecution complied with its disclosure obligations by
serving the raw data as unused material, or making it available for inspection.

38. Second, as to the schedules generated by the application of the CSAS programme, although it is not clear to
us why they were not served, we are satisfied that in the particular circumstances of this case it cannot be argued
that there was any unfairness. The Recorder considered the issue of fairness in his ruling. He rightly pointed out
that fairness applies to the prosecution and the defence, and he decided that the trial process contained sufficient
safeguards to ensure that it would be fair to the applicant. That is a conclusion to which he was entitled to come.
Moreover we did not understand Mr Perry to dispute that


-----

39. Mr Perry did not point to any prejudice the applicant has suffered as a result of him not being able to see the
whole of the schedules produced by the application of the CSAS programme, from which extracts were taken, in PC
Addy's presentational material. On the contrary, the applicant accepted the phone evidence and said so in his
evidence at trial. Further, the Crown disclosed some of the raw material and made the rest available for inspection.
The applicant could have instructed his own expert to analyse the raw material, to check if the prosecution's
evidence was correct, and put further phone material into evidence if he considered that would assist his defence.

40. The applicant's case was that he was a victim of modern slavery and had been compelled to act in the way
that he did, such that he had a defence by virtue of section 45 of the Modern Slavery Act 2015. That issue was
squarely put before the jury, with the benefit of evidence not only from the applicant, but also two experts – a clinical
psychologist and a criminal exploitation and county lines drugs expert. The prosecution's witnesses were crossexamined about it, but said, in effect, that the evidence, including the evidence of bulk dealing in drugs by the
applicant, was not consistent with him simply being a runner who had been exploited.

41. No complaint is made at all about the Recorder's legal directions, or his summary of the evidence. In our view,
the jury were entitled to reject the applicant's modern slavery defence and convict him on both counts.

42. For all these reasons we see no arguable merit in the appeal against conviction. The renewed application for
leave to appeal and for an extension of time within which to do so are accordingly refused.

___________________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________

**End of Document**


-----

