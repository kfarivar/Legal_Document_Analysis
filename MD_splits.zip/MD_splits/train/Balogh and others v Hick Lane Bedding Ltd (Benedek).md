# Balogh and others v Hick Lane Bedding Ltd (Benedek)

**Date** 09/03/2021

**General damages (PSLA)** £65,000.00


**General Damages (PSLA)**
**Today's Value (incl SvC uplift*)**


£85,360.39


**Major injury** PTSD with an alternative diagnosis of adjustment disorder with depression and anxiety

**Injury category** Psychiatric Damage Generally; Post Traumatic Stress Disorder

**Injury duration and prognosis**

Psychiatric Damage Generally

Post Traumatic Stress Disorder

The Claimant needed a course of 12 sessions of cognitive behavioural therapy, or
similar, and the prognosis then was for a substantial resolution of symptoms within 18
months.

**Facts**

The Claimant was a victim of modern slavery. His period of employment with the
Defendant was 67 days. The expert's diagnosis and prognosis was that the Claimant
was suffering from PTSD in the severe range, with an alternative diagnosis of
adjustment disorder with depression and anxiety. He was under the care of his GP and
was on antidepressant medication. He stood in need of a course of 12 sessions of
cognitive behavioural therapy, or similar, and the prognosis then was for a substantial
resolution of symptoms within 18 months. The Claimant carried out further work in a
commercial environment, both in the UK, for 21 months, and in Hungary, for nine
months, when he had briefly returned there. Due, no doubt, to funding difficulties, he
did not undertake the CBT that had been recommended by the expert. He also had a
poor response to antidepressants and, by the time he saw the second expert for an
updating report which was prepared nearly four years after the first report, he was no
better. His PTSD was still seriously disabling, he was unable to seek work and he was
still troubled by intrusive thoughts. He required CBT over a period of a year, and he
required the ongoing supervision and assessment of the community mental health
services. A prognosis was not given by the second expert, but the Court inferred that it
remained broadly the same as that given by the first expert, namely a return to a
reasonable level of functioning and employability within a period of about 18 months.
The Court placed the Claimant in the 'moderately severe' bracket of the Judicial
College Guidelines for post-traumatic stress disorder and/or a general psychological
damage but at a lower point in that range due to the Claimant's lower impairment to his
working capacity and slightly better prognosis than another Claimant in the same case.
The conditions of modern slavery endured for two months. For his injury to feelings,
the Claimant would fall towards the top of the middle band of Vento. An appropriate
global award of general damages in the Claimant's case, reflecting the much longer
period of modern slavery, but taking into account the fact that the main impact of that
would be felt in the early part of the relevant period, would be £65,000. In addition, the
Claimant was entitled to an award of exemplary damages in the sum of £5,000. The
grand total of general damages was £70,000. Citation: [2021] EWHC 1140 (QB).

**Age at injury** 47 Year(s)

**Age at trial** 55

**Gender** Male

**Type of claim** Employers' Liability; Other; Criminal Injury; Psychiatric and Occupational Stress


-----

**Total damages** £121,749.00

**Court** Queen's Bench Division

**Judge** Master Davison

**Contributor's firm** Lexis Nexis

**Notes**

The General Damages (PSLA) Today’s Value figure includes:

## • the Heil v Rankin uplift if the award was made on or before 23 March 2000
and is over £10,000 and

## • * the Simmons v Castle uplift. (If the award was made on or before 1 April
2013 or if the award was after 1 April 2013 and subject to a pre-1 April 2013
Conditional Fee Agreement, the Simmons v Castle uplift has been added by
us except in mesothelioma cases. All other cases will have already had the
_Simmons v Castle uplift applied in the original damages award)._

For further details see our Flowchart: Quantum database general damages uplifts.

**End of Document**


-----

