# R v Ginar; Note [2024] 2 All ER 767

[2023] EWCA Crim 1121

COURT OF APPEAL, CRIMINAL DIVISION

HOLROYDE VP, JEREMY BAKER AND LAMBERT JJ

26 SEPTEMBER 2023

**Sentence — Immigration offences — Illegal entry — Entry without valid entry clearance — Guidance —**
**Immigration Act 1971, s 24(1D).**
**Notes**

For immigration offences: illegal entry and similar offences, see Halsbury's Laws IMMIGRATION AND ASYLUM vol
57A (2023) para 283.

[For the Immigration Act 1971, s 24, see Halsbury's Statutes vol 31 (2021 reissue) 100.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)
**Application**

The applicant, Aydin Ginar, a Turkish national, applied for leave to appeal against the sentence of 8 months'
imprisonment imposed by Recorder Counsell on 18 August 2023 in the Crown Court, following his plea of guilty
before a magistrates' court to an offence of attempting to arrive in the United Kingdom without valid entry clearance,
[contrary to s 1 of the Criminal Attempts Act 1981 and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61M0-TWPY-Y129-00000-00&context=1519360) _[s 24(D1) of the Immigration Act 1971. His application was](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFG0-TWPY-Y0S4-00000-00&context=1519360)_
referred to the full court by the Registrar. The court was invited by the Crown to provide guidance as to the
sentencing of adult offenders for the new s 24(D1) offence, introduced into the 1971 Act by the _[Nationality and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_
_[Borders Act 2022 (which came into effect on 28 June 2022), in the absence of an offence-specific guideline.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_

_A O'Shea for the applicant._

_A Johnson and B Wild for the Crown._

_Judgment was reserved._

26 September 2023. The following judgment of the court was delivered.

**HOLROYDE VP, JEREMY BAKER and LAMBERT JJ.**

**[1] This applicant, Aydin Ginar, pleaded guilty before a magistrates' court to an offence of attempting to arrive in the**
[United Kingdom without valid entry clearance, contrary to s 1 of the Criminal Attempts Act 1981 and s 24(D1) of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61M0-TWPY-Y129-00000-00&context=1519360)
Immigration Act 1971. He was committed for sentence to the Crown Court at Canterbury where, on 18 August
2023, he was sentenced by Miss Recorder Counsell to eight months' imprisonment. His application for leave to
appeal against that sentence has been referred to the full court by the Registrar.

**[2] The relevant facts can be stated briefly. The applicant is a Turkish national. In June 2023 he, and more than 50**
other foreign nationals, were
**[*768]**


-----

passengers on a rigid inflatable boat which was intercepted by a UK Border Force vessel as it sailed from France
into United Kingdom territorial waters. He was detained. When interviewed under caution he made no comment.

**[3] The applicant had previously travelled to the United Kingdom in 2005. He was refused leave to enter but applied**
for asylum. That application was refused and an appeal against the refusal was dismissed. It appears that the
applicant nonetheless remained in the UK.

**[4] In 2013 he applied for leave to remain. That application was refused with no right of appeal, but the applicant**
sought permission to apply for judicial review. That application was also refused. In November 2015 he left the
United Kingdom. In May 2017 he made an unsuccessful application for entry clearance.

**[5] The offence to which the applicant pleaded guilty is of recent origin. It was created by amendments to the**
_[Immigration Act 1971, introduced by the Nationality and Borders Act 2022, which came into effect on 28 June 2022.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
Section 24 of the amended Act creates a number of offences of illegal entry into the UK and related conduct. By s
24(D1):

'A person who—

(a) requires entry clearance under the immigration rules, and

(b) knowingly arrives in the United Kingdom without a valid entry clearance,

commits an offence.'

**[6] By s 24(F1) a person committing such an offence is liable on summary conviction to imprisonment for a term not**
exceeding the general limit in a magistrates' court and/or to a fine, and on conviction on indictment to imprisonment
for a term not exceeding four years and/or to a fine.

**[7] The first case in which the Crown Court had to sentence for such an offence had come before Judge James, the**
Resident Judge at Canterbury. In the absence of an offence-specific guideline, and in order to offer some
assistance to judges dealing with similar cases, he delivered careful and thoughtful sentencing remarks in which he
helpfully identified considerations which may be relevant to sentencing. He very properly emphasised that he was
not seeking to dictate the approach to be taken by other judges.

**[8] At the sentencing hearing no pre-sentence report was thought to be necessary. We are satisfied that none is**
necessary now. The applicant, now aged 44, had no previous convictions in this country or elsewhere. Dr O'Shea,
then as now appearing for the applicant, put forward the following matters in mitigation. The political situation in
Turkey had become difficult for the applicant and his family. Moreover, his home had been destroyed in the
earthquake which struck Turkey in February 2023, and members of his family were lodging with other relatives. He
intended to apply for asylum again. He was not aware that he was breaking a law which had come into effect in
2022, and would not have travelled if he had known of it. When he saw how dangerous and overcrowded the rigid
inflatable boat was, he did not want to board it, but the people smugglers threatened him with death if he did not do
so.

**[9] The recorder derived assistance from, but rightly recognised she was not bound by, the observations of Judge**
James to which we have referred. She observed that the court had to 'strike a balance between the interests of the
public and the concerns of the public in the proliferation of people coming into the UK on small boats, the public
policy in trying to prevent criminal gangs
**[*769]**

from making significant amounts of money out of people in desperate situations and also take into account your
personal mitigation which has led you to take such a desperate and dangerous route to gain entry into the United
Kingdom'.

**[10] The recorder treated the applicant's previous involvement with the asylum system as an aggravating factor, but**
took into account his previous good character and treated his personal circumstances as providing considerable


-----

mitigation. She concluded that there was no alternative to immediate custody and that the appropriate sentence
after trial would have been 12 months. Giving full credit for the guilty plea, she imposed the sentence of eight
months' imprisonment.

**[11] Dr O'Shea puts forward two grounds of appeal. First, he submits that the recorder made an error of principle in**
treating the applicant's history of previous immigration and asylum applications, which did not involve any criminal
offence, as an aggravating factor. He points out that the previous history had arisen at a time when it was not a
criminal offence to arrive at a designated port without valid entry clearance. In such circumstances, he submits, this
applicant's prior experience of the asylum and immigration system could not properly be treated as an aggravating
feature of the offence, even if in principle such a history might have a relevance in other circumstances.

**[12] Secondly, Dr O'Shea submits that the sentence was in any event manifestly excessive in all the circumstances**
of the case.

**[13] On behalf of the respondent, Mr Johnson and Mr Wild resist the application. They invite this court to provide**
guidance as to sentencing for offences of this kind, and make helpful submissions as to factors which might be
relevant.

**[14] We are grateful to all counsel for their written submissions and for the clarity and focus of their oral**
submissions to the court this morning.

**[15] We agree that it is appropriate for us to give guidance in general terms as to the sentencing of adult offenders**
for this type of offence. Sentencers will need to follow the Sentencing Council's General guideline; the Imposition
guideline, particularly if considering suspension of a prison sentence; and where appropriate, the guideline in
relation to Reduction in sentence for a guilty plea.

**[16] The General guideline sets out overarching principles to be applied when there is no offence-specific guideline.**
The first step is to reach a provisional sentence by taking account of the statutory maximum sentence, sentencing
judgments of this court and definitive sentencing guidelines for any analogous offences, and to assess the
seriousness of the offence by considering the culpability of the offender and the harm caused by the offending. The
court should consider which of the five purposes of sentencing listed in s 57 of the Sentencing Code it is seeking to
achieve by the sentence that is imposed. The court should then adjust the provisional sentence upwards or
downwards to reflect the balance of any aggravating or mitigating factors, before making any appropriate reduction
by way of credit for a guilty plea. For present purposes, we need not mention the later steps in the process.

**[17] Applying that approach to an offence contrary to s 24(D1) of the 1971 Act, we regard the following**
considerations as relevant. First, the statutory maximum sentence for this new offence is, as we have said, four
years' imprisonment. So too is the maximum sentence for an offence under s 24(B1) of the 1971 Act of knowingly
entering the United Kingdom without leave.
**[*770]**

Before the amendments to which we have referred, the maximum penalty for the predecessor of that offence was
six months' imprisonment. It is apparent that Parliament regarded that previous level of sentence as insufficient,
both for the existing offence of entering without leave and for the new offence of arriving without a valid entry
clearance. The four-year maximum is also longer than some other offences which may be committed in an
immigration and asylum context.

**[18] It is however significantly shorter than the maximum sentence of 10 years' imprisonment for an offence of**
[possessing a false identity document with intent, contrary to s 4 of the Identity Documents Act 2010. As counsel for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:51SF-9SP1-DYCN-C29V-00000-00&context=1519360)
the respondent pointed out, use of a false identity document will not ordinarily cease at the border but will facilitate
life in this country thereafter. It will also tend to undermine the passport system generally. We therefore accept the
submission of the respondent that the present offence is inherently less serious than an identity document offence
[of the kind for which this court in R v Kolawole [2004] EWCA Crim 3047, [2005] 2 Cr App Rep (S) 71, [2004] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFT1-DYBP-P55M-00000-00&context=1519360)
_[(D) 439 (Nov) indicated as attracting a sentence in the range of 12 to 18 months, even on a guilty plea and even for](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7TXB-5HC0-Y96Y-H3T0-00000-00&context=1519360)_
a person of previous good character


-----

**[19] Secondly, there has not been any previous judgment of this court concerned with this type of offence.**

**[20] Thirdly, we do not think there is any offence-specific guideline for an offence which is so closely analogous as**
to be helpful.

**[21] Fourthly, the predominant purpose of sentencing in cases of this nature will generally be the protection of the**
public. Deterrence can, in our view, carry only limited weight as a distinct aim in the sentencing of those who have
travelled as passengers in a crossing such as that upon which the applicant embarked. The circumstances of those
who commit offences of that kind, as opposed to those who organise them, will usually be such that they are
unlikely to be deterred by the prospect of a custodial sentence if caught. We know of no evidence or research which
indicates the contrary.

**[22] We think the following considerations are relevant as to culpability and harm. There is legitimate public concern**
about breaches or attempted breaches of border control, and this type of offence, which is prevalent, will usually
result in significant profit to organised criminals engaged in people smuggling. A key feature of culpability inherent
in the offence, save in very exceptional circumstances, is that the offender will know that he is trying to arrive in the
UK in an unlawful manner: if it were otherwise, he would take the cheaper and safer alternative route which would
be available to him. The harm inherent in this type of offence is not simply the undermining of border control but
also, and importantly, the risk of death or serious injury to the offender himself and to others involved in the
attempted arrival, the risk and cost to those who intercept or rescue them, and the potential for disruption of
legitimate travel in a busy shipping lane.

**[23] Those considerations lead to the conclusion that the seriousness of this type of offence is such that the**
custody threshold will generally be crossed and that an appropriate sentence, taking into account the inherent
features which we have mentioned but before considering any additional culpability or harm features, any
aggravating and mitigating factors and any credit for a guilty plea, will be of the order of 12 months' imprisonment.

**[24] Culpability will be increased if the offender plays some part in the provision or operation of the means by which**
he seeks to arrive in the United Kingdom, for example by piloting a vessel rather than being a mere passenger;
**[*771]**

or if he involves others in the offence, particularly children; or if he is seeking to enter in order to engage in criminal
activity (for example by joining a group engaged in modern slavery or trafficking). Culpability will be reduced if the
offender genuinely intends to apply for asylum on grounds which are arguable.

**[25] Consideration of aggravating and mitigating factors must of course be a case-specific matter, but the following**
may commonly arise and will call for either an upwards or downwards adjustment of the provisional sentence. The
offence will be aggravated by relevant previous convictions, by a high level of planning going beyond that which is
inherent in the attempt to arrive in the United Kingdom from another country, and by a history of unsuccessful
applications for leave to enter or remain or for asylum. Even if the previous attempts did not involve any criminal
offence, the history of previous failure makes it more serious that the offender has now resorted to an attempt to
arrive without valid entry clearance. The weight to be given to that factor will of course depend on the
circumstances of the case.

**[26] The offence will be mitigated by an absence of recent or relevant convictions, good character, young age or**
lack of maturity, mental disorder or learning disability, or the fact that the offender became involved in the offence
due to coercion or pressure.

**[27] Cases of this nature will often have powerful features of personal mitigation, to which appropriate weight must**
be given on a fact-specific basis. The circumstances which are relied upon as arguable grounds for claiming
asylum, such as the offender seeking to escape from persecution and serious danger, are likely also to mitigate the
offence of arriving in the United Kingdom without a valid entry clearance. We would add that some offenders may
have been misled as to what would await them in this country if they paid large sums of money to the criminals who
offered to arrange their transport. Some may have suffered injury or come close to drowning in crossing in a


-----

dangerously overcrowded vessel. It will be for the sentencer to evaluate what weight to give to circumstances of
that nature in a particular case.

**[28] Having made those general observations, we return to the present case. It is implicit in the recorder's**
sentencing remarks that she took a provisional sentence after trial of 12 months and then treated the aggravating
and mitigating factors as in effect balancing one another out. We can see no arguable ground for challenging either
her approach or her decision. The provisional sentence was in accordance with the view which we have expressed.
As we have indicated, we reject the submission that the recorder made an error of principle in treating the
applicant's immigration history as an aggravating factor. His repeated efforts over a period of years to enter and
remain in this country made it significantly more serious that he again attempted to arrive in the UK on this
occasion. There were cogent points made on his behalf in mitigation, but the recorder was entitled to reach the
conclusion she did as to the balancing of factors. The resultant sentence of 12 months' imprisonment, reduced to
eight months after giving credit for the guilty plea, cannot be said to be manifestly excessive.

**[29] For those reasons, grateful as we are to counsel, the application fails and is refused.**

**[30] We would add, in view of the fact that other cases of this nature will be coming before the Crown Court, we**
would be grateful if the preparation of the transcript could be expedited.
**[*772]**

**[31] MR JOHNSON: My Lord, in light of the order for expedition, I treat as implicit that your Lordships' judgment is**
appropriate to be cited, notwithstanding that leave was refused.

**[32] THE VICE-PRESIDENT: Yes. Thank you.**

Application refused.

Wendy Herring Barrister.

**End of Document**


-----

