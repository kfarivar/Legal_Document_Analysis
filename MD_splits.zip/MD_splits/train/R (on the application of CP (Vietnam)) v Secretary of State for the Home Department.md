(Admin)

# R (on the application of CP (Vietnam)) v Secretary of State for the Home
 Department [2018] EWHC 2122 (Admin)

Queen's Bench Division, Administrative Court (London)

Karon Monaghan QC sitting as a deputy judge of the High Court

6 August 2018Judgment

**Ms. Hooper (instructed by Duncan Lewis Solicitors) for the Claimant**

**Mr. Hansen (instructed by the Government Legal Department) for the Defendant**

Hearing dates: 13 February 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**By order dated 2 August 2016 the Claimant has been granted anonymity and no report of this case**
**shall directly or indirectly identify the Claimant.**

**KARON MONAGHAN QC (Sitting as a Deputy High Court Judge):**

**Introduction**

1. In summary, by this claim the Claimant challenges the Defendant's failures to properly progress his
trafficking claim and to subject him to immigration detention for a period of 70 days.

2. This case was listed for judgment on 11 May 2018. Unfortunately I discovered on the evening of 10
May 2018, when the Defendant's counsel alerted me to it, that both parties had lodged submissions after
the hearing of the claim, voluntarily, to address an issue raised in oral argument. Those submissions were
not forwarded to me by the Court office and I was unaware that they had been lodged. The case was
therefore taken out of the list to allow me time to consider them. These submissions addressed the case of
_[EM v Secretary of State for the Home Department [2016] EWHC 1000 (Admin) to which I revert below.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JRG-H3S1-F0JY-C34N-00000-00&context=1519360)_

3. Before judgment was listed for hand down a second time, I became aware of the judgment in R (TDT) v
_SSHD_ [2018] EWCA Civ 1395 which seemed to me might have a significant bearing on this case. I
therefore provided the parties with the opportunity to make submissions on _TDT. Submissions were_
received in writing from the parties (the last dated 9 July 2018). Though the parties were invited to notify
me if they considered an oral hearing was necessary to address TDT, neither did so.

**Factual Background**

4. The Claimant is a Vietnamese national who was born on 4th January 1982. He arrived in the UK on an
unknown date.

5. The Defendant is responsible for immigration functions as the responsible Secretary of State for the UK
Border Agency. She is also responsible for the “Competent Authority” (“CA”) which in turn is responsible for
the identification of trafficking victims (through the National Referral Mechanism: “NRM”).


-----

(Admin)

6. The Claimant first came to the attention of the authorities on 14th March 2016 when he was
encountered by police officers from the West Mercia police force at Frankly Service Station with three other
men; one Vietnamese man and two “white” men. The officers plainly had concerns about the Claimant
since one of them completed a referral form in respect of the Claimant and submitted it to the NRM. In that
form, the officer completing it identified certain “general indicators of modern slavery.” These included that
the Claimant was _“distrustful of authorities” and_ _“acts as if instructed by another”. The officer also noted_
that the Claimant's passport or documents were held by another; that he lacked access to medical care;
that he had limited social contact; that he did not know his home or work address and that the officer
perceived him to be bonded by debt. The officer gave an account of the information provided by the
Claimant which included that the Claimant had paid $20,000 to fly from Vietnam to France and that though
he had a genuine passport he was in possession of false documents since he had handed his passport
over to a man he did not know when he arrived in France. The Claimant said that he was then taken to the
UK in the back of a lorry, entering the UK illegally. The officer noted that the Claimant was _“clearly_
_nervous”. The Claimant was recorded as stating that a person called “Nam” had told him on the day he_
was apprehended by the officers to go with the two white men with whom he was found. There was
hydroponic equipment (commonly used in the cultivation of cannabis) in the van in which the officers found
the Claimant, and the two white men were found in possession of small quantities of cannabis. The officer
completing the form also noted that he believed that the Claimant had been “told what to say” by the other
Vietnamese man (who was also suspected by the arresting officers of having been trafficked) and that he
was “reluctant to go into any detail”.

7. The two white men were taken into custody. The Claimant was (initially at least) treated as a victim and,
as I have mentioned, a referral was made to the NRM. In consequence of this the Claimant came to the
attention of the Defendant on 15th March 2016 as a Potential Victim of Trafficking (“PVOT”). During the
course of his detention it appears that the Claimant and the other Vietnamese man were interviewed and
made statements to the effect that they had not been trafficked. The documents indicate that there was
then some confusion as to who was responsible for dealing with the men. The police spoke to one of the
Defendant's immigration officers and to the Defendant's Criminal Cases Unit for advice given that the
custody time limits were approaching. The police were advised that since the Claimant had by then been
referred to the NRM, the immigration authorities were unable to do anything until the NRM had undertaken
an investigation. It appears that the police then spoke to the “NRM out of hours number” (the Salvation
Army who provide safe homes and support for PVOTs) and then concluded that the Claimant would be
released from custody when the custody time limit expired and could go home if he had somewhere to live,
or would be referred to the Salvation Army. Records from the Salvation Army show that the police
contacted them on 15th March 2016 and the Salvation Army advised the police to let them know if the
Claimant needed support. As matters transpired, on 15th March 2015 the Claimant was released from
custody to an address provided to the police. It is not clear who provided that address to the police. The
Defendant's contemporaneous records include an entry for that date stating that “it appears that there has
been a breakdown in communication between police and NRM”. No action was taken in respect of the
hydroponic equipment because the police concluded that the possession of the equipment alone was
insufficient to found a criminal charge. The two white men were cautioned for possession of the cannabis.

8. The Salvation Army contacted the police on 16th March 2016 to follow up on the earlier call to them but
their call was not answered or returned. In any event, the Claimant had left police custody by then and
there is no suggestion that he was “signposted” to the Salvation Army. The Claimant says that following his
release from custody he had nowhere to go since he did not know where he had been staying or where his
traffickers were. The Claimant has said that after his release, he was picked up from a street in the
Birmingham area by men and re-trafficked. In due course the Claimant was found in a cannabis factory. I
shall return to this.

9. In the meantime, on 20th March 2016, the Defendant concluded that there were “reasonable grounds”
to believe that the Claimant had been “a victim of modern slavery (human trafficking)”. This decision was
made within the 5-day target the NRM sets itself for the making of reasonable grounds decisions.  The
minute of that decision records the details provided by the police when making the referral to the NRM that


-----

(Admin)

I have already set out, and noted in conclusion that the Claimant's claim was both internally and externally
consistent and that the decision-maker “suspect[ed]” but could not “prove” that the Claimant was a PVOT.
The consequence of that decision was that the Claimant was granted a 45-day _“recovery and reflection_
_period” (that is, until 4th May 2016). During that period the Claimant was entitled to safe accommodation_
and support. A letter was sent to the Claimant notifying him of the decision and informing him that at the
end of the 45 day period, the Competent Authority would make a _“conclusive grounds”_ decision as to
whether the Claimant was indeed a victim of **_modern slavery. The letter went on to state that in the_**
meantime the police and other UK law enforcement authorities might continue with investigations and that,
though he was under no obligation to cooperate, it might be important in helping to bring to justice those
responsible for his exploitation if he did so. The letter stated that it would _“greatly assist”_ if the Claimant
were able to provide documents applying to his case, including among others, a witness statement. The
decision letter was sent to the Claimant at the address held by the police. There was no response to that
letter.

10. A further letter was sent to the Claimant on or around 21st April 2016 inviting him to an interview.
Again this was sent to the address held by the police. This letter was returned to the Defendant resulting in
a note being placed on the Defendant's records on 27th April 2016 that the Claimant was not at the
address to which the letter had been sent.  Ms. Hooper, for the Claimant, submits that at that point at the
latest the Defendant should have appreciated that the Claimant was missing and the police should have
been notified in case the Claimant was or could be found given that there were reasonable grounds to
believe that he had been a victim of modern slavery. This was not done.

11. On 6th September 2016, the Defendant wrote to the Claimant again advising him that in order to come
to a conclusive grounds decision further information was required. The letter asked for a full statement by
14th September 2016. That letter was sent to the same address as the earlier letters and was returned by
the post-office on 18th October 2016.

12. The Defendant sent an email to the West Mercia police on 6th September 2016 requesting further
information about the Claimant. The officer-in-the-case responded by email on 12th September 2016. In
that email the officer stated that on being interviewed through interpreters the Claimant and the other
Vietnamese man had denied being trafficked but they admitted to being illegal immigrants. The arresting
officers were said to have provided statements recording what they had observed before arresting the
Claimant and the other men. Their statements (which were not attached to the email) were said to have
recorded that they had seen the _“males getting out of the van freely and the [Claimant] and [the other_
_Vietnamese] man were seen by the officers to use their mobile phones freely.”_ The officer-in-the-case
expressed the view that the officers' statements suggested that the Claimant and the other Vietnamese
man “weren't under any duress at the time and were willing participants in any subsequent activities”. The
officer-in-the-case said that the two other men told the police that the “Vietnamese men were picked up in
_Birmingham for an undisclosed friend, to give them a lift to Wales”. The Claimant and the other man were_
therefore bailed on immigration offences and released to their _“home addresses in Birmingham”_ to await
contact from the immigration authorities.  The account said to have been provided by the arresting officers
was obviously inconsistent with that given contemporaneously in the NRM referral. It is also difficult to
reconcile with the police's contact with the Salvation Army in respect of the Claimant.

13. The CA then decided that there was an adequate basis for making a conclusive grounds decision
notwithstanding the absence of further contact with the Claimant. That decision, dated 28th September
2016, was negative. The reasons for the decision noted that the UK is a destination country for people from
Vietnam and that migrant workers are forced into labour in, among other places, cannabis farms. The
decision referred to the officer's email of 12th September 2016, in particular that the Claimant and the two
other men were said to have got out of the van _“freely” and used their phones_ _“freely”_ and that such
behaviour suggested that the Claimant was “not under duress at that time but in fact a willing participant in
_any subsequent activities” (lifting the words from the officer's email). The reasons also referred to the fact_
that the Claimant had denied being trafficked when interviewed and told the police that he was an illegal
immigrant and that “[a]lthough hydroponic equipments (sic) were found in the.. car there was no evidence


-----

(Admin)

_to confirm that they were growing cannabis or that if they were [the Claimant] .. was being forced to take_
_part”. The CA did not accept that the Claimant had been trafficked from Vietnam to France and then from_
France to the UK for the purposes of forced criminality, and so was not a victim of modern slavery. The
conclusive grounds decision was not served on the Claimant (whose whereabouts were unknown) - but
instead filed – because of the lack of any contact details (although inexplicably the decision records the
Claimant as being “currently accommodated at an address provided by the Salvation Army”).

14. At some point thereafter the Claimant was arrested on suspicion of the cultivation of cannabis. The
records show that a check was made by the police with the NRM. The notes record what presumably the
police were told which was that the Claimant had had a PVOT case in March 2016 _“but the subject has_
_been deemed to have not been trafficked into the UK”. The Claimant now says that but for this, he would_
have been treated as a PVOT, just as he was when stopped with cannabis producing equipment in March
2016, with all the consequential protections that would flow.

15. The Claimant was prosecuted for the production of Class B controlled drugs – cannabis - and
abstracting electricity. On 27th April 2017 he was sentenced to four months imprisonment following a plea
of guilty to both offences. (The Claimant did not appeal his conviction or sentence). On sentencing the
Claimant, the judge remarked that:

_“I have no doubt that when you made your way to this country you hoped that you would be able to do an_
_honest job and that you have been exploited by other people. The end result of all of this is that you will be_
_sent home owing money to these people. I am sure you are right at the bottom of the scale as far as this_
_offending is concerned.”_

16. The Defendant was aware of these remarks by no later than 3rd July 2017 (since they refer to them in
correspondence: see Defendant's response to Rule 35 Report referred to below).

17. On 2nd May 2017, the Claimant was visited in HMP Birmingham by an immigration officer to
investigate his immigration status. At the meeting the Claimant gave an account of paying an agent and
travelling from Vietnam to France and then being taken in a lorry from France to the UK and that he was
still indebted to the agents. When asked how he came to be working in a cannabis factory, he said that he
had been wandering around in Birmingham and met a Vietnamese person who found him a place to stay
and that he had not appreciated that it was a cannabis factory. The Claimant says that at this point the
Defendant knew or ought to have known that having been released by the police in March 2016, the
Claimant had gone missing and had then had been re-trafficked – and that a referral to the NRM ought to
have been made. Instead, on 11th May 2017, a Notice of a Decision to Deport the Claimant was emailed to
HMP Birmingham (“a stage 1 Notice”). The Notice stated that as a result of the Claimant's criminality, his
deportation was considered to be “conducive to the public good” and as such he was liable to deportation
by virtue of section 3(5)(a) of the Immigration Act 1971.

18. The Claimant was served with deportation papers on 16th May 2017. On the same day the Claimant
made an application for asylum. The Claimant contends that a referral to the NRM should have been made
by at the latest this date (given the asylum application), if not on the 2nd May, and had such a referral been
made a decision on reasonable grounds would, or should, have been made before expiry of the Claimant's
term of imprisonment and this may have impacted on the decision to detain him thereafter.

19. On 23rd May 2017, the Claimant's detention under immigration powers was ordered by the Defendant.
The Claimant was assessed as a high absconding risk, a medium risk of re-offending and a medium risk of
harm to the public given his offending history. These risks were considered to outweigh the presumption of
release. The Claimant's period of imprisonment ended on 25th May 2017 and on 26th May 2017, the
Claimant was transferred to Harmondsworth Immigration Removal Centre (“IRC”).

20. On 6th June 2017, an asylum-screening interview was conducted. In that interview the Claimant gave
a similar account to that which he had given on 2nd May and this time a referral was made to the NRM (on
or around 8th June 2017). According to Ms. Dhillon, a Higher Executive Officer, who has provided a
witness statement in these proceedings for the Defendant, “it was not apparent … whether this was a new


-----

(Admin)

_claim or a repeat of the old claim”. It appears that it was initially thought to be a repeat claim. It was only_
treated as a new claim of re-trafficking once the Claimant's solicitor made submissions on 29th or 30th
June 2017. This meant that the Claimant's new trafficking claim was not allocated to a case-worker at the
CA until 5th July 2017, as I will come back to.

21. In the meantime on 19th June 2017, the Claimant's solicitors were notified that the Claimant's asylum
interview was to be held on 22nd June 2017. On the same day the Claimant's solicitors wrote to
Harmondsworth IRC requesting that an urgent Rule 35 assessment be undertaken. The Claimant's solicitor
submitted representations to the Defendant on 21st June 2017 requesting the Claimant's immediate
release as an adult at risk and, among other things, seeking details of when the Claimant's reasonable
grounds decision was to be made.

22. On 22nd June 2017, the Claimant's solicitor attended Harmondsworth IRC to accompany the Claimant
to his full asylum interview and was informed by the Claimant that his Rule 35 assessment was to take
place on the same day. The Claimant's solicitor therefore sought a postponement of the interview so the
Claimant could attend the Rule 35 appointment so his suitability for detention could be assessed. The
request for a postponement was refused and the Claimant agreed the interview could go ahead as long as
no decision on his asylum claim would be made before a Rule 35 assessment had been undertaken and
this was agreed. The Claimant was informed that his Rule 35 assessment would be re-scheduled to take
place within the next couple of days. The Claimant stated in interview that he had been detained in France
and the UK and forced to cultivate cannabis. He also said that his “agents” in France assaulted him when
he attempted to escape causing injury to his head and a loss of consciousness. The Claimant again gave a
similar account to that which he had given earlier of having been re-trafficked when released from the
police station. The Claimant's detention was reviewed on the same day. Notwithstanding the asylum claim,
the Defendant decided that continued detention was appropriate having regard to the risk factors said to
have justified his detention in the first place.

23. On 23rd June 2017 the Claimant's solicitor wrote again making representations that the Claimant be
released. On 26th June 2017 the Claimant's solicitor wrote again asking for a Rule 35 assessment. The
Claimant's solicitor then wrote to the Defendant at least once a day (and sometimes two or three times) to
follow up the Claimant's case and to emphasise what they said was the urgency of it.

24. On 29th June 2017, the Claimant's solicitor received an email from a Mrs. Mohammed, the NRM
Administration Manager, confirming receipt of the NRM referral dated 8th June 2017 and stating that “after
_consideration, the information contained in it was deemed to be a duplicate, with information already_
_considered previously”. The email invited the Claimant to make representations if he considered that the_
NRM referral related to a new incident of trafficking. The Claimant's solicitor spoke to Mrs. Mohammed on
the same day and she was informed that the decision had been made on the basis of the NRM form dated
8th June 2017 alone and that they had not seen the interview records of 22nd June when making their
decision. Ms. Hooper submits, therefore, that it was clear that nothing had been done to investigate the
Claimant's trafficking claim or to progress it in the three and a half weeks since the original referral. On the
same day, 29th June, the Claimant's solicitor wrote to the IRC and the CA expressing concern about the
Claimant's case and setting out very detailed representations.

25. Also on 29th June 2017, the Claimant was seen by a doctor for a Rule 35 assessment. The resultant
Report noted the Claimant's claim that he had been attacked by those detaining him in France during
which time they banged his head repeatedly on the wall leading to unconsciousness. The doctor noted
that the Claimant had a 4cm scar and depression on the frontal bone of his forehead which was consistent
with trauma and could evidence a skull fracture. The doctor also expressed the view that the Claimant's
account was plausible. The Report noted that the Claimant might be a victim of torture but did not go on to
comment on the impact of on-going detention (as required by the Defendant's published policy).

26. On 30th June 2017, the Claimant's solicitor wrote to the CA stating that they wished to submit that the
Claimant was a victim of re-trafficking. There was then a referral to the NRM for consideration of the


-----

(Admin)

(re)trafficking claim, but not until 3rd July 2017; that is, as the Claimant points out, some two months from
the date on which the Claimant was interviewed in HMP Birmingham (on 2nd May).

27. On 4th July 2017, the Claimant provided his solicitor with a copy of the Rule 35 report. On the same
day, the Claimant's solicitor made representations to the Defendant asking that the report be sent back to
the doctor so that he could comment on the impact of detention. Also on 4th July 2017, the Claimant's
solicitor was notified by the CA that the Claimant's trafficking claim would now be treated as a new claim,
not a duplicate.

28. The Defendant then served the Claimant with a response to the Rule 35 report. This was dated 3rd
July 2017. The Defendant says that the response was served on the Claimant on 6th July 2017. There is
no explanation for this delay. The Defendant also says that the response was served on the Claimant's
solicitor on 7th July 2017, though the Claimant's solicitor says that she received it on 10th July from the
Claimant himself who told her that he had been given it on 7th July. The Defendant's response stated that
in relation to the Claimant's claim of ill-treatment, his account met the definition of “torture” and so he was
regarded as an adult at risk. It was accepted that the evidence provided met Level 2 of the policy (to which
I will return). However, the response noted that the doctor had not indicated that continued detention was
likely to cause the Claimant harm. The Defendant concluded that continued detention was justified having
regard to what the Defendant stated was the fact that the Claimant came to the UK illegally intending to
engage in criminal activity for financial gain; that the Claimant only raised a claim on protection grounds
when faced with removal and that there was a high risk that the Claimant would attempt to evade detection
and would engage in further criminal activity if released, putting the wider community at risk. The letter
stated that there were significant public protection risks associated with the Claimant being released into
the community and that, as to imminence of removal, the Claimant's asylum claim would be determined at
the earliest opportunity and taking account of any appeals and the travel document process, there was a
realistic prospect of removal within 5 months. It further stated that the Claimant's detention would be
reviewed in line with the Defendant's Adult at Risk policy. According to the evidence of Ms. Dhillon, the
Defendant's view was that the report of Dr. Wootton, to which I return below, “did not materially advance
_matters and was not considered to amount to Level 3 evidence”._

29. On 7th July 2017, the CA decision-maker notified the NRM that she had decided to extend the time for
the making of the “reasonable grounds” decision by two weeks because she had only been allocated it on
5th July and it was a “complex case”. On the same day the Claimant's solicitors served on the Defendant a
pre-action protocol letter in which it was said, among other things, that the decision to detain the Claimant
was unlawful and that there had been unjustified and unreasonable delay in making a reasonable grounds
decision. A psychiatric report from Dr. Wootton was enclosed with the pre-action protocol letter. Dr.
Wootton's report expressed the opinion that the Claimant was suffering from Post-Traumatic Stress
Disorder and a moderate depressive episode, and that detention was _”perpetuating his symptoms and_
_could be considered a continuation of his trauma” with “an ongoing risk to his mental health”._

30. On 18th July 2017 one of the Defendant's case workers recommended that the Claimant be released
from detention because the Claimant's outstanding trafficking and asylum claims meant that there was not
a realistic prospect of removal within a reasonable period. The Claimant's solicitor was notified of this and
urgently sought the Claimant's release. Notwithstanding this, the Claimant remained in detention on the
instruction of the Defendant's Senior Assistant Director and a Senior Executive Officer because of their
view as to the Claimant's _“previous negative immigration history”,_ _“risk of reoffending and harm”, and_
_“timescales”. Ms. Dhillon states that even if a reasonable grounds decision had been made by that point,_
_“the high absconding risk and medium risk of offending and harm remained and amounted to public order_
_grounds sufficient to justify detention, notwithstanding that the claimant had been identified as an adult at_
_risk”. I come back to this when I deal with the Claimant's grounds of challenge. In the meantime, according_
to Ms. Dhillon, the CA was endeavouring to address the outstanding reasonable grounds decision.
However, it is said that it was believed that there were inconsistencies between the Claimant's account in
his claim and in his account to Dr. Wootton and this bore on his credibility so clarification was required.
According to Ms. Dhillon, there was then “a clear reason to believe that the diagnosis presented could also


-----

(Admin)

_be flawed and this further impacted upon the assertion that [the Claimant] was an Adult at risk Level 3,_
_which was not accepted”. I note that Dr. Wootton had been provided with the NRM referral, the Claimant's_
interview records and the conclusive grounds decision of 28th September 2016 among other documents.

31. On 24th July 2017, this claim was issued along with an application for urgent consideration and interim
relief, namely an order requiring that a decision be made on the Claimant's trafficking claim within 2
working days and thereafter that his immediate release be directed to somewhere appropriate and safe. By
an Order made on 25th July 2017, Carr J directed that the Defendant file a response to the Claimant's
grounds for seeking release in the interim application by 4.00p.m. on 27th July 2017 and directing that if
the Claimant was not released that there be an interim hearing to determine the Claimant's application in
the week commencing 31st July 2017.

32. On 27th July 2017, the CA wrote to the Claimant's solicitor to update her on the reasonable grounds
decision. She stated that the reason she had extended the time for making the decision by 2 weeks was
because the case was an unusual and complex one which involved an allegation of re-trafficking. The letter
set out what were said to be discrepancies in the Claimant's account which the Claimant was asked to
account for before a reasonable grounds decision was made.

33. On 28th July 2017, the Defendant informed the Court, through the Government Legal Department, that
the Claimant was to remain in detention.

34. On 31st July 2017, the Claimant's solicitors replied to the CA's letter of 27th July (provided by the
Defendant's solicitors to the Claimant's solicitors on 28th July 2017) seeking all relevant documents and
stating that there was no need for any further information or clarification from the Claimant before a positive
reasonable grounds decision could be made.

35. An interim hearing was set down for 2nd August 2017 for which the Defendant provided a Skeleton
Argument resisting the application for release but did not attend because of the unavailability of panel
counsel. At that hearing, HHJ Cooke (sitting as a Deputy High Court Judge) directed that the Claimant be
released to an address provided by the Salvation Army within 24 hours. (On 19th September 2017, the
same judge granted permission to proceed with this claim). The Claimant was released from detention into
the care of the Salvation Army on 3rd August 2017.

36. A positive reasonable grounds decision was made on 8th September 2017. The effect was that a
period of 45 days of recovery and reflection was provided to the Claimant whereafter the Defendant would
make a conclusive grounds decision. By the time of this hearing, no conclusive grounds decision had been
reached but that appears to be in part because the Claimant's solicitor has sought time to gather further
evidence and so the Claimant makes no complaint about that.

37. Before turning to the legal background and the Claimant's grounds, I need to say something about the
detention reviews and detention review minutes. The first minute addressing the reasons for the Claimant's
detention states that the Claimant was a “high” absconding risk and that he posed a medium risk of _“re-_
_offending” and a medium risk of_ _“harm” to the public. This reflected the assessment that resulted in the_
initial decision to detain the Claimant under immigration powers. The assessment of the Claimant as being
at high risk of absconding is said to be based on the fact that the Claimant was aware of the Defendant's
intention to deport him and so “he will have little incentive to remain in touch with the Home Office”. The
assessment of the risk of re-offending and risk to harm to the public (as “medium”) was stated to be based
on the fact that the Claimant was present in the UK illegally and had no permission to work and so it was
likely he would re-offend to sustain himself and that offences involving drugs are offences which have a
wide impact on the health and morals of the community at large. The Claimant says that having regard to
the Defendant's own policies, on the basis of this assessment and even without any trafficking history, he
should have been released following expiry of his prison sentence with stringent conditions. Following the
reasonable grounds decision, the Claimant contends that he should have been released unconditionally.
The next detention minute is dated 23rd June 2017 and is materially identical to the first. The next is dated
21st July 2017 and is materially identical to the first two save that it was now stated that the Claimant was
at Level 2 under the Adults at Risk Policy and that the Claimant's account met the “definition of torture”


-----

(Admin)

noting, however, that the doctor had “not indicated that a period of detention [was] likely to cause harm”.
This reflected the Defendant's response to the Rule 35 Report. In all cases the minutes record the ultimate
decision on detention, namely that the assessed risks outweigh the presumption of release.

38. Regular progress reports were provided to the Claimant concerning his detention. These contained the
purported reasons for the Claimant's continuing detention. The reasons are pro forma; in certain parts they
are incomplete; some of the reasons said to apply are inapplicable to the Claimant's case and some
reasons given are inconsistent with the detention minutes. For example, the progress report of 22nd June
2017 states that detention has been authorised because the Claimant was likely to abscond if given
temporary admission or release and that there was insufficient reliable information to decide on whether to
grant temporary admission or release. The reasons given for coming to these conclusions, include: “You
_have previously failed or refused to leave the United Kingdom set out the details when required to do so”;_
_“You have previously absconded or escaped on date set out the details and there is a significant risk that_
_you would do so again” and “you have previously failed to comply with conditions placed upon (sic) by the_
_police or the courts”. The underlining is mine and it highlights where the decision-maker was plainly_
required to enter details if the pro forma reasons were applicable: details were not included and nor were
the reasons applicable though they were stated to be so. There are other examples. In addition, the
Claimant is told in this progress report that he has been assessed as presenting a “high risk” of harm to the
public: that is inconsistent with the minutes prepared as part of the detention reviews. The report of 24th
July is similarly drafted.

**Law and Policy**

39. It is trite law that absent a special consideration, which must be explained, the Defendant will err as a
matter of public law if she does not exercise her powers in accordance with her own policies (see, for
example, R (Kambadzi v Secretary of State for the Home Department [2011] 1 WLR 1299). The material
policies for this claim include those set out below.

**_Immigration Directorate Instructions_**

40. The Immigration Directorate Instructions addressing the _“Deporting Non-EEA Foreign Nationals”_
(2015) provide that:

3.1 Section 3(5) of the Immigration Act 1971 allows the Secretary of State to deport individuals where their
presence in the UK is not conducive to the public good. This gives the Secretary of State discretion to act
in a way that reflects the public interest.

……

3.2 How to consider if deportation is appropriate

A non-EEA foreign national will normally be considered for deportation pursuant to the _[Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
_[1971 if …..they have been involved in criminal activity in the UK or overseas and meet one of the criteria](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
below:

…..

the non EEA foreign national has received a custodial sentence of any length for a serious drug offence or
gun crime. See: Drug offences (Bournemouth commitment) guidance…

41. The production of cannabis is counted as a serious drug offence. As adverted to earlier in this
judgment, the Defendant decided to deport the Claimant consistent with her policy as encapsulated in the
above instructions. In consequence, the Defendant had a discretion to detain the Claimant pending
deportation pursuant to her powers under paragraph 2 of Schedule 3, of the Immigration Act 1971.

**_Enforcement Instructions_**

42. The Defendant's policy on detention is expressed in Chapter 55 of the Defendant's Enforcement
Instructions and Guidance Chapter 55 provides that “[t]he power to detain must be retained in the interests


-----

(Admin)

_of maintaining effective immigration control. However, there is a presumption in favour of temporary_
_admission or release and, wherever possible, alternatives to detention are used”. That policy applies in the_
case of foreign national offenders: _“the starting point”_ remains that the person should be released on
temporary admission or released unless the circumstances of the case require the use of detention. If a
decision to detain is made then a properly evidenced and fully justified explanation of the reasoning behind
the decision to detain must be in all cases retained on file.

43. Where a foreign national offender meets the criteria for consideration of deportation, Chapter 55 states
that “the presumption in favour of granting immigration bail may well be outweighed by the risk to the public
of harm from re-offending or the risk of absconding, evidenced by a past history of lack of respect for the
law”.  The Instructions in Chapter 55 state that in the case of convictions for one of the more serious
offences, this will be strongly indicative of the greatest risk of harm to the public and a high risk of
absconding. As a result, it is stated that the high risk of public harm carries particularly substantial weight
when assessing if continuing detention is reasonably necessary and proportionate. In practice, it is said, it
is likely that a conclusion that such a person should be released would only be reached where there are
exceptional circumstances which clearly outweigh the risk of public harm and which mean detention is not
appropriate. Drug-related offences are treated as “serious” offences for these purposes.

44. As to assessing the risk of harm to the public, in the absence of a risk assessment from NOMS (and
none seems to exist for the Claimant), the Defendant's case worker is required to make a judgement on the
risk of harm to the public based on the information available to them. Those assessed as low or medium
risk should _“generally be considered for management by rigorous contact management under the_
_instructions” (ie released on bail with restrictions)._

45. The Instructions address the requirement for monthly reviews of detention. They are necessary in all
cases to ensure that detention remains lawful and in line with stated detention policy at all times. The
instructions require that at each review, “robust and formally documented consideration should be given to
_all other information relevant to the decision to detain”. The requirement for a periodic review of detention_
is designed to give practical effect to the Hardial Singh principles (R (Kambadzi v Secretary of State for the
_Home Department [2011] 1 WLR 1299, §51, per Lord Hope)._

46. There is a public law duty to conduct detention reviews in accordance with the Instructions (absent
some good reason not to do so). If reviews are not carried out continued detention will not be authorised by
the initial decision to detain (Kambadzi §54, per Lord Hope) and will be unlawful. Thus the discretion to
continue detention must be exercised both in accordance with the Hardial Singh principles and additionally
in accordance with the policy stated in Chapter 55, including concerning the carrying out of detention
reviews (Kambadzi, §52, per Lord Hope). The timetable for reviews is an essential part of the process and
operates as limitations on the way the discretion to detain may be exercised. The same is true where the
reviews do take place in accordance with the prescribed timetable but _“do not partake of the quality or_
_character required to justify the continuance of detention” (Kambadzi §86, per Lord Kerr). In such a case_
tortious remedies will be available, including damages (ibid. and see R (Lumba) v Secretary of State for the
_Home Department [2012] 1 AC 245, §71, per Lord Dyson). It will be no defence that a claimant could have_
been lawfully detained in any event since unlawful imprisonment is actionable per se (Kambadzi §54, per
Lord Hope; Lumba §71, per Lord Dyson). However, where it can be shown that the power could and would
have been lawfully exercised even had proper reviews been undertaken, that will be a powerful reason for
concluding that the detainee has suffered no loss and is entitled to no more than nominal damages. But
that is not a reason for holding that the tort has not been committed (ibid.).

**_Adults at Risk_**

47. Section 59 of the Immigration Act 2016 obliges the Defendant to issue guidance specifying matters to
be taken into account in determining “(a) whether a person (“P”) would be particularly vulnerable to harm if
_P were to be detained or to remain in detention, and (b) if P is identified as being particularly vulnerable to_
_harm in those circumstances, whether P should be detained or remain in detention.” A person to whom_


-----

(Admin)

guidance is addressed _“must take the guidance into account” (section 59(3)). That Guidance has been_
[issued: “Immigration Act 2016: Guidance on Adults at Risk in Immigration Detention August 2016.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JTC-N011-DYCN-C454-00000-00&context=1519360)

48. The Guidance provides that the clear presumption is that detention will not be appropriate if a person
is considered to be “at risk”. As it makes clear that does not mean that no one at risk will ever be detained.
Instead, detention will only become appropriate at the point at which immigration control considerations
outweigh this presumption. It is plainly intended to set high the bar which must be crossed if detention of an
adult at risk is to be justified – or at least higher than that applicable in the case of a person who is not at
risk. In each case, consideration will need to be given to the weight of evidence in support of the
contention that the individual is at risk, and the level of that risk, and assessed against any immigration
factors to establish whether these factors outweigh the risk. The greater the weight of the evidence
demonstrating that an individual is at risk, the weightier the immigration factors need to be in order to justify
detention.

49. Guidance is provided on the weight that should be afforded evidence pointing to a risk to an individual
if detained. A self-declaration of being an adult at risk is to be afforded limited weight and classed as level
1 evidence. Professional evidence (e.g. from a social worker, medical practitioner or NGO), or official
documentary evidence, which indicates that the individual is an adult at risk should be afforded greater
weight and is classed as level 2 evidence. Where there is professional evidence (e.g. from a social worker,
medical practitioner or NGO) stating that the individual is at risk and that a period of detention would be
likely to cause harm – for example, increase the severity of the symptoms or the condition that have led to
the individual being regarded as an adult at risk in the first place – then this is to be afforded significant
weight. Individuals in these circumstances will be regarded as being at evidence level 3.

50. The Guidance identifies a list of conditions or experiences which may indicate that a person may be
particularly vulnerable to harm in detention. These include (i) that a person is suffering from a mental
health condition or impairment (including psychiatric illness or clinical depression, depending on the nature
and seriousness of the condition) and (ii) that a person is a victim of human trafficking or modern slavery.

51. Any risk factors identified and evidence in support will need to be balanced against any immigration
control factors in deciding whether a person should be detained. Those include “public protection” issues
(so that consideration must be given to whether the individual raises public protection concerns by virtue
of, for example, criminal history, security risk, decision to deport for the public good) and _“compliance_
_issues” (so that an assessment will be made of the individual's risk of absconding, based on the previous_
compliance record). As the Guidance makes clear an individual should be detained only if the immigration
factors outweigh the risk factors such as to displace the presumption that individuals at risk should not be
detained. This will be a highly case specific consideration.

52. Where a positive reasonable grounds decision is made and the PVOT is in immigration detention then,
according to the Defendant's Guidance to the Competent Authority (“Victims of **_Modern slavery –_**
_Competent Authority Guidance” (2016)), they will normally need to be released unless in the particular_
circumstances, their detention can be justified on grounds of “public order”.

**_Trafficking_**

53. As far as material to this claim, the Defendant's policies on trafficking are contained within two
documents:  “Victims of Modern Slavery – Competent Authority Guidance” (2016) (“CA Guidance”) and
the “Victims of Modern Slavery – Frontline Staff Guidance” (2016) (“Front Line Staff Guidance”).

54. The CA Guidance sets out some “indicators” of trafficking/modern slavery including as follows:

Victims may:

be reluctant to come forward with information

not recognise themselves as having been trafficked or enslaved

….


-----

(Admin)

It is not uncommon for traffickers or **_modern slavery facilitators to provide stories for victims to tell if_**
approached by the authorities. Errors or lack of reality may therefore be because their initial stories are
composed by others and learnt.

Victims' early accounts may also be affected by the impact of trauma.

55. The Frontline Staff Guidance includes the following “indicators”

- distrust of authorities

- acting as if instructed by another

- passport or travel document has been confiscated

56. The Frontline Staff Guidance provides detailed instructions on why victims may not recognise
themselves as a victim of modern slavery or trafficking, or be reluctant to be identified as such.

57. Both the CA Guidance and the Front Line Staff Guidance state that the trafficking guidance they
provide is based on the Council of Europe Convention on Action Against Trafficking in Human Beings
(ECAT). The UK has ratified ECAT but it has not been incorporated into domestic law. However, the NRM
was introduced as part of the Government's implementation of ECAT. Article 10(1), ECAT provides that:
_“Each Party shall provide its competent authorities with persons who are trained and qualified in preventing_
_and combating trafficking in human beings [and]… in identifying and helping victims….”. The Defendant_
gives effect to this obligation through the two stage _“reasonable grounds” and_ _“conclusive grounds”_
decisions.  The threshold for a positive reasonable grounds decision is a low one (“I suspect but I cannot
_prove“) and the Guidance states that the expectation is that the CA will make a reasonable grounds_
decision within 5 working days of the NRM referral being received. The CA must then conclusively decide
whether, on balance of probabilities, the person concerned is a VOT (the conclusive grounds decision).
Before coming to that decision the CA must make every effort to secure all available information that could
prove useful in establishing if there are conclusive grounds. That obligation may require that the PVOT is
interviewed. As the Guidance states, if the information available is slim or contradictory, an interview may
help to clarify things – for example by allowing the potential victims to comment on any inconsistencies.

58. The Guidance demands a high standard of reasoning from the CA when coming to a conclusive
grounds decision. Where a decision turns on credibility, the CA “must carefully analyse the relevant factors
_and explain her reasoning about credibility in her decision. It is unfair, and unlawful, for the CA to shy away_
_from grappling with the issue of credibility, and then to refuse a claim on the basis that it is uncorroborated,_
_especially where no opportunity has been given in interview for the Claimant to deal with any doubts about_
_credibility which the CA may have.” (R (M) v Secretary of State for the Home Department_ _[2015] EWHC_
_2467 (Admin))._

59. As to the standard of scrutiny which the Court should apply in reviewing any “conclusive grounds”
decision on rationality grounds,

If the failure to identify a trafficking victim correctly is a breach of his or her fundamental rights, then
another fundamental right is her or her right to have his or her claim properly investigated. In consequence,
a failure to consider fairly and properly whether a person has been trafficked must also be a breach of his
or her fundamental rights bearing in mind the significance of the rights granted to a person held to be
trafficked …

…[A]ll these factors show that the present application is in an area where the court should and can adopt a
more rigorous approach to decisions refusing to hold that a person has been trafficked…..

[P]ulling the threads together, the rationality of a gateway decision that a person is not the victim of
trafficking requires a heightened or a more rigorous level of scrutiny both because it relates to fundamental
rights and also because it arises in an area in which a court has the requisite knowledge. This means that
the approach of the courts should be in accordance with the approach of: Carnwath LJ (with whom MooreBick and Etherton LJJ agreed) in R (YH) v Secretary of State [2010] EWCA Civ 116 [24], which was that:


-----

(Admin)

“the need for decisions to show by their reasoning that every factor which tells in favour of the applicant
has been properly taken into account”.

(R (SF) (St Lucia) v Secretary of State for the Home Department [2016] 1 WLR 1439, §§100, 102, 104).

60. The CA Guidance makes explicit provision for people who go missing while their case is still
progressing through the NRM. In such a case, the CA must still come to a conclusive grounds decision if
sufficient information is available to do so. However, where trafficking indicators are present but are
insufficient to meet the standard of proof required for a positive conclusive grounds decision and it is not
possible to gather more information because the individual is missing, the Guidance anticipates that that
decision will be suspended. In such circumstances the CA must (i) report the PVOT as a vulnerable
missing person to the police and arrange for a missing person marker to be added to the police national
computer (PNC) (ii) ￿register the case as a “PVOT suspended absconder” on the Defendant's CID and (iii)
ensure the case is flagged on CID as having had the issue of human trafficking or modern slavery raised
so the person is recognised as potentially at risk if they are encountered again.

**Grounds, Discussion and Conclusions**

61. I will deal with each of the Claimant's grounds in turn adopting the numbering in the Claimant's
Skeleton Argument.

**_Ground 1: Failure to identify and protect the Claimant as a victim of trafficking_**

62. Under this ground the Claimant primarily complains of a failure to suspend the investigation into his
trafficking claim in 2016 and instead proceed to make a negative conclusive grounds decision. The
Claimant contends that the failure to suspend was in breach of the Defendant's CA Guidance, was
irrational and violated Article 4 of the European Convention on Human Rights (“ECHR”) (Sch 1, Human
Rights Act 1998).

63. I have already set out the factual background to the conclusive grounds decision. The CA had before
them an account of the police officer first encountering the Claimant which disclosed a number of matters
which were indicative of the Claimant having been trafficked. This led to the reasonable grounds decision
being made appropriately timeously: for reasons which are understandable the CA suspected that the
Claimant was a VOT. In its reasonable grounds decision letter, the CA sought relevant documents from
the Claimant. It also decided to interview the Claimant (as is apparent from their letter of 21st April 2016),
presumably because it considered that this was required or at least desirable before coming to a
conclusive grounds decision.

64. By no later than the 27th April 2016 the CA ought to have appreciated that the Claimant was likely to
be missing. This much was clear from the returned letter and the entry on the file noting that the Claimant
was not at the address to which the letter was sent. Mr. Hansen submitted to me that the Claimant had not
gone missing in the sense anticipated by the CA Guidance (he had given an address to the police) and in
any event the Defendant could not have known that the Claimant was not at the address given until 18th
October 2016 when the letter of 6th September was returned; that is, after the conclusive grounds decision
had been reached. I do not accept these submissions. It made no difference that the address from which
correspondence was returned had been given by the Claimant himself (if indeed it had). The CA ought to
have known that the Claimant was likely to be missing when the first letter to the address held by the police
was returned.

65. The CA's letter of 6th September 2016 shows that the CA continued to hold the view that further
information was required to reach a conclusive grounds decision. The only piece of information that came
to the CA between the 6th September and the 28th September 2016, when the decision was made, came
in the form of the email dated 12th September from the officer-in-the-case. This email described the
Claimant on arrest very differently from the portrayal contemporaneously recorded by the arresting officer.

66. Mr. Hansen submitted that at that point the CA had sufficient information to come to a conclusive
grounds decision Further Mr Hansen argued that the Guidance does not prevent the decision-maker from


-----

(Admin)

making a negative conclusive grounds decision if sufficient information is available to make that decision,
notwithstanding that the PVOT is missing. I agree and I reject Ms. Hooper's submissions to the contrary.
There is nothing in the CA Guidance that is to the effect contended for by Ms. Hooper. Further, Mr. Hansen
submits that if the CA concludes that there is sufficient information to reach a conclusive grounds decision
and then makes a negative conclusive grounds decision, that is challengeable only on _Wednesbury_
grounds, applying the heightened degree of scrutiny required (SF, supra). I agree.

67. However, I do not agree that the CA could rationally have concluded that they had sufficient
information to come to a (negative) conclusive grounds decision. The account in the email of 12th
September at the very least required probing if the differing accounts -as between that given by the
arresting officer contemporaneously recorded in the NRM referral and that given in the email - were to be
reconciled. The CA, however, simply did not grapple with the inconsistencies in these accounts or seek to
resolve them.

68. Mr. Hansen placed great weight on the Claimant's denial in interview of having been trafficked.
However, account must be taken of the CA Guidance which recognises that VOTs may not see themselves
as having been trafficked and/or may have been told what to say by their traffickers. Mr Hansen says,
however, that self-denial is very different from self-declaration which, he says, the CA Guidance is getting
at. The fact that the Claimant may not have declared himself to have been trafficked is one thing, he says,
but a denial is altogether different. I do not regard the distinction Mr. Hansen seeks to draw as so clear-cut.
I do, however, accept that a denial may be a relevant factor but it may just as well be consistent with
having been trafficked as not, depending on the wider circumstances. Mr. Hansen points to the fact that the
denial was given through interpreters and away from his putative traffickers and these were material
considerations. I agree. Again, however, that must be weighed against what the Guidance acknowledges
may be a reticence to provide information. These are all matters that may be relevant but they do not affect
the underlying difficulty that presented itself and ought to have been confronted, namely the stark
differences in the accounts given in the NRM referral and the email of 12th September. Just as credibility
must be “grappled with” so must inconsistencies of the sort that the CA were presented with following the
email of 12th September.

69. In my judgment, therefore, the CA's decision that it had sufficient information to come to a negative
reasonable grounds decision was irrational and unlawful. The irrationality of the decision is underscored
by the fact that the circumstances in which the Claimant was discovered by police officers in March 2016
are consistent with what is known about people trafficking from Vietnam and the relationship between that
and cannabis farming, referred to in the Defendant's conclusive grounds decision. As the Claimant
contends, it ought to have been clear to the CA that further information was indeed required and if inquiries
could not be progressed because of the absence of the Claimant, the investigation ought to have been
suspended. The failure to do so was both irrational and in breach of the Defendant's CA Guidance.

70. Further, the CA's reasons for coming to a negative conclusive grounds decision do not demonstrate
that it had carefully analysed the relevant factors, including the contemporaneously recorded indicators of
trafficking. No reasons are given for accepting the later statements as to the Claimant's demeanour on
arrest in preference to the contemporaneous account or for giving weight to the Claimant's denial in
interview. Further, the reasons do not demonstrate that every factor which told in favour of the Claimant
had been properly taken into account: while there is a passing mention of the NRM referral form in the
reasons, no explicit mention is made of a number of things in the NRM that did not appear in the later email
(for example, the distrustfulness exhibited by the Claimant) and nor is there anything in the reasoning
otherwise to suggest those matters were taken into account. In my judgment, there was a failure to
undertake any fair or proper consideration of whether the Claimant was trafficked and for that reason too
the decision reached is irrational, unfair and unlawful.

71. Ms. Hooper made a further point on the Defendant's policies. She argued that the CA Guidance was
such that a negative conclusive grounds decision was never permissible without an interview taking place
with the PVOT first. She relies on what she says is effectively a presumption that they will take place
unless the decision is to be positive (“Interviews are more likely to be relevant to a conclusive grounds


-----

(Admin)

_decision rather than a reasonable grounds decision…….it may be the case that the information submitted_
_on the individual's situation is so compelling that an interview is not necessary”). I do not think the_
Guidance goes that far. It is possible to anticipate circumstances in which the result – a negative one – is
obvious and inevitable and nothing could be said which would affect the outcome. I need say no more
about that in light of my conclusions above.

72. For these reasons, I have concluded that both the CA's decision that there was sufficient information to
make a (negative) conclusive grounds decision and the decision itself were irrational and unfair. Since in
the case of a missing PVOT (as the evidence indicated the Claimant was likely to be at the material time),
the CA Guidance is such that it is only where the CA is in possession of sufficient information that a
conclusive grounds decision can be reached, the making of the conclusive grounds decision was
additionally made in breach of the Defendant's CA Guidance and constituted a public law error.

73. As to the effect of my conclusions on this issue, Ms. Hooper says these conclusions are substantively
important. This is because, she argues, had the investigation been suspended, the Claimant would have
been flagged as a PVOT on the PNC and CID and that is likely to have affected the way he was treated
when encountered again. It is not for me to decide whether the Claimant would have been prosecuted and
sentenced to a period of imprisonment if there was an extant reasonable grounds decision when the
Claimant was arrested in (it appears) 2017 and I do not do so. But the error in reaching the conclusive
grounds decision bore directly on the decision to detain the Claimant under immigration powers after expiry
of his term of imprisonment. Mr. Hansen in his Skeleton Argument argues that if (which the Defendant
denies) the decision should have been suspended, this does not mean that the Claimant's subsequent
immigration detention was unlawful: whether it was or not depends upon whether there were sufficient
public order grounds to justify his detention. I deal with this below.

74. Ms. Hooper also argues under this Ground that the inadequacy of the investigation leading up to the
conclusive grounds decision violated Article 4, ECHR.  At the hearing before me, and in her written
argument, Ms Hooper submitted that Article 4 imposes positive protective and procedural obligations on
States including an obligation to investigate situations of potential trafficking. This meant that a failure to
carry out an adequate investigation into a PVOT, for the purposes of identifying and protecting them, would
violate Article 4. Ms. Hooper cited the well-known case of Rantsev v Cyprus and Russia (2010) 51 EHRR
in support of that proposition.  Before judgment in R (TDT) v SSHD [2018] EWCA Civ 1395 was handed
down, it seemed to me that Ms. Hooper faced an insurmountable obstacle in pursuing this ground: her
submission was in direct conflict with a Court of Appeal authority that binds me. In Secretary of State for
_the Home Department v H_ _[[2016] EWCA Civ 565 the Court of Appeal held that while there is an](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_
investigative obligation inherent in Article 4, that is targeted at identifying and bringing to justice
_perpetrators, that is, traffickers. The parameters of the duty were described in H as follows: “[T]he focus of_
_the procedural obligation under article 4 is to investigate cases of alleged trafficking and to identify those_
_responsible for crimes committed within the jurisdiction of the State Party in question with a view to_
_prosecution for offences which have occurred within that jurisdiction. It is also concerned with immediate_
_relief for those suffering harm and coercion” (§29, per Burnett LJ). This can be contrasted with ECAT that_
has wider scope, and which the United Kingdom has sought to implement through the establishment of the
CA. It is the police, not the CA, that is responsible for the discharge of the obligation under Article 4
concerning the identification and prosecution of alleged traffickers (H, §§30-31, per Burnett LJ). The
involvement of the CA is not for the purpose of discharging the procedural obligations Article 4 ECHR (H,
§§35, per Burnett LJ). The Court of Appeal also observed that that position was not altered by the making
of a positive reasonable grounds decision.

75. Ms. Hooper said three things about _H. Firstly, she argued that_ _H_ was wrongly decided because it
conflicts with the decision in Rantsev. Rantsev was fully considered by the Court of Appeal in H and it is
the judgment of the Court of Appeal that is binding upon me. Secondly, she argued that the holding in H
ought to be reconsidered in the light of the recent decision of the ECtHR in J and others v Austria (2017)
Application No. 58216/12. The decision of the ECtHR in J restates the principles in Rantsev and since the
Court of Appeal in H had those well in mind, it did not provide me with any basis upon which I could depart


-----

(Admin)

from the decision of the Court of Appeal in H. Thirdly, Ms. Hooper contended that the observation in H that
the scope of the investigative obligation under Article 4 was not affected by a positive reasonable grounds
decision was obiter.  I do not agree. The ratio of H is that the investigative obligation under Article 4 is
targeted at bringing to justice traffickers, not identifying victims. It follows from that, as a matter of logic,
that the position is not affected by whether the CA has made a positive reasonable grounds decision or
not. That forms part of (or at least necessarily flows from) the ratio.

76. However, particularly in light of the guidance in R (TDT) v SSHD [2018] EWCA Civ 1395, I accept that
given the width of the protective obligation inherent in Article 4, there may be circumstances where an
investigation of some sort is required if the protective obligation is to be properly discharged – a simple
example may be causing an investigation to take place into the whereabouts of a missing PVOT.  I accept,
however, that TDT does not change the essential holding in H. The procedural (investigative) duty, as was
held in H, imposes an obligation on States to investigate cases of alleged trafficking and to identify those
responsible for trafficking crimes, and in this jurisdiction that obligation rests with the police.

77. In TDT, the Claimant was a young Vietnamese man who was found in the back of a lorry with other
young men and boys, some of whom were also Vietnamese. TDT was then detained in an IRC with a view
to him being returned to Vietnam as soon as possible. Solicitors were soon instructed and caused a
referral to be made to the CA. The solicitors also sought TDT's release but made it clear that a package of
measures would be required to protect him to ensure that he did not fall back into the hands of traffickers
on release. The Defendant did not act upon that and TDT's solicitors therefore commenced judicial review
proceedings whereupon the Defendant decided to release _TDT. When the solicitors learnt of this they_
wrote immediately protesting that TDT should not be released without a package of measures being put in
place. However, his release proceeded in any event. TDT was released on temporary admission to reside
at an address in South London and he has not been seen since. TDT's solicitors believe that he has been
re-trafficked. The judicial review claim proceeded nonetheless with _TDT's_ representatives arguing that
there had been a breach of the protective obligation in Article 4, ultimately reaching the Court of Appeal.

78. The Court of Appeal in TDT identified the duties inherent in Article 4 as follows:

(a) a general duty to implement measures to combat trafficking – “the systems duty”;

(b) a duty to take steps to protect individual victims of trafficking – “the protection duty” (sometimes called
“the operational duty”);

(c) a duty to investigate situations of potential trafficking – “the investigation duty” (sometimes called “the
procedural duty”).

(para 17)

79. _TDT_ concerned a complaint about an alleged breach of the protective obligation (“the operational
duty”). Underhill LJ (with whom the other of their Lordships agreed) held, consistently with the holdings in
_Rantsev, that the protective obligation is treated as having been triggered where it is_ _“demonstrated that_
_the State authorities were aware, or ought to have been aware, of circumstances giving rise to a credible_
_suspicion that an identified individual had been, or was at real and immediate risk of being, trafficked”_
(para. 18). The “credible suspicion” is substantially equivalent to the “reasonable grounds” threshold but as
the Court of Appeal made clear, the duty may be triggered before a reasonable grounds decision has been
made (para. 35). As to the _“real and immediate risk” test, this_ _“ is inevitably sensitive to the particular_
_factual situation under consideration…..[T]he essential question is simply whether the material available_
_shows a sufficient risk – in this case of re-trafficking – for protective measures to be needed” (para. 46)._
Underhill LJ also observed that

_“being a past victim of trafficking and being at real and immediate risk of being (re-) trafficked are very_
_closely inter-related” (para. 82.)_

80. Further, though the ultimate question in any given case will be whether there are reasonable grounds
for suspecting that the particular individual in question is a victim of trafficking “one of those grounds may


-----

(Admin)

_be – indeed is very likely to be – that he or she falls into a class known to be peculiarly vulnerable to being_
_trafficked. The weight to be given to generic evidence of that kind in any particular case will depend both_
_on the strength of the association alleged and the reliability of the evidence supporting it” (para. 47). The_
significance of that for the Claimant in this case, just as it was in TDT, is that “[t]here is abundant evidence,
_and it is undisputed, that there is a high incidence of young Vietnamese males being trafficked to the UK._
_There was plenty of material which was, or should have been, known to the Secretary of State that showed_
_that young Vietnamese males trafficked to this country are at high risk of falling back into the control of_
_their traffickers if released from detention”_ (paras. 78 and 80). That does not mean of course that any
young Vietnamese man should be assumed to be a victim of trafficking or that all Vietnamese young men
who have been trafficked are re-trafficked, but these are relevant factors.

81. Ms. Hooper submits in her written submissions on _TDT_ that the Article 4 protective obligation was
breached when the Claimant was released from detention on 15 March 2016 without any protective
measures being put in place. Further, the duty was breached when the CA failed to conduct an
investigation into the Claimant's whereabouts and then in failing to ensure that the missing persons
guidance was complied with (that is by, (i) reporting the Claimant as a vulnerable missing person to the
police and arranging for a missing person marker to be added to the police national computer (PNC) (ii)
￿registering him as a _“PVOT suspended absconder” on the Defendant's CID and (iii) ensuring the_
Claimant was flagged on CID as having had the issue of human trafficking or modern slavery raised so
the Claimant would be recognised as potentially at risk if he was encountered again).

82. I accept the submissions of Ms. Hooper that the CA had sufficient material on 15 March 2016 to raise
a credible suspicion that the Claimant had been trafficked (and indeed the CA reached a positive
reasonable grounds decision on the basis of it shortly afterwards) and that absent some steps to protect
him, he was at real and immediate risk of being re-trafficked. This is so given what they knew from the
referral about the Claimant and about what is widely known about the trafficking and re-trafficking of young
Vietnamese men, as alluded to in TDT, particularly into work in cannabis farms.

83. The CA took no steps to protect the Claimant when the referral was first made on 15 March 2016
though they came to know quickly that he was going to be released from police custody. There is stated to
have been a breakdown in communication with the police, though the CA does not appear to have done
anything to remedy that at the time. There were no steps taken to ensure that Claimant had somewhere
safe to go on his release, though his potential vulnerability was evident from the referral. This led, Ms.
Hooper contends, to the Claimant's re-trafficking. Thereafter, when it became known (or ought to have
been known) that the Claimant was missing, the CA took no steps such as would meet the requirements of
the CA Guidance addressing missing persons. I accept that the Article 4 duty and the Guidance are not coextensive but the Guidance here is a helpful indication of what could readily have been done by way of
protective measures.

84. I accept Mr. Hansen's submissions that the protective duty is not an absolute one: it must be
interpreted in a way which does not impose an impossible or disproportionate burden. However, the CA
has arrangements in place, including with the Salvation Army to provide safe havens. They were aware
that the Claimant was going to be released and they did nothing to ensure that proper arrangements were
in place ensuring that he could access that safe accommodation. Thereafter, there were no steps taken to
alert the police either to search for him or to flag him as a missing person so that if he was found protective
measures could be put in place. Neither of these things would, in my judgment, have imposed a
disproportionate burden. Mr. Hansen's submission that the CA could not have known that the Claimant
had been re-trafficked, if indeed he was, is unconvincing given the circumstances in which he was found in
March 2016 and the fact that it became clear early on that he was in all likelihood not at the address given.
Far from taking protective steps, the CA did nothing to secure the Claimant's safety and instead
progressed to a conclusive grounds decision thereafter including in their records a note that the Claimant
had been “deemed” not to be trafficked so that when in March 2017 the Claimant was found again, he was
presumed not to be a trafficking victim with the consequence that no further steps were taken for a very


-----

(Admin)

long time to provide protection. All of these matters constitute breaches of the protective obligation under
Article 4 in my judgment.

**_Ground 2: Failure to make reasonable grounds decision in 2017 within a reasonable time_**

85. The Claimant contends that the Defendant ought to have appreciated by no later than 2nd May 2017
that the Claimant's status as a PVOT needed investigating. The Claimant gave an account in interview at
HMP Birmingham which was consistent with having been trafficked/re-trafficked and the Claimant says that
a referral to the NRM ought to have been made at that point.

86. The Claimant points to the Front Line Staff Guidance which makes clear that frontline staff in the
Home Office must refer people they identify as a PVOT to the NRM. No explanation has been provided for
why a referral was not made although the risk indicators suggesting the Claimant was a PVOT were
obvious and reflected those identified in the Defendant's Guidance.  Had a referral to the NRM been made
in respect of the Claimant on or shortly after 2nd May 2017, the likelihood is that a positive reasonable
grounds decision would have (or should have) been made before expiry of the Claimant's term of
imprisonment.

87. Mr. Hansen submits that the pleaded claim challenges only the delay following the referral on 8th June
2017 and not the delay in referring and he resists any attempt to enlarge the claim. I do not read the
pleaded case so narrowly. The Claimant makes a general averment that the Defendant has failed and
continues to fail to identify the Claimant as a PVOT (§58) (i.e. come to a reasonable grounds decision) and
pleads in terms that _“the Defendant has unlawfully detained the Claimant as a victim of trafficking in_
_circumstances where the Defendant knew or ought to have identified the Claimant as such prior to the date_
_on which he entered into immigration detention” (§68). That is sufficient to embrace a complaint_
concerning the delay in referring for which there has been no explanation.

88. I am satisfied that consistent with the Defendant's Guidance, a referral to the NRM should have been
made on or shortly after 2nd May 2017 and the Defendant acted in breach of her stated policy and
unlawfully in failing so to do. Instead, the referral was not made at all until on or around 8 June 2017, over
5 weeks later, by which time the Claimant was already in immigration detention.

89. Thereafter there was, I find, considerable delay in processing the Claimant's trafficking claim. It was
not until 29th June that the Defendant decided that the trafficking claim was a “duplicate” – that is, 3 weeks
after the already delayed referral, against a target time of 5 days. Mr. Hansen says that there was genuine
confusion as to whether the claim was a new claim or a re-statement of the old and the information
provided during the asylum-screening interview was scanty. It was only when the Claimant's solicitors
wrote to the Defendant on 30th June that the Defendant understood there to have been an allegation of retrafficking and time should be treated as starting on 3rd July (when the Claimant's case was referred to the
NRM). This does not explain why it took three weeks to decide that the claim was a duplicate. Further,
when the Defendant recognised the claim as one of re-trafficking it still took over 9 weeks for a reasonable
grounds decision to be made (on 8th September), notwithstanding that the Claimant was in detention.

90. I accept, as Mr. Hansen submits, that the expectation that a reasonable grounds decision will be made
within 5 days working days does not give rise to a hard-edged rule (R (XYL v Secretary of State for the
_Home Department [2017] EWHC 773 (Admin)). Nevertheless, where there has been significant delay, as_
there was in the Claimant's case, it is incumbent upon the Defendant to provide some good explanation for
it. Otherwise there will be a breach of the Defendant's policy on the making of such decisions. No
explanation for the considerable delay has been provided: there is a dearth of evidence pointing to any
reason for the delay. Resources (though not relied upon by the Defendant) and complexity have been
adverted to at times but with no detail or particulars provided. The letter of 27th July does not evince any
great complexity.

91. For these reasons, I have concluded that the failure to refer the Claimant to the NRM on or shortly
after 2nd May 2017 when a referral was not, but ought to have been, made and the Defendant's largely
unexplained failure to expeditiously investigate the Claimant's status for the purposes of coming to a


-----

(Admin)

reasonable grounds decision when a referral was ultimately made on 8th June and then on 3rd July, was in
breach of the Defendant's policies and unlawful. There is no breach of Article 4 by reason only of the
failures to investigate for the reasons that I have given above (H).

92. Mr. Hansen contends that this Ground is now academic since the reasonable grounds decision has
been made. I deal with this when I deal with Ground 3 and the legality of the Claimant's detention.

**_Ground 3: Unlawful detention_**

93. The Claimant relies on a number of matters in support of his claim that the whole period of his
immigration detention, or alternatively periods of it, were unlawful having regard to the Defendant's policies.
I take those matters in turn below (I do not necessarily address them in the order argued but in a way
which most conveniently addresses the argument and where possible, the chronology).

94. In short, the Defendant denies the breaches of policy but also contends that even if there were
breaches which bore upon the decision to detain, only nominal damages should be awarded since, the
Defendant says, the Claimant could and would have been detained in any event. Ms. Hooper's starting
point is that the Claimant would not have been detained if the Defendant's policies had been properly
followed and she argues that the Claimant should be awarded full compensatory damages.

95. Ms. Hooper also contends that the Claimant should be awarded full compensatory damages even if
the Claimant would have been detained in any event since the breaches were so numerous and so
egregious that the claim warrants an award of substantial damages. I can deal with this point at the outset.
I do not accept Ms. Hooper's submissions. As the Supreme Court in Kambadzi and Lumba make clear, if
the Claimant would inevitably have been detained had the power to detain been lawfully exercised, then he
is entitled to no more than nominal damages (see, too _R (VC) v Secretary of State for the Home_
_Department [2018] EWCA Civ 57, §§38-50, 57 to that effect). However, as I will come to, this does not help_
the Defendant because I cannot be satisfied on the evidence in this case that the Claimant would have
been detained had the breaches of policy not occurred.

**_(i) Deportation decision_**

96. Firstly, the Claimant claims that he was unlawfully detained because no proper consideration was
given to the question whether he should be deported. The Claimant says that in exercising her discretion to
deport, the Defendant only took account of the “Bournemouth Commitment” and failed to take account of
any other matters.

97. The Defendant's Enforcement Instructions clearly state that non-EEA nationals will normally be
considered for deportation where they have received a custodial sentence for a serious drug offence
(including that for which the Claimant was convicted). There is nothing on the face of the Defendant's
decision to deport, therefore, that is inconsistent with the way in which the Defendant has said she will
exercise her discretion. I have no role, of course, in second-guessing the correctness of the outcome of
the criminal justice process. In light of the Claimant's conviction, the Defendant did not act, then, in breach
of her policy in deciding to deport the Claimant.

98. The Claimant's claim under this head is of unlawful detention. The Defendant had the power to detain
as indeed the Claimant acknowledges. The Claimant's real complaint is that had the Defendant previously
done what she should have done and suspended the conclusive grounds decision in 2016 or, at the latest,
made a referral to the NRM on 2nd May 2017, the Claimant's status as a PVOT would have been weighed
in the balance in coming to a decision on whether to detain. It seems to me that the substance of this
aspect of the claim is dealt with by the findings and conclusions under Ground 1 and under Ground 3 (ii).

**_(ii) Reasonable grounds_**

99. Secondly, the Claimant contends that the failure to come to a reasonable grounds decision promptly in
2017 in accordance with the Defendant's Guidance rendered his detention unlawful1 (I will come back to


-----

(Admin)

the impact of the decision not to suspend the inquiries into the Claimant's status in 2016 later on under this
head).

100. It is argued that because the Defendant's Guidance makes clear that ordinarily a reasonable grounds
decision will result in the release of a PVOT from detention (and this amounts to a statement of policy that
bears on the legality of detention: Lumba and Kambadzi), unjustified delay in making that decision renders
continued detention unlawful. I accept that as a general proposition. However, the added feature in the
Claimant's case is that even when a positive reasonable grounds decision was made the Claimant was not
released from detention because, the Defendant says, there were overriding public order grounds justifying
his continued detention. The Defendant argues, therefore, that even if there was undue delay resulting in
an unlawful detention, only nominal damages should be awarded because the detention would have
continued in any event.

101. Ms. Hooper emphatically points out, and indeed as Mr. Hansen accepts, that the starting point in all
cases is that person should be granted immigration bail unless the circumstances require detention. As she
points out, even in criminal deportation cases there is a presumption of bail with restrictions in cases where
a person is assessed as low or medium risk of re-offending and of harm to the public. Notwithstanding that
the Claimant's offence might be classed as “serious” under Chapter 55 (and indeed the _Bournemouth_
_Guidelines indicating its seriousness), the Claimant had in fact been assessed as of “medium” (not “high”)_
risk of harm to the public (this may reflect the sentencing remarks indicating low culpability which the
Defendant certainly knew of by no later than 3rd July and quite possibly before then). While the Claimant's
risk of absconding is assessed as “high,” Ms. Hooper points to the absence of any history of absconding or
poor behaviour in prison or in the IRC and the judge's sentencing remarks indicating low culpability on the
part of the Claimant. She therefore contends that even without a reasonable grounds decision, the
Claimant ought not to have been detained and this would be a fortiori if a reasonable grounds decision had
been made in which case the threshold for detention would be set higher.

102. I have already concluded that there was delay in coming to reasonable grounds decision in 2017. I
am also satisfied that that delay rendered the Claimant's continued detention unlawful. The starting point is
that, in my judgment, had the Defendant acted appropriately and in accordance with her policies by making
an NRM referral on 2nd May 2017 or shortly afterwards, the reasonable grounds decision would have been
taken sometime around, or shortly after, 9th May 2017 (5 working days later). Even if one starts the clock
running from the date on which the referral was actually made, on 8th June, a decision should have been
expected by around 15th June 2017.

103. At either of those points, the presumption would be that the Claimant would be released from
detention. The Defendant's policy on release is expressed in clear terms in the CA Guidance: if a positive
reasonable grounds decision is made a PVOT will be “temporarily released” from detention unless in the
particular circumstances, their detention can be justified on grounds of public order. Before me, in oral
argument, the Defendant contended that there were plainly public order grounds present in the Claimant's
case given that he was at high risk of absconding and he posed a medium risk of reoffending and of
causing harm to the public. The Defendant pointed out that the Claimant was involved in drugs offences to
which the _Bournemouth Guidelines applied, he had arrived clandestinely, he had no known medical_
conditions, he was the subject of a deportation decision, he claimed asylum only when the stage 1 notice
was served.

104. The fact of the Claimant's criminality was, of course, very important in assessing risk but the risk was
assessed as “medium” for reoffending/harm to the public (not “high”). If that was all, this would ordinarily
have resulted in release even if a positive reasonable grounds decision had not been made. However, Mr.
Hansen pointed to the high risk of absconding indicated by the Defendant's policies and by the Claimant's
circumstances. While the Claimant had not breached reporting restrictions, he had disappeared when
released from police custody and he had entered the UK clandestinely and had been engaged in
criminality all pointing strongly against an incentive to stay in touch with the authorities. But the difficulty for
the Defendant is that these points all ignore the matters which the Claimant, largely through his solicitors,
had drawn to the Defendant's attention as indicative of him having been trafficked into the UK and re


-----

(Admin)

trafficked (and which no doubt founded the reasonable grounds decision in 2017 when it was eventually
made).

105. Mr. Hansen says that in any event this is all relevant background to the evidence given by Ms.
Dhillon. Ms. Dhillon says in her witness statement that on 18th July the assigned case worker
recommended the release of the Claimant due to his outstanding PVOT and asylum claims and that he
therefore considered that there was no realistic prospect of removal within a reasonable period. However,
this recommendation was not accepted. Instead, Ms. Dhillon says that the Assistant Director and Senior
Executive Officer discussed the case and while they were aware that there were a number of barriers to
removal (the PVOT and asylum claims), _“the consideration hinged on his previous negative immigration_
_history, risk of reoffending and harm and timescales to conclude the barriers”. There is no record of this_
discussion. The minute of the detention review of 21st July 2017 record comments by the Assistant
Director as follows (verbatim): “[CP] appears to be lodging all claims in an attempt to thwart removal, he
_has already had a previous PVoT claim refused, why are we accepting a new claim, can you please check_
_whether this should be rejected outright. He has also lodged an asylum claim and this is with DAC. A_
_decision will be made swiftly on this and if he is given an in country ROA this can be placed in DIA. Please_
_start the EDT process and get this ready for inclusion in Op Impavid. At present I will agree to maintain_
_detention, however if there are any delays with clearing barriers we will have to look a potential release_
_under contact management. The presumption of liberty is outweighed by risk of absconding and detention_
_should therefore be maintained for a further 28 days”. As can be seen, the Assistant Director's comments_
authorising detention contain no reference to the risk of reoffending or of harm to the public or indeed to
_“public order”. The principal concern was the risk of absconding._

106. As the Defendant accepts, there is no contemporaneous reference of a risk to “public order” posed by
the Claimant's release. However, the Defendant argues that _R (EA) v Secretary of State for the Home_
_Department [2016] EWHC 1165 (Admin) supports the proposition that the sorts of factors present in the_
Claimant's case are those that might found “public order” concerns.  The Defendant says that it was not
necessary to explicitly refer to _“public order” prior to the reasonable grounds decision because the_
requirement for public order grounds only arose then (as was the case too in EA). While this may be so,
whether the absence of a reference to “public order” and/or the presence of certain factors are relevant to
the reaching of a rational conclusion that _“public order”_ considerations outweigh the presumption of
release, will depend upon the facts in a particular case. Plainly the requirement for a “public order” ground
is intended to set a higher threshold than would ordinarily be applicable because otherwise it would not be
a necessary condition. In _EA, there was evidence of repeated incidence of violence. No doubt for that_
reason he had been determined to pose a “serious” risk of harm to the public for a period of time (albeit
that was downgraded to medium). I do not seek to understate the seriousness of the drugs offence of
which the Claimant was convicted but it was qualitatively different. In addition, from 3rd July at the latest
the Defendant knew from the Judge's sentencing remarks that the Claimant's culpability was relatively low.
The Claimant in _EA had also failed to comply with reporting conditions and had used deception when_
arrested: there was evidence therefore pointing to an actual risk of absconding. As the Claimant's counsel
accepted in EA, the Claimant had a poor history of compliance with reporting and other conditions. That is
not the case with the Claimant.

107. As I have mentioned above, following the hearing of this claim, the Defendant alerted me to the
decision in EM v Secretary of State for the Home Department _[[2016] EWHC 1000 (Admin) on what is](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JRG-H3S1-F0JY-C34N-00000-00&context=1519360)_
meant by the expression _“public order” in the context in which it is used in the CA Guidance. The_
Defendant relies on EM for the purposes of establishing that a risk of absconding may itself be sufficient to
meet the _“public order” threshold. In_ _EM, the claimant had a truly appalling immigration history. It is not_
necessary to set it out in full, save to say that it was wholly distinguishable from the facts in this case: As
Haddon -Cave J observed in EM “this is not simply a claimant who has disappeared for a short period and

_re‑appeared. This is an exceptionally resourceful claimant who, having tried to exploit every legal avenue_

_to remain, has absconded and made a living for a very lengthy period”_ (para. 20). Haddon – Cave J
described the claimant's immigration history as _“fairly remarkable”_ (para. 13). _EM_ disappeared for some


-----

(Admin)

five years at one stage following release from immigration detention where she had been held following the
commission of an offence that had resulted in 12 months imprisonment. She was subsequently
apprehended and detained. She was adjudged as at _“high risk of absconding”_ and a _“medium risk of_
_offending”_ (as with the Claimant in this case). At some point thereafter a _“reasonable grounds” decision_
was made and it was contended on her behalf in judicial review proceedings that followed that she should
be released from detention since the Defendant's policies were such that she could only be detained if
detention could be justified on _“public order”_ grounds. As to what was meant by _“public order”_ for these
purposes, Haddon-Cave J cited Burnett J (as he was then) in _EO, RA, CE, OE and RAN v Secretary of_
_State for the Home Department [2013] EWHC 1236 where he observed in this context that: “A very high_
_rather than routine risk that a detainee will abscond might well also provide a proper basis for maintaining_
_detention” (para. 69). The Secretary of State in EM argued that since EM had been assessed as at high_
risk of absconding, there was a sufficient basis to detain on “public order” grounds.  According to HaddonCave J, “[t]he term “order” is a general one which is, in my judgment, intended to embrace potentially all
_aspects of public order including the integrity of travel documents and the ability of the authorities to track_
_and trace individuals who are within the United Kingdom illegally or intending to evade detention and_
_deportation” (para. 17). However, whether a person is at a high risk of absconding and whether that risk is_
sufficient to meet the “public order” must be a matter of fact in any case. As Burnett J held, a “very high
_risk”_ might meet the threshold and _EM_ was on the facts known, self-evidently a _“very high risk”.  For_
reasons I have already given, the same cannot be said of the Claimant in this case. As with EA, the facts
in EM are very different from those that were known of in his case.

108. I cannot be satisfied, notwithstanding the Defendant's submission, that the Claimant would have been
detained in any event following a reasonable grounds decision. The Claimant had been assessed as
medium risk of reoffending and as of medium risk of causing harm to the public. Even with a score of “high”
for risk of absconding, the CA Guidance indicates that the Claimant ought to have been released (with or
without bail) in the absence of public order grounds justifying detention. Further, as to Mr. Hansen's
submission that it was not necessary for the Defendant to consider public order until a reasonable grounds
decision had been reached, this simply highlights the Defendant's difficulty in defending this aspect of the
Claimant's claim: if the Defendant had made a reasonable grounds decision promptly, she would then have
been required to consider whether there were any public order grounds justifying detention. It is for the
Defendant to establish that the Claimant would have been detained anyway if she wishes to avoid an
award of compensatory damages and any lack of contemporaneous evidence pointing to a concern about
_“public order” is simply attributable to her own culpable delay. Further, as I have indicated, on the_
evidence before me, in my judgment the “public order” threshold was not met in the Claimant's case.

109. It follows from what I have said above that if the conclusive grounds decision had not been made on
28th September 2016 but instead the investigation suspended, an extant reasonable grounds decision
would have been in place at the commencement of the Claimant's immigration detention (or at least it is
not suggested otherwise) and, based on the evidence before me, the Claimant would have been released.

110. This means that I find that the whole period of the Claimant's detention was unlawful and he is
entitled to compensatory damages for the period lasting 70 days.

**_(iii) Detention reviews_**

111. Thirdly, the Claimant contends that his detention reviews were inadequate rendering his continued
detention unlawful.

112. The Claimant's first review was due by 23rd June 2017. The minutes of that review repeated the
matters set out in the original authorisation, as I have described above. The justifications for detention were
described in the most general of terms and detail is absent or sparse. They indicate that the reviews did
not “partake of the quality or character required to justify the continuance of detention” (Kambadzi §86, per
Lord Kerr). They evidence an absence of identification, scrutiny and weighing of the factual matters
pointing towards and against the risk of absconding, re-offending and harm to the public that is said to
underpin the decision to detain.


-----

(Admin)

113. In my judgment the reasons given in the minutes are too general in character to meet the
requirements of legality. The fact that the Claimant had committed a serious offence is a weighty matter for
determining risk, and it may indicate a high risk of absconding but these are matters that must be weighed
and assessed in an individual's case. If the Defendant intended that every foreign national criminal guilty of
a serious offence and subject to a deportation order should be detained, then she could have said so in her
Instructions. The Instructions, however, anticipate that even in such cases, there is a presumption of bail
with restrictions. This is in contrast to the minutes which suggest that those facts without more justify
detention. It is not possible to take any comfort from the progress reports because they are incomplete
and at points inconsistent with the detention reviews.

114. Mr. Hansen argues that this aspect of the claim should not succeed because what is really
complained of is not the reviews but the progress reports. Mr. Hansen says that any challenge must be to
the adequacy of the reviews. For these purposes he says that the important documents are the minutes
and it makes no difference whether the progress reports are flawed or indeed inconsistent with the
detention reviews. I accept Mr. Hansen's submission that what matters are the reviews and they might be
lawful even if the progress reports were defective in some way. However, the minutes are inadequate and
the progress reports do not fill any gaps or provide the necessary particulars or weighing and taken
together they show that inadequate thought was given to the justification for detention in the Claimant's
case. Together they demonstrate an absence of careful scrutiny of the facts and matters that might
establish risk justifying detention or, conversely point against it. (Although not argued, it could be said too
that the Claimant was entitled to know the reasons for his detention, and the progress reports failed to
provide the Claimant with the reasons because of their inadequacies).

115. In my judgment, therefore, even if lawful at the outset, the Claimant's detention became unlawful on
23rd June 2017 when an adequate detention review did not take place and his detention remained
unlawful until his release on 3rd August 2017.

**_(iv) Rule 35/Medical evidence_**

116. The Claimant contends that his continued detention after the Rule 35 report disclosed what the
Defendant accepted was evidence of torture was in breach of the Defendant's policy and was thus
unlawful.  Given my findings above, it is not necessary for me to reach a conclusion on this ground but I do
so out of an abundance of caution.

117. The Claimant points to Adults at Risk Guidance and argues that the Rule 35 report met level 2 at
least and indeed the Defendant's response to the Report accepted that it met level 2. In those
circumstances, the Claimant says that under the Adults at Risk Guidance it should have been treated as of
greater weight in assessing the likely risk of harm if detention was to be continued. However, the Report
did not say that continued detention would be harmful to the Claimant and, as Mr. Hansen pointed out, the
opportunity to include this in the report was provided for explicitly in the pro forma document in which the
Report was completed.

118. On the other hand no effort was made to elicit an answer to that question from the doctor who had
prepared the Rule 35 report. Further, by 7th July 2017 a report from Dr. Wootton had been received by the
Defendant. That made clear that the Claimant was suffering from post – traumatic stress disorder and that
in Dr. Wootton's view the Claimant's detention was perpetuating his symptoms. As referred to above Ms.
Dhillon says in her witness statement that that did not materially advance matters and was not considered
to amount to level 3 evidence. It is not clear why. Mr. Hansen argues that the opinion expressed on the
risk of harm of continued detention was not clear and was based on self-reporting: I do not accept that.
The report was clear and while of course it was based on what the Claimant told Dr. Wootton, as a
consultant forensic psychiatrist it can be assumed that she was able to reach a sound professional
judgement on the reliability or relevance of the Claimant's account to her diagnosis. The report is notably
measured.


-----

(Admin)

119. Mr. Hansen also argues that even if it did amount to level 3 evidence there remained sufficiently
strong public protection concerns (coupled with a history of non-compliance) to justify his on-going
detention. The Defendant further says that even if the report of Dr. Wootton should have led to the
Claimant's release, the Defendant was entitled to a reasonable time to consider the report and a
reasonable time would not have expired before 14th July (especially given that the report was received on
a Friday). Further, Mr. Hansen says that the necessary balance was carried out by the Defendant in the
response to the Rule 35 report of 3rd July and that can only be interfered with on Wednesbury grounds.
However, that does not address the question whether Dr. Wootton's report changed the position and the
Defendant has not explained why it did not. It was Level 3 evidence under the Defendant's Guidance. The
suggestion by Ms. Dhillon that there were inconsistencies in the accounts given by the Claimant meant that
Dr. Wootton's assessment might in turn be unreliable is bemusing. Dr. Wootton had the relevant accounts
given by the Claimant and she interviewed the Claimant herself. There is nothing to indicate that she would
not have been able to reach a safe opinion on the Claimant's vulnerability with all the evidence that she
had (including any evidence of relevant inconsistencies) given her expertise. I do not accept the
Defendant's explanation for failing to treat Dr. Wootton's evidence as Level 3 evidence. The effect of not
doing so is that the Defendant did not undertake the correct weighing exercise contrary to her own policy
as contained within the Guidance. That, in my judgment, bore on the legality of the detention and
constituted a public law error. I am not satisfied that had that exercise been undertaken the Claimant
would have been detained nonetheless. This is because considerable weight would have been given to the
evidence of risk if the Guidance had been followed and I am not satisfied in the absence of any
contemporaneous evidence of the results of a lawful weighing exercise that detention would have been
continued nonetheless.

120. I therefore conclude that detention following the Report of Dr. Wootton would have been unlawful
even if the Grounds above had failed. Allowing (generously) 14 days for the Defendant to consider the
Report, I conclude that the detention from 14th July would have been unlawful in any event.

**_Ground 4: Unlawful inclusion in the Detained Asylum Casework (DAC) System_**

121. By the time of this hearing, the Claimant had been removed from the DAC system and accordingly
this aspect of his claim is academic.

122. As to the orders that will follow from this judgment, if they cannot be agreed, the parties should
provide written submissions in accordance with an agreed timetable. If a timetable cannot be agreed, I will
direct one at the time of the handing down of this judgment.

**End of Document**


-----

