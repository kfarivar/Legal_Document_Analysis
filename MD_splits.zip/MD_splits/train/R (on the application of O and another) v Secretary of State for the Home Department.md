(Admin)

# R (on the application of O and another) v Secretary of State for the Home
 Department [2019] EWHC 148 (Admin)

Queen's Bench Division, Administrative Court (London)

Garnham J

31 January 2019Judgment

**Natalie Lieven QC, Shu Shin Luh and Gemma Loughran (instructed by** **Deighton Pierce Glynn**
**Solicitors) for the Claimants**

**Lisa Giovannetti QC, Gwion Lewis (instructed by Government Legal Department) for the Defendant**

JUDGMENT: APPROVED BY THE COURT FOR HANDING DOWN (SUBJECT TO EDITORIAL CORRECTIONS)

GARNHAM J:

Introduction

1. The principal issue raised by this case is as follows: have delays by the Home Office in the process of making
“Conclusive Grounds” decisions in respect of potential victims of human trafficking become so significant and so
widespread as to be unlawful?

2. “Conclusive Grounds” decisions are made by “Competent Authorities” under an arrangement established by the
Secretary of State for the Home Department (“the Secretary of State”), for the purpose of identifying victims of
trafficking and modern slavery, an arrangement called “The National Referral Mechanism” (“NRM”). There are two
competent authorities, the UK Human Trafficking Centre, operated by the National Crime Agency, and the Home
Office. This claim relates only to the systems operated by the Home Office

3. There was a delay of 34 months between the date when Ms O, the First Claimant, received what is called a
positive “Reasonable Grounds” decision, in August 2015, and the date in June 2018 when she received a negative
Conclusive Grounds decision. There was a delay of more than 19 months between the positive Reasonable
Grounds decision and the negative Conclusive Grounds decision in the case of Ms H, the Second Claimant. A third
claimant, P waited 19 months between the two decisions. She thereafter discontinued her claim.

4. The two Claimants allege unlawful delay in their own cases. But they also allege that their cases are illustrative of
a much wider and more profound deficiency in the NRM arrangements operated by the Home Office. They point to
what they describe as sustained criticism of the arrangements contained in reports by Mr Jeremy Oppenheim for
the Home Office in 2014 and by the National Audit Office in 2017, and in witness statements from a number of
solicitors with experience of representing potential victims of trafficking.

5. The Secretary of State resists this claim. He argues that there is no duty to make a Conclusive Grounds decision
within a particular period. He says that whilst particular individuals have been waiting regrettably long periods for a
Conclusive Grounds decision to be made in their case, the evidence does not support the claim that “delays are
systematically egregious”. He disputes the suggestion that the delays in the two Claimants' cases were
unreasonably long and points out that ultimately conclusive grounds were not established in their cases.


-----

(Admin)

6. Before considering the criticisms advanced by the Claimants, it is necessary to identify first the relevant
international instruments, second the domestic policies and guidance, third the relevant parts of the Claimants' own
history and fourth the history and reviews of the NRM.

The International Instruments

7. There are three relevant international instruments.

8. First, the Council of Europe Convention on Action against Trafficking in Human Beings (or “ECAT”), which came
into force in February 2008. The relevant articles are as follows:

**“Article 1 - The purposes of this Convention**

1. The purposes of this Convention (include) “(b) to protect the human rights of the victims of trafficking…

**Article 10 – Identification of the victims**

1 Each Party shall provide its competent authorities with persons who are trained and qualified in
preventing and combating trafficking in human beings, in identifying and helping victims, including children,
and shall ensure that the different authorities collaborate with each other as well as with relevant support
organisations, so that victims can be identified in a procedure duly taking into account the special situation
of women and child victims and, in appropriate cases, issued with residence permits under the conditions
provided for in Article 14 of the present Convention.

2 Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in Article 18 of this Convention has been completed by the
competent authorities and shall likewise ensure that that person receives the assistance provided for in
Article 12, paragraphs 1 and 2.

**Article 12 – Assistance to victims**

1 Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:

(a) standards of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

(b) access to emergency medical treatment;

(c) translation and interpretation services, when appropriate;

(d) counselling and information, in particular as regards their legal rights and the services available to
them, in a language that they can understand;

(e) assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

(f) access to education for children…

7 For the implementation of the provisions set out in this article, each Party shall ensure that services are
provided on a consensual and informed basis, taking due account of the special needs of persons in a
vulnerable position and the rights of children in terms of accommodation, education and appropriate health
care.

**Article 13 – Recovery and reflection period**

1 Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be


-----

(Admin)

sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the competent authorities. During this period it shall not be possible
to enforce any expulsion order against him or her…

2 During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures
contained in Article 12, paragraphs 1 and 2…

**Article 14 – Residence permit**

1 Each Party shall issue a renewable residence permit to victims, in one or other of the two following
situations or in both:

(a) the competent authority considers that their stay is necessary owing to their personal situation;

(b) the competent authority considers that their stay is necessary for the purpose of their cooperation with
the competent authorities in investigation or criminal proceedings…

**Article 15 – Compensation and legal redress**

1 Each Party shall ensure that victims have access, as from their first contact with the competent
authorities, to information on relevant judicial and administrative proceedings in a language which they can
understand.

2 Each Party shall provide, in its internal law, for the right to legal assistance and to free legal aid for
victims under the conditions provided by its internal law.

3 Each Party shall provide, in its internal law, for the right of victims to compensation from the perpetrators.

4 Each Party shall adopt such legislative or other measures as may be necessary to guarantee
compensation for victims in accordance with the conditions under its internal law, for instance through the
establishment of a fund for victim compensation or measures or programmes aimed at social assistance
and social integration of victims, which could be funded by the assets resulting from the application of
measures provided in Article 23.

**Article 16 – Repatriation and return of victims**

1 The Party of which a victim is a national or in which that person had the right of permanent residence at
the time of entry into the territory of the receiving Party shall, with due regard for his or her rights, safety
and dignity, facilitate and accept, his or her return without undue or unreasonable delay.

2 When a Party returns a victim to another State, such return shall be with due regard for the rights, safety
and dignity of that person and for the status of any legal proceedings related to the fact that the person is a
victim, and shall preferably be voluntary…

**Article 18 – Criminalisation of trafficking in human beings**

Each Party shall adopt such legislative and other measures as may be necessary to establish as criminal
offences the conduct contained in article 4 of this Convention, when committed intentionally…

**Article 26 – Non-punishment provision**

Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
been compelled to do so.”

9. Second, the 2011 EU Anti-Trafficking Directive (2011/36/EU), the recitals to which include the following:

“(7) This Directive adopts an integrated, holistic, and human rights approach to the fight against trafficking
in human beings and when implementing it, Council Directive 2004/81/EC of 29 April 2004 on the
residence permit issued to third-country nationals who are victims of trafficking in human beings or who
have been the subject of an action to facilitate illegal immigration, who cooperate with the competent
authorities and Directive 2009/52/EC of the European Parliament and of the Council of 18 June 2009


-----

(Admin)

providing for minimum standards on sanctions and measures against employers of illegally staying thirdcountry nationals should be taken into consideration. More rigorous prevention, prosecution and protection
of victims' rights, are major objectives of this Directive. This Directive also adopts contextual
understandings of the different forms of trafficking and aims at ensuring that each form is tackled by means
of the most efficient measures…

18) It is necessary for victims of trafficking in human beings to be able to exercise their rights effectively.
Therefore assistance and support should be available to them before, during and for an appropriate time
after criminal proceedings. Member States should provide for resources to support victim assistance,
support and protection. The assistance and support provided should include at least a minimum set of
measures that are necessary to enable the victim to recover and escape from their traffickers. The practical
implementation of such measures should, on the basis of an individual assessment carried out in
accordance with national procedures, take into account the circumstances, cultural context and needs of
the person concerned. A person should be provided with assistance and support as soon as there is a
reasonable-grounds indication for believing that he or she might have been trafficked and irrespective of
his or her willingness to act as a witness. In cases where the victim does not reside lawfully in the Member
State concerned, assistance and support should be provided unconditionally at least during the reflection
period. If, after completion of the identification process or expiry of the reflection period, the victim is not
considered eligible for a residence permit or does not otherwise have lawful residence in that Member
State, or if the victim has left the territory of that Member State, the Member State concerned is not obliged
to continue providing assistance and support to that person on the basis of this Directive. Where
necessary, assistance and support should continue for an appropriate period after the criminal proceedings
have ended, for example if medical treatment is ongoing due to the severe physical or psychological
consequences of the crime, or if the victim's safety is at risk due to the victim' s statements in those
criminal proceedings…

(23) Particular attention should be paid to unaccompanied child victims of trafficking in human beings, as
they need specific assistance and support due to their situation of particular vulnerability. From the moment
an unaccompanied child victim of trafficking in human beings is identified and until a durable solution is
found, Member States should apply reception measures appropriate to the needs of the child and should
ensure that relevant procedural safeguards apply. The necessary measures should be taken to ensure
that, where appropriate, a guardian and/or a representative are appointed in order to safeguard the minor's
best interests. A decision on the future of each unaccompanied child victim should be taken within the
shortest possible period of time with a view to finding durable solutions based on an individual assessment
of the best interests of the child, which should be a primary consideration. A durable solution could be
return and reintegration into the country of origin or the country of return, integration into the host society,
granting of international protection status or granting of other status in accordance with national law of the
Member States.”

10. The following articles of the Directive are said to be material:

“Article 8

**Non-prosecution or non-application of penalties to the victim**

Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties
on victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence…

Article 11

**Assistance and support for victims of trafficking in human beings**

1. Member States shall take the necessary measures to ensure that assistance and support are provided
to victims before, during and for an appropriate period of time after the conclusion of criminal proceedings


-----

(Admin)

in order to enable them to exercise the rights set out in Framework Decision 2001/220/JHA, and in this
Directive.

2. Member States shall take the necessary measures to ensure that a person is provided with assistance
and support as soon as the competent authorities have a reasonable-grounds indication for believing that
the person might have been subjected to any of the offences referred to in Articles 2 and 3…

4. Member States shall take the necessary measures to establish appropriate mechanisms aimed at the
early identification of, assistance to and support for victims, in cooperation with relevant support
organisations…

Article 16

**Assistance, support and protection for unaccompanied child victims of trafficking in human**
**beings.**

2. Member States shall take the necessary measures with a view to finding a durable solution based on an
individual assessment of the best interests of the child.”

11. Third, the 2000 Charter of Fundamental Rights of the European Union (as amended from the date of entry into
force of the Treaty of Lisbon). The relevant provisions provide as follows:

“Article 5 Prohibition of slavery and forced labour

1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

3. Trafficking in human beings is prohibited…

**Article 52 Scope of guaranteed rights**

1. Any limitation on the exercise of the rights and freedoms recognised by this Charter must be provided for
by law and respect the essence of those rights and freedoms. Subject to the principle of proportionality,
limitations may be made only if they are necessary and genuinely meet objectives of general interest
recognised by the Union or the need to protect the rights and freedoms of others.

2. Rights recognised by this Charter which are based on the Community Treaties or the Treaty on
European Union shall be exercised under the conditions and within the limits defined by those Treaties.

3. In so far as this Charter contains rights which correspond to rights guaranteed by the Convention for the
Protection of Human Rights and Fundamental Freedoms, the meaning and scope of those rights shall be
the same as those laid down by the said Convention. This provision shall not prevent Union law providing
more extensive protection.”

12. Article 5 of the Charter is the equivalent of Article 4 of the European Convention on Human Rights, the
difference being that Article 5(3) makes explicit the protection against human trafficking. (That prohibition was found
to be implicit in Article 4 ECHR in Rantsev v Cyprus v Russia [2010] 51 EHRR 1).

Domestic law and Policy

13. The UK signed the Convention against Trafficking on 23 March 2007 and ratified it on 17 December 2008. It
came into force on 1 April 2009. The obligation to identify and protect potential victims of trafficking (“PVoT”) and
(“VoTs”) was implemented in the UK by the establishment of the National Referral Mechanism and the Home Office
guidance “Victims of Modern Slavery – Competent Authority Guidance”.

14. ECAT has not been incorporated into English domestic law and as a result cannot be relied upon in
proceedings against the Defendant directly. However, insofar as the Secretary of State has adopted parts of ECAT
as his own policy in guidance, the decision of R (G) v SSHD [2016] 1 WLR 4031means that the Secretary of State
must follow that guidance unless there is good reason not to do so.


-----

(Admin)

15. The guidance includes the following: At page 8 it is made clear that the guidance is based on the European
Convention against Trafficking and as part of implementing the Convention, the Government created the NRM in
2009. Page 19 explains that the UK's two designated Competent Authority decision makers under the NRM are the
Human Trafficking Centre (UKHTC) within the National Crime Agency, and the Home Office. The Home Office has
a number of Competent Authorities including UK Visa and Immigration NRM Hub.

16. Page 21 identifies as “First Responders” several designated organisations which can refer potential victims of
**_modern slavery in the UK into the NRM. Those responders include the Home Office, the Police, the Salvation_**
Army and “Unseen UK”. Page 50 of the guidance identifies the '2 Stage National Referral Mechanism' consideration
process.

“Part 1 The first part is the Reasonable Grounds test, which acts as an initial filter to identify potential
victims.

**Part 2**

The second is a substantive Conclusive Grounds decision as to whether the person is in fact a victim…”

17. Page 50 also identifies “Timescales” for making a reasonable grounds decision as follows:

“The expectation is that the Competent Authority will make a reasonable grounds decision within 5 working
days of the NRM referral being received at the UK Human Trafficking Centre (UKHTC) where possible.

Reasonable grounds decisions for cases in immigration detention will be considered as soon as possible”.

18. The guidance continues “the reasonable grounds decision has consequences for the potential victim in terms of
protection and support (and potential further stay in the UK if they are subject to immigration control)”.

19. Page 64 deals with making Conclusive Grounds decisions as follows:

“When a Competent Authority makes a positive reasonable grounds decision, at the end of the recovery
and reflection period they then have to conclusively decide whether the individual is a victim of human
trafficking (Scotland and Northern Ireland) or modern slavery (England and Wales).

The Competent Authority is responsible for making a conclusive decision on whether, 'on the balance of
probabilities' there are sufficient grounds to decide that the individual being considered is a victim of human
trafficking or modern slavery. We refer to this as the Conclusive Grounds decision.”

20. The timescale for Conclusive Grounds decisions is described as follows:

“The expectation is that a conclusive grounds decision will be made as soon as possible following day 45
of the recovery and reflection period. There is no target to make a conclusive grounds decision within 45
days. The timescale for making a conclusive grounds decision will be based on all the circumstances of the
case” (emphasis added).

21. The guidance addresses the need for evidence gathering:

“Competent Authority staff may need to gather more information to make a conclusive grounds decision.

The Competent Authority must make every effort to secure all available information that could prove useful
in establishing if there are conclusive grounds.

If they cannot make a conclusive grounds decision based on the evidence available, they must gather
evidence or make further enquiries during the 45 day recovery and reflection period.”

22. Page 80 deals with monitoring case progress during the 45 day recovery and reflection period. It provides:

“To make sure the potential victim has sufficient time for recovery and reflection and that a conclusive
grounds decision can be made as near as possible to day 45 (although that may not be possible in every
case), you must set a review date for day 30 to:


-----

(Admin)

    - Monitor progress on the case

     - Check it is on target for a conclusive decision…

A potential victim's specific circumstances could mean they need more than 45 days to recover and reflect.
If representations are made for more time, you must consider whether an extension is appropriate…”

23. Although not directly relevant to the present case, it is also to be noted that the Modern Slavery Act became
law from 26 March 2015 and the majority of provisions in that Act have now been brought into force.

The Claimants' History

_Ms O_

24. Ms O who was born in February 1983, arrived in the UK on 3 April 2010 with a Mr O, a man who Ms O's parents
were pressurising her to marry in exchange for financial support for their family. Ms O says she was abandoned by
Mr O on arrival. She was approached by a woman calling herself Mrs Lawrence who offered accommodation and
help, but instead forced her to carry out domestic work for the Lawrence family without pay. She alleges she was
beaten, threatened, locked in the house, had her passport withheld and was subject the sexual advances by Mr
Lawrence.

25. Later in 2010, she says she escaped the Lawrence family and slept rough for a period during which she was
raped and made the victim of theft. She then met a Mr A who offered to help. He brought her to Bristol and in
August 2012 they married. In June 2013, Ms O gave birth to a son.

26. In January 2014, Mr A claimed asylum. He was detained for 10 months during which period Ms O and her son
were supported by social services. In August 2014, Ms O claimed asylum. That was refused in September 2014
and her claim was certified as clearly unfounded. In March 2015, the Home Office provided asylum support for the
family.

27. An NRM referral was made to the Home Office by the Salvation Army. In July 2015, Ms O started receiving
support from an anti-trafficking charity known as “Unseen” who had been contacted through the Salvation Army to
provide support. On 4 April 2015, Ms O received a positive Reasonable Grounds decision from the NRM.

28. In August 2015, Ms O gave birth to a son. Thereafter, a number of representations were made by a number of
different organisations, including Unseen, and an organisation called Migrant Legal Project (MLP), on Ms O's behalf
to the Competent Authority. On 10 November 2015, an interview was conducted for the purposes of a trafficking
identification process. Further clarification and representations were provided by MLP to the Competent Authority
and the First Claimant underwent counselling both with an organisation called “Womankind” and an organisation
called “Kinergy”. Further representations were made on Ms O's behalf during 2016.

29. In August 2016, Ms O was diagnosed by her GP with anxiety and depression. Subsequently she was assessed
by her GP. She was also referred to Somerset and Avon Rape and Sexual Abuse Support. Her GP reported that
she had been referred for psychological treatment and for counselling and cognitive behavioural therapy. Further
representations were made by MLP to the Competent Authority on the First Claimant's behalf during 2017.

30. In September 2017, Ms O gave birth to a daughter. In October 2017, she was seen by perinatal health services
in respect of various mental health difficulties. In November 2017 her GP reported on her continuing mental health
condition. Yet further representations were made to the Competent Authority by MLP and Unseen. At the end of
2017, the Competent Authority acknowledged MLP's representations and requested a passport photograph of Ms O
and her children. That was provided some two months later.

31. On 9 March 2018, a letter before claim was served on the NRM. Correspondence between the parties followed.
On 6 June 2018, the NRM issued the negative Conclusive Grounds decision and on 8 June 2018 the claim was
issued.


-----

(Admin)

Ms H

32. Ms H first came to the UK on 28 April 2016, then aged 15. She reported she had been beaten and disowned by
her family after they discovered that she had lost her virginity. She explains she had been forced to work as a
prostitute prior to obtaining a visa for the UK.

33. She was referred to the NRM some six months after arriving in the UK and an initial contact interview shortly
thereafter. One week later, Ms H received a positive Reasonable Grounds decision. Later that month her initial
health assessment was conducted which identified a wide range of physical and mental problems. On 9 November
2016, a substantive trafficking and asylum interview was conducted. A request of support for Ms H was refused. On
24 November 2016, Ms H attempted suicide by taking an overdose of medication. She was taken to A&E and
subsequently a report on her condition was prepared by the Cardiff Health Practice. A wide range of symptoms
relating to her physical, mental and emotional health were reported.

34. On 14 December 2016, the substantive trafficking and asylum interview was conducted. Two days later, Home
Office case records note that a “level 3 safeguarding flag” was registered on the Claimant's papers.

35. In June 2016, the charity Barnardo's began work with Ms H. In August 2017, Gloucester City Health Centre
provided details of the Second Claimant's condition. On 29 September 2017, Ms H gave birth to a child. In
December 2017, the case record sheets note concern about proposals to relocate Ms H. Also in December 2017,
there was a letter from an organisation called Let's Talk”, indicating the second Claimant suffered moderately
severe symptoms of depression and severe symptoms of anxiety.

36. In January 2018, Barnardo's wrote to the Defendant indicating concern that Ms H's housing situation was
having a detrimental impact on her and she would need cognitive behaviour therapy. A request was made for
relocation to more suitable accommodation. Also, that month, there are records of email correspondence raising
concerns, again, about Ms H's proposed relocation, a step that took place on 22 January 2018 when Ms H was
moved to Bristol.

37. That same month, Unseen began supporting Ms H and in February 2018 Ms H instructed solicitors. There were
further representations by Unseen in March 2018 and later that month a letter before claim was issued by the
Claimant's then solicitor. Correspondence then followed with continued representations being made on Ms H's
behalf. On 8 June 2018, this claim was issued. On 28 June, the Acknowledgment of Service and Summary
Grounds of Defence was filed. The negative Conclusive Grounds decision followed on 2 July 2018.

The Evidence as to the Operation of the NRM

_The evidence of delay_

38. It is common ground that there have been significant delays in recent years in the processing of cases through
the NRM. In her witness statement, Ms Rachel Devlin, the leading policy officer in the Home Office unit responsible
for the NRM said this:

“The Home Office accepts that exponential increases in the number of referrals to the NRM in recent years
have led to the regrettable delays in some cases.”

39. In a submission to the Secretary of State from the Modern Slavery Unit at the Home Office dated 8 September
2017, it is said that the “NRM is intended to be a dynamic process, providing a bridge to support to enable people to
recover the exploitation they have suffered, begin to move forward and to be robust enough to avoid future
exploitation…” One of the key factors that frustrates in practice is the “substantial delays in decisions, in particular
for non-EEA nationals” which mean they spend “extended periods of time in limbo” in NRM support “with no
indication of when a decision will be received…”


-----

(Admin)

40. In the hearing before me, there was some debate about the relevant statistics as to that delay. On the second
day of the hearing, at my suggestion, an agreed note summarising the effect of the statistical material available was
produced. Of particular interest for present purposes are the following five points:

41. First, it is plain that the total number of referrals has risen every year from 2013 to 2017. In 2013, the total
number of referrals was 1745, in 2015, 3266 and in 2017, 5145. It appears that the number of referrals has dropped
in 2018; by 1 November the referrals totalled 3539 and the pro-rata projection for the end of the year is 4245.

42. Second, the number of pending decisions has increased steadily. At the end of 2015, the total number pending
was 2151, made up of 19 cases from 2013, 470 from 2014 and 1662 from 2015. At the end of 2017, there were a
total of 5091 cases pending, made up of 11 from 2013, 124 from 2014, 515 from 2015, 1168 from 2016 and 3273
from 2017. As at 1 November 2018, there were 5315 cases pending of which 109 were from 2015, 581 from 2016,
1882 from 2017 and 2743 from 2018.

43. Third, the average time for making a Conclusive Grounds decision has fallen somewhat. In 2015, UK Visas and
Immigration took an average of 378 days from the positive Reasonable Grounds decision to make a Conclusive
Grounds decision. In 2016, the figure was 370 days and in 2017 it was 327 days; (it is to be noted that the averages
do not include cases from previous years).

44. Fourth, those averages need to be examined in a little more depth to identify the length of time individuals were
waiting for a Conclusive Grounds decision. As at 1 November 2018, 1009 individuals had been waiting more than
18 months, 1218 had been waiting 12-18 months, 550 between 9 and 12, 692 from 6-9 months, 93 from 3-6 months
and also 93 for less than 3 months.

45. Finally, the available figures for 2018 show a steady rise in number of Conclusive Grounds decisions made; 78
in January, 100 in March, 126 in May, 108 in July, 329 in September, 421 in November.

_Concern about delay_

46. Concern about the performance of the NRM has been expressed for some years. In November 2014, Jeremy
Oppenheim, a senior civil servant in the Home Office, conducted a detailed review of the operation of the NRM. His
conclusions included the following;

“7.2.1 Stakeholders agree current timescales for the conclusive grounds decisions are a problem.

7.2.2 UK Visas and Immigration is working to bring conclusive grounds decisions within a service standard
of 98% and straight forward decisions within 6 months. In 2013, the UK Human Trafficking Centre…made
a conclusive grounds decision in an average of 56 days….

8.2.1 The governance of the current system is fragmented and lacking in overall performance framework. It
has evolved in to the system of implementation of 2009 and, whilst improved, cannot be described as
efficient or effective.

8.2.2. There is insufficient accountability for the outcomes of the process or the appropriate management
for the process itself…

8.2.9 It is vital that any system is properly managed so that cases are not delayed unduly. The timeliness
of decision making has been discussed at 7.2.2. Clearly any effective process needs tight performance
management with agreed outcomes. We believe that the management of the National Referral Mechanism
should include an escalation process which sees all cases being referred at agreed decision points if the
case has not reached the expected stage.”

47. In December 2017, the National Audit Office published a report on the NRM. That report includes the following:

“2.12 Very few cases reach a conclusive grounds decision within 45 days. Of those referred in 2016-17,
the Government provided a conclusive grounds decision within 45 days to only 6% of the victims who


-----

(Admin)

received a decision. This rises to 33% for a decision within 90 days. Of potential victims referred to the
NRM in 2016, 46% did not receive a conclusive grounds decision by March 2017…

2.13 The NRM process is inefficient and potential victims are caught up in the system waiting for a decision
for a long time. For two thirds of those referred in 2016-17, the Government took longer than 90 days to
make a conclusive grounds decision…”

48. The Claimants adduced witness statements from a number of solicitors experienced in handling victim of
trafficking cases. Their own solicitor, Ugo Hayter of Deighton Pierce Glynn Solicitors produced a table showing the
time taken from the expiry of the 45 day recovery and reflection period to the receipt of the Conclusive Grounds
decision. The figures ranged from two days to 33 months. Evidence from Kirsten Powrie, of Wilson Solicitors LLP,
demonstrated delays of up to 40 months and showed that of the 43 cases she dealt with that had been referred, 28
individuals experienced delays of 12 months or more and 11 experienced delays in excess of 24 months.

49. I was also taken to evidence from Alice de Looy-Hyde of the Migrant Legal Project to similar effect. She also
speaks of her clients receiving no information from the NRM about the progress of their claims and of her attempts
to provide evidence of the sort she says the Home Office ought to be collecting herself. Ms Powrie of Wilson
Solicitors LLP describes similar experiences.

50. The solicitors to whom I have referred also speak of the effect of these delays on their clients. Ms Hayter, for
example, says:

“One of the most significant and detrimental effects of substantial delays experienced by individuals
awaiting conclusive grounds decisions is on victims ability to recover and ”move on” from their experience
of exploitation…as well as impairing recovery, the delay in the decision making process can also
exacerbate clients' mental health conditions. This is the case particularly for individuals suffering from
anxiety disorders and depression. The continual uncertainty about their future can in itself become
debilitating. For asylum claimants, the Defendant's policy of staying negative asylum claims behind CG
decisions means, in practice, that all asylum decision making is deferred pending the CG decision resulting
in extreme delays to the outcome of the individual's asylum claim as well as to the determination of their
trafficking victim status.”

51. The Claimants also rely on expert evidence from Professor Cornelius Katona, the medical director of the Helen
Bamber Foundation, a highly experienced psychiatrist. He says:

“18. Victims of trafficking, like others who have experienced abuse and trauma, experience a profound loss
of their sense of safety and security. People who do not feel safe and secure are often unable to undertake
trauma-focussed work until they reach a degree of symptomatic and situational stabilisation that enables
them to regain that sense of safety and security. Such stabilisation is determined by external factors; for
example being away from a combat situation, having a long-term roof over one's head, having enough
money to meet essential living needs, having a support network to rely on, and (in the immigration context)
recognition as a victim of trafficking and consequent grant of leave to remain.

19. Without that stability it is much more difficult for patients to engage fully in and thereby benefit from
trauma-focussed work. Continuing uncertainty regarding their NRM status impedes their sustained
recovery. By this I mean that they may be able to achieve symptomatic improvement (i.e. the ability to
function superficially on a day-to-day basis) but not sustained improvement in the form of the ability to cope
with further setbacks without mental deterioration, If however they regain a sufficient sense of stability,
safety and security to engage fully in trauma-focused therapy, such therapy can in turn enable to develop
the ability to cope with future setbacks.”

52. He goes on:

“22. Thus the suggestion that as long as victims have access to support, they should be able to recover is
an oversimplification of the complex therapeutic journey experienced by the clients with whom we work.


-----

(Admin)

23. It is also significant that until people are granted leave to remain they often cannot work or resume
study. It is important to see these activities not just as means to improving the survivor's economic position
but as important ways to help survivors of trauma to rebuild their self-worth and self-esteem, which are
important for their ability to integrate properly into society.”

53. I also received evidence as to the effect of delays such as those described by the solicitors. Mirjam Thullesen is
a registered psychotherapist specialising in the assessment and support of survivors of trauma, especially human
trafficking. In her witness statement, she says:

“In my experience the impact on mental health is one of the most significant problems caused by delay in
CG decision making. The simple reason for this is the state of uncertainty in which potential victims remain
while waiting for an outcome from the NRM identification process. The CG decision, as the outcome of the
NRM identification process is a critical juncture for potential victims; it is life changing. A positive CG
decision may entitle a person to a grant of leave to remain in the UK, for example when continued
treatment for physical or mental health conditions require it or if they are assisting police with an
investigation into their traffickers.”

_Response on the issue of delay_

54. Ms Devlin, the Home Office policy officer to whom I have referred, provides a detailed response to this claim in
her witness statement. She explains that Article 10 of ECAT makes clear that the gateway to the provision of
assistance and support for potential victims of trafficking is the Reasonable Grounds decision. She says that the
NRM complies with the victim identification process required by Article 10 and that the expectation is that such a
Reasonable Grounds decision would be taken within 5 working days of the referral to the NRM. She says that once
a positive Reasonable Grounds decision has been made, the individual is entitled to assistance and support as
required by Article 12 of ECAT.

55. That decision also triggers the requirement under Article 13 for a recovery and reflection period during which the
UK is required to authorise the individual to stay in their territory. She says that the UK allows a longer recovery and
reflection period than the minimum 30 days; the UK allows 45 days. She says that the assistance and the support
provided to an individual does not come to an end on the 45th day if a Conclusive Grounds decision is still awaited.
Instead, it will continue until that Conclusive Grounds decision is taken “irrespective of how long it takes”.

56. Ms Devlin points out that the ECAT does not prescribe a timescale for making the Conclusive Grounds decision.
She acknowledges that the guidance refers to the expectation that a Conclusive Grounds decision will be made “as
soon as possible” following Day 45 of the recovery and reflection period. But she says that:

“a positive reasonable grounds decision does not in itself give rise to any further legal right to remain in
immigration terms, or to any further right to assistance and support…Even those who receive a conclusive
grounds decision are required to leave any accommodation provided to them by the Salvation Army within
two weeks of the decision…”

57. Ms Devlin notes that Article 14 of ECAT makes provision for a renewable residence permit where the
Competent Authority considers it necessary owing to their personal situation or necessary for the purpose of cooperation with the Competent Authority's investigation or criminal proceedings. But she observed that a positive
Conclusive Grounds decision does not mean automatically that either of those conditions are met. The guidance
explains that the subject of a Conclusive Grounds decision “may be eligible for a grant of discretionary leave
outside of immigration rules”. A grant of discretionary leave gives individuals the right to work in the UK but
discretionary leave is not required before potential victims of trafficking can access primary and secondary health
care.

58. Ms Devlin also speaks of proposed changes to the NRM following a decision announced by Home Office
ministers in 2017. She says that in December 2017 a new, additional team of decision makers, recruited in the
UKVI division of the Home Office, started work on reducing the number of outstanding Conclusive Grounds
decisions The aim was to reduce the “cohort of cases that had been outstanding since before April 2017 to as


-----

(Admin)

close as possible to zero by December 2018.” She describes other changes to the system including the commission
of a new digital system to manage cases in the NRM.

The Competing Arguments

59. The Claimants advanced six grounds of challenge in their Grounds, but those arguments were substantially
refined and narrowed in Ms Lieven QC's skeleton argument and oral submissions. As the case was advanced
before me there were, in substance, three grounds:

60. First, Ms Lieven acknowledges that the European instruments to which I have referred do not mandate a
specific time period within which the victim identification process must be completed. However, she says that those
instruments cannot be construed as providing an open-ended discretion. Implicit in them is an obligation to
complete the process “within a reasonable period of time”. There is, she says, a “restrained timescale” for the
identification of victims of trafficking.

61. Second, she says that the delays in the NRM process are systemically unlawful. She argues that the “chronic
delays in completing the process and making a conclusive grounds decision” amounts to “a frustration of the rights
of potential victims of trafficking to obtain practical and effective protection”. She says that the delays in the NRM
system breach the “base requirements set out in EU Directive, ECAT, Article 4 ECHR and Article 5 CFR for the
early identification of victims”. She says the delays have a significant destabilising effect on the mental health and
recovery process of potential victims of torture. She contended that the “systemic delays” in the operation of the
NRM demonstrated both irrationality and systemic unfairness in the operation of the arrangements.

62. Third, Ms Lieven contends that there was “individual unlawfulness and unfairness” in the two Claimants' case.

63. In response, Ms Giovannetti QC for the Secretary of State, says there was no duty to make a Conclusive
Grounds decision within a particular time; that the evidence does not support the Claimants' case that delays are
systematically egregious; that any delays are the result of a substantial number of referrals, not because the
Secretary of State is operating an irrational system; that how the Secretary of State manages his administrative
resources is a matter for him and, ultimately, parliament, and not for the courts; that even where individuals have
been waiting excessive periods they still receive assistance and support as potential victims of trafficking, and the
Conclusive Grounds decision is not the “gateway” to support as a victim of trafficking; that whether, and if so how,
the Secretary of State should prioritise certain cases over others is a policy judgement for him, subject to a
rationality test, and there is nothing irrational about the Secretary of State's approach.

64. I record here my gratitude for the clear and economically expressed submissions, both written and oral, by
counsel for both parties

**Discussion**

Ground 1 - A restrained timescale?

65. As noted above, it is common ground that there is no express time limit for the making of a Conclusive Grounds
decision in any of the European or domestic instruments to which I have referred. However, it is perfectly plain that
there is no intention to give the relevant authorities unlimited time to make a final decision. Article 11(4) of the
Directive requires the establishment of “mechanisms aimed at the early identification of…victims”. The UK's
domestic guidance refers to “an expectation” that a Conclusive Grounds decision will be made as soon as possible
following day 45 of the recovery and reflection period, although it is said that there is no target to make a conclusive
grounds decision within 45 days.

66. In my judgment it is impossible to argue that there was no constraint at all on the period of time the competent
authority could spend deciding any individual case. Such a contention, if well-founded, would have the capacity to
negate entirely the obligation assumed by the Secretary of State when adopting the guidance. It does not need
reference to European instruments to make good that conclusion; the ancient writ of mandamus or its modern


-----

(Admin)

equivalent, a mandatory order, can be deployed to compel performance of such an obligation. Prolonged and
inexcusable delay can justify the issue of a mandatory order requiring performance of a duty.

67. And it is equally straight-forward, in my view, to identify the appropriate descriptor for the time limit; decisions
must be taken in a reasonable time. What is reasonable, however, will turn on the nature of the power being
exercised, the effect of exercising, and failing to exercise, the power, and all the circumstances of the case. It was
on the application of those considerations, both in individual cases and in the generality of cases handled by the
competent authority, that the greater part of the argument in this case was focused.

68. In fact, I do not understand Ms Giovannetti to dissent from either of the propositions just set out. Certainly, in the
not dissimilar circumstances of asylum applications, in S v Home Secretary _[2007] EWCA Civ 546 at [51] Carnwath_
LJ (as he then was) said

“The Act does not lay down specific time-limits for the handling of asylum applications. Delay may work in
different ways for different groups: advantageous for some, disadvantageous for others. No doubt it is
implicit in the statute that applications should be dealt with within “a reasonable time”.

69. Similarly, in H v SSHD [2007] EWHC, highly experienced counsel acting for the Secretary of State was content
to concede that there was an implicit obligation on the defendant to decide applications for leave to remain in the
UK within a reasonable time. In R(MK) (Iran) v SSHD [2010] EWCA Civ at [34] the Court of Appeal recorded that it
was not in dispute that, at least under domestic law, the Secretary of State was under a public law duty to decide
asylum applications within a reasonable time.

70. The position is similar under the law of the ECtHR and in EU law. In _Rantsev v Cyprus and Russia (2010)_
EHRR 1, the ECtHR found that a “requirement of promptness and reasonable expedition is implicit” in the obligation
under art 4 ECHR to investigate situations of potential trafficking. In Italy v the Commission [Case 14/88) the CJEU
held, in the very different circumstances of a claim for the payment of aid, that:

“16 … although it is undeniable that Article 14(1) does not expressly stipulate any period for the payment of
the aid in question and that the expression "… grant … aid …" is not unequivocal, it is clear from the very
terms of that provision that the aid in question is intended to facilitate the commencement of operations of
producers' organizations whose formation is encouraged by Regulation No 1035/72, as is stated in the
10th and 11th recitals in the preamble to the regulation, in order to facilitate the attainment of the objectives
of the common organization of the market in fruit and vegetables . The provision in question refers in fact to
aid which may be granted by Member States to producers' organizations during the three years following
the date of their formation, in order to encourage their formation and to facilitate their operation, provided
that the organizations furnish adequate guarantees as regards the duration and effectiveness of their
activities.

17 That objective may, however, only be attained if the aid is not only granted within a brief period but is
also paid swiftly to the organizations concerned in such a way that they may in fact avail themselves of it,
thus increasing the likelihood of effective action on their part. The stipulation of a short period for payment
of this aid thus appears to be necessary in order to achieve the aim assigned thereto by Regulation No
1035/72.”

71. In my judgment, none of this is remotely surprising or capable of serious dispute. It follows that I accept Ms
Lieven's first submission that there is a restrained timescale for victim identification under the NRM and that
restraint is the obligation to determine cases in a reasonable period.

72. The difficulty lies in identifying how the requirement to take decisions within reasonable periods is to be applied
to a challenge such as this one. As Carnwath LJ said in S v SSHD in the passage immediately following that cited
at paragraph 68 above, an obligation to deal with an application in a reasonable time says little in itself. Such an
obligation:

“…is a flexible concept, allowing scope for variation depending not only on the volume of applications and
a ailable reso rces to deal ith them b t also on differences in the circ mstances and needs of different


-----

(Admin)

groups of asylum seekers. But…in resolving such competing demands fairness and consistency are also
vital considerations.”

73. Ms Lieven sought at one stage to argue that the delays in the case of the two individual Claimants and the
general delay described elsewhere in the evidence was “self-evidently” such as would demonstrate unlawfulness, in
that the Defendant had not acted “fairly and reasonably in the operation of the NRM decision-making process”. I do
not accept that there is anything self-evident about that issue. In my view, the answer to the question whether the
Defendant's conduct has been unlawful turns on consideration of the next two grounds.

Ground 2 – Systemically unlawful delay and unfairness

74. Ms Lieven contends that the operation of the NRM is unlawful both because of the chronic, systemic delays to
which she refers and because of what she describes as the “systemic unfairness” of the arrangement.

75. I was taken to a number of authorities which the parties argued demonstrated the correct approach to systemic
delay as a ground of challenge.

76. In _R v SSHD ex parte Phansopkar [1976] QB 606, the first claimant was from India and the second from_
Bangladesh. Both were resident in England, had been registered as United Kingdom citizens and thereby became
patrials under the 1971 Act. Each had a wife in his country of origin and each wished his wife to join him in England.
Under s2(2) Immigration Act 1971 wives of patrials had the right of abode in the United Kingdom, proof of such right
being established by a certificate of patriality. As a rule of practice, the Home Office required that wives applied for
and obtained such certificates in their countries of origin. Since a delay existed of some eighteen months in the
determination of such applications in both India and Bangladesh, both husbands brought their wives to England
without the requisite certificates, and the wives were both refused entry by immigration officers, such refusal being
confirmed by the Secretary of State for the Home Department upon the grounds that it would be wrong to sanction
"queue-jumping" and that the applications for certificates of patriality could most satisfactorily be dealt with in their
countries of origin.

77. The Court of Appeal granted mandamus, holding that wives of patrials were entitled to enter the United
Kingdom "without let or hindrance"; that good cause must be shown for delaying the exercise of that right; and that,
in the circumstances of these cases, the Secretary of State for the Home Department should determine the
applications.

78. At 626 B Lord Scarman said:

“However, when the claim (as in these two cases) is that the right arises from the status of wife to a man
living in this country, the delay may impose great hardship and stress upon private and family life. Delay of
this order appears to me to infringe at least two human rights recognised, and therefore protected, by
English law. Justice delayed is justice denied: "We will not deny or defer to any man either justice or right":
Magna Carta, chapter 29. This hallowed principle of our law is now reinforced by the European Convention
on Human Rights to which it is now the duty of our public authorities in administering the law, including the
_[Immigration Act 1971,and of our courts in interpreting and applying the law, including the Act, to have](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
regard: …”

79. That, however, was a case of an established right. The Court was not considering, as is the position in the
present case, whether the claimant could establish a right to a particular status or the defendant ought to grant the
relevant status; all that was outstanding was a formal recognition of a right arising as a matter of status. The Court
intervened not because of an unconscionable delay in making a decision but because the government was failing to
act on an established right.

80. That decision was relied upon by Elias J in a case upon which the claimants placed considerable reliance; R v
_SSHD ex parte Mersin [2000] INLR 511. There a Turkish national who had been successful in his appeal against_
the Secretary of State's refusal to grant him asylum, sought a declaration that the eight-month delay between the
adjudicator's decision and the actual grant of leave to enter was unlawful and an enforcement order to remedy the


-----

(Admin)

defects in the administrative process, requiring the Secretary of State to report to the court at regular intervals. The
court held that there had been no deliberate delay on the part of the relevant authorities but that no procedures had
been adopted which enabled priority to be given to asylum applicants who had made successful appeals. The
special adjudicator's decision had given the claimant a right to refugee status which the Secretary of State had
been under a duty to provide within a reasonable time and the failure to fulfil that duty had been unreasonable in
the Wednesbury sense.

81. At page 519 Elias J held:

“In my opinion there is a clear duty on the Secretary of State to give effect to the Special Adjudicator's
decision…

The crucial question, therefore, is whether the delays in this case constituted a breach of that duty. I accept
Mr. Catchpole's submission that there is plainly no fixed period within which the Special Adjudicator's
determination has to be implemented…

Mr. Drabble contends that it is nonetheless necessary for the Secretary of State to act within such period
as is reasonable in all the circumstances, and that in any event the delays in this case-seven and a half
months for what were in essence ministerial acts- were outside the bands of Wednesbury reasonableness.

In my opinion it is necessary to bear in mind three features of this case. First the Secretary of State has not
deliberately delayed in granting refugee status, for example in order to conduct further inquiries or anything
of that kind; he accepts that the delays are solely the result of the administrative procedures taking their
course. Second, whilst no doubt shortage of staff has in part explained the delay, a very important reason
for the delay was that no distinction was made at the relevant time between those who had successfully
appealed an initial refusal and those - a very much larger number - whose applications for asylum were still
being considered. That was, of course, because the respondent chose to organise matters in that way,
operating through a multi-functional directorate which gave no priority to the position of those in the
applicant's position. Third, the respondent has accepted that the delays in this case, and other similar
cases, were unacceptable. His contention is that it was not unlawful.”

82. Having cited Phansopkar, he went on at p522:

“In my judgment if someone has established the right to some benefit of significance, as the right to
refugee status and indefinite leave surely is, and all that is required is the formal grant of that benefit (in the
absence at least of a change in circumstance since the right was acquired or other exceptional
circumstance), then it is incumbent upon the authority concerned to confer the benefit without
unreasonable delay. The resources available to the authority will be part of the circumstances which can
be taken into account when determining whether the delay is reasonable or not. However, if the authority
fails to have regard to the fact that a right is in issue, it will have failed to take into account a relevant factor
and will be acting unlawfully. In this case the respondent ought to have treated the applicant and those in a
similar position differently to other categories of cases. The failure to do that both rendered the decision
unlawful in traditional Wednesbury terms and meant that the refugee status was not granted within a
reasonable period. The resources available to the authority will be part of the circumstances which can be
taken into account when determining whether the delay is reasonable or not. However, if the authority fails
to have regard to the fact that a right is in issue, it will have failed to take into account a relevant factor and
will be acting unlawfully. In this case the respondent ought to have treated the applicant and those in a
similar position differently to other categories of cases. The failure to do that both rendered the decision
unlawful in traditional Wednesbury terms and meant that the refugee status was not granted within a
reasonable period.”

83. But that too was not this case. There is here no “established right to some benefit”.

84. Ms Lieven submits that that is a false dichotomy; that all that matters is that the Claimants have a right to a
_decision, whether or not their claim is ultimately established. I reject that submission. What is sought by the_
Claimants before me and in the numerous other cases to which they refer was more than the formal grant of a


-----

(Admin)

benefit already established in principle. It was the recognition of a status as established victims of trafficking, as to
which hitherto there had been only reasonable grounds for belief. In failing to make a decision on conclusive
grounds the NRM was not failing to have regard to the fact that an established right was in issue.

85. The case of R (FH) v SSHD _[2007] EWHC 1571 (Admin) bears closer comparison with the present case. There_
a number of applicants applied for an order that their applications to be allowed to remain in the United Kingdom
should be considered forthwith by the respondent Secretary of State. They also sought a declaration that the delay
in determining their applications was unlawful. Theirs were all "incomplete asylum cases", in that their initial
applications for asylum had been rejected, and their appeals against those decisions did not succeed, but they had
not been removed from the UK. Some years previously they had submitted fresh claims based on further evidence,
or new circumstances, which were said to justify fresh consideration. The claims had not been considered by the
Secretary of State. They submitted that the Secretary of State had failed in his duty to decide the applications within
a reasonable time and operated a system to deal with the backlog of applications which was unfair and unlawful.

86. Thus, FH was not a case of an established right. At paragraph 11 Collins J held:

“Here the question is whether the delay was unlawful. It can only be regarded as unlawful if it fails the
_Wednesbury test and is shown to result from actions or inactions which can be regarded as irrational …_
What may be regarded as undesirable or a failure to reach the best standards is not unlawful. Resources
can be taken into account in considering whether a decision has been made within a reasonable time, but
(assuming the threshold has been crossed) the defendant must produce some material to show that the
manner in which he has decided to deal with the relevant claims and the resources put into the exercise
are reasonable. That does not mean that the court should determine for itself whether a different and
perhaps better approach might have existed. That is not the court's function. But the court can and must
consider whether what has produced the delay has resulted from a rational system. If unacceptable delays
have resulted, they cannot be excused by a claim that sufficient resources were not available. But in
deciding whether the delays are unacceptable, the court must recognise that resources are not infinite and
that it is for the defendant and not for the court to determine how those resources should be applied to fund
the various matters for which he is responsible.”

87. In R (Arbab) v SSHD [2002] EWHC 1249 (Admin) the applicant was a Sudanese citizen whose appeal against a
refusal of asylum had been successful. His entitlement to assistance from the National Asylum Support Service
ended but he was not entitled to claim welfare benefits from the Benefits Agency because he had not yet received a
status letter from the Secretary of State confirming that he had refugee status. He applied for judicial review of the
Secretary of State's failure to issue him with the "status letter". He sought declarations that the Secretary of State's
conduct was unlawful and requiring the Secretary of State to administer the process of issuing status letters more
efficiently.

88. At [45] Jackson J said:

“One aspect of the separation of powers is that the court will not generally involve itself in questions
concerning the management of a government department or similar body: see _Inland Revenue_
_Commissioners v National Federation of Self-Employed and Small Businesses Ltd [1982] AC 617, at 635_
(per Lord Wilberforce), and at 636 and 644 (per Lord Diplock). There are at least three good reasons for
this abstinence on the part of the courts:

(1) How resources should be allocated between competing priorities and how government ministers should
organise their administrative systems are political questions. Judges are not elected and it is not their
function to decide such questions.

(2) The courts do not have the expertise to review the performance of government departments at this level
of generality.

(3) Under our constitutional arrangements there are other more effective mechanisms for calling to account
ministers and senior civil servants who mismanage their departments or mis-allocate resources. These


-----

(Admin)

mechanisms include Parliamentary questions and, more importantly, the scrutiny of select committees: see
de Smith, Woolf & Jowell “Judicial Review of Administrative Action” (Fifth Edition) 1995 at pages 37–40.”

89. From those cases I draw the following principles which seem to me relevant to the present case:

i) Delay may be unlawful when the right in question arises as a matter of established status and the delay
causes hardship (Phansopkar).

ii) An authority acts unlawfully if it fails to have regard to the fact that what is in issue is an established right
rather than the claim to a right (Mersin).

iii) Delay is also unlawful if it is shown to result from actions or inactions which can be regarded as
irrational. However, a failure merely to reach the best standards is not unlawful (FH).

iv) The court will not generally involve itself in questions concerning the internal management of a
government department (Inland Revenue Commissioners v National Federation of Self-Employed and
_Small Businesses Ltd and Arbab)_

v) The provision of inadequate resources by Government may be relevant to a charge of systematically
unlawful delay, but the Courts will be wary of deciding questions that turn on the allocation of scarce
resources (Arbab).

90. Here, there is no established status or established right in issue. The question then is whether, giving such
weight as is appropriate to the question of resources, can the delays that have undoubtedly occurred, properly be
described as the result of an irrational system.

91. Ms Lieven also argues that the management of NRM led to “systemic unfairness”. She refers me to the decision
in R (Q) v SSHD _[2003] EWCA Civ 364, where the Court of Appeal had to consider whether the Secretary of State_
had established and operated a fair system for determining whether an asylum seeker had satisfied him that he had
claimed asylum as soon as reasonably practicable after his arrival. The Court held that the decision-making process
was unfair, but the reasons for that conclusion related primarily to the interview process rather than the time taken
to reach decisions. For example, the court pointed to the fact that the information given to the claimants before
interview was inadequate; caseworkers were not properly directed as to how human rights issues were to be
addressed, caseworkers were not instructed to consider, and the Secretary of State failed to have regard to, the
claimants' states of mind on arrival, and a more flexible approach to interviewing was required (see [69], [81-102],

[116], [119]).

92. She also referred to the decision of the Court of Appeal in Lord Chancellor v Detention Action [2015] 1 WLR
5431. In that case the court dismissed an appeal against a finding that fast track rules governing asylum appeals
were ultra vires. At [27] Lord Dyson accepted the formulation by counsel for the Secretary of State of the general
principles that can be derived from the authorities as to determining the fairness of a system for considering
appeals:

“(i) in considering whether a system is fair, one must look at the full run of cases that go through the
system; (ii) a successful challenge to a system on grounds of unfairness must show more than the
possibility of aberrant decisions and unfairness in individual cases; (iii) a system will only be unlawful on
grounds of unfairness if the unfairness is inherent in the system itself; (iv) the threshold of showing
unfairness is a high one; (v) the core question is whether the system has the capacity to react appropriately
to ensure fairness (in particular where the challenge is directed to the tightness of time limits, whether there
is sufficient flexibility in the system to avoid unfairness); and (vi) whether the irreducible minimum of
fairness is respected by the system and therefore lawful is ultimately a matter for the courts. ”

93. The present case does not involve a judicial system for determining appeals as did Detention Action; the NRM
is an administrative arrangement for determining a status. The _Detention Action principles inform, but cannot_
entirely determine, the fairness of a system such as the NRM. Point (v), in particular, is more obviously relevant to a
judicial process. In my judgment, however, points (i) to (iv) are relevant in circumstances such as the present.


-----

(Admin)

Accordingly, it needs to be acknowledged that the threshold of showing unfairness is a high one and that it is
necessary to consider the full range of cases being determined before reaching a judgment on the system. The acid
test is whether there is unfairness inherent in the arrangements; aberrant decisions or unfairness in individual cases
will not suffice. Point (vi) serves to underline the fact that a challenge such as this is justiciable in the courts.

94. Five particular criticisms are advanced by Ms Lieven, of the NRM system:

i) As a matter of fact, there are chronic delays;

ii) The Defendant routinely takes no, or little action to progress the decision making;

iii) The Defendant has no regard to the impact of delay and has no system for prioritisation of especially
deserving cases;

iv) The lack of a needs-based mechanism for expedition is discriminatory; and

v) Delays in progressing Conclusive Grounds decisions delays the examination of asylum claims.

95. I deal with each point in turn.

_Chronic Delays_

96. It is apparent from the evidence of Ms Devlin and the agreed statistics that there has been a very significant
growth in the number of persons being referred to the NRM. It is apparent from all I have heard that the NRM has
struggled to cope. The Home Office can, in my view, fairly be criticised for being slow to respond to the growing
number of referrals and the consequent delays in reaching Conclusive Grounds decisions. Appreciating the extent
and persistence of the growth in referrals is, of course, hugely easier in retrospect than when the problem is
emerging. Nonetheless the direction of travel in numbers must have been pretty obvious from early on. If there was
any doubt about that, that doubt is, in my view, entirely resolved by the Oppenheim report which made the position,
and the problem, very clear.

97. In my view, there was delay in taking steps necessary to address the problem. Sensible steps are currently
being taken as described by Ms Devlin, but there is no obvious reason why those changes could not have been
taken earlier. Resources have now been found; I have no evidence as to why they could not have been found in
earlier years if the political will was there. However, there is nothing to suggest there was either any deliberate
decision to delay the decision-making process or any cynical attempts to avoid the costs associated with it. In fact,
delay only added to the expense the Home Office had to bear; the facilities required for persons in respect of whom
there are reasonable grounds to believe they are victims of trafficking is significantly reduced after a decision is
made, whichever way that decision goes.

98. There is, however, nothing to suggest that the delay in reacting to the long-emerging problem or the delay in
applying appropriate resources to the problem is the result of some irrational decision or some irrational failure to
act. Delays are a function of the very substantial growth in the NRM's caseload and the Home Office's tardiness in
responding. But in my judgment, it cannot be said that substantial delay is inherent in the arrangements. There is
nothing to which my attention has been drawn, for example, which suggests there is some design fault in the
system or some flaw in the arrangements which make delay inevitable. Certainly, I do not have the materials on
which I can draw safe conclusions about the internal management of the relevant departments of the Home Office.
It may well be that the Home Office failed in its management of the NRM to reach the highest standards of
administration; it may well be that it would now be possible to devise a better system but neither of those facts
means their conduct of the NRM to date has been unlawful.

99. Furthermore, it appears from the evidence and the agreed statistics that the position is now improving. The
problems appear to have been identified and resources are being devoted to improving the speed at which cases
are determined.

100. In my judgment the simple fact of significant delays in the processing of Conclusive Grounds decisions does
not on these facts establish nla f lness


-----

(Admin)

_Progressing decision making_

101. There is evidence in the statements from solicitors relied on by the claimants of delay and inefficiency in
progressing cases through the conclusive grounds process. But there is no evidence, statistical or from witness, to
substantiate the assertion that the NRM “routinely takes no action” to progress decision-making. In fact, the
statistics of improving rates of decision-making points firmly towards the contrary conclusion. I accept the
submissions on behalf of the Secretary of State that determining Conclusive Grounds decisions is not
straightforward; the evidence has to be gathered, analysed and tested. As the Oppenheim report explains, many
persons and agencies are consulted as part of a process which is evaluative rather than simply administrative.
Furthermore, what matters is not just the speed but also the quality of the decision-making.

102. The Guidance advises that cases are reviewed at the 30th day of the recovery and reflection period to “monitor
progress of the case” and “check it is on target for a conclusive decision”, but it expressly recognises that “it may
not be possible in every case” to make a decision “as near as possible to day 45”.

103. The willingness to recognise, investigate and respond to the cause and effect of delays is demonstrated first
by the commissioning of the Oppenheim report, second by the internal submission to the Secretary of State from
the Modern Slavery Unit dated 8 September 2017, and third, the steps taken in consequence. It is apparent that
these concerns have been taken into account in the management process of the NRM. The NRM cannot fairly be
described as an agency (or a process) that refused to address its own deficiencies. Those responsible for it have, in
recent months, devoted real effort and monies to addressing the problem of delays in making Conclusive Grounds
decisions

104. I am not in a position to conduct an audit on the hundreds or thousands of cases that have passed through the
NRM's hands to determine the level of competence displayed by their staff. But I cannot conclude, on the material
put before me, that the criticism that the Defendant routinely takes no, or little, action to progress the decision
making is made out.

_Impact of delays/Prioritisation/Lack of needs-based mechanism for expedition_

105. These complaints can be taken together.

106. It is clear that the delays about which I have heard have the potential to cause significant distress to those
affected. It is not difficult to imagine the upset caused by waiting months, or even years, to discover whether or not
it has been accepted in the NRM that the reasonable grounds for believing a person is a victim of trafficking have
matured into conclusive grounds for accepting the same. And I accept the evidence of Professor Katona as to the
potential consequences for the psychiatric recovery of victims of trafficking of significant delays in the process.
Furthermore, Ms Lieven is right to observe that a positive Conclusive Grounds decision is a gateway for other
benefits. In particular, it is a pre-requisite for the grant of discretionary leave to remain, a time-limited grant of
permission to remain in the UK.

107. The Home Office does not dispute the potential effects of delay. It accepts that the delays are regrettable, and
that stability is important for victims of trafficking. It has to be observed, however, that all those affected by these
delays have been accepted as potential victims of trafficking and that that decision is the trigger, under the
guidance and the Directive, for protection, support and accommodation. There is no criticism in these proceedings
of either the process for, or timing of, the making of those decisions. The 45-day period for which the guidance
provides is a minimum period for recovery and reflection, after which a Conclusive Grounds decision can be made;
it is not the maximum period within which a decision must be made. Whilst I accept Ms Lieven's submissions that
the process envisaged by the Directive for the recognition of victims of trafficking encompasses both the
Reasonable Grounds and Conclusive Grounds stages, the former is undeniably the more important in ensuring the
safety and welfare of the victim.

108. In my judgment the fact that there are some additional advantages that may flow from a positive Conclusive
Grounds decision does not make the delay in the system unlawful. There is no evidence that potential victims of


-----

(Admin)

trafficking are, in fact, liable to prosecution after the grant of a Reasonable Grounds decision. There are advantages
in the grant of discretionary leave to remain, but those advantages are less obvious when the comparator status is
being a person in respect of whom a Reasonable Grounds decision has been made.

109. As to prioritisation, the Secretary of State's Safeguarding Guidance indicates that his policy is to prioritise
attention and support to individuals within the NRM according to their vulnerability, rather than a policy that
expedites a Conclusive Grounds decision on that basis. It is impossible to see that as irrational or demonstrably
unfair.

_Consequential delay to asylum process_

110. The Secretary of State is right to observe in his skeleton argument that the time taken to make asylum
decisions is not the subject matter of this claim. There is little evidence in support of the contention that delays in
reaching a conclusive grounds decision has a consequential effect on the time taken to make an asylum decision,
or on the lawfulness or unfairness of that consequence. If this was to be an issue of real substance, it would need to
be addressed in detail by the parties and it has not been.

111. The same point made above about discretionary leave to remain would need to be addressed. The comparator
status for determining the nature and extent of any unfairness would not be an asylum seeker _simpliciter but an_
asylum seeker who had the benefit of being the subject of a Reasonable Grounds decision. That exercise was not
carried out before me.

_Conclusions on systemic unfairness and unlawful systemic delay_

112. In those circumstances, whilst there may be significant grounds for criticising the operation of the NRM, they
are not criticisms that can ground a successful judicial review. There is no unfairness inherent in the arrangements
and there is nothing inherently irrational in the system being operated.

Ground 3 – The two claimants' individual claims

113. Ms Lieven argues that each of the criticisms made of the NRM process applies to the Claimants individually.
She says that each Claimant waited an excessive period for her Conclusive Grounds decision. No good reason has
been provided for the delay. No “Day 30” review or any other review appears to have been carried out in their
cases. Neither of their cases was prioritised despite the mental frailty of both women. The delay has caused
consequential delay in resolving their asylum claims.

114. I have rejected each of the grounds advanced in support of the general complaints about the system; they can
fare no better in respect of the two individuals.

115. As Ms Giovannetti submits there is no legal time limit for resolving the Claimants' cases and the delay has not
been so egregious as to be unlawful when looked at in isolation. The explanation for the delays in these two cases
is the same as applies more generally; there has been a rapid increase in the NRM's caseload and the Secretary of
State has been somewhat slow to address the resulting problem. But his response has not been irrational, and the
problem has now been, or is being, addressed. The Secretary of State does not operate a policy of expediting
Conclusive Grounds decisions but has a policy instead to prioritise attention and support to individuals according to
their vulnerability. That is not irrational. The observations above about the impact on asylum claims applies equally
to the Claimants' individual cases.

Conclusion

116. In those circumstances, this claim must fail.

**End of Document**


-----

