41

# R (on the application of TN (Vietnam)) v Secretary of State for the Home
 Department and another [2021] UKSC 41

Supreme Court

Lord Lloyd-Jones, Lord Briggs, Lady Arden, Lord Sales and Lord Stephens SCJJ

22 September 2021Judgment

**THE COURT ORDERED that no one shall publish or reveal the name or address of the Appellant**
**who is the subject of these proceedings or publish or reveal any information which would be likely to lead**
**to the identification of the Appellant or of any member of her family in connection with these proceedings.**

**Respondents:-**

(1) Secretary of State for the Home Department

(2) Lord Chancellor

**Interveners:-**

(1) Helen Bamber Foundation

(2) Detention Action

**_LADY ARDEN: (        with whom Lord Briggs and Lord Stephens agree)_**

**Overview and decisions below**

1. The fast-track procedure for appeals from the rejection by the Secretary of State for the Home Department of
certain asylum claims, set up under the Asylum and Immigration Tribunal (Fast Track Procedure) Rules 2005 (SI
2005/506) (“the FTR 2005”) and continued in the Asylum and Immigration Tribunal (Fast Track Procedure) Rules
[2014 (SI 2014/2604) (“the FTR 2014”), provided for an accelerated procedure for the preparation and hearing of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5D82-RT11-F16W-C1SD-00000-00&context=1519360)
certain appeals with the applicant remaining in detention. This system created a risk that the applicants would have
inadequate time to obtain advice, marshall their evidence and properly present their cases. In this judgment,
references to the “FTR” without a date are to the FTR 2005 and FTR 2014 collectively.

2. There was a series of cases in which the lawfulness of the procedure was challenged. Ultimately, in _R_
_(Detention Action) v First-tier Tribunal (Immigration and Asylum Chamber)_ _[2015] EWCA Civ 840; [2015] 1 WLR_
5341(known as “DA6”), the Court of Appeal held that the FTR 2014 were “structurally unfair, unjust and ultra vires”,
and that they fell to be quashed. Permission to appeal to this court against that decision was refused. Lord Dyson
MR, with whom Briggs and Bean LJJ agreed, held:

“An appeal is bound to seek to challenge the reasons given by the SSHD for refusing the asylum claim. As
I have said, many refusals turn on adverse findings on the appellant's credibility. The focus of the
preparation for an appeal will often, therefore, be on the search for evidence to corroborate the appellant's
account in rebuttal of the adverse findings. The period of seven days between the date of the refusal
decision and the hearing of the appeal is bound to be insufficient in a significant number of cases. I have


-----

41

referred to the difficulties facing legal representatives who have to take instructions from clients who are in
detention. It may not be possible for them to say whether the further inquiries that they wish to make are
likely to be fruitful. In such a situation, it may be difficult to persuade the tribunal that there are cogent
reasons to transfer a case out of the fast track.” (para 42)

3. This appeal is a consequence of the decision in DA6. TN, the appellant, lost her appeal against the Secretary of
State's decision to reject her asylum claim under the FTR 2005. She brought a challenge by way of judicial review
to that determination of her appeal, contending the FTR 2005 also fell to be quashed. Ouseley J, who heard her
application, agreed on that issue, and there is no appeal from that part of his order: _[2017] EWHC 59 (Admin);_

[2017] 1 WLR 2595. But, significantly, TN then contended that the decision of the First-tier Tribunal (“FTT”) in her
case also fell automatically to be quashed. Ouseley J rejected that contention and in addition held that she could
not show that the FTT's decision was unfairly made in her case. The judge had to consider TN's long and complex
immigration history.

4. The Court of Appeal upheld his decision and TN now appeals with permission to this court: [2018] EWCA Civ
_2838; [2019] 1 WLR 2647. Singh LJ gave the leading judgment, with which Sharp and Peter Jackson LJJ agreed._
He lucidly and succinctly explained why the decision in _DA6 did not automatically lead to the nullification of all_
orders made by the FTT under the FTR 2005. His principal reasons were as follows:

“80. … The true position, in my view, is (as illustrated by the task performed by Ouseley J in the present
two cases) that the court must engage in a close analysis of the sequence of events in order to determine
whether subsequent decisions are indeed to be set aside.

81. Although I see force in Mr Tam's submissions based on cases such as Percy v Hall [1997] QB 924, in
particular at pp 947-948, and R (Draga) v Secretary of State for the Home Department _[2012] EWCA Civ_
_842, I consider that it is unnecessary to examine them in detail because they were decided in different_
contexts. For example, _Percy v Hall was concerned with whether an innocent third party (in that case a_
police constable who arrested a person pursuant to a byelaw which was later found to be ultra vires) can
be liable for damages, in that case for the tort of false imprisonment.

82. In my judgment, the straightforward argument made on behalf of the appellants by Ms Lieven must be
rejected on its own merits in the present context and without the need for extensive reference to authority
from other contexts.

83. The first and fundamental reason for this is that, in my view, there is a conceptual distinction between
holding that the procedural rules were ultra vires and the question whether the procedure in an individual
appeal decision was unfair.

84. The jurisdiction of the court to consider the lawfulness of a procedural regime, such as that in the 2014
Rules (which was quashed as a result of the Court of Appeal decision in DA6) … is an important one … In
order to challenge the entire system of such rules it is not necessary to show that the rules will lead to
unfairness in every case. Rather it is the creation by the rules of an 'unacceptable risk' of unfairness which
founds the ability of the court to strike them down. This is because it is important that rules which are
systematically capable of creating unfairness should not be allowed to stand and should be removed or
amended.

85. However, that does not entail the necessary conclusion that in each and every case decided pursuant
to the ultra vires procedural rules a particular decision was itself procedurally unfair. This is reinforced by
the consideration that, in DA6 itself, the Court of Appeal said that the 2014 Rules would inevitably lead to
unfairness in a 'significant' number of cases. The court did not expand upon what that meant, for example
whether it meant in a majority of cases or in a significant minority of cases. That was unnecessary.
Similarly, it had been unnecessary in the Refugee Legal Centre case, which concerned a policy rather than
secondary legislation but where the analysis was similar. It was for that reason that, in the Refugee Legal
_Centre case, the court did not feel it appropriate to consider evidence as to how the scheme had operated_
in practice. It was the fact that a scheme was capable of creating unfairness in an unacceptable way which
would render the scheme unlawful


-----

41

86. I agree with Mr Tam that 'jurisdiction' to determine the appeals in the pure or narrow sense of that
word (the legal authority to decide a question) existed by virtue of the primary legislation (section 82 of the
2002 Act) and the FTT was not deprived of jurisdiction in that sense by reason of the fact that the 2005
Rules were ultra vires. I would also reject Ms Lieven's suggestion that the FTT's jurisdiction was created by
the 2005 Rules themselves. She submitted that a valid appeal required a notice of appeal to be filed in
accordance with rule 6 of the Principal Rules, applied to the fast track process by rule 6 of the 2005 Rules.
In my view, that submission is misconceived. It is a commonplace feature of an appellate system that there
will be procedural rules which require a notice of appeal to be filed in a certain form. That is not what
creates the jurisdiction of a court or tribunal; it is merely a rule which regulates procedure and form. What
creates the jurisdiction is the principal legislation, here the 2002 Act.

87. However, in my view, that would only go so far in meeting Ms Lieven's fundamental submission, which
is that any appeal decision which was made under those Rules was necessarily infected by the fact that
they were unlawful because they created an unacceptable risk of procedural unfairness. It is in that sense
that she submits the FTT did not have jurisdiction, in other words a post-Anisminic understanding of
jurisdiction: not in the pure or narrow sense of having the legal authority to determine a question, but that a
body has acted in a way which is unlawful, including (for this purpose) in a way which is procedurally
unfair. That said, it seems to me that the answer which Mr Tam gives to that contention is correct: there
has to be shown to be procedural unfairness on the facts of the individual case. …

89. Finally, I would add that, as a matter of legal principle, if the appellants' submissions on the first issue
were correct, it would necessarily follow that even appeal decisions where the appeal was allowed would
fall to be set aside, because they would be a nullity. That cannot possibly be correct. At the hearing before
us Ms Lieven submitted that this was a theoretical point and not a real one, since in practice individuals will
have been granted leave to remain in the light of a successful appeal decision and this would not be
curtailed. However, in my view, it is revealing that, if the logic of her submission were accepted, this would
be the result as a matter of principle. That analysis of principle helps to test whether the submission can be
correct.”

5. Singh LJ then helpfully summarised the approach to be taken when there was a challenge to the fairness of a
hearing under the FTR. He formulated a non-exhaustive list of four factors, which I will call the four TN factors:

“103. For the future I would recommend that a court which has to consider an application to set aside an
earlier appeal decision made under the 2005 Rules should approach its task having regard to the following:

(1) A high degree of fairness is required in this context.

(2) What the Court of Appeal said in _DA6 … should be borne in mind: that the 2005 Rules created an_
unacceptable risk of unfairness in a significant number of cases. Depending on the facts it may be that the
case which the court is considering is one of those cases.

(3) There is no presumption that the procedure was fair or unfair. It is necessary to consider whether there
was a causal link between the risk of unfairness that was created by the 2005 Rules and what happened in
the particular case before the court.

(4) It should also be borne in mind that finality in litigation is important. There may be a need to ask how
long the delay was after the appeal decision was taken before any complaint was made about the fairness
of the procedure. There may also need to be an examination of what steps were taken, and how quickly, to
adduce the evidence that is later relied on (for example medical evidence) and whether it can fairly be said
that in truth those further steps were taken for other reasons, such as a later decision by the Secretary of
State to set removal directions. This may suggest that there is no causal link between the risk of unfairness
that was created by the 2005 Rules and what happened in the particular case before the court.

104. The above should not be regarded as an exhaustive checklist. At the end of the day, there can be no
substitute for asking the only question which has to be determined: was the procedure unfair in the
particular case? That has to be determined by reference to all the facts of the individual case.”


-----

41

6. With that introduction I will describe next in more detail the history of TN's case.

**TN's asylum claims: decision of the FTT**

7. On 21 August 2014, the FTT (Designated Judge Appleyard) dismissed the appeal of the appellant, TN, from the
determination of the Secretary of State that TN was not entitled to asylum. The appeal was heard under the FTR
2005.

8. TN was represented by counsel at the hearing and spoke through an interpreter. She gave evidence. She
claimed religious persecution and claimed that in 2003, her mother, her priest and she had all been arrested by the
Vietnamese authorities for fund-raising activities for the church. She left Vietnam in 2003 and came to the UK and,
following an unsuccessful claim to asylum, she was removed from the UK back to Vietnam in 2012. She contends
that she was then detained by the police and questioned about the money she had raised. She managed to
escape, and she then returned to the UK. She contended that she had been raped several times by a man claiming
to help her reach the UK. She became pregnant but suffered a miscarriage in July 2014, but this did not form any
part of her claim to asylum.

9. Following her arrival in the UK, she became friendly with a Mr Quang Minh Dang and a Mr Quang Hai Tran who
gave her food and accommodation. She contended that her mother had died in 2003. She said that she had no
children but in 2003 she claimed that she had two children in Vietnam. She had made a fresh claim in 2011, but she
did not then mention the difficulties that she and her mother had had in Vietnam. Mr Quang Minh Dang and Mr
Quang Hai Tran gave evidence about their friendships with her in the UK.

10. The Secretary of State rejected her asylum claim in February 2012 on the basis that the truthfulness of her
claim was not accepted.

11. The FTT also formed the view that TN's claim was not credible. There were discrepancies and inconsistencies
in her evidence, and, although she knew about the immigration process, she had not made a claim to asylum until
she was arrested, which was some months after arriving in the UK on the second occasion. The FTT rejected her
claim to asylum, under the Refugee Convention, the EU Qualification Directive, under the European Convention on
Human Rights (“the Convention”) and under the Immigration Rules.

12. There was no appeal from this decision. As appears below, on 20 August 2015, TN made a fresh claim to
asylum on the basis that she was trafficked on the journey to the UK and also in the UK. That claim is still
outstanding.

**TN's attempts to establish her asylum claim before and after her appeal to the FTT**

13. The account which TN gave of her experiences may not be untypical of many asylum-seekers. Her first claim to
asylum was in January 2004 when she claimed asylum because of religious persecution against Catholics in
Vietnam. Her claim was refused for non-compliance and treated as withdrawn because she failed to report as
required. She was arrested on suspicion of being an illegal entrant in 2007 and was granted temporary admission
but again failed to report. In 2011 she made further submissions to the Secretary of State and claimed that she was
entitled to asylum again on the basis of religious persecution in Vietnam. She was detained at a nail bar and found
to have £1,000 in cash.

14. Her claim to asylum was refused and in March 2012 she was removed to Vietnam. She claims to have entered
the UK clandestinely in about May 2014. On about 21 July 2014 she had a miscarriage and went to hospital. She
was arrested on suspicion of illegally working while she was present in the nail bar, also in July 2014. She was
again detained.

15. She then claimed asylum because of events which occurred after her removal. She contended that she could
not be returned to Vietnam because of religious persecution. She also stated that her mother and the local priest
caused a financial crisis in the community, which led people to complain to the Vietnamese authorities who arrested
her


-----

41

16. The Secretary of State contended that there were no reasonable grounds to believe that TN was a potential
victim of trafficking and made it clear that she had not been referred for assessment as a victim of human
trafficking. The background to this decision-making is that the Home Office is one of the UK's competent authorities
for the purposes of the Council of Europe Convention on Action against Trafficking in Human Beings 2005, and it is
responsible for making conclusive decisions on whether a person has been trafficked. (Human trafficking is also
known as **_Modern Slavery.) The “reasonable grounds” decision is the first step in that process. The National_**
Referral Mechanism is responsible for ensuring that victims of trafficking receive appropriate support. Where there
is a credible suspicion that an individual has been trafficked, article 4 of the Convention requires that the competent
authority should assess whether they are a victim of trafficking as part of the state's duty to protect them: see
_Rantsev v Cyprus and Russia (2010) 51 EHRR 1 and VCL and AN v United Kingdom (Application Nos 77587/12_
and 74603/12, judgment of 16 February 2021: The Times 17 March 2021).

17. TN was found to be fit when she arrived at the detention centre. She said at one interview that she had not
been tortured. She did, however, contend that she had been raped many times on the journey to the UK. At her
substantive asylum interview, she claimed that on her return to Vietnam in 2012 she had been detained in a
detention centre where she was subject to torture. She further contended that her persecution was because of her
mother's political activities and because she had been involved in raising funds for the local church. She said that
she had been beaten and ill-treated by the Vietnamese authorities. She said that that was the cause of scars on her
head and finger. She said that she had become pregnant because of rape and had suffered the miscarriage, which
I have already mentioned, and that that had caused her distress.

18. The Secretary of State refused her asylum claim. On 16 August 2014, TN appealed to the FTT. The Secretary
of State determined that her case was suitable for determination under the FTR 2005.

19. In preparation for those proceedings TN made a witness statement claiming detention by the Vietnamese
authorities in her own house. She explained that she had escaped and as a result had come to the UK in 2013. She
said she was living in the UK with Mr Dang, whom I have already mentioned, whom she described as her boyfriend.
She said that he had provided her with free food and accommodation and that she had returned to the UK to be
with him. There was another gentleman involved, Mr Tran, whom I have also already mentioned. TN said that she
felt safe in the UK. Both Mr Dang and Mr Tran gave evidence before the FTT, but their evidence was not accepted.

20. TN also filed additional grounds of appeal for the hearing of her appeal in which she said that the Home Office
had failed to consider that she had been a victim of rape. She said that she had also been a victim of a sex
trafficker when she was brought back to the UK, but it is apparent that her real claim to asylum was fear of illtreatment by the Vietnamese authorities. She did not allege that she was a victim of ongoing human trafficking in
the UK. At the hearing of the appeal, she withdrew any reliance on the allegations of rape.

21. In a determination dated 22 August 2014, the FTT concluded that TN's account was not credible and contained
discrepancies and inconsistencies. It also drew attention to other matters affecting her credibility.

22. In August 2015, a year after TN's appeal had been rejected, TN's new solicitors filed further submissions with
the Secretary of State claiming that she was a victim of human trafficking both on her journey to the UK and also
while in the UK, and that she had been sexually exploited. They sought the cancellation of the removal directions
which had by then been made against her. By this stage TN had a witness statement from Dr Rachel Bingham of
Medical Justice, a general practitioner with extensive experience of assessment of victims of torture and other
serious abuse. Dr Bingham's evaluation, based on what TN had told her, was that TN's presentation, including her
scars and injuries, was highly consistent with her history of trafficking, imprisonment, multiple rapes and forced
prostitution.

23. The Secretary of State considered that TN's further submissions did not amount to the making of a fresh claim
and determined that there were no reasonable grounds to believe that TN was a potential victim of trafficking. This
rejection of her fresh claim was challenged within these proceedings by way of judicial review (outlined in para 3
above). Those proceedings were in due course heard by Ouseley J. As part of his thorough and impressive
judgment Ouseley J quashed the rejection of the new submissions He considered that the Secretary of State was


-----

41

wrong not to treat her further submissions as a fresh claim, but that that step did not entitle the appellant to a retrial
of the issues which the FTT had decided, which was the principal reason for the judicial review proceedings. The
fresh claim has yet to be determined.

24. In 2016, TN also obtained a witness statement from Ms Zahra Kellaway-Payne, formerly a Community
Engagement Officer of the Poppy Project, a charity which provides support for women trafficked into the UK. Ms
Kellaway-Payne notes that the Home Office Guidance to Front Line Staff (Victims of **_Modern Slavery: Frontline_**
Staff Guidance Version 2) also recognises that “Potential victims of **_modern slavery may be reluctant to come_**
forward with information, may not recognise themselves as having been trafficked or enslaved and may tell their
stories with obvious errors.” Ms Kellaway-Payne's evaluation was that the marks on TN's body and various
elements of her account of her time in Vietnam, her journey to the UK and her experiences in the UK were
“sufficient objective indicators” of human trafficking to suggest that TN may have been a victim of human trafficking.
TN wishes to adduce her evidence at a new hearing before the FTT.

**The issues argued on this appeal**

25. TN seeks to establish on this appeal: (i) that the systemic unfairness inherent in the FTR 2005 meant that the
determination of her appeal was automatically also of no legal effect; (ii) alternatively that the Court of Appeal
should at least have recognised that in TN's case the features which made the system unfair were present and
established unfairness, or at least should have applied a presumption of unfairness; and (iii) that the structural
unfairness identified in DA6 applied to her appeal and that there was also unfairness on the facts of her case.

26. Lord Pannick QC presents TN's appeal on issues (i) and (ii). Ms Stephanie Harrison QC presents her appeal
on issue (iii). Robin Tam QC presents the Secretary of State's case in response, and Ms Julie Anderson presents
the Lord Chancellor's case in response.

27. There are two interveners, the Helen Bamber Foundation and Detention Action. The Court is grateful for the
assistance given by their joint written and oral submissions. Charlotte Kilroy QC presented helpful oral submissions.

**TN's submissions**

28. Lord Pannick QC properly accepts that an application needs to be made in order to quash an adverse asylum
decision: see Smith v East Elloe Rural District Council [1956] AC 736, 769 per Lord Radcliffe:

“An order, even if not made in good faith, is still an act capable of legal consequences. It bears no brand of
invalidity upon on its forehead. Unless the necessary proceedings are taken at law to establish the cause
of invalidity and to get it quashed or otherwise upset, it will remain as effective for its ostensible purpose as
the most impeccable of orders.”

29. Lord Pannick also accepts that it is not an inevitable consequence of an ultra vires regulation that decisions
taken pursuant to it are necessarily themselves always unlawful, so it is unnecessary for me to address the various
authorities on that point. Lord Pannick properly accepts that it all depends on the legal context.

30. He also points out that, as one would expect, the FTR 2005 were required to be fair. Thus, the FTR 2005 were
made under section 106 of the Nationality, Immigration and Asylum Act 2002 (“the 2002 Act”), which stipulates
(section 106(1A)(a)) that:

“the Lord Chancellor shall aim to ensure … that the [asylum appeal] rules are designed to ensure that
proceedings before the Tribunal are handled as fairly, quickly and efficiently as possible.”

31. The FTR 2014 were made under section 22(4)(a) of the Tribunals, Courts and Enforcement Act 2007, which
went further. This required that the power to make Tribunal Procedure Rules be exercised so that “the tribunal
system is accessible and fair.” Furthermore, UK law places considerable importance on the right to have a fair trial.
This is an uncontroversial proposition. In _R (Osborn) v Parole Board [2014] AC 1115at paras 67-72, Lord Reed_
mentioned three values served by procedural fairness. It is sufficient to mention the first:


-----

41

“The first was described by Lord Hoffmann (ibid) [Secretary of State for the Home Department v AF (No 3)

[2010] 2 AC 269, para 72] as the avoidance of the sense of injustice which the person who is the subject of
the decision will otherwise feel. I would prefer to consider first the reason for that sense of injustice, namely
that justice is intuitively understood to require a procedure which pays due respect to persons whose rights
are significantly affected by decisions taken in the exercise of administrative or judicial functions.” (para 68)

32. Lord Pannick submits that nullification of the FTT's decision should follow the decision in _DA6. He contends_
that the connection between the hearing of the appeal and the systemic failures in the rules was sufficient of itself.
Those failures gave rise to irremediable taint.

33. Lord Pannick relies on the judicial bias cases, that is, the cases which establish that orders made by a judge
who should not have sat on the case because of some financial or other interest are automatically set aside. The
principal authority is _Millar v Dickson [2001] UKPC D4; [2002] 1 WLR 1615(considered below). Lord Pannick_
submits that no distinction could be drawn between those cases and the present one where there is a lack of
fairness in the trial. In Millar, the court did not inquire into the reasons why the trial was unfair.

34. The position was, on his submission, the same if the appellant had had no right to be heard at all.

35. Lord Pannick submits that Singh LJ was wrong to hold in para 89 of his judgment set out above that
automaticity of nullification should be rejected on the basis that it would have the effect of making orders on which a
party had been successful null and void. In that event, the party would rely on the doctrine that the order was valid
unless an application was made to set it aside. A party would not appeal an order in his favour.

36. In the alternative, Lord Pannick submits that there should be a presumption of unfairness in cases heard under
the FTR 2005 because of the inherent unfairness of the system.

37. It was not on Lord Pannick's submission appropriate to ask whether the application would have succeeded. For
this proposition, Lord Pannick places particular reliance on the recent decision of this Court in Pathan v Secretary of
_State for the Home Department_ _[2020] UKSC 41; [2020] 1 WLR 4506. He submits that the courts will not deny a_
remedy because the right to be heard makes no difference on the facts of the individual case. He argues in effect
that fairness is such a fundamental aspect of the justice system that the courts will not decline to give relief in
circumstances such as these simply because the appellant could not show that she would have succeeded on her
appeal. The appellant had to submit to an unfair procedure and that was unfairness enough.

38. As an alternative approach Lord Pannick submits that if automatic nullification is not available, the decision of
the FTT should be set aside if some or all of the features identified in DA6 are present, and that the determination
should be quashed. Those features were an accelerated timetable which made it difficult to obtain corroborative
evidence; a large volume of tasks facing the legal representative; limited access to the legal representative; lack of
legal representation and complexity of the case (present in many asylum appeals). In the further alternative, Lord
Pannick submits that there should in this situation be a presumption to that effect.

39. I now turn to the submissions of Ms Stephanie Harrison QC, who has provided the court with the benefit of her
expertise about human trafficking claims. She submits that the accelerated timetable imposed by the FTR 2005 was
peculiarly prone to have a particular adverse impact on the victim of human trafficking. This is because a victim of
human trafficking is likely to need more time to obtain medical reports and so on and the person is unlikely to be
willing to disclose information that would give rise to such a claim at the outset. The Secretary of State had failed to
pick up the indicators of human trafficking in TN's case, for instance, that she had been raped on her journey to the
UK.

40. Therefore, submits Ms Harrison, TN should have been referred before the hearing of her appeal in the FTT to
the National Referral Mechanism (see para 16 above) for assessment as a possible victim of human trafficking. The
FTR 2005 were only for comparatively straightforward appeals and TN's case should not have been included in that
system. Home Office guidance refers to factors which may make it difficult for a victim of trafficking to come
forward; it provides:


-----

41

“Such factors may include, but are not limited to, the following: trauma (mental, psychological, or
emotional), inability to express themselves clearly, mistrust of authorities, feelings of shame and painful
memories (particularly those of a sexual nature).” (Victims of **_modern slavery - Competent Authority_**
_guidance, version 3.0, p 99)_

41. DA6 had identified the risks of unfairness at the appeal hearing and it was sufficient to show that those risks
were present. The overriding risk was that TN would not have the time required to prepare and present her
trafficking claim. Clear indicators of human trafficking were present. Such indicators included her physical injuries
and that she presented as a vulnerable person. Dr Bingham had opined that TN's injuries were highly consistent
with her account of beatings and rapes and that she exhibited signs of mental trauma. As Dr Bingham put it,
persons who are trafficked do not self-identify.

**The respondents' arguments**

42. Mr Tam submits that, on the hearing of TN's appeal to the FTT, the FTT determined the issue that was placed
before it and there was no application that further time was needed. TN was legally represented. Her original claim
in January 2004 after she was first encountered was that she was subjected to religious persecution in Vietnam
because of her faith. She was not believed and was subject to removal. There was no appeal to the FTT from the
determinations of the Secretary of State.

43. When TN returned to the UK, she claimed that she and her mother had suffered torture and ill treatment at the
hands of the Vietnamese authorities. She did not produce evidence of these allegations, but at the hearing of her
appeal, two friends whom she claimed to have had during her trafficking were called on to give evidence. She did
not explain in her witness statement used at the FTT hearing how it was that her story had changed so radically.

44. Later she changed this story to say that she had been trafficked and had been raped on the way to the UK.
That claim was abandoned at the appeal hearing itself. In a yet further permutation when making her fresh claim,
she claimed that she had been trafficked within the UK. These matters were the subject of the fresh claim which
remains outstanding.

45. Mr Tam fairly accepts that if the Secretary of State cannot show fairness it is normally not enough that the
unfairness made no difference to the outcome. The view taken by English law is, he accepts, stricter than that taken
by the High Court of Australia: see Minister for Immigration v SZMTA [2019] HCA 3.

46. Mr Tam submits that where there is systemic unfairness in a process of adjudication, it is the system that is
struck down, leaving the separate question of whether the hearing was unfair in a particular case. To say that a
whole process of adjudication is unfair is to declare that there is an inherent risk of unfairness: it does not mean that
there was unfairness in every individual case. Moreover, the FTR 2005 provided for judicial discretion to extend
time limits.

47. Mr Tam distinguishes the judicial bias cases by saying that where the system cannot produce a judge who
does not have a conflict of interest, it follows that the whole system is unfair and that all cases decided under it must
be reheard. It is not enough, as the appellant seeks to do, to rely on R (DN (Rwanda)) v Secretary of State for the
_Home Department_ _[2020] UKSC 7; [2020] AC 698where the order for deportation was held to be invalid where the_
statutory instrument under which it was made was held to be ultra vires. In that situation the deportation order
depends directly on the validity of the statutory instrument.

48. Mr Tam opposes Lord Pannick's alternative approaches. In particular he submits that if regard were had to the
presence of some or all of the features of unfairness identified in _DA6, no regard would be paid to the extent to_
which unfairness arising from those factors had fructified in any individual case. There could be a range of reasons
why corroborative evidence was not obtained which had nothing to do with the accelerated timetable. An event
occurring in relation to a determination under the FTR 2005 should also not be capable of leading automatically to
that determination being set aside if it would equally have occurred under the ordinary rules applying to appeals,
which it is not contended were systemically unfair. A presumption was inappropriate when the decision in DA6 had


-----

41

identified the risk of unfairness, not unfairness in individual cases, which would have to be the product of a
multifactorial evaluation of the circumstances of the case.

49. As to unfairness on the facts, the sequence of events in Mr Tam's submission shows that TN's case involved a
last-ditch attempt to resist removal.

50. Miss Julie Anderson adopts Mr Tam's submissions on behalf of the Lord Chancellor.

**Discussion**

51. The question that arises on this appeal stems from the unfairness which the Court of Appeal found in DA6 to be
systemic in the FTR 2014. For instance, there was a shortened timetable (two days for serving a notice of appeal
from the date of the decision, which the FTT could only extend in limited circumstances: see rule 8, with the hearing
potentially to follow as soon as possible after the date on which the respondent provided certain documents: rule
12), and the limited power of the FTT to permit an adjournment of the hearing (rule 28). These elements of the FTR
2014 are capable of impacting very adversely on the asylum-seeker's preparation of his case. Ouseley J reasoned
back from the ruling in _DA6 regarding inherent unfairness in the FTR 2014 to conclude that there was similar_
unfairness inherent in the FTR 2005, which had similar features.

52. The appellant has essentially two ways of putting her case. She firstly contends that her appeal should be
allowed because the system created by the FTR 2005 was unfair and the consequence is that the determination of
her appeal was automatically null and void or should be declared or presumed to be null and void because it
possessed some of the features of unfairness identified in DA6. Her second argument is that it operated unfairly in
her case.

53. I reject the first submission for several reasons. The fact that the FTR 2005 were held to be structurally unfair
does not mean that the hearing was unfair when the rules are applied to her particular case. The position is
analogous to saying that an institution is institutionally unfair or biased. An institution can be institutionally unfair or
biased without every single person within it having the same approach or attitude or every single person who comes
into contact with the institution being treated in an unfair or biased way.

54. Lord Dyson MR observed in DA6 that he was in no doubt that tribunal judges would “do their best to comply
with the overriding objective of dealing with appeals justly” (para 38). In at least a proportion of cases, that objective
will have been achieved. TN had a right to a fair hearing, certainly, but not an additional and separate right to a
hearing conducted under a set of rules that was not systemically unfair.

55. In his concurring judgment, with which I agree, Lord Sales emphasises a point which I gratefully adopt and
which on analysis completely undermines the appellant's case: that, because the hearing by the FTT could still be
fair even if the FTR 2005 were ultra vires, the FTT had jurisdiction in a case where the hearing was shown to be
fair. Both Ouseley J (at paras 73 to 75 of his judgment) and Singh LJ (at paras 86 and 87 of his judgment, referring
to jurisdiction in its post-Anisminic sense) made the point that the FTT had jurisdiction despite the invalidity of the
FTR. The appellant's case in this court did not challenge these paragraphs, and in his oral submissions Lord
Pannick implicitly accepted that the FTT had jurisdiction but submitted that its decision was inextricably linked to the
FTR 2005 and so ought to be set aside (see DN (Rwanda), especially para 19).

56. The FTT's jurisdiction is set out in the 2002 Act, and, as Lord Sales points out, in the events which happened
its jurisdiction was solely governed by its obligation to act judicially, that is in this case, to act fairly. Provided that
the FTT was fair in its conduct of the appeal, its decision was accordingly valid. In turn if, because of following the
rules, its determination was unfair, the FTT would have no jurisdiction, and the resultant determination should be
set aside. On this analysis, there is no automatic nullification of the FTT's decision and it is for the appellant to
establish that it ought to be set aside. As to Lord Pannick's submission on DN (Rwanda) referred to in the preceding
paragraph, I accept Mr Tam's submission for the reason he gives (para 47 above) and reject the argument based
on inextricable link.


-----

41

57. Lord Radcliffe considered that a court order (in this case, that would be the tribunal's decision determining TN's
appeal) is valid and binding until it is set aside (see para 28 above). This principle has been acted on for many
years. In relation to judicial decisions, the rationale of the principle must be to bring litigation to an end and to
promote certainty, especially in property and status matters. The principle and its rationale would be undermined if
the consequence of the systemic failings in the FTR were that tribunal decisions were automatically null and void.

58. In this connection, Mr Tam submits that automatic nullification would create great uncertainty for many years to
come, which may in some cases affect not just the appellant but third parties. I accept that submission and hold that
it supports the conclusion to which I have come. It would undermine confidence in the legal system if automatic
nullification were the result, which is one of the reasons why it is in the public interest that there should, at an
appropriate stage, always be finality in litigation.

59. In so far as Lord Pannick's submission on automatic nullification rests on judicial bias cases, I would hold that
these cases are not on all fours with the present one. I can explain my reason for this conclusion by reference to
_Millar v Dickson, on which Lord Pannick principally relied. In that case the Privy Council, in exercise of its devolution_
jurisdiction in relation to Scotland, held that temporary sheriffs, whose contracts were subject to control by the Lord
Advocate, were not independent for the purposes of article 6 of the Convention, and, therefore, that there was
apparent bias. I accept that this was also a systemic issue. The remedy given was to set aside judgments in cases
in which the temporary sheriffs had appeared. Another example, but not of a systemic issue, would be _Serafin v_
_Malkiewicz_ _[2020] UKSC 23; [2020] 1 WLR 2455, a recent decision of this court, where it was held that the decision_
of the judge who had intervened unfairly in a trial should be set aside in its entirety irrespective of the quality of the
judgment on any particular point. In that case, however, the interventions had occurred throughout the hearing.

60. I do not find the analogy with judicial bias cases convincing. It is not always the case that bias on the part of the
judge will result in the trial being declared unfair. It may be that the party waived its right to object, or the defect
complained of may be cured by an appeal hearing (neither of those points of course applies here). The reason for a
strict rule in relation to apparent bias is that there was no way in which the defect could be cured, and it was one
that persisted throughout the hearing. It would be wrong to require the parties to show that there was an actual lack
of independence. In other words, the apparent bias of the temporary sheriffs was a defect which could not be
purged. As Lord Clyde cogently put it in _Millar at para 83: “The independence of the judiciary is not an empty_
principle which can be forgotten simply because one thinks that a correct conclusion has been reached. Rightly or
wrongly, there is always room for an uneasy fear that there might have been some improper influence affecting the
mind of the judge where he lacks independence.” By contrast, it is possible in this instance for the party who wishes
to say that the hearing, attended by both parties, was unfair, to identify the particular respect in which the trial was
not fair to him or her.

61. Mr Tam has further challenged whether the Secretary of State would be prevented from rejecting a decision
made under unfair rules for which the State was responsible, but in the light of my other conclusions it is
unnecessary for me to pursue this point.

62. The appellant has not complained of any particular act in the course of the hearing or about the way the judge
handled the appeal. Likewise, there has been no complaint about the quality of the reasoning in the decision. As
Lord Dyson said, tribunal judges could be relied on to conduct the trials fairly within the rules. TN, therefore, must
show a particular respect in which the rules impacted adversely on her in terms of the conduct of the hearing. There
was no application for any adjournment, and she was represented by counsel. I do not consider that it is enough to
say that features were present in her appeal which were also identified in DA6: she must show that those factors
impacted upon her so as thereby to render the hearing of her appeal unfair. It follows that I would also reject a
presumption that the trial was as a result unfair. The information to show that it was unfair must be in the appellant's
hands.

63. I turn next to Pathan, a case on which Lord Pannick placed heavy reliance. In Pathan, the appellant applied for
leave to remain under Tier 2 of the points-based immigration system, which allows UK employers to recruit skilled
workers to fill a particular vacancy if it cannot be filled with a UK worker. But the employer must be a licensed


-----

41

sponsor and, if his licence is withdrawn, leave to remain will be refused. The applicant in this case made his
application using a valid certificate of sponsorship, but the Secretary of State revoked the licence to give such
certificates before making a decision on Mr Pathan's application and without informing him that his application was
bound to fail. Thus, he had no opportunity to find another sponsor. Mr Pathan did not seek to show that he would
have succeeded in finding a new sponsor. Nonetheless, the court, Lord Briggs dissenting, held that the Secretary of
State should have informed Mr Pathan of its revocation of the licence. It did not matter that it was unlikely that Mr
Pathan could have found another sponsor in the short time available.

64. I accept that Pathan is relevant. The same rules of natural justice can apply to administrative decisions as well
as judicial decisions. But the circumstances are not the same. Mr Pathan could show that he lost an opportunity to
seek a fresh sponsor. If TN could show that, because of the unfairness of the FTR 2005, she lost the opportunity to
develop some part of her then case that she will now be unable to pursue, she would be similarly placed. But she
cannot show that that was so. She has since made what she contended was a _fresh claim “regarding her sex_
trafficking matter” (letter dated 19 August 2015 from Linga & Co to the Yarl's Wood Detention Centre). That is not
the claim that she advanced at the appeal hearing.

65. In determining whether the appellant has shown that the trial was unfair, the court must bear in mind the need
for anxious scrutiny of any asylum claim. It is well established that the decision-maker is not constrained by rules of
evidence and has to consider all material considerations when making an assessment about the future (see
_Karanakaran v Secretary of State for the Home Department_ _[[2000] 3 All ER 449). Bingham LJ observed in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J80-TWP1-613F-00000-00&context=1519360)_
_Secretary of State for the Home Department v Thirukumar [1989] Imm AR 402, 414:_

“It is … plain that asylum decisions are of such moment that only the highest standards of fairness will
suffice.”

66. It is important to analyse carefully whether there was unfairness in the course of the hearing and, if so, whether
that was caused by the FTR 2005 and what the effects of that unfairness were. In this analysis it may be helpful to
follow the methodology in The Right to a Fair Trial in International Law, Clooney and Webb, (Oxford, 2021) which
disaggregates the right to a fair trial into a number of separate elements, such as the right to an independent
tribunal, the right to prepare a defence, the right to adequate time and facilities to prepare a defence, the right to be
present, the right to examine witnesses, the right to an interpreter and so on. A disaggregated analysis may assist
the court to form a clearer view as to the causes, and causative effect, of any departure from what fairness
required. Of course, at the end of the day, the court must look at the matter in the round and determine whether the
hearing, as a whole, was unfair because of the FTR 2005. In that regard the courts can follow the “overall”
approach of the European Court of Human Rights, which was explained by the Grand Chamber of that court in Al_Khawaja and Tahery v United Kingdom (Application Nos 26766/05 and 22228/06)_ _[(2011) 32 BHRC 1 in these](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W1PM-00000-00&context=1519360)_
terms:

“Traditionally, when examining complaints under article 6(1), the court has carried out its examination of
the overall fairness of the proceedings by having regard to such factors as the way in which statutory
safeguards have been applied, the extent to which procedural opportunities were afforded to the defence
to counter handicaps that it laboured under and the manner in which the proceedings as a whole have
been conducted by the trial judge (see, for example, Murray v United Kingdom _[[1996] ECHR 18731/91).”](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X0FY-00000-00&context=1519360)_
(para 144)

67. A careful analysis is called for, remembering always that the asylum claimant does not have to establish his or
her claim to the same standard of proof as a civil claimant (see _Karanakaran, above). But the system is not_
inquisitorial but adversarial. The trial takes place at the hearing, and it is not a continuous fact-finding process which
goes beyond that hearing. The appellant must bring forward his case at the hearing, not subsequently. If he is
prevented from doing so, he should apply for an adjournment.

68. So even where the alleged unfairness stems from the provision of a defective system the court will look at the
impact of the system, and not simply set aside the order without considering the impact.


-----

41

69. In this case, the judge thought that the appellant was really trying to resist the removal directions. Although he
was prepared to annul the Secretary of State's adverse decision on her fresh claim that she had been trafficked on
her second journey to the UK, a claim that still has to be dealt with, he did not consider that the fairness of the
hearing was infected by the defects in the rules.

70. I turn to the question whether there was unfairness in the way her case was dealt with. I agree with what has
been said in this regard by Ouseley J and by the Court of Appeal, who considered the facts in great detail. For TN
to succeed on this part of her appeal she would have to show that they were wrong in law, and in my judgment this
plainly cannot be shown. There were many inconsistencies in her evidence including the date of the death of her
mother, to whom she was clearly close. She had originally said at the time of her first asylum claim that her mother
had died in 1999, but on her second claim she contended that her mother had died in 2003 in prison. She falsely
claimed to have two children in Vietnam, and so on. It is not appropriate for the court to say anything about her
fresh claim.

71. There is a further reason why unfairness in part is not shown. She has a fresh claim that she was trafficked on
her second journey to the UK and in the UK. That claim has yet to be determined and, if she wishes to challenge
the determination of the Secretary of State of that claim, she will be able to do so under a procedure outside the
FTR. In my judgment, that fresh claim operates (if the procedure runs its course) as a rehearing would have done to
remedy any defect in the handling of her trafficking claim. Any defect in the handling of the claim which is reheard
falls by the wayside and is therefore cured by that process: there is no need to set aside the FTT's determination to
allow her to bring her trafficking claim.

72. This case is to my mind an illustration of TN factor 4, as formulated by Singh LJ (see para 5 above). There is
no causal link between the unfairness, which as I see it surrounded the trafficking claim and only that claim, and the
persecution and maltreatment claims. That being so, the determination of the latter should stand. I would also
endorse the non-exhaustive list of _TN factors as giving helpful guidance for future cases. I would also endorse_
Singh LJ's summation of the ultimate issue in para 104 of his judgment. At the end of the day the question is,
subject always to TN factor 1 (which requires a high standard of fairness to be shown: see Thirukumar per Bingham
LJ): was the FTR procedure unfair in the particular case? I consider that this test is less open to the risk of
ambiguity than that proposed by Mr Tam, namely whether the outcome would have been the same under the
ordinary rules applying to appeals, which it is not contended were systemically unfair: what the appellant is entitled
to is a fair hearing appropriate to her claim and it is no answer that the appeal would have failed even if not unfair to
her. If, applying the anxious scrutiny required of any asylum claim, the court or tribunal is satisfied that the hearing
of an appeal was fair to the appellant, it is its duty to say so and dismiss the application to set aside the
determination of any appeal.

**Conclusion**

73. For the reasons given above, I would dismiss this appeal.

LORD SALES: (with whom Lord Lloyd-Jones, Lord Briggs and Lord Stephens agree)

74. I agree that the appeal should be dismissed. I am grateful to Lady Arden for her account of the facts of TN's
case and the process by which Ouseley J came to hold that the Fast Track Rules 2005 (“the FTR 2005”) were
unfair and ultra vires the statutory power under which they were made.

75. In short summary, in _R (Detention Action) v First-tier Tribunal [2015] EWCA Civ 840; [2015] 1 WLR_
5341(“DA6”) the Court of Appeal held that the Fast Track Rules 2014 were ultra vires on the grounds that they were
structurally unfair and unjust. Ouseley J concluded that the FTR 2005 were sufficiently similar in their effect as to
fall within the scope of the reasoning of the Court of Appeal in DA6 and therefore found them to be ultra vires on the
same basis.

76. TN's asylum claim in 2014 was refused by the Secretary of State and she appealed to the First-tier Tribunal
(“FTT”). TN was detained and her appeal was processed and heard within the framework for speedy consideration


-----

41

set by the FTR 2005. By its decision dated 22 August 2014 the FTT dismissed the appeal (“the FTT decision”). In
its reasons, the FTT made various findings adverse to TN and found her account of the circumstances which she
said gave rise to fear of ill-treatment if returned to Vietnam to be incredible. TN did not apply for permission to
appeal against the FTT decision. Pursuant to that decision she remained in detention pending her removal from the
UK.

77. In June 2016, TN was granted permission to apply for judicial review to quash the FTT decision. A claim she
had brought for false imprisonment was stayed pending the outcome of those proceedings. Ordinarily, the way to
challenge the lawfulness of a decision of the FTT is by an appeal to the Upper Tribunal, but that was not a viable
route of challenge in this case because of the lapse of time. The authorities which gave rise to the argument that
the FTR 2005 were ultra vires came after the FTT decision and it was fair that TN should have the opportunity to
challenge that decision by reference to that argument, which meant that judicial review was the appropriate way to
seek to do that.

78. It is common ground in this appeal that an application is necessary to set aside a decision of the FTT, if it is
said to be a nullity and of no effect by reason of the impact of the FTR 2005 being ultra vires: ie in order to establish
by a formal legal process that that is the case.

79. Although the background to this case is complicated, the issues for decision identified in the statement of facts
and issues are within a narrow compass:

(1) Whether the determination of an asylum appeal made under the FTR 2005, such as the FTT decision
in this case, is a nullity and of no legal effect, so that it must on application be quashed for that reason
alone;

(2) If not, what is the correct approach to deciding on application to quash such a determination?; and

(3) On the facts of TN's case, should the FTT decision be quashed?

Discussion

Issue (1): is a decision taken under the FTR 2005 automatically a nullity?

80. The jurisdiction of the FTT to hear and determine an immigration appeal of the kind brought by TN is conferred
by section 82(1) of the Nationality, Immigration and Asylum Act 2002 (“the 2002 Act”), not by the FTR 2005. Section
82(1) provides: “Where an immigration decision is made in respect of a person he may appeal to the Tribunal.”
Section 86 of the 2002 Act sets out the functions of the FTT on an appeal to it: it is obliged to determine the appeal.

81. Singh LJ in the Court of Appeal rightly emphasised (para 83) the conceptual distinction between the question
whether the FTR 2005 were ultra vires and the question whether a decision in an individual case was procedurally
unfair. As he pointed out (paras 84-85), the first question turned on whether the FTR 2005 created an unacceptable
risk of unfairness in a significant number of cases (not in every case). It does not necessarily follow that a decision
taken under the FTR 2005 procedure would be unfair in any particular individual case.

82. Singh LJ set out the critical analysis in the next two paragraphs of his judgment:

“86. I agree with Mr Tam [counsel for the Secretary of State] that 'jurisdiction' to determine the appeals in
the pure or narrow sense of that word (the legal authority to decide a question) existed by virtue of the
primary legislation (section 82 of the 2002 Act) and the FTT was not deprived of jurisdiction in that sense
by reason of the fact that the 2005 Rules were ultra vires. I would also reject Ms Lieven's [counsel for TN]
suggestion that the FTT's jurisdiction was created by the 2005 Rules themselves. She submitted that a
valid appeal required a notice of appeal to be filed in accordance with rule 6 of the Principal Rules, applied
to the fast track process by rule 6 of the 2005 [Fast Track] Rules. In my view, that submission is
misconceived. It is a commonplace feature of an appellate system that there will be procedural rules which
require a notice of appeal to be filed in a certain form. That is not what creates the jurisdiction of a court or


-----

41

tribunal; it is merely a rule which regulates procedure and form. What creates the jurisdiction is the
principal legislation, here the 2002 Act.

87. However, in my view, that would only go so far in meeting Ms Lieven's fundamental submission, which
is that any appeal decision which was made under those Rules was necessarily infected by the fact that
they were unlawful because they created an unacceptable risk of procedural unfairness. It is in that sense
that she submits the FTT did not have jurisdiction, in other words a post-Anisminic [Anisminic Ltd v Foreign
_Compensation Commission [1969] 2 AC 147] understanding of jurisdiction: not in the pure or narrow sense_
of having the legal authority to determine a question, but that a body has acted in a way which is unlawful,
including (for this purpose) in a way which is procedurally unfair. That said, it seems to me that the answer
which Mr Tam gives to that contention is correct: there has to be shown to be procedural unfairness on the
facts of the individual case.”

I think this reasoning is impeccable.

83. In order for the FTT decision to be found to be a nullity, it would have to be established that it was ultra vires in
the sense that it was taken by the FTT without jurisdiction in the wide Anisminic sense. That means that it would
have to be established that it was a decision arrived at outside the jurisdiction conferred by section 82(1) of the
2002 Act. That provision includes as an implied condition that a decision should be arrived at fairly: that means,
fairly in the circumstances of the individual case.

84. Therefore, Ouseley J and the Court of Appeal were right to hold that the FTT decision could not be held to be a
nullity and of no legal effect merely because it had been made under the procedure set by the FTR 2005. They
were right to examine whether the process by which the FTT decision was arrived at was fair in the particular
circumstances of TN's case.

85. Like Lady Arden, I do not consider the analogy which Lord Pannick QC sought to draw with cases involving
apparent bias on the part of judges to be valid or helpful. Every litigant has a right to determination of their dispute
by a judge or tribunal which is impartial and unbiased, meaning free both of actual bias and of any appearance of
bias. In terms of section 82(1) of the 2002 Act, this is a further implied condition for the valid exercise of the
jurisdiction conferred by that provision. If the FTT in TN's case had been biased in fact or had given an appearance
of bias, the FTT decision would fall to be quashed. But there is no suggestion that the FTT was biased or that it
gave any appearance of a lack of impartiality. Quite simply, these points do not support Lord Pannick's contention
that the mere fact that the FTT operated under the procedure set out in the FTR 2005 means that it acted outside
its jurisdiction; rather, they support the alternative analysis set out by Singh LJ.

Issue (2): the correct approach to deciding whether to quash a determination like the FTT decision

86. As Singh LJ pointed out, there is no necessary connection between a determination being made under the FTR
2005 and that determination being arrived at unfairly. Whether a FTT acting under the FTR 2005 procedure acts
unfairly in an individual case will depend upon the particular circumstances of that case.

87. On this issue I consider that the guidance given by Singh LJ later in his judgment is correct:

“103. For the future I would recommend that a court which has to consider an application to set aside an
earlier appeal decision made under the 2005 Rules should approach its task having regard to the
following:- (1) A high degree of fairness is required in this context. (2) What the Court of Appeal said in
_DA6 should be borne in mind: that [by parity of reasoning] the 2005 Rules created an unacceptable risk of_
unfairness in a significant number of cases. Depending on the facts it may be that the case which the court
is considering is one of those cases. (3) There is no presumption that the procedure was fair or unfair. It is
necessary to consider whether there was a causal link between the risk of unfairness that was created by
the 2005 Rules and what happened in the particular case before the court. (4) It should also be borne in
mind that finality in litigation is important. There may be a need to ask how long the delay was after the
appeal decision was taken before any complaint was made about the fairness of the procedure. There may
also need to be an examination of what steps were taken and how quickly to adduce the evidence that is


-----

41

later relied on (for example medical evidence) and whether it can fairly be said that in truth those further
steps were taken for other reasons, such as a later decision by the Secretary of State to set removal
directions. This may suggest that there is no causal link between the risk of unfairness that was created by
the 2005 Rules and what happened in the particular case before the court.

104. The above should not be regarded as an exhaustive checklist. At the end of the day, there can be no
substitute for asking the only question which has to be determined: was the procedure unfair in the
particular case? That has to be determined by reference to all the facts of the individual case.”

88. These points flow from the analysis under issue (1) above. If any person wishes to contend that a decision of a
tribunal, like the FTT, or an inferior court of limited jurisdiction, is unlawful and therefore void and of no effect, they
have to bring forward a case to make good that contention. In the present context, depending on the circumstances
of their case, they may gain some assistance in doing that by referring to the way in which the FTR 2005 had a
practical impact on them and seeking to show that the reasoning in _DA6_ (and as adopted in relation to the FTR
2005 in the present proceedings) indicates that this involved unfairness in the way in which they themselves were
treated. But it is not helpful or appropriate to speak of there being a presumption of unfairness if a decision has
been taken under the FTR 2005, as Lord Pannick sought to do.

89. In relation to the point about finality of litigation, I would emphasise that as in any judicial review proceedings
the expectation is that a claimant will proceed with their case with reasonable promptness after they become aware
or could reasonably be expected to have become aware of the grounds for the claim. TN appears to have done
that, and so was granted permission to apply for judicial review. Claimants who delay without good reason may not
be granted permission to proceed.

Issue (3): Fairness in the circumstances of TN's case

90. Ouseley J examined with utmost care the circumstances of TN's case and the way in which it was considered
by the FTT and concluded that the FTT had acted fairly in making the FTT decision. He summarised the position at
paras 141-142 of his judgment:

“141. I am not persuaded that the appeal decision was unfair. There was no real basis for contemplating
that [TN] was a trafficked woman, in the light of her immigration history, the absence of any indication from
her that she had been trafficked despite her knowledge of the asylum system and the risk of return on the
story she had given. The fact that she had scarring did not, without more, mean that there was a need for a
rule 35 report. She had been seen by the detention centre GP. I agree with Ms Barnes [counsel for the
Secretary of State] that a number of indicators, such as evading authorities, are consistent with not wanting
to be removed from the UK. Merely asking to be removed from the DFT [detained fast track] proves
nothing. So I see nothing in her presentation in the DFT to show that she should not have been in it at all.

142. She was represented throughout by solicitors. She made no application for a rule 35 report. No
adjournment was sought so that an appointment could be obtained with the Medical Foundation for
example. Transfer out was not sought from the immigration judge. No adjournment was sought in order to
obtain medical evidence of any sort. There was no indication either made expressly or noted by the
immigration judge from observation, that the issues which were raised could not be dealt with in that time
frame, or that further evidence, oral or documentary, was awaited or even obtainable. The possible
relevance of what happened on the journey to the UK was not pursued. The immigration judge could
assess the two men present who gave evidence, knowing that one was alleged to be a boyfriend. Such
further evidence as came did not come within the time-frame that the application of the Principal Rules
would have permitted, but was first presented over a year after the appeal decision. There is no basis for
supposing that the evidence would have been relevant to whether her claim as advanced to the SSHD or
on appeal was credible. There is no evidence that she would have presented a completely different claim if
only she had had more time in which to produce medical evidence of the sort she did a year later. I note
what is said in _DA2_ _[2014] EWHC 2525 (Admin) at para 8 that applicants' solicitors said that they were_
often preparing fresh claims before the substantive appeal was finally determined since they anticipated its
receipt b t not q ickl eno gh for the DFT timetable She made no complaint abo t the fairness of the


-----

41

appeal hearing or procedure in her first judicial review proceedings. The further representations leading to
the August decision had provided no evidence that the appeal decision was unfair. It was only in these
judicial review proceedings lodged on 20 August 2015 that the fairness of the appeal proceedings was
raised. Accordingly, I would not have quashed the appeal decision. …”

91. The question for the Court of Appeal was whether he was “wrong” in the assessment he made in applying well
known standards of fairness to the particular facts of TN's case: CPR Part 52.21 and para 129 in the judgment of
Singh LJ. Singh LJ considered (para 130), rightly in my view, that it could not be said that the judge's assessment
was “wrong” in the requisite sense. In arriving at that conclusion, Singh LJ (with the agreement of the other
members of the court) himself reviewed the circumstances of the case with particular care (paras 131-150). As he
pointed out (para 147):

“… the fundamental difficulty for [TN's] appeal is that many of her reasons for not producing evidence are
not attributable to the shortened timetable which was to be found in the 2005 Rules. Instead, they relate to
the receipt of threats from alleged traffickers. It may also be (as the chronology appears to support) that
representations were not made on her behalf until action was prompted by the imminence of removal
directions.”

92. In circumstances where the application of the relevant law to the facts has been examined with such care by
the courts below, I do not think it is properly open to this court to reach a different conclusion on this aspect of the
case. Neither Ouseley J nor the Court of Appeal can be said to have been wrong in their assessment. Indeed, I
agree with what they say.

Conclusion

93. For these reasons, I would dismiss this appeal.

**End of Document**


-----

