# R v Maciejczyk (Damian) [2018] EWCA Crim 2665

CA, CRIMINAL DIVISION

201802674 B1

Goose J, Macur LJ, HHJ Brown

Thursday 25 October 2018

25/10/2018

J U D G M E N T

(Approved)

1. MR JUSTICE GOOSE: This is an application for leave to appeal against conviction by Damian Maciejczyk,
aged 21, from the Crown Court at Liverpool. The application has been referred to the full court by the Registrar.
The applicant's conviction was upon an amended indictment adding count 3, described as living on prostitution,
contrary to section 30(1) of the Sexual Offences Act 1956. After the applicant's plea of guilty he was sentenced to
four months' imprisonment.

2. We have considered the grounds of appeal and the Respondent's Notice and, for the reasons which we shall
explain we grant leave and allow this appeal.

3. The applicant was arrested in November 2017 whilst driving a vehicle in the West Midlands and after being
stopped by the police. On searching the vehicle mobile telephones displayed messages which linked the applicant
to a sex worker. Further enquiries by the police led to the prosecution of the applicant before the Crown Court at
Liverpool. The trial was listed to start on 18 June 2018. The indictment charged him with an offence contrary to
section 2(1) of the **_Modern Slavery Act 2015, being count 1, and an offence of controlling prostitution for gain,_**
contrary to section 53(1) of the Sexual Offences Act 2003 being count 2. The applicant pleaded not guilty and the
jury were sworn. The judge then invited counsel to consider adding a further count of living on prostitution, contrary
to section 30(1) of the Sexual Offences Act 1956. Unfortunately, neither counsel nor the judge, appreciated that the
offence had been repealed by schedule 7 of the Sexual Offences Act 2003. Unaware of this, the court gave leave
to amend the indictment to add count 3, the offence contrary to section 30(1) of the 1956 Act and the applicant
pleaded guilty. No evidence was offered on counts 1 and 2, such that formal verdicts of not guilty were recorded
upon those counts.

4. After the guilty plea, on a written basis, the judge sentenced the applicant to four months' imprisonment.
Subsequently the error was discovered and an application was made by the prosecution to vary the indictment
under the slip rule within section 155 of the Powers of Criminal Courts (Sentencing) Act 2000. The judge correctly
concluded that such a variation was not permissible.

5. On behalf of the applicant, it is argued that the offence to which the applicant pleaded guilty was not known to
law, having been repealed under the 2003 Act, such that this court should quash the conviction. It is also argued
that the formal verdicts of not guilty having been entered on counts 1 and 2 means that no alternative offence can
now be charged.


-----

6. On behalf of the respondent, it is properly conceded that this appeal against conviction should be allowed and
that there is no alternative offence which can be charged. No retrial is sought. It is not necessary, therefore, for this
court to consider which, if any, charges might have been correctly identified on the indictment.

7. It is indeed unfortunate that this error was not identified or corrected before sentence. The judge would have
been better assisted by counsel had careful research been undertaken before the indictment was amended and the
applicant invited to plead guilty. However, the sentence of four months' imprisonment, we are told, meant that the
applicant was released from custody on the day of his sentence. He had been on remand awaiting his trial for the
two offences that were correctly included in the indictment. It means therefore, that the applicant has not been
required to serve any additional time in custody.

8. For these reasons therefore we allow the appeal against conviction and quash both the sentence and conviction.

9. LADY JUSTICE MACUR: We are asked to confirm for the record that the matter is uncontested as the parties
have agreed.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

165 Fleet Street, London EC4A 2DY

Tel No: 020 7404 1400

Email: Rcj@epiqglobal.co.uk

**End of Document**


-----

