# R v BKR [2023] EWCA Crim 903

Court of Appeal, Criminal Division

Lord Justice Edis, Mr Justice Morris and His Honour Judge Lucraft Kc (Sitting As A Judge Of The Court Of Appeal
Criminal Division)

28 July 2023Judgment

**Paul Jarvis (instructed by CPS London, RASSO Unit) for the Prosecution**

**Corinne Bramwell (assigned by the Registrar) for BKR**

Hearing dates : 28 June 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Redacted Judgment**

**for Publication Prior to Trial**

WARNING: reporting restrictions apply to this case. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

The provisions of s.71 of the Criminal Justice Act 2003 apply to these proceedings.  By virtue of those provisions,
no publication may include a report of these proceedings, save for specified basic facts, until the conclusion of the
trial unless the Court orders that the provisions are not to apply.

The Court hereby orders, further to section 71(3) of the Criminal Justice Act 2003 that the provisions of section
71(1) shall not apply to these proceedings in the Court of Appeal to the extent that the content of this redacted
judgment may be published prior to trial.

The provisions of the _[Sexual Offences (Amendment) Act 1992 apply to the offences in this case. Under those](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)_
provisions, where a sexual offence has been committed against a person, no matter relating to that person shall
during that person's lifetime be included in any publication if it is likely to lead members of the public to identify that
person as the victim of that offence.  This prohibition applies unless waived or lifted in accordance with s.3 of the
Act. It has not been waived and applies to all complainants involved in proceedings against this Respondent.

**Lord Justice Edis :**

1. In this case the judge stayed the prosecution as an abuse of the process of the court. The prosecution
now seeks leave to appeal to this court for an order setting that stay aside so that the trial can proceed. It
is accepted that the procedural requirements of s58 of the Criminal Justice Act 2003 have been complied
with and that this court has jurisdiction to entertain the application. We grant leave and will now deal with
the appeal.


-----

2. It is not necessary to set out in any detail the facts of the offence alleged against the Respondent
(BKR). However, it is necessary to give a history of the two sets of proceedings he has already faced, and
their outcomes.

3. BKR was……, and was convicted ………of four counts of sexual assault and two counts of fraud. Each
of the four sexual assault counts alleged an offence against a different complainant. ……….He was
sentenced to eight years' imprisonment …….In those days he was entitled to be released at the halfway
point, and he was released……..

4. As a result of press reporting of that trial, further …..[people] made complaints of similar offences of
sexual assault against them. He was charged with nine further counts of sexual assault ……..he entered
guilty pleas to seven of the nine counts, and not guilty pleas to offences relating to two of the complainants.
A trial of those two counts was fixed……….. It did not take place then because of the suspension of jury
trials at the start of the Covid-19 pandemic.

5. ………..

6. A further hearing took place……... Afterwards [the judge] placed a widely shared comment on the DCS.
The note reads:
Defendant, Prosecution and Defence advocates, and self (in chambers to prevent audio feedback), by
video due to coronavirus pandemic.

Count 3: Defendant arraigned and pleads Not Guilty.[prosecution offers no evidence] and verdict of Not
Guilty entered accordingly.Count 6: ………….Court invites Prosecution to re-consider whether it should
proceed with Count 6, bearing in mind:(a) I am reserving this case to myself, am going to proceed to
sentence on Counts 1, 2, 4, 5, 7, 8 and 9 in the near future, and I indicate that, even if the Defendant is
eventually convicted on Count 6, this will not add to his overall sentence;(b) There is likely to be a long
delay before a trial of Count 6 is possible, as a result of the ever growing backlog of cases awaiting trial
due to the coronavirus pandemic;…………

7. It is clear that the judge was concerned about the impact of the suspension of jury trials on waiting times
for trials, and concerned to ensure that court resources were expended only on trials which were in the
public interest. In the Summer of 2020, all Crown Court judges shared those concerns.

8. The ……..Judge ……..sentenced BKR to 3 years' imprisonment concurrent on each of the seven counts
to which he had entered guilty pleas. The CPS indicated that they intended to proceed with the trial on
count 6 and the trial was listed……. The trial did not take place then because the defence requested that it
should not. It was re-fixed and started ……….but the jury was discharged on the third day because the
judge found that there had been a disclosure failure in relation to material relating to the complainant's civil
claim. There is an outstanding issue as to costs between the parties and we have not considered what
occurred at that trial at all, and express no view about it.

9. ……….., in response to some comments made by…….., ……the trial judge ……., Christina Smith, a
District Crown Prosecutor attached to the London South Rape and Serious Sexual Offences Unit, wrote a
letter in these terms:
I am a District Crown Prosecutor on the Rape and Serious Sexual Offences Unit, London South and I write
to confirm that this case has been reviewed following the comments made by Your Honour on [date].

Your Honour will be aware of the background to this matter and the facts of the case before the Court so I
will not rehearse them. This case has been reviewed on public interest grounds on various occasions and
in considering this decision, reference has been made to the Code for Crown Prosecutors (the Code).

In reviewing this case the Crown have borne in mind paragraph 4.10 of the Code which states that 'It has
never been the rule that a prosecution will automatically take place once the evidential stage is met. A
prosecution will usually take place unless the prosecutor is satisfied that there are public interest factors
tending against prosecution which outweigh those tending in favour'In considering the public interest


-----

factors set out in paragraph 4.9 of the Code, regard has been had to 4.14 a) to g):4.14a How serious is the
offence committed?

…………..

4.14b What is the level of culpability of the suspect?

…………..

4.14c What are the circumstances of and harm caused to the complainant?

…………...

4.14f Is prosecution a proportionate response.?

The Crown has had regard to the cost to the CPS and the wider criminal justice system, especially where it
could be regarded as excessive when weighed against any likely penalty. The Crown have concluded that
the costs of proceeding to trial on this matter are marginal given that the case was to be tried in any event.
Consideration has also been given to the potential penalty and we are aware that if convicted of this count,
no further penalty will be imposed by the Court. In effect, this would mean that a nominal penalty, albeit a
custodial sentence, would be imposed but not such as would affect the overall sentence in accordance with
the totality principle as outlined by the Sentencing Council Guidelines on Offences Taken into
Consideration and Totality. This is accepted by the Crown.However, the Crown submit that whilst no
further penalty will be imposed it is important that justice for the complainant is also seen to be done by the
recognition of the Defendant's wrongdoing being formally recognised by the Court and to ensure that public
confidence in the administration of justice is upheld.Whilst there was a change of circumstance when the
Defendant pleaded guilty to offences involving other complainants, this does not alter the fact that the
points noted above still apply.

Accordingly, the Crown concludes that it remains in the public interest to proceed with the trial.

10. ………[the trial judge] put a widely shared comment on the DCS dealing with various things, and
including this:
Defendant warned that he is not to assume that the trial Judge is bound by the observations about
sentence of previous Judges, if he is convicted.

11. …………………, …… the new trial judge placed a widely shared comment on the DCS as follows:
I wish to record my profound concerns that I am expected to spend 7 days trying this utterly pointless case
about which 3 of my colleagues have recorded their similar concerns as to the intransigent attitude of the
CPS I am now the fourth to do so.I will not start the trial process on Monday (I still have a defence speech
and summing up to finish in any event) until a senior prosecutor attends court and explains to me just why
the CPS justifies the time and public money to be wasted on his pointless exercise. No wonder the backlog
is as big as it is.I endorse …….the view- there will be no additional penalty if he is convicted and I will
consider costs against the CPS if not………..

12. ……[The new trial judge] uploaded a document on to the DCS which set out her reasons for holding
this view, which she summarised in the last paragraph:
I am strongly of the view that this case does not satisfy the public interest test and that the Prosecution
owes a duty to say even more at this stage that the case should not continue.

13. On the same day, ………a letter was sent by the CPS to [the] Judge……., again signed by Christina
Smith. It read:
I am one of the legal managers within the Rape and Serious Sexual Offences Unit, London South. Your
Honour has asked for a senior prosecutor to attend court on …….to explain why the CPS are proceeding
with this prosecution.


-----

I am aware of the history of this case, and I hope that I will be able to address your concerns.
Unfortunately, I cannot attend Woolwich Crown Court in person. I can be present via a CVP link which I
hope will satisfy your requirement for tomorrows hearing.

This case has been reviewed on various occasions and the CPS remain satisfied that according to The
Code, there is sufficiency of evidence, and it is in the Public Interest to proceed as we have a willing victim
who has suffered abuse at the hands of the Defendant.

I hope that Your Honour will give the Crown an opportunity to clarify why proceedings are to continue on
this matter.

14. ………an event [then] occurred in court which the judge indicated was not a hearing. She said:
This is not a public hearing because this is, as it were, a meeting between myself and a representative of
the Crown Prosecution Service. It is, therefore, not a public meeting and the Press and the public are not
invited to join.

15. There followed a conversation, which has been transcribed, between the judge and Ms. Smith which
began with a discussion about whether it was appropriate to refer to the complainant as a “victim” when the
trial had not yet taken place. The judge referred to her document in which she had set out her view of the
public interest and asked Ms. Smith for her response. Ms. Smith referred to the Code for Crown
Prosecutors with its well-known two stage “full code test”. The first stage is the evidential test, which was
clearly met, and the second stage is the public interest test, which was the subject of disagreement
between the CPS and the judge. Ms. Smith's observations focussed on this second part of that test, and
she said that she had considered whether it was in the public interest to continue the prosecution. She
said that the Code required the CPS to consider the seriousness of the offence and that a case of this kind
was serious enough to pursue and she also said that the reviews of cases required by the Covid-19
pandemic did not change the position because of that factor. She emphasised that the offending had had
a serious impact on the complainant who was willing to continue to support the prosecution and to give
evidence. When pressed about the judge's main concern, namely that the trial would consume substantial
public resources and would not result in any additional sentence, Ms. Smith said this:
The Crown did consider the non-recent and nominal penalties and the reason we said that whilst no further
penalty may be imposed, it's important that justice for the complainant is also seen to be done by
recognition of the Defendant's wrongdoing being formally recognised to ensure public confidence that the
administration of justice is upheld. Finally, in relation to the delays because of Covid – those concerns
were the fact that it wouldn't have been a priority listing and there would be a further delay for this matter to
be listed but we are in a position now where we do have the trial listed and we were in a position that it was
hoped that the trial was going to be starting today – yesterday or today. So, I just want to clarify that point
and I apologise if I've come over saying – being belligerent about the defence, which I didn't intend to.

16. Ms. Smith was not on oath and not questioned formally by anyone. Both counsel then made
comments at some length about what Ms. Smith had said and about the history of the proceedings. At the
end of that discussion, there was a hearing in open court. The judge set out her thoughts on the situation
in some detail, but was careful to say that this was not a judgment and that a formal process would be
required. A date was fixed for an application by the defence for the proceedings to be stayed as an abuse
of the process of the court and directions for skeleton arguments given. That hearing took place …..[and]
the judge announced that she would stay the proceedings as an abuse of the process of the court and
gave summary reasons. She handed down a perfected ruling ………giving full reasons.

17. This appeal is brought against that decision.

**The submissions to the judge and her ruling**

18. Counsel for BKR invited the court to stay the prosecution on the ground that in the particular and
unique circumstances of the case it would offend the court's sense of justice and propriety and would bring
the criminal justice system into disrepute.  This is what is known as an application to stay under the
second limb as identified in _R v Horseferry Road Magistrates ex parte Bennett_ [1994] 1 AC 42 at 74G.


-----

Where we refer to the “second limb” or “limb two” in this judgment, that is what we mean. We will refer to
that foundational decision as “Ex. p. Bennett”. On behalf of BKR it was submitted that there had been
unreasonable disregard for and unjustified and inexplicable disapplication of existing prosecutorial policy
and guidance to the extent that it amounted to an abuse of the process of the court and was oppressive
and vexatious (counsel referred to R v A [2012] 2 Cr. App. R. 8 (at [76-86]) and DPP v Humphrys [1977]
AC 1(at [46]).

19. It was submitted that the Crown had failed in its duty to apply the CPS Code of Crown Prosecutors, by
not keeping changing circumstances under review and, more specifically, by not considering the following
competing factors.

i) BKR pleaded guilty to seven of eight counts on the indictment (the prosecution offered no evidence on
the ninth count);

ii) BKR received an 11 year term of imprisonment and had served the custodial element in two tranches;

iii) BKR was on the Sex Offenders Register for life;

iv) …………………..;

v) The cost of a trial necessitating ……witnesses giving evidence over seven to 10 days was substantial;

vi) There were approximately 70,000 outstanding Crown Court cases in the backlog; and

vii) BKR had waited [a long time] ……….for his trial (since arrest) –it was submitted that the Crown
substantially contributed to the delay.

20. The prosecution submitted that the seriousness of the charge in the proceedings warranted the court
exercising its judicial discretion to allow the case to proceed. The complainant was supportive and was
willing to attend court to give evidence in the proceedings. She deserved to have her case tried by a jury.
The Covid-19 pandemic was not considered to be a “change in circumstances” under the Code.

21. In oral argument, Counsel for the prosecution submitted that:

i) The CPS had taken into account the matters to be considered by the Code for Crown Prosecutors and
had followed the Code, but BKR simply did not agree with the decision.

ii) The CPS had been asked to review and reconsider the matter and had done so on every occasion.

iii) On each review, the public interest in pursuing the matter had remained the same, namely:

a) The seriousness of the offence;

b) The level of culpability;

c) The assessment of harm to the community.

iv) The above factors had been considered and answered in a way that was not vexatious, oppressive or
otherwise an abuse of the process;

a) The fact BKR had been in prison twice was not sufficient a reason to stop further action;

b) The likelihood that a conviction would not lead to any greater sentence was not of relevance;

c) On the matter of Covid-19, there had been a review of all the cases and the present case would have
been part of the review.

**The Ruling**

22. The Judge delivered a lengthy ruling in which she set out the submissions she had received, making
comments about their merits along the way. She did not consider that the delays which had occurred were
relevant to her approach to an application to stay the proceedings as an abuse of process of the court of
the kind she was considering. While summarising the submissions, she made it clear that she was dealing
with an Ex p. Bennett second limb application and said this:

-----

The fairness that I am asked to rule on is the process of trial going on at all and not to the way in which any
such trial would be fair in its conduct. The second limb engages separate and perhaps more abstruse
concepts, e.g. 'offend the Court's sense of justice and propriety, undermine public confidence in the
criminal justice system'. The judiciary accept a responsibility for the maintenance of that and it embraces a
willingness to oversee executive action and to refuse to countenance behaviour that threatens either basic
human rights or the rule of law. At the heart lies perhaps what is more simply expressed as the concept of
fairness, the law. I quote in extenso 'In the second category of case the Court is concerned to protect the
integrity of the criminal justice system'. Here, a stay will be granted where the Court concludes that in all
the circumstances a trial will offend the Court's sense of justice and propriety per Lord Lowry in _R v_
_Horseferry Road Magistrates ex parte Bennett [1994] 1 AC 42 at 74G, 'or will undermine public confidence_
in the criminal justice system and bring it into disrepute, per Steyn L in R v Latif [1996] 1WLR 104 at 112F
cited in the judgment of Lord Dyson in R v Maxwell [2011] 1 WLR 103.

23. In the judge's view, the case was not about the delays on either side or the problems which had
delayed the case. She did not seek to rely on attributing blame for these various failures. The judge's
concern with the case was the matter of sentence at the end of any trial. Any trial would be held after a
long period of time since the first complaint. The six other counts on the indictment were dealt with
appropriately with six concurrent sentences. No challenge had been mounted either as to the excessive
nature of the sentence, and more pertinently, no challenge to its inadequacy. The totality of 11 years
reflected serious sexual assaults on 11 occasions.

24. The judge observed that the usual course of events for such cases was disrupted in July 2020 by the
Covid-19 pandemic. ……………..

25. There were cases where the public interest demanded further trials in order to underline the
unacceptable nature of such actions, for example the protection of prison officers. However, they were
limited in number and the judge did not regard the present case as falling within that limited category.

26. The judge said that it was uncontroversial that the rights of the complainant, who may or may not
ultimately be a victim, were important, relevant and needed careful sensitive consideration. She then
examined the situation of the complainant in a passage to which we will return at the end of this judgment.

27. The judge concluded her ruling with this passage:
“Finally, I come to the context of this case, the continuing effect of Covid and the CPS's own guide
specifically drafted to deal with perceived problems. It is extraordinary that the initial stance by the
prosecution is that Covid is not a change in circumstances. It is one of the biggest and most challenging
changes to the criminal justice system of recent times. I need do no more than refer to that guidance and
say that this case is a paradigm example of the need to address the effects of pursuing cases such as this
in a system in which thousands of Defendants and victims are still waiting significant periods for their day in
court and have 'their story told'. Instead, the CPS have chosen this case to continue, a case which will
achieve nothing by way of further sanctions or protection of the public. I have addressed this case
throughout through the medium of the code and the guidance and have borne well in mind the
prosecution's submission to the effect that this is not judicial review by the back door. I have concerns as to
just what considerations have been given to matters on which I am assured have been looked at, reviewed
and decided upon.

“The question that this Court can and must determine is whether with all the careful and proper
consideration, as a result, a decision to pursue a trial is one not merely unpalatable to the Defendant but
which offends the Court's sense of fairness. Does it offend because it discloses no reason to proceed
beyond an apparent desire to satisfy [the complainant's] desire for her day in court? Does it offend because
it discloses no reason to proceed beyond securing conviction, and does it offend because it does so to the
detriment of thousands of other cases in the face of its own guidance? I answer unhesitatingly and with
certainty that this is vexatious and oppressive. It is unfair and should be stayed as an abuse of the process
of this Court. That is dated today's date.”

**Grounds of Appeal**


-----

28. The prosecution say that the decision to stay the proceedings involved an error of law;

i) in the approach to the test being applied; and

ii) in her identification of the factors that she considered to be relevant to the application of that test, with
the result that she exceeded the bounds of her power.

**Grounds of Opposition**

29. BKR submits that:
i) There was no error of law, and no such error is identified by the applicant.

ii) The Judge applied the correct test in accordance with limb 2, namely, whether in all the circumstances a
trial would offend the court's sense of justice and propriety or would undermine the public confidence in the
criminal justice system and bring it into disrepute (R v Maxwell [2011] 1 WLR 1837, para. 13)

iii) The Judge was scrupulous in her approach to the application of the test.

30. These arguments were developed with skill before us by Mr. Jarvis for the prosecution and Ms.
Bramwell for BKR. We will not summarise their arguments, but we will deal with the main points below.

**The Relationship Between the Prosecution and the Court**

[31. The Crown Prosecution Service (CPS) was established by the Prosecution of Offences Act 1985 and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6130-TWPY-Y1D7-00000-00&context=1519360)
that Act imposes substantial duties for the conduct of prosecutions on the Director of Public Prosecutions
under the superintendence of the Attorney General. The Attorney General is accountable to Parliament.
By section 10 of the Act the Director of Public Prosecutions must publish a Code for Crown Prosecutors.
This gives guidance to prosecutors when deciding whether to bring or continue proceedings.

32. In DPP v Humphrys [1977] AC 1, a case cited to the judge, Lord Salmon said this:
I respectfully agree with my noble and learned friend, Viscount Dilhorne, that a judge has not and should
not appear to have any responsibility for the institution of prosecutions; nor has he any power to refuse to
allow a prosecution to proceed merely because he considers that, as a matter of policy, it ought not to have
been brought. It is only if the prosecution amounts to an abuse of the process of the court and is
oppressive and vexatious that the judge has the power to intervene. Fortunately, such prosecutions are
hardly ever brought but the power of the court to prevent them is, in my view, of great constitutional
importance and should be jealously preserved. For a man to be harassed and put to the expense of
perhaps a long trial and then given an absolute discharge is hardly from any point of view an effective
substitute for the exercise by the court of the power to which I have referred.

33. In R.v H(S) [2010] EWCA Crim 1931 the Court of Appeal expressed the classic approach to judicial
involvement in prosecution decisions to charge or continue proceedings. Leveson LJ, giving the judgment
of the court, said this at [60]:
We must make it clear that we do not suggest that a judge has no right to express his views about a
proposed prosecution or about the way in which the CPS should exercise the discretion vested in it by
Parliament. There is a long tradition of judges doing just that and of the CPS reconsidering the position
when they do; in our experience, both at the bar and on the bench, proper and appropriate respect has
always been paid to any expression of judicial views. Judge Shorrock, however, went beyond moderately
expressing his views. He sought, quite wrongly, to impose them in a way that paid no attention to the fact
that it is the CPS in which the statutory discretion is vested. He did so because of his view about the use of
resources and it is to that topic that we now turn.

**Abuse of Process**

34. The power of a criminal court to stay a prosecution as an abuse of the process of the court is an
important one, but it is not unlimited. Its existence and scope was the subject of disagreement between
the judges in Humphrys, but that was settled in Ex p. Bennett subsequently. It has since been developed
and refined by the Privy Council and the Supreme Court. Ex p. Bennett explains that there are two species


-----

of abuse of process (or “limbs”) which justify a court ordering a stay of criminal proceedings. The first is
that a fair trial is not possible. There is little that needs to be said about that. If the court concludes that
the trial under consideration will not be fair, then it will prevent it from happening. The second limb
therefore does not arise unless the defendant, charged with a criminal offence, will receive a fair trial. It
seems clear that something out of the ordinary must have occurred before a criminal court may refuse to
try a defendant charged with a criminal offence when that trial will be fair.

35. In R v. Norman (Robert) [2016] EWCA Crim 1564 Lord Thomas of Cwmgiedd, giving the judgment of
the court, summarised the position in this way:
**Abuse of process**

**21 It is well established that the court has the power to stay proceedings in two categories of case, namely**
(i) where it will be impossible to give the accused a fair trial, and (ii) where it offends the court's sense of
justice and propriety to be asked to try the accused in the particular circumstances of the case (R v
_Maxwell_ _[2010] UKSC 48; [2011] 1 WLR 1837, per Lord Dyson SCJ at para 13). We are concerned with_
the second category. It is not suggested that the defendant's trial was in any way unfair.

**22 Within the second category fall cases where the police or prosecuting authorities have been engaged in**
misconduct in bringing the accused before the court for trial. In such cases the court is concerned to
protect the integrity of the criminal justice system. A stay will be granted where the court concludes that in
all the circumstances a trial will offend the court's sense of propriety and justice (per Lord Lowry in _R v_
_Horseferry Road Magistrates' Court, Ex p Bennett [1994] 1 AC 42, 74G) or will undermine confidence in the_
criminal justice system and bring it into disrepute (per Lord Steyn in R v Latif [1996] 1 WLR 104, 112F).

**23** This involves a two-stage approach. First it must be determined whether and in what respects the
prosecutorial authorities have been guilty of misconduct. Secondly it must be determined whether such
misconduct justifies staying the proceedings as an abuse. This second stage requires an evaluation which
weighs in the balance the public interest in ensuring that those charged with crimes should be tried against
the competing public interest in maintaining confidence in the criminal justice system and not giving the
impression that the end will always be treated as justifying any means. How the discretion will be exercised
will depend upon the particular circumstances of each case, including such factors as the seriousness of
the violation of the accused's rights; whether the police have acted in bad faith or maliciously; whether the
misconduct was committed in circumstances of urgency, emergency or necessity; the availability of a
sanction against the person(s) responsible for the misconduct; and the seriousness of the offence with
which the accused is charged. These are merely examples of factors which may be relevant. Each case is
fact specific. These principles were reaffirmed by the Privy Council in Warren v Attorney General for Jersey

_[2011] UKPC 10; [2012] 1 AC 22, in which the Board upheld a refusal to stay a prosecution for serious_
drugs offences where the police had acted unlawfully in foreign jurisdictions and deliberately lied to the
foreign authorities, the Attorney General and Chief of Police, in order to obtain incriminating recordings of
conversations in a car without which no prosecution would have been possible.

36. It will be noted that four decisions of the House of Lords, Privy Council or Supreme Court are cited as
authority for these propositions. The then Lord Chief Justice was not seeking to develop the law: he was
stating it. The court decided that the Metropolitan Police had not misconducted themselves in the way
alleged, but that even if they had the level of seriousness of such misconduct fell short of what would
require the proceedings to be stayed. Describing the balance which the law requires a court to draw in
determining an application for a stay in an _Ex p. Bennett_ second limb case, Lord Thomas said this at
paragraph [40]:
The sole ground for a stay is that despite his ability to have a fair trial, despite the powerful public interest
in serious crime being prosecuted and public officials standing trial for corruption, and despite the public
harm caused by his conduct which is an ingredient of this offence, the conduct of the police was so
egregious that his prosecution offends the court's sense of propriety and justice or undermines confidence
in the criminal justice system so as to bring it into disrepute. The conduct of the MPS in this case comes
nowhere near justifying such a conclusion.


-----

37. The Supreme Court in _R v. Maxwell_ _[2010] UKSC 48, [2011] 2 Cr. App. R. 31 were considering an_
appeal against an order by the Court of Appeal Criminal Division for a retrial following the quashing of a
conviction for murder on the ground of misconduct by the police in the investigation of the crime. Although
there are differences between the statutory test for an order for retrial and the common law test for a
second limb abuse of process, there were parallels. Lord Dyson, with whom Lord Rodger and Lord Mance
agreed, conducted a review of that common law test. It is narrower than the test “what do the interests of
justice require”, see paragraph [21]. This decision adopted the “settled law as expounded by Lord Steyn in
_Latif” see [16]. At [13]-[14] Lord Dyson said:-_

13. ……….In the second category of case, the court is concerned to protect the integrity of the criminal
justice system. Here a stay will be granted where the court concludes that in all the circumstances a trial
will offend “the court's sense of justice and propriety” (per Lord Lowry in R. v Horseferry Road Magistrates'
_Court Ex p. Bennett_ (1994) 98 Cr. App. R. 114 at 135; [1994] 1 A.C. 42 at 74) or will “undermine public
confidence in the criminal justice system and bring it into disrepute” (per Lord Steyn in R. v Latif [1996] 2
Cr. App. R. 92 at 100; [1996] 1 W.L.R. 104 at 112).

14. In Latif at 101 and 112, Lord Steyn said that the law in relation to the second category of case was
“settled”. As he put it:

“The law is settled. Weighing countervailing considerations of policy and justice, it is for the judge in the
exercise of his discretion to decide whether there has been an abuse of process, which amounts to an
affront to the public conscience and requires the criminal proceedings to be stayed: R. v Horseferry Road
_Magistrates' Court Ex p Bennett (1994) 98 Cr. App. R. 114; [1994] 1 A.C. 42. Ex p. Bennett was a case_
where a stay was appropriate because a defendant had been forcibly abducted and brought to this country
to face trial in disregard of extradition laws. The speeches in _Ex p. Bennett conclusively establish that_
proceedings may be stayed in the exercise of the judge's discretion not only where a fair trial is impossible
but also where it would be contrary to the public interest in the integrity of the criminal justice system that a
trial should take place. An infinite variety of cases could arise. General guidance as to how the discretion
should be exercised in particular circumstances will not be useful. But it is possible to say that in a case
such as the present the judge must weigh in the balance the public interest in ensuring that those that are
charged with grave crimes should be tried and the competing public interest in not conveying the
impression that the court will adopt the approach that the end justifies any means.”

38. Later in the judgment, Lord Dyson considered a decision of the Court of Appeal in R v. Grant [2005] 2
Cr. App. R. 28. In that case, the Court held that a prosecution for murder should be stayed where the
police had engaged in unlawful covert surveillance of privileged consultations between the defendant and
his lawyers. The product of that surveillance was not adduced in evidence and there was no evidence to
suggest that it had any impact on the trial process at all. Lord Dyson said in _Maxwell_ at [28] “like Lord
Brown, I have considerable reservations as to whether that case was correctly decided.” Lord Brown
dissented in the result, along with Lord Collins, but the criticism of Grant was unanimous.

39. The Privy Council in Warren and others v. Attorney General for Jersey [2012] 1 AC 22carried out an
important analysis of this jurisdiction, relying on and developing the analysis in Maxwell. Lord Dyson gave
the judgment of the Board with which all the justices agreed. This involved a decision about whether the
second limb requires some unfairness to the defendant. It does not. Lord Dyson said:
35. The Board does not accept this criticism of R v Grant. The second category of case where the court
has the power to stay proceedings as an abuse of process is, as already stated, one where the court's
sense of justice and propriety is offended if it is asked to try the accused in the particular circumstances of
the case. It is unhelpful and confusing to say that this category is founded on the imperative of avoiding
unfairness to the accused. It is unhelpful because it focuses attention on what is fair to the accused, rather
than on whether the court's sense of justice and propriety is offended or public confidence in the criminal
justice system would be undermined by the trial. It is confusing because fairness to the accused should be
the focus of the first category of case. The two categories are distinct and should be considered separately.

40. _Grant_ was nevertheless wrongly decided. There was serious misconduct by the police, but on a
balancing exercise which included the fact that it had no impact on the trial at all the trial judge's decision to


-----

refuse a stay was plainly open to him and should not have been reversed on appeal. This means that
grave executive misconduct will not necessarily be sufficient to result in a stay. One question raised in the
present case is whether it is necessary.

41. In this case, the prosecution was stayed as an abuse of process because the prosecution insisted on
proceeding with a case which the judge described as “pointless” in her first widely shared comment on

[date]. There was a realistic prospect of conviction, and the trial would be fair. The judge thought that the
process was pointless because no additional sentence would be imposed. If prosecutorial misconduct is
required for a stay in limb two abuse cases, then this case would appear to involve quite a low level of
executive misconduct if indeed it could properly so described at all. The passage in Latif where Lord Steyn
observed that an infinite variety of cases might arise and that general guidance would not be useful
suggests that there are no hard rules. But the nature of this jurisdiction is founded on the public interest in
maintaining public confidence in the criminal justice system and preventing it from being brought into
disrepute. The court's sense of justice and propriety is engaged. The abuse of process must amount to an
“afront to the public conscience”. See paragraphs [22] and [23] of Warren set out above, and the collection
of extracts from Ex p. Bennett and Latif there cited. It is not the law that any decision to prosecute by a
Crown Prosecutor with which the judge does not agree amounts to a sufficient affront to the court's sense
of justice to enable the court to stay the proceedings.

42. The need to identify some executive misconduct in most limb two cases requires consideration of
three further cases, all decided by the Court of Appeal Criminal Division. The first is R v. Rangzieb Ahmed

_[2011] EWCA Crim 184, decided before Warren and Maxwell. Lord Justice Hughes, giving the judgment of_
the court, said:
24. There is no doubt about the jurisdiction to stay for abuse of process. It applies where the trial process
will be internally unfair (Attorney-General's Reference No 1 of 1990 (1992) 95 Cr App R 296), but it is not
limited to such cases. It may be exercised also where, by reason of gross executive misconduct
manipulating the process of the court, the defendant has been deprived of the protection of the rule of law
and it would as a result be unfair to put him on trial at all. That was clearly established by R v Horseferry
_Rd Magistrates Court ex p Bennett [1994] 1 AC 42and R v Mullen [1999] 2 Cr App R 143. In both cases the_
defendant had been kidnapped abroad and brought into this jurisdiction by an unlawful rendition, to which
the British authorities were party. In both those cases, however, there was a clear link between the abuse
of power on the part of the executive/prosecution and the trial; the trial was the very object and result of the
unlawful abuse of power. Thus, in those cases it is properly said that not only is the misconduct of the
executive an affront to the public conscience, but also, and critically, that the trial itself is such an affront.
The first is not a sufficient ground for a stay, but the second is; the jurisdiction does not exist to discipline
the police or other executive arms of the State (although of course it will incidentally do so), but rather to
protect the integrity of the processes of justice. In R v Grant _[2005] EWCA Crim 1089; [2005] 2 Cr App R_
28 at 409 the police had deliberately and unlawfully eavesdropped on and recorded privileged
conversations between a suspect and his lawyer. This court held that a stay should be imposed in
consequence even without there being any product of the listening giving rise to evidence relied on at trial.
We are bound by that decision, albeit that it appears to represent some extension of the jurisdiction……..
We also accept that the jurisdiction to stay may, in certain circumstances, be invoked where to try a
defendant would involve a breach by this country of a specific international obligation not to do so: see for
example R v Uxbridge Magistrates Court ex p Adimi [2001] QB 667, considered in R v LM & others _[2010]_
_EWCA Crim 2327. In those cases also, however, there was the clearest link between the trial itself and the_
international obligation; to undertake the former involved a direct breach of the latter. It does not at all
follow that in every case in which it is suggested that there has been a breach by the UK of an international
obligation in respect of an individual, that individual becomes exempt from prosecution, and (if guilty)
punishment, for an offence which he has committed.

43. The reason for citing this passage, which has been overtaken in two respects by Warren and Maxwell,
is the emphasis on the importance of a class of case where the executive is proposing to prosecute a
defendant in breach of a specific international obligation not to do so. This is instructive when considering
the next two decisions of the Court of Appeal, which arise in the context of the United Kingdom's


-----

international obligations not to prosecute victims of **_Modern Slavery. In_** _R v. AAD, AAH & AAI_ _[[2022]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
_[EWCA Crim 106 the Court of Appeal reviewed the history of the abuse of process in the modern slavery](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
context, and found that the jurisdiction to stay such cases continued notwithstanding the enactment of a
statutory defence in section 45 of the **_Modern Slavery Act 2015. The court cited this extract from_** _R v_
_[M(L)[2011] EWCA Crim 2327; [2011] 1 Cr. App. R. 12, Hughes LJ giving the judgment of the court:-](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:542M-MGR1-F0JY-C214-00000-00&context=1519360)_

“……..The treaty obligation which we are considering under art.26 is not an obligation to grant immunity,
but rather an obligation to put in place a means by which active consideration is given to whether it is in the
public interest to prosecute. We accept that the power to stay for "abuse" exists as a safety net to ensure
that this obligation is not wrongly neglected in an individual case to the disadvantage of the defendant.”

19. We make it clear that the occasions for the exercise of this jurisdiction to stay ought to be very limited
once the provisions of the Convention are generally known, as by now they should be becoming known.
Moreover, the jurisdiction to stay does not mean that the court is entitled to substitute its own view for that
of the prosecutor upon the assessment of the public policy question whether a prosecution is justified or
not. The power to stay is a power to ensure that the Convention obligation under art.26 is met. The
Convention obligation is to provide for the possibility of not imposing penalties on victims for their
involvement in unlawful activities to the extent that they have been compelled to do so. Thus the
Convention obligation is that a prosecuting authority must apply its mind conscientiously to the question of
public policy and reach an informed decision. If it follows the advice in the earlier version of the guidance,
set out above, then it will do so. If however this exercise of judgment has not properly been carried out and
would or might well have resulted in a decision not to prosecute, then there will be a breach of the
Convention and hence grounds for a stay. Likewise, if a decision has been reached at which no reasonable
prosecutor could arrive, there will be grounds for a stay. Thus in effect the role of the court is one of review.
The test is akin to that upon judicial review.

44. The decision in _AAD, AAH & AAI_ was followed and explained in the third decision which requires
consideration, _R v. AFU [2023] EWCA Crim 16. The court in that case rejected a suggestion that_ _AAD,_
_AAH & AA_ was promoting a fundamentally different approach to that adopted previously by the courts
when determining whether or not there has been an abuse of process. Carr LJ, giving the judgment of the
court, said at [117]:
The court in AAD was not saying that the review is to be carried out strictly on public law grounds. Rather,
it referred to assessment by way of review on grounds "corresponding to public law grounds". This echoes
the statement in R. v LM at [18] where the court stated that the test was "akin to that upon judicial review".
Nor was _AAD_ breaking new ground in terms of the approach to be adopted when considering whether
there has been an abuse of process.

45. The relevance of these decisions to the present case is because they explain the nature of a review in
the Crown Court “akin to judicial review” which might properly lead to a stay of proceedings as an abuse of
the process of the court. At [110] and [115] of _AAD, AAH & AAI_ Lord Justice Fulford summarised the
question being decided in this way:
“110. Does it remain possible, therefore, following the introduction into law of the defence under section 45
(see [64] above), for a defendant to argue (whether at trial before the judge in the absence of the jury or on
appeal) that the prosecution was an abuse of process by reason of a failure on the part of the prosecution
to apply its own policy guidance.

115. The question, therefore, is whether this residual jurisdiction (in practice only to be exercised in very
limited circumstances, as all the authorities indicate) survives the introduction of the 2015 Act.”

46. The court was inclined to resist suggestions that this jurisdiction was special or unusual, but did so in
terms which emphasise its context. Paragraph [117] says this:
“Moreover, although the abuse of process jurisdiction in this context has sometimes been described as
"special" or "unusual" that is, in our judgment, only really so, in substance, just because of the context. (We
say this subject to our comments below at [137] on [17] of L(C)). After all, any abuse of process argument


-----

has to take into account the context: and here such context necessarily includes the international
obligations relating to VOTs and to the very sensitive issues arising with regard to VOTs.”

47. What perhaps underlines this conclusion is that the court did not find it necessary to engage in detail
with the usual test for Ex p. Bennett limb two abuse of process. It summarised that test at [111] as:
“to the broad effect that it [arises if] it is unfair and oppressive that a defendant should be tried”.

48. This summary is not wholly consistent with the decisions of the House of Lords, Privy Council and
Supreme Court referred to above. The reference to unfairness may at first sight be at odds with paragraph

[35] of Warren.  The word “oppressive” appears in some of the authorities, but Ex p. Bennett, Warren, and
_Maxwell taken together show that the test for limb two abuse involves consideration of other factors beside_
the impact on the defendant. Those factors were described by Professor Andrew L-T Choo in _Abuse of_
_Process and Judicial Stays of Criminal Proceedings 2[nd] ed (2008) in a passage cited in Warren at [24] and_
described by Lord Dyson as “a useful summary of some of the factors that are frequently taken into
account by the courts when carrying out the balancing exercise referred to by Lord Steyn in R. v. Latif:
“The courts would appear to have left the matter at a general level, requiring a determination to be made in
particular cases of whether the continuation of the proceedings would compromise the moral integrity of
the criminal justice system to an unacceptable degree. Implicitly at least, this determination involves
performing a “balancing” test that takes into account such factors as the seriousness of any violation of the
defendant's (or even a third party's) rights; whether the police have acted in bad faith or maliciously, or with
an improper motive; whether the misconduct was committed in circumstances of urgency, emergency or
necessity; the availability or otherwise of a direct sanction against the person(s) responsible for the
misconduct; and the seriousness of the offence with which the defendant is charged.”

49. At [120] of _AAD, AAH & AAI_ the court dealt with the decisions concerning the availability of judicial
review of decisions to prosecute. They said this about the availability of a judicial review type of remedy in
the Crown Court:
“This aligns with the principle, summarised helpfully in Blackstone's Criminal Practice 2022 at [D2.22] that,
generally speaking, a decision to prosecute is not susceptible to judicial review in the Administrative Court
because it may be challenged during the trial process itself, most particularly by an application to stay the
proceedings on the grounds of abuse of process. As the editors observe, arguments relating to abuse of
process may and should be raised in the course of the criminal trial itself save in wholly exceptional
circumstances.”

50. In our judgment it does not follow from the proposition that judicial review of decisions to prosecute is
only rarely available because there are processes available in criminal trials that those processes must be
expanded so that they offer a public law remedy as if judicial review were available widely. The test for
limb two abuse is clearly established on the highest authority, including in the particular context of
international treaty obligations, and it is not open to the Crown Court to broaden its jurisdiction to include all
public law remedies in the ordinary domestic criminal case where it wishes to quash a decision to
prosecute with which it disagrees.  The Crown Court process affords remedies to a defendant which are
either derived from the common law or statute. The availability of these remedies has an effect in limiting
the scope for judicial review in this context. It does not follow that these remedies precisely duplicate
judicial review in the ordinary case. The particular context of **_modern slavery cases does require an_**
examination of the basis of decisions to prosecute where they may involve a breach of an international
treaty obligation, and where also they may involve a failure to respect a conclusive grounds decision which
may involve a judicial decision on appeal to the First Tier Tribunal. Other cases, lacking those features, do
not.

**Decision and discussion**

51. In this case there is no doubt that the judge was quite entitled to express her views on the proper
application of the public interest test. We would suggest that many Crown Court judges, faced with the
backlog of serious and important cases waiting to be tried, would probably agree with her that this


-----

prosecution was not in the public interest. Each member of this court, if sitting at first instance, would have
taken steps to ensure that the decision to continue with the case had been taken at an appropriately senior
level and after proper consideration of the Code for Crown Prosecutors.

52. However, it does not follow from this that the continued prosecution was an abuse of the process of
the court. The powers of the court to stay a prosecution as an abuse of process are a very important part
of the jurisdiction of the criminal courts, but they are limited and a stay is an exceptional remedy. The
courts must exercise care and restraint in their use, particularly where the issue is a decision to prosecute
a case to trial. That decision is entrusted by Parliament to the CPS and it is, in the ordinary case, no part
of the function of a judge to say who should be prosecuted and who should not be.

53. In our judgment, the proper analysis of the judge's decision should start from a clear finding that this
kind of case does not involve misconduct by the executive of the kind which might fall within the second
limb of abuse of process as defined by the House of Lords in _Ex p. Bennett. The CPS has reached a_
decision after consideration of the Code with which the judge strongly disagreed. The basis of the decision
was set out in the letter of [date], and repeated by Ms. Smith on [date]. There is no suggestion of bad faith,
or deliberate abuse of power. Neither can it be said that the CPS has simply ignored its Code. We have
set out quite extensive citations from the leading decisions in order to identify the kind of conduct which
might lead a court to stay a prosecution for abuse of process on this ground. To adopt the words of Lord
Thomas quoted at [34] above, “The conduct of the [CPS] in this case comes nowhere near” justifying a
conclusion that the prosecution offends the court's sense of propriety and justice or undermines confidence
in the criminal justice system so as to bring it into disrepute.

54. If the case does not disclose misconduct of the relevant type, is there a route to a finding of abuse of
process by a process “akin to judicial review” as applied in _AAD, AAH & AAI_ in the **_modern slavery_**
context? As explained at [43] above decisions to prosecute which place the United Kingdom in breach of
an international treaty obligation may fall within the Ex. P. Bennett second limb. The unlawful extradition or
rendition cases, such as _Ex. P. Bennett_ itself and _R v. Mullen_ [1999] 2 Cr App R 143 involve serious
[misconduct by the executive for this reason. R v. M(L) [2011] EWCA Crim 2327 is referred to at [43] above](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:542M-MGR1-F0JY-C214-00000-00&context=1519360)
and was cited with approval by the Court of Appeal in _AAD, AAH & AAI,_ as identifying what that court
described at [115] as a:
“..residual jurisdiction (in practice only to be exercised in very limited circumstances, as all the authorities
indicate).

55. It is clear from the extracts from R v. M(L) cited above that the origin of the power to stay is the Council
of Europe Convention on Action Against Trafficking in Human Beings 2005, ratified in December 2008 ("the
CE Convention"), and the EU Directive 2011/36 on Preventing and Combating Trafficking in Human Beings
("the EU Directive"). Hughes LJ put the matter with complete clarity at [19]
“The power to stay is a power to ensure that the Convention obligation under art., 26 is met.”

56. Lord Judge in the subsequent decision in R v. N; R v. Le [2012] EWCA Crim 189 at [16] confirmed the
point in a passage also cited with approval in AAD, AAH & AAI at [114]:
"In any case where it is necessary to do so, whether issues of trafficking or other questions arise, the court
reviews the decision to prosecute through the exercise of the jurisdiction to stay. The court protects the
right of the victim of trafficking by overseeing the decision of the prosecutor and refuses to countenance
any prosecution which fails to acknowledge and address the victim's subservient situation, and the
international obligations to which the United Kingdom is party…”

57. In the present case no question of any breach of any international treaty obligation arises. In our
judgment, the decision in AAD, AAH & AAI should not be read as conferring a jurisdiction comparable to
that of the administrative court in judicial review in all cases to review on public law grounds the charging
decision which has been made. Hughes LJ in R v. M(L) put the general position at [15]:
“The availability of the ultimate sanction of a stay of proceedings on grounds of abuse was common ground
before us, and is thus accepted by the Director of Public Prosecutions. We do not disagree that it is, in


-----

certain limited circumstances, available, but the limitations upon the jurisdiction must be understood.
Criminal courts in England and Wales do not decide whether a person ought to be prosecuted or not. They
decide whether an offence has been committed. They may, however, also have to decide whether a legal
process to which a person is entitled, or to which he has a legitimate expectation, has been neglected to
his disadvantage.”

58. We therefore hold that the exercise on which the judge embarked was one which was not properly
open to her. She engaged in a review of the decision-making process of the CPS in circumstances where
no reasonable judge could find that it was capable of constituting misconduct of the kind which justifies a
stay of a prosecution as an abuse of process in the second limb of Ex. p. Bennett.

59. The judge gave a careful and considered ruling. Her decision focussed on the fact that no additional
penalty would be imposed in the event that the defendant were convicted after a trial on the single
remaining outstanding count. She considered that a conditional discharge was the likely outcome, and that
a seven day trial was not justified in those circumstances. She said that this was the result of the decision
to sentence for the offences where the defendant had pleaded guilty in advance of the trial for the
outstanding count. This was the reverse of the normal practice. It was appropriate because of the delays
caused by Covid-19. She said that this was the “serious central and obvious objection to this trial
proceeding”. She concluded that the CPS had failed to address it or to give it weight. She described their
reasons for continuing as “rather troubling”. These were that the offence was serious and the interests of
justice required that the complainant should be given the opportunity to have her allegation tried and
determined by a jury. This would provide some public recognition of the wrong she says she suffered.
She would be able to “tell her story”. In dealing with this approach, the judge moved on to a passage
which appears to question the motives of the complainant who she describes as “an enigma” who had not
made her complaint soon after the alleged event. …………….. It is not entirely clear what role this
passage played in the judge's reasoning. She made no finding that it was irrational for the CPS not to take
these matters into account in deciding where the public interest lies and there is no basis on which such a
finding could be justified. These reflections on the complainant and her motives were, therefore, irrelevant
but yet they seem have been given some weight. Why otherwise mention them?

60. Prosecutors are required to consider seven factors identified at paragraph 4.14(a)-(g) of the Code.
The first of these is the seriousness of the offence and the second is the culpability of the suspect. There
is no doubt that this allegation passes those tests comfortably. The third (sub-paragraph (c)) and sixth
(sub-paragraph (f)) factors are those most material to the decision in this case:
**c) What are the circumstances of and the harm caused to the victim?**

- The circumstances of the victim are highly relevant. The more vulnerable the victim's situation, or the
greater the perceived vulnerability of the victim, the more likely it is that a prosecution is required.

- This includes where a position of trust or authority exists between the suspect and victim.

- A prosecution is also more likely if the offence has been committed against a victim who was at the time
a person serving the public.

- It is more likely that prosecution is required if the offence was motivated by any form of prejudice against
the victim's actual or presumed ethnic or national origin, gender, disability, age, religion or belief, sexual
orientation or gender identity; or if the suspect targeted or exploited the victim, or demonstrated hostility
towards the victim, based on any of those characteristics.

- Prosecutors also need to consider if a prosecution is likely to have an adverse effect on the victim's
physical or mental health, always bearing in mind the seriousness of the offence, the availability of special
measures and the possibility of a prosecution without the participation of the victim.

- Prosecutors should take into account the views expressed by the victim about the impact that the offence
has had. In appropriate cases, this may also include the views of the victim's family.

- However, the CPS does not act for victims or their families in the same way as solicitors act for their
clients and prosecutors must form an overall view of the public interest


-----

**f) Is prosecution a proportionate response?**

In considering whether prosecution is proportionate to the likely outcome, the following may be relevant:

- The cost to the CPS and the wider criminal justice system, especially where it could be regarded as
excessive when weighed against any likely penalty. Prosecutors should not decide the public interest on
the basis of this factor alone. It is essential that regard is also given to the public interest factors identified
when considering the other questions in paragraphs 4.14 a) to g), but cost can be a relevant factor when
making an overall assessment of the public interest.

- Cases should be prosecuted in accordance with principles of effective case management. For example,
in a case involving multiple suspects, prosecution might be reserved for the main participants in order to
avoid excessively long and complex proceedings.

61. The judge appears to have considered that the final bullet point in paragraph (c) should have led the
prosecutors to give the complainant's views less weight than they did, and to conclude that the fact that no
significant penalty would be imposed on conviction was the dominant consideration which should have
prevailed over the others.

62. Finally, the judge was strongly critical of the decision of the CPS that in this case Covid-19 was not a
significant change of circumstances. Ms. Smith in her observations to the court on [date] had dealt with
this by saying, in effect, that if the judge had simply tried the case when it was listed before her for trial, it
would have been over before she stayed it as an abuse. For that reason, she took the view, on what would
have been the second day of that trial, that Covid-19 was not a reason to discontinue the case following
the judge's intervention.

63. At paragraph [27] above, we have set out the judge's concluding paragraphs in full. She is not to be
blamed for concentrating on the fairness of the decision which had been taken or in using the words
“vexatious and oppressive” as if they encapsulated the test she was required to apply. Despite the care
with which Lord Dyson JSC in _Maxwell_ at [35], cited at [39] above, had explained that concentrating on
fairness to the defendant when considering an application to stay proceedings under the second limb in Ex.
_p. Bennett was apt to confuse, subsequent courts have continued to use this word in this context, and have_
also used the phrase “vexatious and oppressive”. These words focus on the impact of the decision to
prosecute on the defendant, whereas the relevant factor for this kind of abuse is the impact on the court
and the system of justice. Impact on the defendant may be relevant, but it will only be one factor in the
balance which has to be struck. If the judge had focussed on the question of whether the CPS had
committed such misconduct in the decision to continue with this prosecution that “the court's sense of
justice and propriety is offended or public confidence in the criminal justice system would be undermined
by the trial” she may have reached a different conclusion.

64. It is to be noted that, ………………..no one has suggested that the proposed trial would have been an
abuse of process had it been possible to follow the normal course of events, so that sentencing for all
counts took place after the trial of the single count which was denied. It is unlikely that a conviction would
have added greatly to the sentence in that event, given the number of other serious offences for which
sentence was to be passed. There would have been no credit for the plea in relation to this count, but the
overall impact on the total sentence would have been either small or nil.

65. For these reasons the judge's conclusion that the continuation of the prosecution was an abuse of
process cannot be sustained and this appeal succeeds. ………….

66. We have taken a more restrictive approach to the jurisdiction to stay proceedings as an abuse than the
judge did. It does not follow that we disagree with her concern as to the proportionality of the decision to
continue the prosecution in these circumstances. She was quite entitled to express her views about that
and to seek an explanation of the approach of the CPS.  In return she was entitled to expect that “proper
and appropriate respect” should be paid to her views. This is the process described by Leveson LJ in the
extract at [31] above. Proper and appropriate respect, in a case of this kind where the judge's concern was
with the allocation of scarce and stretched resources, would include an explanation of the approach which
was taken to the factor identified in the Code at 4 14(f): proportionality That explanation should also have


-----

regard to the overriding objective in CrimPR 1.1(2)(h)(iv) which requires participants to deal with cases in a
way which takes account of the needs of other cases. In this situation, the CPS decision means that 7
days of court time will be devoted to this case, which could otherwise be used to try other serious sexual
offences. The waiting times for such trials are long because of the well-known stresses on the system.

67. It appeared to us that this case required a further review by the CPS. It is no longer the case that
resources have already been set aside for the trial, as was true on [date] where all parties were ready for a
trial and it could have started then. We therefore required the CPS to review the position afresh in the light
of the events which have happened, and to provide a written explanation of its decision in relation to this
case. That explanation was supplied after the judgment had been distributed in draft and subject to
embargo in the usual way. It is appropriate that decisions on the public interest should be taken in a
transparent way so that the public can judge whether its interest is being served. It would be a retrograde
step if the CPS ceased to pay proper and appropriate respect to the views of trial judges. Part of that
process involves providing explanations where they are requested by a judge which explain the decision
which the judge is concerned about.

68. We are grateful to the CPS for reviewing the case. In the letter to the court, Mr. Kris Venkatasami,
Deputy Chief Crown Prosecutor, RASSO Unit and Pan-London Complex Casework Unit CPS London
South, concludes that the evidential part of the Full Code test is met, and goes on to consider the public
interest part of the test. He says:
Turning to the public interest, there are seven factors set out in paragraph 4.14 of the Code for Crown
Prosecutors that I am required to consider. The factors set out in paragraphs 4.14(a) to 4.14(e) have been
addressed in previous reviews carried out by prosecutors in this case on the invitation of different of judges
at Woolwich Crown Court, and I agree with the conclusions those prosecutors have reached about how
those factors should be weighed in the balance when coming to a conclusion as to the public interest in
continuing with this prosecution.

As to paragraph 4.14(f), this factor invites the prosecutor to consider whether a prosecution is
proportionate to the likely outcome of the case in the event of a conviction, bearing in mind the cost of
pursuing a case to trial and the needs of other cases that are also awaiting trial, as reflected in the
overriding objective in CrimPR 1.1(2)(h)(iv). I am aware that a number of judges at Woolwich Crown Court
have commented that in the event of the defendant being convicted of this count, it is likely he will receive
what has been described as a nominal penalty. Those comments will not bind any future sentencing judge,
but for the purposes of my review I have assumed that upon conviction the sentencing judge will indeed
impose a nominal penalty upon the defendant. In these circumstances, it could be said that a prosecution
is not proportionate in this case because the likely outcome will be no further punishment for this defendant
and therefore court resources could be better directed towards trying other cases where the defendant will
face a substantial penalty on conviction.

However, paragraph 4.14(f) itself stresses that the public interest is not to be determined by reference to
that factor alone. Prosecutors are reminded that it is essential for them to consider all of the factors in
paragraph 4.14 and arrive at a balanced conclusion as to the public interest. Even if the considerations in
paragraph 4.14(f) point towards the public interest in the continuation of this prosecution not being met, in
my view those considerations are outweighed by the factors in paragraphs 4.14(a) – (e).

For all the reasons as set out in the previous and most recent review, I remain of the view that it is in the
public interest for this prosecution to continue.

69. That is a decision which the CPS has made, and it is plain that the Code has been considered and
applied. The proceedings, which will now continue, are not an abuse of the process of the court. The fact
that members of the judiciary at Woolwich Crown Court, and the members of this court, do not agree with
the CPS on the public interest is neither here nor there once that conclusion is reached.

70. We will direct that the proceedings should take place at a court in London other than Woolwich
because members of the judiciary there have expressed their views so clearly (as they were entitled to do)
that the complainant in this case may be concerned that her allegation will not be tried in a way which is


-----

fair to her. We are quite confident that this concern would be misplaced and that she would be treated
properly by the judges at that very strong Crown Court centre, but in order that this case should now have
a fresh start, we will direct that the Presiding Judge for London should allocate this trial to a court other
than Woolwich.

**End of Document**


-----

