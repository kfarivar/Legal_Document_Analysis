# QUYEN VAN PHAN Minuter against HER MAJESTY'S ADVOCATE
 Respondent 2018 Scot (D) 16/5

[2018] HCJAC 7

APPEAL COURT, HIGH COURT OF JUSTICIARY

Lord Justice General, Lord Menzies, Lord Turnbull

Minuter: O'Neill QC, Mackintosh; PDSO, Glasgow

Respondent: Solicitor General (A Di Rollo QC); the Crown Agent

11 January 2018

**Opinion of the court delivered by Lord Carloway, the Lord Justice General**

[1]     This is a reference from the sheriff at Glasgow, posing the following questions:

“(1) Is the Human Trafficking and Exploitation (Scotland) Act 2015 incompatible with Directive 2011/36/EU in
the absence of a statutory defence to the effect that the [minuter]     had been compelled to act as he did as
a direct consequence of being subject to human trafficking?

(2) In the absence of a statutory defence ... is the continued prosecution of the minuter incompatible with
Directive 2011/36/EU, Article 47 of the Charter of Fundamental Rights of the European Union and Article 6(1)
of the European Convention on Human Rights?

(3) If the ... Act and the ... continuation of the ... proceedings are compatible with Directive 2011/36/EU, and if
at trial the evidence broadly follows [certain] lines ... would the court require to give additional directions over
and beyond the standard directions so as to give effect to the Directive, and, if so, what additional directions
should be given?”

**Legislation**

[2]     Following upon the prohibition on slavery in the European Convention on Human Rights, the Palermo
Protocol (UN Convention against Transnational Organised Crime December 2000) had promoted the suppression
of human trafficking, especially that involving women and children, and the need to protect and assist victims. This
was complemented by the EU Framework Decision 2002/629/JHA and the Warsaw Convention (Council of Europe
Convention on Action against Trafficking in Human Beings, May 2005). Article 26 of the latter provided:

“Each party shall, in accordance with the basic principles of its legal system, provide for the possibility of not
imposing penalties on victims for their involvement in unlawful activities, to the extent that they have been
compelled to do so.”

The Palermo Protocol and the Warsaw Convention were ratified by the United Kingdom in 2006 and 2008.

[3]     Recital 14 of the Directive 2011/36/EU of the European Parliament and Council, commonly known as the
Human Trafficking Directive, states:


-----

“Victims of trafficking in human beings should, in accordance with the basic principles of the legal systems of
the relevant Member States, be protected from prosecution or punishment for criminal activities such as the
use of false documents, or offences under legislation on prostitution or immigration, that they have been
compelled to commit as a direct consequence of being subject to trafficking. The aim of such protection is to
safeguard the human rights of victims, to avoid further victimisation and to encourage them to act as witnesses
in criminal proceedings against the perpetrators. This safeguard should not exclude prosecution or punishment
for offences that a person has voluntarily committed or participated in.”

[4]     Article 8 of the Directive specifies:

“(1) Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties on
victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to any of the Acts referred to in Article 2.”

The Acts referred to in Article 2 include threats, or the use of force or other forms of coercion, abduction, fraud,
deception and the abuse of power or vulnerability.

[5]     Article 47 of the Charter of Fundamental Rights of the European Union provides:

“Everyone whose rights and freedoms guaranteed by the law of the Union are violated has the right to an
effective remedy before a tribunal in compliance with the conditions laid down in this Article.

Everyone is entitled to a fair and public hearing ... by an independent and impartial tribunal ...”

[6]     The Human Trafficking Directive was expressly implemented by the Human Trafficking and Exploitation
(Scotland) Act 2015. Section 8 of the 2015 Act provides:

“(1) The Lord Advocate must issue and publish instructions about the prosecution of a person who is, or
appears to be, the victim of an offence –

(a) of human trafficking ...

(2) The instructions must in particular include factors to be taken into account or steps to be taken by the
prosecutor when deciding whether to prosecute a person in the circumstances mentioned in subsections (3) ...

(3) The circumstances are where –

(a) an adult does an act which constitutes an offence because the adult has been compelled to do so, and

(b) the compulsion appears to be directly attributable to the adult being a victim of an offence mentioned in
subsection (1).”

[7]     During the Parliamentary process, the Cabinet Secretary for Justice had explained that, rather than placing
the onus on a person to establish that he was a victim who had been compelled to act, as had been done in other
[parts of the United Kingdom (Modern Slavery Act 2015, s 45; Human Trafficking and Exploitation (Criminal Justice](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
and Support for Victims) Act (Northern Ireland) 2015), the Government had preferred to place an obligation on the
respondent to “produce instructions to prosecutors to deliver [a] victim centred approach” (Official Report of the
Scottish Parliament, 1 October 2015, col 55).

[8]     The Lord Advocate's instructions contain the following:

“If there is sufficient evidence that a person ... has committed an offence and there is credible and reliable
information to support the fact that the person:

(a)  is a victim of human trafficking or exploitation


-----

(b) has been compelled to carry out the offence and

(c)  the compulsion is directly attributable to being the victim of human trafficking or exploitation, then there is
a strong presumption again prosecution of that person for that offence.”

**Facts**

[9]     On 26 April 2016, the minuter was found in a flat in Forth Street, Glasgow which, it appears to be accepted,
was being used for the purposes of cannabis cultivation. There was £100 in cash, adequate supplies of food and
drink and a key available in the flat. Although the minuter said that he did not know where the key was, the police
account is that it was hanging on the wall of the only occupied bedroom. The minuter was arrested and charged. No
interview in relation to the offence took place.

[10]     On 27 April 2016, the minuter was interviewed by the police as a potential victim of human trafficking. He
gave an account of being taken by persons unknown from Vietnam to Scotland, via Russia and France, hidden in a
large lorry with more than 20 others. He had not been on a plane or boat. His abductors had said that they would
arrange for him to work lawfully in the UK. He was happy with that, explaining that he was just “following
instructions”. He had previously registered with his abductors in Vietnam in answer to an internet advertisement. He
did not know their names, but they had many offices in Vietnam, including one in Hanoi. The minuter had worked on
a rice farm. He had had no education. His travel was to be paid for and he would repay it from his UK wages. Once
in the UK he was locked in a house before being taken to the flat where he was asked to look after the cannabis
plants. He had asked to leave the flat many times but had been beaten up. He had been locked in for 2½ months.
The persons beating him up had been westerners who had communicated with him using “body signals”. He had
been paid £100 for painting work.

[11]     On 16 December 2016, the minuter was interviewed by the Home Office. He said that he had a wife and
two sons. He had left his home in Phuong Vinh Tan (300 miles north of Hanoi), Vietnam in May 2015 and travelled
to Russia by plane before arriving in France. He had stayed for three months in the “jungle” before getting on a lorry
and arriving in the UK sometime between October and December. Although his wife and children were now in
hiding, he had been able to contact them in November or December by using a phone which he had been given. He
had agreed to pay $18,000 for the journey to the UK and had handed over his land and property in security. He had
been working as a market porter. He had had 5 years schooling. He had gone to a hotel in Hanoi and then flown
from Hanoi to Russia before arriving in France in about June or July 2015. He had stayed there for 3 or 4 months.
He had then gone to the UK by lorry, although he had not known where he was until his arrest. The minuter had
been told that he would have to work for 2 years to pay off his debt. He had been shown how to tend to the plants
by a person who had stayed in the flat for the first week. Food was provided in the fridge and freezer. He was told
not to leave. He was locked in. He had asked to leave, but his captors had threatened to, and did, beat him up
because he had refused to work.

[12]     The conclusion of the Home Office was that the minuter had not been trafficked. The Home Office
interpreted the Palermo Convention as meaning that trafficking involved the victim being coerced or deceived into a
situation in which he or she was exploited. In its decision, dated 25 January 2017, the Home Office determined that
the minuter was not a credible witness given the inconsistencies in his accounts to the police and to the Home
Office, not all of which are repeated here.

[13]     The respondent reviewed the facts and determined, applying the guidelines, that there was no reasonable
basis for concluding that the minuter was the victim of trafficking and, in any event, the necessary element of
compulsion to commit the offence was not present. The minuter was accordingly placed on petition.
**Procedure**

[14]     The minuter was indicted on charges of producing cannabis and concern in the supplying of cannabis,
contrary respectively to _[sections 4(2)(a) and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0KF-00000-00&context=1519360)_ _[4(3)(b) of the Misuse of Drugs Act 1971 and theft of electricity. A](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0KF-00000-00&context=1519360)_
compatibility minute maintained that the continued prosecution of the minuter was incompatible with the Directive
because the minuter had no access to a defence that he had been trafficked into the UK and compelled to commit
the offences. The minute sought: a declarator that the 2015 Act was incompatible with EU law because of the


-----

absence of such a defence; an order deserting the proceedings because of the absence of the defence on the
ground of oppression; or for directions to the jury on coercion in a manner which was compatible with the Directive;
or a reference to the High Court. A first diet was allocated for 3 August, with a trial diet on 22 August 2016.
Thereafter, the case called on no less 11 occasions before, remarkably, 11 different sheriffs before one of those
sheriffs decided to take a decision to remit the matter to the High Court.

[15]     The sheriff determined that it would not be appropriate to desert simpliciter, since it could not be said that
a fair trial was impossible (Patterson v HM Advocate _[2008 JC 230; HM Advocate v RV](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VDK2-D6MY-P3YG-00000-00&context=1519360)_ _[2017 SCCR 7). The decision](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NR3-G7T1-DYMJ-110C-00000-00&context=1519360)_
taken by the respondent had not been unfair. The guidelines had been cited with approval in the Council of
Europe's Group of Experts on Action Against Trafficking in Human Beings (Report concerning the implementation
_of the Council of Europe Convention on Action against Trafficking in Human Beings by the United Kingdom, Second_
_Evaluation Round, 7 October 2016) and the Anti Trafficking Monitoring Group, in October 2016. The respondent's_
guidelines, which contained a presumption against the prosecution of victims of trafficking, were compliant with the
Directive. That Directive allowed member states to devise their own systems of implementation. The 2015 Act
placed responsibility for the decision to prosecute on the respondent. This was in accordance with the traditional
approach to prosecution. The respondent's decision had been made after consideration of compulsion. It had not
determined the outcome of proceedings and could not affect the fairness of the trial. The minuter was free to lead
evidence in support of his position that he was a victim of trafficking. In these circumstances, the minuter had not
been deprived of any rights that he may have had under the Directive. His rights under Article 6 had not been
breached.

[16]     The issue of punishment was a matter which, according to the sheriff, gave rise to real difficulty. Evidence
that the minuter was the victim of trafficking was not a recognised defence, as it was elsewhere in the UK. Even if
the jury accepted his account of trafficking, the minuter would still face conviction and sentence unless his position
fell within an existing category of special or statutory defence. The sentencing sheriff would not know whether the
jury had, or had not, accepted the minuter's account. The defence of coercion required the minuter to establish that
he had acted under an immediate danger of death or serious bodily harm (Thomson v HM Advocate _[1983 JC 69).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-KM10-TXX6-C0D0-00000-00&context=1519360)_
This requirement would not be met if the minuter had been acting under duress of a serious, but not immediate,
kind.
**SubmissionsMinuter**

[17]     The minuter moved the court to answer questions (1) and (2) in the affirmative or, if it did not do so, to set
out appropriate directions on coercion. Attention was initially focused on the scale of the human trafficking problem;
it not being unusual for victims to be Vietnamese being exploited for the purposes of cannabis cultivation. The
international law background had commenced with the prohibition of slavery in the European Convention (Art 4).
Since 2000, a series of international conventions had addressed the situation, notably the Palermo Protocol, the EU
Framework Decision 2002/629/JHA and the Warsaw Convention.

[18]     The Charter of Fundamental Rights contained a prohibition on slavery, and a specific one relative to
trafficking. Article 47 provided that everyone, whose rights and freedoms were guaranteed by EU law, had a right to
an effective remedy; that being one which was neither theoretical nor illusory (C-638 PPU X v _Belgium [2017] 3_
CMLR 15, AG at para 158; C621/15 W v _Sanofi Pasteur [2017] 4 WLR 171; C-49/14 Finanmadrid v Zambrano_

[2016] 3 CMLR 3, AG at para 84; C-682/15 _Berlioz Investment Fund v Director of Direct Taxation Administration_

[2018]     1 CMLR 1 at para 44). There had been a shift in the general approach from respect for procedural
autonomy to the protection of substantive rights (C-73/16 Puskar v Slovakia, 30 March 2017, unreported, AG at
paras 46-51; Berlioz Investment Fund (supra) at paras 44-56, 83-84). There required to be an effective opportunity
to challenge the respondent's decision to prosecute. National courts had a duty of “sincere co-operation” (R (Miller)
_v Secretary of State [2017] 2 WLR 583 at para 61; R (Buckinghamshire County Council) v_ _Transport Secretary_

[2014]     1 WLR 324 at para 206; Opinion 2/13 Accession of EU to the European Convention, 18 December
2014, unreported).

[19]     In England and Wales, the Warsaw Convention had been implemented (R v M [2011] 1 Cr. App. R. 12) in
three ways, viz through: (1) the common law defences of duress and necessity; (2) specific rules for the guidance of
prosecutors; and (3) the power of the court to stay a prosecution as an abuse of process Careful consideration


-----

required to be given as to whether prosecution and punishment should follow in the case of a victim where the
crime had been something which he or she had been compelled, in a broad sense, to commit. The matter was factsensitive. The **_[Modern Slavery Act 2015 had provided a statutory defence where the accused person had been](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
compelled to commit a crime through trafficking. It was a requirement that a reasonable person, in the same
situation, would have had no realistic alternative but to commit the crime. The Human Trafficking and Exploitation
(Criminal Justice and Support for Victims) Act (Northern Ireland) 2015 had achieved much the same purpose in
Northern Ireland, although it only provided a defence in respect of the cultivation, and not concern in the supplying,
of cannabis.

[20]     The Human Trafficking and Exploitation (Scotland) Act 2015 did not provide a defence. This had been an
intentional decision by Parliament, following upon the statement by the Cabinet Secretary for Justice. For the
purposes of EU law, the question of whether there had been differential treatment depended upon whether the
primacy, unity and effectiveness of EU law had been compromised. The fact that there was no statutory defence
meant that victims of trafficking were less well protected in Scotland than in the rest of the UK. Such an approach
required to be justified substantively and by reference to the requirement of legality. The justification given failed to
recognise the procedural rights of victims under Article 47, when the prosecutor decided whether to prosecute. The
Directive gave the minuter a right to have the question, of whether he was a victim and had been compelled to
commit the offence, determined at a fair and public hearing by an independent and impartial tribunal.

[21]     The defence of coercion (Thomson v HM Advocate (supra)) did not provide sufficient protection because,
in many cases at least, there was no immediate danger of death or serious bodily harm or an inability to resist the
violence. Many of those, who had been compelled to commit offences as a direct consequence of being subject to
the prohibited acts, would not be able to rely on the defence as it was currently expressed (see van Dao v R [2012]
_EWCA Crim 1717 for the position in England)._

[22]     A proof in mitigation was not an effective remedy. If an accused person had a substantive defence, or
there were issues related to other fundamental rights, these would be lost if a proof in mitigation was the only
method by which protection could be secured. Mitigation could not be advanced where it was inconsistent with a
plea of guilty. Any plea would proceed on a narrative in which the Crown would wish to state that the accused had
not committed the offence as a result of trafficking (see Ross v HM Advocate _[2015 JC 271). Even if the narrative](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VF22-D6MY-P489-00000-00&context=1519360)_
did not contradict the plea, the burden of proof would lie upon the accused, and that was not consistent with an
accused's rights.

[23]     The question, of whether the minuter had been compelled to act as he did as a result of trafficking,
required to be decided in a procedurally fair manner. Great deference was given by the courts to the Lord Advocate.
There was no “robust tradition” of independent judicial review of his decisions (Hester v MacDonald _[1961 SC 370 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-KKY0-TXX6-C02W-00000-00&context=1519360)_
_[378-379; Crichton v McBain](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-KKY0-TXX6-C02W-00000-00&context=1519360)_ _[1961 JC 25 at 28-29; Ross v Lord Advocate](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-HBJ0-TXX6-C0VG-00000-00&context=1519360)_ _[2016 SC 502 at para 75; Stewart v Payne](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5P27-D1S1-F0JW-T2B4-00000-00&context=1519360)_
_[2017 JC 155). This was in contrast to the position in England (R (Corner House Research) v Serious Fraud Office](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SJN-7NN1-F0JW-T2FP-00000-00&context=1519360)_

[2009] 1 AC 756at paras 30 and 32). There was no case in which the Lord Advocate's discretion in the context of a
criminal prosecution had been subject to a successful review (see Stuurman v HM Advocate _[1980 JC 111).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-KM40-TXX6-C02N-00000-00&context=1519360)_

[24]     The Lord Advocate had not acted in a procedurally fair manner. The Crown had given an undertaking not
to use the police interview of the minuter in the prosecution, yet the foundation of the Crown's conclusion, that he
was not the victim of trafficking, had stemmed from the Conclusive Grounds Decision Notification, which had relied
on a comparison between what the minuter had told the police and what he had said to the Home Office.

[25]     In R v Joseph (Verna) [2017] 1 WLR 3153(at paras 24-28), the Court of Appeal had held that domestic law
was compatible with the obligations under the international conventions. That reasoning could not apply in
Scotland, because there was no power to stay a prosecution akin to that in England. In the absence of such a
power, the court required to create a defence which would give effect to the Directive in a procedurally fair manner.
If it did not do so, the continued prosecution of the minuter would be oppressive.

[26]     The submission relative to Article 6 of the European Convention was departed from.
_Respondent_


-----

[27]     Section 8 of the 2015 Act required the respondent to issue and publish instructions about the prosecution
of a person who appeared to be the victim of human trafficking. The instructions required certain factors to be taken
into account. The respondent had issued and published instructions in accordance with section 8. They provided
that there was a strong presumption against prosecution where there was credible and reliable information that: the
accused was a victim of trafficking; he or she was compelled to commit the offence; and the compulsion was
directly attributable to being a victim.

[28]     The respondent had appointed a National Lead Prosecutor for Human Trafficking and Exploitation. All
cases required to be reported to him for a final decision. If information came to light, which suggested that the
accused was the victim of human trafficking, the prosecutor was required to investigate. Where information came to
light after conviction, the prosecutor had to apply to have the conviction quashed.

[29]     Article 8 of the Directive provided that the approach taken to implementation was to be in accordance with
the basic principles of the legal systems of each member state. The Directive allowed for different approaches (C571/10 Kamberaj v Instituto per l'Edilizia sociale della Provincia autonoma di Bolzano (IPES) [2012] 2 CMLR 43 at
para 77). Article 8 did not require a statutory defence (see also recital (14)). Member states were only required to
ensure that the national authorities “were entitled” not to prosecute or to impose penalties on victims.

[30]     Prior to the Directive, the principal European instrument relating to human trafficking had been the
Warsaw Convention. It had not formed part of EU law, as it had not been signed or ratified by the EU. Article 26 did
not require a blanket immunity from prosecution, nor did it provide a defence. Rather, an assessment of whether a
prosecution was appropriate had to be carried out (R v M(L) [2011] 1 Cr App R 12 at para 13). The same approach
could be taken in the interpretation of Article 8.

[31]     The prosecutorial discretion of the respondent was a basic principle of the legal system (McBain v
_Crichton (supra) at 29; Stewart v Payne (supra)). The respondent required to consider whether prosecution was in_
the public interest, even where there was sufficient evidence (The Crown Office & Procurator Fiscal Service
Prosecution Code, page 6). The respondent's discretion not to prosecute, taken together with the publication of
criteria to be taken into account when exercising that discretion, was sufficient to satisfy the requirements of Article
8. It had been held to satisfy the requirements of Article 26 of the Warsaw Convention in England and Wales (R v
_M(L) (supra)). The introduction of a statutory defence did not affect the compatibility of the English common law with_
the requirements of Article 26 (R v _Joseph (Verna) (supra)). It had been described as a backstop to the_
prosecutorial discretion (R(McNiece) v Criminal Injuries Compensation Authority [2017] EWHC 2 (Admin), at para
131). Where the commencement or continuation of a prosecution breached a European Convention right, the court
[had the power to halt the prosecution (Butt v Scottish Ministers 2013 JC 274, at para 16).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VDX2-8T41-D08Y-00000-00&context=1519360)

[32]     The obligation imposed on the respondent by section 8 of the 2015 Act had not been necessary to ensure
compliance with Article 8 of the Directive. Rather it served to codify the factors which would be taken into account
(Policy Memorandum to the Human Trafficking and Exploitation (Scotland) Bill, para 52). The Scottish regime had
been endorsed by the GRETA report (supra). Individuals who had voluntarily committed criminal offences could
seek to avoid punishment by falsely claiming to have been compelled to do so. This phenomenon was not
uncommon amongst Vietnamese nationals who were involved in cannabis production (Combating modern slavery
_experienced by Vietnamese nationals en route to, and within, the UK, Independent Anti-Slavery Commissioner_
Report 2017, paragraph 4.2.2). The need for a balanced, thorough and careful investigation was emphasised in the
respondent's instructions.

[33]     The existence of a statutory defence in other UK jurisdictions was irrelevant to the compatibility of the
2015 Act with EU law. The existence of alternative approaches within the UK did not constitute discrimination (C428/07 R (on the application of Hovarth) v Secretary of State for the Environment, Food and Rural Affairs [2009]
ECR I-6355 at para 58). The regime was to be distinguished from a situation where one part of the UK differentiated
between citizens based on whether or not they were residents of that part _(R (A) v Secretary of State for Health_

[2017] 1 WLR 2492, at para 37-49).


-----

[34]     Article 8 did not require any particular approach to be taken by member states. A judge was entitled to
take into account the fact that an accused was the victim of trafficking at the point of sentence. The sentencer could
grant an absolute discharge in almost all cases. The requirement that member states confer a discretion on the
national authorities was subject to the caveat that such provision should be made in accordance with the basic
principles of their own legal systems.

[35]     The continued prosecution of the minuter was not incompatible with the Directive, as it did not confer on
any person the right not to be prosecuted or punished. The continued prosecution of the minuter was not
incompatible with Article 8 of the Directive or Article 47 of the Charter. The second question should be answered in
the negative.

[36]     No additional directions over and above the standard directions on coercion were required. The task of the
jury was to determine guilt or otherwise. The question of compulsion by virtue of being trafficked was a discrete
question which went only to mitigation, unless the circumstances were such as to amount to the recognised
defences of coercion or necessity. Mitigation was a matter for the judge to consider at the point of sentence, having
heard any relevant evidence during the trial or any proof in mitigation. The third question should be answered in the
negative.
**Decision**

[37]     Article 47 of the Charter of Fundamental Rights of the European Union provides that everyone whose
rights and freedoms are guaranteed by EU law has a right to an effective remedy before an independent and
impartial tribunal. The first question is whether the minuter's rights and freedoms under EU law have been violated.
That in turn depends upon Article 8 of the Directive 2011/36/EU. This provides that member states require to
ensure that national authorities are entitled not to prosecute or to impose penalties on victims of human trafficking
for their involvement in crimes which they have been “compelled” to commit as a “direct consequence” of, in
essence, threats, the use of force or other forms of coercion. It does not require that such victims are not
prosecuted or punished. It does not confer a right on such victims not to be prosecuted or punished. What must be
available is an option. No doubt, if such an option were not available in Scotland, proceedings could be taken to
challenge that or any action taken without due consideration of such an option.

[38]     An option not to prosecute a person for a particular crime has always been available in Scotland; it being a
matter for the respondent to decide whether to do so in the public interest. Whether a person was a victim of
trafficking is something which might have been taken into account in deciding whether to prosecute him for a
particular crime. Nevertheless, increasing recognition of the problem of trafficking and, of course, the terms of the
Directive and its international antecedents, prompted the passing of section 8 of the Human Trafficking and
Exploitation (Scotland) Act 2015. This required the respondent to publish instructions on that matter, specific to
those who appear to be victims of human trafficking. The respondent has done this by creating a strong
presumption against the prosecution of such persons where there is credible and reliable information to support the
fact that the person has been compelled to carry out the offence as a direct result of trafficking.

[39]     The existence of such a discretion meets the requirements of Article 8 of the Directive in so far as it
requires national authorities to be “entitled not to prosecute” victims of trafficking who have been compelled to
commit a crime. In this respect, the court agrees with R v Joseph (Verna) [2017] 1 WLR 3153, in which the Court of
Appeal of England and Wales held that, in respect of pre **_[Modern Slavery Act 2015 cases, the common law](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
remained compatible with existing international obligations, not just Article 26 of the Warsaw Convention with its
focus on penalties, but also Article 8 of the Directive (cited at para 14). The Article 26 obligation had, in terms of the
previous case law, been given effect through: (1) the common law defences of duress and necessity; (2) guidance
to prosecutors on the exercise of the discretion to prosecute; and (3) the power of the court to stay a prosecution for
an abuse of process (para 20(i)), but the court also noted (para 20(ii)) the place of prosecutorial discretion, the
context of which is Article 8. The situation is not materially different in Scotland.

[40]     First, there is vested in the respondent a general discretion not to prosecute. This is transmitted to
prosecutors along with a specific instruction which provides a strong presumption against prosecution where a
person has been compelled to carry out the offence as a direct effect of trafficking. Although the court may give due


-----

deference to the respondent in taking a decision to prosecute, that decision could be reviewed by the court where
an accused advances a plea in bar of trial on the grounds of oppression. Such a review may very well succeed if,
for example, the decision had been taken without regard to the respondent's instructions or if any prospective trial
would inevitably be unfair (Butt v Scottish Ministers _[2013 JC 274, LJC (Carloway) at para 16) having regard to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TP7-VDX2-8T41-D08Y-00000-00&context=1519360)_
terms of any international obligations or EU law. However, no grounds have been advanced to suggest that the
decision to prosecute the minuter was not properly taken in the context of the presumption contained in the
instructions. The material available suggests that there were significant factors pointing away from the minuter
having been trafficked in favour of him being a willing economic migrant.

[41]     As in England, there is no blanket immunity from prosecution for victims of trafficking. Various factors
require to be taken into account when deciding whether to prosecute, including the gravity of the offence. Each
case will turn on its own facts and circumstances but, unless there is material to contradict the respondent's findings
or to demonstrate that significant evidence has been ignored by him, then, as in England _(R_ v _Joseph (Verna)_
_(supra) at para 20(viii) citing_ _R v_ _L (C)_ _[[2014] 1 All ER 113 at para 28), the courts would be unlikely to stop the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_
prosecution at a preliminary stage

[42]     Secondly, the common law in relation to coercion is available if the circumstances reveal that an accused
has been coerced into carrying out the cultivation of cannabis under threat of violence. It is important to observe
that the locus classicus (Thomson v HM Advocate _[1983 JC 69) was concerned with the robbery of a Post Office](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4R2P-KM10-TXX6-C0D0-00000-00&context=1519360)_
sorting-office using firearms. It was rather different from the more placid, but time consuming crime of cultivating
cannabis. In the context of a single violent act, committed in a place accessible through public spaces where resort
to the forces of law and order will normally be possible, there is a need for any coercion to involve a threat of
immediate serious violence. As was made clear in Thomson (LJC (Wheatley), delivering the Opinion of the Court, at
78), “the defence of coercion is _normally only open when it is based on present danger from present threats”_
(emphasis added). It is properly tested having regard to: (1) the existence of immediate danger of violence; (2) the
absence of an ability to resist or avoid the danger; (3) the extent of the accused's role in the crime; and (4) the
disclosure of the fact of coercion, and the return of any proceeds of the crime, on the first safe and convenient
occasion. The third and fourth elements are not essential but are rather factors to be included in the assessment of
the credibility and reliability of the primary account. Throughout _Thomson, as in the passages in Hume_
(Commentaries i. 53) cited, there are repeated qualifications using the words “normally” or “generally”. It will always
be a matter of facts and circumstances whether a person was truly coerced (or compelled) to commit a crime by
virtue of genuinely anticipated and unavoidable violence.

[43]     In the case of cannabis cultivation, for example, if the farmer is confined to a flat in which the cannabis is
grown, and has reasonable grounds for believing that, if he does not tend to the crop, he will be seriously injured on
the arrival of those controlling the operation, the defence may well be made out. Thomson correctly stressed (at 78)
the need, as in the related defence of self-defence, to strike a fine balance between the nature of the danger
threatened and the seriousness of the crime. Nevertheless, there may be circumstances in which a person is
exposed to a threat of violence to himself or a third party from which he cannot be protected by the forces of law
and order and which he is not in a position to resist. Where such a situation arises, as it may do in a trafficking
situation, its effect in law would have to be assessed on its particular facts.

[44]     Thirdly, even if the circumstances do not amount to the defence of coercion, they may nevertheless
provide powerful mitigation. It will be a matter for the minuter to decide whether to plead not guilty and to run a
defence of coercion. If the matter goes to trial and the jury reject coercion as a defence, the minuter can still
maintain that he was nevertheless trafficked and that that had a bearing on the degree of his culpability. The fact
that the jury have not been asked to rule on the fact of trafficking or its effect, other than in the context of coercion,
has no bearing on the sheriff's ability to assess that fact and its bearing. As with many potential mitigating factors,
the sheriff is entitled to form a view based upon the evidence heard. This may include the testimony of the minuter
himself. If he has not given evidence prior to a guilty verdict or he elects to plead guilty, he can still make such
submissions about his personal circumstances (including being a victim of trafficking) as he wishes and, if there is a
material issue of disputed fact, he has the option of a proof in mitigation. In all of these various situations, the sheriff
has a discretion to reduce what would otherwise normally have been the appropriate sentence. The sheriff's


-----

concerns in this area are misplaced and the contention that a proof in mitigation is not an effective mechanism is
rejected.

[45]     In a case such as the present, where there are established parameters in relation to sentences for
cannabis cultivation (Lin v HM Advocate 2008 JC 142), a significant reduction in the level of custodial sentence may
be appropriate. In other situations, a non-custodial disposal may be imposed. In some, an absolute discharge might
[be given (Criminal Procedure (Scotland) Act 1995, s 246), in which case there is in effect no conviction other than](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5P1T-49Y1-DYCN-C08Y-00000-00&context=1519360)
for specific purposes (ibid s 247). What is clear is that the sheriff has a wide discretion in deciding what, if any,
penalty should be imposed where the person convicted has been a victim of trafficking and this has encouraged
him to commit the offence, albeit that the common law defence of coercion has not been made out.

[46]     The court will answer each question in the reference in the negative.
**Postscript**

[47]     This case was indicted for a trial diet in August 2016. When the matter called at the First Diet on 3 August
2016, the trial diet was postponed to 3 October with 7 September being a “further” first diet. This was said to be in
order that “further discussions” take place regarding a potential Home Office decision. On 7 September 2016, it was
said that the case was likely to proceed to trial and the outstanding matters were continued to that diet. On 14
October, the trial diet was postponed until 20 February to allow “further investigations” with a “first diet and hearing”
on the preliminary minutes allocated for 30 January 2017. On the latter date the “evidential hearing” was continued
until 13 February to allow time to consider the Home Office decision. On 13 February, the hearing was discharged
because the decision was still awaited. A new diet of 20 February was set for an “evidential hearing” with a trial diet
on 27 February. On 20 February, the trial diet was postponed to 3 April 2017 and a “continued first diet and debate”
assigned for 13 March 2017. On the latter date, the compatibility minute was continued to the trial diet, with a new
diet for other preliminary issues assigned for 27 March. On the latter date, an undertaking not to use the “police
interview” at the trial was given. On 12 April 2017, the trial diet was “adjourned” to 18 July 2017, and a first diet
assigned for 30 June 2017. On the latter date, a “further first diet” was fixed for 10 July and that was also to form an
evidential hearing relative to the compatibility minute. The case ultimately called on 10 July, when argument was
finally heard. Throughout this period, extensions of the 12 month time bar were granted, with the last one being to 4
December 2017.

[48]     Perhaps the most remarkable element of the procedure is the fact that the case called before eleven
different sheriffs over a period of almost a year before argument was heard and a reference made. Such a delay is
unacceptable and is not justified by the various explanations, some of them repetitive, minuted. It is particularly
regrettable in a case of this type where the issue of trafficking was raised. The conduct of the First Diets appears to
have repeatedly contravened the clear terms of the Practice Note No 3 of 2015 concerning Sheriff Court Solemn
Procedure, notably the direction that preliminary pleas and issues ought to be dealt with at the (first) First Diet and
not continued repeatedly, sometimes to another First Diet and often to a trial diet which ultimately, and not
surprisingly, did not take place. It is disturbing to note the large number of sheriffs who appear to have allowed this
to occur.

Crown Copyright

**End of Document**


-----

