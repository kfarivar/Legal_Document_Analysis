# R v BWM [2022] EWCA Crim 924

Court of Appeal, Criminal Division

Males LJ, Sweeney J and Judge Andrew Lees

5 July 2022Judgment

**Ben Douglas-Jones QC (instructed by Birds Solicitors) for the Appellant**

**Nick Adlington (instructed by the Crown Prosecution Service) for the Respondent**

Hearing date: 23 June 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**This judgment will be handed down by the Judge remotely by circulation to the parties'**
**representatives by email and release to The National Archives. The date and time for hand-down is deemed**
**to be 10.30 a.m. on Tuesday 5 July 2022.**

The appellant in this case is entitled to anonymity. This judgment is not subject to any reporting restriction, but
nothing may be published which will disclose the appellant's true identity. A person who breaches this order is liable
to a fine and/or imprisonment.

**Lord Justice Males:**

1. On 23rd July 2018 in the Crown Court at Bradford before His Honour Judge Burn the applicant, a
Vietnamese national then aged 24, pleaded guilty to being concerned in the production of cannabis. On the
same day he was sentenced to 13 months' imprisonment. His application for an extension of time (1,217
days) in which to seek leave to appeal against conviction and leave to call fresh evidence has been
referred to the full court by the single judge.

2. There was initially a single ground of appeal, namely that the applicant's conviction on his own plea is
unsafe because he was not advised (or not properly advised) of the defence available to him under section
45 of the **_Modern Slavery Act 2015, when that defence would probably have succeeded. Following the_**
decision of this court in R v AAD _[[2022] EWCA Crim 106, the applicant seeks to add a further ground of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
appeal, that the conviction is unsafe because the prosecution was an abuse of process in that, had the
prosecution known at the time what is now known about the applicant's status as a victim of trafficking, it
would or might well not have prosecuted him.

3. There is now a conclusive grounds decision dated 28th June 2021, in which the Home Office, as the
competent authority under the 2005 Council of Europe Convention on Action against Trafficking in Human
Beings, determined that the applicant is a victim of **_modern slavery. Previously, and in particular at the_**
date of the applicant's plea of guilty, there was a conclusive grounds decision that the applicant was not a
victim of trafficking. In the light of the more recent decision it is appropriate (applying the principles
summarised in R v L; R v N _[[2017] EWCA Crim 2129 at [7] to [13]) to grant the applicant anonymity, as](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
ordered provisionally by the single judge. Accordingly we direct that he should be referred to as “BWM”. It


-----

is appropriate also to grant the extension of time as the application for leave to appeal was made promptly
once the positive conclusive grounds decision was issued.

**Section 45**

4. Section 45 of the **_Modern Slavery Act provides a defence for victims of slavery or trafficking who_**
commit certain offences under compulsion attributable to slavery or relevant exploitation. Subsection (1)
provides:

“(1) A person is not guilty of an offence if –

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.”

5. _AAD provides authoritative guidance on a number of topics relating to the defence under section 45,_
some of which we shall have to consider.

**The basic facts**

6. On 30th January 2018 police officers went to a large three storey commercial property at an address in
Bradford which was divided into retail and business premises. In the lower ground and basement area of
the building they found a significant cannabis farm. Four rooms contained a total of 412 flowering plants,
while three other rooms contained 557 less established plants. The final room contained nine propagators
which held 720 cannabis plants.

7. The estimated yield of the 412 flowering plants was approximately 24.7 kilograms of “skunk” type
cannabis. The remaining plants could be used to restock the rooms in which the flowering plants were
being grown. According to a forensic drugs report, the four flowering grow rooms were each capable of
producing at least four crops a year. As a result, the total annual yield was estimated at 1,648 plants
yielding 98.9 kilograms.

8. As police officers entered the property, the applicant and three other men, his co-accused, who were
also from Vietnam, escaped via a crawl space into an enclosed courtyard at the rear of the building. They
forced their way into a neighbouring building, two of the men smashing a window with garden furniture.
They then smashed another window to escape into the road. However, they were subsequently detained
and arrested. They were remanded in custody.

**The proceedings**

9. In interview, the applicant denied any involvement in the production of drugs and insisted that he was in
the building to help with cooking, cleaning and tidying. He said that two other men were responsible for the
watering and cutting of the plants and denied causing damage to the windows. He said that he had been
kept in the property, which was locked, against his will for seven weeks, and had not been allowed out; that
he was not paid for his work; and that he owed his captors money.

10. The applicant was charged with producing a controlled Class B drug contrary to section 4(2)(a) of the
Misuse of Drugs Act 1971 and with criminal damage. He pleaded not guilty. Consistently with his account
in interview, the applicant served a Defence Statement in which he accepted being present at the address
at the material time, but denied the offence, saying that he would rely on the matters raised in his interview.
He said that when in Vietnam he had been offered a job in Russia, but had been brought to the United
Kingdom and taken to the Bradford address, where he did not know anyone and was instructed to cook
and clean. He was aware that cannabis was being grown by others, but had no control over the enterprise,
was unable to leave the building and was effectively imprisoned. Although the Defence Statement did not


-----

refer expressly to section 45, it was evidently prepared with that statutory defence in mind. Certainly that
defence was well in mind by the time of the trial.

11. In fact, on 23rd April 2018, the Home Office had issued a negative conclusive grounds decision finding
that the applicant was not a victim of trafficking, but neither the prosecution nor the defence were aware of
this at the time. The decision was shown to prosecution counsel, Mr Nick Adlington, on the morning of the
trial and he provided a copy immediately to the applicant's trial counsel, Mr Robert Stevenson.

12. The trial was due to begin on 23rd July 2018. During a discussion of preliminary matters before a jury
was empanelled, the trial judge, Judge Burn, made an unsolicited observation that the sentence for the
applicant and his co-defendant would be of the order of 12 months, which would mean that they would
already have served all or almost all of (the custodial element of) the sentence. It appears clear from the
sentence which he was to pass that the judge was referring to the sentence which would be imposed in the
event of a guilty plea. Mr Stevenson pointed out that the applicant had a previous conviction from 2014 for
being concerned in the supply of cannabis, but the judge indicated that this would not make much
difference to the sentence.

13. Mr Stevenson had already seen the applicant in conference before this discussion took place, but the
judge now allowed time for a further conference, the result of which was that it was agreed that the
applicant would plead guilty to a new count of being concerned in the production of cannabis and that the
existing counts on the indictment would not be proceeded with. The same pleas were entered by the
applicant's co-defendants.

14. The judge proceeded straight to sentence. He referred to the conclusive grounds decision that the
applicant was not a victim of trafficking, but commented that there were “obvious elements of exploitation
here”. He said that none of the defendants had been enslaved; they had been working for some kind of
financial arrangement without their freedom being fully taken away, but they each had very few options
when it came to getting involved in the operation. He drew no distinction between the defendants, saying
that in each case the sentence after trial would have been one of 16 months' imprisonment which he
reduced by three months to take account of their guilty pleas. Thus the sentence in each case was one of
13 months.

15. In view of the grounds of appeal, which submit that the applicant was not advised about the defence
available to him under section 45, the applicant has waived privilege and we have the comments of Mr
Stevenson as trial counsel. He indicates that the applicant was advised about the defence under section
45, including that it would have some difficulty in view of the factors which had led to the negative
conclusive grounds decision. These included the applicant's previous conviction for being concerned in the
supply of cannabis and inconsistencies in the accounts of his history which the applicant had given on
different occasions. A practical dilemma which the applicant faced was that in order to run a defence under
section 45 with any real prospect of success, it would be necessary to apply to adjourn the trial for what
might be a lengthy period, with the applicant in custody, while on a guilty plea the judge had indicated that,
in effect, the sentence had already been served. Mr Stevenson indicates that it was the applicant's decision
to plead guilty, and that he was advised that he should only do so if that was his genuine wish.

**The applicant's account of being trafficked**

16. The proof of evidence taken from the applicant for the purpose of the criminal trial set out only the bare
bones of any defence under section 45. It said no more than that the applicant was trafficked with the
promise of a job in Russia, where his passport was taken from him, that he was brought to the United
Kingdom to work, and that he was unable to leave the building and effectively imprisoned there. There was
in existence a more detailed statement of the applicant, dated 6th August 2015, which had been taken for
the purpose of his asylum claim, but it appears that this was not in the possession of his criminal defence
team.

17. The account given by the applicant in this asylum statement was as follows.


-----

18. He was born in Vietnam on 28th June 1994. His father worked in an illegal occupation and had
borrowed money from criminals. This debt was the source of the family's problems, with criminals coming
to the family house, beating and threatening his parents and demanding money. His father had died in
what may have been a motor accident, but the family had been threatened that if the debt was not paid,
they would suffer the same consequences. As the applicant grew older, he too was beaten and has a scar
on his eyebrow as a result. It was impracticable to report all this to the police, because the police in
Vietnam were corrupt.

19. Eventually one of the creditors told the applicant that if he left Vietnam, he would get a better job and
would be able to pay back the money owed. He offered to lend the applicant US $20,000 to enable him to
leave Vietnam. The applicant never got the cash, but signed a piece of paper acknowledging the debt. The
creditors provided the applicant with a passport. The applicant left Vietnam and flew to Russia in about
November 2012. In Russia he was met and taken to an abandoned area where there were tents. He
stayed there for about a week. He was given €1,500 in cash and told what to do when he reached his next
destination. He was put onto a lorry, paying the driver €1,200 or €1,300 from the money which he had been
given. He was not told the destination, which turned out to be Poland. There he was met and his
belongings and mobile phone were taken away. He was given €800 in cash and, after a few days, was put
on another lorry. He paid the driver the money which he had been given. Again, he did not know where he
was going, but was told that he would be met. The lorry drove to France and, once again, the applicant
was met and taken to a place where he stayed for a few days, before being taken to a car park and given
€600 to pay the next driver. He was put on a lorry to the United Kingdom, together with seven others. He
was told that, on arrival, he should follow a Vietnamese woman named Lan who was also on the lorry.

20. The applicant arrived in the United Kingdom on 1st December 2012 after a seven hour journey. The
people in the lorry were struggling to breathe and banging on the side of the lorry. The police opened the
door and the applicant was taken, first to a police station, and then to Yarl's Wood Immigration Centre. He
was detained there for a few days, during which he was interviewed. He heard the word “asylum”, but did
not understand what it meant. After a few days, he was taken to Glasgow by the immigration authorities
and was taken to a flat, where he was given the key and some money. Lan had also been taken to
Glasgow and was given a flat in the same building. The next day she came to the applicant's room and told
him to follow her, which he did. He thought that he should do so because his mother and brother in
Vietnam were still under the control of their creditors. Lan took the applicant to the train station and they
caught a train to London, where the applicant was taken to a flat with other immigrants. About twice a week
a Vietnamese person came and took the applicant to work, loading boxes of equipment onto a van and
delivering them to houses at night. At the time he did not realise that these contained equipment for
cultivating cannabis. If he asked questions, he would be threatened or hit. He was told that each time he
worked £50 was deducted from the loan of US $20,000 which he had been given in order to come to the
United Kingdom. This pattern went on for about eight or nine months.

21. After that, in about September 2013, the applicant was told that he had to go back to Scotland. He was
taken by train to a flat in Dumbarton. A couple of weeks later he was taken to a warehouse where he
picked up devices for cannabis cultivation to be put into the flat. He did not attempt to escape because he
did not know what he would do if he did, speaking no English and having no money. He was scared what
would happen to his family if he did escape. He knew that cultivating cannabis was illegal, but was totally
under the control of those telling him what to do. He stayed in the flat growing cannabis for about five
months, with a Vietnamese person called Quang visiting every week to check on him and bring food. He
was not allowed to leave the flat.

22. In February 2014 the police came and arrested him. Another Vietnamese person called Ly was there,
but he managed to jump through the window and run away. The applicant was interviewed, but did not tell
the police his story and was advised to answer “no comment”, which he did. He was remanded for about
four months in a young offenders institution, after which he was brought to court for sentencing. He had
remained in the young offenders institution up to the date of the 6th August 2015 statement. While there he
learned that his mother had died and his brother had been adopted in Vietnam. In fact, although the


-----

statement does not say so, the applicant was sentenced to 38 months in a young offenders institution and
was recommended for deportation.

23. Following the submission of this statement by the applicant's immigration solicitors, and while the
applicant was still in the young offenders institution, the Home Office issued a negative conclusive grounds
decision stating that the applicant was not a victim of trafficking. The decision identified inconsistencies in
the account given by the applicant when compared with previous statements which he had given and
concluded that his account was not credible. The inconsistencies concerned the length of his stay in
Russia, the amounts which he had paid in order to get to the United Kingdom, whether he had returned to
France after arriving in the United Kingdom, how long he had been in Scotland before his arrest, and the
reason why he had remained in the house growing cannabis where he had been arrested. In his latest
statement he had said that he had been forced to remain there, but in an earlier statement he had said that
he stayed there because he was homeless with no mention of being subjected to or threatened with
violence.

24. As at July 2018, the date of the trial in Bradford, the applicant had given no account (or at any rate
none which we have seen) to explain how he came to be growing cannabis in Bradford after completion of
his sentence in Scotland. However, this gap is filled in by statements which the applicant made
subsequently for the purpose of resisting his deportation.

25. According to these statements, on completion of his sentence the applicant was detained under
immigration powers and was not released for another 15 months. He then sought out another Vietnamese
person who had visited him in detention, with an address in Slough. In Slough he was unable to find this
person and was street homeless, sleeping on park benches for a few days. He was then approached by a
group of men, one of whom knocked him unconscious with an electric stun gun. He woke up in the boot of
a moving car, with his hands tied and his head covered by a bag. He was taken to the basement of a
house which was being used as a factory for producing drugs. The door was kept locked and he was never
allowed to leave. He was forced to work, weighing and packing heroin into small bags. He was given food
and drink, but never enough. He was hungry all the time. He slept on the floor. He was beaten with a
wooden bat. He was tortured with hot candle wax being dripped onto his back. He was raped on many
occasions.

26. One day the applicant was taken from this house and driven with two men to a house in what turned
out to be Bradford. He was locked in there for about two months, with nothing to do. One night he was
taken to another building, with cannabis plants in the basement. He was told not to try to escape and that,
if he did, he would be killed. Two other Vietnamese men were also there. A third arrived after a few weeks.
The two who were originally there were in charge and beat the applicant and the third man regularly,
forcing them to do all the work of growing the plants. Working conditions were very bad. The applicant
knew that growing cannabis was illegal, but had no choice and was worried that if he did not do as he was
told, he would be beaten or tortured. He was in the cannabis factory for about seven weeks before the
police arrived and arrested him.

27. This was the arrest which led to the proceedings in Bradford Crown Court.

28. On 6th February 2018 the applicant was once again referred via the National Referral Mechanism to
the Home Office as the competent authority for deciding whether he was a victim of trafficking. Two days
later he received a positive reasonable grounds decision, stating that there were reasonable grounds to
suspect that he was. However, a negative conclusive grounds decision was issued on 23rd April 2018,
which reached the same conclusion that the applicant was not a victim of trafficking as the previous 2015
decision. Again it was said that the applicant's account was not credible and that there were
inconsistencies in his statements. His previous conviction for being concerned in the production of
cannabis was noted and his account of being kidnapped and abused after his release from detention in
Scotland was described as “an unsubstantiated and easy and convenient thing for you to say”.

29. Following completion of the sentence imposed by Judge Burn, the applicant was not released but was
again detained in immigration detention, this time until July 2019. He made a further claim for asylum, in
the course of which he made further statements In those statements in addition to giving the further


-----

information which we have set out, he repudiated part of what he had previously said. He admitted that he
had lied in his initial asylum interview, saying that he was very frightened. He said that some other things
he had said, or appeared to have said, were wrong (in particular, statements that he had been given cash:
he had not been given cash, but had been told that the cost of journeys would be added to his debt) and
must have been the result of misinterpretation.

30. Eventually, on 28th June 2021 the Home Office issued a positive conclusive grounds decision stating
that the applicant was a victim of **_modern slavery. Applying the standard of proof “on the balance of_**
probabilities”, it was accepted that he was a victim of modern slavery in Vietnam, Russia, Poland, France
and the United Kingdom during the period from 2012 to 2018.

**The psychiatric report**

31. A psychiatric report dated 28th October 2019 was prepared by Dr Nuwan Galappathie, a consultant
forensic psychiatrist, following an examination of the applicant on 5th October 2019. Dr Galppathie set out
the account which the applicant had given him and referred to information from his health records while in
detention. He diagnosed the applicant as suffering from two forms of mental disorder, namely Recurrent
Depressive Disorder (characterised by repeated episodes of depression, difficulty sleeping, low energy
levels, poor appetite and weight loss, with thoughts of self-harm and suicide) and Post Traumatic Stress
Disorder as a result of his experiences. Symptoms of the latter included frequent flashbacks of previous
trauma, nightmares and anxiety. It was noted also that the applicant's scars to the head had been found to
be consistent with his account.

32. Dr Galappathie found no evidence of malingering or feigning of the applicant's symptoms, which
appeared consistent with what would be expected from an individual with the experiences which the
applicant described. He added that the applicant's mental health problems were likely to have a significant
adverse effect on his ability to give consistent accounts of his experiences.

33. However, the report also went further, stating positively that these problems were caused by the
applicant having been trafficked:

“In my opinion, his mental health problems by way of depression and PTSD are likely to have been directly
caused by [the applicant] being trafficked and forced to work in a cannabis factory. His mental health
problems are also likely to have been caused by his account of being prevented from leaving, having
threats made against him and his family, being physically beaten and sexually abused.”

**The application to adduce new evidence**

34. The applicant seeks to adduce new evidence on appeal, namely:

(1) documents leading up to and including the 2015 and 2018 negative Conclusive Grounds Decisions;

(2) documents leading up to and including the 2021 positive Conclusive Grounds Decision;

(3) the applicant's further witness statements to which we have referred; and

(4) the applicant's medical records and psychiatric report.

35. The criteria for the admission of new evidence on appeal are set out in section 23 of the Criminal
Appeal Act 1968. The test is whether it is necessary or expedient in the interests of justice to receive such
evidence. In considering that evidence it is necessary to have regard to whether the evidence appears to
be capable of belief, whether it appears that it may afford any ground for allowing the appeal, whether it
would have been admissible in the proceedings below, and whether there is a reasonable explanation for
the failure to adduce the evidence below. In the context of a potential defence under section 45 of the
**_Modern Slavery Act, it is established that a conclusive grounds decision is admissible on appeal (always_**
assuming that it is necessary or expedient to receive such evidence) notwithstanding that such a decision
would not be admissible at trial (see R v Brecani _[2021] EWCA Crim 731, [2021] 1 WLR 5851, and AAD at_

[79] to [82] and cases there cited).

36 _[AAD goes on at [83] to explain citing R v AAJ [2021] EWCA Crim 1278 at [39] that:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_


-----

“The decision of the competent authority as to whether or not a person has been trafficked for the purpose
of exploitation is not binding on the court, but, unless there is evidence to contradict it or significant
evidence that has not been considered, it is likely that courts will respect the decision.”

37. However, this is only a general approach, and in some cases the account given by an appellant may
require testing by way of appropriate questioning (AAD at [84]).

38. In the present case we are satisfied that it is necessary to admit the new evidence, with one
qualification. Although much of the evidence should have been available in the court below, that is not
necessarily a decisive consideration. The evidence is (broadly speaking) capable of belief and may afford
grounds for allowing the appeal. The qualification relates to the positive statement by Dr Galappathie that
the applicant's mental health problems were caused by the applicant having been trafficked. Whether a
defendant has been trafficked is a question of fact on which it is not for a psychiatrist to pronounce,
although he can say (as Dr Galappathie does) that the applicant's mental disorders are consistent with his
account and (in the absence of any other explanation) supportive of it; and that an individual suffering from
depression and PTSD may find it difficult to give a consistent account of his experiences.

**The section 45 defence**

39. In the present case the prosecution has not sought to cross examine the applicant on the account
given in his latest statements as summarised above. Those statements appear to us, in their essentials if
not in every detail, to be capable of belief. It is not surprising, particularly in the light of Dr Galappathie's
report, that there should be some inconsistencies in the applicant's account. Following the approach
described in AAJ at [39] and approved in AAD at [83] of respecting the decision of the competent authority
unless there is reason not to do so, we accept that the applicant is more likely than not to be a victim of
trafficking. Mr Adlington for the prosecution did not dissent from this conclusion.

40. We accept also that the prosecution would be unable to prove to the criminal standard that the
applicant was not acting under compulsion during the time when he was concerned in the production of
cannabis in Bradford. He has given plausible evidence that he was, which the prosecution has not
attempted to challenge. In this respect the position of the applicant is materially different from that of the
appellant AAD in the AAD case. In that case it was accepted that AAD was a victim of trafficking, but he
was not forced to cultivate cannabis against his will, which meant that the element of compulsion, which is
an essential part of a section 45 defence, was lacking. It was for that reason that his appeal failed (see

[181] and [182]).

41. It follows that if what is now known, including the latest conclusive grounds decision, had been known
at the time of the proceedings in Bradford Crown Court, the applicant would probably not have been
prosecuted (applying Stage 1 of the CPS guidance, the CPS must abide by the decision of the competent
authority unless there are clear reasons not to do so and, applying Stage 3 of the guidance, the evidence
limb of the full code test would probably not have been fulfilled) and if he had been prosecuted, he would
have had a defence under section 45 of the Modern Slavery Act.

**The applicant's guilty plea**

42. However, the position was different in 2018 at the time of the proceedings below. At that time there
was a negative conclusive grounds decision and the applicant chose to plead guilty, despite receiving
advice about the possibility of a defence under section 45. It is therefore necessary to consider whether the
applicant should be permitted to vacate his guilty plea, which unless vacated stands as a formal public
admission of guilt (and therefore as an admission that he has no valid defence), as Lord Hughes explained
in R v Asiedu _[[2015] EWCA Crim 714:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FW9-9W11-F0JY-C09M-00000-00&context=1519360)_


-----

“19. A defendant who pleads guilty is making a formal admission in open court that he is guilty of the
offence. He may of course by a written basis of plea limit his admissions to only some of the facts alleged
by the Crown, so long as he is admitting facts which constitute the offence, and Asiedu did so here. But
ordinarily, once he has admitted such facts by an unambiguous and deliberately intended plea of guilty,
there cannot then be an appeal against his conviction, for the simple reason that there is nothing unsafe
about a conviction based on the defendant's own voluntary confession in open court. A defendant will not
normally be permitted in this court to say that he has changed his mind and now wishes to deny what he
has previously thus admitted in the Crown Court.”

43. The circumstances in which an appellant who pleaded guilty but was subsequently found to have been
a victim of trafficking can nonetheless appeal against conviction were considered in R v T _[[2022] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
_[Crim 108 and affirmed in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_ _AAD at [155] to [157], building on what had been said in_ _Asiedu. Three broad_
categories of case were identified where a conviction can be overturned following a guilty plea, albeit this
was stated not to be a closed list. The first category is where the plea of guilty is vitiated in some way.
Examples are where the plea is equivocal or unintended; where it is compelled as a matter of law by an
erroneous ruling by the trial judge; where the appellant has been subjected to improper pressure, for
example from the judge; or where erroneous legal advice or failure to advise as to a possible defence has
deprived the appellant of a defence which would probably have succeeded (see also _R v Mateta_ _[2013]_
_EWCA Crim 1372, [2014] 1 WLR 1516). The second category is where the appellant ought not to have_
been prosecuted at all on the grounds that it was offensive to justice to bring him to trial. Finally, there was
said to be “a small residual third category” where “it is established that the appellant did not commit the
offence, in other words that the admission made by the plea is a false one”.

44. Mr Ben Douglas-Jones QC for the applicant accepts that the applicant was advised about the
possibility of a defence under section 45, but criticises the advice which the applicant received. He submits
that the advice given was wrong because it was based upon what has now been shown to have been an
erroneous negative conclusive grounds decision. Further, instead of being advised that he would need to
challenge this conclusive grounds decision which would be difficult and would need an adjournment while
the applicant would remain in custody, he should have been advised that he did not need to challenge that
decision and merely needed to give evidence for the jury to assess his account of having been trafficked
and acting under compulsion. Moreover, he should also have been advised that he should only plead guilty
if he was guilty.

45. We would not criticise the advice given by trial counsel, based on the facts as they were known at the
time, about the prospect of establishing a defence under section 45. The admissibility or otherwise at trial
of a conclusive grounds decision had not yet been determined and, in any event, counsel was entitled to
give it weight as the view of the competent authority when formulating his advice. Further, it was apparent
(as the applicant's latest statements accept) that there were inconsistencies and errors in the applicant's
account. If the applicant had contested the trial, he would have faced cross-examination on those
inconsistencies and errors and he did not as yet have the benefit of a psychiatric report supporting his
account and going some considerable way to explain away inconsistencies. It was therefore reasonable to
advise that the defence under section 45 would face difficulties and that, if it was to be advanced, it would
be prudent to apply for an adjournment. In his written submissions Mr Douglas-Jones appeared to submit
that an adjournment was unnecessary as the prosecution case itself acknowledged that the applicant had
been exploited, but this falls far short of establishing the elements of a section 45 defence, even
acknowledging that once the issue was raised, the burden would be on the prosecution to disprove those
elements. In oral submissions, however, Mr Douglas-Jones accepted that an adjournment would be
necessary in order to run the defence under section 45 with a real prospect of success. It is not clear to us
whether the applicant was advised in terms that he should only plead guilty if he was guilty but, even if this
advice was not given, it is very doubtful whether it would have made any difference.

46. It seems clear that the decisive factor in the applicant's decision to plead guilty was the fact, confirmed
by the judge's unsolicited indication, that the applicant had already served all or almost all of the sentence
which he would receive if he pleaded. This court has made clear that such indications should not be given.
They risk creating inappropriate pressure on a defendant and narrow the proper ambit of his freedom of


-----

choice, as explained in _R v Nightingale_ _[[2013] EWCA Crim 405 and reiterated in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:584X-GG21-F0JY-C0H4-00000-00&context=1519360)_ _T and_ _AAD. Such_
indications are, moreover, unnecessary as the existence of sentencing guidelines, including as to the credit
to be given for a guilty plea, makes it relatively straightforward for a defendant's lawyers (at any rate in a
case such as this) to advise about the likely sentence.

47. Moreover, the judge's indication was particularly ill-advised as it must have conveyed the impression
that, if the applicant pleaded guilty, he would shortly be released. In view of the applicant's status as an
illegal immigrant, that was a matter over which the judge had no control and of which in all probability he
had no knowledge. It appears that the applicant was advised, in the light of the judge's comments, that his
sentence had effectively been served, but there is no indication that he was advised about what would
happen to him next. This was in fact that he was likely to be held in immigration detention until he was
deported.

48. Accordingly the real choice which the applicant faced was between pleading guilty, in which case he
would be held in immigration detention and then deported, or pleading not guilty and applying for an
adjournment, in which case he would be likely to be held in custody until his trial could take place, but with
the prospect of improving his immigration position in the event of an acquittal. None of this, it seems, was
explained to him. In these circumstances it seems to us that the applicant's guilty plea can properly be
regarded as vitiated by a combination of the pressure placed upon him by the judge's comments and a lack
of understanding of the consequences of the decision which he was being asked to make. This is a case
where the Court of Appeal should intervene on the basis that the applicant's conviction is unsafe. It has
now become clear that the applicant had a good defence under section 45 which would quite probably
have succeeded if the evidence which is now available had been available at the time. His public
admission of guilt was based on a false understanding of his true position.

**Abuse of process**

49. It is therefore unnecessary to say anything about the proposed further ground of appeal to the effect
that the prosecution of the applicant was an abuse of process.

**Conclusion**

50. For these reasons we grant leave to appeal and allow the appeal. The conviction is quashed.

**End of Document**


-----

# R v BWM

_[[2022] EWCA Crim 924, [2022] 4 WLR 116](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65VM-CXY3-GXF6-84FW-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 05/07/2022**

# Catchwords & Digest

**CONVICTION – PRODUCTION OF CANNABIS – APPEAL AGAINST CONVICTION**

quashed. The defendant pleaded guilty to being concerned in the production of cannabis. He was sentenced to 13
months’ imprisonment. The defendant relied on two grounds of appeal, namely that his conviction was unsafe
because (i) he was not advised (or not properly advised) of the defence available to him under
**_Slavery Act 2015, when that defence would probably have succeeded; and (ii) the prosecution was an abuse of_**
process in that, had the prosecution known at the time about the defendant’s status as a victim of trafficking, it
would or might not have prosecuted him. The court held, among other things, that the applicant had a good defence
under s 45 of the Act which would quite probably have succeeded if the evidence which was currently available had
been available at the time. His public admission of guilt was based on a false understanding of his true position.

# Cases considered by this case

R v Tredget

_[[2022] EWCA Crim 108, [2022] 4 WLR 62](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
Considered

R v AAD and others

_[[2022] EWCA Crim 106, [2022] 1 WLR 4042](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
Followed

R v AAJ

_[[2021] EWCA Crim 1278](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_
Followed

R v Brecani

_[[2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62R7-7X53-GXFD-802D-00000-00&context=1519360)_
Considered


08/02/2022

CACrimD

03/02/2022

CACrimD

29/07/2021

CACrimD

19/05/2021

CACrimD


-----

R v L (2017)

_[[2017] EWCA Crim 2129](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
Applied

R v Asiedu

_[[2015] EWCA Crim 714, [2015] 2 Cr App Rep 95](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5FW9-9W11-F0JY-C09M-00000-00&context=1519360)_
Considered

R v Mateta

_[[2013] EWCA Crim 1372, [2014] 1 All ER 152, [2014] 1 WLR 1516, [2013] 2 Cr App](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M24B-00000-00&context=1519360)_
[Rep 431, [2013] All ER (D) 19 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:591P-0VG1-DYBP-N4W6-00000-00&context=1519360)
Considered

R v Nightingale

_[[2013] EWCA Crim 405, [2013] 2 Cr App Rep 69, (2013) Times, 26 March](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:584X-GG21-F0JY-C0H4-00000-00&context=1519360)_
Considered

**End of Document**


23/11/2017

CACrimD

30/04/2015

CACrimD

30/07/2013

CACrimD

13/03/2013

C-MAC


-----

