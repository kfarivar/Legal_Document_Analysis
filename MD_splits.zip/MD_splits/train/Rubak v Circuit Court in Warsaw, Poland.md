# Rubak v Circuit Court in Warsaw, Poland [2020] EWHC 2333 (Admin)

Queen's Bench Division, Administrative Court (London)

Fordham J

25 August 2020Judgment

**Mary Westcott (instructed by Dalton Holmes Gray Solicitors) for the Appellant**

**Rebecca Hadgett (instructed by the CPS) for the Respondent**

Hearing date: 25 August 2020

Judgment as delivered in open court at the hearing

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that no official shorthand note shall be taken of this Judgment and that copies of this version as handed
down may be treated as authentic.

IMAGE NOT AVAILABLE

.............................

THE HON. MR JUSTICE FORDHAM

Note: This judgment was produced for the parties, approved by the District Judge, after using voice-recognition
software during an ex tempore judgment in a Coronavirus remote hearing.

**MR JUSTICE FORDHAM :**

Introduction

1. This is an application for permission to appeal in an extradition case. The appellant is aged 48 and is
wanted for extradition to Poland, in conjunction with two conviction EAWs. Following an oral hearing,
Judge Goozee ordered the appellant's extradition on 13 February 2020. Spencer J refused permission to
appeal on the papers on 13 July 2020. The appellant has been in the UK since May 2018.

Four issues

2. Four issues were in the frame in particular, and still are, so far as resistance on legal grounds of
extradition is concerned. (1) The District Judge had to consider section 20 of the Extradition Act 2003,
finding in relation to that matter that the appellant had been “deliberately absent” from the relevant hearing.
(2) The District Judge had to consider section 14 of the 2003 Act and the passage of time, finding in
relation to that matter that the appellant was a “fugitive”. (3) The District Judge had to consider Article 4
ECHR in the light of the trafficking matters which had been raised, holding that the Polish authorities
attracted the presumption of compatibility which had not been rebutted on the evidence. (4) The District
Judge also had to consider Article 8 ECHR and rejected the argument that extradition would be Article 8

-----

incompatible, on an analysis in which the finding of “fugitivity” played a role. This summary is intended only
to give an introductory overview it is not a description of all of the various issues and sub-issues or of the
entirety of the District Judge's reasoning. I have however referenced some of the particular headline points
that are relevant for what comes next.

Coerced to travel for work: the District Judge's reasoning

3. The appellant and his then partner alleged that they had come to the United Kingdom in May 2018
being coerced to travel for work. The District Judge said in one passage: “I find there is credible evidence
to show that on entry into the UK the [appellant] and his ex-partner may have been victims of human
trafficking and exploitation”. The passage goes on to focus in particular on events which happened when
the appellant arrived in the UK and are linked to what had been stated in what was then the post'reasonable grounds' decision stage of the domestic NRM processes. In the very next paragraph, the
District Judge then said this: “there is no evidence the [appellant] or his ex-partner were coerced or forced
in Poland to leave the country. They left of their own free will. As I have already found above, I also find the

[appellant] was fleeing Poland to avoid serving the prison sentences”. In the next paragraph, he said:
“having made the choice to leave Poland and come to the UK, I find there is evidence they were then
exploited in the UK.”

My decision

4. I have decided that the appropriate course to take in this case in relation to three of the four issues is to
direct a 'rolled up hearing' at which the court will be able, in a single shot and at a relevantly later stage, to
consider all of the arguments and evidence in both directions. There is one ground however namely the
section 20 “deliberately absent” ground, which I see no basis at all for not dealing with today dispositively.
In circumstances where I see it as an entirely distinct issue, and I regard it as clearly having no realistic
prospect of success, I am refusing permission to appeal today in relation to the section 20 ground. The
other grounds will survive, alongside a new point which I will describe. There have been various 'moving
parts' in this case of which two are particularly important, as I will explain.

Mode of hearing

5. The mode of hearing was a BT conference call. Like the parties' representatives, I was satisfied that a
telephone hearing was appropriate. I heard oral submissions in exactly the way I would have done had we
all been physically present in a court room. The hearing and its start time – together with an email address
which could be used by any person wishing to observe the hearing – were published in the cause list. The
hearing was recorded. This judgment will be released into the public domain. By having a remote hearing,
we eliminated any risk to any person, from having to travel to, or be present in, a court. I am satisfied that
no right or interest was compromised and that, if there was any interference with or qualification of any
right or interest, it was justified as necessary and proportionate.

The effective judicial protection development

6. By an application dated 30 July 2020 the appellant asked for permission to add a new ground of appeal
and to stay this case. The ground of appeal now sought to be relied on is the same ground on which I
granted permission to appeal on 3 June 2020 in the case of Wozniak _[2020] EWHC 1459 (Admin). It_
concerns effective judicial protection and the rule of law in Poland, with a focus on s.2 of the 2003 Act and
Article 6 ECHR. The course invited by Ms Westcott for the appellant is that I should give permission, with
an extension of time, for the Wozniak ground to be added, followed by a stay pending the resolution later
this year of Wozniak itself. This is a familiar scenario: see Horchel _[[2020] EWHC 2318 (Admin) and the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60P1-PSN3-GXFD-82S5-00000-00&context=1519360)_
cases referred to in that judgment. The central concern is this. The appellant in this case has now, albeit
belatedly, raised the same point of principle as applies in Wozniak (and a linked case), and which I held in
that case was reasonably arguable. It would, on the face of it in my judgment, be unjust for the appellant to
be removed while that point of principle remains unresolved. Once the Divisional Court has addressed the
point, the implications for other cases including this one can be dealt with. The respondent is neutral. I will
give permission to amend the grounds of appeal and an extension of time. I will direct that the application


-----

for permission to appeal on the new ground take place, at the rolled-up hearing (if the point is maintained),
after the judgment in Wozniak.

The trafficking development

7. I have explained that the time of the District Judge's judgment the National Referral Mechanism was in
operation but only a 'reasonable grounds' decision had at that stage been arrived at. I have already quoted
some of the passages from the District Judge's judgment, where he made observations and findings
relevant to the claim that the appellant and his partner had been 'coerced to travel to the UK for work'. In a
second key moving part in this case, on 20 March 2020 a 'conclusive grounds' determination was made.
That determination, applying the civil standard of proof, accepted that the appellant was 'a victim of
**_modern slavery in the United Kingdom during 2018 for the specific purposes of forced labour'. It is_**
particularly relevant to note that in the narrative of that formal decision is the description of events from
April 2018 culminating in the travelling to the United Kingdom from Poland. The narrative describes what it
says is a “picture that the [appellant] was transported to the UK by an organised group with the promise of
a job and money”.

The finding of fugitivity and the trafficking development

8. I have already described the fact that the District Judge's Article 8 analysis was influenced by his finding
of fugitivity, and that his section 14 analysis included the conclusion that the appellant was barred from
relying on section 14 passage of time because of the finding of fugitivity. The appellant seeks, through an
application dated 4 June 2020, to introduce for the purposes of this appeal fresh evidence including the
conclusive grounds determination to which I have referred. The statutory scheme for appeals to this Court
contains provision by which the Court can, in an appropriate case, receive fresh evidence and can also
evaluate the legality of extradition (against the applicable legal standards) on the basis of that fresh
evidence and the updated factual position. It is therefore at least open to an appellant to invite this court to
consider the implications, including for the finding of fugitivity – a matter requiring proof to a criminal
standard – of the fact that the appellant has himself satisfied a decision-maker on the civil standard that he
was trafficked, in a decision which appears on its face to reflect not just the circumstances post-arrival in
the United Kingdom but also the events from April and the circumstances in which the appellant came to
leave Poland.

9. In my judgment, that is a point of significance and engages a question of principle. One asks the
question: what room is there, in principle, for a finding that an individual is a “fugitive”, having deliberately
“put himself beyond the reach of” the legal process of the requesting state, if the evidence in the case
supports the conclusion that that same individual, in leaving that country, was 'coerced to travel for work'.
The District Judge took the view of this case that the appellant had made a free choice to leave Poland to
put himself beyond the reach of Polish justice and that the trafficking considerations (i) concerned only
what happened in the United Kingdom post-arrival or (ii) concerned the mode by which the appellant put
into effect the choice he had made. It is not at all clear to me in the light of the new material that that is a
sustainable analysis.

10. At the oral hearing this morning the parties referred to an authority Vilionis [2017] EWHC 336 (Admin).
That was a trafficking case but one in which a finding of fugitivity co-existed. I was concerned to see
whether that constituted in favour of the respondent a 'knockout blow'. Paragraph 18 of that judgment, as I
read it, is describing a finding of fugitivity in circumstances where the District Judge had “rejected the
account that the appellant had been trafficked to England” although it was “accepted that once here he was
exploited”. That makes the point, as I see it, that there may be room for the findings of trafficking and
fugitivity to co-exist in a case, depending on its facts, where the trafficking leaves untouched the choice of
voluntary action of the individual in leaving the jurisdiction. For reasons which I have explained, that
analysis is on the face of it put into doubt, at least based on the fresh evidence. If a finding of fact of
fugitivity can no longer stand, the question then arises: how does that influence the section 14 analysis and
the Article 8 analysis?

Relevance of the effective judicial protection development


-----

11. There is also the added complication of the Wozniak points and the rule of law doubts relating to
effective judicial protection, as yet unresolved but soon to be resolved. Ms Hadgett, for the respondent,
fairly accepted that there was a potential overlap between the sorts of effective judicial protection concerns
that arise in Wozniak (and Article 6 issue in Chlabicz, the case to which was the act is linked) and which
arise under the human rights arguments in this case: under the Article 4 and Article 8 issues. It seems to
me the same realism should extend to the questions of oppression and injustice arising under the section
14 issue.

Permission to appeal?

12. In all the circumstances, one option would have been to grant permission on all three of the grounds,
where there is a potential overlap with effective judicial protection, and a potential problem arising from the
new development of the conclusive grounds determination. I do not think that would be the right course.
Everybody is protected by a rolled up hearing. Moreover, since I am not prepared to grant permission to
appeal on the Wozniak point but rather to stay that question, it makes perfect case-management sense in
my judgment to direct the rolled up hearing of the section 14, Article 4 and Article 8 issues in this case and
to direct a hearing, after the Divisional Court judgment in Wozniak and Chlabicz, at which all of the
arguments can be considered. If the Court at that rolled up hearing, in the light of the submissions that it
has received and on the basis of the position as then applies before it, takes the view that there is a
shortcut 'knockout' answer to any of the grounds, that Court would then be perfectly entitled to refuse
permission to appeal.

The section 20 ground

13. I have explained that there is one ground which in my judgment attracts Ms Hadgett's description of
being a distinct point having no realistic prospect of success. She submitted that if there was any ground
falling within that description, I should 'grasp that nettle' today and refuse permission to appeal. That
description does in my judgment fit the section 20 ground of appeal. The issue concerns a hearing in
absence and, in particular, whether the District Judge sustainably found as a fact that the appellant had
been “deliberately absent” from that hearing. I am quite satisfied that that issue is entirely distinct: from the
trafficking features of the case which arose subsequently from April 2018 onwards; from issues as to
fugitivity; and from issues relating to effective judicial protection. The District Judge made a finding of fact
that he was satisfied that the appellant had been “deliberately absent”. That was fatal to the section 20
argument. Having looked at the reasoning and key materials with the assistance of both counsel I am quite
satisfied, as was Spencer J on the papers, that this ground is not reasonably arguable.

14. The District Judge in a passage entitled “findings on the evidence” made a finding that he did not find
the evidence of the appellant as to non-receipt of a summons to attend court on 17 April 2013, in relation to
the theft offence which became the subject of EAW1, to be credible. The District Judge went on to say that
the further information made clear that the appellant had proposed the penalty which had been accepted. It
then said that the appellant had 'submitted a motion to the Polish court to issue a judgment without a trial',
referring to further information dated 3 December 2019. I have looked at the underlying material. Further
information dated 9 October 2019 stated that the Polish court had 'accepted the proposed penalty put
forward by the appellant himself and submitted to the court' and had 'issued the judgment according to the
motion of the appellant'. The further information dated 3 December 2019, to which the District Judge
referred, stated in terms that “the court … accepted the request to issue a judgment without a trial and the
court imposed the penalty proposed by [the appellant] and accepted by the prosecutor”.

15. Ms Westcott submits that it is a fatal error to proceed from 'prior agreement to sentence' to a
conclusion of 'deliberate absence' at the hearing. She cited an authority as an illustration of the fact that
'prior agreement to sentence' and yet 'no deliberate absence from the hearing' can coexist, depending on
the facts. The case was Dworzecki CJEU 24 May 2016 at paragraph 12 and paragraph 54. Be that as it
may, this is a fact specific matter and the District Judge did not proceed from 'prior agreement to sentence'
to a conclusion of 'deliberate absence'. Nor did the materials before him do so. The documents make clear
that there had formally been an application from the appellant himself, inviting the Polish court to deal with
th tt ith t h i I th i t th Di t i t J d ' l i t d lib t


-----

absence was not only reasonably open to him and supported by evidence, it was plainly correct. There is
no realistic prospect, in my judgment, of this Court finding that that conclusion was not open to the District
Judge on the evidence. As it happens, the District Judge also made a finding of fact as to credibility on
whether the appellant had notice. Ms Westcott accepts that she would need to establish a 'manifest lack of
diligence' so far as prior notice is concerned. I regard the section 20 ground as hopeless on the evidence
and will refuse permission to appeal on that ground.

Further observations

16. In all those circumstances there is perhaps little to be achieved by me saying any more. I will make the
following further brief observations, in case it is of assistance to the parties that I do so. On the issue of
fugitivity and trafficking, I see the force in Ms Westcott's emphasis on the fact that two critical dates arose
in this case the month after the appellant and his then partner travelled to the United Kingdom to the UK
from Poland. The first is 19 June 2018 when the appellant failed to surrender in Poland in relation to the
robbery matter which became the subject of EAW2. The second is 22 June 2018 when the previously
suspended sentence in relation to the theft conviction (which became EAW1) was activated. I mention that
because the submission made is that by that stage on those two key dates the appellant was in the
clutches of human traffickers. Next, I observe that the District Judge emphasised the lack of nexus
between (i) the trafficking contentions and (ii) the underlying criminality (the subject of the EAWs). But that
may not be the correct focus for the purposes of the various issues that remain live in this case. Next, there
has been some debate before me as to the position after November 2018 when the appellant and his
partner escaped the clutches of the traffickers, and the true characterisation in law to be given to their
position thereafter. But it is not suggested by Ms Hadgett that any 'knockout' points arise in relation to that.
Nor can she point to any finding by the District Judge that would leave me with confidence to conclude that
any of the three remaining grounds lack a realistic prospect of success.

17. I have referred to the authority of Vilionis. There is a passage in paragraph 13 of that judgment which
reads as follows: “[counsel] recognised that there was no tenable argument that his extradition to Lithuania
would violate his rights under Article 4 ECHR. To succeed in showing that his surrender would breach
Article 4 ECHR and appellant must show not only that he is a real risk of being re-trafficked by criminals
but that the requesting state is not in a position to provide appropriate protection”. Ms Westcott makes no
similar concession in relation to this case and she maintains that there is a substantive ground arising
under Article 4. I am not ruling today on reasonable arguability, given all of the moving parts and the links
between the various issues and in light of the fact that a rolled up hearing provides for the just disposal for
all of the remaining arguments. It may be that the Article 4 substantive point is difficult to sustain in the light
of that passage. Even that would not dispose though of the Article 4 ground completely. Ms Westcott
emphasises the procedural aspect of Article 4. She submits that, at least on the facts of the present case,
there is a present positive obligation of investigation under Article 4. She submits that, in principle, the
extradition of the appellant will interfere with the effective discharge of that obligation. She emphasises
that, so far as concerns the actions of the Polish authorities either to effect steps or to undertake
appropriate coordination and liaison, there is a link to the effective judicial protection concerns recognised
in the Wozniak case, about to be clarified by the Divisional Court in that case. As I have already explained,
Ms Hadgett realistically accepts that there is scope for overlap. She accepts that overlap, moreover, even
in the context of the Article 8 evaluation. I have considered the findings made by the District Judge relevant
to the Article 8 analysis; and also relevant to oppression and injustice from the perspective of section 14.

18. I have sufficient concerns in this case, particularly in the light of the two developments that I have
emphasised, that I am not prepared to refuse permission to appeal today in relation to any of the remaining
grounds. This is a wholly exceptional case, in which very particular facts arise and very particular public
policy considerations. Once Wozniak has been decided, it is likely that the arguments will be brought into
close focus in one way or another. I am satisfied that a court conducting a rolled up hearing, with the
assistance of the submissions and materials that the parties wish to put forward, will have a clear and
focused picture for a dispositive resolution on all issues. I am quite satisfied that that is the, and the only,
just and appropriate course.


-----

25 August 2020

**End of Document**


-----

