# DC (trafficking: protection/human rights appeals) Albania [2019] UKUT 351
 (IAC)

UK Upper Tribunal (Immigration and Asylum Chamber)

Lane J, Judge Gill and Judge Finch

11 April 2019Judgment

For the Appellant: Mr A Chakmakjian, Counsel, instructed by

Kilby Jones Solicitors LLP

For the Respondent: Mr I Jarvis, Senior Home Office Presenting Officer

Interpreter: Mr S Pashoja (Albanian)

_In the light of the judgment of Flaux LJ in Secretary of State for the Home Department v MS (Pakistan)_

_[2018] EWCA Civ 594 and subsequent decisions of the Upper Tribunal and Administrative Court, a tribunal deciding_
_a protection or human rights appeal, which concerns alleged trafficking within the scope of the Council of Europe_
_Convention on Action against Trafficking in Human Beings and decisions of the Competent Authority (CA) under the_
_United Kingdom's National Referral Mechanism, should proceed as follows:_

_(a) In a protection appeal, the “reasonable grounds” or “conclusive grounds” decision of the CA will be_
_part of the evidence that the tribunal will have to assess in reaching its decision on that appeal, giving the CA's_
_decision such weight as is due, bearing in mind that the standard of proof applied by the CA in a “conclusive_
_grounds” decision was the balance of probabilities._

_(b) In a human rights appeal, a finding by the tribunal that the CA has failed to reach a rational decision on_
_whether the appellant has been the victim of trafficking, such as to be eligible for leave to remain in the United_
_Kingdom for that reason alone, may lead the tribunal to allow the human rights appeal, on the basis that removing_
_the appellant at this stage would be a disproportionate interference with the appellant's Article 8 ECHR rights. This_
_scenario is, however, of narrow ambit and is unlikely to be much encountered in practice._

_(c) In a human rights appeal, the question whether the appellant has been the victim of trafficking may be_
_relevant to the issue of whether the appellant's removal would breach the ECHR, even where it is not asserted_
_there is a trafficking-related risk of harm in the country of proposed return and irrespective of what is said in sub-_
_paragraph (b) above: e.g. where the fact of trafficking may have caused the appellant physical or psychological_
_harm. Here, as in sub-paragraph (a) above, the CA's decision on past trafficking will be part of the evidence to be_
_assessed by the tribunal._

**DECISION AND REASONS**

**_A. INTRODUCTION_**

1. This is the re-making of the decision in the appellant's appeal against the refusal on 2 December 2017 by the
respondent of the appellant's protection and human rights claims. The decision of the First-tier Tribunal, which had
allowed the appellant's appeal by a decision dated 3 October 2018, was set aside in its entirety by Upper Tribunal


-----

Judge Gill in a decision dated 11 April 2019. That decision, in which the appellant is referred to as “DJ”, is annexed
to this one.

2. In refusing the appellant's claims, the respondent accepted that the appellant was a citizen of Albania and that
her claimed identity was correct. The respondent, however, rejected the assertion that the appellant had been the
victim of sex trafficking and that she had been domestically abused by her father. The refusal letter drew upon the
appellant's asylum interview record, a letter from her representatives of 13 February 2017 and a letter from what
was said to be a doctor in Albania dated 18 September 2015. From these, the respondent noted that the appellant
claimed to be a member of a particular social group; namely, women who had been trafficked. Her father used to
beat the appellant when he was drunk and the doctor's letter said she had been mistreated by her family from 2009
to 2014.

3. In May 2011, the appellant said she met a man whom we shall call B, with whom she began a relationship which
lasted until August of that year. When the appellant attempted to end the relationship, B began blackmailing her to
work as a prostitute. He threatened to show her family a sex video of the appellant that he had secretly made.

4.  On 26 August 2011, B came to the appellant's family home to take her away. B informed the appellant's father
about the appellant being a prostitute, at which her father threw B from a balcony and then beat the appellant, who
woke up at the home of her uncle, to find that she had been treated by a doctor. She stayed at her uncle's from
then on, occasionally going home to visit her mother. During this time, the appellant worked as a prostitute for B.

5. In August 2015, B took the appellant to Italy by car for the purposes of prostitution. In Italy, the appellant met a
client of B, called Lorenzo, who arranged her escape, using false documents. Lorenzo and the appellant travelled
to France and then to Belfast, via Dublin. The appellant was detained in Belfast, attempting to take a ferry to
Scotland.

6. The appellant told the respondent that she feared persecution from B because he had forced her to work as a
prostitute. She also feared ill-treatment and persecution from her father “because he is an alcoholic and beat you
generally … and/or he is aware of your situation as a prostitute and will kill you because of this” (decision letter,
paragraph 20).

7. As we have already said, the decision stated that the appellant was not accepted to be the victim of trafficking.
That is plain from paragraph 44, which reads: “Not accepted – You are a victim of trafficking” (original emphases).
At paragraph 45, the reason given by the respondent for this conclusion was that the appellant had been referred to
the Competent Authority (CA) under the National Referral Mechanism (NRM), which has the function of identifying
victims of trafficking under the Council of Europe Convention on Action against Trafficking in Human Beings.
Paragraph 45 of the refusal letter stated that the NRM (sic; presumably the CA was meant), having considered the
appellant's claim and all the available evidence, was of the “opinion that you are not a victim of trafficking. The
reasons for this decision have been outlined in their conclusive decision letter dated 08 August 2016. Therefore in
light of the NRM response, it is not accepted that you have been trafficked”.

8. At paragraph 60, however, the letter stated that “as previously noted, it is accepted you were a victim of
trafficking”. On this basis, the appellant's case was, accordingly, assessed by the respondent by reference to the
relevant country guidance on the risk on return to Albania of victims of trafficking: TD and AD (Trafficked Women)
[CG [2016] UKUT 00092 (IAC) and AM and BM (Trafficked Women) Albania CG [2010] UKUT 80.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J57-XW71-F0JY-C30M-00000-00&context=1519360)

9.  Applying that country guidance to the appellant's circumstances, as the respondent considered them to be, the
respondent concluded that the appellant would not be at real risk of serious harm on return to Albania, as someone
who had been the victim of trafficking. Amongst the factors considered were the appellant's level of education
(having completed school at age 18 and started university) and the fact that the appellant would be returning with
an illegitimate child, born in the United Kingdom. It is clear from paragraph 65 of the decision letter that the
respondent considered the father of the child was Lorenzo; in any event, the respondent took the position that the
child would be able to call on its father for support in Albania.


-----

10. The respondent also considered that the age of the appellant (23 at the date of decision) meant that she was
not in the prominent risk category for re-trafficking, albeit that the Upper Tribunal had found that it was “not unusual
for trafficked women to be older”.

11. On a proper reading of the refusal letter, we consider that the respondent, having concluded that the appellant
had not shown that she had been a victim of trafficking, nevertheless considered what the position might be, if she
had been trafficked.

**_B. TRAFFICKING DECISIONS AND APPEALS AGAINST REFUSALS OF HUMAN RIGHTS_**
**_OR PROTECTION CLAIMS_**

12. Before turning to the re-making of the appellant's appeal, it is necessary to address the matter raised in Upper
Tribunal Judge Gill's decision of 11 April 2019. At paragraph 40, she identified –

“… a need for general guidance to be given on the approach to be taken by the First-tier Tribunal or the Upper
Tribunal in determining appeals brought on protection grounds in which it is alleged that the appellant has been
trafficked but where there has been a negative “Conclusive Grounds” decision [of the CA] which has not been
challenged in judicial review proceedings”.

13. We received helpful submissions from the representatives on this issue. In particular, Mr Chakmakjian
provided a skeleton argument dealing with the authorities, to which we shall turn in a moment. Overall, we accept
much of Mr Chakmakjian's analysis, which has helped to inform the discussion which follows.

14. Before going any further, it is necessary to set out in somewhat greater detail the legal framework that we
mention in paragraph 7 above.

**_(a) Legal framework_**

15. On 17 December 2008, the United Kingdom ratified the Council of Europe Convention on Action Against
Trafficking in Human Beings, which had come into force in 2009. The purpose of the Convention is to prevent and
combat trafficking in human beings; to identify and protect victims of trafficking and to safeguard their rights; and to
promote international co-operation against trafficking.

16. Article 10 of the Convention provides as follows:

“Each party shall adopt such legislative or other measures as may be necessary to identify victims as appropriate in
collaboration with other Parties and relevant support organisations. Each party shall ensure that, if the competent
authorities have reasonable grounds to believe that a person has been the victim of trafficking in human beings,
that person shall not be removed from its territory until the identification process as a victim of an offence provided
for in Article 18 of this Convention has been completed by the competent authorities and shall likewise ensure that
the person receives the assistance provided for in Article 12, paragraphs 1 and 2.”

17. It can be seen from Article 10 that there is a preliminary analysis to be conducted in determining whether a
person who is liable to be removed from the United Kingdom is a victim of trafficking. This requires a determination
of whether the competent authorities have “reasonable grounds to believe that a person has been victim of
trafficking”. If the CA decides that there are no reasonable grounds for so believing, the Convention imposes no
further impediment to that person's removal. But if it is determined that there are such reasonable grounds, it is
necessary for the CA to proceed to a second stage, which involves a substantive determination of whether the
person is a victim of trafficking.

18. If, at the end of that second stage, the CA determines conclusively that the person is not a victim of trafficking,
then, again, the Convention will pose no further impediment to removal. But if the conclusive decision is that the
person is a victim, the Convention does not require the victim to be given the right to live in the United Kingdom.
What Article 14 requires is that a renewable residence permit shall be issued to the victim in two particular
situations: (i) to enable the victim to co-operate with the authorities for the purposes of criminal proceedings or


-----

investigation; and (ii) where the CA considers it necessary for the victim to stay in the United Kingdom owing to his
or her personal situation.

19. The Convention is an unincorporated international treaty, whose provisions have not found their way into any
primary or secondary legislation in the United Kingdom; nor even into the immigration rules. As a result, the issue of
the United Kingdom's compliance with the Convention is a matter of government policy and practice: Ahmed v HM
Treasury _[2010] UKSC 2. However, although the Convention is not a free-standing source of rights, the_
respondent's policy is to give effect to the Convention and it will be an error of law for the respondent not to take
that policy into account: AS (Afghanistan) v SSHD [2013] EWCA Civ 1469.

20. The way in which the United Kingdom gives effect to its obligations under the Convention is, therefore, through
the respondent's domestic policies. The NRM provides a non-statutory framework for victim identification and
support. The NRM is designed to facilitate co-operation and information-sharing between the different agencies that
may be involved in a trafficking case, in order to identify victims and provide them with advice, accommodation,
protection and support. The respondent has also published guidance on the functions of the CA. This guidance is
intended to help the CA decide whether a person referred under the NRM is a victim of trafficking.

21. There is no right of appeal against a negative “reasonable grounds” decision or against a negative “conclusive
grounds” decision. The only means of challenge is judicial review. The test is the well-known one of rationality (aka
_Wednesbury unreasonableness)._

22. The guidance to the CA states that the issue to be decided in a “reasonable grounds” decision is whether it is
“reasonable to believe” a person is a victim of trafficking, on the information then available. The guidance describes
this as a “relatively low threshold”. By contrast, the standard of proof that the CA is to apply in making a “conclusive
grounds” decision is the balance of probabilities. In R (MN) v Secretary of State for the Home Department and the
Aire Centre [2018] EWHC 3268 (Admin), to which we shall return in due course, Farbey J held that the balance of
probabilities was the correct standard.

23. In deciding a protection claim or an appeal against the refusal of such a claim, in which the issue is whether a
person's fear of persecution or other serious harm is well-founded, the respondent or tribunal applies the so-called
lower standard of proof of a “real risk” or “reasonable likelihood”: R (Sivakumaran) v SSHD [1987] UKHL 1.

**_(b) Case law_**

24. There are four authorities to consider: Secretary of State for the Home Department v MS (Pakistan) _[2018]_
_[EWCA Civ 594, AUJ (Trafficking – no conclusive grounds decision) Bangladesh [2018] UKUT 200 (IAC), ES (s82](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SKW-5V81-F0JY-C059-00000-00&context=1519360)_
NIA 2002; negative NRM (Albania) [2018] UKUT 335 (IAC) and R (MN) v Secretary of State for the Home
Department, The Aire Centre intervening [2018] EWHC 3268 (Admin).

**Secretary of State for the Home Department v MS (Pakistan) [2018] EWCA Civ 594**

25. In this case, the Court of Appeal was required to determine the lawfulness of decision of the Upper Tribunal,
which had allowed the claimant's appeal on the basis that, although the claimant had not established a real risk of
serious harm if returned to Pakistan (whether by reason of re-trafficking or otherwise), the claimant had not received
a lawful decision from the CA in respect of his claim to have been trafficked to the United Kingdom from Pakistan.

26.  Flaux LJ gave the only reasoned judgment of the Court. The appeal which the Upper Tribunal allowed had
been brought under the provisions of the _[Nationality, Immigration and Asylum Act 2002,as they were prior to the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)_
[extensive amendments made by the Immigration Act 2014. The claimant had appealed against a decision of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
respondent that fell within section 82(2)(g) of the 2002 Act; namely, a decision to remove the claimant from the
United Kingdom under the powers contained in section 10 of the Immigration and Asylum 1999. Under section
84(1) of the 2002 Act, as then in force, the claimant could appeal against the removal decision on the ground that
that decision was unlawful under section 6 of the Human Rights Act 1998 (84(1)(c)) or that the decision was
“otherwise not in accordance with the law” (section 84(1)(e).


-----

27. Flaux LJ considered that what the Upper Tribunal had done was “to engage in a complete re-determination of
the issues as to whether the respondent was trafficked and to reach a decision that he was, despite having failed to
identify any specific respect in which the decisions of the authority were open to a _Wednesbury challenge”_
(paragraph 77). Flaux LJ held that this approach was wrong in law. The Upper Tribunal was bound by the authority
of the Court of Appeal in AS (Afghanistan), which held that a tribunal hearing an appeal against a removal decision
as described in section 82(2)(g) of the 2002 Act could reach its own conclusion whether an appellant had been
trafficked, only where the decision of the CA was found by that tribunal to be perverse: paragraphs 23 to 26, 69 to
71 and 77.

**_(c) The ambit of MS (Pakistan)_**

28. A good deal of the uncertainty about the role of the First-tier Tribunal and the Upper Tribunal in dealing with
decisions of the CA that has arisen since MS (Pakistan) results from a failure to appreciate the proper ambit of
Flaux LJ's judgment. At no point did he hold that a tribunal deciding an appeal under the 2002 Act (whether before
or after the 2014 amendments to the appellate regime) is not permitted, for the purposes of determining that appeal,
to reach its own conclusions, applying the lower standard of proof, on whether the appellant has been the victim of
trafficking. What the Court was doing in MS (Pakistan) was to identify the circumstances in which the tribunal can
directly critique a “reasonable grounds” or “conclusive grounds” decision.

29. As we have seen, the Convention requires the United Kingdom, along with other signatory states, to act in a
positive manner towards those who are victims of trafficking. The respondent gives effect to that requirement
(which is not directly enforceable in United Kingdom law) by means of policies which, if not followed, will give rise to
public law liability, as AS (Afghanistan) explains. For example, a person who has been adjudged by the CA to be a
victim of trafficking may be granted discretionary leave to remain in the United Kingdom, even where he or she
does not qualify “for other leave such as asylum or humanitarian protection” (Home Office: Discretionary leave
considerations for victims of modern slavery – Version 2.0 (10 September 2018)).

30. In allowing the claimant's appeal in MS (Pakistan), the Upper Tribunal was deciding an appeal which, under the
relevant legislation, had to be allowed if the Upper Tribunal found the removal decision was “not in accordance with
the law”. Insofar as that issue turned upon whether the respondent had acted in accordance with her policies on
trafficking, Flaux LJ held that the question for the Upper Tribunal was not whether it would have reached a different
decision than the CA did on this issue but, rather, whether the CA's decision was irrational. The Court of Appeal's
conclusion was, therefore, a paradigm instance of the well-established legal position, which leaves the formulation
and implementation of policy to government, not the judiciary, provided that the government does not act in a way
that is Wednesbury unreasonable.

31. Under the present appellate regime, there is no longer a requirement to allow an appeal where a decision is
“not in accordance with the law”, in the sense just described. It is, however, still possible for the same
considerations to impact upon a so-called human rights appeal; that is to say, an appeal brought under section
84(2) of the 2002 Act on the ground that the decision to refuse a person's human rights claim is unlawful under
section 6 of the Human Rights Act 1998 (whereby it is unlawful for a public authority to act in a way that is
incompatible with a right contained in the European Convention on Human Rights). A refusal of a human rights
claim is a refusal of a person's claim that to remove him or her from the United Kingdom or to require them to leave
would be unlawful under section 6: see section 113 of the 2002 Act.

32. Provided a person has a private or family life that is protected by Article 8(1) of the ECHR, he or she can bring
a human rights appeal on the basis that it would be a disproportionate interference with their enjoyment of that right
to remove them from the United Kingdom or require them to leave. In deciding what is proportionate, the tribunal
will be required to give weight to the importance of maintaining the respondent's system of immigration controls. But
where the respondent has failed to follow her own policies relating to the Trafficking Convention, which impact upon
whether and in what circumstances a person might be given leave to remain as a victim of trafficking, the weight to
be given to the respondent's side of the proportionality balance may, depending on all the circumstances, be
significantly reduced.


-----

33. Accordingly, if one takes the scenario in MS (Pakistan) of a person who had no well-founded fear of future
harm in Pakistan, a “conclusive grounds” decision that is found by the tribunal to have been reached irrationally
may well lead to the tribunal deciding that removal at this stage would be a disproportionate interference with the
appellant's Article 8 rights. It will, not, however, be possible for the tribunal to reduce the weight to be given to
immigration control merely because the tribunal would have decided the historic trafficking matter differently from
the CA. It is also important to emphasise the narrow ambit of this scenario. There will, for example, be no practical
scope for it where the appellant succeeds in a protection claim or where, as we go on to say at paragraph 44 below,
the fact of having been trafficked is a matter that impacts directly on Article 8 by reason of its physical or
psychological consequences on the appellant. Nor is it likely to avail an appellant who, on the evidence now before
the tribunal, is bound to be refused discretionary leave pursuant to Article 14 of the Convention, even if the policy
were to be properly applied. Moreover, as the underlined words above indicate, the tribunal will merely be finding
that, because of the respondent's failure to follow her policy, removal would only be disproportionate before the
respondent has been able to rectify that failure. For all these reasons, we doubt that this scenario will be commonly
encountered.

34. By contrast, in an appeal against the refusal of a protection claim under section 82(1)(a) of the 2002 Act, the
assessment of risk on return, whether in terms of the Refugee Convention or Article 3 of the ECHR, is for the
tribunal to determine. To the extent that the resolution of this “protection appeal” involves making findings of fact as
to whether the appellant has been the victim of trafficking, the tribunal must assess all the evidence, applying the
lower standard of proof. The fact that the CA may have reached a negative “reasonable grounds” or “conclusive
grounds” decision will be part of the evidence that the tribunal will have to assess, giving it such weight as is due
(and, of course, bearing in mind that the standard of proof applied in a “reasonable grounds” decision was the
relatively low one described in paragraph 22 above, whereas in a “conclusive grounds” decision, it was was the
balance of probabilities).

35. If the tribunal considers that, on the evidence before the CA, the latter could not rationally have reached the
conclusion it did, then no weight will be afforded to the CA's conclusions. But, even if the CA's negative decision
was impeccable, it will not thereby be determinative of the protection appeal. Not only is it perfectly possible for the
tribunal to conclude that it is reasonably likely the appellant was trafficked, even though the CA has found, on the
balance of probabilities in its “conclusive grounds” decision, that the appellant was not; the tribunal may well have
before it evidence that was not available to the CA.

36.  Where the CA has made a positive “conclusive grounds” decision, this will point strongly in the appellant's
favour in the protection appeal, given the higher standard of proof applied by the CA in coming to that decision. But,
again, it will not necessarily be determinative. The evidence before the tribunal may, for example, show that the
appellant has lied because it has subsequently emerged he was fingerprinted in Greece at a time when, according
to the appellant's account, he was being trafficked in Afghanistan.

37. Once one appreciates the distinction between the tribunal's task in assessing risk on return in a protection
appeal and its task in deciding whether the respondent has applied her policies regarding the Trafficking
Convention, the true ambit of Flaux LJ's judgment in MS (Pakistan) stands revealed and we can turn to the cases
that have had to grapple with it.

**_(d) Upper Tribunal cases_**

**[AUJ (Trafficking – no conclusive grounds decision) Bangladesh [2018] UKUT 200 (IAC)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SKW-5V81-F0JY-C059-00000-00&context=1519360)**

38. The first part of the headnote to AUJ reads as follows:
“(i) If a person (“P”) claims that the fact of being trafficked in the past or a victim of modern slavery gives rise to a
real risk of persecution in the home country and/or being re-trafficked or subjected to modern slavery in the home
country and/or that it has had such an impact upon P that removal would be in breach of protected human rights, it
will be for P to establish the relevant facts to the appropriate (lower) standard of proof and the judge should made
findings of fact on such evidence.”


-----

39. Although this part of the headnote derives from paragraph 63(1) of the Upper Tribunal's decision, where the
hypothesis was that there had, in fact, been no “conclusive grounds” decision of the CA, we consider that the
headnote is correct, as a general proposition, whether there has been a “conclusive grounds” decision or not. If
there has, and the decision of the CA is that the appellant has not been a victim of trafficking, then, as we have
said, that will be part of the factual matrix that the fact-finding tribunal will assess, in reaching its overall conclusion
on whether or not there is a real risk of persecution or other serious harm to the appellant, in the event of his or her
removal from the United Kingdom. As we have already attempted to explain, there is here no question of the
tribunal deciding a protection appeal being bound to accept a “reasonable grounds” or a “conclusive grounds”
decision, unless that decision is shown to be perverse.

40. For this reason, the passage in the respondent's decision letter in the present case to which we have made
reference in paragraph 7 above was wrong. The respondent (like the tribunal on appeal) has to apply the lower
standard of proof when considering risk on return, as to which the question whether the appellant had previously
been trafficked was clearly relevant.

41. The second part of the headnote in AUJ also derives from paragraph 63 of the decision:
“(ii) If P does not advance any such claim in the statutory appeal but adduces evidence of being trafficked or
subjected to modern slavery in the past, it will be a question of fact in each case (the burden being on P to the
lower standard of proof) whether the Secretary of State's duty to provide reparation, renders P's removal in breach
of the protected human rights.”

42. In this regard, it is important to note what the Upper Tribunal said at paragraph 59 of the decision in AUJ:
“59. Mr Franco's submission, that as the Secretary of State had not complied with the policy to refer potential
victims of trafficking or modern slavery to the Competent Authority the appellant was "entitled" to look to the Firsttier Tribunal to make the findings that the Competent Authority should have made, is simply misconceived because
it ignores the fact that the two bodies have separate functions and jurisdiction, the question before the First-tier
Tribunal being confined to deciding whether the appellant's removal would be in breach of the United Kingdom's
obligations under the Refugee Convention or whether it would be in breach of his protected rights under the ECHR.”

43. Paragraph 59 is important. It is consistent with the judgment in MS (Pakistan) in that, as we have seen, an
assertion that the appellant should not be removed because of an alleged failure of the respondent to apply her
policy responsibilities that flow from the Trafficking Convention can be advanced before the tribunal only if the
respondent's decision-making (or absence thereof) through the CA is perverse. That remains so, notwithstanding
that the appeal in the present case was brought under the post-2014 Act appellate regime. The Court of Appeal in
MS (Pakistan) was fully aware of the changes brought by the 2014 Act: see paragraphs 18 and 19 of the judgment.
There is nothing in that judgment to show that the Court was of the view that the present regime rendered otiose the
Court's judgment in AS (Afghanistan).

44. That said, the question of whether an appellant has been a victim of trafficking may well be relevant to the
discrete issue of whether the appellant's removal would breach the ECHR, even where it is not asserted that there
is a trafficking-related risk of serious harm in the country of return and irrespective of any issue as to whether there
has been a failure to abide by the respondent's policies relating to the Trafficking Convention. This is the important
point being made in paragraph 63(2) of AUJ. For example, the fact of being trafficked may have caused physical or
psychological harm to the appellant, with consequent medical needs that may require to be addressed by the
tribunal; in particular, as part of an Article 8 claim.

**ES (s82 NIA 2002; negative NRM) Albania [2018] UKUT 335 (IAC)**

45. In this case, the Upper Tribunal held that a decision made by the CA on the balance of probabilities is not “of
primary relevance” to the determination of an asylum appeal.

46. Again, that conclusion is plainly correct. At paragraph 24 of its decision, however, the Upper Tribunal based its
reasoning on the fact that both AS (Afghanistan) and MS (Pakistan) were concerned with the previous appellate


-----

regime. But, as we have already explained, those cases have relevance to the present regime. The key distinction
is not the difference in regimes but that mentioned in paragraph 37 above.

**_(e) Administrative Court_**

**R (MN) v Secretary of State for the Home Department and the Aire Centre** **_[2018] EWHC 3268_**
**_(Admin)_**

47. This case involved a judicial review of a decision taken by the CA that the claimant was not a victim of
trafficking. The claimant contended that the CA had applied the balance of probabilities in its assessment, when it
should have applied the lower standard of proof (reasonable likelihood), which pertains in international protection
cases in the tribunal.

48. Farbey J rejected the claim. At paragraph 43, she found that the Secretary of State was entitled to set the
standard as the balance of probabilities. This was the standard of proof “that is well recognised in domestic law. It
is simple to state. It reflects the CA's task at the conclusive stage, which is to decide whether or not a person is –
as a matter of fact – a victim of trafficking”.

49. Farbey J then turned to the principle of non-refoulement. Here, the claimant's argument was that applying the
higher standard of proof in trafficking cases might put the United Kingdom in breach of its international obligation of
non-refoulement.

50. In a useful analysis of the relevant case law, Farbey J rejected this submission:
“45. The principle of non-refoulement is essentially the principle of international law that a State will not expel an
individual to a country where he or she is at risk of serious ill-treatment such as (but not limited to) torture or loss of
liberty. The duty of non-refoulement extends to refugees who are those with 'well-founded fear of being persecuted
for reasons of race, religion, nationality, membership of a particular social group or political opinion' (Refugee
Convention; article 1A(2)). The duty itself arises from article 33(1) of the Refugee Convention which states:

'No Contracting State shall expel or return ("refouler") a refugee in any manner whatsoever to the frontiers of
territories where his life or freedom would be threatened on account of his race, religion, nationality, membership of
a particular social group or political opinion'.

46. In deciding whether a person satisfies the refugee definition, the Secretary of State must consider whether that
person has demonstrated a reasonable degree of likelihood that he or she would be persecuted in the country of
origin (Regina v Secretary of State for the Home Department, Ex parte Sivakumaran [1988] AC 958). That
standard has become known as the 'lower standard of proof' and I shall refer to it as such.

47. The lower standard of proof in asylum cases is not a matter of policy but of law. It arises from the proper
interpretation of the Refugee Convention (Sivakumaran at 998G). An asylum claimant must demonstrate 'wellfounded fear of being persecuted'. The words 'well-founded' in their nature mean something less than the degree
of certitude that a party must demonstrate in civil litigation. In deciding whether a person has well-founded fear, the
Secretary of State does not assess the person's past or present situation but must consider what might happen to
the person if expelled to his or her country of origin (Sivakumaran at 993D). The issues for a decision-maker under
the Refugee Convention are 'questions not of hard fact but of evaluation' (Karanakaran v Secretary of State for the
_Home Department [2000] 3 All ER at 477a). They involve a prospective analysis of risk which is 'a matter of degree_
and judgment' (Sivakumaran at 996E-F) apt to be expressed in terms of likelihood rather than established fact. The
lower standard is also consistent with the 'relative gravity of the consequences of the court's expectation being
falsified' (Sivakumaran at 994H citing Regina v Governor of Pentonville Prison, Ex parte Fernandez [1971] 1 WLR
987per Lord Diplock at p.994). It is consistent with the duty of anxious scrutiny which arises from the threat to life or
liberty that may arise from a flawed decision (Sivakumaran at 997A citing Regina v Secretary of State for the Home
_Department, Ex parte Bugdaycay [1987] AC 514, 537). The lower standard ensures the United Kingdom's_
compliance with its international obligations: a risk-based precautionary approach recognises the inherent difficulty


-----

of predicting future events and so helps to ensure that the United Kingdom does not refoule refugees (Karanakaran
at 469f-g).

48. The application of the Sivakumaran standard has been considered by the courts in a number of well-known and
important cases. In Kaja v Secretary of State for the Home Department [1995] Imm AR 1, the Immigration Appeal
Tribunal (as it then was) held that there was no distinct divide between (on the one hand) proof of present or past
facts on which an asylum claim was based and (on the other hand) proof of future risk. The assessment of whether
a person has well-founded fear of being persecuted is a one-stage process which treats all relevant evidence in the
same way. In applying the Sivakumaran standard, the decision-maker will need to take into account all evidence to
which some credence may be attached, even if it is not probably true. This approach does not mean that there
should be a more ready acceptance of fact as established as more likely than not to have occurred. It does
however create a more positive role for uncertainty, which is as applicable to evidence of past events as to any
other evidence. In short, there is no 'probabilistic cut-off' because 'everything capable of having a bearing has to be
given the weight, great or little, due to it' (Karanakaran at 479d). The lower standard is the single applicable
standard across all questions of fact.”

51. Beginning at paragraph 55, Farbey J examined the relationship of trafficking decisions with decisions regarding
risk of serious harm on return:
“55. …A decision that someone has been trafficked can be relevant to the question whether he is at risk of being
re-trafficked on return to his country of origin (MS Pakistan at [83]). To this extent, the trafficking decision may be
relevant to a prospective analysis of risk in the asylum process. However, ECAT 'is intended to give victims of
trafficking particular protection and assistance' (PK (Ghana) at [56]). The Secretary of State is under no legal
obligation to merge one process with the other.

56. The distinction between the United Kingdom's obligations under ECAT and its non-refoulement obligations is
reflected in the Secretary of State's policies about the grant of leave to enter or remain. The policy of granting
discretionary leave to victims of trafficking states that it is intended to provide an additional ground for remaining in
the United Kingdom 'based on…individual circumstances' where the victim does not qualify for other leave 'such as
asylum or humanitarian protection'. The policy is not a substitute for, or an addition to, the United Kingdom's nonrefoulement obligations.

……..

57. The only remedy against a negative conclusive grounds decision is judicial review. Appeals to the FTT and
onwards to the Upper Tribunal should not be used as a forum for indirect challenges to trafficking decisions which
do not have the same status as adverse asylum decisions (MS (Pakistan) at [81]). While the question of whether a
person has been trafficked may be relevant to whether he or she may be expelled from the United Kingdom, the
two questions are different.

59. Mr Lewis submitted that _MS (Pakistan) means that if the CA has determined certain factual matters in the_
trafficking context, it is not open to the Tribunal to reconsider those same matters in the context of an asylum
appeal. The Tribunal is bound on the facts by the CA's assessment of the evidence underpinning a trafficking claim

- even if those same facts are part of an asylum claim or an article 3 claim. Ms Harrison QC submitted that, if the
ratio of _MS (Pakistan) has the reach for which Mr Lewis contends, the Tribunal on an asylum appeal would be_
bound by the CA's factual assessment made on the balance of probabilities rather than the lower standard which
the Tribunal is bound to apply in the asylum sphere. That would create what Ms Harrison QC called a 'protection
gap'.

60. In my judgment, Ms Harrison QC's submissions on this point are to be preferred. I do not accept that the Court
in MS (Pakistan) was intending such a radical departure from well-established principle as Mr Lewis's submissions
would imply. The judgment in MS (Pakistan) was limited to issues arising under ECAT. It did not make any change
to the function of the Tribunal in asylum or article 3 cases; nor did it change any aspect of the standard of proof in
those cases, with which it was not concerned.


-----

61. The Court in _MS (Pakistan) was concerned with a Tribunal decision which had held that MS, as a victim of_
trafficking, had been entitled to certain benefits under ECAT and that, by reason of errors in the CA's trafficking
decision, there was a prohibition against removing MS from the United Kingdom. However, the question of asylum
was not before the Court of Appeal. By that time MS's protection claim, based on the risk of re-trafficking, had fallen
away: on this issue, the Tribunal had found against MS on the facts. Flaux LJ recognised (at [81]) that a decision
that someone has been trafficked can be relevant to future risk in the asylum context, but it was not that part of the
Tribunal's reasoning which the Court of Appeal impugned.

62. The Court's conclusion was (at [88]) that the Upper Tribunal had 'effectively substituted itself' for the CA in
relation to matters under ECAT which cannot fall for consideration on appeal. That conclusion does not touch the
question of the standard of proof in asylum and article 3 claims. It does mean that appellants before the tribunal
who seek to rely on specific obligations under ECAT will get short shrift.

63. In my judgment, the appropriate standard for the assessment of a claim to have been trafficked will depend on
the legal issue to which it is relevant. If the issue is whether a person will suffer persecution under the Refugee
Convention or ill-treatment prohibited by article 3 ECHR, the lower standard will apply. If the issue is whether a
person has the specific rights available to victims of trafficking under ECAT, the standard has been rationally set by
the Secretary of State as the balance of probabilities. I am fortified in taking this issue-based approach by _RM_
_(Sierra Leone) v Secretary of State for the Home Department_ _[2015] EWCA Civ 541 at [35] (cited in AS (Guinea) v_
_Secretary of State for the Home Department and another_ _[2018] EWCA Civ 2234 at [55]). In that case, Underhill LJ_
applied an issue-based approach to the standard of proof to be applied in determining a person's nationality. He
held that the same question may require different standards, depending on whether it was relevant to an asylum
claim or some other claim.

64. In principle, it is possible that the Secretary of State may reject a trafficking claim on the balance of probabilities
but accept the same evidence in an asylum claim on the lower standard. I doubt that the different standard would
make a practical difference in every case. It would be unlikely to make a difference in the present case, where the
claimant has at every stage been disbelieved. Nevertheless, the United Kingdom's non-refoulement obligations
mean that the Secretary of State must have systems in place to determine an asylum claim on the lower standard,
even if the CA has rejected a similar claim for the purpose of ECAT. I would be straying beyond the issues in this
case if I were to comment on the Secretary of State's asylum processes on which I did not in any event hear
submissions. The claimant's asylum claim has been rejected and her appeal failed. She seeks to challenge a
subsequent decision on her trafficking claim and I am not concerned with the risks of returning her to Albania.”

52. Although we have necessarily had to address in more detail the relationship between trafficking issues and
appeals under the 2002 Act, we would respectfully adopt what is said by Farbey J in the above paragraphs.

**_(f) Summary_**

53. Before proceeding to analyse the appellant's case, it may be useful to summarise our analysis of the
relationship between decisions of the CA pursuant to the Trafficking Convention and decisions of tribunals deciding
protection and human rights appeals:

(a) In a protection appeal, the “reasonable grounds” or “conclusive grounds” decision of the CA will be part of the
evidence that the tribunal will have to assess in reaching its decision on that appeal, giving the CA's decision such
weight as is due, bearing in mind that the standard of proof applied by the CA in a “conclusive grounds” decision
was the balance of probabilities: paragraphs 34 to 36 above.

(b) In a human rights appeal, a finding by the tribunal that the CA has failed to reach a rational decision on whether
the appellant has been the victim of trafficking, such as to be eligible for leave to remain in the United Kingdom for
that reason alone, may lead the tribunal to allow the human rights appeal, on the basis that removing the appellant
at this stage would be a disproportionate interference with the appellant's Article 8 ECHR rights. This scenario is,
however, of narrow ambit and is unlikely to be much encountered in practice: paragraphs 30 to 33 above.


-----

(c) In a human rights appeal, the question whether the appellant has been the victim of trafficking may be relevant
to the issue of whether the appellant's removal would breach the ECHR, even where it is not asserted there is a
trafficking-related risk of harm in the country of proposed return and irrespective of what is said in sub-paragraph (b)
above: e.g. where the fact of trafficking may have caused the appellant physical or psychological harm. Here, as in
sub-paragraph (a) above, the CA's decision on past trafficking will be part of the evidence to be assessed by the
tribunal: paragraph 44 above.

**_C. RE-MAKING THE DECISION IN THE APPELLANT'S CASE_**

**_(a) The appellant's evidence_**

54. We can now turn to the re-making of the appellant's appeal. We heard oral evidence from the appellant. We
treated her as a vulnerable witness. Both representatives were reminded of their responsibilities in this regard. In
particular, we emphasised (and ourselves bore in mind) that the appellant might be recounting incidents of a
traumatic nature. She was offered the opportunity of taking breaks during her evidence and availed herself of this.
We also explained the importance of simplifying questions. In the event, we were fully satisfied that the appellant
was able fully to put her case to us. There were no difficulties in the appellant understanding the interpreter, and
vice versa.

55. As well as the interview record and other materials referred to in the respondent's decision, we have had
regard to the first and second witness statements of the appellant and to the other materials contained in the bundle
prepared for the hearing. A Home Office evidence bundle had been filed on 14 May 2019, pursuant to directions
that we gave on 7 May 2019. The appellant responded with a third witness statement dated 28 May 2019. We
have had regard to all of this. We have applied the lower standard of proof described in paragraph 23 above.

56. At the hearing, Mr Chakmakjian submitted a medical history relating to the appellant, comprising a printout from
her surgery of visits to her GP. It also recorded her visits to the Accident and Emergency Department in March
2017. She had been referred for counselling and had been prescribed medication. She was, however, unable to
complete her counselling sessions as there were no spaces available to look after her son and she was worried that
taking medication would stop her being a good mother. Her son was born in 3 December 2016. The appellant says
that this was a result of a “one-night stand” with a man whom she asserts to be a British citizen but of whose
identity she claims to be otherwise unaware.

57. The appellant adopted her witness statements and was tendered for cross-examination. She confirmed her
signatures on documentation adduced by the Home Office, showing that the appellant had agreed for her details to
be entered into the NRM system.

58. The appellant was asked about the letter said to come from a doctor in Albania, dated 18 September 2015.
According to the translations supplied, this recorded that one

“Zeqir Dukaj, a medical doctor, declare that today on 26.08.2009, I was called by Mr [IS] maternal uncle of [DC]
born … [1994]. I urgently attended the house … to give the first aid to [her] as her family had used physical
violence on her and she was in a very severe psychological state” [sic].

59. The letter goes on to say that from that time the appellant sought the doctor's

“assistance on several occasions and I have given her the necessary medications as she fell into depression. She
was being mistreated by the family from time to time and would be expelled from the family home in a serious
condition”.

60. The letter ends as follows:
“From 2009 until 2014 she was mistreated continuously; she was scared to come to the hospital as her family would
follow here there. The only safe place she had was her maternal uncle's house … He was there for her, and I
attended her medically every time I was called.”


-----

61. Asked how she had obtained this letter, the appellant said she wanted to provide evidence and sought
assistance in this regard from her uncle. That was the last contact she had had with him. She could not remember
when that last contact had been. She had ceased contact owing to problems with her father. She did not have the
fax record relating to the letter having been sent by fax to her solicitor's office.

62. The appellant then said that she had been asked by her uncle not to contact him because of the medical
condition of her mother. The appellant's father would cause problems for her mother if he found out about her
contact with her uncle.

63. Asked why she had not said in her statements that contact with her uncle had ended, she said she could not
remember why. She could not remember if she had told her solicitor.

64. The appellant said that her uncle lived about a fifteen-minute walk from her mother and father's house. The
town in which they live is a small one. Her uncle did not know that she had been working as a prostitute in Albania.

65. The appellant was asked why, in her asylum interview record, she had not mentioned living with her uncle.
She said no one had asked her if she had been doing so. She then said she had told the interviewer that she had
been living with her uncle. Asked why this had not found its way into the interview record, the appellant said she
did not know why and that the interpreter had not been from her area.

66. It was put to her that this was the first time she had mentioned problems with interpretation at her interview.
Indeed, in her statement, she stated that she wished to rely upon the contents of the interview record. The
appellant said no one had explained the record to her and she had just been asked to sign it. It was put to her that
she was still relying on the record in 2018. Eventually, the appellant said she did not know why the matter had not
been raised earlier.

67. At questions 175 and 176 of the interview record, the appellant had said that she continued to live at home,
following B coming to her house to attempt to take her for prostitution. The appellant replied that the interviewer
and interpreter had not understood her properly. Again, she was asked why she had not raised the issue of
interpretation until the present hearing, to which she replied that she was here in court.

68. It was put to her that in her second witness statement she had said she was living with her uncle after her
father had “kicked her out” following the incident with B, so it had been possible to challenge the interview. She
said that she had been suffering from depression and was scared.

69. The appellant said she would visit her mother at the family home when her father was not there. She visited
always in the company of her uncle and as far as she recalled her father was not there when she visited. It was put
to her that in her second witness statement she said that her father was “often too drunk or asleep”. She said that,
as far as she remembered, she might have said this. She had not encountered her father during those visits. The
bar had been below the family home.

70. Asked why she had risked going to the home when her father was present, the appellant said that her mother
had meant the world to her. Asked if she could not have met at her uncle's house, the appellant said that her
mother was ill in bed most of the time. She had not met her father in the years when she had been with her uncle
but had seen him.

71. The appellant was asked about the doctor's letter, which asserted that between 2009 and 2014 she was
mistreated continuously. The appellant said she did not understand the question. The appellant then said that the
doctor's letter was about mistreatment that she had suffered as a result of working as a prostitute. She could not
remember if, in that time, anyone from her father's house had come to her uncle's house. The uncle and her father
had lots of problems with each other. She thought that her father had “maybe” known that she was living with her
uncle.


-----

72. The appellant was asked why she could stay so long with her uncle, and yet he remained unaware she was
working as a prostitute during that time. It was put to her that the town was a small one. She said that perhaps the
uncle had been aware; she did not know.

73. The appellant then took the opportunity for a short break.

74. Resuming cross-examination, Mr Jarvis asked about whether the appellant had scars on her body. She said
she has a scar on her hand from a knife that her father had used to cut her. She did not know whether the scar
was, in fact, caused by a knife or from a broken window during the disturbance involving B.

75. The appellant said her prostitution went on most of the time, including whilst she was at school. She would lie
to her uncle and say that she was going to school. She would also leave around 1 a.m. On most occasions she
would say that she was going with friends. She would leave quietly without noticing.

76.  The appellant then said that she had, in fact, administered sleeping tablets and administered these to the
uncle and his family in their food and drink. The uncle had a wife and two children. She administered these drugs
to the entire family, but not every night. She administered the drugs whenever B asked her to do this. Asked how
often she drugged the family, the appellant said that it had been a long time and she was trying to get rid of these
memories. B had bought the pills for her at a pharmacy.

77. The appellant was asked why she had never mentioned any of this before. She replied that she was not
asked.

78. She was asked about the Home Office evidence, which indicated that the appellant had earlier travelled to Italy
in 2014. She agreed that she had done so and had returned by air. She had made the excuse she was going on a
school trip.

79. She was asked why she had not mentioned this trip to Italy before. She replied that she had just been asked
when she had last left Albania. She had gone to the passport office in her town in order to obtain the passport.
Asked if anyone had observed this in her small town, given that she was very young, the appellant said that people
might have done but that she was studying at university. She had enrolled in university in 2012 but could not go
that year because of the problems she had experienced. She had used her birth certificate and documents to enrol.

80.  It was put to her that she had said she had needed her passport to do so. The appellant then said that the
lack of a passport was why she had not enrolled. By the time she had obtained the relevant documentation, it was
too late. She had been asked to enrol in 2012 by B to cover the fact that she was working for him as a prostitute.

81. The appellant was asked whether it was plausible that in a small town no one had noticed that she was not
going to school. She said that people might have told her uncle and he might have found out everything and that
was why he did not want her to contact him anymore.

82. The appellant was asked about her journey to the United Kingdom with Lorenzo. She said that since he had
been removed from the United Kingdom, she had had no contact with him. She had seen no reason to do so. This
was despite the fact that he had helped her to escape prostitution, on her account. The appellant accepted that she
had called Lorenzo her fiancé, when encountered by the immigration authorities in Belfast. This had been a
mistake on her part. Lorenzo had paid for her false documents in Italy and for her trip to Belfast. She had chosen
not to tell him that she was alright in the United Kingdom. She thought that Lorenzo might have wanted a
relationship with her but she did not wish this. He had not subsequently tried to contact her.

83. The appellant was asked about her NRM statement. She said that this was not her document. She was asked
why she had not challenged the CA's conclusive grounds decision that she was not a victim of trafficking. The
appellant said that she was waiting for a final decision, which only came in December 2017.

84. The appellant was asked about the position of B in Albania. The appellant's account was that after the
altercation with her father, B had his name removed from the police record about the incident. This was at the
intervention of an uncle who used to work for the police She was asked why B would be concerned to have his


-----

name removed from the police record if he had fallen from a balcony. It was put to the appellant that B was said by
her in her second witness statement to have connections with the police. However, at question 100 of the interview
record, the appellant said she did not know if he had such connections. The appellant replied that he might have
had connections but she did not know.

85. Asked about her son, the appellant said she did not know the identity of his father but, from what the father had
told her, he was British. He might have lied about his name.

86. There was re-examination.

**_(b) Our assessment of the evidence_**

87. The credibility of the appellant's account is of great importance in determining whether she is entitled to
international protection or whether her removal would violate Article 8 of the ECHR. In making our findings, we
have had regard to the potential vulnerability of the appellant; particularly if she may have suffered serious harm in
the past. We have had regard to her medical records and to the fact that she gave birth in the United Kingdom, at a
time when her claim was unresolved.

88. We have also made our credibility assessment against the background that, as is evident from the country
guidance case law and the materials produced by the respondent and by other countries' agencies, trafficking of
women in Albania for prostitution abroad remains a problem, albeit that it may not be as prevalent today as
previously (including when the appellant said she encountered her difficulties). We also make our findings by
reference to the background evidence, which indicates that domestic abuse remains widespread in Albania and, as
the respondent's fact-finding mission of November 2017 found, is “seemingly not defined by class or education”.

89. We have, nevertheless, reached the firm conclusion that the appellant is not a witness of truth and there is not
a reasonable likelihood of any material part of her account being true. The appellant presented as an intelligent and
somewhat self-assured young woman whose account fell apart under cross-examination and who was, as a result,
reduced to making things up as she went along, saying whatever she thought might best serve her interests.

90. The most striking incidence is the appellant's assertion, in cross-examination, that she had been able to live
with her uncle and his family for several years, whilst engaging regularly in prostitution by night and day, as a result
of administering sleeping drugs to that family on a regular basis. Nowhere does this feature in the appellant's
interview record or her written statements. It is wholly unbelievable that, were it true, the appellant would not have
mentioned it to those advising her, if not to the respondent. We conclude that it is a blatant lie.

91. The appellant has been inconsistent in respect of the important matter of whether, after the alleged incident
between B, her father and herself, she remained living in the family home. Mr Chakmakjian, in closing submissions,
pointed to the appellant's answer to question 169 of the interview, where she said that in 2015 (sic) when her
parents found out about her prostitution, what happened was “Nothing I just left my father threw me out and they
didn't accept me anymore”. It is, nevertheless, manifest that, later in the interview, the appellant was categoric that
she continued to live at home after the incident with B. In any event, its own terms, the answer to question 169 is
problematic for the appellant, in that it contradicts her account that, when her father found out about her prostitution
as a result of B's visit, he attacked B and the appellant.

92. The account of the appellant spending several years with her uncle, whilst working as a prostitute, lacks
credibility. We have already referred to the drugging allegation. Quite apart from that, however, it beggars belief
that the appellant's activities would not have come to the attention of the uncle and his family that the appellant was
regularly engaged in prostitution, rather than attending to her education.

93.  It is also not credible that the appellant's father would not realise where the appellant had gone, given the
proximity of the uncle's house to his and the fact that both were living in a small town. That, however, is how the
appellant's account has evolved; although this account now stands in stark contrast to the assertions made in the
doctor's letter of 18 September 2015 that, for some five years, the appellant “was mistreated continuously”. The
letter is plain that this mistreatment was at the hands of “the family”. In order to reconcile these serious problems


-----

with her evidence, the appellant was compelled in cross-examination to assert that the mistreatment referred to by
the doctor was as a result of her work as a prostitute. Again, that is something which we find the appellant decided
to make up.

94. It is also not believable that the appellant forgot about or did not consider it necessary to mention the trip she
made to Italy, before returning by air. If the trip to Italy had, in truth, been for the purposes of prostitution at the
instigation of B, the appellant could be expected to have mentioned it in her statements.

95. The appellant has also been materially inconsistent regarding the position of B. Under cross-examination, it
emerged that she really had no valid reason to consider that B had influence with the police. On the contrary, the
fact that B was worried about whether there was a police record concerning him supposedly being thrown over a
balcony does not chime with him being a powerful player in the locality, able to control corrupt police. Nor does it
chime with the appellant's apparent assertion in cross-examination, that B had to be helped by an uncle of the
appellant, who used to work for the police.

96. So far as the NRM statement is concerned, we take account of Mr Chakmakjian's submission that little or no
weight should be given to this as it was not produced by the appellant and we do not know who wrote it or in what
circumstances.

97. The statement is, however, noteworthy in that it reveals, as do the answers at interview to which we have
referred, that, following her exposure as a prostitute, her father started treating [the appellant] “badly and with
disrespect”.

98. The statement also is at odds with the appellant's account in that it says that her ex-boyfriend, presumably B,
disappeared from the scene in August 2014 and that it was her fiancé, Lorenzo, who was a person of whom her
family disapproved. The statement also records the appellant as saying that her father “had close connections in
most European countries”, which was why she and Lorenzo decided to come to the United Kingdom.

99. We have decided to give the document some weight because the account recorded in it is reflected in the
conclusive grounds decision, which was given to the appellant. There, we see that the person who we have
referred to as Lorenzo (but may also be known by the name of Dorian) was the person of whom the appellant's
father disapproved and that:
“Both you and [Lorenzo/Dorian] indicated you were in a long-term relationship together on arrival in the country …
Given that your paid representatives sought to add Dorian as a dependant on your asylum claim, this is considered
to cast doubts on your later allegations that he was not your fiancé and indeed that is not even his genuine identity
details.”

100. The conclusive grounds decision specifically noted the appellant's change in her claim but said that “It is
considered it is clearly recorded what you said at that time” and that the “details relating to your family members are
consistent to those provided at a later date … As such it is considered you have given different accounts and that
have been internally inconsistent in your account”.

101. The appellant had an opportunity to challenge the conclusive grounds decision but did not do so. Further and
in any event, she could but did not deal with this issue in her witness statements.

102. Irrespective of the above, we consider that the problems we have identified regarding the appellant's evidence
as to what happened after her alleged exposure to her father as a prostitute are, in themselves, such as to compel
the finding that the appellant cannot be believed as to any material aspect of her account.

103. We find that the appellant has failed to show a reasonable likelihood that she is on bad terms with her father.
Even if she were, there is no reasonable likelihood of the appellant being without substantial familial support in her
home town, in the shape of her uncle and his family. Such are the problems with the appellant's credibility that we
do not find she has shown it is reasonably likely that she worked as a prostitute in Albania or abroad. Even if she
did, she has not shown that this led to any significant familial disapproval.


-----

104. We do not believe the appellant's attempt to paint Lorenzo/Dorian as someone whom she, in effect, used, in
order to reach the United Kingdom. It is, in our view, highly likely that he and the appellant were in the genuine
relationship that they claimed to be, when speaking to the respondent's officers in Belfast.

105. Given that the appellant has failed to make out any relevant aspect of her account, to the lower standard, we
must assess her on the basis that she would be a single mother with a very young child, returning to Albania, where
she has family who have not been shown, to the lower standard, to be hostile towards her.

106.  On the basis of our findings, the appellant would not need to seek any form of shelter. She would have
familial support within Albania. She is also relatively highly educated, having left school at 18 and begun (although
not completed) university education in journalism. She is suffering from stress, as the medical records make clear,
but her medical position is nowhere near the point where she can successfully assert that she would be unable to
seek work in Albania to support herself and her son, even if she were to receive no assistance from her family.

107. We have had regard to what is said in the country guidance and the country materials regarding attitudes in
Albania towards illegitimacy. The fact that illegitimacy carries a greater social stigma than in, say, Western Europe,
is a factor that we bear in mind. In the light of our findings, however, it has not been shown that this issue, either
alone or cumulatively, would have any material bearing upon the ability of the appellant and her child to lead
satisfactory lives in Albania.

108. In conclusion, the appellant has failed to show that there is a reasonable likelihood that, if removed, she would
suffer treatment contrary to the Refugee Convention or Article 3 of the ECHR.

109. So far as Article 8 is concerned, there is no credible evidence that the appellant has any family life in the
United Kingdom, other than with her small child. There is no evidence that the appellant has formed any protected
family life here.

110. There is a paucity of evidence regarding the child. There is, however, nothing to show that his best interests
would be served by anything other than being where his mother will be. In the light of our findings, that would be in
Albania.

**_D. DECISION_**

111. The appeal is dismissed on both protection and human rights grounds.

**Direction Regarding Anonymity – rule 14 of the Tribunal Procedure (Upper Tribunal)**
**Rules 2008**

Unless and until a Tribunal or court directs otherwise, the appellant is granted anonymity. No report of these
proceedings shall directly or indirectly identify her or any member of her family. This direction applies both to the
appellant and to the respondent. Failure to comply with this direction could lead to contempt of court proceedings.

Signed     Date: 30 August 2019

The Hon. Mr Justice Lane

President of the Upper Tribunal

Immigration and Asylum Chamber

**ANNEX**

IMAGE NOT AVAILABLE

Upper


-----

Tribunal
(Immigration
and Asylum
Chamber)

the
immigration
Acts

Heard at: F
i
e
l
d

H
o
u
s
e

On 9

A
p
r
i
l

2
0
1
9

Before

Upper
Tribunal
Judge Gill

Between


D
e
c
i
s
i
o
n

p
r
o
m
u
l
g
a
t
e
d


T
h
e

S
e
c
r
e


Appellant


-----

And


t
a
r
y

o
f

S
t
a
t
e

f
o
r

t
h
e

H
o
m
e

D
e
p
a
r
t
m
e
n
t

M
i
s
s

D
J

**(**
**A**
**N**
**O**
**N**
**Y**
**M**
**I**
**T**
**Y**


Respondent


-----

**D**
**I**
**R**
**E**
**C**
**T**
**I**
**O**
**N**

**M**
**A**
**D**
**E**
**)**

**Anonymity**

**I make a direction under r.14(1) of the Tribunal Procedure (Upper Tribunal) Rules 2008 prohibiting**
**the disclosure or publication of any matter likely to lead members of the public to identify the original**
**appellant, Miss DJ. No report of these proceedings shall directly or indirectly identify her. This direction**
**applies to both the appellant and to the respondent and all other persons. Failure to comply with this**
**direction could lead to contempt of court proceedings.**

**I make this direction because Miss DJ alleged in her appeal that she was a victim of trafficking.**

**The parties at liberty to apply to discharge this order, with reasons.**

Representation:

For the appellant:  Mr D Clarke, Senior Home Office Presenting Officer.

For the respondent: Mr J Trussler, of Counsel, instructed by Kilby Jones Solicitors LLP.

Decision and Directions

1. The Secretary of State has been granted permission to appeal the decision of Judge of the First-tier Tribunal
Wright (hereafter the “judge”) who, in a decision promulgated on 26 October 2018 following a hearing on 27
September 2018, allowed the appeal of Miss DJ (hereafter the “claimant”), a national of Albania born in August
1994, against a decision of the respondent of 2 December 2017 to refuse her claim of 16 September 2015 for
refugee and humanitarian protection. The decision also refused the claimant's Article 8 claim. The reasons for the
Secretary of State's decision are given in the decision letter dated 2 December 2017 (hereafter the “Decision
Letter”).

2. The claimant's grounds of appeal to the First-tier Tribunal raised her asylum and humanitarian protection claims
and her rights under Articles 2 and 3 of the 1950 European Convention for the Protection of Human Rights and
Fundamental Freedoms (ECHR). There was no mention of Article 8.

3. The judge found (at para 37) that “[the claimant] was at real risk or a substantial likelihood of persecution were

_[she] to be returned to Albania and in sufficiency [sic] of state protection”. At para 38, she said she allowed the_
appeal but did not indicate the ground of appeal upon which the appeal was allowed. However, it is evident from her
finding at para 37 that she allowed the appeal on asylum grounds. In her assessment of the case (at paras 32-36),
she did not mention humanitarian protection or Articles 2, 3 or 8 of the ECHR.


-----

Immigration history

4. The claimant claimed to have left Albania on 24 August 2015 and travelled by car to Milan, Italy, where she said
she stayed for about two weeks. She then travelled to France followed by Dublin. From Dublin, she travelled to the
United Kingdom, arriving on 8 September 2015 on which date she was served with form RED.0001 as an illegal
entrant. On 16 September 2015, she claimed asylum.

5. On 21 September 2015, the claimant was referred to the Competent Authority (“CA”) under the National Referral
Mechanism (“NRM”). On 23 September 2015, the CA made a positive “Reasonable Grounds” decision. On 8
August 2016, the CA reached a “Conclusive Grounds” decision, that the claimant was not a victim of trafficking. The
claimant did not judicially review this decision.

6. The Secretary of State then refused her asylum claim which she appealed, as stated above.

Basis of claim

7. The following summary is based on paras 17-20 of the judge's decision:

8. The claimant claimed that in May to August 2011, she met an older man who I shall refer to as “B”. She began a
sexual relationship with him. The nature of their relationship changed and he forced her into prostitution, by
blackmailing her with a video she was unaware he had taken of them having sex. On one occasion, B went to her
house and her father became aware that she had been in a sexual relationship with B. Her father beat her
unconscious. He threw B from the balcony. She woke up at her uncle's house. B then forced her into prostitution.
He forced her to work as a prostitute in Italy.

9. The claimant said she was at risk of persecution in Albania due to the fact that she had been trafficked to Italy;
she was sexually exploited; her father had disowned her; and she is a now a single mother of a child who will be
seen as an illegitimate child in Albania.

The judge's decision

10. The judge heard submissions as to the approach she should take in relation to the “Conclusive Grounds”
decision pursuant to the judgment of the Court of Appeal in MS (Pakistan) _[2018] EWCA Civ 594 and the Upper_
Tribunal's decision in AUJ (Trafficking – no conclusive grounds decision) Bangladesh _[[2018] UKUT 00200 (IAC).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SKW-5V81-F0JY-C059-00000-00&context=1519360)_
The respondent's representative stated that he was content for the judge to decide the claimant's substantive
asylum claim (para 10). The judge decided to do so, applying the lower standard of proof applicable to asylum
claims (para 16 of the decision).

11. In view of the submissions of Mr Clarke at the hearing before me, it is necessary to quote paras 32-37 of the
judge's decision. These read:

“Findings and conclusions

32. The Tribunal has undertaken a credibility assessment of [the claimant's] evidence. It has scrutinised that
evidence. In doing so, it have used the tools of internal credibility, external credibility, plausibility, coherence,
consistency, and then stood back and judged the matter in the round. The relevant authorities, authorities referred
to by the parties and any guidance have been considered. The documents the Tribunal was taken to have been
reviewed. There is no requirement for corroboration in asylum cases; however the evidence requires anxious
scrutiny. Not all matters considered are referred to in this judgment; however that is not to say they were not fully
examined or analysed.

33. The Tribunal has regard to Lord Neuberger's comments in HK v SSHD [2006] EWCA Civ 1037:

[I]n many asylum cases, some, even most, of [the claimant's] story may seem inherently unlikely but that does
not mean that it is untrue. The ingredients of the story, and the story as a whole, have to be considered against the


-----

available country evidence and reliable expert evidence, and other familiar factors, such as consistency with what

[the claimant] has said before, and with other factual evidence (where there is any).'

34. [The Secretary of State] has not undermined [the claimant's] case, other than to discount it due to
inconsistencies. [The claimant's] account of her time in Albania and Italy and her oral evidence, on the applicable
burden of proof was accepted. Where [the Secretary of State] says it has evidence which undermines [the
claimant's] account, it has not been produced or disclosed.

35. In considering TD & AD (Trafficked women) (CG) v SSHD _[[2016] UKUT 00092 (IAC), [the claimant's]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J57-XW71-F0JY-C30M-00000-00&context=1519360)_
particular circumstances are she is vulnerable as she now has a child and is not married. As [the claimant] said, any
assistance in terms of shelters is supportive not protective and even if she is able to avail herself of such
assistance, that will further stigmatise her and open her up to being exposed to further forced sexual servitude and
she now has a young child to consider. Whilst in view of her child's age (and taking into account his best interests)
in theory it would be possible for him to relocate to Albania; were he to do so, that causes additional problems for

[the claimant].

36. It is noted that re-trafficking (in the form of being forced into compulsory sexual servitude) is a reality. That
factor is compounded by the existence of [the claimant's] son and it is clearly in his best interests for him to remain
in this country, when there is a risk upon return for [the claimant] and a lack sufficiency of protection for her and
therefore for him, were she to be returned to Albania. It is also accepted that [the claimant] lacks a support network.

37. As such, there is a real risk or a substantial likelihood-of persecution were [the claimant] to be returned to
Albania and in sufficiency [sic] of state protection.”

The Secretary of State's grounds and submissions

12. The Secretary of State's grounds may be summarised as follows:

(i) (Ground 1) The judge had failed to make a finding as to whether the claimant had been trafficked and therefore
failed to resolve a material fact.

(ii) (Ground 2) If it is considered that the judge had, by implication, found that the claimant was a victim of
trafficking, she failed to provide adequate reasons for such a finding.

(iii) (Ground 3) The judge reversed the burden of proof when she said at para 34 that the Secretary of State had
not undermined the claimant's case or had failed to provide evidence that undermined the claimant's case.

(iv) (Ground 4) The judge misdirected herself in law by failing to follow the guidance of the Court of Appeal in MS
(Pakistan) pursuant to which she was not entitled to go behind the conclusion of the CA on the claimant's trafficking
claim.

13. By an amended skeleton argument dated 17 January 2019, the Secretary of State stated, in reliance upon
paras 55-63 of the judgment of Farbey J in R (MN) v SSHD [2018] EWHC 3268 (QB), that he no longer relied upon
Ground 4.

Submissions

14. I informed the parties that I would decide whether the judge had materially erred in law and whether her
decision should be set aside by considering only grounds 1, 2 and 3. However, in the event that the judge's
decision was set aside, the Upper Tribunal would wish to hear submissions at the resumed hearing on the correct
approach to be followed by the First-tier Tribunal and the Upper Tribunal in determining asylum claims which
include a claim that an individual has been trafficked, in view of the judgments in AUJ, ES (s82 NIA 2002; negative
NRM) Albania [2018] UKUT 00335 (IAC) and MN. I emphasised that this would not arise if I concluded that the
judge had not materially erred in law as contended in grounds 1, 2 and/or 3.


-----

15. Mr Clarke amplified on the grounds, taking me through the judge's decision. He drew my attention to the fact
that the Decision Letter and the Secretary of State's representative at the hearing before the judge raised specific
credibility issues which I will refer to below and which, in his submission, the judge did not engage with or resolve.
He submitted that the judge's reasons were confined to para 34. At para 33, the judge referred to and quoted from
HK. At para 34, the judge reversed the burden of proof. This is then followed by para 35 which concerns the risk on
return and para 36 which concerns the claimant's circumstances in Albania as a single mother of an illegitimate
child. At para 37, the judge set out her conclusion.

16. Mr Clarke submitted that it is therefore clear that the judge had not made a clear finding that the claimant had
been trafficked and that, even if it is considered that she had made such a finding by implication on account of the
fact that she had referred to the claimant being re-trafficked, she had failed to give adequate reasons.

17. In response, Mr Trussler submitted that the judge's reasons were not confined to para 34. She stated at para
32 that she had undertaken her credibility assessment having scrutinised the evidence using the tools she
described in that paragraph. She said she had applied anxious scrutiny to the evidence. At para 33, she said she
had in mind the judgment in HK.

18. Mr Trussler asked me to bear in mind that the Decision Letter was a very lengthy document. He submitted that
the fact that the judge had not dealt with each and every point raised in the Decision Letter does not undermine her
findings of fact.

19. Mr Trussler referred me to the final sentence of para 34 where the judge had stated that the Secretary of State
had stated that he had evidence to undermine the claimant's account but had failed to produce it. This was a
reference to the fact that a previous hearing in February 2018 had been adjourned in order to enable the Secretary
of State to produce documents which he had failed to produce.

20. Mr Trussler submitted that the judge had plainly undertaken a careful assessment of the evidence. The
claimant had submitted a witness statement which she adopted at the hearing before the judge. The claimant was
cross-examined at the hearing. The judge had believed her evidence. She was entitled to accept her evidence.
Interference with her decision would not be justified.

21. I reserved my decision.

Assessment

22. Whilst it is correct that the judge did not state, in terms, that she found that the claimant had been trafficked, I
am satisfied that it is implicit from her reasoning that she did find that the claimant had been trafficked. As Mr Clarke
submitted, it is clear from both the Decision Letter and the submissions of the Secretary of State's representative
before the judge, that the Secretary of State did not accept that the claimant had been trafficked. Accordingly, when
the judge said at para 34 that “[The claimant's] account of her time in Albania and Italy and her oral evidence, on
_the applicable burden of proof was accepted”, she could only have meant that she accepted the claimant's account._

23. I have therefore concluded that ground 1 is not established.

24. It is clear from the Decision Letter and the judge's summary of the submissions of the Secretary of State's
representative at the hearing before her that specific credibility issues were raised on the Secretary of State's
behalf. By way of example:

(i) Para 47 of the Decision Letter took issue with the credibility of the claimant's evidence given that she had said
that she had not told the hospital in Albania where she was treated what had happened to her because (she said)
no one had asked her.

(ii) Para 48 of the Decision Letter noted an inconsistency in the claimant's accounts, in that, she had said in her
witness statement that her family had disapproved of her fiancé when she introduced him and that her father had
threatened to kill her if she continued with the relationship whereas she made no mention of her fiancé or being
threatened by her father at her interview


-----

(iii) At para 49, the Secretary of State noted a discrepancy between the claimant's account at question 169 of her
interview that when her parents found out about her dealings with B, she just left her home because her father
threw her out and did not accept her anymore whereas at questions 243-245, she said that her father had beaten
her up so badly that she did not remember what happened and that she woke up at her uncle's home with a doctor
over her head.

(iv) At para 50 of the Decision Letter, the Secretary of State stated that the claimant's account at question 255 of
her interview that she returned home to see her mother after the incident was inconsistent with her fear of returning
to Albania because of her father's abuse.

(v) As noted at para 21 of the judge's decision, the Secretary of State's representative drew attention to the fact
that the claimant had not submitted any medical evidence to support her claim that she had sustained injuries.

25. There is simply no mention at all in the judge's decision of any credibility point raised on the Secretary of
State's behalf.

26. I entirely agree with Mr Trussler that judges are not obliged to deal with each and every aspect of a party's
case. Indeed, I have noted that the judge said in the final sentence of para 32 that “Not all matters considered are
_referred to in this judgment; however that is not to say they were not fully examined or analysed”._

27. However, the judge completely failed to deal with or engage with any aspect of the Secretary of State's case.
She explained, at para 32, the principles she said she had applied in assessing the claimant's evidence but her
reasons for accepting the claimant's account are a complete mystery and known only to her.

28. Just as it would be wholly unacceptable for a judge to reject an claimant's account without giving any reasons
whatsoever, it is unacceptable for a judge to accept an account without giving any reasons whatsoever when the
Secretary of State has raised specific points concerning the individual's credibility.

29. I stress that this is not a case of a judge who has engaged with certain aspects of the Secretary of State's
reason for disputing an appellant's credibility but a case of a judge wholly failing to engage with _any part of the_
Secretary of State's case.

30. I am therefore satisfied that ground 2 is established. The failure to give any reasons at all for accepting the
appellant's account is a material error such that it justifies setting aside the judge's decision on this ground alone,
leaving aside ground 3.

31. I am also satisfied that ground 3 is established. It is clear from para 34 of the judge's decision that she did
reverse the burden of proof. Again, this is in itself a material error, such that it justifies setting aside the judge's
decision on this ground alone, leaving aside ground 2.

32. For the above reasons, I set aside the decision of Judge Wright to allow the claimant's appeal. Her summary of
the evidence at paras 17-20 of her decision stands as the record of the evidence she heard.

33. I agreed with the parties that, if the judge's decision was set aside, the claimant's appeal would be heard de
_novo. This means that credibility will need to be re-assessed. The grounds that are to be decided are the grounds_
that were before the First-tier Tribunal in the appeal before the judge. As I said at para 2 above, there was no
mention of Article 8 in the claimant's grounds of appeal to the First-tier Tribunal. Notwithstanding the fact that the
Decision Letter considered her Article 8 claim, her grounds of appeal raised her asylum and humanitarian protection
claims and her rights under Articles 2 and 3 of the ECHR only.

34. Although the judge said at para 12 of her decision:

“12. It was agreed the issue to be determined was does [the claimant] fall within the Refugee Convention and
Article 3? In addition there are Article 8 and s.55 of the Borders, Citizenship and Immigration Act 2009
consideration _[sic] in respect of [the claimant's] son (born in the UK on [xx]/12/2016) and what is in his best_
interests”.


-----

there was no application for permission to amend the grounds of appeal to the First-tier Tribunal to include Article 8
of the ECHR.

35. Accordingly, the appeal that was brought to the First-tier Tribunal did not raise Article 8.

36. Further and in any event, there was no application by the claimant to cross-appeal the decision of the judge on
the ground that she had failed to decide her Article 8 claim. Upon the Secretary of State being granted permission
to appeal to the Upper Tribunal, it is reasonable to expect the claimant to have made such an application to crossappeal if she had wished to contend that the judge had erred by failing to determine Article 8. There was no such
application to cross-appeal at the hearing before me, nor did Mr Trussler mention Article 8 at any point.

37. It follows therefore that the re-making of the decision on the claimant's appeal will be limited to her asylum and
humanitarian protection grounds of appeal and (in relation to her human rights grounds of appeal) her claims under
Articles 2 and 3 of the ECHR.

38. I turn to decide whether the decision on the claimant's appeal should be re-made in the First-tier Tribunal or in
the Upper Tribunal. Mr Trussler and Mr Clarke submitted that the appeal should be remitted to the First-tier Tribunal
in view of the fact that the claimant's appeal was allowed by the judge.

39. As is clear from the judge's decision, submissions were made as to whether the judge should following the
judgment of the Court of Appeal in MS (Pakistan) and the Upper Tribunal in AUJ. In the period between the date of
the hearing before the judge (27 September 2018) and the date that her decision was promulgated (26 October
2018), the Upper Tribunal published the decision in ES. The judgment of Farbey J in MN, which was delivered on
29 November 2018, is not binding on the Upper Tribunal strictly speaking, whereas the Court of Appeal's judgment
in MS (Pakistan) is binding.

40. It is therefore a need for general guidance to be given on the approach to be taken by the First-tier Tribunal or
the Upper Tribunal in determining appeals brought on protection grounds in which it is alleged that the appellant
has been trafficked but where there has been a negative “Conclusive Grounds” decision which has not been
challenged in judicial review proceedings. In the absence of such guidance, the judge deciding this appeal in the
First-tier Tribunal on the next occasion would be faced with having to decide for himself or herself the approach that
should be followed.

41. We have therefore decided that the decision on the claimant's appeal should be re-made in the Upper Tribunal
so that such general guidance can be given.

**Directions to the parties**

(1) The Tribunal will provide an interpreter in the Albanian language at the hearing. If an interpreter in another
language is required, either instead of or in addition to an interpreter in the Albanian language, she must notify the
Tribunal of the language(s) in which an interpreter is required, no later than 5 days from the date on which these
Directions are sent to the parties.

(2) No later than 5 days from the date on which these Directions are sent to the parties, the claimant to notify the
Tribunal of the number of witnesses who will give evidence.

(3) Any evidence the claimant seeks to rely upon (including any evidence that was previously served) must be
served no later than 1 May 2019 and must be served on the Upper Tribunal in triplicate. The claimant's bundle must
include:

a. Witness statements of the evidence to be called at the hearing, which will stand as the examination-in-chief of
the witnesses.

b. A paginated and indexed bundle of all documents to be relied upon at the hearing. Essential passages must be
identified in a schedule, or highlighted.


-----

c. A skeleton argument, identifying all relevant issues and citing relevant authorities, and dealing with the issue for
general guidance described at paras 39-40 of this decision.

d. A chronology of events.

IMAGE NOT AVAILABLE

Signed        Date: 11 April 2019

Upper Tribunal Judge Gill

**End of Document**


-----

