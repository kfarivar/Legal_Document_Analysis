# R v ADG and another [2023] All ER (D) 37 (Nov)

[2023] EWCA Crim 1309

Court of Appeal, Criminal Division

EnglandandWales

Lord Justice Dingemans, Mr Justice Goss and Mrs Justice Foster

8 November 2023

**CRIMINAL LAW – APPEALS AGAINST CONVICTIONS – MODERN SLAVERY DEFENCE FOR UNDER 18**
**DEFENDANTS AND WHETHER CONVICTIONS UNSAFE**
Abstract

_The Court of Appeal, Criminal Division, allowed the defendants' appeals against their convictions for conspiracy to_
_supply class A drugs. The defendants, both aged 17, had been sentenced to a three-year youth rehabilitation order_
_(YRO) (in addition to concurrent three-year YROs for other drug offences to which they had pleaded guilty). At trial,_
_the first defendant had argued that he had been 'targeted, utilised and exploited by the others', while the second_
_defendant had contended that he had been threatened and accused of stealing drugs and had had to continue_
_selling drugs in order to pay off his debt. The defendants contended that the judge had wrongly directed the jury_
_[that, to make good the defence under s 45 of the Modern Slavery Act 2015, the defendants had been required to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_
_show that there had been, or might have been, compulsion. The court held that the s 45 defence for those under 18_
_years did not include the requirement of compulsion, and that, in circumstances where the judge had added in_
_another element to the defence which the law did not require, and where it was not possible to say that the jury had_
_not been influenced by that additional step on the routes to verdict, the convictions were rendered unsafe._
_Accordingly, the court quashed the convictions. No retrial was ordered._
Digest

The judgment is available at: [2023] EWCA Crim 1309

**Background**

Following a trial, the defendants (ADG and BIJ) were convicted of two counts of conspiracy to supply class A drugs
(one conspiracy related to cocaine, and the other to diamorphine). They were sentenced to a youth rehabilitation
order (YRO) for three years. The defendants, both aged 17, had been aged 14-16 at the time of the relevant events.

[At trial, the defendants had unsuccessfully sought to rely on the defence in s 45 of the Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
[(MSA 2015), which provided that: '... (4) A person is not guilty of an offence if (a) the person is under the age of 18](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
when the person does the act which constitutes the offence, (b) the person does that act as a direct consequence
of the person being, or having been, a victim of slavery or a victim of relevant exploitation, and (c) a reasonable
person in the same situation as the person and having the person's relevant characteristics would do that act.'

ADG had contended that he had been 'targeted, utilised and exploited by others' at a time when he had been in a
care placement. His defence had relied on a report from a consultant psychologist, who had concluded that ADG
had a learning disability and dyslexia.


-----

BIJ had contended that he had been in foster care since around 2018, that he had been threatened and accused of
stealing drugs, and that he had felt pressured to pay off drugs and cash that had been seized from him when the
police had arrested him.

The defendants appealed against conviction.

ADG had also pleaded guilty to two counts of being concerned in the supply of class A drugs, and BIJ had pleaded
guilty to three counts of being concerned in the supply of class A drugs and two counts of possession with intent to
supply class A drugs, for which they had been sentenced to a YRO for three years. Whatever the result of the
present appeal, the defendants would remain subject to the concurrent YROs.

**Issues and decisions**

Whether the convictions were unsafe.

The defendants submitted that the judge had wrongly directed the jury that the defendants had needed to show that
there had been, or might have been, compulsion to make good the defence under MCA 2015 s 45, in
circumstances where the element of the defence requiring compulsion only applied to those over 18 years, and
there was no such requirement for those aged under 18 years.

Concerning ADG, the court considered whether the judge had wrongly refused to direct the jury on the issue of
'relevant exploitation' going beyond the slavery aspect of the defence available under MCA 2015.

The judge had directed the jury that ADG and BIJ would have had to show either that they had become engaged in
the conspiracies, or might have become engaged in the conspiracies, because of compulsion. That would have
been a proper direction for a defendant who had been over 18 years because of the terms of s 45(1), (2) and (3).
Section 45(1)(b) and (c) required that the defendant committed an offence 'because the person is compelled to do
it' and that 'the compulsion is attributable to slavery or to relevant exploitation' (see [22], [23], 36] of the judgment).

Although the objective test for both over, and under, 18-year-old defendants was in similar terms (see ss 45(1)(d)
and 45(4)(c)), the defence for those under 18 years did not include the requirement to show compulsion. Section
45(4) required the person under 18 to have committed the offence as a 'direct consequence of the person being, or
having been, a victim of slavery or a victim of relevant exploitation'. It was apparent that a requirement to show
compulsion was more onerous than a requirement to show that the relevant act had been committed as a direct
consequence of the person being, or having been, a victim of slavery or a victim of relevant exploitation (see [37] of
the judgment).

In circumstances where the judge had added in another element to the defence which the law did not require, and
where it was not possible to say that the jury had not been influenced by that additional step on the routes to
verdict, the convictions of both ADG and BIJ for conspiracy to supply class A drugs were unsafe and would be
quashed. No retrial would be ordered (see [38], [43] of the judgment).

_R v NHF_ _[[2022] EWCA Crim 859 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65S2-RRH3-CGX8-016K-00000-00&context=1519360)_

Observed: 'It might be noted that ... this is the second case in which it is apparent that the critical difference
between the section 45 defence for those aged 18 years and over, and those aged under 18 years, has been
missed. This may have something to do with the fact that sections 45(1), (2) and (3) relate to the defence for those
aged 18 years and over, and it is only section 45(4) that relates to those aged under 18 years. It highlights the
importance of reading carefully the relevant statutory provisions' (see [39] of the judgment).

Will Parkhill (instructed by the Registrar of Criminal Appeals) for ADG.

Joss Ticehurst (instructed by the Registrar of Criminal Appeals) for BIJ.


-----

Raymond Tully KC and Lee Bremridge (instructed by the Crown Prosecution Service) for the Crown.
Carla Dougan-Bacchus Barrister.

**End of Document**


-----

