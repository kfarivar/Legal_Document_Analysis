# *Reyes and another v Al-Malki and another [2017] All ER (D) 85 (Oct)

[2017] UKSC 61

Supreme Court

Lord Neuberger, Lady Hale, Lord Clarke, Lord Wilson and Lord Sumption SCJJ

18 October 2017

**Constitutional law – Diplomatic privilege – Immunity from legal process**
Abstract

_Constitutional law – Diplomatic privilege. Where the first respondent's functions as a diplomatic agent had come to_
_an end in London, he had not been entitled to any immunity, under art 31 of the Vienna Convention on Diplomatic_
_Relations, and the residual immunity, under art 39(2) of that Convention, could not apply, because the respondents'_
_employment or treatment of the appellant (a Philippine domestic worker, who had alleged human trafficking) had_
_not amounted to acts performed in the course of the first respondent's official functions. So held the Supreme Court_
_in allowing the appellant's appeal against the lower court's decision that the employment tribunal had had no_
_jurisdiction to hear her employment claims, because the first respondent had been entitled to diplomatic immunity,_
_under art 31, and the that his wife had been entitled to residual immunity. Further, the court, in dismissing the_
_respondents' cross-appeal, agreed with the lower court that there had been valid service of the employment claim_
_on the respondents._
Digest

The judgment is available at: [2017] UKSC 61

**Background**

Between January and March 2011, the appellant, R, a Philippine national, had been employed by the respondents,
Mr and Mrs A, as a domestic servant in their residence in London. At the time, Mr A was a member of the
diplomatic staff of the embassy of Saudi Arabia in London, until 29 August 2014.

R alleged that she had been the victim of human trafficking. In June 2011, she brought proceedings in the
employment tribunal (the tribunal), alleging direct and indirect race discrimination, unlawful deduction from wages
and failure to pay her the national minimum wage. The Court of Appeal, Civil Division, held that the tribunal had no
jurisdiction, because Mr A was entitled to diplomatic immunity, under art 31 of the Vienna Convention on Diplomatic
Relations (the Vienna Convention), and Mrs A was entitled to a derivative immunity, under art 37(1) of the Vienna
Convention, as a member of his family.

R appealed and Mr and Mrs A cross-appealed. The Secretary of State for Foreign and Commonwealth Affairs and a
charity that supported migrant domestic workers intervened.

Appeal allowed. Cross-appeal dismissed.

**Issues and decisions**


-----

(1) Whether the tribunal had had jurisdiction to hear R's claims, under the exception to diplomatic immunity
contained in art 31(1)(c) of the Vienna Convention, which applied where the proceedings related to any professional
or commercial activity exercised by the diplomatic agent in the receiving state outside his official functions'. A
question arose as to whether art 31(1)(c), in fact, applied, or whether there was immunity on the narrower basis
authorised by art 39(2) of the Vienna Convention (see [8] of the judgment).

(Per Lord Sumption, Lord Neuberger agreeing) Diplomatic immunity was not an immunity from liability. It was a
procedural immunity from the jurisdiction of the courts of the receiving state. Article 31 of the Vienna Convention
conferred immunity only while a diplomatic agent was in post. A diplomatic agent who was no longer in post and
who had left the country was entitled to immunity only on the narrower basis authorised by art 39(2) of the Vienna
Convention (see [4], [7] of the judgment).

Fundamental to the operation of the scheme, under arts 31 to 40 of the Vienna Convention, was the distinction
between those immunities which were limited to acts performed in the course of a protected person's functions as a
member or employee of the mission, and those which were not. The acts which an agent of a diplomatic mission did
in a personal or non-official capacity were not acts of the state which employed him. They were acts in respect of
which any immunity conferred on him could be justified only on the practical ground that his exposure to civil or
criminal proceedings in the receiving state, irrespective of the justice of the underlying allegation, was liable to
impede the functions of the mission to which he was attached (see [17] of the judgment).

The exception, under art 31(1)(c), applied if both of two conditions were satisfied: (i) that the action related to a
'professional or commercial activity exercised by the diplomatic agent'; and (ii) that the exercise of that activity was
'outside his official functions'. If the relevant acts had been within the scope of the diplomat's official functions, the
enquiry ended there. He was immune. Moreover, he would retain the residual immunity in respect of them even
after his posting came to an end. However, if he was still in post and the relevant activity had been outside his
official functions, the operation of the exception would depend on whether it amounted to a professional or
commercial activity exercised by him. The first question was what were a diplomatic agent's official functions. The
starting point was the functions of the mission to which he was attached. Whether incidental or direct, a diplomatic
agent's official functions were those which he performed for, or on behalf of, the sending state. The test was
whether the relevant activity was part of those functions. If the relevant activity was outside the diplomatic agent's
official functions, the next question was whether it amounted to a professional or commercial activity exercised by
him. An activity was not the same as an act. Article 31(1)(c) of the Vienna Convention was concerned with the
carrying on of a professional or commercial activity having some continuity and duration, namely with a course of
business. However, it was not only a question of continuity or duration. It was also a question of status. In the
ordinary meaning of the words, the 'exercise' of a 'professional or commercial activity' meant practising the
profession or carrying on the business. The diplomatic agent had to be a person practising the profession or
carrying on (or participating in carrying on) the business (see [19]-[21] of the judgment).

(Per Lord Sumption, Lord Neuberger agreeing) The present appeal would be allowed on a different and narrower
ground [to that concerning art 31(1)]. On 29 August 2014, Mr A's posting in London had come to an end and he had
left the United Kingdom. Accordingly, since Mr A's functions as a diplomatic agent had come to an end, he was no
longer entitled to any immunity under art 31 of the Vienna Convention. The only immunity available to him was the
residual immunity, under art 39(2). That immunity applied only so far as the relevant acts had been performed while
he had been in post in the exercise of his diplomatic functions. The employment and maltreatment of R were not
acts performed by Mr A in the exercise of his diplomatic functions. On any view, Mr A's official functions could not
have extended to the employment of domestic staff to do the cleaning, help in the kitchen and look after his
children. Those things had not been done for, or on behalf of, Saudi Arabia. The Court of Appeal had considered
that such activities had been 'conducive' to the performance of Mr A's official functions. No doubt they had been.
However, it did not make the employment of R part of Mr A's official functions as a diplomatic agent. It followed from
the fact that the relevant acts had not been done in the course of his official functions that that immunity could not
apply. Likewise, Mrs A was no longer entitled to any immunity at all. It did not matter that the respondents had been
entitled to immunity under arts 31(1) and 37(1), respectively, at the time when the present proceedings had been
commenced (see [4], [48], [49] of the judgment).


-----

(Per Lord Wilson, Lady Hale and Lord Clarke agreeing) The appeal should be allowed by reference to the apparent
loss of immunity on the part of Mr A (and, therefore, of Mrs A) when, in August 2014, he had ceased to be a
member of the Saudi mission in London and when, therefore, they had left the UK. The present court would not
answer, in any binding form, the central question presented to it, namely whether an action instituted in the tribunal
against a foreign diplomat in the UK by his former domestic servant brought to the UK to work in his home in
(assumed) conditions of modern slavery related to any '… commercial activity exercised by [him here] outside his
official functions' within the meaning of art 31(1)(c) of the Vienna Convention (see [55], [56] of the judgment).

The appeal would be allowed and, unless, within 21 days, written submissions were received from the parties
justifying some other course, it would be declared that the respondents were not entitled to diplomatic immunity in
respect of R's claims and the case would be remitted to the tribunal to determine the claims on their merits (see

[53]-[55] of the judgment).

_Baccus SRL v Servicio Nacional del Trigo_ _[[1956] 3 All ER 715 considered; Zoernsch v Waldock](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-609F-00000-00&context=1519360)_ _[[1964] 2 All ER 256](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP90-TWP1-605P-00000-00&context=1519360)_
considered; Empson v Smith _[[1965] 2 All ER 881 considered; Fothergill v Monarch Airlines Ltd](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-94H0-TWP1-61C4-00000-00&context=1519360)_ _[[1980] 2 All ER 696](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-6134-00000-00&context=1519360)_
considered; Propend Finance Pty Ltd and Others v Sing and Another _[[1997] Lexis Citation 1786 considered; Jones](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PWD-4Y30-TXX3-21G4-00000-00&context=1519360)_
_v Ministry of the Interior of the Kingdom of Saudi Arabia (Secretary of State for Constitutional Affairs intervening);_
_Mitchell v Al-Dali_ _[[2006] All ER (D) 145 (Jun) considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTT1-DYBP-N39K-00000-00&context=1519360)_ _Abusabib v Taddese_ _[UKEATPA/1819/10 considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53RN-11T1-F0JY-C0C5-00000-00&context=1519360)_
_Wokuri v Kassam_ _[[2012] All ER (D) 25 (May) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55J7-JP01-DYBP-N443-00000-00&context=1519360)_

(2) Whether the claim form had validly been served on the respondents. The mode of service R had relied on was
service by post to the respondents' private residence, in accordance with r 61(1)(a) of the Employment Tribunal
Rules of Procedure. The respondents submitted that that rule could not authorise service on a diplomatic agent
because that would violate Mr A's person, contrary to art 29 of the Vienna Convention, and his residence, contrary
to art 30 of that Convention. The question was whether there was an immunity from service, or from certain modes
of service, implicit in the inviolability of a diplomat's person and private residence.

(Per Lord Sumption) The mere conveying of information, however unwelcome, by post to a defendant, was not a
violation of the premises to which the letter was delivered. It was not a trespass. It did not affront his dignity or affect
his right to enter or leave or use his home (see [16] of the judgment).

The point concerning service of the claim form had failed at every stage below and had been dealt with by the Court
of Appeal in terms with which the court was in substantial agreement. In all the circumstances, the claim form had
been validly served (see [13]-[16] of the judgment).

Per curiam: 'In my opinion, the employment of a domestic servant to provide purely personal services is not a
'professional or commercial activity exercised by the diplomatic agent'. It is therefore not within the only relevant
exception to the immunities. The fact that the employment of Ms Reyes may have come about as a result of human
trafficking makes no difference to this' (per Lord Sumption, see [4] of the judgment).

Per curiam: 'Article 31(3)(c) of the Vienna Convention requires the interpretation of an article to take account of any
relevant rules of international law applicable in the relations between the parties ... Far preferable would it be for the
International Law Commission, mid-wife to the 1961 Convention, to be invited, through the mechanism of article 17
of the statute which created it, to consider, and to consult and to report upon, the international acceptability of an
amendment of article 31 which would put beyond doubt the exclusion of immunity in a case such as that of Ms
Reyes' (per Lord Wilson, see [67], [68] of the judgment).

[Decision of the Court of Appeal, Civil Division [2015] All ER (D) 56 (Feb) Reversed In Part.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5F7K-PXK1-DYBP-N1V4-00000-00&context=1519360)

Timothy Otty QC and Paul Luckhurst (instructed by ATLEU) for R.

Sir Daniel Bethlehem KCMG QC and Sudhanshu Swaroop QC (instructed by Reynolds Porter Chamberlain LLP)
for the respondents.


-----

Richard Hermer QC, Tom Hickman, Flora Robertson and Philippa Webb (instructed by Deighton Pierce Glynn)
(written submissions only) for Kalayaan, as intervener.

Ben Jaffey QC and Jessica Wells (instructed by The Government Legal Department) (written submissions only) for
the Secretary of State for Foreign and Commonwealth Affair, as intervener.
Carla Dougan-Bacchus Barrister.

**End of Document**


-----

