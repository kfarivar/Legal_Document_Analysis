# R v Ahmet and another [2024] EWCA Crim 102

Court of Appeal, Criminal Division

Lord Justice Dingemans, Mr Justice Andrew Baker, Her Honour Judge Angela Rafferty Kc (Sitting As A Judge Of
The Cacd)

25 January 2024Judgment

MS F ROBERTSON appeared on behalf of the Attorney General.

MR I DAVE & MS T MALCOLM appeared on behalf of the Ahmet.

MR J HURLOCK appeared on behalf of the Offender Gibbons.

_____

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

LORD JUSTICE DINGEMANS:

**Introduction**

1. This is a hearing of an application by His Majesty's Solicitor General, seeking leave to refer sentences
to this Court which the Solicitor General considers to be unduly lenient.

2. The respondents are Tunc Ahmet, who is 31 years old, having been born on 28 April 1992. He had,

before these convictions, 13 convictions for 31 offences, including possession of drugs, vehicle‑related

offences and failure to comply with court orders. He had no previous convictions for the supply of drugs.
He was sentenced to 10 months' imprisonment suspended for 18 months, imposed on 13 July 2020 for
assault occasioning actual bodily harm and affray, which related to a pub fight. Some of this offending put
him in breach of that suspended sentence. Jordan Gibbons is the other respondent. He is aged 30 years
old, having been born on 18 November 1993. He had before these matters one conviction on 16 March
2021, for obstructing powers of search for drugs, for which he was fined. He also had two police warnings.

3. Mr Ahmet first appeared before the Highbury Corner Magistrates' Court on 25 March 2021, for
possession of a controlled drug of Class A and B with intent to supply. He gave no indication of plea, and
his case was sent for trial. Mr Ahmet and Mr Gibbons then appeared before the Magistrates' Court on 20
January 2022 in respect of these conspiracies. Each gave no indication of plea, and their cases were sent


-----

for trial. Mr Ahmet remained remanded in custody throughout and Mr Gibbons was released on conditional
bail.

4. The case was listed for pre‑trial and preparation hearings on 17 February 2022 at Wood Green Crown

Court. Mr Gibbons pleaded not guilty, and Mr Ahmet was not present due to medical problems and a trial
date was fixed for 20 February 2023.

5. On 15 June 2022, when he was first arraigned, Mr Ahmet pleaded guilty to conspiracy to supply a
controlled drug of Class B, cannabis (count 5); being concerned in the supply of a controlled drug Class B,
cannabis (count 11), possessing a controlled drug of Class A, cocaine (count 12) and possessing a
controlled drug of Class B, cannabis (count 13). He pleaded not guilty to the conspiracy to supply a
controlled drug of Class A, namely cocaine (count 1) and Mr Gibbons had pleaded not guilty to three
counts of conspiracy to supply a controlled drug of Class A, cocaine (count 1), crack cocaine (count 2) and
diamorphine (count 3), and conspiracy to supply a controlled drug of Class B, namely amphetamine.

6. The trial commenced on 20 February. On 27 March 2023, the jury were discharged. A new jury were

selected, and the trial was delayed by Covid‑19, illnesses amongst legal representatives and witnesses,

the withdrawal of a co‑accused's legal team, delays in producing the defendants, who were in custody, and

the need then to take time for the jurors' holidays. On 4 October 2023, the jury returned guilty verdicts.
Sentence was adjourned until 31 October 2023.

7. During the course of the proceedings, it is apparent from the records that we have seen, that the judge
considered three applications for bail on the part of Mr Ahmet and remarked that he had been a model

prisoner. These applications were made because of consequences of Mr Ahmet's ill‑health, following an

acid attack, and his father's ill‑health. At sentencing, Mr Ahmet was sentenced to a total of 7 years 8

months' imprisonment, which comprised of 7 years 6 months on count 1, which was the conspiracy to
supply a controlled drug of Class A, 5 years' imprisonment concurrent on count 5, conspiracy to supply a
controlled drug of Class B, and no separate penalty was imposed on counts 11, 12 and 13. Two months
consecutive imprisonment was imposed for driving while disqualified and no separate penalty was imposed

for driving without insurance. Mr Ahmet was disqualified from driving for 12 months with a 29‑month

extension period.

8. The judge initially revoked a suspended sentence order and ordered no separate penalty be imposed
but this was later amended under the slip rule to activate the suspended sentence of 10 months'
imprisonment, which was then ordered to run concurrently to the substantive sentences.

9. Mr Gibbons was sentenced to a total of 6 years 6 months' imprisonment, comprising 6 years 6 months'
imprisonment concurrent on counts 1, 2 and 3, the conspiracy to supply a controlled drug of Class A, 2
years 6 months' imprisonment concurrent on count 4, conspiracy to supply a controlled drug of Class B.

**Factual offending**

10. Over the course of a year, the respondents were involved in conspiracies to purchase wholesale
quantities of Class A and Class B drugs. The drugs were then subjected to onward supply in kilogram
amounts, as well as being broken down and sold on to street users through deal lines. The respondents
were arrested as part of an investigation by the police into the supply of Class A drugs between June 2020

and July 2021. A co‑defendant, Mr Andreas Antonaides, was identified as an established and significant

supplier of Class A drugs, who was using an EncroChat network to discuss and run his business. He was
involved in the commercial supplies of kilogram quantities of Class A drugs in the United Kingdom between
March and May 2020, and following the compromise of his network, he entered into fresh conspiracies with
these respondents from about June 2020, although the dates for each differ.

11. The trial indictment conspiracies involved the purchase of quantities of Class A and B drugs, and Mr

Antonaides worked with a co‑defendant, a Mr Terry Dixon, and they were, according to the judge's

findings, the driving force of the organised drugs supply business. On behalf of the Solicitor General there


-----

was noted a disparity in sentence between Mr Dixon and Mr Ahmet who could both be described, albeit for
different periods, as trusted lieutenants. As was pointed out, the difficulties with mounting any ground of
appeal, either for the Solicitor General or for an appellant, on the basis of disparity in sentence are well
known.

12. Mr Dixon was involved in the offending between September 2020 and May 2021, and he was
implicated in the supply of cocaine, crack cocaine, heroin and cannabis in commercial quantities, which he
sourced from London and the southeast. He also ran his own operation as well as overseeing an
operation run by Mr Antonaides. Mr Ahmet assisted in the running of the business, the sale and movement
of drugs. He was involved in the conspiracy from about October 2020 to March 2021, and he was
implicated in the supply of cocaine to users and cannabis in commercial quantities and directly to users.
He provided the conspiracy with what was said to be a safe location for the delivery of wholesale quantities
of Class A drugs, where he cut and repressed them using a commercial press.

13. Mr Gibbons was involved in the conspiracy from about November 2020 to 19 April 2021, and he was
implicated in the supply of cocaine, crack cocaine, heroin and amphetamine. He managed those selling
directly to street purchasers having at least two runners and organised the various packs of drugs that
were supplied to street dealers in quantity values of £550 to £1,550. He received £1,000 per week for his
work and held one of the deal line phones at times. Much of the evidence in the case was centred on
observations of the respondents conducted by the police, who were rightly commended by the trial judge
for all their work.

14. On 23 March 2021, Mr Ahmet was observed leaving a property known as “Caneland Court”. Police
officers approached him, but Mr Ahmet ran off discarding a bag containing white powder and mobile
phones. He was detained and searched and found in possession of white powder. The contents of the
bag were analysed and found to contain cocaine and cannabis divided into deals. Mr Ahmet said that the
drugs were his. He was in possession of a key that fitted and opened the door to a property in Caneland
Court and the address was searched and a large quantity of cocaine (£30,000), skunk cannabis (£21,000),
herbal cannabis and £295 and phenacetin were found in the upstairs bedrooms. In addition, scales, heatsealing equipment, mixing equipment and a Tupperware container with white powder was found. A
subsequent analysis of cocaine revealed several batches had a purity of 94 to 97 per cent.

15. Mr Ahmet was interviewed on 24 March and 26 October 2021. He gave “no comment” interviews. Mr
Gibbons was arrested on 18 October 2021. He was interviewed and gave “no comment” interviews.

**The sentencing hearing**

16. Following the trial and conviction there was a sentencing hearing. The prosecution case was that the
chats and drugs seizures from linked conspirators and relevant addresses amounted to some 32 kilograms
of cocaine, 0.75 kilograms of crack and 6.5 kilograms of heroin, 34 kilograms of cannabis and some
amphetamine. There were also mitigation bundles prepared on behalf of Mr Ahmet and Mr Gibbons. As
far as Mr Ahmet was concerned, that contained prison certificates and achievements, positive character
references, a positive National Referral Mechanism decision about modern slavery showing that he had
been trafficked, medical evidence confirming Mr Ahmet's father's medical issues, a conditional offer of
employment on release, evidence of counselling for PTSD, a psychiatric report about his anxiety and
PTSD and a psychological report about his depressive episodes. Mr Gibbons submitted a bundle
containing a letter showing remorse, his lack of previous convictions, his good character and steps taken to
address offending behaviour, and the fact that he was a primary carer for three dependent children. He

provided character references, evidence of his mother‑in‑law and father's medical conditions and a letter in

which he set out his reflections on how life and dependants had been impacted by the offending.

**The sentencing**

17. The judge stated that she had formed her own conclusions as to the roles played by the respondents.
She took into account all of the materials which were before her. She had regard, she said, to the
Sentencing Council Guidelines on Drug Offences, totality and reduction in sentence for guilty pleas. She
also had regard to the medical reports submitted by some of the defendants and respondents but was


-----

satisfied that none of the disorders raised would have any impact on sentencing or an assessment of
culpability. She therefore did not consider the Sentencing Council Guideline on Sentencing Offenders with
Mental Disorders. The judge found, on the material that had been before her at the trial, that Mr Ahmet
and Mr Gibbons were both willing participants in the conspiracy, albeit for shorter periods than others
which the judge took into account in her consideration of categorisation and harm. The judge found that Mr
Ahmet, within this limitation, played a very significant role in the operation of the conspiracy. He expected
financial advantage and had some awareness of the scale of the operation. The judge did not accept he
was forced, coerced, treated as a modern slave or made to participate under duress. In fact, Mr Ahmet's
defence at trial had been based on **_modern slavery and the judge, in making findings of fact for the_**
purpose of sentencing, did not accept that the decision of the National Referral Mechanism should be
taken into account in considering culpability or mitigation because it was not based on the evidence,
whereas her findings were based on the evidence at trial, including the fact that Mr Ahmet had given
evidence in front of her.

18. The judge found that Mr Gibbons fell on the cusp of roles, at times performing a significant operational
or management role but, for the most part, appearing to perform under direction. He had no influence on
those above him but was aware of the scale of the operation, and the judge said that he was to be
sentenced at the top end of the lesser role.  The judge said in respect of amounts, that it was difficult, if not
impossible, to be accurate about the precise amounts of drugs involved. The judge was sure that the
figures exceeded the indicative quantities on which sentencing guideline starting points were based and
even allowing for a downward adjustment for possible exaggeration, the judge was satisfied that the
quantities involved were 15 to 20 kilos of cocaine and therefore, within harm category 1 although above the
5-kilogram basis on which the sentencing starting points were made.

19. The judge noted that the guideline made clear that where the operation is on the most serious and
commercial scale, involving a quantity of drugs significantly higher than category 1, sentences of 20 years
and above might be appropriate depending on role, and she noted that higher figures were often in respect
of exploitation or importation cases, neither of which were relevant. The judge held that the case was
aggravated by the fact that there were several forms of Class A drugs as well as dealing in Class B drugs.
The judge did not attach much weight to the previous convictions as they were not for this type of offending
and the judge expressly considered totality. The judge said:

“I have already indicated the roles you each played. I have indicated the harm that was caused, and I have
had regard to the Totality Guideline. I have also stood back and considered the sentences that I am
imposing on you. I have considered that they should be just and proportionate and that they should reflect
the serious offending that you were engaged in. I have also taken into account your roles in respect to
each other. The sentences may appear to be strange at first sight but reflect the view that I have taken of
the overall criminality.”

20. The judge said that in respect of Mr Ahmet, she had taken a starting point of 10 years, then had regard
to mitigation and ended up with the sentence of 7 years 6 months, as already indicated, with the 2 months
consecutive for the driving offence. In relation to Mr Gibbons, said that his life had been turned upside
down by his involvement, as he had previously enjoyed success as a footballer, worked and had a good
family life. She concluded he was motivated by greed, and the judge said that Mr Gibbons had appeared to
step up to support Mr Dixon following the arrest of Mr Antonaides and was a willing participant in the
conspiracy. The judge imposed a sentence of 6 years 6 months on him.

21. Co‑defendants were sentenced. Mr Antonaides was told he had a starting point of 22 years before

discounts for mitigation and pleas. Mr Dixon was sentenced to 14 years' imprisonment and another
defendant was sentenced to 6 years' imprisonment.

22. There was a slip rule hearing on 15 December 2023, where the judge and all the parties agreed that
the court did not have power to revoke the suspended sentence order which the judge had done in relation
to Mr Ahmet and imposed no separate penalty for breach. The judge therefore activated the 10-month
custodial element of that suspended sentence but ordered that it run concurrent to the sentences which
she had already imposed


-----

**Other materials**

23. It is apparent from prison reports that, although Mr Ahmet started off having some negative records,
both Mr Ahmet and Mr Gibbons have enhanced status and have cooperated with the prison regime. Mr
Ahmet has been mentoring. He prevented a suicide in prison and is drug free.

**The issues on the reference**

24. Ms Robertson, on behalf of the Solicitor General, submits that the judge failed properly: (i) to reflect
the roles of the respondents in the sentences; (ii) failed to uplift the sentence to reflect the amounts of the
drugs involved and (iii) failed to uplift the sentences to reflect the criminality of the other conspiracies and
offending disclosed.

25. It was submitted on behalf of Mr Ahmet by Mr Dave, that the judge was the trial judge and best placed
to assess the relevant factors and sentences. It was submitted on behalf of Mr Gibbons, by Mr Hurlock,
that the judge had rightly used all the information that she had gained from the trial to see exactly what
sentence ought to be imposed for the particular roles carried out by the respondents at the particular times.

**The Guidelines**

26. It was common ground that harm was assessed by the scale of the operation involved and the
conspiracy as a whole rather than each individual's part in it. The judge concluded, on a conservative
basis, that the conspiracy was involved in the supply of 15 to 20 kilograms of cocaine. This was therefore
within category 1 for count 1, and the starting point for which was based on 5 kilograms of cocaine. It was
category 2 for Class B drugs, the starting point which was based on 40 kilograms of cannabis. Relevant
starting points and ranges were for Class A category 1 significant role, a starting point of 10 years with a
range of 9 to 12 years and a lesser role, a starting point of 7 years with a range of 6 to 9 years.

27. As far as Class B was concerned, a category 2 significant role had a starting point of 8 years with a
range of 6 years 6 months to 10 years' custody and a lesser role, a starting point of 5 years with a range of
3 years 6 months to 7 years' custody. The Totality Guideline makes it clear that a court should consider
the sentence for each individual offence, referring to the relevant Sentencing Guidelines and to determine
then whether the case called for concurrent or consecutive sentences. When sentencing three or more
offences a combination of concurrent and consecutive sentences might be appropriate. A judge should
test the overall sentence against the issues of justice and proportionality.

**Some relevant legal principles relating to References**

28. In Attorney-General's Reference No 4 of 1989 (1989) 11 Cr App R(S) 517, it was held that:

“A sentence is unduly lenient we would hold where it falls outside the range of sentences which the judge,
applying his mind to all the relevant factors, could reasonably consider appropriate ... However, it must
always be remembered that sentencing is an art rather than a science: the trial judge was particularly well
placed to assess the weight to be given to various competing considerations, and leniency is not in itself a
vice. That mercy should season justice is a proposition as soundly based in law as it is in literature.”

The Reference permits this Court to remedy a gross error and therefore to preserve public confidence in
the sentencing process.

**This Reference**

29. We turn then to the three grounds on which the Reference is based. The first relates to the role, and
whether that was reflected in the sentence. The judge found that Mr Ahmet had a very significant role and
Mr Gibbons a lesser role, although at the top end. It was common ground there is no basis for interfering
with these findings because they were made by the trial judge and there is no basis such as irrationality,
internal inconsistency or inconsistency with an uncontroverted fact which would justify such an intervention.
The real question was whether the finding was reflected in the judge's sentence which involves
consideration of all the points. We turn back to that at the end.


-----

30. The second ground is that there was no uplift to reflect the amounts involved. We reject this
submission. The judge expressly sentenced a co-defendant Mr Antonaides to a sentence with a starting
point of 22 years, showing that an increase for commercial dealing was expressly shown. The different
roles played by the respondents meant that different approaches were appropriate for them. We note that
there were differences about the length of time of involvement in the particular conspiracies.

31. The third ground is that there was no uplift to reflect the other criminality disclosed by the other
conspiracies. The difficulty with that submission is that the judge expressly stated that it had been taken
into account. That brings us back to the first point and the overarching point that the sentence was simply
too short for the offending which was proved.

32. We grant leave for the Reference, because it is clear that there are some matters which require
consideration by this Court. In particular, the judge's starting point of 10 years for Mr Ahmet does not, at
first sight, appear to reflect an increase to reflect the role found, the other offending or the amount of drugs
involved. However, we have considered all these matters together with the excellent submissions made by
Ms Robertson, Mr Dave and Mr Hurlock. It is apparent that the judge, who was best placed to make the
assessment, did draw a principal distinction between the roles carried out by Mr Ahmet and Mr Gibbons
and others. A finding of, for example, significant roles covers many different activities, and it is clear that
the judge had in mind the amount involved, as appears from the sentence for Mr Antonaides. It is clear
also that there was a very substantial reduction for mitigation made for both Mr Ahmet and Mr Gibbons.
This Court might have given less discount but there were particular features of note, including, for example,
an acid attack on Mr Ahmet, his actions in prison (saving a person from suicide) and Mr Gibbons's
particular family circumstances. In all, and stepping back and looking at the matter as a whole, we do
consider the sentence to be lenient but we are unable to say that it was unduly lenient. For all those
reasons, having granted leave for the Reference, we dismiss it.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or
part thereof.

Lower Ground, 46 Chancery Lane, London WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

