# Ansari v Commissioner of Police of the Metropolis and others [2024] EWHC
 2006 (KB)

King's Bench Division

The Honourable Mr Justice Linden

31 July 2024Judgment

**Scarlett Milligan (instructed by Bindmans LLP) for the Appellant**

**Kerry Nicholson (instructed by Weightmans LLP) for the First Respondent**

**David Reader (instructed by Weightmans LLP) for the Third Respondent**

Hearing date: 10 June 2024

- - - - - - - - - - - - - - - - - - - - 
**JUDGMENT**

**MR JUSTICE LINDEN:**

**INTRODUCTION**

1. This is an appeal from an order of Senior Master Cook made on 28 October 2022. With one
qualification, the Master struck out all of the claims brought by the Claimant against the Defendants
pursuant to CPR Rule 3.4(2)(a), on the basis that her statements of case did not disclose any reasonable
grounds for bringing the Claim; and under Rule 3.4(2)(c) – failure to comply with a rule, practice direction or
order – because her statements of case did not comply with Rule 16 or Practice Direction 16 in various
respects. The qualification was that the Claimant was given 14 days to file and serve Re-Amended
Particulars of Claim which properly pleaded a claim against the First Defendant for wrongful arrest on 12
May 2022, failing which that claim would also be struck out on the same basis as the other claims which
the Claimant had brought.

2. The Claimant represented herself before the Master and she drafted the Grounds of Appeal from his
decision. Permission to appeal was refused on the papers by Sir Stephen Stewart on 23 June 2023.
However, the Claimant was represented at the renewed application for permission to appeal, before
Freedman J, by Ms Scarlett Milligan who was then acting through Advocate, the Bar pro bono charity. On
13 October 2023 Freedman J granted permission on the basis that the appeal had a real prospect of
success and that there was in any event a compelling reason for the appeal to be heard. That reason is
not, however, apparent from the Order.

**BROAD OUTLINE OF THE CASE**

3. The draft Amended Particulars of Claim (“the APOC”) which was before the Master, and which set out
the Claimant's case for the purposes of the Defendants' application to strike out, is difficult to follow and her
account of events in her various iterations of her case is not always consistent. Since the APOC was
written, she has also considerably reduced the number of claims which she wishes to pursue. I will


-----

therefore provide a brief summary of the key features of her case for the purposes of the issues in this
appeal before returning, later in this judgment, to the detail in relation to the claims which she now pursues.

4. The Claimant says in her pleaded case that she is a lawyer with a doctorate from the University of
Saveh in Iran. She qualified as an Iranian barrister-solicitor in 2011 and practised in Tehran from 20112018. She came to this country in October 2018 and applied for asylum in February 2019. She was offered
and accepted a job in a law firm, Vanguard Law, in September 2019. At the time of her original Particulars
of Claim, in May 2021, she was doing a conversion course to become a solicitor in England. It appears
from a supplementary skeleton argument which she prepared that, by 14 March 2023, she had passed the
Solicitors Qualifying Examination.

5. Ms Milligan's Speaking Note for the permission hearing before Freedman J states that the Claimant has
had Attention Deficit Hyperactivity Disorder since childhood, but I was not able to find any suggestion that
this was the case in the Claimant's various statements of case, witness statements or skeleton arguments.
Ms Milligan's skeleton argument for the purposes of the hearing before me did not suggest that this was
the case either, but it said that the Claimant _“has been assessed as having symptoms of depression,_
_anxiety and [Post Traumatic Stress Disorder] and has previously been referred to a trauma service as a_
_result” (emphasis added). The Claimant also makes references to anxiety in her statements of case and_
asserts that she was diagnosed with PTSD as a result of the actions of the First and Third Defendants in
arresting her in March 2020 and September 2021, although no detail or medical evidence to support these
assertions was put before me.

6. In broad outline, it appears from the Claimant's statements of case that the job with Vanguard Law was
offered to her by a Ms Maryam Sohi who was representing her in relation to her claim for asylum and that,
in October 2019, the Claimant moved into a flat which she rented from Ms Sohi for £500 per month. At an
early stage, relations between the Claimant and Ms Sohi appear to have soured. The Claimant alleges that
she objected to unethical conduct by Ms Sohi and that she was not paid wages which she was owed. By
29 November 2019 the Claimant had reported Ms Sohi to the Metropolitan Police when she became
“aggressive”. She says that she also called the police on 6 December 2019 about “an Arab Girl who had
been instructed by Ms. Sohi. (sic) the girl had twisted my right index finger” and that she made a further
report to the police on 5 March 2020 about a male who had been instructed by Ms Sohi to turn off the
electricity in the flat. She also says that she reported online harassment by Ms Sohi on 12 March 2020.

7. The police were then called to an incident at the flat on 18 March 2020 where, according to a 24
January 2022 report by the Professional Standards Unit of the North West Basic Command Unit of the First
Defendant on an investigation into a subsequent complaint by the Claimant, Ms Sohi was found slumped at
the bottom of a staircase and she and various witnesses alleged that the Claimant had pushed her down
the stairs. The Claimant denies that she pushed Ms Sohi down the stairs and alleges that she was
attacked by Ms Sohi after she had taken an electrician to repair a fuse box. She says that she attempted to
video the incident but her mobile phone was taken from her by one of the witnesses. She refers to this as
“a violent robbery”. The police found the account of Ms Sohi and the other witnesses to be sufficiently
credible for the Claimant, who was apparently in an agitated state, to be arrested, handcuffed and taken
into custody.

8. On 19 March 2020, the Claimant was charged with common assault on Ms Sohi. The matter proceeded
to trial in the Willesden Magistrates' Court and, on 19 March 2021, the Claimant was found not guilty. This
prosecution was the subject of the claim against the Second Defendant.

9. The Claimant says that, after the 18 March 2020 incident, on 5 further occasions up to and including 16
May 2021 she reported that she had been subject to online harassment and abuse by Ms Sohi. On the
other hand, the police appear from the APOC to have taken the view that the Claimant was at least partly
responsible and, on 26 January 2021, to have warned her not to post about Ms Sohi and threatened her
with arrest if she did.

10. It appears that by September 2021 the Claimant was living in Brighton. On 1 September 2021 she was
arrested by officers of the Third Defendant on suspicion of sending malicious communications. The
allegation which the Claimant denies was that she had operated an Instagram account which posted a


-----

message which (according to the Claimant) included Ms Sohi's address and the address of her mother.
The post is said to have incited an acid attack on Ms Sohi (although the Claimant pleads in the APOC that
it incited an attack on a police officer and called the officer a “whore”). It was also alleged to have
encouraged an attack on Ms Sohi's mother. The Claimant was handcuffed and taken into custody. As part
of the investigation which followed, her three electronic devices were seized. Ms Milligan says in her
skeleton argument that there were then prolonged discussions between the First and the Third Defendant
as to which police force should have jurisdiction over the investigation given that the Claimant lived in
Brighton and had been arrested there, but Ms Sohi lived in London.

11. The Claimant was arrested by officers of the Third Defendant again in Brighton on 12 May 2022 on
suspicion of online harassment and stalking of Ms Sohi. She denied that she operated the Instagram
account in question. She was handcuffed and taken into custody and her mobile phone was seized. She
alleges that she was forced to take all of her clothes off whilst in custody in front of 6 officers who included
male officers. It appears that she was then taken to London in the small hours of the morning.

12. It appears that the investigation of the Claimant, and the Claimant's devices, were then transferred to
London in late May 2022. Her devices were returned to her on 10 September 2022 and, I am told, the
Claimant was not charged.

**THE PROCEEDINGS BELOW**

13. The original Claim Form was dated 17 March 2021 by the Claimant, although the seal date is 8 June
2022, and the original Particulars of Claim is dated 19 May 2021. The CE-File shows that these documents
were uploaded on 8 June 2022. Multiple claims are identified in the Claim Form as follows:

_“1- Claimant seeks an interim injunction under the_ _[Protection from Harassment Act 1997 restraining](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)_
_defendants from another unlawful arrest and seizure of belongings and trespass._

_2- Claimant seeks an interim injunction to return her 4 devices seized by the 3[rd] defendant._

_3- Claimant seeks, Damages, including aggravated damages against Defendants for Wrongful Arrest_
_and/or False detention and/or Malicious Prosecution and/or Trespass to good and land and/or for the_
_wrongful imposition of three devices and/or Misfeasance in public office and/or Assault and/or Injury_
_[Compensation and/or breach of protection from Harassment Act 1997 and/or, Breach of privacy Article 8](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y0CJ-00000-00&context=1519360)_
_Human Right Act 1998 and/or Lack of medical care while in custody and/or Defamation and/or breach of_
_[the Data Protection Act 1998 and/or breach of Freedom of Expression article 10 of the Human Right Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y13M-00000-00&context=1519360)_
_[1998 and/or Contempt of court and/or negligence, breach of the right to a fair trial Article 6 of the Human](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
_[Rights Act 1998 and/ Breach of Article 5 of Human Right, Right to liberty and/or Breach of Article 9 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
_Human Right: the Freedom of thought, belief, and religion and/or Exemplary compensation….”_

14. The value of the Claim and/or the amount claimed was stated to be £150,000.

15. The Third Defendant filed and served a Defence dated 25 July 2022 which set out her case as best
she could, expressly subject to the contention that the Claim should be struck out pursuant to Rule
3.4(2)(c) because the Particulars of Claim did not comply with Rule 16.2(1)(a) – which requires that the
Claim Form “contain a concise statement of the nature of the claim” - and contained no recognisable claim,
such that it should be struck out pursuant to Rule 3.4(2)(a).

16. There was then an amended Claim Form which was sealed on 19 September 2022. The amendment
was a minor one, to delete the claim for an order for the return of the Claimant's devices given that they
had by now been returned. All of the claims in the original Claim Form were apparently still pursued. The
amended Claim Form was accompanied by the APOC which is dated 19 September 2022. Although it is
not clear to me that permission to amend was given, no point on this was taken before me. These
documents were served by email on 20 September 2022.

17. The APOC runs to 34 pages and, the Claimant now accepts, did not comply with the requirements of
CPR Part 16 for various reasons. It refers to multiple different types of claim in relation to a number of
incidents or parts of incidents which are not presented in chronological order. It is lacking in coherence,
l d diffi lt t f ll It th t th Cl i t i ki “E l C ti ” d d


-----

for the impact of the Defendants' actions on her mental health but there is no schedule of loss. Although
the APOC says that the Claimant has attended approximately 25 therapy sessions in relation to her mental
health and is still attending a psychologist, no medical report is provided in support of the Claimant's
assertion that her mental health had been harmed and she had been caused PTSD by the first arrest and
complex PTSD by the second one. There is reference to medical records being attached, but these were
not included in the bundle for the appeal (see, further, below).

18. On 22 September 2022 there was then an Order, apparently of the Master's own motion although I
was not shown the Order, listing the matter for a hearing before the Master on 28 October 2022. The Order
stated that at the hearing:

_“the Court will be considering whether to strike out the claim or transfer            it to the county_
_court”._

19. The Second Defendant's Defence, dated 14 October 2022, and the Third Defendant's Amended
Defence, dated 19 October 2022, then both contended that the case as set out in the APOC should be
struck out pursuant to Rule 3.4(2) on the grounds that it still failed to comply with Rule 16, it disclosed no
reasonable grounds for bringing the Claim, and it was an abuse of the Court's process or otherwise likely to
obstruct the just disposal of the proceedings. All three limbs of Rule 3.4(2) were therefore relied on. The
Defendants also argued in the alternative that there should be summary judgment, dismissing the whole of
the Claim pursuant to Rule 24.2, on the basis that the claims had no real prospect of success and there
was no other compelling reason why the case should go to trial.

20. The First Defendant did not file a defence but did make an application, dated 18 October 2022, to
strike out the whole of the Claim pursuant to both Rule 3.4(2)(a) and (c). That application was supported by
a witness statement made by Mr Lambourne of Plexus Law. At [4]-[13] he explained why the First
Defendant took the position that the pleaded claim did not disclose reasonable grounds for bringing it,
including by reference to some of the relevant law. He also exhibited a letter, dated 24 January 2022, to
which I have referred at [7] above. In this letter the First Defendant had set out its response, based on body
worn camera footage of the 18 March 2020 incident, to issues which the Claimant had raised by way of
various formal complaints to the First Defendant. The First Defendant's case was also set out in a letter
dated 13 April 2022 which Mr Lambourne exhibited.

21. In relation to the First Defendant's case under Rule 3.4(2)(c), Mr Lambourne contended that the
amended Claim Form did not contain a concise statement of the nature of the claim as required by Rule
16.2(1)(a) – it failed to specify relevant dates, actions and locations - that although the value of the Claim
was said to be “£150,000” the remedy sought was not particularised, contrary to Rule 16.2(1)(b) and (c);
and the Claimant had not served a schedule of loss, contrary to [4.2] of Practice Direction 16, and had
failed to serve a medical report in support of her claims for personal injury pursuant to [4.3] of the same
Practice Direction.

22. The Claimant made applications, on 6 and 19 October 2022, for the hearing on 28 October 2022 to be
“cancelled”. In the latter application, she also asked for the matter to be heard by a jury. These applications
were dismissed by the Master who held that they were “totally without merit”.

23. The Defendants also agreed a Case Summary dated 24 October 2022 which was served on the
Claimant by email on the same day. It said that each of the Defendants would submit, at the hearing before
the Master, that the whole of the Claimant's statements of case should be dismissed either by striking out
pursuant to Rule 3.4(2) or by summary judgment pursuant to Rule 24.2. The Defendants again contended
(a) that there were no reasonable grounds for bringing the Claim; (b) that the statements of case were an
abuse of process or otherwise liable to obstruct the just disposal of the proceedings; and (c) that there had
been a failure to comply with the requirements of Part 16 as to pleading. They also made clear that they
would be seeking their costs, and the sums which they would claim were identified. And they argued that
there should be no further opportunities to amend afforded to the Claimant and nor should the matter be
transferred to the County Court to enable her to do so. They said that the deficiencies in her claim had
been pointed out to her and this had resulted in further applications, additional sets of proceedings and
vexatious correspondence and complaints


-----

**THE HEARING BEFORE THE MASTER**

24. There is no transcript of the hearing before the Master or of the reasons for his decision, as the
recording equipment malfunctioned. However, the Defendants have helpfully agreed a Note of the hearing
which the Master has approved. The Claimant does not agree this Note but she has inserted, in red, a
small number of additional points which she says she made at the hearing. Her position appears to be the
Note is incomplete rather than inaccurate so far as it goes and it is fair to say that the Note, which runs to 4
pages, is a compressed version of a hearing which lasted approximately 2 hours.

25. At the outset of the hearing the Master explained to the Claimant his concerns about her pleaded case
which, he said, did not contain a concise statement of the facts, did not properly plead the causes of action
or the claim for damages and did not include any medical evidence to support the claims for personal
injury. He said that the pleaded case did not begin to comply with the CPR. The Note of the hearing
describes the Master's criticisms of the Claimant's statements of case as “direct” and “candid”. He said that
he would therefore go through the alleged causes of action and consider whether, on the Claimant's
version of events, they were capable of being properly pleaded. When he had done so he would then
consider what to do in terms of giving the Claimant more time or transferring the Claim to the County Court.

26. The Master then explained the ingredients of a claim for malicious prosecution and asked the Claimant
to explain her claim against the Second Defendant. He told her that her understanding of the law was
incorrect and concluded that, even if the facts were as the Claimant said they were, this claim was bound
to fail. He therefore struck out the malicious prosecution claim and held that it was totally without merit on
the basis that it should never have been brought.

27. The Master then turned to the allegations against the First Defendant and went through the same
exercise, asking the Claimant to explain her case on wrongful arrest and what other claims she sought to
bring against the First Defendant. As to other claims, she referred to negligence and to complaining about
**_modern slavery on numerous occasions, and her amendments to the Note say that she referred to_**
defamation by malicious prosecution based on false evidence, to trespass to land, to trespass to goods, to
personal injury and breaches of each of Articles 3 to 6 of the European Convention on Human Rights
(“ECHR”) and Article 1 of Protocol 1 (“A1P1”). The Master ordered that all of these claims be struck out,
save for a claim for wrongful arrest in respect of the arrest of the Claimant on 12 May 2022. He also
referred to the lack of any pleading of injury or a medical report. The Claimant's amendments to the Note
say that she responded that “she will provide if direction is given”.

28. The Master then undertook the same exercise in relation to the Claimant's claims against the Third
[Defendant. She said that she made claims for wrongful arrest and, under the Human Rights Act 1998,for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
breaches of Article 9. Her amendments to the Note say that she also referred to Article 5 ECHR and A1P1.
She also referred to claims for trespass to goods and land. The Claimant also argued that email service of
the Claim by her on the Third Defendant had not been effective with the result that the Third Defendant's
Acknowledgement of Service and Defence were, in effect, pre-action and either out of time or an abuse of
process, such that they should be struck out. The Master found that service had been effective and
criticised the Claimant for attempting to manipulate the procedural rules. He then struck out all of the
claims against the Third Defendant, save for a claim for wrongful arrest, on the grounds that they were
chaotic and not in accordance with the requirements of the CPR.

29. The Master then considered whether any of the allegations of unlawful arrest against the First and
Third Defendants could be properly pleaded and concluded that there was one allegation, in relation to the
arrest on 12 May 2022, which was “just about arguable”. According to the Note he then heard submissions
from the Claimant which led him to decide that, as the Third Defendant was acting on requests which had
been made by the First Defendant, the only potentially viable claim was against the First Defendant and
the claim in respect of this arrest would therefore be struck out as against the Third Defendant.

30. The Master added that the pleading of the claims was an abuse of the court's process and that the
statement of case obstructed the disposal of the proceedings or otherwise interfered with the smooth
running of justice. His view of the case was that the only potentially viable claim was the claim for wrongful
arrest on 12 May 2022 against the First Defendant This led him to give the Claimant 14 days to file and


-----

serve a compliant statement of case in relation to this claim. He held that the claims which he had struck
out were also totally without merit and he warned the Claimant about the possibility of a civil restraint order
if she were to make further pointless or misguided applications or claims. In relation to costs he awarded
the Second and Third Defendants the full sums claimed by them in their statements of costs on the basis
that these sums (£10,316.30 and £5,600.10 respectively) were both reasonable and proportionate.

31. The Master gave his decisions as to the merits of the claims against each of the Defendants in turn in
the course of the hearing, as they were explained by the Claimant, rather than in one judgment at the end
of the hearing. It is also fair to say that the Note gives only a limited account of what was said to him and of
his reasoning.

32. Although it appears from the Note that the Master considered that all three limbs of Rule 3.4(2) were
satisfied, his Order states that the claims were struck out under Rules 3.4(2)(a) and (c). There is no
suggestion that the claims were dismissed under Rule 24.2.

**THE APPEAL**

33. The Grounds of Appeal document which was attached to the Notice of Appeal asserts, in the
Introduction, that the appeal is on the ground that the Master's Order was “wrong in principle”. The five
grounds of appeal focus on alleged wrongful arrest in March 2020, September 2021 and May 2022, and
malicious prosecution by the Second Defendant.

34. When the renewed application for permission was made before Freedman J, the proposed grounds of
challenge, as set out in a helpful Speaking Note drafted by Ms Milligan, were that “the claim documents”
before the Master did contain facts which, if proven, amounted to causes of action identified by the
Claimant against each of the Defendants. The Speaking Note went on to identify, by reference to specific
paragraphs of the APOC, the particular claims which it was maintained were “legally recognisable
claims….which are capable of being advanced on the facts as alleged in the Particulars of Claim.” against
each of the Defendants. It is not necessary to list the claims which were said to be arguable, as the list had
shortened by the time of the hearing before me. But suffice it to say that, even at that stage, it did not
include any claim for wrongful arrest against any of the Defendants. Certain paragraphs of the APOC were
also noted by Freedman J in his Order as not being pursued.

35. Secondly, the Speaking Note for the purposes of the renewed application for permission argued that it
was not proportionate to strike out the claims for failure to comply with the requirements of the CPR.
Instead, the Claimant should have been given an opportunity to address the deficiencies in her statements
of case by way of amendment and/or the filing and serving of substitute amended Particulars of Claim
within a specified timescale.

36. Thirdly, it was said to follow from these two points that the order that the Claimant pay the full amount
of the costs incurred by the Second and Third Defendants was disproportionate.

37. At the permission stage, the appeal was not based on any criticism of the amount of notice which the
Claimant had been given of the issues at the hearing before the Master, nor any criticism of his conduct of
the hearing. However, on 29 June 2023, the Claimant had filed an Application Notice which renewed her
application for permission to appeal but also, on one reading, applied to set aside the Master's Order, albeit
on bases which were unclear. Freedman J directed that the Claimant file and serve a properly formulated
application by 19 January 2024, which would be heard alongside the appeal. This she did on 19 February
2024, having been granted an extension of time for doing so on 17 January 2024.

38. The 19 February 2024 application was made pursuant to Rule 3.1(7) and was supported by a
statement of Ms Joanna Bennett, an associate at Bindmans LLP who now acts for the Claimant, legal aid
having been granted on 7 February 2024. She said at [14] that the Claimant accepted that her pleadings
did not comply with CPR Part 16 but that the breach was not so serious that it could not be rectified. She
pointed out that the Claimant was a litigant in person and said that she was vulnerable. The Claimant
accepted that the notice of the hearing before the Master stated that the purpose of the hearing was to
consider whether to strike out the claim or transfer it to the County Court, but Ms Bennett said that the


-----

Claimant was not aware of the deficiencies in her pleadings until she was in the hearing room. The hearing
before the Master involved a debate between her and the Master as to the merits of the case which was
“highly technical, focussing on the constituent elements of causes of action”. The Claimant was unable
properly to follow that debate, let alone to “provide a full and complete answer to it in the heat of what was,
for her, a stressful hearing”. That, in itself, was good reason to give the Claimant time to address the
deficiencies in her statements of case and it was disproportionate to strike out without giving her an
opportunity to do so.

39. Ms Milligan's skeleton argument, dated 3 June 2024, for the full hearing of the appeal before me said
that the grounds of appeal were that:

i) The Master erred in law in that, having concluded that the Claimant's statements of case did not comply
with the CPR he failed to have any regard to the proportionality of striking out the Claim and requiring the
Claimant to pay the whole of the Second and Third Defendants' costs, as opposed to giving her an
opportunity to address the deficiencies in her pleadings.

ii) He also erred in law in holding that the Claimant's statements of case did not disclose reasonable
grounds for bringing the Claim save in respect of the claim against the First Defendant in relation to the
arrest on 12 May 2022.

40. At [53] of her skeleton argument Ms Milligan set out the list of claims which were said to be both
apparent from the APOC and arguable, and I address these claims below. However, she also widened the
scope of the appeal beyond that which had been given permission by Freedman J. In addition to the
grounds of appeal in the paragraph above, she now also relied on the _“serious procedural or other_
_irregularity” limb of Rule 52.21(3). She contended that the Claimant was not given advance notice of the_
matters which would be put to her and on which the strike out would be based, and nor was she given any
opportunity to rectify her pleaded case “in circumstances where the allegations contained therein were of
the utmost gravity and required full and fair consideration by the court”. This rendered the Master's Order
_“unjust” and it should therefore be set aside. Her position was that in the event that the Court allowed the_
appeal on this basis, the Claimant's application to set aside under Rule 3.1(7) need not be considered.

**THE HEARING BEFORE ME**

41. By the time of the hearing before me, the Claimant had reached a settlement with the Second
Defendant and the appeal was therefore pursued only in relation to the alleged claims against the First and
Third Defendants. At the beginning of the hearing Ms Milligan also confirmed that:

i) The Claimant did not in fact file Re-amended Particulars of Claim pursuant to the opportunity given in
the Master's Order. Her claim against the First Defendant of wrongful arrest on 12 May 2022 therefore
stands struck out.

ii) Her skeleton argument contained, at [53], all of the claims which the Claimant now sought to pursue,
and any other claims were now dropped.

iii) As was apparent from the Speaking Note for the permission hearing and her skeleton argument, the
Claimant was not pursuing any claim for wrongful arrest against any Defendant, not even in respect of the
arrest on 12 May 2022.

iv) Although a different impression may have been given by her skeleton argument, she was not arguing
that the Master conducted the hearing on 28 October 2022 unfairly or that there was a procedural or other
irregularity in the conduct of that hearing itself. Her case was that the lack of notice of the hearing and the
matters referred to by Ms Bennett in her witness statement were reasons to give the Claimant another
chance to put her statements of case right.

42. I raised, more than once, the fact that the APOC appeared to have enclosed 29 Annexes and that it
was not clear whether any of these had been included in the bundle for the appeal. However, all parties
confirmed that they did not seek to put any further documents or Annexes before me. Ms Milligan
confirmed this twice in the course of the hearing.


-----

43. Ms Milligan did not provide a draft of the pleading which, on her case, could have been produced if the
Claimant had been permitted by the Master to rectify the deficiencies in the APOC by amendment or
substitution. She said that this was because of legal aid funding constraints. However, nor did her skeleton
argument clearly indicate how the proposed claims would be pleaded, or cross refer to the APOC to show
that these claims could and should have been recognised by the Master. Matters were further complicated
by the fact that no explanation of the legal basis for any of the claims was provided in her skeleton, other
than what appears in the passages quoted below. It was therefore necessary to go through each of the
proposed claims in turn at the hearing and for Ms Milligan to provide an explanation of her case and its
legal basis. No schedule of loss was provided for the purposes of the appeal and nor, as I have noted, was
any medical evidence put before me to evidence the Claimant's claims about her injuries or her health
more generally.

44. At the end of the hearing, in her reply to the submissions of her opponents, Ms Milligan also sought to
change her position about whether the Claimant was pursuing any claim for wrongful arrest. She indicated
that she now wished to pursue a claim based on the arrest on 12 May 2022 and said that her change of
position had arisen out of something which had been said by her opponents in the course of their
submissions, but it was not clear how this was so. It appeared that she was relying on matters which were
already apparent from the Note of the hearing before the Master. I therefore directed that if she wished to
make any application in this regard she should set it out in writing, with a clear explanation, within 7 days. I
also gave the Defendants the opportunity to provide a written reply if they wished to.

45. In the event, an application to pursue a claim for wrongful arrest in relation to 12 May 2022 was made
on behalf of the Claimant on 17 June 2024 and there were witness statements in reply from the First and
Third Defendants dated 24 June 2024 which resist that application. I deal with the detail of this issue
below.

**THE ISSUES IN THE APPEAL**

46. In the light of the above, the issues for me to determine were:

i) Whether I should give permission for Ms Milligan to appeal on the serious procedural irregularity point
and, if so, whether the appeal should be allowed on this basis and/or whether I should grant the Claimant's
Rule 3.1(7) application (“Issue 1”).

ii) Whether the Master erred in law in relation to the question whether it was proportionate to strike out the
Claim and, in particular, whether he should have given the Claimant an opportunity to plead claims which
are apparent from the APOC and have a real prospect of success, either by amendment or by a
substituted compliant statement of case. (“Issue 2”)

iii) Whether the Master erred in law in holding that the APOC did not disclose reasonable grounds for
bringing the Claim. (“Issue 3”)

iv) The Claimant's application of 17 June 2024. (“Issue 4”)

**ISSUE 1: ALLEGED PROCEDURAL UNFAIRNESS**

47. As to the Claimant's application to set aside the Master's Order pursuant to Rule 3.1(7), [3.1.17.1.1] of
the White Book 2024 states that:

_“The interests of justice, and of litigants generally, require that a final            order remains final_
_unless there are proper grounds for an appeal, or            unless there are exceptional grounds for_
_varying it or revoking it without            an appeal.”_

48. In my view there are no exceptional grounds for dealing with the Claimant's complaint of procedural
unfairness by way of an application under Rule 3.1(7). In the course of her oral submissions Ms Milligan
suggested that the fact that there was an approved Note of the hearing rather than a transcript was an
exceptional reason for dealing with the Claimant's procedural complaints in this way. But I do not see why
that is so. The procedural complaint is about whether the Claimant had adequate notice of the issues at the
hearing The evidence which is relevant to that complaint is in documentary form and what happened is


-----

clear. Insofar as the fact that there is no transcript of the hearing is a problem, it is as much a problem in
relation to the Rule 3.1(7) application as it is in relation to the appeal. The absence of a transcript does not
render a Rule 3.1(7) application rather than an appeal appropriate.

49. Given that the issue of whether to strike out was determined after argument at a hearing which was
attended by the Claimant, the correct procedural route was to appeal the Master's Order and to raise any
issues as to procedural fairness in that context. Indeed, it was implicit in her overall approach to this issue,
which was to raise it as part of the appeal and to say that the Rule 3.1(7) application did not arise if the
appeal point succeeded, that Ms Milligan recognised this.

50. This, in itself, is sufficient to dispose of the Claimant's application of 19 February 2024 but, in any
event, there is no basis on the merits to set aside the Master's Order, as I will explain.

51. Rule 52.21(3) provides that:

_“(3) The appeal court will allow an appeal where the decision of the lower            court was—_

_(a) wrong; or_

_(b) unjust because of a serious procedural or other irregularity in the            proceedings in the_
_lower court.”_

52. There was no procedural or other irregularity in the proceedings before the Master, still less a serious
one or one which rendered his decision _“unjust” on this ground. As I have sought to illustrate in my_
summary of the steps taken by the Defendants and the Master in the proceedings which led up to the
hearing on 28 October 2022 (see [15]-[23], above), the Claimant was put on notice of the issue as to
whether her Claim should be struck out, and the bases on which it was said that it should be struck out, as
early as 25 July 2022. The Defendants' position that it should be struck out was reiterated and explained
several times thereafter. It was also made clear to the Claimant, more than a month before 28 October
2022, that this question would be determined at that hearing. She had ample opportunity to appreciate that
it was being alleged that her statement of case did not comply with the CPR and that there was no legal
basis for her case, and to prepare accordingly. She is also a lawyer, albeit trained in a different jurisdiction,
and it is evident from her various statements of case that she was able to access, and had accessed, the
relevant source materials.

53. No complaint is made about the hearing before the Master other than in the form of Ms Bennett's
evidence that the Claimant was not able to explain her causes of action because she was a litigant in
person who had not understood the rules or appreciated the deficiencies in her statements of case. But the
answer to this complaint is as stated above: she had ample notice of the issues at the hearing and time to
prepare and, at least in principle, was in a better position to prepare than many litigants in person who
have no legal training at all. The Master then gave her an opportunity to explain the claims which she was
bringing. That she was unable to do so reflects the lack of focus in her case and fact that she had brought
a large number of different types of claim, apparently without fully understanding the law on which they
were based. It is also indicative of a lack of legal merit in most, if not all, of these claims rather than a lack
of fairness in the procedure which led to the Master's Order.

54. The Grounds of Appeal drafted by the Claimant do not challenge the fairness of the procedure which
led to the hearing or the conduct of the hearing itself, and nor does the Claimant's original skeleton
argument in support of the appeal dated 4 November 2022 or her supplementary skeleton argument dated
14 March 2023. No application to amend the Grounds of Appeal was made by Ms Milligan. Nor, as I have
pointed out, did Freedman J give permission for such a ground to be argued in the appeal. Erring on the
side of generosity, and treating Ms Milligan's raising of the point in her skeleton argument as an application
to amend and for permission to appeal, I refuse permission to amend and/or to appeal on this point on the
basis that it has no real prospect of success. For the same reasons, I would have dismissed the appeal in
any event and refused the application to set aside under Rule 3.1(7).

55. Although Ms Milligan asserted in her oral submissions that there could be a case in which there was a
procedural irregularity which was not sufficiently important to form the basis for a successful appeal under


-----

Rule 52.21(3)(b) but was sufficiently important to set aside a final order pursuant to Rule 3.1(7), she did not
give an example. Nor is it easy to think of one. The essence of the Rule 52.21(3)(b) basis for allowing an
appeal is that there has been a procedural or other irregularity which is sufficiently serious to render the
decision unjust. If the irregularity is not sufficiently serious to pass this test, the appeal will fail because, in
effect, the court has concluded that the decision was not unjust. If that is the position, it is difficult to see
how the same procedural issues can then be relied on to contend, in effect, that the order was unjust for
the purposes of an application under Rule 3.1(7) and should therefore be set aside.

**ISSUES 2 AND 3: WAS THE MASTER WRONG TO STRIKE OUT?**

**Legal framework: the principles applicable to applications to strike out under CPR Rule**
**3.4(2)**

56. CPR Rule 3.4(2) provides as follows:

_“3.4 (2) The court may strike out a statement of case if it appears to the court-_

_(a) that the statement of case discloses no reasonable grounds for bringing or defending the claim; or_

_(b) that the statement of case is an abuse of the court's process or is otherwise likely to obstruct the just_
_disposal of the proceedings; or_

_(c) that there has been a failure to comply with a rule, practice direction or court order”_

57. The rule contemplates a two stage approach (see Asturian Fondation v Alibrahim [2020] 1 WLR 1627
at [64] and Cable v Liverpool Victoria Insurance Co Ltd [2020] 4 WLR 110):

i)  first, is one of the three bases for strike out established?; and

ii) if it is, second, should the court in the exercise of its discretion strike the statement of case out?

58. As to the test under Rule 3.4(2)(a), it is well established that, in contrast to an application for summary
judgment under Rule 24.2, the court should focus on the pleaded case rather than the evidence (see: The
_Royal Brompton Hospital NHS Trust v Hammond [2001] 1 Lloyds Rep PN 526 at [106]) and should ask_
whether that case is hopeless or bound to fail. The court should normally assume the pleaded facts to be
true unless they are contradictory or obviously wrong: see e.g. MF Tel Sarl v Visa Europe Limited _[2023]_
_EWHC 1336 (Ch) at [34(1)] and should not attempt to resolve disputes of fact. Nor should it generally seek_
to determine novel points of law, particularly where the facts are in dispute.

59. Ms Milligan also referred to the examples of the type of case which may be struck out under Rule
3.4(2)(a) which are given in [1.2] of Practice Direction 3A. These are:

_“(1) those which set out no facts indicating what the claim is about, for example “Money owed £5,000”,_

_(2) those which are incoherent and make no sense,_

_(3) those which contain a coherent set of facts but those facts, even if true, do not disclose any legally_
_recognisable claim against the defendant.”_

60. As far as Rule 3.4(2)(c) is concerned, it was common ground that the fact that the Claimant was a
litigant in person at the relevant time did not exempt her from compliance with the CPR: see _Barton v_
_Wright Hassell LLP [2018] 1 WLR 1119 at [18] where Lord Sumption JSC said:_

_“At a time when the availability of legal aid and conditional fee agreements            have been_
_restricted, some litigants may have little option but to represent            themselves. Their lack of_
_representation will often justify making            allowances in making case management decisions_
_and in conducting            hearings. But it will not usually justify applying to litigants in person a_
_lower standard of compliance with rules or orders of the court. The            overriding objective_
_requires the courts so far as practicable to enforce            compliance with the rules:… . The rules_
_do not in any relevant respect            distinguish between represented and unrepresented parties…_
_Unless the            rules and practice directions are particularly inaccessible or obscure, it is_


-----

_reasonable to expect a litigant in person to familiarise himself with the rules            which apply to_
_any step which he is about to take.”_

61. The rules and practice direction in this case were those which apply to pleadings under Part 16. These
include the requirements:

i) under Rule 16.1(a), to provide in the claim form “a concise statement of the nature of the claim”; and (b)
to specify the remedy which the Claimant seeks;

ii) under Rule 16.4(1)(a), to include in the Particulars of Claim “a concise statement of the facts on which
_the Claimant relies” and, under (e), such other matters as may be set out in a practice direction;_

iii) under [1.4] of Practice Direction 16, that _“If a statement of case exceptionally exceeds 25 pages…it_
_must include an appropriate short summary at the start”;_

iv) under [4.2] of Practice Direction 16, in personal injury claims, to attach a schedule of loss to the
Particulars of Claim and, under [4.3], _“Where the Claimant is relying on evidence from a medical_
_practitioner….a report from the medical practitioner about the Claimant's personal injuries”._

62. As is well known, the purpose of a statement of case is to identify the issues and the extent of the
dispute between the parties. It should not contain excessive detail. As Leggatt J (as he then was) put it in
_Tchenguiz v Grant Thornton UK LLP_ _[[2015] 1 All ER (Comm) 961 at [1]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VWB-SKN2-D6MY-P500-00000-00&context=1519360)_

_“Statements of case must be concise. They must plead only material facts, meaning those necessary for_
_the purpose of formulating a cause of action or defence, and not background facts or evidence. Still less_
_should they contain arguments, reason or rhetoric. These basic rules were developed long ago and have_
_stood the test of time because they serve the vital purpose of identifying the matters which each party will_
_need to prove by evidence of trial.”_

63. Teare J also said this at [18] of his judgment in Towler v Wills _[2010] EWHC 1209 (Comm):_

_“The purpose of a pleading or statement of case is to inform the other party what the case is that is being_
_brought against him. It is necessary that the other party understands the case which is being brought_
_against him so that he may plead to it in response, disclose those of his documents which are relevant to_
_that case and prepare witness statements which support his defence. If the case which is brought against_
_him is vague or incoherent he will not, or may not, be able to do any of those things. Time and costs will, or_
_may, be wasted if the defendant seeks to respond to a vague and incoherent case. It is also necessary for_
_the Court to understand the case which is brought so that it may fairly and expeditiously decide the case_
_and in a manner which saves unnecessary expense. For these reasons it is necessary that a party's_
_pleaded case is a concise and clear statement of facts on which he relies…”_

64. As for the stage 2 question under Rule 3.4(2), should the statement of case be struck out, Ms Milligan
emphasised that the fact that the threshold for striking out a claim is crossed does not mean that strike out
follows automatically. The discretion to do so should be exercised in accordance with the overriding
objective. Striking out is a draconian step and it will only be justified where it is proportionate. She relied on
the following passage from _Fairclough Homes v Summers [2012] 1 WLR 2404 at [48], which considered_
the position under Article 6 ECHR:

_“It is in the public interest that there should be a power to strike out a statement of case for abuse of_
_process, both under the inherent jurisdiction of the court and under the CPR, but…. in deciding whether or_
_not to exercise the power the court must examine the circumstances of the case scrupulously in order to_
_ensure that to strike out the claim is a proportionate means of achieving the aim of controlling the process_
_of the court and deciding cases justly.”_

65. Ms Milligan also referred to _Biguzzi v Rank Leisure Plc [1999] 1 WLR 1926 at 1932B where, Lord_
Woolf MR said this:

_“Under rule 3.4(2)(c) a judge has an unqualified discretion to strike out a case such as this where there has_
_been a failure to comply with a rule. The fact that a judge has that power does not mean that in applying_
_the overriding objective the initial approach will be to strike out the statement of case. The advantage of the_


-----

_CPR over the previous rules is that the court's powers are much broader than they were. In many cases_
_there will be alternatives which enable a case to be dealt with justly without taking the draconian step of_
_striking the case out.”_

66. And she reminded me of the following passage from the judgment of Tugendhat J in In Soo Kim Park
_& Others_ _[[2011] EWHC 1781 (QB) at [40]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GJ7-PW71-F0JY-C1MB-00000-00&context=1519360)_

_“However, where the court holds that there is a defect in a pleading, it is normal for the court to refrain from_
_striking out that pleading unless the court has given the party concerned an opportunity of putting right the_
_defect, provided that there is reason to believe that he will be in a position to put the defect right….”_
(emphasis added)

67. She also referred to Brown v AB _[[2018] EWHC 623 (QB) as an example of another option which she](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RXX-KNW1-F0JY-C1RH-00000-00&context=1519360)_
said was open to the Master, namely to strike out the existing statement of case and to order that a
compliant statement of case be filed and served. She submitted that the Master could also have stayed the
claim pending an application to amend or made an unless order requiring a compliant statement of case to
be served with in a specified period of time. She also relied on Mark v Universal Coatings and Services Ltd

[2019] 1 WLR 2376 at [57] where Martin Spencer J held that, in the circumstances of that case, it was not
proportionate to strike out the claim for personal injury for failure to comply with [4.2] and [4.3] of Practice
Direction 16 given that these failings could be remedied by more proportionate measures such as the
making of unless orders and penalising the Claimant in costs.

**Legal framework: the scope for intervention by this court**

68. As for the scope for intervention by the High Court on appeal, the task of the appellate court is to
_“review” the decision of the first instance judge rather than to rehear the application which was determined_
below, unless a practice direction provides otherwise or it would be in the interests of justice to hold a
rehearing: see Rule 52.21(1). Although there was a suggestion in Ms Bennett's witness statement that the
Claimant would invite the court to deal with the appeal by way of a rehearing, given the lack of a transcript
of the hearing before the Master, this was not pursued by Ms Milligan who argued the appeal on the basis
that the Master had erred in law. In Cable v Liverpool Victoria Insurance Co Ltd (supra) at [74] Coulson LJ
said this:

_“When considering this aspect of the appeal, I remind myself that this court will only interfere if it considers_
_that the first instance judge has erred in principle, or if she has left out of account a feature which should_
_have been considered or taken into account a feature which should not have been considered, or failed to_
_balance various factors fairly in the scale”_

**The Defendants' position in relation to issues 2 and 3**

69. Neither Defendant filed a Respondent's Notice, seeking to uphold the Master's decision on different or
additional grounds. The Defendants' position was, in summary, that the Master had not erred in law as
alleged or at all. It was readily apparent from the Note of the hearing that the Master had recognised that a
two stage approach should be adopted. He had considered whether the relevant threshold tests for striking
out had been satisfied and had then considered whether to allow the Claimant an opportunity to amend. It
was conceded by the Claimant that the threshold under Rule 3.4(2)(c) was met. The Master was also right
to find that the Claimant's statements of case did not disclose reasonable grounds for bringing any claims
other than in respect of the arrest on 12 May 2022.

70. The only issue was therefore whether the Master was entitled in the exercise of his discretion to strike
out. The appellate court should be slow to interfere with his exercise of discretion: see Tanfern v Cameron_McDonald [2000] 1 WLR 1311 at [32]. The opportunity to cure defects in statements of case should only be_
afforded where there is reason to believe that they can be cured (see Soo Kim, above). It is apparent from
the fact that the Master had given the Claimant an opportunity to amend her statement of case in this
regard that he had considered proportionality and whether there was reason to believe that the Claimant
would be in a position to put things right. He had not erred in law in concluding that the deficiencies in the
pleading of all of her other claims could not be rectified.


-----

71. Moreover, even if it is right that, as Ms Milligan submitted, there were other claims which were capable
of being pleaded the Master made his decision on the basis of what was before him and what he was told
by the Claimant at the hearing. It would not follow from the fact, if it is a fact, that other claims have been
identified on appeal that the Master erred in law. The thrust of the appeal was to invite me to disagree with
the Master rather than to establish any error of law on his part, and I should reject that approach.

**Overall approach to this part of the appeal**

72. Grounds 2 and 3 overlap to a significant degree in that they both depend on whether there were
reasonable grounds disclosed in the APOC for bringing the claims which the Claimant now wishes to
pursue and/or it was apparent that such claims were capable of being properly pleaded. In view of the lack
of a transcript of the hearing on 28 October 2022 and the Master's reasons for his decision, I decided that I
should focus on whether it was apparent from the APOC that there were such claims. If it was I would
consider whether it was nevertheless proportionate to strike out. I kept in mind, however, the fact that I was
being asked to review the decision and that I did not have a full account of what the Claimant, as opposed
to Ms Milligan, had said to the Master by way of explanation of those claims.

73. In undertaking this task, my starting point was [53] of Ms Milligan's skeleton argument which, she said,
set out _“by way of overview only…a list of allegations that, if proven, give rise to a number of causes of_
_action against ...[the First and Third] Defendants”. In her oral submissions, Ms Milligan took me to the_
passages in the APOC where, she said, the claims were to be found and she explained the basis for those
claims further. I focus on these passages below but it should be noted that I have read them in the context
of the APOC as a whole, in which certain points are repeated, reiterated and/or expanded upon.

**The claims indicated at [53(i)] of the Claimant's skeleton argument**

74. [53(i)] of the Claimant's skeleton argument says this:

_“The First Defendant's officers negligently failed to conduct any or any adequate investigate (sic) into_
_serious crimes against the Appellant in breach of her Article 3 ECHR rights, including assault, and_
_harassment/malicious communications and that, but for its failure to investigate, the Appellant would not_
_have been arrested in March 2020 or May 2022;”_

75. Ms Milligan told me that the factual case in relation to this or these claims was firstly that had the
police investigated whether Ms Sohi had committed offences against the Claimant on 18 March 2020 this
would have prevented the events which followed. Secondly, the police had failed to investigate her
complaints of online harassment by Ms Sohi.

76. Ms Milligan said, in answer to a question from the court, that the legal case under Article 3 ECHR was
based on the line of reasoning in _Commissioner of Police of the Metropolis v DSD [2019] AC 196. This_
decision concerned the failures by the police in relation to the investigation of John Worboys, a black-cab
driver who drugged and seriously sexually assaulted multiple female passengers between 2003 and 2008.
The Supreme Court held that in cases of serious ill treatment amounting to inhumane or degrading
treatment, the positive obligation on the part of state authorities to investigate complaints arose in
circumstances where non-state agents were responsible for the infliction of the harm which is said to
amount to a breach of Article 3. Serious failures which were purely operational would suffice to establish a
claim that an investigation carried out pursuant to an Article 3 duty infringed the duty to investigate,
provided that they were egregious and significant and not merely simple errors or isolated omissions.

The passages from the APOC relied on by Ms Milligan

77. As far as the factual basis for these claims is concerned, Ms Milligan said that she relied on [30] of the
APOC. Under the heading _“…False Allegation by Ms Sohi against me to distract police again…” this_
paragraph says that on 18 March 2020 Ms Sohi attacked the Claimant when the latter took an electrician to
fix the fuse box. The Claimant took a video of the attack on her phone whereupon Ms Sohi's sister stole her
phone “in the angle of a CCTV under the control of Sohi”. There were 5 witnesses. The Claimant asked
them to call the police who attended and arrested the Claimant. At [31] she alleges that her arrest was


-----

wrongful and that she told the police that she had been robbed of her phone. She goes on to develop this
point in [32] and [33] which are amongst the paragraphs of the APOC which are no longer pursued by her.

78. At [34] of the APOC the Claimant says, under the heading “Jeopardising the investigation, abuse of
_procedure” that she asked the officer to seize and check the CCTV but they did not. She asked them to_
interview the witnesses but the officer refused without giving a clear explanation for the refusal (albeit it
appears from the APOC that the police did interview Ms Sohi and other witnesses and their accounts were
that the Claimant had assaulted Ms Sohi). Under the heading “Malicious Prosecution”, at [41] the Claimant
again complains that there was a failure to check the CCTV and [46] she says that she should not have
been charged before seizure of the CCTV. But it is not apparent that these matters are being referred to as
part of a case in negligence. The APOC does not say that they are, or begin to plead any relevant duty of
care or particulars of breach etc.

79. As far as the issue of online harassment is concerned, the factual case in the APOC is as follows:

_[“From 12 March 2020, I have reported online harassment and online activity contrary to Section 5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BB30-TWPY-Y0D6-00000-00&context=1519360)_
**_Public Order Act 1986 by Ms Sohi which was constantly over a year until I referred the matter to the_**
**_High Court of Justice for an injunction._**

_26- Over the last two years I was under constant online harassment from Ms.Sohi, calling me names such_
_as a whore, a mother fucker, and a bastard and spreading out my personal information such as my Asylum_
_ID card, my religion, my phone number, etc. Please see Annex 10 including, my Claim Form to the High_
_Court of Justice No. QB-2021-001620 and particular of the claim written with my Pro0Bono barrister, for_
_protection of Harassment. Etc. defendant's correspondence confirming those malicious content has been_
_committed whereas there was no action from police albeit my numerous reports._

**_Negligence:_**

_28- every time officers in charge have been closing the cases albeit Ms.Sohi has confessed that she is_
_doing this offence. As a result, the harassments and acts contrary to section 5 of the Public Order Act are_
_still ongoing and the officers in charge do not take action. They close the case for lack of evidence whereas_
_all of the screenshots and Sohi's confession and information downloaded from her devices is available, she_
_had never been charged for the offence.”_

80. The alleged negligence is therefore a general failure to investigate the Claimant's complaints about
online harassment although it appears from other parts of the APOC that the police did investigate and
concluded that the Claimant was at least partly to blame, as I have pointed out at [9] above.

Discussion and conclusion on this proposed claim

81. Even assuming, which I do not, that the Master received the explanation of the claims given in [53(i)]
of Ms Milligan's skeleton argument and in her oral submissions, in my view it is wholly unsurprising that he
did not hold that the APOC disclosed reasonable grounds for bringing these claims. Various causes of
action were indicated in relation to the events of 18 March 2020, most or all of which are no longer
pursued, but they did not include negligence. In relation to the allegation of negligence in failing to
investigate the Claimant's complaints of online harassment, the common law will only impose liability for
negligent omissions in limited circumstances, none of which are applicable or pleaded as being applicable
in this case: see Robinson v Chief Constable of West Yorkshire Police [2018] AC 736.

82. As far as the proposed claim under Article 3 ECHR is concerned, no such legal claim is indicated
amongst the multiple claims listed in the amended Claim Form nor, indeed, in the prayer to the APOC
which lists a number of causes of action. There is a reference to Article 3 and the DSD case in the body of
the APOC in relation to the Claimant's first complaint to the police, on 29 November 2019, about Ms Sohi
becoming aggressive. But there is no trace of such an allegation in relation to the events of 18 March 2020
or the alleged online harassment. It is therefore wholly unsurprising that the Master did not discern such a
claim. Even if there had been such a claim made or indicated in the Claimant's statements of case, the
facts alleged by her, even as further explained by Ms Milligan, do not begin to show egregious operational


-----

failings on the part of the police in their investigation of harm of a level of seriousness which would support
a claim based on DSD.

83. I deal with the allegation of assault on 18 March 2020 below. Subject to this, for all of these reasons, I
do not accept that the Claimant's statements of case disclosed reasonable grounds for bringing the claims
indicated in [53(i)] of Ms Milligan's skeleton argument, nor that the Master was wrong to decide that the
Claimant should not be given a further opportunity to plead such claims.

**The claims indicated at [53(ii)]**

84. [53(ii)] of the Claimant's skeleton argument says this:

_“The First Defendant's officers used unreasonable force in the course of arresting her in March 2020,_
_amounting to negligence, assault and battery, and a breach of her Article 8 ECHR rights, in circumstances_
_where the Appellant did not pose a physical risk to the officers and was complying with their requests;”_

The passages from the APOC relied on by Ms Milligan

85. Ms Milligan told me that the key paragraph in the APOC is [35] which says this:

_“Assault, Injury:_

_35- I draw your attention to the officers' witness statement. “I have then handcuffed Ansari in a front stock_
_position” “PC Doland and I had have to actively restrain her” “and handcuffed her again in the rear stack_
_position” “PC.Doland has then carried out a search” “Ansari has been put in the back of the van”.”_

86. Ms Milligan also relied on the fact that, later in the APOC, under the heading “Malicious Prosecution,
_Misfeasance in public office, breach of the Right of Fair Trial according to Article 6 of Human Right” (sic)_
the Claimant had said this at [68F]:

_“Regarding false statements of the officers “Officers made enquiries as to who had this however Ms Ansari_
_was distressed and incoherent and did not point out who had the phone.” Please see my upheld complaint_
_4638/20. I clearly named the offender while I was pulling and pushing by the officers.”_

87. The APOC does not identify the injury which the Claimant suffered as a result.

Discussion and conclusion in relation to this proposed claim

88. I confess to a high degree of scepticism about the likelihood that this claim will succeed, and I have
been very tempted to hold that on the evidence which I have seen, including the letter of 24 January 2022
referred to at [7] above, it is bound to fail. I was also tempted to dismiss this claim on the basis of the
principle in Jameel v Dow Jones & Co [2005] QB 946. But the Master's decision was not based on Rule
24.2 i.e. an assessment of the evidence and this is not how the case was argued before me. Nor was his
Order based on Rule 3.4(2)(b) and nor was the _Jameel principle relied on before me by the Defendants_
until I raised it in the course of the hearing. Moreover, the nature of any injury suffered by the Claimant is
currently unknown, so that there is uncertainty as to the evidential basis for a submission that the matter is
effectively de minimis. And I bear in mind that one of the questions to be determined was whether the
matter should be transferred to the County Court given its apparent low value.

89. Given that his decision was based on the APOC, and the presumption that the pleaded facts are
correct, the basis on which the Master held that the APOC did not disclose reasonable grounds for bringing
a claim of assault in the course of the arrest on 18 March 2020 is not apparent from the Note of the
hearing. Nor does the Note record why he did not consider that the Claimant should be given an
opportunity to plead it properly, e.g. by giving particulars of her case as to why the degree of force was
unreasonable and/or the (or any) injury which she sustained. I also recognise that it is not possible to
discern what, if anything, the Master was told by the Claimant about this particular claim: indeed, it may or
may not have been discussed at the hearing in the way that it was before me. However, and without any
criticism of the Master given the unfocussed way in which the Claimant's case was presented, I consider
that on balance she ought to have been given an opportunity to plead this claim properly, including her


-----

case as to what force was used, why that force was unreasonable and what injury she says she suffered
as a result of this particular aspect of her arrest.

**The claims indicated at [53(iii)]**

90. [53(iii)] of the Claimant's skeleton argument says this:

_“The First Defendant was negligent in its duties towards the Appellant as a potential victim of trafficking_
_(“PVOT”), and acted in breach of her Article 3 and 4 ECHR rights and under ECAT which resulted in her_
_homelessness following her arrest on 20 March 2020;”_

91. Ms Milligan explained at the hearing that the Claimant' case was that the police should have done
more to help the Claimant as she was a potential victim of modern slavery and, in particular, they ought to
have referred her under the National Referral Mechanism (“NRM”) for assessment as to whether she was a
victim of modern slavery. Ms Milligan was not specific about which duty under the European Convention
on Action against Trafficking in Human Beings (“ECAT”) applied and did not explain how the First
Defendant could be held to be in breach of it given that it is unincorporated international law. Nor did she
explain how a private law claim in damages could be brought against the police under ECAT itself. She
said that she relied on Article 4 ECHR as the basis for this part of the claim indicated in [53(iii)].

The passages from the APOC relied on by Ms Milligan relied

92. Ms Milligan relied on [50]-[52] of the APOC where the following appears in passages which relate to 19
March 2020 and the aftermath of her arrest on 18 March 2020:

_“Negligence:_

_50- In the interview, I have mentioned that I have been relocated here by Sohi to work for her, but she does_
_not pay me. Again, the officers did not recognise that I am a victim of modern slavery, and they did not_
_make a referral to the NRM._

**_On 19 March 2020, CAD 6034_**

**_Compensation for injury and negligence,_**

_51- When I was released from custody, I went back to my accommodation, and I understood that Sohi had_
_abused the situation and changed the lock of the door and locked me out. I called to police asking support_
_for getting back to my place. But once police arrived they again asked me about my immigration situation_
_whereas that was clear for them. They also remind me the bail._

_52- finally disappointed from any help by police, I became homeless for two days mostly in Colindale Police_
_Station asking for help. During this time, I got infected by the Covid-19 which I am still suffering from the_
_long-term effects. Please see Annex 14 of the medical record”_

93. The Claimant also says in the APOC that at other points she explained to the police, for example, that
she “transferred here for work and do not receive any payment which is a description of the Modern Days
Slavery Offence” (see [12] which refers to the Claimant's complaint to the police on 29 November 2019).
She does not say that she herself believed that she was a victim of modern slavery at the relevant time,
nor that she told the police this in terms. I was told that she was referred to the NRM in October 2020 and
the Claimant appears to plead at [22] that it was subsequently accepted that there were reasonable
grounds to believe that she was a victim of modern slavery and she was provided with support, although
the nature of the support is not specified. But, in answer to a question from me, Ms Milligan also said that it
had been determined at the conclusive grounds stage that the Claimant was not in fact a victim of modern
**_slavery. It was not clear when this decision was made, nor why this information had not been put before_**
the court before I asked.

Discussion and conclusion on this proposed claim

94. I have already noted that no claim under Article 3 ECHR was indicated in the amended Claim Form
and nor was any in this connection indicated in the APOC. The reference to Article 3 and the DSD case


-----

relates to 29 November 2019, in respect of which no claim is pursued, whether in relation to inhumane and
degrading treatment or **_modern slavery. The same is true of Article 4 ECHR (“No one shall be held in_**
slavery or servitude” etc) and ECAT. They are not referred to at all in the Claimant's statements of case
before the Master.

95. Ms Milligan submitted that “the Master should have seen the threads of a claim” under these
provisions and, in effect, sent the Claimant off to take advice and to plead these claims. I do not agree. It
was not his function to attempt to weave a case for the Claimant from the disparate and incomplete
information and complaints presented by her, nor to suggest claims which she had not brought but might
be able to if the facts were right. Whilst it was appropriate for him to give a degree of latitude to the
Claimant, it was also important for him to be fair to the Defendants and to ensure that their, and the court's,
time and resources were not wasted.

96.  In my view the Master cannot be criticised for not taking the view that the APOC disclosed reasonable
grounds for bringing the claims indicated in [53(iii)] and/or that the Claimant should be given an opportunity
to plead them. The claim that there was breach of these provisions also seems particularly unrealistic when
it is considered that, as emerged for the first time during the hearing before me, the Claimant was not in
fact a victim of modern slavery.

97. As for negligence, no duty of care was pleaded in the APOC and Ms Milligan did not explain how one
arose. In any event, in my view the APOC does not allege that the Claimant told the police enough as at
March 2020 for them to be expected to think that she may be a victim of modern slavery and to refer her
to the NRM. The “Background” section of the APOC does not suggest that she was brought to this country
in October 2018 by anyone else. It says that when she made her claim for asylum, five months after she
had arrived here, she was living with a retired couple. She was then looking for a job and one was offered
to her by Ms Sohi and she moved into a flat belonging to Ms Sohi. On the face of the APOC she presents
and presented as a qualified lawyer who told the police she had not been paid her wages by her employer
and had been locked out of her flat after a physical altercation with her landlady.

98. For all of these reasons I do not accept that the Master was wrong to strike out the claims indicated in

[53(iii)] of Ms Milligan's skeleton argument (insofar as they were made in the APOC) and/or not to give her
an opportunity to plead them or improve her pleading of them.

**The claims indicated in [53(vi)]**

99. [53(vi)] of the Claimant's skeleton argument says this:

_“The Third Defendant's officers used unreasonable force in the course of her arrest on 2 September 2022_
_amounting to negligence, assault and battery, and a breach of her Article 8 ECHR rights, in circumstances_
_where the Appellant did not pose a physical risk to the officers and was complying with their requests;”_

100. Ms Milligan told me that in fact the Claimant was alleging 2 assaults. The first was during her arrest
on 1 September 2021 and was pleaded as follows:

_“Assault, Personal injury,_

_90- During the time of the arrest. I got an injury on my hands, which I reported to the doctor in custody I_
_have been pushed out of my flat and into the police car, in custody for fingerprint, etc. I asked for fresh air_
_many times, but they declined.”_

101. Ms Milligan said she had no instructions as to the nature of the injury to the Claimant's hand.

102. The second assault is alleged to have occurred in the course of the Claimant's arrest on 12 May 2022
and is pleaded as follows:

_“Trespass to land._

_108- five Officers had trespassed into my flat and assaulted me and took me out handcuffed._

**_Trespass to good._**


-----

_109- again the officers took my phone using force and aggression._

_“Breach of Article 9 of Human Rights, freedom of religion_

_110- I have been taken out half naked which contrasts with my religion and belief. I asked the police to let_
_me put my clothes on and let me take some money or bank account with me, but they pull me and pushed_
_me out regardless. The officer constantly was shouting and stopped my support worker that was trying to_
_help me to cover my body.”_

103. Again, I have very real doubts as to whether either of these claims will succeed but, for essentially
the same reasons as apply to the claims indicated in [53(ii)] (see [89], above), and again without any
criticism of the Master given the way in which the statements of case were drafted, I consider that on
balance the Claimant ought to have been given an opportunity to plead these claims properly. The
allegation of assault was made at [90] of the APOC in relation to the arrest of 1 September 2021, including
that it resulted in injury. The headings in relation to 12 May 2022 were distracting but the allegation of
assault was made and, more generally, there were other allegations about the Claimant's treatment on 12
May 2022 which, if true, were concerning and capable of providing the basis for a cause of action (see the
next section of this judgment).

**The claims indicated in [53(vii)] of the Claimant's skeleton argument**

104. [53(vii)] of the Claimant's skeleton argument says this:

_“The Third Defendant's officers removed the Appellant's clothes in circumstances where that was not_
_required nor necessary, and causing the Appellant to be unnecessarily exposed to a number of other_
_officers in a vulnerable state. This was a violation of her privacy and/or negligent, breach of her Article 8_
_ECHR rights and amounted to assault and battery;”_

105. Ms Milligan said that this refers to [110] of the APOC (see [102] above) and [111] which reads as
follows:

**_Sexual assault in custody_**

_111- Sexual Assault; In custody, I was forced to take out all my clothes in front of 6 officers including_
_males. The Officer threatened me that if I don't take off my underwear including bra and panties, they will_
_take it off using force. I had an experience of rape about 15 years ago, this incident has escalated my pre-_
_existing medical conditions. Please see annex 29.”_

106. As Freedman J's Order makes clear, the Claimant is not pursuing the allegation that she was
_sexually assaulted._

107. I note that the witness statement of Mr Daniel Rutherford dated 26 June 2024, which was submitted
on behalf of the Third Defendant in response to the Claimant's application dated 17 June 2024, contests
aspects of the factual basis for this claim. However, in my view it is too late for him to do so. This evidence
does not arise out of the Claimant's application and seems to have been produced as a response to points
put to Mr Reader by me during the course of the hearing. It should have been put before the Master or, at
the very least, been produced in good time before the appeal hearing if it was to be relied on. The Claimant
has not had an opportunity to respond to it and, in any event, this claim was struck out rather than
dismissed under Rule 24.2. As noted above, the Master's decision was therefore based on the pleaded
case rather than an evaluation of the evidence, or a determination of disputed evidence, and the appeal
has been conducted on that basis. It would not be right for me to dismiss the appeal on this new ground,
raised after the hearing, no Respondent's Notice having been filed.

108. On balance, and essentially for the reason given above in relation to the claims indicated by [53(ii)]
(see [89] above) I consider that the Claimant ought to have been given an opportunity properly to plead the
claim indicated in [53(vii)]. The claim is apparent on the face of the APOC. It may or may not succeed on
the evidence but that is not a question which the Master decided or which I am able to decide at this stage.

**The claims indicated by [53(viii)]**


-----

109. [53(viii)] of the Claimant's skeleton argument says this:

_“The Third Defendant's officers were negligent in its duties towards the Appellant as PVOT and acted in_
_breach of her Article 3 and 4 ECHR rights and ECAT, which resulted in her homelessness following her_
_arrest;”_

110. Ms Milligan said that this referred to the following paragraphs of the APOC:

_“Trespass to land and harassment_

_113- On 26 May 2022 while luckily, I was not home in Brighton, a few officers trespassed into my flat and_
_attempted another arrest, causing a huge amount of anxiety and distress during the day and days after._

_114- Since then I had been homeless as I did not go back home, concerning my safety from the police._

_116- I have not been provided with fresh air at custody and I was left without enough clothes and any_
_money in Northwest London knowing that I live in Brighton.”_

111. Ms Milligan said that the Claimant was too afraid to return to her flat in Brighton and was therefore
effectively homeless although she could not say whether this meant street homeless (as opposed to the
Claimant staying with friends or family), or for how long this was.

112. I reject the appeal in respect of the claims proposed in [53(viii)] for the reasons which applied to

[53(iii)] (see [94]-[98] above). Indeed, they are even weaker than the equivalent proposed claims against
the First Defendant. There is no plea in this part of the APOC, which relates to events more than two years
after the Claimant told the First Defendant that she had not been paid wages which she was owed, that the
Claimant told officers of the Third Defendant that she was potentially a victim of **_modern slavery or_**
anything that would indicate to them that this was the case, or that she was afraid to go home or was
otherwise homeless. Nor is there any suggestion in the APOC that these matters amounted to negligence
on the part of the Third Defendant and nor is it possible to see how there could be on the basis of the
factual case alleged.

**The claims indicated by [53(ix) and (x)] of the Claimant's skeleton argument**

113. [53(ix) and (x)] of the Claimant's skeleton argument say this:

_“ix. The Third Defendant's officers retained the Appellant's personal communication devices for_
_approximately four months following their download of data from the devices. This was without lawful_
_[foundation in light of requirement of s.53 of the Criminal Justice and Police Act 2001 (“CJPA 2001”) read](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y189-00000-00&context=1519360)_
_with s.22 of the Police and Crime Evidence Act 1984 (“PACE”). Under those provisions, the Third_
_Defendant was required to (i) conduct an initial examination as soon as possible, (ii) to only retain property_
_for so long as is necessary in all the circumstances and (iii) return severable property (e.g. physical devices_
_versus digital data) as soon as reasonable practicable after the examination. Its failure to do so amounted_
_to a breach of the Appellant's Article 8 ECHR rights and/or negligence._

_x. The First Defendant's officers, employees and/or agents retained the Appellant's personal_
_communication devices for circa four months following the transfer from the Third Defendant. As the Third_
_Defendant had downloaded the data from the devices for the purpose of investigating the offences alleged_
_to have been committed by the Appellant, the First Defendant's prolonged retention of the Appellant's_
_[personal devices without lawful foundation in light of the requirements of s.53 CJPA 2001 read with s.22](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y189-00000-00&context=1519360)_
_PACE (see above). These actions also amounted to a breach of the Appellant's Article 8 ECHR rights_
_and/or negligence._

114. Ms Milligan explained that the complaint was that failure to return the devices meant that the
Claimant had no means of communicating with friends and family and was unable to pursue her studies.
This engaged Article 8. It was not that the Defendant's examination of the Claimant's personal data was
intrusive and unnecessary, nor for the loss of the devices given that they had been returned.

115. She referred to [87]-[88] of the APOC where the following is pleaded in relation to the day after the
arrest on 1 September 2021:


-----

_“Trespass to land:_

_87- On 2[nd] September 2021, two female officers trespassed into my accommodation in Brighton._

**_Trespass to goods, wrongful imposition of my 3 devices including an iPhone 12 Pro mack worth_**
**_£1,400 and a Samsung tablet worth £900 and a phone worth £200:_**

_88- They have sized three of my devices and they did not return. I received back my devices on 10_
_September 2022 from Metropolis. I understood albeit the information of my devices was fully downloaded_
_and examined in January 2022, Sussex Police refrained to return them without a lawful ground. The OIC_
_was informed by my psychologist that I am suffering from serious mental health problems as I was_
_disconnected from my family and friend and that was not any answer regarding the date that I can receive_
_back my devices.”_

116. Ms Milligan also referred to [100]-[101]:

_“100- The OIC is aware that I am on the Qualified Lawyer Transfer Scheme online course, and I am losing_
_my course as well as my mental health due to seizure of my devices, but she is regardless of the damage_
_that she is causing. Considering I did not deny any information on my phone, there is no point to keep my_
_devices._

_101- As a result I flailed my final exam and was unemployed for over a year as my study material was_
_taken away from me. At least they could have told me the approximate time that I will be receiving them_
_back, so I would buy another one to continue studying.”_

117. Again, I accept that the APOC is less than clear and am sceptical about whether this claim will
ultimately succeed on the evidence and/or has any significant value. A particular difficulty which I raised at
the hearing was that it appeared that the Claimant was saying in [101] that she was in a position to buy a
replacement phone. It would be surprising if she did not do so. But it does seem to me that the APOC
reveals a complaint about the fact that the Claimant's devices were retained for as long as they were given
that the police downloaded, or could have downloaded, the information on them. The alleged
consequences of this are also set out in the APOC. The Master did not determine whether the claims
would succeed on the evidence and nor am I in a position to do so. On balance I consider that the
Claimant ought to have been given an opportunity to plead this claim properly.

**ISSUE 4: THE CLAIMANT'S APPLICATION DATED 17 JUNE 2024**

118. As I read it, the Claimant's application of 17 June 2024 (“the Application”) was to be permitted, in the
context of the appeal succeeding, to file and serve reformulated pleadings which include claims for
wrongful arrest against the First and Third Defendants on 12 May 2022 in addition to the claims indicated
at [53] of Ms Milligan's skeleton argument. There is no application to amend the Notice of Appeal.

119. The basis for the proposed claims would be that there were no reasonable grounds to suspect that
the Claimant had been stalking Ms Sohi or had committed any offence and/or that the officers of the Third
Defendant who arrested her (said to be PS Bell and others) did not themselves have reasonable grounds
to suspect that the Claimant was guilty of doing so. The Application states that the Claimant's legal
representatives had overlooked the reasons why the Master held that this claim was properly brought
against the First Defendant if it was brought at all, that Ms Milligan's clear and repeated statements at the
hearing before me that the Claimant was not pursuing any claim for wrongful arrest were in error, and that
there would be no prejudice to the First and Third Defendants if claims against them both in respect of the
12 May 2022 arrest could now be brought.

120. I refuse the Application.

121. The procedural position in relation to the First and the Third Defendants is slightly different. In the
case of the First Defendant, the proposed claim was not struck out by the Master's Order, as I have said.
The Claimant was given an opportunity to plead it within 14 days but did not do so. The real problem is that
the Claimant did not avail herself of this opportunity, and what was effectively an unless order took its


-----

course. The correct procedural approach if she wishes to pursue this claim is to apply to the Master for
relief against sanctions and an extension of time to file a compliant statement of case.

122. The Notice of Appeal does not challenge the Master's decision in respect of the potential claim
against the First Defendant based on the 12 May 2022 arrest. Nor, as I have noted, was there any
suggestion at the permission stage or in Ms Milligan's skeleton argument, or in her oral submissions, that
she wished to challenge it. On the contrary, it was made clear by her written arguments, and confirmed by
her orally, that she was not challenging it.

123. In relation to the Third Defendant, the Notice of Appeal did challenge the striking out of the wrongful
arrest claim, although the basis for the challenge did not include the contention that the arrest was unlawful
because the officers of the Third Defendant acted on the request of the First Defendant rather than forming
their own view as to whether there were grounds to suspect the Claimant. Thereafter, the procedural
position is the same as in relation to the First Claimant i.e. that Ms Milligan consistently made clear that no
claim for wrongful arrest was pursued against any of the Defendants on the basis of any of the arrests of
the Claimant referred to in the APOC.

124. The true position in relation to the Application is therefore that the Claimant requires permission to
amend her Notice of Appeal if she is to challenge the Master's Order in respect of the proposed claim
against the First Defendant. That does not appear to be applied for but I will treat the application as such.
She requires permission to appeal in relation to the proposed claim against both Defendants and she
wishes to resile from her previous position that no such claim was pursued and to develop arguments
which did not feature in the appeal proceedings until, at best, her reply.

125. The “hook” on which the Application is based is that it was not appreciated that the Third Defendant's
officers had arrested the Claimant at the request of the First Defendant. On this basis, and as a result of
the digital information held by the Third Defendant it is inferred or suggested by the Claimant that the
officers of the Third Defendant did not themselves have reasonable grounds to suspect that she was guilty
of stalking and therefore had no grounds to arrest her. However, the Note of the hearing, which was in its
final form on 23 June 2023, and was provided to the Claimant in draft before this for her comment, clearly
shows that initially the Master considered that there may be a claim against both Defendants in respect of
the 12 May 2022 arrest which was capable of being pleaded but, at [19], he held that as the arrest by the
Third Defendant was at the request of the First Defendant the only allegation of wrongful arrest which could
succeed was against the First Defendant. That was then reflected in the Master's Order. The Note was
clearly available to Ms Milligan at the permission stage and to her instructing solicitors when they were
instructed.

126. Given that, based on cost schedules which have been served on the Defendants, Ms Milligan
apparently carried out 55 hours of work when she was instructed pro bono in August 2023, and
approximately £38,000 of legal aid fees have been incurred by the Claimant's legal representatives in the
appeal proceedings, the suggestion that they overlooked [19] of the 4 page Note of the hearing is
surprising. But, be that as it may, the fact is that nothing new was revealed in the course of the hearing
before me and there is nothing to warrant the raising of this issue at such a late stage.

127. I do not accept the Claimant's argument that there would be no prejudice to the Defendants if her
application were allowed. Contrary to her assertions, the First Defendant has been entitled to proceed,
since 14 days after the Master's Order, on the basis that the wrongful arrest claim against him was not
pursued. There was also no issue in relation to this aspect of the Master's Order in the appeal. That has
been confirmed by the position adopted by Ms Milligan and her instructing solicitors since their involvement
in the appeal. The First Defendant's litigation decisions throughout the appeal have no doubt been taken
on this basis. No steps were taken to prepare materials and arguments in relation to this issue. Similarly,
since the permission hearing (at which all three Defendants were represented by Counsel) the Third
Defendant has been entitled to proceed on the basis that this aspect of the Master's Order was not
challenged, and to take litigation decisions and prepare accordingly.

128. It is clear that the Claimant could have raised the issues in her 17 June 2024 Application as part of
the appeal and long before Ms Milligan's reply She has had every opportunity to do so given that the


-----

appeal proceedings have been ongoing for the best part of 18 months. I acknowledge that there may be
prejudice to the Claimant in refusing to permit her to do so but it should be noted that the factual basis for
her now wishing to claim against the Third Defendant i.e. that her officers did not themselves form any view
about whether there were reasonable grounds to arrest the Claimant and/or did not have such grounds,
was not pleaded in the APOC. Nor has it been fully explored, for reasons which are obvious. However, it
appears from the witness statement of Mr Daniel Rutherford in response to the Application that the
Claimant is mistaken as to the identity of the officer who arrested her. In fact it was PC Mongan. Moreover,
his statement on the day of the arrest says that he did familiarise himself with the “arrest circumstances,
necessity and items to be seized”. It is therefore very far from clear that the Master's decision to strike out
the claim for wrongful arrest against the Third Defendant was wrong and/or that the proposed claim is
sound or could be properly pleaded in any event.

129.  On the other hand there is, in my view, considerable prejudice to the Defendants in allowing new
arguments/grounds to be raised effectively after the appeal hearing. A considerable degree of procedural
latitude has already been afforded to the Claimant and substantial costs have been incurred. I am
conscious of the fact that other claims in relation to 12 May 2022 may in due course proceed, and that it
could be said that therefore it does not matter if a claim for wrongful arrest is added, but these claims
engage different evidential considerations.

130. In my judgment is it not in accordance with the overriding objective to allow the Application. It will
have been noted that I have applied essentially the same approach to Mr Rutherford's attempts to put in
evidence about the alleged strip search on 12 May 2022: see [107] above.

**Conclusion**

131. The appeal is therefore allowed to the extent that the Claimant will be given an opportunity to plead
the claims indicated at [53](ii), (vi), (vii), (ix) and (x) of Ms Milligan's skeleton argument in accordance with
this judgment. It goes without saying that the revised pleading will be required to comply with the CPR but,
for the avoidance of doubt, it should also include particulars of any personal injury which the Claimant
alleges she suffered as a consequence of the matters complained of, a medical report insofar as she
intends to rely on medical evidence, and a schedule of loss.

132. I will invite agreement or submissions as to the terms of the Order which I should make but my
provisional indications are as follows:

i) The amended case should be pleaded by way of a re-amended Claim Form and substituted ReAmended Particulars of Claim.

ii) Bearing in mind the time of year, the Claimant should be given a generous period of time to do this (6-8
weeks) on the express basis that she will correspond with the Defendants about the relevant claims with a
view to narrowing the issues, making an informed and realistic assessment of her prospects of success
and, insofar as any claim is pursued, being able to focus her pleaded case.

iii) The matter should be transferred to the County Court.

133. The parties are also invited to reach agreement or make submissions as to whether the Order should
be, for example, an unless order or an order that the claims are stayed until such time as a compliant
statement of case is served, or some other order which ensures that the claims will only proceed if they are
properly pleaded. The opportunity to re-plead is without prejudice to the Defendants' right to argue that the
revised pleading is not compliant and/or is bound to fail and/or should be summarily dismissed pursuant to
Part 24.2, but my provisional view is that the determination of such issues would be for the County Court.

134. The parties should also make agree or make submissions on any other consequentials including
costs.

**End of Document**


-----

