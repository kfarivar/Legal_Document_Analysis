# A and another v Criminal Injuries Compensation Authority and another

 [2018] EWCA Civ 1534

Court of Appeal, Civil Division

Gross, Sharp and Flaux LJJ

3 July 2018Judgment

**Martin Chamberlain QC and Ms Shu Shin Luh (instructed by Leigh Day) for the Appellants**

**Ben Collins QC and Mr Robert Moretto** (instructed by Philippa Long) for the Government Legal
Department

Hearing date: 6 March 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**LORD JUSTICE GROSS :**

INTRODUCTION

1. The Appellants (A and B) appeal against the judgment of Wilkie J, dated 12th January, 2017 (“the
judgment”), dismissing their claims for Judicial Review challenging the lawfulness of the Criminal Injuries
Compensation Scheme in its 2012 iteration (“the Scheme”), insofar as it concerns applicants for
compensation who have unspent criminal convictions which resulted in a custodial sentence or community
order.

2. The Appellants accept that the refusal by the Criminal Injuries Compensation Authority (“CICA”) to
award compensation was in accordance with the terms of the Scheme but contend that the relevant
provisions of the Scheme are unlawful.

3. It is convenient to set out at once the provisions of the Scheme which are central to the present appeal:

“Grounds for withholding or reducing an award

……

26. Annex D sets out the circumstances in which an award under this Scheme will be withheld or reduced
because the applicant to whom an award would otherwise be made has unspent convictions.

**Annex D: Previous convictions**

2. Paragraphs 3 to 6 do not apply to a spent conviction……

3. An award will not be made to an applicant who on the date of their application has a conviction for an
offence which resulted in:

(b) a custodial sentence;

(e) a community order;


-----

(g) a sentence equivalent to a sentence under sub-paragraphs (a) to (f) imposed under the law of Northern
Ireland or a member state of the European Union, or such a sentence properly imposed in a country
outside the European Union.

4. An award will be withheld or reduced where, on the date of their application, the applicant has a
conviction for an offence in respect of which a sentence other than a sentence specified in paragraph 3
was imposed unless there are exceptional reasons not to withhold or reduce it.

5. Paragraph 4 does not apply to a conviction for which the only penalty imposed was one or more of an
endorsement, penalty points or a fine under Schedule 2 to the Road Traffic Offenders Act 1988.

6. Paragraphs 3 and 4 do not apply in relation to a sentence under the law of a country outside the United
Kingdom for conduct which on the date of conviction did not constitute a criminal offence under the law of
any part of the United Kingdom.”

4. Before the Judge, the Appellants' claims were heard together with a joined claim by a Mr McNiece (“the
McNiece claim”). The McNiece claim likewise failed and it has not been pursued on appeal.

5.  A number of themes loom large when dealing with this appeal. The background to the particular
challenge is the modern scourge of human trafficking, unquestionably a grave evil and rightly now
combated, internationally and domestically, in a variety of ways. Inevitably, there is and must be sympathy
for those trafficked. But that sympathy is at best an uncertain guide to the determination of these
proceedings because combating trafficking and assisting those trafficked are not the only matters to be
taken into account.  The challenge before us also gives rise to issues going to the allocation of scarce
taxpayer funding by way of a gesture of public solidarity for victims of crime. In considering a challenge to
the Scheme it is therefore necessary to keep well in mind the distinct roles of the Legislature, Executive
and Judiciary. Plainly, there is scope for different views as to the limits of and the exclusions from such a
Scheme but the Court's task is confined to whether the Appellants' challenge to the lawfulness of the
Scheme - approved as it has been by both Parliament and the Executive - is entitled to succeed.

FACTS AND BACKGROUND

6. The underlying facts are not in dispute and I gratefully adopt the Judge's summary, at [7] and following
in the judgment.

7. The Appellants are twin brothers and Lithuanian nationals, born on the [a date in] 1986. To the extent
that it is relevant, after a very difficult childhood, they were placed in care.

8. A was convicted in Lithuania of burglary on the 6th June, 2010 and was sentenced to 3 years'
imprisonment. B was convicted in Lithuania of theft on the 11th December, 2011 and was sentenced to 11
months' imprisonment.

9. Under the _[Rehabilitation of Offenders Act 1974 (as amended), in A's case the sentence does not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
become spent until the 6th June, 2020. In B's case, the conviction became spent on the 11th November,
2016.

10. In 2013, thus a considerable time after their convictions, the Appellants were trafficked from Lithuania
to the United Kingdom and, as expressed by the Judge:

“….subjected to labour exploitation and abuse. Their experiences between the dates of the 1st June and
the 30th October 2013 constituted criminal offences for which, on the 22nd January 20016, the traffickers
responsible were convicted receiving custodial sentences of 3 ½ years. Slavery and trafficking prevention
[orders were made under the Modern Slavery Act 2015.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

11. Interposing here, the Appellants' status as victims of **_modern slavery and trafficking is common_**
ground and was confirmed by decisions of a branch of the National Crime Agency (“NCA”) on the 25th and
26th November, 2013.

12. The Appellants applied to the CICA for compensation under the Scheme on the 16th June, 2016.


-----

13. It follows that, at the time of their application, each Appellant had an unspent conviction which resulted
in a custodial sentence.

14. On the 7th July, 2016, the CICA Claims Officer wrote to each of the Appellants, refusing to make an
award of compensation for their criminal injuries, in the following terms:

“ I am sorry to tell you that I have decided not to make any award because, under paragraph 26 of the
Scheme, Annex D sets out the circumstances in which an award under this Scheme will be withheld or
reduced because the applicant, to whom an award would otherwise be made, has unspent convictions.”

For completeness, as the Respondents correctly point out, the 7th July letter did not go beyond declining to
make an award by reason of para. 26 and Annex D of the Scheme. The letter said, in terms, that the CICA
had not made any decision in relation to any other paragraphs of the Scheme.

15. Neither Appellant launched a review or an appeal under the Scheme on the basis that as the terms of
the Scheme had been properly applied any such application would inevitably fail.

16. Before the Judge, the Appellants contended that the provisions of the Scheme precluding an award of
compensation to those with unspent convictions resulting in a custodial or community offence were
unlawful on the following grounds:

i) They constituted a disproportionate interference in the Appellants' rights under _Article 1 of Protocol 1_
(“A1P1”) to the European Convention on Human Rights (“ECHR”).

ii) They were unjustifiably discriminatory contrary to A1P1 read together with Art. 14 of the ECHR.

iii) They were in breach of Art. 17 of Directive 2011/36/EU of the European Parliament and of the Council
_of 5 April 2011 on preventing and combating trafficking in human beings and protecting its victims (“the_
Directive”).

iv) They were in breach of A1P1 read together with Art. 4 of the ECHR.

17. The Judge rejected all four grounds but granted the Appellants permission to appeal. On the appeal,
the Appellants do not pursue grounds i), ii) and iv).  Instead they do pursue ground iii), together with an
additional ground – to which the Respondents do not object.

18. There are, accordingly, two grounds of appeal before this Court:

i) Whether the terms of the Scheme amount to a breach of Art. 17 of the Directive?  (“Ground I: Art. 17 of
the Directive”);

ii) Whether the terms of the Scheme fall within the ambit of Art. 4 ECHR and amount to unjustified
discrimination against the Appellants (on the ground of their “other status” of having unspent convictions for
offences which resulted in a custodial or community sentence) contrary to Art. 14 ECHR, read with Art. 4?
(“Ground II: Discrimination”).

I turn directly to these Grounds.

GROUND I: ART. 17 OF THE DIRECTIVE

19. (1) The legal framework: The _[Criminal Injuries Compensation Act 1995](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61G0-TWPY-Y0WD-00000-00&context=1519360)_ (“the 1995 Act”) provides by
s.1(1) that the Secretary of State shall make arrangements “for the payment of compensation to, or in
respect of, persons who have sustained” criminal injuries. Any such arrangements (s.1(2)) “shall include
the making of a scheme” providing, in particular, for the circumstances in which awards may be made and
the categories of person to whom awards may be made. By s.3(1):

“ The Scheme may, in particular, include provision –

(a) as to the circumstances in which an award may be withheld or the amount of compensation reduced;”

20. S.11 of the 1995 Act provides that, as happened in the case of the Scheme, the Secretary of State
shall lay a draft of it before Parliament and the Secretary of State “…shall not make the Scheme unless the
draft has been approved by a resolution of each House” Para 1 of the Scheme indeed so records


-----

21. For present purposes, key provisions of _the Scheme have already been set out. Certain other_
provisions must now be referred to. Para. 4 provides that a person may be eligible for an award under the
Scheme “…if they sustain a criminal injury which is directly attributable to their being a direct victim of a
crime of violence….”.

22. Paras. 10 and following of the Scheme address, _inter alia, the position of victims of trafficking,_
essentially by broadening the eligibility criteria.  Thus, whereas the basic provisions are that a person is
only eligible for an award under the Scheme if ordinarily resident in the United Kingdom (para. 10(a)) or
satisfies citizenship or related requirements (paras. 10(b) and 11), para. 10(c) extends eligibility to a person
in respect of whom “one of the conditions in paragraph 13 is satisfied….on the date of their application
under this Scheme”. In turn, the condition in para. 13(a) is satisfied if the person in question has “been
referred to a competent authority as a potential victim of trafficking in human beings”. Para. 14 permits a
person who has made an application under the Scheme and satisfies a condition in para. 13 to request that
their application is deferred until a final decision is taken in respect of their status as a victim of trafficking.
Insofar as relevant, paras. 15 and 16 provide as follows:

“ 15. Where a person is eligible for an award under this Scheme by virtue of paragraph 10 only because a
condition in paragraph 13 is satisfied….that person will not be eligible for an award unless….they have
been:

(a) conclusively identified by a competent authority as a victim of trafficking in human beings;

…..

16. In paragraphs 13 and 15:

(a) a person is conclusively identified as a victim of trafficking in human beings when, on completion of the
identification process required by Article 10 of the Council of Europe Convention against Trafficking in
Human Beings…, a competent authority concludes that the person is such a victim;

(b) 'competent authority' means a person who is a competent authority of the United Kingdom for the
purpose of that Convention; and

(c) 'victim of trafficking in human beings' has the same meaning as under that Convention.”

23. Paras. 22 and following set out the grounds for withholding or reducing an award under the Scheme.
Aside from para. 26, already referred to, these grounds include a failure to cooperate as far as reasonably
practicable in bringing the assailant to justice (para. 23), the conduct of the applicant before, during or after
the incident giving rise to the criminal injury (para. 25) and the applicant's character other than in relation to
an unspent conviction referred to in paras. 3 or 4 of Annex D (para. 27).

24. We were taken to a variety of European instruments and materials. I begin with the Council of Europe
_Convention on Action against Trafficking in Human Beings, of 2005 (“ECAT”), which entered into force in_
respect of the United Kingdom on 1 April 2009.

25. Though much of ECAT is of general interest, it is only necessary to set out the provisions of Arts. 15
and 26. Art. 15 deals with “Compensation and legal redress” and provides as follows:

“ ……

3. Each Party shall provide, in its internal law, for the right of victims to compensation from the
perpetrators.

4. Each party shall adopt such legislative or other measures as may be necessary to guarantee
compensation for victims in accordance with the conditions under its internal law, for instance through the
establishment of a fund for victim compensation or measures or programmes aimed at social assistance
and social integration of victims, which could be funded by the assets resulting from the application of
measures provided in Article 23.”

(Art. 23 relates to sanctions and measures to ensure that criminal offences are punished.)


-----

26. The Explanatory Report accompanying ECAT contains the following paragraphs of relevance of Arts.
15.3 and 15.4 of ECAT:

“197. Paragraph 3 [i.e., 15.3] establishes a right of victims to compensation. The compensation is
pecuniary…. For the purposes of this paragraph, victims' right to compensation consists in a claim against
the perpetrators of the trafficking – it is the traffickers who bear the burden of compensating the
victims……..

198. However, even though it is the trafficker who is liable to compensate the victim….in practice there is
rarely full compensation whether because the trafficker has not been found, has disappeared or has
declared himself bankrupt. Paragraph 4 therefore requires that Parties take steps to guarantee
compensation of victims. The means of guaranteeing compensation are left to the Parties, which are
responsible for establishing the legal basis of compensation, the administrative framework and the
operational arrangements for compensation schemes. In this connection, paragraph 4 [i.e., 15.4] suggests
setting up a compensation fund or introducing measures or programmes for social assistance to and social
integration of victims that could be funded by assets of criminal origin.”

27. Art. 26 is headed “Non-punishment provision”. It is in these terms:

“ Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
been compelled to do so.”

28. The Directive, which builds upon ECAT and adopts the same approach, begins with Recital (1),
recording, inter alia, that human trafficking is a serious crime, a gross violation of fundamental rights and
that combating trafficking is a priority for the European Union and Member States. Recital (7) notes that the
Directive adopts “an integrated, holistic and human rights approach” to the fight against human trafficking.
Recital (18) underlines that it is necessary for victims of human trafficking to be able to exercise their rights
“effectively”. Therefore:

“…assistance and support should be available to them before, during and for an appropriate time after
criminal proceedings. Member States should provide for resources to support victim assistance, support
and protection…..”

Recital (19) urges the provision of legal counselling and representation, for the purpose of claiming
compensation, including from the State.

29. The Articles of the Directive reflect these Recitals, though it is only necessary to refer to a very few.
Art. 8 is headed “Non-prosecution or non-application of penalties to the victim” and is in these terms:

“Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties
on victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2

[i.e., trafficking offences].”

30. Art. 12 is headed “Protection of victims of trafficking in human beings in criminal investigations and
proceedings” and includes a provision (at Art. 12.2) that victims of trafficking should have access to legal
counselling “including for the purpose of claiming compensation”.

31. Art. 17 provides as follows:

“ Compensation to victims

Member States shall ensure that victims of trafficking in human beings have access to existing schemes of
compensation to victims of violent crimes of intent.”

32. Putting to one side for the moment any questions as to its status in law, the Communication from the
Commission to the European Parliament, the Council, the European Economic and Social Committee and


-----

the Committee of the Regions, entitled “The EU Strategy towards the Eradication of Trafficking in Human
_Beings 2012-2016” (“the Strategy document”), dated 19th June, 2012, includes (at para. 2.1) the following:_

“It is crucial to identify potential victims, so that anyone who has dealings with a victim of human trafficking
can best attend to the 'five broad needs of victims', respect and recognition, assistance, protection, access
to justice and compensation.”

33. The strategy document frames the European Union's priorities under the Directive within the
fundamental rights framework prohibiting slavery and human trafficking, provided by the _Charter of_
_Fundamental Rights of the European Union_ (“the CFR”) (Art. 5.3), ECAT and the ECHR (Art. 4, set out
below).

34. _(2) The judgment (under appeal):_ As to Ground I (ground iii) before the Judge), the Appellants'
submission was (and is) that the mandatory exclusion of a victim of trafficking with an unspent relevant
criminal conviction is incompatible with Art. 17 of the Directive because it imposes an impermissible
obstacle to “access to” the Scheme for victims of trafficking (such as the Appellants).

35. The Judge rejected the Appellants' submission. As he expressed it:

“129. ….there is nothing in the terms of the Directive whether the preamble or the Articles which suggests
that all victims of trafficking must receive awards of compensation under national schemes made, or
altered, for the purpose regardless of their circumstances and regardless of the terms of national schemes
which are lawful under national law.

130. .....there is nothing in Article 17 which does more than require the UK to secure for victims of
trafficking access to the existing Scheme with all of its rules and exclusions. In my judgment it does so by,
amongst other things, the provisions of paragraphs 10 to 15 [i.e. of the Scheme] already referred to.
Pursuant to those arrangements, victims of trafficking can make application under the Scheme which will
be, and have been, considered substantively under all the provisions of the Scheme and been determined
in accordance with them.

131. Furthermore, ….the arrangements presently in place satisfy the requirements of Article 8 [i.e., of the
Directive]. They are the prosecutorial discretion given to the CPS not to prosecute victims of trafficking
involved in criminal activities which they have been compelled to commit as a direct consequence of being
subjected to acts of trafficking, coupled with, as a backstop, the availability of any such prosecution being
stayed as an abuse of the process recognised in R v L and ors [2013] EWCA (Crim) 991 and, as a further
backstop, Section 45 of the **_Modern Slavery Act 2015, which now provides a defence for slavery or_**
trafficking victims who commit an offence attributable to slavery or relevant exploitation. ”

36.  (3) The rival contentions:  We were most grateful (on all aspects of the appeal) to Mr Chamberlain
QC for the Appellants and Mr Collins QC for the Respondents for the quality of their respective
submissions.

37. For the _Appellants, Mr Chamberlain QC submitted that the Scheme was intended (inter alia) to_
implement the United Kingdom's obligations under Art. 17 of the Directive. This issue turned on the true
construction of the wording “access to existing schemes of compensation” within Art. 17.  That wording
was to be interpreted purposively and in accordance with the fundamental rights protected by the
Community legal order. Mr Chamberlain disclaimed any contention that Art. 17 guaranteed all victims an
award of compensation. His argument was, he said, narrower. Namely, that “a rule mandatorily precluding
_any compensation in circumstances where a conviction may arise from the very vulnerability that made the_
applicant susceptible to trafficking denies effective access to the scheme”. Mr Chamberlain took issue with
the Judge's finding (at [131]) that the arrangements in place (there set out) offered a complete answer to
the criticism of the mandatory nature of the Scheme's exclusion of those with unspent convictions resulting
in custodial or community sentences. Furthermore, Mr Chamberlain placed reliance on the principle of
“effectiveness”, summarised in the judgment of Lord Reed and Lord Hodge JJSC, in _Littlewoods Ltd v_
_Revenue and Customs Comrs_ _[2017] UKSC 70; [2017] 3 WLR 1401, at [57], namely:_


-----

“ ….that the rules do not render practically impossible or excessively difficult the exercise of rights
conferred by EU law… ”

For all these reasons, the terms of the Scheme, properly considered, gave rise to a breach of Art. 17 of the
Directive.

38. For the Respondents, Mr Collins QC's response was forthright; as he put it in his skeleton argument:

“The unambiguous wording of Article 17 provides expressly that victims of trafficking must have access to
'existing' schemes of compensation: for present purposes, the same scheme that is already available for
victims of violent intentional crimes.

There is no obligation on Member States to create a further or different scheme for victims of trafficking
than for victims of violent crime. Yet the logic of the Appellants' case must be that there is such an
obligation.”

Moreover, the Appellants' case involved the proposition that known serious criminals must be granted
different rights (to other applicants under the Scheme) _because they were subsequently trafficked. That_
was untenable. Here, the victims of trafficking had enjoyed access to the Scheme. In any event, both
ECAT and Art. 17 plainly contemplated that the decision on the scope of compensation schemes was for
national authorities.  So far as concerned victims whose crimes arise from their being trafficked, the law in
this jurisdiction provided a sufficient array of protections, as held by the Judge. Blameless victims of
trafficking, forced into criminality, would not thus be excluded from the Scheme by the mandatory rules
contained in para. 26 and Annex D. The Appellants' recourse to a purposive interpretation did not advance
the matter. Neither ECAT (which in any event operated on the international plane) nor the Explanatory
Report guaranteed financial compensation.  The Strategy document had no legal force. As to the principle
of effectiveness, it was first necessary to establish the right in question; here, it was the right to have a
claim considered in accordance with the Scheme. The Appellants' claims had been thus considered.
There was no breach of Art. 17 of the Directive; the Judge's ruling was correct.

39. _(4) Discussion:_ In my judgment, the Judge was plainly right; the mandatory exclusion for unspent
convictions resulting in custodial or community sentences contained in para. 26 and Annex D, para. 3 of
the Scheme (hereafter, “the exclusionary rule”) does not give rise to a breach of Art. 17 of the Directive.
My reasons follow.

40. First, under this heading the question is whether the Appellants had “access” to the Scheme. This is a
straightforward question concerning the wording of Art. 17 of the Directive - and admits of a straightforward
answer. The provisions of paras. 10 – 15 of the Scheme, by widening or loosening the eligibility
requirements, ensured that victims of trafficking were not, as such, denied access to the existing Scheme,
in accordance with its terms. The Appellants enjoyed such access. They were not denied recovery by dint
of being victims of trafficking; the Appellants were excluded by the provisions of para. 26 and Annex D,
para. 3 of the Scheme by reason of their convictions pre-dating their subsequent trafficking. In my
judgment, the language of Art. 17 is clear and adverse to the Appellants' case under Ground I.

41. Secondly, the Appellants' case is not assisted even when I turn from a consideration of the wording of
Art. 17 to a purposive construction. To begin with, the essential thrust of both ECAT and the Explanatory
Report is that arrangements for compensation are left to national law; they contain nothing whatever calling
for victims of trafficking to enjoy rights under national compensation schemes free of any limiting or
exclusionary terms and not enjoyed by other potential applicants for compensation who are not victims of
trafficking.  So far as concerns the Strategy document, it has no force in law and is in any event couched
at such a level of generality as to be of no assistance to the present debate.

42. Thirdly, that the Appellants may have been “vulnerable” before they were trafficked is neither here nor
there; it is a sad fact that a great many of those who commit crimes have faced adversity or have had
difficult backgrounds. It would be hopeless to contend that all those who were “vulnerable” before
committing criminal offences resulting in custodial or community sentences were entitled to compensation
under the Scheme regardless of the exclusionary rule. But if that is so, then it is impossible to conjure from
the wording of Art 17 (however purposively construed) any basis for conferring additional rights on


-----

applicants for compensation, who would not otherwise qualify for an award (by reason of the exclusionary
rule) merely because they were subsequently trafficked – yet that is an essential part of Mr Chamberlain's
argument, even accepting that he did not go so far as to submit that all victims of trafficking must receive
an award of compensation.

43. Fourthly, the more substantive question here goes to whether the exclusionary rule shuts out victims
whose crimes arise from their own trafficking. As is already apparent, such concerns do not bear on the
position of the Appellants themselves; their convictions pre-date and have no evidential nexus with their
trafficking. Nonetheless, if these concerns had force generally, then they would impact on a consideration
of whether the exclusionary rule constituted a breach of Art. 17 of the Directive.  In my judgment, the
provisions of domestic law in this jurisdiction provide amply sufficient safeguards to ensure that this is not
the case. Victims whose crimes arise from their own trafficking should not fall foul of the exclusionary rule.
In this regard, I agree with the Judge (at [131]) that the arrangements presently in place satisfy the
requirements of Art. 8 of the Directive (set out above). Spelling them out:

i) S.45 of the Modern Slavery Act 2015 (“the 2015 Act”) provides an express defence to trafficking victims
compelled to commit an offence. This defence will be available to genuine victims of trafficking, such as a
victim forced to work in a cannabis farm or a victim forced to use false documentation to work and who is
raped and starved if she does not comply. Where this defence is available, a victim of trafficking will not
receive a criminal conviction and will not be excluded from eligibility under the Scheme.

ii) As is clear from authority, the Court has power to protect victims of trafficking in respect of offences they
have been compelled to commit by staying a prosecution or, if identification of a person as a victim of
trafficking does not take place until after conviction, quashing a conviction as an abuse of process. See: R
_v L(C) and others_ _[2013] EWCA Crim 991; [2013] 2 Cr App R 23; R v Joseph (Verna) and others_ _[2017]_
_EWCA Crim 36; [2017] 1 WLR 3153. In any such cases, the victims will not be excluded from eligibility_
under the Scheme. It may be noted that a claims officer has discretion to extend the usual time limit of two
years for claims under the Scheme: see, paras. 87 and 89 of the Scheme.

iii) It is to be recollected that the exclusionary rule is not triggered by a criminal conviction alone.  The
exclusionary rule only bites in more serious criminal cases where a custodial or community sentence is
imposed. As will be apparent when dealing with Ground II, the exclusionary rule is considerably more
nuanced than the Appellants' characterisation of it would suggest. For immediate purposes, the provisions
[of the Criminal Justice Act 2003 are relevant. Thus, when sentencing, the Court is entitled and bound to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)
consider the offender's culpability and the harm caused by the offence: s.143; in turn, ss. 152 and 148
provide that custodial and community sentences may only be passed where the offence is so serious that a
lesser sanction is inappropriate; s.166 preserves the Court's power to mitigate sentences.

iv) Though more relevant to Ground II, it is further right to underline that the exclusionary rule applies only
to relevant unspent convictions. Broadly speaking, the period for which a conviction remains unspent
reflects the type of disposal and the length of the custodial sentence imposed - thus the seriousness of the
offending, taking into account also the circumstances of the offender and any relevant mitigation. The
period during which a community sentence remains unspent is less than that applicable to custodial
sentences.

44. Fifthly, the principle of effectiveness does not assist the Appellants. The starting point is to establish
the right in question, as Mr Collins correctly submitted. That right required the Appellants to have access
to the Scheme. They did. The Appellants were entitled to have their claims considered in accordance with
the Scheme. They were. The exercise of the Appellants' right to do so was not rendered practically
impossible or excessively difficult (Littlewoods, supra, loc. cit), let alone by any factor connected to their
trafficking. On no view was the very essence of the right impaired (cf., Brown v Stott [2003] 1 AC 681, at
p.695). Neither the principle of effectiveness, nor for that matter, purposive interpretation can confer
additional rights on the Appellants, not granted by Art. 17 of the Directive.

45. Accordingly, I would dismiss Ground I of the appeal.

GROUND II: DISCRIMINATION


-----

46. (1) The legal framework: The only additional provisions which need to be set out are Arts. 4 and 14,
ECHR. Insofar as relevant, these provide as follows:

“ Article 4

1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced….labour.

…..

Article 14

The enjoyment of the rights and freedoms set forth in in this Convention shall be secured without
discrimination on any ground such as sex, race, colour, language, religion, political or other opinion,
national or social origin, associations with a national minority, property, birth or other status [Italics added].”

47. _(2) The judgment (under appeal): The argument before this Court on Ground II (Discrimination) is_
somewhat different to that advanced before the Judge. However, then and now, no discrimination claim
could succeed unless the Appellants could bring themselves within Art. 14 ECHR by maintaining that
having relevant unspent convictions did constitute an “other status” within that Article. In this regard, the
Appellants were successful before the Judge (at [72] – [80]).

48. Accordingly, the Judge next needed to determine whether a difference of treatment on the ground of a
relevant other status was discriminatory, i.e., if it had no objective and reasonable justification. The test
was whether the adoption of the Scheme in its present form was “manifestly without reasonable
foundation” and the Judge went on to hold (at [88]) that the “exclusionary bright line rule” provided by
Annex D, para. 3 of the Scheme was not such. Accordingly, grounds ii) and iv) before the Court below
failed.

49. Wilkie J said this, of continuing relevance to Ground II before this Court:

“107. I accept the Claimants' argument that the adoption in 2012 of this version of the Scheme did
constitute a significant change in the terms of the Scheme which applied heretofore. Where a conviction is
sufficiently serious to attract either a custodial or a community sentence, no residual discretion is given to
the decision maker. There is a bright line of exclusion…..

108. However, where the conviction did not attract that kind of sentence, then the Scheme retains an
element of discretion under paragraph 4, and where the conviction is of a minor nature, paragraph 5
provides that the fact of such a conviction, even though not spent, does not operate to exclude an award of
compensation…..

…….

110. It is undoubtedly the case …that where schemes such as the present have been approved by
Parliament, the Court has to be extremely slow to interfere with the judgment which Parliament has
exercised in passing the legislation in its particular form. I accept the Defendants' contention that the test is
that even an exclusionary bright line rule may not be interfered with unless it is manifestly without
reasonable foundation.

111. In my judgment, the bright line exclusionary rule provided for by paragraph 3 of Annex D, contains
within it many elements of nuance and does not represent a hard and fast, one-size fits all, approach. The
period during which a conviction is unspent depends on the seriousness of the offence and the
circumstances of the offender as reflected in the sentence passed and the period before the offence
becomes spent under the Rehabilitation of Offenders Act…… These are all variables which reflect on the
seriousness of the applicant's offending, his or her history, and/or mitigating factors, and how recent the
offending was as reflected in the type and custodial length of sentence.

112. Whilst one obvious way of building in flexibility to a bright line exclusionary rule is to give the decision
maker a discretion to exclude or ameliorate its impact on grounds of exceptional circumstances or broader
criteria….it cannot be said that this Scheme, passed by Parliament, is rendered manifestly without


-----

reasonable foundation by reason of the omission of such provision, particularly where, as here, Parliament
has decided, in paragraph 4, to give a discretion. Therefore it must be taken to have considered the
question of a discretion under paragraph 3 and decided not to adopt one.”

50. (3) The rival contentions: For the Appellants, Mr Chamberlain's starting point was that Art 4, ECHR
imposed an absolute prohibition against slavery, servitude and forced labour. That prohibition extended to
a prohibition against human trafficking and, having regard to ECAT in particular, imposed a positive
obligation upon contracting states to provide victims of trafficking with access to compensation schemes.
Accordingly, the terms of the Scheme fell within the ambit of Art. 4. In turn, Art. 14, ECHR was engaged
because the Scheme discriminated against those with unspent criminal convictions, which constituted an
“other status” for the purposes of Art. 14 and/or discriminated against victims of trafficking by treating them
in the same way as other applicants for compensation when their position was different. Next, the
exclusionary rule was to be subjected to a proportionality analysis – and did not satisfy it. In particular, on
the footing that the legitimate aims of the Scheme included ensuring that those who received
compensation were morally deserving of it, those aims would be met by the less intrusive measure of
providing a discretion to claims officers enabling them to make an individualised assessment of applicants.
Previous versions of the Scheme had included such a discretion and, indeed, the mandatory exclusion had
not been foreshadowed in the public consultation preceding the introduction of the Scheme. The Scheme
failed to strike a fair balance between:

“…the need to limit eligibility to those who are morally deserving of it and the interests of those (like the
Appellants) whose convictions were linked to the vulnerability that led them to be trafficked.”

There was, accordingly, no justification for the mandatory exclusion in the Scheme barring compensation
for those, including the Appellants, with relevant unspent convictions and the Judge had erred in his
conclusion.

51. For the Respondents, Mr Collins contested these submissions root and branch. While Art. 4, ECHR
required the State to take steps to protect the individual, the State's obligations under Art. 4 did not extend
to compensation which was not, therefore, within its ambit. ECAT could not be relied upon as the basis for
a claim by an individual. Here, as under Ground I, there was no basis in law for the assertion that there
was a greater obligation to provide victims of trafficking with compensation than other victims of violent
crime. The discrimination claim failed at the first hurdle. It likewise failed at the next, Art. 14, hurdle. Mr
Collins submitted that the Appellants did not enjoy any “other status”; a sentence imposed for offending
could not amount to an “other status” within Art. 14.  In this regard, Mr Collins primarily relied on House of
Lords authority, which remained binding on this Court regardless of subsequent European Court of Human
Rights (“Strasbourg”) authority. If necessary to go further, then the test for justification of the mandatory
exclusion in the Scheme was whether it was “manifestly without reasonable foundation”. The answer was
that it was not. The issue concerned the allocation of resources and the eligibility of applicants for public
funds. These were pre-eminently matters for the Legislature and Executive and the Court should be slow
to intervene. The European instruments had given a broad discretion to the State and the 1995 Act had
given a broad discretion to the Executive. A legitimate aim of the Scheme was to exclude the payment of
public money to serious criminals. There was a rational connection between that aim and the mandatory
exclusionary rule. The Judge was right; the Scheme had struck a fair balance. In any event, the Scheme
was nuanced and the terms of Annex D could not properly be described as a “blanket rule”. It could not be
said that the line drawn by the Scheme was “manifestly without reasonable foundation”.

52.  (4) Discussion: The discussion here falls conveniently under three headings: (A) The ambit of Art. 4,
ECHR; (B) “Other status” under Art. 14, ECHR; (C) Justification.

53. _(A) The ambit of Art. 4, ECHR:_ As is common ground, Art. 14 complements the other substantive
provisions of the ECHR; it has effect solely in relation to the enjoyment of the rights and freedoms
safeguarded by those provisions. It is, therefore, a pre-condition for Art. 14 to be engaged, that the matter
complained of comes, at the least, within the ambit of Art. 4. At once the question arises as to the true
scope of Art. 4 and whether it extends to the right to compensation from the State to those who have been
subjected to slavery or servitude or forced labour by a non-State agent.


-----

54. At first blush, the absolute prohibition on slavery, servitude and forced labour in Art. 4 (set out above)
seems somewhat far removed from a consideration of the exclusionary rule under the Scheme. However,
before coming to any view, it is necessary to have regard to the relevant Strasbourg jurisprudence.

55. The Respondents drew our attention to the admissibility decision in _Stuart v UK Application No._
41903/98 (6 July 1999), concerning Arts 3 and 8, ECHR, in the context of sexual abuse of a child by her
step-father. The victim's claim for compensation under the CICA scheme then in force failed because of
the rule, applicable at the material time, excluding the payment of compensation when victim and assailant
were living together as members of the same family. The victim complained under Arts. 3 and 8 that the
State's positive obligation to provide practical and effective protection against treatment such as that she
had suffered extended to the provision of compensation when it could not be recovered from the
perpetrator. Her complaint was rejected. The Strasbourg Court said this (at [1]):

“ ….the Court finds that the State's positive obligation under Articles 3 and 8 cannot be interpreted as
requiring a State to provide compensation to the victims of ill-treatment administered by private individuals.
”

56. The Appellants placed much reliance on the decision of the Strasbourg Court in Rantsev v Cyprus and
_Russia [2010] 51 EHRR 1.  The matter arose out of the death of a Russian woman in Cyprus, where she_
had been trafficked and exploited. So far as here relevant, the claim of the deceased's mother succeeded
against Cyprus. There had been a violation of Art. 4 by Cyprus, because of the failure to afford the
deceased both practical and effective protection against trafficking and exploitation in general, and specific
measures of protection.

57. The Court in Rantsev dealt at length with Art. 4 and trafficking (at [272] and following).  It concluded
(at [282]) that trafficking fell within the scope of Art. 4.  The Court reiterated (at [283]) that, together with
Arts. 2 and 3, Art. 4 “enshrines one of the basic values of the democratic societies making up the Council
of Europe”. There were no exceptions and no provisions for derogation from its terms. The “spectrum of
safeguards” (at [284]) in national legislation “must be adequate to ensure the practical and effective
protection of the rights of victims or potential victims of trafficking”. As a matter of positive obligation (at

[285]), States were required to have in place a legislative and administrative framework to prevent
trafficking, punish traffickers and protect victims. There would be (at [286]) a violation of Art. 4 where the
authorities failed to take appropriate measures within the scope of their powers to remove the individual
from a trafficking situation or the risk of trafficking. Furthermore (at [288]), States were under a procedural
obligation to investigate situations of potential trafficking. It must, however, be noted that the Court said
nothing about the State's obligations extending to the provision of compensation while saying this (at

[287]):

“Bearing in mind the difficulties involved in policing modern societies and the operational choices which
must be made in terms of priorities and resources, the obligation to take operational measures must,
however, be interpreted in a way which does not impose an impossible or disproportionate burden on the
authorities.”

58. The Appellants further relied on Chowdury and others v Greece (Application no. 21884/15), judgment
dated 30 March 2017, concerning a claim by various Bangladeshi nationals arising from their conditions of
work as farm labourers.

59. In Chowdury, the Court reiterated (at [103]) that Art. 4 may, in certain circumstances, require the State
to take “operational measures to protect actual or potential victims of human trafficking”.  Art. 4 was to be
construed in the light of ECAT (at [104]) and required “…in addition to prevention, victim protection and
investigation, together with the characterisation as a criminal offence and effective prosecution of any act
aimed at maintaining a person in such a situation”. The Court added (at [110]) that “protection measures”
included “…facilitating the identification of victims by qualified persons and assisting victims in their
physical, psychological and social recovery”. The Court went on (at [126] – [127]) to disapprove of the
amount of compensation that certain of the perpetrators (including an armed guard), convicted of grievous
bodily harm, had been sentenced to pay - €43 per injured worker:


-----

“However, Article 15 of …[ECAT]…obliges Contracting States, including Greece, to provide in their
domestic law for the right of victims to receive compensation from the perpetrators of the offence and to
take steps to, inter alia, establish a victim compensation fund.”

Accordingly, the Court found that there had been a violation of Art. 4.2, on account of the State's failure
“…to fulfil its positive obligations under that provision, namely the obligations to prevent the impugned
situation of human trafficking, to protect the victims, to conduct an investigation into the offences and to
punish those responsible for the trafficking”.

60. Both _Rantsev and_ _Chowdury were considered in the (domestic) case of_ _R (Tirkey)_ [2018] 1 WLR
2112v The Director of Legal Aid Casework and The Lord Chancellor _[2017] EWHC 3403 (Admin). The_
issue in question was whether the statutory charge under the Legal Aid Scheme, which effectively
extinguished the amount the claimant had recovered pursuant to the decision of the Employment Tribunal
had breached her rights under Arts. 4, 6 and 14 of the ECHR. Though describing the circumstances as
“extremely unfortunate” (at [63]), William Davis J dismissed the claim; the statutory charge was a
“brightline” provision.

61. The claimant contended that Chowdury established the proposition that Art. 4 served to give victims of
trafficking the right to compensation and that a legislative framework which did not operate properly in a
particular case was not consistent with Art. 4. William Davis J's observations in rejecting this submission
have some resonance for the present dispute.

“ 40. I am satisfied that the statutory charge does not violate Article 4 when applied as it was in the
Claimant's case. Article 15(2) of ECAT requires provision of free legal aid for victims of trafficking under the
conditions provided by its internal law. The civil legal aid scheme as it applied to the Claimant satisfied that
requirement. Article 15(3) of ECAT requires the state to ensure that victims of trafficking have the right to
compensation from the perpetrators. The relief obtained by the Claimant was precisely that. Article 15(4) of
ECAT does not impose an unconditional requirement for the state to compensate victims of trafficking.
The requirement is 'in accordance with the conditions under its internal law'. The internal law in the United
Kingdom includes the civil remedies open to a victim of trafficking, the provision of legal assistance and the
means to enforce any judgment obtained. That provides the guarantee in terms of civil process required
by ECAT. ”

62. As to Rantsev, William Davis J (at [42]) rejected the notion that it said anything which supported the
proposition that the statutory charge undermined the “practical and effective protection of the rights of
victims of trafficking”. As a matter of context, the Court in Rantsev was concerned with criminal law and
regulatory measures in relation to businesses and immigration policy.

63. William Davis J went on (at [43]) to reject the argument that _Chowdury served to guarantee the_
claimant the sums she was awarded by the Employment Tribunal. He added this:

“ …The case was concerned solely with the failure of the police to investigate the complaints of the victims
and the failure of the judicial system to reach appropriate findings in relation to the victims' status. As an
adjunct to the finding in relation to the judicial system the European Court considered that compensation of
43 Euros in criminal proceedings for someone having been seriously injured in a shooting did not meet the
requirements of Article 15(4) of ECAT. ….. ”

64. In my judgment, the Strasbourg jurisprudence as such provides, at most, no more than marginal
support for the Appellants' contentions. Stuart is authority, on Arts. 3 and 8, squarely against the State's
obligations extending to the provision of compensation to victims of ill-treatment at the hand of non-State
actors. That Stuart was an admissibility decision seems to me neither here nor there. On the other hand, it
must be acknowledged that _Stuart was not an authority on Art. 4, so cannot assist with the true_
construction of that Article. _Rantsev, though dealing in considerable detail with the State's obligations_
under Art. 4 provides no support for the Appellants' submission that those obligations extend to the
provision of State compensation. If anything, it tells against any over-ready assumption that the State's
other obligations of protection and the like extend to encompass compensation. So far as _Chowdury_
addresses compensation, its essential focus is compensation against the perpetrators of the trafficking not


-----

the State. There is no more than a passing reference to State compensation and that does no more than
record the terms of Art. 15, ECAT. As William Davis J put it, in Tirkey, the reference to compensation –
_from the perpetrators - in Chowdury was “no more than an adjunct” to the Court's findings as to the judicial_
system in question.

65. Matters do not, however, end there, as the Appellants have another avenue of argument open to them.
The Appellants are entitled to and do pray in aid the reference in Chowdury (at [104]) to construing Art. 4 in
the light of ECAT. The argument, accordingly, is that ECAT is relevant to determining the scope of the
State's positive obligations under Art. 4. Those obligations include the protection of victims. Having regard
to the terms of ECAT as a whole, it can fairly be argued that the obligation to protect victims of trafficking
extends to having in place a system for the provision of compensation (Art. 15).  If so, then the system
must be “effective” and, therefore, the terms of access to compensation schemes may fall to be
considered. If all this is right, then the basis for the Appellants' argument that the terms of access to the
Scheme come within the ambit of Art. 4 begins to emerge. Moreover, the consideration that ECAT
operates on the international plane is not an answer, in that the Appellants' argument is founded on Art. 4 –
but interpreted by reference to ECAT. So too, for the purposes of this stage of the argument, the fact that
ECAT, the Explanatory Report and, for that matter, the Directive all regard compensation as falling under
national law (with such conditions as are attached), does not serve to remove compensation from the ambit
of Art. 4.

66. Notwithstanding this line of argument, my strong inclination is that the Appellants are unable to
establish that the terms of access to the Scheme fall within, or sufficiently, within the ambit of Art. 4, so that
the Appellants' Discrimination claim ought to fail at the first hurdle. I am troubled by the posited inexorable
expansion (or perhaps extrapolation) of rights and duties (cf., Lord Sumption and the Limits of the Law
(2016), at p.216), so that a straightforward ECHR prohibition on slavery and the like, commanding it must
be hoped universal support, somehow encompasses the terms of access to a national compensation
scheme. In short, on the Appellants' case, the Art. 4 prohibition not only requires the prevention of
trafficking, the prosecution of offenders and the protection of victims or potential victims but leaps to the
provision of State compensation. It is by no means inevitable that it should; it is a major leap indeed and
not one which necessarily, or even obviously, increases respect for the law.

67. That said, to hold that the terms of access to the Scheme do not fall within the ambit of Art. 4 would
not only be fatal to the Appellants' claim but may have wider consequences. Given the view which I take of
Ground II as a whole, it is unnecessary that I reach a final conclusion on this point. I therefore do not do so
and leave its final resolution for a case where such a decision is crucial to the outcome. I am content
instead to proceed on the assumption, in the Appellants' favour, that the terms of access to the Scheme do
fall within the ambit of Art. 4 – and to deal with headings (B) and (C) on that footing.

68.  (B) “Other status” under Art. 14: In order that Art. 14 can be relied upon in support of the Appellants'
Discrimination claim (the substantive arguments are dealt with under (C) below), Art. 14 must be engaged.
Art. 14 does not prohibit differential treatment on any ground whatever. The only possible basis on which
the Appellants could contend that they come within the scope of Art. 14 is if they hold an “other status”. As
already indicated, the Judge (at [80]) decided in favour of the Appellants on this point, on the ground that
having unspent convictions of the relevant kind constituted an “other status”.

69. The issue here is one concerning the domestic rules of precedent. It is common ground, for present
purposes, that this Court must follow a binding decision of the House of Lords or Supreme Court, despite
its inconsistency with subsequent Strasbourg authority: Kay v Lambeth Borough Council _[2006] UKHL 10;_

[2006] 2 AC 465.

70. The problem arises because of the divergence between the decision of the House of Lords in R (Clift)
_v Home Secretary [2006] UKHL 54; [2007] 1 AC 484(“Clift HL”) and the subsequent Strasbourg decision in_
the same case _Clift v The United Kingdom (Application no 7205/07) Judgment 13 July 2010 (“Clift_
_Strasbourg”)._

71. In Clift HL, the House of Lords held that a prisoner serving a determinate sentence of 15 years or more
(but less than a life sentence) did not on that ground have an “other status” The House of Lords was


-----

concerned that to decide otherwise would go beyond the existing Strasbourg jurisprudence. The length of
the sentence was not a personal characteristic.  As expressed by Baroness Hale of Richmond (at [62]):

“ ….it is plain…that a different parole regime for foreigners who are liable to deportation from that
applicable to citizens or others with the right to remain here, falls within the grounds proscribed by article
14 and thus….requires objective justification. The same would surely apply to a difference in treatment
based on race, sex or the colour of one's hair. But a difference in treatment based on the seriousness of
the offence would fall outside those grounds. The real reason for the distinction is not a personal
characteristic of the offender but what the offender has done.”

72. In Clift Strasbourg, the Court took a different view, as appears from the passages which follow. First,
the Court made it plain that the list of grounds was “illustrative and not exhaustive”:

“55. Article 14 does not prohibit all differences in treatment but only those differences based on an
identifiable, objective or personal characteristic or 'status', by which persons or groups of persons are
distinguishable from one another….. Article 14 lists specific grounds which constitute 'status' including,
_inter alia, sex, race and property However, the list set out in Article 14 is illustrative and not exhaustive, as_
is shown by the words 'any ground such as'….and the inclusion in the list of the phrase 'any other
status'….”

Later, the Court held that the characteristics in question need not be “innate” or “inherent”:

“The Court therefore considers it clear that while it has consistently referred to the need for a distinction
based on a 'personal characteristic' in order to engage Article 14, as the above review of its case-law
demonstrates, the protection conferred by that Article is not limited to different treatment based on
characteristics which are personal in the sense that they are innate or inherent. Accordingly, even if as the
Government contended, a ejusdem generis construction were appropriate in the present case, this would
not necessarily preclude the distinction upon which the applicant relies.”

73. The Judge (at [60]) accepted that Clift HL was binding “for the issue it decided”. However, the issue in
_Clift was the length of the sentence, whereas here it related to the “concept of an unspent conviction which_
is determined by a combination of the nature of the sentence passed, its length and the amount of time
which has elapsed from a relevant moment under the Rehabilitation of Offenders Act scheme”.  The issue
in this case was thus wider than that in Clift, so that the Judge was not bound by Clift HL.  Following the
instincts of the majority of the House of Lords in Clift HL (had they not felt constrained by the then state of
Strasbourg jurisprudence) and the decision in Clift Strasbourg, the Judge held that the Appellants did have
“other status” for the purposes of Art. 14.

74.  While I confess attraction to the view that personal characteristics are “innate” or “inherent” and are to
be distinguished from that which someone has done (as remarked by Baroness Hale), perhaps especially
in the context of criminal offending, in the light of _Clift Strasbourg that line cannot be held. In the_
circumstances, unless we are bound by _Clift HL_ to conclude that the Appellants did not enjoy an “other
status”, _Clift Strasbourg_ points to the conclusion that they did. For the reasons given by the Judge and
with which I agree, I do not think that we are bound by Clift HL to decide this issue against the Appellants.
As it seems to me, the issue here is indeed distinguishable from the issue in Clift HL. It follows that the
Appellants, by reason of their unspent convictions of the relevant kind, did have an “other status”, so that
Art. 14 is engaged.

75. (C) Justification: I come, therefore, to the crucial question: justification of the terms of the Scheme in
its present form – in particular, the exclusionary rule.

76. (1) The test: A difference in treatment on the ground of a relevant “other status” is only discriminatory
if it has no objective and reasonable justification. There was no or no serious dispute that the test for
determining that question here is whether the adoption of the Scheme in the form it is in was “manifestly
without reasonable foundation”. In the present context, a State has a significant margin of appreciation.


-----

77. _Stec v United Kingdom (2006) 43 EHRR 47 was concerned with limiting conditions relating to_
additional state benefits payable to people who had to stop working because of injury at work or
occupational disease. The Strasbourg Court said this:

“51. …. A difference of treatment is…discriminatory if it has no objective and reasonable justification, in
other words if it does not pursue a legitimate aim or if there is not a reasonable relationship of
proportionality between the means employed and the aim sought to be realised. The Contracting State
enjoys a margin of appreciation in assessing whether and to what extent differences in otherwise similar
situations justify a different treatment.

52. The scope of this margin will vary according to the circumstances, the subject-matter and the
background. As a general rule, very weighty reasons would have to be put forward before the Court could
regard a difference in treatment based exclusively on the ground of sex as compatible with the Convention.
On the other hand, a wide margin is usually allowed to the State under the Convention when it comes to
general measures of economic or social strategy. Because of their direct knowledge of their society and its
needs, the national authorities are in principle better placed than the international judge to appreciate what
is in the public interest on social or economic grounds, and the Court will generally respect the legislature's
policy choice unless it is 'manifestly without reasonable foundation'.”

See too, Humphreys v Revenue and Customs Comrs _[2012] UKSC 18; [2012] 1 WLR 1545, at [15] et seq._

78. In _R (RJM) v Work and Pensions Secretary_ _[2008] UKHL 63; [2009] 1 AC 311, the Supreme Court_
considered the cessation of payment of a disability premium to those who had become homeless. The
observations of Lord Neuberger of Abbotsbury furnish, with respect, compelling guidance. They endorse
the test in Stec; address the question of general rules and the drawing of lines; emphasise that the Court
should be slow to intervene in such an area; and serve as a reminder that the fact that the policy adopted
can be criticised may well not be a ground for rejecting it. Thus:

“54. ….policy concerned with social welfare payments must inevitably be something of a blunt instrument,
and social policy is an area where a wide measure of appreciation if accorded by the ECtHR to the state:
see…Stec… As Lord Bingham said about a rather different statute, '[a] general rule means that a line must
be drawn, and it is for Parliament to decide where', and this 'inevitably means that hard cases will arise
falling on the wrong side of it, but that should not be held to invalidate the rule, if judged in the round, it is
beneficial': R (Animal Defenders International) v Secretary of State for Culture, Media and Sport [2008 AC
1312, para. 33.

56. ….the discrimination in the present case was justified, in the sense that the Government was entitled to
adopt and apply the policy at issue. This is an area where the court should be very slow to substitute its
view for that of the executive, especially as the discrimination is not on one of the express, or primary,
grounds…….

57. The fact that there are grounds for criticising, or disagreeing with, these views does not mean that they
must be rejected. Equally, the fact that the line may have been drawn imperfectly does not mean that the
policy cannot be justified. Of course, there will come a point where the justification for a policy is so weak,
or the line has been drawn in such an arbitrary position, that, even with the broad margin of appreciation
accorded to the state, the court will conclude that the policy is unjustifiable. However, this is not such a
case…..”

79. With regard to judicial restraint where, as in the present case, a statutory instrument has been
reviewed by Parliament, Lord Sumption's observations in Bank Mellat v HM Treasury (No 2) _[2013] UKSC_
_38; [2013] UKSC 39; [2014] AC 700, at [44], are very much in point:_

“….when a statutory instrument has been reviewed by Parliament, respect for Parliament's constitutional
function calls for considerable caution before the courts will hold it to be unlawful on some ground (such as
irrationality) which is within the ambit of Parliament's review. This applies with special force to legislative
instruments founded on considerations of general policy.”


-----

80. So far as concerns conducting a proportionality analysis in the course of the application of the
“manifestly without reasonable foundation test”, the four stages have been helpfully summarised by Lord
Mance JSC (as he then was) in _In re Medical Costs for Asbestos Diseases (Wales) Bill_ _[2015] UKSC 3;_

[2015] AC 1016, at 45 (building on Bank Mellat, esp. at [20] and [68] – [76]):

“ There are four stages, which I can summarise as involving consideration of (i) whether there is a
legitimate aim which could justify a restriction of the relevant protected right, (ii) whether the measure
adopted is rationally connected to that aim, (iii) whether the aim could have been achieved by a less
intrusive measure and (iv) whether on a fair balance, the benefits of achieving the aim by the measure
outweigh the disbenefits resulting from the restriction of the relevant protected right.”

As Lord Sumption observed in Bank Mellat (at [20]), the four stages are logically separate but, in practice,
inevitably overlap.

81. _(2) The application of the test:_ By way of recap and as expressed in their skeleton argument, the
Appellants complain of discrimination on two bases; first, that the exclusionary rule in the Scheme
discriminates against those with relevant unspent criminal convictions; secondly, that it treats victims of
trafficking in the same way as other applicants for compensation when their position is different.

82.  I am amply persuaded that the exclusionary rule is justified. It cannot be said that the policy
embodied in the exclusionary rule is without reasonable foundation or fails to strike a fair balance. I reject
the Appellants' claim of unjustified discriminatory effects in breach of Art. 14, ECHR.  My reasons follow.

83. _First,_ as to the first way in which the Appellants put their case, the Appellants themselves accept
“…that it is, in general, permissible to limit eligibility for compensation to those who are morally deserving
of it”. This is no more than realistic but is an important concession nonetheless.

84. Going back to the _European Convention on the Compensation of Victims of Violent Crimes,_
Strasbourg, 24.xi.1983 (“the 1983 Convention”), Art. 8 provided that compensation may be reduced or
refused on account of the victim's or applicant's conduct, involvement in organised crime, membership of
an organisation which engages in crimes of violence, or (Art. 8.3) if “an award or a full award would be
contrary to a sense of justice or to public policy…”.  The Explanatory Report to the 1983 Convention (“the
1983 Explanatory Report”) includes the following pertinent passage, relating to Art. 8.3 of the 1983
Convention, at para. 36:

“ …Compensation repugnant to the sense of justice or contrary to public policy…

States which introduce compensation schemes usually want to retain some discretion in awarding
compensation and to be able to refuse it in certain cases where it is clear that a gesture of solidarity would
be contrary to public feeling or interests or would be contrary to the basic principles of the legislation of the
State concerned. This being so, a known criminal who was the victim of a crime of violence could be
refused compensation even if the crime in question was unrelated to his criminal activities.”

85. In the Ministry of Justice Consultation Paper CP3/2012, January 2012, Getting it right for victims and
_witnesses (“the 2012 Consultation”), preceding the amendment of the Scheme producing its current_
iteration, the Foreword by the then Lord Chancellor and Secretary of State for Justice (The Rt. Hon.
Kenneth Clarke QC MP) highlighted, inter alia, the funding difficulties faced by the Scheme and remarked
that “Absurdly, tens of millions of pounds have been spent on compensation for people who are
themselves convicted criminals.”  Accordingly, compensation would no longer be available to “anyone who
has been breaking the law themselves”.  In its approach to reforming the Scheme, the Government stated
(at para. 172) that it was intent on ensuring that its proposals complied with “our legal obligations, both
domestic and European”. In this regard, the proposals (at para. 189) foreshadowed the relaxation of the
residence test, to accommodate victims of human trafficking (in accordance with the Directive).

86. The 2012 Consultation dealt specifically with previous convictions (at paras. 203 and following).  It
underlined that the Scheme had always been intended to benefit “blameless victims of crimes of violence”.
It referred to the previous practice of claims officers applying a system of points linked to the sentence and
the time that had passed since it was imposed to decide if a reduction or refusal of an award was


-----

appropriate – while recording that “in exceptional circumstances” claims officers had been entitled to make
an award or reduced award outside the points system.

87. The Government proposal (at para. 205) was to “tighten existing provisions relating to an applicant's
unspent criminal convictions”.  Two options were canvassed:

“ **Option A:** all those with any unspent criminal convictions should be excluded from claiming under the
Scheme, retaining a discretion to depart from this rule only in exceptional circumstances…..

**Option B: To exclude from the Scheme those who have unspent convictions for offences which could give**
rise to an award under the Scheme (namely, for violent or sexual offences). Those with unspent
convictions relating to other offences would continue to have their awards reduced or withheld unless there
are exceptional circumstances justifying the making of a full or partial award…..”

88. A preference was expressed (at para. 206) for Option A. The proposal was to include a discretion to
depart from this rule in exceptional circumstances. The 2012 Consultation continued (at para. 207):

“ We acknowledge that our proposals in relation to the Scheme rules on unspent convictions, although a
development of the existing position could impact in particular on those who have on their record relatively
minor unspent convictions. However, we consider that tougher rules are warranted. The Scheme is a
taxpayer-funded expression of public sympathy and it is reasonable that there should be strict criteria
around who is deemed 'blameless' for the purpose of determining who should receive a share of its limited
funds. We consider that, in principle, awards should only be made to those who have themselves obeyed
the law and not cost society money through their offending behaviour. Minor convictions will, under the
_[Rehabilitation of Offenders Act 1974,become spent (and therefore no longer count for the purpose of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y1JH-00000-00&context=1519360)_
Scheme) so long as the offender does not reoffend.”

89. The potential financial impact of Options A and B were assessed (at para. 208). Option A was
expected to save between £4 and £5 million a year. Option B was predicted to save less, though it was not
possible to quantify the precise amount.

90. The Government Response to the 2012 Consultation was published in July 2012 (“the Response”).
The Response acknowledged (at paras. 177 and 178) a negative reaction to Option A and a majority of
respondents favouring claims officers continuing to have a discretion. Nonetheless and in the event, the
Response foreshadowed the terms of the Scheme, in these terms:

“180. We have considered again the proportionality of our original proposals. We remain of the view that
applicants who have unspent convictions should not generally benefit from an award under the Scheme.
We believe strongly that any applicant who has an unspent conviction which resulted in a custodial
sentence or community order should not be able to benefit from the scheme under any circumstances.

181. However, we have considered consultation responses which argued that claims officers should be
able to exercise discretion in some cases. Where the applicant has an unspent conviction and did not
receive a custodial sentence or community order we will retain discretion to make an award in exceptional
circumstances…..We will not withhold or reduce awards where the applicant has received an
endorsement, penalty points or a fine for a driving offence.”

91. As is clear from the Impact Assessment (“the IA”) dated 2nd July, 2012 (“the IA”), Government's focus
was a more effective use of available resources, ensuring the sustainability of the Scheme for the future
and reducing the burden on taxpayers.

92. In my judgment, a generalised attack on the exclusionary rule in the Scheme for those with unspent
relevant convictions is hopeless. The complaint is belied by the Appellants' own concession. The moral
element, underlying the exclusionary rule, is internationally understood and, in any event, a matter for
national states (see the 1983 Convention and the 1983 Explanatory Report).  There is plainly a legitimate
aim in limiting eligibility for compensation to those who are morally deserving of it, namely, “blameless
victims of crimes of violence” (in the words of the 2012 Consultation). The measure adopted is rationally
connected to that aim, not least as the unspent convictions which trigger the exclusionary rule are those
where the offenders “have cost society money through their offending behaviour” (ibid) – in terms of


-----

custodial or community sentences. The exclusionary rule operates in the realm of social policy and the
Scheme has been reviewed and approved by Parliament; the matter cries out for judicial restraint. That
the Scheme should contain a provision precluding compensation in certain cases of serious criminal
offending for those with unspent relevant convictions, is unremarkable. On any view, the existence of
some such provision cannot be said to be manifestly without reasonable foundation.

93. It follows that any attack on the exclusionary rule requires a narrower focus. I turn to explore (inter
_alia) whether the position of victims of trafficking or the elimination of the case officers' discretion lends any_
more substance to the Appellants' complaint.

94. _Secondly, the Appellants complain that the Scheme discriminates against victims of trafficking by_
treating them in the same way as other applicants for compensation, when their position is different. The
juristic basis for this submission is to be found in the observations of the Strasbourg Court in Thlimmenos v
_Greece (2001) 31 EHRR 15, esp. at [44]:_

“ The Court has so far considered that the right under Article 14 not to be discriminated against in the
enjoyment of the rights guaranteed under the Convention is violated when States treat differently persons
in analogous situations without providing an objective and reasonable justification. However, the Court
considers this is not the only facet of the prohibition of discrimination in Article 14. The right not to be
discriminated against in the enjoyment of the rights guaranteed under the Convention is also violated when
States without an objective and reasonable justification fail to treat differently persons whose situations are
significantly different.”

95. The principle is straightforward but there is a short answer to this submission. Namely, insofar as their
situations are significantly different, victims of trafficking _are treated differently from others who commit_
crimes resulting in custodial or community sentences. The various protections in the criminal justice
system available to victims of trafficking have already been set out. To reiterate, there is the statutory
defence under s.45 of the 2015 Act; there are the Court's powers to stay a prosecution or quash a
conviction; there are the Court's sentencing powers, amply permitting the sentencing Judge to take
account of the circumstances of the victim of trafficking. If, however, a victim of trafficking is for some
reason unable to benefit from any of these protections, then the circumstances of the offending would likely
be so divorced from the trafficking as to point to him (or her) not being a blameless victim of a crime of
violence.

96. The Appellants' submission did not, however, stop there. They criticised the Scheme for failing to strike
a fair balance, praying in aid “…the interests of those (like the Appellants) whose convictions were linked to
the vulnerability that led them to be trafficked”. As already held under Ground I, this is an impossible
contention. There is no, certainly no sufficient, evidential basis for linking the Appellants' convictions “to
the vulnerability that led them to be trafficked”. The material before us goes no further than the Appellants
having difficult childhoods and being placed in care. “Vulnerability” is in no sense unique to victims of
trafficking. Sadly, if to repeat an earlier observation, many of those who commit crime are themselves
vulnerable and have had very difficult backgrounds, to put it no higher. Acceding to this submission of the
Appellants would open the way to an attack on any provision excluding those with unspent relevant
criminal convictions from recovery under the Scheme.

97. Thirdly, it is necessary to confront the Appellants' criticism of the Scheme based on the exclusionary
rule not leaving a claims officer with discretion – as was the case under previous versions of the CICA
Scheme. The blunt answer is that national States, allowed a margin of appreciation in this area, are free to
draw lines. The mere fact that there are grounds for criticising the line drawn by the Scheme, or that others
might have preferred different provisions leaving a discretion in place, does not render the policy
unjustifiable: Lord Neuberger, supra, in RJM. Drawing a line does not of itself mean that the policy was
manifestly without reasonable foundation or, put another way and as the Judge observed (at [112]), that
building in a discretion is necessary for the policy to have a reasonable foundation. Parliament approved
the provisions of the exclusionary rule and, in my judgment, the Court should not intervene.


-----

98. _Fourthly,_ in further considering whether the exclusionary rule under the Scheme was on the wrong
side of the line drawn by Lord Neuberger in RJM (at [57]), it is important to emphasise the nuanced nature
of the exclusionary rule. So:

i) Annex D, para. 3 applies only to unspent convictions for offences resulting in custodial or community
sentences, reflecting the seriousness of the offending in question;

ii) Annex D, para. 4 permits a discretion to be exercised in favour of an applicant for compensation where
sentences other than those under para. 3 have been passed – thus, lesser sentences because of the lower
order of gravity of the offending.  Moreover, para. 4 plainly leaves to the claims officer a discretion to
approve a reduced award.

iii) Annex D, para. 5 provides that paras. 3 and 4, contemplating or requiring the withholding or reduction
of awards of compensation, does not apply to (essentially) various road traffic offences resulting in no more
than an endorsement, penalty points or a fine.

iv) Finally and as para. 26 of the Scheme makes clear, Annex D, para. 3 only bites on _unspent_
convictions. In short, the more serious the offending the longer an applicant might be debarred from
recovering compensation under the Scheme - and in cases of the most serious offending, will be
permanently debarred.

99. The Judge observed (at [111]) that the exclusionary rule provided for by Annex D, para. 3 did “not
represent a hard and fast, one-size fits all, approach”. I agree. Annex D read as a whole provides a
graduated approach to withholding or reducing awards of compensation, hinging on the seriousness of the
offending, the circumstances of the offender and applicable mitigation, all reflected in the sentence passed
and the time which has elapsed since the offending in question. Given the legitimate aim of restricting
eligibility for compensation to those morally deserving, the exclusionary rule plainly has a rational
connection to it. Moreover, having regard to the nuanced nature of the exclusionary rule, it is difficult to
see that the legitimate aim could have been achieved by a less intrusive measure, unless it is to be said
that the existence of a discretion is a necessary condition for the policy to be justifiable. For reasons
already given, that is not an argument I can accept.  As it seems to me, having regard to the true nature
of the exclusionary rule, it strikes a fair balance and, on no view, can be regarded as “manifestly without
reasonable foundation”.

100. I add only that I have not overlooked the decision of the Strasbourg Court in Hirst v United Kingdom
_(No.2) (2006) 42 EHRR 41 but it does not begin to dissuade me from the conclusion to which I have come._
Not only was the context far-removed from the considerations underpinning the Scheme here but the
measure in question was described as “indiscriminate” (at [82]). That could not be said of the exclusionary
rule under the Scheme.

101. _Fifthly,_ largely for completeness, I do not think that anything turns on the 2012 Consultation not
having canvassed in terms the exclusionary rule as it finally appeared in the Scheme (without a discretion
left to the claims officer). I do not accept the Appellants' contention that the Scheme was adopted without
resource considerations having been reflected upon. As already noted, the 2012 Consultation proposed
tightening “existing provisions relating to an applicant's unspent criminal convictions”.  Option A retained a
discretion and was predicted to save more than the less stringent Option B. Inevitably, the adoption of the
exclusionary rule without a discretion would be likely to increase savings, both in terms of payments made
and reduced administrative expenses. It is unrealistic to suppose that such considerations did not play a
role, accompanied by underlying considerations of policy, encapsulated in the Response at para. 180.

102. _Overall and for the reasons given, the exclusionary rule is justified. It satisfies a proportionality_
analysis and was not on any view “manifestly without reasonable foundation”.  In my judgment, Ground II
fails and I would dismiss the appeal.

103. For completeness:

i) Given my conclusions, it is unnecessary to say anything as to the remedy to which the Appellants might
have been entitled, had the appeal succeeded.


-----

ii) To the extent that the Appellants left open the possibility of a stand-alone claim pursuant to Art. 4,
ECHR, nothing in this judgment lends it support. The assumption that the Appellants' claim came within
_the ambit of Art. 4 does not at all signify that a claim alleging breach of Art. 4 would have any foundation._

LADY JUSTICE SHARP

104. I agree

LORD JUSTICE FLAUX

105. I also agree

**End of Document**


-----

