# Koceku v Republic of Albania [2024] EWHC 1028 (Admin)

King's Bench Division, Administrative Court (London)

Mr Justice Julian Knowles

10 May 2024Judgment

**David Ball (instructed by Lloyds PR Solicitors) for the Appellant**

**Amanda Bostock (instructed by CPS) for the Respondent**

Hearing dates: 18 January 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 10 May 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

**Mr Justice Julian Knowles:**

**Introduction**

1. This is an appeal against the decision of DJ Clews to send the Appellant's case to the Secretary of
[State dated 18 April 2023 further to s 87(3) and s 103(1), Extradition Act 2003 (EA 2003)). I granted](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1C9-00000-00&context=1519360)
permission at an oral hearing. The single ground of appeal is that the district judge was wrong to find that
extradition would be a proportionate interference with the Appellant's rights under Article 8 of the ECHR.

2. The Secretary of State issued an order for the Appellant's extradition to Albania pursuant to s 93(4) EA
2003 on 13 June 2023.

3. The Appellant says that this is an unusual case. The Respondent seeks the Appellant's extradition
following a conviction for which a sentence of immediate imprisonment was passed. But both the
Appellant and the Respondent still have pending appeals in Albania. The matter therefore comes before
this court as an accusation case because there is no final and enforceable decision giving effect to the
court's sentence. This is not uncommon in itself.

4. The Appellant says that what is particularly unusual about this case is that the prosecution in Albania
are appealing on the basis that the sentence of immediate custody that has been imposed was a mistake.
They are inviting the Albanian court to impose a suspended sentence instead. The Appellant says if this
were a conviction case then it would not even cross the threshold for amounting to an extradition offence,
where a sentence of four months' immediate custody is required. He submits this is a case in which the
public interest in extradition is therefore not as heavy as it might ordinarily be. But added to this, he also
says there is now compelling fresh evidence which was not available at the time the district judge made his
decision. There has now been a Conclusive Grounds decision by the Home Office's Single Competent
Authority (SCA) that the Appellant has been the victim of modern slavery. He is a vulnerable individual.
Mr Ball for the Appellant therefore says these matters tip the Article 8 balance in his client's favour.


-----

**The facts**

5. It is alleged that on 23 December 2019 in Beselidhja Street the Appellant and another person (called
Renalto Haspepa) had an altercation with two others (called Roland Billa and Denis Billa). It was alleged
that during the incident the Appellant pulled out a pistol and hit Denis Billa with it, such that he required
medical treatment. In other words he was accused of 'pistol-whipping' Mr Billa. However the matter was
investigated and he was never ultimately charged with any assault. Instead on 8 June 2020, the
prosecution concluded the investigation and asked the District Court of Tirana to send the case to trial on
just one count, namely illegal possession of firearms and ammunition.

6. On 29 December 2020 the Applicant was found guilty of that offence.  The Court found in its judgment
that the Appellant had used violence during the incident. On 29 December 2020 he was sentenced to
two years' imprisonment.

7. The defence lodged an appeal on 12 July 2021. The appeal was based, amongst other things, on the
fact that the ballistic report established that fingerprints on a gun found in someone's garden did not match
the Appellant's fingerprints. It also pointed to what were said to be further significant absences and
inconsistencies in the evidence.

8. However, importantly for present purposes, in addition to the defence appeal, as I have said, the
prosecution also appealed proposing that a sentence of immediate custody could not lawfully be
imposed. The prosecution appealed on the fact that, as a matter of Albanian law, the sentence had been
passed, in its words, based on a 'MISTAKE' (sic):

This appeal is made to correct a “MISTAKE” by the Prosecutor of the case in the final inquiries and a
“MISTAKE” by the Court in its decision no. 2884 dated 29.12.20 20, where the sentence is treated in the
old form of Article 278/1 of the Criminal Code, while in the new form, which covers as event, it is provided
a minimum of 5 years of imprisonment.

Thus, there is an obligation to correct such MISTAKE and the only legal mechanism left at this
stage of the criminal proceedings is an Appeal to the Court of Appeals of Tirana against the decision of the
Court, in order to restore the legal parameters at the specific time of the event.

…

I REQUEST

     - Changing of the criminal decision no. 2884 dated 29.12.20 20 of the Judicial District Court of Tirana by
declaring guilty the citizen Hasan KOCEKU for article 278/1 of the Criminal Code and his punishment
of 5 years of imprisonment, applying article 406 of the Criminal Procedure Code; to be finally sentenced
to 3.4 years of imprisonment and by suspending this sentence of imprisonment according to the
provisions of article 59 of the Criminal Code with 4 years of probation period. “

9. As at the date of this judgment the appeals have not been heard.

**The district judge's judgment**

10. DJ Clews handed down judgment on 18 April 2023. He carried out the required _Celinski_
balancing exercise between [57] and [58] and found extradition was proportionate for the reasons set out
between [59] and [76].

11. One of the factors that he found in favour of extradition was that 'The RP is wanted in Albania for
involvement in a serious offence in which he possessed a firearm and significant violence was used.'

12. One of the factors he found weighing against extradition was:

“The RP is convicted of the offence but sentence (and possibly the conviction) will be reconsidered. The
prosecution are suggesting a suspended sentence.”

13. In his reasons, he said:


-----

“62. The public interest in this case is very high and in the circumstances any counter balancing factors
would have to be truly compelling, and exceptionally so, for the public interest to be outweighed.

…

64. In this case, there is nothing out of the ordinary in the factual matrix. The practical effect of extradition,
whilst unwelcome, would not be significant and it is simply impossible to say there is any aspect of the
case either taken singly or in combination with other factors that would render extradition disproportionate.
I cannot decline to extradite on Article 8 grounds.”

14. He added at [76]:

“I make it clear that I send the case to the Secretary of State on the explicit understanding the RP's appeal
will be heard in Albania.”

**The test on appeal**

[15. The test for allowing an appeal under Part 2 of the Extradition Act 2003 (EA 2003) is set out in s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1C9-00000-00&context=1519360)
104(2)-(4). The High Court can only allow an appeal if the first instance judge, 'ought to have decided a
question before him … differently', and had s/he done so, it would have required him/her to discharge the
defendant.

16. The question for this Court is whether the decision of the district judge was 'wrong': _Love v_
_Government of the United States [2018] 1 WLR 2889, [25]-[26]; Celinski v Polish Judicial Authorities [2016]_
1 WLR 551, [24]. In Love, Lord Burnett CJ said:

“25. The statutory appeal power in section 104(3) permits an appeal to be allowed only if the district judge
ought to have decided a question before him differently and if, had he decided it as he ought to have done,
he would have had to discharge the appellant. The words "ought to have decided a question differently"
(our italics) give a clear indication of the degree of error which has to be shown. The appeal must focus on
error: what the judge ought to have decided differently, so as to mean that the appeal should be allowed.
Extradition appeals are not re-hearings of evidence or mere repeats of submissions as to how factors
should be weighed; courts normally have to respect the findings of fact made by the district judge,
especially if he has heard oral evidence. The true focus is not on establishing a judicial review type of error,
as a key to opening up a decision so that the appellate court can undertake the whole evaluation afresh.
This can lead to a misplaced focus on omissions from judgments or on points not expressly dealt with in
order to invite the court to start afresh, an approach which risks detracting from the proper appellate
function. That is not what _Shaw or_ _Belbin was aiming at. Both cases intended to place firm limits on the_
scope for re-argument at the appellate hearing, while recognising that the appellate court is not obliged to
find a judicial review type error before it can say that the judge's decision was wrong, and the appeal
should be allowed.

26. The true approach is more simply expressed by requiring the appellate court to decide whether the
decision of the district judge was wrong. What was said in Celinski and Re B (A Child) are apposite, even if
decided in the context of article 8. In effect, the test is the same here. The appellate court is entitled to
stand back and say that a question ought to have been decided differently because the overall evaluation
was wrong: crucial factors should have been weighed so significantly differently as to make the decision
wrong, such that the appeal in consequence should be allowed.”

17. The approach to Article 8 was summarized by Lady Hale in H(H) v Deputy Prosecutor of the Italian
_Republic [2013] 1 AC 338, [8]:_

“(1) There may be a closer analogy between extradition and the domestic criminal process than between
extradition and deportation or expulsion, but the court has still to examine carefully the way in which it will
interfere with family life.

(2) There is no test of exceptionality in either context.

(3) The question is always whether the interference with the private and family lives of the extraditee and
other members of his family is outweighed by the public interest in extradition


-----

(4) There is a constant and weighty public interest in extradition: that people accused of crimes should be
brought to trial; that people convicted of crimes should serve their sentences; that the United Kingdom
should honour its treaty obligations to other countries; and that there should be no “safe havens” to which
either can flee in the belief that they will not be sent back.

(5) That public interest will always carry great weight, but the weight to be attached to it in the particular
case does vary according to the nature and seriousness of the crime or crimes involved.

(6) The delay since the crimes were committed may both diminish the weight to be attached to the public
interest and increase the impact upon private and family life.

(7) Hence it is likely that the public interest in extradition will outweigh the article 8 rights of the family
unless the consequences of the interference with family life will be exceptionally severe.”

18. There was no dispute in relation to these principles.

**Submissions**

19. On behalf of the Appellant, Mr Ball submitted as follows.

20. Firstly, that that the district judge erred in his analysis of the public interest in favour of extradition.

21. Secondly, there are crucial factors the district judge should have weighed significantly differently
on the Appellant's side of the scales.

22. As to the first submission, Mr Ball said if this were a Part 1 case, then, further to s 21A(3)(b) of the EA
2003, there would be a statutory obligation on the court to consider the likely penalty.  Here, because of
the prosecution's appeal, that penalty is a suspended sentence. Whilst there is no equivalent to s
21A(3)(b) in Part 2, the same considerations which underpin should be taken into account in the Article 8
proportionality analysis.

23. He said the district judge had fallen into error in the following ways: (a) he said at [53], 'I do not think it
is appropriate for me to transpose the s 21A considerations into a Part 2 case when Parliament omitted s
21A (or an equivalent) from the court's consideration in Part 2 cases.' The Appellant was not arguing that
an equivalent to s 21A should be read into Part 2, merely that likely penalty was to be taken into account
in both Part 1 cases (under s 21A) and in Part 2 cases under Article 8; (b) the district judge erred in
observing that he 'simply [had] no way of knowing what a court in Albania would consider to be the
appropriate sentence.' He appears to have given no weight, and no regard, to the prosecutor's categorical
position that the sentence of immediate custody was a mistake and the lawful and appropriate sentence to
be passed, at least as far as the Prosecution are concerned, is a suspended sentence; (c) the judge
wrongly said that the Appellant was wanted for involvement in a serious offence, 'in which he possessed a
firearm and significant violence was used'. He was wrong because the Appellant was never charged with
an offence of violence; (d) the judge erred on the question of whether this is an accusation warrant or a
conviction warrant. At [5] he said 'the AW is a 'conviction' warrant and was issued in relation to an
investigation into two offences in Albania.' This was wrong, and was not corrected by his subsequent
observations at [11] that this is an accusation warrant. It undermines the degree of confidence the
Appellant has that the judge has properly directed himself; (e) the district judge failed adequately or at all to
take into account the delay in hearing the prosecution's appeal in Albania.

24. In relation to the second submission, Mr Ball said that the Applicant relies on fresh evidence. The
district judge's decision was 18 April 2023.  On 3 August 2023 the SCA found that there were Conclusive
Grounds that the Appellant was a victim of modern slavery. He relies on this as proving his vulnerability.
The fact that he has been found to be a victim of trafficking is an obviously relevant and material
consideration in an assessment of the proportionality of an interference.

25. In addition to this, Mr Ball said there are a number of factors which the District Judge should have
weighed significantly differently: (a) his father and uncle had been killed in a blood feud when he was a
young child, which gives him particular fears in being extradited; (b) he has moderate depression and is a


-----

high suicide risk; (c) he was groomed in Albania, and approached when in the UK; (d) he has a strong and
established private and family life in the UK.

26. On behalf of the Respondent, Ms Bostock submitted as follows.

27. Her headline submission was that Article 8 was raised at first instance and fully considered by the
district judge and that he did not err in his overall conclusion that extradition would not be a
disproportionate interference with Article 8.

28. Ms Bostock accepted that the Appellant's conviction has not yet been confirmed as there is an
outstanding appeal by both the defence (conviction) and the prosecution (sentence). She accepted that,
within the prosecution document, an amendment to the sentence is suggested (on the basis of incorrect
legislation/minimum sentence having been applied by the Court) and that a suspended sentence (three
years and four months' imprisonment, suspended for four years' probation) is proposed by the prosecuting
authorities. The need for this is outlined in the prosecution application dated 11 January 2021 in the final
three paragraphs, which note that a minimum sentence of 5 years' imprisonment should have been applied
following which appropriate reductions would have resulted in a sentence of 3.4 years imprisonment. She
said that presumably due to this increase, the prosecution therefore suggests the sentence is suspended.

29. Also by way of preliminary submission, Ms Bostock said I should not admit the Conclusive Grounds
decision under the principles in _Szombathely City Court v Fenyvesi_ _[2009] EWHC 231 (Admin). She_
accepted that it was not available before the district judge but said it was not decisive. She pointed to its
brevity. It simply says 'it is accepted that you were a victim of **_modern slavery in the UK during_**
approximately 2019'. She said this finding was inconsistent with the Appellant's evidence, which was he
had had nothing to do with the trafficking gang after his arrival in the UK.  She also relied on R v Brecani

_[2021] EWCA Crim 731, [40], [43], which said that Conclusive Grounds decisions cannot be relied on as_
expert evidence at criminal trials, having in general been made by junior civil servants, and that 'The
conclusive grounds decision … is a statement of opinion based upon the decision maker's evaluation of the
evidence placed before her'.

30. Ms Bostock pointed out that the judge said, having heard the Appellant give evidence (and having
disbelieved him) that, _'On the evidence I heard, I cannot accept he was trafficked and I am sure he is a_
fugitive from Albanian justice who knowingly and deliberately placed himself beyond the reach of the
Albanian authorities.' Given this, the opinion of a junior civil servant in the Conclusive Grounds decision
was irrelevant and incapable of affecting the Article 8 balancing exercise.

31. She said the judge had correctly directed himself on Article 8 by reference to the authorities at [54]
[56]. He had then set out the relevant factors for and against extradition.

32. In relation to the errors suggested by Mr Ball under his first heading, she said that there were either no
errors, and/or that in any event they were incapable of affecting the balancing exercise. For example, in
relation to the s 21A point, the judge had been right not to read an equivalent provision into Part 2 (when
Parliament had intentionally not done so) but in any event he had taken the potential sentence into
account.

33. In relation to the second part of Mr Ball's submissions, Ms Bostock said that the Conclusive Grounds
determination should not be admitted for the reasons given earlier, and that otherwise all of the points
relied upon had been dealt with properly by the district judge.

34. She said, overall, the factors in favour of extradition are strong: the offence is serious; the Appellant is
a fugitive, as the judge found and which has not been challenged; he lied to the Albanian court about why
he could not attend, as the district judge found at [25]; and his private life in the UK had been established
whilst he was a fugitive and knew the proceedings in Albania were continuing.

**Discussion**

35. Despite the unusual feature of this case, namely the prosecution's stance on its sentence appeal, for
the substance of the reasons advanced by Ms Bostock, and the following reasons, I am not persuaded that


-----

the judge erred in relation to Article 8 in a way which could lead me properly to conclude that he ought to
have decided that issue differently, and so discharged the Appellant.

36. In relation to the s 21A point, the judge was obviously right in his approach when he said at [53] that
he could not transpose s 21A into Part 2 when Parliament had not done so.  But the judge did expressly
take the likely penalty into account when he came to Article 8, as I indicated earlier. The likely penalty is
the factor to be taken into account in relation to proportionality in a Part 1 case by virtue of s 21A(3)(b).
The judge therefore, in effect, applied an analogous approach to s 21A.

37. I also do not think that the judge's approach to the prosecution's appeal can be faulted.  Whilst the
prosecution in Albania has clearly set out what its view of the appropriate penalty is, it is also right that the
Albanian court is not bound to accept the prosecution's view. In exactly the same way in this country,
whilst in sentencing submissions the prosecution sets out its view as to where the offence sits within the
relevant Sentencing Guideline, this is not binding on the sentencing judge, who has to reach his or her own
determination.  Furthermore, as Ms Bostock pointed out, there is a five year minimum penalty. I do not
consider that there is anything in the point made by Mr Ball that the judge failed to have the requisite
'mutual trust and confidence' to the judgment of the independent Albanian prosecutor. The judge accepted
that the prosecution's position was as it is expressed to be, and has been put forward in good faith on the
appeal.

38. Mr Ball relied on Celinski, [11], where the court said 'the independence of prosecutorial decisions must
be borne in mind when considering issues under article 8.' But when that _dictum_ is read in context, it is
plain that the sort of decision in question is the decision to prosecute. That is for the prosecutor and not
the judge, whatever he or she thinks of the merits of the decision. The same is not true in relation to
sentence, as I have explained. The decision on sentence is for the court, and not the prosecutor.

39. Although the prosecution's stance on this appeal does make it unusual as Mr Ball submitted, in the
end I do not think that it weighs particularly heavily against extradition in the way Mr Ball submitted. The
judge took it into account and gave it appropriate weight. As the judge rightly noted at [52], in Miraszewski
_v District Court in Torun, Poland_ _[2014] EWHC 4261 (Admin), the leading case on s 21A, it was said at [39]_
that the likelihood of a non-custodial sentence did not preclude a judge from deciding that extradition would
be proportionate.  (The judge in this case, perhaps generously to the Appellant, said he regarded a
suspended sentence as a non-custodial sentence. In England, the relevant Sentencing Guidelines make
clear that a suspended sentence is a custodial sentence). Overall, the Appellant is perhaps fortunate in
the stance the prosecution is taking in Albania, given that the offence has a five year minimum term. But
the offence is undeniably serious, and a suspended sentence is not axiomatically devoid of utility or public
good, as Mr Ball suggested in his Skeleton Argument at [26].

40. Next, I do not think the judge was wrong to find that significant violence was used during the offence,
on the basis that the Appellant was not tried for a violent offence, but only with possession of a firearm and
ammunition. Mr Ball said it had been 'unfair and prejudicial' for the judge to have done so. I disagree.
The allegation of violence was in the initial arrest warrant from January 2020.  The judgment of the Judicial
District Court of Tirana dated 29 December 2020 found that the Appellant had used violence during the
altercation with his victims, even though he was not ultimately tried with such an offence. The Court
treated the violence as part of the factual matrix in which the charged firearms offence had been
committed. Much the same approach might be taken by an English court under the bad character
[provisions of the Criminal Justice Act 2003, s 101(1)(c) and s 102 (important explanatory evidence).  The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-F0X0-TWPY-Y08W-00000-00&context=1519360)
district judge therefore did not err and was entitled to take the violence into account as part of his
assessment.

41. Next, I accept that the judge was inconsistent as describing the warrant in the request as being both a
conviction warrant and an accusation warrant (cf [5], [11] and [60] of his judgment).  It is clear that the
decisions of the Albanian prosecutor of 28 January 2020 and 30 January 2020 were accusation warrants.
But I also consider Ms Bostock was right to say that the judge's error was not of any significance. It did not
affect his Article 8 assessment in any material way, or even at all. The judge said at [60], 'It helps the RP's
case that this is now to be treated as an accusation warrant, and he has no previous convictions.'


-----

42. Lastly, there is nothing in the delay point.  The period involved is not significant and the Appellant is a
fugitive. There is nothing to suggest that Albania has been intentionally deleterious. The delays in hearing
the appeals is no doubt due to the demands on the Albanian court system. Delays in cases coming to
court is not unknown in this country.

43. Turning to Mr Ball's submissions under his second heading, I agree with Ms Bostock in relation to the
Conclusive Grounds decision in the Appellant's favour. However such decisions are properly to be
regarded (and I set out the case law earlier), the decision in this case is simply too brief to be of any
assistance.  It is the opinion of a civil servant expressed in one line, which even despite its brevity appears
to be inconsistent with the case which the Appellant advanced before the district judge.   It is certainly
nowhere near decisive, and I decline to admit it.  I cannot readily see how what happened (or did not
happen) in the UK after his arrival here can have any bearing on the question of whether extradition would
be Article 8 disproportionate.

44. In relation to the alleged blood feud and the murder of the Appellant's father and uncle in 1997 and
1994 respectively, I consider the judge dealt properly with it. He rightly noted at [48], whilst painful to
recall, 'they occurred many years ago'. The district judge was not satisfied that the blood feud was
continuing ([35]). He described the Appellant's evidence about it as 'self-serving'. The murder of his father
and uncle occurred almost 30 years ago and, as Ms Bostock submitted, whilst one can (and should) have
sympathy, they have no real relevance to the Article 8 balancing exercise, and certainly not for an offence
of the gravity of that which the Appellant is accused of. The district judge did not err by failing to give this
factor more weight.

45. I also consider that the judge dealt with the evidence about the Appellant's mental health properly. He
dealt fully with the medical evidence at [26]-[33].   He listed it as a factor against extradition ('He is
struggling psychologically, with the prospect of extradition and has a 'depressive episode' with an elevated
risk of suicide … I take account of the RP's anxiety. I also take account of Dr Singh's report, albeit with the
reservations referred to above.'). It is therefore not arguable that the judge's overall Article 8 determination
is undermined because the judge should have given this factor more weight. It was the Appellant's own
evidence that his depression was directly linked to these extradition proceedings (at [29]) and this was also
the conclusion of the psychiatrist, who simply suggested an adjustment in medication. The district judge (at

[37]), having seen the Appellant give evidence, was not persuaded that he had not exaggerated his
symptoms to the psychiatrist (who had seen no medical notes and noted this to qualify his opinion).

46. Finally, in relation to the Appellant's private life, in my judgment the judge dealt properly with it at [63]
and [64] and gave it appropriate weight. He acknowledged the adverse effect on the Appellant's family it
would have, but rightly said that that was commonplace, and at [64] said that it would not be significant.
The fact is, as Ms Bostock said, that he established his private life here as a fugitive knowing there was
always the risk of proceedings in Albania catching up with him.  She said (Skeleton Argument, [45]) and I
agree:

“The reality of the Appellant's private life is that he entered the UK illegally, has no right to remain here and
has been hiding from Albanian justice here ever since. As the District Judge found, in those circumstances
and given the gravity of this offence, this is plainly a case where extradition is proportionate and the appeal
should be dismissed.”

**Conclusion**

47. Despite Mr Ball's able submissions, this appeal is dismissed.

**End of Document**


-----

