# R v Haslam [2024] EWCA Crim 404

Court of Appeal, Criminal Division

Lord Justice Dingemans, Mr Justice Wall, The Recorder Of Norwich, Her Honour Judge Alice Robinson (Sitting As
A Judge Of The Cacd)

20 February 2024Judgment

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

MR B HOLT appeared on behalf of the Attorney General

MISS R SMITH appeared on behalf of the Offender

_________

**J U D G M E N T**

(Approved)

LORD JUSTICE DINGEMANS:

**Introduction**

1. This is the hearing of an application on the part of His Majesty's Solicitor General for leave to refer sentences
imposed on 22 November 2023. The sentences were deferred sentences imposed for three counts of possession
of class A drugs (cocaine, heroin and crack cocaine) with intent to supply and one count of possession of criminal
property. The offences were committed on 17 August 2023. His Majesty's Solicitor General considers those
sentences to be unduly lenient.

2. A deferred sentence is a sentence which may be the subject of a Reference: see _R v Ferreira_ _[[2021] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62FR-HRR3-GXFD-83Y0-00000-00&context=1519360)_
_[Crim 537 at paragraph 23. We grant leave. This is because the Reference raises issues about the imposition of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62FR-HRR3-GXFD-83Y0-00000-00&context=1519360)_
the statutory minimum period of 7 years imprisonment for three class A drug trafficking offences on a person found
by the judge to be developmentally a child.

3. The respondent is Ryan Haslam, who is aged 19 years and three months, having been born on 12 November
2004. He was aged 18 years and 9 months as at 17 August 2023. Mr Haslam had, before the sentences the
subject of this Reference, five previous convictions for 14 offences. This included offences committed on 7 April


-----

2022 (possession of a class B drug, possessing a knife and assaulting an emergency worker). Mr Haslam was
convicted on his plea of guilty on 9 June 2022 of a conspiracy to supply class A drugs on dates between 1 October
2020 and 2 February 2022 when he was aged between 15 years 11 months and 17 years and three months. He
was sentenced on 4 August 2022 to a youth rehabilitation order with two years supervision for the April 2022
offences and the offences for which he had pleaded guilty in June 2022.

4. On 10 January 2023 Mr Haslam committed two offences of possessing class A drugs (crack cocaine and heroin)
with intent to supply. On 22 May 2023 he was sentenced to a community order with an electronic curfew and
rehabilitation activity requirements. It was common ground that given the timing of the respective earlier offences,
as a result of his further three convictions for possessing class A drugs with intent to supply on 17 August 2023, that
unless there were exceptional circumstances Mr Haslam should have received a minimum custodial sentence of
seven years before discount of a maximum of 20 per cent for a guilty plea.

**The issues**

5. It is submitted on behalf of the Solicitor General that there were in fact no exceptional circumstances and the
judge was therefore wrong to defer the sentence. An immediate sentence of seven years less discount of 20 per
cent should be imposed. Mr Holt on behalf of the Solicitor General submitted that even if there were exceptional
circumstances because of the judge's findings relating to Mr Haslam's developmental age, a deferred sentence was
still unduly lenient because a period of immediate imprisonment was required because of Mr Haslam's offending
and past offending.

6. It is submitted on behalf of Mr Haslam that there were exceptional circumstances so that he should not receive
the statutory minimum sentence of 7 years less 20 per cent discount for plea. This was because, as the judge
found, while technically an adult, Mr Haslam was operating as a juvenile. Miss Smith submitted that this was the
particular factor relating to Mr Haslam which justified the finding of exceptional circumstances in this particular case,
given that there was that offence that triggered the mandatory minimum terms. Mr Haslam, it was submitted,
satisfied almost every factor which might heighten a person's vulnerability to exploitation according to the Home
Office Guidance on Criminal Exploitation of Children and Vulnerable Adults. Mr Haslam was at a crossroads and
the judge was right to see whether a deferred sentence would provide clarity as to which path Mr Haslam might
take.

7. We are very grateful to Mr Holt and Miss Smith for their helpful submissions.

**These offences**

8. At 13.22 hours on 15 August 2023 police officers gained entry to 1 Higher Barley Mount in Exeter. Mr Haslam,
who was present, attempted to flee the property by running out into the back garden. He was detained and
arrested. He was also arrested with another male, Finley Walsh.

9. Mr Haslam was searched and items were seized. One item was split into four packages. That was 90 white
plastic knotted wraps containing crack cocaine, 20 white plastic knotted wraps and 15 translucent plastic knotted
wraps of brown powder. One of the white wraps was tested and found to be 0.14 grams of crack cocaine. One of
the translucent wraps was weighed and found to be 0.11 grams of heroin and one larger white plastic knotted wrap
was 0.6 grams of what appeared to be crack cocaine. There was another translucent plastic knotted wrap of brown
paper which was 0.6 grams of crack cocaine. Another item was split into three packages: one of cocaine and two
of heroin. There was also the finding of cutting agents and two sets of digital scales. There was cash and coins
totalling £148.70.

10. At Mr Haslam's home address there was a machete in a sheath and what the prosecution submitted was
designer or brand clothing totalling £1,000. It was submitted on behalf of Mr Haslam that some of that had been
provided by the local authority or his personal adviser for his use.

11. A drug expert witness provided a statement dealing with the street value of the drugs. The street value was
£17,730 and the wholesale value was some £7,830.


-----

12. Mr Haslam was interviewed on 16 August but he did not answer any questions.

13. At a first appearance on 17 August 2023 Mr Haslam pleaded guilty to the four charges and was therefore
entitled to full credit for pleas and he was committed to the Crown Court for sentence.

**Mr Haslam's background**

14. It is apparent from the terms of a pre‑sentence report that Mr Haslam has had many difficulties in life. Mr

Haslam and his twin brother were born to drug‑addicted parents. They experienced methadone withdrawal as

young children. Mr Haslam had foetal alcohol syndrome. He was subjected to chronic neglect in between periods
of care. At the age of three he was recorded to have climbed a wall with a needle which had been used by his
parents to take drugs.

15. He was removed from his parents at the age of nine and given to the care of relatives. The relatives found it
difficult to care for Mr Haslam because of his aggression. He was placed in care and he was then excluded from
school and he has had no formal education since the age of 10.

16. He was placed in foster care in Exeter but there were concerns that he had a drug debt to a drug dealer and
was at risk of being drawn into county lines drug dealing.

17. He was moved at the age of 13 to Bradford but he visited Devon in Easter 2018 when he was still 13 and he
saw his mother after a long period of separation. He wrote a letter to her asking questions in June 2018 but it was
not sent because a social worker was on leave and in July 2018 his mother died because of a suspected drug
overdose.

18. Reports completed in secure welfare units, to which Mr Haslam was sent, showed that he had been violent and
verbally threatening. He had shown signs of improvement in 2021 but there remained anger management issues.
Other reports showed that Mr Haslam had no resilient personality traits and he was at risk of exploitation.

19. There is a Reasonable Grounds Decision by the Single Competent Authority that Mr Haslam is a victim of
**_modern slavery but a Conclusive Grounds Decision was awaited at the time of deferral of sentence and is still_**
awaited. Modern slavery was not raised as a defence to these offences because, we were told and accept, Mr
Haslam was not prepared to cooperate with providing details of a defence, but it was relied on to show that he had
been exposed to exploitation and grooming.

20. An updated report for sentencing prepared by Emily Coleman, a probation officer, showed that something
changed in August 2023 when after 10 months of consistent work to engage with Mr Haslam, he began attending
appointments without so much resistance and he would stay in appointments for up to an hour. He was reported to
have softened in his manner and started to open up more about his feelings. Miss Coleman reported: "We started
to explore his childhood relationships and experiences" and she reported: "Mr Haslam is an intelligent and likeable

young man when he allows his barriers to come down. It seems due to his early experiences he is hyper‑vigilant

and views all new people as a potential threat unless they prove otherwise." Miss Coleman recorded that any
resistance to engage initially was a consequence of these perceptions rather than a lack of respect for the order in
place. Miss Coleman reported that over the past three weeks before the report he had begun to withdraw and she
had not seen him face to face but he had stayed in touch every week by phone and had seen his personal adviser.

**The sentencing**

21. It was submitted before the sentencing judge by the prosecution that the appropriate culpability category was
significant because an expectation of substantial financial advantage was present and there was some awareness
of the scale of the operation. The prosecution submitted that the harm category was 3, selling directly to street
users, and that would have given a starting point of four years six months and a range of three years six months to
seven years' custody.


-----

22. It was submitted on behalf of Mr Haslam that with grooming and immaturity he fell within a Category 3 lesser
role. That would have given a starting point of three years and a range of two years to four years six months. In
many respects that was completely academic unless there was a finding of exceptional circumstances because, as
already indicated, Mr Haslam faced a mandatory minimum sentence of seven years, less the discount for plea of 20
per cent.

23. During the sentencing hearing the judge asked whether the Crown accepted, on the basis of the materials, that
although technically an adult Mr Haslam was operating as a juvenile. Counsel for the Crown accepted that
proposition.

24. It was argued on behalf of Mr Haslam that he was really the victim of **_modern slavery and had not had a_**
choice but to deal drugs and the judge discussed those considerations. The judge remarked that counsel was
pushing at an open door in saying that young people do not have a choice in certain circumstances. It was
submitted that Mr Haslam was at a turning point and information was provided orally to the court from Mr Haslam's
leading care worker. Miss Susan O'Leary, who had been working with Mr Haslam for about two years gave
evidence and she noted that Mr Haslam was finally showing some trust in people.

25. The judge recorded: "... it strikes me, each of these Defendants, on everything I've read, are modern slaves ... "
The judge found that there were exceptional circumstances for Mr Haslam given his age, the judge's findings on
grooming and Mr Haslam's personal background.

26. The judge deferred sentence saying that he hoped the Attorney General would not refer the deferral of
sentence to this court, but the Reference has been made.

27. On 22nd November 2023 Mr Haslam was sentenced to a deferred sentence with the following requirements: no
offences to be committed, comply with the requirements of social services or probation, retain accommodation, try

to obtain employment and a full assessment with a psychologist ‑ the latter being a hope not an expectation. The

deferred sentence is currently scheduled to be heard on 17 May 2024.

**Developments since the deferral of sentence**

28. A progress report for the Court of Appeal Criminal Division has been produced by Emily Coleman. This
repeated the information about Mr Haslam's trauma in early life and the challenges of engaging with Mr Haslam.
Miss Coleman said that Mr Haslam had come a long way in engaging with his order after months of relationship
building. He had had a push/pull approach to engagement and a lack of trust. The change reported to the court in
sentencing below in August 2023 was referred to but it was said:

"Since Mr Haslam's deferred sentence on the 22/11, I have only seen him in person on two occasions. Mr Haslam

continues to have a 'push‑pull' approach in his relationship with me and I do feel the relationship between us,

although is far better, is extremely fragile. I continue to use a trauma informed approach in my management of Mr
Haslam and make professional judgements each week. If Mr Haslam does not attend his weekly appointment, he
will generally keep in touch via the phone or he will see his personal advisor ... which means I am able to gather an
update from her. I had hoped Mr Haslam would be more committed to ensuring he attends every week, knowing he
needs to fully comply before being sentenced in May.

I would currently say Mr Haslam's compliance has remained the same as before the deferred sentence was given. I
have issued Mr Haslam a first warning this week with the hope to remind him of his responsibility to make more

effort to engage. I do feel Mr Haslam 'self‑sabotages' a great deal and almost sets himself up to fail. At times he will

overcome this, attend his appointment on time and engage well. However, the following week he won't attend and
suggest I just 'breach him' because his comfort zone is things not going well. I feel custody would be a 'terrifying'
prospect for Mr Haslam and could possibly contribute to further traumatising him which concerns me."

29. The report writer concluded that Mr Haslam had been targeted and groomed by those further up the chain and
his need for belonging and acceptance made him a target. Miss Coleman considered that Mr Haslam had huge


-----

potential and that support was there if he wanted to change but if he did not a custodial sentence whatever the
impact on him was inevitable.

30. It is therefore apparent that Mr Haslam has not complied with the conditions of the deferral of his scheme,
namely that he complies with all the requirements of the probation service.

**_[Section 313 of the Sentencing Act 2020](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5XD3-CGXG-02VV-00000-00&context=1519360)_**

31. Section 313 of the Sentencing Act 2020, is headed "Minimum sentence of 7 years for third class A drug
trafficking offence". Section 313 applies where a person is convicted of a class A drug trafficking office, and when
the offence was committed, the offender “… (i) was aged 18 or over, and (ii) had 2 other relevant drug convictions,
and (c) one of the offences to which those other relevant drug convictions related was committed after the offender
had been convicted of the other”. The section, as amended by the _[Police, Crime, Sentencing and Courts Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F9-MJP3-GXF6-80DM-00000-00&context=1519360)_
_[2022,now provides that where the relevant drug trafficking offence was committed after 28 June 2022 (and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F9-MJP3-GXF6-80DM-00000-00&context=1519360)_
relevant offence in this case was committed on 17 August 2023) the court must impose an appropriate custodial
term of 7 years “unless the court is of the opinion that there are exceptional circumstances which (a) relate to any of
the offences or to the offender; and (b) justify not doing so”.

32. It might be noted that the statutory provisions require the last index offence to have been committed when the
offender was over the age of 18 but the first two qualifying convictions may be committed by the offender when he
is under the age of 18. It is not apparent that Parliament contemplated a person becoming, what Mr Holt referred to
as, "a third striker" at the age of 18 years.

**Relevant guidance on exceptional circumstances**

33. The definitive guideline for drug offences provides that the following principles apply to exceptional
circumstances. First, that the circumstances must be truly exceptional such as would result in an arbitrary and
disproportionate sentence if the maximum mandatory minimum sentence was applied. Secondly, that the court
should adhere to the statutory requirement and not too readily accept that the circumstances are exceptional. A
factor is unlikely to be regarded as exceptional if it would apply to a significant number of cases. Thirdly, the court
should consider all of the circumstances of the case. The seriousness of the previous offences and the period of
time that has elapsed will be relevant. Fourthly, the presence of one or more of the following factors should not in
itself be regarded as exceptional: one or more lower culpability factors, one or more mitigating factors or a plea of
guilty.

34. The same statutory wording relating to exceptional circumstances, albeit in relation to the mandatory minimum
sentence for firearms, was considered in _R v Nancarrow_ _[[2019] EWCA Crim 470, [2019] 2 Cr.App.R (S) 4. The](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V4C-8522-8T41-D45M-00000-00&context=1519360)_
court reminded sentencers that the purpose of mandatory minimum terms was to deter. It would be exceptional if
the resulting sentence would be arbitrary or disproportionate. Sentencers should not undermine the intention of
Parliament by accepting too readily that circumstances are exceptional. There should be a holistic approach. The

health of an offender may be relevant and each case is fact‑specific.

**Children and young people**

35. The Sentencing Council Guideline for Sentencing Children and Young People records that when sentencing
young people a court should have regard to the fact that the principal aim of the youth justice system was to prevent
offending by children and young people and the welfare of the young person and that maturity was as important as
chronological age. A court should be alert to traumatic life experiences and the effect on young people of loss,
neglect and abuse. Attaining the age of 18 years is not a cliff edge for the purposes of sentencing.

**This sentence**


-----

36. First it is apparent, as the judge below remarked, that illicit controlled drugs destroy society. Useful members
of society cease to function, they begin to look no further than their next drug taking, they commit acquisitive crime,
some develop mental disorders and some become violent. Those who deal in drugs spread this misery.

37. Secondly, it is clear that Mr Haslam was not only chronologically young but he was also immature and had no
formal education. He had had the most difficult of childhoods, starting from his birth to two drug addicts, proving yet
again the damage caused by drugs to society, and the judge made a finding of fact that he had been groomed by
others who identified his need for approval.

38. Thirdly, it is apparent that the judge found exceptional circumstances on the basis of Mr Haslam's age, his
grooming and his personal background.

39. Mr Haslam was an adult when he committed the offence which triggered the mandatory minimum seven year
sentence, less discount for plea, unless exceptional circumstances justified not doing so. The requirement for the
last offence to be committed when aged over 18 is not a requirement for the first two qualifying offences. On the
other hand, it is apparent that the requirement for the last offence to be committed as an adult means that a finding
made by the judge that Mr Haslam was operating as a child is significant. The finding made in this case was a
finding made on evidence heard by the judge, rather than one made simply on the papers or on the basis of a
report without hearing the report writer. A finding of fact by a judge will not be set aside by this court unless it is
internally inconsistent, inconsistent with some uncontroverted fact or is irrational. Here there is nothing pointed to
by Mr Holt to show that the finding could be set aside by this court. Indeed counsel for the Crown at the sentencing
hearing at first instance accepted that Mr Haslam was operating as a child or juvenile.

40. The judge's finding of fact that Mr Haslam was operating as a juvenile and developmentally a child cannot
therefore be set aside by this court. The question therefore for us is whether giving this finding, it would be
disproportionate to impose a sentence of seven years less 20 per cent on Mr Haslam. In our judgment it would be
disproportionate to impose such a sentence. This is because the judge found that Mr Haslam, although aged 18
years 9 months was in fact operating as a child at the time that he committed the final and relevant offence, and the
statutory regime is addressed at adults. We consider that the circumstances giving rise to this type of situation are
likely to be very rare indeed. It is very unusual to find a person of Mr Haslam's age who is 'a third striker', and even
more unusual to find that they have the background developmental difficulties in this case. This means that the
Reference fails on its main ground.

41. We have noted Mr Holt's fallback position, namely that Mr Haslam should be sentenced to a sentence of
immediate imprisonment even without the statutory minimum period applying. We consider that this must be for the
sentencing judge to address in the first instance. The judge has deferred the sentence and was, in our judgment,
entitled to find that there were exceptional circumstances to enable him to do so. The judge when hearing the
deferred sentence can then decide whether Mr Haslam should receive a sentence of immediate imprisonment,
albeit one likely to be less than the mandatory minimum period. We do record that Miss Smith's submissions that
Mr Haslam had done all that the judge had asked him to do when deferring sentence is, at the current time, not a
submission that we can accept. That is because one of the requirements was to comply with the requirements of
the probation service and it is apparent from the information before us that Mr Haslam has not engaged for long
periods with the probation services. We were told that things might have changed in February 2024. Those are
matters for the judge to deal with at first instance.

42. For all those reasons, although we have granted leave for this Reference, we dismiss it.

43.  Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground Floor, 46 Chancery Lane, London, WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk


-----

**End of Document**


-----

