# *R v Joseph and others (Anti-Slavery International intervening) [2017] All ER
 (D) 100 (Feb)

[2017] EWCA Crim 36

Court of Appeal, Criminal Division

EnglandandWales

Lord Thomas CJ, Hallett VP and Goss J

9 February 2017

**Criminal law – Trafficking people for exploitation – Offences committed by victims of human trafficking – In**
**2015, statutory defence available to individuals claiming nexus between their trafficking and crime**
**committed – For individuals not falling within statutory defence, judiciary and Crown Prosecution Service**
**developing legal regime to give effect to United Kingdom's international obligations relating to non-**
**punishment of victims of human trafficking – Court of Appeal, Criminal Division, hearing conjoined appeals**
**and applications to clarify legal principles for individuals not having benefit of statutory defence – Modern**
**_Slavery Act 2015, s 45, Sch 4 – Council of Europe Convention of Action against Trafficking in Human_**
**Beings, art 26.**

**Criminal law – Prosecution – Decision to prosecute – In 2015, statutory defence available to individuals**
**claiming nexus between their trafficking and crime committed – For individuals not falling within statutory**
**defence, judiciary and Crown Prosecution Service developing legal regime to give effect to United**
**Kingdom's international obligations relating to non-punishment of victims of human trafficking – Court of**
**Appeal, Criminal Division, hearing conjoined appeals and applications to clarify legal principles for**
**individuals not having benefit of statutory defence – Modern Slavery Act 2015, s 45, Sch 4 – Council of**
**Europe Convention of Action against Trafficking in Human Beings, art 26.**
Abstract

_Criminal law – Trafficking people for exploitation. The Court of Appeal, Criminal Division, gave guidance on the_
_legal regime relating to those not within the scope of the Modern Slavery Act 2015 who faced charges, but who_
_claimed there was a nexus between the crime with which they were charged and their status as victims of trafficking_
_for the purposes of exploitation._
Digest

The judgment is available at: [2017] EWCA Crim 36

From 2000, a series of international conventions were agreed to deal with the trafficking in humans for the purposes
of exploitation. Those conventions imposed on the United Kingdom obligations in respect of those trafficked. In
2009, on the ratification of one of the conventions, the government established a national referral mechanism and,
within the Home Office, what were named the Competent Authorities to determine whether those who claimed to
have been trafficked for the purposes of exploitation had in fact been trafficked. In 2015, Parliament made
comprehensive provision in respect of human trafficking by the enactment of the **_Modern Slavery Act 2015 (the_**
2015 Act) which was brought into force, as regards the material provisions, on 31 July 2015. Until the 2015 Act,


-----

there was no statutory provision which transposed into the law of England and Wales the obligations of the UK
under the international conventions towards those victims of human trafficking for the purposes of exploitation who
committed crimes in England and Wales, where there was a nexus between the crime committed and the
trafficking. In cases where the defence of duress was not likely to be applicable, it was left to the judiciary (utilising
the flexible nature of the common law in a series of decisions between 2011 to 2013) and to the Crown Prosecution
Service (the CPS) (through the exercise of their independent prosecutorial discretion) to develop a legal regime for
England and Wales in which the international obligations, as they successively developed, were given effect in the
domestic law of England and Wales. For those within the scope of the 2015 Act, the law was clearly set out in s 45
and Sch 4. Section 45 set out the conditions which had to be satisfied for a defence to arise respectively for adults
and children where there was a nexus between the trafficking and the crime committed. The offences to which the
defence did not apply were set out in Sch 4. For the future, the 2015 Act would, therefore, provide the legal
framework. However, as the 2015 Act was not drafted to provide retrospective protection, the regime that had been
developed by the courts would, subject to the interveners' submissions (see [24]-[26] of the judgment), continue to
apply to those not within the scope of the 2015 Act who faced charges, but who claimed there was a nexus
between the crime with which they were charged and their status as victims of trafficking for the purposes of
exploitation. The court heard conjoined appeals and applications made by six defendants who, save for the third
defendant, had been designated by the Competent Authority as victims of human trafficking sometime after their
convictions for a range of offences. The objective was to try and resolve issues on the guidance given in the caselaw in respect of those who did not have the benefit of the 2015 Act.

In rejecting the interveners' submissions that the existing approach relating to victims of trafficking should be
abandoned and a new approach for cases not covered by the 2015 Act should be adopted, the court set out the
legal regime in domestic law in giving effect to the UK's international obligations relating to action against trafficking
[in human beings, deriving from the judgments of R v LM ([2010] All ER (D) 202 (Oct)), R v N; R v E ([2012] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)
_[(D) 128 (Feb)) and R v L ([2014] 1 All ER 113). Further, three general issues arose, namely: (i) the relevance of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5513-TB01-DYBP-N1F7-00000-00&context=1519360)_
gravity of the offence; (ii) the position of a child victim; and (iii) the relationship between the Competent Authority
and the CPS. Consideration was given to art 26 of the Council of Europe Convention of Action against Trafficking in
Human Beings (art 26).

The court ruled:

(1) The obligation under art 26 was given effect in England and Wales through: (i) the common law defences of
duress and necessity; or (ii) guidance for prosecutors on the exercise of the discretion to prosecute (which had
been revised from time to time); or (iii) the power of the court to stay a prosecution for abuse of process (see [20(i)]
of the judgment).

_R v LM_ _[[2010] All ER (D) 202 (Oct) applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_

(2) In a case where: (i) there was reason to believe the defendant who had committed an offence had been
trafficked for the purpose of exploitation; (ii) there was no credible common law defence of duress or necessity; but
(iii) there was evidence the offence had been committed as a result of compulsion arising from trafficking, the
prosecutor had to consider whether it was in the public interest to prosecute (see [20(ii)] of the judgment).

_R v LM_ _[[2010] All ER (D) 202 (Oct) applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_

(3) The court's power to stay was a power to ensure that the state complied with its international obligations and
properly applied its mind to the possibility of not imposing penalties on victims. If proper consideration had not been
given, then a stay should be granted. However, where proper consideration had been given, the court should not
substitute its own judgment for that of the prosecutor (see [20(iii)] of the judgment).

_R v LM_ _[[2010] All ER (D) 202 (Oct) applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_

(4) Where the Court of Appeal, Criminal Division, concluded that the trial court would have stayed the indictment
had an application been made, the proper course was to quash the conviction (see [20(iv)] of the judgment).


-----

_R v LM_ _[[2010] All ER (D) 202 (Oct) applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_

(5) The obligation under art 26 did not require a blanket immunity from prosecution for victims of trafficking. Various
factors should be taken into account in deciding whether to prosecute; if there was no reasonable nexus of
connection between the offence and the trafficking, generally a prosecution should proceed. If some nexus
remained, then prosecution would depend on various factors including the gravity of the offence, the degree of
continuing compulsion and the alternatives reasonably available to the defendant. Each case was fact specific (see

[20(v)] of the judgment).

_R v LM_ _[[2010] All ER (D) 202 (Oct) applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:519V-BV41-DYBP-N4HP-00000-00&context=1519360)_

(6) The distinct question for decision in the case of a trafficked defendant was the extent to which the offences with
which he was charged (or of which he had been found guilty) were integral to or consequent on the exploitation of
which the person had been a victim. It was clear that such a decision was a fact sensitive one. The court could not
be prescriptive. In some cases, the facts would indeed show that the defendant was under levels of compulsion
which meant that, in reality, culpability had been extinguished. If so, when such cases were prosecuted, an abuse
of process submission was likely to succeed. In other cases, more likely in the case of a defendant who was no
longer a child, culpability might be diminished but nevertheless be significant. For those individuals, prosecution
might well be appropriate, with due allowance to be made in the sentencing decision for their diminished culpability.
In yet other cases, the fact that the defendant was a victim of trafficking would provide no more than a colourable
excuse for criminality which was unconnected to and did not arise from their victimisation. In such cases, an abuse
of process submission would fail (see [20(vi)] of the judgment).

_R v L_ _[[2014] 1 All ER 113 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_

(7) The reason why the criminality or culpability of a trafficked person was diminished or extinguished did not result
merely from age but in circumstances where there had been no realistic alternative available to the person but to
comply with the dominant force of another individual or group of individuals (see [20(vii)] of the judgment).

_R v L_ _[[2014] 1 All ER 113 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_

(8) The decision of the Competent Authority as to whether a person had been trafficked for the purposes of
exploitation was not binding on the court, however, unless there was evidence to contradict it or significant evidence
that had not been considered, it was likely that the criminal courts would abide by the decision (see [20(viii)] of the
judgment).

_R v L_ _[[2014] 1 All ER 113 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)_

(9) Regarding the first general issue on 'the relevance of the gravity of the offence': there would be graves crimes
where, taking into account all the circumstances, it was in the public interest to prosecute. The decision was always
fact sensitive (see [31] of the judgment).

(10) Regarding the second general issue on 'the position of a child victim': it was not necessary to prove
compulsion. Once it was established that a child had been a victim of trafficking for the purposes of exploitation, the
relevant consideration was whether there had been a sufficient nexus between the trafficking for the purposes of
exploitation and the offence; it was not necessary to go so far as to show there had been compulsion to commit the
offence required in the case of an adult (see [35] of the judgment).

(11) Regarding the third general issue on 'the relationship between the Competent Authority and the CPS': the
decision of the Competent Authority did not bind the court. Where there was an issue as to whether a person had
been a victim of trafficking for the purposes of exploitation whilst a prosecution was being considered or was in
progress, the CPS and police were able to refer to the Competent Authority the case of a person in respect of
whom there might be evidence of that person being a victim of trafficking. Provision was made in the guidance to
the Competent Authority for co-operation with the police and CPS in all cases before the conclusion of the
prosecution That co-operation had developed so that during the procedures for considering prosecution every


-----

effort was made to reach a common view on whether the evidence pointed to the person being a victim of
trafficking. That was plainly of the greatest importance, as the cogency of the evidence which might be relied on by
the Competent Authority had to be subject to thorough forensic examination when the CPS was considering the
question of nexus and whether it was in the public interest to prosecute. However, in respect of a person claiming
after conviction to be a victim of trafficking, there was no clear guidance on or process in respect of co-operation
with the CPS or in obtaining court documents. It would be desirable for much clearer guidance and processes to be
developed between the CPS and the Competent Authorities in cases where the claim to be a victim of trafficking
was made after conviction. It was important to appreciate that a court would bear the Competent Authority's
conclusion very much in mind but would examine the question of the cogency of the evidence on which the
Competent Authority relied and subject the evidence to thorough forensic examination. It did not follow from the fact
than an individual 'fits the profile' of a victim of trafficking that they were necessarily the victim of trafficking. A
careful analysis of the facts was required, including close examination of the individual's account and proper focus
on the evidence on the nexus between the trafficking and the offence with which they were charged (see [38]-[40] of
the judgment).

In the present cases, the first and second defendants' applications would be dismissed. The third defendant's
appeal against conviction, made upon a reference by the Criminal Cases Review Commission, pursuant to s 9 of
the Criminal Appeal Act 1995, would be dismissed. In the circumstances, his criminality or culpability had not been
extinguished or significantly reduced to such a level that he should not have been prosecuted in the public interest.
The fourth defendant's appeal against conviction would be allowed and his conviction quashed. On the basis of all
the facts presently known, it was satisfied that the prosecution would not have been pursued. Given the absence of
the fifth defendant, which prevented the court from being assisted on a number of key questions, the court declined
to hear his applications and adjourned them _sine die. The sixth defendant's appeal against conviction would be_
allowed and her conviction quashed. Not without very considerable hesitation, that was a case in which, on a review
of all the admissible material presently available, she should have been treated as a credible victim of human
trafficking and there had been a sufficient nexus of compulsion between her being trafficked and the commission of
the offences to justify the conclusion that, on investigation, the prosecution would have decided not to pursue the
prosecution (see [68], [98], [100], [125], [136], [144], [145], [160] of the judgment).

Per curiam: 'We would emphasise at the outset that each case is very heavily fact specific' (see [6] of the
judgment).

Per curiam: 'The present law of duress is clear. Its scope and limits are set out in cases of the highest authority.
Parliament has considered the position. It enacted s 45 [of the 2015 Act] without providing for retrospective
protection. In the circumstances it would require instances of clear injustice to justify a court amending the law of
duress as applicable to victims of trafficking who were not able to take advantage of the 2015 Act. We have seen no
evidence of such instances. The individual cases that were the subject of the decisions in 2010 to 2013 and the
appeals and applications being heard by us show that the law operates in practice in a way entirely consistent with
the UK's international obligations. We accept that the cases that the court has to consider are cases where the
issue as to trafficking often has arisen after the conviction. Changing the law of duress would not alter that type of
case. A court cannot grapple with the issue until it is raised; in some of the cases we are considering it was not
raised until after conviction. What has changed is a greater understanding of the position of victims and the need in
such cases to investigate. We see no reason to develop the law of duress in the way suggested [by the
interveners]' (see [28] of the judgment).

Henry Blaxland QC and Tom Wainwright for the first defendant.

Jessica Russell-Mitra for the second defendant.

Henry Blaxland QC and Michelle Brewer for the third defendant.


-----

Tom Wainwright for the fourth and fifth defendant.

Shahida Begum for the sixth defendant.

John McGuinness QC and Ben Douglas-Jones (instructed by the Crown Prosecution Service) for the Crown.

Shu Shin Luh, Maria Moodie and Felicity Williams (instructed by Deighton Pierce Glyn Ltd) for Anti-Slavery
International, as interveners.
Manveer Cheema Barrister.

**End of Document**


-----

# *R v Joseph and others (Anti-Slavery International intervening) [2017] EWCA
 Crim 36

Court of Appeal, Criminal Division

Lord Thomas CJ, Hallett VP and Goss J

9 February 2017Judgment

**Henry Blaxland QC and TomWainwright for the Applicant Joseph**

**Henry Blaxland QC and M Brewer for the Appellant VCL**

**Tom Wainwright for the Appellant NTN**

**Tom Wainwright for the Applicant Dong Nguyen**

**Shahida Begum for the Appellant AA**

(instructed by Philippa Southwell of Birds Solicitors)

**Jessica Russell-Mitra for the Applicant Craciunescu**

**John McGuinness QC and Ben Douglas-Jones for the Respondent**

**Shu Shin Luh, Maria Moodie, and Felicity Williams (instructed by Zubier Yazdani of Deighton Pierce**
**Glyn) for Anti-Slavery International, as Interveners**

Hearing dates: 23 and 24 November 2016

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Thomas of Cwmgiedd, CJ, Hallett LJ and Goss J:**

**INTRODUCTION**

1. From 2000, a series of international conventions were agreed to deal with the scourge of trafficking in
humans for the purposes of exploitation. These conventions imposed on the United Kingdom obligations in
respect of those trafficked. In 2009, on the ratification of one of the Conventions, the Government
established a National Referral Mechanism and, within the Home Office, what were named the Competent
Authorities to determine whether those who claimed to have been trafficked for the purposes of exploitation
had in fact been trafficked. In 2015, Parliament made comprehensive provision in respect of human
[trafficking by the enactment of the Modern Slavery Act 2015 (the 2015 Act) which was brought into force](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
as regards the material provisions on 31 July 2015.

2. Until that Act there was no statutory provision which transposed into the law of England and Wales the
obligations of the United Kingdom under the international conventions towards those victims of human
trafficking for the purposes of exploitation who committed crimes in England and Wales where there was a
nexus between the crime committed and the trafficking. In cases where the defence of duress was not


-----

likely to be applicable, it was left to the judiciary (utilising the flexible nature of the common law in a series
of decisions in 2011-2013) and to the Crown Prosecution Service (CPS) (through the exercise of their
independent prosecutorial discretion) to develop a legal regime for England and Wales in which the
international obligations as they successively developed were given effect in the domestic law of England
and Wales.

3. For those within the scope of the 2015 Act, the law is clearly set out in s.45 and Schedule 4. S.45 sets
out the conditions which have to be satisfied for a defence to arise respectively for adults and children
where there is a nexus between the trafficking and the crime committed. The offences to which the
defence do not apply are set out in Schedule 4. For the future, the 2015 Act will therefore provide the legal
framework.

4. However, as the Act was not drafted to provide retrospective protection, the regime that has been
developed by the courts will, subject to the issue we consider at paragraphs 24 and following, continue to
apply to those not within the scope of the Act who face charges, but who claim there is a nexus between
the crime with which they are charged and their status as victims of trafficking for the purposes of
exploitation.

5. We understand there is a considerable degree of optimism that the status of a person who claims to be
a victim of such trafficking will be resolved through close cooperation between the CPS and the Competent
Authority, as we explain at paragraphs 38-40. There will, however, remain cases to be resolved where
either the claim to be a victim of such trafficking has only been made after conviction or where there is an
issue as to the nexus between the offence and the trafficking or where the crime is so serious that it would
nonetheless be in the public interest to prosecute the trafficked person.

6. In these conjoined appeals and applications the Court has heard together a series of appeals made by
applicants who, save in the third appeal, have been designated by the Competent Authority as victims of
human trafficking sometime after their convictions for a range of offences. The objective was to enable the
court to try and resolve issues on the guidance given in the case law in respect of those who do not have
the benefit of the 2015 Act. We would emphasise at the outset that each case is very heavily fact specific.

7. Anti-Slavery International, a charitable organisation founded in 1839 to combat the different forms of
slavery then prevalent, intervened by way of written submissions to argue that this court should reassess
the approach in the law developed by the courts and the CPS and should redefine the law of duress to
bring it into line with the 2015 Act; we are grateful for the submissions which we consider at paragraphs 24
and following.

**I: GENERAL PRINCIPLES**

8. It is first necessary to provide a very brief summary of the international conventions.

_International Conventions and the EU Directive_

9. In 2001, following UN General Assembly Resolution 55/25 of 15 November 2000, the UN Convention
against Transnational Organised Crime was agreed at Palermo in December 2000. Annex II to the
Convention was the Protocol to prevent, suppress and punish trafficking in persons, especially women and
children, usually called the Palermo Protocol. It was ratified by the UK on 9 February 2006.

10. Its stated purpose was to prevent and combat trafficking in persons and to protect and assist victims of
trafficking. A particular importance of the protocol is its definitions in Article 3:

“(a) “Trafficking in persons” shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of
deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other
forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or
the removal of organs;


-----

(b) The consent of a victim of trafficking in persons to the intended exploitation set forth in subparagraph
(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation
shall be considered "trafficking in persons" even if this does not involve any of the means set forth in
subparagraph (a) of this article;

(d) "Child" shall mean any person under eighteen years of age.”

11. The Palermo Protocol was complemented in the EU by EU Framework Decision (2002/629/JHA) on
combatting trafficking in human beings (replaced in 2011, as set out at paragraph 14, by a Directive).

12. It was also followed by a Council of Europe Convention on Action against Trafficking in Human Beings
which was agreed in Warsaw in May 2005. This convention was ratified by the UK on 17 December 2008
and came into force in respect of the UK on 1 April 2009. It adopted in Article 4 the same definition of
trafficking in human beings as the Palermo Protocol. Article 26 entitled “Non-punishment provision”
provided:

“Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
been compelled to do so.”

The Council of Europe Convention was accompanied by an Explanatory Report.

13. In 2010 the Strasbourg Court decided in Rantsev v Cyprus and Russia (2010) 51 EHHR 1, that Article
4 of the ECHR contained a procedural obligation similar to that in respect of Article 2 and therefore
required effective means be in place in States to provide practical and effective protection of the rights of
victims of trafficking (see paragraphs 282-289).

14. On 5 April 2011, the EU promulgated Directive 2011/36/EU on preventing and combatting trafficking in
human beings. This has had direct effect from 6 April 2013.

i) Recital 14 of the Directive provided:

“Victims of trafficking in human beings should, in accordance with the basic principles of the legal systems
of the relevant Member States, be protected from prosecution or punishment for criminal activities such as
the use of false documents, or offences under legislation on prostitution or immigration, that they have
been compelled to commit as a direct consequence of being subject to trafficking. The aim of such
protection is to safeguard the human rights of victims, to avoid further victimisation and to encourage them
to act as witnesses in criminal proceedings against the perpetrators. This safeguard should not exclude
prosecution or punishment for offences that a person has voluntarily committed or participated in.”

ii) Article 2, paragraphs 1-4 provided:

“Offences concerning trafficking in human beings

1. Member States shall take the necessary measures to ensure that the following intentional acts are
punishable:

The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or
transfer of control over those persons, by means of the threat or use of force or other forms of coercion, of
abduction, of fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or
receiving of payments or benefits to achieve the consent of a person having control over another person,
for the purpose of exploitation.

2. A position of vulnerability means a situation in which the person concerned has no real or acceptable
alternative but to submit to the abuse involved.

3. Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of
sexual exploitation, forced labour or services, including begging, slavery or practices similar to slavery,
servitude, or the exploitation of criminal activities, or the removal of organs.


-----

4. The consent of the victim of trafficking in human beings to the exploitation, whether intended or actual,
shall be irrelevant where any of the means set forth in paragraph 1 have been used.”

iii) Article 8 of the Directive provided:

“Non-prosecution or non-application of penalties to the victim

Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties
on victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2.”

_The establishment of the Competent Authority at the Home Office._

15. 0n 1 April 2009, with the coming into force of the Council of Europe Convention, the UK Government
created the National Referral Mechanism with Competent Authorities being responsible for making what
are described as conclusive decisions on whether a person has been trafficked for the purposes of
exploitation. The Competent Authorities are a Unit within the National Crime Agency and units or hubs
within the Home Office Immigration and Visa Section.

16. Each Competent Authority operates under Guidance issued by the Home Office; the current version,
version 3, was issued on 21 March 2016. The guidance is very detailed. It sets out the process by which
the Competent Authority first makes a decision that there are reasonable grounds to conclude that the
person may be a victim of trafficking and then makes a conclusive decision. Conclusive decisions are
made by Executive Officers or Higher Executive Officers on the basis of a balance of probabilities, making
every effort to secure all available evidence, including evidence from the police, interviews with the person
claiming to be a victim (though these are not always necessary), information from the person or his or her
representative, and the general information and intelligence it has available to it in relation to trafficking.
Negative decisions are reviewed by a Senior Executive Officer.

_The CPS Policy and Guidance_

17. The CPS developed its first policy to give effect to the international obligations of the UK, which we
have set, out in December 2007; it related to those charged with immigration offences and to the
prosecution of young offenders who might be trafficked victims; the policy in respect of the latter
highlighted theft and cultivation of cannabis as offences likely to be committed by child trafficked victims.

18. Detailed guidance implementing this policy was given on 31 January 2008; that was revised on 4
February 2009. A further policy was issued in May 2011. On 31 July 2015, a new policy was introduced to
deal with those under the 2015 Act as well as those outside its scope.

_The establishment of the principles through the common law: 2010 -2013_

19. In parallel with the development of these policies after the coming into force of the Council of Europe
Convention, this court has heard a number of appeals relating to the position of victims of trafficking for the
purposes of exploitation who commit crimes. The most significant have been:

i) _R v M(L), B(M) and G(D)[2010] EWCA Crim 2327, [2011] 1 Cr App R 12 (Hughes LJ, Owen and_
Thirlwall JJ).

ii)  R v N, R v Le _[2012] EWCA Crim 189, [2013] QB 379(Lord Judge CJ, Royce and Globe JJ)._

iii) _R v L(C), N, N & T [2013] EWCA Crim 991 [2013] 2 Cr App R 23 (Lord Judge CJ, Moses LJ and_
Thirlwall J).

20. The judgments in these cases established the legal regime in domestic law to give effect to the
international obligations we have set out:

i) The obligation under Article 26 of the Council of Europe Convention is given effect in England and
Wales through (1) the common law defences of duress and necessity or (2) guidance for prosecutors on
the exercise of the discretion to prosecute (which has been revised from time to time) or (3) the power of


-----

the court to stay a prosecution for abuse of process (see R v M(L), B(M) and G(D), 2010 at paragraphs 712)

ii) In a case where (a) there was reason to believe the defendant who had committed an offence had been
trafficked for the purpose of exploitation, (b) there was no credible common law defence of duress or
necessity but (c) there was evidence the offence was committed as a result of compulsion arising from
trafficking, the prosecutor has to consider whether it is in the public interest to prosecute. (See: R v M(L),
_B(M) and G(D), 2010 at paragraph 10.)_

iii) The court's power to stay is a power to ensure that the State complied with its international obligations
and properly applied its mind to the possibility of not imposing penalties on victims. If proper consideration
had not been given, then a stay should be granted, but where proper consideration had been given, the
court should not substitute its own judgment for that of the prosecutor (see R v M(L), B(M) and G(D), 2010)
at paragraph 19).

iv) Where this court concludes that the trial court would have stayed the indictment had an application
been made, the proper course is to quash the conviction, (see _R v M(L), B(M) and G(D), 2010) at_
paragraph 17).

v) The obligation under Article 26 does not require a blanket immunity from prosecution for victims of
trafficking. Various factors should be taken into account in deciding whether to prosecute; if there is no
reasonable nexus of connection between the offence and the trafficking, generally a prosecution should
proceed. If some nexus remained, then prosecution would depend on various factors including the gravity
of the offence, the degree of continuing compulsion and the alternatives reasonably available to the
defendant. Each case was fact specific. (See R v M(L), B(M) and G(D), 2010 at paragraph 13-14).

vi) The distinct question for decision in the case of a trafficked defendant is the extent to which the
offences with which he is charged (or of which he has been found guilty) are integral to or consequent on
the exploitation of which the person was a victim (see R v L(C), N, N & T, 2013, at paragraph 33). The
court made clear such a decision is a fact sensitive one:

“We cannot be prescriptive. In some cases the facts will indeed show that he was under levels of
compulsion which mean that, in reality, culpability was extinguished. If so, when such cases are
prosecuted, an abuse of process submission is likely to succeed. That is the test we have applied in these
appeals. In other cases, more likely in the case of a defendant who is no longer a child, culpability may be
diminished but nevertheless be significant. For these individuals prosecution may well be appropriate, with
due allowance to be made in the sentencing decision for their diminished culpability. In yet other cases, the
fact that the defendant was a victim of trafficking will provide no more than a colourable excuse for
criminality which is unconnected to and does not arise from their victimisation. In such cases an abuse of
process submission would fail.”

vii) The reason why the criminality or culpability of a trafficked person is diminished or extinguished does
not result merely from age but in circumstances where there has been no realistic alternative available to
the person but to comply with the dominant force of another individual or group of individuals (see R v L(C),
_N, N & T, 2013 at paragraph 13)._

viii) The decision of the competent authority as to whether a person had been trafficked for the purposes
of exploitation is not binding on the court but, unless there was evidence to contradict it or significant
evidence that had not been considered, it is likely that the criminal courts will abide by the decision (see R
_v L(C), N, N & T, 2013 at paragraph 28)._

21. As a consequence of experience and the decisions of the courts and the successive changes to CPS
guidance, the present policy of the CPS, as expressed in 2015, in respect of those not within the scope of
the 2015 Act is to require the prosecutor to consider three broad questions on a fact specific basis in each
case where the defence of duress does not arise on the evidence:

i) Is there credible evidence that the defendant falls within the definition of trafficking in the Palermo
Protocol and the Directive?


-----

ii) Is there a nexus between the crime committed by the defendant and the trafficking? In the case of
adults it is necessary to assess whether the defendant had been compelled to commit the crime by
considering whether the offence

“was a direct consequence of, or in the course of trafficking/slavery and whether the criminality is
significantly diminished or effectively extinguished because no realistic alternative was available but to
comply with the dominant force of another”.

iii) Is it in the public interest to prosecute? There will be some crimes that it will be in the public interest to
prosecute.

22. The policy makes clear that in the case of children the position in relation to the second question is
different. As we set out at paragraph 37 below, it is a sufficient nexus if the offence is a direct
consequence of the trafficking. It is not necessary to show compulsion.

_[Should the courts redefine the approach in the light of the Modern Slavery Act 2015?](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_

23. As we have already mentioned, s.45 of the 2015 Act provides for a substantive defence. It is in these
terms:

“This section has no associated Explanatory Notes

(1) A person is not guilty of an offence if—

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if—

(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if—

(a) the person is under the age of 18 when the person does the act which constitutes the offence,

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.

(5)For the purposes of this section—

“relevant characteristics” means age, sex and any physical or mental illness or disability;

“relevant exploitation” is exploitation (within the meaning of section 3) that is attributable to the exploited
person being, or having been, a victim of human trafficking.

(6)In this section references to an act include an omission.

(7)Subsections (1) and (4) do not apply to an offence listed in Schedule 4.”

24. In the submission made to the court by Anti-Slavery International, as interveners, it was urged that the
court should take the opportunity of these appeals to re-assess the approach the courts have taken to


-----

victims of trafficking. It is said that it is no longer appropriate or in compliance with the international
obligations of the United Kingdom, in cases where the evidence does not establish duress, to rely on the
approach set out in _R v M(L), namely what is described as dependency on the use of prosecutorial_
discretion and the abuse of process jurisdiction.

25. The court, it was submitted, should develop the common law defence of duress in line with the
international obligations of the UK so that it applies to victims of trafficking in a manner consistent with the
UK's international obligations under Article 26 of the Council of Europe Convention, Article 3 of the
Palermo Protocol and Article 4 of the ECHR. To achieve that result those who could not avail themselves
of the defence under s.45 of the 2015 Act because it was not in force at the material time should be put in
the same position as those who can rely on s.45. Such a development of the law of duress should not be a
general development but one strictly confined to cases involving victims of trafficking. It was right to do so,
because the courts should develop the common law so that it reflected the international obligations of the
UK.

26. Furthermore, it was submitted that the questions which arose in each case as to whether the
defendant was a victim, whether there was a nexus and whether there had been compulsion should be
determined by a jury. It was no longer appropriate to rely on prosecutorial discretion and a review by the
court, as set out in the cases decided in 2010-2013 which we have summarised. The court should
therefore develop the common law in relation to duress in relation to victims of trafficking only so that it was
aligned with the international conventions. The present law operated in a way which meant that the
remedies provided by the court came after the conviction and often after service of the sentence. A
detailed and closely argued submission urged the court to redefine the concept of compulsion so that it
was sufficiently broad to encompass the means of trafficking set out in the Palermo Protocol and the
Convention.

27. We do not accept the submission. In our judgement the principles in the case law to which we have
referred at paragraphs 19-20 were established by the courts in a way which ensured that the domestic law
of England and Wales was in accordance with the obligations under the international conventions: see in
particular paragraph 7 of R v M(L).

28. The present law of duress is clear. Its scope and limits are set out in cases of the highest authority.
Parliament has considered the position. It enacted s.45 without providing for retrospective protection. In
the circumstances it would require instances of clear injustice to justify a court amending the law of duress
as applicable to victims of trafficking who were not able to take advantage of the 2015 Act. We have seen
no evidence of such instances. The individual cases that were the subject of the decisions in 2010 to 2013
and the appeals and applications being heard by us show that the law operates in practice in a way entirely
consistent with the UK's international obligations. We accept that the cases that the court has to consider
are cases where the issue as to trafficking often has arisen after the conviction. Changing the law of
duress would not alter that type of case. A court cannot grapple with the issue until it is raised; in some of
the cases we are considering it was not raised until after conviction. What has changed is a greater
understanding of the position of victims and the need in such cases to investigate. We see no reason to
develop the law of duress in the way suggested.

29. In R v van Doo [2012] EWCA Crim 1717, this court expressed the provisional view that the defence of
duress should not be expanded in a case involving the case of a credible victim of trafficking; and that it
would not be right to alter the ingredients of the defence so that a threat of false imprisonment would
suffice (see paragraph 24(iv), 33, 54-56 of the judgment). As we have set out, our view accords with this
provisional view.

30. As we have rejected the contention that the existing approach should be abandoned and a new
approach adopted for cases not covered by the 2015 Act, it is necessary to deal with three general issues
that have arisen on these appeals before turning to the facts of the appeals.

i) The relevance of the gravity of the offence.

ii) The position of a child victim.


-----

iii) The relationship between the Competent Authority and the CPS.

_The gravity of the offence committed._

31. As has been made clear in the decisions to which we have referred there will be graves crimes where,
taking into account all the circumstances, it is in the public interest to prosecute. The decision is always
fact sensitive. The first appeal (see paragraphs 61-66) and the second appeal (see paragraph 98) are
cases where the crimes committed were serious drug trafficking offences and prosecution was, in all the
circumstances, in the public interest.

_The position of a child_

32. In the third case, on a reference from the Criminal Cases Review Commission, one of the issues which
arose related to the relevance of compulsion in respect of a child trafficked for the purposes of exploitation.
In the judgment of this court in _R v L(C), N, N & T, 2013 there is extensive discussion of the position of_
children and the evidential requirements in relation to trafficking and the nexus between trafficking for the
purposes of exploitation and the crime committed. The court had to consider if the crime alleged was
consequent upon and integral to the trafficking of which he was a victim.

33. It was suggested that both the CPS and the court in R v N, R v Le had misunderstood the law on the
basis that, at paragraph 90 of the judgment, the Court asked the following question which suggested that in
the case of a child compulsion had to be shown:

“whether the circumstances in which this defendant was working at the time of his arrest represented a
level of coercion and compulsion that should have led to a decision that he should not be prosecuted.”

34. This paragraph in the judgment was in the section dealing with the examination of the circumstances
of N, the other appellant. It was neither in the section on general principles nor in the section relating to the
appeal of the appellant in this further appeal. We shall return to this issue in the course of consideration of
the third case at paragraph 124 below.

35. The law is, in our view, clear. Once it is established that a child is a victim of trafficking for the
purposes of exploitation, the relevant consideration is whether there is a sufficient nexus between the
trafficking for the purposes of exploitation and the offence; it is not necessary to go so far as to show there
was compulsion to commit the offence required in the case of an adult. It is clear from the definitions in the
Palermo protocol and the Council of Europe Convention (which we have set out at paragraphs 9 and 12
above) and paragraph 76 of the Report on the Convention (to which we have also referred at paragraph 12
above), that once it is shown that a child had been trafficked for the purpose of exploitation, what has to be
shown is that the offence has been committed as a direct result of the trafficking for the purposes of
exploitation. It is not necessary to prove compulsion.

36. The 2009 CPS guidance was not explicit in the passage referring to child trafficked victims involved in
theft or the cultivation of cannabis:

“Prosecutors should be alert to the possibility in such circumstances a young offender may actually have
been a victim of trafficking and committed the offences under coercion.”

It did not make clear there has been no need to establish coercion in the case of a child who had been
trafficked for the purpose of exploitation if a direct nexus could be shown between the offence and such
trafficking. The 2011 guidance was more explicit when it stated:

“if new information or evidence supports the fact that the child or youth has been trafficked and had
committed the offence whilst in a coerced situation, there is a strong public interest to stop the prosecution.
However there must be consideration of whether the criminality is as a direct consequence of their
trafficking situation.”

37. The 2015 guidance sets out more clearly that what has to be established is that the commission of the
offence is direct consequence of the trafficking for the purposes of exploitation and that it is not necessary
to establish compulsion. The 2015 makes the position clear by simply stating:


-----

“When considering whether to prosecute a child victim of trafficking/slavery, prosecutors will only need to
consider whether or not the offence is committed as a direct consequence of, or in the course of
trafficking/slavery”

_The relationship between the Competent Authority and the CPS_

38. As we have set out at paragraph 20.viii), the decision of the Competent Authority does not bind the
court.

39. Where there is an issue as to whether a person is a victim of trafficking for the purposes of exploitation
whilst a prosecution is being considered or is in progress, the CPS and police are able to refer to the
Competent Authority the case of a person in respect of whom there may be evidence of that person being
a victim of trafficking. Provision is made in the Guidance to the Competent Authority for cooperation with
the police and CPS in all cases before the conclusion of the prosecution. We were told that the
cooperation has been developed so that during the procedures for considering prosecution every effort is
made to reach a common view on whether the evidence points to the person being a victim of trafficking.
That is plainly of the greatest importance, as the cogency of the evidence which may be relied on by the
Competent Authority must be subject to thorough forensic examination when the CPS is considering the
question of nexus and whether it is in the public interest to prosecute.

40. However, in respect of a person claiming after conviction to be a victim of trafficking, there is no clear
guidance on or process in respect of co-operation with the CPS or in obtaining court documents. These
appeals have shown that it would desirable for much clearer guidance and processes to be developed
between the CPS and the Competent Authorities in cases where the claim to be a victim of trafficking is
made after conviction. It is important to appreciate a court will bear the Competent Authority's conclusion
very much in mind but will examine the question of the cogency of the evidence on which the Competent
Authority relied and subject the evidence to thorough forensic examination. It does not follow from the fact
than an individual 'fits the profile' of a victim of trafficking that they are necessarily the victim of trafficking.
A careful analysis of the facts is required including close examination of the individual's account and proper
focus on the evidence on the nexus between the trafficking and the offence with which they are charged.
The second, third and sixth appeals illustrate the issues that can arise (see in respect of the second appeal
paragraphs 87-94 and 96-97, in respect of the third appeal paragraphs 115-116 and 122 and the sixth
appeal paragraphs 157 and 160).

41. We turn to deal with the specific appeals.

**II: SPECIFIC APPEALS**

**(1)          R v VERNA SERMANFURE JOSEPH**

_Introduction_

42. On 15 September 2005 the applicant was convicted at the Crown Court at Manchester before Poole J
and a jury of being knowingly concerned in the fraudulent evasion of the prohibition on the importation of a
controlled drug of Class A (cocaine). She was sentenced to 9 years' imprisonment. An application for
leave to appeal against sentence was refused by the Single Judge in 2005 and not renewed. This is her
first application to appeal against conviction for which she needs an extension of time of approximately 10
years and 1 month.  The applications for leave and an extension have, in accordance with the practice of
the court, been referred to the Full Court.

43. She has served her sentence.

_Factual background_

44. The applicant was a resident of St Lucia. On 8 February 2005 she arrived at Manchester airport on a
flight from St Lucia. As she was passing through the green 'nothing to declare' channel at customs she
was stopped by an official who asked to examine her baggage. She stated she had packed the suitcase
herself, that she understood that it was illegal to bring drugs into the UK, and that nobody had asked her to


-----

bring anything into the UK for them. The applicant produced a key from her handbag to enable the officer
to unlock her suitcase. Amongst the items in the case were four wine bottles. They contained 5.13 kg of
liquid in which was dissolved a total of 2.12 kg of cocaine at 100% purity. The estimated street value of the
drug was £271,658.

45. On the same day as the applicant's flight, two other women, including a Channel Lizell Cornibert
(hereafter referred to as Ms Cornibert), were arrested at St Lucia airport and were found to be in
possession of large quantities of drugs.

46. In interview, the applicant claimed that the purpose of her trip to the UK was to confront the father of
two of her children. She had decided to come to the UK some months before and was planning on staying
with an uncle. She provided an address for the uncle which did not exist. She said that she had been
asked to carry the wine bottles by a friend, Ms Cornibert, who was on the same flight but who had
exceeded her baggage allowance. She said Ms Cornibert was unreliable and a user of drugs. She
claimed to have misunderstood the customs officer's question when she had denied that she was carrying
anything for anyone else. She denied knowing that the bottles contained drugs.

_The trial in 2005_

47. The defence case at trial was duress. Her case was that she was the mother of eight children one of
whom, Marcia, was aged fourteen. The father of her youngest two children was Antoine Jean Marie, also
known as 'Stone'. She claimed that on 24 October 2004 armed members of a gang known as the
“Graveyard Crew” called at her house looking for Stone. They returned many times. One morning, Stone
rang her and told her to meet him. When she was with him, she received a call from a friend who told her
that the gang had trashed her house and shop and had kidnapped Marcia. She returned home
immediately. She informed the police of the kidnapping and also made a plea for the return of her
daughter on a radio broadcast. The gang returned her daughter that evening. The applicant went to stay
at a relative's house where she thought she would be safe but gang members found her, kidnapped her
and held her at gunpoint. They drove her to a house where they tied her to a chair and started to torture
her in an attempt to get her to reveal Stone's whereabouts. They stubbed cigarettes out on her and pulled
her toes and ears with pliers. They pushed a gun into her mouth. They starved her for sixteen days and
raped her.

48. On the tenth day they captured Stone, brought him to the house, and beat and tortured him whilst she
watched. On the sixteenth day they cut off his toes. Later that day Stone escaped. The men panicked
and returned her home. They warned her not to do anything stupid and told her that she must not go into
town or to any government building or to the police. She was told that they had men watching her.

49. Subsequently the men contacted her by phone and told her that she was responsible for paying
Stone's debt of $25,000. They threatened to kill her and her children if she did not pay and do as they
said. She did not have the money and she reported the threats to the police.

50. Some time later, the men arranged a meeting. They explained that she had to go to England and that
when she got to the airport in St Lucia someone would give her a bag which she had to take to England.
She knew that the bag would contain drugs. She had no choice but to agree because she was scared they
would kill her and her children. They told her that if she took the drugs to England she and her children
would be free.

51. She was not surprised to see someone called Ms Cornibert at the airport as she knew her to be
associated with the gang. Ms Cornibert handed her the bag which had four bottles in it. Ms Cornibert
accompanied her to the departure gate and told her not to do anything stupid. Ms Cornibert then turned
back to immigration. The applicant believed that Ms Cornibert was on the flight, but she did not see her.
At Manchester she did not tell customs about the drugs because she was scared and did not know what
the gang would do to her family. She denied that she had concocted her story whilst on remand.

52. Members of her family and friends provided statements which in summary confirmed that there was a
gang in St Lucia known as “the Graveyard Crew” which was capable of serious violence and murder. DC


-----

Brett of the Royal St Lucia Police said that on 26 October 2004 information was received that the
applicant's daughter had been kidnapped by a number of men from the Graveyard Crew. The gang
consisted of about ten people and were connected mainly with drugs and guns. He had never had any
previous dealings with the applicant. Her daughter was released after Stone had made a call to the gang.
The applicant appeared frightened and would not leave the police station. He then became aware that
both she and her boyfriend had been kidnapped. He only saw her once after that in connection with
another matter to which she was a potential witness but she was too fearful to make a statement.

53. DC Raymond also a St Lucian officer stated that he had been told by the applicant's former boyfriend,
Stone, that the reason she had been kidnapped was because she had gone to Trinidad for some drugs in
2004 which she was meant to bring back to St Lucia. The drugs had gone missing and this had provoked
the gang. The applicant's passport showed that on 14 October 2004 she had entered Trinidad and
Tobago.

_Sentencing remarks_

54. Although the jury by their verdict rejected the defence of duress, the judge accepted when sentencing
that the applicant was used by others much higher up the chain of command and that she was subjected to
horrific treatment by the gang members. However, she had been badly treated because she had
voluntarily associated with the gang, had become involved in drug smuggling and then fallen out with them.
He noted that the applicant had opportunities, which she did not take, to report matters to the authorities
both in St Lucia and the UK. He reduced the sentence of twelve years which the offence merited to one of
nine years to reflect her lower level of culpability.

_Grounds of Appeal_

55. Two grounds formed the basis of the application for leave to appeal that:

i) There was fresh evidence that demonstrated that the applicant was the victim of trafficking which, taken
together with the judge's sentencing remarks, showed that she was under such a level of compulsion that
her culpability for her offending was extinguished;

ii) Had the material been available at the time, either it would not have been in the public interest to
prosecute or submissions for the proceedings to be stayed as an abuse of process would have succeeded.

_Fresh evidence_

56. There were two items of fresh evidence upon which the applicant sought to rely - the decision of the
Competent Authority and a psychological report from Dr Amanda Jones.

57. In a letter dated 3 September 2015, from Angie McIlveen and Sharon Gallagher of the Home Office
UK Visas and Immigration Department, the Competent Authority confirmed that, following a decision in
August 2014 that there were reasonable grounds to believe that the applicant was a potential victim of
human trafficking, the Competent Authority has concluded that, on the balance of probabilities, the
applicant was a victim of human trafficking. The Authority stated it had borne in mind objective evidence of
the prevalence of human trafficking in St Lucia, the applicant's own account of her involvement in drugs
smuggling, a clinical forensic report on her physical injuries consistent with her account of physical trauma
when kidnapped and psychological reports upon her.

58. In a psychological report dated 10 March 2015 Dr Amanda Jones stated that, from a psychiatric
diagnostic point of view, the applicant suffered from post-traumatic stress disorder, panic disorder and
recurrent depressive episodes. Dr Jones opined that the Applicant presents as someone who has
“endured considerable loss and trauma”.

_The applicant's submissions_

59. In submissions made on the applicant's behalf by Mr Blaxland QC and Mr Wainwright, we were invited
to conclude that there was “compelling evidence that the applicant was a credible victim of trafficking” and
should not have been prosecuted. Although Mr Blaxland QC, when pressed, conceded there may be


-----

some offences which were so serious that even a victim of trafficking must expect to be prosecuted, he did
not accept that smuggling a significant quantity of Class A drugs into the United Kingdom was one of them.
He dismissed as unreliable the evidence that suggested the applicant willingly involved herself in the
gang's drugs smuggling activities and as unrealistic the Crown's assertion that the applicant could have
sought the help of the authorities in St Lucia. He contended that the level of criminality established was not
such as to deprive the applicant, a victim of trafficking, of the protection to which she was entitled, given
the severity of the compulsion to which she had been subjected. Had the Crown chosen to proceed with
the prosecution despite the evidence which had since become available, the court would have been bound
to intervene and stay the proceedings as an abuse of process.

60. The Crown, acknowledging the decision of the Competent Authority that the applicant was a credible
victim of trafficking, made clear that was insufficient and what was required was, as set out in the policy it
had developed as summarised at paragraphs 17-18 and 21, the necessary nexus between the trafficking
and the offence. There was insufficient evidence of compulsion which would significantly diminish or
extinguish the criminality of the applicant, given the high level of criminality involved in smuggling the
substantial quantity of cocaine; the decision to prosecute on all the evidence now available was in the
public interest and therefore justified.

_Conclusion_

61. Although the Council of Europe Convention and Directive were not part of the international obligations
of the UK at the time of the offending in 2005, it was rightly accepted by the Crown that the protection
afforded to the applicant by the Palermo Protocol, Article 4 of the ECHR and the Code for Crown
Prosecutors, should be treated as materially the same as the protection outlined in the passages from the
authorities to which we have referred at paragraphs 19 and 20 above and the CPS policy summarised at
paragraph 21 above.

62. We note that Recital 11 of the Directive refers to the exploitation of a person to commit among other
crimes, pick-pocketing, shop-lifting, drug trafficking and similar activities which are subject to penalties and
imply financial gain. We also note that drug trafficking is not one of the crimes listed in Schedule 4 to the
2015 Act.

63. However, we cannot dismiss an offence of importing Class A drugs into this country or the applicant's
involvement in drugs smuggling as lightly as Mr Blaxland QC invited us to do. Class A drugs bring death
and misery to the streets of the UK and those who involve themselves willingly in the supply chain must
face the consequences of their actions. A distinction must be drawn between the individual put under
some kind of pressure to become involved in drugs smuggling and the genuine victim of human trafficking.
The circumstances of the former can be fairly and adequately reflected in the court's assessment of their
role in the offending and the sentence imposed.

64. Even if we accepted the fresh evidence without reservation and took fully into account the fact that the
applicant had been subjected to serious violence and sustained serious injuries, which was not in dispute
at the trial or subsequently, it is important to determine why she was subjected to such violence and
sustained such injuries when determining the issue of nexus between the alleged trafficking and the
offence. The objective evidence suggests that this applicant did involve herself willingly in smuggling Class
A drugs. Her first drugs trip was to Trinidad and Tobago in October 2004; it was only when that operation
went wrong that she and Stone faced the wrath of the gang. Several months then passed between the
kidnaps and torture (which ended at the latest in mid-November 2004) and her being sent to the UK in
February 2005. Although as is made clear in the international and European conventions, it must be
appreciated that a victim of trafficking may find it difficult to report what has happened, in the
circumstances of this case which we have set out, it was not unrealistic or unreasonable to expect her to
report the gang's demands to the police in the same way as she reported the kidnaps and subsequent
threats.

65. It follows that, in our judgement, the applicant has failed to establish a sufficient nexus between her
becoming involved in a very serious offence and her ill treatment to justify not proceeding with the


-----

prosecution. The judge properly reflected the reduced culpability by the reduction in sentence he made.
The decision to prosecute was justified and fully in accordance with the applicable legal regime.

66. In the light of those circumstances, the Competent Authority's decision that the applicant is a credible
victim of human trafficking is not such as to “diminish significantly” or “effectively extinguish” the high level
of criminality involved in the international smuggling of Class A drugs. Public policy dictated that she be
prosecuted.

67. We add only this. The fresh evidence in the form of the conclusions of the psychologist and the Home
Office officials appears to have been based almost entirely on the applicant's own account. No attempt
seems to have been made by any of those involved to test that account. It is not for us to advise officials in
the Home Office how to investigate the credibility of a person claiming to be a victim of trafficking; that is a
matter for them. However if an expert's report is relied on for the purposes of an appeal before this court,
the expert should remember their duty to the court and not simply proffer an opinion on an applicant's
credibility without exploring areas of possible inconsistency.

68. For all those reasons, we refuse the applications for an extension of time and for leave to appeal
against conviction.

**(2)        R v ALEXANDRA DORINA CRACIUNESCU**

69. On 13 September 2010 at the Crown Court at Isleworth before HH Judge McDowall and a jury the
applicant was convicted of being knowingly concerned in the importation of cocaine and sentenced to ten
years' detention. She did not appeal against conviction; her application for leave to appeal against
sentence was refused by the Single Judge on 8 February 2011.

70. She seeks an extension of time of over 4 years and 11 months to apply for leave to appeal against
conviction and applies for leave to appeal. Her applications have been referred to the Full Court by the
Registrar. She also seeks leave to renew her application for leave to appeal against sentence and the
necessary extension of time.

71. She was released on licence in 2015.

_Factual background: her case at trial_

72. The applicant was a Romanian national born on 21 September 1989; she had a child in Romania.
She arrived in the UK in November 2009. On 30 or 31 March 2010 she travelled by airplane from the UK
to Brazil. When she returned to Heathrow airport on 15 April 2010 her luggage was found to contain two
packages which, on analysis, contained 1.16 kg of pure cocaine with an approximate street value of
£220,000. The notes of the advice of those representing her at the interview with Customs showed that
they raised with her the question of whether she had been forced to carry the cocaine. The note records
the advice that it was the best time to put such a case and advance such mitigation. A 'no comment'
interview then took place.

73. The applicant pleaded not guilty, claiming that she did not know that she was carrying the cocaine.
Her case was that after coming from Romania she had worked at two cafes in London and earned
approximately £1,000 a month. She had gone to Brazil to visit Adam, a man she had met online on a
dating website; she had paid for the ticket herself. He had persuaded her to stay for longer and agreed to
pay the extra cost of her ticket home. While she was there he bought her two handbags, each worth about
£5, as gifts. He had assisted her with packing them. She maintained that he must have placed the drugs
inside. She did not allege she had been trafficked. Despite attempts by those presently representing the
applicant in accordance with the practice set out in _McCook_ _[[2014] EWCA Crim 734, it has not been](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C0P-34W1-F0JY-C187-00000-00&context=1519360)_
possible to ascertain anything from her previous legal team who represented her at the trial; her counsel
has died and her solicitor is untraceable.

74. In imposing the sentence of 10 years, the judge stated he took into account her young age, her
previous good character and the fact she was the single mother of a child.


-----

_Her subsequent claim she was trafficked_

75. In February 2013 the applicant claimed in conversations with the prison authorities that she had been
trafficked into the UK. She was referred to the Poppy Project. Acting on her behalf they referred the
applicant in May 2013 as a potential victim of trafficking to the Competent Authority. The referral was
based on the applicant's account of her background and the events leading up to the offence.

76. Her account was that her mother had died when she was 14, that her father had then sexually abused
her; she moved in with a friend but had a child by the friend's brother when she was 18. Her friend's
boyfriend whom she has refused to identify and we therefore identify as RX offered to pay for her travel to
London for her to work in a café or as a cleaner. She arrived in Luton airport on 14 November 2009; RX
collected her and arranged for her to work in cafes; she earned £300 a week, but was only allowed by RX
to keep £20. He also took her passport.

77. In January 2010 he tried to pressure her to travel to French Guyana to bring drugs back for him, but
she refused. In March 2010 he asked her to go to Brazil for the same purpose and, following threats that
she would lose her job and never see her son again and physical abuse, she relented.

78. She was driven to Heathrow airport by her trafficker and another man and was given her passport,
plane tickets, $1,000 in cash and the address of a hotel to stay in. While in Brazil an associate of her
trafficker took the money from her and acted as her minder until the drugs were delivered. She was told
what to say if caught returning through customs, and did so because she was afraid for her safety and that
of her family in Romania. The account given at trial was what she had been told to say. She had said
nothing about trafficking as she feared RX would carry out the threats he had made.

79. The Competent Authority determined on 5 August 2013 that there were reasonable grounds to believe
that the applicant had been trafficked. The Poppy Project subsequently provided further submissions on
23 August 2013 in the form of an expert report. The content of this report was based on the Project's
general expertise in trafficking and the applicant's own account of events.

80. On 11 October 2013 the Competent Authority responded by letter explaining their considerable
reservations about the evidence presented that the applicant had been trafficked. These ranged from
apparent internal contradictions in the applicant's account to highlighting reasonable alternative courses of
action available to her. The letter noted that the applicant had failed to disclose this information at trial and
that no medical evidence had been provided to explain this omission. The Competent Authority also
requested documentary evidence to corroborate her account, such as the name of the cafes in London
where she claimed to have worked, details of the plane tickets and the hotel in Brazil where she stayed,
and information about her alleged trafficker.

81. On 10 July 2014 the Poppy Project responded on her behalf to these matters, providing details of the
applicant's medical record and prison patient record, and an expert report dated 6 November 2013 from Dr
Fleetwood, a criminologist. The latter report described how, in general terms, the applicant's account
conformed to the experiences of other victims of trafficking. No other documentary evidence was provided
to corroborate her account.

82. On 31 October 2014 the Competent Authority made a conclusive determination that the applicant was
a victim of trafficking. The letter stated:

“In light of the representations received from the Poppy Project and Dr Fleetwood, and having regard to
other factors, including the fact that you were only 20 years of age when you were arrested and that you
have (or had) anxiety and fear related mental health issues, it has been accepted that on the balance of
probabilities that you have provided a substantially truthful account and that you were a victim of human
trafficking.”

However, the letter further concluded that the circumstances of the trafficking no longer existed; the
applicant did not qualify for leave to remain in the UK. On 21 April 2015 the Home Office decided to deport
the applicant.


-----

83. In a report dated 28 July 2015 Professor Katona, a psychiatrist, diagnosed the applicant as suffering
from PTSD, and concluded that this was consistent with her being a victim of trafficking; he opined that
remaining in the UK would improve her prospects of recovery and there would be a worsening of her PTSD
if retuned to Romania.

_The grounds of appeal and the fresh evidence_

84. It was contended on the applicant's behalf that the fresh evidence of the applicant's trafficking,
particularly the conclusive determination by the Competent Authority, should be received, as well as
evidence in support from Dr Fleetwood and Professor Katona. She had been trafficked twice – from
Romania to the UK and then her trafficker had exploited her by using her to transport cocaine back from
Brazil. On the basis of that evidence it was clear that the applicant would not have been prosecuted.

85. It was submitted in the alternative that, although on the facts before the trial judge no issue could be
taken with the sentence, the new evidence did not sufficiently reflect the reduction in culpability that should
flow from the new evidence.

86. We heard evidence de bene esse from Dr Fleetwood and Professor Katona.

_The evidence of Dr Fleetwood_

87. Dr Fleetwood was a lecturer in criminology at the University of Leicester who had specialised in
research into international drug trafficking and the involvement of women in trafficking cocaine. Her
opinion was that the applicant's account of being a drug mule as a result of being subject to exploitative
practices and threats was entirely consistent with her knowledge and research. There was some material
to suggest an emerging trend of trafficking women for use as mules. Mules did not report themselves,
particularly when subject to threats.

88. The Crown submitted that the report of Dr Fleetwood was irrelevant to the appeal; it amounted to
hearsay which was intended to bolster the credibility of the applicant and to establish, in the opinion of Dr
Fleetwood, that the applicant's account was plausible and credible and should be accepted. We agree.
The report was highly speculative and of no relevance to the appeal. It is for the jury (or this court on
appeal) to assess the credibility of the account given, not an expert. Speculation has no part to play.

_The evidence of Professor Katona_

89. Professor Katona is a very experienced psychiatrist having been Dean of the Royal College between
1998 and 2003 and is currently an Emeritus Professor at the University of Kent and at University College
London. He examined the applicant on 22 June 2015.

90. He rated her mental distress as severe, her depressive symptoms as moderate and her symptoms of
trauma as severe. He diagnosed her as suffering from PTSD with depressive symptoms secondary to that.
The PTSD was caused by her traumatic childhood experiences in Romania and her more recent
experiences of enforced work and trafficking. He considered that her clinical presentation was consistent
with her being a victim of trafficking. Her past experiences had made her vulnerable to trafficking and
explained why she would not reveal details of trafficking to the police and her lawyers at the time of her
arrest and trial; there was therefore a plausible reason why she had not disclosed matters until later. He
stressed in his evidence that it was not for him to express a view on credibility.

91. In the course of his evidence he said that the applicant had told him that she had been diagnosed with
PTSD whilst in prison, but he had not cross checked this to the prison records as he had not obtained
access to them.

92. The Crown submitted that the evidence of Professor Katona was irrelevant as it did not assist in the
determination of the issue in the appeal to have evidence that the applicant was found to suffer from PTSD
years after the offence.

_The submissions_


-----

93. It was submitted on behalf of the applicant that the level of criminality was not so high to deprive the
applicant of protection given the severity of the compulsion. The court should take into account her PTSD
and her fear of reprisals and should conclude that this explained why she had not raised her trafficking
status at the time of arrest and trial. The evidence of Dr Fleetwood and Professor Katona showed her level
of vulnerability and the ease with which she could be subject to compulsion. Someone in her position with
the relevant characteristics would have had no alternative to offending; her trafficker had used his power
over her. The nexus between the trafficking and the offence was established particularly through the
continued hold of the trafficker over her and the steps taken by the trafficker to stop her doing anything but
comply with his demands. If the Crown wished to rely on the matters raised by the Competent Authority in
their letter of 11 October 2013 to which we have referred at paragraph 80, then the Crown should have
investigated the matters.

94. The Crown acknowledged the Competent Authority's decision, but did not concede that the applicant
was a victim of trafficking; she had lied when arrested by customs, she had lied to her lawyers and had lied
in her evidence at trial. In any event her status under the determination of the Competent Authority was
not such as significantly to diminish or effectively to extinguish the very high level of criminality in
smuggling the quantity of cocaine into the UK so that she should not have been prosecuted. Furthermore,
the nexus of compulsion was not sufficient to warrant a decision not to prosecute; there was insufficient
evidence to show that she was compelled to commit the offence. Public policy dictated she be prosecuted.

_Conclusion_

95. The Council of Europe Convention but not the Directive was applicable at the time of the offending in
2010. It was, however, rightly accepted by the Crown that the protection afforded to the applicant was
materially the same as the protection outlined in the passages from the authorities to which we have
referred at paragraphs 19 and 20 above and the CPS policy reflecting that case law as summarised at
paragraph 21 above.

96. It is clear from the medical records that the applicant had many discussions in the course of mental
health reviews in the first three years of her sentence where she discussed issues relating to her health,
her time in Romania, her family and son and abuse before the age of 14. In the light of the fact that these
records had not been reviewed by Professor Katona, we do not consider it possible to conclude she was
suffering from PTSD at the time of the offence.

97. We therefore approach the issues on the basis that the evidence of Professor Katona was of very
limited value in relation to her mental state at the time when she committed the offence and that the
evidence of Dr Fleetwood was irrelevant as it was speculative and directed at bolstering the credibility of
the applicant which was a matter for the jury or the court.

98. We have serious doubts as to the credibility of the applicant's account, but it is not necessary for us to
determine the appeal on that basis. The essential question for us is whether the prosecutor (or the court
on the consideration of a stay) would have concluded it was in the public interest to prosecute the
applicant. We have no doubt that it was. The offence related to a very substantial quantity of Class A
drugs where, as we have explained at paragraph 63 in respect of the first applicant, the harm caused is so
significant. The evidence did not in our view show a nexus, let alone a sufficient nexus, between the
trafficking and the commission of the offence; there was no real evidence of compulsion. The
circumstances were not such as to “diminish significantly” or “effectively extinguish” the high level of
criminality involved in the international smuggling of Class A drugs. Public policy dictated that she be
prosecuted.

99. We would add that we do not accept the applicant's submission that it was for the Crown on an appeal
where there has been a conviction to investigate all the facts relating to the claim by the applicant in
relation to her claim that she was a victim of trafficking and in particular the matters raised by the
Competent Authority which cast doubt on her claim. We have set out at paragraph 40 our concerns in
respect of the relationship between the Competent Authority and the CPS in cases where the claim to be a
victim of trafficking has arisen subsequent to conviction. It is to be hoped that this concern can be


-----

addressed, but the court will continue to apply to these appeals and applications the ordinary applicable
principles. Nor will this court require the CPS to go beyond what is its ordinary duty in such cases.

100. As to her application for an extension of time to renew her application for leave to appeal against
sentence, nothing in the further information now before us in any way leads us to conclude that the
sentence passed was manifestly excessive. We refuse the application.

**(3)        R v VCL**

_Introduction_

101. On 20 August 2009, the appellant and a number of co-accused pleaded guilty at the Crown Court at
Peterborough before HH Judge Coleman to producing a Controlled Drug of Class B (cannabis). On 19
January 2010 he was sentenced to 20 months detention in a young offenders' institution. On 26 May 2011
the Single Judge refused his applications for leave to appeal against conviction and sentence and these
were renewed to the Full Court.

102. On 20 February 2012 the Full Court (Lord Judge CJ, Royce and Globe JJ) in the decision in R v N, R
_v L to which we have referred at paragraphs 19 and following granted the appellant permission to appeal,_
but dismissed his appeal against conviction. His appeal against sentence was allowed to the extent of
reducing his sentence to 12 months' detention

103. The appellant appeals against conviction on this occasion upon a reference by the Criminal Cases
Review Commission made in April 2016 under s.9 of the Criminal Appeal Act 1995.

_Factual background_

104. On 6 May 2009 police attended 105 Milton Road, Cambridge, a four bedroom house. They
discovered it had been converted into a factory for the cultivation of cannabis plants. The appellant's
fingerprints were found on light bulbs in two of the rooms at the property. The value of the cannabis plants
found was estimated at £130,000. The appellant was arrested with others. The others subsequently
pleaded guilty either to offences of conspiracy to produce cannabis or producing cannabis; the sentences
imposed were 5 and 6 years for the more serious offence and a range of 2 years to 21 months for the less
serious offences (see paragraph 95 of the earlier judgment of this court).

105. The appellant was found to be in possession of £100 in cash and a mobile telephone with credit. The
appellant's role was said by the Crown to be that of “gardener”, tending the cannabis plants. The house
had not been secured in such a way he could not leave.

106. In interview the appellant (who was accompanied by an appropriate adult and a legal representative)
declined to answer questions. He gave a prepared statement to the effect that he had been trafficked from
Vietnam and arrived in the UK seeking his adoptive father but had lost his contact details. Other
Vietnamese nationals found him wandering the streets and took him in. He was aware there were
cannabis plants at the address but he did not realise growing cannabis was illegal. He was provided with
groceries on a weekly basis.

107. His claim to be 15 years of age was not accepted. A finding of fact that the appellant was at least 17
years old was made by the District Judge in the Magistrates' Court and the case sent to the Crown Court.
However, the possibility that the appellant was the victim of trafficking was noted by various agencies and
by his lawyers. Nonetheless, he decided to plead guilty which he did on 20 August 2009. He declined to
apply to withdraw his plea when subsequently advised by counsel to do so. Counsel decided to seek an
adjournment in the hope that a report from the Social Services might persuade him to change his mind.
The Crown Court judge was also concerned and agreed to await the report.

108. In the meantime, the CPS reviewed their decision to prosecute and concluded on 14 October 2009
there was no credible evidence he had been trafficked.

109. The Competent Authority (in this case the UKBA) then issued on 15 October 2009 a reasonable
grounds letter to the effect that the appellant may have been trafficked. On 16 October 2009 the case went


-----

back before the Crown Court judge who tested the decision to proceed with the prosecution. The case
was again adjourned. Negotiations continued. In November 2009 the Crown Prosecution Service and the
appellant's lawyers were informed that the Competent Authority had concluded the appellant was a victim
of trafficking. The Chief Crown Prosecutor nonetheless confirmed at a hearing on 15 December 2009 the
decision to continue with the prosecution at a hearing on 15 December 2009. The appellant, fully and fairly
advised, decided not to make an application to vacate the plea.

110. At the sentencing hearing on 19 January 2010, the Crown explained why they considered the
appellant was not a trafficked person, the circumstances in which the appellant had been arrested and his
inconsistent accounts. Although the appellant had developed over the months an account of mild pressure
or threats, the assessment by the Competent Authority provided information that the appellant was clear
that his family in Vietnam was not under threat, there were no debts owed to anyone in Vietnam and he
had not been abused prior to his arrest. There was no reason to revise their assessment that it was in the
public interest that the appellant be prosecuted.

_The decision of this court on the appeal in 2013_

111. The court concluded (see paragraphs 94-113 of the judgment) that the Crown and the judge had
taken meticulous care in examining all the available evidence. As to the submission that there should have
been an application to vacate the plea and an application to stay, even if the judge had allowed the
applications to be made, the court had unhesitatingly concluded that the inevitable outcome would have
been that the decision to continue the prosecution was fully justified.

112. The sentence was reduced to 12 months detention on the basis of the appellant's age.

_Grounds of Appeal_

113. On present known facts it was not in the public interest to prosecute the appellant. He should be
permitted now to vacate his guilty plea. That would then permit a re-consideration of the decision to
prosecute.

114. The Crown, if it had applied the law correctly, would not have continued with the prosecution. It had
misdirected itself in the original proceedings by importing a requirement of force/coercion into the issue of
trafficking of a child. The appellant was a child and force or coercion was irrelevant to their consideration.
Similarly, as we have already set out at paragraphs 33 and following, it was contended the court had in the
earlier appeal misunderstood the law. It was submitted that the appellant's account that he had been
invited to come to the UK by his “foster father” to improve himself was true; on arrival he had no contact
with the supposed foster father. It was clear he had been deceived. It followed under the definition in the
Council of Europe Convention applicable to a child that he had worked in the cannabis factory as a direct
consequence of the trafficking. That was sufficient. It was not necessary to prove that he had been
compelled.

_Fresh evidence_

115. There was also an application to call fresh evidence pursuant to s.23 of the Criminal Appeal Act 1968
in respect of the reports of Dr Dene Robertson, a consultant psychiatrist at the Bethlem Royal and
Maudsley Hospitals dated 30 October 2013 and 24 June 2016 in which he concluded that for practical
purposes the appellant should be considered as suffering from Asperger's syndrome and, for a variety of
reasons, was likely to have been socially naïve and vulnerable to exploitation.

116. It was contended that had this diagnosis been available to the appellant's lawyers at the time, it would
have affected the advice they gave to the appellant. It would have been admissible in support of his
defence. It was relevant to the extent of his vulnerability and to his credibility. It was contended that the
fresh evidence from Dr Robertson supported the conclusion reached by the Competent Authority that the
appellant was a victim of trafficking.

_The submissions on the appeal_


-----

117. In addition to the submission made in relation to the issue of compulsion, the appellant has reasserted the submissions rejected by the court on the last occasion that if an application should have been
made to vacate the plea, it should have succeeded and the prosecution abandoned. It was contended that
this court had on the previous appeal wrongly focussed on the fairness of the process that took the
appellant to the Crown Court and the process at the Crown Court as opposed to the true question of
whether it was in the public interest to prosecute.

118. A challenge was also made to the findings of the court on the last occasion to the effect that the
appellant was not a prisoner in the cannabis factory, as such findings were not justified by the evidence.
To all intents and purposes the appellant was a prisoner. He had nowhere to go and was isolated. No key
to the property was found and police officers had to break in. The fact the appellant was left with a
telephone and cash did not bear the significance the court on the previous occasion had thought. It was
described by counsel to us as being common place for traffickers to provide equipment so as to keep in
touch with their workers.

119. The Crown maintained that it had been right to continue with the prosecution. Neither it nor the Court
had misunderstood the law. The court had been correct in its assessment of the facts. The fresh evidence
from Dr Robertson added nothing material to the issue before the court.

_Conclusion_

120. This same ground of appeal albeit differently expressed was at the heart of the appeal on the last
occasion in 2012. As we have set out, the court held that the decision to prosecute was amply justified.
This is not a case therefore where the court or a defendant's lawyers have missed the opportunity to review
an offender's status as a possible victim of trafficking and the nexus with the offence. This was an issue
explored with great care and in great detail at the Crown Court and by this court.

121. It would require a compelling piece of fresh evidence or line of argument to persuade us to re-tread
well-trodden ground. In the appellant's case, there is in truth very little by the way of fresh evidence or
fresh argument. The Home Office's determination that the appellant has been trafficked was before the
Crown Court and the Court of Appeal.

122. The only “fresh evidence” is the medical report that the appellant is on the Asperger's spectrum and
is socially naïve. The submissions to us have made what can be made of that evidence, but we bear in
mind the observations of this court in the earlier appeal at paragraph 86(c) as to the limited assistance
given by expert reports that rely so heavily on the account given by the applicant where it differed from
earlier accounts. In our judgement, neither the medical report nor its support for the Home Office's
conclusion is enough to undermine the appellant's plea of guilty or the court's conclusions on the last
occasion that the decision to prosecute in the public interest was amply justified.

123. The appellant, who was very nearly an adult, stayed in a house as a gardener of cannabis plants. He
was not a prisoner, he had a significant quantity of cash (for no obvious reason) and he had access to a
telephone. His explanation of his presence at the house was unsatisfactory and his account of how he got
there far from consistent. On those facts, it was open to the Crown to decide that the prosecution should
continue as the relevant nexus in the case of a child victim of trafficking had not been established.

124. We reject the assertion that the Court on the last occasion applied the wrong test as to the nexus
required in the case of a child. The judgment begins with a clear statement of all the relevant principles in
relation to trafficking including the relevant principles as far as child victims are concerned. The court did
not proceed on the basis the appellant had to establish compulsion before his plea could be vacated. As
we have pointed out at paragraph 33 above, the paragraph in which reference is made to compulsion and
which is the subject of criticism did not relate to this appellant. In paragraph 90 of its judgment on the
earlier appeal the court was addressing a particular issue in relation to the co-accused as we have
explained. The Crown and this court on the last appeal considered the nexus between the trafficking and
the offence on the correct basis; it did not suggest that there had to be evidence of compulsion.


-----

125. We are satisfied therefore that the appellant's criminality or culpability was not extinguished or
significantly reduced to such a level he should not have been prosecuted in the public interest. The appeal
is dismissed.

**(4)          R v NTN**

126. On 21 February 2005 in the Crown Court at Liverpool the applicant pleaded guilty to Producing a
Controlled Drug of Class C (namely Cannabis) contrary to s.6(2) of the Misuse of Drugs Act 1971 (Count
2). On 13 May 2005 he was sentenced to 15 months' detention in a Young Offenders' Institution.

127. His applications for an extension of time of approximately 10 years and 9 months in which to apply for
leave to appeal against conviction and sentence and to produce fresh evidence, namely the finding of the
Immigration and Asylum First Tier Tribunal that he had been a victim of trafficking, have been referred to
the full court by the Registrar.

_Factual background_

128. The applicant is a Vietnamese citizen. He first became known to the UK authorities in April 2004
when, accompanied by a Mrs Le Vuong, he attended Bexley Social Services and applied for asylum with
Mrs Le Vuong as his sponsor. He was registered with the Refugee Council. His application for asylum
was refused, although he was granted discretionary leave to remain in the UK until his 18th birthday.

129. On 15 October 2004 the applicant was arrested in a private house in Beechwood, Wirral. The
premises had been converted into a cannabis factory. A large hydroponics system had been set up and a
number of the rooms contained cannabis plants. A total of 400 plants with a value in excess of £80,000
were found.

130. On 21 February 2005, the day the case was listed for trial, the applicant pleaded guilty. There was a
dispute about his age. He gave his date of birth as 26 October 1988. In reliance upon the evidence of a
forensic dental expert, who considered him to be aged between 18 and 21 years, the sentencing Judge
found that he was 19 years' old. He sentenced him on the basis that he had been smuggled into the UK in
about April 2004 and had been forced to work in a Chinese restaurant in Kent. He had escaped, reported
to the UK authorities and had been refused asylum at the end of June 2004. Thereafter, he had been
seized by a gang and brought to the Wirral where he had been made to work in the cannabis factory, his
job being to water the plants and make sure the equipment was working properly and for which he was fed
in return. He had been “….used and manipulated by an unscrupulous gang…”, acting out of fear of what
would happen if he did not, and had made no money. The sentence also took account of his age, lack of
previous convictions and low risk of reoffending.

_The decision of the First Tier Tribunal in 2014 on his application for asylum_

131.  In 2012 the applicant made a fresh application for asylum, in part on the basis that he had been
trafficked into the UK. It was refused by the Home Office on 23 January 2014. The Competent Authority
had considered and rejected his possible trafficking status. However, on 10 August 2014, the First Tier
Tribunal (Immigration and Asylum Chamber) (the Tribunal), after hearing evidence including from the
applicant himself, allowed his appeal and made a number of findings of fact to a standard of the balance of
probabilities, including that:

i) The Crown Court reliance on evidence of dentition to determine the applicant's age was no longer used.
His date of birth had been found by Bexley Social Services, the Home Department, Wirral Social Services
and Wirral Young Offending Team to be 26 October 1988 (making him 16 years of age at the date of
sentence).

ii) He was an orphan. His mother had been Chinese. He was sent to an orphanage at the age of 13 and
had left Vietnam on 28 March 2004, when he was aged 15, being taken to China to work and to find
members of his family.

iii) He was taken to the UK by air and lorry, entering on 5 April 2004. He was then taken by Chinese men
to a restaurant where he was told he would have to work for two to three years to pay for the cost of his


-----

travel to the UK. He was beaten. He managed to escape and found a Vietnamese woman, Mrs Le Vuong,
who took him to the authorities with whom he lived until he was found by members of the gang who had
put him to work in the Chinese Restaurant. They took him to the Wirral where he was put to work in the
cannabis factory. He was told he would have to work there for about a year, was given a mobile phone,
£20 a week for food, monitored weekly by gang members and warned that he would be beaten if the plants
were not growing well.

132. The Tribunal specifically addressed the issues that had caused the Competent Authority to find the
applicant not to have been a trafficking victim and the apparent inconsistencies in his account. It found that
there were no material inconsistencies and the Competent Authority had erroneously found that he was not
a victim of trafficking. The Tribunal concluded he was a victim of trafficking.

_The application for leave to appeal_

133. This finding is the fresh evidence upon which the applicant seeks to rely in support of his application
for leave to appeal. The Crown does not oppose the application for the evidence to be admitted.

134. On behalf of the applicant it is submitted he was the victim of trafficking and there was such a clear
nexus between his being trafficked and his employment at the cannabis factory that his culpability was
extinguished. Alternatively, the sentence was manifestly excessive in light of the fresh evidence that
demonstrates his culpability was significantly diminished.

135. The Crown accepted that the Tribunal decision supported the assertion that the applicant was the
victim of trafficking to China and into the UK, having been transported, transferred, harboured or received
for the purpose of exploitation, and that he was exploited through debt bondage. He was a child at the
point he was trafficked. Even if he was not, the means of trafficking were present, namely, the threat or
use of force, coercion through debt bondage, abduction, the abuse of power and the abuse of a position of
vulnerability. Although an element of compulsion was accepted in the Crown Court, he was not recognised
as a potential victim of trafficking. The Crown agreed that his culpability, as was recognised in the
sentencing remarks, was significantly diminished if not extinguished by the direct nexus between the
trafficking and the offence, whereby it would not have been in the public interest to prosecute him or
maintain the prosecution against him.

_Conclusion_

136. We grant the applications to extend time and admit the fresh evidence. There is powerful evidence
that the applicant was both a child victim of trafficking and fell to be treated as such and his offending was
committed when he was still a child by reason of the offence being directly connected to his having been
trafficked. On the basis of all the facts now known we are satisfied that the prosecution would not have
been pursued. We therefore allow his appeal and quash his conviction.

**(5)          DONG NGUYEN**

137. On 9 July 2014 in the Crown Court at Peterborough the applicant pleaded guilty to a single count of
producing a controlled drug of Class B, namely cannabis. On 3 September 2014 he was sentenced to 2
years' imprisonment and appropriate ancillary orders relating to forfeiture and destruction of the drugs and
related paraphernalia and the payment of the statutory surcharge were made.

138. His applications for an extension of time of 19 months and 2 weeks in which to apply for leave to
appeal against conviction and sentence and to produce fresh evidence, namely evidence that he was a
credible victim of human trafficking, have been referred to the full court by the Registrar.

_Factual background_

139. The applicant is 46 years of age and a citizen of Vietnam. On 27 June 2014 he was arrested in a raid
on a residential address in St Paul's Road, Peterborough which had been converted into a cannabis
factory. 368 cannabis plants and some cuttings were seized. The applicant was the sole occupant and in
the loft, which was itself part of the factory. In interview he said that he had paid $23,000 to come “here”


-----

and had been at the property for two months. He found out after his arrival that the plants were cannabis
and wanted to leave but was told that he would be found and killed. Therefore, he remained at the
address. He was told that he would be paid £1,000 per crop. He was paid £300-£400 for food when he
first arrived. He had a key to the property but was told he could only leave once a month.

140. Neither the Police nor his legal adviser took any step to refer him via the National Referral
Mechanism to a Competent Authority for his status as a possible victim of trafficking to be explored. He
pleaded guilty on 9 July 2014 at the Preliminary Hearing in the Crown Court; he was represented by an 'in
house' solicitor advocate. Sentence was adjourned. On 28 July 2014 a first responder under the National
Referral Mechanism contacted the applicant's Solicitors who were, thereby, made aware of the National
Referral Mechanism being invoked. On 3 September 2014 it was agreed by the applicant's legal
representatives and the Crown that the Crown Court should proceed to sentence. He was sentenced on
the basis he was “a gardener” and of previous good character.

_Finding by the Competent Authority_

141. On 16 September 2014, the Competent Authority found there were reasonable grounds to believe
that he was a credible victim of trafficking. On 15 January 2015, the Competent Authority found the
grounds to be conclusive.

142. The basis of the applicant's application for leave to appeal his conviction is that in the light of the
fresh evidence he was a victim of trafficking, the offence was committed as a result of compulsion arising
from being trafficked into the UK and then re-trafficked internally at such a level that his culpability for his
offending was extinguished. Had this material been available at the time, either the public interest would
have determined that the matter should not have been prosecuted or a submission for the proceedings to
be stayed as an abuse of process would have succeeded. Alternatively, leave to appeal against sentence
is sought on the basis that the fresh evidence demonstrates his culpability was significantly diminished and
his sentence was manifestly excessive.

_The failure of the applicant to attend or contact the court_

143. However, he has failed to maintain contact with his solicitors, who were last in communication with
him in January 2016. He did not attend the hearing in this court. We have been provided with no
explanation as to why his solicitors have lost contact with him. There is no evidence that he has been retrafficked. He is a mature man in his mid-40s.

144. His absence prevents the court from being assisted on a number of key questions in our minds such
as whether he came here as an economic migrant, whether he had a key to the house, the extent to which
he was 'imprisoned' and whether he said he wished to return to Vietnam. Important issues cannot be
resolved.

145. Accordingly, we declined to hear these applications and adjourned them sine die. Should he still be
in this country and he comes to the attention of the Police then this court is to be notified forthwith so that
these applications may be then heard as speedily as possible.

**(6)        AA**

146. On 15 January 2010 in the Crown Court at Northampton the applicant, AA, having pleaded guilty to
one offence of possession of false identity documents with intent and one offence of fraud, was sentenced
to concurrent sentences of 6 months' imprisonment for each offence. Appropriate forfeiture and
destruction orders were made and a recommendation was made that she be deported. She was released
from custody on 12 March 2010.

147. Her applications for an extension of time of approximately 66 months and 27 days in which to apply
for leave to appeal against conviction and sentence and to produce fresh evidence comprising documents
from her immigration file have been referred to the full court by the Registrar.

_The factual background_


-----

148. On 9 October 2009 police and immigration officers conducted a search of 4 Pemberton Street,
Rushden, Northamptonshire in respect of a matter not unrelated to the applicant. They found a counterfeit
Zimbabwean passport in the name of “Natasha Khumalo” which bore a photograph of AA. A photocopy of
a Ugandan passport in the name of AA was also found.

149. She was not present at the address but was contacted by telephone and stated that she was in
London and that the authorities would not be able to trace her. Enquiries established that she had used the
counterfeit Zimbabwean passport together with a false National Insurance card to obtain employment in
the name “Natasha Khumalo” at an NHS Care Home for the elderly in Rushden, thereby committing the
offence of fraud. The Home Office held a record of the Ugandan passport in the name of AA that they
considered to be genuine.

150.  On 11 December 2009 she was arrested and identified herself as AA. She was interviewed the
same day and admitted the offences. She stated that she did not know her true identity, she did not want
to be returned to Uganda as she did not know anyone there; she had entered the country by lorry in 1999
and had paid for the Ugandan and Zimbabwean passports.

_Her plea and sentence_

151. She pleaded guilty to the offences at the Preliminary Hearing in the Crown Court. The sentencing
Judge stated the authorities were clear and the custody threshold had been crossed, but a long period of
imprisonment was not necessary.

_Subsequent events_

152. On 21 January 2010, at a time she was being held in immigration detention, AA claimed in an
interview that her real name was Alexandra Mimi and she had indefinite leave to remain in the UK. The
UKBA found no trace of such an application. On 4 March 2010 she was served with a notice of Liability for
Deportation. She responded with a statement, received by the Home Office on 11 March 2010, in which
she stated that her first memories were when she was aged 5 or 6 in Holland and that she had been
subjected to domestic servitude until she was 13. She was smuggled into the UK in 1999 to work as a
slave. She worked under false aliases for up to 14 hours a day, was locked up, provided with one meal a
day and was raped.

153. She extricated herself and, in 2005, went to reside with a friend. Upon the advice of her friend she
acquired a false Zimbabwean passport, national insurance number and birth certificate. She frequently
changed jobs due to immigration issues. On the advice of her friend she acquired a Ugandan passport for
€1200 and an application for indefinite leave to remain was made using the Ugandan passport.

154. Her claim for asylum was refused in June 2010 on the ground that she was AA, a Ugandan national,
born on 5 May 1986. She appealed the Home Office decision. Medical reports from Dr Charmain
Goldwyn, a doctor with expertise in interpreting scars and PTSD, referred to the presence of scars
consistent with her having been subjected to the violence she had described in her asylum claim. On 20
December 2011 an appeal against the deportation order was allowed on Article 3 and 8 grounds by the
First Tier Tribunal. She did not give evidence on account of her fragile mental health. On appeal on 16
April 2012 the Upper Tribunal found that the First Tier Tribunal had erred in law and set aside the original
decision; a rehearing before the Upper Tribunal was ordered. On 3 October 2013 she was diagnosed as
suffering severe depression with psychotic symptoms. On 18 October 2013 the Upper Tribunal held the
rehearing and on 24 October 2013 the Upper Tribunal dismissed her appeals under Articles 3 and 8. AA
did not give evidence; the Upper Tribunal found her account to be inconsistent.

155. AA instructed fresh solicitors who made further representations to the Home Office, submitting
medical evidence pertaining to her mental health and a report from a psychotherapist and anti-trafficking
consultant, Mirjam Thullesen, dated 20 February 2015. AA gave her an account that was consistent with
what she had said in her statement of March 2010. Her account of trafficking was deemed plausible and
contained a significant number of trafficking indicators which suggest that she is very likely to have been
trafficked. The assessment was based on her verbal account as well as her behaviour during assessment


-----

and comparison with other accepted victims. Her failure to disclose that she had been trafficked until after
her arrest was said not to render her account unreliable.

156. The Competent Authority reconsidered the case and concluded, on 15 July 2015, that she was a
victim of trafficking and she was no longer liable for removal on the ground that the circumstances which
gave rise to her status no longer pertained. Her solicitors are to be instructed to seek revocation of the
deportation order and make a fresh claim. She has been granted discretionary leave to remain for 30
months.

_The application to this court_

157. The fresh evidence in respect of which leave is sought is the expert trafficking report of Mirjam
Thullesen, the letter of Stephen Miller of the Competent Authority dated 26 May 2015 stating that there
were reasonable grounds to conclude she had potentially been the victim of trafficking and the letter of
Adam Brown of the Competent Authority dated 15 July 2015 concluding that she had been trafficked.

158. AA's case is that the indictment ought to have been stayed as an abuse of process as evidence has
become available which establishes that, at the time of her arrest and prosecution, she was a victim of
trafficking and that the offences with which she was charged were committed under compulsion as a direct
consequence of her being a victim of trafficking. Despite there being sufficient indicators at the time, which
should have alerted the police, defence, the Crown and the court to the fact that she was a victim of
trafficking, no inquiry was made by any party. As a consequence, the Crown failed to take into account
relevant considerations in the exercise of its discretion to prosecute and the court failed to consider
whether the indictment should be stayed. She has been assessed by an expert, received a positive
reasonable grounds decision and a conclusive grounds decision. She has been consistent about her
trafficking experiences, expanding on them as she has become more comfortable and there is
considerable medical evidence that supports her account.

159. The Crown acknowledged that there are strong indicators of human trafficking and there is evidence
that she was at or before the point of the offences a credible victim of human trafficking. There is also
evidence that a nexus of compulsion existed between the alleged trafficking and the alleged offending.
The Crown notes the presence of some anomalies and inconsistencies. However, the Competent
Authority has, since July 2015, carefully assessed and weighed the evidence, considered the decisions of
the First Tier Tribunal and the Upper Tribunal, had the benefit of expert evidence and found there are
conclusive grounds to believe the applicant was a credible victim of human trafficking. Her evidence was
neither heard not tested at the hearing before the Upper Tribunal. She raised her account at the outset
without legal advice. In all these circumstances, the Crown did not oppose the applications or seek to say
that the convictions are safe, conceding that had consideration been given to her status, it would or might
well have resulted in a decision not to prosecute her.

_Conclusion_

160. We have considered the case with great care. We admit the fresh evidence in the form of the letter
of the Competent Authority, but not the report of Mirjam Thullesen. We grant the extension of time.
Applying the principles to which we have referred earlier, we have concluded, not without very
considerable hesitation, that this is a case in which, on a review of all the admissible material now available
to us, she should have been treated as a credible victim of human trafficking and there was a sufficient
nexus of compulsion between her being trafficked and the commission of the offences to justify the
conclusion that, on investigation, the Crown would have decided not to pursue the prosecution. In
reaching that conclusion, we have taken into account the present position of the CPS and the principle set
out at paragraph 20.viii) above. We therefore allow her appeal and quash the conviction.

**End of Document**


-----

