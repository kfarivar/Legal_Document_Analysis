# R v Claxton [2023] EWCA Crim 1208

Court of Appeal, Criminal Division

Macur LJ, Goss J, Heather Williams J

6 October 2023Judgment

MS C TOPOLSKI appeared on behalf of the Appellant.

MS S ELLIS appeared on behalf of the Crown.

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

1. LADY JUSTICE MACUR: Lewis Abraham Claxton (“the applicant”) pleaded guilty on the third day of
trial to one count of being concerned in the supply of Class B drugs, namely cannabis, and one count of
being concerned in the supply of Class A drugs, namely cocaine. He had previously (on day 1 of the trial)
pleaded guilty to a count of being concerned in the supply of Class B drugs, based on joint purchase and
subsequent division of drugs with an associate, and simple possession of a Class B drug.

2. On 22 February 2022 he was sentenced to 3 years' imprisonment in relation to the offences concerning
Class B drugs, to be served concurrently, and 4 years' imprisonment, in relation to the Class A drugs, to be
served consecutively. He received no separate penalty in respect of the count of simple possession of
cannabis.

3. The applicant was represented throughout the criminal investigation and trial by solicitors. At trial he
was represented by counsel, Ms Deborah Morris.

**_The Present Proceedings_**

4. The applicant applies for a short extension of time in which to seek leave to appeal against conviction
and sentence and leave to introduce fresh evidence relating to his status as a victim of trafficking or
**_modern slavery, pursuant to section 23 of the Criminal Appeal Act 1968. The Registrar has referred the_**
applications to the Full Court.

5. The fresh evidence consists of the reasonable grounds decision, conclusive grounds notification and
decision minute of the Single Competent Authority, a witness statement of the applicant, a witness
statement of Ms Morris (trial counsel) and her original grounds of appeal, an email to from DC Taylor


-----

regarding the conclusive grounds decision dated 25 January 2022, and a psychological report of Mr
Shaapveld, a clinical and forensic psychologist, dated 10 January 2022.

6. We admit these documents for the purpose of considering the merits of the applications for permission
to appeal without objection by the respondent.

7. The applicant is now represented by Ms Clea Topolski. The prosecution is represented by Ms Ellis,
who adopts the Respondent's Notice, drafted by prosecution trial counsel who is unable to appear today.

8. There are two drafted grounds of appeal, namely that the applicant was erroneously advised that
without a positive conclusive grounds decision from the Single Competent Authority, a section 45 Modern
**_Slavery Act 2015 defence was unlikely to succeed, alternatively that the sentence is manifestly excessive_**
in light of the positive conclusive grounds decision.

9. However, the second ground of appeal has not been pursued. Ms Topolski realistically concedes that
all relevant information covered by the conclusive grounds finding, was taken into account in sentence.

**_The Facts_**

[10. On 17 December 2021 the police executed a search warrant, under the Misuse of Drugs Act 1971,at](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)
the applicant's home address. They seized £3,400 in cash, two mobile phones, drugs paraphernalia used
for the supply of cannabis and a small amount of cannabis. The applicant was arrested. The police also

searched the home addresses of others who became co‑accused, and seized similar items relating to

supply of both Class A and Class B drugs.

11. The police interrogated the phones seized from the applicant's address and found multiple messages
and tick lists apparently relating to the supply of drugs. Several messages were exchanged between the

applicant and his co‑accused. There were also bulk messages sent to multiple potential customers

advertising the availability of drugs.

12. In interview, the applicant provided a prepared statement, which was read into the interview record by
his solicitor, in which he stated that the money at his home address was the sum of disability payments
and prize money. However, when asked about the use and ownership of a Samsung mobile telephone he
“remained silent”, as he did when asked specifically about messages retrieved from the seized phones. He
was explicitly asked whether he or his family were being threatened or if he felt “forced into committing
crime” but “remained silent”.

13. In his subsequent Defence Statement the applicant detailed that he had been the subject of a serious
assault in 2017. Since that time his physical and mental vulnerability had been well known to those in the
area and, as a result, others took advantage of him and forced him to allow them to use his iPhone and,
on occasion, to send messages on their behalf. If the messages sent by the applicant in these
circumstances did involve the commission of an offence, he had acted under compulsion. He and his
family were subject to threats of violence.

14. In June 2021 the applicant was referred into the National Referral Mechanism by the Salvation Army.
On 6 July 2021 the Single Competent Authority made a positive reasonable grounds decision; that is a
preliminary decision that it appeared that the applicant may well have been the victim of modern-day
slavery. However, this was still to be ratified.

15. On 25 January 2022 (the first day of trial but prior to the jury being sworn) the applicant pleaded guilty
to being concerned in the supply of a quantity of cannabis to another. (See [1]). The prosecution then
proceeded to open the case and called the first of two police witnesses.

16. On 28 January (the third day of trial) the applicant pleaded to being concerned in the supply of Class A

and Class B drugs to another, on a 'full‑facts basis'. Other offences charged were left to remain on the file.

17. His trial counsel, Ms Morris, has prepared a witness statement dealing with the circumstances of how
those pleas came to be made. She states that she was aware that the applicant was awaiting the results
of the NRM referral On the first day of trial (17 January 2022) she had approached the prosecution


-----

counsel to inform him that she would be seeking an adjournment for the report to become available. The
officer in the case was present and said that there was going to be a negative finding and showed Ms
Morris the email she had received the week before from the NRM caseworker to that effect. (We
interpolate here that there is no suggestion that this information was provided other than in good faith.) Ms
Morris, then informed the applicant and her solicitor of this likely finding. She and the solicitor agreed that,
in the circumstances, there was no point in seeking an adjournment; the applicant repeated his desire to
plead not guilty and continue to trial.

18. The case was then adjourned to the following week. On 24 January 2022, the prosecution
commenced to open the case, and various defendants offered partial pleas. In Ms Morris' words the
opening was “comprehensive and spanned three days”. She advised the applicant in robust terms that,
without a positive conclusive grounds finding he would very likely be convicted at trial and that he should
consider his options carefully, as there would still be some credit available to him if he were to plead guilty.
The applicant then decided to enter guilty pleas because of the indication of a negative conclusive
grounds finding and the 'strength' of the opening.

**_Sentence_**

19. The judge found the applicant to be a middle-tier drug dealer, involved in the supply of significant
quantities of drugs. She accepted that his business centred on cannabis but he had also been involved in
the supply of smaller amounts of cocaine. For being concerned in the supply of Class A drugs, the judge
categorised the offence as category 2 significant role, which had a starting point of 8 years and a range of
6½ years to 10 years; and for being concerned in the supply of Class B drugs, category 2 leading role,
with a starting point of 6 years and a range of 4½ to 8 years. The judge disregarded his previous
convictions for simple possession of cannabis, she accepted that the applicant had a serious disability and
suffered personal difficulties as a result of the attack in 2017 but noted that it had not prevented him in
becoming involved in serious offending. She accepted that he was remorseful and took into account his
positive character references and the Covid restrictions in custody. She indicated that she took into
account totality and intended to impose consecutive sentences for the Class A and Class B drugs offences
but that they were shorter than they might otherwise have been. She reduced the sentences in light of the
applicant's medical issues and allowed just over 15 per cent credit for his late guilty pleas. The total
sentence was 7 years' imprisonment.

**_Appeal proceedings_**

20. Subsequently, in March 2022, the Single Competent Authority made a positive conclusive grounds
decision, confirming that the applicant was considered to be a victim of trafficking at the time of the
offending. These applications were then launched on his behalf.

21. The applicant states in a witness statement prepared for these proceedings that he had freely pleaded
guilty to being concerned in the supply of Class B cannabis to his associates. He pleaded guilty on day 3 of
the trial to the other counts, because Ms Morris said that he had a “one in ten chance of being acquitted
and that my sentence would likely be in the double figures range”. He had found it extremely difficult to
plead guilty to something he knew he had been forced into and “stood my ground for three days until I was
eventually broken down. I was told to think of my family and young son, so I did what I was advised to do
and plead, which I thought was in my best interest ... I feel like I was pressured to because I was made to
feel that without a positive conclusive grounds decision, that I no longer had a defence under section 45
**_modern slavery”. He then repeated the contents of his Defence Statement which go to the section 45_**
defence.

22. The application for permission to appeal is opposed by the prosecution, who submit that the statement
of Ms Morris makes clear that the applicant was fully advised of the availability of a section 45 defence, but
also robustly advised as to the strength of the prosecution case. That advice was not erroneous. The
conclusive grounds decision was “wholly lacking in any analysis of the evidence”. There is ample evidence
against the applicant in the text messages retrieved from his phone in which he revealed himself to be an
“enthusiastic drug dealer”. There was no hint in those messages, which span a long period, of his being a


-----

victim of modern slavery, or of his phone being used by anyone else. He did not mention exploitation in
interview, nor did he explain the presence of a hunting knife found at his home. . The applicant's defence
had no prospect of success.

23. There is no dispute about the relevant principles of law to be applied and which we summarise to be
as follows:

1. A conclusive grounds finding, whether positive or negative, is inadmissible at trial but is admissible on
appeal, assuming it is necessary and expedient to receive such evidence (see R v AGM [2021] EWCA
920, at paragraph 43, confirming R v Brecani [2021] EWCA Crim 731).

2. The sole responsibility of the Court of Appeal is to determine whether the conviction is unsafe (see R v
[AFU [2023] EWCA Crim 23, at paragraph 91)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)

3. The Court should be cautious when overturning convictions following a guilty plea:

“The defendant having made a formal admission in open court that they are guilty of the offence will not
normally be permitted to change their mind. The trial process is not to be treated as a tactical game.” (see
[R v Asiedu [2014] EWCA Crim 567)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-N401-F0JY-C1S4-00000-00&context=1519360)

4. A guilty plea may be vitiated in circumstances where there has been erroneous legal advice as to a
possible defence, even where the advice may not have been so fundamental to have rendered the plea a
nullity, if its effect was to deprive the defendant of a defence which would probably have succeeded (see R
[v Tredget [2021] EWCA Crim 108, at paragraph 158).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61YN-6JY3-GXFD-827G-00000-00&context=1519360)

5. The Court of Appeal is not bound to accept the substance of a conclusive grounds finding (see R v AAJ

_[[2021] EWCA Crim 1278, at paragraph 39(7)).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63DC-GJY3-CGXG-006X-00000-00&context=1519360)_

**_The oral evidence_**

24. Ms Morris and the applicant have given oral evidence confirming their witness statements.

25. Ms Morris said that she had advised the applicant of the strength of the case against him, having
heard the way the prosecution had “knitted together” the messages found on his phone. However, her
advice was also influenced by reason of what she believed would be a negative finding as to his status as
a victim of trafficking. She said that if she had known that there would be a positive conclusive grounds
finding, then she would have sought an adjournment in order for the prosecution to review the case against
the applicant. She was aware of Brecani (see [23] (1) above) but f the case proceeded to trial, she would
have sought leave to admit the positive conclusive grounds finding into evidence

26. In cross‑examination, she repeated that after the prosecution had opened the case at length, her

advice to the applicant was robust and in terms that he did not have a chance. She had based her advice,
in part, upon what she believed would be a negative conclusive grounds finding, however, she did not
advise the applicant that he was unable to mount a defence pursuant to section 45 of the Modern Slavery
Act 2015, absent a positive conclusive grounds finding.

27. The applicant has given his evidence with all due dignity and has obviously striven to assist the Court
as to the circumstances in which he came to plead guilty. He confirmed that he received robust advice
from Ms Morris in terms that “I was fucked and told that I had a one in ten chance of winning”. We accept
that evidence and that he was subject to the pressure of the court proceedings. His evidence was
consistent with his witness statement: he did not initially take counsel's advice but pondered upon it, and
eventually was persuaded to plead guilty faced with the prospect of a prison sentence in double digits if
convicted by the jury, as opposed to a lesser sentence if he pleaded guilty in “a deal”. He said that he
entered his plea freely on the basis of that advice but he was also under the impression that this advice
was in no small part due to the fact that there was an anticipated negative conclusive grounds finding in
the offing.

28. When asked in cross examination about the understanding he had of the evidence against him, he
accepted that he understood that the prosecution placed great reliance upon the telephone messages,
both oral and te t hich ere fo nd on his phone and implicated him Ho e er he maintained that he


-----

pleaded guilty because he had “no leg to stand o” by reason of there being “no NRM” and not by reason of
him accepting the 'reality of the situation' that the jury would be unpersuaded by his version of events.

29. He said that he had not told the solicitor who represented him at the time of interview that he was
being manipulated and coerced into commission of the offences. He could not answer why there was a
lack of particularity in the Defence Statement, which he had left to his solicitor. However, when asked, he
was unable to explain the very large number of telephone and text messages which appeared to have
emanated from him over a significant time span and seemed to relate to drug dealing, and did not
particularise the manner in which he had been exploited beyond saying that his vulnerabilities were known
by those who lived in the area who without any prior arrangements having been made, if they saw him in
the road or in the park would approach him and make him send messages. He knew the identity of one of
his exploiters but did not wish to name him as he feared for his life having been the victim of a savage
attack previously.

30. In her submissions, Ms Topolski, draws our attention to the original grounds and advice on appeal
drafted by Ms Morris after receipt of the positive conclusive grounds finding. Ms Morris had sought
permission to appeal on the basis that the conclusive grounds finding would be admissible at trial. This led
Ms Topolski, to submit with all due diffidence having regard to the criticism of a fellow member of the bar,
that Ms Morris's advice to Mr Claxton was more likely to be in terms that a negative positive grounds
finding would negate the defence.

**_Our Findings_**

31. There is no available contemporaneous endorsement referring to the advice given to the applicant
leading to a change in plea. We accept Ms Morris's advice that is was her usual practice to do so, but we
can have no confidence that on this occasion such an endorsement upon her brief was made or that the
applicant signed it. In the event, this carries the matter no further forward since there is very limited
factual dispute as to the terms in which the advice on the prospects of success was tendered; Ms Morris
indicates that she referred to the dual aspect of negative conclusive grounds finding and the strength of the
evidence, and the applicant focuses upon the negative conclusive grounds finding.

32. We accept Ms Topolski's submission that Ms Morris did appear to misapprehend the relevance of the
SCA finding and therefore the advice that she gave to the applicant may well have been unclear.
However, we are not persuaded that Ms Morris advised the applicant that, absent a positive conclusive
grounds finding, he did not have a defence pursuant to section 45 of the Modern Slavery Act 2015.  We
find, as a fact, that her advice to the applicant was robust and in the terms that he recalled either during or
shortly after the conclusion of the prosecution opening.

33. We accept the evidence of Ms Morris, which indicates that the nature of the opening was such as to
make her appreciate the strength of the case against the applicant and that  the applicant took time to
consider his position. When he did make his decision, for whatever reason, the plea was unequivocal.

**_Discussion following making of those Findings of Fact_**

34. Section 45 of the Modern Slavery Act 2015 provides that a person is not guilty of an offence if:

“(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.”

35. The questions for us on the application for permission to appeal against conviction are: (i) did Ms
Morris provide erroneous legal advice regarding the availability of the section 45 defence; and (ii) if so,
would this defence probably have succeeded?


-----

36. We have already indicated that we are not satisfied that the evidence does disclose that Ms Morris
tendered erroneous legal advice per se. There is no evidence that she informed the applicant that he was
unable to pursue the defence, merely that his prospects of success were negligible absent a positive
conclusive grounds decision. We accept that her evidence was indicative of some ambiguity, in that it
suggested that a conclusive grounds decision, positive or negative, could play any part in the trial
proceedings. The positive conclusive grounds decision, as it subsequently transpired to be, could not
determine the prospective section 45 defence to be run before the jury. It was inadmissible, whether
positive or negative, and its only potential worth, prior to trial, was to seek to persuade the prosecution that
it would not be in the public interest to proceed. However, as is clear from the respondent's notice filed,
and confirmed by Ms Ellis today, there was no realistic prospect that the positive grounds finding, in this
case, would have had that effect.

37. Ms Morris has emphasised in her witness statement and evidence the strength of the prosecution
opening. Her opinion of the applicant's prospects would have to be based upon the evidence as she
interpreted it to be. The advice she gave was obviously her professional opinion of the prospects of
success. We do not find that this amounted to legal advice that a negative conclusive grounds decision
precluded a section 45 defence in law. That the applicant did not immediately accept her advice and only
felt “pressured” into pleading after three days of repeated advice to “think of his family” confirms this; that
is, he continued to believe that he had a prospect of successfully defending himself against the charges.
His resolve faltered because he was told to “think of his family” and his best prospect of achieving a
reduced sentence.

38. There was no ambiguity in the plea that he tendered. We find no adverse or undue pressure upon him
to plead guilty. However, even if we had found that the applicant had been led to believe that the
conclusive grounds decision was determinative to lead him to change his plea, we are not satisfied that a
section 45 defence would have succeeded.

39. We find little assistance in the conclusive grounds decision, which we consider to be deficient in its
failure to realistically appraise the applicant's account as against the prosecution evidence, most
particularly the contents of the recorded spoken telephone messages and the text messages and the other
paraphernalia found in his home. We are struck by the applicant's silence at interview in respect of
questions, which specifically sought to investigate the issues of exploitation and compulsion. Whilst his
reluctance to speak to police may be understandable, his unwillingness or inability to raise these issues
with his solicitor, whom he had already instructed as regards the origin of the moneys found and the

tick‑box application on his mobile phones. Further, we find his assertion that dealers would use his

telephone to make profitable deals, delete messages and nevertheless require him to act as a messenger,
absent any detail as to where or how he was to contact them, to be fanciful.

40. Finally, there is no evidence to suggest that he lacked the ability to seek assistance to escape this
asserted exploitation. Acknowledging that he would expose himself to risk if he named his exploiters, there
was no good reason why he could not at least have indicated during interview the way he was being
exploited.

41. Consequently, we do not consider that there is any good basis upon which to vitiate the guilty pleas
tendered. The application for permission to appeal is unarguable.

**_Sentence_**

42. Ms Topolski has already realistically conceded that the application for permission to appeal against
sentence is unarguable. The authority upon which she initially relied, namely R v N _[2019] EWCA Crim_
_984 at paragraph 20(iv, ) is not authority for the proposition that a positive conclusive grounds finding of_
itself affords mitigation, but it is the information put before the Single Competent Authority which may. In
this case, we are satisfied that the judge, took into account all factors relating to this applicant's disability.
There can be no dispute about the categorisation of these offences. It is clear, therefore, that the judge
made a significant reduction to reflect medical issues, totality, and plea. The sentence cannot arguably be
said to be manifestly excessive.


-----

**_Our conclusions in summary_**

43. We extend time in which to make the applications for permission to appeal against conviction and
sentence. We admit and have regard to the fresh evidence for the purpose of considering the applications
for permission to appeal. We dismiss the applications for permission to appeal conviction and sentence.

LADY JUSTICE MACUR: Ms Topolski, we do not conclude without, first of all, thanking you for the
undertaking of this sensitive and difficult case; secondly, for the quality of your submissions and also to
commend Mr Claxton for his arrival, on time, at court today and also the manner in which he gave his
evidence. We know that the result will be disappointing to him but we, I am sure, can say that we have had
regard to all matters that could and has been so very properly put by you before us. Ms Ellis, thank you
also for taking the reins of the respondent at late notice.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

