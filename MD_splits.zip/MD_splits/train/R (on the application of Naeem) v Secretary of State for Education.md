# R (on the application of Naeem) v Secretary of State for Education [2022]
 EWHC 15 (Admin)

Queen's Bench Division, Administrative Court (London)

Foster J

6 January 2022Judgment

Ms Amanda Weston QC and Ms Gráinne Mellon (instructed by Watkins Solicitors) for the Claimant and Interested
Party

Mr Leon Glenister (instructed by Government Legal Department) for the Defendant

Hearing date: 18 November 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

MRS JUSTICE FOSTER DBE

**Mrs Justice Foster DBE:**

Introduction and The Issue

1. This application brings a challenge to the Education (Student Support) Regulations 2011 (as amended),
(“the Regulations”). The Regulations are made by the Defendant Secretary of State for Education and
contain the eligibility requirements for provision of student finance to would-be higher education students.

2. By section 2(a) of Schedule 1 to the Regulations the Claimant was required to be “settled in the United
Kingdom” in immigration terms, on the first day of the first academic year of his course, that is to say by 1
September 2020 to be eligible for receipt of student finance.

3. The Claimant challenges the Defendant's refusal of his application for finance under the Regulations on
the grounds he did not satisfy the requirement to be “settled” on 1 September 2020. His case is that
applying this requirement to him was discriminatory contrary to Article 14 of the European Convention on
Human Rights (“ECHR”) read with Article 2 of the First Protocol to the Convention (“A2P1”).

4. A further argument in respect of Article 1 of the First Protocol to the Convention was also raised but,
although not conceded, not pursued in this case since the Defendant accepts the application of Article 14
read with A2P1 to the issues but denies any infringement of rights.

5. The Claimant made an application for settled status in May 2020. He had in previous applications used
the Home Office Super Priority visa application service which grants visas within twenty-four hours on
payment of a fee. A similar Priority Service granted visas on payment of a smaller fee within five working


-----

days. If no fees are paid, the turnaround offered by the Home Office for disposal of an Indefinite Leave To
Remain (“ILR”) Visa application is six months. With only a few days' notice, the Priority channels were
withdrawn by the Home Office on 31 March 2020, unknown to the Claimant until he sought to submit his
application on 17 May 2020. He had no alternative but to make his application by the slower route. The
Claimant achieved his place at university and made his application for student finance on 24 August 2020.
His evidence is that he fully expected to be granted settled status, as he was aware he fulfilled the
immigration criteria, accordingly in his application he stated that he was entitled to settled status.

6. In the event, the Claimant chased the Home Office on several occasions, but was only offered an
extension to his limited leave to remain pursuant to section 3C of the Immigration Act 1971, and so the
Claimant started his course on 25 September 2020 without finance but incurring fees. On 23 November
2020 he was granted Indefinite Leave To Remain and acquired settled status. By letter of 18 December
2020 he was informed that he was ineligible for student finance because he had not met the 1 September
2020 deadline. The same day the Claimant began the statutory two-stage appeals process against the
decision. That process was exhausted, unsuccessfully, on 24 February 2021 whereupon he referred his
case to an Independent Assessor and thereafter entered into pre-action correspondence.

7. The Claimant argues that in the context of the Covid-19 Pandemic the application of the requirement to
be settled in the United Kingdom on 1 September 2020 the first day of the academic year of his course,
as provided by section 2(a) of Schedule 1 to the Regulations, discriminated unlawfully against him contrary
to Article 14 of the ECHR.

8. The Interested Party is a citizen of South Africa and in substantially the same position as the Claimant,
having been caught by the withdrawal of the priority schemes at a time when it was too late to acquire ILR
through the only remaining six-month route.

The Framework

9. The power of the Secretary of State for Education to make Regulations derives from section 22 of the
Teaching and Higher Education Act 1998 as amended (“the 1998 Act ”) which provides relevantly

_“(1) Regulations shall make provision authorising or requiring the Secretary of State to make grants or_
_loans, for any prescribed purposes, to eligible students in connection with their undertaking —_

(a)  Higher education courses or

_(b) further education courses, which are designed for the purposes of this section by or under the_
_Regulations_

_(2) Regulations under this section may, in particular, make provision –_

_(a) for determining whether a person is an eligible student in relation to any grant or loan available under_
_this section.”_

10. The relevant requirement of eligibility appears as follows in Regulation 4 of the Regulations:

_“(1) An eligible student qualifies for support in connection with a designated course subject to and in_
_accordance with these Regulations._

_(2) Subject to paragraph (3), a person is an eligible student in connection with a designated course if in_
_assessing that person's application for support the Secretary of State determines that the person falls_
_within one of the categories set out in Part 2 of Schedule 1.” (emphasis added)_

11. The relevant eligibility category in FN's case is set out at paragraph 2 of Schedule 1 of the Regulations
and is entitled 'persons who are settled in the United Kingdom'. It provides relevantly:

_“(1) A person who on the first day of the first academic year of the course—_

_(a) is settled in the United Kingdom other than by reason of having acquired the right of permanent_
_residence;_

_(b) is ordinarily resident in England;_


-----

_(c) has been ordinarily resident in the United Kingdom and Islands throughout the three-year period_
_preceding the first day of the first academic year of the course; and_

_(d) subject to sub-paragraph (2), whose residence in the United Kingdom and Islands has not during any_
_part of the period referred to in paragraph (c) been wholly or mainly for the purpose of receiving full-time_
_education._

_(2) Paragraph (d) of sub-paragraph (1) does not apply to a person who is treated as being ordinarily_
_resident in the United Kingdom and Islands in accordance with paragraph 1(4).”_

12. 'Settled' in paragraph 2(1)(a) above is defined in paragraph 1(1) of Schedule 1 the Regulations having
_'the meaning given by section 33(2A) of the Immigration Act 1971'. It provides that:_

_“[…] references to a person being settled in the United Kingdom are references to his being ordinarily_
_resident there without being subject under the immigration laws to any restriction on the period for which he_
_may remain.”_

13. Regulation 2 defines “academic year” as:

_“the period of twelve months beginning on 1st January, 1st April, 1st July or 1st September of the calendar_
_year in which the academic year of the course in question begins according to whether that academic year_
_begins on or after 1st January and before 1st April, on or after 1st April and before 1st July, on or after 1st_
_July and before 1st August or on or after 1st August and on or before 31st December, respectively;”_

14. The effect of the scheme for both Claimant and Interested Party is that a failure to achieve the criteria
for the receipt of student finance on the first day of the first term of the first year of the course, means no
finance is payable for the whole of the academic course. The effect of this is that debts incurred to date
are payable, yet because eligibility to student finance support is established at the beginning of a student's
course, a student remains ineligible for support for the duration of the course if the 1 September 2020 date
is missed. As each of the appeal decisions acknowledged, and the Independent Assessor, there is no
relevant compassionate or other discretion to disapply the requirements of the Regulations.

Factual Background

15. The Claimant Mr Jawad Naeem is a citizen of Pakistan who was born on 27 November 1987. He is a
currently a second-year student at Nottingham Trent University where he is studying for a BSc degree in
Computer Science (Cyber Security). His current position is tenuous because of his inability, without a loan
from student finance, to fund his place.

16. Jawad Naeem entered the UK on 14 April 2015 as the spouse of a person settled here. On 13
December 2017 he was granted a visa extension with limited leave for 2½ years. Accordingly, his visa was
due to expire on 18 May 2020. On 14 April 2020 he became eligible to apply for Indefinite Leave to
Remain (“ILR”) as a partner on what is known colloquially as the '5-year route', outlined in Appendix FM to
the Immigration Rules. He was only entitled to apply for such an extension during the window of his last 28
days' currency of his limited visa.

17. The Claimant had applied for a place at Nottingham Trent University to study for the degree. He was
accepted for the course commencing in September 2020 and, explains that he gave up his employment in
order to attend the university and better his and his family's prospects. He had been made aware that he
was entitled to ILR and lodged his application for settled status. He had utilised the fast track before and
has deposed he intended to on this occasion.

18. Under the Super-Priority Service utilised previously, the 24-hour service cost £800 whilst the Priority
Service five-day turnaround would be guaranteed on payment of £500. When he spoke to his solicitor,
they discovered that both services had been withdrawn by the Home Office citing the effects of the
Pandemic. The compulsory online application process had no provision for urgency. The Home Office
had also closed all UK Visa and Citizenship Application Centres and Service and Support Centres. The
Claimant was unable to communicate the urgency of his application.


-----

19. Kyra Morris, the Interested Party, is a citizen of South Africa born on 11 February 1999, moving to the
UK 10 August 2015 as a child dependent upon the Ancestral visa held by her father. Kyra Morris
completed her A-levels in the UK in 2017, following which she intended to read Physics and Astrophysics
at the University of Bristol. She was unable to afford the international fees and so required to be qualified
as a Home Student.

20. Accordingly, on 2 July 2020, she made an application for ILR intending to use the Super Priority
Route. She was unaware until some weeks after that she required funding to be in place by 1 September
2020 for starting in the Autumn Term.

21. Given the Covid 19 delays and the loss of the Super Priority Route, she contacted her local MP to
help, following which her application was dealt with speedily, but she achieved ILR only on 4 September
2020. The University of Bristol agreed to classify her as a Home Student nonetheless, but she was
informed on 18 November 2020 that because ILR was not in place on 1 September, she had been refused
student funding.

22. Ms Morris began her Physics and Astrophysics course on 5 October 2020 but has been warned unless
she can pay her first year's fees she may be unable to continue to the second year. She is without the
means to do so and so far owes a debt of £9,250 which will remain outstanding even if she is unable to
continue her course. Because of the effect of the failure on 1 September 2020 under the student finance
scheme, she is ineligible for funding for the whole of the rest of the course.

23. The evidence before the court as to the Home Office website was not complete but suggested that on
23 March 2020 a warning was posted to the visa application website stating that the priority and superpriority services would be withdrawn on 30 March 2020. The effect of this is that given that the general
service indication for ILR visas is a six month turnaround, the warning of 23 March 2020 came too late for
any person whose visa application was made, (by my calculation, and allowing no margin for error) after
Friday 28 February 2020. That date was the last working day when a six month turnaround would have
been expected to have produced a decision before 1 September 2020 for Autumn commencement.
Applicants, who needed to rely upon the Priority Services, would be unable to acquire ILR in time to
comply with the Regulations.

24. The Claimant accepted a place at university to study for a BSc Honours degree in Computer Systems
(Cyber Security). On 24 August 2020 (still not having heard in response to the visa application) he made
an application for student finance to the Defendant, filling in the appropriate forms. In those forms he was
asked about his settled status and he put “ILR” and gave the application reference number. Whilst the
Secretary of State did not contend this was actually dishonest, he observed that “at a minimum Mr Naeem
should have known he was not entitled to ILR”. (In the event, a visa was granted on 23 November 2020, in
the usual course, without query.)

25. On 28 August 2020 the Claimant emailed the Home Office at their contact address for coronavirus
issues, requesting a letter to provide to the University to confirm his ILR status/eligibility. However,
instead, on 1 September 2020 his limited leave to remain was extended pursuant to section 3C of the
Immigration Act 1971 – which did not entitle him to student finance.

26. The Claimant nonetheless continued to chase and started the course on 25 September 2020 hoping
matters would be resolved.

27. Student Finance England who administer student finance asked him for settled status information on 9
October 2020 – but by this date no reply had been received. He emailed the Home Office again on 20
November 2020 telling them of the request. On 23 November the Claimant was informed that a Biometric
Residence Permit was being sent and an attached information sheet confirmed his application for ILR had
been approved with confirmation by way of the Biometric Residence Permit. It appears that on or about 21
September 2020 the Home Office told Student Finance that Mr Naeem had applied in time, but the
outcome was still outstanding. He was deemed ineligible for student finance on 18 December 2020 in the
following terms:


-----

“As Mr Naeem's ILR was not granted prior to 1st September 2020, he cannot be seen as entitled within the
_UK for the purpose of student finance on the first day of the academic year.”_

By this date, the Claimant had of course received his ILR status, but it was not extant prior to 1 September
2020.

28. The Claimant submitted a Stage 1 appeal against the decision on 18 December 2020 explaining his
position and intention to use the Super Priority Service, indicating that the application of the Regulations
meant he would be personally liable for the fees incurred and that he could not afford to drop out and defer
his course for a year. On 1 February 2021, being without response to the appeal, he made a complaint.
The response was communicated the following day indicating the framework required that status as at the
1 September 2020 had to be considered. A Stage 2 appeal was issued by the Claimant on 4 February
2021 in similar terms to the Stage 1 appeal. The appeal body responded on 24 February 2021 that the
jurisdiction was limited to considering the proper application of the Regulations. Student Finance England
confirmed to him this was the effect of the decision.

29. An Independent Assessor considered a request by him for consideration and on 19 May she accepted
the facts advanced by the Claimant, namely that he intended to use the Super Priority Service and
concluded it was “through no fault of his own” that he did not have ILR by 1 September 2020. She
concluded the Claimant was unlikely to be able to complete his course without a student loan but was
compelled to conclude that the Claimant did not meet the requirements of the Regulations because of the
limits of her jurisdiction. The Interested Party also exhausted the appeal route, unsuccessfully, but with
similar comments as to the unfairness of her position. Although to an extent challenged by the Defendant,
I see no reason not to accept the underlying facts as they were found by these Tribunals.

30. The Claimant and Interested Party rely also upon the publication of a policy entitled “Government
_support package for higher education providers and students” for an illustration of what they regard as the_
unfairness of the position compared with the allowances made for foreign students coming to study here.
They note it said:

_“The government is clear that we do not want to see students miss out on the opportunity to benefit from_
_our excellent HE system as a result of Covid 19”._

31. This position was echoed during Parliamentary Questions and Answers on 22 June 2020. Gillian
Keegan, Minister for Apprenticeships and Skills at the Department for Education said:

_“In May we announced a package of measures to support our universities and safeguard the interests of_
_students. This means that every student who wants to go to university and gets the grades can achieve_
_their ambitions.”_

The support package referred to a:

_“discretion to ensure that international students are not negatively impacted if they find themselves in a_
_position where they cannot comply with certain Visa rules as a result of the Covid 19 outbreak”_

32. There were specific changes introduced through new guidance or amended guidance. The applicants
draw attention to the following:

i. _“Guidance for students from England Wales and Northern Ireland” published on 27 August 2020,_
_indicating that eligibility for student finance would be extended to individuals unable to meet UK residency_
_requirements due to Covid 19: this was a policy statement by the Student Loans Company_

ii. “Covid 19: Guidance for Student sponsors, migrants and Short-term students”, under which international
_students were permitted to begin their courses before their Visa applications had been decided_

iii. “Coronavirus (Covid-19) fact sheet: Visa holders and short-term residents in the UK 9 April 2020 giving
_permission for Tier 4 students to comply with Visa requirements through distance learning._

33. Reliance is placed upon the contrast between these concessions to the effects of the pandemic for
others, and the suspension of the Priority and Super Priority Services at the end of March 2020 to show


-----

that in some areas accommodation was made for the effects of the Pandemic on applications. Indeed
eligibility was extended to those who could not meet residency requirements. The Defendant indicated
they related principally to travel issues.

34. In the course of the Claimant's pre-action correspondence with the Defendant he invited the Defendant
to review the application of the Regulations during the currency of the Covid 19 Pandemic to individuals
who had an outstanding application on the first day of the first year of their academic course and who meet
the requirements for ILR such that they would have been “settled” but for the suspension of the Home
Office priority service. The Defendant was invited to amend the Regulations with retrospective effect to
provide student funding for individuals within that class. He agreed to a review but declined to make any
changes.

35. The Super Priority Service appears to have been restored in respect of all ILR applications in the early
months of 2021. Apparently there has been some but not extensive restoration of the Priority Service.

The Defendant's Position

36. The Secretary of State and Minister of State for Universities were provided for the purposes of the
review with a Ministerial Submission recommending rejection. The Ministers adopted the reasoning in the
Submission and refused to accommodate the claim of the Claimant and Interested Party under the
Regulations or otherwise.

37. The Secretary of State relies in these proceedings on the reasoning of the Submission.

38. The Ministers declined to make any changes:

“given the operational importance of maintaining clear rules on eligibility, and the serious difficulties in
_introducing a retrospective change that would apply only to students affected by the Home Office action.”_

This was explained in the following way:

i. Both claimants were aware when they made their application for ILR that the priority service was not
available and that the turnaround for their application would be up to six months. Further, they both began
their courses knowing that they did not meet the requirement to be settled at the relevant date (or if they
did not know, they should have known).

ii. If the Claimant and Interested Party had begun an academic course starting after January 2021 (thus
delaying the start of their courses by only a few months, or by one year for the same course in September
2021) they would meet the requirement to be settled on the first day of the first academic year of the
course so it was not the case they were denied access to Higher Education rather, they may need to defer
for no more than one year.

iii. High-level caselaw (Tigere) supported the legality and rationality of having clear bright line rules on
eligibility for student finance, and the lack of an “exceptional circumstances” discretion was lawful, an
individualised system would have very powerful disadvantages.

iv. It was justifiable to maintain the requirement in the Pandemic even given the withdrawal of the Home
Office priority services because, applying the requirement to be settled on the first day of the first academic
year of the course always meant that some students have fallen on the wrong side of the relevant date by
a few days, and sometimes for reasons beyond their control e.g. where the HO has not met its own service
standards, or because key documents have been lost by a third party. “It is not obvious that such persons
_would be any less 'deserving' than the current claimants.” This requires a general power of exceptions and_
that would be a very difficult system to operate fairly. The SoS would have to make judgements on
decisions made by other Ministers.

v. Second, any scheme would have to be of general application as it would be very difficult to provide an
exception which applied only to the claimants. Such a scheme would require evidence of whether, had it
not been for the withdrawal of that service the student would have use the priority system, whether there
was an outstanding application on the first day of the course and whether that application was


-----

subsequently granted. It would be necessary to discover whether the delays were as a direct result of the
withdrawal of the super priority service; and that would be impossible.

vi. It would allow students who never intended to use the service to claim student finance earlier than
entitled under the Regulations. Accordingly it would have to cover all who applied for ILR between 30
March 2020 and 31 March 2021. Statistics show there were 95,120 decisions on applications for
settlement in the UK from non-EEA nationals in the year ending March 2020. Even if the Regulations
could be amended retrospectively it would have to be applied as a blanket policy i.e. if a person can show
they applied for ILR between these dates and were subsequently granted it, they could have the
requirement to be settled on the first day of the first academic year waived and would be eligible for funding
for the entirety of their course. This opens up the scope for funding considerably and would inevitably
bring into scope a significant number of students who did not meet the settlement year rule solely as a
result of their own actions.

vii. A significant number of students may have refrained from application knowing they were not eligible,
they may have self-funded, others may have deferred their studies until they became eligible. It would not
be fair on them to have a scheme that made exceptions that benefited these applicants.

viii. Fourth, they should have known of the requirements and when they applied would have been aware
the priority service was not operating and they would be considered under the standard Home Office
timeframe, and when they made their application for student finance they should have known they were not
eligible.

39. The Minister concluded that a scheme to allow the Claimant and Interested Party to obtain finance
now was not a proportionate response to the “slight delay in obtaining settled status”, and therefore,
student funding.

40. The Secretary of State represented by Mr Leon Glenister did not take issue with the framework within
which the application for judicial review took place. He disputed, however, the basis upon which status
was asserted. The first basis for “other status” was derived from the Statement of Facts and Grounds in
terms that the Claimant was “a person who meets the requirements of ILR under the Immigration Rules but
_he was prevented from meeting the eligibility of the Regulations by suspension of the Home Office priority_
_service”. This is later described in the skeleton argument, he observes, as “students who owing to the_
_suspension of the Home Office Priority Service/Super Priority Service between 30 March 2020 and 31_
_March 2021 were granted ILR after the first day of the first academic year of their course, where they would_
_have been granted ILR before the first day of the first academic year of their course had the priority service_
_remained in operation”. This status cannot be relevant he argues because the Claimant asserts he was_
treated differently from 1 September 2020 because it is at that date that he suffered the detriment of not
meeting the requirement.

41. Mr Glenister says this means his “other status”, by reason of which he was discriminated against, must
be that he had limited leave to remain with an outstanding application for ILR – in his skeleton argument
the Secretary of State says the Claimant had not expressed his claim in this way so must fail. He also
raises a further point: the effect of what the Claimant says amounts to asserting a status which seeks to go
behind his formal immigration status which is equivalent to prejudging the application to be determined by
the Home Office, and it cannot form the basis of a claim to differential treatment – of course the treatment
is different, because the status is different.

42. This case is different from the situation in _Tigere, he argues, where what was compared was an_
immigration status, namely discretionary leave to remain, that shared similar characteristics to the ILR in
terms of its connection to the UK but did not carry with it the student finance consequences of ILR. Further
and in any event, the asserted status is merely a “description of the difference in treatment” as opposed to
the “ground of the difference in treatment” which R(SC, CB and 8 children) v Secretary of State for Work
_and Pensions [2021] UK S 2671, describes. The status asserted contains the phrase he was “prevented_
from meeting the eligibility criteria by suspension of the Home Office priority service”, but that is, he said
“open to significant interpretation”. In any event, the fact he was “prevented” from obtaining ILR is not a


-----

part of the ground of difference in treatment. The reason he was treated differently, was that he had limited
leave to remain.

43. Mr Glenister relies upon the case of R v Docherty [2017] 1 WLR 181at paragraph 63. In that case, the
Claimant said he was discriminated against by being treated less favourably than a prisoner who had been
convicted on a different date. By that different date, the law had changed and the nature of the sentence
available for that other person had changed, it was more lenient than that to which the Claimant was
exposed.

44. Lord Hughes giving the judgement of the court stated:

“[63] … even if it be assumed in the appellant's favour that the mere date of conviction can amount to a
_sufficient status, which is doubtful, the differential treat in treatment is clearly justified. All changes in_
_sentencing law have to start somewhere. It will inevitably be possible in every case of such a change to_
_find a difference in treatment as between a defendant sentenced on the day before the changes effective_
_and the defendant sentenced on the day after it stop the difference of treatment is inherent in the change in_
_the law. If it were to be objectionable discrimination it would be impossible to change the law.”_

45. Mr Glenister submitted there was in truth no “other status” than the difference in immigration position.
The Claimant was treated in the same way as any other individual who, for example could not afford the
priority service, or had a delay in considering their application. He was justifiably treated differently to
somebody who had already been granted ILR and this application requires the Defendant to second-guess
an application for ILR.

46. Mr Glenister defends the bright-line rule of 1 September cut-off date as a practical part of its operation
which inevitably means some students might miss the deadline for reasons beyond their control. Such
students are as “deserving” as the Claimant; the detriment to the student was not great because they
needed only to delay the start of their course for a few months or at worst a year.

47. He further argued that the Claimant was aware or should have been aware of the requirement of 1
September 2020 and in stating that he had been granted ILR and was “settled” was wrong – that was why
he was in the position he was now in. The same could be said, as I understand his submission, for the
Interested Party who began the course knowing she did not meet the criteria for student finance. I
understood this to be his argument against any suggested detriment to the students on the basis that they
had incurred fees and would be left high and dry, with debts but no course to continue were their
applications to fail.

48. A central tenet of the Secretary of State's refusal to accede to the claims, and of Mr Glenister's
defence of the claim was what were described as the unfairness to others who might be in similar
positions, but who would not obtain relief. Emphasis was laid on the further ramifications if any exception
were to be made in respect of this claimant and Interested Party.

Consideration

49. Ms Amanda Weston QC and Ms Grainne Mellon on behalf of the Claimant argue that this case
involves a straightforward application of Article 14. The Claimant says:

i. The regulation of student finance fell within the ambit of A2P1.

ii. The Claimant at the material time, namely by 1 September 2020, met the requirements for ILR but was
prevented from satisfying the criteria in the Regulation by the summary suspension of the Priority Service
and was therefore a person having “other status” as one of the group of “students who achieved ILR only
after the first day of the first academic year of their course due to the summary suspension of the priority
service/super priority service between 30 March 2020 and 31 March 2021 and who would have been
granted ILR before the relevant date, but for the suspension of the service”. The difference does not relate
to substantive satisfaction of the Regulation, but to withdrawal of the fast-track policy.

iii. Alternatively, he was treated in the same way as those who did not meet the criteria for ILR, despite
being in a materially different situation was not treated differently from them. In other words a Thlimmenos


-----

_v Greece (2000) 31 EHRR 15 analysis. This could be expressed alternatively as he ought to have been_
treated the same as those who had received ILR by the 1 September 2020 because he was in a relevantly
analogous situation and the consequential prejudice is considerable since he is deemed ineligible for
finance for the whole degree course, not just the year.

iv. there is no objective and reasonable justification for such detriment/discriminatory treatment/difference
in treatment. Further, the cohort of those affected is small and may be addressed easily by amendment to
the relevant Regulations.

50. It was not in issue that, as Baroness Hale set out in in _R (DA) v Secretary of State for Work and_
_Pensions (Shelter Children's Legal Services intervening)_ [2019] 1 WLR, there are four questions to be
asked namely:

_“(i) Does the subject matter of the complaint fall within the ambit of one of the substantive Convention_
_rights?_

_(ii) Does the ground upon which the complainants have been treated differently from others constitute a_
_status?_

_(iii) Have they been treated differently from other people not sharing that status who are similarly situated_
_or, alternatively, have they been treated in the same way as other people not sharing that status whose_
_situation is relevantly different from theirs?_

_(iv) Does that difference or similarity in treatment have an objective and reasonable justification, in other_
_words, does it pursue a legitimate aim and do the means employed bear a reasonable relationship of_
_proportionality to the aims sought to be realised (see Stec v United Kingdom (2006) 43EHRR 47, para_
_51)?”_

51. I turn to these questions now. It is convenient to consider (ii) and (iii) together.

Ambit. (i) Does the subject matter of the complaint fall within the ambit of one of the substantive Convention rights?

52. On question (i) as both parties agree, a generous approach is taken by the court to the notion of falling
within the ambit of a substantive Convention right. As long as the impugned measure has more than a
tenuous connection with one of the core values protected by an ECHR right, the court will recognise the
subject matter as coming within the ambit of that right. Article 2 Protocol 1 has been extended to the
regulation of financial support for education. As was said in R (Kebede) _[2013] EWHC 2396 (Admin):_

_“… Nobody can have access to university education unless funding is found to discharge the fees. State_
_support for the discharge of fees by way of loans will be, for a very large number of people, the only_
_practical way of paying them. It is therefore an important feature in providing practical and effective access_
_to university education. For this reason I do not accept that the current arrangements relating to funding_
_are too remote from the right guaranteed by A2P1 to fall outside its ambit and therefore to be considered_
_by reference to Article 14.”_

53. The central areas of dispute between the parties were as to whether it was possible to discern “other
status” into which the Claimant and Interested Party fell, and if so whether differential treatment could be
justified.

Status (ii) Does the ground upon which the complainants have been treated differently from others constitute a
status? and

Differential treatment (iii) Have they been treated differently from other people not sharing that status who are
similarly situated or, alternatively, have they been treated in the same way as other people not sharing that status
whose situation is relevantly different from theirs?

54. The Claimant argues that a broad, non-mechanistic approach is necessary when deciding whether the
treatment complained of could be described as on grounds of “other status”. It seems to me that must now
be correct by reference to the recent developments in understanding of how Article 14 operates to right
bli l t t i d t il b l


-----

Tigere

R(Stott)


55. The Claimant submits that the legislative context includes the clear public interest in ensuring that
people in the position of the Claimant and Interested Party achieve their educational goals, became
taxpayers and earners, and made a positive contribution to society. The general context for the application
was the awareness on the behalf of the Secretary of State for Education that the Pandemic was impacting
upon studying and on applications in respect of education both from abroad and at home. This is a fair
representation of the context of the case in my judgement, and I would add to the factual context of the
application as follows. As a matter of common sense, decisions as to university courses and study are
frequently once-in-a-lifetime matters, and have significant consequences bringing with them attendant
expenses and life-style and other changes. Further, a particular selected course may not be available to a
student in a different year from that in which it is first offered. The loss of a particular course at a particular
time is a matter of real significance.

56. Ms Weston QC submitted that the Secretary of State treats ILR as a proxy for being “settled” i.e.
sufficiently connected to the UK for the purposes of accessing student finance, but that the notion of a
sufficient connection with the United Kingdom was not necessarily reflected in the possession of
ILR/settled status under the Immigration Rules. Thus, being sufficiently settled in the UK for the purposes
of accessing student finance was not always coterminous with the possession of ILR. In other words,
colloquially, one could be sufficiently connected for the purposes of the intention behind the Regulations
without the actual visa in one's hand.

57. In support of these contentions Ms Weston QC referred to a number of recent cases of high authority.

58. The starting point for this consideration is the case of R (Tigere) v The Secretary of State for Business,
_Innovation and Skills_ _[2015] UKSC 57 in which the court considered the statutory purpose of the restriction_
of student finance to those who were legally “settled” in the UK and had three years' lawful ordinary
residence. The applicant had only discretionary leave to remain, and she was “settled here for many years
_in the factual sense but not so settled in the legal sense” [per Baroness Hale at paragraph [1]], that is, she_
did not have the ILR required by the first day of the first academic year of the course and so was excluded
from receiving a student loan.

59. The Court held that immigration status could be an “other status” within the meaning of Article 14
(following Bah v United Kingdom (2012) 54 EHRR 21), and the exclusion of those who did not have ILR in
the United Kingdom would be discriminatory under Article 14 unless justifiable and proportionate to its
objective, and it could be justifiable and proportionate on the basis it was legitimate to target resources on
those who are properly part of the community and likely to remain here, and contribute. However, by a
majority, the appeal was allowed, (the court intervening because there was no evidence the Secretary of
State had addressed his mind to the relevant issue), and deciding that the Claimant, had, on the facts of
her case, the same reasonable prospect of benefiting society from a contribution after a university
education and repaying loans as did those who met the full ILR requirement.

60. At paragraph 55 Baroness Hale said:

_“It is readily understandable why the Secretary of State for Business, Innovation and Skills should have_
_looked to the immigration rules for a convenient definition of those who are sufficiently connected with this_
_country to justify receipt of the subsidy. But if he is to take that course, he needs to consider whether those_
_rules do in fact adequately identify those who are sufficiently connected when it comes to University_
_funding and exclude those who are not. The purpose is served by the immigration rules are not identical to_
_the purposes of the Regulations governing eligibility for student loans.”_

61. On this basis, Ms Weston QC said, it was appropriate to regard the Claimant in the present action as
within the class of persons intended to benefit from the student finance provisions. I agree. As she
expressed it orally, at the point at which eligibility had to be shown under the Regulations the Claimant and
the Interested Party had the attributes of status.


-----

62. The flexibility of “other status”, recognising that an acquired or temporary status may suffice, is found
in _R (Stott) v Secretary of State for Justice [2018] UKSC 59. In that case the Supreme Court was_
considering the rule that an offender serving an extended determinate sentence was only eligible for
release on parole after serving two thirds of the appropriate custodial term whereas other prisoners serving
determinate sentences became eligible after the halfway point. The majority held that this difference in
treatment was a difference on the grounds of “other status” within Article 14.

63. In Stott the Supreme Court decided (by a majority of four to one) to depart from the previous decision
of R (Clift) v Secretary of State for the Home Department [2006] UKHL 54 and follow the decision of the
European Court in _Clift v United Kingdom_ (Application No 7205/07) 13 July 2010 in holding that being a
prisoner serving a determinate sentence of imprisonment of more than 15 years amounts to a status.

64. _Stott was a case in which the developing concept of “other status” was explored and the question_
whether there was a requirement for status to be defined by more than merely the difference in treatment
complained of. Lady Black JSC at paragraph [56] gave the following overview of the development of the
position through the case law starting with the older cases:

_“Reviewing these decisions, together with R (Clift) [2007] 1AC 484, I think it can be said (although_
_acknowledging the danger of oversimplification) that prior to the decision in Clift v United Kingdom… the_
_House of Lords had adopted the following position on “other status”:_

_“(i) The possible grounds for discrimination under Article 14 were not unlimited but a generous meaning_
_ought to be given to “other status”_

_(ii) the Kjeldsen test of looking for a “personal characteristic” by which persons or groups of persons were_
_distinguishable from each other was to be applied_

_((iii) Personal characteristics need not be innate and the fact that a characteristic was a matter of personal_
_choice did not rule it out as a possible “other status”_

_(iv) there was support for the view that the personal characteristic could not be defined by the differential_
_treatment of which the person complained_

_(v) there was a hint of a requirement that to qualify the characteristic needed to be “analogous” to those_
_listed in Article 14 but it was not consistent (see, for example, Lord Neuburgers comment in R (R JM) v The_
_Secretary of State Work and Pensions [2009] AC 311, paragraph 43) and it was not really borne out by the_
_substance of the decisions._

_(vi) there was some support for the idea that if the real reason for differential treatment was what_
_somebody had done, rather than who he or what he was, that would not be a personal characteristic, but it_
_was not universal._

_(vii) the more personal the characteristic in question, the more closely connected with the individual's_
_personality, the more difficult it would be to justify discrimination, with justification becoming increasingly_
_less difficult as the characteristic became more peripheral.”_

65. Lady Black returned to the development of the law at [63] of Stott:

_“Returning to the list of propositions derived from the House of Lords' decisions which is to be found at_
_paragraph 56 above, it seems to me that the subsequent authorities in the Supreme Court could be said to_
_have continued to proceed upon the basis of propositions(i) to (iii), which have also continued to be_
_reflected in the jurisprudence of the ECtHR. Proposition (iv) lives on, in R v Doherty [2017] 1WLR 181, but_
_perhaps needs to be considered further in the light of its rejection in Clift v United Kingdom: see further_
_below… That court's answer to the argument was, it will be recalled, to give quite wide-ranging examples_
_of situations in which a violation of Article 14 had been found. With the continued expansion of the range_
_of cases in which “other status” has been found, in domestic and Strasberg decisions, the search for_
_analogy with the grounds expressly set out in Article 14 might be thought to be becoming both more_
_difficult and less profitable. However, that should not, of course, undermine the assistance that can be_
_gained from reference to the listed grounds, taken with examples of “other status” derived from the case_


-----

R (RA)


_law. It may not be helpful to pursue proposition (vi) abstract; whether it assists will depend upon the facts_
_of the particular case. Proposition(vii) comes into play when considering whether differential treatment is_
_justified, rather than in considering the “other status” question and need not be further considered at this_
_stage.”_

66. Lord Mance said at paragraph 231:

"There is no reason why a person may not be identified as having a particular status when the or an aim is
_to discriminate against him in some respect on the ground of that status."_

And at paragraph [75] Lady Black perhaps summed up the approach; she was

“cautious about spending too much time on an analysis of whether the proposed status has an
_independent existence, as opposed to considering the situation as a whole, as encouraged by the ECHR in_
_Clift v United Kingdom”_

67. The effect on the law of the decision in _Clift v UK_ and the requirement, if any, for the independent
existence condition with regard to status was considered further in two recent cases in the Supreme Court
_R(A) the Criminal Injuries Compensation Authority [2021] 1 WLR and R(SC, CB and 8 children) v SSWP_

_[2021] UK SC 2671, both handed down on the same day. In R(A) the claimants were victims of modern_
**_slavery and trafficking but their applications for compensation under a government scheme were refused_**
on the grounds that they did not qualify since they had unspent convictions.

68. Lord Lloyd-Jones, with whom the rest of the court agreed, set out the relevant passage from Clift v UK
as follows:

_“[60] …The question whether there is a difference of treatment based on a personal or identifiable_
_characteristic in any given case is a matter to be assessed taking into consideration all of the_
_circumstances of the case and bearing in mind that the aim of the convention is to guarantee not rights that_
_are theoretical or illusory rights that are practical and effective (see Artico v Italy 13 May 1980, para 33,_
_Series A no 37; and Cudak v Lithuania [GC] (Application No 15869/02) 23 March 2010, para 36). It should_
_be recalled in this regard that the general purpose of Article 14 is to ensure that where a state provides for_
_rights falling within the ambit of the Convention which go beyond the minimum guarantees set out therein_
_those supplementary rights are applied fairly and consistently to all those within its jurisdiction unless a_
_difference of treatment is objectively justified.”_

which, he described as giving

“[42] …a broad meaning to “any other status” in Article 14. In particular, it rejected (at paragraph 56)
_earlier notions that “any other status” must relate to innate or inherent characteristics.”_

…

“At the very least, suggest[ing] disapproval of an over technical approach.”

69. Lord Lloyd-Jones reflected the conflicting approaches at Supreme Court level, including the
observations of Lord Mance and Lord Hughes JJSC in _Kaiyam v Secretary of State Justice [2015] AC_
1344to the effect that Clift, read literally, might eliminate altogether consideration of status.

70. He also considered _Mathieson v Secretary of State for Work and Pensions [2015] 1 WLR 3250. In_
_Mathieson treatment which was held to violate Article 14 was suspending disability allowance to a child on_
the ground that he had been an in-patient in an NHS hospital for more than 84 days. There was no
suggestion that the 84 day criterion had any significance apart from the fact that it was the ground for the
difference in treatment complained of (between the entitlement of a disabled person in the claimant's
situation and that of a disabled person in an NHS hospital for 84 days or less). Even where the status is
contrived the court concluded the claimant had status falling within the grounds of discrimination prohibited
by Article 14.

71 At paragraph [22] of Mathieson Lord Wilson reflected the ECtHR position saying:


-----

Re (SC)


_“It is clear that, if the alleged discrimination falls within the scope of a Convention right, the Court Human_
_Rights is reluctant to conclude that nevertheless the applicant has no relevant status, with the result that_
_the enquiry into discrimination cannot proceed.”_

72. Lord Lloyd-Jones, having reviewed the case law, concluded at paragraph 46 of SC:

“In the light of this more generous approach to status, I have no doubt that being a victim of trafficking does
_constitute a status for this purpose. Although it is an acquired characteristic resulting from something done_
_as opposed to being inherent or innate, it is plainly a personal identifiable characteristic to which many_
_important legal consequences attach.”_

73. This has resonance for the applicants in the present case where the relevant characteristic is acquired,
resulting from the withdrawal of the Priority Schemes.

74. Lord Lloyd-Jones dealt with the proposition that there was a requirement for “individual existence” that
is to say the question whether the status contended for exists solely by reference to the terms of the
legislation or policy which is under challenge and has no independent character; the argument being that a
personal characteristic cannot be defined by the differential treatment of which a person complains: the
basis of the discrimination of which complaint is made has to have an existence independent of the
measure that is under attack. Lord Lloyd-Jones agreed with Lord Reid in _SC that Article 14 draws a_
distinction between relevant status and difference in treatment and the former could not be defined solely
by the latter. Status must be something more than a mere description of the difference in the treatment.

75. Particular reliance was placed by Ms Weston QC upon SC, inviting the court to find that following this
case, “status” now has an “uncomplicated and broad reach”. The need to establish status as a separate
requirement had, (see the authority of _Stevenson the Secretary of State for Work Pensions [2017] at_
paragraph [41]) “diminished almost to vanishing point”.

76. I accept as she submits, that the Court must look to the whole circumstances of the case when
seeking to discover whether the construct of culpable Article 14 differential treatment has taken place. The
case of _SC_ settles the position and indicates Ms Weston QC is, in my judgement, correct in her
submissions.

77. In _SC Lord Reed gave the judgment of the court and referred, on the question of status to the_
reasoning of Leggatt LJ below, who held that the words in Article 14 prohibiting discrimination “on any
_ground such as sex, race, colour, language, religion, political or other opinion, national or social origin,_
_association with a national minority, property, birth or other status…” were:_

“[69] … _intended to add something to the requirements of discrimination so status could not be defined_
_solely by the difference in treatment complained of it must be possible to identify a ground for the_
_difference in treatment in terms of the characteristic which was not merely a description of the difference in_
_treatment itself. On the other hand, he also observed that there seemed to be no reason to impose a_
_requirement that the status should exist independently, in the sense of having social or legal importance for_
_other purposes or in other contexts than the difference in treatment complained of.”_

78. Lord Reed continued

_“[71] I would add that the issue of “status” is one which rarely troubles the European Court. In the context_
_of Article 14, “status” merely refers to the ground of the difference in treatment between one person and_
_another. As explained below, it refers specifically in its judgements to certain grounds, such as sex,_
_nationality and ethnic origin, which lead to it supplying a strict standard of review. But in cases which are_
_not concerned with so-called “suspect” grounds it often makes no reference to status but proceeds directly_
_to a consideration of whether the persons in question are in relevantly similar situations, and whether the_
_difference in treatment is justified. As is stated in Clift the United Kingdom para 60 “the general purpose of_
_Article 14 is to ensure that where a state provides full rights falling within the ambit of the Convention which_
_go beyond the minimum guarantees set out therein, those supplementary rights are applied fairly and_
_i t_ _tl_ _t_ _ll th_ _ithi_ _it_ _j_ _i di ti_ _l_ _diff_ _f t_ _t_ _t i_ _bj_ _ti_ _l_ _j_ _tifi d”_


-----

_Consistently with that purpose, it added at paragraph 61 that: “while… There may be circumstances in_
_which it is not appropriate to categorise an impugned difference of treatment as one made between groups_
_of people, any exception to the protection offered by Article 14 of the Convention should be narrowly_
_construed. Accordingly, cases where the court has found the “status” requirement not to be satisfied are_
_few and far between.”_

79. Status can therefore be acquired and limited in time (see Stott, a type of sentence of imprisonment),
and may refer to the specific circumstances of a claimant, see the recent case of _SM v Lord Chancellor_

[2021] EWHC 418 where the distinction drawn was between immigration detainees in prison compared
with immigration detainees in removal centres.

80. The Claimant here postulates the two groups in analogous situations for comparison as

i. Those who applied in time and achieved ILR by 1 September 2020; and on the other hand

ii. those who applied in time and were as at 1 September 2020 just as entitled to ILR but were prevented
by the withdrawal of the Priority Services from achieving it by then.

81. Ms Weston QC suggested that the Claimant here could be compared to Ms Tigere who was described
in that case:

“The reality is that even though she does not yet have ILR her established private life here means that…
_she will almost inevitably secure ILR in due course. She is just as closely connected with and integrated_
_into UK society as her settled peers.”_

The evidence in that case showed that it was unlikely that the overwhelming majority of people in her
position would emigrate, removing all the net benefit to the UK so her value to the UK was the same as if
she was in the settled class.

82. I accept this analysis and I agree, the value to the UK in these terms of the applicants in this case is
indistinguishable from the value of those whose ILR applications were processed in time. The difference in
treatment appears to be unjustified, subject to arguments on a bright line rule or other reasons against. It
appears to exclude people who meet the criteria which the Regulations are designed to include. The
application of the cut-off date to this particular cohort does not reflect the objectives of the Regulation.

83. Importantly, the difference in treatment in _Tigere was found to be inconsistent with the objectives_
behind the Regulations which were expressed by Lord Hughes at paragraph 54 of Tigere thus:

_“…. the plain objectives of the government in promulgating the eligibility rules under consideration are:_

_a) principally, to target the not inconsiderable subsidy represented by the student loan scheme (about 45%_
_of £9bn per annum) on those who are properly part of the community (in this case of England, for there are_
_separate and different rules for the other parts of the UK)._

_(b) thereby to target the subsidy on those who are likely to remain in England (or at least the UK)_
_indefinitely, so that the general public benefits of their tertiary education will enure to the country's_
_advantage._

_(c) thereby to increase the likelihood that, because the recipients of the loans will probably remain here, the_
_public will receive repayment; and_

_(d) to provide a rule which is easy to understand and apply, and inexpensive to operate, so that the_
_minimum part of the available funds are taken up in administration costs.”_

84. In _Tigere the Court decided that the decision to exclude a person like Ms Tigere (by imposing the_
settlement rule that she could not fulfil), did not serve the objectives of the Regulations. The conclusion
was expressed in this way:

“58 …It follows that in respect of this cohort of people, the settlement rule, whilst no doubt intended to
_serve the first three objectives set out in para 53 above, does not in fact do so. It goes further than is_
_needed to serve those objectives. In consequence, it excludes people who meet the criteria which those_
_bj_ _ti_ _d_ _i_ _d t_ _i_ _l d_ _It f il t_ _t ik_ _f i b l_ _b t_ _th_ _t t ' i t_ _t_ _d th_ _f_


-----

_the cohort concerned. There is little sign in the evidence lodged by the Department that this cohort was_
_expressly considered. The adoption of the rule in relation to this cohort creates discrimination which is_
_outside the legitimate range of administrative decisions available to the Secretary of State, and whether the_
_test correctly characterised as a decision manifestly without reasonable foundation or as some less_
_stringent criterion.”_

85. I acknowledge Mr Glenister's observation about the claim of discrimination being apparently capable of
articulation only as from 1 September 2020. This highlights the temporal aspects of this case: necessarily,
given the facts, the position is only seen clearly retrospectively. These are not features which defeat the
Claimant's arguments but in my judgement, rather, illustrate the nature of the claim. These aspects may
be relevant to remedy, but do not of themselves defeat the fact that it is possible to articulate with clarity
the nature of the status in play. The establishment of a status and the comparator group against whom
detrimental treatment is claimed, can be elusive, and it may be expressed in more than one way, as was
recognised in Stott. However, that is also a feature of the series cases set out above. Analysing the case
by reference to the approach in Tigere reveals that in my judgement the facts clearly fall within the Article
14 framework.

86. In essence the Claimant and Interested Party are complaining about the fact that, although equally
entitled, they are being treated differently from those who were not impeded from acquiring ILR as they
were, and that is the ground on which this difference in treatment is based. I accept that the analysis under
Article 14 is not straight forward. This case has the hallmarks of a legitimate expectation that has been
disappointed. What has arisen here may also be expressed as a manifest unfairness but its remedy may
in my judgment be expressed within what is now recognised as the flexible context of Article 14. The
public law wrong of disabling a clearly identifiable cohort of students from acquiring student finance by not
adapting the Regulations so as to cater for the exigencies of the Pandemic-driven withdrawal of access,
may amount in my judgement to discrimination as claimed, and also plainly meets the justice of the case.

87. It seems to me that Ms Weston's QC reference in oral submissions to the case of _Thlimmenos v_
_Greece (2000) 31 EHRR 15 provides an apt analogy here. In that case an inflexible rule existed such that_
a person convicted of a serious crime would be refused admission to the profession of chartered
accountant. The applicant had previously been convicted of failing to wear a military uniform. In this case,
the crime was committed because he was a conscientious objector, he refused for religious reasons to
wear a uniform. The applicant's crime did not imply a failure of integrity or morality rendering him
unsuitable for the profession, accordingly the court held that there existed no objective and reasonable
justification for not treating the applicant differently from other persons convicted of a felony seeking to
enter the profession.

88. By analogy here Ms Weston argues that there is no objective and reasonable justification for not
treating the cohort of applicants caught by the sudden withdrawal of the Priority application process as
complying with the Regulations.

89. I accept that the Claimant is, by reference to Lord Hughes' description in _Tigere, (see citation from_
paragraphs 54 and 58 above) within the class of persons sufficiently connected with this country to justify
receipt of student finance under the Regulations. Thus the absence of a solution to the issue which arose,
namely withdrawal of the ability to achieve student finance for the required course, does not serve the
legislative purpose, but rather cuts right across it.

90. In my judgement, even though the cases are not the same, the Tigere analysis may be applied here.
In the present case a cohort of people will (if not remediated) be disentitled from pursuing their academic
careers, probably, or at least possibly for a considerable time, with no guarantee of being able to
recommence their studies. I do not accept, as was argued, that there is here no infringement of rights. At
the date of withdrawal of the Super Priority and Priority Services a closed class of would-be students
became, on that withdrawal, disentitled from acquiring student finance for their university courses.

91. I acknowledge, as submitted by Mr Glenister, that there is an element of retrospectivity to this
conclusion. This is inherent in a case where the discrimination involves meeting a requirement described
by reference to a set date and is described retrospectively However this does not detract from the fact


-----

that properly analysed, there is here unlawful discrimination. The question, therefore, is whether it can be
justified as pursuing a legitimate aim and satisfy the proportionality requirements, to which I turn.

(iv) Does that difference or similarity in treatment have an objective and reasonable justification, in other words,
does it pursue a legitimate aim and do the means employed bear a reasonable relationship of proportionality to the
aims sought to be realised.

92. In the context of education in the Supreme Court in _Tigere Baroness Hale (with whom Lord Kerr_
agreed) said the following of the courts approach:

“32 ... As the appellant points out, education (unlike other social welfare benefits) is given special
_protection by A2P1 and is a right constitutive of a democratic society. Nevertheless, we are concerned_
_with the distribution of finite resources at some cost to the taxpayer, and the court must treat the judgments_
_of the Secretary of State, as primary decision-maker, with appropriate respect.”_

93. She continued:

“33 … It is now well-established in a series of cases at this level, beginning with Huang v Secretary of
_State for the Home Department [2007] 2AC 167, and continuing with R (Aguilar Quila) v Secretary of State_
_for the Home Department (AIRE Centre intervening) [2012] 1AC 621, and Bank Mellat HM Treasury (No 2)_

_[2014] AC 700, that the test for justification is fourfold_

_(i) does the measure have a legitimate aim sufficient to justify the limitation of a fundamental right;_

_(ii) is the measure rationally connected to that aim_

_(iii) could a less intrusive measure have been used; and_

_(iv) bearing in mind the severity of the consequences, the importance of the aim and the extent which the_
_measure will contribute to that aim, has a fair balance been struck between the rights of the individual and_
_the interests of the community?_

94. I do not accept the submissions made in respect of the facts on behalf of the Secretary of State. True
it is that the applicants knew there was an issue with their funding when they began their courses. They
were, however, between a rock and a hard place. They were entitled in my view to look to the statements
elsewhere that the Secretary of State did not intend that delays in immigration issues should affect
students' academic positions. It is true, these were statements directed at different cohorts of students, in
different circumstances, and did not assure the Claimant and Interested Party directly. Nonetheless,
absent the sudden withdrawal of the Priority Services at the Home Office, these individuals were entitled to
have had confidence that, when their opportunity to apply for ILR (and thus student funding) arose, they
could swiftly receive the appropriate paperwork from the Home Office. It was not unreasonable to hope
and expect that the effects of the delay beyond their control would be mitigated in their cases too, so they
might continue and not lose their university places. But I do not base my assessment of prejudice on these
aspects of the facts.

95. I do not regard their starting their courses, hoping, and not unreasonably expecting, that some
mitigation of their position would be available, to be culpable or relevant to the issues here. Nor do I regard
the loss of a particular course and the requirement to start another at another time as not engaging their
A1P2 rights. The evidence here shows that there is no guarantee these applicants would be able to carry
on to another course at another time given their personal circumstances. In any event, one course is not
necessarily so easily interchangeable with another as suggested by the Secretary of State in seeking to
diminish the prejudice to these applicants.

96. Mr Glenister submitted and I accept that certainty is a legitimate aim in this context. That proposition
is well supported by the dicta of the Supreme Court. The fallacy of the argument here, however, is the
suggestion that the solution to the issue would lead to uncertainty. The class of those affected by a
remedy is tightly confined and the criteria for protection capable of being precisely drawn. In any event,
given the passage of time, the class is now closed.


-----

Mr Glenister also described the Defendant's stance as an area of “policy” which the Court must be very
wary of entering. I disagree that the risk of so doing presents itself in this case. I am mindful of the warning
from Lord Reed in paragraph 162 of SC where he said:

“… In practice, challenges to legislation on the ground of discrimination have become increasingly common
_in the United Kingdom. They are usually brought by campaigning organisations which lobbied_
_unsuccessfully against the measure when it was being considered in Parliament, and then act as solicitors_
_for persons affected by the legislation, or otherwise support legal challenges brought in their names, as a_
_means of continuing their campaign. The favoured ground of challenge is usually article 14, because it is_
_so easy to establish differential treatment of some category of persons, especially if the concept of indirect_
_discrimination is given a wide scope. Since the principle of proportionality confers on the courts a very_
_broad discretionary power, such cases present a risk of undue interference by the courts in the sphere of_
_political choices.”_

97. That is clearly not this case. The risk of treading inappropriately into an area of legislative discretion is
not manifested by requiring the Defendant to mitigate the effects of the discriminatory treatment under the
secondary legislation of the Regulations.

98. Mr Glenister argued that the nature of any remedy allowing the Claimant and Interested Party to
benefit under the Regulations would be quite disproportionate to the problem. He postulated a general
remedy that would have far-reaching effect on a huge cohort of students. I do not believe that to be a
corollary of a remedy in this case.

99. Ms Weston QC told the Court that the researches of those instructing her suggested that these two
parties were the only people within the particular factual matrix of this case. That aside, I reject the
suggestion that there would be so wide a scope of any operative amendment to the Regulations that it
would be disproportionate to remedy the wrong in these cases.

100. The evidence in this case is that the Priority Schemes were withdrawn with only six days' notice
which means there is an identifiable cohort of people for whom it was immediately impossible to obtain
student finance for the September 2020 year if the Defendant insisted upon evidence of settled status by 1
September 2020.

101. This can be notionally tested the term beginning 1 September 2020 could, with the availability of the
Priority and Super Priority Schemes, have accommodated funded students who achieved their ILR the day
before each course was due to start. Accordingly, it was feasible on payment of a fee, to achieve ILR in a
window that closed at the end of August. The last date on which an application under the Super Priority
24-hour Scheme could have been made was probably Friday, 28 August, to ensure turnaround by Monday,
31 August, achieving ILR by 1 September 2020. So (merely by way of example), a scheme that involved
changing the relevant date on which evidence of ILR status would be acceptable, together perhaps with an
indication that those who commenced their courses ran the risk of having to foot their student fees' bill if
they failed in their ILR applications, could in my judgement easily have been developed. Payment of the
relevant fee could even have been part of that scheme if thought appropriate. The fact that some evidence
would have been required is not of itself evidence of disproportion. Proof of status is required in any event
under the Regulations and payment of a fee, is (even to a different branch of government) not problematic.
To the extent that such a scheme might perhaps include those who would not otherwise have used the
Priority system, that in my judgement is neither here nor there: such scheme will not attract those without a
course or, perhaps, prepared to pay the fee, or able to run the risk of not achieving ILR in due course. The
development of the scheme is not this court's function, but it is not theoretically impossible nor, as argued,
would such scheme prove disproportionate.

102. In any event, the issue here is whether the discrimination against the Claimant and the Interested
Party can be justified and is proportionate. In my view it cannot and is not. To exclude these candidates
on these facts cuts across the purpose of the Regulations and defeats the aims recognised in Tigere.

103. The essence of the Claimant's claim is that the Defendant did not mitigate the severe effect of
withdrawal of the Priority Services in the limited way required to protect this group, affected by Covid


-----

strictures, who were, as has subsequently been shown, as entitled to student finance as the comparator
group, unaffected by the Covid Priority Scheme changes. The loss of finance for the whole of the degree
course if the 1 September date were missed is in my judgement of very significant weight.

104. In terms of proportionality or other justification, it is not relevant (or accurate) to describe these
applicants as “no less deserving” as another, unparticularised cohort postulated on behalf of the Defendant
who may have decided to cut their losses and not apply that year. There is no inherent unfairness: these
particular applicants applied to the Court, on their own facts and are entitled to a remedy, if the court so
finds.

105. As indicated above, Mr Glenister's concentration on the time at which the discrimination is argued to
begin is understandable and highlights the character of the problem: what has happened is now in the
past. What is required at this stage is a retrospective remedy. That does not in my judgement mean there
is no case of discrimination here, nor that a failure to accommodate the “lost cohort”, probably only these
two people, cannot be remedied. This is not equivalent to the case of Docherty (above) or Minter v United
_Kingdom (2017) 65 EHRR SE6 which were cases involving failed applications under Article 14 on the basis_
of a change in sentencing legislation. The differential treatment on which the applicants there relied flowed
exclusively from changes in the legislative sentencing regime, which were prospective. It is wellestablished that differential treatment caused purely by the commencement of a new legislative regime
does not constitute discrimination. Here, there is a distinct ground of discrimination.

106. I disagree with the Secretary of State that this impediment to the applicants amounts merely to “slight
delay in obtaining settled status”. It is plain from the facts deposed to by the Claimant and the Interested
Party, that it is far from clear that either of these people could afford to continue without student finance,
nor that their places would have been open to them either, as appears to be suggested, one term late, or
one year late. I accept, as Mr Glenister submits, both knew that they were technically not entitled to
student finance at the time of the courses started, but in the circumstances of this case, that is not
determinative.

107. However, importantly the Court is asked only to give relief to these claimants and in my judgement
there is no unfairness in affording relief to those who have claimed, even if, only those non-claimants
strictly within the same description, are then afforded relief. The Secretary of State, somewhat in terrorem,
argued it would be necessary to ascertain in each individual case, on the assumption that there were many
more, evidence as to whether, had it not been for the withdrawal of the service, the student would have
used the Priority System, and evidence whether the delays were caused by the withdrawal of the priority
services. I disagree. This is not borne out by the evidence or the logic of the case.

108. At the end of the ministerial submission this was said:

_“We have considered whether we can mitigate against this happening again in the future without the need_
_to make any changes in the Regulations. Should the super priority service be withdrawn again, we intend_
_to clearly signpost students to the Gov.uk website to manage their expectations and allow them plenty of_
_time to apply for their ILR. We have also asked whether the HMO could consider expediting applications_
_for settlement from individuals who can show they have outstanding student finance application (sic) and_
_the grant of ILR is key to their eligibility.”_

109. This reflects the Defendant's understandable concern about the integrity of the bright line ILR
requirement in the Regulations. Mr Glenister in his submissions emphasised the difficulty with any
importation of a discretion requiring the Secretary of State to decide between cases and on competing
evidence. He drew the court's attention to those passages in the authorities which reflect the desirability of
a bright line rule, indeed Lord Hughes said as much in the present context in the Tigere case (above). I
accept the importance of a bright line rule concerning qualification for the scheme. A remedy in this case
does not impugn that, nor will the Defendant necessarily be required to exercise a discretion,
compassionate or otherwise, in the circumstances of this case: the relevant factors for inclusion are all
ascertainable. The vice in the present case is the disqualification by the date contained in the Regulations.
It is now not in issue that, but for the date, both Claimants here qualify. It is not difficult to construct a
scheme which catches those who made an application which under the usual course of the suspended


-----

scheme, would have acquired ILR. Those persons can, now in retrospect, be shown to have done so
successfully

110. I do not however purport to draft or influence the required working out of the remedy which the parties
may wish to have considered at a short consequentials hearing in the New Year.

Summary of Conclusion

111. The Claimants have succeeded in their Claim.

112. The Defendant unlawfully discriminated against the Claimant and the Interested Party by treating
them less favourably than those who were not caught out by the sudden withdrawal of the Super Priority
Scheme.

113. The Defendant did not mitigate the severe effect of withdrawal of the Priority Services in the limited
way required to protect this group, who were, as has subsequently been shown, as entitled to student
finance as the comparator group, unaffected by the Covid Priority Scheme. It is contrary to the objectives
of the Regulations for there to be no mitigation of the delay in process that was forced upon the applicants
in this case.

114. In these circumstances the Court will remedy the unlawful discrimination and grant a declaration and
a quashing Order as asked by the Claimant and Interested Party.

**End of Document**


-----

