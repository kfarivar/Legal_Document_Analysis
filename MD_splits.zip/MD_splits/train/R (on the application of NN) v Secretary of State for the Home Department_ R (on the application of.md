Secretary of State for the Home Department

# R (on the application of NN) v Secretary of State for the Home Department; R
 (on the application of LP) v Secretary of State for the Home Department

 [2019] EWHC 1003 (Admin)

Queen's Bench Division, Administrative Court (London)

Julian Knowles J

17 April 2019Judgment

**Chris Buttler, Miranda Butler and Zoe McCallum (instructed by Duncan Lewis) for the Claimants**

**Robin Tam QC and Emily Wilsdon (instructed by GLD) for the Defendant**

Hearing date: 10 April 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**The Honourable Mr Justice Julian Knowles:**

**Introduction**

1. This is an application for permission to seek judicial review and for interim relief by the Claimants, NN
and LP.  On 21 March 2019 following an oral hearing in Birmingham I granted interim relief until this
hearing and gave directions for the transfer of the cases to London and for the filing of evidence as well as
other orders, including anonymity. My judgment is reported at _[2019] EWHC 766 (Admin). Since then,_
both sides have filed evidence and made further written submissions.

2. The background to the claims and the grounds of challenge are set out in my earlier judgment and so I
will not repeat them here.  Suffice it to say that the Claimants are both victims of modern slavery/people
trafficking who challenge aspects of the Defendant's policy towards people such as themselves who have
been accepted as victims (as they have) by the Defendant following a Conclusive Grounds (CG)
determination under the National Referral Mechanism.  One of the policies challenged by the Claimants
as unlawful is the Defendant's policy of ending support including additional financial payments,
accommodation and support worker assistance 45 days after the CG determination has been given. In
response, the Defendant relies on the fact that victims can ask for an extension of support pursuant to an
unpublished policy. There are amended grounds of challenge to include a challenge to the legality of that
extension policy.

**Permission and interim relief for NN and LP**

3. On behalf of the Defendant Mr Tam QC accepted that permission to seek judicial review should be
granted to NN and LP on all grounds (including the new ground relating to the extension policy) and he
also accepted that the interim relief which I granted to them (namely, that their support should continue
until today's hearing) should continue until the determination of their claims.


-----

Secretary of State for the Home Department

4. I therefore grant permission to the Claimants to seek judicial review on all grounds (namely those set
out in [8] and [9] of my earlier judgment and the additional grounds of challenge relating to the extension
policy) and I also order that the Defendant shall continue to provide support for LP and NN under the
Victims of Modern Slavery Contract until the final disposal of their claims for judicial review (as per [1] of
the Order dated 26 March 2019).

**The issue before me**

5. The argument before me concerned whether I should also order similar interim relief generally, in other
words, whether I should order that support should continue for all of those similarly situated to NN and LP,
namely, victims of trafficking who have received positive CG determinations and who are currently
receiving support which will end 45 days after that determination.  I granted such relief until today's
hearing in [2] of my 26 March 2019 order, which was in the following terms:

“Pending the hearing referred to a paragraph 7 below [that is, the permission/interim relief hearing], the
Defendant shall not restrict support for victims of trafficking under the Victims of Modern Slavery Contract
by reference to the date of a Conclusive Grounds decision or the length of time the support has been
provided.”

6. Mr Buttler on behalf of the Claimants submitted that it was appropriate for me to continue this order until
the disposal of NN and LP's claims. He suggested the full hearing could take place in May or early June
2019 and that the balance of convenience came down in favour of granting interim relief until then. He said
that although the number and identity of the persons who would benefit from such relief could not, by
definition, be known, he argued that the nature of public law proceedings is such that, NN and LP having
brought claims and been granted permission and interim relief, and because they are in an identical
position to these other victims of trafficking who would suffer irreparable harm if their support were to be
withdrawn, the balance of convenience came down in favour of granting interim relief.  He said that there
was no reason in principle why such an order for interim relief benefitting an unascertainable class of
individuals could not be made in public law proceedings, and he cited examples where such orders had
been made. He also said that the evidence filed on behalf of the Secretary of State did not show that it
would not be possible for the Defendant (through the service providers with whom it contracts to provide
support) to continue to provide support for all trafficking victims until the disposal of these claims in the
relatively near future.

7. On behalf of the Secretary of State, Mr Tam QC submitted that I should not grant general interim relief.
He said that I should leave it to those individuals who may be affected by withdrawal of support to bring
judicial review proceedings so that the question of interim relief can be considered on a case by case
basis. Although he suggested that s 31(2A) of the Senior Courts Act 1981 might provide a statutory bar to
the grant of general relief, if he was wrong about that, Mr Tam accepted that I had jurisdiction to grant
general relief, but said that it was a form of relief only to be granted in exceptional cases and that this case
was not exceptional. He relied heavily on the decision of Cranston J in R(Majit) v Secretary of State for the
_Home Department_ _[[2016] EWHC 741 (Admin), [10]-[18], where the judge refused this form of relief to a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JGN-9471-F0JY-C252-00000-00&context=1519360)_
class of persons other than the claimant (who already had interim relief) in respect of their removal to
Bulgaria and gave a number of reasons for not granting the general relief sought.  Mr Tam submitted that
the resource implications for service providers to victims of trafficking if I granted the general relief meant
that the balance of convenience came down against granting the relief sought.  He said that the number of
victims entering the system was unpredictable (because, for example, there could be sudden enforcement
action) there is a risk, even in the short term, of the system becoming overloaded or unstable.  He also
relied on the extension policy and said that the evidence showed that the overwhelming number of
requests for extensions were granted.

**Discussion**

8. I begin with the issue of whether I have jurisdiction to grant general interim relief in the form sought in
this case in respect of persons other than the individual Claimants NN and LP who are not claimants


-----

Secretary of State for the Home Department

before me. The Defendant suggested in guarded terms that I do not. I am satisfied that I do. Whether it is
appropriate do so in a particular case resolves down into an application of the well-understood American
_Cyanamid principles (see American Cyanamid Company v Ethicon Limited [1975] AC 396) in the particular_
public law and factual context involved.

9. The High Court's power to grant injunctive relief is a wide one and is confirmed by s 37 of the Senior
[Courts Act 1981 (SCA 1981):](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y189-00000-00&context=1519360)

“Powers of High Court with respect to injunctions and receivers

(1) The High Court may by order (whether interlocutory or final) grant an injunction or appoint a receiver in
all cases in which it appears to the court to be just and convenient to do so.

(2) Any such order may be made either unconditionally or on such terms and conditions as the court thinks
just.”

10. The wide, clear and express words of s 37 can be traced to the Supreme Court of Judicature Act 1873.
As [15-4] of Volume 2 of the White Book 2019 makes clear, the High Court's power to grant an injunction
on the basis contained in s 37 derives not from the section but is confirmed by it: Fourie v Le Roux [2007] 1
WLR 325, [25]. Paragraph [15-4] goes on to say:

“The 1873 legislation conferred on the High Court the jurisdiction vested in, or capable of being exercised
by, various courts, including courts of equity. In courts of equity the jurisdiction to grant injunctions:

;… has always been without limit, and could indeed be exercised either in support of any legal right, or in
the creation of a new equitable right, as the court thought fit in the application of equitable principles (Spry,
_The Principles of Equitable Remedies, 5th Edn (1997), p331)'_

It follows from this that, insofar as the High Court has thought it fit to not to exercise its equitable
jurisdiction to grant injunctions (either interlocutory or final), and has customarily refused relief, it has done
so, not because it lacked jurisdiction or power, but as a matter of discretion.”

11. I acknowledge the further discussion of the question of jurisdiction in subsequent paragraphs in the
_White Book, but given the width of the High Court's power as reflected in s 37, it seems to me that the_
question is whether it has been restricted in some way so as to deprive the High Court of the power to
grant an injunction for the benefit of persons who are not before it as parties but who are identically
situated to a claimant before the court who seeks similar or identical relief.

12. There is some limited guidance from the Court of Appeal that the power in s 37 has not been so
restricted, namely HN (Afghanistan) v Secretary of State for the Home Department _[[2015] EWCA Civ 1043,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5H59-T4C1-F0JY-C1B3-00000-00&context=1519360)_
which was discussed in Majit, supra, at [5] – [7].

13. In that case, Christopher Clarke LJ had given permission for certain appellants to appeal a decision of
the Upper Tribunal (eventually the appeal was dismissed: R (On application of HN and SA) (Afghanistan)
_(Lead cases associated Non-Lead Cases) v Secretary of State for the Home Department [2016] EWCA Civ_
123).  In light of that permission, the appellants made an application for interim relief as regards other
persons who were to be removed with them on a specific flight to Kabul on 21 April 2015. An order to that
effect had been given out of hours by Lady Rafferty LJ. Ultimately, the order that Christopher Clarke LJ
made was as follows:

“The appellant's application for further interim relief is granted in the form of a stay on a removal from the
UK until further order of the Court of Appeal, for all other persons [ie not the appellants] facing forced
removal from the UK on the charter flight PVT 081 to Kabul on 26 August 2015 who were not habitually
resident in the Provinces of Bamyan, Panjsher and Kabul.”

14. In the course of his judgment, Christopher Clarke LJ said that the logic of the grant of permission to
appeal was that the appellants would arguably face a real risk of injustice to them and, more importantly,
danger. He noted that persons other than the appellants might make applications for interim relief against


-----

Secretary of State for the Home Department

removal but 'others may not be in a position to do so in time to prevent their removal on Wednesday of next
week'. He then said at [21]:

“It seems to me that this Court probably does have jurisdiction to make an order of the type now sought
under the general power to make an injunction whenever it is just and convenient to do so or under the
Court's inherent jurisdiction. I make no final decision in relation to that. It seems to me that in any event it
has jurisdiction to make an order such as the one that I propose to make on an interlocutory basis.”

15. Then continuing at [23]:

“ ... In a public law case when a consideration which affects one group of applicants affects others who are
not or not yet parties to the proceedings in that or a very similar way it seems to me proper for the recent
stay ordered by the Court to extend to those in the latter as well as the former category. At any rate, that
seems to be appropriate on the facts of the present case.”

16. Although the learned Lord Justice did not provide a final view on the issue, these passages do provide
some support for the conclusion that I have reached.

[17. I can deal shortly with Mr Tam's suggestion (faintly though it was pursued) that s 31(2A) (SCA 1981)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y189-00000-00&context=1519360)
represents a statutory limitation on the ambit of s 37 so as to deprive the Court of granting general interim
relief that is sought in this case. That section provides:

“(2A) The High Court—

(a) must refuse to grant relief on an application for judicial review, and

(b) may not make an award under subsection (4) on such an application,

if it appears to the court to be highly likely that the outcome for the applicant would not have been
substantially different if the conduct complained of had not occurred.”

18. Mr Tam submitted that as the general interim relief sought would make no difference to the outcome
for NN and LP, because individual interim relief has been ordered in relation to each of them in any event,
this section requires me to refuse to grant general interim relief unless there are reasons of exceptional
public interest.

19. I reject that submission. Section 31(2A) is aimed at academic claims where the conduct complained of
would have made no difference to the final outcome of the case. It is not concerned with the granting of
interim injunctive relief.  Section 31(2A) cannot have removed by a side wind the High Court's historic
power to grant an injunction where it is appropriate to do so.

20. In Majit, supra, Cranston J gave three reasons for refusing the broader interim injunction sought in that
case and for not taking the approach of Christopher Clarke LJ in HN (Afghanistan), supra:

a. The first reason was that the relief was sought on behalf of persons unknown (at [11]). He said that
counsel for the Secretary of State had submitted that there was a general principle that litigation cannot be
carried out on behalf of individuals save with their consent and in strictly defined circumstances. He went
on at [12] to identify three exceptions to this supposed principle, including where NGOs 'act on behalf of
groups of persons who may not be immediately identifiable' and cited Lord Chancellor v Detention Action

[2015] 1 WLR 5341as an example.

b. The second reason was s 31(2A) of the SCA 1981.

c. The third reason was that in HN, supra, the order was in respect of a defined class (persons liable to
removal from the UK on a specific flight) who might not have had the opportunity to apply for judicial review
because of the imminence of their departure. Cranston J distinguished those facts from the case before
him. He said that there was no evidence that the persons affected could not access the court and that if
they did their removal would be automatically stayed as the result of the Secretary of State's declared
policy in such cases. He said HN, supra, was a 'quite exceptional case'.


-----

Secretary of State for the Home Department

21. Although Mr Tam put Majit, supra, at the heart of his submissions, in my judgment it does not provide
any real assistance to his case. That is because Cranston J was not purporting to lay down any general
guidance but was simply exercising his discretion on the particular facts before him. The decision certainly
does not, as Mr Tam submitted, suggest there is no jurisdiction to grant general interim relief or lay down
any general principle that the sort of general relief sought by NN and LP should only be granted in
'exceptional' cases. Also, and with the greatest of respect to Cranston J, it seems to me that his reasons
do not provide significant support for his conclusion, correct overall might that conclusion have been on the
particular facts:

a. As to his first reason, the fact that relief was being sought for persons unknown is unremarkable and is
a common feature of public law injunction applications.  Where a claimant seeks injunctive relief to stop a
motorway being built next to his village the class of persons whom it may benefit may be unknown, but that
of itself is not a reason not to grant the injunction. Also, and perhaps more pertinently, NGOs frequently
seek relief including injunctive relief for the benefit of a set of unascertained (and sometimes
unascertainable) individuals who can be identified solely on the basis that they have a characteristic or
status which means the impugned action may be applied to them. An example is _R (Medical Justice) v_
_Secretary of State for the Home Department_ _[[2010] EWHC 1425 (Admin). Another example is](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_ _Detention_
_Action, supra, which the judge referred to._

b. As to s 31(2A), I have already explained why in my view that is not an impediment to the grant of
general interim relief and is concerned with something entirely different.

c. Cranston J's third reason was simply an observation on the factual distinction between the case before
him and HN, supra.

22. In short, if it is (as it is) open to an NGO concerned with a particular matter to seek injunctive relief in
public law proceedings for those affected by that matter then a fortiori it must be open to Claimants such as
NN and LP to seek similar relief for persons identically situated to them and I have jurisdiction to grant such
relief.  I can see no reason of principle why that should not be so.  Whether it will be right to do so will
depend on the application of the normal principles governing the grant of injunctive relief.  To that matter I
now turn.

23. The correct approach was not materially in dispute between the parties. It was conveniently
summarised in Medical Justice, supra. The principles are those contained in American Cyanamid, supra,
but modified as appropriate to public law cases. First, the claimant must demonstrate that there is a real
prospect of succeeding at trial. This seems to equate with something more than a fanciful prospect of
success. In Smith v Inner London Education Authority [1978] 1 All 1978] 1 All ER 411, the claimants had
obtained an interim injunction in relation to the closure of a grammar school. On appeal, Lord Denning
acknowledged that _American Cyanamid could not automatically fit with public law cases, but held that a_
public authority should not be restrained from exercising its statutory power or doing its duty to the public
unless the claimant could show a real prospect of succeeding at the trial ( at p418). Browne LJ said this (at
p419):

“The first question is whether the plaintiffs have satisfied the first requirement laid down by the House of
Lords in American Cyanamid Co v Ethicon Ltd: is their action not frivolous or vexatious? Is there a serious
question to be tried? Is there a real prospect that they will succeed in their claim for a permanent injunction
at the trial? The first two questions were clearly intended to state the same test, because they are joined by
the phrase 'in other words', and the third cannot, I think, have been meant to state any different one."

24. In _Sierbein v Westminster City Council [1987] 86 LGR 43, the Court of Appeal agreed with the_
approach in _Smith v Inner London Education Authority, although underlined the importance of the public_
interest in an application for an interim injunction against a public authority: see Dillon LJ at 440.

25. The White Book 2019, at [54.3.6], p1931, summarises the position this way:

“The courts will consider whether the claim raises a serious issue to be tried, and if so, where the balance
of convenience including the wider public interest lies In considering whether there is a serious issue to


-----

Secretary of State for the Home Department

be tried, the court will consider whether the claimant can demonstrate a real prospect of succeeding at trial:
_R (Medical Justice) v Secretary of State for the Home Department_ _[[2010] EWHC 1425 (Admin).  In](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_
considering the balance of convenience, the availability of damages is unlikely to be determinative of the
grant of interim injunctions in most public law cases as damages will either not be available or will not be
an adequate remedy. In considering the balance of convenience as a whole, the courts must have regard
to the wider public interest (Smith v Inner London Education Authority _[[1978] 1 All ER 411;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-612X-00000-00&context=1519360)_ _Sierbein v_
_Westminster City Council_ [1987] 86 LGR 431). The wider public interest includes permitting a public
authority to continue to apply its policy but that interest will need to be weighed against other relevant
factors: R (Medical Justice) v Secretary of State for the Home Department [2010] EWHC 1425.”

26. There is in this case plainly a serious issue to be tried and Mr Tam did not suggest otherwise. As I
have said, he agreed that permission should be granted).

27. In relation to the balance of convenience, I am entirely satisfied that there is a serious risk of
irreparable harm to individuals similarly situated to NN and LP, ie, victims of slavery and trafficking who
have received positive CG determinations but whose support will end 45 days thereafter, absent an
extension. Rachel Collins-White works for Unseen, an organisation which helps the survivors of slavery.
She says at [6] of her witness statement:

“The 45-day deadline for support ending can be very daunting for victims. Having built a relationship with
their key worker, having felt safe and secure. Having received support to access the care that is needed,
the prospect of that support no longer being there is a blow. For victims of trafficking, who often have
complex trauma, the recovery process does not follow a fixed trajectory. Recovery is very up and down,
support needs to be consistent to help build resilience throughout. The knowledge to victims that the oneto-one relationship that they have built with their support is coming to an end often causes great anxiety.”

28. In my earlier judgment I set out some of the evidence relating to NN and LP and the serious harm they
would have suffered if their support had been withdrawn.  Even though I cannot quantify the exact
number, it is not difficult for me to infer that there will be some – perhaps many - other individuals in the
class with which I am concerned who will be similarly harmed if their support is withdrawn. Ex hypothesi
they are all victims of trafficking and very many, if not the majority, will have undergone experiences akin to
those suffered by LP (trafficked and repeatedly raped) and NN (trafficked, held in slave conditions and then
badly beaten). I readily conclude that there will be those among the general class who have suffered and
are suffering mentally and physically as a result of the ordeals they have gone through and who will be
irreparably harmed if their support ends.

29. In other words, the fact that this case concerns a population of very vulnerable individuals who have
ended up in a foreign country through no choice of their own, is something to which I attach great weight
when the balance of convenience is being assessed.

30. I reject Mr Tam's suggestion that the extension policy means that there is little or no risk of harm. I do
not doubt the statistics set out in [11] of Alice Matthews' statement. She works in the Tackling Slavery and
Exploitation Directorate of the Home Office. She says that since 2015, 1569 extension requests were
made and 1503 were granted (95.8%). These were in relation to 492 individuals, representing 11.2% of
those who have received support. She also gives some evidence about how extension requests are dealt
with, although she does not produce the relevant policy itself.

31. The reasons why I reject Mr Tam's suggestion are as follows. First, as I have said, I am dealing with a
population of extremely vulnerable individuals. I cannot assume that they would not suffer harm simply by
the uncertainty of having to ask for a discretionary extension of support instead of receiving it as of right.
Second, the lack of transparency about the policy which the Secretary of State applies is concerning. The
evidence of Rachel Mullen-Feroze, who works for an organisation which provides assistance for victims of
trafficking at [9]-[11] of her witness statement is that:

“9. We take a pragmatic view in terms of when to make extension requests, and generally only make
requests when we know they will not be refused. I am not aware of any published criteria against which


-----

Secretary of State for the Home Department

our requests will be considered, although from experience we know that requests made on certain grounds
are more likely to be successful. I was told verbally in a meeting with by the Modern Slavery Unit of the
Home Office that extension requests will only be granted in very limited circumstances …

11. If a request to extend funding for support is rejected, we usually receive rejection reasons. I believe
that it is possible to challenge extension rejections, though I do not know of any published guidance for
doing so, or on the basis for which such challenges will be considered.”

32. Third, although Ms Matthews says there has been training to service providers about the extension
policy, the fact that only 11% of victims have sought extensions suggests there is not a large take up.

33. Overall, there is the forensic point that if extensions are readily given when asked for, as Mr Tam
submitted, then this suggests that granting general interim relief for a short period would not cause the
system to become overburdened in the way that the Defendant suggested. I put this point to Mr Tam in
argument and, with respect to him, he did not have any real answer to it.

34. Turning to that point, I am also satisfied on the evidence that whilst granting the general relief sought will
undoubtedly increase pressure on the system, it will not cause the system to become unworkably overloaded
provided that the case is determined within a comparatively short period of time.  In connection with this point there
are three principal matters to be considered: (a) the costs of continued financial support and the overall additional
costs; (b) the provision of support workers; and (c) the provision of accommodation.

35. As to the first of these, there is no evidence to suggest that the necessary money would not be found.
Rachel Devlin sets out the additional costs in [35] of her witness statement. They are in the order of
hundreds of thousands of pounds.   I do not underestimate the demands on the Exchequer, but there is
nothing to suggest that these additional costs could not be borne in the short term.

36. As to the second, the evidence of Rachel Collins-White at [16] of her witness statement is that:

“We are confident that, with our current number of support workers, we could accommodate the extension
of support ordered by Julian Knowles J for at least three months. We also consider that we would be able
to recruit and train new support workers within a relatively short period, providing that this is paid for by the
Home Office.”

37. As to the third matter, accommodation, the evidence from Ms Devlin is that as at 2 April 2019 the
Salvation Army (which holds the contract with the Home Office to provide support for victims, and then
subcontracts) had 68 free bed spaces and can secure a further 38 beds from 8 April 2019, making a total
of 106 beds.  The forecast increase in demand from 10 April and 13 May 2019, according to best
estimates, is between 70 and 83 bed spaces. This suggests that sufficient beds would be available over
that period. I entirely accept Mr Tam's point that there are uncertainties in forecasting and that the number
of entrants into the system could suddenly spike, for example, as a result of enforcement action.  But such
an eventuality could be catered for by sourcing additional accommodation (as Ms Devlin says at [27] could
happen) or, if the system really were at the point of being unable to cope, by the Secretary of State
applying for a discharge of interim relief on the grounds that the balance of convenience had altered.  I
received a letter directly from the Salvation Army which helpfully said that it would take two months for safe
house accommodation to reach capacity.  I envisage this case being disposed of within a comparatively
short time frame.

**Conclusions**

38. I have jurisdiction to grant general interim relief for the reasons I have given. There is a serious issue
to be tried in these claims.  In my judgment there is a real risk of irreparable harm to a significant number
of vulnerable victims of slavery and trafficking if their support were to end after 45 days. When that is set
against the fact that the system can cope if I order that their support be continued in the short term, I
conclude that the balance of convenience comes down in favour of granting the general relief sought, and I
so order. Granting this relief will also avoid the cost and inconvenience of large numbers of individual
claimants having to apply for interim relief to this Court


-----

Secretary of State for the Home Department

39. I invite the parties to draw up a suitable form of order reflecting this judgment.

**End of Document**


-----

Secretary of State for the Home Department - [2019] Al....

# R (on the application of NN) v Secretary of State for the Home Department; R
 (on the application of LP) v Secretary of State for the Home Department

 [2019] All ER (D) 104 (May)

[2019] EWHC 1003 (Admin)

Queen's Bench Division, Administrative Court (London)

Julian Knowles J

17 April 2019

**Immigration – Trafficking – Support**
Abstract

_Immigration – Trafficking. The court had jurisdiction to grant general interim relief in respect of persons other than_
_the individual claimants who were not claimants before it. The Administrative Court further held that there was a_
_serious issue to be tried in the claimants' judicial review proceedings challenging the defendant Secretary of State's_
_policy of ending support 45 days after a conclusive determination that a person was a victim of_ **_modern_**
**_slavery/people trafficking and the balance of convenience came down in favour of granting the general relief_**
_sought._
Digest

The judgment is available at: [2019] EWHC 1003 (Admin)

**Background**

The claimants were both victims of **_modern slavery/people trafficking who challenged aspects of the defendant_**
Secretary of State's policy towards people such as themselves who had been accepted as victims following a
conclusive grounds determination. One of the policies challenged by the claimants as unlawful was the Secretary of
State's policy of ending support including additional financial payments, accommodation and support worker
assistance 45 days after the conclusive determination had been given.

The Secretary of State accepted that the interim relief granted to the claimants, namely, that their support should
continue until the hearing, should continue until the determination of their claims. The present argument concerned
whether similar interim relief should be ordered generally, in other words, whether it should be ordered that support
should continue for all of those similarly situated to the claimants, namely, victims of trafficking who had received
positive conclusive grounds determinations and who were currently receiving support which would end 45 days
after that determination.

**Issues and decisions**

(1) Whether the court had jurisdiction to grant general interim relief in the form sought in respect of
persons other than the individual claimants who were not claimants before it.

The court had jurisdiction to grant general interim relief in the form sought in respect of persons other than the
individual claimants who were not claimants before it (see [8] of the judgment)


-----

Secretary of State for the Home Department - [2019] Al....

The Secretary of State's submission, that as the general interim relief sought would make no difference to the
outcome for the claimants, because individual interim relief had been ordered in relation to each of them in any
event, _[s 31(2A) of the Senior Courts Act 1981 required the refusal of general interim relief unless there were](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6140-TWPY-Y172-00000-00&context=1519360)_
reasons of exceptional public interest, would be rejected. Section 31(2A) was aimed at academic claims where the
conduct complained of would have made no difference to the final outcome of the case. It was not concerned with
the granting of interim injunctive relief. Section 31(2A) could not have removed by a side wind the High Court's
historic power to grant an injunction where it was appropriate to do so (see [18], [19] of the judgment).

As it was open to a non-governmental organisation concerned with a particular matter to seek injunctive relief in
public law proceedings for those affected by that matter, it had to be open to claimants such as the present
claimants to seek similar relief for persons identically situated to them and the court had jurisdiction to grant such
relief. There was no reason of principle why that should not be so (see [22] of the judgment).

_HN (Afghanistan) v Secretary of State For The Home_ _[[2015] EWCA Civ 1043 considered; R (on the application of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5H59-T4C1-F0JY-C1B3-00000-00&context=1519360)_
_Majit) v Secretary Of State For The Home Department (2016)_ _[[2016] EWHC 741 (Admin) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JGN-9471-F0JY-C252-00000-00&context=1519360)_

(2) Whether interim relief should be granted generally for all victims of trafficking who had received positive
conclusive grounds determinations and who were currently receiving support which would end 45 days after that
determination.

In the present case, there was plainly a serious issue to be tried (see [26] of the judgment).

In relation to the balance of convenience, there was a serious risk of irreparable harm to individuals similarly
situated to the claimants, namely, victims of slavery and trafficking who had received positive conclusive grounds
determinations but whose support would end 45 days thereafter, absent an extension (see [27] of the judgment).

Even though the exact number could not be quantified, it was not difficult to infer that there would be some –
perhaps many – other individuals in the class with which the court was concerned who would be similarly harmed if
their support was withdrawn. Ex hypothesi they were all victims of trafficking and very many, if not the majority,
would have undergone experiences akin to those suffered by the claimants. It would be readily concluded that there
would be those among the general class who had suffered and were suffering mentally and physically as a result of
the ordeals they had gone through and who would be irreparably harmed if their support ended (see [28] of the
judgment).

The fact that the case concerned a population of very vulnerable individuals who had ended up in a foreign country
through no choice of their own, was something to which great weight would be attached when the balance of
convenience was being assessed (see [29] of the judgment).

The Secretary of State's suggestion that the fact that victims could ask for an extension of support pursuant to an
unpublished policy meant that there was little or no risk of harm would be rejected. Overall, there was the forensic
point that, if extensions were readily given when asked for, as the Secretary of State submitted, then that suggested
that granting general interim relief for a short period would not cause the system to become overburdened in the
way that the Secretary of State suggested (see [30], [33] of the judgment).

Further, on the evidence, while granting the general relief sought would undoubtedly increase pressure on the
system, it would not cause the system to become unworkably overloaded provided that the case was determined
within a comparatively short period of time (see [34] of the judgment).

_American Cyanamid Co v Ethicon Ltd_ _[[1975] 1 All ER 504 applied;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-604K-00000-00&context=1519360)_ _Medical Justice (R on the application of) v_
_Secretary Of State For The Home Department_ _[[2010] EWHC 1425 (Admin) applied;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_ _Smith v Inner London_
_Education Authority_ _[[1978] 1 All ER 411 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-612X-00000-00&context=1519360)_

Chris Buttler, Miranda Butler and Zoe McCallum (instructed by Duncan Lewis) for the claimants.


-----

Secretary of State for the Home Department - [2019] Al....

Robin Tam QC and Emily Wilsdon (instructed by the Government Legal Department) for the Secretary of State.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

