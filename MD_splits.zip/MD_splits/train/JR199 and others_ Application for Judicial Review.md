# JR199 and others' Application for Judicial Review [2024] NIDiv 3,
 (Transcript)

NORTHERN IRELAND KING'S BENCH DIVISION DIVISIONAL COURT

TREACY LJ, SCOFFIELD J AND SIR PAUL MAGUIRE

14 MARCH 202414 MARCH 2024

**Human trafficking — Judicial review — Applicant were three fishermen from Ghana who were recruited in**
**Ghana through Ghana based recruitment agency to work on fishing boat — Fishing vessel was owned by**
**two individuals based in Norther Ireland — Recruitment of men was arranged by local company owned by**
**one of recruiters — Applicants were removed from boat by PSNI amid concerns about human trafficking**
**and forced labour — PSNI noted poor living conditions on boat including broken shower which was shared**
**by six men — NRM form sent to home office for each applicant in accordance with framework for**
**identifying potential victims of modern slavery — Home office made reasonable grounds decision that**
**applicants were victims of human trafficking — Applicants sought to have local company as well as**
**recruiters prosecuted for range of alleged offences against them — Public prosecution system issued**
**decision letter refusing to prosecute local company or recruiters or anyone else for any criminal offence —**
**Applicants sought to have no prosecution orders quashed — Applicant sought leave to apply for judicial**
**review in that regard — Whether applicants were exploited for purposes of s 4 of Fraud act — Whether**
**hours demanded from applicants by employers was excessive — Whether living conditions on boat did not**
**meet minimum living standard requirements — Immigration Act 1971, s 25 — Immigration, Asylum and**
**Nationality Act 2006, s 21 — Fraud Act 2006, s 4 — Asylum and Immigration (Treatment of Claimants) Act**
**2004, SI 2004/3398, s 4 — Coroners and Justice Act 2009, SI 2009/3253, s 71 — National Minimum Wage**
**1998, SI 1998/2574, s 31.**

**TREACY LJ (delivering the judgment of the court):**

**_Introduction_**

**[1] The Applicants are three fishermen from Ghana, who we have anonymised as above. They were recruited in**
Ghana through a Ghana-based recruitment agency called Sea Crew Ltd (“Sea Crew”) to work on the “Kestrel”
fishing boat (“the boat”). The Kestrel is a fishing vessel owned and managed by John and Mark Anderson and
based in Kilkeel, Northern Ireland. The recruitment of the men was arranged by Acquis Business Systems Ltd
(“Acquis”), a local company of which John Anderson is a director.

**[2] The Applicants arrived in Kilkeel on 6 May 2011, and on 9 June 2011 they were removed from the boat by the**
PSNI amid concerns about human trafficking and forced labour. After inspecting the vessel, the PSNI noted that:

- It was a small fishing boat, so small that many of the regulations designed to protect employees, for example
those relating to accommodation, did not apply to it.

- The facilities were extremely poor with one shower shared between six men. At the date of the inspection this
shower was broken.


-----

- There were no private areas for the men.

**[3] On 10 June 2011, in accordance with the National Referral Mechanism (“NRM”), the framework for identifying**
potential victims of modern slavery and providing necessary support, an NRM form for each applicant was sent to
the Home Office. The Home Office made a 'reasonable grounds decision' that the Applicants were victims of human
trafficking for the purposes of the Council of Europe Convention on Action Against Trafficking in Human Beings.

**[4] The Applicants sought to have Acquis Business Systems Limited and/or John and Mark Anderson prosecuted**
for a range of alleged criminal offences against them. The offences which they argued were discernible from the
facts of this case were as follows:

[- Facilitating a breach of immigration law contrary to s 25 of the Immigration Act 1971;](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFF0-TWPY-Y0G4-00000-00&context=1519360)

- Employing an individual knowing he is disqualified from employment by reason of his immigration status contrary
[to s 21 of the Immigration, Asylum and Nationality Act 2006;](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y0S6-00000-00&context=1519360)

[- Fraud contrary to s 4 of the Fraud Act 2006;](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1W0-TWPY-Y0FT-00000-00&context=1519360)

- Human trafficking and slavery, contrary to s 4 of the Asylum and Immigration (Treatment of Claimants) Act 2004;

[- Slavery, servitude and forced or compulsory labour, contrary to s 71 of the Coroners and Justice Act 2009; and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95F0-Y97X-74X7-00000-00&context=1519360)

[- Failure to pay the minimum wage contrary to s 31 of the National Minimum Wage Act 1998.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y1CK-00000-00&context=1519360)

**[5] On 30 May 2019 the Public Prosecution Service (“PPS”) issued a decision letter refusing to prosecute Acquis**
Business Systems, John Anderson, Mark Anderson or any other person for any criminal offence.

**[6] Since then, the Applicants have sought to have these 'no prosecution' decisions reversed.**

**_Factual Background_**

**[7] The Applicants were recruited by Sea Crew, a Ghana-based recruitment agency that was working for Aquis, a**
Northern Ireland company of which John Anderson was a director.

**[8] To enable these men to join a ship in the UK, they required “Letters of Invitation” and “OK to Board” letters from**
their prospective employer. These documents were to be submitted to the British embassy in Ghana so that visas
permitting them to enter the UK could be issued to them. The documents, including “OK to Board” letters signed by
John Anderson and stamped with the Acquis business stamp, were issued for each of the men. The OK to Board
letters were dated 29 April 2011 and submitted to the British embassy in Ghana by Sea Crew. The letters state:

“To the officer in charge

Dear Sir /Madam

As agent for John Anderson owner of fishing vessel Kestrel B56 operating in international waters, we confirm
and certify the crewman detailed below is scheduled to join the vessel on 5 May 2011.”

[My emphasis.]

**[9] The documents used to procure the men's visas clearly state that they were to join a boat “operating in**
international waters,” and this representation governed the type of visa that was applied for and issued to the men.
Based on the documents supplied, the British embassy issued 'to join ship' visas to the men. These visas permitted
them to enter the UK and travel within the UK _for the purpose_ of joining a ship that would work in international
waters. They were, in effect, transit visas. They did not provide a right to remain in the UK, to work generally in the
UK, nor to work on a fishing boat that operated in UK territorial waters.


-----

**[10] While still in Ghana, the Applicants received a Seaman's Contract of Employment with Acquis, whereby they**
agreed to work on the boat for twelve months at a salary of £400 per month. They allege that other terms were
offered to them verbally, including a tonnage allowance and an allowance related to each port they entered in the
course of their work. These allegations are denied by John Anderson and/or Acquis, and no such terms appear in
the written contracts that were issued to the men. The document entitled “SEAMANS CONTRACT OF
EMPLOYMENT” provides for a salary of £400 per month and that the duration of the contract is “twelve months
upon mutual consent by both parties.” The contract also states “I agree to work on the named vessel for the period
entered above. I understand and agree that if I return home early for any reason (other than exceptional
circumstances agreed with ACQUIS BUSINESS SYSTEMS LTD). I will be responsible for all costs of flights etc.”
Separate contracts in identical terms were signed by each of the Applicants. The documents are all dated and
signed by John Anderson and bear the stamp of ACQUIS BUSINESS SYSTEMS LTD and are on headed Acquis
notepaper with their Kilkeel address in Northern Ireland and other contact details.

**[11] While still in Ghana each man was required to sign a letter to the effect that, if they left their job before the end**
of the twelve-month contract term, they would have to pay $2000 to Sea Crew. They were each required to procure
a guarantor to make the same undertaking, so that both the men and their guarantors were subject to the risk of
enforcement of this debt bond if they did not complete their full contractual terms. The Applicants state that this
guarantee was sought by Sea Crew at the request of Acquis and of John Anderson. John Anderson denies this
allegation.

**[12] The Applicants arrived in Kilkeel on 6 May 2011. They had travelled with Isaac Amoah, an employee of Sea**
Crew, who accompanied them to Kilkeel. Upon their arrival in Kilkeel, two of the three applicants had their
passports confiscated by Amoah.

**[13] On 18 May 2011 the visas of JR199 and JR200 expired, and on 20 May 2011 JR201's visa also expired. No**
steps were taken by the Andersons or by Acquis to regularise their immigration status.

**[14] The Applicants state that the boat they were assigned to fished between Northern Ireland and Scotland, and**
that it did not fish in international waters. This was in contravention of their visa status and had the effect that they
were not legally entitled to do the work allocated to them. This fact put them at risk of deportation for breach of
immigration laws, and of failing to complete their contracts which put them and their guarantors at risk of
enforcement of the debt bond. The resulting insecurity caused them anxiety and fear.

**[15] They complain that:**

- Between 7 May 2011 and 9 June 2011 they worked for the Andersons who warned them to stay on the vessel
because of the risk of arrest should they set foot on Northern Irish soil. As it happened, Isaac Amoah, who did not
live on the boat with them, was arrested by immigration authorities shortly after his arrival in Northern Ireland and
was deported for breach of immigration laws. The Applicants were therefore very aware of the risks of arrest and
deportation;

- The combination of circumstances which Acquis/the Andersons had created had the effect of imprisoning them on
the boat and left them with no option but to do the work the Andersons demanded of them;

- They endured exploitative working conditions in that they:

- had wages were withheld

- worked excessive hours; and

- lived in substandard conditions with poor hygiene facilities and poor-quality food.

**[16] All three applicants made statements to the PSNI in April 2014. The PPS considered prosecutions for all the**
candidate offences, but on 30 May 2019, it issued a decision not to prosecute John or Mark Anderson or any other
person for any criminal offence.


-----

**[17] In March 2020 the Applicants requested a review of this decision. On 6 October 2020 the Respondent issued**
a review decision letter (“the October decision letter”) which upheld the original decision not to prosecute. In this
letter the reason relied upon by the PPS was that there was insufficient evidence to generate a reasonable prospect
of conviction for any of the candidate offences. In other words, it decided that all the potential prosecutions failed to
meet the first limb of the test for prosecution – the evidential test.

**[18] Since October 2020 there has been a protracted exchange of correspondence between the parties, and the**
Respondent has changed its position in relation to some offences. These developments are set out below.

**_History of the present proceedings_**

**[19] On 15 December 2020 a pre-action protocol (“PAP”) letter was sent challenging the October decision letter**
and proceedings were issued thereafter. Leave to bring a judicial review was granted on the 29 July 2021 to all
three applicants.

**[20] The case was initially listed for substantive hearing on 14 December 21, then re-listed for 11 February 2022.**
There followed an application for discovery and a long series of case reviews related to the discovery issue.

**[21] The case was re-listed for substantive hearing in December 2022, but in November the Respondent proposed**
to re-take the impugned decision so the December hearing date was vacated in order to consider the result of any
changed position.

**[22] On 3 February 2023 a new decision letter was issued (“the February decision letter”). It reviewed the non-**
prosecution decisions for all the candidate offences and considered another potential offence, namely Fraud by
[false representation contrary to s 2 of the Fraud Act 2006. This provision states:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y06W-00000-00&context=1519360)

**“Fraud by false representation**

(1) A person is in breach of this section if he–

a dishonestly makes a false representation, and

b intends, by making the representation –

i to make a gain for himself or another, or

ii to cause loss to another or to expose another to a risk of loss

(2) A representation is false if–

a It is untrue or misleading, and

b The person making it knows that it is, or might be, untrue or misleading.”

By virtue of s 1(3)(b) a person who is guilty of fraud is liable on conviction on indictment to imprisonment for a term
not exceeding ten years or to a fine (or both).

**[23] The February 2023 decision-maker felt duty bound to consider this offence in relation to John Anderson and**
the OK to Board letters issued by his company, even though it was not one of the original candidate offences that
the Applicants had argued for. This was because of the evidence in the police file about the OK to Board letters.
Anderson was questioned by police about these letters and the prosecutor notes that:

“John Anderson accepted in interview that in effect he issued this letter and that the letter said the men were
joining a vessel that was to fish in international waters.”

When questioned about where it did fish:


-----

“John Anderson says that you can go in and out of the waters and when pressed says 'Everyone is breaking
that rule.”

The prosecutor concluded:

“I am satisfied that the statement in the Ok to Board letter was made by John Anderson and that it was false. It
was clear from the evidence in the file including … satellite data provided in the file that the vessel fished
between Ireland and Scotland and not in international waters. As the owner operator of the vessel I am
satisfied that Mr Anderson would have known this when making the statement. He admits as much when he
says 'Everyone was breaking that rule.' The Ok to Board letter was required to allow your clients to come to the
UK and work for him and employing your clients was done with a view to John Anderson trading profitably,
therefore, I am satisfied that the False Statement was made with the intention to make a gain.”

**[24] It is convenient at this stage to summarise what the decision-maker believed about the evidence at the**
material time. When this prosecutor made his decisions in February 2023, he was satisfied that sufficient evidence
existed to show that John Anderson knowingly made a false statement to the British embassy in Ghana to the effect
that the seamen he was recruiting there were going to work on a ship that would operate in international waters. He
also believed there was viable evidence to show that John Andeson made this false statement with the intention of
making a gain.

**[25] The second offence which he believed was supported by sufficient evidence was the breach of s 21 of the**
Immigration Asylum and Nationality Act 2006. This section provides:

“A person commits an offence if he employs another ('the employee') knowing that the employee is disqualified
from employment by reason of the employee's immigration status.”

**[26] The employee may be disqualified because their leave to enter or remain in the UK:**

“(i) is invalid

or

(iii) is subject to a condition preventing the person from accepting the employment.”

**[27] Although satisfied that the evidential limb of the test for prosecution was satisfied for both these offences, he**
decided that the public interest limb of the test was not satisfied in either case. One of the reasons he gave for his
decision on the public interest point was:

“The offences were committed at time when there was widespread non-compliance with the regulations around
immigration status of non-UK fishermen and that non-compliance was recognised and to some extent tolerated
by the introduction of the concession described by Craig Ragnor.”

**[28] Craig Ragnor is an official who worked for the Visa and Immigration Service and who provided a short memo**
to the decision-maker about the rules related to 'to join ship' visas, a memo which the Respondent avers he
considered during the decision making process.

**[29] On the basis of all the materials he reviewed, he decided to recommend no prosecution for any offence,**
including the two which he had found were evidentially adequate for prosecution. His decision in relation to the
public interest test in respect of these two offences was later reversed by the Respondent. Nevertheless, this
prosecutor's reasoning at the material time remains relevant to the evaluation of the rationality and reasonableness
of all his decisions in this suite of cases and we shall return to this in due course.

**[30] After the February decision letter was issued the Applicants' Order 53 statement was amended to address the**
changed rationale offered in that letter. Further extensive correspondence was exchanged between the parties
addressing the latest position adopted by the Respondent.


-----

**[31] The case was re-listed for substantive hearing on 15 and 16 March 2023. On 13 March the Respondent**
issued yet another decision (“the March 2023 decision”). On this occasion prosecutions were directed for three
offences, namely:

[i Facilitating a breach of the immigration law contrary to s 25 of the Immigration Act 1971;](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFF0-TWPY-Y0G4-00000-00&context=1519360)

ii Employing an individual knowing he is disqualified from employment by reason of his immigration status contrary
[to s 21 of the Immigration, Asylum and Nationality Act 2006; and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y0S6-00000-00&context=1519360)

[iii Fraud by false representation contrary to s 2 of the Fraud Act 2006.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y06W-00000-00&context=1519360)

**[32] Thus the Respondent reversed the earlier decision of February 2023 that it was not in the public interest to**
prosecute the fraud offence and the s 21 offence. A further offence was proposed to be charged also. The court
was informed by the Respondent that these prosecutions will be on indictment.

**_The remaining issues_**

**[33] The remaining issues may be summarised as public law challenges to the 'no prosecution' decisions in**
relation to three offences (“the remaining offences”). These are:

- Human trafficking and slavery, contrary to s 4 of the Asylum and Immigration (Treatment of Claimants) Act 2004,
(the “human trafficking offence”);

- Slavery, servitude and forced or compulsory labour, contrary to s 71 of the Coroners and Justice Act, 2009 (the
“forced labour offence”); and

[- Failure to pay the minimum wage, contrary to s 31 of the National Minimum Wage Act 1998 (“the minimum wage](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y1CK-00000-00&context=1519360)
offence”).

**_The respondent's decision_**

**[34] The elements of the remaining offences which must be proved to the criminal standard and the reasons for the**
'no prosecution' decisions in relation to each of them were contained in the February decision letter and have not
been changed since. They are set out below.

**_The human trafficking offence_**

**[35] The February decision letter sets out the relevant provisions that created this offence as follows:**

“1. Human trafficking and slavery under section 4 Asylum and Immigration (Treatment of Claimants) Act 2004

(since repealed but applicable at the time of these offences.)

4. Trafficking people for exploitation

(1) A person commits an offence if he arranges or facilitates the arrival in the United Kingdom of an individual
(“the passenger”) and –

a he intends to exploit the passenger in the UK or elsewhere, or

b he believes that another person is likely to exploit the passenger in the UK or elsewhere.

(2) A person commits an offence if he arranges or facilitates travel within the United Kingdom by an individual
(the “passenger”) in respect of whom he believes that an offence under subsection (1) may have been
committed and

a he intends to exploit the passenger in the United Kingdom or elsewhere, or


-----

b he believes that another person is likely to exploit the passenger in the United Kingdom or elsewhere …

(4) For the purposes of this section a person is exploited if (and only if)–

a he is the victim of behaviour that contravenes Article 4 of the Human Rights Convention (slavery and forced
labour),

b …

c He is subjected to force, threats or deception designed to induce him–

i to provide services of any kind,

ii to provide another person with benefits of any kind, or

iii to enable another person to acquire benefits of any kind …”

**_The suspects' intent_**

**[36] In relation to these offences the decision-maker states:**

“There is no reasonable prospect of a conviction for the offence of trafficking people for exploitation as there is
insufficient evidence that John or Mark Anderson arranged or facilitated the arrival in the UK of the men with
the intent to exploit them. Your clients agreed a contract with Sea Crew [sic] which set out the terms of their
employment. … but there is _no evidence_ that the suspects in this case, John and Mark Anderson, were
involved in the settling of these terms.'

[My emphasis.]

**[37] In fact, the Applicants' contract of employment was with John Anderson and ACQUIS not Sea Crew and, as**
we shall later see, there was evidence that John Anderson was involved in the drafting.

**[38] The prosecutor then considers whether any criminal intent can be evidenced from the actions the suspects**
took. He says:

“Even if it was arguable that the provision by John Anderson of an “OK to Board” Letter was deemed to have
been facilitating the arrivals of your clients in the UK I do not consider there is sufficient evidence to show that
either John or Mark Anderson (who had no involvement with the men before they arrived in the UK) had the
_necessary intent to exploit them.”_

[My emphasis.]

**[39] Having found no evidence of an** _intent to exploit, he goes on to consider the next element of the offence,_
“exploitation” itself.

**_Were the men 'exploited' for the purposes of the Act?_**

**[40] On the question whether the Applicants were “exploited” for the purposes of s 4 he says:**

“having considered the definition of what constitutes exploitation at 4(4) … I note that the applicable sections …
are (a) and (c).”

**[41] Section 4(4)(a) says a person is exploited if, and only if, “he is the victim of behaviour that contravenes art 4 of**
the Human Rights Convention (slavery and forced labour) …” Although not quoted in the decision letter, art 4 of the
European Convention on Human Rights (ECHR) provides:

“1. No one shall be held in slavery or servitude.


-----

2. No one shall be required to perform forced or compulsory labour.”

**[42] In relation to the elements of art 4(1) of the Convention (slavery and servitude) the decision maker says:**

“There is insufficient evidence to provide a reasonable prospect of a conviction of any offence based on slavery
or servitude. There is no evidence of John or Mark Anderson having or asserting any legal right of ownership
over your clients in this case.”

**[43] On the question of whether their labour might have been 'forced' for the purposes of art 4(2) ECHR they said:**

“The men entered the UK on a visa which did not entitle them to base themselves in the UK and was granted
for the purposes of their working on the boat but … they were not prevented from leaving the boat. The visas
were applied for by Sea Crew Services Limited and were not unusual visas for non-EU nationals who were
employed in the UK in the fishing industry to be issued with albeit these visas did not correspond to the work
the fishermen actually carried out.”

**[44] Considering whether the debt bond might be evidence of a contravention of art 4 ECHR he says:**

“The evidence suggests that the men had some apprehension in relation to the debt bond they had entered
into with Seacrew and the associated fear of deportation both of which are linked to Seacrew Services Ltd.”

**[45] Once again, the decision-maker here confines any wrongdoing for the purposes of art 4 to the recruitment**
agency rather than to either of the Andersons.

**[46] His consideration of the issue of potential forced or compulsory labour continues as follows:**

“In respect of whether your clients were subject to forced or compulsory labour the case law in this area would
look to the International Labour Organisations Conventions for guidance. The conventions define forced or
compulsory labour as being 'all work or service which is extracted from any person under the menace of any
penalty and for which the said person has not offered himself voluntarily.' In your submissions you state that
the precarious immigration and employment status make them _de facto prisoners on the boat. It is true that_
their immigration status did inhibit what they were free to do as it was conditional on their working on the boat
and prohibited them from basing themselves in the UK. However … despite this condition, they did leave the
boat or were told they could, albeit that there were risks in doing so. The fact that they may be deported if they
breached the terms of their arrival and stay in the UK does not in my view constitute a menace of penalty for
the purposes of showing they were subject to forced labour. Rather this was the factual position they find
themselves in and there was no evidence that the Andersons relied on their status as a menace; indeed Mark
Anderson warned the men to be careful.”

[My emphasis.]

**[47] This quest for overt “reliance” on their immigration status as a menace, referred to in the italicised section**
portion above, recurs elsewhere. For example, in relation to whether the debt bond could be considered a 'menace'
for the purposes of the ILO guidance he finds:

“there is no evidence that such a menace was used against them by the Andersons.”

**[48] As he had done in relation to their irregular immigration status, we again, find the decision maker looking for**
evidence that the suspects relied upon the debt bond as a menace. He finds no such evidence. Indeed, he notes, in
relation to their precarious and irregular immigration status, apparently approvingly, that Mark Anderson “warned
the men to be careful.” Thus, even when the facts show a suspect bringing their precariousness and its risks to the
conscious attention of the men, this prosecutor interprets that action as a 'friendly warning' and fails to consider the
possibility that it might be the very mechanism wherein reliance may be evidenced.

[My emphasis.]


-----

**[49] Next, he considers the Applicants' submissions about indicators of trafficking. He says:**

“In your submissions you highlight the poor pay, withheld wages, accommodation and working conditions as
further examples of indications of trafficking/forced labour that your clients were subjected to by the Andersons.
However, the conditions were not considered as poor by another fisherman who was on the vessel”.

**[50] The person referred to was “BR”, a Lithuanian fisherman, on board at the same time as the Applicants. The**
prosecutor says:

“The evidence of [BR]] would have particular importance when assessing the prospects of establishing that
your clients were the victims of forced labour on the basis of the factors set out above … as he had a clear
animus to the Andersons yet confirmed the conditions, whilst undoubtedly difficult, were what was to be
expected in the trade.”

**[51] There is no explanation from the prosecutor of why he chose to give such weight to the subjective, non-expert**
view of this fisherman as opposed to the subjective, non-expert views of the three applicants, or as to whether he
sought any expert report about the objective conditions on board the boat when measured against applicable
standards contained in relevant legislation at the material time.

**[52] Next, he considers the requirements of s 4(4)(c), ie whether forced labour could be proved by showing these**
men were subjected to force, threats or deception to induce them to work for the Andersons. He finds:

“There is no evidence that your clients were forced into signing the contract or the undertaking about a penalty
of $2,000 if they broke the contract. They may have felt that had to [sic] because of the money they had paid to
date but there is insufficient evidence to prove that the Andersons were involved in any significant way in the
circumstances under which they signed the contract and debt bond _and it is accepted that this took place in_
_Ghana.”_

[My emphasis.]

**[53] Next, he makes a statement which is inconsistent with his earlier analysis of the evidence set out at para [36]**
above. In that earlier analysis the decision maker was considering whether there was evidence that the suspects in
arranging or facilitating the Applicants' arrival in the UK did so with the intent to exploit. In that context he says that
there was 'no evidence' that the suspects were involved in settling the terms of the Applicants' employment.
However, some two pages after that analysis he expressly says there _was_ evidence of John Anderson's
involvement in drawing up the contract:

“In [BR's] statement he does say he _was involved in typing up the contract for the Ghananians_ **_for_** _John_
_Anderson so this would be some evidence of his involvement in the drawing up of the contract …”._

We shall return to the significance of this conflict in due course. However, we note that the decision-maker's initial
position was that there was “no evidence” that the Anderson suspects were involved in the settling of the contract;
next it is “insufficient evidence” that the suspects were involved in any “significant” way; and then to a third position,
namely, an acknowledgment that BR was involved in typing up the contract “for the Andersons” and that this “would
be some evidence of his involvement in drawing up the contract.” So from “no evidence” that the suspects were
involved in drawing up the contract the decision-maker has moved to the position that the contract was being typed
up by B specifically “for the Andersons” (the suspects) and, contrary to what he had previously said, that this
constituted evidence of John Anderson's involvement in the drawing up of the contract.

Further, if by use of the qualification 'some' the decision maker intends to imply a 'small or insignificant' amount of
evidence, we do not understand the basis for such a qualification. As noted earlier the documents entitled
“SEAMANS CONTRACT OF EMPLOYMENT” are all dated and signed by John Anderson and bear the stamp of
ACQUIS BUSINESS SYSTEMS LTD and are on headed Acquis notepaper with their Kilkeel address in Northern
Ireland and other contact details.

**[54] He concludes his review of the evidence for the human trafficking offence as follows:**


-----

“Having considered this offence I do not consider there to be a reasonable prospect of a conviction in respect
of John or Mark Anderson.”

**_[Offence under section 71 of the Coroners and Justice Act 2009](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95F0-Y97X-74X7-00000-00&context=1519360)_**

**[55] Section 71 of the 2009 Act provides:**

“Slavery, servitude and forced or compulsory labour

(1) A person (D) commits an offence if–

a D holds another person in slavery or servitude and the circumstances are such that D knows or ought to
know that the person is so held, or

b D requires another person to perform forced or compulsory labour and the circumstances are such that they
know or ought to know that the person is being required to perform such labour.

(2) In subsection (1) the reference to holding a person in slavery or servitude or requiring a person to perform
forced or compulsory labour are to be construed in accordance with Article 4 of the Human Rights Convention
…”

**[56] Having set out the provision which creates this offence, the prosecutor states that it:**

“will require the application of the same principles as discussed above and for the same reasons as above I do
not consider that there is a reasonable prospect of conviction for this offence.”

[My emphasis.]

**[57] The rationale for the non-prosecution of the s 71 forced labour offence is, therefore, the prosecutor's view that**
there is insufficient evidence to justify a prosecution of either of the Andersons for this offence.

**_The Minimum Wage Offence_**

**[[58] The final offence he considers is the s 31 offence under the National Minimum Wage Act 1998. In relation to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)**
this he says:

[“Offences under the National Minimum Wage Act 1998 are investigated by HMRC. No file was received by the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)
PPS from HMRC in respect of John or Mark Anderson and your clients and I understand that the HMRC
decided to take no further action. I am unaware of the reasons for their decision … In any event the decision
not to prosecute for this offence was not a decision of the PPS and therefore no right of review exists under the
PPS Code for Prosecutors nor under our continuing duty to review prosecution decisions as no such decision
was made. Any complaint that a prosecution for this offence was not forthcoming should be directed to HMRC.”

**[59] The materials considered above represent the reasons given by the decision maker for the 'no prosecution'**
decisions he issued in February 2023.

**[60] His February 2023 decision differs materially from the October 2022 decision. The October decision finds that**
the evidential test was not satisfied in respect of any offence. The February 2023 decision was that the evidential
test was satisfied for two offences, including the fraud offence. Despite the sufficiency of the evidence (and the
seriousness of the charge) the decision maker nevertheless concluded that it was not in the public interest to
prosecute for either offence, including the fraud offence. The Code for Prosecutors makes clear that there is a
presumption in favour of prosecution if the evidential test is met and that the serious nature of a case would make
the presumption a 'very strong one': see _Re B v PPS_ _[[2021] NI 593. As earlier noted, this decision provoked](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6459-40K3-GXF6-84RN-00000-00&context=1519360)_
interesting and detailed correspondence as well as an amendment to the Ord 53 statement challenging this aspect
of the decision. So, in February 2023 this prosecutor was satisfied that the evidence _was_ sufficient to mount
prosecutions for the offences of employing an individual knowing he is disqualified from employment by reason of


-----

his immigration status, and committing fraud on the immigration system by making false representations to the
British embassy in Ghana; but, in both cases, he decided that it was not in the public interest to prosecute.

**[61] As we have seen, his decisions on the public interest test in relation to these two offences have now been**
reversed by the Respondent which also reversed his finding that there was insufficient evidence to mount a
[prosecution for the offence of facilitating a breach of immigration law contrary to s 25 of the Immigration Act 1971.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-CFF0-TWPY-Y0G4-00000-00&context=1519360)

**_The parties' arguments re the remaining offences_**

**_Applicants' arguments_**

**[62] The Applicants' arguments in relation to the remaining offences have been taken from their Ord 53 statements**
and their skeleton arguments related to both the October and the February decision letters. There is inevitable
overlap and duplication within these documents, so the court has selected those arguments that we consider have
most weight. It can be assumed that any argument that is not specifically addressed in this judgment has been
dismissed, rather than overlooked, by this court.

**[63] In addition to the arguments summarized below, the Applicants make the overarching and recurring complaint**
that the Respondent did not exhibit all the evidential material it relied upon in reaching its decisions, and that this
approach has placed them at a disadvantage when making their case. Bearing this last complaint in mind, we
summarise below the most cogent arguments advanced by the Applicants in relation to each of the remaining
offences.

**_The Human Trafficking Offence_**

**[64] The Applicants say there are overlaps between the human trafficking offence and the forced labour offence in**
that both target forms of exploitation of vulnerable workers. They say that in any case involving a consideration of
whether a person has been subject to slavery, human trafficking, servitude, or forced/compulsory labour, the
starting point should be to consider whether the facts of the case disclose what are known as the “indicators of
trafficking.” These indicators are used by first responders such as the police to identify potential victims of such
offences, and they also appear in the Crown Prosecution Service (“CPS”) guidance notes in a section entitled
“Evidential Considerations.” The Respondent attached this guidance to its affidavit and averred that the October
decision-maker considered them in this case. The Applicants say that such consideration is not apparent from the
text of the decision in the October letter and claim that the absence of any proper consideration of the indicators
“informed the decision maker's analysis that the men had not been exploited,” which is the basis of the conclusion
that there was no reasonable prospect of conviction for human trafficking offence in the October decision. One
might have thought that if the decision maker had considered the guidance that it would have been apparent from
the text of the decision letter. In the absence of disclosure by the PPS of the underlying material the court must
accept the averment. We say that bearing in mind that the Respondent owes a duty of candour to the court and that
if there were any material inconsistent with the averment that it would have been disclosed by the Respondent to its
lawyers and thence to the court.

**[65] Specific aspects of the alleged exploitation which the Applicants say were not considered adequately or at all**
include the withholding of pay. The October decision found there was insufficient evidence to prove that pay was
withheld by John Anderson. The Applicants claim this finding is irrational on the facts because it fails to have regard
to the obligations placed on employers of seamen under applicable merchant shipping regulations, which require
them to pay the seamen and to deliver accounts. The Applicants assert that “if the men had been paid the
Andersons would have been able to provide accounts showing same.”

**[66] They also note that prior to the impugned October decision being taken, Newry Magistrates' Court had made**
an order for forfeiture of withheld wages for persons who had worked on the Andersons' boat. Two of the Applicants
received letters from the PSNI in relation to a payment that was to be made to them. In response to a follow-up
letter from their solicitors the PSNI confirmed:


-----

“The order was issued on the 25 September 2019 at Newry Magistrates' Court and is an order for forfeiture of
detained cash … the sum of £4200 is to be retained by the PSNI for dissemination to workers of the
respondent in respect of outstanding wages.”

**[67] The PSNI confirmed that six workers stood to receive payments, including two of the Applicants in the present**
case. The Applicants note that the existence of this order undermines the October decision-maker's finding of
“insufficient evidence” that their wages were withheld.

**_Working Conditions_**

**[68] In their complaints to the PSNI the Applicants asserted that they worked excessive hours and that their living**
conditions were poor. Both these factors are indicators of trafficking. In relation to the working conditions the
October decision found that:

- Working conditions were poor and hours were long but there was no evidence that they were manifestly
excessive;

- There was no expert evidence to show a comparison between the men's working hours and conditions and the
norm, and police did not intend to provide such evidence; and

- Such additional expert evidence would in any event not enable prosecution in the absence of proof of the menace
of penalty applied by the Andersons.

**[69] The Applicants assert that these conclusions in relation to working hours failed to have regard to the Fishing**
Vessels (Working Time; Sea-Fishermen) Regulations 2004 which provide limits to working time at sea. They say
the decision maker should have referred to those objective, mandatory standards to determine whether the hours
demanded from the Applicants were in fact excessive, and that by failing to reach a reasoned conclusion on this
point the Respondent had failed to have regard to a material consideration.

**[70] In relation to the Respondent's reliance on lack of expert evidence provided by the police on these matters,**
the Applicants question whether expert evidence was necessary given the easy availability of the 2004 Regulations
which could have informed a rational decision being taken by the Respondent itself on the point. Also, if it was felt
that an expert report was required, then there was nothing to prevent the Respondent from directing such a report
for itself.

**[71] In relation to the complaints about working conditions they note that standards governing the conditions of**
merchant seamen are also set out in a range of statutory regulations. These deal with matters such as cabin size,
washing facilities, and galley areas for the preparation of food at sea.

**[72] The Applicants assert that there is inconsistency in the Respondent's affidavit in relation to exactly what**
evidence it had about the working conditions. They note that para 32 of the Respondent's affidavit suggests there
was no expert evidence about it, whereas para 82 suggests that an expert report was sought, and it concluded that
there **was** sufficient evidence to provide a reasonable prospect of conviction for breaches of the relevant
regulations.

**[73] They say this inconsistency underscores the need for respondents to exhibit the evidential materials they have**
regard to when taking decisions like these. We will return to this point in due course.

**[74] The Applicants assert that the Respondent erred in law because it failed to consider the relevance of the**
men's precarious employment status adequately or all. The Applicants' evidence about their precarious position and
its effects includes the following matters:

- The Andersons/Acquis assisted the men to obtain visas which did not comply with immigration law, and which
placed them in a precarious legal position.


-----

- They were told by their skipper Mark Anderson not to leave the boat because of these risks, and Mark Anderson
berthed the boat in a place that made it hard for them to get off.

- They had each entered a substantial debt bond which their families would be liable for if they did leave their jobs.

- They were not being paid for the work they had done which added to their insecurity.

**[75] The Applicants assert that exploitation of a precarious immigration status is an indicator of trafficking and is**
equivalent to a form of coercion by circumstance. We were referred to Siliadin v France [2006] 43 EHRR 13 which
states:

“117. It remains to be ascertained whether there was “forced or compulsory” labour. This brings to mind the
idea of physical or mental constraint. What there has to be is work “exacted … under the menace of any
penalty” and also performed against the will of the person concerned, that is work for which he “has not offered
himself voluntarily” (see Van der Mussele, cited above, p. 17, § 34).

118. The court notes that, in the instant case, although the applicant was not threatened by a “penalty”, the fact
remains that she was in an equivalent situation in terms of the perceived seriousness of the threat.

She was an adolescent girl in a foreign land, unlawfully present on French territory and in fear of arrest by the
police. Indeed, Mr and Mrs B nurtured that fear and led her to believe that her status would be regularised (see
paragraph 22 above).

Accordingly, the court considers that the first criterion was met, especially since the applicant was a minor at
the relevant time, a point which the court emphasises.

119. As to whether she performed this work of her own free will, it is clear from the facts of the case that it
cannot seriously be maintained that she did. On the contrary, it is evident that she was not given any choice.

120. In these circumstances, the court considers that the applicant was, at the least, subjected to forced labour
within the meaning of Article 4 of the Convention at a time when she was a minor.”

**[76] The salient point, the Applicants say, is that the victim in** _Siliadin_ was not “threatened by a penalty” but the
court treated her as nevertheless being in an equivalent situation because of the circumstances she found herself in
and the seriousness of the de facto threats she faced.

**[77] The Applicants allege that the Respondent misdirected itself in law by requiring evidence of reliance upon a**
threat by the suspects. The alleged misdirection is seen in the following paragraph of the October decision letter:

“I do not consider that [expert evidence about the men's working conditions] would add sufficient to enable
there to be a prosecution in this case in the absence of evidence to prove the menace of penalty applied by the
Andersons.”

The Applicants argue that the conclusion drawn in the October decision letter was wrong in law:

“The reliance on absence of menace to conclude that the offences cannot be made out was not informed by
relevant settled law or relevant CPS guidance.”

**[78] Many of these arguments were made initially in relation to the October decision letter which the Applicants say**
were not corrected by the February letter. Since the same errors are present there, these arguments are equally
applicable to the February decision.

**_Respondent's arguments_**

**[79] In the PPS skeleton argument dated 13 March 2023 Dr McGleenan KC summarises the reasons for the 'no**
prosecution' decision in relation to these offences as follows:


-----

“The Human Trafficking Offence

The assistant director is not satisfied there is a reasonable prospect of proving the offence beyond reasonable
doubt on the available evidence. He was not satisfied that the necessary intent, which is either an intention to
exploit or a belief that another was likely to exploit, could be proven to the required standard.

**_The Forced Labour Offence_**

The section 71 offence requires proof beyond reasonable doubt that the defendant 'holds another person in
slavery or servitude' or 'requires another person to perform forced or compulsory labour' and that the defendant
knows or ought to know this. Section 71 therefore requires proof of actual exploitation in the form of slavery
servitude or forced labour. The prosecutor was not satisfied there was a reasonable prospect of proving any of
these elements of the offence beyond reasonable doubt.

**_The Minimum wage offence_**

In relation to the alleged failure to pay the minimum wage he notes that the applicants have not lodged any
statement of complaint on this issue and that the PPS has not received a file referring to such a complaint. He
states that this type of offending is investigated by HMRC and that therefore the applicants have an alternative
remedy which they have failed to exhaust.”

**_Discussion: general_**

**[80] This case involves a consideration of how the test for prosecution was applied to a suite of potential criminal**
offences. In the present context, the offences in play all target practices of exploitation of potentially vulnerable
workers.

**[81] The test for prosecution has two limbs. The first limb is the evidential test. This requires that the evidence**
which can be adduced in court is sufficient to provide a reasonable prospect of conviction. If the available evidence
fails to meet this threshold, the PPS must issue a 'no prosecution' decision.

**[82] If the evidence is deemed sufficient to meet the evidential test, then the PPS must apply the second limb of**
the test. This is the public interest test. It states that a prosecution should be directed if it is required in the public
interest.

**[83] Only if both limbs of the test are satisfied should a decision to prosecute be issued. The second limb, the**
public interest test, only comes into play after it is decided that the first limb is satisfied.

**[84] The PPS has now directed prosecutions in respect of three offences that arise from the factual matrix in this**
case. In relation to the three remaining offences, the decision makers' view is that the evidential test is not satisfied
and therefore no prosecution can be directed in respect of any of them. The question we must decide, therefore, is
whether the Respondent committed any public law error in so concluding.

**[85] The principal role of the PPS is to evaluate evidence of crime and to direct prosecution in those cases where**
there is sufficient evidence to provide a reasonable prospect of conviction and where the public interest requires
that a prosecution should take place. Broadly, the presumption is that the public interest requires prosecution where
there has been a contravention of the criminal law, and that the serious nature of the case will make the
presumption a very strong one.

**_Applicable legal principles_**

**[86] The extent to which a prosecutorial decision is amenable to judicial review and the relevant caselaw are set**
[out in Re Margaret Brady [2018] NICA 20, at paras [91]-[93]; and in the recent judgment of the Lady Chief Justice](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SY2-B8V1-DYBP-Y0NH-00000-00&context=1519360)
[sitting in the Divisional Court in Re Duddy, Montgomery and McKinney's Application [2022] NIQB 23 (“McKinney's](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65J9-NNH3-CGX8-018V-00000-00&context=1519360)
_Application”), at paras [52]-[63], with a helpful summary set out at para [63]. There was no significant dispute before_
us as to the applicable legal principles. There is a clear and recognised distinction between a challenge to a


-----

decision to prosecute, and one not to prosecute. In relation to the latter, judicial review is the only available remedy,
hence a more intense degree of scrutiny may be required than is otherwise applicable in challenges to prosecutorial
decision-making.

**_Irrationality Test_**

**[87] Para [153] of McKinney's Application states:**

“… we consider that the decision crosses the threshold of irrationality where it simply does not add up or, in
other words, there is an _error of reasoning_ which robs the decision of logic: see _R v Parliamentary_
_Commissioner for Administration, ex parte Balchin [1996] EWHC Admin 152. …”_

[My emphasis.]

**[[88] In the recent case of Craig Thompson's Application [2022] NIKB 17, Humphreys J noted:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66SM-THV3-GXF6-8181-00000-00&context=1519360)**

“[33] In _Re McKinney's Application_ _[[2022] NIQB 23 the Divisional Court recently approved the rationality test](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65J9-NNH3-CGX8-018V-00000-00&context=1519360)_
espoused by Lord Woolf in R v North and East Devon HA ex p. Coughlan [2001] QB 213:

'Rationality, as it has developed in modern public law, has two faces: one is the barely known decision which
simply defies comprehension; the other is a decision which can be seen to have proceeded by flawed logic.'”

[para 65]

**[89] Having reminded ourselves of the scope of our role in reviews like this, we now consider the February**
decision-maker's reasoning in relation to each of the remaining offences. But first it is important here, as in every
case, to be aware of the general context within which the factual matrix exists.

**_The general context_**

**[90] One factor which contributed to the outcomes in this case is the general context which applied in the UK**
fishing industry when these potential offences occurred. The February decision letter refers to this context in several
places. In his consideration of whether the Applicants could be said to be victims of behaviour that contravenes art
4 of the European Human Rights Convention he says:

“The men entered the UK on a visa which did not entitle them to base themselves in the UK … The visas were
applied for by Sea Crew Services Ltd and were not unusual visas for non-EU nationals who were employed in
the UK in the Fishing industry to be issued with albeit these visas did not correspond to the work the fishermen
actually carried out.”

**[91] Addressing the Applicants' complaint that these insufficient visas created risks to them which caused them**
fear and anxiety, he says:

“The fact that they may be deported if they breached the terms of their arrival and stay in the UK does not in
my view constitute a menace of penalty for the purposes of showing they were subject to forced labour. Rather
_this was the factual position they found themselves in and there was no evidence that the Andersons relied on_
_their status as a menace …”_

[My emphasis.]

**[92] This approach treats the factual background to the men's immigration status as if it were a simple aspect of**
happenstance which befell them quite haphazardly. It fails to make any reference to the fact that the factual
circumstances of the men's employment in the UK were purposefully engineered by John Anderson, as this
prosecutor accepts elsewhere in his decision letter.


-----

**[93] The evidence for what the prosecutor believed John Anderson did in this case comes from his discussion of**
one of the other offences he considered, namely fraud by false representation, contrary to _[s 2 of the Fraud Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y06W-00000-00&context=1519360)_
2006. This Act provides at s 1 that a person is guilty of fraud if he is in breach of any of a range of sections including
s 2 (fraud by representation). Section 2 has already been set out at para [22] above.

**[94] Having reviewed the evidence in relation to this offence the prosecutor says:**

“I am satisfied that the statement in the OK to board letter was made by John Anderson and that it was false. It
is clear from the evidence in the file including … satellite data provided in the file, that the vessel fished
between Ireland and Scotland and not in international waters. As the owner operator of the vessel I am
satisfied that Mr Anderson would have known this when making the statement. He admits as much when he
says that “everyone was breaking that rule.” The OK to board letter was required to allow your clients to come
to the UK and work for him and employing your clients was done with the view to John Anderson trading
profitably, therefore, I am satisfied that the false statement was made with the intention to make a gain.

[In view of all of that I believe that there is a reasonable prospect of a conviction for an offence under Section](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)
_[1(2) and (2) of the Fraud Act 2006.”](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1V0-TWPY-Y0X7-00000-00&context=1519360)_

**[95] The evidence in relation to John Anderson's role in the 'OK to board' letters, his procurement of the insufficient**
visas, and his intentions when taking these actions, is also relevant to the question of the same suspect's general
intentions towards these men. There are obvious inferences that could be drawn from the facts the prosecutor
found about what John Anderson did and why, which inferences are relevant in relation to the _mens rea_ of the
human trafficking offences, and there is no evidence anywhere in the papers that he gave any thought to what
those inferences might be. It is also clear that he did not have regard to his own findings in respect of the offences
in which he accepted that the evidential test was satisfied, when considering, inter alia, the issue of intent to exploit
for the purposes of the human trafficking offences. This is a clear failure to have regard to relevant factors.

**[96] We are also concerned about the decision-maker's knowledge and understanding about a Government**
concession made to the UK fishing industry at the material time. The Respondent's affidavit says that the police file
contained some information about this. Para 34 of the affidavit says, “The Visa and Immigration Service … did
provide a short memo, which I considered.” This memo came from Craig Ragnor who worked in that service. The
decision-maker describes it as follows:

“The memo … referred to a concession operated outside of the Immigration Rules _which operated like an_
_amnesty between March 2010 and August 2012 (which includes the potential offending period), which enabled_
fishermen operating in the UK waters without the appropriate authority to regularise their position. It appeared
the problem was common. The concession system required payment of a fee, although there was no evidence
any such attempt had been made to engage in this process by any of those involved in this case.”

[My emphasis.]

**[97] The concession that the prosecutor thought 'operated like an amnesty' was in fact designed to address a**
prevalent malpractice within the inshore fishing industry at the material time. It was explained as follows in a House
of Commons debate on 28 November 2012 by the then Minister for Immigration, Mr Mark Harper, who said:

“The use of non-European economic area crew on UK vessels has been an issue for several years …

I will set out the background of the visa regime for those who work in the sector. Non EEA migrants can come
to the UK to join ships that are currently in the UK but operate outside UK territorial waters - those ships that
mostly operate more than 12 nautical miles beyond UK territorial waters. Because those people are joining
ships that operate outside the UK, they do not fall under the scope of normal immigration rules, which means
they do not need permission to work. However, they do need permission to enter the UK to join the ship
effectively to transit ….


-----

Migrants entering through that route are not migrant workers in the usual sense, so the system is not a
loophole through which employers can bring in non-EEA workers to carry out work that is not deemed to be
sufficiently skilled, as the work is largely taking place outside the UK. We recognise the need for migrant labour
in some specific and highly skilled roles in the United Kingdom but … businesses should be looking to the local
labour market for opportunities to fill lower skilled roles. That is why non EEA nationals cannot come to work on
_vessels that operate within the 12 mile limit - the inshore fleet- under the 'to join ship' provisions …_

_Visas would not be issued for people to come to work on inshore vessels. People who workor employ people to_
_work- on vessels in the inshore fleet after they have come to the UK on a “to join ship” visa … are breaking_
_immigration law and behaving unlawfully._

Some years ago, it became apparent that some in the UK inshore fishing fleet were using non EEA labour to
crew their ships. The UK Border Agency made it clear that that was not acceptable and that immigration rules
needed to be enforced in that area. However, genuine concerns were raised … including by the Scottish and
Northern Ireland Governments, that the UK fishing fleet relied on non-EEA labour and that immediate
enforcement of the immigration rules would have a significant and negative impact on that fleet.

In light of those concerns, in March 2010, the previous Government introduced temporary … concessions that
allowed for up to 1,500 visas to be issued to non-EEA fishermen to work on the UK inshore fleet _to give it_
_sufficient time to transition to using local labour for such job s …_

_Those concessionary arrangements came with strict conditions. Permission was granted only after appropriate_
_assurances were given that the worker would be paid the minimum wage and … that they would be given_
_suitable onshore accommodation when their ships were in port. The take-up of the concession was relatively_
low … and we closed it down for good this August (2012).

UK Border Force … regularly undertakes enforcement action to ensure that those who employ non-EEA
fishermen do so legally …

As with all our enforcement activity, we do not accept people hiring outside the immigration rules, and we seek
_to deal with that in a tough manner.”_

[My emphasis.]

**[98] Given this explanation from the responsible Minister, it is not clear how the decision-maker could rationally**
consider that the concessionary arrangements 'operated like an amnesty.' This is a clear misunderstanding of a
relevant factor which has infected the reasoning in the case.

**[99] The true situation was that when John Anderson hired these men in Ghana, he had a choice of two ways to do**
it. He could either apply for “to join a ship” visas and falsely declare that the ship they would work on would operate
in international waters, when he knew that it would not. This is the route he chose to take, and it was an illegal route
as is reflected in the decision that has now been taken to prosecute John Anderson for fraud by misrepresentation
and for employing persons who he knew were disqualified by their immigration status from doing the work allocated
to them by the Anderson's.

**[100] The other way John Anderson could have hired the men also involved using “to join a ship” visas but**
compliantly with the “concession” system which operated at that time. To use this route Anderson would have to
give undertakings that these fishermen would (a) be paid at least the minimum wage and (b) would be given
appropriate on-shore accommodation when their ship was in port.

**[102] The evidence suggests that John Anderson knowingly and deliberately chose the illegal route over the legal**
route and the February decision maker found that he did so in order to trade profitably and “to make a gain.” The
reason he gave to the police for choosing the illegal route was that “everyone was breaking that rule.”

**[103] We consider that these facts say a great deal about what intent towards the Applicants can properly be**
inferred from John Anderson's decision to make false representations to the British embassy in Ghana


-----

**[104] The February decision-maker does not identify or evaluate what inferences might be drawn from such**
behaviour. This is because he proceeded on a fundamental misunderstanding because he understood or believed
that the 'concession' that applied at the time “operated like an amnesty.” That is what he says about his own
understanding of the “concession.” We can find no rational basis for such a conclusion about the concession as it
was explained by the responsible Minister at the time. It was a limited mechanism to permit employers to operate
_within the rules; not a licence to turn a blind eye to those acting outside the rules. The non-prosecution decision for_
the human trafficking offences was infected by that misunderstanding of the nature and purpose of the concession.
The decision “simply does not add up”, proceeds on the basis of flawed logic, and therefore cannot stand.

**[105] The principal reason the decision-maker gives for not prosecuting John Anderson is set out in the following**
paragraph:

“There is no reasonable prospect of a conviction for the offence of Trafficking People for Exploitation as there is
insufficient evidence that John or Mark Anderson arranged or facilitated the arrival in the UK of the men with
the intent to exploit them. Your clients agreed a contract with Seacrew which set out the Terms of their
employment. There were other verbal commitments given by the Assistant Manager Isaac Amoah but there is
no evidence that the suspects in this case, John and Mark Anderson, were involved in the settling of these
terms. Even if it was arguable that the provision by John Anderson of an 'OK to Board' letter was deemed to
have been facilitating the arrivals of your clients in the UK I do not consider there is sufficient evidence to show
that either John or Mark Anderson (who had no involvement with the men before they arrived in the UK) had
the necessary intent to exploit them.”

**[106] This paragraph suggests several things about the prosecutor's reasoning on the issue of intent. First, he**
appears to harbour doubts about whether or not the provision by John Anderson of an 'OK to Board' letter could
properly be deemed to have been facilitation of the arrival of the men in the UK at all. If that is what is intended to
be conveyed, it simply does not add up. What else could the provision of such a letter possibly be? Secondly, he
considers that even if this “doubt” was resolved in favour of the Applicants, there would still be no evidence of the
requisite intention to exploit in John Anderson. This is because, in his view, the Applicants agreed their contracts
with the agent Sea Crew alone and these contracts set out the terms of their employment. Should it turn out that
these terms were exploitative, that circumstance would not constitute evidence of the intent to exploit on the part of
John Anderson because there is no evidence that he was involved in settling those terms or, in other words, no
evidence of his 'involvement' in the drawing up of the contract.

**[107] This too does not add up given that later in the same letter he explicitly mentions that there is evidence of**
John Anderson's “involvement in the drawing up of the contract” which is contained in BR's statement to the PSNI.
This is precisely the evidence that he suggested earlier did not exist. Without repeating ourselves we refer to what
we have said on this subject at para [53] of this judgment.

**[108] In addition to this conclusion on John Anderson's intent being (at least potentially) contradicted by the**
available evidence, the paragraph quoted at para [105] above suggests a second, very dangerous reason why
criminal intent could not be attributed to John Anderson. This is in his statement that:

“Your clients agreed a contract with Seacrew which set out the terms of their employment.”

Then the decision-maker follows up with:

“There is no evidence that … John and Mark Anderson were involved in the settling of these terms”.

**[109] We consider that there ought to have been anxious scrutiny of the totality of the arrangements and**
mechanisms in play, not least because of the context of alleged human trafficking. Such exploitation is
characteristically international, crossing borders and territories and involving collaboration by different actors at
different levels. At its heart it will often involve the exploitation and abuse of power of those who are vulnerable for a
variety of reasons or who are rendered vulnerable to facilitate their exploitation. The motive for the exploitation will
usually be financial gain. The acceptance, without proper investigation and anxious scrutiny of the arrangements
and mechanisms in play, poses clear dangers. Particularly in the field of exploitative crime such as human


-----

trafficking, decision makers must be astute not to place undue weight on, eg, the formal legal separation between a
principal and his agent as a basis for non-prosecution. Indeed, the 'separate' legal entity may be the vehicle (or one
of them) by which alleged exploitation is engineered. The danger is that by failing to probe or being complacent in
the face of agency arrangements, prosecutors could unwittingly enable principals to be effectively insulated from full
or any criminal responsibility for actions taken by their agents. This is extremely dangerous ground given that in
human trafficking cases foreign agents, acting outside the reach of our criminal laws, could be (and no doubt are)
regularly recruited precisely to take the actions that would more readily result in criminal responsibility if done
directly by a UK principal.

**[110] The drawing of this dividing line between principal and agent revealed in the passages set out above also sits**
uncomfortably with the decision-maker's own findings in relation to the s 2 fraud offence. There he was satisfied
that the 'OK to Board' letters were, in effect, written by John Anderson and that he wrote them with the intent of
trading more profitably and making a gain.

**[111] In the present case there was direct evidence of John Anderson's involvement in the drawing up of the**
contract between him/Acquis and the Applicants. This is not really surprising given who the parties were to the
relevant employment contract. Speaking generally, such evidence will not exist in every case and the competent
authorities need to be diligent in following the evidence necessary to show which party was in truth directing and
benefiting from the alleged wrongs suffered by complainants in cases of suspected human trafficking. The
competent authority must be expected to forensically probe and not be complacent or less resolute where a
separate legal entity is inserted into the mix. Should traffickers gain the impression that enforcement agencies were
disinclined to go behind basic agency arrangements to ascertain where criminal liability may really come to rest, this
would come with very high and unacceptable costs. One of those costs is that migrant fishermen rendered
vulnerable by engineered insufficient visa arrangements, could be subjected to forced labour, made to work
excessive hours for no or insufficient pay and forced to live in quite unsuitable conditions without any or effective
access to any redress. Another cost is that lower skilled jobs which are intended by Government policy to be made
available to less skilled workers within the domestic economy will never become available to those workers simply
because it is immeasurably cheaper to hire illegal migrant workers to perform that work. From a public policy
perspective this is a lose-lose situation for every party involved except the employer who illegally maximises his
profits at the expense of every other stakeholder and potential stakeholder involved.

**[112] In light of all the above we consider that the decision-maker's conclusion that there is insufficient evidence to**
give rise to a reasonable prospect of proving the intent required for the human trafficking offences cannot stand. It
“simply does not add up”, proceeds upon flawed logic, fails to identify or take into account obvious inferences;
and/or proceeds on a wholly erroneous misunderstanding that the “concession” that applied “operated like an
amnesty.”

**_Working conditions_**

**[113] There is also merit in the Applicants' complaints about how the prosecutor dealt with their statements about**
working conditions [see paras [68]-[73]]. The accommodation requirements for seamen are regulated by secondary
legislation that is freely available for anyone to consult. There is no evidence that the prosecutor did consult it, but
he reached the conclusion that there was insufficient evidence of exploitation on the basis of views expressed by
another worker (BR) living on the boat. It is not explained why this worker's view was preferred over that of the
Complainants. There is some uncertainty as to whether the prosecutor requested and obtained an expert report
about the adequacy of the living conditions. We proceed on the basis that had such a report been obtained the
Respondent would have exhibited it. We, therefore, proceed on the basis that no such report was sought or
obtained. If we are wrong about that the Respondent should draw this to our attention.

**[114] The further reason given for the 'no prosecution' decision in the human trafficking offence was that there was**
insufficient evidence of exploitation. The Applicants had made quite specific complaints about features of their
working conditions which they claimed were exploitative. These included the claims about wages being withheld,
hours being excessively long and living conditions being inadequate. The October decision found no evidence that
wages had been withheld. The Applicants then supplied evidence in the form of an order from Newry Magistrates'


-----

Court (which we have referred to above) which stated that wages had been withheld and that retained funds would
be distributed to the affected workers, including two of the Applicants. The February decision still does not refer to
that evidence, either in relation to the question of whether exploitation occurred or was intended for the purposes of
the human trafficking offence, nor in relation to the alleged Minimum Wage offence. It appears therefore that
relevant evidence may have been left out of account when assessing the exploitation issue.

**_Summary of Principal conclusions_**

**[115] The decision maker proceeded on a fundamental misunderstanding or misinterpretation of material facts by**
considering that the 'concession' arrangement “operated like an amnesty.” One inference is that Anderson chose
not to avail of the concession because those arrangements came with 'strict conditions.' Permission would only be
granted under the concessionary arrangements after appropriate assurances were given that the worker would be
(i) paid the minimum wage and (ii) that the worker would be given 'suitable onshore accommodation when their
ships were in port.' One possible, even obvious, inference, is that Anderson did not avail of this concession in order
to avoid having to comply with those conditions. Compliance with those two conditions were the strict rules that
governed access to the concession. The decision maker never perceived or addressed the obvious inferences
which flowed from Anderson's behaviour or, if he did, they are not mentioned in his decision [see [90]-[92], [96]
[104]].

**[116] The decision-maker did not have regard to his own findings of fact in respect of the offences for which it is**
accepted the evidential test was satisfied. These findings were relevant when considering, _inter alia, the issue of_
intent to exploit for the purposes of the human trafficking offences. This is a clear failure to have regard to relevant
factors [see paras [90]-[95]]. It is clear that:

- The OK to Board letter was made by John Anderson.

- The letter was false.

- Anderson knew it was false.

- These letters were submitted to the British Embassy in Ghana to obtain visas on a fraudulent basis so that visas
would be issued to the Applicants to enable them to enter the UK.

- The fraudulent OK to board letters were required to facilitate the Applicants to come to the UK to work for John
Anderson.

- The false statements were made with the intention to make a gain.

**[117] Further, the following matters are not in dispute:**

- The 'transit' visas expired in May 2011.

- These visas did not entitle the Applicants to work in UK waters, only in international waters.

- Requiring the Applicants to work in UK territorial waters placed them in in contravention of their visa status doing
work that they were not entitled to do.

- They were therefore placed in double jeopardy – (i) risk of deportation for breach of immigration laws and (ii) risk
of failing to complete their contracts thus placing not only the Applicants but also their guarantors at the risk of
enforcement of the debt bond.

- When the transit visas expired no steps were taken by the Andersons to 'regularise' the Applicants' immigration
status.

- The Applicants were warned by the Andersons to stay on the boat because of the risk of arrest should they set
foot on Northern Irish soil.


-----

- The Applicants were aware of the risks of arrest, deportation and enforcement of debt bond.

- The fact of their complaints summarised at para [15] detailing the Applicants' accounts of their working conditions
– (i) withholding wages (ii) working excessive hours and (iii) living in substandard conditions with poor hygiene
facilities and poor-quality food.

- The Home Office 'reasonable grounds decision' that the Applicants were victims of human trafficking.

**[118] The evidence in relation to John Anderson's role in the 'OK to Board' letters, his procurement of the**
insufficient visas, and his intentions when taking these actions, is relevant to the question of the same suspect's
general intentions towards these men. There are obvious inferences that could properly be drawn from the facts the
decision maker considered about what John Anderson did and why, which inferences are relevant in relation to the
_mens rea for the human trafficking offences. The OK to Board letter submitted to the British Embassy was entirely_
fraudulent and was submitted with the intention of John Anderson making a gain. There is no evidence that the
prosecutor forensically evaluated why Anderson chose to make the men illegal and to place them in legal and other
jeopardy. Why did he want them to be illegal and be at risk of the menace of arrest, charging, deportation and
enforcement of the debt bond when he could, using the same visa under the 'concession', have brought them to the
UK legally by complying with the strict conditions of the concession? He chose the illegal route thereby avoiding the
requirements to pay the minimum wage, provide suitable onshore accommodation and deliberately exposing them
to the aforesaid menaces. There is no evidence that the decision maker identified, evaluated or gave consideration
to these plainly relevant matters and the potential inferences that might in consequence ensue.

**_Forced labour offence_**

**[119] The prosecutor dealt shortly with the potential forced labour offence and so shall we. His conclusion on it was**
as follows:

“This will require the application of the same principles as discussed above and for the same reasons as above
I do not consider that there is a reasonable prospect of a conviction for this case.”

**[120] Given our conclusions on the human trafficking offences and the acknowledgment by the decision maker that**
they applied the same principles and the same reasons to this offence, we consider that the application of the
flawed analysis to this offence requires the prosecutor to consider this offence afresh. If upon reconsideration by the
PPS it is concluded that the evidential test for prosecution is met in respect of the human trafficking offences and
specifically a reasonable prospect of proving the requisite intent, this is likely to be a material consideration in
respect of the forced labour offence. We also consider that an engineered precarious immigration status in
combination with the other resulting menaces of arrest, deportation, criminal charges and risk of enforcement of the
debt bond against the Applicants or their guarantors are plainly relevant considerations. It is clear from Siliadin (see
para [75] above) that a precarious immigration status is an indicator of trafficking and is equivalent to a form of
coercion by circumstance. We appreciate that the facts of that case, involving a minor, are quite different from the
present case. It will be for the decision maker on reconsideration to consider the extent of any deception
perpetrated upon the Applicants to lure them to the UK; to consider their predicament resulting from their arguably
engineered precarious and unlawful immigration status; their arguably engineered fear of arrest, detention,
charging, deportation and the fear that the huge debt bond might be executed against them and their family
guarantors none of whom are likely to be in a position to discharge such an enormous sum. It will be a matter to
investigate whether these fears and risks were engineered, nurtured and reinforced by the factual situation they
were placed in by the choices the Anderson's made and sustained by their failure to regularise the mens
immigration status after the initial visa expired. The decision maker will want to consider the decision of the ECtHR
in Chowdury & Ors v Greece (Application no. 21884/15) which considers the issue of “forced labour” at para 90 et
_seq and, in particular, the following:_

“95. The Court also observes that the applicants did not have a residence permit or work permit. The applicants
were aware that their irregular situation put them at risk of being arrested and detained with a view to their
removal from Greece. An attempt to leave their work would no doubt have made this more likely and would


-----

have meant the loss of any hope of receiving the wages due to them, even in part. Furthermore, the applicants.
Could neither live elsewhere in Greece nor leave the country.

96. The Court further considers that where an employer abuses his power or takes advantage of the
vulnerability of his workers in order to exploit them, they do not offer themselves voluntarily. The prior consent
of the victim is not sufficient to exclude the characterisation of the work as forced labour. The question whether
an individual offers himself for work voluntarily is a factual question which must be examined in the light of all
the relevant circumstances of the case.

97. In the present case the Court notes that the applicants began working at a time when they were in a
situation of vulnerability as irregular immigrants without resources and at risk of being arrested, detained and
deported. The applicants probably realised that if they stopped working they would never receive their overdue
wages …. Even assuming that, at the time of their recruitment, the applicants had offered themselves for work
voluntarily and believed in good faith that they would receive their wages, the situation changed as a result of
their employers' conduct.”

**[121] We would add that we consider that there is considerable weight in the Applicants' submission that the**
conclusion on the forced labour offence reflects an incomplete consideration of the offence. We note that there is no
detailed consideration of the mens rea for the s 71 forced labour offence in the decision letter. This offence has a
different mens rea from that set out in the human trafficking offence because it includes criminal liability where an
employer “knows or ought to know” that a person is being held in servitude or required to complete forced labour.
The Respondent's case has been that any deceptions practised on the Applicants were practised by Sea Crew.
However, in a case such as the present, a searching analysis is required of whether an employer must be taken to
know, should be required to know, or at least “ought to know” of the deceitful practices engaged in by his agent for
the reasons we have adverted to at para [111] above. This aspect of the _mens rea_ for this offence should be
specifically considered by the Respondent.

**[122] Accordingly, we direct that a fresh decision be taken in respect of this offence also in order to address the**
issues identified by this court.

**_The minimum wage offence_**

**[123] The prosecutor's decision not to prosecute for this offence is explained by him as follows:**

[“Offences under the national minimum wage act 1998 are investigated by HMRC. No file was received by the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6120-TWPY-Y078-00000-00&context=1519360)
PPS from HMRC in respect of John or Mark Anderson and your clients and I understand that the HMRC
decided to take no further action. I am unaware of the reasons for their decision … In any event the decision
not to prosecute for this offence was not a decision of the PPS and, therefore, no right of review exists under
the PPS Code for Prosecutors nor under our continuing duty to review prosecution decisions as no such
decision was made. Any complaint that a prosecution for this offence was not forthcoming should be directed to
HMRC.

**[124] We consider that this an inadequate response to a potential offence which is woven unavoidably into the**
factual matrix of this case, and the proper investigation of which is inherently necessary to the discharge of the
prosecutor's task. Whether or not these men were paid any, or sufficient, wages for the work they did may be a vital
question within the overall factual matrix. The prosecutor must properly address this question because some such
working answer must exist in order for him to measure the suspects' behaviour against the required elements of
some of the other offences he is reviewing.

**[125] Also, it appears to us to be wrong in principle for the agency principally tasked with the prosecution of serious**
crime in this jurisdiction to fail to consider an alleged offence which is clearly part and parcel of the factual matrix
around a course of conduct which may involve crimes of a particularly concerning type; and which was squarely
raised by the materials placed before it by the PSNI. Whether or not another agency might also have had an
investigative role in relation to this type of offence is immaterial to the core question “is the PPS already seized of
this responsibility because the minimum wage issue is so integral to the whole factual matrix?” The PPS


-----

[undoubtedly has power to institute proceedings for this offence under s 31(2) of the Justice (Northern Ireland) Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-F0X0-TWPY-Y0M5-00000-00&context=1519360)
2002. For this reason, we set aside the prosecutor's decision in relation to the minimum wage offence and ask that
this decision be reconsidered by a fresh prosecutor.

**_Conclusion_**

**[126] We quash the decisions not to prosecute for (i) human trafficking, contrary to s 4 of the Asylum and**
[Immigration (Treatment of Claimants) Act 2004; (ii) forced or compulsory labour, contrary to s 71 of the Coroners](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95F0-Y97X-74X7-00000-00&context=1519360)
[and Justice Act 2009 and (iii) failure to pay the minimum wage, contrary to s 31 of the National Minimum Wage Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y1CK-00000-00&context=1519360)
1998. We further direct that the decision whether to prosecute or not in respect of those three offences be taken by
a fresh prosecutor.

Application allowed.

**End of Document**


-----

