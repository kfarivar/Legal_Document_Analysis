# NN v Secretary of State for the Home Department; LP v Secretary of State for
 the Home Department

_[[2019] EWHC 766 (Admin), [2019] All ER (D) 172 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VJB-V2K2-8T41-D0RB-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 28/03/2019**

# Catchwords & Digest

**IMMIGRATION - TRAFFICKING – SUPPORT**

Immigration – Trafficking. The claimants would be granted interim relief which had the effect of maintaining their
current level of support as victims of modern slavery/people trafficking until further order. The Administrative Court
held that, when set against the potential harm to the claimants, both of whom had been accepted by the defendant
Secretary of State as having been trafficked and very badly mistreated, the balance of prejudice came down in
favour of the grant of relief.

**End of Document**


-----

