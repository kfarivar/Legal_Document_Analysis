# R v Koroma [2022] EWCA Crim 1414

Court of Appeal, Criminal Division

Popplewell LJ, May J, HHJ Shant KC

11 October 2022Judgment

MR N JAMES appeared on behalf of the Appellant.

MR J POLNAY appeared on behalf of the Respondent.

________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

LORD JUSTICE POPPLEWELL:

1 An order was made in the Magistrates' Court on 7 January 2022 pursuant to s.45 of the Youth Justice
and Criminal Evidence Act 1999 restricting publicity in respect of the youth involved in this case, to whom
we shall refer as "JT", until he reaches the age of 18.

2 His Majesty's Attorney General applies pursuant to s.36 of the Criminal Justice Act 1988 for leave to
refer as unduly lenient a total sentence of 46 months' imprisonment imposed on the offender, Alieu
Koroma, by Mr Recorder Mayall sitting in the Crown Court at Wood Green on 1 July 2022.

3 The sentence was made up as follows:

     - Count 2 charging being knowingly concerned in the supply of a class A drug (heroin) contrary to s.4(3)(b)
of the Misuse of Drugs Act 1971 – 40 months' imprisonment.

    - Count 3 charging being knowingly concerned in the supply a class A drug (crack cocaine) – 40 months'
imprisonment to run concurrently.

     - Count 4 having an article with a blade or point contrary to s.139(1) of the Criminal Justice Act 1988 – six
months' imprisonment to run consecutively.

     - Count 5 possession of cocaine contrary to s.5(2) of the Misuse of Drugs Act 1972 – no separate penalty.

4 In addition, a Criminal Behaviour Order lasting five years was imposed.

5 The offender had pleaded guilty to Count 5 at the PTPH and pleaded guilty to Counts 2, 3 and 4 on the
day of the trial. On that last occasion, the prosecution elected not to proceed with Count 1 on the
indictment, which charged arranging or facilitating the travel of JT with a view to exploitation contrary to
s.2(1) of the Modern Slavery Act 2015, which was ordered to lie on the file.


-----

6 The offender ran a county lines drugs line from London to supply heroin and crack cocaine to users in

Clacton‑on‑Sea in Essex over a period of nearly three months, using a vulnerable youth, JT, to supply the

drugs from the cuckooed address of a local drug dealer.

7 The facts in a little more detail are these. The prosecution evidence identified that the offender was a
leading figurehead within a gang operating in the Peckham area known as the "Zone 2 Gang". Between
13 October 2021 and 6 January 2022 he ran the drugs line known as the "Riko" drugs line. He was based

in London. Drug users in Clacton‑on‑Sea would telephone the line held by the offender to order crack

cocaine and heroin. They would be directed to a location where they would be met by a runner who would
supply the drugs. The local operation involved two local adult dealers, one of whom was called Natalie
Berrett. The runner in this operation was JT, then aged 14, turning 15 towards the end of the indictment
period. JT was a vulnerable child. He had been placed with foster carers in London but had gone missing.
He was living in Clacton in the cuckooed address of Ms Berrett in deplorable conditions. The premises
were filthy with rubbish strewn across the floor. There was sick and dog faeces in the kitchen and dirty
plates and cutlery were strewn all over.

8 It was assessed that over the indictment period there were on average 789 customers per day on the
Riko line to whom a total of at least 710 grams of heroin and cocaine were supplied over the indictment
period.

9 When the offender was arrested on 5 January 2022 in London he was found in possession of the drugs
line phone and another private phone, into which he had copied the contact details of customers so that
they would be available to him if he stopped operating the Riko line. He also had on him a lock knife
tucked away in his waistband, which was the subject matter of Count 4, and a small quantity of cocaine,
which was the subject matter of Count 5.

10 He was aged 22 at the date of sentencing and had six convictions for 14 offences. The following are of
particular relevance. In 2016, when he was aged 16, he was convicted of possession of cannabis and
possession of a knife in a public place, for which he was given a referral order for four months. In March
2017, when he was aged 17, he was convicted of possession of an offensive weapon and sentenced to a
four-month detention and training order. In December 2017 he was convicted of six offences of robbery,
one offence of attempted robbery and one offence of having an offensive weapon in a public place, all
committed in 2016 when he was aged 17. He was sentenced to a total of three years and three months'
detention in a Young Offenders' Institution. He was also made the subject of a three-year Criminal
Behaviour Order prohibiting him from associating with members of the Zone 2 Gang. The robberies and
attempted robberies were carried out with two other gang members with the offender in possession of a
knife. In 2019, when he was aged 19, he was convicted of possession of a knife in a public place and
sentenced to 32 weeks' detention in a Young Offenders' Institution. This was a hunting knife with a seveninch blade, which he had on him when chasing two youths in East Croydon train station.

11 The offender is a prominent drill artist. Amongst other things, he appeared in, and promulgated, videos
glorifying drug dealing including county lines drug dealing, and glorifying violence.

12 Prior to trial, there were discussions between counsel as to pleas. The prosecution's position was that
a plea to the drugs offences would not be acceptable unless the offender accepted that he himself had
involved JT in the county lines operation. On the day of the trial the offender accepted that that was so,
and entered his pleas on that basis. Accordingly, the prosecution agreed not to proceed with Count 1, the
**_modern slavery offence. There was no basis of plea and, therefore, the pleas were entered on a full facts_**
basis.

13 At the sentencing hearing the defence submitted and the prosecution accepted that the drugs offences
fell within Category 3 significant role of the Sentencing Council Guideline, which has a starting point of four
and a half years and a range of three and a half to seven years. The defence also submitted, and counsel
then acting for the crown agreed, that the relevant aggravating feature was the involvement of JT. It was
also agreed that the knife offence fell within Category 2A of the relevant guideline, which has a starting
point of six months and a range of three months to one year. Under s.315(3) of the Sentencing Act 2020


-----

the Recorder was obliged to impose a minimum sentence of six months with a maximum discount for plea
of 20 per cent for the knife offence as a second relevant offence.

14 At the hearing the offender's counsel, Mr James, who has also represented him in this court, submitted
that his instructions were that the offender was remorseful and wanted nothing more to do with his previous
pattern of association. In written submissions the defence had opposed the imposition of a Criminal
Behaviour Order which was sought by the prosecution and which had as one of its conditions that he had
no further contact with a number of individuals, two of whom were named on the basis that they were
fellow gang members. At the sentencing hearing, opposition was withdrawn to the imposition of the
Criminal Behaviour Order and Mr James submitted that the offender's willingness to subject himself to it
was further evidence of his remorse.

15 Three character references were made available, which testified to his talent as a footballer and, in
particular, to his ability and success as a rap artist. A Mr McQuaid, the head of A&R at Moves Recording
(the offender's record label), said that the offender was "an extremely focused young man with a strong
work ethic". He explained that the offender's first release had reached number 8 on YouTube's viral chart
and Mr McQuaid considered that the offender had a great deal of unrealised potential. He remained
signed to the label and Mr McQuaid indicated that upon his release from prison the offender would be
provided with accommodation away from South London so that he could pursue his promising career in the
music industry, as he put it, "away from negative forces". We take that to be a reference to the gang
context in which his offending had occurred.

16 In sentencing the Recorder adopted the following approach. For the drug supply offences, he identified

four and a half years as the category starting point. It was, he said, aggravated by the use of a 14‑year‑old

child living in squalor. The Recorder identified as mitigating factors that there were no relevant convictions,
by which he meant no convictions for drug dealing; that the offender had shown remorse; that it was very
much to his credit that he had voluntarily agreed to be subject to the Criminal Behaviour Order, which the
Recorder said was no doubt an attempt when he was released from prison to ensure that he did "not fall
into this trap again"; and that he was still a young man who clearly lacked maturity at the time. The
Recorder said that the aggravating factor and the mitigating factors cancelled themselves out. He then
applied a reduction of 20 per cent to the four-and-a-half-year figure to reflect the effect of Covid in two
ways. One was the effect on prison conditions referred to by this court in R v Manning [2020] 2 Crim App
R (S) 46. The second was that it had impeded communications between the offender and Mr James prior
to the pleas being indicated, so that a greater discount than 10 per cent for the pleas entered on the day of
trial was warranted.

17 Although the Recorder did not spell this out, what had happened was that on instructions Mr James
had indicated to the crown that pleas would be entered to the drugs offences in May, a month or so before
the trial, but the crown's insistence that there be an express acceptance that the offender had involved JT
had not been able to be communicated to him, because of the difficulties in arranging video conferences

and a lack of face‑to‑face access between Mr James and the offender. The result was that it was only on

the morning of the trial that those discussions could take place and on that occasion the offender accepted
the position in relation to JT and the pleas were entered. The 20 per cent reduction from the four and a
half year starting point produced a rounded figure of 43 months.

18 In relation to the knife offence, the Recorder referred to the aggravation of it being a fifth offence of that
kind and identified the appropriate sentence as a consecutive one of six months, presumably having also
given a discount of 20 per cent for the plea and Covid conditions. The Recorder then adjusted the
sentences by reducing the sentences for the drugs offences by three months, taking them down from 43
months to 40 months to reflect totality. With the consecutive sentence of six months for the knife offence,
that gave rise to a total sentence of 46 months.

19 On behalf of the Attorney General, Mr Polnay's over‑arching submission was that the sentence for the

drugs offending was simply much too short. Within that over‑arching submission, he made a number of

submissions as to why the sentence was unduly lenient He submitted that the judge ought to have


-----

elevated the starting point to the top of the Category 3 significant role range to reflect the fact that the
offender was involved in the supply direct to users of a quantity which was over four times that of the
indicative Category 3 weight; and that such an upward adjustment was also warranted by there being
features of a leading role in the offender's behaviour, albeit that he accepted that, overall, the
categorisation was correctly put as one of a significant role. He argued that a further significant uplift was
required for the significant aggravating factors, which should have taken the sentence beyond the top of
the Category 3 range. They included that this was a county lines operation; the cuckooing; and in
particular the fact that a vulnerable child was used in the supply of the drugs. He went on to argue that the
judge fell into error in reducing the sentence to the extent that he did on account of the mitigating factors,
which he characterised as of very limited weight. He submitted that the previous convictions, in the sense
of the absence of any convictions for drugs offences, did not form any real mitigation; that there was no
particular evidence of immaturity and, indeed, immaturity was contraindicated by the relatively
sophisticated offending that took place over a period of time and by the drill videos. He submitted that
there was no substantial evidence of any real remorse.

20 He went on to submit that the sentence for having a bladed article did not sufficiently reflect the fact
that this was the offender's fifth separate conviction for this type of offence, although he frankly accepted
that had that been the only complaint it would not have been one which made the overall sentence unduly
lenient.

21 On behalf of the offender, Mr James submitted that the sentence was well within the range properly
open to the Recorder, who was best placed to balance the aggravating and mitigating features; and was
not a sentence which was unduly lenient. He argued that Category 3 applies to all street dealing,
regardless of amount, and that it would be wrong to make any upward adjustment from the starting point to
take account of the quantity involved. He accepted that the involvement of a child was a statutory
aggravating factor and the Recorder had taken this into account. This was not, however, a case, in which
the offender could be said to have exploited a child. That was the subject matter of Count 1 of the
indictment which was not proceeded with. There was no evidence that the offender knew anything about
JT, other than that he was under18. There was no evidence that he knew anything about his particular
vulnerability or about the particular conditions in which he was living in Clacton. He went on to submit that
the Recorder's finding of immaturity on the part of the offender was based in part on submissions about his
upbringing and, in any event, his young age at the time of the offending was itself a mitigating feature
irrespective of his immaturity. The six-month consecutive sentence for the knife offence was in his
submission entirely appropriate and not unduly short.

22 In his oral submissions, Mr James also made an over‑arching submission, which was that it had been

agreed between crown counsel and himself at the sentencing hearing that the offending fell within
Category 3A, involving a significant role only and that the only aggravating feature was the involvement of
JT. He submitted that it would be unfair for the Attorney General on this reference to be permitted to argue
that there were the additional aggravating features or that the involvement of JT involved exploitation of
someone who was vulnerable.

23 In our view, this last over‑arching submission is misconceived. There were, as we have described,

discussions as to the express acceptance of the offender having involved JT as part of the basis on which
the pleas were entered. However, subject to that, the pleas were entered on a full facts basis without any
qualified basis of plea. That meant that the Recorder was bound to sentence in accordance with those
facts on the view which he properly took about their seriousness or lack of seriousness and about the
extent to which they aggravated or mitigated the relevant offences. He was not bound by any subsequent
agreement, that is to say an agreement subsequent to the entering of the pleas between crown counsel
and defence counsel, as to what the mitigating features were, what the aggravating features were or how
they were to be applied to the starting point in the category. Contrary to Mr James' submission, it would
not have been open to him to have sought a Newton Hearing had the arguments which have been put
before us as to the aggravating features been put before the Recorder at the time of sentencing. They


-----

were all matters which arose from the prosecution case as it had been put before the court by which the
offender was bound by his unqualified plea.

24 We start with the knife offence. This was the fifth such offence, which is a seriously aggravating
feature over and above the minimum required of six months which arises for a second offence. A
significantly longer sentence than six months was called for had this been a standalone offence, even after
an appropriate discount for plea and the effect on prison conditions of the pandemic. Had a further
reduction been made to the sentence for this offence, on top of the reduction for plea and the effect of
Covid, to take account of the totality of all the offending being sentenced, we do not think however, that a
sentence of six months could be said to be unduly lenient.

25 As to the drugs offences, a very significant uplift from the starting point was required for a number of
reasons. First, although the offender's role was agreed to be such as to fall within the guideline category of
significant, it had some aspects of a leading role. He was directing others in large scale street dealing,
which was on a commercial scale and he had substantial links to, and influence on, others lower down in
the chain. Although this did not form any part of the argument put before the Recorder, in our view it is
important and it is a role which puts him above the starting point in the range. Second, the duration and
scale of the dealing also put his offending in the upper part of the range. It was high volume, lasting almost
three months and involved at least 710 grams, which is much nearer the indicative quantity for the starting
point in Category 2 than Category 3 for offences which are not street dealing. Contrary to Mr James'
submission, this is a ground for moving up the range. The guideline provides, amongst other things:

" ... The court should consider all offences involving supplying directly to users as at least category 3 harm,
and make an adjustment from the starting point within that category considering the quantity of drugs in the
particular case."

26 Third, the use of JT was, as is recognised, a serious aggravating feature. We accept that there was no
evidence that the offender knew of his particular vulnerability as a child in need or of the particular
conditions in which he was operating. However, he knew that he was a child. He involved him in a county
lines operation and he exposed him within that operation to other drug dealers. That was in a very real
sense of the word exploiting him and the prosecution decision not to proceed with the Modern Slavery Act
offence does not in any way undermine that characterisation. Moreover, the fact that he was a young
child, that he was a particularly vulnerable child in need and that he was operating in squalor was all part of
the harm which was caused by the offending, which aggravates the offence, irrespective of the offender's
assumed ignorance of it.

27 Fourth, it is clear that the offending was in an organised gang context. That emerges from the previous
CBO, which had as a condition that the offender was to have no contact with Zone 2 gang members, and
the terms of the CBO to which he voluntarily subjected himself on this occasion.

28 Fifth, his previous convictions did not provide any mitigation, involving as they did numerous robberies
and the possession of knives. On the contrary, they were an aggravating rather than a mitigating feature.
Although they were not for drugs offences as such, they were for offences of violence and for carrying
knives in a gang context. The guideline provides in the drop down menu under the heading "No Relevant
Convictions" in the section on mitigating features the following:

"Previous convictions are likely to be 'relevant' when they share characteristics with the current offence
(examples of such characteristics include, but are not limited to: dishonesty, violence, abuse of position or
trust, use or possession of weapons, disobedience of court orders)."

29 We agree with Mr Polnay that against these aggravating features, there was little weight in the
mitigation relied on. Mr Polnay is correct to submit that running this county lines operation did not suggest
any lack of maturity nor did anything in what the Recorder was told about the offender's background. His
young age did provide some mitigation, but he was nevertheless rising 22 when he started committing
these offences and 22 by their conclusion. His last minute acceptance that a CBO should be imposed,
having opposed it until the day of sentence, is a slender basis for accepting any genuine remorse or
determination to change his way of life. The effect of Covid conditions in prison can only justify a modest


-----

reduction in light of the length of the sentence and the fact that conditions have been gradually easing
since January of this year when the offender was remanded.

30 In those circumstances, a sentence of 40 months for the drugs offences was not merely lenient but
unduly so. It was well below the bottom of the range which was reasonably available to the Recorder. We
do not accept Mr Polnay's submission that the factors which we have identified required a sentence
beyond the top of the range for Category 3 significant role, but a sentence of not less than six years after a
trial was required. Allowing a 20 per cent reduction to take account of his guilty pleas and conditions in
prison during Covid would reduce the sentences for the drugs offences to 57 months. No further reduction
for totality is called for, because a six-month consecutive sentence for the knife offence already makes
sufficient allowance for totality.

31 Accordingly, we will grant leave and increase the sentences on Counts 2 and 3 to 57 months to run
concurrently with each other, with the sentence on Count 4 to remain one of six months which runs
consecutively. The effect is to increase the total sentence from 46 months to 63 months, that is to say five
years and three months.

__________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge_**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge

**End of Document**


-----

