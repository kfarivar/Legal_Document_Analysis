# R v Rafiq (Mohammed) and Another (2016) [2016] EWCA Crim 1368

CA, CRIMINAL DIVISION

1601161 A1, 1601309 A1

Treacy LJ, Lang J and Dove J

26/04/2016

**[Neutral Citation Number: [2016] EWCA Crim 1368](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KPY-7221-F0JY-C3NV-00000-00&context=1519360)**

No: 201601161 A1 201601309 A1

**IN THE COURT OF APPEAL**

**CRIMINAL DIVISION**

Royal Courts of Justice

Strand

London, WC2A 2LL

Tuesday, 26th April 2016

**B e f o r e:**

**LORD JUSTICE TREACY**

**MRS JUSTICE LANG DBE**

**MR JUSTICE DOVE**

**REFERENCE BY THE ATTORNEY GENERAL UNDER**

**_[S.36 OF THE CRIMINAL JUSTICE ACT 1988](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YF0-TWPY-Y0X0-00000-00&context=1519360)_**

**ATTORNEY‑GENERAL'S REFERENCE NO 35 OF 2016**

&

**R v MOHAMMED RAFIQ**

Computer‑Aided Transcript of the Stenograph notes of

WordWave International Ltd trading as DTI

8th Floor, 165 Fleet Street, London EC4A 2DY


-----

Tel No: 020 7404 1400 Fax No: 020 7831 8838

(Official Shorthand Writers to the Court)

**Mr C Tehrani & Mr S Grattage appeared on behalf of the Attorney General/Crown**

**Mr R H Christie QC & Mr N Karbhari appeared on behalf of the Offender/Applicant**

J U D G M E N T

(Approved)

Crown copyright©

1. LORD JUSTICE TREACY: This is an Attorney General's reference under section 36 of the Criminal Justice Act

1988 relating to a sentence which is said to be unduly lenient. There is a cross‑application for permission to appeal

made by the offender on the basis that the sentence imposed was too long. That application has been referred to
this court by the Registrar. We have heard both matters together.

2. This offender was convicted after a long trial at Leeds Crown Court of conspiring with Janos Orsos, Ferenc Illes
[and others to arrange or facilitate travel within the UK for exploitation contrary to section 1(1) of the Criminal Law](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BG90-TWPY-Y135-00000-00&context=1519360)
_[Act 1977. The particulars of that offence were that the offender, between 1st January 2011 and 1st December](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BG90-TWPY-Y135-00000-00&context=1519360)_
2013, conspired with those others to arrange or facilitate travel within the UK by individuals in respect of whom he
knew that an offence contrary to section 4(1) of the Asylum and Immigration (Treatment of Claimants etc) Act 2004
had been committed with intent to exploit those individuals in the UK or else where. Had this offender faced a
substantive offence, it would have been contrary to section 4(2) of the 2004 Act.

[3. Those provisions have now been replaced by the Modern Slavery Act 2015 going forward, but they remain on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
the statute book for the purpose of dealing with cases which arise prior to the coming into force of the 2015 Act.

4. After conviction, the offender was sentenced to 27 months' imprisonment on 12th February 2016.

5. The named conspirators, Orsos and Illes, had pleaded guilty in separate proceedings in May 2014 to a similar
offence, with Orsos pleading guilty to other substantive counts of money laundering and blackmail deriving from the
conspiracy. Orsos was the principal organiser of this offending. Illes was his lieutenant, involved over a 12 month
period. Orsos was sentenced to five years' imprisonment based on a starting point of seven years. Illes was
sentenced to three years' imprisonment based on a starting point of five years. The case against those offenders
involved six other victims of trafficking, in addition to four of the five victims featuring in the present case. Orsos
had placed those victims in a total of four different businesses.

6. In this offender's case the court additionally made a Slavery and Trafficking Prevention Order and a Company
Director's Disqualification.

7. This offender was the majority shareholder and managing director of a company trading as Kozee Sleep, a
manufacturer of bed frames and mattresses based in West Yorkshire. Orsos had approached him, offering to
supply cheap labour. The company would pay Orsos £3 per hour for each Hungarian worker supplied.

8. This case relates to five Hungarian victims, although evidence was adduced by way of background in relation to
three other individuals. All of those men were under the direction of Orsos. The five victims were Hungarian
nationals who had been deceived and enticed by false representations made by Orsos, leading them to travel to
this country after false representations regarding pay and conditions of work had been made to them. This offender
had no part in the making of those representations. The Hungarians were unaware that the UK minimum wage at
the relevant time was about £6 per hour. The evidence showed that, at the very least, the Hungarian workers were
not paid that minimum wage. Some of them said that if they had been paid as little as £3 per hour, they would have


-----

considered that to be a good wage. As events transpired, they did not even receive that meagre figure. The
workers were made to work long hours, ranging between ten and 18 hours per day and five to seven days a week.

9. The evidence showed that at the relevant time many Hungarian nationals were desperate for work in this country
because of the dire economic situation in Hungary. Once in the UK, the Hungarian workers faced a very different
reality from that promised by Orsos. They found themselves living in very overcrowded, often squalid,
accommodation. They did not receive the wages that had been promised to them, which were a little less than £3
per hour. The wages they had earned were not given to them, but were collected and retained by Orsos and/or
Illes, who in turn would hand on minimal amounts to the workers. For most of the time they worked, the Hungarians
would receive about £10 per week, with each household in which they lived being given an additional £20 to £30
per day per household for food.

10. There was evidence that over a two year period, Orsos had transferred almost £60,000 overseas. The Crown's
case was that this was just a percentage of the monies he obtained.

11. Matters came to an end in around November 2013 with the arrests of Orsos and Illes. At that point the police
began to investigate the businesses that had employed the trafficked Hungarian nationals.

12. It appears that by 2011 this offender's business was in serious financial trouble. Although it had good contracts

with well‑known reputable retailers, its profit margin was extremely low. This financial situation appears to have

been the motivation for this offender's involvement.

13. All payments to Orsos, both in respect of his commission and the wages of the workers, were paid in cash with
no invoices issued. These transactions were wholly off the books of Kozee Sleep so that, in addition, no tax or
national insurance was paid. There had been from time to time ethical audits conducted by the retail customers of
Kozee Sleep, but they failed to detect these abuses in the absence of paperwork. The initial approach had been
made to this offender by Orsos and this offender had accepted the arrangement proposed. He contacted Orsos
when he required extra staff.

14. There was evidence from more than one victim that when complaint was made about not receiving wages,
those complaints were brushed aside.

15. At the end of the prosecution's case the judge ruled that this offender did not have a case to answer. However,
following an appeal by the Crown, that ruling was reversed and the trial resumed. This offender did not give
evidence and the jury convicted him.

16. There was before the court at the time of sentencing a very large number of character references, of which we
have seen a selection. It is clear that this offender had previously been of exemplary character; the sentencing
judge referred to him as a pillar of the community. He had worked very hard over many years to build up his
business. As a result of the court proceedings, he had suffered from depression. In addition, the judge had a

pre‑sentence report and there were personal statements from three of the victims, all of whom asserted that they

had been harmed by their experiences. We have seen a recent custody report showing that the offender has
adapted well to custody.

17. On behalf of the Attorney General, Mr Tehrani QC has submitted that the sentence passed was unduly lenient.
It is said that the judge was unduly influenced by the offender's personal mitigation, that he failed to pass a
deterrent sentence, and that there was too great a disparity between the sentences passed upon Orsos and Illes
and this offender. Overall, the submission is that the sentence of 27 months' imprisonment failed to reflect the
gravity of the offence by some margin. Particular emphasis has been laid on the nature of the offending, with its
willingness to employ trafficked labour, a motivation of greed and commercial gain, the long working hours and poor
pay, the harm suffered by the victims and the concealment of the victims from the company payroll.

18. For the offender, it is submitted, firstly, that the sentence imposed was not unduly lenient if the sentencing
judge was entitled to pass sentence on the basis identified by him in his sentencing remarks. The offender's


-----

cross‑application relating to sentence is based on the assertion that the judge adopted an improper factual basis

before passing sentence when those remarks are compared with observations he made at the time of holding that
there was no case for the offender to answer.

19. This offender cannot claim the benefit of any mitigation for a guilty plea. However, he relies upon a number of
other matters. Firstly, his positive good character, which was recognised by the judge and which it is said should be
set against the offending taking place in more recent times. The offender is 60 years of age. There is evidence to
show that his health has suffered in the course of these proceedings. The business which he had built up
throughout his working life has now failed, it was a legitimate business, and the five victims represented only about
2 per cent of the workforce. It is properly said that he is not the primary offender in this trafficking, but an end user
of the process started by Orsos. He was not party to the initial deception and not responsible for the way in which
the victims had been housed. Although the victims had worked long hours and not received wages, the working
conditions at Kozee Sleep were otherwise satisfactory; indeed, two of the victims had indicated that they would
have been prepared to return to Kozee Sleep if properly paid. All of the victims were in the United Kingdom legally.

20. We have considered the guidance given in Attorney General's Reference Nos 37, 38 and 65 of 2010 [2011] 2
Cr App R (S) 31. Factors relevant to an assessment of the seriousness of an offence of this type are set out at
paragraph 17 of that judgment.

21. There are similar offences to this one which may be committed in breach of immigration control or which
involve sexual exploitation. We accept that ordinarily offences with those features may attract a higher sentence
than a section 4 offence. We also recognise that this offender was not the organiser or prime mover in the overall
offending, and in that respect this case differs from the Attorney General's Reference already cited. That, however,
does not absolve him from significant criminal responsibility. Had he not provided exploitative employment to the
likes of Orsos, Orsos would have been unable to operate a scheme such as this. Moreover, this offender willingly
colluded with Orsos and did so for his own financial benefit in alleviating pressure on his ailing business. By the
time the victims had been deceived and trafficked to this country, they were in a vulnerable position. All of those
matters are to be reflected in a consideration of sentence, as well as the fact that the victims had been adversely
affected.

22. In passing sentence, the judge paid full tribute to previous excellent work done in the community by this
offender, but found the following facts. The offender knew that the victims had been trafficked into this country. He
made all the major decisions in his business. He was party to an arrangement for payment of wages entirely
different to the rest of his workforce and, in addition, was paying well below minimum wage. He had some
awareness of the conditions in which the victims were housed and it was inconceivable that he was unaware that
the workers were not being paid by Orsos. As the person in charge of the business, he must have approved the
arrangements. When complaint had been made to him by one victim, he had been rebuffed. No tax or national
insurance had been paid. It was only after Orsos' arrest that this offender ceased to employ these workers. In
relation to the five victims, these matters had run for well over 12 months and the judge was satisfied that the
offender had reached agreement with Orsos well prior to that.

23. We have considered the rival contentions made on the question of undue leniency. This offender's
involvement was substantial and over a prolonged period. Although not a prime mover, he was a beneficiary of and
a significant participant in what occurred. Offending of this sort calls for deterrence, which in the case of this
offender was met by a sentence of imprisonment of some length. We are not impressed by assertions of disparity
as compared with the sentences passed on Orsos and Illes: they were prime movers in the creation and operation
of this scheme; they were involved with a greater number of victims and responsible for the living conditions in
which the victims were kept; they lacked the benefits of a positive good character upon which this offender could
rely. Accordingly, we reject submissions based on disparity.

24. The other major submission made on behalf of the Attorney General is that the judge gave undue weight to this
offender's personal mitigation. We do not consider that he did, and certainly not to the extent that would render this
an unduly lenient sentence. All cases of this sort are very much fact sensitive.


-----

25. We have come to the clear conclusion that the Attorney General's application must fail. Permission is refused
and the application is dismissed as the sentence imposed was not unduly lenient.

26. There was a suggestion in passing this morning that we might give general guidance for this type of case. No
submissions were made to assist us in that task. Cases of this sort, as we have said, are fact sensitive and we do
not feel able to give such guidance today on the basis of a single case. This mirrors the approach of this court in
paragraph 20 of the Attorney General's Reference referred to. Moreover, since the provisions of the 2015 Act have,
for all future purposes, replaced those of section 4 of the 2004 Act, there is an additional reason as to why we
should not now provide general guidance.

27. That leaves in place the cross‑application based on a comparison between the judge's sentencing remarks and

observations when holding that there was no case to answer. It is said that the judge's findings at sentence were
significantly firmer than his position at the close of the Crown's case. We have considered those submissions, but
conclude that the judge was not bound by his earlier comments and that he was fully entitled to reflect further in the

light of the cases advanced to the jury, the issues identified in summing‑up and the jury's verdict. We do not

consider that any arguable point arises. Accordingly, this offender's cross‑application is refused.

28. The overall result, therefore, is that both applications are dismissed and that the sentence of 27 months'
imprisonment imposed below remains in place.

**End of Document**


-----

