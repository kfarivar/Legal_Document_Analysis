# R v NHF [2022] EWCA Crim 859

Court of Appeal, Criminal Division

Fulford LJ, McGowan J, and Foxton J

26 May 2022Judgment

**Mr A Morris appeared on behalf of the Applicant**

**Miss T McCarthy appeared on behalf of the Crown**

**____________________**

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**J U D G M E N T**

Thursday 26th May 2022

**LORD JUSTICE FULFORD:**

1. On 26th March 2021, following a trial in the Crown Court at Lewes before Mr Recorder Swirsky and a jury, the
applicant (then [an age], now [an age]) was convicted of two counts of being concerned in the supply of Class A
drugs, contrary to section 4(3)(b) of the Misuse of Drugs Act 1971.

2. On 19th May 2021 the Recorder sentenced the applicant (then [an age]) on each count concurrently to a 12
month Youth Rehabilitation Order, with requirements to undertake 100 hours of unpaid work and six weeks'
attendance at an Offender Behaviour Programme. His co-accused, Bilal Charles and Christopher Wilson (both [an
age] at the time of the offending), were acquitted on both counts.

3. The applicant's application for an extension of time (219 days) in which to apply for leave to appeal against
conviction has been referred to the full court by the single judge.

4. On 6th February 2020 plain clothes police officers observed Charles, Wilson and the applicant (the latter was
then [an age]), in the [a street] area of Brighton. They were seen approaching known drug users and it was
established that they were operating out of a room at the [a hotel] in [a park]. At around 11.15 am Wilson and the
applicant left the hotel. They then took part in a suspected drug deal and were both arrested. A search was
conducted of their hotel room, where Charles was arrested. The police seized Class A drugs, which included 115
individual wraps lying on the floor, along with a larger package of wraps. The drugs were contained in either blue or


-----

white plastic wrappings, colour coded for cocaine (count 1) and heroin (count 2).  The paraphernalia utilised by
drug dealers was also seized; it included scales, a drugs line mobile telephone and cash.

5. It was submitted that this was a "county line" drug dealing operation. The three defendants accepted that they
were supplying Class A drugs. They suggested that they were acting on behalf of a London gang (the Mali Boys),
which was based in the Waltham Forest area of the Capital. They each claimed that they were a victim of modern
**_slavery and relied on the defence pursuant to section 45 of the Modern Slavery Act 2015 ("section 45")._**

6. The prosecution did not accept that they had a valid defence under section 45. It is of note that the Crown relied
on bad character evidence in the form of a Drill rap video in which the applicant could be seen dancing. The
prosecution submitted that the video was evidence that showed that he was a willing associate of this gang.

7. The applicant admitted supplying drugs in county lines operations in various locations, selling drugs for older
gang members. There was evidence, including from the applicant himself, that he had been involved with the Mali
Boys since he was [an age] and that he had been involved additionally with the 2Reckless Gang which had been
running drug lines into Norfolk and other counties, as well as with the DM Crew.

8. The applicant had previously been arrested with adults in circumstances linked to drugs. His first arrest for
possession of drugs with intent to supply was when he was [an age]. He had frequently gone missing in the past,
most notably during 2017. The applicant had been placed in care as a result of these and other linked events, and
he had been subjected to domestic abuse from a young age. He is autistic, and his vulnerabilities would, it is
suggested, have made him more susceptible than otherwise would have been the case to being recruited into
criminality of this kind.

9. In his evidence to the jury, the applicant said that the Mali Boys forced him to travel to Brighton to sell drugs prior
to his arrest for these offences. He bumped into Charles and Wilson by chance at Brighton Railway Station and he
"hung out" with them because he knew them. He said that he was selling separately from his co-accused.

10. The prosecution relied on his somewhat different account in his defence statement in which he had suggested
that he had gone to Brighton because he believed that Charles and Wilson would be in danger if they did not travel
to sell drugs. In addition, the applicant appeared to change his account as to whether he had been a member of
the 2Reckless Gang. He accepted that he had appeared in the Drill rap music video, and he said that he had
participated in the filming because he thought that it would be fun. He testified that he had been unaware of the
content of the lyrics at the time of the filming.

11. There are four grounds of appeal as follows:

(i) The Recorder incorrectly ruled that bad character evidence was admissible at trial;

(ii) The Recorder misdirected the jury as to the elements of the section 45 defence;

(iii) The Recorder misdirected the jury in relation to lies allegedly told by the applicant and as regards
inconsistencies within the defence statement;

(iv) The prosecution failed to disclose evidence which arguably would have been persuasive evidence to
support the applicant's defence.

12. It is suggested that these grounds, considered individually or cumulatively, render the applicant's conviction
unsafe. For reasons that will shortly become apparent, we need focus only on the second ground of appeal,
namely the Recorder's direction vis-à-vis section 45. By way of an introduction to our analysis of this issue, we
wish to pay tribute to the care the Recorder took over formulating the written directions and the Route to Verdict,
both of which he had provided to the jury. He had clearly thought carefully about the structure and content of the
summing up. Although for the reasons set out below we are wholly unable to accept the respondent's submission
that there was no, or alternatively no material, misdirection as to a critical element of the applicant's defence, the
Recorder otherwise approached the summing up with commendable care and diligence.

13. Section 45 of the Modern Slavery Act 2015 is in the following terms:


-----

"Defence for slavery or trafficking victims who commit an offence

(1) A person is not guilty of an offence if —

(a) the person is [an age] or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if —

(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if —

(a) the person is under [an age] when the person does the act which constitutes the offence,

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.

(5) For the purposes of this section —

'relevant characteristics' means age, sex and any physical or mental illness or disability;

'relevant exploitation' is exploitation (within the meaning of section 3) that is attributable to the exploited
person being, or having been, a victim of human trafficking.

(6) In this section references to an act include an omission.

(7) Subsections (1) and (4) do not apply to an offence listed in Schedule 4.

(8) The Secretary of State may by regulations amend Schedule 4."

14. The position is very significantly different as between those over and those under [an age]. The defence for
those over 18 is available if the defendant did the act which constitutes the offence because he or she was
compelled to do it and the compulsion is attributable to slavery or to relevant exploitation, and a reasonable person
in the same position as the person, and having the person's relevant characteristics, would have no realistic
alternative to doing that act.

15. In the case of an individual under 18, it is equally necessary that there was a direct causal link between the
criminal act and the individual being (or having been) a victim of slavery or human trafficking, but there is no
requirement of compulsion. Moreover, whereas in the case of an individual over 18 the defence requires that a
reasonable person in the same situation with the same relevant characteristics would have "no realistic alternative"
to doing the criminal act, in the case of an individual under 18, it simply requires that a reasonable person in the
same situation and with the child's relevant characteristics would do what the child did.

16. Those two markedly different regimes as set out in section 45 for defendants who are over or under 18 are
reflected in the example directions given in the Crown Court Compendium Part 1: Jury Trial Management and
Summing Up 2021, paragraph 18.6.

17. The Recorder directed the jury during the summing up as follows:


-----

"Modern Slavery

In this case each of the defendants admits all four elements of the offence on each count. The case then
is about their defence.

[Each defendant is arguing the same defence which arises under the Modern Slavery Act 2015. They say](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
that they are the victims of **_modern slavery. The word 'slavery' is of course highly emotive, and many_**
people have some idea of what historical slavery involved. Modern slavery is a concept defined in an Act
of Parliament.

For the purpose of this case, a person would be a modern slave if another person or persons knowingly
exploits by requiring them to carry out forced or compulsory work. In deciding whether or not a person has
been required to carry out forced or compulsory work, you are entitled to look at all the circumstances of
that person that you know about.

Mr Wilson and Mr Charles are adults, while NHF is a minor. There are different considerations for you as
regards the two adult defendants and NHF. The defence for Mr Wilson and Mr Charles: 'A person will not
be guilty of an offence which was committed when he was over 18 if the following three elements are
present: that the person was compelled to do the act' – in this case drug dealing; 'that the compulsion was
attributable to **_modern slavery; three, a reasonable person in the defendant's position and having the_**
same characteristics as the defendant would have had no realistic alternative but to do the act'.

Mr Charles also says that he has been the victim of human trafficking, and that he met someone in
Somalia who helped him come back to the UK and then coerced him into working for a gang. If you decide
that he was being truthful about this, that is something you should consider with regard to each of the
factors that you have got to consider in his defence.

The defence of NHF. A person will not be guilty of an offence which is committed when he was under 18 if
the following two elements are present: one, a person did the act because he was a victim of **_modern_**
**_slavery; two, a reasonable person in the defendant's position, having the same characteristics as the_**
defendant, would have had no realistic alternative but to do the act. So, there is not a separate
requirement of compulsion in the case of Horatio.

The reasonable person. Both defences require you to consider a reasonable person. This should be an
ordinary person who found themselves in the same situation as the defendants as regards to compulsion
and **_modern slavery, i.e., of exploitation in the cases of Mr Charles and Mr Wilson and as regards_**
**_modern slavery, i.e., exploitation in the case of NHF._**

The burden on the prosecution. Do you recall what I said at the beginning? You will remember that the
burden of proof is on the prosecution. This remains the case when the defendant says they have a
**_modern slavery defence. It is for the prosecution to prove that the defence does not apply to each of_**
these three defendants, and to do this the prosecution must make you sure that it does not apply.

The issue in this case. The only issue then for you to decide with respect to each of these defendants is
whether the prosecution has made you sure that the modern slavery defence does not apply."

18. The Recorder's written legal directions contained the following:

"Modern Slavery

In this case each of the defendants admits all four elements of the offence on each count. The case then
is about their defence. Each defendant is arguing the same defence which arises under the **_[Modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
**_[Slavery Act 2015. They each say that they are victims of modern slavery.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**

The word 'slavery' is, of course, highly emotive and many people have some idea of what historical slavery
involved. Modern Slavery is a concept defined in an Act of Parliament.

For the purpose of this case a person will be a Modern Slave if another person or persons knowingly
exploits them by requiring them to carry out forced or compulsory work. In deciding whether or not a


-----

person is being required to carry out forced or compulsory work you are entitled to look at the
circumstances of that person that you know about.

[Christopher Wilson] and [Bilal Charles] are adults while [the applicant] is a minor. There are different
considerations for you as regards the two adult defendants and [the applicant].

**The Defence of [Christopher Wilson] and [Bilal Charles]**

A person will not be guilty of an offence which was committed when he was over 18 if the following three
elements are present:

(1) That the person was compelled to the act – in this case  drug dealing;

(2) That the compulsion was attributable to Modern  Slavery;

(3) A reasonable person in the defendant's position, and  having the same characteristics as the defendant
would  have had no realistic alternative but to do the act.

[Bilal Charles] also says that [he] has been the victim of human trafficking in that he met someone in
Somalia who helped him come back to the UK and then coerced him into working for a gang. If you decide
that he was being truthful about that, [that] is something you can consider with regard to each of the factors
you have to consider.

**The Defence of [the applicant]**

A person will not be guilty of an offence which was committed when he was under 18 if the following two
elements are present:

(1) The person did the act because he was a victim of  Modern Slavery;

(2) A reasonable person in the [applicant's] position, and  having the same characteristics as the

[applicant] would  have had no realistic alternative but to do the act.

So, there is not [a] separate requirement of compulsion in the case of [the applicant].

**Reasonable Person**

Both defences require you to consider a 'reasonable person'. This would be an ordinary person who found
themselves in the same situation as the defendants as regards to compulsion and **_modern slavery (i.e._**
exploitation) in the cases of [Bilal Charles] and [Christopher Wilson], and as regards modern slavery (i.e.
exploitation) in the case of [the applicant].

**The Burden on the Prosecution**

If you recall what I said at the beginning you will remember that the burden of proof is on the prosecution.
This remains the case when the defendants say they have a Modern Slavery defence.

It is for the prosecution to prove that the defence does not apply to each of these three defendants and to
do this the prosecution must make you sure that it does not apply."

19. The relevant document entitled Route to Verdict set out:

"[The Applicant] – Route to Verdict

It is not in dispute that [the applicant] was concerned with drug dealing in the Preston Street area of
Brighton on 6th February 2021. The defence case is that [the applicant] was compelled to do so due to the
threats of violence he had received from the Mali Boys.

Accordingly, you must consider the following questions.

**Question 1**

Has the prosecution made you sure that [the applicant] was NOT a victim of **_modern slavery by being_**
exploited so as to perform forced labour?

If th t [th li t] t i ti f **_d_** **_l_** t di t f 'G ilt '


-----

     - If you think that [the applicant] was or may have been a victim of modern slavery, go on to consider the
next question.

**Question 2**

Has the prosecution made you sure that a reasonable person in the same situation as [the applicant] and
of [the applicant's] age and sex, sharing any of [the applicant's] physical characteristics or his personal and
family circumstances, including his level of education, would have had a realistic alternative to drug
dealing?

    - If the prosecution has made you sure that a reasonable person (as I have explained that concept to you)
would have had a realistic alternative, return a verdict of 'Guilty'.

     - If you are not sure, then your verdict will be 'Not Guilty'."

20. The Recorder therefore clearly acknowledged that the applicant was in a different position as regards the
elements of the section 45 defence from his two co-accused. His summing up in this context for Wilson and
Charles was appropriate. But he made a fundamental error as regards the applicant in that, although he correctly
identified that the element of compulsion did not apply in his case, he simultaneously incorporated one of the
elements of the defence for those over 18, namely that "a reasonable person in the same situation as the person,
and having the person's relevant characteristics, would have no realistic alternative to doing that act", instead of the
requirement for those under 18, namely that "a reasonable person in the same situation as the person, and having
the person's relevant characteristics, would do that act".

21. Miss McCarthy, on behalf of the respondent, in the written Respondent's Notice did not acknowledge that there
were any difficulties in the Recorder's summing up in this regard. In oral submissions before us, however, she
accepted that parts of the direction for those over 18 had indeed been incorporated into the direction as regards this
applicant. She submitted, nonetheless, that the dynamic of the trial and the way in which the case evolved as
regards all of the accused meant that this misdirection did not taint the summing up, and the issues in relation to
**_modern slavery in relation to all of those on trial were, in her submission, appropriately explored, developed and_**
explained to the jury.

22. We are unable to accept these submissions. There are two fundamental difficulties which flow from the
Recorder's direction in this regard. First, there is a material difference between the notions, on the one hand, that a
reasonable person in the same situation as the applicant, and having the applicant's relevant characteristics would
**have no realistic alternative to doing that act, and, on the other hand, that the same reasonable person simply**
**would do the act. The words "no realistic alternative" act to limit, potentially significantly, the circumstances in**
which the defence can apply. Second, the requirement that the applicant should have had no realistic alternative is
a clear and unavoidable reference back to the requirement of compulsion for those over 18. In the event, the
direction made no sense and was logically unworkable. The Recorder directed the jury that for the applicant the
requirement of compulsion was not present, whilst he simultaneously directed them that the defence required that
the applicant acted as he did because he had no realistic alternative, thereby describing, or strongly alluding to, the
defence as it applies to those over 18 years of age.

23. It is self-evident that the ingredients of this defence should have been properly set out in the summing up. In
the present circumstances there is no way of telling whether the jury would have come to a different verdict if they
had understood that the defence in the applicant's case did not involve the jury needing to consider whether a
reasonable person in the same situation would have had a realistic alternative to drug dealing.

24. Parliament has created markedly different provisions within section 45 for those over and those under 18,
providing that the two groups should not be treated in the same way in this context. As a result of a mistake,
regrettably unnoticed by counsel who had been provided with the written directions and the Route to Verdict in
advance of the summing up, the Recorder, in our view, fatally incorporated a significant element of the wrong
defence in his directions regarding this applicant, thereby rendering the applicant's conviction on these two counts
unsafe.


-----

25. It follows that we reject the wholly unjustified assertion in the written Respondent's Notice that this application
has been brought solely to disrupt a subsequent trial in which the applicant is advancing a defence under section
45. Assertions of bad faith of that kind, which include direct criticism of the applicant's counsel, should only be
made if they have the clearest sustainable foundations. That is not the case here. Indeed, the position is quite the
contrary.

26. We grant the application for leave, we allow the appeal, we quash the two convictions for being involved in the
supply of Class A drugs, and, as we have already indicated, it is unnecessary in these circumstances to consider
the other grounds of appeal.

(The Crown's application for a retrial was resisted on behalf of the Appellant)

**LORD JUSTICE FULFORD:**

27. In our judgment it is not in the interests of justice to order a retrial, given the particular circumstances of this
case, and including the result of the recent trial at Snaresbrook Crown Court.

____________________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________

**End of Document**


-----

