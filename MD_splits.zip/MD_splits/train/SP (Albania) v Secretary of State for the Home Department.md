# SP (Albania) v Secretary of State for the Home Department [2019] EWCA Civ
 951

Court of Appeal, Civil Division

Sir Ernest Ryder SP and Bean LJ

19 June 2019Judgment

**Mr. James Collins (instructed by Sentinel Solicitors) for the Appellant**

**Mr. Eric Metcalfe (instructed by Government Legal Department) for the Respondent**

Hearing date: 9 May 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

Sir Ernest Ryder, Senior President:

Introduction:

1. This is an appeal against the decision of Judge McGeachy sitting in the Upper Tribunal (Immigration
and Asylum Chamber) ['UT'] made on 20 February 2017 which dismissed the appellant's application to
judicially review the Secretary of State's decision to refuse her claim for asylum and to certify the
appellant's claim as clearly unfounded. Permission to appeal to this court was granted on 26 February
2018.

Factual and procedural background:

2. The appellant is a national of Albania. She entered the United Kingdom with her husband in 1999 and
claimed asylum, falsely claiming to be from Kosovo. On 27 January 2004 the appellant gave birth to twin
sons in the United Kingdom. The appellant's asylum claim was refused and she and her children were
returned to Albania in December 2004.

3. The appellant's case is that in 2007 she began to borrow money from a man known as AK who had a
hotel in the town of Skhodra. In order to repay the money she had borrowed from him she worked as a
cleaner in his hotel every summer between 2008 and 2014. The appellant says that in September 2014 AK
became frustrated with her inability to repay her debt and told her to have sex with tourists in his hotel. She
resisted but was locked in one of the rooms and forced to have sex with tourists for a period of three
weeks. The appellant was also raped and assaulted by AK on a number of occasions. After the appellant
pretended to cooperate with him she was given more freedom and she managed to escape after she was
allowed into the garden of the hotel.

4. The appellant did not report AK to the police because, she says, he had threatened to have her children
taken away and be violent towards her if she did.

5. On 1 October 2014 the appellant and her children, with the help of her family, left Albania. On 4 October
2014 the appellant re-entered the United Kingdom with her children, then aged 10. On 8 October 2014 the
appellant claimed asylum with the children as her dependents


-----

6. On 1 April 2015 the Secretary of State refused the appellant's asylum claim and certified it as clearly
unfounded under section 94(2) of the Nationality, Immigration and Asylum Act 2002.

7. On 13 May 2015 the appellant applied to the UT for permission to judicially review the Secretary of
State's decision. On 7 March 2016 Judge Plimmer granted permission to bring the judicial review claim. On
12 December 2016 the appellant's substantive application for judicial review was heard by Judge
McGeachy. On 20 February 2017 Judge McGeachy dismissed the claim. It is this decision that is the
subject of the appeal to this court.

8. There have been developments in the appellant's status as a trafficked person since Judge McGeachy
handed down his judgment. On 7 February 2017 the appellant's case was referred to the 'Competent
Authority' via the Home Office's National Referral Mechanism ['NRM'] to consider whether there were
reasonable grounds to believe that she was a victim of human trafficking. On 13 February the Competent
Authority notified the appellant that there were reasonable grounds to believe she was a victim of
trafficking. The appellant was told that after a 45 day recovery and reflection period the Competent
Authority would make a 'Conclusive Grounds Decision' as to whether the appellant was a victim of human
trafficking.

9. On 7 September 2018 the Competent Authority concluded that the appellant was not a victim of human
trafficking. Following this, the appellant's solicitors sent a pre-action letter to the Competent Authority
challenging its decision. The Competent Authority agreed to reconsider.

10. On 30 January 2019 the Competent Authority concluded that the appellant was a victim of trafficking. It
went on to consider whether it was necessary to grant her discretionary leave. It noted that there was
nothing to show that such a grant was necessary for the purposes of protecting and assisting the appellant
with her recovery or for pursuing a compensation claim against her traffickers. The Competent Authority
further noted that there was no realistic risk of the appellant being re-trafficked or again becoming a victim
of modern slavery and that the objective evidence was that the Albanian authorities were able and willing
to provide her with assistance should she require their support. Accordingly, the Competent Authority
concluded that the appellant was not eligible for a grant of discretionary leave.

Decision appealed:

11. Judge McGeachy noted that it was appropriate to take the appellant's claim at its highest. Even at its
highest he found that the only conclusion he could reach was that the appellant's asylum claim could not
succeed. He reached this conclusion for the following reasons:

i. On the facts before the UT, the appellant was not trafficked. It should be noted that the judge could not
have been aware of the contrary conclusion of the Competent Authority. He observed that trafficking
involves moving individuals from one place to another. On the appellant's own case she was not moved
and therefore not trafficked.

ii. There would be sufficient protection for the appellant in Albania. The appellant did not report AK's
crimes to the police. There was no evidence AK was a member of a gang. There was nothing to indicate
that AK had any influence over the police or that he could influence any decision they made.

iii. Internal relocation in Albania was reasonably open to the appellant. The judge held that it is clear from
_AM and BM_ _[2010] UKUT 80 (IAC) that internal relocation as a question is fact specific. One of the factors_
is the likelihood of being re-trafficked by those who had trafficked the woman in the first place who might
have particular criminal connections in Albania or if the victim was likely to be re-trafficked again because
of a particular vulnerability. In this case the appellant had not been trafficked. There was nothing to show
AK had contacts in different cities throughout Albania or that he had any intention of finding the appellant.

12. The judge concluded that the appellant is a victim of a serious crime. However, she was not a victim of
trafficking and the Secretary of State was unarguably entitled to consider that there would be sufficient
protection for the appellant and that she could internally relocate within Albania. The appellant's claim
could not succeed.


-----

Grounds of appeal:

13. The appellant has four grounds of appeal:

i. The judge erred in finding that the appellant was not a victim of trafficking.

ii. The judge erred by not considering the appellant's claim at its highest.

iii. The judge's finding that there would be sufficient protection in Albania was infected by the finding that
the appellant was not a victim of trafficking and accordingly her claim was not taken at its highest.

iv. The judge's finding that there would be a viable internal relocation option in Albania was infected by the
finding that the appellant was not a victim of trafficking and accordingly her claim was not taken at its
highest.

Grant of Permission to Appeal:

14. On the papers the Secretary of State submitted that the grant of permission to appeal was based on a
material error. It is not necessary to consider the merits of this submission and in fairness to Mr Metcalfe
who appeared before us for the Secretary of State, he did not pursue it.

Discussion:

15. The definition of trafficking relied upon by the judge at paragraph [15] of his judgment is taken from
Article 4(a) of the _Council of Europe Convention on Action against Trafficking in Human Beings which_
defines human trafficking as:

“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position
of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person
having control over another person, for the purpose of exploitation. Exploitation shall include, at a
minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or
services, slavery or practices similar to slavery, servitude or the removal of organs.”

16. The first sentence of this definition lists a number of independently sufficient acts only one of which
needs to be present for there to be trafficking, provided the other elements of the definition are present.
This is clear from paragraphs 74 and 75 of the Explanatory Report to the Council of Europe Convention on
_Action against Trafficking in Human Beings which sets out the different elements of the definition in Article_
4(a) and gives examples of which elements need to be present to satisfy the definition:

“74. In the definition, trafficking in human beings consists in a combination of three basic components,
each to be found in a list given in the definition:

– the action of: “recruitment, transportation, transfer, harbouring or receipt of persons”;

– by means of: “the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of
the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person”;

– for the purpose of exploitation, which includes “at a minimum, the exploitation of the prostitution of others
or other forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery,
servitude or the removal of organs”.

75. Trafficking in human beings is a combination of these constituents and not the constituents taken in
isolation. For instance, “harbouring” of persons (action) involving the “threat or use of force” (means) for
“forced labour” (purpose) is conduct that is to be treated as trafficking in human beings. Similarly,
recruitment of persons (action) by deceit (means) for exploitation of prostitution (purpose).”

17. It is plain that the definition is to be read disjunctively rather than conjunctively. It cannot otherwise be
effective. Slavery, often referred to in this context as modern slavery, includes exploitation by the abuse
of power which encompasses, among other practices, servitude, forced or compulsory labour and sexual


-----

exploitation.  It is accepted that these were circumstances that were imposed on the appellant in this case.
Before this court, the appellant would also have been able to rely, if necessary, upon the decision of the
Competent Authority that there were conclusive grounds to believe that she was a victim of trafficking.

18. The Secretary of State does not concede that the judge fell into error in his application of the definition
but the problem is patent on the face of his judgment given the plain meaning of the words of the definition.
The question that arises, however, is whether any error that the judge made in this regard is material.

19. The Secretary of State submits that it was accepted by both parties before the UT that the appellant
might _prima facie fall within the definition of trafficking. What was in dispute was whether the appellant_
would be considered to be a member of a particular social group of trafficked women if she were returned
to Albania. The fact that the appellant may fall within the definition of trafficking did not in itself establish
that she would be considered a member of a particular social group namely, trafficked women.

20. The Secretary of State submits that this is because there is nothing about the particular circumstances
of the appellant's case to show that she would be identified as a member of that group upon her return.
Even if she were identified as a member of that group she could not show that she had a well-founded fear
of persecution in Albania for being a member of that group because there was no evidence that other
women had been trafficked or that the perpetrator had any connection or involvement with gangs or that
there was a continuing risk.

21. The Secretary of State further submits that the fact that the appellant has subsequently been
recognised to be a victim of trafficking does not alter the position. That is because, he submits, the
Competent Authority found that there was no realistic risk of the appellant being re-trafficked or becoming a
victim of modern slavery again if she were returned to Albania, given the particular circumstances of her
case.

22. It can readily be seen that each of the Secretary of State's propositions depends upon an assessment
of the facts, that is: what the appellant's case is when taken at its highest. Likewise, the judge's
determination in the UT depends on his assessment of the same material.

23. The judge said at [30] that he was taking the appellant's claim at its highest. He was right to do so. At
the date of the decision to certify the appellant's claim as clearly unfounded the Secretary of State's policy
document 'Non Suspensive Appeals (NSA) Certification under Section 94 of the NIA Act 2002' stated that
the appellant's claim would be assessed at its highest.

24. Taking a case at its highest does not mean that everything the appellant claims must be taken to be
correct. This was made clear by this court in R (on the application of FR (Albania)) v Secretary of State for
_the Home Department [2016] EWCA Civ 605 per Beatson LJ at [77] where he considered and rejected a_
submission similar to the one made by the appellant in this case:

“Ms Carss-Frisk's submissions were elegantly presented. They were formulated to reflect the version of the
guidance about credibility that was in force at the time of the decisions about these appellants: “when
considering certification … claims are assessed at their highest and are only certified when they are bound
to fail, even if it is accepted that the claim is true”. But at times she appeared to be submitting that anything
said by a claimant should be accepted as correct for the purpose of the certification exercise or because
further information might emerge at the hearing of an appeal. In my judgment, that puts it far too high. It
would in practice prevent the certification of any claim, however incapable of belief or inconsistent with the
objective evidence the account given by the claimant is. What must be assessed is the claim which has in
fact been put forward, including the answers in interview and the contents of witness statements, the detail
given and any supporting evidence submitted. To do otherwise is to let a genuine subjective fear be
conclusive, whether or not it is objectively well-founded and regardless of what the objective evidence
about a state is.”

25. The correct approach when considering a claim at its highest following FR (Albania) is to consider the
claim that has in fact been put forward by the appellant including all the information she has provided. If
there is material provided by the appellant, including her answers during interview, which is capable of
being objectively well founded and sufficient to establish a claim but which is not accepted by the Secretary


-----

of State, then an opportunity to have that evidence tested before a judge of the First-tier Tribunal should be
provided i.e. certification by the Secretary of State would not be appropriate.

26. In this case the appellant claimed AK was a member of a gang. However, on her own case she
suggested that it may be her fear that made her think that he was in a gang (Asylum Interview ['AI'] Q5, tab
3, pg 47). She stated that no one else was involved in the crimes committed against her (AI, Q280, tab 3,
pg 64) and that she had no basis to believe AK's friends were involved in his activities other than the fact
that they were his friends (AI, Q282 and Q285, tab 3, page 64). On this basis, the judge would have been
right to assess the appellant's claim as being entirely subjective and the Secretary of State could not be
criticised for certification.

27. What was not apparently investigated before the judge in the UT and was not raised before this court
until almost the conclusion of the hearing was the earlier answers the appellant had given at her screening
interview on 8 October 2014 (tab 2 page 77 of the bundle). At Q4.2 in answer to the question 'why you
cannot return to your home country?', the appellant said “I am afraid of the person I used to work for. He
raped me and my family found out and helped me to leave. He said that if I reported him then he would
have my children taken away”. In answer to the question 'What do you fear will happen to you if you return
to your home country?' She said: “I am afraid that if I return he will take my children and be violent towards
me”.

28. Those answers beg any number of further questions that were not asked and which were relevant to
the appellant's claim being taken at its highest by the decision maker and the tribunal. For example, why
did the appellant fear that her children would be taken away? Who would take them away? What was the
connection between AK and the authorities or anyone else who would take the children away? Why would
she not be believed if she told the authorities the truth? Those questions were not asked or answered in
any sufficient particularity to demonstrate that her case was being considered at its highest.

29. Furthermore, whether there would be a sufficiency of protection and whether internal relocation was
open to the appellant in Albania were subsequent questions that were in part dependent on an
investigation of the case she was putting forward. The failure to consider her case at its highest
necessarily damages any assessment of these questions.

30. I do not criticise the judge for the way he addressed these subsequent questions and he should not be
criticised for not taking into consideration something that was not raised by either party. Central to the UT's
assessment on the sufficiency of protection was the appellant's own admission that she took no steps to
avail herself of the protection of the Albanian authorities before she left Albania. The questions which I
have identified were not asked and so the position that the judge faced was that there was no evidence
that AK was a member of a gang or that he had any connections with the police or others in authority.

31. The appellant said she did not go to the police because “you can bribe anyone in Albania”. That would
not have been sufficient to avail the appellant of a ground of appeal. In Horvath v Secretary of State for the
_Home Department [2001] AC 489 at 511Lord Clyde held that “corruption, sympathy or weakness of some_
individuals in the system of justice does not mean that the state is unwilling to afford protection”.

32. Likewise, the question of whether it would have been reasonable for the appellant to re-locate was
considered by the judge in the context of the facts that were put before him. He applied the test in Januzi
_and others v Secretary of State for the Home Department_ _[2006] UKHL 5, at [21]:_

"The decision-maker, taking account of all relevant circumstances pertaining to the claimant and his
country of origin, must decide whether it is reasonable to expect the claimant to relocate or whether it
would be unduly harsh to expect him to do so."

And he took into account all the relevant circumstances of which he was aware in accordance with the
guidance given in AM and BM _[2010] UKUT 80, the relevant country guidance for Albania._

33. None of that saves the decision of the judge or the Secretary of State from the misapprehension which
they had about the appellant's case when taken at its highest. This was not an appropriate case for
certification for the reasons I have given with the consequence that the Secretary of State's decision should


-----

have been quashed and set aside. This court is in a position to do that and accordingly I would allow the
appeal, set aside the decision of the Upper Tribunal and substitute a decision of this court quashing the
Secretary of State's decision of 1 April 2015 refusing her asylum claim and certifying it as clearly
unfounded.

**Lord Justice Bean:**

34. I agree.

**End of Document**


-----

