# R v Iyamu [2018] All ER (D) 74 (Sep)

[2018] EWCA Crim 2166

Court of Appeal, Criminal Division

EnglandandWales

Davis LJ, Simler J, Dove J

20 September 2018

**Criminal Law – Trafficking people for exploitation – Sentencing**
Abstract

_Criminal Law – Trafficking people for exploitation. The Solicitor General's appeal to increase the offender's_
_[sentence for offences contrary to section 2 of the Modern Slavery Act 2015 was successful. The Court of Appeal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C254-00000-00&context=1519360)_
_held that the offences committed by the offender had been grave and her role in the offences had been a leading_
_one. Her five victims had been left psychologically and physically scarred and the offender had shown no remorse_
_for her actions, therefore the sentence of 14 years imprisonment did not accurately reflect the appalling gravity of_
_the offences. The offender's sentence was accordingly increased to 18 years' imprisonment._
Digest

The judgment is available at: [2018] EWCA Crim 2166

**Background**

The offender had taken her five Nigerian victims to a juju priest in Nigeria and threatened them with curses and
misfortune if they failed to comply with her instructions. They had then travelled to Germany where the women were
provided with false identification documents and forced into prostitution. One of the five victims had only been made
aware that she would be working as a prostitute once she arrived in Germany. The offender had demanded
between €30,000 to €38,000 from each of the victims as payment for her services in bringing them to Europe. After
investigations by the German authorities, the victims were arrested, as was the offender, who instructed her
husband to ensure that the victims' families withdrew their witness statements. The sister of one of the victims was
subsequently arrested in Nigeria and warned not to give witness evidence against the offender. The offender was
convicted and sentenced to a total of 14 years imprisonment consisting of 13 years for five offences contrary to
_[section 2 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C254-00000-00&context=1519360)_ **_[Modern Slavery Act 2015 (MSA 2015) and one year for perverting the course of justice, to run](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
concurrently.

The Solicitor General successfully applied for leave to challenge the sentence on the ground that it was unduly
lenient.

Appeal allowed.

**Issues and decisions**

Whether the judge at first instance had erred in imposing an unduly lenient sentence.


-----

The facts and circumstances compelled the conclusion that the sentence ought to be increased. Offences of such
gravity required condign sentences to deter individuals from re-offending in the same manner. Stronger sentences
deterred people from engaging in vicious, ruthless and heartless human trafficking and showed that the courts
would show no mercy in such situations (see [51] of the judgment).

The offences committed had been grave and the offender's role had been a leading one involving a high level of
planning and organisation. There had been considerable financial gain at stake and the vulnerability of not just one
but five victims had been exploited from the outset in a period of around 15 months. The trafficking had further
involved sexual exploitation of young women, including coercion by threats and juju rituals, and who were
psychologically detained as well as being psychologically and physically scarred. The victims had been exposed to
appalling suffering while travelling to Europe and had been exposed to a real risk of danger. Threats had been
made to them and their family members and they had been further exposed by having their identification
documentation removed in Europe, putting them at risk of detention as illegal entrants. Further, the offender had
attempted to pervert the course of justice (see [45] of the judgment).

The mitigation available was relatively sparse; there could have been no credit for any plea as the trial was fought,
and further, the offender had displayed no remorse. However, the offender had been of previous good character
and had worked as a nurse in the United Kingdom; in addition, she had a 16 year old son with health problems and
she herself had health issues. Further, she had claimed to have been providing financial and emotional support to
family members in Nigeria, which she could no longer do (see [46] of the judgment).

[However, the judge had reached the wrong conclusion and 13 years' imprisonment for the MSA 2015 offences did](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
not sufficiently reflect the appalling gravity of the offences which related to five separate victims. Accordingly, the
[offender's sentence for the MSA 2015 offences would be increased to concurrent terms of 17 years imprisonment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
with one year for perverting the course of justice, to run concurrently (see [50] and [52] of the judgment).

_A-G's Reference (Nos 37, 38 and 65 of 2010)_ _[2010] EWCA Crim 2880 applied; R v Connors_ _[2013] EWCA Crim_
_324 applied; R v Zielinski (David) [2017] EWCA Crim 758 considered._

R Buckland QC (Solicitor General) and J Evans on behalf for the Attorney General

J Benson QC for the offender.
Amarjit Atwal Solicitor.

**End of Document**


-----

