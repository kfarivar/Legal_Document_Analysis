# R v Valencia [2023] EWCA Crim 1683

Court of Appeal, Criminal Division

William Davis LJ, Farbey J and Judge Kearl KC (Recorder of Leeds)

30 November 2023Judgment

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child.**

**Reporting restrictions prohibit the publication of the applicable information to the public or any**
**section of the public, in writing, in a broadcast or by means of the internet, including social media. Anyone**
**who receives a copy of this transcript is responsible in law for making sure that applicable restrictions are**
**not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment. For**
**guidance on whether reporting restrictions apply, and to what information, ask at the court office or take**
**legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

MR B HOLT appeared on behalf of the Attorney General

MISS A HUSSAIN appeared on behalf of the Offender

_________

**J U D G M E N T**

1. LORD JUSTICE WILLIAM DAVIS: Freddie Valencia was born on 20 October 2005. He is now 18. On 3 April
2023 in the Crown Court at Woolwich he pleaded guilty to an offence of affray. He pleaded not guilty to counts of
causing grievous bodily harm with intent, having an article with a blade or point, being concerned in the supply of
cannabis between July 2022 and January 2023 and possession of 10 MDMA tablets with intent to supply. On 24

July 2023 he was re‑arraigned on those counts. He pleaded guilty. On 18 September 2023 he was made the

subject of a youth rehabilitation order with an intensive supervision and surveillance programme. The duration of
the order was two years. The order was imposed concurrently in relation to each count. The requirements of the
order in summary form were: supervision 24 months, exclusion from the London Borough of Southwark six months,
curfew (9.00 pm to 6.00 am) six months, prohibited activity 24 months, programme requirement 28 days, 200 hours
unpaid work.

2. His Majesty's Solicitor General now seeks leave pursuant to section 36 of the Criminal Justice Act 1988 to refer
the sentence to this court as being unduly lenient.

3. The offender came to the United Kingdom from Spain with his mother when he was four or five years old.
Between 2017 and 2019 he lived with his father in Ecuador before returning to this country. Shortly after his return
to the United Kingdom from Ecuador he began to smoke cannabis on a regular basis. He occasionally went
missing from home. By 2022 he was living with his mother and her new partner, together with his grandmother and


-----

sister in a house in Thornton Heath in South London. According to the police, albeit this is denied by the offender,
he was associated with a known gang operating in South London.

4. The offender was the subject of referrals to the Single Competent Authority under the NRM in 2021 by Croydon
Council and in early 2023 by the police. The referrals were on the basis that the offender may have been the victim
of modern slavery. In March 2023 the Single Competent Authority made a Conclusive Grounds Decision that the
offender was such a victim. The factual matters referred to in the decision were several missing person episodes,
truanting from school, unexplained funding of new shoes and clothing and a meeting at a party in
November/December 2022 when the offender was the subject of an implicit threat to his family if he did not agree to
sell cannabis.

5. On the evening of 3 December 2022, two young males named Medina and Velez went to Elephant Park in
Elephant and Castle. This was at Velez's suggestion. They wanted to buy cannabis. Velez had told Medina that
he had been given the details of a dealer that he had not previously used. In the park they met the dealer. It was
the offender. The offender was with a female. The offender had cannabis to supply. Velez was handed a bag of
cannabis. He then said words to the effect: "I'm not paying for this." The offender pulled out a large knife. Velez
and Medina ran off, Velez still holding the bag of cannabis. They were chased by the offender accompanied by the
female. As he chased Velez and Medina he shouted “get them” to two other males. The other males joined in the
chase.

6. The offender caught up with Medina. With his knife he stabbed Medina several times to the left chest, abdomen
and left thigh. One stab wound penetrated the chest cavity. Medina's left lung collapsed and there was internal
bleeding within the cavity. Medina's left rib was fractured. Another stab wound penetrated the spleen. The two
males caught up. They punched Medina. They demanded his mobile telephone. When Medina put his telephone
on the ground they ran off with it.

7. Despite his injuries, Medina was able to run to a nearby restaurant. Those at the restaurant could see that he
was injured. He was taken upstairs by members of staff. Velez also ran to the restaurant. He was followed by the
offender, the female and the other two males. Inside the restaurant the offender picked up a glass and made as if
to throw it at people sitting in the restaurant. When he realised that Velez and Medina were not in view he put the
glass down. He and those with whom he had arrived left the restaurant.

8. On 25 January 2023 the offender was arrested in South London. He had with him a bag of cannabis. Hidden in
his underwear were 10 MDMA tablets. His mobile telephone was interrogated. It contained messages showing
that over a significant period from July 2022 onwards he had been dealing in cannabis.

9. The offender was interviewed about the drugs seized from him and the messages on his telephone. He declined
to answer questions; rather, he provided a prepared statement saying he had been forced to sell MDMA and
cannabis by drug dealers. The drug dealers had threatened to harm his family. Whilst he was in custody, the
offender was identified by Medina as the person who had stabbed him.

10. On 27 January 2023 the offender was sent for trial at the Crown Court. He pleaded guilty to affray at the first
effective hearing at the Crown Court, that count relating to his behaviour in the restaurant. The other counts were
adjourned for trial. A defence statement was served. In relation to the drugs offences, the offender indicated he
[would rely on a defence under section 45 of the Modern Slavery Act 2015. In respect of events in December 2022](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
he admitted presence in Elephant Park when Medina was stabbed. He denied that he had had a knife and he
denied that he was the person who had stabbed Medina.

11. At a pretrial review on 19 July 2023 counsel then representing the offender invited the judge who was
considering the case to give a Goodyear indication. There had been no written application. As a result the judge
declined to give any indication of sentence. However the judge stated that a reduction of 20 per cent would be
retained were pleas of guilty to be tendered thereafter.

12. The pleas of guilty were in fact tendered on the first day of the trial, i.e. just under a week later. Sentence was
adjourned for the preparation of reports


-----

13. When the offender appeared for sentence on 18 September 2023 he had been in custody for just under eight
months. The judge had a copy of the Conclusive Grounds Decision, to which we have already referred. He had a

pre‑sentence report from the Youth Justice Service. The report spoke positively of the offender's progress during

his time in custody at Cookham Wood. The offender had demonstrated "growing maturity levels and capacity for
reflection..." In relation to the offences, the offender was reported as explaining that he took the knife with him on
the evening in question as a form of protection. He said that he did not regularly carry a knife. When the customer
had refused to pay for his drugs he had become angry and seen red. In relation to the supply of drugs more
generally, the offender explained that he had been involved in the supply of cannabis since July 2022, an assertion
consistent with the messages on his telephone. He said that his motivation was financial, i.e. to support himself
and his family.

14. The report assessed the offender as presenting a high risk of further offending, despite his lack of previous
convictions. The author of the report said that the offender had difficulty controlling his emotions and that the facts

of the principal offence demonstrated poor decision‑making. The report also concluded that such further offending

would carry a high risk of serious harm. It is to be noted however that the report indicated that those risks did not
necessarily have to be dealt with by a custodial sentence.

15. The report set out the various options available to the sentencing judge. It concluded in these terms:

"The Youth Justice Service maintain the view that a youth rehabilitation order with intensive supervision and
surveillance offers the most appropriate means through which to provide appropriate punishment, protection of the
public and victim, manage risk whilst also offering a realistic hope for successful societal reintegration and positive
welfare outcomes for Fredy."

16. In the course of the hearing today, that report has been described as thorough and comprehensive. It was, as
we would expect from any report from the Youth Justice Service relating to a troubled young man such as the
offender.

17. Medina on 8 February 2023 provided a victim personal statement. Following the attack on him he had been
admitted to the intensive care unit at King's College Hospital. He had required more than one significant medical

intervention. He was discharged on 12 September 2022 but re‑admitted to hospital four days later with severe

abdominal pain due to an infection in his spleen. He was discharged again shortly before Christmas 2022 requiring

long‑term medication. His spleen was permanently damaged. He was off work and unable to attend college for two

months. He experienced pain in his left side on any kind of exertion.

18. Medina has provided a further victim personal statement, which was dated shortly after the sentencing hearing,
which updates the position. He continues to experience pain on his left side which limits his participation in sport.
He describes anxiety when out in public and being fearful of another attack.

19. When sentencing the offender the judge said this:

"You have pleaded guilty to a litany of very serious offences, the most serious of them is inflicting grievous bodily
harm with intent ... You are incredibly lucky that this young person did not die ... it is true that you have not really
had any offences in the past, but you started right at the very top. You could well have been in the position today

where, as a 17‑year‑old, you would be going to prison for the rest of your life. You have got to actually understand

this is serious. Wandering around with a 13" blade ... and stabbing someone three times is simply outrageous
behaviour; it is wildly criminal. Count two, having an article with a blade or point ... It is just not acceptable ... then
you are dealing in drugs."

20. The judge then turned to what the outcome should be and he said this:

"... when I first looked at this case ... I was of the view that ... there was no other sentence I could justify other than
a very long, immediate custodial sentence. However, I have read the report, which was prepared by the Probation


-----

Service, [the Youth Justice Service] which I have got to say was actually incredibly thorough and it is has actually,
having taken account of it, persuaded me together with what counsel have said, that the course which is
recommended in it is one that as a wholly exceptional course, I will follow ... I have seen the **_modern slavery_**
reports and I take full account of the fact that in those, you have been found to be a victim of modern slavery, as
now understood under the legislation. I have ... taken account of that ... Another factor that has influenced me in
this is the fact that your family have turned up to court and are supportive. Another factor that has played a part in
my thinking is the fact that you pleaded guilty at the outset, and you have shown a degree of contrition ... you now

realise the seriousness of what you have done. Post‑arrest, your behaviour has changed, and you have engaged

and that is something which is to your credit."

21. The judge did not at any stage explain his thinking by reference to the Children guideline issued by the
Sentencing Council. He did not refer to any guideline in relation to the specific offences to which the offender
pleaded guilty.

22. On behalf of His Majesty's Solicitor General, it is argued that the offences committed by the offender, in
particular the offence of causing grievous bodily harm with intent, pass the custody threshold by some distance,
such that no sentence other than immediate custody was appropriate. In those circumstances the judge should
have had regard to the adult guidelines for the various offences. By reference to the adult guidelines, even taking

into account the offender's age, a non‑custodial sentence amounted to a gross error.

23. On behalf of the offender we have heard submissions from Miss Hussain, who represented the offender in the
court below. She has emphasised that the two objectives of sentencing for those under the age of 18 are to

prevent re‑offending and to protect the welfare of the offender. There must be an individualistic approach. She

also draws our attention to the fact that the offender had already spent eight months in custody on remand prior to
the sentence being imposed in September of this year. She relies on the fact that the Single Competent Authority
made a finding that the offender was exploited for the purposes of criminal offending. She invites us to say that the
sentence imposed was not unduly lenient because of all the factors relating to the offender as opposed to the
offence. Even if it could be said that the sentence were unduly lenient, she argues that the court in its discretion
should not interfere with the sentence.

24. The correct formulation of what amounts to an unduly lenient sentence is still that provided by the then Lord
Chief Justice in Attorney General's Reference No 4 of 1989 [1990] 1 WLR 41:

"A sentence is unduly lenient, we would hold, where it falls outside the range of sentences which the judge,
applying his mind to all the relevant factors, could reasonably consider appropriate."

It follows that for us to conclude that this sentence was unduly lenient we must find that it was not reasonably

appropriate for the judge to impose a non‑custodial sentence.

25. The lead offence which fell to be sentenced was causing grievous bodily harm with intent. The offender was
engaged in drug dealing. He was armed with a large knife. The only sensible inference is that he had it with him to
use in case of trouble. That potential trouble included a customer refusing to pay and running off with the drugs.
When that happened the offender got out his knife and chased after the person who had taken the drugs. He was
the apparent leader of a group shouting to other males who were nearby to join in. He stabbed his victim several
times, inflicting deep wounds to vulnerable areas. He then pursued his victim into a restaurant where he caused
fear to customers in that restaurant.

26. Paragraph 6.44 of the Children guideline issued by the Sentencing Council states as follows:

"In determining whether an offence has crossed the custody threshold the court will need to assess the seriousness
of the offence, in particular the level of harm that was caused, or was likely to have been caused, by the offence.

The risk of serious harm in the future must also be assessed. The pre‑sentence report will assess this criterion and


-----

must be considered before a custodial sentence is imposed. A custodial sentence is most likely to be unavoidable
where it is necessary to protect the public from serious harm."

27. On any view the offence committed against Medina was very serious. The judge acknowledged that in the
opening passage of his sentencing remarks to which we have already referred. Very significant harm was suffered

by Medina. In addition, the pre‑sentence report established that at the time of writing the offender presented a

significant risk of serious harm from further offences of violence, albeit that there were other ways in which that
might be dealt with other than custody. The facts of this case met the definition in paragraph 6.44 of the Guideline,
namely "a custodial sentence is most likely to be unavoidable..."

28. In those circumstances the subsequent paragraphs in the Children guideline fall to be considered:

"6.45 Only if the court is satisfied that the offence crosses the custody threshold, and that no other sentence is
appropriate, the court may, as a preliminary consideration, consult the equivalent adult guideline in order to decide
upon the appropriate length of the sentence.

6.46 When considering the relevant adult guideline, the court may feel it appropriate to apply a sentence broadly

within the region of half to two‑thirds of the adult sentence for those aged 15‑17 and allow a greater reduction for

those aged under 15. This is only a rough guide and must not be applied mechanistically. In most cases when
considering the appropriate reduction from the adult sentence **the emotional and developmental age and**
**maturity of the child or young person is of at least equal importance as their chronological age. This**
reduction should be applied before any reduction for a plea of guilty."

29. We are satisfied that the judge ought to have consulted the adult guideline for the offences. We are satisfied
that the judge should have concluded, at least as a preliminary finding, that no sentence other than custody was
appropriate. Had he consulted the adult guideline he would have found that the offence of causing grievous bodily
harm fell into Category 2A within that guideline. Culpability was high because the offender used a knife and
because he played a leading role in a group. Harm was in Category 2 because the injury was grave. The starting
point for a Category 2A offence is seven years' custody in the case of an adult. In this instance the presence of two
significant culpability factors justified an uplift. The fact that the offence was committed in the context of other
criminal activity was an aggravating factor, as was the pursuit of the victim and the threats made to customers in the
restaurant. The offender's lack of previous convictions mitigated the sentence.

30. The other offences committed on 3 December served to aggravate the principal offence. It is not necessary for
us to consider the guidelines in relation to those offences save that we observe that the bladed article offence was a
very serious one of its kind which would have required an immediate custodial sentence for an adult.

31. The drugs offences for which the offender was arrested on 25 January 2023 fell into Category 3 harm within the
relevant guidelines since they involved the supply of drugs to users. Assuming that the MDMA offence involved a
lesser role on the part of the offender, the starting point in the guideline for an adult would have been three years'
custody. Given the length of time for which the offender was involved in the supply of cannabis, he would have
been placed into a significant role in the adult guideline giving a starting point of one year's custody. Whatever
exploitation there might have been, the offender did not seek to rely on any statutory defence in the 2015 Act.

Moreover, the particular matter relied on within the Conclusive Grounds Decision post‑dated by some months the

start of the offender's dealing in cannabis.

32. The sentence for the principal offence, namely causing grievous bodily harm with intent, had to reflect the
drugs offending. We consider that the overall sentence before discount for age and reduction for the plea of guilty

should have been in the region of eight years' custody. Using two‑thirds of the adult guideline to fix the sentence

after trial and applying a reduction of 20 per cent for the pleas of guilty achieves a sentence (rounded down) of four
years' custody. It follows that the sentence in fact imposed was unduly lenient.


-----

33. It does not necessarily follow that the sentence imposed must be quashed. We retain a discretion to avoid that
outcome if we consider that justice requires it. We are acutely conscious that the offender even now is still a young
man, albeit that he has now passed his 18th birthday. It is of significance that having spent almost eight months in
custody he was released just over two months ago and has been making good progress on the order imposed by
the judge. We accept and acknowledge the requirement to take an individualistic approach, as pressed on us by
Miss Hussain.

34. However, we have come to the conclusion that the judge took into account, when he made his decision,
matters that were of no or no significant weight. He said that the offender had pleaded guilty at the outset. That
was not the case. In relation to the serious offending the offender pleaded guilty on the day of trial, having served a
defence statement denying stabbing his victim. The offender was very fortunate to have a 20 per cent reduction
preserved in relation to his pleas. The judge took account of the Conclusive Grounds Decision in relation to
**_modern slavery. The main basis of that decision was inconsistent with the account given by the offender to the_**

author of the pre‑sentence report and with the plea tendered to the indictment. In those circumstances, the

decision was of little weight. In taking those matters into account the judge fell into error. We conclude that he
compounded that error by striking the wrong balance between the seriousness of the offending and the needs of
the offender.

35. The court is always anxious to avoid imposing custodial sentences on offenders under 18. This case is no
exception. However, where the offending is so serious that custody is the only appropriate course, then that is the
sentence that has to be imposed. We have concluded that is what must follow in this case.

36. We grant leave to His Majesty's Solicitor General to refer the sentences imposed on 18 September 2023. We
quash the sentences imposed, namely the youth rehabilitation order with intensive surveillance and supervision,
and we substitute for those sentences concurrent sentences of detention as follows:

Count 1, causing grievous bodily harm with intent, four years' detention; count 2, having an article with a blade or
point, no separate penalty; count 4, affray, no separate penalty; count 5, being concerned in the supply of cannabis,
six months' detention; and count 6, possession of MDMA with intent, 12 months' detention. All those sentences will
run concurrently, making four years in all.

37. As we have made clear in what we have said, the sentence on count 1 is intended to reflect the entirety of the
offending. By imposing a total sentence of four years' detention we have engaged in some rounding down of what
otherwise would have been the overall sentence.

38. We are very grateful to counsel, particularly Miss Hussain for the assistance they have given us in the course
of this difficult and unhappy sentencing exercise.

39. MR HOLT: My Lord, I believe the police station is Charing Cross. I think it may have been Brixton but I am told
that has closed so it is Charing Cross Police Station.

40. LORD JUSTICE WILLIAM DAVIS: Tomorrow?

41. MR HOLT: Tomorrow by 4.00 pm.

42. LORD JUSTICE WILLIAM DAVIS: Miss Hussain, it is very difficult for you since you are not even in view any
more. The offender will have to surrender the Charing Cross Police Station at 4.00 pm tomorrow to commence that
sentence. We hope you and he will be able to communicate in some way either today or first thing tomorrow.

43. MISS HUSSAIN: Yes, my Lord. I will make sure that that happens.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS


-----

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

