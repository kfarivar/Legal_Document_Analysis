# R v S [2020] All ER (D) 107 (Jun)

[2020] EWCA Crim 765

Court of Appeal, Criminal Division

EnglandandWales

Singh LJ, Holgate J and Judge Lucraft QC (sitting as a judge of the Court of Appeal, Criminal Division)

17 June 2020

**Criminal law – Defence – Victim of trafficking**
Abstract

_[It was not clear that the defendant had fully appreciated that he could mount his defence under s 45 of the Modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_
**_Slavery Act 2015 before a jury notwithstanding the negative view of the Competent Authority. Accordingly, the_**
_Court of Appeal, Criminal Division, admitted fresh evidence that the defendant had been a victim of trafficking and_
_held that his guilty plea to producing a controlled drug of class B (cannabis) could not be allowed to stand, as his_
_conviction was unsafe and an injustice would be done if it were allowed to stand._
Digest

The judgment is available at: [2020] EWCA Crim 765

**Background**

In October 2017, the Competent Authority decided that there were reasonable grounds to believe that the
defendant was a victim of trafficking, in what it described as the reasonable grounds decision. In November, it
decided that there were insufficient grounds to believe that he was, in what it described as the Conclusive Grounds
Decision. In December, the defendant pleaded guilty to producing a controlled drug of class B (cannabis), contrary
[to s 4 of the Misuse of Drugs Act 1971, and was sentenced to 12 months' imprisonment.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0KF-00000-00&context=1519360)

In December 2018, the competent authority decided that the defendant was indeed the victim of trafficking. The
defendant appealed against conviction and sought leave, pursuant to _[s 23 of the Criminal Appeal Act 1968, to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1KR-00000-00&context=1519360)_
introduce fresh evidence from the Competent Authority, to the effect that the defendant was the victim of trafficking.

**Issues and decisions**

[Whether the defendant's guilty plea should be set aside on the basis of s 45 of the Modern Slavery Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)

Permission to adduce the fresh evidence would be granted. On the basis of the evidence, it was not clear that the
defendant had fully appreciated that he could mount his defence under s 45 before a jury notwithstanding the
negative view of the Competent Authority. There was, at the very least, ambiguity about what had been regarded as
'conclusive'. The origin of the confusion might lie in the description which the Competent Authority itself gave such
decisions. It also had to be borne in mind that the defendant had been unable to speak English and had needed the
benefit of an interpreter. Nuances about whether a document which described itself as a 'conclusive grounds
decision' was conclusive against a defendant might be lost even on well-educated lay people who were fluent in
English, let alone a recently arrived foreign national who was not familiar with the language and who had been the


-----

victim of trafficking. That view was reinforced by the fact that, not only the defence team, but the prosecution at that
time had also regarded the view of the Competent Authority as being of critical importance (see [11], [38]-[40] of the
judgment).

In those highly unusual circumstances, the present was one of those most exceptional cases in which the
defendant's guilty plea could not be allowed to stand. His conviction was unsafe and an injustice would be done if it
were allowed to stand (see [41] of the judgment).

_R v Boal_ _[[1992] 3 All ER 177 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49F0-TWP1-61MW-00000-00&context=1519360)_

Bunty Batra (instructed by Wylie Kay Solicitors) for the defendant.

Andrew Johnson (instructed by the Crown Prosecution Service) for the Crown.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

