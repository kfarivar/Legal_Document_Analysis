# R (on the application of LM) v Secretary of State For the Home Department

_[[2021] EWHC 3034 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6435-32N3-GXF6-8412-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 15/11/2021**

# Catchwords & Digest

**IMMIGRATION - HUMAN TRAFFICKING – LACK OF CREDIBILITY**

The Administrative Court dismissed the Albanian claimant’s challenge to the defendant’s negative conclusive
grounds decision in which the defendant concluded that the claimant’s multiple inconsistent and false accounts had
damaged her credibility to the extent that her claim to have been trafficked could not have been believed on a
balance of probabilities. The conclusion on credibility was reached with the defendant’s guidance (the guidance),
[published pursuant to s 49 of the Modern Slavery Act 2015, firmly in mind and was based on a holistic assessment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C273-00000-00&context=1519360)
of all the material. The decision was not structured in such a way that, contrary to the guidance, a conclusion on
credibility was reached before considering whether expert evidence of the claimant’s mental health conditions
provided mitigation. The defendant was also entitled to conclude that the mental health issues could not explain the
inconsistencies between accounts and could be attributed to causes other than trafficking.

# Case History


R (on the application of LM (Albania)) v Secretary of State for the Home Department

_[[2022] EWCA Civ 977, [2022] All ER (D) 65 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65YK-X603-CGX8-0209-00000-00&context=1519360)_
—

R (on the application of LM) v Secretary of State For the Home Department

_[[2021] EWHC 3034 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6435-32N3-GXF6-8412-00000-00&context=1519360)_
Affirming

# Cases considered by this case

MN v Secretary of State for the Home Department; IXU v Secretary of State for the
Home Department (AIRE Centre and another intervening)


15/07/2022

CACivD

15/11/2021

AdminCt

21/12/2020

CACivD


-----

_[[2020] EWCA Civ 1746, [2021] 1 WLR 1956, [2020] All ER (D) 128 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6233-WXB3-GXFD-81YV-00000-00&context=1519360)_
Applied
R (on the application of M) v Secretary of State for the Home Department

_[[2015] EWHC 2467 (Admin), [2015] All ER (D) 310 (Jun)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5H2Y-P3Y1-DYBP-N4XY-00000-00&context=1519360)_
Considered

MA (Somalia) v Secretary of State for the Home Department

_[[2010] UKSC 49, [2011] 2 All ER 65, [2011] INLR 188, (2010) Times, 1 December,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52HJ-R1C1-DYBP-M495-00000-00&context=1519360)_

_[[2010] All ER (D) 258 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:51JF-M6S1-DYBP-N068-00000-00&context=1519360)_
Considered

R (on the application of YH) v Secretary of State for the Home Department

_[[2010] EWCA Civ 116, [2010] 4 All ER 448, [2010] All ER (D) 280 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
Considered

**End of Document**


18/06/2015

AdminCt

24/11/2010

SC

25/02/2010

CACivD


-----

