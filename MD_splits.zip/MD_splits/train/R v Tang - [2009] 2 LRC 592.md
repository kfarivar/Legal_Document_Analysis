# R v Tang [2009] 2 LRC 592

[2008] HCA 39

High Court of Australia

Gleeson CJ, Gummow, Kirby, Hayne, Heydon, Crennan and Kiefel JJ

13–14 May, 28 August 2008

**(1) Criminal law — Slavery offences — Actus reus — Possessing a slave — Exercising powers over a slave**
**— Condition of slavery — Definition — Sex workers — Complainant prostitutes recruited in Thailand to be**
**contract workers in respondent's licensed brothel in Australia — Whether respondent possessing slave or**
**exercising over slave powers attaching to 'the right of ownership' — Statutory provisions implementing**
**international treaty obligations — Whether statutory provisions within legislative power — Criminal Code**
**(Cth), ss 270.1, 270.2, 270.3(1)(a) — International Convention to Suppress the Slave Trade and Slavery 1926,**
**art 1.**

**(2) Criminal law — Slavery offences — Mens rea — Intentionally possessing or using a slave — Sex**
**workers — Complainant prostitutes recruited in Thailand to be contract workers in respondent's licensed**
**brothel in Australia — Whether respondent intentionally possessing slave or exercising powers over slave**
**— Mental element of such offences — Appropriate direction to jury — Whether necessary for prosecution**
**to establish knowledge or belief concerning source of powers exercised over complainants — Criminal**
**Code (Cth), s 270.3(1)(a).**

The respondent was the owner of a licensed brothel in Australia. The five complainants were Thai nationals. They
had all previously worked in the sex industry. They became 'contract workers'. They were recruited in Thailand and
consented to come to Australia to work as prostitutes, on the understanding that, once they had paid off the
contract 'debt' of $45,000, they would have the opportunity to earn money on their own account as prostitutes. They
entered Australia on visas that were obtained illegally and, upon their arrival, they were financially deprived and
vulnerable. The respondent agreed to accept four of the complainants as contract workers in her brothel and to take
up a 70% interest in a syndicate which would 'purchase' the women. While under contract, each complainant was to
work in the respondent's brothel six days per week, serving up to 900 customers over a period of four-to-six
months. While on contract, the complainants' passports and return airfares were retained by the respondent. The
complainants earned nothing in cash while under contract except that, by working on the seventh, 'free', day each
week, they could keep the $50 per customer that would, during the rest of the week, go to offset their contract
debts. Section 270.3(1)(a) of the Criminal Code (Cth) (the Code) made it an offence intentionally to possess a slave
or to exercise over a slave 'any of the

**[*593] other powers attaching to the right of ownership'. The respondent was convicted of five offences of**
intentionally possessing a slave and five offences of intentionally exercising over a slave a power attaching to the
right of ownership, namely the power to use, contrary to s 270.3(1)(a). She was sentenced to a lengthy term of
imprisonment. The respondent appealed to the Court of Appeal, which quashed her convictions and ordered a new
trial on all counts, substantially upon a single ground of criticism of the primary judge's directions to the jury about
the mental element of the offences of possessing or using a slave. The prosecution, by special leave, appealed to
the High Court of Australia. The respondent sought special leave to cross-appeal against the order for a new trial on


-----

the grounds, inter alia, that the Court of Appeal erred in holding that (i) ss 270.1 and 270.3(1)(a) of the Code were
within the legislative power of the Commonwealth and (ii) the offences created by s 270.3(1)(a) extended to the
behaviour alleged in the instant case and were not confined to situations akin to 'chattel slavery' or in which the
complainant was notionally owned by the accused or another at the relevant time.

**HELD: (Kirby J dissenting) Appeal allowed. Cross-appeal dismissed.**

(1) The word 'slave' in s 270.3(1)(a) was not defined. It took its meaning from the definition of 'slavery' in s 270.1.
That definition, in turn, derived from, although it was not identical to, the definition of 'slavery' in art 1 of the
International Convention to Suppress the Slave Trade and Slavery 1926 (the Convention). Because the purpose of
the Convention was to suppress the slave trade and slavery it was directed to both the status of slavery and the
condition of slavery. The status of slavery, in the context of the Convention, was to be understood as referring to a
legal status created by or recognised under relevant municipal law. By contrast, the condition of slavery was to be
understood as referring to a factual state of affairs which did not have to, but might, depend upon recognition by the
relevant municipal legal system. Both that status and that condition were defined in the Convention in identical
terms: as a status or condition of a person over whom any or all of the powers attaching to the right of ownership
were exercised. Such powers included the capacity to make a person an object of purchase, the capacity to use a
person and a person's labour in a substantially unrestricted manner and an entitlement to the fruits of the person's
labour without compensation commensurate to the value of the labour. Each of those powers was of relevance in
the instant case. On the evidence it was open to the jury to conclude that each of the complainants was made an
object of purchase (although in the case of one of them the purchaser was not the respondent); that, for the
duration of the contracts, the owners had a capacity to use the complainants and the complainants' labour in a
substantially unrestricted manner; and that the owners were entitled to the fruits of the complainants' labour without
commensurate compensation. Furthermore, the reference to 'chattel slavery' in the second ground of cross-appeal
was a reference to the legal capacity of an owner to treat a slave as an article of possession, subject to the
qualification that the owner was not allowed to kill the slave. Without doubt, chattel slavery fell within the definition in
art 1 of the Convention, but

**[*594] the definition was not limited to that form of slavery. It was important not to debase the currency of**
language, or to banalise crimes against humanity, by giving slavery a meaning that extended beyond the limits set
by the text, context, and purpose of the Convention. In particular, it was important to recognise that harsh and
exploitative conditions of labour did not of themselves amount to slavery. Although the definition of 'slavery' in s
270.1 was plainly based on the definition in the Convention, the wording was not identical. Firstly, s 270.1 referred
to 'condition', not 'status or condition'. The explanation for the difference appeared from s 270.2. There was no
status of slavery under Australian law. Legal ownership of a person was impossible. Consequently s 270.1, in its
application to conduct within Australia, was concerned with de facto slavery. In s 270.1, the reference to powers
attaching to the right of ownership, which were exercised over a person in a condition described as slavery, was a
reference to powers of such a nature and extent that they were attributes of effective (although not legal, for that
was impossible) ownership. Secondly, s 270.1 made it plain that a condition that resulted from a debt or a contract
was not, on that account alone, to be excluded from the definition, provided that it would otherwise be covered by it.
In the result, the definition of 'slavery' in s 270.1 fell within the definition in art 1 of the Convention, and the relevant
provisions of the Code were reasonably capable of being considered appropriate and adapted to give effect to
Australia's obligations under that Convention. They were sustained by the external affairs power. They were not
limited to chattel slavery. Furthermore, consent was not inconsistent with slavery. For the purpose of s 270.3(1)(a)
of the Code, the commodification of an individual by treating him or her as an object of sale and purchase, if it
existed, was a material factor when a tribunal of fact came to assess the circumstances of a case and might involve
the exercise of a power attaching to a right of ownership. The facts alleged in the instant case were capable of
being regarded as within the scope of s 270.3(1)(a) and there was evidence to go to a jury that was capable of
sustaining verdicts of guilty. Accordingly, the cross-appeal was dismissed (see paras [20]–[21], [26]–[27], [30]–[36],

[45], [57], [60], [67], [84], [112], [130], [132], [136], [169]–[171], below). Prosecutor v Kunarac (Case No IT-96–23-T
& IT-96–23/1-T, 22 February 2001) (Trial Chamber); (Case No IT-96–23 & IT-96–23/1-A, 12 June 2002) (Appeals
[Chamber), ICTFY and Siliadin v France (2005) 20 BHRC 654 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)


-----

Per Kirby J. The definition of 'slavery' in s 270.1 of the Code and the consequential offences in s 270.3(1)(a) were
reasonably proportionate to a law giving effect to Australia's obligations under the 1926 Slavery Convention; the
challenge to the constitutional validity of the contested provisions of the Code, as barely arguable (see para [84],
below). XYZ v Commonwealth (2006) 227 CLR 532 applied.

Per Hayne J. It was open to the jury at the respondent's trial to find that each complainant was a person over whom
was exercised, by the respondent, one or more powers attaching to the right of ownership. The way in which all five
women were treated in Australia by setting them to work as they did, on the terms that they did, coupled with the
restraints on their movement and freedom of other action, permitted a jury to conclude that what the

**[*595] respondent did, when she took up a 'share' in four of the women, was to buy them as if they were articles of**
trade or commerce and thereafter possess and use them. What was done with respect to the fifth of the
complainants could be understood as her 'owners' giving the respondent the right to possess her and use her.
Those who exercised over the fifth complainant the powers attaching to the right of ownership carved out of that
'ownership', and disposed of to the respondent, subsidiary possessory 'rights' over the woman. What permitted the
conclusion, in respect of each complainant, that she had been bought and sold as if an article of trade or commerce
and thereafter possessed and used by the respondent, was the combination of the evidence about the treatment of
each in Australia with the evidence of sale and purchase in Thailand. The practical impediments and economic
consequences for each woman, if she refused to complete her performance of the arrangement, were such as
permitted the jury to conclude that, if there were choices to be made about those matters, they were to be made by
others. In this case the evidence permitted the conclusion that the respondent used and possessed each
complainant as a slave because it permitted the conclusion, in each case, that the respondent used and possessed
the complainant as an item of property at the disposal of those who had bought the complainant regardless of any
wish she might have. Assuming that each of the women was to be taken to have voluntarily agreed to be the
subject of sale and purchase, her assent did not deny that the result of the transaction to which each agreed was
her subjection to the dominion of her purchasers (see paras [163]–[168], below).

Per curiam. Per Hayne J. (i) The condition of slavery (which is what provides the content of the term 'a slave') is
defined as the condition of a person over whom any or all of the powers attaching to the right of ownership are
exercised. It thus follows that proof of the intentional exercise of any of the relevant powers over a person suffices
to establish both that the victim is a slave and that the accused has done what the legislation prohibits (see para

[145], below).

(ii) In inquiring whether the person concerned was deprived of freedom of choice in some relevant respect and, if
so, what it was that deprived the person of choice, some assistance was to be had from US decisions about
legislation giving effect to the Thirteenth Amendment to the US Constitution (see paras [149]–[155], below). US v
_Shackney_ (1964) 333 F 2d 475, _US v Mussry (1984) 726 F 2d 1448 and_ _US v Kozminski (1988) 487 US 931_
considered.

(2) (Kirby J dissenting) Section 270.3(1)(a) made it an offence intentionally to possess a slave or to exercise over a
slave any of the other powers attaching to the right of ownership. The central issue in the appeal concerned what
directions should have been given to the jury at the respondent's trial about the mental element of the offences of
possessing or using a slave. What was to be proved was the intentional possession and use of each complainant
as a slave, which was to say as a person over whom any or all of the powers attaching to the right of ownership
were exercised. The relevant fault element of each of the offences with which the respondent was charged was
intention. The conduct in question was possessing a slave or using a slave. To establish the relevant fault element
it was necessary to show that the respondent meant

**[*596] to engage in the conduct, in respect of each complainant, of exercising powers attaching to the right of**
ownership. The critical powers the exercise of which was disclosed (or the exercise of which a jury reasonably
might find disclosed) by the evidence were the power to make the complainants an object of purchase, the capacity,
for the duration of the contracts, to use the complainants and their labour in a substantially unrestricted manner, the
power to control and restrict their movements and the power to use their services without commensurate
compensation. As to the last three powers, their extent, as well as their nature, was relevant. As to the first, it was


-----

capable of being regarded by a jury as the key to an understanding of the condition of the complainants. The
evidence could be understood as showing that they had been bought and paid for and that their commodification
explained the conditions of control and exploitation under which they were living and working. Contrary to the
holding of the Court of Appeal, it was not necessary for the prosecution to establish that the respondent had any
knowledge or belief concerning the source of the powers exercised over the complainants. Accordingly, the ground
on which the Court of Appeal regarded the primary judge's directions as inadequate had not been sustained. It
followed that the appeal would be allowed (see paras [43], [48], [50]–[52], [57], [60], [132]–[134], [169]–[171],
below).

Per Hayne J. In the criminal law, 'possession', one particular power attaching to the right of ownership, implied a
state of mind with respect to the thing possessed and was best understood as referring to a state of affairs in which
there was the 'intentional exercise of physical custody or control over something'. Under s 270.3(1)(a) of the Code,
however, it was also important to recognise that the right to possess a subject matter, coupled with a power to
carve out and dispose of subsidiary possessory rights, was an important element in that aggregation of powers over
a subject matter that was commonly spoken of as 'ownership' (see paras [146]–[147], below). Dicta of Brennan J
and Dawson J in He Kaw Teh v R _[[1986] LRC (Crim) 553 at 604–605, 615 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_

Per Kirby J (dissenting). The approach of the Court of Appeal to the 'critical issue'—concerning the accuracy and
adequacy of the directions given to the jury involving the meaning and application of the provisions of the Code that
defined the offences with which the respondent was charged and the content of the 'fault elements'—had been
correct and the appeal should be dismissed. That approach was more consonant with: the proper analysis of the
Code; the basic doctrine of criminal law in Australia, against the background of which the Code was written, on the
operation of 'intention' in respect of serious criminal offences; the principles of interpretation applicable to the
legislation in question; a proper view of the relationship between the Code provisions and the international law that
they sought to apply in Australia and the various other considerations of legal principle and policy to which regard
might properly be had. Under s 270.3(1) it was not enough for the accused to 'possess' a slave or to 'exercise' over
a slave 'any of the other powers attaching to the right of ownership': to be guilty the accused had to do these things,
and all of them, 'intentionally'. The 'intention' was not simply an 'intention' addressed to the 'physical elements'
concerned with 'possession' or the

**[*597] exercise of powers attaching to the 'right of ownership', it was also an intention directed to the underlying**
entitlement that gave rise to those elements. To exercise such a power, as if over property that the person owned or
possessed, it was inherent that the person deploying that power did so based upon a notion of that person's
entitlement to act as he or she did. It was essential for the 'fault element' of 'intention' to be applied to all, and not
just _some, of the ingredients of the offences and to be accurately and clearly explained to the jury. That had not_
been done. The respondent's trial miscarried and there should be a new trial (see paras [65], [67], [84]–[85], [93],

[95], [99], [102]–[104], [108]–[109], [127]–[131], below).

Per curiam. Per Kirby J. To the extent that the intention element is restricted to conduct in relation to a person, with
no attention being given to the perpetrator's intention, there is a serious risk of over-expansion of the notion of
'slavery'. Similarly, there is a great need to not over-extend 'slavery offences' to apply to activities such as seriously
oppressive employment relationships (see paras [113], [117], below.

[Editors' note: Section 270 of the Criminal Code (Cth), so far as material, is set out at para [3], below.

Article 1 of the International Convention to Suppress the Slave Trade and Slavery 1926 is set out at para [23],
below.]
**Cases referred to in judgments**

_Adelaide Company of Jehovah's Witnesses Inc v Commonwealth [1943] HCA 12, (1943) 67 CLR 116, Aus HC_

_Ahern v R [1988] HCA 39, (1988) 165 CLR 87, Aus HC_

_AK v Western Australia [2008] HCA 8, (2008) 82 ALJR 534, Aus HC_


-----

_Alford v Magee [1952] HCA 3, (1952) 85 CLR 437, Aus HC_

_Bank of NSW v Commonwealth [1948] HCA 7, (1948) 76 CLR 1, Aus HC_

_Bernal v US (1917) 241 F 339, US Ct of Apps (5th Cir)_

_Blackadder v Ramsey Butchering Services Pty Ltd [2005] HCA 22, (2005) 221 CLR 539, Aus HC_

_Bodyline Spa and Sauna (Sydney) Pty Ltd v South Sydney City Council (1992) 77 LGRA 432_

_Central Bayside General Practice Association Ltd v Commissioner of State Revenue (Vic) [2006] HCA 43, (2006)_
228 CLR 168, Aus HC

_Clyatt v US (1905) 197 US 207, US SC_

_[R v CTM [2008] HCA 25, [2008] 5 LRC 44, (2008) 82 ALJR 978, Aus HC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-84CK-00000-00&context=1519360)_

_Davis v US (1926) 12 F 2d 253, US Ct of Apps (5th Cir)_

_Doggett v R [2001] HCA 46, (2001) 208 CLR 343, Aus HC_

_[Forbes v Cochrane (1824) 2 B & G 448, [1824–34] All ER Rep 48](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDK0-TWXJ-20NJ-00000-00&context=1519360)_

_He Kaw Teh v R_ _[[1986] LRC (Crim) 553, (1985) 157 CLR 523, Aus HC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_

_[Lange v Australian Broadcasting Corpn [1997] 4 LRC 192, (1997) 2 BHRC 513, (1997) 189 CLR 520, Aus HC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-83HX-00000-00&context=1519360)_

_Loty and Holloway and Australian Workers' Union, Re [1971] AR (NSW) 95_

_M v R [1994] HCA 63, (1994) 181 CLR 487, Aus HC_

_[Melbourne v R [2000] 2 LRC 294, Aus HC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-84G0-00000-00&context=1519360)_

**[*598] Mulholland v Australian Electoral Commission [2004] HCA 41, (2004) 220 CLR 181, Aus HC**

_Murphy v Farmer [1988] HCA 31, (1988) 165 CLR 19, Aus HC_

_New South Wales v Commonwealth (Work Choices Case) [2006] HCA 52, (2006) 229 CLR 1, Aus HC_

_Northern Territory of Australia v Arnhem Land Aboriginal Land Trust [2008] HCA 29, Aus HC_

_Parker v R [1997] HCA 15, (1997) 186 CLR 494, Aus HC_

_Pierce v US (1944) 146 F 2d 84, US Ct of Apps (5th Cir)_

_Prosecutor v Kunarac (Case No IT-96–23-T & IT-96–23/1-T, 22 February 2001) (Trial Chamber); (Case No IT-96–_
23 & IT-96–23/1-A, 12 June 2002) (Appeals Chamber), ICTFY

_R v Barlow [1997] HCA 19, (1997) 188 CLR 1, Aus HC_

_R v Bow Street Metropolitan Stipendiary Magistrate, ex p Pinochet Ugarte (No 3)_ (Amnesty International
_[intervening) [1999] 1 LRC 482, [1999] 2 All ER 97, [2000] 1 AC 147, UK HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-83YV-00000-00&context=1519360)_

_R v Decha-Iamsakun [1993] 1 NZLR 141, NZ CA_

_R v DS (2005) 191 FLR 337, Vic CA_

_R v Saengsai-Or (2004) 61 NSWLR 135, NSW SC_


-----

_R v Tolson_ _[(1889) 23 QBD 168, [1886–90] All ER Rep 26](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V1D-FPY2-8T41-D2JT-00000-00&context=1519360)_

_Residual Assco Group Ltd v Spalvins [2000] HCA 33, (2000) 202 CLR 629, Aus HC_

_[Siliadin v France (2005) 20 BHRC 654, ECt HR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

_Smith v Gould (1706) 2 Salk 666, 91 ER 567_

_Somerset v Stewart_ _(1772) Lofft 1, 98 ER 499_

_US v Ingalls (1947) 73 F Supp 76, S Cal_

_US v Kozminski (1988) 487 US 931, US SC_

_US v Mussry (1984) 726 F 2d 1448, US Ct of Apps (9th Cir)_

_US v Shackney (1964) 333 F 2d 475, US Ct of Apps (2nd Cir)_

_Vallance v R [1961] HCA 42, (1961) 108 CLR 56, Aus HC_

_Victoria v Commonwealth (Industrial Relations Act Case) [1996] HCA 56, (1996) 187 CLR 416, Aus HC_

_Weiss v R [2005] HCA 81, (2005) 224 CLR 300, Aus HC_

_[Woolmington v DPP [1935] AC 462, [1935] All ER Rep 1, UK HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-20DC-00000-00&context=1519360)_

_XYZ v Commonwealth [2006] HCA 25, (2006) 227 CLR 532, Aus HC_

_Yanner v Eaton [1999] HCA 53, (1999) 201 CLR 351, Aus HC_

_Zoneff v R [2000] HCA 28, (2000) 200 CLR 234, Aus HC_
**Legislation referred to in judgmentsAustralia**

Constitution, s 51(xxix), (xxxv)

Crimes Act 1958 (Vic), s 568(1)

Criminal Code Amendment (Slavery and Sexual Servitude) Act 1999 (Cth)

Criminal Code, ss 2–5, 268, 270–271

Migration Act 1958 (Cth) and Regulations

Prostitution Control Act 1994 (Vic)

_[Slave Trade Act 1824 (Imp)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B1N0-TWPY-Y08J-00000-00&context=1519360)_

**[[*599] Slave Trade Act 1843 (Imp)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GTP0-TWPY-Y0KK-00000-00&context=1519360)**

_[Slave Trade Act 1873 (Imp)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9230-TWPY-Y03B-00000-00&context=1519360)_

_[Slavery Abolition Act 1833 (Imp)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y0S9-00000-00&context=1519360)_
_New Zealand_

Crimes Act 1961, s 98(1)
_United States_

Constitution 1787, Thirteenth Amendment, ss 1–2


-----

**Other sources referred to in judgments**

Allain 'A Legal Consideration of “Slavery” in Light of the _Travaux Préparatoires_ of the 1926 Convention', paper
delivered at the conference Twenty-First Century Slavery: Issues and Responses (23 November 2006)

Allain 'The Definition of “Slavery” in General International Law and the Crime of Enslavement within the Rome
Statute', paper delivered at the International Criminal Court, _Guest Lecture Series of the Office of the Prosecutor_
(26 April 2007) pp 12–13

Allain _The Slavery Conventions: The Travaux Préparatoires of the 1926 League of Nations Convention and the_
_1956 United Nations Convention (2008)_

Australia. Senate. Parliamentary Debates (Hansard), 24 March 1999 at 3076

Australian Law Reform Commission Criminal admiralty jurisdiction and prize (Report No 48, 1990), pp 72–92

Bassiouni 'Enslavement as an International Crime' (1991) 23 NYUJIL & Pol 445 at 448

Bassiouni Crimes Against Humanity in International Criminal Law (2nd rev edn, 1999) p 212

Criminal Code Amendment (Slavery and Sexual Servitude) Bill 1999 (Cth), Explanatory Memorandum

Dorevitch and Foster 'Obstacles on the Road to Protection: Assessing the Treatment of Sex-Trafficking Victims
under Australia's Migration and Refugee Law' (2008) 9 Melb JIL 1 at 8, 10, 19–20, 38–39, 44–45

Drew 'Human Trafficking: A modern form of slavery?' (2002) 7 EHRLR 481 at 481

Gostin and Lazzarini Human Rights and Public Health in the AIDS Pandemic (1997) pp 50–51, 124–125

Halley 'Rape in Berlin: Reconsidering the Criminalisation of Rape in the International Law of Armed Conflict' (2008)
9 Melb JIL 78 at 113

Hannikainen Peremptory Norms (Jus Cogens) in International Law (1988) pp 446–447

Hathaway 'The Human Rights Quagmire of “Human Trafficking” ' (2008) 49 Vir JIL 1

Henkin International Law: Politics and Values (1995) p 39

International Convention to Suppress the Slave Trade and Slavery 1926 (212 UNTS 17), art 1

International Labour Office (Belser, de Cock and Mehran) _ILO Minimum Estimate of Forced Labour in the World_
(2005) at 4–6

International Labour Office Trafficking in Human Beings: New Approaches to Combating the Problem (2003) at 6

**[*600] Jennings and Watts (eds) Oppenheim's International Law (9th edn, 1992) vol 1, Pts 2 to 4, §429**

Lacey, Wells and Meure Reconstructing Criminal Law (1990) pp 357–368

Levchenko _Combat of Trafficking in Women for the Purpose of Forced Prostitution—Ukraine_ (Country Report)
(1999) at 23

Meron Human Rights and Humanitarian Norms as Customary Law (1989) pp 20–21

Model Criminal Code Officers Committee of the Standing Committee of Attorneys General Model Criminal Code,
_Chapter 9, Offences Against Humanity: Slavery Report (1998) p 29_


-----

Protocol to Prevent, Suppress and Punish Trafficking in Persons, Especially Women and Children, Supplementing
the United Nations Convention Against Transnational Organized Crime 2000, art 3

Rome Statute of the International Criminal Court (2187 UNTS 90), art 7(2)(c)

Schachter International Law in Theory and Practice (1991) p 343

Simpson Law, War and Crime: War Crimes Trials and the Reinvention of International Law (2007) p 159

Supplementary Convention on the Abolition of Slavery, the Slave Trade, and Institutions and Practices similar to
Slavery 1956 (266 UNTS 3), arts 1, 7

Tessier 'The New Slave Trade: The International Crisis of Immigrant Smuggling' (1995) 3 Indiana Journal of Global
Legal Studies 261 at 261–262

United Kingdom. Committee on Homosexual Offences and Prostitution _Report of the Committee on Homosexual_
_Offences and Prostitution (1957) Cmnd 247, para 286 ('the Wolfenden Report')_

United Nations Economic and Social Council Contemporary Forms of Slavery UN Doc E/CN.4/Sub.2/2000/3 (2000)
at para 48

United Nations Economic and Social Council Slavery The Slave Trade, and Other Forms of Servitude, Report of the
Secretary General, UN Doc E/2357 (1953), p 28

Vienna Convention on the Law of Treaties 1969, art 53
**Appeal and cross-appeal**

The Crown, by special leave, appealed and the respondent, Wei Tang, sought special leave to cross-appeal, from a
judgment (R v Wei Tang (2007) 16 VR 454) of the Court of Appeal of the Supreme Court of Victoria upholding the
respondent's appeal against conviction following a trial in the County Court of Victoria, before Judge McInerney, of
five offences of intentionally possessing a slave, and five offences of intentionally exercising over a slave a power
attaching to the right of ownership, namely the power to use, contrary to s 270.3(1)(a) of the Criminal Code (Cth),
and ordering a new trial on all counts. The Attorney General of the Commonwealth and the Human Rights and
Equal Opportunity Commission intervened. The facts are set out in the judgment of Gleeson CJ.

_W J Abraham QC and R R Davis for the appellant._

_N J Young QC, M J Croucher and K L Walker for the respondent._

_D M J Bennett QC (Solicitor-General of the Commonwealth) and S P Donaghue for the Attorney General of the_
Commonwealth, intervening.

**[*601] B W Walker SC and R Graycar for the Human Rights and Equal Opportunity Commission, intervening.**

28 August 2008. The following judgments were delivered.

**GLEESON CJ.**

[1] Following a trial in the County Court of Victoria, before Judge McInerney and a jury, the respondent was
convicted of five offences of intentionally possessing a slave and five offences of intentionally exercising over a
slave a power attaching to the right of ownership, namely the power to use, contrary to s 270.3(1)(a) of the Criminal
Code (Cth) ('the Code'). She was sentenced to a lengthy term of imprisonment. The Court of Appeal of the
Supreme Court of Victoria upheld an appeal against each of the convictions, quashed the convictions and ordered a
new trial on all counts (R v Wei Tang (2007) 16 VR 454). The prosecution, by special leave, has appealed to this
court. The respondent seeks special leave to cross-appeal against the order for a new trial.

[2] The Court of Appeal rejected a number of grounds of appeal which, if upheld, would have resulted in an acquittal
on all counts It upheld one ground of appeal which complained that the directions given to the jury were


-----

inadequate. The proposed cross-appeal raises three grounds. The first two grounds concern the meaning and
constitutional validity of s 270.3(1)(a). Both grounds were rejected by the Court of Appeal. Logically, a consideration
of those grounds should come before consideration of the Court of Appeal's decision on the directions given to the
jury. Special leave to cross-appeal on those two grounds should be granted. It will be convenient to deal with them
before turning to the prosecution appeal. It is also convenient to leave to one side for the moment the proposed
third ground of cross-appeal, which is that the Court of Appeal erred in failing to hold that the jury verdicts were
unreasonable or could not be supported having regard to the evidence.
**The legislation**

[3] Chapter 8 of the Code deals with 'Offences against humanity'. It includes Div 270, which deals with 'Slavery,
sexual servitude and deceptive recruiting'. Division 270, which was introduced by the Criminal Code Amendment
(Slavery and Sexual Servitude) Act 1999 (Cth), was based on recommendations made by the Australian Law
Reform Commission in 1990 (Australian Law Reform Commission Criminal admiralty jurisdiction and prize Report
No 48, (1990) at pp 72–92). It includes the following:

'270.1 Definition of slavery

For the purposes of this Division, _slavery is the condition of a person over whom any or all of the powers_
attaching to the right of ownership are exercised, including where such a condition results from a debt or
contract made by the person.

270.2 Slavery is unlawful

**[*602] Slavery remains unlawful and its abolition is maintained, despite the repeal by the** _Criminal Code_
_Amendment (Slavery and Sexual Servitude) Act 1999 of Imperial Acts relating to slavery._

270.3 Slavery offences

(1) A person who, whether within or outside Australia, intentionally:

(a) possesses a slave or exercises over a slave any of the other powers attaching to the right of ownership; or

(b) engages in slave trading; or

(c) enters into any commercial transaction involving a slave; or

(d) exercises control or direction over, or provides finance for:

(i) any act of slave trading; or

(ii) any commercial transaction involving a slave;

is guilty of an offence.

Penalty: Imprisonment for 25 years.

(2) A person who:

(a) whether within or outside Australia:

(i) enters into any commercial transaction involving a slave; or

(ii) exercises control or direction over, or provides finance for, any commercial transaction involving a slave; or

(iii) exercises control or direction over, or provides finance for, any act of slave trading; and

(b) is reckless as to whether the transaction or act involves a slave, slavery or slave trading;


-----

is guilty of an offence.

Penalty: Imprisonment for 17 years.

(3) In this section:

_slave trading includes:_

(a) the capture, transport or disposal of a person with the intention of reducing the person to slavery; or

(b) the purchase or sale of a slave.

(4) A person who engages in any conduct with the intention of securing the release of a person from slavery is
not guilty of an offence against this section.

(5) The defendant bears a legal burden of proving the matter mentioned in subsection (4).'

[4] Later, at a time after the alleged offences the subject of these proceedings, a further offence described as 'debt
bondage' was added to Ch 8 (s 271.8). That offence carries a lesser maximum penalty than an offence against s
270.3. It may be that the facts of this case would have fallen within s 271.8 had it been in force. If so, that is
immaterial. There are many statutes, Commonwealth and state, which create offences of such a kind that particular
conduct may fall within both a more serious and a less serious offence. There is a question, to be considered,
whether the facts alleged in this case fall within s 270.3. If they had occurred at a later time, they might also have
fallen within s 271.8. The two provisions are not mutually exclusive.

[5] It is necessary also to refer to Ch 2 of the Code. It includes the following:

'Chapter 2—General principles of criminal responsibility

**[*603] Part 2.1—Purpose and application**

Division 2

2.1 Purpose

_The purpose of this Chapter is to codify the general principles of criminal responsibility under laws of the_
_Commonwealth. It contains all the general principles of criminal responsibility that apply to any offence,_
irrespective of how the offence is created …

Part 2.2—The elements of an offence

Division 3—General

3.1 Elements

(1) An offence consists of physical elements and fault elements.

(2) However, the law that creates the offence may provide that there is no fault element for one or more
physical elements.

(3) The law that creates the offence may provide different fault elements for different physical elements.

3.2 Establishing guilt in respect of offences

In order for a person to be found guilty of committing an offence the following must be proved:

(a) the existence of such physical elements as are, under the law creating the offence, relevant to establishing
guilt;


-----

(b) in respect of each such physical element for which a fault element is required, one of the fault elements for
the physical element …

Division 4—Physical elements

4.1 Physical elements

(1) A physical element of an offence may be:

(a) conduct; or

(b) a result of conduct; or

(c) a circumstance in which conduct, or a result of conduct, occurs.

(2) In this Code:

_conduct means an act, an omission to perform an act or a state of affairs._

_engage in conduct means:_

(a) do an act; or

(b) omit to perform an act.

4.2 Voluntariness

(1) Conduct can only be a physical element if it is voluntary.

(2) Conduct is only voluntary if it is a product of the will of the person whose conduct it is …

4.3 Omissions

An omission to perform an act can only be a physical element if:

(a) the law creating the offence makes it so; or

(b) the law creating the offence impliedly provides that the offence is committed by an omission to perform an
act that by law there is a duty to perform.

Division 5—Fault elements

5.1 Fault elements

(1) A fault element for a particular physical element may be intention, knowledge, recklessness or negligence.

**[*604] (2) Subsection (1) does not prevent a law that creates a particular offence from specifying other fault**
elements for a physical element of that offence.

5.2 Intention

(1) A person has intention with respect to conduct if he or she means to engage in that conduct.

(2) A person has intention with respect to a circumstance if he or she believes that it exists or will exist.

(3) A person has intention with respect to a result if he or she means to bring it about or is aware that it will
occur in the ordinary course of events.

5.3 Knowledge


-----

A person has knowledge of a circumstance or a result if he or she is aware that it exists or will exist in the
ordinary course of events.

5.4 Recklessness

(1) A person is reckless with respect to a circumstance if:

(a) he or she is aware of a substantial risk that the circumstance exists or will exist; and

(b) having regard to the circumstances known to him or her, it is unjustifiable to take the risk.

(2) A person is reckless with respect to a result if:

(a) he or she is aware of a substantial risk that the result will occur; and

(b) having regard to the circumstances known to him or her, it is unjustifiable to take the risk.

(3) The question whether taking a risk is unjustifiable is one of fact.

(4) If recklessness is a fault element for a physical element of an offence, proof of intention, knowledge or
recklessness will satisfy that fault element.

5.5 Negligence

A person is negligent with respect to a physical element of an offence if his or her conduct involves:

(a) such a great falling short of the standard of care that a reasonable person would exercise in the
circumstances; and

(b) such a high risk that the physical element exists or will exist;

that the conduct merits criminal punishment for the offence.

5.6 Offences that do not specify fault elements

(1) If the law creating the offence does not specify a fault element for a physical element that consists only of
conduct, intention is the fault element for that physical element.

(2) If the law creating the offence does not specify a fault element for a physical element that consists of a
circumstance or a result, recklessness is the fault element for that physical element.'

**The background**

[6] The respondent was the owner of a licensed brothel at 417 Brunswick Street, Fitzroy known as Club 417. The
ten counts in the indictment contained two charges (possessing and using) under s 270.3(1)(a) in relation to each of
five women (sometimes described as the complainants). The women

**[*605] were Thai nationals. They all came to Australia to work as prostitutes. They had all previously worked in**
what was described as the sex industry. They became 'contract workers'. There was no written contract, but there
were agreed conditions. Each complainant came to Australia voluntarily.

[7] In an appeal to the Court of Appeal of Victoria by a woman, DS, who originally had been a co-accused of the
respondent, Chernov JA described the practice that was followed (R v DS (2005) 191 FLR 337 at [6]):

'The organisers in Australia arranged for an appropriate visa to be issued to a [complainant], no doubt on the
basis of false information being provided to the immigration authorities. Sometimes that required funds to be
deposited temporarily in a bank account in the name of the [complainant] in order to ensure that her visa could
be obtained. The woman was then flown to Sydney from Bangkok, “escorted” by one or two people, usually an
elderly couple (so as not to arouse suspicion as to the [complainant's] real purpose in coming to Australia)


-----

Generally, once the [complainant] arrived here she was treated as being “owned” by those who had procured
her passage. The [complainant] would be met at the airport by a representative of the Australian “owner”, who
would pay off the “escorts” and take the [complainant] to an apartment or hotel in Sydney and keep her there
until a decision was made as to the brothel at which she was to work.'

**The 'purchase' of the complainants and the 'debts' incurred by them**

[8] DS gave evidence at the trial of the respondent. DS's involvement included negotiating with people in Thailand
who recruited the women, and settling the women in brothels in Australia (R v DS (2005) 191 FLR 337 at [7]). In her
evidence in the trial of the respondent, DS described the process that was followed in relation to one of the
complainants, once she had arrived in Australia. She gave a similar account in relation to three of the other
complainants. After receiving a telephone call from the woman's 'boss', DS collected this particular complainant
from a hotel. She then contacted the respondent, who agreed to accept the complainant as a contract worker in her
brothel, and who also agreed to take up a 70% interest in a syndicate which would 'purchase' the woman, DS and
her associates taking up the other 30%. The syndicate agreed to pay the 'boss' the sum of $20,000. That sum was
described by DS as 'the amount for this girl', 'the amount of money we purchased this woman' and 'the money for
purchasing women from Thailand to come here'. The $20,000 was sent to Thailand.

[9] An amount of $110 was to be charged to customers for the complainant's services. It was agreed that the
respondent would retain $43 in her capacity as brothel owner. The remaining $67 was divided between the 'owners'
of the complainant. In this case, the respondent retained 70% of $67 and DS and her associates took 30%.

[10] The complainant acknowledged a 'debt' to the syndicate in an amount of $45,000. For each customer serviced,
the complainant's 'debt' would be reduced by $50. In the particular case, the amount of the debt was the subject

**[*606] of subsequent negotiation between DS, the respondent and the complainant. DS said:**

'It was agreed in Sydney that the debt would be $45,000, but [the complainant] was not happy to pay that
amount. So, I asked [the respondent] if she could review the amount on her. So, it was finally agreed that the
amount would be I'm not sure $43,000 or $42,000.'

It was also agreed that there would be a 'free day' for the complainant. On that day, the complainant retained $50
per customer and $17 was divided between the syndicate members (70% to the respondent and 30% to DS and
her associates). The respondent was also paid $43 per customer, in her capacity as owner of the brothel. Prior to
coming to Australia the complainants were not always aware of the precise terms of the debt or of the living
conditions in Australia.

[11] There were five complainants. All of them consented to come to Australia to work, on the understanding that,
once they had paid off their 'debt', they would have the opportunity to earn money on their own account as
prostitutes. Upon their arrival the women had very little, if any, money in their possession, spoke little, if any,
English, and knew no one.

[12] Four of the complainants went to work in the respondent's brothel in the circumstances described above. In
respect of each of those four complainants, the respondent had a share in a syndicate which, according to DS,
'purchased' the complainant for $20,000. The contract 'debt' was $45,000, or, in the particular case earlier
mentioned, $42,000 or $43,000. In his remarks on sentencing, which were based on the evidence that went to the
jury, the trial judge said that this sum took account of the $20,000 paid to the recruiters in Thailand, as well as costs
of travel and the complainant's living expenses during the term of the contract. It included a profit margin, but the
margin was not the subject of any calculation. The 'debt' was a notional liability by reference to which aspects of the
complainant's obligations were regulated. It was the amount she had to work off, at the rate of $50 per customer,
under her 'contract'. Two of the complainants ultimately worked off their debts, and were thereafter paid for their
prostitution.

[13] The respondent herself paid nothing to the recruiters in the case of the fifth complainant. The evidence was
that, after the fifth complainant was brought to Australia, she worked for others at a different brothel. Later, DS
arranged for her to work at the respondent's brothel. The arrangements in relation to the fifth complainant were the


-----

same as for the other four, save that she had different 'owners'. DS's evidence was that, in relation to the $110 paid
by each of the fifth complainant's customers, the respondent retained $43 as brothel owner and the remaining $67
would be paid to DS, who divided the amount between that complainant's owners. The fifth complainant's 'debt' of
$45,000 also was being worked off at the rate of $50 per customer.

[14] In summary, then, while under contract, each complainant was to work in the respondent's brothel in
Melbourne six days per week, serving up to 900 customers over a period of four to six months. The complainants
earned nothing in cash while under contract except that, by working on the seventh, 'free', day each week, they
could keep the $50 per customer that would,

**[*607] during the rest of the week, go to offset their contract debts.**
**The conditions of the complainants**

[15] The trial judge said in his sentencing remarks that he was satisfied on the evidence that the complainants were
financially deprived and vulnerable upon arriving in Australia. He found that the complainants entered Australia on
visas that were obtained illegally. Continued receipt of the benefits of the complainants' contracts depended on their
not being apprehended by immigration authorities. The benefits were more certain to be obtained when the
complainants were kept hidden.

[16] While on contract, the complainants' passports and return airfares were retained by the respondent. This was
done so that the passports could be produced to immigration authorities if necessary, and also so that the
complainants could not run away. The complainants lived in premises arranged by the respondent, where they were
lodged and fed, and their medical requirements attended to. The evidence was that the complainants were wellprovisioned, fed and provided for. The complainants were not kept under lock and key. Nevertheless, the trial judge
said that, in the totality of the circumstances, the complainants were effectively restricted to the premises. On rare
occasions they ventured out with consent or under supervision. The circumstances to which the trial judge referred
included the hours of work involved, as well as control by way of fear of detection from immigration authorities, fear
of visa offences, advice to be aware of immigration authorities, advice to tell false stories to immigration authorities
if apprehended and instructions not to leave their accommodation without the respondent, DS or the manager of the
brothel. In the case of some of the contract workers, the regime became more relaxed as the contract progressed
and, towards the end of their contracts, they were at liberty to go out as they wished. At work, the trial judge found
that, while they were occasionally permitted to go out to shop, the complainants were, because of the nature and
hours of their work, effectively restricted to the premises.

[17] In the case of the two complainants who ultimately paid off their debts, the restrictions that had been placed on
them were then lifted, their passports were returned and they were free to choose their hours of work and their
accommodation.

[18] In addition to the restrictions that were placed on the complainants, the prosecution pointed to the demands
placed upon them as to the numbers of clients they were required to service, their lack of payment, and the days
and hours they were required to work as demonstrating that their situation differed materially from that of other sex
workers who, however exploited they may have been, were not slaves. The Court of Appeal accepted that the
evidence was capable of supporting the jury verdicts, which were held not to have been unreasonable.
**The meaning and validity of s 270.3(1)(a)**

[19] The first two grounds of the respondent's proposed cross-appeal are that: (1) the Court of Appeal erred in
holding that ss 270.1 and 270.3(1)(a) of the Code were within the legislative power of the Commonwealth and (2)
the

**[*608] Court of Appeal erred in holding that the offences created by s 270.3(1)(a) extended to the behaviour**
alleged in the present case and that they were not confined to situations akin to 'chattel slavery' or in which the
complainant is notionally owned by the accused or another at the relevant time.

[20] As to ground (1), the Court of Appeal held that the relevant provisions of the Code were enacted pursuant to,
and sustained by, the power of the Parliament to make laws with respect to external affairs (Constitution, s


-----

51(xxix)). As to ground (2), the Court of Appeal held that s 270.3(1)(a) was not confined to what is sometimes called
'chattel slavery'. Presumably, the reference in ground (2) to 'situations akin to' chattel slavery, and to notional
ownership, was prompted by the consideration that chattel slavery is, in Australia, a legal impossibility. If s
270.3(1)(a), in its application to conduct within Australia, were confined to chattel slavery and legal ownership it
would have no practical operation. Section 270.2 would eliminate chattel slavery and ownership and s 270.3(1)(a)
would be otiose. The Court of Appeal held that the facts alleged in the present case were capable of being regarded
as within the scope of s 270.3(1)(a). For the reasons that follow, the decision of the Court of Appeal on these issues
should be upheld.

[21] The word 'slave' in s 270.3(1)(a) is not defined. It takes its meaning from the definition of 'slavery' in s 270.1.
That definition, in turn, derives from, although it is not identical to, the definition of 'slavery' in art 1 of the 1926
International Convention to Suppress the Slave Trade and Slavery (the 1926 Slavery Convention) (212 UNTS 17).
That definition was taken up in art 7 of the 1956 Supplementary Convention on the Abolition of Slavery, the Slave
Trade, and Institutions and Practices similar to Slavery (the 1956 Supplementary Convention) (266 UNTS 3), which
dealt with institutions and practices similar to slavery 'where they still exist and whether or not they are covered by
the definition of slavery contained in article 1 of the [1926] Slavery Convention' (art 1).

[22] The 1926 Slavery Convention, in its preamble, recited the declaration in the General Act of the Brussels
Conference of 1889–1890 of an intention to put an end to the traffic in African slaves, the intention, affirmed at the
Convention of Saint-Germain-en-Laye of 1919, to secure the complete suppression of slavery in all its forms and
the need to prevent forced labour from developing into conditions analogous to slavery. Article 2 contained an
undertaking by the parties to prevent and suppress the slave trade and to bring about the complete abolition of
slavery 'in all its forms'.

[23] Article 1 of the 1926 Slavery Convention was in the following terms:

'For the purpose of the present Convention, the following definitions are agreed upon:

(1) Slavery is the status or condition of a person over whom any or all of the powers attaching to the right of
ownership are exercised.

(2) The slave trade includes all acts involved in the capture, acquisition or disposal of a person with intent to
reduce him to slavery; all acts involved in the acquisition of a slave with a view to selling or exchanging

**[*609] him; all acts of disposal by sale or exchange of a slave acquired with a view to being sold or**
exchanged, and, in general, every act of trade or transport in slaves.'

[24] The definition in art 1(1) has continued to be used in international instruments. For example, the Rome Statute
of the International Criminal Court, which entered into force in 2002, defined 'enslavement', a crime against
humanity, as 'the exercise of any or all of the powers attaching to the right of ownership over a person … includ[ing]
the exercise of such power in the course of trafficking in persons' (2187 UNTS 90, art 7(2)(c)).

[25] The travaux préparatoires of the 1926 Slavery Convention are not especially illuminating as to the meaning of
art 1 (Allain 'A Legal Consideration of “Slavery” in Light of the Travaux Préparatoires of the 1926 Convention', paper
delivered at the conference Twenty-First Century Slavery: Issues and Responses (23 November 2006), Allain 'The
Definition of “Slavery” in General International Law and the Crime of Enslavement within the Rome Statute', paper
delivered at the International Criminal Court, Guest Lecture Series of the Office of the Prosecutor (26 April 2007)
and Allain The Slavery Conventions: The Travaux Préparatoires of the 1926 League of Nations Convention and the
_1956 United Nations Convention (2008)). Nevertheless, certain observations may be made as to the text and_
context, including the purpose, of the Convention. First, in 1926, in the case of many of the parties to the
Convention, including Australia, the legal status of slavery did not exist and legal ownership by one person of
[another was impossible. (In Australia, the law on slavery was based on four nineteenth century Imperial Acts (Slave](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B1N0-TWPY-Y08J-00000-00&context=1519360)
_[Trade Act 1824 (Imp); Slavery Abolition Act 1833 (Imp); Slave Trade Act 1843 (Imp); Slave Trade Act 1873 (Imp)),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B1N0-TWPY-Y08J-00000-00&context=1519360)_
a matter adverted to in s 270.2 of the Code.) Secondly, a principal object of the Convention was to bring about the
same situation universally, as soon as possible. Thirdly, the definition of slavery in art 1 referred to the status _or_


-----

condition of a person. Status is a legal concept. Since the legal status of slavery did not exist in many parts of the
world, and since it was intended that it would cease to exist everywhere, the evident purpose of the reference to
'condition' was to cover slavery de facto as well as de jure. This is hardly surprising. The declared aim of the parties
to the Convention was to secure the complete suppression of slavery in all its forms and to prevent forced labour
from developing into conditions analogous to slavery. They undertook to bring about 'the complete abolition of
slavery in all its forms'. It would have been a pitiful effort towards the achievement of those ends to construct a
Convention that dealt only with questions of legal status. The slave trade was not, and is not, something that could
be suppressed merely by withdrawal of legal recognition of the incidents of slavery. It is one thing to withdraw legal
recognition of slavery; it is another thing to suppress it. The Convention aimed to do both. Fourthly, the definition
turns upon the exercise of power over a person. The antithesis of slavery is freedom. The kind of exercise of power
that deprives a person of freedom to the extent that the person becomes a slave is said to be the exercise of any or
_all of the powers attaching to the right of ownership. As already noted, there was no legal right of ownership in_
many of the states

**[*610] which were parties to the Convention and one purpose of the Convention was that there would be no such**
legal right anywhere.

[26] In its application to the de facto condition, as distinct from the de jure status, of slavery, the definition was
addressing the exercise over a person of powers of the kind that attached to the right of ownership when the legal
status was possible; not necessarily all of those powers, but any or all of them. In a 1953 Memorandum, the
Secretary General of the United Nations (United Nations Economic and Social Council Slavery The Slave Trade,
_and Other Forms of Servitude, Report of the Secretary General, UN Doc E/2357 (1953) at 28) listed such powers_
as including the capacity to make a person an object of purchase, the capacity to use a person and a person's
labour in a substantially unrestricted manner and an entitlement to the fruits of the person's labour without
compensation commensurate to the value of the labour. Each of those powers is of relevance in the present case.
On the evidence it was open to the jury to conclude that each of the complainants was made an object of purchase
(although in the case of one of them the purchaser was not the respondent), that, for the duration of the contracts,
the owners had a capacity to use the complainants and the complainants' labour in a substantially unrestricted
manner and that the owners were entitled to the fruits of the complainants' labour without commensurate
compensation.

[27] The reference to 'chattel slavery' in the second ground of cross-appeal is a reference to the legal capacity of an
owner to treat a slave as an article of possession, subject to the qualification that the owner was not allowed to kill
the slave; power over 'the slave's person, property, and limbs, life only excepted' (Somerset v Stewart _(1772) Lofft 1_
at 2; see also Smith v Gould (1706) 2 Salk 666 and Forbes v Cochrane (1824) 2 B & G 448 at 471–472). Without
doubt, chattel slavery falls within the definition in art 1 of the 1926 Slavery Convention, but it would be inconsistent
with the considerations of purpose, context and text referred to in the preceding paragraph to read the definition as
limited to that form of slavery.

[28] In _Prosecutor v Kunarac, before the International Criminal Tribunal for the Former Yugoslavia, where the_
charges were of 'enslavement', both the Trial Chamber (Case No IT-96–23-T & IT-96–23/1-T, 22 February 2001)
and the Appeals Chamber (Case No IT-96–23 & IT-96–23/1-A, 12 June 2002) adopted a view of the offence that
was not limited to chattel slavery. The Trial Chamber, after an extensive review of relevant authorities and
materials, concluded that enslavement as a crime against humanity in customary international law consisted of the
exercise of any or all of the powers attaching to the right of ownership over a person; the actus reus of the violation
being the exercise of any or all of such powers and the mens rea consisting in the intentional exercise of such
powers (Case No IT-96–23-T & IT-96–23/1-T, 22 February 2001 at [539]–[540]). The Trial Chamber identified, as
factors to be taken into account, control of movement, control of physical environment, psychological control,
measures taken to prevent or deter escape, force, threat of force or coercion, duration, assertion of exclusivity,
subjection to cruel treatment and abuse, control of sexuality and forced labour (Case No IT-96–23-T & IT-96–23/1T, 22 February 2001 at [543]). The Appeals Chamber agreed with those factors (Case No IT-96–23 &

**[*611] IT-96–23/1-A, 12 June 2002 at [117]–[119]). However, it preferred to leave open, as a matter that was**
unnecessary for decision in that case, the Trial Chamber's added factor of an ability to buy and sell a person and it


-----

disagreed with the Trial Chamber's view that lack of consent was an element of the offence, although accepting that
it may be of evidential significance (Case No IT-96–23 & IT-96–23/1-A, 12 June 2002 at [119]–[120]).

[29] It is unnecessary, and unhelpful, for the resolution of the issues in the present case, to seek to draw boundaries
between slavery and cognate concepts such as servitude, peonage, forced labour or debt bondage. The 1956
Supplementary Convention in art 1 recognised that some of the institutions and practices it covered might also be
covered by the definition of slavery in art 1 of the 1926 Slavery Convention. To repeat what was said earlier, the
various concepts are not all mutually exclusive. Those who engage in the traffic in human beings are unlikely to be
so obliging as to arrange their practices to conform to some convenient taxonomy.

[30] In _Siliadin v France_ _[(2005) 20 BHRC 654 the European Court of Human Rights dealt with a complaint by a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_
domestic worker that the French criminal law did not afford her sufficient and effective protection against 'servitude'
or at least 'forced or compulsory' labour. Reference was made to legislative materials which used the term 'modern
**_slavery' to apply to some females, working in private households, who started out as migrant domestic workers, au_**
[pairs or 'mail-order brides' ((2005) 20 BHRC 654 at [49]). The court referred briefly and dismissively to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)
[possibility that the applicant was a slave within the meaning of art 1 of the 1926 Slavery Convention, saying ((2005)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)
_[20 BHRC 654 at [122] (my emphasis)):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9S-1RY1-DYBP-W2VW-00000-00&context=1519360)_

'[The court] notes that this definition corresponds to the “classic” meaning of slavery as it was practised for
centuries. Although the applicant was, in the instant case, clearly deprived of her personal autonomy, the
evidence does not suggest that she was held in slavery in the proper sense, in other words that Mr and Mrs B
exercised a genuine right of legal ownership over her, thus reducing her to the status of an “object”.'

(In the authoritative French text, 'c'est-a-dire que les epoux B aient exerce sur elle, juridiquement, un veritable droit
_de propriete, la reduisant a l'etat d'«objet»': Affaire Siliadin c France, Requete No 73316/01, 26 July 2005 at [122]_
(my emphasis).)

[31] It is understandable, in the context of that case, that the definition of 'slavery' was dealt with only in passing and
briefly. Nevertheless, it is to be noted that the court did not refer to the definition's reference to condition in the
alternative to status, or to powers as well as rights, or to the words 'any or all'. It may be assumed that there is, in
France, no such thing as 'a genuine right of legal ownership' of a person. That Mr and Mrs B did not exercise a
genuine right of legal ownership over the applicant was self-evident, but it would not have been a complete answer
if there had been a serious issue of slavery in the case.

[32] It is important not to debase the currency of language, or to banalise crimes against humanity, by giving slavery
a meaning that extends beyond the

**[*612] limits set by the text, context and purpose of the 1926 Slavery Convention. In particular it is important to**
recognise that harsh and exploitative conditions of labour do not of themselves amount to slavery. The term 'slave'
is sometimes used in a metaphorical sense to describe victims of such conditions, but that sense is not of present
relevance. Some of the factors identified as relevant in _Prosecutor v Kunarac, such as control of movement and_
control of physical environment, involve questions of degree. An employer normally has some degree of control
over the movements, or work environment, of an employee. Furthermore, geographical and other circumstances
may limit an employee's freedom of movement. Powers of control, in the context of an issue of slavery, are powers
of the kind and degree that would attach to a right of ownership if such a right were legally possible, not powers of a
kind that are no more than an incident of harsh employment, either generally or at a particular time or place.

[33] Although the definition of 'slavery' in s 270.1 of the Code is plainly based on the definition in art 1 of the 1926
Slavery Convention, the wording is not identical. First, s 270.1 refers to 'condition', not 'status or condition'. The
explanation for the difference appears from s 270.2. There is no status of slavery under Australian law. Legal
ownership of a person is impossible. Consequently s 270.1, in its application to conduct within Australia, is
concerned with de facto slavery. In s 270.1, the reference to powers attaching to the right of ownership, which are
exercised over a person in a condition described as slavery, is a reference to powers of such a nature and extent
that they are attributes of effective (although not legal, for that is impossible) ownership (Allain 'The Definition of


-----

'Slavery' in General International Law and the Crime of Enslavement within the Rome Statute', paper delivered at
the International Criminal Court, Guest Lecture Series of the Office of the Prosecutor (26 April 2007) at pp 12–13).
Secondly, the concluding words of the definition in s 270.1 ('including where such a condition results from a debt or
contract made by the person') do not alter the meaning of the preceding words because it is only where 'such a
condition' (that is, the condition earlier described in terms of the 1926 Slavery Convention) results that the words of
inclusion apply. The words following 'including', therefore, do not extend the operation of the previous words but
make it plain that a condition that results from a debt or a contract is not, on that account alone, to be excluded from
the definition, provided it would otherwise be covered by it. This is a common drafting technique, and its effect is not
to be confused with that of cases where 'including' is used as a term of extension. (That this construction conforms
to the legislative purpose appears from the minister's Second Reading Speech: Australia, Senate, _Parliamentary_
_Debates_ (Hansard), 24 March 1999 at 3076; and Model Criminal Code Officers Committee of the Standing
Committee of Attorneys General Model Criminal Code, Chapter 9, _Offences Against Humanity: Slavery Report_
(1998) p 29.)

[34] In the result, the definition of 'slavery' in s 270.1 falls within the definition in art 1 of the 1926 Slavery
Convention and the relevant provisions of Div 270 are reasonably capable of being considered appropriate and
adapted to give effect to Australia's obligations under that Convention (cf _Victoria v Commonwealth_ (Industrial
_Relations Act Case) (1996) 187 CLR 416_

**[*613] at 486–488). They are sustained by the external affairs power. They are not limited to chattel slavery.**

[35] The factors accepted by both the Trial Chamber and the Appeals Chamber in Prosecutor v Kunarac (Case No
IT-96–23 & IT-96–23/1-A, 12 June 2002) are relevant to the application of s 270.3(1)(a) of the Code. The Appeals
Chamber was right to point out that consent is not inconsistent with slavery. In some societies where slavery was
lawful, a person could sell himself into slavery. Peonage could be voluntary as well as involuntary, the difference
affecting the origin, but not the character, of the servitude (Clyatt v US (1905) 197 US 207 at 215). Consent may be
factually relevant in a given case, although it may be necessary to make a closer examination of the circumstances
and extent of the consent relied upon, but absence of consent is not a necessary element of the offence. On the
point left open by the Appeals Chamber, it should be concluded that, for the purpose of s 270.3(1)(a) of the Code,
the commodification of an individual by treating him or her as an object of sale and purchase, if it exists, is a
material factor when a tribunal of fact comes to assess the circumstances of a case, and may involve the exercise
of a power attaching to a right of ownership. Having regard to all those matters, there was in the present case
evidence to go to a jury that was capable of sustaining verdicts of guilty.
**The appeal**

[36] The Court of Appeal quashed the respondent's convictions and ordered a new trial, substantially upon a single
ground of criticism of the primary judge's directions to the jury. The point on which the Court of Appeal differed from
the primary judge comes down to a question of the application of the provisions of Ch 2 of the Code to charges of
breaches of s 270.3(1)(a). Before turning to those provisions, it is convenient to set out what was said in the Court
of Appeal by Eames JA, with whom Maxwell P and Buchanan JA agreed.

[37] Eames JA described as 'the critical issue' one that 'concerns the character of the exercise of power by the
accused over the victim'. He said that the prosecutor's argument and the trial judge's directions 'did not, in terms,

[invite or] direct the jury to consider the subjective intention of the [respondent]—her state of mind—when dealing
with the complainants'. This, he said, 'was a critical element of the offence that had to be established if the

[respondent] was to be convicted'. The jurors, Eames JA held, 'were not alerted as to the relevance, when
considering the question of intention, of the belief which the [respondent] may have held as to the basis on which
she was dealing with each of the complainants'. What his Honour understood to be the relevance of that belief was
made clear in his reasons. The primary judge had told the jury that, in order to convict, they had to find that the
complainants were slaves in accordance with the statutory definition as he explained it to them, that the respondent
knew the facts that brought the complainants within that definition (although not that she was aware of the
legislation or the legal definition of slavery) and that she intended to possess or use persons in the condition
disclosed by those facts. (It may be noted that the elements of the offence as explained by the primary judge in his
directions


-----

**[*614] were somewhat similar to what the Trial Chamber in Prosecutor v Kunarac (Case No IT-96–23-T & IT-96–**
23/1-T, 22 February 2001) identified as the actus reus and the mens rea for the crime of enslavement.)

[38] Eames JA said that the critical element of the offence of possessing a slave, missing from the primary judge's
directions, was '[the respondent's] appreciation of the character of her own actions' (my emphasis). He described
the element as follows (references omitted):

'Fourthly, the accused must have possessed the worker in the intentional exercise of what constitutes a power
attaching to a right of ownership, namely, the power of possession. For that to be the case the accused must
be shown to have regarded the worker as though she was mere property, a thing, thereby intending to deal
with her not as a human being who had free will and a right to liberty, but as though she was mere property.
However harsh or oppressive her conduct was towards the worker it would not be sufficient for a conviction if,
rather than having possessed the worker with the knowledge, intention, or in the belief that she was dealing
with her as though she was mere property, the accused possessed her in the knowledge or belief that she was
exercising some different right or entitlement to do so, falling short of what would amount to ownership, such as
that of an employer, contractor, or manager.'

[39] In a footnote to his reasons on this point, Eames JA said that it was not necessary to prove that an offender
knew that the power to possess or use property was an incident of the right of ownership. That is correct, but it is
not easy to relate that to the concluding words of the paragraph just quoted, which seem to postulate, as
exculpatory, a knowledge or belief that the offender was exercising some other right or entitlement. If it were not
necessary to prove that the respondent knew what rights of ownership were, it would be curious if it were relevant
to consider what she knew or believed about other rights or entitlements. One would have expected that a person
could be convicted of the offence of possessing a slave without knowing, or caring, anything about possible
alternative sources of rights or entitlements.

[40] In a further footnote, Eames JA supported the above paragraph by references to ss 5.2(2) and 5.2(3) of the
Code, which, he said, were both relevant. This is a matter to which it will be necessary to return.

[41] Later, Eames JA said (in a passage that also is difficult to reconcile with the first of the footnotes mentioned
above):

'What the judge omitted to state was that the Crown had to prove intention to exercise power over the slave in
the knowledge or belief that the power that was being exercised was one attaching to ownership. That is, the
power must have been intentionally exercised as an owner of property would exercise power over that
property, acting in the knowledge or belief that the victim could be dealt with as no more than a chattel. It would
not suffice for the power to have been exercised by the

**[*615] accused in the belief that she was dealing with the victim as her employee, albeit one in a subservient**
position and being grossly exploited.'

[42] These passages, notwithstanding the footnote, indicate that Eames JA had in mind that it was necessary for
the prosecution to establish a certain state of knowledge or belief on the part of the respondent as to the source of
the powers she was exercising, in addition to an intention to exercise those powers. They appear to require
advertence by the respondent to the different capacities (owner or employer) by virtue of which she might have
been able to exercise powers. This was made even clearer by the form of an answer which his Honour said should
have been given to a question asked by the jury:

'You must be satisfied that the accused was intentionally exercising a power that an owner would have over
property _and was doing so with the knowledge or in the belief that the complainant was no more than mere_
_property. If it is reasonably possible that the accused acted to possess or to use the complainant with the_
knowledge or in the belief that she was exercising her rights and entitlements as her employer or contractor
and not in the belief that the complainant had no rights or free will, but was property, a thing, over whom she
could exercise power as though she owned her then, however exploitative and unfair you may think her


-----

treatment of the complainant was, it would not constitute the offences of intentionally possessing or using a
slave.' (My emphasis.)

[43] This cannot be accepted. What the respondent knew or believed about her rights and entitlements as an
employer or contractor, as distinct from rights of property, in the perhaps unlikely event that she knew or believed
anything on that subject, was not something that the prosecutor had to establish or that the jury had to consider.

[44] It seems likely that the Court of Appeal was, with good reason, concerned about a problem presented by s
270.3(1)(a), at least in a borderline case: how is a jury to distinguish between slavery, on the one hand, and harsh
and exploitative conditions of labour, on the other? The answer to that, in a given case, may be found in the nature
and extent of the powers exercised over a complainant. In particular, a capacity to deal with a complainant as a
commodity, an object of sale and purchase, may be a powerful indication that a case falls on one side of the line.
So also may the exercise of powers of control over movement which extend well beyond powers exercised even in
the most exploitative of employment circumstances, and absence or extreme inadequacy of payment for services.
The answer, however, is not to be found in the need for reflection by an accused person upon the source of the
powers that are being exercised. Indeed, it is probably only in a rare case that there would be any evidence of such
consideration.

[45] It should also be noted that the concluding words of the definition of slavery in s 270.1 of the Code show that
the existence of a contract between an alleged offender and a complainant is not inconsistent with the commission
of an offence. The legislation, in terms, accepts that a condition

**[*616] of slavery may result from a contract. The above reasoning appears to construct a false dichotomy between**
employment and effective ownership, in addition to importing a requirement of rights analysis by the offender which
is unnecessary.

[46] Chapter 2 of the Code does not provide support for the Court of Appeal's reasoning. In the case of both of the
offences alleged in relation to each complainant, the physical element of the offence was conduct, which is defined
to include both an act and a state of affairs. It was not suggested by the Court of Appeal that recklessness, as the
default element in relation to circumstances, had a role to play (cf _R v Saengsai-Or (2004) 61 NSWLR 135). As_
Brennan J pointed out in He Kaw Teh v R _[[1986] LRC (Crim) 553 at 588, having something in possession is more](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
easily seen as a state of affairs that exists because of what the person who has possession does in relation to the
thing possessed. Both possessing a slave and using a slave are conduct, and the prosecution had to establish the
existence of the conduct and one of the fault elements specified in s 5.1(1). The prosecution case was conducted
on the basis that the relevant fault element was intention. In a footnote earlier mentioned, Eames JA said that all of
sub-ss (1), (2) and (3) of s 5.2 were relevant. This is not easy to understand: sub-s (1) applies where the physical
element is conduct; sub-s (2) applies where the physical element is a circumstance; sub-s (3) applies where the
physical element is a result. Section 4.1 says a physical element may be conduct _or a result of conduct_ _or a_
circumstance in which conduct or a result of conduct occurs.

[47] The physical element was conduct (which includes a state of affairs); the fault element was intention. It was,
therefore, s 5.2(1) that was relevant. A person has intention with respect to conduct if he or she means to engage in
that conduct. Knowledge or belief is often relevant to intention (He Kaw Teh v R _[[1986] LRC (Crim) 553 at 592–](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
593). If, for example, it is the existence of a state of affairs that gives an act its criminal character, then proof of
knowledge of that state of affairs ordinarily will be the best method of proving that an accused meant to engage in
the proscribed conduct.

[48] The terms of s 270.3(1) reinforce the conclusion that intention is the relevant fault element. The offences in
question were of intentionally possessing a slave or intentionally exercising over a slave another power (here,
using) attaching to the right of ownership. It is agreed on all sides that it was unnecessary for the prosecution to
prove that the respondent knew or believed that the complainant was a slave or even that she knew what a slave
was. Thus, Eames JA said that the respondent 'does not have to have known the definition of a slave, nor even that
there was an offence of slavery'. So much is uncontroversial. If a person is known by an accused to possess the
qualities that, by virtue of s 270.1, go to make that person a slave, then the state of knowledge relevant to intention,


-----

and therefore intention itself, may be established regardless of whether the accused appreciates the legal
significance of those qualities. An accused does not have to know anything about the law in order to contravene s
270.3(1)(a).

[49] In so far as a state of knowledge or belief is factually relevant to intention as the fault element of the offence, it
is knowledge or belief about the facts relevant to possession or using, and knowledge or belief about the

**[*617] facts which determine the existence of the condition described in s 270.1. This is a condition that results**
from the exercise of certain powers. Whether the powers that are exercised over a person are 'any or all of the
powers attaching to the right of ownership' is for a jury to decide in the light of a judge's directions as to the nature
and extent of the powers that are capable of satisfying that description. This is not to ignore the word 'intentionally'
in s 270.3(1). Rather, it involves no more than the common exercise of relating the fault element to the physical
elements of the offence (cf He Kaw Teh v R _[[1986] LRC (Crim) 553 at 591).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_

[50] In this case, the critical powers the exercise of which was disclosed (or the exercise of which a jury reasonably
might find disclosed) by the evidence were the power to make the complainants an object of purchase, the capacity,
for the duration of the contracts, to use the complainants and their labour in a substantially unrestricted manner, the
power to control and restrict their movements and the power to use their services without commensurate
compensation. As to the last three powers, their extent, as well as their nature, was relevant. As to the first, it was
capable of being regarded by a jury as the key to an understanding of the condition of the complainants. The
evidence could be understood as showing that they had been bought and paid for, and that their commodification
explained the conditions of control and exploitation under which they were living and working.

[51] It was not necessary for the prosecution to establish that the respondent had any knowledge or belief
concerning the source of the powers exercised over the complainants, although it is interesting to note that, in
deciding to order a new trial, the Court of Appeal evidently took the view that the evidence was capable of satisfying
a jury, beyond reasonable doubt, of the existence of the knowledge or belief that the Court of Appeal considered
necessary.

[52] The ground on which the Court of Appeal regarded the primary judge's directions as inadequate has not been
sustained.
**The third ground of proposed cross-appeal**

[53] This ground is:

'The Court of Appeal erred in failing to hold that the verdicts are unreasonable or cannot be supported having
regard to the evidence.'

[54] The argument that the jury's verdict was unreasonable, because of the inadequacy of the evidence, was
considered and rejected by the Court of Appeal, applying the principles stated by this court in _M v R_ (1994) 181
CLR 487. Eames JA noted that much of the evidence in the case was uncontested, although there were some
disputes of fact, especially in relation to some testimony as to aspects of the restraint applied to the movements of
the complainants.

[55] A cognate question was the subject of further argument and further reasons for judgment. When the Court of
Appeal delivered its reasons for quashing the convictions (on the ground discussed earlier) it left open for further
argument and consideration the question whether there should be an order for a new trial. After further argument,
Eames JA said that his earlier

**[*618] reasons were intended to embrace a conclusion that the evidence in the case had sufficient cogency to**
justify a conviction. He said it did not follow automatically that there should be a new trial, but went on to deal with
other relevant considerations. Finally, the Court of Appeal ordered a new trial.

[56] It is likely that a good deal would have turned on the jury's assessment of DS and the complainants. Subject to
that, there was cogent evidence of the intentional exercise of powers of such a nature and extent that they could


-----

reasonably be regarded as resulting in the condition of slavery, and the conduct, to which s 270.3(1)(a) was
directed. There was no error of principle by the Court of Appeal on this aspect of the case, and it has not been
shown that the interests of justice require a grant of special leave to cross-appeal on this ground.
**Orders**

[57] I propose that the following orders be made:

'1. Appeal allowed.

2. Special leave to cross-appeal on the first and second grounds in the proposed notice of cross-appeal
granted. Cross-appeal on those grounds treated as instituted, heard instanter and dismissed.

3. Special leave to cross-appeal on the third ground in the proposed notice of cross-appeal refused.

4. Set aside orders 3, 4 and 5 of the orders of the Court of Appeal of the Supreme Court of Victoria made on 29
June 2007 and, in their place, order that the appeal to that court against conviction be dismissed.'

[58] Notwithstanding that these are criminal proceedings, the appellant, on the hearing of the application for special
leave to appeal, undertook to pay the costs of the respondent of the application for special leave to appeal and of
the appeal to this court. Consistently with that undertaking, the court should order that the appellant pay the
respondent's costs of the application for special leave to appeal and of the appeal to this court.

[59] There was also an application to the Court of Appeal for leave to appeal against sentence. Because the Court
of Appeal allowed the appeal against conviction, it did not deal with the matter of sentence. The matter should be
remitted to the Court of Appeal for its consideration of the application for leave to appeal against sentence.

**GUMMOW J.**

[60] I agree with the orders proposed by the Chief Justice and with his Honour's reasons. I agree also with the
reasons of Hayne J.

**KIRBY J.**

[61] These proceedings arise out of convictions entered against Wei Tang ('Ms Tang') following jury verdicts. The
convictions are said to be the 'first convictions in Australia' of 'slavery offences' contrary to s 270.3(1)(a) of the
Criminal Code (Cth) ('the Code') (R v Wei Tang (2007) 16 VR 454 at [4]). These

**[*619] offences are found in Ch 8 of the Code dealing with 'Offences against humanity'.**

[62] Ms Tang sought, and obtained, leave to appeal against her convictions to the Court of Appeal of the Supreme
Court of Victoria ((2007) 16 VR 454 at [200]). That court, while rejecting her submission that verdicts of acquittal
should be entered, set aside the convictions and ordered a retrial of the charges (R v Wei Tang [2007] VSCA 144 at

[13]–[14]; see (2007) 16 VR 454 at [199]–[200]).

[63] The prosecution, by special leave, has appealed to this court seeking restoration of Ms Tang's convictions. For
her part, Ms Tang has sought special leave to cross-appeal on three grounds. If successful on the cross-appeal, Ms
Tang again seeks the substitution of verdicts of acquittal.

[64] The other members of this court have concluded that the prosecution is entitled to succeed; its appeal should
be allowed; the convictions of Ms Tang should be restored; and the cross-appeal rejected. (Reasons of Gleeson CJ
at para [57], above, and reasons of Hayne J at para [168], below. Gummow, Heydon, Crennan and Kiefel JJ
agreeing with both.) I agree with most of their reasons. However, upon what Eames JA, in the Court of Appeal,
described as 'the critical issue' in the proceedings ((2007) 16 VR 454 at [66]; see also reasons of Hayne J at para

[133], below), I disagree with my colleagues. On that issue, in effect, I concur in the approach and conclusion


-----

expressed in the Court of Appeal by Eames JA (with whom Maxwell P and Buchanan JA agreed without additional
reasons ((2007) 16 VR 454 at [66]; see also reasons of Hayne J at para [133], below).

[65] The 'critical issue' concerns the accuracy and adequacy of the directions given to the jury at the second trial of
Ms Tang. (In the first trial, the jury failed to agree on verdicts in relation to Ms Tang ((2007) 16 VR 454 at [17].) The
controversial point involves the meaning and application of the provisions of the Code that define the offences with
which Ms Tang was charged and the content of the 'fault elements' (the Code, Ch 2, Div 5, s 5.1. The relevant
provisions are set out in the reasons of Gleeson CJ at para [5], above) (relevantly the 'intention' aspect) necessary
to constitute those offences. It concerns what the trial judge was obliged to tell the jury in that respect about the law
governing these offences.

[66] I concede that there is room for differences of opinion on the issue that separates my opinion from that reached
by the majority in this court. Such differences may arise because of the difficulties in interpreting the novel
provisions of the Code (see (2007) 16 VR 454 at [60], [143]); the absence of earlier explorations of those provisions
by appellate decisions ((2007) 16 VR 454 at [93]); the necessary interaction of the applicable Australian law with the
relevant provisions of international law—in particular, the Convention to Suppress the Slave Trade and Slavery ('the
1926 Slavery Convention') and the Supplementary Convention on the Abolition of Slavery, the Slave Trade, and
Institutions and Practices Similar to Slavery ('the 1956 Supplementary Convention') (opened for signature in 1956
and entered into force in 1957; see [1958] ATS 3; 266 UNTS 3); and the mass of evidentiary material from the
lengthy trial of Ms Tang. Such evidence was relevant for two purposes: first, as to the quality of the relationship
between Ms Tang and the five women

**[*620] ('the complainants') whom she was charged with possessing as 'a slave' or using as 'a slave' contrary to s**
270.3(1)(a) of the Code; and secondly, as to the suggested 'fault element' ('intention') that the prosecution was
required to prove in order to secure convictions (cf (2007) 16 VR 454 at [157]).

[67] While I agree that the other challenges mounted for Ms Tang fail, in my opinion the approach of the Court of
Appeal to the 'critical issue' was correct. That approach is more consonant with: the proper analysis of the Code;
the basic doctrine of criminal law in Australia, against the background of which the Code is written, on the operation
of 'intention' in respect of serious criminal offences; the principles of interpretation applicable to the legislation in
question; a proper view of the relationship between the Code provisions and the international law that they seek to
apply in Australia and the various other considerations of legal principle and policy to which regard may properly be
had.

[68] We do not advance the correct application in Australia of a contemporary statutory provision to tackle modern
issues of 'slavery' and trafficking in 'sexual slaves' by distorting the essential ingredients of serious criminal offences
as provided by the Parliament. Nor do we do so by diminishing the elements that the prosecution must prove and
that the trial judge must accurately explain to the jury. In this case, that element is the 'intention' necessary to
constitute such a serious offence, with the exposure that it brings, upon conviction, to special calumny and to
extremely severe punitive consequences.

[69] In a case such as the present, there is an inescapable dilemma in the operation of fundamental principles of
human rights, reflected in the Code and in Australian law more generally. Protection of persons alleged to have
been trafficked as 'sexual slaves' is achieved in this country in a trial system that also provides fundamental legal
protections for those who are accused of having been involved in such offences. As is often observed, the
protection of the law becomes specially important when it is claimed by the unpopular and the despised accused of
grave wrong-doing (cf Adelaide Company of Jehovah's Witnesses Inc v Commonwealth (1943) 67 CLR 116 at 124
per Latham CJ).

[70] In my opinion, the appeal fails and so does Ms Tang's attempt, by cross-appeal, to secure the substitution of
verdicts of acquittal. As the Court of Appeal proposed, an order for a retrial, freed from the legal errors of the
second trial, is the correct outcome.
**The factsThe general background**


-----

[71] The general factual background is explained in the reasons of Gleeson CJ (reasons of Gleeson CJ at paras

[6]–[18], above). There were various points of difference in the extensive evidence called at the trial. For example,
in respect of one of the complainants, there were differences as to the arrangements whereby she had travelled to
Australia from Thailand and as to the persons involved in making those arrangements. However, much of the
evidence tendered against Ms Tang was not in dispute ((2007) 16 VR 454 at [191]). The battleground, instead, lay
in the interpretation of that evidence and its legal effect. The relevant question was whether the evidence fell within

**[*621] the particular provisions of the Code governing, first, the 'physical elements' of the offences provided in s**
270.3(1) with which Ms Tang was charged, and secondly, the 'fault elements' that also had to be proved in order to
satisfy those charges (see the Code, ss 2.1, 3.1, 3.2, 5.1. These provisions are set out in the reasons of Gleeson
CJ at para [5], above).

[72] In this appeal, the novelty of the meaning of the 'slavery offences' provided by s 270.3 of the Code gives rise to
the first problem of interpretation. This country has never lawfully had 'slavery' in the conventional meaning of that
term and still does not. The novelty of the 'general principles of criminal responsibility' (the chapter heading to Ch 2
of the Code. See reasons of Gleeson CJ at para [5], above) and the specification of the essential elements of an
offence under the Code give rise to the second problem of interpretation. Those problems of interpretation must be
made concrete by reference to the evidence at the trial. Such evidence will help to test whether the trial judge
properly understood, and explained, the provisions of the Code so as to render the verdicts of the second jury (and
the convictions that followed) both lawful and reasonable. The evidence will also help to answer the legal
propositions advanced by the contesting parties.

[73] At the outset, it is important to acknowledge that the evidence was by no means incontestable or clear-cut.
There are two particular indications of this. First, upon basically the same evidence, the first jury summoned to try
Ms Tang and a co-accused (Mr Paul Pick, who was the manager of the licensed brothel 'Club 417') acquitted Mr
Pick on eight counts. The jury were unable to agree on two further counts against him or upon any of the counts
presented against Ms Tang. Mr Pick subsequently applied successfully for a nolle prosequi ((2007) 16 VR 454 at

[17]). Secondly, following very extensive directions given by the trial judge to the jury in the second trial, the jury
returned twice to seek judicial clarification about the requirements of intention. This became the 'critical issue' in the
Court of Appeal as it is likewise in this court. What took place and the terms of the questions asked by the jury and
directions given by the trial judge are explained in detail by Eames JA ((2007) 16 VR 454 at [122]–[129]).

[74] The first question was asked on the first day of the jury's deliberations (after a charge that had proceeded over
three days). The question was presented after the jury had already been deliberating for five hours. The second
question was asked the following afternoon, after the jury had been deliberating for over a day. It will be necessary
to return to these developments (see these reasons at paras [123]–[125], below).

[75] For a complete understanding of my reasons, it is essential to appreciate how the questions emerged; the
preceding complex and confusing instructions given to the jury on the subject; and the further instruction that
followed which, with respect, was partly non-responsive and partly added to the uncertainty and confusion. This is
all set out with admirable clarity by Eames JA. If nothing else, it indicates the confusion of the instructions given to
the jury on the subject of the intention necessary to justify guilty verdicts; the correct focus that the jury themselves
were giving to the 'critical issue'; and thus the great importance of that issue to their deliberations in the forensic
circumstances of the second trial.

**[*622] [76] The successive questions from the jury indicate the significance that they were assigning to the quality**
and content of the 'intention' of Ms Tang which the prosecution had to prove to secure guilty verdicts. The length of
the jury's deliberations and their repeated questions on this issue also indicate (correctly in my view) that this jury,
like the earlier jury in the first trial, did not find reaching their verdicts in these proceedings an easy task, considering
the way in which the evidence emerged in the second trial.

[77] In these reasons, I incorporate by reference the chronicle set out by Eames JA in the Court of Appeal. This
includes the lengthy directions given to the jury about the meaning of the words 'possession' and 'use' of a 'slave',
contrary to the Code; the jury's successive questions; the supplementary directions then given by the trial judge;


-----

and the further supplementary directions given after trial counsel for Ms Tang took exception to aspects of the
judge's first attempt (this is set out, with extracts from the trial, at (2007) 16 VR 454 at [93]–[141]).

[78] Although additional reference will be made below to these questions and the resulting redirections, because
mine is a minority opinion in this court, I will not set the passages out seriatim. They are not set out in other
reasons. Nevertheless, to understand the conclusion that Eames JA and the other members of the Court of Appeal
reached, it is essential to appreciate the deficiencies in the directions given to the jury on the critical subject of
'intention'. No other course would do justice to Ms Tang's case or to the Court of Appeal's analysis.
_Evidence against statutory slavery_

[79] Allowing, for the moment, that the Code expands somewhat the traditional definition of 'slavery' in international
law (and in more recent times under the 1926 Slavery Convention and the 1956 Supplementary Convention) and
that it may do this in Australia in conformity with the Constitution, there was certainly evidence before the jury in the
second trial that, in combination, could have supported the acquittal of Ms Tang.

(1) The trial was conducted on the footing that each of the complainants, in their country of nationality (Thailand),
had earlier worked in the sex industry ((2007) 16 VR 454 at [5]). In this sense, they were not tricked into
employment in Australia on a false premise or led to believe that they would be working in tourism, entertainment or
other non-sexual activities (cf Dorevitch and Foster 'Obstacles on the Road to Protection: Assessing the Treatment
of Sex-Trafficking Victims under Australia's Migration and Refugee Law' (2008) 9 Melb JIL 1 at 8, 38 ('Dorevitch and
Foster')). While trafficking in persons for sexual or like purposes is an undeniable feature of modern population
movements, equally, some such movements are undoubtedly economically motivated (see Dorevitch and Foster
(2008) 9 Melb JIL 1 at 38–39). As such, they would not constitute 'slavery' offences under s 270.3(1)(a) of the Code
if undertaken with appropriate knowledge and consent by an adult person who was able to give such consent.

(2) Each complainant was above the legal age of consent. It was not suggested (and it did not appear from the
evidence) that they were in any way legally incompetent or that they had been subjected to coercion to persuade

**[*623] them to come to Australia to work in the sex industry. It was accepted that they came to this country**
voluntarily, knowing at least the general nature and incidents of the work they were agreeing to perform (reasons of
Gleeson CJ at para [6], above; reasons of Hayne J at para [166], below).

(3) While the evidence revealed several offences against the Migration Act 1958 (Cth) and Regulations and
perhaps state offences, the brothel in Melbourne in which the complainants worked as commercial sex workers and
their work were not illegal under Victorian law. The brothel held a licence pursuant to the Prostitution Control Act
1994 (Vic) ((2007) 16 VR 454 at [8]). Although activities of prostitution were previously illegal under Australian law
(as they still are in many countries) they were not, without more, illegal in the subject brothel. Necessarily, Ms
Tang's trial was unconcerned with any migration or other offences that she, the complainants or others might have
committed. No such offences were before the jury.

(4) The evidence indicated that the complainants were not imprisoned in the brothel or in their place of residence.
The largest evidentiary dispute at trial concerned the extent to which the complainants were able to move freely and
whether their accommodation was subject to a deadlock controlling access and egress ((2007) 16 VR 454 at [191]).
It is appropriate to accept the trial judge's finding on sentencing that the complainants were not kept under lock and
key ((2007) 16 VR 454 at [192]; see also at [196]) although initially they were 'effectively restricted'. In part, such
restrictions were adopted because of the common objective of the complainants and Ms Tang to avoid detection by
migration authorities and deportation from Australia as unlawful aliens present in the country without relevant visas
((2007) 16 VR 454 at [8]).

(5) The 'fee' paid to the 'recruiters' in Thailand who arranged for the complainants to travel to Australia (and
eventually to Melbourne) (the 'fee' varied but was about $20,000. See reasons of Gleeson CJ at para [12], above)
was never fully explained, still less justified, to the complainants. However, there was no doubt that some costs
were incurred by the 'recruiters'. These included, by inference, procuring visas; arranging land and air transport
(reasons of Gleeson CJ at para [8], above); providing return airfares for the complainants; arranging and paying for
accompanying persons (usually an elderly couple so as to avoid detection at the border); providing initial and later


-----

accommodation; and a 'profit margin' (reasons of Gleeson CJ at paras [8], [12], above). The 'fee' extracted would
arguably fall to be considered (at least in part) in the context of the law, culture and economy of Thailand where it
was orally agreed. It would also arguably need to be judged in the context that the complainants voluntarily entered
Australia aware of the type of work they were to perform, inferentially so as to make their lives better as a
consequence and appreciating that it would result in a debt to those who had made the necessary arrangements to
facilitate their travel and relocation ((2007) 16 VR 454 at [149]).

(6) As was essential to their successful initiation into the sex industry in Australia, the complainants themselves
participated in the subterfuge of pretending to visit Australia on a tourist visa ((2007) 16 VR 454 at [6]).

(7) After the complainants commenced work in the brothel, their passports and return air tickets were taken and
retained in a secure place. It was stated

**[*624] that this was done to permit the nationality and identity of the complainants to be established, in the event of**
investigations by migration authorities. Also, it was done to avoid loss or theft of the documents. This is in addition
to any motive to prevent the non-consensual departure of the complainants;

(8) It was agreed that the complainants enjoyed a 'free day' each week; that each was credited with a notional sum
of $50 per customer in the reduction of their outstanding debt; and that, on the free day, each complainant could
either rest or continue to work and receive $50 per customer for themselves (reasons of Gleeson CJ at para [14],
above). The evidence also showed that the complainants were well fed and provided for (reasons of Gleeson CJ at
para [16], above). Two had actually paid off their debts (the debt varied but was about $45,000, inclusive of the 'fee'
paid or payable to the Thai 'recruiters') within six months of arrival. Assuming that they worked every day of the
week (as most did), this would mean attending to an average of five clients a day. The two who had paid off their
debts stayed and continued to work in the brothel. This was strongly relied on as contradicting a relationship that
could be characterised as 'slavery' in any meaningful sense of that word. It was common ground that once the debt
was paid, each complainant was completely free to choose for herself the hours of work and place of
accommodation (reasons of Gleeson CJ at paras [12], [17], above). There was conflicting and unclear evidence
about the freedom of movement permitted before the debt was paid, other than transfer between the brothel and
the residence. Some evidence suggested that at least one complainant had formed a personal relationship which
she pursued during that interval.

(9) Once the complainants and their migration status were discovered, they were, by law, subject to immediate
detention and deportation from Australia. The availability of legal relief against that course was limited. One such
form of relief, introduced soon after these events took place, was the provision of both temporary and longer-term
visas to stay in Australia. (Dorevitch and Foster, (2008) 9 Melb JIL 1 at 10: 'Effective since 1 January 2004, the …
framework consists of four types of visa: a new Bridging Visa F (Subclass 060) (BVF); the existing Criminal Justice
Stay Visa (CJSV); a Temporary Witness Protection (Trafficking) Visa (TWPTV); and a Permanent Witness
Protection (Trafficking) Visa (PWPTV)' (footnotes omitted).) The latter were available only to permit a person, such
as one or more of the complainants, to stay if they made a 'significant contribution' to a prosecution of an accused
offender for criminal offences.

(10) There was no evidence that the complainants were subjected to rape, violence or other such offences (cf
Halley 'Rape in Berlin: Reconsidering the Criminalisation of Rape in the International Law of Armed Conflict' (2008)
9 Melb JIL 78 at 113). This sometimes marks the predicament of those (generally women and children) who are
trafficked for the purpose of sexual slavery and sexual debt bondage (Dorevitch and Foster (2008) 9 Melb JIL 1 at
19–20).
_Evidence favouring statutory slavery_

[80] The foregoing evidence was available to Ms Tang to contest the charge that she had 'within … Australia,
intentionally … possesse[d] a slave or

**[*625] exercise[d] over a slave any of the other powers attaching to the right of ownership' (the Code, s**
270.3(1)(a)). However, as noted by the Court of Appeal, there was also evidence capable of supporting the


-----

conclusions that Ms Tang was guilty of the offences charged and that such verdicts were not unreasonable (cf
reasons of Gleeson CJ at para [18], above).

[81] The relevant evidence included:

(1) The meaning to be given to the language of Div 270 of the Code is not controlled by considerations prevailing in
the law, culture or economy of Thailand. The applicable Code provisions draw upon international law, specifically
the 1926 Slavery Convention and the 1956 Supplementary Convention. They thus purport to express universal
offences against humanity. However, ultimately it is the duty of an Australian court to give effect to the language
stated in the Code, an Australian statute. It is to measure the evidence accepted against the standards expressed
in the Code, as that law is understood in Australia. In determining what constitutes employment conditions that are
extremely harsh, unconscionable and oppressive but which do not answer to the defined description of 'slavery', it is
proper that the criteria expressed in the Code should be given a meaning that reflects Australian understandings.
(The Code, s 270.1 (definition of slavery): 'the condition of a person over whom any or all of the powers attaching to
the right of ownership are exercised, including where such a condition results from a debt or contract made by the
person.') The definition of 'slavery' in the Code is not intended to attract merely harsh, unconscionable and
oppressive employment conditions. As such, the discrimen for 'slavery offences' will properly take into account the
normal features of working conditions in Australia and not working conditions that may exist in Thailand or
elsewhere. Such conditions in Australia are closely regulated by federal and state laws. They have been so
regulated since colonial times. Commonly, the applicable laws are designed to ensure a 'fair go all round'
(Blackadder v Ramsey Butchering Services Pty Ltd (2005) 221 CLR 539 at [30], citing Re Loty and Holloway and
_Australian Workers' Union [1971] AR (NSW) 95 at 99 per Sheldon J; cf New South Wales v Commonwealth (Work_
_Choices Case) (2006) 229 CLR 1 at [609]). (Some would argue the purpose of s 51(xxxv) of the Constitution was to_
protect and entrench in law that basic feature of Australian society.) Measured against that feature, as this court
may take judicial notice and as a jury would have been aware, the working conditions of the complainants were
substantially different. The differences were most evident in the hours, conditions and circumstances of the work,
the closely restricted accommodation and the onerous requirements for the reduction of the 'employment' debts. At
trial, counsel for Ms Tang suggested analogies between the situation of the complainants and those of an oil rig
employee or of students obliged to repay HECS debts. These comparisons are unconvincing when contrasted with
the seriously exploitative conditions of the complainants that were revealed by the evidence. At the very least, in an
Australian setting, it was open to the jury to conclude that such circumstances bore no comparison or analogy to
(even harsh) employment conditions as understood in Australia (see (2007) 16 VR 454 at [8], [12]);

(2) If it be accepted that the complainants came voluntarily to Australia to

**[*626] work in the sex industry, the counts charging Ms Tang with offences against s 270.3(1)(a) of the Code still**
raised a critical question. That question was what happened to the complainants after they arrived at their place of
employment and what was the quality and content of Ms Tang's intention in that regard. Allowing for the existence
of some kind of agreement with the complainants before they left Thailand, the fact is that the agreement was not in
writing; its terms were in some respects unclear and disputed; and the 'fees' payable to the Thai 'recruiters' and to
Ms Tang were never fully explained or justified to the complainants. At the very least, the complainants were
economically vulnerable in Thailand. They were particularly vulnerable once they arrived in Australia. In this
country, they found themselves in an alien culture; were exposed to the possibility of sudden immigration expulsion;
had severe practical restrictions affecting their movements, work and accommodation; had little skill in the English
language; and had few, if any, local friends or acquaintances outside the brothel, its personnel and customers;

(3) The taking of the passports and return air tickets from the complainants can, it is true, be explained in other
ways; likewise the confiscation of the funds lent to them to afford evidence upon arrival of an apparent capacity of
self-support. However, the consequence of these steps was to remove from the complainants the wherewithal to
inquire about or pursue their legal rights or to escape from the conditions in which they found themselves, if that
was their desire ((2007) 16 VR 454 at [192]–[193]; see also at [155]). Particular employment arrangements,
including in Australia, can sometimes seem oppressive to those engaged in conventional employment. Relevant
here, however, was the work that the complainants had agreed to perform; the regime of effective discipline
governing the complainants' place of employment and accommodation; their sleeping arrangements; the long hours


-----

of service; and the effective contemplation of a seven-day week. These factors combine to portray a level of
oppression having few analogies in contemporary consensual Australian employment conditions. The Court of
Appeal did not err in reaching the opinion that it was open to the jury to so conclude ((2007) 16 VR 454 at [59],

[155], [193]);

(4) There was a lively dispute at the trial as to whether the arrangements with the Thai 'recruiters' or the 'syndicate'
amounted to a 'purchase [of] the women' ((2007) 16 VR 454 at [46]). This is distinct from 'purchasing the contracts'
under which they allegedly agreed to travel to Australia to work in their own interests. However, at least one witness
used the term 'we purchased this woman'. To that extent, evidence was available that the jury could accept about
the attitude of human purchase towards procuring the complainants' services for Ms Tang ((2007) 16 VR 454 at

[46]);

(5) Not every exploitative employment arrangement will warrant the description of 'slavery', including in its extended
Australian statutory form under the Code. Making the distinction between harsh, unconscionable and oppressive
employment and 'slavery' may sometimes be difficult. The notion of 'slavery' should not be debased by
metaphorical applications to non-'slave' conditions. Nevertheless, it was open to the Court of Appeal to reach its
conclusion that the burdens imposed on the complainants were different in

**[*627] kind from even the harshest conditions of 'employment', as such, in contemporary Australia ((2007) 16 VR**
454 at [59]). Upon this basis, it was competent for a properly instructed jury to conclude that the 'employment'
conditions of the complainants involved the exercise over them of at least some of the 'powers attaching to the right
of ownership'. That expression is to be understood in the Australian context where full ownership (in the sense of
'chattel slavery') was unlawful under Imperial legislation dating back to colonial times and remains unlawful under
the Code (the Code, s 270.2);

(6) 'Full ownership' of another human being (and thus 'chattel slavery') is, and has always been, expressly excluded
as a possibility under Australian law. This makes it clear that, in creating 'slavery offences' as it does, s 270.3 of the
Code provides such offences in another, different and extended (statutory) sense. Subject to any constitutional
problems in so providing, it is therefore in this extended sense that the charges of 'slavery offences' preferred
against Ms Tang under the Code needed to be understood. This involved some awareness on the part of the court
of important changes in international law since earlier times. It also involved responding to the evidence of new
forms of people trafficking and exploitation. Subject to the Constitution, there are good reasons why the 'slavery
offences' in s 270.3 of the Code should be given an operation that accords with the language in which the offences
are expressed. The language of s 270.3 should not be artificially narrowed nor its application circumscribed when
invoked for suggested application to new and emerging fact situations; and

(7) It is possible that the complainants, especially when faced with the prospect of deportation as illegal immigrants,
may have been motivated to cooperate with the prosecution of Ms Tang in order to obtain visas to remain in
Australia (Dorevitch and Foster (2008) 9 Melb JIL 1 at 44–45). However, such visas themselves present serious
deficiencies. They are readily cancelled. Their provision does not found an inference that the complainants falsely
elaborated the circumstances of their living and working arrangements with Ms Tang simply to stay in Australia and
to further the economic opportunities that allegedly motivated their journey to Australia in the first place.
_Conclusion: verdicts arguably available_

[82] Subject therefore to what follows, to respond to the issues raised by the appeal and by Ms Tang's application
for special leave to cross-appeal (including on constitutional grounds), no error has been demonstrated in the
conclusion of the Court of Appeal that there was evidence available at the trial to support the second jury's guilty
verdicts and the subsequent convictions of Ms Tang. As long as that trial was not flawed by inaccurate or imperfect
directions on the applicable law, the resulting convictions must therefore stand.
**The legislation**

[83] The reasons of Gleeson CJ set out the relevant provisions of the legislation (reasons of Gleeson CJ at para [5],
above), which I incorporate by reference. That legislation consists of the specific provisions of the Code in


-----

**[*628] respect of the 'slavery offences', introduced by the Criminal Code Amendment (Slavery and Sexual**
Servitude) Act 1999 (Cth), and the general provisions, under Ch 2 of the Code, that govern the required approach
to the 'general principles of criminal responsibility' under the laws of the Commonwealth (including the Code). It is
unnecessary for me to repeat those provisions.
**The issues**

[84] The following issues are raised by these proceedings.

(1) _The meaning of_ 'slavery' _issue. Upon consideration of Div 270 of the Code and relevant provisions of_
international law, did the Court of Appeal err in the 'slavery' definition that it adopted (and, by extension, the
definition of 'slave' in s 270.3(1)(a) of the Code)? Should Ms Tang be granted special leave to cross-appeal to
challenge the approach adopted by the Court of Appeal with respect to the stated ambit of the offence? Before
tackling propounded issues of constitutional validity, it is the conventional methodology of this court to identify first
the meaning to be attributed to the impugned legislation (Bank of NSW v Commonwealth (1948) 76 CLR 1 at 186
per Latham CJ, _Residual Assco Group Ltd v Spalvins_ (2000) 202 CLR 629 at [81] and _Northern Territory of_
_Australia v Arnhem Land Aboriginal Land Trust_ [2008] HCA 29 at [65]). Subject to what I have said in these
reasons, I am in general agreement on this issue with Gleeson CJ (reasons of Gleeson CJ at paras [21]–[35],
above) and Hayne J (reasons of Hayne J at paras [135]–[159], above) about the meaning of 'slavery' and 'slave' in
the Code. Accordingly, the order proposed by Gleeson CJ in respect of the first ground of Ms Tang's notice of
cross-appeal should be made;

(2) The constitutional validity issue. The Court of Appeal rejected Ms Tang's challenge to the constitutional validity
of the offences expressed in s 270.3(1)(a) under which Ms Tang had been charged. It affirmed the validity of the
offences on the footing that the provisions give effect to Australia's obligations under the 1926 Slavery Convention
((2007) 16 VR 454 at [24]). Did the Court of Appeal err in making such findings? Alternatively, was s 270.3(1)(a)
constitutionally valid as within the powers of the Federal Parliament on any of the alternative bases propounded by
the prosecution ((2007) 16 VR 454 at [23]), as supported by the Attorney General of the Commonwealth intervening
in this court? The Court of Appeal did not err in concluding this issue as it did. The definition of 'slavery' in s 270.1 of
the Code, and the consequential offences expressed in s 270.3(1)(a) of the Code, are reasonably proportionate to a
law giving effect to Australia's obligations under the 1926 Slavery Convention. (The 'reasonable proportionality' test
is to be preferred to the opaque and partly circular 'reasonably capable of being considered appropriate and
adapted' test expressed in Victoria v Commonwealth (Industrial Relations Act Case) (1996) 187 CLR 416 at 486–
489. However, there is no basic difference in these two propounded tests of constitutional connection: _Lange v_
_Australian Broadcasting Corpn_ _[[1997] 4 LRC 192 at 208, 212 and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-83HX-00000-00&context=1519360)_ _Mulholland v Australian Electoral Commission_
(2004) 220 CLR 181 at [205]–[206].) In any case, besides the constitutional support afforded by that treaty, other
well-established foundations for constitutional validity exist in

**[*629] the present case. Following the decision of this court in XYZ v Commonwealth (2006) 227 CLR 532, I regard**
the challenge to the constitutional validity of the contested provisions of the Code as barely arguable. Even on the
narrowest view expressed in that case, and assuming that the external affairs power in s 51(xxix) of the Constitution
does not support laws that are solely concerned with matters geographically external to Australia ((2006) 227 CLR
532 at [226] per Callinan and Heydon JJ), there is no such disqualifying defect in the present case. The provisions
of the Code are valid. Accordingly the order proposed by Gleeson CJ, in relation to this ground, should also be
made;

(3) The accuracy of the judicial directions issue. This is the 'critical issue' presented by the appeal. It constitutes the
ground upon which the Court of Appeal concluded that the second trial of Ms Tang had miscarried ((2007) 16 VR
454 at [146]). For reasons that I will explain, the Court of Appeal was right in its conclusion. Accordingly, subject to
what follows, Ms Tang was entitled to have her convictions set aside. That order, and the consequential orders that
followed, should be confirmed by this court;

(4) The unreasonable verdicts issue. Did the Court of Appeal err in concluding that the verdicts of the jury were not
unreasonable or unsupported by the evidence so that (besides the allegedly inaccurate and inadequate directions
on the applicable law) they should otherwise stand ((2007) 16 VR 454 at [194])? For the reasons explained by the


-----

Court of Appeal ((2007) 16 VR 454 at [190]–[193]), by Gleeson CJ (reasons of Gleeson CJ at para [35], above) and
by myself (these reasons at paras [80]–[82], above), the evidence before the jury was otherwise capable of
sustaining the verdicts of guilty that the second jury returned against Ms Tang. This ground of Ms Tang's application
for special leave to cross-appeal therefore fails. The order proposed by Gleeson CJ in that respect should be made.
It follows that the attempt by Ms Tang to persuade this court to substitute orders of acquittal, so as to spare her a
further (third) trial, fails; and

(5) _The miscarriage/proviso issue. The Court of Appeal declined to apply the 'proviso' stated in s 568(1) of the_
Crimes Act 1958 (Vic) with respect to the inaccurate and inadequate directions that it found the trial judge had given
to the jury on the ingredients of the slavery offences ((2007) 16 VR 454 at [195]–[197]). Did the Court of Appeal err
in so deciding? In this court, the prosecution ultimately contested an order for a retrial on the basis of the conclusion
reached by the Court of Appeal on the 'essential issue' as it defined it. There was no error in the reasoning of that
court (cf Weiss v R (2005) 224 CLR 300 at [45]–[46]; see also AK v Western Australia (2008) 82 ALJR 534 at [59]
[per Gummow and Hayne JJ, at [87] per Heydon J and R v CTM [2008] HCA 25, [2008] 5 LRC 44 at [132]). If the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-84CK-00000-00&context=1519360)
conclusion of the Court of Appeal on the errors and inadequacies of the impugned directions is otherwise sustained
by this court, the dispositive orders made below will likewise be upheld. This would result in a retrial of Ms Tang
even though a third trial would be most unfortunate (see R v Wei Tang [2007] VSCA 144 at [10]). Any relief against
a third trial would have to rest in the discretion of the prosecution.

[85] From the foregoing it follows that all but one of the issues that have been propounded in these proceedings
(including some that were not

**[*630] continued in this court (for example, the ground complaining of lack of balance in the trial judge's charge to**
the jury and the ground complaining of excessive judicial intervention during cross-examination; see (2007) 16 VR
454 at [159]–[189])) fall away. That leaves only the accuracy of the judicial directions issue relating to the intention
of Ms Tang necessary for her to be found guilty of the 'slavery offences' charged. I turn to that issue to explain why I
come to a conclusion different from my colleagues.
**Remaining issue: judicial directions on intentionThe issue defined**

[86] The issue that divides this court is whether, in the second trial, the trial judge gave sufficiently accurate and
clear directions to the jury on the ingredients of the offences with which Ms Tang was charged.

[87] Juries cannot be expected to know the law. They must rely on the judge, presiding in the trial, to explain to
them, accurately and clearly, the legal ingredients of the offences with which the accused stands charged and of
any defences that arise for consideration. It is not the duty of the judge to give the jury a general disquisition on the
law or to burden them with immaterial or unnecessary directions (Alford v Magee (1952) 85 CLR 437 at 466. See
_Melbourne v R_ _[[2000] 2 LRC 294 at [143] per Hayne J). However, unless the charges are explained to the jury](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-84G0-00000-00&context=1519360)_
accurately and clearly, with assistance on the application of the law to the facts as appropriate, a fundamental
assumption of trial by jury is undermined.

[88] As the Court of Appeal pointed out, the 'trial judge had the misfortune to be the first judge in Australia called on
to devise directions for these novel offences' ((2007) 16 VR 454 at [93]). This is a reason to avoid overly pernickety
approaches to Ms Tang's challenge to those directions. But it cannot be a reason for denying Ms Tang an accurate
trial that conforms to the law as stated by the Parliament.

[89] The matter that concerned the Court of Appeal was the explanation given by the trial judge 'as to the elements
of the offences created by s 270.3(1)(a)'. Relevantly, that issue concerns the character and quality of the exercise
of power by the accused over the victim who is alleged to be a 'slave' ((2007) 16 VR 454 at [66]). In the Court of
Appeal, Eames JA, a judge with much experience in criminal trials and law, concluded that the approach urged by
the prosecution, and adopted by the judge at the trial, 'did not correctly identify the elements of the offences which
the [prosecution] had to establish'. Specifically, by reference to s 5.2 of the Code (which contains the explanation of
the general principles of criminal responsibility in respect of 'intention'), Eames JA concluded that, to make good the
offences in s 270.3(1)(a), the prosecution had to prove the following against Ms Tang ((2007) 16 VR 454 at [77]


-----

(citations omitted); Eames JA explained that he would use the 'neutral descriptor of “worker” ', inferentially instead
of using the conclusory word 'victim'):

'First, the worker must have been reduced to the condition that would constitute her a slave, as defined in the

[Code]. The jury must be satisfied that she had had powers exercised over her as though she was mere

**[*631] property, with the result that she had been reduced to the status of mere property, a thing, over whom**
powers attaching to the right of ownership could be exercised. Secondly, the accused must have known that
the worker had been reduced to a condition where she was no more than property, a thing, over whom persons
could exercise powers as though they owned her. Thirdly, the accused must have intentionally possessed the
worker, that is, must have intentionally held her in her custody or under her physical control. Fourthly, the
accused must have possessed the worker in the intentional exercise of what constitutes a power attaching to a
right of ownership, namely, the power of possession. For that to be the case the accused must be shown to
have regarded the worker as though she was mere property, a thing, thereby intending to deal with her not as a
human being who had free will and a right to liberty, but as though she was mere property. However harsh or
oppressive her conduct was towards the worker it would not be sufficient for a conviction if, rather than having
possessed the worker with the knowledge, intention, or in the belief that she was dealing with her as though
she was mere property, the accused possessed her in the knowledge or belief that she was exercising some
different right or entitlement to do so, falling short of what would amount to ownership, such as that of an
employer, contractor, or manager.'

[90] I do not take there to be a present dispute concerning the first three 'elements of the offences' identified in the
foregoing passage. There was also no disagreement over the trial judge's direction to the jury that it was not
essential that Ms Tang should know that the 'worker' was, in law, a 'slave'. Although ignorance of the law is no
excuse, the provisions of s 270.3(1)(a) of the Code do not postulate that a person, such as Ms Tang, will
necessarily be aware of the categories and classifications of Australian law. Still less would such a person be
expected to know the provisions of an international treaty dating back to 1926. The Code, however, is intended to
bring proved 'physical' and 'fault' elements together in particular evidentiary circumstances to render a person
answerable for 'criminal responsibility under laws of the Commonwealth' (the Code, s 2.1; see also s 3.1(1)). This
befits a contemporary federal statute that imposes criminal liability on people for their acts and omissions within
Australia.

[91] The basic reason for adopting this view arises from the language and structure of the Code itself. That is the
starting point for an analysis of the offences with which Ms Tang was charged. However, there are several other
reasons that support the approach to the construction of the Code adopted by the Court of Appeal. In the balance
of these reasons, I will explain what I consider to be the most important arguments favouring the approach that the
Court of Appeal adopted.
_Analysis of the statute_

[92] Relevant here are not only the 'slavery offences' with which Ms Tang was charged under s 270.3(1)(a) of the
Code but also the more general 'physical' and 'fault' element provisions under Ch 2 of the Code. These latter

**[*632] elements are declared by the Parliament to be necessary in Australia for criminal responsibility under federal**
law (pursuant to ss 3.1(1) and 5.2(1) of the Code).

[93] The starting point is the structure of s 270.3(1). In expressing the relevant 'slavery offence', the word
'intentionally' is placed in the chapeau, above the particular offences that follow. These include the provisions of
para (a) under which Ms Tang was charged. By the ordinary application of the principles of statutory construction, it
must therefore be accepted that the adverb 'intentionally' was designed to modify the entirety of the subsequent
paragraphs. Thus, it is not enough for the accused to 'possess' a slave or to 'exercise' over a slave 'any of the other
powers attaching to the right of ownership'. To be guilty of the offence provided by the Code, the accused must do
these things, and all of them, 'intentionally'.

[94] That paragraph contains descriptors of 'physical elements', such as 'possessing' a slave or 'exercising' powers
'attaching to the right of ownership' over a slave However the general principles of criminal responsibility contained


-----

in Ch 2 of the Code also make it clear that such 'physical elements' alone are not sufficient to secure a conviction.
There must be a relevant combination of both 'physical' and 'fault' elements. In the present appeal (as was properly
acknowledged by the prosecution in its conduct of Ms Tang's trial) it was common ground that the applicable 'fault
element' was the 'intention' of the accused. This is clear enough because of the inclusion of the adverb
'intentionally' in the chapeau to s 270.3(1).

[95] Where 'intention' is the applicable 'fault element', as here, s 5.2(1) of the Code provides that '[a] person has
intention with respect to conduct if he or she means to engage in that conduct'. Quite apart from the introductory
adverb in the language of s 270.3(1) of the Code, it is clear that the prosecution must prove beyond reasonable
doubt that the accused had the 'intention' to engage in the relevant conduct. Thus, in a case brought under s
270.3(1) of the Code, the 'intention' is not simply an 'intention' addressed to the 'physical elements' concerned with
'possession' or the exercise of powers attaching to the 'right of ownership'. It is also an intention directed to the
underlying entitlement that gives rise to those elements. Without that ingredient of the offence, the word
'intentionally' might just as well not have been present in s 270.3(1).

[96] In effect, the construction urged by the prosecution (and now adopted by this court) either ignores the word
'intentionally' at the head of the subsection or treats it as relevant only to the physical elements involved in the
treatment of a person. It does not, as s 270.3(1)(a) indicates by its language and structure, also govern the quality
and character of those physical elements so that they amount, in law, to 'possession' or to 'exercis[ing] over a slave
any of the other powers attaching to the right of ownership'.

[97] Paragraph (a) of s 270.3(1) of the Code uses legal notions such as 'possession' and 'rights of ownership'
preceded by the statutory requirement that such 'physical elements' should be exercised 'intentionally'. This imports
into the constituent elements of the offences charged an appreciation, belief or realisation by the accused
('intentionally') of the entitlement to assert the 'physical elements' that go to make up the offences.
**[*633] Relevant canons of construction**

[98] A fundamental canon of construction that supports the Court of Appeal's approach is reflected in the
acknowledgment, in extrinsic statutory material, that—

'slavery is more than merely the exploitation of another. It is where the power a person exercises over another
effectively amounts to the power a person would exercise over property he or she owns.' (See the revised
Explanatory Memorandum to the Criminal Code Amendment (Slavery and Sexual Servitude) Bill 1999 (Cth) at
4, cited by the Court of Appeal: (2007) 16 VR 454 at [27].)

[99] To exercise such a power, as if over property that the person owns or possesses, it is inherent that the person
deploying that power does so based upon a notion of that person's entitlement to act as he or she does. What is
done is not done mindlessly, thoughtlessly or carelessly. It is done out of a sense of power, founded on a sense of
entitlement. Thus the language and structure of the legislation, and the terms of the Explanatory Memorandum,
support the approach of the Court of Appeal. And basically that is enough.

[100] Two additional considerations further reinforce the conclusion adopted by the Court of Appeal. The first, which
Eames JA noted ((2007) 16 VR 454 at [85]), is that the Code comprises penal legislation which is conventionally
construed strictly because of the consequences of serious punishment that may follow from a conviction (cf He Kaw
_Teh v R_ _[[1986] LRC (Crim) 553 at 602–603 per Brennan J and Murphy v Farmer (1988) 165 CLR 19 at 28–29). To](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
the extent that there is any residual doubt about the meaning and requirement of the provisions of the Code to Ms
Tang's case, the Court of Appeal adopted such an approach and that approach is to be preferred.

[101] Secondly, the introduction of 'slavery offences' into the Code enacted novel crimes that have to be read
together with general principles of the Code governing criminal responsibility. Those principles are, in turn, in some
ways new. They must be given meaning according to their terms and in consideration of the context and purpose of
the reforms they introduce. Nevertheless, these provisions are themselves written against the background of the
basic doctrines of criminal law as they operate throughout Australia. It will generally be presumed that the language
of a code that is designed to state criminal offences applicable in Australia is intended generally to reflect, and not


-----

to depart from, long-observed basic principles of criminal liability (R v Barlow (1997) 188 CLR 1 at 32; the passage
cites Vallance v R (1961) 108 CLR 56 at 75–76 and Parker v R (1997) 186 CLR 494 at 517–519).

[102] With respect, it is not persuasive to suggest (reasons of Gleeson CJ at para [49], above) that the approach
favoured by the majority is supported by the 'common exercise of relating the fault element to the physical elements
of the offence' (referring to _He Kaw Teh v R_ _[[1986] LRC (Crim) 553 at 591). The ultimate duty of this court is to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
construe the language of the Code. (This is a special example of the general rule mandating the primacy of
statutory language as the source of, and starting point for deriving, legislative obligations. Recent cases are set out
in Central Bayside General Practice Association Ltd v Comr of State Revenue (Vic) (2006) 228 CLR 168 at [84], fn
86.

**[*634] See also R v Barlow (1997) 188 CLR 1 at 31–33.) This must be done by reference to the text of the Code**
and a consideration of the context of the relevant provisions and their purpose of expressing a new approach to the
application of the 'fault elements' of federal offences. When this approach is adopted, the language of the Code,
and especially the structure of the provisions in which that language appears (the chapeau of s 270.3(1)), argue
powerfully against the conclusion reached by the majority. This approach instead supports the analysis adopted by
the Court of Appeal.

[103] In any case, when considering basic principles of criminal law, one such principle is the common law
presumption that no person will be punished criminally 'for doing an act which he honestly and reasonably believes
to be lawful and right' (R v Tolson _[(1889) 23 QBD 168 at 182; see R v CTM [2008] HCA 25, [2008] 5 LRC 44 at [4]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V1D-FPY2-8T41-D2JT-00000-00&context=1519360)_
per Gleeson CJ, Gummow, Crennan and Kiefel JJ, at para [61] of my own reasons). To the extent that they are
consistent with the Code, fundamental principles of criminal responsibility inform the construction of such statutory
[provisions (R v CTM [2008] HCA 25, [2008] 5 LRC 44 at [5] per Gleeson CJ, Gummow, Crennan and Kiefel JJ, at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-84CK-00000-00&context=1519360)
para [61] of my own reasons, at [146] per Hayne J). It would require very clear statutory language to render the
mere performance of an act criminally blameworthy, without regard being had to the 'golden thread' (Woolmington v
_DPP_ _[[1935] AC 462 at 481) which has been present in Australian (and earlier English) criminal law for at least](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-20DC-00000-00&context=1519360)_
seventy years. In the present case, this is not to oblige (in effect) that the accused should know the precise terms of
the statute or of antecedent treaties. It is simply to apply the statutory postulate of 'intention' not only to the physical
elements but also to their quality and the 'circumstances [that] make [them] criminal' (He Kaw Teh v R _[[1986] LRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
_[(Crim) 553 at 594per Brennan J).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_

[104] General considerations such as these confirm the conclusion of the Court of Appeal in this case (cf R v CTM

[2008] HCA 25, _[[2008] 5 LRC 44 at [6] per Gleeson CJ, Gummow, Crennan and Kiefel JJ, at [108] of my own](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-84CK-00000-00&context=1519360)_
reasons). The mere existence of what the Code now describes as 'physical elements' (relevantly 'possession' and
'the right of ownership') does not, on conventional theory, ordinarily attract criminal liability to a person accused in
Australia of a serious criminal offence. Something more is required. That something is the 'mental element' (mens
rea as formerly described) on the part of the accused, or as is now described in the Code, the 'fault element'. This
element is essential to constitute, with a 'particular physical element', responsibility in law for an offence against
federal criminal provisions.

[105] The Court of Appeal's approach gives full force and effect to these basic notions of our criminal law. So much
is required by the language and structure of the Code. However, if there were any ambiguity, this is the approach
that this court should take. It conforms more closely to the 'general principles of criminal responsibility' expressed in
Ch 2 of the Code and also in the basic doctrines of contemporary Australian criminal law. It is against this
background that the Code provisions were formulated and enacted.
**[*635] Further considerations in support**

[106] A number of additional considerations lend still further support to the approach adopted by the Court of
Appeal.
_Traditional approach to 'intention'_

[107] Having something in 'possession' (or asserting over something 'powers attaching to the right of ownership')
will not ordinarily render a person liable for a criminal act unless the mind ('intention') of the person combines with


-----

the physical elements. Take, for example, someone who carries a suitcase containing a prohibited drug over a
border. The physical elements involved in such 'possession' of that drug (or the assertion of powers attaching to the
'right of ownership' over the suitcase) would not, on conventional theory, alone be sufficient to render the carrier
criminally liable. The prosecution would have to identify and prove that the accused was aware of the nature and
quality of the control asserted over the import in question. It is not enough that the suitcase should, in physical fact,
contain a prohibited drug. The prosecution must establish, to the requisite standard, that the accused knew that the
drug was present and intended to perform the physical acts amounting to a criminal importation (He Kaw Teh v R

_[[1986] LRC (Crim) 553 at 604–605 per Brennan J).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_

[108] Innocent parties fall outside the ambit of the offences provided by s 270.3(1) of the Code. This is precisely
because the requirement of 'intentionally', as expressed in the chapeau to the subsection, imports a necessity of
consciousness of the quality, source and purported basis or justification of the 'possession' and 'right of ownership'
being asserted. All of this is simply to insist that, under the Code, as conventionally at common law, the mere acts
of 'possession' or 'ownership' alone are not enough to constitute the criminal offence. The necessary added
ingredient is the presence of the intention to which s 270.3(1) refers, addressed to the quality and character of the
acts charged.

[109] The Court of Appeal correctly insisted upon the necessity of this ingredient. Correctly, it concluded that its
absence from the directions of the trial judge to the jury constituted a serious omission in explaining to the jury the
legal components of the offences charged.
_Conformability with international law_

[110] The present task is to construe and apply the Code, an Australian statute. However, the ostensible purpose of
the relevant provisions was to introduce into Australian municipal law offences derived substantially from the 1926
Slavery Convention.

[111] The interpretation of s 270.3(1) favoured by the Court of Appeal is more consonant with that Convention and
the extremely grave international crime that 'slavery', so expressed, involves. As stated in the Code (the Code, s
268.10), slavery, like piracy (Simpson Law, War and Crime: War Crimes Trials and the Reinvention of International
_Law (2007) p 159), is a crime against humanity. (Prosecutor v Kunarac (Case No IT-96–23-T & IT-96–23/1-T, 22_
February 2001) (Trial Chamber) at [522], [526] and (Case No IT-96–23 & IT-96–23/ 1-A, 12 June 2002) (Appeals
Chamber) at [13]), Jennings and Watts

**[*636] (eds) Oppenheim's International Law (9th edn, 1992) vol 1, Pts 2 to 4, §429 and Bassiouni 'Enslavement as**
an International Crime' (1991) 23 NYUJIL & Pol 445 at 448. Some of the above references refer to the term
'enslavement', which is none the less applicable in the present circumstances. As noted in Prosecutor v Kunarac
(Case No IT-96–23-T & IT-96–23/1-T, 22 February 2001) (Trial Chamber) at [539], 'enslavement' consists of the
'exercise of any or all of the powers attaching to the right of ownership over a person'. Further, _Prosecutor v_
_Kunarac (Case No IT-96–23 & IT-96–23/1-A, 12 June 2002) (Appeals Chamber) at [123] equates the terms 'slavery'_
and 'enslavement'.) Thus those who engage in 'slavery', piracy and other special crimes are enemies of mankind
(see Simpson _Law,_ _War and Crime: War Crimes Trials and the Reinvention of International Law_ (2007) p 159).
Such offences arguably attract obligations that attach to crimes of universal jurisdiction (cf _R v Bow Street_
_[Metropolitan Stipendiary Magistrate, ex p Pinochet Ugarte (No 3) (Amnesty International intervening) [1999] 1 LRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-83YV-00000-00&context=1519360)_
_[482 at 499–500, 510–514, 58–5909). As a rule jus cogens (Hannikainen](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-83YV-00000-00&context=1519360)_ _Peremptory Norms_ (Jus Cogens) _in_
_International Law (1988) pp 446–447, Meron Human Rights and Humanitarian Norms as Customary Law (1989) pp_
20–21, Henkin _International Law: Politics and Values (1995) p 39, Schachter_ _International Law in Theory and_
_Practice (1991) p 343 and Drew 'Human Trafficking: A modern form of slavery?' (2002) 7 EHRLR 481 at 481),_
slavery is prohibited as a peremptory norm from which no derogation is permitted (Vienna Convention on the Law of
Treaties 1969, art 53). This further reinforces the seriousness of slavery and hence the need to define it very
carefully and precisely.

[112] I therefore agree with Gleeson CJ that, without the clearest statutory authority, it is undesirable to banalise
slavery crimes by applying them to circumstances that would amount to no more than a seriously exploitative
employment relationship (reasons of Gleeson CJ at para [32], above). The approach of the Court of Appeal requires


-----

consideration by the decision-maker of the quality and extent of the accused's 'intention'. To that extent, in asserting
'possession' and 'rights of ownership' over another person as a 'slave', the crimes provided by s 270.3(1) are
reserved to indisputably serious offences containing a substantial, not trivial, intention element.

[113] To the extent that the intention element is restricted to conduct in relation to a person, with no attention being
given to the perpetrator's intention, there is a serious risk of over-expansion of the notion of 'slavery'. The approach
of the Court of Appeal is more rigorous. Such rigour is more appropriate to a crime defined by reference to the
universal international offence of 'slavery'.
_Consistency with severe punishment_

[114] All of the foregoing is yet further reinforced by a reflection upon the maximum penalty that the Code provides
upon conviction of the s 270.3(1) slavery offences.

[115] The maximum penalty of imprisonment for 25 years ((2007) 16 VR 454 at [53]) is one of the highest now
provided under Australian legislation. This feature helped to reinforce the conclusion of the Court of Appeal that the
applicable 'fault element' of 'intention' should apply in the manner

**[*637] adopted by Eames JA (cf He Kaw Teh v R** _[[1986] LRC (Crim) 553 at 602–603 per Brennan J). His Honour](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
remarked ((2007) 16 VR 454 at [84]):

'Lack of control of the “slave” over her life, and her lack of personal liberty, may well suggest that she is being
treated as though she were mere property—as a thing—but more is required to be proved for an offence under
s 270.3(1)(a). And much more is required than that the person be shown to have been exploited, abused or
humiliated, whether physically, emotionally or financially. To be a slave, the person must be in a state where he
or she is dealt with by others as though he or she was mere property—a thing. For the exercise of the power to
contravene s 270.3(1)(a) the accused must have knowingly treated the person as though he or she was the
accused's property. Only when that state of mind exists is the exercise of power referable to a right of
ownership, as the section requires.'

_Comparison with human trafficking_

[116] In a case such as the present it is important for the judicial decision-maker to be familiar with contemporary
instances of human trafficking. Human trafficking involves the movement, recruitment or receipt of persons, often by
means of the threat or use of force, for the purpose of exploitation (see Protocol to Prevent, Suppress and Punish
Trafficking in Persons, Especially Women and Children, Supplementing the United Nations Convention Against
Transnational Organized Crime 2000, art 3; International Labour Office _Trafficking in Human Beings: New_
_Approaches to Combating the Problem (2003) at 6; International Labour Office (Belser, de Cock and Mehran) ILO_
_Minimum Estimate of Forced Labour in the World (2005) at 4–6). As such, it commonly operates in conjunction with,_
or as part of, slavery. (See Rome Statute of the International Criminal Court 1998, art 7(2)(c); United Nations
Economic and Social Council _Contemporary Forms of Slavery UN Doc E/CN.4/Sub.2/2000/3 (2000) at para 48;_
Tessier 'The New Slave Trade: The International Crisis of Immigrant Smuggling' (1995) 3 Indiana Journal of Global
Legal Studies 261 at 261–262; Bassiouni _Crimes Against Humanity in International Criminal Law (2nd rev edn,_
1999) p 212; Levchenko Combat of Trafficking in Women for the Purpose of Forced Prostitution—Ukraine (Country
_Report) (1999) at 23. For a comprehensive analysis of the relationship between slavery and trafficking, see_
Hathaway 'The Human Rights Quagmire of “Human Trafficking” ' (2008) 49 Vir JIL 1.) Women and children are
particularly vulnerable to human trafficking and they are often subjected to sexual and other physical and emotional
exploitation. This abhorrent activity commonly involves conditions of infancy, serious vulnerability, shocking living
and working conditions and repeated violence, oppression and humiliation.

[117] The close connection between human trafficking, as described, and 'slavery' serves to reinforce the extremely
serious nature of such 'slavery offences'. Given the nature of 'slavery', as understood in international law, there is a
great need to not over-extend 'slavery offences' to apply to activities such as seriously oppressive employment
relationships. The approach adopted

**[*638] by the Court of Appeal is more consistent with such an aim. The approach of the majority in this court is not.**


-----

_Distinguishing 'slavery' from debt bondage_

[118] Since the actions occurred for which Ms Tang was charged, the Parliament has amended the Code to
introduce into Australian law ((2007) 16 VR 454 at [86]) a new and discrete offence of 'debt bondage'. (The Code, s
271.8. 'Slavery' and 'debt bondage' are often treated separately in international instruments. See, for example, the
1956 Supplementary Convention, arts 1(a), 7(b) ('debt bondage' as a 'person of servile status') and art 7(a)
('slavery').) As Eames JA remarked ((2007) 16 VR 454 at [87] (footnote omitted)):

' “Debt bondage” is defined in the Dictionary of the Code as arising when a person pledges personal services
as security for a debt and the debt is manifestly excessive, or the reasonable value of the services provided is
not applied in reduction of the debt, or the length and nature of the services are not limited and defined.
Arguably, that offence would have been proved on the evidence in this case and, if so, it would have carried a
maximum sentence of 12 months' imprisonment. There being no such provision, [Ms Tang] was charged with
slavery offences, which carried a maximum sentence of 25 years … [S]he received a total effective sentence of
10 years' imprisonment with a non-parole period of six years, although she had no prior convictions.'

[119] Responding to a question asked during the hearing, the Attorney General of the Commonwealth
acknowledged that:

'After examining the legislation of the United States, Canada, South Africa, New Zealand and the United
Kingdom, we have not identified any provisions that implement the Convention in terms similar to those found
in Australia's Criminal Code.'

The closest analogy to the Australian provisions was said to be s 98(1) of the Crimes Act 1961 (NZ). (This section
creates an offence of dealing with, using or detaining a person as a slave and defines 'debt bondage' in terms
similar to the 1956 Supplementary Convention (art 1). See also R v Decha-Iamsakun [1993] 1 NZLR 141.)

[120] None of the states mentioned above have implemented the Convention in a similar way to that of the Code
here. This affords a further reason why, in respect of the 'slavery offences' in s 270.3(1)(a) of the Code, this court
should adopt the more stringent requirement of proof of intention favoured by the Court of Appeal. Doing so would
ensure that Australian law remained in broad harmony with the law of similar countries. Especially in relation to
crimes having a universal or transnational character, that is a proper interpretive consideration.
_Shift in law on sex work_

[121] As to the extension of 'slavery' to adult consensual participation in the commercial sex industry, it is also
important for courts such as this to give due

**[*639] weight to recent changes in Australian law (including in Victoria). Those changes reflect a recognition by**
Parliament that adults (as the prosecution conceded before this court) are entitled to participate in the sex industry
lawfully. This includes participation as sex workers, consensually, for economic reasons. Attempts to use 'slavery
offences' to suppress commercial sex work, based upon individual repugnance towards adult sexual behaviour,
potentially contradict the law enacted by the Victorian Parliament. The simple fact is that some commercial sex
workers have no desire to exit the industry. Some people may find that shocking; but it matters not. In Victoria, so
long as the sex worker is a consenting adult with no relevant disability, that is a choice open to her or him. The
contrary approach risks returning elements of the sex industry to operate, as was previously the case, covertly,
corruptly and underground. This would undermine the fundamental objectives of the recent Australian legislation in
this area, such as that of Victoria under which the brothel where the complainants worked was licensed (Prostitution
Control Act 1994 (Vic)).

[122] Such developments could also prove counterproductive to important purposes of the recent legislation.
Specifically, such purposes include empowering sex workers to safeguard their own lives and wellbeing and
thereby assisting in the reduction of the spread of sexually transmitted diseases, including the human
immunodeficiency virus. (See United Kingdom, Committee on Homosexual Offences and Prostitution Report of the
_Committee on Homosexual Offences and Prostitution (1957) Cmnd 247 at para 286 (Wolfenden Report); Lacey,_
Wells and Meure Reconstructing Criminal Law (1990) pp 357–368; cf Bodyline Spa and Sauna (Sydney) Pty Ltd v


-----

_South Sydney City Council (1992) 77 LGRA 432 at 433–438 and Gostin and Lazzarini Human Rights and Public_
_Health in the AIDS Pandemic (1997) pp 50–51, 124–125.) These policy considerations (although not mentioned by_
the Court of Appeal) offer additional reasons of legal principle and policy to confine 'sexual slavery' offences in
Australia to cases where the specific element of 'intention' includes exerting powers of possession or ownership
over a person because of an established belief, on the part of the accused, that it is his or her right and entitlement
to do so.
_The jury's repeated questions_

[123] The Court of Appeal's approach on this issue was by no means an esoteric one. This is made clear by the
questions which the jury in the second trial returned twice to ask. The first question was ((2007) 16 VR 454 at

[122]):

'Does the defendant have to have known what the definition of a slave is “to intentionally possess a slave” as
stated in the indictment.'

[124] The second question, presented the following afternoon, was ((2007) 16 VR 454 at [129]):

'To intentionally possess a slave is it necessary for the accused to have knowledge that her actions amount to
slavery? or

Is it sufficient that the accused only have knowledge of the conditions she has imposed (ie slavery has not
entered her mind) and the law has decided those conditions amount to slavery.'

**[*640] [125] The members of the jury in the second trial were obviously puzzled over these questions and the**
members of the jury in the first trial were unable to reach verdicts. It is thus reasonable to infer that considerations
as to the requisite _intention of Ms Tang may be foremost in the minds of Australian jurors as they seek to_
differentiate activities that amount to seriously oppressive employment from those that justify conviction of 'slavery
offences' against s 270.3(1)(a) of the Code.
_Court of Appeal's answers_

[126] Instead of the partly unresponsive, generally unclear and confusing answers given by the trial judge to the
foregoing questions, the Court of Appeal (consistent with its approach) favoured the following answers. In my
opinion, they are correct. They are not confusing. They respond precisely to the concern expressed by the jury
about the 'fault element' of 'intention' that the Code requires to be proved to establish the 'slavery offences'. Eames
JA said ((2007) 16 VR 454 at [145]):

'With the benefit of hindsight, and the luxuries of time and the provision of comprehensive submissions of
counsel on the appeal, I would respectfully suggest that the answers to the jury questions might have been
along the following lines:

[As to the first question]

A—No, she does not have to have known the definition of a slave, nor even that there was an offence of
slavery in the laws of Australia. Ignorance of the law is no defence (see s 9.3 of the Code).

The Crown has to prove that she did know that in each case the worker had been reduced to a condition in
which she was treated as though she was mere property, just a thing, who had no say in how she was treated.

[As to the second question]

A—It is not necessary for the accused to have knowledge that her actions amount, in law, to slavery.

For the offence of intentionally possessing a slave, the accused must have known that the complainant had
been reduced to a condition where she was no more than property, merely a thing, over which the accused
could exercise powers as though she owned the complainant.


-----

Furthermore, the Crown must prove that in exercising the relevant power over a particular complainant (that is,
possessing or using the complainant) the accused was treating that complainant as though she was property,
as if she owned her, as if she could do with her whatever she chose to do. You must be satisfied that the
accused was intentionally exercising a power that an owner would have over property and was doing so with
the knowledge or in the belief that the complainant was no more than mere property.

If it is reasonably possible that the accused acted to possess or to use the complainant with the knowledge or
in the belief that she was exercising her rights and entitlements as her employer or contractor and not in the
belief that the complainant had no rights or free will, but was property, a thing, over whom she could exercise
power as though she

**[*641] owned her then, however exploitative and unfair you may think her treatment of the complainant was, it**
would not constitute the offences of intentionally possessing or using a slave.'

[127] Such answers would have provided accurate and adequate instructions to the jury and clear responses to
their questions. These suggested answers may be contrasted with the very confusing directions actually presented
to the jury by the trial judge (set out at length by the Court of Appeal: (2007) 16 VR 454 at [122]–[139]).
_Conclusion: miscarriage of the trial_

[128] I leave aside the justifiable criticisms by the Court of Appeal of the unresponsiveness, ambiguity and
uncertainty of the directions given to the jury. These criticisms alone raise serious questions about the compliance
of Ms Tang's trial with the standards established by this court for the comprehensibility and accuracy of jury
directions (Ahern v R (1988) 165 CLR 87 at 103, _Zoneff v R_ (2000) 200 CLR 234 at [65]–[67] and _Doggett v R_
(2001) 208 CLR 343 at [2] per Gleeson CJ). The Court of Appeal considered authorities of this court and came to
the correct conclusion on this 'critical issue'. It is the conclusion that I also reach. It leaves a continuing substantive
operation for 'slavery offences' under Australian law, as the valid provisions of s 270.3(1)(a) of the Code require. It
allows such offences to apply in contemporary circumstances warranting the appellation of 'slavery'. It properly
confines such offences to the grave affront to humanity that is 'slavery' eo nomine, as expanded by statute in
Australia to include modern instances, and not to employment deemed harsh, oppressive or repulsive.

[129] As the Court of Appeal concluded, there was evidence upon which a reasonable jury, properly instructed,
might have arrived at the decision that 'slavery offences' of the kind provided for in the Code had been proved
against Ms Tang. However, it was essential for the 'fault element' of 'intention' to be applied to _all, and not just_
_some, of the ingredients of the offences and to be accurately and clearly explained to the jury. Despite the jury's_
repeated questions, this was not done. The result is that Ms Tang's second trial miscarried. The outcome favoured
by the Court of Appeal was then inevitable. There should be a new trial.
**Orders**

[130] It follows that I agree with Gleeson CJ that special leave to cross-appeal on the first and second grounds in
the proposed notice of cross-appeal should be granted. That cross-appeal should be treated as instituted and heard
instanter and dismissed. I also agree with Gleeson CJ that special leave to cross-appeal on the third ground in the
proposed notice of cross-appeal should be refused.

[131] However, the appeal from the orders of the Court of Appeal of the Supreme Court of Victoria should be
dismissed.

**HAYNE J.**

[132] I agree with Gleeson CJ that, for the reasons he gives, the appeal to this court should be allowed. I also agree
with Gleeson CJ that, for the

**[*642] reasons he gives, orders should be made granting the respondent special leave to cross-appeal, limited to**
the first two proposed grounds of cross-appeal, but dismissing the cross-appeal. I agree that consequential orders
should be made in the form proposed by Gleeson CJ.


-----

[133] Section 270.3(1)(a) of the Criminal Code (Cth) ('the Code') makes it an offence intentionally to possess a
slave or to exercise over a slave 'any of the other powers attaching to the right of ownership'. The central issue in
the appeal concerns what directions should have been given to the jury at the respondent's trial about the mental
element of the offences of possessing or using a slave. I agree with Gleeson CJ that, contrary to the holding of the
Court of Appeal (R v Wei Tang (2007) 16 VR 454 at [77], [124], [145]), the prosecution did not have to prove that
the respondent had any knowledge or belief about the source of the powers she exercised over the complainants.
What was to be proved was the intentional possession and use of each complainant as a slave, which is to say as a
person over whom any or all of the powers attaching to the right of ownership were exercised.

[134] I agree with what Gleeson CJ has said about the application of Ch 2 of the Code to s 270.3(1). The relevant
fault element of each of the offences with which the respondent was charged was intention (Criminal Code (Cth), ss
5.1, 5.2). The conduct, which is to say the act or state of affairs (s 4.1(2)), in question in this matter was possessing
a slave or using a slave. To establish the relevant fault element in this case it was necessary to show that the
respondent meant to engage in the conduct, in respect of each complainant, of exercising powers attaching to the
right of ownership.

[135] The remaining part of these reasons is directed to the meaning, and application in this case, of the terms
'slavery' and 'slave' when used in the relevant provisions of the Code. 'Slavery' is defined (s 270.1) as follows:

'For the purposes of this Division, _slavery is the condition of a person over whom any or all of the powers_
attaching to the right of ownership are exercised, including where such a condition results from a debt or
contract made by the person.'

'Slave' is not separately defined but must take its meaning from the definition of 'slavery'.

[136] As Gleeson CJ has pointed out, the definition of 'slavery' in the Code derives from, but is not identical with, the
definition of 'slavery' in art 1(1) of the 1926 International Convention to Suppress the Slave Trade and Slavery
([1927] Australian Treaty Series 11). Because the purpose of the Convention was to suppress the slave trade and
slavery it was directed to both the status of slavery and the condition of slavery. The status of slavery, in the context
of the Convention, is to be understood as referring to a legal status created by or recognised under relevant
municipal law. By contrast, the condition of slavery is to be understood as referring to a factual state of affairs which
need not, but may, depend upon recognition by the relevant municipal legal system. Yet both that status and that
condition were defined in the Convention in identical terms: as a status or condition of a person over whom any or
all of the powers attaching to the right of ownership are exercised.

[137] The language of the Convention, whether in its definition of slavery

**[*643] or otherwise, cannot be read as if it gave effect to or reflected particular legal doctrines of ownership or**
possession developed in one or more systems of municipal law. Nothing in the preparatory materials relating to the
Convention suggests that it was intended to embrace any particular legal doctrine of that kind and the text of the
Convention itself does not evidence any such intention. Rather, slavery (both as a legal status and as a factual
condition) was defined only by a description that assumed an understanding, but did not identify the content, of 'the
powers attaching to the right of ownership'. Yet for the purposes of creating particular norms of individual behaviour
enforceable by application of the criminal law, the definition of 'slavery' that is adopted in s 270.1 of the Code takes
as its origin the definition of slavery, as a condition, that was given in the Convention.

[138] What are the 'powers attaching to the right of ownership'? How are they to be identified when the Code is
applied, given that the Convention did not use the term 'ownership', or the expression 'powers attaching to the right
of ownership', with a legal meaning that was anchored in any particular legal system? Both 'ownership' and the
'powers attaching to the right of ownership' must be understood as ordinary English expressions and applied having
regard to the context in which they are to be applied. The chief feature of that context is that the subject of
'ownership', the subject of the exercise of 'powers attaching to the right of ownership', is a human being.

[139] Because 'ownership' cannot be read in s 270.1 of the Code as a technical legal term whose content is spelled
out by a particular legal system, it is a word that must be read as conveying the ordinary English meaning that is


-----

captured by the expression 'dominion over' the subject matter. That is, it must be read as identifying a form of
relationship between a person (the owner) and the subject matter (another person) that is to be both described and
identified by the powers that the owner has over that other.

[140] 'Ownership' ordinarily is to be understood as referring to a _legal_ relationship between owner and subject
matter. An 'owner' has an aggregation of powers that are recognised in law as the powers permissibly exercised
over the subject matter (cf Yanner v Eaton (1999) 201 CLR 351 at [17], [85]–[86]). It is a term that connotes at least
an extensive aggregation of powers, perhaps the fullest and most complete aggregation that is possible. But s
270.1 cannot be read as requiring the identification of an aggregation of powers that the law permits to be exercised
over a person because Australian law does not recognise, and never has recognised, the possibility that one
person may own another. There is not, and never has been, legal endorsement in Australia for the creation or
maintenance of such a concentration of legally recognised powers in one person over another as would amount to
'ownership' of that person. In particular, Australian law does not recognise, and never has recognised, any right to
'possess' a person.

[141] It follows that neither the definition of slavery in s 270.1, nor the references to 'a slave' in s 270.3, invite
attention to what legal rights the 'owner' has over the person who it is alleged is 'a slave'. Rather, the references in s
270.3(1)(a) of the Code to possessing a slave, and exercising over a slave 'any of the other powers attaching to the
right of ownership', invite attention to what the alleged offender has done. In particular, what powers has the

**[*644] alleged offender exercised over the person who is alleged to be a slave? And what the alleged offender has**
done must then be measured against a factual construct: the powers that an owner would have over a person if,
contrary to the fact, the law recognised the right to own another person.

[142] As explained earlier, to constitute 'ownership', one person would have dominion over that other person. That
is, the powers that an owner of another person would have would be the powers which, taken together, would
constitute the complete subjection of that other person to the will of the first. Or to put the same point another way,
the powers that an owner would have over another person, if the law recognised the right to own that other, would
be powers whose exercise would not depend upon the assent of the person over whom the powers are exercised.

[143] How are those abstract ideas to be given practical application? It is convenient to approach that question by
reference to the particular allegations in this matter, where it was alleged that the respondent had 'possessed' each
complainant as a slave and that she had 'used' each complainant as a slave.

[144] The first step to take is to recognise that both the offence of possessing a slave, and the offence of exercising
over a slave any of the powers attaching to the right of ownership, are cast in terms that appear to present two
questions: first, did the accused possess, or exercise some other power attaching to the right of ownership over, the
complainant and second, was the complainant a slave? But the two questions merge.

[145] The condition that must be proved is that the person meets the description 'a slave'. The offence is
intentionally to possess a slave or intentionally to exercise over a slave any of certain powers. The condition of
slavery (which is what provides the content of the term 'a slave') is defined as the condition of a person over whom
any or all of the powers attaching to the right of ownership are exercised. It thus follows that proof of the intentional
exercise of any of the relevant powers over a person suffices to establish both that the victim is a slave and that the
accused has done what the legislation prohibits.

[146] The next step to take is to observe that the Code's definition of 'slavery' in s 270.1 speaks of 'the _powers_
attaching to the right of ownership' (my emphasis). Section 270.3 of the Code shows that possessing a slave is one
particular power attaching to the right of ownership. And it is also clear that possessing a slave is not the only power
attaching to the right of ownership. So much is made clear by the use of the word 'other' in the phrase 'other powers
attaching to the right of ownership'. But s 270.1 does not further identify what those powers are.

[147] As Brennan J said in He Kaw Teh v R _[[1986] LRC (Crim) 553 at 604, ' “possession” is a term which implies a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
[state of mind with respect to the thing possessed'. In that case, Brennan J identified ([1986] LRC (Crim) 553 at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)
_[604–605) the actus reus of possession of a prohibited import as being that the object of possession was physically](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_


-----

[in the custody or under the control of the accused. And as Dawson J pointed out in the same case ([1986] LRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)
_[(Crim) 553 at 615), '[p]ossession may be an intricate concept for some purposes, but the intricacies belong to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
civil rather than the criminal law'. That is why, in

**[*645] the criminal law, 'possession' is best understood as a reference to a state of affairs in which there is (He**
_Kaw Teh v R_ _[[1986] LRC (Crim) 553 at 615per Dawson J) 'the intentional exercise of physical custody or control](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M2V-1K71-DYJ0-83BD-00000-00&context=1519360)_
over something'. In considering s 270.3(1)(a) of the Code, however, it will also be important to recognise that the
right to possess a subject matter, coupled with a power to carve out and dispose of subsidiary possessory rights, is
an important element in that aggregation of powers over a subject matter that is commonly spoken of as
'ownership'.

[148] Just as the word 'ownership' evokes notions of the dominion of one person over another, to speak of one
person possessing another (in the sense of having physical custody of or control over that other) connotes one
person having dominion over the other. Or to put the same point in different words, possession, like ownership,
refers to a state of affairs in which there is the complete subjection of that other by the first person.

[149] One, and perhaps the most obvious, way in which to attempt to give practical content to the otherwise
abstract ideas of ownership or possession (whether expressed by reference to subjection, dominion or otherwise) is
to explore the antithesis of slavery. That is, because both the notion of ownership and of possession, when applied
to a person, can be understood as an exercise of power over that person that does not depend upon the assent of
the person concerned, it will be relevant to ask why that person's assent was irrelevant. Or, restating the proposition
in other words, in asking whether there was the requisite dominion over a person, the subjection of that person, it
will be relevant to ask whether the person concerned was deprived of freedom of choice in some relevant respect
and, if so, what it was that deprived the person of choice. In that inquiry some assistance is to be had from United
States decisions about legislation giving effect to the Thirteenth Amendment to the United States Constitution.

[150] Those cases explore what is meant when it is said that a person had no choice but to continue to serve a
person accused of holding the first in 'involuntary servitude'. And they show that a person may be deprived of
choice to the requisite extent, not just by force or the threat of force, but also by threats to invoke the proper
application of the law to the detriment of the person threatened. But examination of the cases will also show why
analysis of who is 'a slave' by reference only to freedom or absence of choice of the alleged victim, or by reference
only to the nature of the coercion applied by an accused, is not determinative of that question.

[151] The Thirteenth Amendment provides, in s 1, that:

'Neither slavery nor involuntary servitude, except as a punishment for crime whereof the party shall have been
duly convicted, shall exist within the United States, or any place subject to their jurisdiction.'

Section 2 of the amendment gives the Congress power to make appropriate laws to enforce the amendment.

[152] The prime purpose of outlawing 'involuntary servitude' in the Thirteenth Amendment, and in statutes enacted
to enforce it, was described by Judge Friendly, speaking for the plurality of the United States Court of

**[*646] Appeals for the Second Circuit in US v Shackney (1964) 333 F 2d 475 at 485–486, as being—**

'to abolish all practices whereby subjection having some of the incidents of slavery was legally enforced, either
directly, by a state's using its power to return the servant to the master … or indirectly, by subjecting persons
who left the employer's service to criminal penalties.'

But as Judge Friendly went on to point out, the Thirteenth Amendment is not addressed solely to state action. In the
United States it has been held to apply in cases of physical restraint (Davis v US (1926) 12 F 2d 253), threats of
imprisonment or physical violence (Bernal v US (1917) 241 F 339, Pierce v US (1944) 146 F 2d 84 and US v Ingalls
(1947) 73 F Supp 76). In US v Shackney (1964) 333 F 2d 475 at 486 the plurality held that—


-----

'a holding in involuntary servitude means to us action by the master causing the servant to have, or to believe
_he has, no way to avoid continued service or confinement … not a situation where the servant knows he has a_
choice between continued service and freedom, even if the master has led him to believe that the choice may
entail consequences that are exceedingly bad.' (My emphasis.)

The third member of that court, Judge Dimock, held ((1964) 333 F 2d 475 at 488) that servitude is involuntary only
'[w]here the subjugation of the will of the servant is so complete as to render him incapable of making a rational
choice'.

[153] Twenty years later, in 1984, the United States Court of Appeals for the Ninth Circuit expressed the test
differently. In US v Mussry (1984) 726 F 2d 1448 at 1453, a case about Indonesian domestic workers, the Court of
Appeals held that:

'A holding in involuntary servitude occurs when an individual coerces another into his service by improper or
_wrongful conduct that is intended to cause, and does cause, the other person to believe that he or she has no_
alternative but to perform the labor.' (My emphasis.)

In that case the prosecution alleged ((1984) 726 F 2d 1448 at 1453) that—

'[the defendants] knowingly placed [the Indonesian servants] in a strange country where [they] had no friends,
had nowhere to go, did not speak English, had no work permit, social security card, or identification, no
passport or return airline ticket to return to Indonesia, [were] here as … illegal alien[s], with no means by which
to seek other employment, and with insufficient funds to break [their] contract[s] by paying back to defendant[s]
the alleged expenses incurred in getting … here.'

The court held that the conduct alleged by the prosecution, if proved, was sufficient to demonstrate improper or
wrongful acts by the defendants intended to coerce the Indonesian servants into performing service for the
defendants. The court further held ((1984) 726 F 2d 1448 at 1455) that 'the use, or threatened use, of law or
physical force is not an essential element of a charge of “holding” in involuntary servitude'. Other forms of coercion
may also result in a violation of the involuntary servitude statutes.

**[*647] [154] Subsequently, the Supreme Court of the United States held in US v Kozminski (1988) 487 US 931 that**
the use, or threatened use, of physical or legal coercion was essential to proof of involuntary servitude ((1988) 487
US 931 at 944, 952). The court rejected the view that the statute then in question extended to cases the court
identified (at 949) as the compulsion of services 'through psychological coercion'. Such a test was rejected (at 949)
as depending 'entirely upon the victim's state of mind'. Accordingly, while deprivation of the victim's will was
essential, the court held that the deprivation must be enforced by the use or threatened use of the means identified.
But as the reference to 'legal coercion' reveals, the court held that involuntary servitude could be established in
cases where the coercion applied was not in itself illegal. Thus, threatening an immigrant with deportation was
identified (at 948) as one possible form of threatened legal coercion.

[155] The discussion in the United States cases reveals three points of immediate relevance to the application of
the provisions of the Code in issue in this case. First, they show that some assistance can be obtained in the
practical application of the abstract concepts of ownership and possession by considering the antithesis of slavery
and asking whether, and in what respects, the person alleged to be a slave was free. But the second point revealed
by the United States cases is that to ask whether a person was 'free', or to ask the more particular questions of
when and how a person was deprived of will or freedom of choice, is in each case a question of fact and degree.
And because that is the nature of the question, the answer may often be expressed using some word like 'real' or
'substantial' to describe the quality of the freedom or the denial of freedom that is identified. The third point that
emerges from the United States cases is that to ask whether a person has been deprived of free choice presents
two further questions. First there is the question: choice about what? Then there is the question: how is the
deprivation effected? The United States cases that have been discussed explore choice about provision of labour,
and deprivation by means other than close physical confinement. The detail of that discussion may or may not be
immediately relevant to the facts of a case brought under the provisions of the Code that are in issue in this case.


-----

[156] Asking what freedom a person had may shed light on whether that person was a slave. In particular, to ask
whether a complainant was deprived of choice may assist in revealing whether what the accused did was exercise
over that person a power attaching to the right of ownership. To ask how the complainant was deprived of choice
may help to reveal whether the complainant retained freedom of choice in some relevant respect. And if the
complainant retained freedom to choose whether the accused used the complainant, that freedom will show that the
use made by the accused of the complainant was not as a slave. But it is essential to bear three points at the
forefront of consideration.

[157] First, asking what freedom a person had is to ask a question whose focus is the reflex of the inquiries required
by ss 270.1 and 270.3 of the Code. It is a question that looks at the person who it is alleged was a slave whereas
the definition of slavery in s 270.1 looks to the exercise of power over that

**[*648] person. The question looks at freedom, but the Code requires a decision about ownership.**

[158] Secondly, what is proscribed by the Code is conduct of the accused. An absence of choice on the part of the
complainant may be seen to result from the combined effect of multiple factors. Some of these, such as the
complainant's immigration status or the conduct of third parties, may be present independently of the conduct of the
accused. Such factors are part of the context in which the conduct of the accused falls to be assessed. However, it
is that conduct which must amount to the exercise by the accused of a power attaching to the right of ownership for
the offence to be made out.

[159] Thirdly, because the Code requires consideration of whether the accused exercised _any_ of the powers
attaching to the right of ownership, it will be important to consider the particular power that it is alleged was
exercised and the circumstances that bear upon whether the exercise of that power was the exercise of a power
attaching to the right of ownership. To ask only the general question— was a complainant 'free'—would not address
the relevant statutory questions.

[160] There were two aspects in the present case that were of critical importance in deciding whether the
respondent possessed each complainant as a slave and used each as a slave. There was the evidence that each
complainant came to Australia following a transaction described as purchase and sale. There was the evidence of
how each complainant was treated in Australia, in particular evidence about the living and the working conditions of
each. And a critical feature of that evidence was that each woman was treated as having incurred a debt that had to
be repaid by working in the brothel. Although there was evidence that one of the complainants was able to secure a
reduction in the amount of her initial debt, there was no satisfactory explanation in the evidence of how the socalled debt of any of the complainants was calculated, or of what had been or was to be provided in return for the
incurring of the obligation. To be put against this evidence about the purchase and sale of the women and their
living and working conditions was the concession made by the prosecution at the outset of these proceedings that
each complainant came to Australia voluntarily.

[161] The evidence at trial showed that the respondent had bought a 'share' in four of the five women. The fifth
woman had also been bought by a syndicate but the respondent was not a member of that syndicate.

[162] In argument at trial, and on appeal to the Court of Appeal, there was much attention given to what was meant
by 'buying' the women or a share in some of them. A deal of that debate appears to have proceeded by reference to
a supposed distinction between the respondent buying a contract under which a person agreed to provide services,
and buying the person (see, for example, (2007) 16 VR 454 at [149]–[158]). The distinction asserted depends upon
directing attention to the legal rights and duties of the parties affected by the transaction. But it is a distinction that is
necessarily flawed. One of the asserted alternatives (buying a person) is legally impossible. It is a transaction that
could not give rise to legal rights and duties. To the extent, therefore, that the comparison seeks to direct attention
to legal rights and duties, it is of no assistance.

**[*649] [163] Yet because reference to buying or selling the complainants is to speak of what, in Australian law, is a**
legal impossibility, the significance that is to be attached to the transaction depends upon what the respondent did.
And in that respect, each of the transactions identified as a syndicate 'buying' one of the women had to take its
significance in a context provided by all of the evidence The way in which all five women were treated in Australia


-----

by setting them to work as they did, on the terms that they did, coupled with the restraints on their movement and
freedom of other action, permitted a jury to conclude that what the respondent did, when she took up a 'share' in
four of the women, was to buy them as if they were articles of trade or commerce and thereafter possess and use
them.

[164] In the case of the fifth woman, where the respondent was not a member of the syndicate, the respondent's
acceptance of that woman as a worker in her brothel on terms that payments were made to the syndicate members
for her services was evidence which, when coupled with the evidence of her working conditions and restraints on
movement and freedom, was again capable of demonstrating to a jury's satisfaction that the respondent possessed
her as if she were an article of trade or commerce that others had bought and sold, and that the respondent
thereafter possessed and used her. That is, what was done with respect to the fifth of the complainants could be
understood as her 'owners' giving the respondent the right to possess her and use her. Those who exercised over
the fifth complainant the powers attaching to the right of ownership carved out of that 'ownership', and disposed of
to the respondent, subsidiary possessory 'rights' over the woman.

[165] What permitted the conclusion, in respect of each complainant, that she had been bought and sold as if an
article of trade or commerce and thereafter possessed and used by the respondent, was the combination of the
evidence about the treatment of each in Australia with the evidence of sale and purchase in Thailand. The
respondent's use of each woman in the respondent's business, coupled with the restraints on the freedom of action
of the complainants, permitted the conclusion that the reference to their sale and purchase was an accurate
reflection of the relationship that the respondent was to have with each complainant. That relationship was to be
one in which the respondent was to have the possession and use of each as if the respondent owned her.

[166] Accepting, as the prosecution did at the outset of the trial, that each of the women came to Australia
voluntarily did not preclude the conclusion that each was possessed and used by the respondent as if owned by
her. Taking the concession at its highest (that each woman had consciously, freely and deliberately submitted
herself to the conditions that she encountered in Australia), the evidence permitted the jury to conclude that none of
the women thereafter retained _any_ freedom to choose what was done with them in Australia. The practical
impediments and economic consequences for each woman, if she refused to complete her performance of the
arrangement, were such as permitted the jury to conclude that, if there were choices to be made about those
matters, they were to be made by others. In this case the evidence permitted the conclusion that the respondent
used and possessed

**[*650] each complainant as a slave because it permitted the conclusion, in each case, that the respondent used**
and possessed the complainant as an item of property at the disposal of those who had bought the complainant
regardless of any wish she might have.

[167] There is one further point to make about the evidence of purchase and sale. There was no evidence at trial
about the circumstances in which the transactions were made. In particular, there was no evidence of how it came
about that the 'vendor' asserted the right to make the sales that were made. Exploration of those matters would very
likely have cut down, even eliminated altogether, the notion that the women came to Australia voluntarily. Not least
is that so because it is possible, even probable, that examination of those matters would reveal not just great
disparities of knowledge and power as between the 'vendor' and each of the women concerned, but other
circumstances touching the reality of the assent which it was accepted each had expressed. But assuming that
each of the women was to be taken to have voluntarily agreed to be the subject of sale and purchase, her assent
does not deny that the result of the transaction to which each agreed was her subjection to the dominion of her
purchasers.

[168] It was open to the jury at the respondent's trial to find that each complainant was a person over whom was
exercised, by the respondent, one or more powers attaching to the right of ownership. The respondent's appeal to
the Court of Appeal of Victoria against her convictions should have been dismissed.

**HEYDON J.**


-----

[169] I agree with both Gleeson CJ and Hayne J.

**CRENNAN J.**

[170] I agree with the orders proposed by the Chief Justice, for the reasons given by his Honour. I agree also with
the reasons given by Hayne J for concurring in those orders.

**KIEFEL J.**

[171] I agree with Gleeson CJ and with Hayne J.

Solicitors:

_Director of Public Prosecutions (Cth) for the appellant._

_Slades & Parsons Solicitors for the respondent._

_Australian Government Solicitor for the Attorney General of the Commonwealth, intervening._

_Human Rights and Equal Opportunity Commission for the Human Rights and Equal Opportunity Commission,_
intervening.

**End of Document**


-----

