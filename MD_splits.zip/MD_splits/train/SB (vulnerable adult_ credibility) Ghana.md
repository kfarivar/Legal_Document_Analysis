# SB (vulnerable adult: credibility) Ghana [2019] UKUT 398 (IAC)

UK Upper Tribunal (Immigration and Asylum Chamber)

Lane J and CMG Ockelton

22 November 2019Judgment

For the Appellant: Mr M Allison, instructed by Duncan Lewis & Co Solicitors

(Harrow Office)

For the Respondent: Mr N Bramble, Senior Home Office Presenting Officer

_(1) The fact that a judicial fact-finder decides to treat an appellant or witness as a vulnerable adult does_
_not mean that any adverse credibility finding in respect of that person is thereby to be regarded as inherently_
_problematic and thus open to challenge on appeal._

_(2) By applying the Joint Presidential Guidance Note No 2 of 2010, two aims are achieved. First, the_
_judicial fact-finder will ensure the best practicable conditions for the person concerned to give their evidence._
_Secondly, the vulnerability will also be taken into account when assessing the credibility of that evidence._

_(3) The Guidance makes it plain that it is for the judicial fact-finder to determine the relationship between_
_the vulnerability and the evidence that is adduced._

**DECISION AND REASONS**

1. The appellant is a citizen of Ghana, born in 1983. He entered the United Kingdom in 2011 as a visitor. In 2012,
he submitted an application for residence documentation as a spouse of an EEA national. That was refused by the
respondent in July 2013. The appellant appealed against that refusal but by March 2014 he had become appeal
rights exhausted.

2. On 15 April 2015, the appellant was convicted at Aylesbury Crown Court of two counts of rape of a female aged
16 years or over. He was sentenced to eight years' imprisonment. The appellant raped a stranger in the street,
both anally and vaginally. The appellant pleaded not guilty, thereby requiring the victim, according to the
Sentencing Judge, “to relive her appalling ordeal at your hands, but you chose not to give evidence and go into the
witness box yourself”. The Probation Service concluded that the appellant posed a high risk of harm to adult
females and that he had a high risk of sexual offending.

3. On 30 January 2017, the respondent served a notice of decision to make a deportation order on the appellant.
Six months later, the appellant claimed asylum and, three months later, that he was a victim of modern slavery.

4. The appellant's asylum and protection claims were based on his assertion that he would face mistreatment on
his return to Ghana, owing to his unwillingness to traffick drugs to the United Kingdom. He also feared serious
harm there as a result of his United Kingdom rape conviction. On 3 April 2019, the respondent refused the
appellant's protection claim. On 16 April 2019, the appellant filed a notice of appeal with the First-tier Tribunal. At
this point, he was represented by Duncan Lewis Solicitors, having signed a letter of instruction to them on 18
January 2019. Duncan Lewis were also acting in a judicial review, challenging the appellant's detention by the


-----

respondent. Dicksons Solicitors had previously acted for the appellant, submitting representations on his behalf in
2017 and 2018.

5. On 24 April 2019, the First-tier Tribunal sent the appellant and Duncan Lewis a notice relating to the pre-hearing
review of his case and of the substantive hearing, to be held respectively on 13 and 20 May 2019.

6. On 10 May 2019 at 10.15 am, Ms F, a trainee solicitor at Duncan Lewis, sent an email to the First-tier Tribunal
headed “URGENT ADJOURNMENT REQUEST”. Ms F's application said:
“As evident from the Appellant's medical records, he is vulnerable and not suitable for detention. It is noted in the
Appellant's medical records on 16th January 2019 that there is evidence of historical risk of self-harm. His medical
records states that he is moderately serve [sic] depressed.

It is further on evident that the Appellant's mental health has deteriorated whilst in detention. The Appellant has a
diagnosis of depression and is currently on medication for this. The Appellant has repeatedly stated that he suffers
from low mood and lack of motivation. The Appellant in the past has attempted to self-strangulate and he was
found with a ligature in his room trying to end his life. The Appellant has thus been placed on hourly observation.

Please see enclosed the Appellant's medical records.

It is also essential to point out that the Appellant instructs that whilst in Ghana, he was tortured by his traffickers. As
such, it is not possible to make a decision in his asylum claim without giving the Appellant the opportunity to seek a
medical expert to provide a medico legal report in his matter. We submit that a medico legal report goes to the core
of his asylum claim and it will not be possible to determine his appeal without such a report.

**Psychiatrist report**

We therefore seek an adjournment because a psychiatrist report is required to assess whether the Appellant is
capable of giving instructions and thus his ability to effectively take part in the legal proceedings.

We have been in contact with Dr Satinder Sahota who is Consultant Forensic Psychiatrist in the NHS in regards to
providing a psychiatric report for the Appellant.

As the Appellant is currently detained at Morton Hall IRC, Dr Sahota has advised that he will be able to attend and
assess the Appellant on 25th May 2019.

Appellant will be denied due justice. A Country Expert is also required for the reasons set out above.

We look forward to your urgent response in this matter.”

7. First-tier Tribunal Caseworker Varney refused the adjournment application in a written decision dated 13 May
2019. The caseworker observed that although Duncan Lewis made reference to the appellant's medical records,
they did “not identify any aspects of these records which indicate he may not be capable of giving instructions.
There is no guarantee that funding will be available for the country expert report and the representatives' reasons
for requiring such a report are speculative”.

8. On 15 May 2019, the First-tier Tribunal was supplied with an appeal bundle from the appellant, running to 479
pages. Also on that day, a witness statement of the appellant was filed with the First-tier Tribunal, signed by the
appellant on (it seems) 14 May. The statement detailed the appellant's claim to be in need of international
protection and commented on various paragraphs of the respondent's letter of refusal. Under the heading “Mental
Health”, the appellant referred to his medical records, stating that he was “moderately severe depressed and I am
currently on medication for this”. He also described his “low mood and lack of motivation” and that in the past “I
have attempted to self-strangulate”. He also said that he suffered from “nightmares and flashbacks. I may only
able to sleep for a few hours a day. I have been taking antidepressants and anti-anxiety medication for a period 3
years”.


-----

9. On 20 May 2019, the appellant's appeal came before First-tier Tribunal Judge Plumptre, sitting at
Harmondsworth. The appellant was represented by Mr Allison. He renewed the application of Duncan Lewis for
the hearing to be adjourned. The First-tier Tribunal Judge recorded Mr Allison's application as follows:
“11. Mr Allison stated that he had spoken to his instructing solicitor, [Ms F] who had expressed concerns about the
appellant's mental capacity to give instructions and referred me to the Bar Council's guidance on mental incapacity
which made reference to **Re P** **_[2008] EWCA Civ 462 and specifically paragraph 47 to the effect that once a_**
solicitor or Counsel had formed a view that the client might not be able to give proper instructions and might be a
person under a disability, their professional duty was to have the question resolved as quickly as possible.

12. He read out an email from Ms F, a trainee solicitor at Duncan Lewis, from his mobile telephone in terms that:

“Please note that a statement was prepared with the client during attendance at Harmondsworth a few months ago.
However this was not finalised and was not signed. The statement was finalised with the client last week and sent
to him to read over, sign and fax back which he did. During my appointment at Harmondsworth the client was able
to give instructions. Since then his mental health has worsened with nightmares, flashbacks and he is unable to
concentrate. It has been difficult to obtain specific instructions. I strongly believe my client's ability to give
instructions should be assessed. Whilst he is able to give instructions I believe he has been struggling to do so
recently. I do still believe he would be able to stand as a witness but I am unable to tell how effectively he would
give instructions as I have been unable to obtain an assessment dealing with this”.

This is a summary of the terms of the email as Mr Allison was unable to download a copy from his phone. Mr
Allison sought further instructions because he recognised that the text of this email did not meet the test to establish
mental incapacity to give instructions.

13. The appellant confirmed that he had seen Duncan Lewis four-five weeks ago at Harmondsworth and was
thereafter transferred to Morton Hall.

14. Mr Allison also made reference to **ES (s.82 NIA 2002, Negative NRM) Albania [2018] UKUT 335 and the**
need for the Tribunal to make its own assessment about the trafficking claim. He stressed that the Tribunal would
benefit from a professional psychiatric assessment of the appellant's mental ill health. He relied on the Rule 35
report before me and the medical records which showed that the appellant had been prescribed antidepressants
since August 2017. These records indicated conditions consistent with PTSD, and that on page 261 the appellant
had reported that his roommate found him with a ligature. There were concerns about the appellant's risk of suicide
and he had been put on observation. An adjournment was needed for a professional medical assessment as to the
appellant's capacity to give instructions and possible suicide risk. The Tribunal should have the opportunity to
consider such psychiatric assessment. A country report was needed on the risk of re-trafficking from Ghana and
the level of protection available in that country.

15. The Presenting Officer opposed the adjournment, stating that neither a psychiatric report nor a country report
was necessary given the detailed medical records. He referred me to many non-attendances by the appellant in his
medical records and references to him not having any mental health issues. The appellant had had sufficient
capacity to sign a witness statement five days ago when he had challenged the Home Office reasons for refusing
his protection and human rights claim. He acknowledged that there was no country guidance on the conditions in
Ghana. The medical records indicated that the appellant frequently self-referred himself to doctors. The medical
records and OASys Report were reliable documents which the Tribunal could properly take into account. Any
further professional medical assessment was not necessary.

16. I queried whether Duncan Lewis had public funding for either report. Mr Allison was not able to confirm this.

17. In reply, Mr Allison submitted that mental ill health does fluctuate. His instructing solicitor had observed a very
recent deterioration in the appellant's mental capacity and submitted that an adjournment for these reports was
necessary for reasons of fairness.”

10. Judge Plumptre decided to refuse the adjournment application. She recorded her reasons as follows:

-----

“18. I refused an adjournment to obtain two expert reports since I was satisfied from the terms of Duncan Lewis'
letter dated 9 May 2019 that public funding had not been obtained, as the letter stated this was outside legal aid
rates and it could take eighteen weeks for funding to be obtained, an assessment to be conducted and a report to
be produced. Hence I found the position might be the same at any adjourned hearing. Further, the only steps
taken to obtain reports were in the form of an informal email dated 8 May 2019 to Dr Sahota who had indicated he
could see the appellant at Morton Hall on 25 May 2019 and that he had no other availability. In making my decision
that a psychiatric report was unnecessary, I considered that the appellant's detailed medical records from pages
166-290, i.e. some 130 pages, provided ample evidence to the Tribunal in relation to the appellant's medical
conditions and that a further report would be of limited assistance.

19. I found that if Duncan Lewis had serious professional concerns about the appellant's mental capacity to give
instruction steps would have been taken earlier to consult Dr Sahota and took into account that despite such
concerns, Duncan Lewis had been able to draft a witness statement and had asked the appellant to read, sign it
and fax it back – conduct which I considered inconsistent with any concerns over the appellant's mental capacity to
give instructions.

20. In relation to the request for a country expert report from Katherina Thomas, although it was stated by Duncan
Lewis that they were in contact with this writer who stated she could provide a country report by 18 May 2019, this
report was not before me. I took into account that Ms Thomas was in residence at Broad Institute of Harvard
University and Massachusetts Institute of Technology, that she has a Master of Science in public health at the
London School of Hygiene and Tropical Medicine. I found her expertise to provide evidence about effective state
protection and the availability of mental health institutions in Ghana was questionable, given that there was no
indication that she had every [sic] visited the country and no indication of what her knowledge was of Ghana.
Moreover, the respondent had made reference to country guidance in some detail about the sufficiency of
protection in Ghana by reference to websites and the availability of medical treatment in Ghana at paragraphs 8389 of the decision letter. I was not satisfied that Katherina Thomas had sufficient expertise on the limited details
provided about her that any report from her would be of assistance to the Tribunal.

21. Thirdly, I gave weight to the fact that the grounds of appeal dated 16 April 2019 made no mention of the
appellant's mental ill health or possible incapacity to give instructions. I reminded myself of Rule 2 of the 2014
Procedure Rules that delay was not in the public interest nor in the interest of the appellant who had been in
immigration detention since 18 November 2018.“

11. The judge then recorded what happened next:
“22. Having given my ruling, I gave Mr Allison the time to take further instructions. On return to court at 13.40 Mr
Allison very properly stated that he had been able to speak to Marina Khan of Duncan Lewis, the supervisor of [Ms
F], who confirmed that the appellant does have capacity to give instructions.

23. In making my decision to refuse the adjournment I stated that I would treat the appellant as a vulnerable
witness in accordance with the Joint Presidential Guidance Note No 2 of 2010 in view of the diagnosis of
depression and his prescription for antidepressants for the last three years.“

12. Beginning at paragraph 24, Judge Plumptre set out the appellant's evidence, given orally to her, adopting his
written witness statement. She also recorded the cross-examination of the Presenting Officer.

13. At the beginning of the section of her decision dealing with findings of fact and credibility the judge said:
“38. In reaching my findings I have borne in mind the well-known case of Karanakaran and the categorisation by
Brooke LJ in paragraph 55 that when assessing future risk I have to take into account disparate pieces of evidence.

39. When considering the appellant's asylum claim I have considered it in the context of the factual matrix provided
by reference to website reports, the letters written by the appellant, the trafficking report and the medical records,
as per the guidance given by Buxton LJ in Mibanga v SSHD [2005] EWCA Civ 376.


-----

40. In assessing all this evidence I have been mindful of the Joint Presidential Guidance Note and that the
appellant is a vulnerable witness given the diagnosis of depression and that he should be accorded a liberal
application of the benefit of the doubt.“

14. At paragraphs 41 to 48, Judge Plumptre gave her reasons for concluding that the appellant was guilty of a
particularly serious crime, such that (even if he succeeded in establishing a real risk of harm, if returned to Ghana)
he would not be entitled to refugee status in the United Kingdom. She noted, in particular, at paragraph 41 that “Mr
Allison sensibly did not challenge this finding by the respondent which I endorse”.

15. Judge Plumptre then turned to the assessment of the appellant's claim to be at real risk of serious harm in
Ghana. At paragraph 50, she explained how her approach to the issue of trafficking, in respect of which the
appellant had received a negative decision from the Competent Authority, was to consider all the evidence in the
round at the date of the hearing, applying the lower standard of proof.

16. Beginning at paragraph 51, the judge then examined the appellant's account of being asked to smuggle drugs
into the United Kingdom. She gave weight to the appellant's answer in his screening interview that he was an
electrician in Ghana with a good job and that a man he worked with had said that “he would help me to get a good
education”. This man “gave me a bag to bring with me but a friend tipped me off that there were drugs in the bag
so I came without it”. Judge Plumptre found that the fact the appellant had left the bag behind “speaks for itself in
that he exercised free will to do this and was not in any way coerced or forced to do so”. That was, she found,
inconsistent with the appellant's assertion that he was “being exploited”. Further, in both his screening and
substantive asylum interviews the appellant had made no mention of being detained and tortured in a house for
three weeks. She found that claim to be “a later fabrication”.

17. The judge then turned to the appellant's letter of 24 November 2018, where he had been given an opportunity
to clarify discrepancies. The appellant claimed that the interviewing officer who conducted the asylum interview had
made a number of errors. The judge gave weight to the fact that the interview took place on 30 November 2017
and that the appellant had been sent a copy of the interview notes but chose to make no complaint about any errors
for nearly a year, until 24 November 2018. Some of the alleged discrepancies concerned other sources of
information which did not relate to the asylum interview. The judge gave weight to the fact that in his letter of 28
March 2017 and during his asylum interview the appellant stated that he had no family in Ghana, whereas in the
NRM Referral there was reference to the appellant telling an Immigration Officer that threats were made to him if he
told his family in Ghana.

18. In a Rule 35 report, compiled whilst the appellant was in detention consequent upon him raising a claim that he
had been tortured, the judge noted there was reference to him saying that the ringleader of the drugs gang had
asked for information about his family and had threatened him. The judge gave weight to the appellant's response
of 24 November 2018, where the appellant stated that when referring to family he had meant “my relatives not a
direct family and even my friends as well”. The judge did not find that to be a plausible explanation, given that the
appellant had previously said he had no family in Ghana. The judge considered that the appellant's account “has
been undermined by these severe inconsistencies”.

19. At paragraph 54, the judge gave weight to the appellant's letter of 22 February 2017 that “those you have
suffered from since your grandmother died when you were 10” conflicted with what he had said at his asylum
interview, that he did not come across or meet the drug gang until after he had done an electrical job, when he
would have been approximately 28 years old.

20. At paragraph 55, the judge gave weight to the fact that the NRM Referral Report made reference to the
appellant being held in a house for five days before being taken to the airport in Ghana, whereas the Rule 35
Report recorded the appellant as saying he was held in a house for two to three weeks. There was also no mention
in either of the interviews of the appellant being held for any length of time before going to the airport. In the NRM
Referral, the appellant said he was threatened by the gang that he would be raped and was beaten and kicked;
whereas there was no mention at all of this in his asylum interview (paragraph 56). The judge also noted that the
appellant had not spoken to the interviewing officer at his asylum interview about being stabbed because the officer


-----

was not interested to ask him information about this. The judge found this to be “a fabrication and do not accept
that he mentioned this in his asylum interview”, for if he had, it would undoubtedly have been recorded (paragraph
57).

21. The appellant was inconsistent about whether he had been given a locked bag containing drugs at the airport
or whether he had been given it at the house. At paragraph 59, the judge noted the discrepancy that, at interview,
the appellant said he gave the bag containing drugs to his friend, whereas he stated in the letter dated 11 March
2017 that he had dumped the bag. At paragraph 61, the judge did not find it credible that the appellant would enter
into an arrangement with the man known as Mr Noah, whom he had known for only about three weeks, or that the
latter was willing to entrust the appellant with the task of importing dangerous drugs, after knowing him for only such
a short period of time.

22. At paragraph 62, the judge found that the appellant gave no credible explanation at interview as to why he
would put his best friend's life at risk by giving him the bag allegedly containing drugs. The judge rejected the
appellant's explanation that he did not put his friend's life at risk because he thought “he could sort it”.

23. At paragraph 63, the judge considered a threatening letter said to come from the leader of the gang and also
letters of support of the appellant, including a letter from his church. Considering these in the round, she concluded
that it was for the appellant to show that documents adduced in his support could be relied upon to support his
claim.

24. Having made that self-direction, the judge, at paragraph 64, found the purported letter from the gang leader
unreliable, in that it made reference to the gang going after the appellant's family, which was inconsistent with his
claim that his parents died in a car crash when he was aged 9 or 10 and that his grandfather died when he was 10
to 15 years old; and that he had no family to return to in Ghana. There was, indeed, no evidence that the letter
even came from Ghana.

25. As regards the appellant's claim that the gang knew the date the appellant would be released from prison, the
judge held that there was no means of any gang or friend being aware of the appellant's removal date to Ghana
unless he chose to inform them himself (paragraph 66).

26. Judge Plumptre then turned to the issue of suicide risk:
**“Suicide Risk**

67. As acknowledged by Mr Allison the reasoning of Dyson LJ as he then was in J v SSHD [2005] EWCA Civ 629
remains good law and that the test in suicide cases is not whether there is “a real risk of an increased risk”, but
simply whether there is a “real risk” that removal will cause an asylum seeker to take his/her life. Measures taken
by the expelling state before and during removal, and the availability of medical treatment and family support after
removal may reduce the risk below the threshold of a “real risk”. I note that in 'foreign cases' as opposed to
'domestic cases' where the risk is run in the expelling country, the threshold for Article 3 is particularly high. I have
considered what is set out and the case law on the risk of suicide at paragraph 18 of Mr Allison's skeleton
argument.

68. I find at the time of the OASys Report that the appellant is recorded as having no mental health issues and note
from page 261, part of the medical records, that it was the appellant who said that his roommate found him with a
ligature which he intended to use to end his life. I accept that he is on hourly observations from 16 January 2019
which in my judgment does not establish that the appellant is a genuine suicide risk but is indicative of the care
which the detention authorities are required to take. I have considered his oral evidence that he made two other
suicide attempts but take into account that there is no record of these two attempts in his medical records. Given
the numerous inconsistencies in the appellant's account of events in Ghana, I am not satisfied that there have been
two additional suicide attempts, although I accept that the appellant is vulnerable and has been diagnosed with
depression.


-----

69. I find any diagnosis of depression is consistent with the appellant's uncertain future in Ghana, his lack of
immigration status in the UK given that he is an overstayer, and as submitted by the Presenting Officer is consistent
with being depressed about the breakdown of his relationship with his wife and lack of contact with his daughter
whom understandably the appellant misses.

70. I give weight to the fact that the appellant failed to raise any concerns of being targeted in Ghana as a result of
his criminal convictions being public knowledge until very recently. I reject his claim that he cannot return to Ghana
because people are aware of them as a late fabrication and find that there was no reference to any such fear in his
screening and asylum interviews.

71. I find that there is sufficiency of protection from the police in Ghana for any claimed fear of the … gang for all
the reasons given in paragraphs 45-53 of the decision letter, and find that there is a functioning police force in that
country and that although they may be susceptible to corruption, steps are being taken to address this.

72. I find that any mental health problems and possible suicide risk are being managed by suitable medication for
depression. I apply the reasoning in **N V SSHD** **_[2005] UKHL 31 that the high threshold to establish that the_**
appellant's removal would be a breach of Article 3 ECHR has not been met.

73. I give weight to what is stated at paragraph 83 of the decision letter about the availability of medical treatment
in Ghana which is one of the most advanced countries in Africa in terms of health organisations thanks to a public
insurance system, and that there are many different categories of hospital in Ghana and that there are around
1,294 private hospitals and around 1,818 public hospitals generally located in urban areas.

74. I give weight to what is stated at paragraph 85 of the decision letter about the treatment for mental health
conditions and that mental health services in Ghana are available at most levels and to what is set out at paragraph
86 and adopt the finding at paragraph 87 of the respondent that suitable medical care is available in Ghana for any
mental instability or mental health issues including depression, anxiety, stress, panic attacks, paranoia, suicidal
thoughts, sleeplessness, loneliness, emptiness, confusion and sadness. I give weight to the fact that Citalopram,
Mirtazapine and Sertraline are all available in Ghana, as per the COI Requests/Information dated April 2018 and
February 2017.”

27. At paragraph 75, dealing with section 8 of the Asylum and Immigration (Treatment of Claimants, etc.) Act 2004
(claimant's credibility), Judge Plumptre noted that, although the appellant had allegedly come to the United
Kingdom in 2011 to escape his problems in Ghana and claim asylum (as asserted in two of his letters written in
support of his challenge to deportation), he did not claim asylum at the airport and did so only after he had been
served with an order of deportation. That delay constituted “behaviour” which undermined the credibility of the
appellant's asylum claim.

28. Finally, at paragraph 76, Judge Plumptre noted that “there were sensibly no submissions on Article 8 on which
the appellant cannot rely, given the breakdown of his marriage and lack of any contact with his daughter”. She then
proceeded to dismiss the appeal.

29. On behalf of the appellant, Mr Allison drafted the grounds attached to Duncan Lewis's application for
permission to appeal to the Upper Tribunal. The grounds described the “factual basis of A's appeal” as a fear of the
man named Noah, who had “previously tortured” the appellant in Ghana and threatened him with death; and “the
risk of A committing suicide as a result of his fears about returning to Ghana”.

30. Paragraph 5 of the grounds contended that the renewed application to adjourn made to Judge Plumptre at the
hearing “was based at least in part on the need to obtain supporting medical evidence of the risk of suicide”. In the
light of what the grounds asserted was the respondent's “procedural obligation to assess available treatment in
Ghana, it was essential for A to be able to produce reliable evidence from a mental health professional properly
qualified to assess his mental state, diagnose any relevant medical conditions and proffer an expert opinion on risk.
Medical records could not properly be considered as a satisfactory substitute”.


-----

31. So far as concerned Judge Plumptre's reliance on delay on the part of Duncan Lewis, the grounds contended
that since the appellant “has been in detention throughout the proceedings, the available time to obtain supporting
medical evidence was necessarily limited”. The grounds went on to say that it had been explained “that in light of
the need to make an application for funding to the LAA [Legal Aid Authority] due to the quotation being above the
relevant threshold, an adjournment of 8-10 weeks was being sought. On this basis, there was simply insufficient
time to make the necessary arrangements”.

32. The grounds contended that Judge Plumptre had been wrong to rely on the OASys Report that the appellant
had no mental health issues, despite accepting that he was a vulnerable witness due to his diagnosis of depression.
So far as the suicide attempts were concerned, the grounds submitted that the judge had failed to have regard to
the fact that two further suicide attempts were said to have post-dated the first one in January 2019. This touched
upon the point made earlier in the grounds, that there was a gap in the medical records from 10 February to 19 April
2019 and no medical records from 30 April 2019 onwards.

33. Ground 2 asserted that Judge Plumptre misapplied the law on suicide risk, as articulated in J v Secretary of
State for the Home Department [2005] EWCA Civ 6529 and Y and Z (Sri Lanka) v Secretary of State for the Home
Department [2009] EWCA Civ 362. Judge Plumptre had wrongly assumed that the high threshold of Article 3 harm
required in so-called “health” cases apply, when those authorities made it plain that this was not the correct legal
position.

34. Ground 3 asserted that Judge Plumptre had not given effect, in analysing the appellant's evidence, to the fact
that the appellant had been treated by her as a vulnerable witness.

**_Discussion_**

**_(a) The grant of permission_**

35. Permission to appeal to the Upper Tribunal was granted by First-tier Tribunal Judge Bibi on 17 July 2019.
Somewhat remarkably, Judge Bibi, at paragraph 2, stated in terms that Judge Plumptre's decision “contains a
material error of law”. At paragraph 3, Judge Bibi said that Judge Plumptre “has erred in not granting an
adjournment to enable the appellant to produce reliable evidence from a mental health professional properly
qualified to assess his mental state, diagnose any relevant medical conditions and to offer an expert opinion on risk.
The medical records could not properly be considered as a satisfactory substitute”.

36. It is inappropriate for a judge granting permission to appeal to assert that the decision under challenge contains
a material error of law. Although, at paragraph 4 of her decision, Judge Bibi stated that “there is an arguable error
of law that has been identified which merits further consideration”, her views, as expressed in paragraphs 2 and 3,
should have been couched in terms of arguability.

37. If Judge Bibi had been satisfied, not just that there was an arguable error of law, but that Judge Plumptre had in
fact made an error of law in her decision, then Judge Bibi should have reviewed that decision pursuant to rule 35 of
the Tribunal Procedure (First-tier Tribunal) (Immigration and Asylum Chamber) Rules 2014. We are not suggesting
that such a course would have been appropriate reaction to Judge Plumptre's decision; merely that it is only in the
context of review that a judge considering an application for permission to appeal is entitled to say that the decision
under challenge is legally erroneous. As will be evident from what follows, the challenges to Judge Plumptre's
decision are, in fact, devoid of merit.

**_(b) The refusal to adjourn_**

38. The oral and written grounds of challenge to Judge Plumptre's decision to refuse to adjourn the substantive
hearing mis-characterise the application with which she was faced. As can be seen from the application sent by
email on 10 May from Ms F of Duncan Lewis, the application to adjourn in order to obtain a psychiatric report was
on the basis that this “is required to assess whether the appellant is capable of giving instructions and thus his
ability to effectively take part in the legal proceedings”. Although Ms F made reference to the appellant having


-----

attempted to self-strangulate, the adjournment application was not made, even in part, so that a medical
assessment could be obtained of the risk of the appellant committing suicide, if he were returned to Ghana.

39. When Mr Allison renewed the application before Judge Plumptre, it is evident from paragraph 11 of her
decision that this was on the same basis as Ms F had put the written application. The email read out to the judge
by Mr Allison, and recorded by her at paragraph 12 of her decision, is concerned with the appellant's ability to give
instructions, even if “he would be able to stand as a witness”.

40. Although the judge, at paragraph 14, recorded Mr Allison as saying that an adjournment was needed “for a
professional medical assessment as to the appellant's capacity to give instructions and possible suicide risk”, it is
quite evident that this was no more than an aside. It is noteworthy that Mr Allison's written skeleton argument of 20
May 2019 dealt at length with the issue of suicide risk to the appellant but did not contain any submission that
further evidence on this issue was necessary. On the contrary, paragraph 17 of the skeleton reads as follows:
“17. Although the Respondent has concluded that there is insufficient evidence to preclude that A's removal would
result in suicide (RFRL, §100) this assessment does not take into account the evidence indicating that A has
actually attempted to commit suicide whilst in detention.”

41. At paragraph 18 of the skeleton, Mr Allison's submission that the respondent had an obligation to assess what
treatment would be available in practice, to preclude the real risk of suicide, was couched in terms of what medical
evidence might be available in Ghana. We have not been told that the psychiatrist whom Duncan Lewis wished to
instruct has any expertise about mental health facilities in Ghana.

42. We are not satisfied that any criticism can be made of Judge Plumptre's finding at paragraph 19 of her decision
regarding Duncan Lewis having had an opportunity of consulting Dr Sahota at an earlier point in time. The medical
evidence before the judge extended back over a considerable period. The appellant himself said that he had been
taking antidepressant medication for three years. Over much of that period he had been instructing Dicksons
Solicitors, who were making representations on his behalf following service of the notice of decision to make a
deportation order in January 2017. The change of solicitors which, as we have said, appears to have occurred in
January 2019 falls to be looked at in that light. In any event, the mere fact that the appellant had been in detention
at the time Duncan Lewis began to represent him should not have posed significant difficulties for such an
experienced immigration practice.

43. At the hearing, we asked Mr Allison whether Dr Sahota had produced a report. Mr Allison replied that he had
not. The explanation given was that the Legal Aid Agency would not fund such a report unless and until the Upper
Tribunal had found a material error of law in the First-tier Tribunal's decision. Under questioning from us, Mr Allison
was unable to say whether Duncan Lewis had, in the interim, made any approach to the LAA to secure exceptional
funding, or the like, in order to enable such a report to be prepared.

44. We have to say that we find this stance problematic. The Upper Tribunal is being urged to set aside the
decision of First-tier Tribunal Judge Plumptre on an entirely speculative basis. So far as concerns the alleged gap
in medical records, referred to in the grounds of application for permission to appeal, Duncan Lewis could have
obtained the appellant's authority to get these from the respondent, in respect of the remaining period when the
appellant was in detention. Given that the appellant has now been released, and lives in Cornwall, records could
have been sought from his General Practitioner.

45. We make no professional criticism of Ms F; but the events described above raise the question of how a trainee
solicitor was allowed by her firm to make the assertion that this appellant was not capable of giving instructions,
when a more experienced practitioner would have realised the difficulties with such a stance, as belatedly occurred:
see paragraph 11 above.

46. We find that First-tier Tribunal Judge Plumptre did not err in law in refusing to adjourn. She properly addressed
the application made to her.

**_(c) The risk of suicide_**


-----

47. As we have seen, Judge Plumptre dealt with the issue of suicide risk at paragraphs 67 to 74 of her decision.
The criticism in the grounds of her finding at paragraph 68, regarding the absence of evidence of two further suicide
attempts, fails for the reason we have just given: there is still no satisfactory evidence of these, let alone anything to
show that it would have materially affected the judge's analysis of the suicide risk, based on the evidence that was
before her.

48. The appellant contends that Judge Plumptre misapplied the relevant law, in that J held that the risk of harm is
not to be assessed by reference to the elevated threshold for “health cases”, such as one finds articulated in D v
United Kingdom (1997) 24 EHRR 423 and in N v Secretary of State for the Home Department _[2005] UKHL 31._
Notwithstanding that J featured prominently in his written grounds, Mr Allison did not consider it necessary to
provide the Upper Tribunal with a copy of the judgment or of that in Y and Z (Sri Lanka) v Secretary of State for the
Home Department [2009] EWCA Civ 362, upon which he also relied.

49. At paragraph 67 of her decision, the judge set out a synopsis of the Court of Appeal's judgment in J. We can
see nothing wrong with what she there said. Under the heading “Foreign Cases” Dyson LJ set out the following
requirements:
“26. First, the test requires an assessment to be made of the severity of the treatment which it is said that the
applicant would suffer if removed. This must attain a minimum level of severity. The court has said on a number of
occasions that the assessment of its severity depends on all the circumstances of the case. But the ill-treatment
must "necessarily be serious" such that it is "an affront to fundamental humanitarian principles to remove an
individual to a country where he is at risk of serious ill-treatment": see Ullah paras [38-39].

27. Secondly, a causal link must be shown to exist between the act or threatened act of removal or expulsion and
the inhuman treatment relied on as violating the applicant's article 3 rights. Thus in Soering at para [91], the court
said:

"In so far as any liability under the Convention is or may be incurred, it is liability incurred by the extraditing
Contracting State by reason of its having taken action which _has as a direct consequence the exposure of an_
_individual to proscribed ill-treatment."(emphasis added)._

See also para [108] of Vilvarajah where the court said that the examination of the article 3 issue "must focus on the
foreseeable consequences of the removal of the applicants to Sri Lanka…"

28. Thirdly, in the context of a foreign case, the article 3 threshold is particularly high simply because it is a foreign
case. And it is even higher where the alleged inhuman treatment is not the direct or indirect responsibility of the
public authorities of the receiving state, but results from some naturally occurring illness, whether physical or
mental. This is made clear in para [49] of D and para [40] of Bensaid.

29. Fourthly, an article 3 claim can in principle succeed in a suicide case (para [37] of Bensaid).

30. Fifthly, in deciding whether there is a real risk of a breach of article 3 in a suicide case, a question of
importance is whether the applicant's fear of ill-treatment in the receiving state upon which the risk of suicide is said
to be based is objectively well-founded. If the fear is not well-founded, that will tend to weigh against there being a
real risk that the removal will be in breach of article 3.

31. Sixthly, a further question of considerable relevance is whether the removing and/or the receiving state has
effective mechanisms to reduce the risk of suicide. If there are effective mechanisms, that too will weigh heavily
against an applicant's claim that removal will violate his or her article 3 rights.”

50. That articulation of the test was specifically in the context of “foreign cases”. However, at paragraph 33, under
the heading “Domestic Cases” Dyson LJ said this:
“33. In relation to domestic cases, it is apparent that Strasbourg applies a somewhat different approach, since the
concern to avoid or minimise the extra-territorial effect of the ECHR (ie the third of the 6 factors we have just
mentioned) is absent But the remaining factors are equally applicable in domestic cases The sixth factor is of


-----

particular significance. This is not surprising because the signatories to the ECHR have sophisticated mechanisms
in place to protect vulnerable persons from self-harm within their jurisdictions. Although someone who is sufficiently
determined to do so can usually commit suicide, the fact that such mechanisms exist is an important, and often
decisive, factor taken into account when assessing whether there is a real risk that a decision to remove an
immigrant is in breach of article 3.”

51. At paragraph 42, Dyson LJ said:
“42. … In our view, suicide cases should be approached in the manner that we have explained earlier. Cases
concerning the risk of death resulting from the non-availability of treatment in the receiving state are not precisely
analogous to those concerning the risk of suicide. The scope of article 3 in relation to the former has now been
explained by the House of Lords in N(FC).”

52. The judgment of Sedley LJ in Y and Z makes reference to another Court of Appeal case that post-dates Y: RA
(Sri Lanka) v Secretary of State for the Home Department [2008] EWCA Civ 1210. Richards LJ, giving the judgment
of the Court, had this to say about the standard or threshold to be applied where the risk of Article 3 harm following
return concerns the risk of suicide:

“49. There has been some debate in our domestic case-law as to the extent to which cases of mental illness, in
particular where it is said that removal will give rise to a risk or increased risk of suicide, are analogous to cases of
physical illness for the purposes of the application of article 3: see J v Secretary of State for the Home Department

_[2005] EWCA Civ 629, para 42;_ _R (Tozlukaya) v Secretary of State for the Home Department [2006] EWCA Civ_
_379, para 62; AJ (Liberia) v Secretary of State for the Home Department [2006] EWCA Civ 1736, para 15; and CN_
_(Burundi) v Secretary of State for the Home Department [2007] EWCA Civ 587, paras 25-26. Mr Mackenzie_
contended that a material difference exists between the two types of case, since in the suicide risk case the very act
of expulsion causes or may cause a deterioration in the applicant's condition whereas in the HIV/AIDS situation it is
the loss of assistance or services currently enjoyed that gives rise to the issue under article 3. Whilst there may be
factual differences between the two types of case, the passage I have quoted from _N v United Kingdom makes_
clear, as it seems to me, that the same principles are to be applied to them both. Nor do I detect any important
difference of approach in the domestic cases on suicide risk. In the present case the senior immigration judge
relied both on the line of domestic authority beginning with J v Secretary of State for the Home Department and on
the line of Strasbourg authority beginning with D v United Kingdom. In my view that resulted in a perfectly coherent
approach, in line with the statement of principles now to be found in N v United Kingdom.

50. In any event, I am satisfied that the senior immigration judge was entitled to conclude that the appellant's
removal to Sri Lanka would not have such adverse consequences for the appellant's psychiatric condition as to
reach the article 3 threshold; on her findings of fact, this could not be said to be a very exceptional case where the
humanitarian grounds against removal are compelling. She was similarly entitled to conclude that his removal
would not be in breach of article 8.”

53. In Y and Z, Sedley LJ distinguished but did not disapprove what Richards LJ held at paragraphs 49 and 50 of
RA. Those paragraphs accordingly remain an authoritative finding on risk of suicide after return. They fully accord
with what Judge Plumptre held in the present appeal. It is unfortunate that we were not referred to RA at the
hearing.

54. So far as UK suicide risk was concerned, there was no evidence before the judge to show that the respondent
was not responding appropriately, whilst the appellant was in detention, following the appellant's suicide attempt.
On the evidence before the judge, she was entitled to conclude at paragraph 69 that the appellant's mental state
was “consistent with being depressed about the breakdown of his relationship with his wife and lack of contact with
his daughter whom understandably the appellant misses”. No suggestion was made by Mr Allison that the
respondent would not take appropriate precautions to safeguard the appellant, in the event of him being detained
with a view to effecting his removal.

55. So far as Ghana was concerned, there is no challenge to the judge's finding at paragraph 74 that relevant
drugs including the commonly prescribed citalopram mirtazapine and sertraline are available in Ghana


-----

Furthermore, paragraph 30 of J is highly important. There, Dyson LJ found that, if a person's fear of harm on return
is not well-founded “that will tend to weigh against there being a real risk that the removal would be in breach of
Article 3”. The judge made findings of fact that the appellant was not a witness of truth and that his account of what
he feared might happen to him in Ghana was a fabrication. For the reasons we will shortly give, the challenge to
the judge's conclusions is not made out. Accordingly, the appellant will know that there are no individuals in Ghana,
such as Noah, waiting to harm him.

56. Mr Allison sought to rely upon Y and Z. Quite apart from what we have just said, the facts of Y and Z were
entirely different from the present one, in that the appellants, who had been imprisoned and tortured in Sri Lanka,
were so fearful of what might happen to them on return that there was a real risk that they would commit suicide,
even though the Sri Lankan authorities might not any longer be adversely interested in them: paragraphs 49, 50
and 61 to 64.

57. We conclude that the Judge Plumptre did not materially err in law in her assessment of the suicide risk to the
appellant.

**_(d) The appellant as a vulnerable adult_**

58. At paragraph 23 of her decision, Judge Plumptre said that she would treat the appellant “as a vulnerable
witness in accordance with the Joint Presidential Guidance Note No. 2 of 2010”. We assume that she meant
“vulnerable adult”: see paragraph 2, footnote 2 to the Guidance Note and paragraph 1 of the Senior President of
Tribunals' Practice Direction: Child, vulnerable adult and sensitive witnesses. No point emerges from this slip.

59. The appellant's final ground of appeal contends that, having decided to treat the appellant as a vulnerable
adult, at no point did Judge Plumptre “appear to give effect to” this fact, when making her findings of fact including,
importantly, the findings of credibility.

60. There is no merit in this challenge. The fact that a judicial fact-finder decides to treat an appellant or witness as
a vulnerable adult does not mean that any adverse credibility finding in respect of that person is thereby to be
regarded as inherently problematic and thus open to challenge on appeal.

61. By applying the Joint Presidential Guidance Note, No 2 of 2010, two aims are achieved. First, the judicial factfinder will ensure the best practicable conditions for the person concerned to give their evidence. Secondly, the
vulnerability will also be taken into account when assessing the credibility of that evidence.

62. So far as the second aim is concerned, the Guidance makes it plain that it is for the judicial fact-finder to
determine the relationship between the vulnerability and the evidence that is adduced:

“3. The consequences of such vulnerability differ according to the degree to which an individual is affected. It is a
matter for you to determine the extent of an identified vulnerability, the effect on the quality of the evidence and the
weight to be placed on such vulnerability in assessing the evidence before you, taking into account the evidence as
a whole”.

63. If one examines the judge's findings, one can see that they are fully in accord with that second aim. At
paragraph 40, the judge expressly stated that she had had regard to the appellant as vulnerable, given his
diagnosis of depression “and that he should be accorded liberal application of the benefit of the doubt”. Mr Allison
was completely unable before us to show that Judge Plumptre might not, in fact, have done what she expressly
said she did. On the contrary, Mr Allison could offer no explanation of how the fact that the appellant has been on
antidepressants is capable of having a positive bearing on the credibility of his account, by reference to his
contradictory statements ranging over a considerable period of time. As the Vice President observed at the
hearing, there is nothing to show that the appellant's answers at interview were any more or less to be taken at face
value on this account than were his subsequent written submissions, including his witness statement of May 2019.

64. In any event, certain fundamental problems with the appellant's account cannot rationally be ascribed to his
depression. His inconsistencies regarding whether he has family in Ghana were attempted to be explained on the


-----

basis that he meant “my relatives not a direct family and even my friends as well” (paragraph 53). The appellant
was not here asserting that he had forgotten about or been too depressed to remember whether he had family in
Ghana. Likewise, the judge's findings at paragraphs 60 to 62 were that it was unbelievable that an individual who
had not known the appellant for long would give him drugs, or that the appellant would enter into such an
arrangement. The same is also true of the judge's finding that it was not believable the appellant would put his best
friend's life at risk.

**Decision**

The appeal is dismissed.

**Direction Regarding Anonymity – Rule 14 of the Tribunal Procedure (Upper Tribunal)**
**Rules 2008**

Unless and until a Tribunal or court directs otherwise, the appellant is granted anonymity. No report of these
proceedings shall directly or indirectly identify him or any member of his family. This direction applies both to the
appellant and to the respondent. Failure to comply with this direction could lead to contempt of court proceedings.

Signed     Date

The Hon. Mr Justice Lane

President of the Upper Tribunal

Immigration and Asylum Chamber

**End of Document**


-----

