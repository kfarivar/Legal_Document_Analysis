# R (on the application of EM) v Secretary of State for the Home Department

 [2018] EWCA Civ 1070

Court of Appeal, Civil Division

Arden, Sharp and Peter Jackson LJJ

15 May 2018Judgment

**Martin Chamberlain QC and Christopher Buttler (instructed by Leigh Day) for the Appellant**

**James Eadie QC and Gwion Lewis (instructed by Government Legal Department) for the Respondent**

Hearing date: 25 April 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Peter Jackson:**

**SUMMARY**

1. This is an application for judicial review for which Underhill LJ granted permission on appeal on 22
September 2016, when he further directed that it should be heard in this court rather than in the
Administrative Court. It raises two questions:

(1) What is the nature and scope of the State's obligation to provide assistance and support ('the support
duty') to persons formally identified as potential victims of human trafficking ('PVoTs') arising from Articles
11(2) & (5) of Directive 211/36/EU, and from the published policy guidance of the Home Secretary ('the
SSHD')?

(2) Was the duty discharged in the case of the Claimant, EM, during a period in 2016 when she had been
identified as a PVoT but was detained at an immigration removal centre ('IRC')?

2. The Claimant argues that the support duty requires PVoTs to be offered an individualised assessment
of their needs so that they can be provided with the assistance necessary for their physical, psychological
and social recovery. This assessment is a complex task that must be performed by a specialist in the
assessment of victims of trafficking, otherwise meaningful individualised assistance cannot be provided. It
is accepted that in relation to PVoTs who are not in detention the duty is discharged by means of a national
support service jointly funded by the Home Office and Ministry of Justice, but that service does not extend
to detained PVoTs. The different provision that is made for detained PVoTs does not, it is said, discharge
the support duty and consequently the treatment of the Claimant was unlawful.

3. The SSHD accepts that all identified PVoTs must be assessed with a view to meeting their needs as a
PVoT. She does not accept that the support duty requires the assessment to be performed by a specialist
in human trafficking, or for the support to focus on the issue of human trafficking as opposed to the overall
needs of the individual. She contends that the support provided to the Claimant when she was in detention
amply discharged the UK Government's duty towards her.


-----

4. My conclusion, as appears below, is that the Claimant overstates the obligations that arise under the
Directive and the policy guidance. The obligation is to provide necessary assistance and support directed
to the overall needs of each PVoT. The manner in which needs are to be assessed and assistance
provided is not prescribed in the way that the Claimant contends. Nor does the regime that has been put in
place for non-detained PVoTs imply an obligation to replicate it for detained PVoTs. The Claimant was
provided with a level of assistance and support that met the State's domestic and international legal
obligations.

5. I would therefore dismiss this judicial review application.

6. This judgment covers the following matters:

A. The Claimant's account

B. The legal proceedings

C. Relevant Law and Policy

D. Current health provision for PVoTs

E. The assistance and support provided to the Claimant

F. Witness evidence

G. Submissions

H. Determination

I. Conclusion

A. THE CLAIMANT'S ACCOUNT

7. The account given by the Claimant (which has not been accepted by the SSHD) is that she has suffered
a number of traumatic experiences. Now in her late 40s, she was born in Nigeria. After an unexceptional
early life, she married in 1997 and had a son born in the same year. She studied to be a midwife but was
not able to continue when she became pregnant again. During the pregnancy, her husband and son were
killed in a car accident in which she was not involved. The circumstances surrounding the funerals were
extremely distressing and were followed by severe oppression from her late husband's family. As a result,
she and her second child, a daughter, went into hiding. However, she was found, faced threats, and had to
move on more than once. She therefore arranged for her daughter to be cared for temporarily while she
herself moved overseas to find work. She met a woman who offered to get her work as a carer in the UK
with the opportunity to complete her midwifery diploma; if she repaid the expenses involved, her daughter
could then join her. In September 2006, this woman brought her to London and gave her a room, but kept
her passport. It transpired that the accommodation was a brothel, and the Claimant was forced to engage
in prostitution in order to send money back to Nigeria. She was told that if she went to the police, she
would be arrested and her family would suffer. After about six months, she escaped with the assistance of
a customer, who set her up with accommodation and a cleaning job. An agent helped her to get a false
Nigerian passport with fake immigration stamps. When she tried to use this to open a bank account, she
was arrested and in October 2008 she was sentenced to 12 months' imprisonment for using a false
document. In February 2009, she was detained for the first time at Yarl's Wood IRC for a period of seven
months and in April 2009 she was made the subject of a deportation order. In December 2009 she was
again detained to facilitate her imminent deportation.

8. At that point, the Claimant challenged her detention by the first of no fewer than five sets of proceedings
that she has brought. She was released, re-arrested and again released. Her application to apply for
judicial review was refused as being totally without merit. In March 2010 an attempt was made to re-arrest
her, but she had absconded. For 5½ years her whereabouts were unknown to the SSHD.

9. On 22 September 2015, the SSHD's officers visited a London nursing home with a warrant. Entry was
forced after three people were seen trying to escape via the rear. The officers found the Claimant hiding in


-----

the back garden. She was detained and returned to Yarl's Wood on 24 September 2015, where she
remained until 9 August 2016.

B. THE LEGAL PROCEEDINGS

10. On 1 October 2015, the Claimant issued her second judicial review claim, challenging her proposed
removal and seeking bail, which was refused. She falsely claimed to be pregnant. However, on 6 January
2016, the Secretary of State issued a positive “reasonable grounds” decision, namely that there was
reason to believe that she was a PVoT and was entitled to a 45-day reflection and recovery period
('reflection period'). On 16 January, her application for temporary admission was refused.

11. The Claimant then issued a third set of judicial review proceedings, challenging her detention and the
decision to refuse her admission. On 11 February, Haddon-Cave J refused these applications and on 25
February, an application for permission to appeal was lodged.

12. On 1 April 2016, after an interview with the Claimant on 8 March, the SSHD made a “conclusive
grounds” decision that she was not, on the balance of probabilities, a victim of trafficking. This
determination relied significantly upon the absence of any account of trafficking given by the Claimant in
2008-2010 during her detention and in the first set of judicial review proceedings.

13. On 28 June 2016, the Claimant issued a fourth claim for judicial review, challenging the lawfulness of
the conclusive grounds decision on the ground that the 8 March interview and consequent decision was
rendered unfair by a breach of the support duty (the issue that arises in this claim). She successfully
applied for an order that that claim be stayed behind this claim. On 13 July, she then filed a claim for
damages in the county court for false imprisonment and/or breach of Arts. 4 and/or 5 ECHR. On 9 August,
the Claimant was released from immigration detention.

14. The application for permission to appeal from the order of Haddon-Cave J was refused on paper by
Underhill LJ on 30 June 2016, but granted in part by him on oral renewal on 22 September. He also
ordered that this hearing would not consider the fourth set of proceedings or the false imprisonment claim,
which remain outstanding.

15. The grounds for which permission was given have evolved as a result of an order made by the Master,
but ultimately boil down to the questions set out in paragraph 1 above.

C. RELEVANT LAW AND POLICY

16. This arises from three sources:

    - The Council of Europe Convention on Action Against Trafficking in Human Beings ('The Convention')

     - Directive 2011/36/EU ('The Directive')

    - Victims of Modern Slavery: Competent Authority Guidance ('The Home Office Guidance')

17. The parties are agreed that, for reasons explained below, directly enforceable legal obligations can
only arise under the Directive and the Guidance.

**_The Anti-Trafficking Convention_**

18. The Anti-Trafficking Convention is the principal international measure designed to combat trafficking in
human beings. It is concerned with the immediate treatment of those in respect of whom there are
reasonable grounds to believe that they are victims of trafficking. It is also concerned with their mediumterm treatment for immigration purposes if it is accepted administratively that they have been trafficked. It
is also concerned with the criminalisation of behaviour associated with trafficking and the need to
[investigate and prosecute offences. See Secretary of State for the Home Department v H [2016] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)
_[Civ 565 at [30].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_

19. The United Kingdom signed the Convention in March 2007 and ratified it on 17 December 2008. The
Convention has not been incorporated into UK law, and consequently individuals cannot enforce its
provisions directly against the Government, but insofar as the SSHD has adopted parts of the Convention


-----

as her own policy in guidance, she must follow that guidance unless there is good reason not to do so: R
_(Lumba) v SSHD [2012] 1 AC 245, Lord Dyson at [26-39]; R (Galdikas) v SSHD [2016] 1 WLR 4031, Sir_
Stephen Silber at [66].

20. The Convention contains these provisions:

- Articles 5 and 6 require parties to take measures to prevent trafficking, to strengthen international coordination and to discourage the demand for trafficked persons.

- Article 10(1) requires State Parties to establish competent authorities, staffed by trained and qualified
persons, to identify and help PVoTs.

- Article 10(2) provides that if the competent authorities of a State Party have reasonable grounds to
believe that a person has been a victim of trafficking, that person shall not be removed from the party's
territory until a process of identifying whether the person is a victim has been completed.

- Article 12 stipulates that in the meantime various forms of support should be provided:

_“Article 12 – Assistance to Victims_

_1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their_
_physical, psychological and social recovery. Such assistance shall include at least:_

a. standards of living capable of ensuring their subsistence, through such measures as: appropriate and
_secure accommodation, psychological and material assistance;_

b. access to emergency medical treatment;

c. translation and interpretation services, when appropriate;

d. counselling and information, in particular as regards their legal rights and the services available to them,
_in a language that they can understand;_

e. assistance to enable their rights and interests to be presented and considered at appropriate stages of
_criminal proceedings against offenders;_

f. access to education for children.

_2.            Each Party shall take due account of the victim's safety and protection needs. […]”_

- Article 13 provides for a reflection period of at least 30 days (the UK gives at least 45 days), during which
time the person may not be removed:

_Article 13 – Recovery and reflection period_

_1. Each party shall provide in its internal law a recovery and reflection period of at least 30 days, when_
_there are reasonable grounds to believe that a person concerned is a victim. Such a period shall be_
_sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an_
_informed decision on cooperating with the competent authorities. During this period it shall not be possible_
_to enforce any expulsion order against him or her. This provision is without prejudice to the activities_
_carried out by the competent authorities in all phases of the relevant national proceedings, and in particular_
_when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise_
_the persons concerned to stay in their territory._

_2. During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures_
_contained in Article 12, paragraphs 1 and 2._

_3. ….”_

21. The Convention therefore provides for a two-stage process for identifying victims of trafficking. The
first stage is to ask whether there are 'reasonable grounds' for believing that a person is a victim of
trafficking. If that is so, the second stage is to determine whether the person is in fact a victim of trafficking
or not (the 'conclusive grounds' decision). While this process continues, assistance and support are to be
provided


-----

22. An Explanatory Report is annexed to the Convention. At [160] it explains the obligation in Art. 12(1)(d)
to provide counselling and information:

_“160. Sub-paragraph d. provides that victims are to be given counselling and information, in particular as_
_regards their legal rights and the services available to them, in a language that they understand. The_
_information deals with matters such as availability of protection and assistance arrangements, the various_
_options open to the victim, the risks they run, the requirements for legalising their presence in the Party's_
_territory, the various possible forms of legal redress, how the criminal-law system operates (including the_
_consequences of an investigation or trial, the length of a trial, witnesses' duties, the possibility of obtaining_
_compensation from persons found guilty of offences or from other persons or entities, and the chances of a_
_judgment's being properly enforced). The information and counselling should enable victims to evaluate_
_their situation and make an informed choice from the various possibilities open to them.”_

**_The Directive_**

23. Directive 2011/36/EU _“on preventing and combating trafficking in human beings and protecting its_
_victims” was adopted on 5 April 2011. It is in part intended to give effect to the Anti-Trafficking Convention:_
_R (Gudanaviciene) v Director of Legal Aid Casework [2015] 1 WLR 2247, Lord Dyson MR at [105]. The_
UK opted into the Directive on 18 October 2011 and it consequently has direct effect: _Hounga v Allen_

[2014] 1 WLR 2889 at [61].

24. Article 11 of the Directive reflects Article 12 of the Convention and deals with the provision of
assistance and support:

_“Assistance and support for victims of trafficking in human beings_

_[1.            Assistance and support in connection with criminal proceedings.]_

_2.            Member States shall take the necessary measures to ensure that a person is provided_
_with assistance and support as soon as the competent authorities have a reasonable-grounds indication for_
_believing that the person might have been subjected to any of the offences referred to in Article 2 and 3._

_[3.]            …_

_4.            Member States shall take the necessary measures to establish mechanisms aimed at the_
_early identification of, assistance to and support for victims, in cooperation with relevant support_
_organisations._

_5.            The assistance and support mechanisms referred to in paragraphs 1 and 2 shall be_
_provided on a consensual and informed basis, and shall include at least standards of living capable of_
_ensuring victims' subsistence through measures such as the provision of appropriate and safe_
_accommodation and material assistance, as well as necessary medical treatment including psychological_
_assistance, counselling and information, and translation and interpretation services where appropriate._

_6.            The information referred to in paragraph 5 shall cover, where relevant, information on a_
_reflection and recovery period pursuant to Directive 2004/81/EC […]_

_7.            Member States shall attend to victims with special needs, where those needs derive, in_
_particular, from whether they are pregnant, their health, a disability, a mental or psychological disorder they_
_have, or a serious form of psychological, physical or sexual violence they have suffered.”_

25. The Directive does not contain provisions dealing with reflection periods. However, Art. 11(6) makes
reference, in the context of the provision of information, to Directive 2004/81/EC ('the 2004 Directive'),
which made provision for a reflection period in Art. 6. The UK opted out of the 2004 Directive and has not
since opted into it.

26. Recital 18 to the Directive includes this:

_“It is necessary for victims of trafficking in human beings to be able to exercise their rights effectively._
_Therefore, assistance and support should be available to them before, during and for an appropriate time_
_after criminal proceedings_ _Member States should provide for resources to support victim assistance_


-----

_support and protection. The assistance provided should include at least a minimum set of measures that_
_are necessary to enable the victim to recover and escape from their traffickers. The practical_
_implementation of such measures should, on the basis of an individual assessment carried out in_
_accordance with national procedures, take into account the circumstances, cultural context and needs of_
_the person concerned. A person should be provided with assistance and support as soon as there is a_
_reasonable-grounds indication for believing that he or she might have been trafficked and irrespective of_
_his or her willingness to act as a witness. In cases where the victim does not reside lawfully in the Member_
_State concerned, assistance and support should be provided unconditionally at least during the reflection_
_period.”_

This recital does not constitute a rule, but may cast light on the interpretation to be given to Article 11:
_Galdikas at [40]._

**_The Home Office Guidance_**

27. The Secretary of State has issued guidance to explain how the Government meets some of its
international obligations through policy, notably by establishing a National Referral Mechanism (“NRM”) to
facilitate the identification of victims of trafficking. Version 2 of the Guidance, which came into effect on 31
July 2015, was in force when the 'reasonable grounds' decision was made in this case. Version 3, which is
currently in force, came into effect on 21 March 2016, and is in similar terms in relation to matters arising in
this application.

28. Frontline staff are required to refer PVoTs to the NRM. The 'competent authority' then makes a
'reasonable grounds decision' as to whether there are reasonable grounds to believe that a person has
been a VoT. In the case of EU nationals, the competent authority is the UK Human Trafficking Centre. In
non-EU cases, the competent authority is a unit within the Home Office.

29. The Guidance states (p.25) that a reflection period of at least 45 days should be provided to an
individual who is the subject of a positive reasonable grounds decision. It explains (p.27), having listed the
NHS services available to all PVoTs free of charge, irrespective of immigration status, that PVoTs are also
entitled to:

     - translation and interpretation services (when appropriate)

     - counselling and information in a language they can understand (particularly regarding their legal rights
_and the services available to them),_

      - _help to make sure their rights and interests are presented and considered at appropriate stages of_
_criminal proceedings against offenders_

     - access to education for children

_Potential victims who are not housed in specialist accommodation (including those housed by asylum_
_support) must still be offered outreach support to make sure their entitlements are met under Article 12 of_

_[the Convention]. …”_

30. The Guidance indicates at p.57 that it will normally be necessary to release a detained individual
identified as a PVoT after a positive reasonable grounds decision. However, at p.92 it also makes clear
that that there may be cases in which that is not appropriate, and mirrors the Convention by identifying for
that purpose cases where continued detention “can be justified on grounds of public order”.

31. Synthesising these sources, the core obligation defining the support duty arises from Arts. 11(2) and
(5) of the Directive, which (emphasising words directly relevant to the present claim) mandate that
**assistance and support must be provided to PVoTs on a consensual and informed basis, and** **shall**
**include at least standards of living capable of ensuring victims' subsistence through measures such as the**
provision of appropriate and safe accommodation and material assistance, as well as necessary medical
**treatment including psychological assistance, counselling and information, and translation and**
interpretation services where appropriate.


-----

32. That much is common ground. The disagreement concerns the true meaning of the words in
emphasis. So that the parties' submissions on this can be understood, I will outline what happens in the
case of PVoTs who are and are not detained, and describe the services provided to the Claimant.

33. Before leaving the legal framework, I should refer to the decision in Galdikas. This was an application
for judicial review by four individuals who had been accepted as victims of trafficking following conclusive
grounds decisions. The decision of Sir Stephen Silber concerned the nature of the obligation towards
these non-detained individuals under the Convention, the Directive and the Guidance. The conclusion was
that Art. 11(2) imposes a freestanding duty to provide support after the reflection period that is not linked to
criminal proceedings, and that the duty is relevant to a decision to grant temporary leave to remain. The
issues that were before the court in those proceedings are therefore distinct from the issue before this
court, which concerns the nature of the support duty as it applies to detained individuals who have not yet
received a conclusive grounds decision, and does not concern the grant of temporary leave to remain (a
matter arising in Galdikas and in this claimant's fourth judicial review application).

34. However, the Galdikas decision is of assistance in its summary of some important general principles at

[26-28]:

26. In order to resolve the outstanding matters, there are two important preliminary matters to stress. First,
the Defendants have discretion as to how the provisions in the Directive are to be implemented in order to
reach the result to be achieved. Article 288 of TFEU states that:

_"A directive shall be binding, as to the result to be achieved, upon each Member State to which it is_
_addressed, but shall leave to the national authorities the choice of form and methods."_

27. So my task when considering whether the Defendants have complied with the Directive is to determine
if the Defendants have achieved the result sought to be achieved and not to decide if the result could be
achieved by another preferable manner.

28. Second, as I have explained, the Claimants are seeking to challenge various aspects of the
Defendants' policy on the basis that it is vitiated by a justiciable public law error. The fall-back position of
the Claimants is that the support regime creates an unacceptable risk of unfairness and so should be
quashed. The threshold that has to be reached before making quashing orders was considered by the
Court of Appeal in R (Tabbakh) v Staffordshire Probation Trust [2014] 2014] 1 WLR 4620 at paragraphs 38
and 45, when it observed that a policy could only be struck down if it was "inherently unfair". That case also
established that if a policy is not in itself "inherently unfair", then in the words of Richards LJ, giving the
only reasoned judgement of the Court of Appeal at paragraph 38, "the correct target of challenge is not the
guidance but any individual decisions alleged to have been made in breach of the requirements of
procedural fairness". Lord Dyson M.R. followed this approach in Lord Chancellor v Detention Action [2015]
2015] 1 WLR 5341 at paragraph 27, where he explained when giving the only reasoned judgement of the
Court of Appeal that:

_"I would accept Mr. Eadie's summary of the general principles that can be derived from these authorities:_
_(i) in considering whether a system is fair, one must look at the full run of cases that go through the system;_
_(ii) a successful challenge to a system on grounds of unfairness must show more than the possibility of_
_aberrant decisions and unfairness in individual cases; (iii) a system will only be unlawful on grounds of_
_unfairness if the unfairness is inherent in the system itself; (iv) the threshold of showing unfairness is a high_
_one; (v) the core question is whether the system has the capacity to react appropriately to ensure fairness_
_(in particular where the challenge is directed to the tightness of time limits, whether there is sufficient_
_flexibility in the system to avoid unfairness); and (vi) whether the irreducible minimum of fairness is_
_respected by the system and therefore lawful is ultimately a matter for the courts. I would enter a note of_
_caution in relation to (iv). I accept that in most contexts the threshold of showing inherent unfairness is a_
_high one. But this should not be taken to dilute the importance of the principle that only the highest_
_standards of fairness will suffice in the context of asylum appeals."_

35. Also to be noted, in Galdikas there was an issue about whether there had been an obligation to carry
out an individual assessment of each claimant under Art.11(7). At [105] it was determined that no such


-----

obligation arises as that sub-paragraph only requires member states to _“attend to victims with special_
_needs”. However, at [108] the judge recorded that individual assessments were in fact being carried out_
and that the court therefore did not need to rule on the issue.

D. CURRENT HEALTH PROVISION FOR PVoTs

**_Those not in detention_**

36. It is relatively unusual for a PVoT to be in detention, and consequently the arrangements now
described apply to most PVoTs.

37. The Home Office and Ministry of Justice jointly fund a national support service for all adult victims of
trafficking in England and Wales identified through the NRM under a victim care contract delivered by The
Salvation Army ('the SA'). The SA itself subcontracts elements of the service to a number of charities and
like organisations under service agreements. The SA's own contract and its contracts with subcontractors
require both initial and detailed assessments and access to specialist services to be provided by fullyqualified professionals with a proven track record. An individual support plan is made for each PVoT. This
includes support with arrangements for moving on in the UK or returning to their country of origin,
depending on the needs, wishes and entitlements of the person concerned.

38. These procedures are fully explained in the Guidance.

**_Those detained at IRCs_**

39. Neither the Guidance nor the SA contract makes any mention of individuals who are in detention. A
detained PVoT is entitled to the same services as other detainees. There is no specific guidance or
training for staff at IRCs relating to PVoTs.

40. The regime at IRCs provides:

(1) Accommodation, catering facilities, leisure and recreation facilities, religious arrangements, education
classes, opportunities for paid work, and access to social and legal visits.

(2) Health screening of all detainees on arrival, and thereafter healthcare provision equivalent to the
primary community healthcare services provided to the general public.

(3) A range of psychological services according to need.

(4) The right to legal advice. Libraries in immigration removal centres contain a range of reference
materials and resources. Detainees are entitled to keep a mobile phone. Weekly legal surgeries are held.

(5) Telephone interpretation is available to help staff speak to detainees.

41. In addition, rule 35 of the Detention Centre Rules 2001 imposes an ongoing obligation on the medical
practitioners working at the removal centres to ensure that “any detained person whose health is likely to
_be injuriously affected by continued detention or any condition of detention” is referred to the attention of_
the SSHD so that their ongoing detention can be reviewed.

42. In relation to counselling, the government contract with the providers of IRCs requires (at 8.10.1) that
the key aim of the mental health services is _“to manage detainees with common health problems and_
_provide brief evidence based clinical interventions as appropriate to address the clinically assessed needs”_
of the detainee, which may include “guided self-help, brief Cognitive Behavioural Therapy (CBT) and other
_psycho-social interventions” and_ _“group work where appropriate”. The provision made for 'brief'_
interventions reflects the usually short-term nature of detention, making it inappropriate to start long-term
counselling programmes which may not be completed, potentially causing more harm than good.

43. A reasonable grounds decision (whether positive or negative) is sent directly to the PVoT at the
removal centre if they are detained, with Home Office staff based in the removal centre also being notified
of the decision, including on the central 'GCID' database maintained by the Home Office.

E. THE ASSISTANCE AND SUPPORT PROVIDED TO THE CLAIMANT


-----

44. The Claimant was at Yarl's Wood on this occasion from 22 September 2015 until 8 August 2016, a
period of 10½ months.  We have been provided with a chronology of the healthcare she received during
this period, running to 19 pages. It includes the following entries, listed only in summary:

22 September 2015 Detained

23 September Health screening assessment by nurse

23 September First health assessment by nurse

29 October Hibiscus (a charity which has officers based at Yarl's Wood IRC providing advice to
non-EU detainees) advises Home Office officials at the IRC that C “spoke to them and
it transpired that she had been trafficked”.
Home Office official:
_“I called [C] for an interview and asked about her claim. [C] has stated_
_that she mentioned to have been trafficked when she was in prison in 2008, but_
_nothing was done about it. She then wrote a statement and passed it to her solicitor…_
_about a month ago but again her solicitor did not do anything to progress it further._

_[C]'s husband has now found a new solicitor who will be coming to see her on_
_Monday.”_

[The SSHD contends that this was the first time that C had spoken of being trafficked.]

12 November Detention review refers to trafficking.

16 November Nurse notes social and personal history, including trafficking, and reports C to the
mental health and well-being team because she was complaining of stress and
depression.

20 November Doctor reviews personal history, receives a very detailed account of trafficking, and
prescribes anti-depressants.

25 November Referral to mental illness team to create Mental Health Care Plan.

26 November C seen by nurse at clinic.

26 November C's then solicitors write to Home Office (Criminal Casework Directorate) stating that
she had been subjected to human trafficking.

28 November Doctor makes Rule 35 report expressing concern that C may have been a victim of
torture.

1 December Healthcare staff speak to C because she had not been attending the dining room to
eat.

2 December Doctor prescribes anti-depressants

3 December Nurse conducts mental health review

3 December Detention review refers again to Hibiscus' concerns about trafficking and reiterates
that no formal referral to NRM yet made

10 December Nurse conducts well-being session

11 December Nurse examines C for dizzy spells and records that she felt depressed

15 December Doctor makes second Rule 35 report expressing concern that C was a victim of torture

21 December C signs NRM referral form, referral made

21 December C seen by clinician

24 December Nurse conducts mental health review

29 December Nurse conducts mental health review

3 January 2016 Doctor advises continue with anti-depressants

6 January SSHD makes positive reasonable grounds decision: 45-day reflection period begins

6 January Mental health nurse conducts mental health review of C (first of 6 during reflection
period, others being on 12, 14, 26 January; 9, 16 February). ACDT initiated.

_[Assessment Care in Detention and Teamwork: the Prison Service model of self-harm_
reduction.]

12 January Home Office wrote to C's solicitors refusing their request for C to be granted temporary
admission. Re trafficking claim:
_“… we have arranged for your client to be interviewed regarding this_

|22 September 2015|Detained|
|---|---|
|23 September|Health screening assessment by nurse|
|23 September|First health assessment by nurse|
|29 October|Hibiscus (a charity which has officers based at Yarl's Wood IRC providing advice to non-EU detainees) advises Home Office officials at the IRC that C “spoke to them and it transpired that she had been trafficked”. Home Office official: “I called [C] for an interview and asked about her claim. [C] has stated that she mentioned to have been trafficked when she was in prison in 2008, but nothing was done about it. She then wrote a statement and passed it to her solicitor… about a month ago but again her solicitor did not do anything to progress it further. [C]'s husband has now found a new solicitor who will be coming to see her on Monday.” [The SSHD contends that this was the first time that C had spoken of being trafficked.]|
|12 November|Detention review refers to trafficking.|
|16 November|Nurse notes social and personal history, including trafficking, and reports C to the mental health and well-being team because she was complaining of stress and depression.|
|20 November|Doctor reviews personal history, receives a very detailed account of trafficking, and prescribes anti-depressants.|
|25 November|Referral to mental illness team to create Mental Health Care Plan.|
|26 November|C seen by nurse at clinic.|
|26 November|C's then solicitors write to Home Office (Criminal Casework Directorate) stating that she had been subjected to human trafficking.|
|28 November|Doctor makes Rule 35 report expressing concern that C may have been a victim of torture.|
|1 December|Healthcare staff speak to C because she had not been attending the dining room to eat.|
|2 December|Doctor prescribes anti-depressants|
|3 December|Nurse conducts mental health review|
|3 December|Detention review refers again to Hibiscus' concerns about trafficking and reiterates that no formal referral to NRM yet made|
|10 December|Nurse conducts well-being session|
|11 December|Nurse examines C for dizzy spells and records that she felt depressed|
|15 December|Doctor makes second Rule 35 report expressing concern that C was a victim of torture|
|21 December|C signs NRM referral form, referral made|
|21 December|C seen by clinician|
|24 December|Nurse conducts mental health review|
|29 December|Nurse conducts mental health review|
|3 January 2016|Doctor advises continue with anti-depressants|
|6 January|SSHD makes positive reasonable grounds decision: 45-day reflection period begins|
|6 January|Mental health nurse conducts mental health review of C (first of 6 during reflection period, others being on 12, 14, 26 January; 9, 16 February). ACDT initiated. [Assessment Care in Detention and Teamwork: the Prison Service model of self-harm reduction.]|


-----

|Col1|application and it is not considered an unreasonable period of time to maintain her detention during this period due to her previous immigration history”|
|---|---|
|21 January|Doctor reviews C, continues anti-depressants|
|21 January|Home Office officials undertake asylum screening interview of C|
|22 January|SSHD writes to C's solicitors refusing their request that C be granted temporary admission, stating: “There are healthcare facilities available at Yarlswood IRC and [C's] health and welfare are monitored, including her eating habits. There are no indications that her care is not being adequately managed at Yarlswood IRC.”|
|29 January|Healthcare support worker conducts psychological wellbeing assessment|
|31 January|C seen by healthcare staff as refusing food|
|2 February|Doctor reviews C|
|3 February|Detention review: “It is considered [C's] detention while her PVoT application is fully considered is appropriate on grounds of public order due to her criminal offence and her history of absconding for a five year period and record of working illegally in the UK.”|
|20 February|45-day reflection period ends|
|29 February|Nurse conducts mental health review|
|2 March|Doctor reviews C, changes anti-depressant|
|7 March|Nurse conducts mental health review|
|8 March|C interviewed for asylum claim|
|10 March|Health care support worker conducts psychological wellbeing assessment|
|1 April|SSHD makes negative 'conclusive grounds' decision|
|4 April|Nurse conducts mental health review|
|5 April|Doctor assesses C|
|19 April|Nurse conducts mental health review|
|26 April|Doctor assesses C|
|27 April|C seen by psychiatrist and mental health nurse|
|By 5 May|C interviewed by Dr Chisholm|
|12 May|Doctor reviews C|
|18 May|Mental health nurse reviews C|
|23 May|Mental health nurse reviews C|
|25 May|C seen by psychiatrist and mental health nurse|
|7 June|Doctor reviews C|
|8 June|Mental health nurse reviews C|
|15 June|C seen by psychiatrist and senior nurse|
|21 June|Doctor reviews C|
|23 June|Doctor reviews C|
|29 June|Mental health nurse reviews C|
|8 July|Health care support worker conducts psychological wellbeing assessment|
|12 July|Doctor reviews C|
|26 July|C transferred from Yarl's Wood to Colnbrook IRC|
|27 July|Doctor reviews C, decides to refer her to psychiatric team|
|9 August|C released from detention|


F. WITNESS EVIDENCE

45. The SSHD relies on (i) a statement by Alan Gibson, Head of Detention Operations at the Home Office,
which describes the framework within IRCs generally and as it related to the Claimant; (ii) a statement
made in the _Galdikas_ case by Helen Sayeed of the Asylum Strategy and Trafficking Team, in which the


-----

SSHD's general policy in relation to human trafficking is set out in detail; and (iii) records covering the
period of the Claimant's detention at Yarl's Wood, from which the detailed chronology has been created.

46. The Claimant has provided (i) a statement by Ann-Marie Douglas, (Project Director of the Adult Victims
of **_Modern Slavery Care and Coordination Services at the SA); (ii) a statement by Kate Garbers,_**
(Managing Director of Unseen UK, one of the SA's subcontractors, which supports about 65 PVoT's each
year); and (iii) two reports from Dr Brock Chisholm, a consultant clinical psychologist with special expertise
in treating victims of trauma.

47. Ms Douglas states that she is not aware of the SA having provided support to a detained PVoT, but
can see no reason in principle why its outreach support could not be provided in an IRC.

48. Ms Garbers describes in detail the process of assessment and support that her organisation provides.
She emphasises the very particular needs of victims of trafficking, and the difficulties they face in speaking
about their experiences. The independence, specialised experience and continuity of support workers is
important. She contrasts what is available in the community with the services at Yarl's Wood, with which
she is familiar. In her opinion, the services available there do not meet the recovery needs of PVoTs, who
are anyway particularly vulnerable as detained individuals.

49. Dr Chisholm's first report is dated 5 May 2016. He interviewed the Claimant in detention and received
a full account from her. He found her to be probably suffering from a mild form of major depressive
disorder (his description), but not to have PTSD, nor to be psychotic or suicidal. He considered that the
harm caused to her by detention outweighed any benefits from the mental health care she was receiving.
He advised that the conditions during the reflection period were not sufficient for her recovery needs.

50. Dr Chisholm's second report, provided over a year later on 29 August 2017, was very much more
expansive. He is critical that an individual psychological formulation, based upon knowledge that the
Claimant was a PVoT, was not constructed by a person with clinical experience and formal training so that
support could be appropriately planned and so that she could give of her best at interview.  There was no
attempt to build trust beyond general forms, and no attempt to assist in creating a coherent
autobiographical memory. The staff appears to have no experience and awareness of the specific issues
associated with trafficking and had no formal professional qualifications. The declared objective to help the
victim overcome the trauma they have been through and get back to re-integration into society _“is_
_unfulfilled at virtually every level in Yarl's Wood”._ The service may be adequate for asylum seekers
generally, but not for PVoTs. Had the Claimant been cared for in the community under the SA contract,
she would have been enabled “to have a greater understanding of what happened to her, be better able to
_provide a truthful and accurate account, and be less likely to avoid details and therefore be at risk of_
_inadvertently providing a discrepant account”._

51. Dr Chisholm expresses the view that it is normally ethically inappropriate to offer psychotherapies
within a detention centre for PVoTs, but that offering something is better than offering nothing. He states
that the Claimant would have been able to provide a better quality of evidence had she been given specific
therapy and been afforded a reflection period where she felt safe and contained.

G. SUBMISSIONS

**_The Claimant_**

52. Mr Chamberlain QC and Mr Buttler begin by referring to Art.12 of the Convention, which requires
states to adopt such legislative or other measures “as may be necessary to assist victims in their physical,
_psychological and social recovery.” Although not directly enforceable, this should inform the interpretation_
of Art. 11 of the Directive, which requires states to “take the necessary measures to ensure that a person is
_provided with assistance and support”._ Recital 18 of the Directive supports the submission that there
should be “an individual assessment” of the needs of each PVoT. Relying on the opinion of Dr Chisholm,
they submit that the identification of a victim of trafficking is a specialised task. Further, relying on the
evidence of Dr Chisholm and Ms Garbers, the provision of meaningful support requires an individualised
plan that cannot be delivered by generic support services. Accordingly, subject only to the individual


-----

consenting, the SSHD must provide such assistance and support as is necessary to aid the individual's
physical, psychological and social recovery from the trauma of trafficking. This requires special
arrangements to be made for PVoTs, going beyond those made for others. Furthermore, detention may
aggravate mental health difficulties, so there is likely to be an enhanced need for assistance and support,
which cannot be met by untrained staff. Nor is there any formal system for IRC healthcare staff to be
informed that a 'reasonable grounds' decision has been made. The SSHD's argument that the support
already provided to all detainees incidentally discharges her duty appears to have been formulated in
response to this claim.

53. Mr Chamberlain concedes that there is nothing in the extensive Explanatory Report to the Convention
that requires there to be an individualised assessment, or for the assessment to be carried out by a
trafficking specialist. However, he argues that the Art. 11 obligation to take “necessary” measures can only
logically be discharged following such an assessment. (The assertion made in the Claimant's skeleton
argument that Art. 11(7) is a source of this obligation was not pursued in oral submissions in the light of the
contrary conclusion in Galdikas at [103].)

54. Mr Chamberlain further accepts that the level of service provided to non-detained individuals is not
determinative of the requirements of the support duty, but he relies upon the contents of the contract with
the SA and the subcontracts with organisations such as Unseen, which require them to provide specialist
services. Even though the Guidance does not refer to detained PVoTs at all, these contractual provisions
are relevant as showing the SSHD's conception of the nature of the support duty.

55. Mr Chamberlain argues that the failure to replicate external arrangements within IRCs is a systemic
failure, giving rise to an unacceptable risk that the support duty will not be met for detained PVoTs. He
does not seek to say that formally identified PVoTs must always be released, but in such cases, the
support duty should be discharged by visits from external outreach workers.

56. In the case of the Claimant, Mr Chamberlain contends that she was not informed of her rights when
the reflection period began. During those 45 days, no assessment was made of her needs as a PVoT, nor
was tailored support provided. Her mental health reviews were mainly carried out by nurses who were not
specially trained and had not been formally informed that a 'reasonable grounds' decision had been taken.
The reviews were generic and did not engage with the question of what, if any, needs the Claimant had
resulting from trafficking. No mentor was appointed, in whom the Claimant could put her trust.

57. The Claimant accordingly seeks declarations that:

(1) The SSHD fails to give effect to her Guidance to refer all those in receipt of a favourable reasonable
grounds decision to the SA. Alternatively, if the Guidance is to be read as excluding SA support for those
in immigration detention, the Guidance is flawed in that it fails to address how the duty of assistance and
support is to be discharged in respect of such persons.

(2) The SSHD's system for discharging the duty of assistance and support is inherently flawed and gives
rise to an unacceptable risk that the duty will not be discharged in respect of persons in immigration
detention with positive reasonable grounds decisions.

(3) The duty of assistance and support owed to the Claimant was breached in that her needs for physical,
psychological and social recovery were not adequately assessed or provided for during her recovery and
reflection period.

**_The SSHD_**

58. Mr Eadie QC and Mr Lewis submit that the duty on the SSHD is to provide the assistance and support
that is necessary in the circumstances. The manner in which it is to be provided is not prescribed in the
Directive, and decisions about the form that it is to take are for national authorities; it can be provided in
different ways in different contexts. There is no prohibition on the detention of PVoTs, and assistance and
support can therefore be provided in or outside detention.

59. The ingredients of the Art. 11 duty (see Art. 11(5)) are to provide:


-----

- “standards of living capable of ensuring victims' subsistence”;

- “appropriate and safe accommodation and material assistance”

- “necessary medical treatment including psychological assistance”

- “counselling and information”

- “translation and interpretation services where appropriate”

All of these are provided within the detention estate.

60. There is no legal right to be assisted and supported by any particular organisation (such as the SA) in
all settings. The Guidance does not refer to a legal right to be supported by the SA because there is no
such right. Whilst referral to the SA is the default method of providing assistance and support outside the
detention estate, within detention the SSHD complies with the duty differently. There is no obligation to
provide directly equivalent services to those who are and those who are not detained.

61. As to the alterative contention – that the Guidance is flawed because it does not spell out how the
support duty of assistance is to be discharged to those in detention – there is nothing in law that requires
the Secretary of State to spell out in guidance how she complies with the Art. 11(2) duty in respect of those
in immigration detention. The 2011 Directive only imposes an obligation as to the result to be achieved.

62. The requirement to provide assistance and support was met in the Claimant's case. By having her
mental health reviewed by qualified mental health professionals no fewer than seven times during the
reflection period, as well as two psychological wellbeing assessments and several further appointments
with a nurse, the Claimant was provided with a level of medical treatment that exceeded the minimum
necessary to assist her. In addition, she had 14 visits from a volunteer befriender and she also made use
of the compassion-based and talking therapies offered by Kaleidoscope Plus from March 2016 onwards.

63. The Claimant does not come close to demonstrating that there is something inherent in the structure of
the scheme that gives rise to a risk of injustice, in the light of the principles set out in the Detention Action
decision. There is no reason to conclude that the healthcare services at IRCs cannot identify and respond
to the particular needs of PVoTs. On the contrary, the evidence establishes that the detention estate has
the capacity to react appropriately to provide the minimum measures required by Art. 11(2). While it might
well be sensible in future to ensure that the healthcare staff (as well as IRC officials) are also directly
notified of any 'reasonable grounds' decision made by the Home Office, that does not make it obligatory.

64. The SSHD contends that the key flaw in the Claimant's argument is that it proceeds on the basis that
the Directive and the Guidance prescribe the manner in which assistance and support are to be provided in
different circumstances. There is no such prescription. The Claimant focuses wrongly on the choice of
form and methods to achieve the result, rather than on the result itself. The Convention applies to all 47
states of the Council of Europe and the Directive to the 28 states of the European Union. Individual states
must design systems to achieve the required result. The obligation to provide support does not translate
into an obligation to secure psychological recovery.

H. DETERMINATION

**_What is the nature and scope of the support duty?_**

65. The general duty on the State under Arts. 11(2) and (5) of the Directive is to provide assistance and
support to a PVoT by mechanisms that at least offer a subsistence standard of living through the provision
of

- appropriate and safe accommodation

- material assistance

- necessary medical treatment including psychological assistance, counselling and information, and

- translation and interpretation services.


-----

66. As to that element of the duty that requires the provision of necessary medical treatment including
psychological assistance, counselling and information, the treatment provided must respond to the welfare
needs of the individual, objectively assessed in each case. The obligations arising under the Directive and
Guidance, read alongside the Convention, do not extend to a requirement that the assessment or
treatment must be provided by specialists in trafficking, or that it be targeted towards one aspect of an
individual's needs (the consequences of trafficking) as opposed to his or her overall psychological needs.
The support duty calls for the provision of support, not the accomplishment of physical, psychological or
social recovery. There is nothing in the Convention, Directive, or Guidance to warrant the extended
interpretation of the duty argued for by the Claimant. That interpretation would require significant additions
to the texts to prescribe specific obligations that would undoubtedly have been spelt out, had they been
intended.

67. Nor do the Claimant's submissions gain strength from a comparison between services that are
provided in the community and those provided in IRCs. The position of a PVoT who is detained is different
from the position of one who is not, and it is lawful for the State to decide to provide support in different
ways. A PVoT living in the community may well not have access to any of the four forms of support
mentioned at paragraph 65 above, while all four will automatically be available to a detained PVoT. The
way in which psychological treatment is provided may take account of the inherent uncertainty about the
length of detention, and the ready availability of on-site medical care for a person who is in any case under
close observation. The evidence filed on behalf of the Claimant is in my view more effective in
demonstrating the way in which the support duty is satisfactorily discharged in the community than in
establishing any breach of legal duty towards detained PVoTs. The fact that different, or better, provision
might be made for those not in detention does not of itself equate to a breach of duty.

68. I also consider that, when considering whether the support duty has been discharged, it is appropriate
to look at the level of assistance and support that has been provided to the PVoT at all stages in the
process, and not just at support provided during the 45-day reflection period.

**_Was the duty discharged in the Claimant's case?_**

69. The Claimant was known by the medical staff at Yarl's Wood to be a PVoT and she received constant
treatment for her psychological difficulties before, during and after the reflection period. As Mr Eadie puts
it, her case was picked up, her treatment was not deficient in any way, and the system was looking out for
her. The fact that the treatment and support sought to address her problems globally and was not
'trafficking-specific' is not determinative of the issue before us. Even taking at face value Dr Chisholm's
medical opinion and his view (which can only be speculation, given the detailed circumstantial account of
trafficking that the Claimant gave throughout her period of detention) about the effect of different
treatments upon her narrative ability, these do not translate into a legal obligation. Nor can the good work
done by organisations such as Unseen lead to the conclusion that the support duty can only be discharged
if the same approach is replicated in an environment that is not equivalent.

70. I would also accept Mr Eadie's submission that this is not a suitable case for considering a systemic
challenge. There is no evidence about the numbers and experiences of other detained PVoTs, nor any
representations from charities or NGOs, as was the case in Detention Action. But as there was no breach
of duty in the Claimant's individual case, that wider issue does not arise.

I. CONCLUSION

71. I therefore conclude that the State's obligations under Arts. 11(2) and (5) were discharged in this case
and I would accordingly dismiss this application. It should now be possible for the Claimant's remaining
litigation, which has been awaiting the outcome of these proceedings, to be determined without delay.

**Sharp LJ:**

72. I agree.

**Arden LJ**

73 I also agree


-----

__________________

**End of Document**


-----

