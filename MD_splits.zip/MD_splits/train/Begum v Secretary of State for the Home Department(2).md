# Begum v Secretary of State for the Home Department [2024] EWCA Civ 152

Court of Appeal, Civil Division

Lady Carr CJ, Bean and Whipple LJJ

23 February 2024Judgment

**Dan Squires KC, Samantha Knights KC, Ayesha Christie, Tim James-Matthews** and Julianne
**Morrison (instructed by Birnberg Peirce LLP) for the Appellant**

**Sir James Eadie KC, Jonathan Glasson KC, David Blundell KC, Jennifer Thelen and Karl Laird**
(instructed by Government Legal Department) for the Respondent

**Angus McCullough KC and Adam Straw KC** (instructed by **Special Advocates Support Office)**
appeared as Special Advocates

Hearing dates: 24-25 October 2023 (open), and 26 October 2023 and 2 February 2024 (closed)

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

.............................

**The Lady Carr of Walton-on-the-Hill, LCJ, Lord Justice Bean and Lady Justice Whipple:**

**Introduction**

1. On 19 February 2019 Shamima Begum, then aged 19, was deprived of her British citizenship by a
[decision under s 40(2) of the British Nationality Act 1981 (“BNA 1981”), made personally by the then](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GSM0-TWPY-Y0YY-00000-00&context=1519360)
Secretary of State for the Home Department, the Rt Hon. Sajid Javid MP. Her appeal to the Special
Immigration Appeals Commission (“SIAC”) was dismissed on 22 February 2023. She appeals to this court
with permission granted by the Chairman of SIAC, Jay J. The issue in this appeal is whether SIAC was
right to conclude that the Secretary of State's decision to deprive her of her citizenship was lawful.

2. We heard two days of oral argument in open court followed by one day in closed session with Special
Advocates representing Ms Begum's interests. This is the open judgment of the court, to which we have all
contributed. There is also a closed judgment in this appeal. We are grateful to counsel for all parties for
their focussed submissions. In particular we are grateful to the Special Advocates, who discharged their
difficult and demanding role of scrutinising the Secretary of State's closed evidence and submissions with
great skill and thoroughness.

**Legislation**

3. Section 40 of the BNA 1981 (“s 40”) provides, so far as relevant, as follows:

“(2) The Secretary of State may by order deprive a person of a citizenship status if the Secretary of State is
satisfied that deprivation is conducive to the public good.

…


-----

(4) The Secretary of State may not make an order under (2) if he is satisfied that the order would make a
person stateless.

…

(5) Before making an order under this section in respect of a person the Secretary of State must give the
person written notice specifying 
(a) that the Secretary of State has decided to make an order,

(b) the reasons for the order, and

(c) the person's right of appeal under section 40A(1) or under section 2B of the Special Immigration
Appeals Commission Act 1997.

…”

4. Sub-sections 40(3) and 40(6) permit the Secretary of State to exercise the deprivation power in
circumstances where he is satisfied that the person obtained registration or naturalisation as a British
citizen by means of fraud, false representation or concealment. Sub-section 40(4A) contains an exception
to the rule in s 40(2) (not relevant to this appeal). Sub-sections 40(5A)-(5E) were inserted by the
_[Nationality and Borders Act 2022 with effect from 10 May 2023, which post-dates the decision in question.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:65F4-3713-GXF6-83T9-00000-00&context=1519360)_

5. Section 40A of the BNA 1981 provides that a person who is given notice under s 40(5) of that Act may
appeal to the First-tier Tribunal, subject to the Secretary of State certifying, pursuant to s 40A(2), that the
deprivation decision was taken wholly or partly in reliance on information which in his opinion should not be
made public for reasons, amongst other things, of national security.

[6. The Special Immigration Appeals Commission Act 1997 (“SIACA 1997”) provides for a right of appeal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9YG0-TWPY-Y0J2-00000-00&context=1519360)
as follows:

“2B. A person may appeal to the Special Immigration Appeals Commission against a decision to make an
order under section 40 of the British Nationality Act 1981 (deprivation of citizenship) if he is not entitled to
appeal under section 40A(1) of that Act because of a certificate under section 40A(2) …”

**Litigation History**

7. The case has an extensive litigation history. After giving notice of appeal against the deprivation
decision to SIAC, Ms Begum applied for leave to enter the UK outside the Immigration Rules so that she
could take part in her appeal. The Secretary of State refused that application. Ms Begum challenged that
decision both by way of appeal to SIAC and by way of a claim for judicial review in the Administrative
Court. SIAC ordered a preliminary hearing to determine: (1) whether the deprivation decision rendered the
claimant stateless as at the date of that decision, (2) whether the decision was unlawful as exposing the
claimant to a real risk of mistreatment contrary to Article 2 or 3 of the European Convention on Human
Rights (“ECHR”) and/or the published policy or practice of the Secretary of State and (3) whether Ms
Begum could have a fair and effective appeal against the deprivation decision from outside the UK. At the
preliminary hearing before SIAC the then Chairman, Elisabeth Laing J, presided; she simultaneously heard
the claim for judicial review as a single judge. By decisions dated 7 February 2020 the preliminary issues
were determined against Ms Begum and the claim for judicial review was dismissed.

8. Ms Begum sought judicial review of the decision of SIAC and appealed against the decision of Elisabeth
Laing J. On 16 July 2020 King, Flaux, and Singh LJJ allowed Ms Begum's appeals (sitting as the Court of
Appeal) and her claim for judicial review (sitting as a Divisional Court). However, the Secretary of State
succeeded in reversing these decisions on appeal to the Supreme Court in a judgment given by Lord Reed
PSC, with whom the other Justices agreed (R (Begum) v Special Immigration Appeals Commission
(“Begum UKSC”) [2021] UKSC 7; [2021] AC 765).

9. The Supreme Court held that the Secretary of State acted lawfully in refusing Ms Begum leave to enter
the UK for the purposes of her appeal to SIAC. She was given the choice of either having that appeal
stayed or proceeding with it notwithstanding that she could not give evidence or be physically present. She


-----

elected to proceed with the substantive appeal, which was heard by SIAC from 21 to 25 November 2022.
In reserved open and closed judgments dated 22 February 2023, in which the case was described as
being “of great concern and difficulty”, SIAC dismissed the appeal.

**The role of the courts in challenges to decisions on the grounds of national security**

10. The relevant principles governing SIAC's jurisdiction and role on an appeal against a decision to
deprive a person of citizenship under s 40(2) are now well established. In summary, those principles are:

i) SIAC is not the primary decision-maker. The exercise of the power conferred by s 40(2) must depend
heavily on a consideration of relevant aspects of the public interest, which may include considerations of
national security and public safety. The primary decision is entrusted to the Secretary of State who has the
advantage of a wide range of advice, including from security specialists.

ii) SIAC's jurisdiction is appellate (and not supervisory). In general, SIAC's powers are restricted to
considering whether the Secretary of State has acted in a way in which no reasonable decision-maker
could have acted, or whether it has taken into account some irrelevant matter or has disregarded
something to which it should have given weight, or has erred on a point of law (an issue which
encompasses the consideration of factual questions). SIAC can consider whether the Secretary of State
has made findings of fact which are unsupported by any evidence or based on a view of the evidence
which could not reasonably be held.

iii) SIAC must have regard to the nature of the discretionary power in question, and the Secretary of
State's statutory responsibility for deciding whether the deprivation of citizenship is conducive to the public
good. It will bear in mind the serious nature of a deprivation of citizenship, and the severity of the
consequences which can flow from such a decision.

iv) In questions involving an evaluation of risk, SIAC allows a considerable margin, and real respect, to the
Secretary of State's assessment. Some aspects of that assessment may not be justiciable; others will
depend on an evaluative judgment. In matters of high policy, SIAC's deference may be effectively simple
acceptance; at more granular levels, it is the function of SIAC to scrutinise all the evidence, open and
closed, assisted by the invaluable contribution of the Special Advocates. It will apply a critical and expert
intelligence – a “powerful microscope” - to test the approach and the evidence bearing on the assessment,
both for and against the conclusions of the Secretary of State, and then, applying due deference, decide
whether the conclusions of the Secretary of State are sustainable.

v) SIAC can make its own findings of fact which may be relevant to the assessment of national security, as
long as it does not use those findings of fact as a platform for substituting its view of the risk to national
security for that of the Secretary of State. Subject to that important limitation, it may make whatever
findings of fact it considers it is able to on the evidence and which, in its expert judgment, it considers that it
is appropriate to make.

vi) SIAC can determine whether the Secretary of State has complied with s 40(4) (concerning
statelessness) and must also determine for itself the compatibility of the decision with the obligations of the
[Secretary of State under the Human Rights Act 1998,where such a question arises.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)

(See Secretary of State for the Home Department v Rehman [2001] UKHL 47;[2003] 1 AC 753 at [57] and

[58]; _Begum UKSC_ at [66] to [71] and [119]; _P3 v Secretary of State for the Home Department [2021]_
_EWCA Civ 1642, [2022] 1 WLR 2869 at [126];_ _U3 v Secretary of State for the Home Department [2023]_
_EWCA Civ 811, [2024] 2 WLR 319 at [101], [169] and [176].)_

**Background**

_The relevant events of 2014-2015_

11. Ms Begum was born in the United Kingdom on 25 August 1999. She was brought up in Bethnal Green
in the London Borough of Tower Hamlets. Her parents are of Bangladeshi origin and, through them, Ms


-----

Begum had Bangladeshi citizenship until her 21st birthday. Until her departure to Syria in February 2015
Ms Begum was living with her mother and older sister in Tower Hamlets.

12. In September 2014 Ms Begum entered Year 11 at Bethnal Green Academy. She was predicted to
attain A/A* grades in most of her GCSE subjects.

13. In the autumn of 2014, Ms Begum's school-friend and peer, Sharmeena Begum (no relation), was
following the Tumblr blog of Aqsa Mahmood. The latter had travelled to Syria from this country earlier in
2014 and, using the moniker “Um Laith”, was encouraging others to follow her there. Sharmeena tweeted
Aqsa Mahmoud asking her to message her directly via Twitter. Sharmeena was a close friend of Ms
Begum and of two other girls who were in due course to travel as a group.

14. On 6 December 2014 another girl from the borough, known as “B”, was planning to travel to Syria via
Istanbul but was taken off the plane at the last moment.

15. The case of B came before Hayden J sitting in the Family Division on 21 August 2015. The evidence
was that B, who was a “stellar” student, had undertaken internet research about ISIS (Islamic State of Iraq
and the Levant, also known as ISIL or Daesh), including information about how to travel to Syria and other
propagandist material. B was also left in no doubt that ISIS was a brutal entity which had carried out, and
was planning to carry out, the most hideous atrocities. As Hayden J observed:

“The case comes before me consecutively with a number of other cases within the Borough of Tower
Hamlets, each of which involves intelligent young girls, highly motivated academically, each of whom has,
to some and greatly varying degrees, been either radicalised or exposed to extreme ideology. … In each of
these cases … young women … have been captured, seduced, by a belief that travelling to Syria to
become what is known as 'Jihadi brides' is somehow romantic and honourable both to them and their
families. There is no doubt, to my mind, that young women have been specifically targeted, in addition to
young men of course, but for different purposes. The reality is that the future for such girls as we know,
holds only exploitation, degradation and risk of death; in other words these children with whose future I
have been concerned, have been put at risk of really serious harm and as such the State is properly
obligated to protect them. …”

16. On 5 December 2014, Sharmeena travelled from Gatwick Airport to Istanbul. Given that it is known
that she ended up in Syria, it is reasonable to infer that she took a bus from Istanbul to the south-east of
Turkey and then crossed the border. According to the Secretary of State, Sharmeena may have
encouraged Ms Begum and her friends to travel to Syria.

17. On a date between 5 and 10 December 2014 police officers visited the school and spoke to seven
girls, including Ms Begum and her two friends. The police came to the conclusion that Ms Begum was not
at risk. SIAC observed that this conclusion may be thought to be “somewhat myopic”. Ms Begum's school
considered that due to her friendship ties with Sharmeena there was a risk that she could also be
encouraged to leave her family, and possibly the UK, and go to Syria. However, as SIAC concluded, it
appears that the school allowed the police assessment to overrule that concern.

18. On 5 February 2015 police officers returned to the school. They handed a letter to Ms Begum and her
friends in the expectation that it would be provided to their parents. It never was. The letter was dated 2
February 2015 and sought parental consent to their child being interviewed by the police “to understand

[her] better and the reasons why she has decided to leave the country”. It is not clear why the police did not
send these letters to the parents directly. The police were later to apologise for this.

19. On 17 February 2015 Ms Begum and her two friends gave their families untrue reasons as to why they
would be absent that day. They travelled together to Gatwick Airport. Ms Begum used the passport of her
sister which she had stolen. They travelled to Istanbul on a Turkish Airways flight.

20. Ms Begum and her friends left Istanbul by bus at some point during the course of the evening of 19
February 2015. The girls travelled overnight and arrived at a point near the Syrian border the following day.
It is the Secretary of State's judgment, reached with the advice of the Security Service (“MI5”), that once


-----

there, Ms Begum aligned with the organisation ISIL. Ten days after arriving in Syria, Ms Begum, still aged
only 15, was “married off” to Yago Riedjik, a Dutch national who was an adult considerably older than her.

21. SIAC said:

“92. ... In our view, putting the matter at its very lowest, there is an arguable case of failing to take
reasonable preventative measures directed against the police, the school and the local authority. The case
against the Home Office is less clear-cut; the case against the Security Services appears thin. None of that
matters for the purposes of Ms Begum's trafficking argument, as will be more fully examined below.

93. There is a limit as to what may be said in OPEN about what happened to Ms Begum in Syria. On the
basis of what is in the public domain, any fair-minded person would have to agree that Hayden J's generic
predictions as to what could well happen to those exploited in this way have been amply borne out in Ms
Begum's case. She was “married off” to an ISIL fighter shortly after her arrival in Syria and spent much of
the following four years pregnant. Her three babies have all died. She remained in ISIL territory until
January 2019, at which time she was in the ninth month of her pregnancy (her third child died in March
2019, three weeks old). Whatever the extent of her ideological commitment before she left in February
2015, Ms Begum could not have had any inkling of how much personal suffering she was destined to
endure.”

22. The self-styled caliphate established by ISIL effectively collapsed in January 2019 after a series of
military defeats. Ms Begum, together with her husband, were in the last pockets of ISIL territory in Baghuz.
They surrendered and were captured by members of the Syrian Democratic Forces (“the SDF”). Ms
Begum was taken to the Al-Hawl camp in north-east Syria.

23. In mid-February 2019, then nine months pregnant and subsequently, even after she had just given
birth, Ms Begum gave a number of interviews to a reporter from The Times newspaper and to other print
and TV journalists. On 14 February 2019, The Times published an article entitled “Shamima Begum: Bring
Me Home”.

24. SIAC considered Ms Begum's interviews in detail, finding as follows:

“102. On 19th February 2019 there was an interview with a BBC journalist which was transmitted that day.
Ms Begum was asked about the Manchester Arena attack and she described it as “kind of retaliation” for
the women and children being killed in Syria and Iraq. Her comment was that this was “fair justification”.
She stated that she had made the choice to leave and travel from the United Kingdom to Syria:

“Even though I was only 15 years old … I could make my own decisions back then. I do have the mentality
to make my own decisions and I did leave on my own knowing that it was a risk.”

103. The Commission understands the force of the argument that those who have been groomed,
radicalised and trafficked do not necessarily understand and/or process all of what has happened to them.
However, that argument cannot be elevated to a universal or absolute principle. On one interpretation of
this interview, Ms Begum was being disarmingly frank and was also showing self-awareness.”

_The Minors' Policy_

25. On 31 January 2019 a memorandum had been submitted to the Secretary of State and the Security
Minister by Phil Larkin, an official in the Special Cases Unit (known as SCU) and the Office of Security and
Counter-Terrorism (known as OSCT), who gave oral evidence before SIAC. This memorandum came to
be known as the “minors' policy”. That policy was approved by the Secretary of State on 14 February
2019. The extract from the policy placed in evidence in the open hearing begins with the sentence “NOTE
our starting position that we consider minors assessed to have been radicalised to be vulnerable victims”.
Only paragraphs 4 and 19 of the minors' policy were produced in open and they provided as follows

[emphasis in the original]:

“4. We accept that individuals who have been radicalised as minors and travelled to Syria or Iraq, or
**who, whilst a minor, have been taken to Syria or Iraq by their family, are first and foremost victims.**
It is possible that some of these individuals may be self-motivated but that may be difficult to establish and


-----

so our presumption is that in most if not all cases, the individual will have been manipulated or radicalised
at some stage – either at home in the UK, or during their time in Iraq/Syria. Our general view is that it is
reasonable to consider that, as a minor, such an individual would be more at risk of radicalisation, and less
able to resist such manipulation, than an adult. For this reason we consider that individuals who have been
radicalised as minors should be considered as vulnerable victims.

19. Where a minor has now reached the age of majority but there is a national security case against them
to justify deprivation and that is based on their actions as a minor, we will recommend deprivation … Whilst
such individuals may once again be considered as a victim, perhaps having been radicalised or compelled
to travel to Syria/Iraq as a minor, this does not alter the assessment that will have been carried out as the
threat they now pose to the UK. In preparing advice in such cases, we would continue to explore carefully
any information to suggest an individual who had not travelled to theatre as a minor of their own volition
and had not been involved in further activity of concern, is now as an adult seeking to distance themselves
or escape from an ISIL/AQ group. As with other cases, where such information exists, it will be included in
the advice put before you, as this could provide a basis for holding back from deprivation action.”

26. On 17 February 2019 the _Sunday Times published an article by the Secretary of State under the_
headline: “If you run away to join ISIS, like Shamima Begum, I will use all my powers to stop you coming
back”.  In that article, the Secretary of State wrote that deprivation powers are used “very carefully” and
that “we look at the facts of each case, the law and the threat to national security”.

_The Ministerial Submission and Decision in Ms Begum's case_

27. On 18 February 2019 a ministerial submission with accompanying documents was received by the
Secretary of State. The submission recommended that the appellant be deprived of her British citizenship
on the basis that it would be conducive to the public good due to the threat that she was assessed to pose
to UK national security.  The Secretary of State was also asked to sign the decision notice and to certify
the decision, in accordance with s 40A(2), as having been based in part on information which should not be
made public for reasons of national security and because it would not otherwise be in the public interest to
do so. A summary of the submission was placed in evidence in the open hearing.

28. One of the annexes to the submission, dealing with the potential risks to Ms Begum of mistreatment
contrary to Articles 2 and 3 of the ECHR, expressed the view that although there was a risk that individuals
in Bangladesh could be subject to conditions which would not comply with the ECHR, the Secretary of
State may consider that there was no real risk of her returning to Bangladesh. Neither the submission nor
the annexes to it expressly considered the issue which forms the basis of Ms Begum's third ground of
appeal before this court, that if deprived of British citizenship she would be “de facto stateless”.

29. The Secretary of State agreed with the recommendations in the submission on 19 February 2019.
Notice of that decision was served to file, in accordance with the Secretary of State's practice at that time
(which practice was subsequently held to be unlawful, leading to the implementation of s 40(5A)-(5E): see
_R (D4) v Secretary of State for the Home Department [2022] EWCA Civ 33, [2022] QB 508). Ms Begum's_
family was notified of the decision by letter of the same date, 19 February 2019.

_Appeal to SIAC_

30. Ms Begum appealed to SIAC against the deprivation decision. She advanced nine grounds of appeal.
It was not until late 2022 that the appeal came before SIAC. As well as the pandemic, a major factor in the
delay was the appeals to this court and to the Supreme Court which we have outlined above. The decision
under challenge remained, however, that of the Secretary of State dated 19 February 2019. Indeed it is
important to note that the same decision could no longer be made, because with the loss of Ms Begum's
Bangladeshi citizenship when she reached her 21[st] birthday, a decision to deprive her of her British
citizenship now would render her stateless (contrary to s 40(4)). It is common ground that subsequent
material (whether exculpatory or inculpatory) was admissible before SIAC to the extent that it could help to
demonstrate whether or not the original decision was lawful.


-----

31. The post-decision material before SIAC included two National Security Statements filed on behalf of
the Secretary of State. In its judgment at [135], SIAC emphasised the significance of this passage from the
Amended First National Security Statement dated 27 May 2022:

“36. We assess that multiple factors are likely to have contributed to BEGUM's decision to travel but, as
outlined above we assess that BEGUM's activities prior to and during her travel to Syria demonstrated
determination and commitment to aligning with ISIL. As set out above, we assess that BEGUM was aware
of the atrocities committed by ISIL and their ideology prior to travel and her decision to align with ISIL and
was therefore indicative of her extremist mindset.

37. Considering all the information that is now available, we have not altered our assessment that BEGUM
posed a risk to UK national security at the time she was deprived of her British nationality. We maintain our
assessment that BEGUM travelled to Syria and aligned with ISIL.”

32. Ms Begum's case was kept under review by officials but was not referred back to the Secretary of
State at any stage.

**SIAC's decision**

33. We will not attempt to do more than give some extracts from the detailed 413-paragraph open
judgment of SIAC.

_Trafficking – ECHR Article 4_

34. This argument became Ground 1 before us (it was Ground 2 before SIAC). SIAC made a finding of
fact at [219] that “there is a credible suspicion that Ms Begum was recruited, transferred, and then
harboured for the purpose of sexual exploitation”. SIAC noted that she had been a child at the time.
However, it went on to say:

“227. Ms Begum must also show that the exercise of the section 40 power amounts to a breach of her
rights under Article 4 of the ECHR. Anything less than that will not suffice on this appeal under section 2B.
A credible suspicion that she was trafficked does not, in and of itself, amount to a violation of Article 4.
Consideration must now be given to the investigative duty and then the protective duty.”

35. SIAC noted the contrast with _MS (Pakistan) v Secretary of State for the Home Department [2020]_
_UKSC 9, [2020] 1 WLR 1373, where the exercise of the executive power of removal entailed a violation of_
ECHR Article 4 because MS's presence in this country was integral to an effective investigation. Ms
Begum, by contrast, was not within the jurisdiction. It continued:

“228. … Even if, for the purposes of argument, it may be accepted that an effective investigation requires
her to be here, because she cannot be properly assessed in Syria, a violation of Article 4 would occur only
if the Secretary of State were under an obligation to repatriate her for that purpose.”

36. SIAC rejected the submission that there was a repatriation obligation under Article 16 of the European
Convention Against Trafficking (“ECAT”). It held at [234] that “if the Article 16 ECAT duty were directly
justiciable, Ms Begum's argument would have some force”, but held that it was not directly justiciable.
General statements to the effect that the UK Government offers assistance to the victims of **_modern_**
**_slavery were insufficient to prevent the Secretary of State from exercising the power of deprivation instead_**
of repatriating. As to any recovery obligation arising under the ECHR, SIAC held that by the time of the
deprivation decision Ms Begum was no longer in ISIL-controlled territory and that any recovery obligation
did not apply. It rejected the argument that there was “a relevant breach of the investigative duty” by the
exercise of the deprivation power (see [237]).

37. Turning to the protective duty, SIAC said:

“238 ... the State may have failed in its duties to Ms Begum before she travelled to Syria, but she is now
well beyond the scope of its protection. An investigation into whether there was a material failure meets the
same arguments that have just been addressed in the context of the investigative duty. Ms Begum needs
to persuade us, not merely that there is a credible suspicion that the protective duty has been breached,
but also that this violation is directly and necessarily relevant to the exercise of the section 40 power to the


-----

extent that it would, perforce, be an unlawful exercise of that power to exercise it pending any investigation.
Although in a general and unspecific sense we recognise the force of the point that by depriving Ms Begum
of her citizenship she is not being “protected”, that is not the issue. There must be a direct connection
between the exercise of the power and the violation of the right, and what happened in 2015, even if a past
injustice falls to be remedied, or at least recognised, does not provide that connection.”

38. Finally, SIAC considered whether the non-punishment principle set out in Article 26 of ECAT applied
and held that the exercise of the s 40 power did not contravene the non-punishment principle (see [246]).

_Trafficking – common law_

39. This argument (which became Ground 2 before us but was Ground 1 before SIAC) was that the
Secretary of State failed to take account of a mandatory relevant consideration, namely the credible
suspicion that Ms Begum had been trafficked. SIAC described this as a “lesser version” of the previous
ground in that it was unnecessary for the argument to show that the exercise of the s 40 power was a
violation of ECHR Article 4. But SIAC held, in contrast with the human rights argument, that in dealing with
this public law challenge it was not for SIAC to decide the credible suspicion issue itself. Indeed, the finding
of credible suspicion for the purposes of the human rights argument had no relevance to this common law
(public law) ground. For the purposes of that ground “the limelight is on the Secretary of State and the
breadth of the section 40 power” (see [254]). As to that, SIAC said:

“257. …[T]he proposition that the Secretary of State must view Ms Begum's case through the lens of
trafficking cannot be supported. This is not a mandatory relevant consideration, and there is an inherent
question-begging in the contention that it is. On Ms Knights' argument, the primary focus would not be
national security but the fact that Ms Begum was groomed by others for the purposes of sexual
exploitation. [SIAC] cannot accept that the Secretary of State should be compelled to view her case in
these terms. Further, the trafficking analysis removes from consideration all questions of fact and degree.
We have already made the point that the legal policy underlying Article 4 is not nuanced. Children cannot
consent to sexual exploitation and the inquiry ends there. However, for the purposes of the broader
considerations relevant to the proper exercise of the power under section 40, there is force in Sir James'
submission that issues of personal responsibility and agency are not black and white. Despite her age, Ms
Begum could “consent” to travelling to Syria for the purpose of aligning with ISIL: that is a key
consideration relevant to national security and the lawful exercise of the section 40 power. We know from
the case of _B that children such as Ms Begum were radicalised to greatly varying degrees. It cannot be_
presumed in her favour that her radicalisation was at the more serious end of the scale.”

40. SIAC concluded as follows:

“259. … [SIAC] is unable to accept Ms Knights' argument that trafficking is relevant to the exercise of the
section 40 power.

260. ... it is for the Secretary of State to decide what is in the public interest, and how much weight to give
to certain factors, subject always to [SIAC] intervening on ordinary administrative law principles. This
Secretary of State, speaking through Sir James, maintains that national security is a weighty factor and
that it would take a very strong countervailing case to outweigh it. Reasonable people will profoundly
disagree with the Secretary of State, but that raises wider societal and political questions which it is not the
role of [SIAC] to address. This is because questions of weight and balance are pre-eminently for the
decision-maker and not for [SIAC], subject always to _Wednesbury review. It is well established that a_
decision-maker may decide to give a material factor no weight: see Lord Hoffmann in Tesco Stores Ltd v
_Secretary of State for the Environment [1995] 1 WLR 759, at 780.”_

41. SIAC went on to consider Ms Begum's attack on the lawfulness of the minors' policy. Not all of this
challenge was repeated before us but Ms Knights KC did maintain her challenge on the issue of
voluntariness. As to this, SIAC upheld the Secretary of State's assessment of voluntariness:


-----

“280. One of the key planks of the national security assessment is that Ms Begum travelled voluntarily to
Syria, demonstrated determination and commitment in doing so, and remained in ISIL-controlled territory
for four years.

…

285. … It is clear from all the documentation available in OPEN that the assessment that Ms Begum
travelled voluntarily is in the nature of a national security assessment. It may well be the case that experts
and those with experience of these matters are well-placed to form their own judgments as to whether a 15
year old girl who may have been radicalised and was not “self-motivated” acted “voluntarily”. It may also be
the case that [SIAC] is not without experience of its own derived from other areas of the law, including
criminal law. However, in [SIAC's] experience many national security assessments require an
understanding of human nature, and the context of the present case is terrorism and national security. We
consider that [the Security Service] is not merely well-placed to make experiential judgments on matters
such as voluntariness and degree of commitment in that particular context, but also that these issues fall
within their institutional and constitutional competence. The consequence must be that [SIAC] defers.

…

291. It is clear from all the available evidence that the Secretary of State was aware of the following
matters: Ms Begum's youth; that she travelled to Syria as a minor and was therefore, under the terms of
the policy that he had approved just four days previously, could once again be regarded as a victim
because she was radicalised at an age when she could not be treated as fully responsible (per para 4 of
the policy); and, that it was not solely the risk she posed that was driving the outcome.

292. Furthermore, although voluntariness falls on a notional spectrum, those advising the Secretary of
State are entitled to say on which side of the line a particular case is assessed to fall. The steps Ms Begum
had to take to get to Syria can be viewed as being in her favour, against her or neutral, but that was for the
Secretary of State to reach a conclusion about and not for the Commission to decide for itself. The same
applies to the ramifications of Ms Begum's lengthy sojourn in Syria and whether there was any possibility of
escape. Even had the Secretary of State been advised in terms that the issue of voluntariness was
nuanced and that this was not an all-or-nothing question, he would still have been told that her travel to
Syria demonstrated determination and commitment.

293. Ultimately, although many right-thinking people will strongly take issue with the assessment of those
advising the Secretary of State, [SIAC] has come to the conclusion that the assessment that Ms Begum's
travel was voluntary cannot be impugned on the application of administrative law principles in these
appellate proceedings.”

_De facto statelessness_

42. This was Ground 3 before us, as before SIAC. SIAC observed that Ms Begum's case under this
ground was straightforward: even if the deprivation decision did not render her technically stateless, it had
that practical effect. One way or another, she could not go to Bangladesh, and that meant there was
nowhere for her to go, a factor which the Secretary of State had failed to take into account.

43. SIAC held:

“303. [SIAC] has thought carefully about this but cannot accept this argument. It will assume for present
purposes that the relevant question must be addressed as at 19th February 2019, taking into account
subsequent evidence to the extent that it bears on that question, and not as at today's date – when there is
absolutely no prospect of Ms Begum being admitted to Bangladesh since she is now over 21 and is not a
citizen of that country. The Secretary of State was told in terms that there was no real prospect that Ms
Begum would go, or be compelled to go, to Bangladesh and he also knew that she could not go there for
her own safety. He was therefore aware of the devastating impact that [SIAC] has identified, and it must be
inferred that he considered this. Mr Squires did not contend in the alternative that the Secretary of State's
decision was perverse.”

_Procedural unfairness_


-----

44. This was Ground 4 before us, as before SIAC. SIAC recorded (at [307]) that for many years it had
proceeded on the basis that the recipient of a deprivation decision and order did not have the right to make
prior representations to the decision-maker, and that any unfairness was remedied by the appellate
process; a different constitution of SIAC chaired by Flaux J had so held in Al-Jedda (No. 2) v Secretary of
_State for the Home Department_ (SC-66-2008, 18 July 2014) (“Al-Jedda”) in a ruling not affected by the
subsequent Supreme Court decision in the same case.

45. In Al-Jedda, it was decided that there was no duty of prior consultation before a deprivation order was
made on national security grounds. The reasons were summarised by SIAC at [322]-[323], to the following
effect: (1) s 40(5) sets out an exhaustive procedural framework which does not include any obligation to
give prior notice (a reference to [156] of _Al-Jedda); and, as a separate reason leading to the same_
conclusion (2) Parliament has conferred a full merits appeal on a person deprived of citizenship, by s 2B of
SIACA 1997, in contrast with judicial review proceedings which do not afford such a right (a reference to

[159] of Al-Jedda).

46. Before SIAC in the present case, reliance was placed on the judgment of Lord Sumption JSC (with
whom the majority agreed) in Bank Mellat v HM Treasury (No.2) [2013] UKSC 39, [2014] AC 700:

“35. The duty of fairness governing the exercise of a statutory power is a limitation on the discretion of the
decision-maker which is implied into the statute. But the fact that the statute makes some provision for the
procedure to be followed before or after the exercise of a statutory power does not of itself impliedly
exclude either the duty of fairness in general or the duty of prior consultation in particular. … Like Lord
Bingham in R (West) v Parole Board [2005] 1WLR 350, para 29, I find it hard to envisage cases in which
the maximum expressio unius exclusio alterius could suffice to exclude so basic a right as that of fairness.”

47.  SIAC also noted at [317] the rule as it was formulated by Lord Neuberger JSC in Bank Mellat:

“179. … before a statutory power is exercised, any person who foreseeably would be significantly affected
by the exercise should be given the opportunity to make representations in advance, unless (i) the
statutory provisions concerned expressly or impliedly provide otherwise or (ii) the circumstances in which
the power is to be exercised would render it impossible, impractical or pointless to afford such an
opportunity.”

48. SIAC recognised that s 40(5) contained an exhaustive statutory code but did not think that was
sufficient by itself to justify the conclusion that common law fairness had been impliedly excluded. SIAC
concluded that the decision in Al-Jedda had failed to accord sufficient weight to Lord Sumption's judgment
in Bank Mellat, [35] in particular (see SIAC's judgment at [327]). Nevertheless, it thought that Al-Jedda was
correctly decided on the premise that there was also a full merits appeal against a deprivation decision,
and that in combination, those reasons supported the conclusion that s 40 excluded a right of prior
representation ([328]), a conclusion which was not displaced by the fact that not all deprivation decisions
were for national security reasons or involved people outside the UK (see [329]). However, SIAC held that
because the Al-Jedda premise of a full merits appeal had now been removed by Begum UKSC, with which
_Al-Jedda could not be reconciled ([331]), the right to prior representation was not impliedly excluded. SIAC_
held:

“337. On balance, and not without some hesitation, we have concluded that, in the absence of a full merits
appeal, it cannot be said that common law fairness has been impliedly excluded.”

49. Having decided the point of principle in Ms Begum's favour, SIAC returned to Bank Mellat to consider
Lord Neuberger's exceptions to the general rule, namely when the giving of advance notice would be
impossible, impractical or pointless. SIAC noted that the concepts of impossibility and impracticability must
take into account the fact that giving an opportunity to make representations may be contrary to national
security, and that SIAC's experience was that it was usually contrary to national security to give an
individual who was outside the United Kingdom prior notice, “not least because prior notification runs an
unacceptable risk of precipitating his or her early return”; but SIAC accepted that B4 v Secretary of State
_for the Home Department (SC/159/2018) might have gone slightly too far in suggesting that “the general_
rule in national security cases is that there is no duty to seek representations before making the deprivation


-----

order…”, noting that the deprivation power could be exercised even where the individual is in the United
Kingdom in which case the risk of early return was inapplicable (see [341]). SIAC held that “political rather
than national security factors drove the outcome” in Ms Begum's case ([342]). When it came to
pointlessness, SIAC held that any attempt by Ms Begum to challenge the national security case at the predecision stage would have been fruitless:

“346. … prior notification would have given her the opportunity to set out in summary form some of the
compassionate circumstances which should go into the balance. It would not have been incumbent on the
Secretary of State to wait the many months it would have taken to assemble the powerful evidential case
contained in the voluminous bundles placed before the Commission in this appeal. The Secretary of State
is entitled to proceed relatively speedily in the public interest, and a brief window of opportunity is all that
would and should have been afforded. The national security context is relevant here.

347. In this brief hypothetical timeframe, and whatever the position regarding Ms Begum's legal
representation as at 19th February 2019, it would not have been possible for valuable instructions to have
been obtained from Ms Begum herself, given the circumstances in which she was living. We cannot ignore
the practical reality that these instructions still have not been obtained. The most that would and could
have happened, assuming everything in Ms Begum's favour, is that Ms Gareth Peirce or someone else
would have put together, no doubt expressed in powerful and eloquent terms, a number of obvious
reasons why this draconian and radical step should not be taken.

…

349. Overall, the Commission does not consider that representations of the nature we are predicating
would have made any practical difference in the particular circumstances of Ms Begum's case, even in the
context of a decision-making process that was at its formative stage. The Secretary of State was of course
aware that Ms Begum was a child at the time of her departure and might have been the victim of
radicalisation and so forth, and he would clearly understand that this was not a decision to be taken lightly.
He was also aware, as we have found, that Ms Begum – assuming that she could ever surmount a number
of obvious practical difficulties - could not travel to Bangladesh without putting herself at personal risk.
Whatever the force of the pre-decision advocacy put forward on Ms Begum's behalf, we are confident to
the requisite standard that the outcome would have been the same.

350. It is not sufficient for Ms Begum's purposes to demonstrate a technical breach of the rules of natural
justice. … Strictly speaking, the position must be examined as at today's date, taking into account all the
material now available, rather than as at 19th February 2019 or shortly thereafter. Either way, it makes no
difference. The Commission is entirely satisfied that the outcome would have been the same four years
ago and that it would be and is the same now.

351. Sir James did not advance any oral submissions directed to … the well-known decision of the Court of
Appeal in Simplex GE (Holdings) v Secretary of State for the Environment … However, Sir James did not
abandon his skeleton argument, and could not have predicted on which issue or issues his submissions
might not prevail.”

_The public sector equality duty_

50. This was Ground 7 before SIAC, Ground 5 before us. SIAC held that the public sector equality duty
[(“PSED”) created by s 149(1) of the Equality Act 2010 (“EA 2010”) was excluded by s 192 of the same Act,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
which provides that “a person does not contravene the Act only by doing, for the purpose of safeguarding
national security, anything that it is proportionate to do for that purpose.” They rejected Mr Squires'
[argument that the s 192 exemption relates only to the discharge of any function or duty under the EA 2010](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
(see [387]-[391]). They went on to hold that even if s 192 had not applied they were satisfied that there was
no breach of the PSED (see [393] - [399]).

_Grounds not pursued in this court_

51. SIAC also rejected grounds alleging pre-determination of the case by the Secretary of State, unfair
presentation in the ministerial submission of the risks posed by the returnees from Syria and arguments


-----

based on Article 8 of the ECHR. Permission to appeal was not sought on any of these grounds. We need
say no more about them.

**Grounds of appeal and Respondent's Notice**

52.  We summarise Ms Begum's grounds of appeal.

(1) Trafficking: Article 4 ECHR: Pursuant to the procedural protections imposed by Article 4, prior to taking
the decision to deprive, the Secretary of State was required to consider (a) whether Ms Begum was a
potential victim of trafficking; (b) whether there had been any failures by the State to protect Ms Begum
from trafficking; (c) the legal obligations owed to Ms Begum as a victim or potential victim of trafficking
(pursuant to the Article 4 investigative, protective, recovery and restitutionary obligations); and (d) the fact
that deprivation would impede the State's ability to discharge those obligations. Having considered these
issues, the Secretary of State then had to decide whether in the circumstances deprivation could
nonetheless be justified. The Secretary of State's failure to consider these matters meant the decision to
deprive Ms Begum of her citizenship breached Article 4, and SIAC erred in its consideration of this issue.

(2) Trafficking: common law: The fact that Ms Begum had been or might well have been trafficked was a
mandatory and relevant consideration in determining whether it was conducive to the public good and
proportionate to deprive her of her citizenship but was not considered by the Secretary of State. As a
consequence, the deprivation decision was unlawful, and SIAC erred in its analysis of this issue.

(3) De facto statelessness: The deprivation decision was unlawful on account of a failure by the Secretary
of State to have regard to whether the decision to deprive would render Ms Begum de facto stateless on
account of her de jure Bangladeshi citizenship being of no practical value to her. SIAC correctly concluded
that this was a mandatory relevant consideration to which the Secretary of State was required to have
regard. However, SIAC erred in finding that the matter had been properly considered.

(4) Procedural unfairness: SIAC correctly held that the requirements of natural justice should be read into
s 40, that they had not been expressly or impliedly excluded by Parliament, and that they had been
breached because the Secretary of State improperly failed to afford Ms Begum an opportunity to make
representations prior to the decision to deprive her of citizenship. That decision was therefore vitiated by
an error of law. It held, however, applying _Simplex GE (Holdings) v SSE_ [1988] P&CR 306, that the
outcome would “inevitably” have been the same. In doing so, SIAC misapplied the Simplex test.

(5) Breach of the PSED: The deprivation decision was taken in breach of the PSED under s 149 EA 2010.
SIAC rejected the argument on the basis that the Secretary of State had a defence pursuant to s 192 of
that Act, and had not, in any event breached s 149(1)(a) or s 149(1)(c). SIAC erred: (i) in its interpretation
of s 192; and (ii) in concluding that SIAC had not breached ss 149(1)(a) or 149(1)(c).

53. By a Respondent's Notice the Secretary of State has sought to uphold the decision of SIAC for
additional and different reasons in respect of (what are now, adopting the numbering in the grounds of
appeal as set out in the previous paragraph) grounds 1, 4, and 5. In summary:

(1) Ground 1: Trafficking and Article 4 ECHR: SIAC's conclusions were predicated on the application of
Article 4 to Ms Begum's case. However, Ms Begum was not within the jurisdiction of the UK for the
purposes of Article 1 ECHR and so no issue under Article 4 ECHR could arise. SIAC did not, however,
determine that primary issue. In failing to do so, it erred.

(2) Ground 4: Procedural fairness: SIAC's approach to procedural fairness and prior representations was
flawed: (a) the framework provided by s 40 provides an exhaustive statutory code which impliedly excludes
any further right to make representations in advance of the decision to deprive a person of the British
citizenship; (b) _Begum UKSC_ does not require a departure from the finding in _Al-Jedda._ There is no
obligation to give prior notice of a deprivation order because Parliament has conferred a right to a full
merits appeal. (c) Further and alternatively, if SIAC was right that procedural fairness did, in principle,
require an opportunity to make prior representations, then it was wrong to find that there was any public
law error in this respect, whether material or otherwise. SIAC correctly found that it would not have been
possible for Ms Begum to provide “valuable instructions” and that such instructions had still not been


-----

obtained at the time of the substantive appeal hearing before SIAC. SIAC was right to find that such an
opportunity would not have made any practical difference in the particular circumstances of this case.
SIAC was, however, wrong to suggest that this was for political rather than national security reasons.  (d)
As such, the proper analysis was that there was no error, rather than that there was an immaterial error.
Alternatively, if SIAC was right to find that there was an error, then any such error was immaterial.

(3) Ground 4: Simplex: The Secretary of State maintained in full his argument based on Simplex both in
relation to Ground 4 (prior representations) and generally.

(4) Ground 5: PSED: SIAC erred in finding that the PSED was engaged, despite the fact that Ms Begum
was abroad at the time of the decision to deprive. The PSED does not apply to persons or matters outside
the UK. The fact that the exercise of the s 40 power itself is linked to the UK, or the exercise of that power
may have impacts in the UK, is not sufficient to bring it within the scope of the PSED.

**Ground 1: ECHR Article 4**

54. Before dealing with the grounds of appeal we emphasise that an appeal from SIAC to this court may
only be brought on a question of law. Thus, findings of fact made by SIAC are rarely susceptible to
challenge on appeal. There are two findings of fact in particular that Sir James Eadie KC for the Secretary
of State accepted were not appealable (although in each case he emphasised that they were couched in
carefully limited terms). The first was the finding that there was a credible suspicion that Ms Begum had
been the victim of trafficking in 2015. The second is the finding that “putting the matter at its very lowest,
there is an arguable case of failing to take reasonable preventative measures” in and before February
2015, in relation to the police, the school and the local authority.

_The correct approach_

55. Although Ms Knights initially complained that the Secretary of State had breached obligations owed to
Ms Begum under Article 4, her submissions narrowed to a central submission under Ground 1 that the
Secretary of State had failed to take into account the possibility of breach of Article 4 by the UK authorities.
This was to shift away substantially from the arguments advanced before SIAC which proceeded on the
basis that there had been actual breach (or breaches) of Article 4, and not merely a failure to take account
of the possibility of breach.

56. Ms Knights submitted that it was necessary for the Secretary of State to take into account any possible
breaches of Article 4 as part of his assessment of whether deprivation was conducive to the public good
pursuant to s 40. She said that the obligation (to take possible breaches into account) was consequent
upon the credible suspicion that Ms Begum had been trafficked. She relied in particular on VCL v United
_Kingdom (2021) 73 EHRR 9 where the court held:_

“160. … It follows that, as soon as the authorities are aware, or ought to be aware, of circumstances giving
rise to a credible suspicion that an individual suspected of having committed a criminal offence may have
been trafficked or exploited, he or she should be assessed promptly by individuals trained and qualified to
deal with victims of trafficking. …”

57. She drew our attention to examples in domestic cases of the possibility of Article 4 breaches being
taken into account: _EK Tanzania_ _[[2013] UKUT 00313 (IAC) at [44] and [67], and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5929-8BS1-F0JY-C1RS-00000-00&context=1519360)_ _MS (Pakistan)_ at [35].
She also cited Hesham Ali v Secretary of State for the Home Department [2016] UKSC 60, [2016] 1 WLR
4799 at [169] where Lord Kerr identified the “multi-faceted” nature of the public interest in the context of the
proportionality of deportation of foreign criminals.

58. By contrast, Sir James submitted that in circumstances where the statute did not identify what
considerations were to be taken into account (as s 40 did not), it was necessary to define the threshold or
test for determining whether, and if so which, considerations needed to be taken into account. He
submitted that it was for the Secretary of State to determine what factors counted as material, which was
itself a matter for the rational judgment of the Secretary of State, citing CREEDNZ Inc v Governor-General

[1981] 1 NZLR 172 at 183, R (DSD) v Parole Board and Another [2018] EWHC 694 (Admin), [2019] QB


-----

285 at [141] and R (Friends of the Earth Ltd and another) v Secretary of State for Transport _[2020] UKSC_
_[52, [2021] 2 All ER 967 at [116]-[121], noting [120] in particular:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62SP-0NS3-GXFD-825Y-00000-00&context=1519360)_

“120. … a decision-maker may not advert at all to a particular consideration. In such a case, unless the
consideration is obviously material according to the _Wednesbury_ irrationality test, the decision is not
affected by any unlawfulness”.

59. He submitted that the same point could be put alternatively as part of the _Tameside_ duty to make
enquiries. The elements of that duty were summarised in R (Balajigari) v Secretary of State for the Home
_Department [2019] EWCA Civ 673, [2019] 1 WLR 4647 at [70], to largely similar effect: it was for the_
Secretary of State to determine what further enquiries were to be made, and he could only be challenged
on rationality grounds.

60. This was, in essence, to submit that the approach to Ground 1, concerning Article 4, was the same as
the approach to Ground 2, concerning common law: Parliament had confided the discretion under s 40(2)
to the Secretary of State and it was for him to determine what was or was not a relevant consideration,
subject to a rationality challenge.

61. We do not consider that the authorities relied upon by Ms Knights make good her submission that the
possibility of Article 4 breach was a necessary part of the assessment of whether or not deprivation was
conducive to the public good. This was not the issue under consideration in the authorities in question.
Thus, for example and as explored in greater detail below, VCL related to the quite different question of a
State's right to prosecute a putative victim of trafficking.

62. Rather, the approach to be adopted is the well-established public law test identified in the line of
authorities including _Friends of the Earth. The question for us is whether the credible suspicion that Ms_
Begum was trafficked (and the possible breaches of Article 4 consequent upon that suspicion), taken alone
or together, amounted to an obviously material consideration for the Secretary of State in the assessment
of whether to deprive Ms Begum of her citizenship, according to the Wednesbury irrationality test.

_Article 4, related instruments and relevant case law_

63. Article 4 of the ECHR states:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.”

64. Article 4 of ECAT provides:

“(a) 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt
of persons by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of
deception, of the abuse of power or a position of vulnerability or of the giving or receiving of payment or
benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation. Exploitation shall include, at a minimum, the exploitation or the prostitution of others or other
forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or
the removal of organs.

…

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation
shall be considered 'trafficking in human beings' even if this does not involve any of the means set forth in
subparagraph (a) of this article.

(d) Child shall mean any person under 18 years of age.”

65. Article 26 of ECAT provides:

“Each party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
been compelled to do so.”


-----

66. In her submissions, Ms Knights placed particular emphasis on three Strasbourg cases dealing with a
State's obligations under Article 4 of the ECHR. The first and most important was _Rantsev v Cyprus &_
_Russia [2010] 51 EHRR 1. Ms Rantseva, who was aged 21 at the age of her death, was working on an_
“artiste” visa in a cabaret in Cyprus. She wrote a note saying that she wanted to return home to Russia.
The manager of the cabaret informed the authorities and, when she was seen at a discotheque,
apprehended her and took her to a police station. The police consigned her to the manager, who took her
to the apartment of a male employee. The next morning, she was found dead in the street below the
apartment. Her father then brought a claim against both Russia and Cyprus under inter alia Article 4 of the
ECHR. The relevant claim for present purposes is the one against Russia because at the time of Ms
Rantseva's death she was outside the jurisdiction of that country.

67. The court said:

“287. Bearing in mind the difficulties involved in policing modern societies and the operational choices
which must be made in terms of priorities and resources, the obligation to take operational measures must,
however, be interpreted in a way which does not impose an impossible or disproportionate burden on the
authorities (see, mutatis mutandis, Osman, cited above, § 116) …

288. Like Articles 2 and 3, Article 4 also entails a procedural obligation to investigate situations of potential
trafficking. … For an investigation to be effective, it must be independent from those implicated in the
events. It must also be capable of leading to the identification and punishment of individuals responsible,
an obligation not of result but of means. A requirement of promptness and reasonable expedition is implicit
in all cases but where the possibility of removing the individual from the harmful situation is available, the
investigation must be undertaken as a matter of urgency. The victim or the next-of-kin must be involved in
the procedure to the extent necessary to safeguard their legitimate interests (see, mutatis mutandis, Paul
_and Audrey Edwards, cited above, §§ 70 to 73)._

289. Finally, the Court reiterates that trafficking is a problem which is often not confined to the domestic
arena. When a person is trafficked from one State to another, trafficking offences may occur in the State of
origin, any State of transit and the State of destination. Relevant evidence and witnesses may be located in
all States. Although the Palermo Protocol is silent on the question of jurisdiction, the Anti-Trafficking
Convention explicitly requires each member State to establish jurisdiction over any trafficking offence
committed in its territory…”

68. At [304]-[309] the court held that any positive obligation incumbent on Russia to take _operational_
measures could only arise in respect of acts which occurred on Russian territory. Since there was no
evidence that the Russian authorities were aware of circumstances giving rise to a credible suspicion of a
real and immediate risk to Ms Rantseva herself prior to her departure to Cyprus, there was no violation of
Article 4 in respect of any obligation to take operational measures. However, the procedural obligation on
the Russian authorities to investigate trafficking had not been fulfilled:

“308. … The recruitment having occurred on Russian territory, the Russian authorities were best-placed to
conduct an effective investigation into Ms Rantseva's recruitment.”

69. In SM v Croatia (2021) 72 EHRR 1 the ECtHR found a breach of the Article 4 investigative obligation
in the context of allegations of trafficking with a view to prostitution. The Court repeated that the procedural
obligation is a “requirement of means and not of result” (see [315]), and that “the authorities must take
whatever reasonable steps they can to collect evidence and elucidate the circumstances of the case…”
(see [316]).

70. The third case is _VCL v United Kingdom, a decision of the Grand Chamber. The applicants were_
Vietnamese nationals who were arrested and prosecuted for involvement in the production of class B
drugs, despite the existence of a credible suspicion that they were victims of trafficking. The Court
reviewed the United Kingdom's anti-trafficking legislation and processes (including the **_[Modern Slavery](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
_[Act 2015,associated guidance and the National Referral Mechanism). It held that there was no general](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
prohibition on the prosecution of victims of trafficking, even child victims ([158]), but that there may be


-----

circumstances where the prosecution of victims of trafficking may be at odds with the State's duty to take
operational measures:

“159. Nevertheless, the Court considers that the prosecution of victims, or potential victims, of trafficking
may, in certain circumstances, be at odds with the State's duty to take operational measures to protect
them where they are aware, or ought to be aware, of circumstances giving rise to a credible suspicion that
an individual has been trafficked. In the Court's view, the duty to take operational measures under art.4 of
the Convention has two principal aims: to protect the victim of trafficking from further harm; and to facilitate
his or her recovery. It is axiomatic that the prosecution of victims of trafficking would be injurious to their
physical, psychological and social recovery and could potentially leave them vulnerable to being retrafficked in future. Not only would they have to go through the ordeal of a criminal prosecution, but a
criminal conviction could create an obstacle to their subsequent integration into society. In addition,
incarceration may impede their access to the support and services that were envisaged by the AntiTrafficking Convention.”

71. The Respondent's Notice argues that, since Ms Begum was in 2019 (and still is) not within the
jurisdiction of the UK for the purposes of Article 1 of the ECHR, no issue under Article 4 of the ECHR can
arise.

_Discussion_

72. In the light of the judgment in Rantsev, SIAC was right to reject the Secretary of State's jurisdictional
argument as being a simple answer to all aspects of the case based on Article 4. The argument is more
nuanced than that.

73. The first stage in any Article 4 assessment is to ask whether it has been demonstrated that the State
authorities were aware, or ought to have been aware, of circumstances giving rise to a credible suspicion
that an identified individual had been, or was at, a real and immediate risk of being trafficked or exploited
(see eg VCL at [160]). Credible suspicion is not in dispute in this case.

74. The second stage is to establish what duties and obligations flow from that credible suspicion of
trafficking. The framework of Article 4 includes the following positive obligations: (i) legislative (ie, the duty
to put in place a legislative and administrative framework to prohibit trafficking, which is not in issue in this
case); (ii) operational; and (iii) investigative (see SM v Croatia at [306] and VCL at [156]). The operational
and investigative duties are in issue in this case. Ms Knights invokes both duties in different ways to
support her argument. She also suggests the possibility of a restitutionary duty consequent on alleged
breaches of the operational and/or investigative duties. We shall take each in turn.

(1) Operational duties

75. Rantsev emphasises that the duty to take “appropriate measures” to protect victims or potential victims
must be interpreted “in a way which does not impose an impossible or disproportionate burden on the
authorities” ([287]). VCL repeats this and refers at [154] to the need to bear in mind the difficulties involved
in policing modern societies and the “operational choices which must be made in terms of priorities and
resources”.

76. The two aspects of the duty to take operational measures are (a) to protect the victim of trafficking
from further harm (the protective duty); and (b) to facilitate the victim's physical, psychological and social
recovery (the recovery duty) (see VCL at [159]). We begin with the protective duty.

The protective duty

77. We have noted SIAC's finding at [92] of its judgment that there is an arguable case that, in the period
leading up to Ms Begum's departure for Syria in February 2015, the police, school and local authority failed
to take reasonable preventative measures. At [224] SIAC put it in this way:

“It is also arguable, in the Commission's judgment, that there were State failures, and possible violations of
the corollary protective duty, between December 2014 and February 2015. There is force in the submission
that these could be investigated.”


-----

78. Two obstacles lie in the way of the case which Ms Knights sought to build on this foundation. The first
is that SIAC's findings at [92] and [224] of its judgment only go so far as to say that there was an arguable
breach of the protective duty by organs of the State. The second is the passage of time between February
2015 and February 2019 and the lack of any causal link between the possible breaches of the protective
duty in 2015 and the deprivation decision in 2019. In our judgment, these obstacles are fatal to the
argument that the UK authorities owed Ms Begum a protective duty under Article 4 at the time of the
deprivation decision. More relevantly, it cannot be said that the possibility of the existence of such a duty
should have been taken into account: there was nothing in this regard for the Secretary of State to take into
account, let alone something obviously material.

The recovery duty

79. The recovery duty includes an obligation to assist victims in their physical, psychological and social
recovery, and to provide support and treatment for the consequences of past ill-treatment. It has, to date,
been held to arise only in cases when the victim is present within the State's jurisdiction: see for example
_VCL, which examined extensively the UK's domestic provisions to support and protect victims of trafficking._
We were shown no Strasbourg or domestic decision supporting the proposition that a State has an
obligation, as part of the recovery duty, to repatriate a former victim of trafficking if they have been
trafficked abroad, in order that they can receive support and protection within the jurisdiction. Ms Knights
did not argue that there was any obligation to repatriate the appellant. Further, she recognised that the
appellant was outside the jurisdiction so there was no question of her now being provided with any support
or treatment.  Therefore, the recovery duty does not assist in this case: there was nothing arising as part
of that duty which might have been material to the decision whether or not to deprive Ms Begum of her
citizenship.

80. A repatriation obligation is also said to arise under Article 16 of ECAT, which provides:

“(1) The Party of which a victim is a national or in which that person had the right of permanent residence
at the time of entry into the territory of the receiving party shall, with due regard for his or her rights, safety
and dignity, facilitate and accept, his or her return without undue or unreasonable delay.”

81. It is not argued on behalf of Ms Begum that Article 16 of ECAT “fleshes out” the content of Article 4. As
SIAC noted, such a submission would inevitably have failed in view of the decision of the Supreme Court in
_R (AB) v Secretary of State for Justice [2021] UKSC 28, [2022] AC 487. Rather, it is said that the Home_
Office has adopted Article 16 as a matter of policy. As to that, we agree with SIAC that general statements
to the effect that the Government offers assistance to victims of **_modern slavery are insufficient to_**
constitute an obstacle to the exercise of the s 40 power or to place the Secretary of State in breach of his
own guidance in deciding to exercise that power instead of repatriating. Article 16 does not therefore
assist Ms Begum in establishing any failure on the part of the Secretary of State to take into account
something obviously material to the deprivation decision.

The non-punishment principle

82. It is recognised that the prosecution of victims or potential victims of trafficking may in certain
circumstances be at odds with the protective duty (VCL at [159]).  Ms Knights relied, as she did before
SIAC, on Article 26 of ECAT. As SIAC noted, the UN Special Rapporteur on trafficking in persons,
Professor Siobhán Mullally, has expressed the opinion that the non-punishment principle set out in Article
26 is broad enough to include non-repatriation. Ms Knights argued that the deprivation of citizenship was
at least arguably a breach of the non-punishment principle, and that possibility should have been taken into
account by the Secretary of State. On this we take the same view as SIAC. There is no authority either of
a domestic court or of the Strasbourg court which has held that the non-punishment principle extends
beyond criminal prosecutions (which is the context in which it was discussed in VCL, see [160] and [161])
to a decision to deprive an individual of her citizenship, or to a refusal to repatriate her. Applying the
principle laid down by the Supreme Court in _AB, we cannot be confident that, were the issue to come_
before the Strasbourg court, it would uphold Professor Mullally's view. The conditions established at [59] of
the judgment of Lord Reed PSC in _AB are not satisfied and it would go well beyond “incremental_
development” of the principles established by the Strasbourg court to hold otherwise It follows that in our


-----

judgment the non-punishment principle was not engaged; there was nothing which the Secretary of State
was required to take into account in this regard.

(2) The investigative obligation

83. SIAC suggested that the alleged violations of the protective duty could be investigated ([224]) but
made no findings about any possible breach of a duty to investigate arising under Article 4. No material
relating to any investigations was put before SIAC or us. We do not know whether efforts have been made
to investigate the circumstances in which Ms Begum and her friends travelled to Syria in 2015.  Because
there is no finding by SIAC of an actual breach of the investigative obligation, this submission is based on
the asserted possibility of breach.

84. The Article 4 cases cited to us all concerned investigation of possible criminal offences. Cases relating
to the investigative duty under other Articles of the ECHR, such as those concerning the obligation under
Article 2 to investigate deaths in State custody, are of little assistance. There are cases where it is
reasonable to expect the trafficked person to be present in the UK to assist in the investigation. _MS_
_(Pakistan) is an example, but on very different facts from those arising on this appeal. In that case, MS_
alleged that he was the victim of trafficking; his claim for asylum was refused; on appeal the Upper Tribunal
(“UT”) decided that he was indeed a victim of trafficking; once brought to the attention of police, he was
removed from the risk of further exploitation, while the UT held that he would not be at risk of re-trafficking
if returned to Pakistan; the UT allowed his appeal against a decision to remove him. The Court of Appeal
reversed the UT decision, but the Supreme Court held that an effective investigation was required and
could not take place if MS were to be removed to Pakistan, so the decision of the UT was restored. Unlike
Ms Begum, MS was within the jurisdiction, and his challenge was to the Secretary of State's decision to
remove him; further, the UT had made a clear finding that he had been the victim of trafficking; and yet
further, there was no national security element in the case. The decision provides no support for Ms
Knights' submissions.

85. Ms Begum's argument is that any investigation could only be effective if she were present in the UK to
assist in it. She says this gives rise to an obligation on the Secretary of State at least to consider this factor
before making an order for deprivation. We cannot accept this for a number of reasons. Firstly, it seems to
us to be tantamount to an obligation to repatriate. But we have already concluded there is no such
obligation, at least not as part of the operational duty. It would be surprising if such a duty existed as part
of the investigative duty even though there was no operational duty to procure the same outcome.
Secondly, and in any event, an obligation to repatriate the appellant would be inconsistent with _Begum_
_UKSC_ in which the Supreme Court held that the Secretary of State was not required to give Ms Begum
leave to enter the UK in order to present her appeal to SIAC: if there was no duty to allow her to enter to
pursue her own case, it would be surprising if there were a duty to allow her entry to assist in the
investigation of offences allegedly committed by other people in 2015, or even to consider doing so.
Thirdly, the obligation on the State is only to take reasonable steps to investigate (SM v Croatia at [316]). It
is not arguable that reasonable steps extend to repatriating someone who is assessed to pose a threat to
national security.

86. Accordingly, we are not persuaded that there was any obligation on the Secretary of State to take into
account the possibility that there might be a duty to investigate the circumstances of Ms Begum's
trafficking, alternatively, to consider whether any such investigation as might be required would be
enhanced by her presence in this country.

(3) A possible restitutionary duty

87. If a breach of an ECHR obligation is established, the State is under an obligation to restore the
individual to the position they would have been in if the breach had not occurred. The ECtHR said in
_Papamichalopoulos v Greece (1996) 21 EHRR 439 at [34] that a violation “imposes on the respondent_
State a legal obligation to put an end to the breach and make reparation for its consequences in such a
way as to restore as far as possible the situation existing before the breach”. This is sometimes described
as a “restitutionary duty”.


-----

88. There is no established breach in this case. A possible or arguable breach is insufficient to trigger the
restitutionary duty. In any event, even if a breach were established, the ECtHR has given States latitude in
determining how reparation is to be assessed. The Strasbourg court has held repeatedly that it is for the
State concerned to choose the means to be used in its domestic legal order in order to discharge its legal
obligation.

89. Further, the asserted breach of the duty to protect occurred in 2015, four years before the deprivation
decision and before many of the events which gave rise to it. We were shown no authority to support the
proposition that a restitutionary duty consequent on the breach of the protective duty could exist so long
after the event giving rise to that breach, and despite supervening events which supported the adverse
national security assessment.

90. We conclude that there was no restitutionary duty owed to Ms Begum such as to trigger an obligation
on the part of the Secretary of State to consider it.

_Summary on Article 4_

91. Ms Begum was outside the jurisdiction and outside the control of the UK Government when the
decision was made to deprive her of her citizenship. There was no obligation under the ECHR to repatriate
her in 2015 or 2019 and there is none now. Further, the focus of a deprivation decision on the grounds of
national security must be the assessment of risk. We do not accept that an individual who is assessed as
presenting a risk to national security must be repatriated, or even that the Secretary of State is required to
consider her repatriation, in order to meet obligations which might be owed under the protective duty, the
recovery duty or the investigative duty (noting that any putative investigation would concern offences
committed by other people, or State failures to protect her, four years earlier). Further, we do not accept
that the non-punishment principle extends to a decision to deprive her of her citizenship on national
security grounds or that a restitutionary duty exists even arguably on these facts.

92. We are not persuaded that there is any substance to any of Ms Knights various arguments alleging
possible Article 4 breaches, whether considered separately or together. Adopting the approach identified
above, Article 4 gave rise to no obviously material consideration for the Secretary of State to consider in
the context of the s 40 decision. Indeed, even adopting the approach suggested by Ms Knights, we would
not have concluded that there had been any material failure. On the basis of the open arguments, Ground
1 fails.

**Ground 2: Common Law**

93. We turn next to Ms Knights' submission that, as a matter of common law, the Secretary of State should
have taken account of the fact that Ms Begum was a potential victim of trafficking for the purposes of
sexual exploitation. Ms Knights submitted that the Secretary of State was required to take all relevant
considerations into account, here accepting the threshold test of what is “obviously material” (see the
discussion above). However, in applying that test, she argued that it was necessary to have in mind the
particularly sensitive circumstances of this case, and the need for decisions to show by their reasoning that
“every factor which might tell in favour of the applicant has been properly taken into account” (R (YH) v
_Secretary of State for the Home Department [2010] EWCA Civ 116,_ _[[2010] 4 All ER 448 at [24], per](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
Carnwath LJ) as well as the fact that Ms Begum was a child when she was trafficked (a factor given
particular emphasis in _R v Verna (Joseph) [2017] EWCA Crim 36, [2017] 1 WLR 3153 at [21]-[22]). We_
agree that the “obviously material” test is context sensitive. No further gloss is required.

94. The ministerial submission and its annexes did not discuss Article 4 ECHR or ECAT, or the possibility
that Ms Begum might have been trafficked for the purposes of sexual exploitation, in terms. However, the
material before the Secretary of State included press articles referring to “jihadi brides”, a phrase much in
use at the time, which incorporates the idea of young women being groomed by ISIL for the purpose of
marriage and sexual exploitation. The material before the Secretary of State powerfully expressed the
view that people who were children when they went to align with the ISIL caliphate should be considered
first and foremost as victims. There is no material distinction to be drawn for present purposes between
such individuals as victims of radicalisation manipulation or enticement by agents or supporters of ISIL


-----

generally, and such individuals as victims of such manipulation or enticement for the purposes of sexual
exploitation.  In any event, as SIAC pointed out (at [257]), the Secretary of State was not obliged to view
Ms Begum's case “through the lens of trafficking”. By approving the ministerial submission, taken together
with its annexes and the minors' policy, the Secretary of State accepted the view that Ms Begum's
“victimhood”, to the extent that it was a point in her favour, was not of such weight as to affect his
conclusion that she posed a threat to national security such that it would be conducive to the public good to
deprive her of citizenship and thus the right to return to the UK.

95. The Security Service kept the assessment under review: the amended second open National Security
Statement dated 17 October 2022 maintains the conclusion that she was a risk to national security. We
are satisfied, as was SIAC, that the point remained in clear view.

96. The skeleton argument for Ms Begum challenges the finding by SIAC at [285] that the intelligence
services were well placed to make experiential judgments on matters such as voluntariness and that “these
issues fall within their institutional and constitutional competence”, with the consequence being that SIAC
deferred to their assessment. It was submitted (original emphasis):

“That is to erroneously conflate an assessment of why a victim of trafficking may have done or said what
they did, with the assessment of national security risk that flows from that. Why an individual travelled to
Syria or remained in ISIL-controlled territory and whether such conduct should be regarded as “voluntary”
is clearly relevant to their national security risk. It is, however, a logically prior question, and from the
OPEN evidence there was no suggestion that in relation to a victim of trafficking, it was a matter on which
the security services had expertise.”

97. In our judgment, SIAC was entitled to find, as the specialist tribunal established by Parliament, that the
issue of whether and to what extent Ms Begum's travel to Syria had been voluntary was within the
expertise of the intelligence agencies advising the Secretary of State. As SIAC said (at [285]), “in the
Commission's experience many national security assessments require an understanding of human nature,
and the context of the present case is terrorism and national security”.

98. We also accept the submission for the Secretary of State that voluntariness is not a binary question.
Ms Begum may well have been influenced and manipulated by others but still have made a calculated
decision to travel to Syria and align with ISIL. The skeleton argument on her behalf rightly accepts that the
degree of voluntariness was “clearly relevant to the question of national security risk”. The assessment of
the national security risk was, as _Begum UKSC_ made clear at [56]-[57], a question of evaluation and
judgment entrusted by Parliament to the Secretary of State.

99. We conclude that there was no material shortcoming on the part of the Secretary of State arising out of
any failure to take account of the possibility that Ms Begum had been trafficked for the specific purpose of
sexual exploitation. He was aware of the circumstances of her departure to Syria, and the likelihood that
she was a child victim of others who wished to exploit her for sexual or extremist reasons. He thus had
regard, in substance, to the points made on behalf of Ms Begum. On the basis of the open arguments, we
reject Ground 2.

**Ground 3: de facto statelessness**

100. Section 40(4) prohibited the Secretary of State from making a deprivation order if he was satisfied
that the order would make a person stateless. It was common ground before us, as it was before the
Supreme Court in Pham v Secretary of State for Home Department _[2015] UKSC 19, [2015] 1 WLR 1591,_
that the term “stateless” in s 40(4) means de jure statelessness. This is a binary question, as Pham itself
illustrates.

101. Mr Squires KC, accepting that the appellant was not _de jure_ stateless at the time of the decision,
nonetheless argued that in the present case the Secretary of State failed to take account of the fact that
the deprivation order would render Ms Begum de facto stateless.

102. It is not necessary to decide what might be difficult questions about whether the concept of “de facto
statelessness” is established in international law. The point in layperson's language is that Ms Begum had


-----

nowhere else to go. Until her 21[st] birthday in 2021 she had Bangladeshi citizenship by descent but there
was no realistic possibility of her being able or permitted to enter that country. The appendix to the
ministerial submission made this clear, though in the context of whether she was at risk of treatment
contrary to ECHR Article 2 or Article 3. As SIAC found at [302]-[305], this was sufficient to bring the issue
to the attention of the Secretary of State, if he did not know it already. Despite knowing that she had
nowhere else to go, in all practicality, the Secretary of State nonetheless decided that to deprive her of her
British citizenship on grounds that to do so was conducive to the public good and in the interests of
national security. He took that matter into account. The decision cannot be impugned on the basis that he
did not do so. On the basis of the open arguments applied to the evidence that we have seen in open and
closed, Ground 3 fails.

**Ground 4(a): due process**

103. As set out above, SIAC departed from the decision in Al-Jedda and held that fairness had required
that Ms Begum be given the opportunity to make representations before a deprivation order was made. Ms
Begum seeks to uphold this conclusion, while the Secretary of State challenges it by his Respondent's
Notice.

104. We start with a consideration of the proper approach to statutory construction, asking ourselves
whether Parliament has by necessary implication excluded a right to prior representation. As was stated in
_R (Morgan Grenfell & Co Ltd) v Special Commissioner of Income Tax [2002] UKHL 21, [2003] 1 AC 563 at_

[45], a necessary implication is not the same as a reasonable implication. In R (Black) v Secretary of State
_for Justice_ [2018] UKSC 81, [2018] AC 215 at [36] Baroness Hale stated that a necessary implication is
one which necessarily follows from the express provisions of the statute construed in both their context and
by reference to their purpose. Thus a necessary implication could arise if, without it, a very important
purpose of the legislation would be frustrated.

105. Beyond this, the requirements of common law fairness are not the same in every type of case.
Orders without prior notice are commonly made. To take the example of freezing injunctions, the initial
order is almost invariably made without notice, since prior notice would enable the respondent to conceal
assets or put them beyond the reach of the court and thus pre-emptively frustrate the purpose of the order.
The without notice procedure is to some extent a violation of due process, but on the return date the court
has wide powers to vary or discharge the order. The same applies, for example, to non-molestation orders
in the family courts.

106. What is required depends on the legislative purpose and context. At least a main purpose of s 40(2),
if not the main purpose, is to protect the public from a threat to national security. A requirement to invite
representations prior to a deprivation decision made on national security grounds could frustrate that
purpose. As SIAC itself had said in B4 at [138]:

“The general rule in national security cases is that there is no duty to seek representations before making
the deprivation order. This is because the very act of seeking representations would be contrary to the
national security of the UK: the individual would take immediate steps to return, in the knowledge of what
was about to happen.”

107. SIAC sought to step back from this statement of the general rule. However, in our judgment, the
general rule identified in B4 for national security cases is apt. To notify a person abroad of an intention to
remove their citizenship could obviously act as an encouragement to that person to return to the UK preemptively. Like SIAC, we do not consider the fact that some deprivation decisions involve persons who are
already in the UK, alternatively are made pursuant to s 40(3) for reasons not involving national security,
makes any difference to the basic analysis (see [329] of SIAC's judgment).

108. As to context: s 40(2) confers the power on the Secretary of State to deprive a person of citizenship if
satisfied that to do so would be conducive to the public good. The requirements to be met “before making
an order under this section” are specified in s 40(5). Notice must be served (i) that the Secretary of State
has decided to make a deprivation order, (ii) stating the reasons for that order and (iii) confirming the
individual's right of appeal against that order. In Al-Jedda at [156], SIAC concluded this was “an


-----

exhaustive procedural framework”, impliedly excluding any obligation to invite representations from the
person concerned.

109. In the present case SIAC agreed that s 40(5) contained an exhaustive procedural code, but was not
satisfied that that was sufficient, in and of itself, to exclude a right of representation. In the light of Bank
_Mellat_ that might be so if s 40 were to be construed in isolation. But to do so underrates the distinctive
nature of an appeal to SIAC.

110. Section 40 must be read alongside s 2B SIACA 1997. In Al-Jedda at [155], this provision was said to
give rise to a full merits right of appeal which rendered any duty to consult before the decision
unnecessary. Begum UKSC lays down that the appeal to SIAC is not a full merits appeal. However, what
is clear is that s 2B SIACA 1997 affords an appellate merits review and is not merely a judicial review
exercise. So much can be seen from Begum UKSC itself (at [65] and [69]) and U3.

111. In _U3_ (handed down since SIAC decided this appeal), this court provided a clear explanation of
SIAC's function on appeal:

“171. The procedure for deprivation is inherently unfair, on two accounts: the appellant has no input into
the decision and the decision is based in part on material which she never sees… Those factors suggest
that the appeal which Parliament has given an appellant is a forum in which such decision should be
examined as meticulously as possible… SIAC has an important role in scrutinising all that evidence
independently, with the invaluable help of the Special Advocates, who press for as much disclosure to the
appellant as possible, and who rigorously test the CLOSED evidence. In the course of a hearing, SIAC
sees more intelligence materials by the Secretary of State will have done: she will normally only see a
ministerial submission perhaps with some annexes… SIAC's reference in this case to its 'powerful
microscope'… was apposite. Moreover, SIAC will also have a potentially wide range of evidence from the
appellant (as in this case), which will not have been seen by the Secretary of State, either. The appeal may
well be the appellant's first and only opportunity to influence a decision-maker. SIAC is entitled to expect
that by the time of the appeal it will have been given an updated national security statement which takes on
board the evidence which the appellant has served for the purposes the appeal. It is also entitled to expect
that the Secretary of State will make available a national security witness who is immersed in the detail of
the case, and who is ready to be cross-examined by the OPEN representatives and by the Special
Advocates.”

112. The existence and distinctive nature of this right of appeal, and the risk of pre-emptive action by the
appellant if prior notice is given, remain in our view compelling reasons to construe s 40(5) as excluding
the right of prior consultation before a deprivation decision is made on the grounds of national security, as
was held in Al-Jedda.

113. There is therefore merit in the Secretary of State's Respondent's Notice on this point. On the basis of
the open arguments, we agree that SIAC fell into error in concluding that Ms Begum was entitled, as a
matter of procedural fairness, to the opportunity to make representations before the Secretary of State took
the deprivation decision.

114. In the event, it makes no difference to the outcome, because, as set out below, we agree with SIAC
that nothing could have been said which might have made a difference. We turn to the detail of Ms
Begum's challenge to that conclusion.

**Ground 4(b): The Simplex argument**

115. SIAC held that the outcome would not have been any different, even if Ms Begum had been offered
an opportunity to make submissions, either because she would only have been able to put forward basic
facts which were already known to the Secretary of State ([349]) or because, examining the matter at the
date of SIAC's judgment, the outcome would have been the same anyway ([350] and [409]). Mr Squires
challenged these conclusions. First, he argued that Ms Begum could have put forward good reasons for
not being deprived of her citizenship if she had been given that chance. But secondly, he argued that
SIAC was wrong to conclude that the decision would inevitably have been the same anyway; Simplex was


-----

not properly applicable in this case, because (he argued) SIAC had only a limited role as a review court
and it lacked expertise to reach national security assessments; it could not step into the decision-maker's
shoes. In sum, he argued that SIAC should have quashed the decision and remitted the case to the
Secretary of State for further review.

116. Mr Squires further submitted that the asserted error in this case was of a lack of procedural fairness
where a particularly exacting approach to the materiality of the error applied; it was only in cases of “great
rarity” that an error going to procedural fairness could be overlooked (citing Bingham LJ in _R v Chief_
_Constable of Thames Valley Police ex p Cotton_ _[[1990] IRLR 344 at [60] and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W1HS-00000-00&context=1519360)_ _R (Smith) v North Eastern_
_[Derbyshire Primary Care Trust [2006] EWCA Civ 1291, [2006] 1 WLR 3315 at [10]). He argued that Ms](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VG71-DYBP-P3ST-00000-00&context=1519360)_
Begum would and could have made representations about her age and the circumstances in which she
had travelled to Syria in 2015; she might also have been able to make representations about the possibility
of State failure in the terms now forming grounds 1 and 2 of this appeal.

117. Sir James countered that the point had been settled already, against the appellant, in _U3_ at first
instance where Chamberlain J considered the validity of Simplex in the context of an appeal to SIAC, and
concluded as follows (emphasis in original):

“33.  Another consequence of SIAC's specialised constitution and unique procedure is that there may be
cases where a flaw that appears at first sight to be material can be shown not to be. A judge in judicial
review proceedings who identifies a potentially significant flaw may find it difficult, given the more limited
evidential materials available, to conclude that relief can be refused because the flaw is immaterial or the
outcome would inevitably have been the same: see _Simplex_ ...  SIAC's more powerful microscope may
enable it to see more clearly not only the potentially significant flaws but also their evidential content. This
means that it may be better placed than would a judge in judicial review proceedings to conclude, once a
flaw has been identified, that it is not material or that the outcome would inevitably have been the same in
any event. As before, however, the same high test (whether the outcome would inevitably have been the
same) applies.”

118. The Court of Appeal in U3 endorsed this approach at [175] - [177], accepting that it was for SIAC to
test the Secretary of State's assessment without substituting its own view. Some support for that approach
can also be found, in a planning context, in R (Goring-on-Thames Parish Council) v South Oxfordshire DC

_[[2018] EWCA Civ 860, [2018] 1 WLR 5161 at [55].](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5S5Y-MDC1-F0JY-C18F-00000-00&context=1519360)_

119. _Simplex_ was a planning case, where it was held that a factual error had wrongly been taken into
account in reaching the decision in question. The Court of Appeal held that it was not possible to say that
the decision would have been the same if the error had not been made, and the decision was set aside.
The proposition now relied on appears in the judgment of Staughton LJ at p 329:

“… where one of the reasons given for a decision is bad, it can still stand if the court is satisfied that the
decision-making authority would have reached the same conclusion without regard to that reason.”

120. In our judgment, it was well within SIAC's remit to conclude that the deprivation decision would
inevitably have gone against Ms Begum in any event.  As was emphasised in U3 at first instance and on
appeal, SIAC's role is rigorously to test the assessment which underpins the decision under appeal.  If
SIAC finds there has been an error in that assessment (of law or fact), it is for SIAC to consider whether
that error is material in the sense that it might have affected the outcome. In this case, SIAC did not err in
law in considering the _Simplex_ question or reaching the conclusion, on the evidence, that the same
conclusion was inevitable.

121. We have in any event considered the matter for ourselves. We conclude that on all of the evidence
before us, including the closed evidence, the decision would inevitably have been the same.

**Ground 5: The public sector equality duty**

122. Section 149(1) of the EA 2010 provides, so far as relevant:

**“A public authority must, in the exercise of its functions, have due regard to the need to—**


-----

(a) eliminate discrimination, harassment, victimisation and any other conduct that is prohibited by or under
this Act;

…

(c)  foster good relations between persons who share a relevant protected characteristic and persons who
do not share it.”

123. Section 192 provides:

“A person does not contravene this Act only by doing, for the purpose of safeguarding national security,
anything it is proportionate to do for that purpose.”

124. Ms Begum's case is that in taking the decision to deprive her of British citizenship, the Secretary of
State failed to have due regard to whether the exercise of deprivation powers: (i) is disproportionately
applied to British Muslims of certain ethnic minorities (engaging s 149(1)(a)); and/or (ii) impacts
detrimentally upon the relations between members of Muslim communities and others (engaging s
149(1)(c)).

125. The Fourth Witness Statement of Ms Begum's solicitor, Gareth Peirce, contains statistical evidence
showing that deprivation powers have been used almost exclusively against Muslims, mainly of South
Asian, Middle Eastern, and African heritage, and highlights the concerns raised by prominent British
Muslims that the use of deprivation powers has created what is seen as a “second class” category of
British citizenship defined by race and religion. (We observe in passing that these statistics must be treated
with caution, since the deprivation power cannot be used against those who have only British nationality
and would be ineffective against anyone with dual British and Irish citizenship in view of the special rights
of Irish citizens to enter the UK.)

126. So far as the possible detrimental impact on community relations is concerned, the Secretary of State
was advised in the ministerial submission as follows:

“OSCT's current assessment was that “public sentiment is overwhelmingly negative towards BEGUM, with
the general feeling being that she made her decision and now must live with it”… There appears to be little
differentiation between the views of British Muslims and the wider British public on the issue at this time. A
decision to deprive BEGUM of her citizenship (should it become public knowledge), however, would likely
be considered controversial. [It was considered] that this would particularly be so among British Muslims
and Bangladeshi communities, who are likely to view this as a comment on their own nationality status.
This also comes in the context of Windrush and Brexit…”

127. SIAC rejected the PSED ground of challenge. Its primary basis for doing so was that the Secretary of
State could rely on the exemption provided by s 192 of the EA 2010 (see [387]). SIAC also considered the
substantive issues but was not attracted to the arguments on behalf of Ms Begum directed to s 149(1)(a),
observing that “Islamic fundamentalist terrorism is, and remains, a potent threat, and it is hardly surprising
that the section 40 power has been used in that context against Muslims”. SIAC acknowledged that in
relation to deprivation powers the fact that “many right-thinking people in this country's Muslim communities
(and beyond) feel that they are being treated as second-class citizens, and/or that their welcome is
somehow contingent”, raised “important issues” relevant to the PSED. It referred to evidence in closed
which answered the substantive challenges ([398]).

128. Mr Squires submitted that SIAC erred in its interpretation of s 192 of the EA 2010. As a matter of
statutory construction, “doing… anything” within s 192 must refer to the breach of an obligation arising that
Act. In the present case, it was not proportionate to deprive the appellant of her British citizenship without
having due regard to the factors mandated by s 149(1). This was for three reasons:

i) First, any other interpretation is unworkable. This is because proportionality involves a balancing
exercise between an otherwise unlawful act and a legitimate objective (here, national security). If the
“thing” which is required to be proportionate becomes “untethered” from the Act the law becomes
incoherent – it is impossible to know what must be weighed in the balancing exercise against national
security


-----

ii) Second, SIAC's interpretation is inconsistent with authority. Mr Squires relied on the House of Lords
decision in _A v Secretary of State for the Home Department [2004] UKHL 56, [2005] 2 AC 68for the_
proposition that in the context of substantive discrimination claims, “what has to be justified is not the
measure in issue but the difference in treatment between one group and another” ([68]). The interpretation
of s 192 EA 2010 must respect this approach, even if the present concern was not substantive
discrimination but the application of the PSED.

iii) Third, on SIAC's interpretation, the obligations arising under _[EA 2010 could never apply in national](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_
security cases so long as decisions could be shown to be proportionate in some general sense. That, Mr
Squires submitted, could not have been Parliament's intention, given the importance of these provisions,
which are intended to apply unless any of the statutory exceptions are made out.

129. The Secretary of State's primary case is that SIAC erred in finding that the PSED was engaged by
the deprivation decision. Sir James submitted that this was for two reasons, relying on the recent judgment
of the Supreme Court in R (Marouf) v Secretary of State for the Home Department [2023] UKSC 23, [2023]
3 WLR 228, which affirmed the decision of this Court in _R (Turani) v Secretary of State for the Home_
_Department_ _[2021] EWCA Civ 348, [2021] 1 WLR 5793:_

i) First, the mandatory due regard principle contained in s 149(1) EA 2010 is “primarily directed at policy
decisions, not at the application of policy to individual cases” (Marouf, per Lady Rose JSC, at [62]). Where,
as in the present case, a decision is not itself suggested to be discriminatory, but is asserted to have wider
impacts, s 149(1) EA 2010 is not intended to provide a basis for a general challenge.

ii) Second, the “due regard” duties under s 149(1) EA 2010 do not have extraterritorial effect and when the
Secretary of State took the decision to deprive Ms Begum of her citizenship she was in Syria (where she
remains).

130. Sir James submitted that even if the Court found that the PSED was engaged, the s 192 exemption
applies and SIAC's conclusion on this point should be upheld for the reasons it gave.

131. The interpretation of s 192 is a task of statutory construction to which the usual principles apply. The
broad language of the provision leads more naturally to the conclusion reached by SIAC, that “doing…
anything” refers to any exercise of functions or powers, rather than being restricted to the breach of duties
or obligations imposed by the _[EA 2010. As Mr Squires accepted during the hearing, to achieve the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_
interpretation he advanced required the Court to read additional words into the provision. Instead, the
ordinary and natural meaning of the words is the creation of a general exemption from the provisions of the
_[EA 2010 for anything done for the purpose of safeguarding national security.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_

132. The words of s 192 must also be read in their wider statutory context. The provision appears in a
group of sections under the heading “General Exceptions”. There is no suggestion that the national
[security exemption does not apply to EA 2010 as a whole.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)

133. As SIAC observed, while s 192 refers to “doing”, a breach of the duty arising under s 149 is a failure
to do, namely a failure to have due regard. This reinforces SIAC's conclusion at [390] that the word
[“anything” in s 192 is not confined to the breach of a duty arising under any provision of the EA 2010,but](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
rather to whatever is being done on the facts of the particular case.

134. The judgment of the House of Lords in _A v Secretary of State_ was concerned with the antidiscrimination provision under Article 14 of the ECHR and related to substantive discrimination. The case
was decided before the _[EA 2010 was enacted, and it did not consider any equivalent prior equality or](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_
discrimination provisions. It does not provide assistance on how s 192 ought to be interpreted.

135. SIAC was correct to hold that that the s 192 exemption applied on the facts of this case and to reject
Ms Begum's interpretation of this provision.

136. Mr Squires further submitted that even if s 192 applied, it required an analysis of whether the
deprivation decision was proportionate by reference to “the factors mandated by the PSED”, rather than
whether it was proportionate in a more general sense. We do not accept that a separate proportionality


-----

analysis of this kind was required. In any event SIAC found that the s 40 power had been exercised in a
proportionate manner and we agree with them.

137. SIAC was therefore right to uphold the submission that the PSED was excluded by s 192. This is a
conclusion reached on the basis of the open arguments. This makes it unnecessary to consider whether
the Secretary of State could also rely on the presumption against extra-territorial effect dealt with in Marouf,
and also unnecessary to consider Mr Squires' submissions on the substantive issues under s 149(1).

**Conclusion**

138. Deprivation decisions often have severe consequences (as demonstrated in the U3 case where the
decision resulted in the permanent separation of a mother from her children). It could be argued that the
decision in Ms Begum's case was harsh; it could also be argued that Ms Begum is the author of her own
misfortune. But it is not for this court to agree or disagree with either point of view. Our only task is to rule
on whether the decision made under s 40 was unlawful. For the reasons set out above, and the further
reasons given in our closed judgment, we conclude that it was not unlawful. Ms Begum's appeal from the
decision of SIAC is accordingly dismissed.

**Postscript**

139. The Court sent the draft open and closed judgments to the Government Legal Department and the
Special Advocates in late December 2023 (following the procedure set out at CPR 82.17(1) explained by
CPR 82.17.1). A further closed hearing took place on 2 February 2024, following submissions from the
Special Advocates, to determine which parts of the draft closed judgment could be put into open. The
parts of the closed judgment which the Secretary of State conceded, or the Court ruled, could properly be
put in open are set out in the Annex to this open judgment.

**Annex:**

One closed judgment was given by Lady Justice Whipple. Lord Justice Bean and the Lady Chief Justice,
Baroness Carr of Walton-on-the-Hill, agreed with it.

**“Introduction**

[…]

Although I have come to the conclusion, for reasons set out below, that SIAC did make some errors of law
in the closed judgment, I am satisfied that none of those errors was material to the outcome.

The Special Advocates' closed Ground 6 is a new ground, not raised before us in quite the form in which it
came before SIAC (although it has elements of former Grounds […] as they were before SIAC). In the
event, I find no merit in that ground.

SIAC's conclusion that this appeal must be dismissed, based both on the open and the closed material,
was in my judgment correct. I agree that the Secretary of State's decision to deprive the appellant of her
citizenship was not unlawful.

[…]

**Ground 4: procedural fairness […]**

[…]

The Special Advocates' points in support of ground 4(b), taken alone or in combination with the appellant's
open case, are insufficient to lead to success on that ground, even if the duty to give notice existed in law
(which it does not: see the CoA open judgment). _Simplex would have applied and led to the same_
conclusion, inevitably.

**Ground 5: PSED**

_SIAC_


-----

In its open judgment, SIAC accepted that the Secretary of State was required to have due regard to the
way in which deprivation decisions could impact Muslim communities and it found nothing in open to
indicate that the Secretary of State had addressed his mind to that issue ([397] of the open judgment) but
held on the basis of closed material that the matters required by the PSED were properly considered ([398]
of the open judgment).

In its closed judgment, SIAC observed that the ministerial submission did address community relations and
by that means the Secretary of State did have due regard to the PSED for the purposes of section
149(12)(c) of the Equality Act 2010 (see […] of the closed judgment).

_Submissions_

In the open grounds of appeal, the appellant challenged SIAC's conclusion in relation to the PSED, arguing
that the issue of how deprivation practices impact on community relations should be addressed in the open
judgment and not the closed judgment. It was also submitted that the Secretary of State's original
argument, that there was no obligation to consider the PSED because no equality issues arose anyway,
was inconsistent with SIAC's conclusion that the Secretary of State did, in fact, have due regard to the
PSED (see the appellant's open skeleton at [83.1]-[83.2]).

The Special Advocates sought to advance these challenges in closed. They invited this Court to have
particular regard to the appellant's wider open points going to the discriminatory effect of this decision (see,
for example, the points made at [68] of the appellant's open skeleton, emphasising the disproportionate
application of the deprivation power to British Muslims or those of particular ethnic minority backgrounds,
and the detrimental impact of the deprivation power on relations between members of the Muslim and
other minority ethnic communities), those propositions being supported by extensive evidence which was
before SIAC.

The Special Advocates criticised the general level of the Secretary of State's attention to these matters
arguing that the regard which was had to community relations was insufficient to meet the statutory
requirement of “due regard”.

Sir James resisted this challenge arguing that the Secretary of State did have due regard to the PSED and
in particular to the likely impact of this decision on community relations. He relied not only on SIAC's
conclusions in the open and closed judgments, but also on the […] paragraphs of the ministerial
submission put before the Secretary of State which addressed community relations in terms:

a. […] that submission […] noted, amongst other things, that the publication of an interview with the
appellant on 14 February 2019 had already attracted significant attention; it confirmed that the local
PREVENT coordinator was monitoring community networks […]

b. […] the submission recorded the current assessment that public sentiment was overwhelmingly
negative towards the appellant with the general feeling being that she had made her decision in travelling
to Syria and must now live with it. These points were gisted in the open summary of the submission.

[…]

_Discussion_

The open advocates' points about the desirability of this point being put in open were well made. Since the
date of the hearing, the Secretary of State has agreed with the Special Advocates to disclose openly […] of
the closed judgment (including a citation from […] of the submission) (see letter from Government Legal
Department to the Court dated 13 November 2023). That further disclosure may deal with the point. […].

The Secretary of State is required to have “due regard” to the PSED. This Court has already determined in
its open judgment that the defence in section 192 Equality Act 2010 applies and that it is in consequence
not necessary to consider the issue of “due regard” under section 149 (paragraph [137] of the CoA open
judgment). Even with the fuller view of the evidence in closed, I am not persuaded that SIAC was in error
in its approach or its conclusions at […] of the closed judgment where it held that the Secretary of State did
have due regard to the PSED for the purposes of section 149(1)(c). Paragraph […] and in particular


-----

paragraph […] of the ministerial submission are in my judgment clearly sufficient for that purpose: the
impact on Muslim communities was specifically highlighted.

**Ground 6: the wrong target**

_SIAC_

In its open judgment, SIAC recognised the Secretary of State's obligation to keep the decision under
review by reference to material which came to light after the initial decision was taken. SIAC held that it
was a judgment for those advising the Secretary of State whether to return the case to the Secretary of
State personally for further consideration (paragraphs [43] and [54] of the open judgment). Even though
there was later material that was admissible and relevant, in fact the case never was returned to the
Secretary of State for his personal review (paragraph [132] of the open judgment).

In its closed judgment, SIAC held that there were no rigid lines of demarcation between the factors which
the Secretary of State was competent to consider and those which fell to the Security Service to consider.
Issues relating to the voluntariness of the appellant's travel were part of the national security assessment
which was properly undertaken by the Security Service […]. The closed national security statements
prepared by the Security Service, which took account of post-decision evidence and kept that decision
under review up to the date of the hearing before SIAC, contained a series of value judgments […]
(paragraphs […] of the closed judgment). SIAC […] held that the assessments contained in the closed
national security assessments were rational (paragraphs […] of the closed judgment) and should be upheld
(paragraphs […] of the closed judgment).

_Submissions_

The Special Advocates raise what they say is properly a challenge to be brought in closed, not open,
because they say that it is only with full sight of the closed material that the problem becomes apparent.
The problem, they say, is this: the decision whether to deprive is one for the Secretary of State, informed
but not determined by the national security assessment (in support of which reliance is placed on the
Secretary of State's own witnesses – see SIAC's record of Mr Larkin's evidence at [150] of the open
judgment and Witness E's evidence at [158] of the open judgment); however, in this case, the Security
Service never put the case back to the Secretary of State for his review […]. The fact that the appellant
was a minor who had been radicalised (so that her travel abroad was not entirely voluntary) meant that it
was particularly important that the Secretary of State reviewed her case. Paragraph 19 of the minors'
policy (dealing with cases where a person had travelled abroad as a minor but had now reached the age of
majority) highlighted the complexity of these sorts of cases and drew a distinction between the national
security assessment and the assessment of other, non-national security factors […]. There were factors
here which went outside the narrow national security case. The Security Service lacked the institutional
competence and democratic accountability to consider this evidence. SIAC erred in accepting the analysis
and reasons set out in the two closed national security statements because the Security Service was the
“wrong target”; it was the Secretary of State who should have been responsible for reviewing the totality of
the evidence to determine whether deprivation remained appropriate.

The Special Advocates summarised the post-decision […] material which they argued was non-national
security in character (and lay outside the institutional competence of the Security Service to assess) […].

The Secretary of State advanced a number of arguments in response. First, he submitted that this was an
open point of law which did not properly arise as part of the closed case at all. Secondly, he submitted that
there could be no criticism in the approach to the decision made on 19 February 2019, given that it was the
Secretary of State who made that decision. After that point, those advising the Secretary of State were
required to keep the basis for the deprivation decision under review and to refer the matter back to the
Secretary of State only if the appeal process generated evidence which undermined or materially altered
the original national security assessment (citing U3 v. Secretary of State for the Home Department _[2023]_
_EWCA Civ 811 at [95], which drew on_ _B4 v. Secretary of State for the Home Department Appeal No_
SC/159/2028 at [18] and _U3 at first instance, SC/153/2018 and SC/153/2021 at [38]; and noting that the_
same point was made by SIAC in this case at paragraphs [43] of its open judgment which is not appealed).


-----

In this case, the post-judgment material did not undermine or materially alter the original security
assessment […]. There was no basis for suggesting that the matter should have been referred back to the
Secretary of State. […] there was in any event no distinction to be drawn between national security factors
and non-national security factors; instead, a holistic assessment of all available information was required,
first in order to determine whether deprivation was conducive to the public good and, second, if that
decision had already been made, as to whether new evidence undermined or materially altered the original
assessment. The Security Service were institutionally competent to keep the original decision under
review and SIAC was correct so to conclude ([…] of the closed judgment) and paragraph 19 of the minors'
policy did not require any different approach. Further, […] the various factors set out […] [in] the Special
Advocates' skeleton were all properly taken into account by the Security Service, with the involvement of
the Home Office throughout the preparation for the appeal to SIAC. The rationality of that decision
(including its maintenance up to the time of the appeal in SIAC) was accepted by SIAC in the closed
judgment which was further confirmation of the Secretary of State's position that the original assessment
was correct. For all those reasons, the Special Advocates were wrong to suggest that SIAC had focussed
on the “wrong target”.

_Discussion_

The challenge has been raised in closed and, in the absence of any concession by the Secretary of State
that the arguments can be put in open, the point must remain in closed at least for the moment. The
Special Advocates were entitled to raise this point. They can reasonably assert that this ground of
challenge, even if notionally available to the open legal team, only really emerged with clear sight of the

[…] evidence and the closed national security statements dealing with it. Clear sight of the evidence is not,
of course, possible for the appellant's open legal team. The Secretary of State should consider, however,
whether this part of our closed judgment can be put in open in whole or in part.

I do not consider that there has been any error of law by SIAC. The post-decision evidence, taken together
and at its highest, did not require the matter to be referred back to the Secretary of State. […] The
evidence as a whole does support the original assessment. The threshold for referral back to the
Secretary of State was not met (applying U3 at first instance and on appeal, and B4). […]

Further, I accept Sir James' submission that there is no sharp dividing line between national security
factors on the one hand and non-national security factors on the other. The various factors which are
taken into account in reaching a decision (or keeping it under review) cannot be separated in that way (and
SIAC was correct so to decide, see […] of the closed judgment). Section 40 requires an assessment to be
made of whether deprivation is conducive to the public good (which assessment was in this case made by
the Secretary of State, on advice from officials, on 19 February 2019); and that decision must be subject to
ongoing review, requiring referral back to the Secretary of State if the original decision is undermined or
materially altered by post-decision evidence.

I am satisfied that the Security Service possesses the required skill and expertise to keep the matter under
review in this way. Paragraph 19 of the minors' policy does not suggest otherwise, when given a fair
reading in context, and recognising that the assessment is in reality likely to involve multiple agencies and
individuals. I would accept that the ongoing review must itself be holistic, taking account of all relevant
factors and post-decision evidence, including evidence which relates to the reasons for the person having
left the UK to join ISIL and any lack of volition in doing so. […] the Security Service was alive to such
matters and to the fact that the appellant was a minor when she travelled to Syria, and was well aware that
issues such as lack of voluntariness and immaturity were important in the overall assessment of her case.

If there were any doubt about the Security Service's competence to keep the decision under review, the
Home Office's involvement throughout the period after the decision until the appeal to SIAC resolves that
doubt in the Secretary of State's favour. If the Home Office had considered that the matter should be
referred back to the Secretary of State, the Home Office (or its officials) would doubtless have said so.

The entirety of the pre- and post-decision material was anyway put before SIAC as part of the appeal
process. If SIAC considered that the decision was no longer justified, it would have said so. SIAC
considered the various points listed at paragraph [ ] of the Special Advocates' skeleton [ ] SIAC's view


-----

was that the Security Service's assessment, maintained in the closed national security statements, was
rational and should be upheld. I agree with that view. Further and in any event, I am not persuaded that
any of these pieces of information are particularly significant taken individually or together, nor that they
were overlooked in the ongoing review.

I reject ground 6.”

**End of Document**


-----

