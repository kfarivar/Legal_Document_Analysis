# R (on the application of DS) v Secretary of State for the Home Department

 [2019] All ER (D) 109 (Nov)

[2019] EWHC 3046 (Admin)

Queen's Bench Division, Administrative Court (London)

Kerr J

15 November 2019

**Immigration – Trafficking people for exploitation – Reconsideration of negative decision**
Abstract

_The defendant Secretary of State's policy, requiring that a person whose claim to be a victim of human trafficking_
_had been rejected, could only have the decision reconsidered if one of a class of bodies interceded with_
_government on the person's behalf, was not lawful. The Administrative Court, in allowing the claimant's application_
_for judicial review, held that fact that, however strong the merits of a case for reconsideration, the identity of the_
_requesting person might determine whether the request was considered or ignored, was an unlawful fetter on the_
_discretion to reopen negative decisions._
Digest

The judgment is available at: [2019] EWHC 3046 (Admin)

**Background**

The claimant Albanian national reached the UK and a local authority's social services department referred her to
the National Referral Mechanism (the NRM) as a potential victim of trafficking. A positive 'reasonable grounds'
decision was made, indicating that there were reasonable grounds for believing her to be a victim of trafficking.
However, the defendant Secretary of State did not believe the claimant's account and issued a negative 'conclusive
grounds' decision.

The claimant wrote a pre-action protocol letter to the Secretary of State, demanding the withdraw of the negative
conclusive grounds decision and the taking of a fresh, lawful decision taking into account new evidence which had
not been obtained when the decision had been made. The Secretary of State declined and said that it was open to
request a reconsideration via a first responder or a support provider involved in the case.

In the present judicial review proceedings, the claimant challenged the Secretary of State's policy, Victims of
**_modern slavery – Competent Authority guidance, requiring that a person whose claim to be a victim of human_**
trafficking had been rejected, could only have the decision reconsidered if one of a class of bodies interceded with
government on the person's behalf.

**Issues and decisions**

Whether the policy was lawful.

There was real force in the claimant's proposition, that the Single Competent Authority (the SCA) could not refuse
to consider a reconsideration request at all, merely because it did not come from a first responder or support


-----

provider. The Secretary of State's submission, that the spectre of disruption to the important work of the SCA
provided legal justification for the policy under challenge in the case, if the policy was tainted with the vices of
rigidity, institutional disregard of potentially relevant evidence and unlawful delegation of the state's duty to identify
victims of human trafficking, could not be accepted. Therefore, it had to be considered whether the policy did, in
substance, display those vices (see [59]-[61] of the judgment).

The discretionary power to reopen negative decisions (both at the reasonable grounds stage and the conclusive
grounds stage) was vested in the SCA, according to the process set out in the guidance, explaining the operation of
the NRM. It was not vested in the first responders, nor in the support providers. The policy did entail an abdication
of the state's responsibility to perform the identification duty, in cases where a negative decision needed
reconsidering in the light of relevant new material and the request for reconsideration was made directly to the SCA,
not by a first responder or support provider, but by a victim or victim's friend or relative or representative (see [69],

[72] of the judgment).

The availability of judicial review did not make the policy lawful if it was otherwise unlawful. The evidence indicated
willingness to depart from the policy under direct threat of litigation, but there was no evidence of any broader
willingness on the SCA's part to entertain reconsideration requests outside the policy, other than under threat of
litigation. That was not a surprise because to do so would contradict the terms of the guidance (see [80] of the
judgment).

The real vice lay in the policy itself. On its face, it was rigid and did not admit of exceptions. However strong the
merits of a case for reconsideration, the identity of the requesting person might determine whether the request was
considered or ignored. That was an unlawful fetter on the discretion to reopen negative decisions. Accordingly, the
reconsideration policy under challenge was not lawful and the claim succeeded (see [83]-[85] of the judgment).

Shu Shin Luh (instructed by Deighton Pierce Glynn Solicitors) for the claimant.

William Irwin (instructed by the Government Legal Department) for the Secretary of State.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

