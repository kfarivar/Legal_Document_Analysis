# R (on the application of T) v Secretary of State for the Home Department

_[[2024] EWHC 640 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6BMR-N0X3-RVTK-43JK-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 22/03/2024**

# Catchwords & Digest

**IMMIGRATION - MODERN SLAVERY – EXPLOITATION**

The Administrative Court dismissed the claimant’s action to challenge the defendant Secretary of State’s
decision that there were no reasonable grounds to conclude that he was a victim of modern slavery. The claimant,
an Albanian national, had been referred to the National Referral Mechanism by Home Office Immigration
enforcement based on **_modern slavery in Albania following the refusal of his asylum claim in the UK. The_**
Immigration Enforcement Competent Authority (IECA) had made a negative reasonable grounds decision. The
IECA had rejected that the claimant had been recruited for ‘exploitation’ purposes, whether in the form of forced
labour or forced criminality despite accepting the claimant’s factual account of working as a construction worker in
Albania. Further, while two of the three elements of the **_modern slavery definition had been made out to the_**
reasonable grounds standard, the third element of the **_modern slavery definition had not been met. It fell to be_**
determined whether the IECA had erred in law in its assessment that the claimant was not recruited for purposes of
exploitation. The court held that it was correctly concluded, to the reasonable grounds standard: (a) that the
claimant had been recruited at the time he was asked to work on a building site six months before he was asked to
supply drugs; and (b) that it could not therefore have been the employer’s purpose at the time of the act of
recruitment to exploit the claimant. Accordingly, the Secretary of State’s decision that the ‘purposes of exploitation’
definition had not been met was not irrational.

# Cases considered by this case


MN v Secretary of State for the Home Department; IXU v Secretary of State for the
Home Department (AIRE Centre and another intervening)

_[[2020] EWCA Civ 1746, [2021] 1 WLR 1956, [2020] All ER (D) 128 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6233-WXB3-GXFD-81YV-00000-00&context=1519360)_
Applied

**End of Document**


21/12/2020

CACivD


-----

