# R v Omorie Tevon-Te Nixon [2021] EWCA Crim 575

CA, CRIMINAL DIVISION

202100424 A2

Bean LJ, Goose J, HHJ Tayton

Tuesday, 30 March 2021

30/03/2021

JUDGMENTLORD JUSTICE BEAN:

1 We have before us two applications by the Attorney General and on application by a defendant for permission to
appeal against sentence. The three applications relate to sentences passed by HHJ David Evans in the Crown

Court at Exeter on two defendants, Omorie Tevon‑Te Nixon and Itman Ismail.

2 During 2018 and 2019 Ms Ismail worked for an organisation called Heartwood Care Group, which provides
support to those who have been or are within the care system. She was the key worker for Mr Nixon. In the spring
of 2019 she began an intimate relationship with him. She was no longer his key worker by that time.

3 In December 2019 she went on sick leave from her employment. By this time, Mr Nixon was involved in the
supply of drugs within Devon and Cornwall in furtherance of a county lines operation. As part of that operation, he
used a number of graft phones and made regular trips by car from London to Devon in order to deal in heroin and
crack cocaine. That operation also involved the use of four young boys. The offenders arranged for the boys to be

transported from London to the South‑West to act as runners. Ms Ismail was instrumental in arranging

accommodation for the boys to run from. She booked and drove hire cars to transport the boys to and from
London. However, it was plain that she was assisting Nixon rather than the other way round.

4 On January 2020 both of them travelled to the West County on a National Express coach. They did so with three
of the four young boys to whom we have referred, the youngest of whom was [an age]. A week later, Ms Ismail
hired a car in London and she, Mr Nixon and the fourth boy drove to the Plymouth area. A few days later on 22
January 2020 a car, which was being driven badly on the A38 from Cornwall towards Plymouth, was stopped. Ms
Ismail was driving. Mr Nixon was the front seat passenger and among others in the car was the [an age] boy who
had been reported as missing from an address in London on 5 January 2020.

5 The next day police performed a check on an address in Torquay and found another of the boys, also [an age],
who had been reported missing from an address in High Wycombe on 13 January. This property search in Torquay
resulted in the finding of substantial quantities of wrapped heroin and cocaine with a machete and a mobile phone.

The drugs included a package with 32 deal‑sized wraps of heroin and 21 deal‑sized wraps of crack cocaine.

6 The next day the same car which had been stopped on 22 January was again stopped in Torquay by the police.
The two defendants were in the car together with two [an age] boys. Both of the boys were taken into police
custody. The police discovered that each had drugs secreted in his anus. Ms Ismail and Mr Nixon were arrested.
They were released on police bail with conditions not to enter Devon, with which they did not comply. They made a
further trip to Devon on 4 February and the next day after that a new graft phone was set up.


-----

7 On 12 March 2020 they were arrested in London. A search at Mr Nixon's flat led to the discovery of two cling film
wraps: in one of them there were 98 wraps of crack cocaine and four of heroin and in the other 73 wraps of crack
cocaine and 31 of heroin. Two micro mobile phones were also seized. The total weight of all the drugs seized was
79g and the total value given as about £8,000.

8 Ms Ismail had no previous convictions, cautions, warnings or reprimands recorded against her. Mr Nixon, on the
other hand, had significant previous experience of the criminal courts running to 35 previous convictions from 19
prior court appearances. He was not a major league criminal, but his convictions by the time of the index offences,
when he was still only 19, included convictions for possession of knives, handling stolen goods, dwelling house
burglary, perverting the course of justice, dangerous driving, possessing cannabis and a variety of breaches of
court orders. He had been the subject of Detention and Training Orders on three occasions. On 21 March 2019 he

was made subject to a 12‑month suspended prison sentence for breach of a criminal behaviour order and was

subject to that suspended sentence when he committed the index offences.

9 Mr Nixon was charged with conspiracy to supply controlled drugs of Class A between 1 December 2019 and 13
March 2020. Ms Ismail was also charged with that count, pleaded not guilty and that plea was accepted. Each
offender was charged with four counts of what we will call "trafficking", that is to say arranging or facilitating travel of
another person with a view to exploitation contrary to s.2(1) of the Modern Slavery Act 2015. (The fourth of these
counts was not pursued to trial. Each defendant pleaded not guilty to it, those pleas were accepted and we say no
more about it.) The three remaining counts concerned the trafficking of the four boys. We are not mentioning their
names in this judgment, but for the avoidance of doubt their identity is protected by an anonymity order, as it was in
the Crown Court.

10 There was no arraignment of the defendants at the Plea and Trial Preparation Hearing, but we are told and
accept that Mr Nixon indicated at an early stage that he would plead guilty to the drugs conspiracy count. The
learned judge gave him full discount for an early plea, notwithstanding that that plea had not been indicated in the
Magistrates' Court, but we will not go behind the finding of the judge that Nixon was entitled to a full discount on that
charge. The defendants pleaded not guilty to the trafficking counts at a hearing on 25 September 2020. Their case
was adjourned to 1 December 2020 for trial. On the second day of the trial they changed their pleas.

11 In the meantime, Mr Nixon had indicated a plea of guilty in the Magistrates' Court to a further offence; namely,
possession of a mobile phone in prison. He had committed this offence while on remand for the offences charged
in the indictment. He was committed to the Crown Court for sentence in respect of that offence.

12 The judge imposed the following sentences on Nixon. On the charge of conspiracy to supply Class A controlled
drug, he found that the offender was to be sentenced on the basis of a significant role in street dealing or direct
supply to the public. The guideline starting point is four and a half years. He increased that starting point for five
years, made a reduction of a third, to which we have referred, for the plea of guilty, giving three years and four
months. On the three counts of trafficking, where there is no applicable sentencing guideline, he took a starting
point of five years, less ten per cent for the plea of guilty in the course of the trial, giving a figure of four years and
six months. Those two sentences added together would have come to seven years and ten months. He made a
reduction for totality to seven years and then imposed concurrent sentences of seven years' detention in a Young
Offenders' Institution on each charge. Nothing turns on whether these offences should have been dealt with by
consecutive or concurrent sentences. It is the total of seven years which Mr Jarvis for the Attorney General submits
was unduly lenient.

13 On the charge of possession of the mobile phone in prison, the judge quite rightly imposed a consecutive
sentence of nine months. He reached that figure by taking a starting point of 15 months, making a reduction of a
third for the prompt plea of guilty and a further reduction of one month for totality. That sentence is not the subject
of the reference; nor is it suggested on Mr Nixon's behalf that there was anything wrong in that sentence of nine
months' imprisonment consecutively.


-----

14 Ms Ismail was to be sentenced only for the three counts of trafficking. In her case, the judge took a starting
point of four and a half years, less a reduction of ten per cent for the plea. That in round figures resulted in a
sentence of four years.

15 On behalf of the Attorney General, Mr Jarvis submits, dealing first with the drugs charge, that the elevation of
the starting point before discount for plea from the guideline figure of four and a half years to five years was not
enough. Firstly, he submits that conspiracy to supply Class A drugs is generally considered more serious than

simple supply, particularly by contrast with a one‑off supply or a limited series of supplies. Secondly, he submits

that a conspiracy to supply both heroin and crack cocaine is somewhat more serious than a conspiracy to supply
just one of these drugs, although perhaps this is not a major point in the context of these offences. Thirdly, and this
certainly is a significant point, he submits that the courts treat county line supplies of Class A drugs as being a
particularly serious form of the offence.

16 Turning to the trafficking charges and starting with Nixon, Mr Jarvis submits that the six year starting point taken
by the judge was simply too low. He has referred us to a recent decision of this court in the case of _Zakaria_
_Mohammed_ _[[2019] EWCA Crim 1881, to which we shall return later in this judgment. He also draws attention to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XMW-H6Y3-CGXG-02KG-00000-00&context=1519360)_
fact that four children were exploited in the course of this trafficking, the youngest being 15 years old at the time,
and that they were used not only as drug runners, but as drug vessels: that is to say, they had drugs in their
anuses, which poses a particular danger to the drug carrier and is an aggravating factor over and above that of the
exploitation of teenage children simply as drug runners.

17 Mr Jarvis draws attention to the fact that Mr Nixon, though still a young man, has numerous previous

convictions, to which we have referred, and that several attempts at non‑custodial methods of persuading him to

turn away from crime have been tried and failed.

18 So far as Ms Ismail is concerned, Mr Jarvis refers to a finding by the sentencing judge that she was “not an
entirely naive participant” in the trafficking and that she knew at least in general terms what the purpose of these
trips to the West Country with children was. Mr Jarvis submits that in those circumstances the judge's starting point
of four and a half years involved too great a discount from the six years which he held would otherwise have been
the appropriate starting point and the one he adopted for Nixon on these charges.

19 On behalf of Nixon, Mr Lewin urges in mitigation, firstly, his age, only 19 at the time of the offences, but also his
troubled upbringing which Mr Lewin described as tragic and difficult. He did indeed have an exceptionally difficult
start in life and we are told, and accept, that he witnessed a stabbing in the family when he was only 14 and that he
was himself exploited and abused by others when he was younger. We also accept that he was not the
mastermind of the drugs conspiracy. Plainly if he had been, the sentence on him would have been very much
greater.

20 On the other hand, despite his troubled upbringing, there must come a time when credit for that begins to run
out. He had, as we have said, had numerous previous convictions, some dealt with by custodial sentences, others
not. He had been the subject of a criminal behaviour order, breached that; then a suspended sentence for breach
of the criminal behaviour order and then these offences were themselves in breach of a suspended sentence, which
the judge ordered to be activated by only concurrently, so it made no difference to the result.

21 We are also asked to bear in mind, as the judge did for both offenders, that they were sent to custody in the
middle of the pandemic and, like almost all prisoners in almost all custodial institutions at the moment, they are
confined to their cells for 23 hours a day. This is a factor which this court in the judgment of the Lord Chief Justice in
the case of Manning has said the sentencer is entitled to bear in mind, though the effect which it has in reducing the
sentence becomes proportionately more modest as the sentence increases.

22 We also bear in mind in the case of Nixon the importance of avoiding double‑counting. The sentences for the

drugs conspiracy on the one hand and the counts of trafficking on the other hand should be reached in isolation
from each other, though at the end it is possible to look at the question of totality.


-----

23 We agree with the submissions of Mr Jarvis that on the drugs conspiracy charge the judge's increase of the
starting point from four and a half years to five years was unduly lenient, even taking the defendant's age into
account. This was a relatively sophisticated county lines operation involving both Class A drugs and involving the
supply of them in the West Country. We accept, as we have said, that the defendant was not at the top of the chain
of command and we accept also, as Mr Lewin set out in a document entitled "Basis of Plea", that he was paying off
drug debts of his own and so in that sense was subject to exploitation. Nevertheless, we consider that in a case of
this kind a starting point of not less than six years' detention was justified and that with a discount of one third for
the plea should have led to a sentence of four years on Count 1.

24 On Counts 2 to 4, as we have said, Mr Jarvis referred us to the case of Zakaria Mohammed and, although it is
not a guideline case, there are observations in it which we would wish to mention. The case does have some
similarities to the present case, although of course no two cases are identical. Mr Mohammed was charged with
both offences of supplying Class A drugs and offences of human trafficking. He was a drug dealer who had used
three children [ages] to deal in crack cocaine and heroin. He was sentenced on a late plea of guilty to seven years
for the human trafficking and five years consecutive for the drug supply. He was 21 years old. At para.35 and 37 of
the judgment of this court William Davis J said this:

"In this case the appellant's offending meant that children [ages] were exposed to the trade in Class A drugs. Such
a trade is dangerous to those who are involved in it, never mind those buying the drugs. It is for those reasons that
we are not greatly assisted by forced labour cases."

25 We interpose that there had been previous authorities referred to involving the exploitation of victims for forced
labour. William Davis J continued at para.37.

"Just as the court in _Attorney General's Reference No. 2 of 2013 did not engage in setting a guideline for the_
offences with which it was concerned, so it is not for us to do so for the offence under s.2 of the Modern Slavery
Act. What we can do, as the court did in the Attorney General's reference, is to identify relevant considerations.
First, where the other person whose travel is arranged with a view to exploitation is a child then the offence
inevitably will be more serious than a case where the person is an adult. Second, where the exploitation of itself
involves the commission of serious criminal offences, the exploitation offence will be especially grave. Third, the
number of children whose travel is facilitated or arranged will be of importance. Fourth, the offence will be
aggravated if the same child is the subject of travel with a view to exploitation more than once."

26 Mr Lewin says, rightly, that the fourth of these considerations is inapplicable in the present case, but the first
three are entirely applicable, as he accepts. Here there were four victims [ages]. The case has the additional
aggravating feature to which we have referred that they were required to travel to the West Country with drugs in
their anuses.

27 In our view, a starting point before discount for plea in Mr Nixon's case of not less than eight years on the
trafficking charges would have been justified, resulting in a sentence after the late change of plea of seven years (or
just above that, but we will round it down). Adding that to the four year sentence for the drugs conspiracy would
give a total of 11 years plus nine months consecutive for the mobile phone offence. We will make a reduction of

one year for totality. We shall achieve this as follows. We grant leave to refer. The seven‑year sentence of

detention imposed on Nixon for the trafficking offences will remain unaltered, as will the nine months consecutive
for the mobile phone offence. On the drug traffic charge, we shall quash the seven years concurrent and substitute
a consecutive sentence of three years' detention in a Young Offenders' Institution. The result is that the total
sentences on Nixon will be ten years and nine months' detention, rather than seven years and nine months.

28 We turn to the case of Ms Ismail. She was eight years older than Nixon and she had been his care worker, but,
as we have said, there can be no doubt that he was the driving force in these offences of trafficking. We have
noted the judge's finding that she knew what Nixon was doing in general terms. He made no finding that Ms Ismail
knew that the children were carrying drugs in their anuses and we consider that on this point Ms Ismail must be
given the benefit of the doubt. Unlike Nixon, she was of previous good character. Mr Murray has told us, and we
accept, that she has been entirely alienated from her family. She has lost her career. She has, as Mr Murray said,


-----

fallen very far. She is now in custody for the first time and the reports on what she has made of it are very positive.
In her case too, we give the Attorney General leave to refer the sentence. We consider that it was lenient, but it
was not unduly lenient and, accordingly, we shall leave the judge's sentence undisturbed.

**End of Document**


-----

