# J. and others v Austria (App. No. 58216/12) [2017] ECHR 58216/12

EUROPEAN COURT OF HUMAN RIGHTS
JUDGE SAJÓ (PRESIDENT), JUDGES DE GAETANO, TSOTSORIA, PINTO DE ALBUQUERQUE, WOJTYCZEK,
KUCSKO-STADLMAYER, BOŠNJAK; AND TSIRLI (SECTION REGISTRAR)

6 DECEMBER 2016

17 JANUARY 2017JUDGMENTPROCEDURE

1. The case originated in an application (no. 58216/12) against the Republic of Austria lodged with the Court under
Article 34 of the Convention for the Protection of Human Rights and Fundamental Freedoms (“the Convention”) by
three Filipino nationals (“the applicants”), Mrs J. (“the first applicant”), Mrs G. (“the second applicant”) and Mrs C.
(“the third applicant”), on 4 September 2012. The President of the Section acceded to the applicants' request not to
have their names disclosed (Rule 47 § 4 of the Rules of Court).

2. The applicants were represented by Mr Adam Weiss, Legal Director of the AIRE Centre, a non-governmental
organisation (NGO) with its registered office in London. The Austrian Government (“the Government”) were
represented by their Agent, Mr H. Tichy, Head of the International Law Department at the Federal Ministry for
Europe, Integration and Foreign Affairs.

3. The applicants complained that the Austrian authorities had failed to undertake effective and exhaustive
investigations into their allegations that they had been the victims of human trafficking.

4. On 10 June 2014 the complaints under Articles 3, 4 and 8 of the Convention were communicated to the
Government, and the remainder of the application was declared inadmissible, in accordance with Rule 54 § 3.
**THE FACTSI. THE CIRCUMSTANCES OF THE CASE**

5. The first and second applicants were born in 1984 and 1982 respectively and live in Vienna. The third applicant
was born in 1972 and lives in Switzerland.

6. The following summary of the background of the case and the events in Austria is based on the submissions by
the applicants. The account of the investigation in Austria is based on the submissions by both parties.
_A. Background of the case_

7. The applicants are all nationals of the Philippines. The first and third applicants were recruited in 2006 and 2009
respectively by an employment agency in Manila to work as maids or au pairs in Dubai (United Arab Emirates). The
second applicant travelled to Dubai in December 2008 for the same purpose, at the suggestion of the first applicant,
not via an agency. All of the applicants had their passports taken away by their employers. During the course of
their work in Dubai, they allege that they were subjected to ill-treatment and exploitation by their employers, who
also failed to pay them their agreed wages and forced them to work extremely long hours, under the threat of
further ill-treatment.
_1. The first applicant_

8. In late 2006 the first applicant contacted an agency in Manila in order to find a job abroad. She is a single mother
with one daughter who was eight months old at the time. She signed a contract in which she agreed to work for a
family in Dubai for two years, from December 2006 until December 2008. The contract also stipulated that she
would be paid 700 United Arab Emirates dirhams (AED – approximately 150 euros (EUR) at that time) per month to
work for eight hours each working day Upon her arrival in Dubai the first applicant was taken to her employers who


-----

were two sisters or sisters-in-law sharing one large residence with their families. One of them took possession of
her passport.

9. For most of the initial two-year contract the first applicant was not subjected to physical abuse or direct threats of
harm by her employers, and she was paid regularly. However, she had to work from 5 a.m. to midnight throughout
the initial two-year period. Her duties included looking after her employers' children, preparing meals, cleaning the
house, doing the laundry and numerous other jobs around the house and garden. During the first nine months she
was required to perform this work seven days per week without a single day off, and was not allowed to leave the
house unsupervised. She was not allowed to have her own telephone and was only allowed to call her family in the
Philippines once a month, the costs of these calls being deducted from her wages. Further, the first applicant was
forbidden from speaking to any of the other workers from the Philippines in their native language. She was
constantly hungry, as she was generally only given the family's leftover food. Only when she accompanied the
family to the supermarket approximately once a month was she allowed to buy some basic food for herself.

10. After approximately nine months, the first applicant faced the first punishments by her employers. She was
forced to sleep on the floor when they found out that she had been talking to another employee from the Philippines
in their native language. When she became ill after sleeping on the cold floor, her employers prevented her from
buying medicine or contacting a doctor; instead, she had to continue working the same hours.

11. Towards the end of her two-year contract, the first applicant's employers informed her that they wished her to
stay, and offered her better pay, more days off and a telephone of her own, as well as permission to visit her family,
provided that she recruited someone to take over her job while she was away. The first applicant finally agreed to
extend her contract and returned to the Philippines for three months. Owing to the incentives and the prospect of
improved working conditions, she asked the second applicant to take over her role in Dubai during the time she was
away.

12. While the first applicant was in the Philippines, she received threats from her employers that if she did not return
to Dubai to work, she would be banned from ever going back there, and the second applicant would be subjected to
ill-treatment. The first applicant therefore returned to Dubai in April 2009.

13. After she returned to Dubai, she was taught how to drive. After she failed her first driving test, she was forced to
pay for further lessons and tests out of her own salary, with four further driving tests costing AED 700 each, a
month's salary. While she was driving, one of her employers hit her on the shoulder on a number of occasions to
force her to speed up. The employer also started to slap or hit her regularly for no or little reason. She also
repeatedly threatened to let her husband hit the first applicant if she did not follow her orders or made any mistakes.

14. The first applicant accompanied her employers on trips to Europe, Australia, Singapore and Oman, where she
spent significant amounts of time locked up in hotel rooms or under the close supervision of her employers. She
only had to visit one embassy in person to obtain entry documents, and that was in relation to a trip to London, at
which time she was ordered by her employers to lie about her work conditions. When they arrived in London, the
first applicant was not allowed at any time to leave the apartment in which they were staying.
_2. The second applicant_

15. The second applicant was married with three young children in the Philippines. Her husband had no regular
work. Because she expected better pay in Dubai, she agreed to work for the same employers as the first applicant.
The employers in Dubai arranged a visiting visa for her, under false pretences. As a result of this arrangement, the
second applicant did not approach the employment agency in the Philippines and did not have a written contract
with her employers. Her understanding was that she would get AED 700 per month, which would be paid directly to
her family in the Philippines.

16. In December 2008 the second applicant started to work in Dubai. After the first applicant returned to the
Philippines for three months in January 2009 (see paragraph 11 above), the employers significantly changed their
conduct towards the second applicant. They threatened not to pay her family if she made any mistakes. They
refused to let her leave Dubai, including by refusing to return her passport and ordering her to repay them her travel
costs and related expenses They also told her that she would be put in prison if she ran away or went to the


-----

authorities in Dubai for help. They physically and emotionally abused her, and there was one incident when one of
her employers struck her across the shoulder using significant force. She was also forced to work from around 5 or
6 a.m. until midnight or 1 a.m. the following day.

17. Between April 2009 and June 2010 the violent and threatening behaviour of the employers increased. The
second applicant was punched by one of her employers on one occasion, and in another incident the employer
aimed a hard slap at her face, but instead struck her across the shoulder.
_3. The third applicant_

18. The third applicant's family were desperate for money to pay for crucial medical treatment for her brother.
Therefore, in 2009 she contacted an employment agency in the Philippines and was offered work as a maid in
Dubai. She was informed that she would be earning between AED 800 and 1,000 (approximately EUR 160 to 200
at that time) per month, roughly twice her salary in the Philippines. Upon her arrival in Dubai in 2009 she had to
hand over her passport and mobile phone to someone supposedly working for the employment agency. She was
told that these items would be returned to her when she finished her work in Dubai.

19. The third applicant was working for a family member of the first and second applicants' employers. The
applicants got to know each other, as the two families met every Friday. They secretly shared their experiences on
these occasions.

20. The third applicant was also bound by working hours going from 6 a.m. to midnight. Her employer forced her to
clean her car in the sun and in unbearable heat, and she was prohibited from going to the toilet without letting her
employer know. She was only allowed to call her family in the Philippines once a month, and only in the presence of
her employer. She did not receive any remuneration at all for the first three months of her employment. Afterwards,
she only received approximately AED 750 per month, less than what had been agreed. On one occasion she was
slapped by her employer, and on a different occasion she witnessed another employee being hit over the head.

21. When the third applicant told her employer that she wished to return to the Philippines, she was told that she
would have to pay the cost of the flight and the agency fees, which her employer knew she could not afford at that
point. Her employer also made it clear that, in any event, her passport would not be returned to her until she had
completed at least nine months of work in Dubai. Subsequently, the third applicant was too scared to ask to leave
Dubai again, owing to her fear that her employer would take her earnings from her or refuse to return her passport
for an even longer period.
_B. Events in Austria_

22. On 2 July 2010 the applicants' employers took them along on a short holiday trip to Austria. The applicants all
stayed at the same hotel in the city centre of Vienna. The applicants slept in their own, separate apartment together
with the female children. The male children slept in the same apartment as their parents. As in Dubai, the applicants
had to take care of all of the employers' children and perform numerous other domestic duties. They were still
required to work from approximately 5 or 6 a.m. until midnight or even later. The third applicant was regularly
shouted at by her employer, for example if she failed to get all the children ready early every morning. In addition,
their employers woke the first applicant up at around 2 a.m. and forced her to cook food for them. Furthermore, the
first applicant was forced to carry the employers' twenty suitcases into the hotel by herself. While the applicants
were in Austria, their passports remained with their employers. In the hotel in Vienna in which the applicants were
staying, they became acquainted with N., an employee at the hotel who could speak Tagalog, the first applicant's
mother tongue.

23. When the applicants accompanied their employers to a zoo one or two days after their arrival in Austria, one of
the children went missing for some time. One of the employers started screaming at the first and third applicants in
a manner which the applicants had not experienced before. The first applicant found the level of verbal abuse
extreme, and this was a particularly distressing and humiliating experience for her. The employer threatened to beat
the third applicant, and said that “something bad” would happen to her if the child was not found safe and well. By
this stage, the third applicant had formed the impression that this employer, of whom she lived in a constant state of
fear, was a dangerous person who might try to hurt her very badly. She had the feeling that the violence towards
h lik l t l t t ti Th f h b li d th t thi b d i t h t h if h


-----

remained with the family. Similarly, the first applicant believed that they could not live with their conditions of work
any longer, and did not want to risk waiting to see what happened if they travelled with their employers from Vienna
to London, as they were scheduled to do. The applicants therefore decided to speak to N., the Tagalog-speaking
employee at the hotel, to see whether she could help them.

24. The night following the incident – that is, two or three days after their arrival in Austria – the applicants left the
hotel with the help of N., who had organised a car to pick them up in a side street near the hotel and take them to a
“safe place”. The applicants subsequently found support within the local Filipino community in Vienna.
_C. Proceedings in Austria1. Criminal proceedings against the applicants' employers_

25. In April or May 2011, approximately nine months after they had left their employers, the applicants contacted a
local NGO called “LEFÖ” for assistance in reporting their ill-treatment, abuse and exploitation to the police. LEFÖ is
actively involved in the fight against trafficking in human beings in Austria. It is financed though government funds,
in particular for the provision of assistance to victims of trafficking. In July 2011 the applicants decided to turn to the
Austrian police and filed a criminal complaint (Strafanzeige) against their employers. They explained that they had
been the victims of human trafficking. On 11 and 21 July and 17 August 2011, accompanied by representatives of
LEFÖ, they were interviewed at length by officers from the Office to Combat Human Trafficking (Büro für
_Bekämpfung des Menschenhandels) at the Federal Office of Criminal Investigations (Bundeskriminalamt). In their_
report, the officers concluded that the offences had been committed abroad.

26. The applicants were informed that their employers had also made allegations about their conduct, alleging, inter
_alia, that they had stolen money and a mobile phone from them when they had fled the hotel. Those allegations_
were subsequently formally recognised by the Austrian authorities as false. The applicants all expressed their
willingness to actively cooperate with the authorities and to engage in criminal proceedings against their employers.

27. On 4 November 2011 the Vienna public prosecutor's office (Staatsanwaltschaft Wien) discontinued the
proceedings under Article 104a of the Criminal Code (Strafgesetzbuch – hereinafter “the CC”) relating to human
trafficking (see paragraph 35 below), pursuant to Article 190 § 1 of the Code of Criminal Procedure
(Strafprozessordnung – hereinafter “the CCP” – see paragraph 36 below). On 14 November 2011 the public
prosecutor gave a short written decision with reasons for the discontinuation of the proceedings. In the public
prosecutor's view, the offence had been committed abroad by non-nationals, and did not engage Austrian interests
within the meaning of Article 64 § 1 (4) of the CC.

28. On 30 November 2011 the applicants lodged an application to continue the investigation (Fortsetzungsantrag)
with the Vienna Regional Criminal Court (Straflandesgericht Wien). They submitted that Austrian interests had
indeed been engaged, and that their employers had continued to exploit and abuse them in Austria. In their view,
the elements of the crime punishable under Article 104a § 1 (2) of the CC had been present.

29. The Vienna public prosecutor's office then submitted a statement to the Vienna Regional Criminal Court,
specifying its reasons for discontinuing the investigation. There had been no indication in the case file that any of
the criminal actions exhaustively listed in Article 104a of the CC had occurred in Austria, particularly since the
offence had already been completed in Dubai (zumal das Delikt bereits in Dubai vollendet wurde), and the accused
were not Austrian citizens. Furthermore, from the applicants' statements (looking after children, washing laundry,
cooking food), it did not appear that they had been exploited in Austria, especially since they had managed to leave
their employers only two to three days after their arrival in Vienna.

30. On 16 March 2012 the Vienna Regional Criminal Court dismissed the applicants' application. The relevant parts
of the decision read (translation from German):

“The decision to discontinue [criminal proceedings] requires – by implication – that the facts of a case are
sufficiently clear, or a lack of indication that investigations would be promising.

There is no reason for further prosecution if, on the basis of the … results of the investigation, a conviction is
no more likely than an acquittal …


-----

According to Article 64 § 1 (4) of the CC, if Austrian interests have been harmed by the offence or the
perpetrator cannot be extradited, Austrian criminal laws apply independently of the criminal laws of the place
where the crime was committed, for example in relation to the offence of kidnapping for ransom under Article
104a of the CC. Owing to the fact that the applicants spent approximately three days in Vienna, the conditions
regarding the fulfilment of the elements of the crime under Article 104a § 1 (2) of the CC have not been met,
since the relevant acts relating to the exploitation of labour must be committed over a longer period of time;
therefore, the commission of the offence in Austria is ruled out.

The jurisdiction of the Austrian criminal-law enforcement authorities cannot be deduced from Article 64 § 1 (4)
of the CC either.

Austrian interests are engaged if either the victim or the perpetrator is an Austrian citizen, or if the criminal acts
have a concrete connection to Austria, or if an obligation arises under international law in relation to the
prosecution of certain offences. Austrian interests are, in any event, engaged if a criminal offence under
Articles 102, 103, 104 or 217 of the CC is committed against an Austrian citizen, or if Austrian funds or Austrian
securities (Wertpapiere) are the subject of offences under Article 232, or Article 237 in conjunction with Article
232, of the CC.

The applicants' argument that the elements of the crime under Article 104a of the CC had also been fulfilled in
Austria therefore fails, and the plea that the alleged criminal actions against them by their employers in Dubai
… would lead to an obligation on the part of Austria under international law is likewise not convincing. In
relation to the present case, [this latter argument] also cannot be inferred from the quoted [Supreme Court]
judgment no. 11 Os 161/81, which affirmed that Austrian interests had been damaged as a result of the import
into Austria of a large amount of narcotics for transport…”

This decision was served on the applicants' counsel on 23 March 2012.
_2. Civil proceedings against the applicants' employers_

31. In January 2013 two of the three applicants lodged a civil claim against their employers with the Vienna Labour

and Social Court (Arbeits‑und Sozialgericht) in order to claim their wages. However, they alleged that because of

the high risk of having to pay the costs of the proceedings because the employers did not reside in Austria, they
withdrew the action.
_3. Proceedings concerning the applicants' residence permits_

32. The NGO LEFÖ not only assisted the applicants in filing a criminal complaint against their employers, but also
supported them in applying for a special residence permit in Austria for victims of human trafficking, under the
former section 69a of the Residence Act (Niederlassungs- und Aufenthaltsgesetz – see paragraph 46 below).

33. All three applicants were granted a residence permit for special protection purposes in January 2012, valid for
one year initially. Subsequently, because of their progressing integration, they were granted other types of
residence permits with longer periods of validity.

34. The applicants were officially registered in the Central Register (Melderegister) from the point when LEFÖ
started supporting them. A personal data disclosure ban was enacted on the Central Register for their protection, so
that their whereabouts would not be traceable by the general public.
_II. RELEVANT DOMESTIC AND INTERNATIONAL LAW AND PRACTICEA. Domestic law and practice_

35. Article 104a of the CC, entitled “Human trafficking”, as in force at the relevant time, reads:

“(1) Any person who recruits, houses or otherwise accommodates, transports or offers, or passes on to a third
party:

1. a minor (under 18 years of age); or

2. an adult, using dishonest means (paragraph 2) against this adult;


-----

with the deliberate intention of sexual exploitation of the minor or adult, exploitation through organ transplant, or
labour exploitation, shall be punished by a prison sentence of up to three years.

(2) Dishonest means are defined as: deceit regarding the facts; exploitation of authority, situations of distress,
mental disease or any condition rendering the person defenceless; intimidation; or the granting or accepting of
an advantage for surrendering control over that person.

(3) A person who commits this criminal act using force or severe threats shall be punished by a prison
sentence of a minimum of six months up to five years.

(4) …”

36. Article 190 of the CCP reads in its relevant parts:

“The public prosecutor's office shall refrain from pursuing the prosecution of an offence and shall discontinue
the investigation if

1. the facts on which the investigation is based cannot be punished under criminal law, or if the further
prosecution of the accused is inadmissible for legal reasons …”

37. Article 193 § 2 of the CCP reads in its relevant parts:

“(2) The public prosecutor's office may order the continuation of a criminal investigation which had been
discontinued pursuant to Articles 190 or 191 [of the CCP] as long as the criminal liability for the offence is not
time-barred and if

1. the accused has not been questioned in relation to this offence … and no coercive measures have been
taken against him …”

38. Article 197 § 1 of the CCP reads:

“If the accused has absconded or his whereabouts are unknown, the investigation must continue in so far as it
is necessary to secure traces and evidence. In this case, investigative measures and the taking of evidence, in
which the accused has the right to participate … may be carried out even in his absence. An order may be
issued for the determination of the accused's whereabouts or for his arrest. Thereafter, the public prosecutor's
office must stay the investigation and continue it after the accused has been located.”

39. Article 210 of the CCP provides that if a conviction is likely on the basis of sufficiently clarified facts, and if there
are no reasons to discontinue the proceedings or withdraw the prosecution, the public prosecutor's office has to file
an indictment (Anklage einbringen) with the competent court.

40. Article 64 of the CC, as in force at the relevant time, provided that offences which were committed abroad could
be punishable under Austrian law, inter alia, under the following conditions:

“(1) Austrian law applies irrespective of the law of the country where the crime was committed in respect of the
following offences:

…

4. … slavery (Article 104), human trafficking (Article 104a), … if Austrian interests are engaged by this offence
or the offender cannot be extradited.”

According to Austrian legal practice, Austrian interests are engaged if either the offender or the victim is an Austrian
citizen, or the offence has a connection to Austria, or there is an obligation under international law (see Supreme
Court judgments in case no. 13 Os 105/03, 24 September 2003, and case no. 15 Os 37/03, 27 March 2003). On 9
December 1981 the Austrian Supreme Court decided in case no. 11 Os 161/81, which concerned the transport and
import of narcotics to Austria that Austrian interests were in any event engaged if narcotics were brought to Austria


-----

even though it was only for a short time. Moreover, the Supreme Court referred to a duty under international law to
combat the transport of drugs.

41. Article 363a of the CCP, under the heading “Renewal of criminal proceedings” (Erneuerung des
_Strafverfahrens), provides:_

“1. If it is established by a judgment of the European Court of Human Rights that there has been a violation of
the Convention for the Protection of Human Rights and Fundamental Freedoms (Official Gazette

[Bundesgesetzblatt] no. 210/1958) or one of its Protocols on account of a decision or order of a criminal court,
a retrial shall be held upon request, in so far as it cannot be ruled out that the violation might have affected the
decision in a manner detrimental to the person concerned.

2. All applications for the renewal of proceedings shall be decided by the Supreme Court. Such an application
may be filed by the person affected by the violation or the Prosecutor General's Office; Article 282 § 1 shall be
applicable by analogy. The application must be lodged with the Supreme Court. If the Prosecutor General's
Office has lodged an application, the person affected must be heard; if the person affected has lodged an
application, the Prosecutor General's Office must be heard; Article 35 § 1 shall be applicable by analogy.”

42. On 1 August 2007 (in case no. 13 Os 135/06m) the Supreme Court allowed an application for the renewal of
criminal proceedings under Article 363a of the CCP, where the applicant had not previously filed a human rights
complaint with the Court. In so far as relevant, the Supreme Court stated:

“Given that Article 13 of the Convention requires a Contracting State to provide any person who shows with
some plausibility that there has been a violation of his or her rights under the Convention and its Protocols with
an effective remedy, in other words to ensure that there is a court at domestic level which examines questions
of whether there has been a violation of Convention rights, Article 363a § 1 of the CCP must not be interpreted
so as to allow an application for the renewal of criminal proceedings only in those cases where the European
Court of Human Rights has already issued a judgment finding a violation of the Convention.”

For an extensive summary of the Supreme Court judgment, see _ATV Privatfernseh-GmbH v. Austria ((dec.), no._
58842/09, § 19, 6 October 2015).

43. In a judgment of 16 December 2010 (in case no. 13 Os 130/10g) concerning an application under Article 363a
of the CCP, the Supreme Court clarified:

“According to established case-law, a judgment by the European Court of Human Rights is not required in
order to lodge an application for the renewal of criminal proceedings under Article 363a § 1 of the CCP.
Persons who plausibly claim that a decision of a criminal court of last instance has violated their fundamental
rights, or that they are still victims of a human rights violation by the Criminal Investigation Department, the
public prosecutor's office, or a court, even though all domestic remedies have been exhausted, are eligible to
file such an application …

Persons who are affected by a violation of the Convention in their position as [private] prosecutors … shall not
have the right to lodge an application for the renewal of criminal proceedings. In the light of this intention of the
original drafters of the legislation and the scope of protection, the same must apply to victims (Article 65 of the
CCP) who are in such a position. Their interests are sufficiently protected by the possibility of lodging an
application for the continuation of criminal proceedings (Article 195 of the CCP) …”

44. In subsequent decisions the Supreme Court has confirmed that victims within the meaning of Article 65 of the
CCP are not allowed to file applications for the renewal of criminal proceedings under Article 363a of the CCP
(decisions of 15 May 2012, no. 14 Os 37/12s, and 19 February 2014, no. 15 Os 177/13p). Article 65 § 1 (a) of the
CCP defines a “victim” as any person who may have been exposed to violence or a dangerous threat, or whose
sexual integrity may have been interfered with because of an intentionally committed criminal offence.


-----

45. Article 66 of the CCP, as in force at the relevant time, listed the rights of victims during criminal proceedings,
such as the right to: be represented by counsel; inspect court files; be informed of the progress of proceedings; and
apply for the continuation of proceedings discontinued by the public prosecutor.

46. Under the heading “special protection”, section 69a of the Residence Act (Niederlassungs- und
_Aufenthaltsgesetz), as in force at the relevant time, made provision for victims of human trafficking to obtain_
residence permits.
_B. Relevant international treaties and other international material1. The Palermo Protocol_

47. The Protocol to Prevent, Suppress and Punish Trafficking in Persons, especially Women and Children (“the
Palermo Protocol”), supplementing the United Nations Convention against Transnational Organised Crime 2000,
was adopted on 15 November 2000, and came into force on 25 December 2003. It was ratified by Austria on 15
September 2005. The relevant provisions are set out in the following paragraphs.

48. Article 3 (a) defines “trafficking in persons” as:

“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having
control over another person, for the purpose of exploitation. Exploitation shall include, at a minimum, the
exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or services, slavery
or practices similar to slavery, servitude or the removal of organs.”

49. Article 3 (b) provides that the consent of a victim of trafficking to the intended exploitation is irrelevant where any
of the means set forth in Article 3 (a) have been used.

50. Article 4 identifies the scope of application of the Palermo Protocol as the “prevention, investigation and
prosecution of the offences established in accordance with article 5 of this Protocol, where those offences are
transnational in nature and involve an organized criminal group, as well as … the protection of victims of such
offences”.

51. Article 5 (1) provides that “each State Party shall adopt such legislative and other measures as may be
necessary to establish as criminal offences the conduct set forth in article 3 of this Protocol, when committed
intentionally”.

52. Article 6 deals with the assistance and protection of victims of trafficking in persons and provides, in so far as
relevant:

“2. Each State Party shall ensure that its domestic legal or administrative system contains measures that
provide to victims of trafficking in persons, in appropriate cases:

(a) Information on relevant court and administrative proceedings;

(b) Assistance to enable their views and concerns to be presented and considered at appropriate stages of
criminal proceedings against offenders, in a manner not prejudicial to the rights of the defence …”

_2. The Council of Europe Anti-Trafficking Convention_

53. The Council of Europe Convention on Action against Trafficking in Human Beings (“the Anti-Trafficking
Convention”) was adopted by the Committee of Ministers of the Council of Europe on 3 May 2005, and entered into
force on 1 February 2008. The Anti-Trafficking Convention was ratified by Austria on 12 October 2006. The relevant
provisions are set out in the following paragraphs.

54. Article 2 establishes the scope of the Anti-Trafficking Convention and states that it “shall apply to all forms of
trafficking in human beings, whether national or transnational, whether or not connected with organised crime”.


-----

55. Article 4 (a) adopts the definition of “trafficking in human beings” which can be found in the Palermo Protocol,
and replicates the provision in Article 3 (b) of the Palermo Protocol on the irrelevance of the consent of a victim of
trafficking to the exploitation (see paragraphs 48 and 49 above).

56. Article 10 is concerned with the identification of victims and provides, in so far as relevant:

“1. Each Party shall provide its competent authorities with persons who are trained and qualified in preventing
and combating trafficking in human beings, in identifying and helping victims, including children, and shall
ensure that the different authorities collaborate with each other as well as with relevant support organisations,
so that victims can be identified in a procedure duly taking into account the special situation of women and
child victims and, in appropriate cases, issued with residence permits under the conditions provided for in
Article 14 of the present Convention.

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure that,
if the competent authorities have reasonable grounds to believe that a person has been victim of trafficking in
human beings, that person shall not be removed from its territory until the identification process as victim of an
offence provided for in Article 18 of this Convention has been completed by the competent authorities and shall
likewise ensure that that person receives the assistance provided for in Article 12, paragraphs 1 and 2.”

57. Article 18 requires States to:

“…adopt such legislative and other measures as may be necessary to establish as criminal offences the
conduct contained in article 4 of this Convention, when committed intentionally.”

58. Article 27 deals with ex parte and ex officio applications and reads:

“1. Each Party shall ensure that investigations into or prosecution of offences established in accordance with
this Convention shall not be dependent upon the report or accusation made by a victim, at least when the
offence was committed in whole or in part on its territory.

2. Each Party shall ensure that victims of an offence in the territory of a Party other than the one where they
reside may make a complaint before the competent authorities of their State of residence. The competent
authority to which the complaint is made, insofar as it does not itself have competence in this respect, shall
transmit it without delay to the competent authority of the Party in the territory in which the offence was
committed. The complaint shall be dealt with in accordance with the internal law of the Party in which the
offence was committed.

3. Each Party shall ensure, by means of legislative or other measures, in accordance with the conditions
provided for by its internal law, to any group, foundation, association or non-governmental organisations which
aims at fighting trafficking in human beings or protection of human rights, the possibility to assist and/or support
the victim with his or her consent during criminal proceedings concerning the offence established in
accordance with Article 18 of this Convention.”

59. Article 31 § 1 deals with jurisdiction and requires States to adopt such legislative and other measures as may be

necessary to establish jurisdiction over any offence established in accordance with the Anti‑Trafficking Convention

when the offence is committed:

“(a) in its territory; or

(b) on board a ship flying the flag of that Party; or

(c) on board an aircraft registered under the laws of that Party; or


-----

(d) by one of its nationals or by a stateless person who has his or her habitual residence in its territory, if the
offence is punishable under criminal law where it was committed or if the offence is committed outside the
territorial jurisdiction of any State;

(e) against one of its nationals.”

60. With regard to Article 31 § 1 (a), the explanatory report accompanying the Anti-Trafficking Convention states:

“328. Paragraph 1 (a) is based on the territoriality principle. Each party is required to punish the offences
established under the Convention when they are committed on its territory. For example, a Party in whose
territory someone is recruited by one of the means and for one of the exploitation purposes referred to in Article
4 (a) has jurisdiction to try the human-trafficking offence laid down in Article 18. The same applies to Parties
through or in whose territory that person is transported.”

_3. The Group of Experts on Action against Trafficking in Human Beings_

61. In its “Report concerning the implementation of the Council of Europe Convention on Action against Trafficking
in Human Beings by Austria, First Evaluation Round” (GRETA(2011)10, 15 September 2011), the Group of Experts
on Action against Trafficking in Human Beings (hereinafter “GRETA”) found the following:

“In recent years, the Austrian authorities have taken a number of significant measures to combat trafficking in
human beings (THB) on all fronts: prevention, protection of victims and prosecution of traffickers …

A series of measures designed to raise awareness on THB and to train relevant professionals have been taken
by the Austrian authorities in co-operation with NGOs and intergovernmental organisations. GRETA welcomes
the introduction in 2009 of special procedures to prevent THB for the purpose of domestic servitude in
diplomatic households. That said, GRETA considers that the Austrian authorities should take further measures
to raise awareness on the problem of THB, in particular as regards child trafficking and trafficking for the
purpose of labour exploitation. More research is needed to shed light on the extent of these forms of trafficking
and to guide the authorities in the development of policies to tackle them. …

As concerns measures to assist and protect victims of THB, the Austrian authorities have set up facilities and
services, in co-operation with civil society, primarily tailored to the needs of female victims. The Federal
Ministry of the Interior has introduced by an internal decree a recovery and reflection period of a minimum of 30
days for presumed victims of trafficking, during which time the person concerned should not be removed from
Austria. However, the number of persons who have benefited from such a period is very low. … The access to
compensation for victims of THB remains limited in Austria, among other due to the low number of
prosecutions and convictions of traffickers. …

Finally, GRETA considers that the Austrian authorities should review the current provisions criminalising THB
with a view to addressing possible overlaps and ensuring the dissuasiveness of the penalties provided for, in
order to reflect the fact that THB constitutes a serious violation of human rights. In addition, victims of trafficking
should be better protected both during the legal proceedings against traffickers and afterward, in particular by
making full use of the witness protection programme in respect to victims of trafficking. …

A special Central Unit in the Federal Criminal Intelligence Service within the Federal Ministry of the Interior is
specialised in investigating THB and migrant smuggling. This unit has the power to conduct criminal
investigations and is in regular contact with units of the regional criminal intelligence services specialised in
combating THB and other serious criminal activities. In addition, it plays the role of an intermediary between the
Austrian police and law enforcement agencies of other countries in the field of information exchange,
participation in joint operations, etc. …

LEFÖ-IBF enjoys a special position compared to other NGOs involved in the fight against trafficking in human
beings in Austria. It operates on the basis of an agreement with the Government and is financed though
governmental funds, in particular for the provision of assistance to THB victims. …”

_4. The ILO Forced Labour Convention_


-----

62. The Convention concerning Forced or Compulsory Labour, adopted in Geneva on 28 June 1930 by the General
Conference of the International Labour Organisation (hereinafter “the ILO”), entered into force on 1 May 1932. It
was ratified by Austria on 7 June 1960. Pursuant to Article 1, “each Member of the ILO which ratifies this
Convention undertakes to suppress the use of forced or compulsory labour in all its forms within the shortest
possible period”.

63. Article 2 § 1 defines “forced or compulsory labour” as:

“…all work or service which is exacted from any person under the menace of any penalty and for which the
said person has not offered himself voluntarily.”

64. Article 25 provides:

“The illegal exaction of forced or compulsory labour shall be punishable as a penal offence, and it shall be an
obligation on any Member ratifying this Convention to ensure that the penalties imposed by law are really
adequate and are strictly enforced.”

_C. European Union Law1. The EU Fundamental Rights Charter_

65. As a Member State of the European Union (hereinafter the “EU”) since 1 January 1995, Austria is bound to
respect the rights enshrined in the EU Charter of Fundamental Rights when transposing or applying EU law. Article
5 of the Charter provides:

**Prohibition of slavery and forced labour**

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

3. Trafficking in human beings is prohibited.”

_2. The EU Anti-Trafficking Directive_

66. The relevant parts of Article 2 of Directive 2011/36/EU of the European Parliament and of the Council of 5 April
2011 on preventing and combating trafficking in human beings and protecting its victims read as follows:

“1. Member States shall take the necessary measures to ensure that the following intentional acts are
punishable:

The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or transfer
of control over those persons, by means of the threat or use of force or other forms of coercion, of abduction, of
fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of
payments or benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation.

2. A position of vulnerability means a situation in which the person concerned has no real or acceptable
alternative but to submit to the abuse involved.

3. Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services including begging, slavery or practices similar to slavery, servitude, or
the exploitation of criminal activities, or the removal of organs.

4. The consent of a victim of trafficking in human beings to the exploitation, whether intended or actual, shall be
irrelevant where any of the means set forth in paragraph 1 has been used.

…”

67. Article 10 of the Directive deals with jurisdiction and provides, in so far as relevant:


-----

“1. Member States shall take the necessary measures to establish their jurisdiction over the offences referred
to in Articles 2 and 3 where:

(a) the offence is committed in whole or in part within their territory; or

(b) the offender is one of their nationals.

…”

**THE LAWI. APPLICATION OF ARTICLE 37 § 1 OF THE CONVENTION**

68. By Article 37 § 1 of the Convention, the Court may decide to strike an application out of its list of cases where
the circumstances lead to the conclusion that:

“(a) the applicant does not intend to pursue his application; or

(b) the matter has been resolved; or

(c) for any other reason established by the Court it is no longer justified to continue the examination of the
application.

However, the Court shall continue the examination of the application if respect for human rights as defined in
the Convention and the Protocols thereto so requires.

…”

69. By a letter of 30 January 2015 the applicants' representative informed the Court that he was no longer in
contact with the third applicant. He believed the third applicant to have relocated to Switzerland, but was unable to
take her instructions with regard to the Government's observations.

70. The Government did not comment on this issue.

71. The Court is of the opinion that the third applicant's failure to inform her representative of her current
whereabouts must be taken as indicating that she has lost interest in pursuing her application. Although it is true
that she did authorise the AIRE Centre to represent her in the proceedings before the Court, it considers that this
authority does not by itself justify pursuing the examination of her application. Given the representative's inability to
establish any communication with the third applicant, the Court considers that the AIRE Centre cannot meaningfully
pursue the proceedings before it (see V.M. and Others v. Belgium [GC], no. 60125/11, § 36, 17 November 2016,
with further references).

72. That being so, the Court finds that further examination of the third applicant's application is not justified.
Consequently, it concludes that the third applicant may be regarded as no longer wishing to pursue her application
within the meaning of Article 37 § 1 (a) of the Convention (see, mutatis mutandis, Chirino v. the Netherlands (dec.),
no. 31898/04, 4 May 2006, and Noor Mohammed v. the Netherlands (dec.), no. 14029/04, 27 March 2008).

73. The Court also notes that the third applicant has raised the same complaints as the other two applicants in the
present case, which it will examine below. In accordance with Article 37 § 1 _in fine, the Court therefore finds no_
reasons relating to respect for human rights, as defined in the Convention and its Protocols, which would require it
to continue the examination of the application (see Denizci and Others v. Cyprus, nos. 25316-25321/94 and

27207/95, § 369, ECHR 2001‑V).

74. Accordingly, the Court decides to strike the third applicant's application out of its list of cases. In the following
parts of the present judgment, the expression “the applicants” should be taken to refer to the first and second
applicants only.
_II. ALLEGED VIOLATION OF ARTICLE 4 OF THE CONVENTION_


-----

75. The applicants complained that they had been subjected to forced labour and human trafficking, and that the
Austrian authorities had failed to comply with their positive obligations under the procedural limb of Article 4 of the
Convention.

76. The relevant parts of Article 4 read:

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

…”

_A. Admissibility1. The parties' submissions(a) The Government_

77. The Government firstly submitted that it appeared that the applicants had not complied with the six-month timelimit under Article 35 § 1 of the Convention. They stated that while the final domestic decision had been given by
the Vienna Regional Court on 16 March 2012 (see paragraph 30 above), the application to the Court was dated 2
November 2012. It was therefore doubtful that the time-limit had been complied with.

78. Secondly, the Government asserted that the case should be declared inadmissible for non-exhaustion of
domestic remedies, as the applicants had failed to lodge an application for the renewal of criminal proceedings
under Article 363a of the CCP (see paragraph 41 above) against the decision of the Vienna Regional Criminal
Court of 16 March 2012.

79. By referring to the Supreme Court's established case-law, beginning with its ruling of 1 August 2007 (no. 13 Os
135/06m – see paragraph 42 above), the Government argued that an application for the renewal of proceedings
under Article 363a of the CCP constituted an effective remedy at domestic level within the meaning of Article 13 of
the Convention. The applicants could have complained of a violation of Convention rights and asked the Supreme
Court to order the continuation of the criminal investigation proceedings. Lodging such an application would have
led to a comprehensive examination of the compatibility of the judicial decision with Convention rights, and could
have led to the renewal of the proceedings and subsequently to a new judicial decision.

80. The Supreme Court's ruling of 1 August 2007, wherein it had held that an application for the renewal of
proceedings under Article 363a of the CCP could be lodged even prior to a decision by the Court, had been widely
disseminated and discussed not only amongst legal scholars, but also in daily newspapers. Further, statistics
showed that people had actually made use of the remedy: 37 times in 2011 and 40 times in 2012 and 2013
respectively.

81. Also, the Supreme Court's ruling of 16 December 2010 (case no. 13 Os 130/10g – see paragraph 43 above)
had not restricted the applicants' right to lodge an application for the renewal of proceedings, as it had merely
referred to the rights of victims within the meaning of Article 66 § 1 of the CCP, and did not affect alleged violations
of the Convention.
_(b) The applicants_

82. Concerning the six-month time-limit, the applicants submitted that the Government's doubts were mistaken.
They had sent the letter of intent on 4 September 2012. The application form had been faxed and sent by post on 5
November 2012, in accordance with the deadline given by the Court. The time-limit under Article 35 § 1 of the
Convention had thus been complied with.

83. With regard to the question whether domestic remedies had been exhausted, the applicants pointed to the
decision of the Vienna Regional Court of 16 March 2012 (see paragraph 30 above), which expressly stated that, in
accordance with Article 196 § 3 of the CCP, there was no right of appeal against that decision. This indicated
already that domestic remedies had been exhausted.

84. The applicants argued that an application for the renewal of criminal proceedings under Article 363a of the CCP
(see paragraph 41 above) was not an effective remedy. The Government had failed to prove that the proposed
remedy had been both effective and available in theory and in practice at the relevant time


-----

_2. The Court's assessment_

85. Regarding the Government's contention that the application was submitted outside the time-limit provided for by
Article 35 § 1 of the Convention (see paragraph 77 above), the Court notes that the applicants' first letter of intent –
which at the time of its submission was satisfactory to stop the six-month time-limit from running – reached the
Court on 4 September 2012. The last domestic decision in the matter was served on the applicants' counsel on 23
March 2012 (see paragraph 30 in fine above), hence less than six months before that date. The Court is therefore
satisfied that the admissibility criterion of Article 35 § 1 in fine has been complied with.

86. Turning to the Government's objection of non-exhaustion of domestic remedies (see paragraphs 78-81 above),
the Court observes that in the case of _ATV Privatfernseh-GmbH v. Austria ((dec.), no. 58842/09, §§ 32-37, 6_
October 2015) it examined in detail the question whether Article 363a of the CCP was a remedy which was readily
available and sufficient to afford redress in respect of an alleged breach of rights under Article 10 of the Convention
in proceedings for compensation under section 7 of the Media Act. It found that, in the circumstances of that case,
an application under Article 363a of the CCP constituted an effective and sufficient remedy which an applicant
would be obliged to use. However, it appears from the Supreme Court's case-law that victims of crimes and private
prosecutors as well as public prosecutors are not entitled to that remedy (see Fürst-Pfeifer v. Austria, nos. 33677/10
and 52340/10, § 31, 17 May 2016, and the judgment of the Supreme Court of 10 December 2010 (no. 13 Os
130/10g), cited in paragraph 43 above). The Government have not provided evidence to show that the availability of
the remedy also extends to those groups of persons. It follows that the Government's objection with regard to the
non-exhaustion of domestic remedies has to be dismissed.

87. The Court notes that this complaint is not manifestly ill-founded within the meaning of Article 35 § 3 (a) of the
Convention. It further notes that it is not inadmissible on any other grounds. It must therefore be declared
admissible.
_B. Merits1. The parties' submissions(a) The applicants_

88. The applicants submitted that the credibility of their claims was highlighted by the fact that the Austrian
authorities had dismissed the criminal allegations of theft made against them by their employers after the police had
had an opportunity to question the applicants (see paragraph 26 above). They stressed that the authorities had
accepted that their treatment fell within the notion of human trafficking, as defined by Articles 4 and 10 of the

Council of Europe Anti‑Trafficking Convention, and the Court's judgment in _Rantsev v. Cyprus and Russia (no._

25965/04, ECHR 2010 (extracts)).

89. Moreover, the public prosecutor and the Vienna Regional Criminal Court had at no stage queried the veracity of
the allegations of forced labour and human trafficking, but had simply stated that the incidents alleged to have taken
place on Austrian soil were too short in duration to engage Austrian interests for the purpose of having jurisdiction
over a criminal offence. It followed that the events which had occurred outside Austria were also to be considered
credible. The incidents which had occurred in Austria – which had remained undisputed by the Government – could
not be viewed in isolation, and had been part of an ongoing course of treatment. Indeed, the incidents prior to the
applicants' arrival in Austria had been part of the trafficking chain relevant to the trafficking situation in Austria, and
should be examined as part of the respondent State's procedural obligations (the applicants referred to _Rantsev,_
cited above, § 307). As the applicants had been accepted in Austria as victims of human trafficking, the parts of the
trafficking chain prior to their arrival in Austria, that is those parts in the Philippines (their recruitment, deception,
and transportation at least) and in the United Arab Emirates (their exploitation and transportation at least), should
be examined. Seeing in isolation the events which had occurred in Austria over the course of three days would be
an unlawfully narrow window for examination, and was not supported by either authority or common sense. By
confining their approach to their duty to investigate and prosecute the incidents in Vienna, the Government were
ignoring the fact that the positive identification of a person as a victim of human trafficking was sufficient to trigger
the duty under international law to investigate also those events which occurred abroad.

90. The applicants submitted that there was a difference between the duty to identify and provide substantive
assistance and support to victims of human trafficking, and the procedural obligation to investigate under
international and EU law. While the Government had described a range of measures that had been applied in the


-----

applicants' case in respect of the former duty (see paragraphs 98-100 below), they had failed to comply with the
latter. The investigation in the present case had been so inadequate as to be in breach of Article 4 of the
Convention. The duty to investigate had been triggered by the applicants showing sufficient indicators to raise a
credible suspicion of trafficking. In C.N. v. the United Kingdom (no. 4239/08, § 72, 13 November 2012) the Court
had held that “the fact that the domestic authorities conducted any investigation into the applicant's complaints
strongly indicates that, at least on their face, they were not inherently implausible”. The applicants contended that
that finding applied in their case, given that the public prosecutor had not treated their complaints as incredible or
implausible, but had simply discontinued them for technical reasons.

91. In this context, the applicants alleged that the relevant Articles of the CC had been interpreted too strictly and
narrowly in their case, or in the alternative, that the Articles had been too narrowly framed to begin with, giving rise
to a breach of Article 4 of the Convention.

92. The applicants submitted that the respondent State's duty to investigate had been triggered in July 2011 (see
paragraph 25 above), when they had turned to the police. That duty flowed from Articles 27 and 31 of the AntiTrafficking Convention (see paragraphs 58 and 59 above), and Articles 4, 5 and 6 of the Palermo Protocol (see
paragraphs 50-52 above). By discontinuing any investigation against the applicants' employers at such an early
stage, the Austrian authorities had failed to satisfy the key aims of the State's international obligations relating to
human trafficking, including ensuring the effective investigation and prosecution of the perpetrators of the crimes
against the applicants.
_(b) The Government_

93. The Government emphasised at the outset that there was no evidence available to them as to whether and to
what extent the incidents in the Philippines and the United Arab Emirates, as submitted by the applicants, had
actually occurred. Only the events and proceedings in Austria were undisputed.

94. Concerning the general and legislative measures Austria had taken in order to combat human trafficking and
labour exploitation, the Government submitted that Austria was a State Party to all the relevant international legal
instruments, such as the Council of Europe Anti-Trafficking Convention, the United Nations Convention against
Transnational Organized Crime, and the Palermo Protocol. The first Austrian “National Action Plan against
Trafficking in Human Beings” had been prepared in close cooperation with civil society organisations, and had been
adopted by the Austrian Council of Ministers (Ministerrat) in March 2007 for a three-year period. Since then, further
national action plans had been adopted. In the period 2010-11 Austria had been among the first Council of Europe
member States to be evaluated by GRETA (see paragraph 61 above), whose recommendations, adopted on 26
September 2011 by the Committee of the Contracting Parties to the Anti-Trafficking Convention, had been taken
into account and implemented in the National Action Plan 2012-2014, specifically concerning the exploitation of
domestic staff. Austria had fully complied with its obligation to protect the victims of human trafficking and forced
labour, in particular through the assistance of LEFÖ (the intervention centre which had supported the applicants
during the domestic proceedings – see paragraph 25 above), which was active throughout Austria on behalf of the
Ministry of the Interior (Bundesministerium für Inneres) and the Ministry for Education and Women
(Bundesministerium für Bildung und Frauen).

95. The Government pointed out that Austria was therefore in full compliance with its obligations under international
law. Article 104a of the CC (see paragraph 35 above), in force since 2010, constituted an adequate and efficient
legal basis to prosecute and punish trafficking in human beings. In accordance with Article 64 of the CC (see
paragraph 40 above), offences committed abroad were punishable even beyond the extent required by Article 31 of
the Council of Europe Anti-Trafficking Convention, namely irrespective of whether the offence was punishable
under criminal law in the country where it had been committed. Apart from territorial jurisdiction and the extended
active and passive personality principle, Austrian laws also included a wider interpretation of the principle _aut_
_dedere aut iudicare. Austria assumed jurisdiction not only if an offender's extradition was rejected because of his or_
her nationality, but also if Austrian interests were at stake (see Article 64 of the CC). The Government underlined
that the Anti-Trafficking Convention did not require its States Parties to establish universal jurisdiction to combat
human trafficking and forced labour.


-----

96. The Government asserted that the provisions and measures described above had been applied in the
applicants' case, and that the actions taken by the Austrian authorities had also been in full compliance with the
Convention.

97. The incidents with their former employers during their holidays in Austria, as described by the applicants, had
occurred over the course of three days in July 2010. The applicants had only notified the police of these incidents
approximately one year later. Even though they could not be blamed for turning to the police so late, it had made
the investigation of their case more difficult. Owing to the initial investigation against the applicants because of the
theft reported by their employers, the authorities had assumed that the applicants had long since left Austria, and
could not be interrogated via letters of request (Rechtshilfeersuchen) from organs of the United Arab Emirates
either. From general experience, the incidents described by the applicants as taking place at the hotel in Vienna
(looking after the children, cooking and doing washing at unusual hours and in excessive amounts, intimidating
behaviour on the part of their employers, and the confiscation of their passports), and especially the scene in the
very popular zoo, could not be ascertained with the certainty required for criminal proceedings more than one year
later. Therefore, it could no longer be assessed whether the applicants' treatment had actually reached an intensity
to be qualified as labour exploitation within the meaning of Article 4, or degrading treatment within the meaning of
Article 3 of the Convention. The statements made during the questioning of the three presumed victims of human
trafficking, and those of the hotel receptionist, who had only witnessed some of the incidents herself, had not
seemed sufficient to substantiate such serious criminal charges.

98. The applicants had been supported first by other Filipino nationals living in Vienna, and as of 2011 also by the
NGO LEFÖ. After having left their employers, they had no longer been in either a situation of exploitation, or under
any conceivable threat of being exploited in the future. On the contrary, it had been with the assistance of the
Austrian State that they had been able to reside lawfully in Austria. From the point when they had turned to LEFÖ –
an institution financed by public funds – they had been provided with legal representation, procedural guidance, and
assistance to facilitate their integration in Austria.

99. In accordance with Article 10 of the Anti-Trafficking Convention (see paragraph 56 above), the applicants had
not been questioned by ordinary police officers, but by officers specially trained and experienced in cases of crossborder human trafficking and labour exploitation. During the questioning, they had been accompanied by
representatives of LEFÖ (see paragraph 25 above). The applicants had not been expelled to their country of origin,
nor had any other measures been taken to terminate their stay in Austria. Rather, they had been granted special
protection under section 69a of the Residence Act (see paragraph 46 above), thus enabling them to reside lawfully
in Austria. The applicants had therefore not only been treated in a manner going beyond Austria's obligations under

Article 10 of the Anti‑Trafficking Convention, but had also been given the opportunity to work and secure their own

livelihood in Austria. Furthermore, a personal data disclosure ban had been imposed on the Central Register, so
their whereabouts were not traceable by the general public (see paragraph 34 above).

100. The Government submitted that the Austrian authorities had also complied with their obligations under Article
27 of the Anti-Trafficking Convention (see paragraph 58 above). As described above, the applicants had been
supported by LEFÖ before the police authorities, within the meaning of Article 27 § 3, and by lawyers before the
Vienna public prosecutor's office. It had not been possible to institute proceedings earlier, since the applicants'
allegations against their former employers had only been brought to the authorities' attention in July 2011.

101. The Government contended that the applicants' situation had thus differed significantly from the situation of
applicants in previous cases before the Court, where an immediate and intensive investigation into the
circumstances would have been required (the Government referred, notably, to Rantsev, cited above, § 289). In a
case such as the instant one, there appeared to be no duty to cooperate with the competent authorities of the other
State concerned (here, the United Arab Emirates) in the investigation of events which had occurred in that State
(they cited, _mutatis mutandis, Rantsev, loc. cit.). The legal assistance necessary for conducting criminal_
investigations against the applicants' former employers could not be obtained from the United Arab Emirates, as no
mutual legal assistance agreement between Austria and the United Arab Emirates yet existed. Even simple
requests for legal assistance had repeatedly been rejected in the past without discernible reason. There were also
no indications that the applicants' former employers were still staying in the United Kingdom where they had


-----

allegedly planned to travel after their stay in Vienna. However, for further investigative measures, it would have
been indispensable to inform the former employers of the allegations made and give them an opportunity to
comment on the accusations. Under Austrian law, in the absence of an accused, it was not possible to conduct
proceedings to determine the offences at issue.

102. The Government concluded by saying that there had been no violation of Article 4 of the Convention, because
the general obligation to take operational measures, as detailed above, did not impose an impossible or
disproportionate burden on the authorities, but required them to endeavour to provide for the physical safety of
victims of trafficking in human beings, which they had done (the Government referred, _mutatis mutandis, to_
_Rantsev, cited above, § 287)._
_2. The Court's assessment(a) General principles_

103. The Court refers to its relevant case-law on the general principles governing the application of Article 4 of the
Convention in the specific context of trafficking in human beings and forced labour (see Rantsev, cited above, §§
272-289). It reiterates that Article 4 enshrines one of the fundamental values of democratic societies. The first
paragraph of this Article makes no provision for exceptions, and no derogation from it is permissible under Article
15 § 2, even in the event of a public emergency threatening the life of a nation (see C.N. v. the United Kingdom, no.
4239/08, § 65, 13 November 2012).

104. The Court noted in _Rantsev_ that trafficking in human beings was often described as a form of **_modern_**
**_slavery, and it therefore took the view that it was in itself an affront to human dignity and incompatible with_**
democratic and Convention values, and thus within the prohibition of Article 4, without needing to classify it as
“slavery”, “servitude” or “forced labour”. The identified elements of trafficking – the treatment of human beings as
commodities, close surveillance, the circumscription of movement, the use of violence and threats, poor living and
working conditions, and little or no payment – cut across these three categories (see Rantsev, cited above, §§ 279282). The Court has held that trafficking in human beings, by its very nature and aim of exploitation, is based on the
exercise of powers attaching to the right of ownership. It treats human beings as commodities to be bought and sold
and put to forced labour, often for little or no payment, usually in the sex industry but also elsewhere. It implies
close surveillance of the activities of the victims, whose movements are often circumscribed. It involves the use of
violence and threats against victims, who live and work under poor conditions (ibid., § 281; see also M. and Others
_v. Italy and Bulgaria, no. 40020/03, § 151, 31 July 2012)._

105. Trafficking in human beings is a problem which is often not confined to the domestic arena. When a person is
trafficked from one State to another, trafficking offences may occur in the State of origin, any State of transit and the
State of destination. Relevant evidence and witnesses may be located in all States. Although the Palermo Protocol
(see paragraphs 47-52 above) is silent on the question of jurisdiction, the Anti-Trafficking Convention (see
paragraphs 53-59 above) explicitly requires each member State to establish jurisdiction over any trafficking offence
committed in its territory. Such an approach is, in the Court's view, only logical in light of the positive obligation
incumbent on all States under Article 4 of the Convention to investigate alleged trafficking offences. Member States
are also subject to a duty in cross-border trafficking cases to cooperate effectively with the relevant authorities of
other States concerned in the investigation of events which occurred outside their territories (see _Rantsev, cited_
above, § 289).

106. The Court has held that a State may be held responsible under Article 4 of the Convention not only for its
direct actions, but also for its failure to effectively protect the victims of slavery, servitude, or forced or compulsory
labour by virtue of its positive obligations and to conduct a comprehensive investigation (see Siliadin v. France, no.

73316/01, §§ 89 and 112, ECHR 2005‑VII). It follows that States are also under an obligation to put in place a

legislative and administrative framework to prohibit and punish trafficking, as well as to take measures to protect
victims, in order to ensure a comprehensive approach to the issue, as required by the Palermo Protocol and the
Anti-Trafficking Convention (see Rantsev, cited above, § 285). States are also required to provide relevant training
for law-enforcement and immigration officials (ibid., § 287).

107. As with Articles 2 and 3, the positive obligation to investigate is triggered as soon as a matter has come to the
attention of the authorities; the investigation must fulfil the requirements of independence and impartiality,


-----

promptness and reasonable expedition, and urgency where there is a possibility of removing the individual
concerned from a harmful situation. The investigation must also be capable of leading to the identification and
punishment of the individuals responsible – an obligation concerning the means to be employed, and not the results
to be achieved (ibid., § 288). In addition, authorities must take all reasonable steps available to them to secure
evidence concerning the incident (see, in relation to Article 3 of the Convention, Nikolay Dimitrov v. Bulgaria, no.
72663/01, § 69, 27 September 2007). Finally, the positive obligation must not be interpreted in such a way as to
impose an impossible or disproportionate burden on the authorities (see, mutatis mutandis and in relation to Article
2 of the Convention, Maiorano and Others v. Italy, no. 28634/06, § 105, 15 December 2009).
_(b) Application of these principles to the instant case_

108. At the outset, the Court considers that the applicants' allegations fall within the ambit of Article 4 of the
Convention, as established by its case-law on the subject (see, among other authorities, Siliadin, cited above, and
_Rantsev, cited above). The alleged treatment prohibited by Article 4 was not imputed to organs of the Austrian_
State, but to private individuals, namely the applicants' employers, over a period of several years in Dubai and two
to three days in Austria. Therefore, the present case concerns the positive obligations arising under this provision,
rather than the negative obligations.

109. The Court considers that the instant case essentially raises two questions: whether the Austrian authorities
complied with their positive obligation to identify and support the applicants as (potential) victims of human
trafficking, and whether they fulfilled their positive obligation to investigate the alleged crimes.
_(i) Whether the positive obligation to identify and support the applicants as victims of human trafficking has been_
_complied with_

110. Concerning the first question, having regard to the applicants' statements to the police (see paragraph 25
above), the Court notes that the authorities appear to have considered their claims credible. From the point when
the applicants turned to the police, they were immediately treated as (potential) victims of human trafficking. They
were interviewed by specially trained police officers (see paragraphs 25 and 99 above), were granted residence
and work permits in order to regularise their stay in Austria (see paragraphs 32-33 above), and a personal data
disclosure ban was imposed on the Central Register so their whereabouts were untraceable by the general public
(see paragraph 34 above). During the domestic proceedings, the applicants were supported by the NGO LEFÖ,
which is funded by the Government especially to provide assistance to victims of human trafficking. According to
the uncontested statements of the Government (see paragraph 98 above), the applicants were given legal
representation, procedural guidance and assistance to facilitate their integration in Austria.

111. For the purposes of Article 4 of the Convention, it is paramount that the applicants' claims as a whole were
taken seriously and the applicable legal framework was applied, in accordance with the State's obligations under
the Convention. From that point of view, the Court considers that the legal and administrative framework in place
concerning the protection of (potential) victims of human trafficking in Austria appears to have been sufficient, and
that the Austrian authorities took all steps which could reasonably have been expected in the given situation. This
was not contested by the applicants. The Court is therefore satisfied that the duty to identify, protect and support
the applicants as (potential) victims of human trafficking was complied with by the authorities.
_(ii) Whether the positive obligation to investigate the allegations of human trafficking was complied with_

112. Concerning the second question, namely the procedural obligation incumbent on the Austrian authorities to
investigate the applicants' allegations and to prosecute cases of human trafficking, the Court notes that the
applicants were given the opportunity to describe in detail what had happened to them and how they had been
treated by their employers. The public prosecutor's office initiated an investigation after the applicants had given
their statements to the police in July and August 2011. It would not have been possible to initiate the investigation
earlier, as the applicants only decided to turn to the police approximately one year after leaving their employers.
However, the investigation was discontinued in November 2011, as the public prosecutor's office was of the opinion
that the applicants' employers' alleged conduct on Austrian territory did not fulfil the elements of Article 104a of the
CC. As far as the events abroad were concerned, the public prosecutor's office observed that the alleged crime of
trafficking in human beings had been committed abroad, the accused were non-nationals, and Austrian interests
were not engaged (see paragraph 27 above). The decision to discontinue the proceedings was confirmed in


-----

December 2011by the Vienna Regional Criminal Court, which added that there was no reason to prosecute if, on
the basis of the results of the investigation, a conviction was no more likely than an acquittal. In its view, there was
also no obligation under international law to pursue the investigation in relation to the events that had allegedly
taken place abroad (see paragraph 30 above). In their observations, the Government added that requests for legal
assistance had repeatedly been rejected in the past by the United Arab Emirates without discernible reason,
implying that making such a request would have been of no use in the instant case (see paragraph 101 above).

113. The Court considers that, in the context of Austria's positive obligations in the instant case, questions arise as
to whether Austria was under a duty to investigate the crimes allegedly committed abroad, and whether the
investigation into the events in Austria was sufficient.
_(α) Alleged events abroad_

114. Concerning the alleged events in the United Arab Emirates, the Court considers that Article 4 of the
Convention, under its procedural limb, does not require States to provide for universal jurisdiction over trafficking
offences committed abroad (compare Rantsev, cited above, § 244, in relation to Article 2 of the Convention). The
Palermo Protocol is silent on the matter of jurisdiction, and the Anti-Trafficking Convention only requires States
Parties to provide for jurisdiction over any trafficking offence committed on their own territory, or by or against one
of their nationals (ibid., § 289 – see paragraph 105 above). The Court therefore cannot but conclude that, in the
present case, under the Convention, there was no obligation incumbent on Austria to investigate the applicants'
recruitment in the Philippines or their alleged exploitation in the United Arab Emirates.
_(β) Events in Austria_

115. The applicants argued that the Austrian authorities had accepted that they were victims of the crime of human
trafficking by treating them as such (see paragraphs 88-91 above). However, the Court does not consider that the
elements of the offence of human trafficking had been fulfilled merely because the Austrian authorities treated the
applicants as (potential) victims of human trafficking (see paragraphs 110-11 above). Such special treatment did not
presuppose official confirmation that the offence had been established, and was independent of the authorities' duty
to investigate. Indeed, (potential) victims need support even before the offence of human trafficking is formally
established; otherwise, this would run counter to the whole purpose of victim protection in trafficking cases. The
question whether the elements of the crime had been fulfilled would have to have been answered in subsequent
criminal proceedings.

116. The Court reiterates that the applicants were given the opportunity to provide a detailed account of the events
to specially trained police officers. Over thirty pages of statements were drawn up by the police. Based on the
descriptions given, the authorities concluded that the events – as reported by the applicants – which had taken
place over a maximum of three days in Vienna did not in themselves amount to any of the criminal actions
exhaustively listed in Article 104a of the CC (see paragraphs 29-30 above). No ill-treatment in Austria was reported
by the applicants. The Court considers that, in the light of the facts of the case and the evidence the authorities had
at their disposal, the assessment that the elements of Article 104a of the CC had not been fulfilled in relation to the
events in Austria does not appear to be unreasonable.

117. Next, the Court will examine the applicants' argument that the events in the Philippines, the United Arab
Emirates and Austria could not be viewed in isolation (see paragraph 89 above). However, even if the alleged
events were taken together, for the following reasons, the Court considers that there is no indication that the
authorities failed to comply with their duty of investigation. The Austrian authorities were only alerted approximately
one year after the events in Vienna, when the applicants' employers had long left Austria and had presumably
returned to Dubai. Therefore, the only further steps the authorities could possibly have taken were: requesting legal
assistance from the United Arab Emirates; attempting to question the applicants' employers by means of letters of
request, hence giving them the opportunity to make a statement in their defence; and issuing an order to determine
their whereabouts (zur Aufenthaltsbestimmung ausschreiben) under Article 197 of the CCP (see paragraph 38
above). From the information submitted, the Court considers that the authorities could not have had any reasonable
expectation of even being able to confront the applicants' employers with the allegations made against them, as no
mutual legal assistance agreement exists between Austria and the United Arab Emirates. In this regard, the
Government referred to their experience that even simple requests for legal assistance had been refused in the


-----

past without discernible reason (see paragraph 101 above). It does not appear that the steps described above,
albeit possible in theory, would have had any reasonable prospects of success and would therefore have been
required. In addition, the Court emphasises that, under Austrian law, the public prosecutor's office has a certain
margin of appreciation – based on the principle of proportionality – when deciding which cases to pursue and which
to discontinue (Article 210 of the CCP, see paragraph 39 above). Moreover, in accordance with Article 197 of the
CCP (see paragraph 38 above), it is not possible to conduct criminal proceedings in the absence of the accused.
Lastly, in accordance with Article 193 § 2 of the CCP (see paragraph 37 above), the public prosecutor can – within
the statute of limitations – reopen and continue the investigation into the applicants' allegations if there are legal
and factual grounds to do so. The foregoing considerations enable the Court to conclude that the investigation
conducted by the Austrian authorities in the applicants' case was sufficient for the purposes of Article 4 of the
Convention.
_(iii) Conclusion_

118. In the light of the above, the Court considers that the Austrian authorities complied with their duty to protect the
applicants as (potential) victims of human trafficking. In finding that they did not have jurisdiction over the alleged
offences committed abroad, and in deciding to discontinue the investigation into the applicants' case concerning the
events in Austria, they did not breach their positive obligation under the procedural limb of Article 4 of the
Convention.

Therefore, there has been no violation of that provision.
_III. ALLEGED VIOLATION OF ARTICLE 3 OF THE CONVENTION_

119. The applicants further submitted that the treatment they had suffered met the minimum level of severity under
Article 3 of the Convention, and that there had been a breach of the respondent State's procedural obligation to
duly investigate their case. Article 3 reads:

“No one shall be subjected to torture or to inhuman or degrading treatment or punishment.”

120. The Court notes that this complaint is linked to the one examined above, and must therefore likewise be
declared admissible.

121. The applicants submitted in their observations that, strictly speaking, it would be unnecessary to consider the
same set of facts under Article 3 if the Court examined the failure to investigate under Article 4 of the Convention.

122. The Government submitted essentially the same observations in relation to the applicants' complaints under
Articles 3 and 4 of the Convention (see paragraphs 78-102 above).

123. In line with the applicants' submissions, the Court considers that the test of the State's positive obligations
under the procedural limb of Article 3 of the Convention is very similar to that under Article 4, which has been
comprehensively examined above (compare, for example, Jeronovičs v. Latvia [GC], no. 44898/10, § 107, 5 July
2016 in relation to Articles 2 and 3, and Rantsev, cited above, §§ 232, 288-89 and 299-300 in relation to Article 4).

For essentially the same reasons (see paragraphs 112‑18 above), the Court concludes that there has been no

violation of the State's positive obligations under Article 3 of the Convention.
_IV. OTHER ALLEGED VIOLATIONS OF THE CONVENTION_

124. The applicants submitted that, even though in their specific case Austria had identified them as victims of
human trafficking, the lack of a formal recognition system was in itself capable of giving rise to a breach of Article 8
of the Convention.

125. As the Court has set out in its findings concerning Article 4 of the Convention, it is satisfied that the applicants
have been treated as (potential) victims of trafficking in human beings, in line with Austria's domestic and
international legal obligations (see paragraphs 110-11 above). In the light of all the material in its possession, and in
so far as the matters complained of are within its competence, the Court finds no appearance of a violation of the
rights and freedoms set out in the Convention or its Protocols arising from this complaint. It must therefore be
declared inadmissible pursuant to Article 35 §§ 3 and 4 of the Convention


-----

**FOR THESE REASONS, THE COURT, UNANIMOUSLY,**

1. Decides to strike out of the list the application lodged by the third applicant;

2. _Declares the complaints lodged by the first and second applicants under Articles 3 and 4 of the Convention_
admissible, and the remainder of their application inadmissible;

3. Holds that there has been no violation of Article 4 of the Convention;

4. Holds that there has been no violation of Article 3 of the Convention.

Done in English, and notified in writing on 17 January 2017, pursuant to Rule 77 §§ 2 and 3 of the Rules of Court.

In accordance with Article 45 § 2 of the Convention and Rule 74 § 2 of the Rules of Court, the concurring opinion of
Judge Pinto de Albuquerque, joined by Judge Tsotsoria, is annexed to this judgment.
**CONCURRING OPINION OF JUDGE PINTO DE ALBUQUERQUE, JOINED BY JUDGE TSOTSORIA**

Table of Contents

I. Introduction (§ 1) 33

First Part (§§ 2-40) 34

II. The world response to forced labour and trafficking for that purpose (§§ 2-21) 34

A. In international human rights law (§§ 2-8) 34

B. In international labour law (§§ 9-13) 40

C. In international criminal and humanitarian law (§§ 14-21) 43

III. The regional response to forced labour and trafficking for that purpose (§§ 22-40) 49

A. In general (§§ 22-26) 49

B. Within the European Union (§§ 27-31) 51

C. Within the Council of Europe (§§ 32-40) 53

Second Part (§§ 41-59) 61

IV. The respondent State's obligations (§§ 41-52) 61

A. The international obligation to criminalise and prosecute forced labour (§§ 41-42) 61

B. The international obligation to criminalise and prosecute trafficking in human beings (§§ 44-52) 62

V. Application of the legal framework to the facts of the case (§§ 53-59) 67

A. The substantive reasons for discontinuance (§§ 53-55) 67

B. The procedural reasons for discontinuance (§§ 56-59) 68

VI. Conclusion (§§ 60-61) 69

_I. Introduction (§ 1)_

1. I concur with the Chamber, but I am not satisfied with the reasoning of the judgment, for two reasons. First, it did
not engage with the constituent elements of the offence of trafficking in human beings and its distinguishable
features from slavery, servitude and forced labour. Second, it did not properly analyse the respondent State's
international obligations in the present case. This opinion pursues those objectives, against the background of a
critical reflection on the global and regional response to the scourge of forced labour and trafficking for that
purpose. The reflection will be carried out at the point of intersection of international human rights law, international
labour law and international criminal and humanitarian law, with a concomitant overview of the Inter-American,
African, Asian, European Union and Council of Europe systems of combating trafficking in human beings.
_First Part (§§ 2-40)II. The world response to forced labour and trafficking for that purpose (§§ 2-21)A. In_
_international human rights law (§§ 2-8)_

2. Since the beginning of the twentieth century, forced labour and trafficking in human beings for that purpose[1] are
prohibited in line with the constant practice of the States both domestically and internationally. According to the
United Nations Office on Drugs and Crime (UNODC), human trafficking is a criminal offence in 146 countries in the
world, but there are still two billion people who lack full legal protection against this offence[2].


-----

The international obligation to prohibit, criminalise and punish slavery and forced labour and the trafficking in human
beings for that purpose is set out in the Mandates for Class B and C territories of the League of Nations mandatory
system for the administration of certain non-European territories; Article 6 of the 1926 Convention to Suppress the
Slave Trade and Slavery (“the Slavery Convention”)[3] and Article 6 (1) of its 1956 Supplementary Convention[4];
Article 25 of the 1930 International Labour Organisation (ILO) Convention concerning Forced or Compulsory Labour
(No. 29)[5]; Article 6 (b) and (c) of the Charter of the International Military Tribunal (“the Nuremberg Charter”); Article
4 of 1948 Universal Declaration of Human Rights (UDHR); Article 4 of the 1950 European Convention on Human
Rights (“the Convention”); Article 6 of the 1957 ILO Convention concerning the Abolition of Forced Labour (No.
105)[6]; Article 13 of the 1958 Convention on the High Sea[7]; Article 8 of the 1966 International Covenant on Civil and
Political Rights (ICCPR); Article 6 of the 1969 American Convention on Human Rights (ACHR)[8]; Article 4 (2) (f) of
the Additional Protocol II to the Geneva Conventions[9]; Article 5 of the 1981 African Charter on Human and Peoples'
Rights (ACHPR)[10]; Article 99 of 1982 Convention on the Law of the Sea[11]; Articles 32 and 36 of the 1989
Convention on the Rights of the Child (CRC)[12]; Article 11 of the 1990 International Convention on the Protection of
the Rights of All Migrant Workers and Members of Their Families (ICPRMW)[13]; Article 15 of the 1990 African
Charter on the Rights and Welfare of the Child (ACRWC)[14]; Article 5 (c) of the 1993 International Criminal Tribunal
for the former Yugoslavia (ICTY) Statute; Article 7 of the 1994 Inter-American Convention on International Traffic in
Minors[15]; Article 3 (c) of the 1994 International Criminal Tribunal for Rwanda (ICTR) Statute; Article 4 of the 1995
Commonwealth of Independent States (CIS) Convention on Human Rights and Fundamental Freedoms (the “CIS
Convention”)[16]; Article 7 § 2 (c) of the 1998 Statute of the International Criminal Court (“the Rome Statute”)[17]; Article
7 of the 1999 ILO Worst Forms of Child Labour Convention (No. 182)[18]; Article 5 of the 2000 Protocol to Prevent,
Suppress and Punish Trafficking in Persons, Especially Women and Children (“the Palermo Protocol”)[19]; Article 2 of
the 2000 Optional Protocol to the Convention on the Rights of the Child on the sale of children, child prostitution
and child pornography[20]; Article 5 (3) of the European Union (EU) 2000 Charter on Fundamental Rights[21]; Article 2
(c) of the 2002 Statute for the Special Court for Sierra Leone; Article 1 of the Council of the European Union
Framework Decision of 19 July 2002 on combating trafficking in human beings; Article 10 of the 2004 Arab Charter
on Human Rights (ArCHR)[22]; Article 19 of the 2005 Council of Europe's Convention on Action Against Trafficking in

Human Beings (“the Anti‑Trafficking Convention”)[23]; Article 27 (2) of the 2006 Convention on the Rights of Persons

with Disabilities (CRPD)[24]; Article 9 (1) (d) of the 2009 African Union Convention for the Protection and Assistance
of Internally Displaced Persons in Africa[25]; Article 3 (2) (b) of the 2011 ILO Convention Concerning Decent Work for
Domestic Workers (No. 189)[26]; Article 2 of Directive 2011/36/EU of the European Parliament and of the Council of 5
April 2011 on preventing and combating trafficking in human beings and protecting its victims; and Article 5 of the
2015 Association of Southeast Asian Nations (ASEAN) Convention Against Trafficking in Persons, Especially
Women and Children[27].

3. The question of forced labour was first brought within the sphere of international consideration on the occasion of
the adoption of the 1920 Covenant of the League of Nations and of the mandatory system there outlined for the
administration of the non-European territories detached from the former German and Turkish Empires. In Article 23
of the 1920 Covenant of the League of Nations the members endeavoured to secure and maintain fair and humane
conditions of labour for men, women and children, both in their own countries and in all countries to which their
commercial and industrial relations extend, and for that purpose to establish and maintain the necessary
international organisations. They also undertook to secure just treatment of the native inhabitants of territories
under their control. Furthermore, they entrusted the League with the general supervision over the execution of
agreements with regard to the traffic in women and children. In addition, the terms of the Mandate for Class B
territories provided for a prohibition of “all forms of forced or compulsory labour, except for essential public works
and services, and then only in return for adequate remuneration.”[28] A similar prohibition was included in the
Mandate for Class C territories.

4. In 1926, Article I of the Slavery Convention defined slavery as “the status or condition of a person over whom any
or all of the powers attaching to the right of ownership are exercised.” The concept included the de jure possession
or the _de facto exercise of powers over a person attaching to the right of ownership[29]. Article 5 recognised that_
recourse to forced labour may have grave consequences. Therefore, the High Contracting Parties undertook the
obligation to take all necessary measures to prevent compulsory or forced labour from developing into conditions
analogous to slavery. Nevertheless, forced labour was admitted when exacted for public purposes. In territories in


-----

which compulsory or forced labour for other than public purposes still survived, the High Contracting Parties should
endeavour progressively and as soon as possible to put an end to the practice. So long as such forced or
compulsory labour existed, this labour should invariably be of an exceptional nature, should always receive
adequate remuneration, and should not involve the removal of the labourers from their usual place of residence. In
Article 6, the High Contracting Parties undertook the obligation to adopt the necessary measures to ensure that
severe penalties could be imposed in respect of any infractions of laws and regulations enacted with a view to
giving effect to the purposes of the Slavery Convention.

5. Article 4 of the UDHR proclaimed that “No one shall be held in slavery or servitude; slavery and the slave trade
shall be prohibited in all their forms.”[30] Article 23 (1) acknowledged “the right to work, to free choice of employment,
to just and favourable conditions of work and to protection against unemployment”. No reference was made to
forced labour, because it was understood that it fell under the purview of servitude[31].

6. In 1956, the States Parties to the Convention of 1926, which remained operative, decided that it should be
complemented with the conclusion of a supplementary convention designed to intensify national as well as
international efforts towards the abolition of slavery, the slave trade and institutions and practices similar to slavery.
Article 1 of the 1956 Supplementary Convention on the Abolition of Slavery imposed (“shall”) the obligation to take
all practicable and necessary legislative and other measures to bring about progressively and as soon as possible
the complete abolition or abandonment of the following institutions and practices similar to slavery, where they still
existed[32]: debt bondage[33], serfdom, servile forms of marriage and sale or adoption of a child for exploitation. These

slavery‑like practices constitute different forms of servitude[34]. Articles 3 and 6 established the obligation to

criminalise slave trade and enslavement, including attempt, accessory and conspiracy forms. Article 7 defined
slavery, servile status and slave trade.

7. Article 8 of the ICCPR prohibited slavery, the slave trade, servitude and forced or compulsory labour[35]. Contrary
to the UDHR, the drafters of the ICCPR considered that slavery and servitude were two different concepts and
therefore should be dealt with in different paragraphs[36]. Such prohibition did not preclude, in countries where
imprisonment with hard labour may be imposed as a punishment for a crime, the performance of hard labour in
pursuance of a sentence to such punishment by a competent court[37]. Moreover, other forms of work or service were
excluded from the scope of the prohibition[38]. Article 4 (2) allowed no derogation to the prohibition of slavery, slave
trade and servitude[39]. The UNHRC interpreted this provision in the light of the recent codification of crimes against
humanity in the Rome Statute by ascribing non-derogable status to the prohibition of conducts punishable under the
Rome Statute as a crime against humanity, which includes forced labour as a form of enslavement[40].

8. Article 11 of the CRC committed the Contracting Parties to take measures to combat the illicit transfer and nonreturn of children abroad[41]. Article 32 of the CRC recognised the right of the child to be protected from economic
exploitation and from performing any work that is likely to be hazardous or to interfere with the child's education, or
to be harmful to the child's health or physical, mental, spiritual, moral or social development. The Parties undertook
the obligation to take legislative, administrative, social and educational measures to provide for a minimum age for
admission to employment, appropriate regulation of the hours and conditions of employment and appropriate
penalties or other sanctions to ensure the effective enforcement of these rules. Article 34 was devoted to the
protection of children from all forms of sexual exploitation and sexual abuse, Article 35 to the prevention of
abduction of, the sale of or traffic in children for any purpose or in any form and Article 36 to the protection of
children against all other forms of exploitation prejudicial to any aspects of the child's welfare.

The Optional Protocol complemented this framework, by prohibiting the sale of children, child prostitution and child
pornography and imposing on States Parties an obligation to criminalise such conducts whether they are committed
domestically or transnationally or on an individual or organised basis. The sale of a child consists in any act or
transaction whereby a child is transferred by any person or group of persons to another for remuneration or any
other consideration. International commercial surrogacy with an exploitative intent also falls within the international
legal definition of sale of children[42].


-----

Finally, in Article 27 (2) of the CRPD the States Parties undertook the obligation to ensure that persons with
disabilities are not held in slavery or in servitude, and are protected, on an equal basis with others, from forced or
compulsory labour.
_B. In international labour law (§§ 9-13)_

9. The form of exploitation that is of particular concern to the ILO is forced labour. Conventions No. 29 and No. 105
are the primary ILO instruments aimed at the prohibition and elimination of forced or compulsory labour. According
to the ILO Declaration on Fundamental Principles and Rights at Work of 1998, all ILO member States have an
obligation, even if they have not ratified the ILO Conventions in question, to respect, promote and realise the
principle of the elimination of all forms of forced or compulsory labour and the effective abolition of child labour. The
right not to be subjected to forced or compulsory labour and to child labour applies to all people in all States, and
particularly to groups with special needs, such as the unemployed and migrant workers[43].

Article 2 of the 1930 ILO Convention concerning Forced or Compulsory Labour defined forced or compulsory labour
as “all work or service which is exacted from any person under the menace of any penalty and for which the said
person has not offered himself voluntarily.” Certain forms of labour were excluded from the meaning of the term
forced labour. Articles 20 and 21 proscribed absolutely forced labour as a form of collective punishment and forced
labour in undergrounds mines. Article 25 set out the obligation to criminalise the illegal exaction of forced or
compulsory labour[44].

A forced labour situation is determined by the nature of the relationship between a person and the “employer”, and
not by the type of activity performed, the legality or illegality of the activity under national law, nor its recognition as
an “economic activity”. The exaction of labour under the threat of a penalty is the characteristic feature of this
relationship[45]. Forced labour thus includes forced prostitution, forced begging, forced criminal activity, forced use of
a person in an armed conflict, ritual or ceremonial servitude, forced use of women as surrogate mothers, forced
pregnancy and illicit conduct of biomedical research on a person[46].

10. In Article 1 of the 1957 ILO Convention concerning the Abolition of Forced Labour, the Contracting Parties
undertook the obligation to suppress in all instances and not to make use of any form of forced or compulsory
labour, as a means of political coercion or education or as a punishment for holding or expressing political views or
views ideologically opposed to the established political, social or economic system; as a method of mobilising and
using labour for purposes of economic development; as a means of labour discipline; as a punishment for having
participated in strikes; and as a means of racial, social, national or religious discrimination. This obligation was
meant to narrow the scope of the exceptions of Article 2 (2) of the 1930 Convention[47].

11. Article 7 of the 1999 Worst Forms of Child Labour Convention established the obligation to sanction, namely
with penal sanctions, the worst forms of child labour, comprising the following conducts[48]: all forms of slavery or
practices similar to slavery, such as the sale and trafficking of children, debt bondage and serfdom and forced or
compulsory labour, including forced or compulsory recruitment of children for use in armed conflict; the use,
procuring or offering of a child for prostitution, for the production of pornography or for pornographic performances;
the use, procuring or offering of a child for illicit activities, in particular for the production and trafficking of drugs as
defined in the relevant international treaties; and work which, by its nature or the circumstances in which it is carried
out, is likely to harm the health, safety or morals of children.

12. In Article 3 of the 2011 ILO Convention Concerning Decent Work for Domestic Workers, the Contracting Parties
undertook the obligation to take measures to ensure the effective promotion and protection of the human rights of
all domestic workers, namely to respect, promote and realise the fundamental principles and rights at work, such as
the elimination of all forms of forced or compulsory labour.

13. The ILO has developed six indicators of forced labour which provide a valuable benchmark in the identification
of forced labour[49]. These indicators are the threat or actual physical violence towards the victim, the restriction of
movement of workers, debt bondage, the withholding of wages, the retention of passports or identity documents
and the threat of denunciation to the authorities, where the worker is in an irregular immigration status. The
seemingly “voluntary offer” of the worker may have been manipulated or was not based on an informed decision. A
t i ti l i j b h th k f l d t t it b id d f d l b 50


-----

The ILO recommends that trafficking be codified as an offence independently of cross-border movement and the
involvement of organised crime, forced labour be criminalised in anti-trafficking laws and the types of coercion used
be defined, the circumstances in which consent is not relevant be specified and finally that prosecution should lead
not only to criminalisation, but also to reinstatement of rights of the victim, financial compensation, and, most
importantly, to confiscation of assets[51]. Specifically regarding domestic workers, the ILO recommends the limitation
of the hours of domestic work by specifying: (a) a 40-hour work week, with adequate remuneration for overtime
work; (b) the specification of the maximum hours of work permitted per day; (c) a fixed uninterrupted rest period of
eight hours per day; (d) a limitation on the hours spent “on call” and adequate remuneration for those hours. Proper
procedures for termination of employment should be guaranteed[52].
_C. In international criminal and humanitarian law (§§ 14-21)_

14. Deportation to slave labour and enslavement were listed as a war crime and a crime against humanity,
respectively, in Article 6 (b) and (c) of the Nuremberg Charter. After the Second World War, the US Military Tribunal
Nuremberg found, in the Pohl et al. case, that prisoners in the Nazi concentration camps were in a state of slavery
and those responsible for these camps were guilty of war crimes and crimes against humanity[53].

Article 52 of the Third Geneva Convention provided that prisoners of war should not be compelled to carry out
unhealthy, dangerous or humiliating work. Article 4 (2) (f) of the Additional Protocol II to the Geneva Conventions
prohibited at any time and in any place slavery and slave trade in all their forms of persons who do not take direct
part or have ceased to take part in hostilities[54].

15. Article 5 (c) of the ICTY Statute included within the Tribunal's remit enslavement as a crime against humanity
when committed in armed conflict, whether international or internal in character, and directed against any civilian
population. Article 3 (c) of the ICTR Statute provided for the same punishment for enslavement when committed as
part of a widespread or systematic attack against any civilian population on national, political, ethnic, racial or
religious grounds[55].

In the Kunarac et al. case, the Trial Chamber of the ICTY stated in February 2001 that “at the time relevant to the
indictment, enslavement as a crime against humanity in customary international law consisted of the exercise of
any or all of the powers attaching to the right of ownership over a person.” The Chamber admitted that this definition
“may be broader than the traditional and sometimes apparently distinct definitions of either slavery, the slave trade
and servitude or forced or compulsory labour found in other areas of international law.” On the basis of various
cases from the Second World War and the International Law Commission work, the Chamber concluded that forced
or compulsory labour should be included “under enslavement as a crime against humanity.”[ 56]

16. Under Article 7 § 2 (c) of the Rome Statute, enslavement means “the exercise of any or all of the powers
attaching to the right of ownership over a person and includes the exercise of such power in the course of trafficking
in persons, in particular women and children.” The Elements of Crimes to the Rome Statute further clarified that
exercising any or all powers attaching to the right of ownership over one or more persons includes the following:

“purchasing, selling, lending or bartering such a person or persons, or by imposing on them a similar
deprivation of liberty. … It is understood that such deprivation of liberty may, in some circumstances, include
exacting forced labour or otherwise reducing a person to a servile status as defined in the Supplementary
Convention on the Abolition of Slavery, the Slave Trade, and Institutions and Practices Similar to Slavery of
1956. It is also understood that the conduct described in this element includes trafficking in persons, in
particular women and children.”

Comparing the concepts of slavery set out in international law in 1926, 1956 and 1998, and applied in the Pohl et al.
judgment in 1947, and the concept of enslavement as posited in the ICTY Statute and applied for the first time by
the Trial and the Appeals Chambers in the _Kunarac et al. case, one permanent element stands out: the powers_
attaching to the right of ownership. This is the sine qua non element of the concept of slavery or enslavement in
international law. Both the _de jure possession or the_ _de facto exercise of these powers suffices to define the_
concept.


-----

17. The Palermo Protocol presents the first internationally agreed definition of trafficking in persons[57]. Its Article 5
requires the criminalisation of the intentional recruitment, transportation, transfer, harbouring or receipt of persons,
by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse
of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve the consent
of a person having control over another person, for the purpose of exploitation[58]. The Protocol offers a list of
exploitative forms, rather than defining exploitation itself. Exploitation shall include, at a minimum[59], the exploitation
of the prostitution of others or other forms of sexual exploitation, forced labour or services[60], slavery or practices
similar to slavery, servitude or the removal of organs[61]. These concepts are to be understood according to their
meaning in international law, as follows from Article 14 of the Protocol. The recruitment, transportation, transfer,
harbouring or receipt of a child for the purpose of exploitation shall be considered as trafficking in persons even if
this does not involve any of the above mentioned means. The consent of a victim of trafficking in persons to the
intended exploitation is irrelevant when any of those means have been used[62]. The use of impermissible means
imply the involuntariness of the victim's conduct. Thus, trafficking in human beings is different from the crime of
human smuggling as the unlawful cross-border transport in order to obtain, directly or indirectly, a financial or other
material benefit, with the consent of the smuggled person[63].

18. Hence, in international criminal law there are essentially four elements to the offence of trafficking in persons[64]:

the actus reus: recruitment, transportation, transfer, harbouring or receipt of persons;

the means: threat or use of force or other forms of coercion[65], abduction, fraud, deception[66], abuse of power or of a
position of vulnerability[67] or the giving or receiving of payments or benefits to achieve the consent of a person
having control over another person;

the (general) mens rea: to intend to recruit, transport, transfer, harbour or receipt persons;

and the (specific) mens rea: for the purpose of exploitation.

19. The actus reus must be a positive act or conduct, which may be of continuing nature (for example: to transport,
to transfer, to harbour someone). The breadth of the actus reus includes all stages of the trafficking process and
brings within the reach of the offence recruiters, brokers, transporters, but also the owners, managers, supervisors
and controllers of any exploitation place, whenever they were involved themselves in the supply chain into
exploitation. But the trafficking offence is not applicable to situations of exploitation where the final exploiter did not
intervene in the trafficking process.

Negligent conduct is not punishable[68]. A mistake of fact is a ground for excluding criminal responsibility only if it
negates the mental element required by the crime[69]. Since enslavement, forced labour and trafficking for those
purposes are crimes against humanity, a mistake of law as to whether a particular type of conduct is a crime does
not exclude the mental element required by such crimes and any orders to commit such offences are manifestly
unlawful[70].

20. The Protocol obligation is to criminalise trafficking as a combination of the constituent elements and not the
elements themselves[71]. The blameworthiness and the punishment of the trafficking offence should reflect the
gravity of the means utilised, in accordance with Article 11 of the United Nations Convention against Transnational
Organized Crime, which the Protocol supplements. Hence, when the use of one of the listed impermissible means
constitutes per se an offence, such as the threat or use of force, the trafficking offence consumes, in principle, the
means-offence and the effective punishment of the trafficking offence does not warrant the concurrent punishment
of the means-offence, save when the means-offence is punishable with a higher penalty than the trafficking offence
itself. In this case, only the means-offence should be punished, in order to avoid an excessive, double punishment
of the same unlawful conduct.

Punishment is not dependent on the fact that exploitation occurs[72]. In other words, it is not necessary for the
completion of the trafficking offence that the trafficked person be actually exploited, i.e. submitted to forced
prostitution, forced labour, slavery, practices similar to slavery, servitude or removal of organs. In view of the
instrumental link between human trafficking and exploitation, the effective punishment of the latter does not warrant


-----

the concurrent punishment of the former, save when the specific form of exploitation constitutes per se an offence
(such as forced removal of organs) punishable with a lesser penalty than trafficking. In this case, only the trafficking
offence should be punished, in order to avoid an excessive double punishment of the same unlawful conduct.

The obligation to criminalise includes participating as an accomplice in an offence, organising or directing other
persons to commit an offence and, subject to the basic concepts of its legal system, attempting to commit an
offence. The obligation applies to both natural persons and legal persons, though in the case of the latter the liability
established need not necessarily be “criminal” liability. The scope of the Protocol limits the criminalisation obligation
to instances where human trafficking is transnational in nature and involves an organised criminal group[73]. But
neither transnationality nor participation in a criminal organisation are elements of the offence[74]. In transnational
exploitation cases, the standards that should be taken into account when considering whether a situation is
exploitative are those of the host country, not those of the country of origin, otherwise the incentive for crime would
remain. The existence of bad living or working conditions, or the violation of labour law in the host country, is
certainly a strong element indicative of a situation of exploitation.

21. In sum, the Protocol does not require that the exploitation be made a criminal offence in and of itself. It does not
impose the obligation to criminalise forced labour. In this context it should be noted that not all forced labour results
from trafficking in persons: according to ILO, about 20 per cent of all forced labour results from trafficking.
Legislation against any exploitation of human beings under forced or slavery-like conditions as an autonomous
offence will therefore be needed no matter how people arrive in these conditions, that is, independently of the
presence of the other elements of the trafficking offence[75]. This is also imposed by the above-mentioned
international human rights law instruments, which clearly prohibit the use of slavery, slavery-like practices and
forced labour.
_III. The regional response to forced labour and trafficking for that purpose (§§ 22-40)A. In general (§§ 22-26)_

22. Article 6 of the ACHR prohibited all forms of slavery, involuntary servitude, slave trade, traffic in women and
forced or compulsory labour. In those countries in which the penalty established for certain crimes is deprivation of
liberty at forced labour, the execution of such a sentence imposed by a competent court is permitted, but “forced
labour shall not adversely affect the dignity or the physical or intellectual capacity of the prisoner”. The provision
also excluded certain forms of work or service from the meaning of forced or compulsory labour[76]. Article 27 (2) did
not permit any derogation to this prohibition, including in time of war, public danger, or other emergency that
threatens the independence or security of a State Party.

23. In Article 7 of the Inter-American Convention on International Traffic in Minors, the States Parties undertook to
adopt effective measures, under their domestic law, to prevent and severely punish the abduction, removal or
retention, or attempted abduction, removal or retention, of a minor for unlawful purposes or by unlawful means.
"Unlawful purpose" includes, among others, prostitution, sexual exploitation, servitude or any other purpose
unlawful in either the State of the minor's habitual residence or the State Party where the minor is located. "Unlawful
means" includes, among others, kidnaping, fraudulent or coerced consent, the giving or receipt of unlawful
payments or benefits to achieve the consent of the parents, persons or institution having care of the child, or any
other means unlawful in either the State of the minor's habitual residence or the State Party where the minor is
located. Conduct with unlawful purpose does not warrant unlawful means to be used, and vice-versa.

24. Article 5 of the ACHPR prohibited all forms of exploitation and degradation of man, particularly slavery, slave
trade, torture, cruel, inhuman or degrading punishment and treatment[77]. In a judgment on the _wahiya or_ _sadaka_
customary practice, the Economic Community of West African States (ECOWAS) Court of Justice stated the
following:

“Under Nigerien criminal law, as in international instruments, the prohibition and repression of slavery are
absolute and of public order. As stated by the International Court of Justice in the Barcelona Traction judgment
(5 February 1970), 'the outlawing of slavery is an obligation erga omnes imposed on all State's organs.'”[78].

Article 15 of the ACRWC protected every child from all forms of economic exploitation and from performing any
work that is likely to be hazardous or to interfere with the child's physical, mental, spiritual, moral, or social
d l t It f th i d St t P ti t t k ll i t l i l ti d d i i t ti t


-----

ensure the full implementation of this Article which covers both the formal and informal sectors of employment.
Having regard to the relevant provisions of the ILO's instruments relating to children, States Parties shall in
particular (a) provide through legislation, minimum wages for admission to every employment; (b) provide for
appropriate regulation of hours and conditions of employment; (c) provide for appropriate penalties or other
sanctions to ensure the effective enforcement of this Article; (d) promote the dissemination of information on the
hazards of child labour to all sectors of the community. More recently, Article 9 of the ArCHR prohibited trafficking in
human organs and trafficking for the use of medical experimentation and Article 10 “all forms of slavery and
trafficking in human beings”[79]. Finally, Article 9 (1) (d) of the African Union Convention for the Protection and
Assistance of Internally Displaced Persons in Africa protected the right of these persons not to be subjected to
forced labour.

25. Article 4 of the CIS Convention prohibited slavery, servitude and forced or compulsory labour, but excluded from
the meaning of this term certain forms of work or service. Article 35 did not allow for any derogation from Article 4
(paragraph 1) - the prohibition of torture and servitude. The CIS also approved the Program of Cooperation in
Combating Trafficking in Human Beings for 2010-2012 and CIS Model legislation[80]. In April 2012, a Round Table on
Combating Trafficking in Human Beings was organised jointly by the Council of Europe, the Organisation for

Security and Co‑operation in Europe (OSCE), the Interparliamentary Assembly of the CIS and the CIS Executive

Committee, in St. Petersburg, Russian Federation[81]. The Round Table created a new platform for developing

co‑operation between the Council of Europe, the OSCE and the CIS, with a view to collecting and exchanging good

practices.

Article 5 of the ASEAN Convention Against Trafficking in Persons, Especially Women and Children, which is not yet
in force, established the obligation to criminalise trafficking in human beings with the same scope as the Palermo
Protocol[82].

26. The OSCE political anti-trafficking commitments taken since 2000 by consensus at the annual meetings of the
OSCE Ministerial Council and agreed upon by the participating States constitute a comprehensive political
framework for action against trafficking in human beings[83]. In 2003, the OSCE approved an Action Plan to Combat
Trafficking in Human Beings and set up the Office and post of Special Representative and Co-ordinator for
Combating Trafficking in Human Beings to help participating States develop and implement effective policies.
_B. Within the European Union (§§ 27-31)_

27. Within the European Union, trafficking in human beings was initially associated with forced prostitution and the
sexual exploitation of minors. The annex to the Europol Convention[84] already contained the following definition of
trafficking for the purpose of sexual exploitation: “traffic in human beings: means subjection of a person to the real
and illegal sway of other persons by using violence or menaces or by abuse of authority or intrigue with a view to
the exploitation of prostitution, forms of sexual exploitation and assault of minors or trade in abandoned children”.

28. On 18 January 1996, the European Parliament adopted a Resolution on trafficking in human beings. The
following year, the Council of the European Union adopted the Joint Action 97/154/JHA on 24 February 1997
concerning action to combat trafficking in human beings and sexual exploitation of children, which referred to “any
behaviour which facilitates the entry into, transit through, residence in or exit from the territory of a Member State for
gainful purposes with a view to the sexual exploitation or abuse of the adults or children involved”.

29. Following the prohibition of trafficking in human beings by Article 5 (3) of the EU Charter on Fundamental
Rights[85], the Council of the European Union approved the Framework Decision of 19 July 2002 on combating
trafficking in human beings, which superseded the Joint Action[86]. The obligation to criminalise trafficking was
modelled on the Palermo Protocol, with the following relevant differences: vulnerability was defined as a situation
“which is such that the person has no real and acceptable alternative but to submit to the abuse involved”; the
exhaustive list of purposes of the action included compulsory labour and pornography, but not removal of organs; a
rule on the proportionate and dissuasive character of penalties was inserted; and aggravated offences were also
foreseen.


-----

30. Some years later, Directive 2004/81/EC set out the legal framework for granting residence permits to non-EU
victims of trafficking[87] and Directive 2009/52/EC outlined the framework for Member States to issue sanctions
against employers who knowingly employ illegally staying third country workers[88]. In 2010, the European
Commission appointed an EU Anti-Trafficking Coordinator in order to improve coordination amongst EU institutions,
its agencies, Member States and international actors in implementing EU legislation and policy against trafficking in
human beings, following a call by the European Parliament Resolution on preventing trafficking in human beings,
approved that same year[89].

31. Finally, Directive 2011/36/EU on preventing and combating trafficking in human beings and protecting its victims
replaced the Framework Decision, adopting an integrated, holistic, and “low-threshold” human rights approach to
the fight against trafficking in human beings and a contextual, gender- and child-sensitive understanding of the
different forms of trafficking and aiming at ensuring that each form is tackled by means of the most efficient
measures[90]. The Directive's most important novelty was its broader concept of trafficking in human beings as
compared with the Framework Decision, which included additional forms of purposive exploitation, such as forced
begging, forced criminal activities (as in the case of, inter alia, pick-pocketing, shop-lifting, drug trafficking and other
similar activities which are subject to penalties and involve financial gain), forced removal of organs, illegal adoption
or forced marriage. Immediately after the publication of the Directive the EU Strategy towards the Eradication of
Trafficking in Human Beings 2012-2016 was launched.
_C. Within the Council of Europe (§§ 32-40)_

32. The Convention prohibits slavery and servitude[91]. It also prohibits forced and compulsory labour while excluding
certain forms of work and service from this term[92]. In the landmark Van der Mussele case[93], the Court noted that
this paragraph

“is not intended to 'limit' the exercise of the right guaranteed by paragraph 2, but to 'delimit' the very content of
that right, for it forms a whole with paragraph 2 and indicates what the term 'forced or compulsory' shall not
include. This being so, paragraph 3 serves as an aid to the interpretation of paragraph 2. The four subparagraphs of paragraph 3, notwithstanding their diversity, are grounded on the governing ideas of the general
interest, social solidarity and what is normal in the ordinary course of affairs.”

The Court acknowledged the influence of the ILO Convention No. 29 on Article 4 of the Convention and considered
that the definition of the term “forced or compulsory labour” as “all work or service which is exacted from any person
under the menace of any penalty and for which the said person has not offered himself voluntarily” could provide a
starting-point for interpretation of Article 4 of the Convention.[94 ] After admitting that work is in no way limited to
manual labour[95], the Court assessed whether there had been “forced or compulsory” labour. In the Court's view,

“The first of these adjectives brings to mind the idea of physical or mental constraint, a factor that was certainly
absent in the present case. As regards the second adjective, it cannot refer just to any form of legal compulsion or
obligation. …What there has to be is work 'exacted … under the menace of any penalty' and also performed against
the will of the person concerned, that is work for which he 'has not offered himself voluntarily'.[96]

In the circumstances of the case, the mere fact of the applicant's prior consent did not warrant the conclusion that
the obligations incumbent on him in regard to legal aid did not constitute compulsory labour for the purposes of
Article 4 § 2 of the Convention. For the Court, account must necessarily also be taken of other factors, including
whether the burden imposed on the applicant was disproportionate. While remunerated work may also qualify as
forced or compulsory labour, the lack of remuneration and of reimbursement of expenses constitutes a relevant
factor when considering what is proportionate. Such a proportionality test had no correspondence in the criteria of
the 1930 ILO Convention. Notwithstanding the lack of remuneration and of reimbursement of expenses, the Court
considered that there was no compulsory labour in view of the limited number of working hours and did not address
the issue whether the notion of “normal civic obligations” extends to obligations incumbent on a specific category of
citizens by reason of the position they occupy, or the functions they are called upon to perform, in the community.

33. Article 1 (2) of the European Social Charter also prohibits forced labour, with the same scope of Article 4 of the
Convention and Article 2 of ILO Convention 29 on forced labour[97]. Forced labour is understood as “coercion of any
k t t k i t hi i h d ith t hi f l d t”[98] Th Ch t hibiti f


-----

forced or compulsory labour may be infringed, for example, by criminal punishment of seamen who abandon their
post, even when the safety of a ship or the lives or health of the people on board are not at stake[99]; obligation of
career army officers who have received several periods of training to complete a term of compulsory service that
may last up to twenty five years[100] or refusal of the right to seek early termination of their commission unless they
repay to the state at least part of the cost of their education and training[101]; too broadly defined powers of
mobilisation of the civilian population in a state of emergency, that is, “in any unforeseen situation causing
disruption of the country's economy and society”[102]; the unreasonable length of service to replace military
service[103]; the employment of prisoners by private enterprises, without the prisoners' consent and in conditions far
removed from those normally associated with a private employment relationship[104]; the imposition of non-paid
labour on employees who refuse to perform their professional obligations[105]; and “domestic slavery”[106].

34. Article 19 of the 2005 Council of Europe's Convention on Action Against Trafficking in Human Beings requires
criminalisation of the conduct as defined in Article 4, which is inspired by Article 3 of the Palermo Protocol[107]. The
offence of trafficking is explicitly acknowledged as a human rights violation and applies to all forms of trafficking in
human beings, whether national or transnational, with or without lawful entry and stay in the transit or destination
countries, whether or not connected with organised crime[108]. A provision on penalties and aggravated forms of the
offence is included. Another distinctive feature is the obligation to criminalise those knowingly using the services of
victims.

The Anti-Trafficking Convention was adopted with the aim of promoting a more human rights-centred and genderand child-sensitive approach to human trafficking than the Palermo Protocol, imposing higher standards upon
States Parties on the prevention of trafficking in human beings, on the cooperation between the States parties, and

on the protection of the rights of victims of trafficking, including recovery- and reflection period, non‑punishment, the

compensation and redress they should be afforded and the granting of a residence permit to such victims[109]. It also
instituted a monitoring mechanism (GRETA).

35. Article 37 of the 2011 Council of Europe Convention on preventing and combating violence against women and
domestic violence sets out the obligation to criminalise intentional forced marriage and the intentional conduct of
luring an adult or a child to the territory of a Party or State other than the one she or he resides for that purpose[110].
The 2014 Council of Europe Convention on Trafficking in Human Organs deviates from the Palermo Protocol
approach by addressing “trafficking in human organs” rather than trafficking in persons for removal of organs[111]. In
addition to these hard-law instruments, both the Committee of Ministers[112] and the Parliamentary Assembly of the
Council of Europe[113] focused their attention on domestic slavery, forced marriage and trafficking in human beings
offences, insisting on the need to include them in the States Parties' criminal codes.

36. In full coherence with these standards, the Court has emphasised more recently the vital importance of
combating both forced labour and traffic for that purpose. In Siliadin[114], the Chamber inferred from Article 4 of the
Convention a positive obligation incumbent on the States Parties to adopt criminal law provisions to penalise the
practices referred to in that provision and to apply them in practice[115]. Article 4 does not only imply a vertical effect
upon States parties, but also a horizontal effect in the private sphere. In a situation where the applicant was
required to perform forced labour, almost fifteen hours a day, seven days per week, the Chamber concluded that
the case at hand was not a situation of slavery “in the proper sense, in other words that Mr and Mrs B. exercised a
genuine right of legal ownership over her, thus reducing her to the status of an 'object'”[116]. Hence, the Chamber
interpreted the 1926 Slavery Convention narrowly, since this convention does not restrict the concept of slavery to
the _de jure “genuine right of legal ownership over” another person, but includes the_ _de facto “condition” of being_
subjected to the exercise of a power similar to ownership. Beyond this, the deprivation of the applicant's personal
autonomy was identified by the Chamber as servitude[117]. The element of dependency resulted from the fact that
“the applicant, who was afraid of being arrested by the police, was not in any event permitted to leave the house,
except to take the children to their classes and various activities. Thus, she had no freedom of movement and no
free time”[118].

37. In _Rantsev[119], the Chamber concluded that trafficking itself, within the meaning of Article 3(a) of the Palermo_
Protocol and Article 4(a) of the Anti-Trafficking Convention, falls within the scope of Article 4 of the Convention[120].


-----

The established definition in international law of the concept of trafficking in human beings was enshrined in
Convention law.

38. It should be noted that this ground-breaking pronouncement was not accompanied by an explanation of which
paragraph of Article 4 was applicable to trafficking in human beings, which could be relevant for the purposes of
Article 15, since this Article only refers to paragraph 1 of the Article 4. The Chamber's silence on this point can only
be fully understood in the light of its other very bold statement that Article 4 “makes no provision for exceptions and
no derogation from it is permissible under Article 15 § 2 even in the event of a public emergency threatening the life
of the nation”[121]. In a commendable, progressive interpretation of the Convention, the Chamber refused any internal
normative hierarchy between paragraphs (1) and (2) of Article 4 and any difference of treatment of these
paragraphs in a state of emergency or any other exceptional circumstance. By so doing, the Chamber not only
extended the scope of the Article 4 proscription rule to trafficking in human beings, but submitted this new
proscriptive rule to the regime of Article 15. The Chamber's interpretation followed, without citing it, the UNHRC
General Comment No. 29 progressive interpretation of Article 4 (2) of the ICCPR in the light of the recent
codification of crimes against humanity in the Rome Statute[122]. The crime of enslavement, which includes forced
labour and trafficking for that purpose, is one of such crimes.

39. Based on the Palermo Protocol and the Council of Europe Anti‑Trafficking Convention comprehensive approach

to combat trafficking which includes measures to prevent trafficking and to protect victims, in addition to measures
to punish traffickers, the Chamber went further than the Siliadin criminalisation obligation, affirming that

“it is clear from the provisions of these two instruments that the Contracting States, including almost all of the
member States of the Council of Europe, have formed the view that only a combination of measures
addressing all three aspects can be effective in the fight against trafficking. … The extent of the positive
obligations arising under Article 4 must be considered within this broader context.”[123]

The Chamber elaborated on the State obligations to protect victims. Article 4 may require a State to take
operational measures to protect victims, or potential victims, of trafficking when in the circumstances of a particular
case it has been demonstrated that the State authorities were aware, or ought to have been aware, of
“circumstances giving rise to a credible suspicion that an identified individual had been, or was at real and
immediate risk of being, trafficked or exploited”[124]. The obligation to take operational measures must, however, be
interpreted in a way which does not impose an impossible or disproportionate burden on the authorities[125].

In the Chamber's understanding, Article 4 also entails a procedural obligation for the authorities to investigate of
their own motion situations of potential trafficking.[126] Finally, in the light of the preamble to the Palermo Protocol,
member States are also subject to a duty in cross-border trafficking cases to cooperate effectively with the relevant
authorities of other States concerned in the investigation of events which occurred outside their territories.[127] The
Chamber underscored that this obligation is valid not only for host states, like Cyprus, and origination states, like
Russia, but also for transit states. Such cooperation, in the format of bilateral or multilateral agreements, is
particularly critical between countries involved in different stages of the trafficking chain[128].

40. In sum, States Parties to the Convention have the duty to criminalise forced or compulsory labour and trafficking
in human beings. For the purposes of Article 4 of the Convention, forced and compulsory labour or services shall be
interpreted within the meaning of Article 2 of the 1930 ILO Convention, as all work or service which is exacted from
any person under the menace of any penalty and for which the said person has not offered him or herself voluntarily
or, once engaged, finds that he or she cannot leave it. The concept comprises two definitional elements: the
employer's menace of a penalty and the worker's involuntariness[129]. There is no requirement regarding the legality,
duration or severity of the exacted labour. Hence, forced labour includes permanent, contingent, temporary,
occasional, incidental, intermittent, irregular or part-time forced factory work as well as forced prostitution, forced
begging, forced criminal activity, forced use of a person in an armed conflict, ritual or ceremonial servitude, forced
use of women as surrogate mothers, forced pregnancy and illicit conduct of biomedical research on a person. The
conducts described by Article 4 (3) of the Convention delimit the Convention concept of forced or compulsory labour
and, therefore, must be interpreted restrictively, in the light of the imperative prohibition of Article 1 of the 1957
Abolition of Forced Labour Convention.


-----

Forced labour and trafficking for that purpose are not to be confused with slavery, institutions or practices similar to
slavery, or servitude. Not “all forced labour is trafficking”, just as not “all trafficking is slavery”. These two
manifestations of what has been termed the “exploitation creep” must be avoided[130]. The trafficking process itself is
a preparatory stage of the ensuing exploitation and therefore is attached to each of the three proscribed conducts in
Article 4. But there can be trafficking in human beings without subsequent exploitation and there can be exploitation
without previous trafficking.

Trafficking for the purpose of forced labour is prohibited by Article 4 (2) of the Convention, since it is a preparatory
offence to the proscribed conduct. Expulsion to a country where the person faces the risk of forced labour or
trafficking for that purpose raises an issue under this provision. For the purposes of Article 4 of the Convention,
trafficking in human beings shall be interpreted within the meaning of Article 3(a) of the Palermo Protocol, Article
4(a) of the Council of Europe Anti-Trafficking Convention and Article 2 of the European Union Directive on
Preventing and Combating Trafficking in Human Beings and the Protection of Victims. Neither forced labour nor
trafficking for that purpose include per se a profit, commercial element, a transnational, border crossing component
or an organised crime connection.

For the purposes of Article 4 of the Convention, slavery should be interpreted within the meaning of Article I of the
Slavery Convention, i.e. the de jure possession or the de facto exercise of powers over a person attaching to the
right of ownership. Trafficking for the purposes of slavery (including slave trading) is prohibited by Article 4 (1) of the
Convention. Expulsion to a country where the person faces the risk of slavery or of trafficking for that purpose
raises an issue under this provision[131].

For the purposes of Article 4 of the Convention, servitude should be interpreted within the meaning of Article 7 (b) of
the 1956 Supplementary Convention on the Abolition of Slavery, which identifies victims of “practices similar to
slavery” (debt bondage, serfdom, servile forms of marriage and sale or adoption of children for exploitation) as
“persons of servile status”. Illegal adoption of a child with exploitative intent, whether for reward or not, is included
among these practices, in the light of the Interpretative Notes for the travaux préparatoires of the Palermo Protocol,
the Explanatory Report of the Council of Europe Anti-Trafficking Convention and the EU Directive 2011/36/EU.
Trafficking for the purposes of submitting a person to a servile status (i.e. practices similar to slavery) is prohibited
by Article 4 (1) of the Convention. Expulsion to a country where the person faces the risk of being submitted to such
servile status or being trafficked for that purpose raises an issue under this provision.

In the context of the horizontal application of the Convention, States have the obligation not only to criminalise
forced labour and trafficking for that purpose, bring to justice the alleged offenders and empower the victims with an
active role in the criminal proceedings, but also to prevent private actors from committing or reiterating the offence.
Such an international positive obligation must be acknowledged as reflecting a principle of customary international
law, binding on all States, in view of the broad and long-standing consensual practice and _opinio juris already_

mentioned, such as the 1998 ILO Declaration and the 2011 Survey Guidelines and other soft‑law instruments cited

above. Furthermore, this obligation is a peremptory norm with the effect that no other rule of international or
national law may derogate from it, as the Court advanced in _Rantsev, the ACHR determines and the UNHRC_
acknowledges[132]. Therefore, State inertia _vis-à-vis forced labour or trafficking in human beings for that purpose_
represents a breach of the State Party's obligation. The Court's outline of positive obligations to combat exploitation
goes beyond the framework of human trafficking, since domestic authorities have to take reasonable steps “to
remove the individual from that situation or risk” of being trafficked or exploited and “to avoid a risk of illtreatment”[133].
_Second Part (§§ 41-59)IV. The respondent State's obligations (§§ 41-52)A. The international obligation to_
_criminalise and prosecute forced labour (§§ 41-42)_

41. Treating a person like a slave and trafficking in slaves is punishable under Article 104 of the Austrian Criminal
Code (Sklavenhandel). Article 104a criminalises trafficking in human beings (Menschenhandel), for the purposes of
exploitation[134]. Article 106a makes forced marriage (Zwangsheirat) a criminal offence. Transnational prostitution
trade (Grenzüberschreitender Prostitutionshandel) is punishable under Article 217. Finally, Austria also criminalises
forced labour of foreigners ((Ausbeutung eines Fremden) – Article 116 of the Aliens' Police Law
(Fremdenpolizeigesetz))


-----

42. Article 104 of the Criminal Code applies to slavery-like practices (in eine sklavereiähnliche Lage), such as debt
bondage and servitude, whereas less severe practices of labour exploitation fall within the scope of Article 104a of
the Criminal Code[135].

43. Article 116 of the Aliens' Police Law criminalises the conduct of the agent who exploits a foreign person, with
the deliberate intention of obtaining continuous profits from the exploitation of the specific dependency of the victim
which results from the fact that he or she is either illegally in the country, does not have a valid work permit or is in
any other particular situation of dependency[136]. The dependency of a victim may also occur in a situation where he
or she can move freely, but cannot use this possibility out of fear or threat of being identified by authorities and
possibly deported[137].

Exploitation itself is not defined in law and, worse still, is not always punishable[138]. Article 104a (3) of the Criminal
Code only refers to an exhaustive list of forms of exploitation, but does not define exploitation. Exploitation of
nationals, including forced labour of nationals, is not punishable per se.
_B. The international obligation to criminalise and prosecute trafficking in human beings (§§ 44-52)_

44. Enshrined in the Criminal Code in 2004, Article 104a criminalises trafficking (Menschenhandel) as a preparatory
offence (Vorbereitungsdelikt) for forced labour and other forms of exploitation[139]. The punishability of the conduct
does not warrant the effective exploitation of the victim by the trafficker or other person[140]. It suffices that the
trafficker acts with a view to exploit the victim (Delikt mit überschiessender Innentendenz).

Since the legal interest protected by the provision is the right to liberty, the offence is included in the third chapter of
the special part of the Criminal Code (strafbaren Handlungen gegen die Freiheit)[141]. It covers both cases of national
and transnational trafficking and cases in which Austrian citizens and aliens are victims[142]. The Austrian legislator
assumed that recourse to certain specified impermissible means impairs free will, and therefore consent is
irrelevant[143]. Indeed, no causes of justification are admitted for this offence[144].

45. The elements of the offence of Article 104a of the Criminal Code (as in force at the relevant time) are the
following:

the _actus reus: recruit (anwerben)[145], house (beherbergen)[146] or otherwise accommodate (sonst aufnehmen)[147],_
transport (befördern)[148], offer (anbieten)[149] or pass to a third party (oder einem anderen weitergibt)[150];

the impermissible means (unlautere Mittel): deceit regarding the facts (Täuschung über Tatsachen); exploitation of
a position of authority (Ausnützung einer Autoritätsstellung)[151], of situations of distress (einer Zwangslage)[152], of
mental disease (einer Geisteskrankheit), or of any condition rendering the person defenceless (oder eines
_Zustands, der die Person wehrlos macht); intimidation (Einschüchterung)[153]; the granting or accepting of an_
advantage for surrendering control over that person (Gewährung oder Annahme eines Vorteils für die Übergabe der
_Herrschaft über die Person)[154];_

the (general) _mens rea: to intend to recruit, house or otherwise accommodate, transport, offer or pass to a third_
party;

and the (specific) _mens rea_ (Delikt mit erweitertem Vorsatz): for the purpose of exploitation[155], namely sexual
exploitation (sexuell), organ transplant (durch Organentnahme)[156] or labour exploitation (in ihrer Arbeitskraft
_ausgebeutet werde)[157]._

46. In its 2011 Report on Austria, GRETA made certain recommendations regarding the dissuasiveness of the
penalties provided for in Article 104(a) of the Criminal Code in the absence of any aggravating circumstances as
well as the offence of trafficking in children between the age of 14 and 18[158] and invited the Austrian authorities “to
clarify what could constitute exploitation in the field of labour, for instance by drawing a list of indicators that could
be used by the relevant authorities to detect cases of THB for the purpose of labour exploitation.”[159]

47. The Government reacted with a reform of the impugned legal provision by the Criminal Law Amendment Act
2013[160]. The basic offence (Grunddelikt) now consists in trafficking of adults, and Article 104a (5) provides for a


-----

new offence of trafficking in minors. The penalty for the basic offence was increased from up to three years'
imprisonment to between six months and five years' imprisonment. The aggravated form is punishable with
imprisonment to between one and ten years. The offence of trafficking of minors is punishable by a prison sentence
of between one year and ten years, but has no aggravated form[161].

48. Two news forms of exploitation are explicitly included: begging[162] and benefiting from criminal activities
committed by other persons[163]. The exhaustive list of impermissible means set out in Article 104a (3) was
broadened, but there is still no open-ended reference to other forms of coercion, including abduction. The former
aggravated offence of trafficking with use of force and dangerous threat (der Einsatz von Gewalt oder gefährlicher
_Drohung) became one of the modalities of impermissible means. In case the exploitation does not occur by one of_
the described impermissible means, the trafficking offence does not apply[164].

49. The distinction between Article 104a of the Criminal Code and § 116 of the Aliens' Police Law is still rather
difficult to establish. The former provision does not require that the trafficker him or herself exploits the victim, but if
this is the case, the conditions of both provisions are met and the perpetrator has to be punished according to both
provisions, although uncertainty reigns as regards the regime of concurrence of penalties[165]. As regards the relation
between Article 104(a) and Article 217 of the Criminal Code, if the elements of both provisions are fulfilled, Article
217(1) applies besides Article 104(a)(1), Article 217(2) applies instead of Article 104(a)(1), and Article 104(a)(4)
applies besides Article 217[166].

50. In sum, the Austrian legal framework is still in need of reform in order to comply with international law. The
offence of forced labour (of nationals) must be introduced and the offence of forced labour of aliens must be
enlarged, on the model of forced marriage (Zwangsheirat)[167]. The legislative solution would be to formulate a single
_Tatbestand of forced labour of nationals and aliens along the lines of the above-mentioned international-law_
concept of forced labour, which does not distinguish between nationals and aliens. A stand-alone general
exploitation offence would not seem to be an option in view of the recent political choice made with the incrimination
of the special exploitation offence of Zwangsheirat.

51. The objective element of the trafficking offence (objektiver Tatbestand) must be clarified and refined, both with
regard to the some of the relevant conducts and impermissible means, as for example the exploitation of a position
of authority. The prevailing understanding officially supported by the EBRV StRÄG 2004 and the EBRV
SexualStRÄG 2013 is too narrow in some aspects.

52. For example, the concept of “a ruthless and sustainable oppression of vital interests” excessively narrows the
exploitative purpose of trafficking. The exploitation notion and the _erweiterte Vorsatz_ of exploitation must be
explicitly delinked from the “sustainable” or “prolonged” duration of the conduct, from any “ruthlessness”
requirement and from the equivocal “vital” nature of the affected victim's interests. Exploitation may have an
intermittent, irregular or even short duration[168], have no especially “ruthless” character and affect no “vital” interest
of the victim[169]. Any criminal-law reform in this field must be aware that political and social acceptance of
exploitative working conditions, particularly among migrants, contributes to the lower profile of such conduct[170] and
that a vague law is not a good law: that the basic principle of legality requires criminal offences to be delineated with
certainty.
_V. Application of the legal framework to the facts of the case (§§ 53-59)A. The substantive reasons for_
_discontinuance (§§ 53-55)_

53. The Vienna Landesgericht discontinued the investigation because, in its view, the period of three days in Vienna
was not sufficient to fulfil the elements of the trafficking offence and there was no claim or evidence of ill-treatment.
This application of domestic law to the facts is not compatible with international law. First, there is no need for
evidence of ill-treatment in order to prosecute someone for human trafficking. Second, the prosecution for a
trafficking offence does not hinge on the duration of the trafficking conduct, and even less on the time the actual
exploitation lasted. As a matter of Austrian and international law, the actual exploitation does not even need to have
started. Hence it is doubly wrong to state, as the _Landesgericht did, that “the relevant acts relating to the_
exploitation of labour must be committed over a longer period of time” than three days[171].


-----

54. Clear indicators of exploitation and trafficking for that purpose are present in the case file, both abroad and on
Austrian soil: confiscation of passport and mobile phones of the victims by the employer, withholding and unilateral
reduction of the victims' salary by the employer, unbearable working conditions, excessive working time,
humiliation, verbal abuse, threat and use of force against the victims[172]. The alleged facts that took place in Vienna
can be classified as housing at the hotel (beherbergen), with organisation of the transportation (befördern) of the
victims. The impermissible means included, at least, intimidation (Einschüchterung), not to speak about the verbal
abuse.

55. The domestic authorities did not take into account the chain of events stretching from the Philippines to the
United Arab Emirates and Austria, and the presence of the same pattern of behaviour by the employer in Austrian
soil. The “continuing criminal offence” (Dauerdelikt) nature of the denounced facts was overlooked[173]. Neither did
they consider the fact that the duration of the facts in Austria was necessarily short, since the employers and the
victims were travelling on their way to London, merely and stopping over for a few days in Vienna.
_B. The procedural reasons for discontinuance (§§ 56-59)_

56. The domestic authorities invoked four procedural reasons to discontinue the investigation: the lack of jurisdiction
(keine Zuständigkeit der österreichischen Straverfolgungsbehörden) regarding the recruitment in the Philippines
and the alleged exploitation in the United Arab Emirates; the absence of a mutual legal assistance agreement with
United Arab Emirates; the public prosecution authorities' margin of appreciation accorded by Article 210 of the CCP
and the rule in Austrian law that no criminal proceedings may be conducted in the absence of the accused, under
Article 197 of the CCP.

57. If the lack of jurisdiction over facts which occurred outside Austria could be an obstacle to prosecution before
Austrian courts in the light of the Austrian legal framework[174], the absence of a mutual legal assistance agreement
with the United Arab Emirates could not per se impede prosecution based on the facts which did occur in Austria[175].
Where the authorities of the country of origin of the trafficking victims or the perpetrators do not wish or are unable
to cooperate with the authorities of the country of destination or transit, there are still other legal avenues open for
the latter authorities to promote the investigation, prosecution, possible detention and bringing to justice of the
alleged traffickers, such as the EUROPOL, FRONTEX and INTERPOL tools which are available for combating
human trafficking, for example the Human Smuggling and Trafficking (HST) message and the INTERPOL's

耀Notices and Diffusions system, and possibly the blue or green notice. None of them was used by the domestic

authorities, although the identity of the employers was available to them[176]. The domestic and international warning
notice systems could have been triggered.

58. Finally, the public prosecutor has no margin of discretion in promoting criminal action in Austria, since the
Austrian system is governed, pursuant to Article 210 of the CCP, by the principle of legality of criminal prosecution
(or mandatory prosecution) and not by the principle of expediency (or discretionary prosecution). When there are
sufficient indicia for an offence, the public prosecutor must instigate prosecution, except in cases of privately
prosecuted offences, which are dependent on a victim pressing charges. Trafficking is a publicly prosecuted offence
in Austria, and there is no margin of discretion for public prosecutors not to prosecute such offence[177].

59. In my view, one single but important factor militates in favour of staying the case: the victim's tardy contact with
the domestic authorities impeded the questioning of the alleged perpetrators and the normal development of the
proceedings. In March 2012, the case should have been stayed, and not discontinued, in view of the prolonged
absence of the alleged perpetrators. In any event, the investigation may be reopened according to Article 197 of the
CCP, as mentioned in paragraph 116 of the judgment.
_VI. Conclusion (§§ 60-61)_

60. As with the fight against slavery and the slave trade during the early twentieth century, the fight against forced
labour and trafficking for that purpose has been at the top of the international human rights agenda since the turn of
the century. Austria has made considerable headway in this fight, especially in terms of the social support provided
to victims. Nevertheless, the Austrian criminal law framework is still deficient, in spite of the 2013 reform. This case
could, and should, provide a new impulse to legislative reform.


-----

61. Allegedly, the applicants were forced to work in Austria and abroad and were trafficked for that purpose on
Austrian soil. The domestic authorities disputed this fact, but nonetheless provided social support to them as if they
had been victims of trafficking. This contradictory position is exemplary of the strengths and the weaknesses of the
Austrian system: effective in victim protection, ineffective in punishing the perpetrators[178]. Ultimately, the domestic
authorities failed in the present case to investigate fully the denounced facts and, eventually, to bring those
responsible to justice. However, the applicants also bear major responsibility for this failure in view of the tardiness
of their contact with the domestic authorities. Little more could be done at that time and in the specific
circumstances of the case than activating the domestic and international warning notice systems. That is why I was
nonetheless able to vote for the finding of no violation.

1

1   This opinion does not deal with the specific issues of forced prostitution and trafficking for that purpose. On these
issues see the 1904 International Agreement for the Suppression of the White Slave Traffic, reviewed 1910, and its
1949 Protocol; the 1921 International Treaty for the Suppression of Traffic in Women and Children, and its 1947
Protocol; the 1933 International Convention for the Suppression of the Traffic in Woman of Full Age; the 1949
Convention for the Suppression of Traffic in Persons and the Exploitation of the Prostitution of Others; the 1979 UN
Convention on the Elimination of All Forms of Discrimination Against Women (Article 6) and the 2002 South Asian
Association for Regional Cooperation Convention on Preventing and Combating Trafficking in Women and Children for
Prostitution.

2   United Nations Office on Drugs and Crime (UNODC), Global Report on Trafficking in Persons, 2014, p. 12; the
Report of the UN Special Rapporteur on contemporary forms of slavery, including its causes and consequences,
Urmila Bhoola, 8 July 2015, A/HRC/30/35; and the ILO Global Estimate of Forced Labour, Results and Methodology,
2012.

3   The Slavery Convention was signed at Geneva on 25 September 1926 and entered into force on 9 March 1927. It
was amended by a Protocol of 7 December 1953 which entered into force on 7 July 1955. It has 99 parties.

4   The Supplementary Convention on the Abolition of Slavery, the Slave Trade, and Institutions and Practices Similar
to Slavery, was adopted by a Conference of Plenipotentiaries convened by Economic and Social Council resolution
608(XXI) of 30 April 1956, which was done at Geneva on 7 September 1956 and entered into force on 30 April 1957. It
has 123 parties, including Austria (7 October 1963).

5   The ILO Convention No. 29 was adopted at Geneva, 14th ILC session (28 June 1930), and entered into force on 1
May 1932. It has 139 ratifications, including by Austria (7 June 1960). A Protocol to the Forced Labour Convention was
adopted at Geneva, 103rd ILC session (11 June 2014) and entered into force on 9 November 2016. It has
10 ratifications. See also the Forced Labour (Supplementary Measures) Recommendation, 11 June 2014 (No. 203).

6   The ILO Convention No. 105 was adopted at Geneva, 40th ILC session (25 June 1957), and entered into force on
17 January 1959. It has 175 ratifications, including by Austria (5 March 1958).

7   The Convention on the High Sea was opened for signature on 29 April 1958 and entered into force on 30
September 1962. It has 63 parties, including Austria (10 January 1974).

8   The American Convention was adopted in San José, Costa Rica, on 22 November 1969, and came into force on
18 July 1978. It has 25 ratifications, but two States have denounced the Convention.

9   The Protocol was adopted by the Diplomatic Conference on the Reaffirmation and Development of International
Humanitarian Law Applicable in Armed Conflicts in Geneva, on 8 June 1977, and entered into force on 7 December
1978. It has been ratified by 168 States, including Austria (13 August 1982).

10   The Charter was adopted by the eighteenth Assembly of Heads of State and Government of the Organisation of
African Unity, in Nairobi, Kenya, in June 1981, and entered into force on 21 October 1986. It has 54 ratifications.

11   The Convention on the Law of the Sea was adopted by the Third United Nations Conference on the Law of the
Sea and opened for signature on 10 December 1982 in Montego Bay, Jamaica, and entered into force on 16
N b 1994 I h 166 i i l di A i (14 J l 1995)


-----

12   The CRC was adopted by the United Nations General Assembly on 20 November 1989 and came into force on 2
September 1990. 196 countries are parties to it, including Austria (6 August 1992).

13   The ICPRMW was adopted by General Assembly resolution 45/158 of 18 December 1990 and entered into force
on 1 July 2003. It has 49 parties.

14   The African Charter was adopted on 11 July 1990 and entered into force on 29 November 1999. It has 47 parties.

15   The Inter-American Convention on International Traffic in Minors was adopted at Mexico, D.F., Mexico, on 18
March 1994, at the Fifth Inter-American Specialized Conference on Private International Law, and entered into force on
8 August 1997. It has 15 parties.

16   The CIS Convention was adopted on 26 May 1995 and has since been ratified by Belarus, Kyrgyzstan, the
Russian Federation and Tajikistan. It entered into force on 11 August 1998.

17   It was adopted at a diplomatic conference in Rome on 17 July 1998 and entered into force on 1 July 2002. 124
countries are States Parties, including Austria (28 December 2000).

18   The ILO Convention No. 182 was adopted at Geneva, 87th ILC session (17 Jun 1999) and entered into force on
19 November 2000. It has 180 ratifications, including Austria (4 December 2001).

19   It was adopted by resolution A/RES/55/25 of 15 November 2000 and entered into force on 25 December 2003. It
has 170 parties, including the respondent State (15 September 2005).

20   The Protocol was adopted by the United Nations General Assembly on 25 March 2000 and entered into force on
18 January 2002. 173 states are parties to the protocol, including Austria (6 May 2004).

21   It was proclaimed at the Nice European Council on 7 December 2000. At that time, it did not have any binding
legal effect. On 1 December 2009, with the entry into force of the Treaty of Lisbon, the Charter became legally binding
on the EU institutions and on national governments, including the Austrian government.

22   The second, updated version of the Arab Charter was adopted on 22 May 2004 and entered into force on 15
March 2008. It has 12 States Parties. This is a revised edition of the first Charter of 15 September 1994.

23   CETS no. 197. It was adopted by the Committee of Ministers (CM) of the Council of Europe on 3 May 2005 and
entered into force on 1 February 2008. It has 46 Parties, including the respondent State.

24   The CRPD was adopted by the United Nations General Assembly on 13 December 2006 and came into force on
3 May 2008. It has 172 States Parties.

25   The African Union Convention was adopted on 23 October 2009 and entered into force on 6 December 2012. It
has been ratified by 25 States.

26   The ILO Convention No. 189 was adopted at Geneva, 100th ILC session (16 Jun 2011) and entered into force on
5 September 2013. It has 23 ratifications.

27   The ASEAN Convention was adopted at Kuala Lampur on 21 November 2015 and has not yet entered into force.
See also ASEAN Declaration Against Trafficking in Persons Particularly Women and Children, 2004; and the Criminal
Justice Responses to Trafficking in Persons: Ending Impunity for Traffickers and Securing Justice for Victims (“ASEAN
Practitioner Guidelines”), 2007.

28   ILO, Forced Labour: Forced Labour; Report and Draft Questionnaire, Item III on the Agenda, International Labour
Conference, 12[th] Session, 1929 (Geneva), cited in “Forced Labour: A Selective ILO Bibliography 1919 – 2005”.

29   Such powers were not specified, but see United Nations Economic and Social Council, “Slavery, the slave trade
and other forms of servitude”, Report of the Secretary-General, 27 January 1953, E/2357, p. 28.

30   The new concept of servitude was not defined by the UDHR, nor by the ICCPR. The UNODC Model Law against
Trafficking in Persons, 2009, p. 18, proposes that servitude “shall mean the labour conditions and/or the obligation to
work or to render services from which the person in question cannot escape and which he or she cannot change”. See
Jean Allain, Slavery in International Law of Human Exploitation and Trafficking, Leiden, 2013, pp. 143-202.

31 J All i i d b 251


-----

32   The odd formulation “whether or not they are covered by the definition of slavery contained in article 1 of the
Slavery Convention” left open the issue of the intention of the drafters of the Slavery Convention to include the four
newly enumerated practices under the concept of slavery.

33   UNODC Model Law, cited above, p. 13: “a person is kept in bondage by making it impossible for him or her to
pay off his or her real, imposed or imagined debts.”

34   See Allain, cited above, pp. 146 and 160, and Gallagher, The International Law on Human Trafficking,
Cambridge, 2010, pp. 181 and 182.

35   Article 11 of the ICPRMW replicated the ICCPR provision with regard to migrant workers or members of their
families.

36   Bossuyt, Guide to the Travaux préparatoires of the International Covenant on Civil and Political Rights,
Dordrecht, 1987, p. 164.

37   See the United Nations Human Rights Committee (UNHRC), Communication No. 289/1988, _Dieter Wolf v._
_Panama, 8 April 1992 (CCPR/C/44/D/289/1988)._

38   See the UNHRC Communication No. 666/1995, Frédéric Foin (represented by François Roux, lawyer in France)
_v. France, 9 November 1999 (CCPR/C/67/D/666/1995)._

39   Article 13 of the Convention on the High Sea and Article 99 of the Convention on the Law of the Sea also
prohibited the transport of slaves.

40   UNHRC General Comment 29, States of Emergency (article 4), U.N. Doc. CCPR/C/21/Rev.1/Add.11 (2001),
paras. 11-12.

41   See also the UNICEF Guidelines on Protection of the Rights of Child Victims of Trafficking, 2006; the Reference
Guide on Protecting the Rights of Child Victims of Trafficking in Europe, 2006; and the Guidelines for Protection of the
Rights of Children Victims of Trafficking in South Eastern Europe, 2003.

42   See UNODC, The Concept of “Exploitation” in the Trafficking in Persons Protocol, 2015, p. 112.

43   The ILO Commission of Inquiry into Forced Labour in Myanmar, Report 2 July 1978, para. 203, affirmed explicitly
the peremptory nature of the prohibition of forced labour.

44   The ILO has affirmed that, with the exception of organ removal, trafficking is covered by the Forced Labour
Convention (ILO, Profits and Poverty: The Economics of Forced Labour, 2014, pp.3-4, and UNODC, the concept of
“exploitation”, cited above, p. 32).

45   UNODC Model Law, cited above, p. 15: “The threat of a penalty can take multiple forms ranging from (the threat
of) physical violence or restraint, (threats of) violence to the victim or his or her relatives, threats to denounce the victim
to the police or immigration authorities when his or her employment or residence status is illegal, threats of
denunciation to village elders or family members in the case of girls or women forced into prostitution, (threat of)
confiscation of travel or identity papers, economic penalties linked to debts, the non-payment of wages, or the loss of
wages accompanied by threats of dismissal if workers refuse to work overtime beyond the scope of their contract or
national law.” (ILO, Global Report 2005, pp. 5-6; ILO, Eradication of Forced Labour, International Labour Conference,
2007, p. 20).” In C.N. and V. v. France, no. 67724/09, §§ 77-78, 11 October 2012, the Court referred to the ILO Global
report, The Cost of Coercion, 2009, paras. 24-25, when discussing the menace of a penalty as a component of forced
labour.

46   UNODC Model Law, cited above, pp. 14 and 28, and ILO, Eradication of Forced Labour, International Labour
Conference, 2007, p. 42. The ritual or ceremonial servitude includes the “exploitative and abusive religious or cultural
practices that dehumanize, degrade or cause physical or psychological harm”.

47   Jean Allain, cited above, p. 254.

48   See ILO, Hard to See: Harder to Count: Survey Guidelines to Estimate Forced Labour of Adults and Children,
2011; ILO, Eliminating the Worst Forms of Child Labour under Time-Bound Programmes: Guidelines for Strengthening
Legislation, Enforcement and Overall Legal Framework, 2003; and ILO/IPU, Eliminating the Worst Forms of Child
L b A i l id ILO C i N 182 2002


-----

49   ILO Operational indicators of trafficking in human beings: Results from a Delphi survey implemented by the ILO
and the European Commission, 2009; ILO, Global Report under the Follow-up to the ILO Declaration on Fundamental
Principles and Rights at Work: A Global Alliance against Forced Labour, 2005; and ILO, Human Trafficking and Forced
Labour Exploitation: Guidelines for Legislators and Law Enforcement, 2004. The practice of the States follows these
indicators (UNODC, The concept of “exploitation”, cited above, p. 109). The Court referred to the ILO indicators in C.N.
_v. the United Kingdom, no. 4239/08, § 35, 13 November 2012._

50   ILO Guidelines, cited above, p. 23. As noted by the ILO in the Forced Labour Survey Guidelines: “… the
obligation to stay in a job due to the absence of alternative employment opportunities, taken alone, does not equate to
a forced labour situation; however, if it can be proven that the employer is deliberately exploiting this fact (and the
extreme vulnerability which arises from it), to impose more extreme working conditions than would otherwise be
possible, then this would amount to forced labour.” (ILO, Hard to See, cited above, p. 16).

51   ILO Guidelines, cited above, p. 61.

52   ILO Guidelines, cited above, p. 63.

53   Judgment of 3 November 1947, in Trials of War Criminals Before the Nuremberg Military Tribunals Under Control
Council Law No. 10, Volume V, p. 969.

54   The Red Cross Rule 95 on Forced Labour dictates that “Uncompensated or abusive forced labour is prohibited”,
considering that State practice establishes this rule as a norm of customary international law applicable in both
international and non-international armed conflicts (Henckaerts and Doswald-Beck, Customary International
Humanitarian Law, volume I, Rules, Cambridge, 2005, pp. 330-334). See also Articles 29-32 of the 1929 Geneva
Convention, Articles 49-68 of the 1949 Third Geneva Convention and Articles 40, 51 and 95 of the 1949 Fourth
Geneva Convention.

55   See also Article 2 (c) of the 2002 Statute for the Special Court for Sierra Leone.

56   See _Kunarac et al. (IT-96-23&23/1), Trial Chamber judgment of 22 February 2001, §§ 539-542. The Appeals_
Chamber Judgement of 12 June 2002 confirmed this reasoning in paragraphs 117-124. It is important to note that the
Appeals Chamber observed that “the duration of the enslavement is not an element of the crime.” The findings of the
_Kunarac trial were replicated by the Special Court for Sierra Leone in the Brima et als. Trial Chamber judgment, SCSL-_
2004-16-T, 20 June 2007, paras. 739-749.

57   This definition was anticipated by the work of UN Special rapporteur on Violence against Women, Its Causes and
Consequences whose very similar definition made trafficking conditional upon the occurrence of non-consensual
transportation for the purpose of slavery-like practices or forced labour (E/CN.4/2000/68, 29 February 2000, paras. 1017).

58   See UNODC, Model Law, cited above, which drew inspiration from the US State Department Model Law to
Combat Trafficking in Persons, 2003; the UNODC Legislative Guides for the Implementation of the UN Convention
Against Transnational Organised Crime and the Protocols thereto, 2004; the UNODC Toolkit to Combat Trafficking in
Persons, 2008; the UNODC Assessment Toolkit on the Criminal Justice Response to Human Trafficking; the
International Framework for Action To Implement the Trafficking in Persons Protocol, 2009; the Abuse of a Position of
Vulnerability and other “Means” Within the Definition of Trafficking in Persons, 2012; The Role of “Consent” in the
Trafficking in Persons Protocol, 2014; and The Concept of “Exploitation”, cited above. See also Office of the High
Commissioner for Human Rights, Recommended Principles and Guidelines on Human Rights and Human Trafficking,
E/2002/68/Add.1, and the UN Basic Principles on the right to an effective remedy for trafficked persons.

59   According to the Travaux Préparatoires, “[t]he words “at a minimum” will allow States parties to go beyond the
offences listed in this definition in criminalizing [and are] also intended to make it possible for the protocol to cover
future forms of exploitation (i.e. forms of exploitation that [are] not yet known” (UNODC, Travaux Préparatoires of the
Negotiations for the E labouration of the United Nations Convention against Transnational Organized Crime and the
Protocols Thereto (2006), p. 343, note 22). “The non-exhaustive character of the Protocol's definition is manifested in
two ways: (i) through the term 'at a minimum'; and (ii) through the absence of definitions relating to concepts that are
not otherwise defined in international law.” (UNODC, The Concept of “Exploitation”, cited above, p. 8)

60   According to UNODC, the reference to services enabled the prohibition to extend to other illegal or unregulated
i i i h S i l b (Th C f “E l i i ” i d b 31) Th E l


-----

Report to the Council of Europe Anti-Trafficking Convention, para. 92, does not directly address this matter but notes
no distinction between “forced labour” and “forced services”.

61   According to the Interpretative Notes for the _travaux préparatoires of the Palermo Protocol (A/55/383/Add.1, 3_
November 2000), para. 66, illegal adoption also falls within the scope of the Protocol. The Explanatory Report of the

Council of Europe Anti‑Trafficking Convention, para. 94, repeats this stance.

62   The note in the UNODC Legislative Guide to the Implementation of the Protocol to the effect that “the removal of
a child's organs for legitimate medical or therapeutic reasons cannot form an element of trafficking if a parent or
guardian has validly consented” is equivocal as it may be construed to imply that a different rule may apply in the case
of consensual removal of an adult's organs “for legitimate medical or therapeutic reasons”. This is evidently not the
case, the same rule of therapeutic justification applying to children and adults.

63   See Article 3 of the UN Protocol against Smuggling of Migrants by land, Sea and Air and Gallagher and David,
The International Law on Migrant Smuggling, Cambridge, 2014.

64   In its yearly Trafficking in Persons Report, the United States Department of State monitors whether a State
complies with the obligations in the Palermo Protocol.

65   UNODC Model Law, cited above, p. 11: “use of force or threat thereof, and some forms of non-violent or
psychological use of force or threat thereof, including but not limited to: (i) Threats of harm or physical restraint of any
person; (ii) Any scheme, plan or pattern intended to cause a person to believe that failure to perform an act would
result in serious harm to or physical restraint against any person; (iii) Abuse or any threat linked to the legal status of a
person; (iv) Psychological pressure.”

66   UNODC Model Law, cited above, p. 12: “Deception or fraud can refer to the nature of the work or services that
the trafficked person will engage in (for example the person is promised a job as a domestic worker but forced to work
as a prostitute), as well as to the conditions under which the person will be forced to perform this work or services (for
instance the person is promised the possibility of a legal work and residence permit, proper payment and regular
working conditions, but ends up not being paid, is forced to work extremely long hours, is deprived of his or her travel
or identity documents, has no freedom of movement and/or is threatened with reprisals if he or she tries to escape), or
both.”

67   In the Interpretative Notes for the _travaux préparatoires of the Protocol, cited above, para. 63, the “position of_
vulnerability” was defined as “any situation in which the person involved has no real and acceptable alternative to
submit to the abuse involved.” Both the EU Directive 2011/36/EU and the Explanatory Report to the Council of Europe
Anti-Trafficking Convention, para. 83, follow the formulation of the Interpretative Notes. The definition of the UNODC
Model Law, cited above, p. 9, is different: “any situation in which the person involved believes he or she has no real
and acceptable alternative but to submit”. See also the ILO Survey Guidelines, cited above, p. 16, and Article 8 (b) of
the Arab Model Law on Combating Trafficking in Human Beings. It seems that vulnerability encompasses both innate
or acquired characteristics of the victim or the situational context in which he or she may be in, such as extreme
poverty.

68   UNODC, Anti-Human Trafficking Manual for Criminal Justice Practitioners (2009), Module 1, pp. 4–5. UNODC
notes that domestic law could enable _mens rea to be established on a lesser standard than direct “intent”, such as_
willful blindness.

69   Article 32 (1) of the Rome Statute.

70   Articles 32 (2) and 33 (2) of the Rome Statute. UNODC Legislative Guides, cited above, p. 276: “Drafters should
note that the element of intention refers only to the conduct or action that constitutes each criminal offence and should
not be taken as a requirement to excuse cases, in particular where persons may have been ignorant or unaware of the
law establishing the offence.”

71   UNODC Legislative Guides, cited above, p. 268, and the Explanatory Report to the Council of Europe AntiTrafficking Convention, para. 249. See also Gallagher, cited above, pp. 80 and 81, for other important criminal law
related obligations deriving from the Palermo Protocol.

72   UNODC Legislative Guides, cited above, p. 269: “The offence defined in article 3 of the Protocol is completed at
a very early stage. No exploitation needs to take place.”

73   In addition, States should adopt preventive and cooperative measures. Only three articles define the status and
i h f ffi k d b h h d i i i l


-----

74   See the UNODC Legislative Guides, cited above, p. 259 (“In the case of trafficking in persons, domestic offences
should apply even where transnationality and the involvement of organised criminal groups do not exist.”), and pp. 275276.

75   UNODC Model Law, cited above, p. 35. See also The Miami Declaration of Principles on Human Trafficking (Feb.
10, 2005), 1 Intercultural Human Rights L. Rev. 11 (2006).

76   See Inter-American Court of Human Rights, Case of the Ituango Massacres vs Colombia, Series C No. 148, 1
July 2006, paras. 154-168, which applied the criteria of Article 2(1) of ILO Convention No. 29, and Inter-American
Commission on Human Rights, Captive Communities: Situation of the Guaraní Indigenous People and Contemporary
_Forms of Slavery in the Bolivian Chaco, OEA/SER.L/v/ii, Doc. 58, 24 December 2009, p. 27, which referred to the_
same criteria in substance.

77   See Malawi African Association and Others v. Mauritania, African Commission on Human and Peoples' Rights,
Comm. Nos. 54/91, 61/91, 98/93, 164/97 à 196/97 and 210/98 (2000), para. 135, where there was a violation of article
5 of the Charter due to practices analogous to slavery. The Commission emphasised that unremunerated work is
tantamount to a violation of the right to respect for the dignity inherent in the human being.

78   ECOWAS Court of Justice, _Hadijatou Mani Koraou v. Republic of Niger, ECW/CCJ/JUD/06/08 (27 October_
2008), para. 81.

79   The Council of the Arab Ministers of Justice in 2005 and the Council of the Arab Ministers of Interior in 2006, had
already adopted the Arab Guiding Law on Human Trafficking (Model Law to Combat the Crime of Trafficking in
Persons), which followed the definition on trafficking contained in the Palermo Protocol.

80   The CIS member States are Azerbaijan, Armenia, Belarus, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan
and Uzbekistan. Turkmenistan and Ukraine are associate States.

81   The Proceedings of the Round Table were published and are available on line.

82   In Asia, the fight against trafficking had been focused until recently on trafficking for forced prostitution (see the
SAARC Convention on Preventing and Combating Trafficking in Women and Children for Prostitution, and United
Nations Economic and Social Commission for Asia and the Pacific, Combating Human Trafficking in Asia: A Resource
Guide to International and Regional Legal Instruments, Political Commitments and Recommended Practices, 2003). As
mentioned earlier, this subject lies outside the scope of this opinion.

83   The OSCE has 57 participating States from Europe, Central Asia and North America.

84   Council Act of 26 July 1995 drawing up the Convention on the Establishment of a European Police Office.

85   According to the explanations relating to the text of the Charter of the Praesidium to the Convention, “The right in
Article 5(1) and (2) corresponds to Article 4(1) and (2) of the ECHR, which has the same wording. It therefore has the
same meaning and scope as the ECHR Article, by virtue of Article 52(3) of the Charter. Consequently no limitation may
legitimately affect the right provided for in paragraph 1.” EU Network of Independent Experts on Fundamental Rights
Commentary of the Charter, 2006: “In contrast to slavery and servitude, which are continuing states, forced labour may
arise incidentally or on a more temporary basis.”

86   Council Framework Decision 2002/629/JHA of 19 July 2002 on combating trafficking in human beings, followed
by the 2005 EU Plan on best practices, standards and procedures for combating and preventing trafficking in human
beings and the Measuring Responses to Trafficking in Human Beings in the European Union: an Assessment Manual,
EC Directorate General Freedom, Security and Justice, 2007. The European Conference on Preventing and
Combating Trafficking in Human Beings – Global Challenge for the 21[st] Century delivered the Brussels Declaration on
Preventing and Combating Trafficking in Human Beings, 29 November 2002, 14981/02.

87   Council Directive 2004/81/EC of 29 April 2004 on the residence permit issued to third‑country nationals who are

victims of trafficking in human beings or who have been the subject of an action to facilitate illegal immigration, who
cooperate with the competent authorities.

88   Directive 2009/52/EC of the European Parliament and of the Council of 18 June 2009 providing for minimum
d d i d i l f ill ll i hi d i l


-----

89   See also European Parliament resolution of 17 January 2006 on strategies to prevent the trafficking of women
and children who are vulnerable to sexual exploitation; and European Parliament recommendation to the Council on
fighting trafficking in human beings – an integrated approach and proposals for an action plan (2006/2078(INI)).

90   Directive 2011/36/EU of the European Parliament and of the Council of 5 April 2011 on preventing and combating
trafficking in human beings and protecting its victims, and replacing Council Framework Decision 2002/629/JHA. See
the very useful Joint UN Commentary on the EU Directive – A Human Rights-Based Approach, 2011, on the “low
threshold approach” towards addressing the assistance and protection needs of victims in cases where trafficking
cannot be proven by the criminal justice system.

91   In the Travaux préparatoires de l'article 4 de la Convention, DH(62) 10, 16 November 1962, p. 16, reference is
made to servitude as “a more general idea covering all possible forms of man's domination of man”. This passage is
taken from the commentary to the ICCPR draft prepared by the UN Secretary General in 1955.

92   In the Travaux préparatoires, reference was made to the definition of the 1930 ILO Convention, which “was not
considered entirely satisfactory for inclusion in the covenant.” This passage was taken from the commentary to the
ICCPR draft.

93   Van der Mussele v. Belgium, judgment of 23 November 1983, Series A, No.70, § 38.

94   Van der Mussele, cited above, § 32.

95   Van der Mussele, cited above, § 33.

96   Van der Mussele, cited above, § 34.

97   ECSR Conclusions II, Statement of Interpretation on Article 1 § 2, p. 4.

98   ECSR Conclusions III, p. 5.

99 _International Federation of Human Rights Leagues (FIDH) v. Greece, Complaint No. 7/2000, Decision on the_
merits of 5 December 2000, § 22.

100   International Federation of Human Rights Leagues (FIDH), cited above, § 21.

101   ECSR Conclusions 2004, Ireland, p. 260. It was also noted that the decision to grant early retirement was left to
the discretion of the Minister of Defence.

102   ECSR Conclusions XVI-1, Greece, p. 283. See also the ECSR Conclusions 2012 - Moldova - article 1-2.

103 _Quaker Council for European Affairs (QCEA) v. Greece, Complaint No. 8/2000, Decision on the merits of 25_
April 2001, §§ 23-25.

104   ECSR Conclusions XVI-1, Germany, pp. 242-243.

105   ECSR Conclusions XX-1 - Netherlands Aruba - Article 1-2.

106   ECSR Conclusions 2012 - France - Article 1-2.

107   Explanatory Report to the Convention, para. 72.

108   Ibid., para. 80.

109   Explanatory Report to the Convention, para. 87.

110   CETS No. 210.

111   CETS No. 216. The UN Special Rapporteur on Trafficking in Persons has expressed concern about this
convention's failure to integrate the relevant practices within the broader conceptual and normative framework of the
Trafficking in Persons Protocol and the possible lowering of victim protection and assistance standards as a
consequence (UN Doc. A/68/256, 2 Aug. 2013, paras. 64, 65, 100).

112   See Recommendation No. R (91) 11 on sexual exploitation, pornography and prostitution of, and trafficking in,
children and young adults; and Recommendation No. R (2000) 11 on action against trafficking in human beings for the
purpose of sexual exploitation.

113   See Recommendation 1325 (1997) on traffic in women and forced prostitution in Council of Europe member
R d i 1523 (2001) d i l R d i 1526 (2001) i i


-----

trafficking in minors to put a stop to the east European route: the example of Moldova; Recommendation 1545 (2002)
on a campaign against trafficking in women; Recommendation 1610 (2003) on migration connected with trafficking in
women and prostitution; and PACE Recommendation 1663 (2004) on domestic slavery: servitude, au pairs and mailorder brides.

114   Siliadin v. France, no. 73316/01, ECHR 2005‑VII.

115   Siliadin, cited above, §§ 89 and 112.

116   Siliadin, cited above, §§ 122 and 124. See also C.N. v. the United Kingdom, cited above, § 66, C.N. and V. v.
_France, cited above, § 105, and Kawogo v. the United Kingdom (dec.), 3 September 2013._

117   The European Commission of Human Rights had regarded servitude as having to live and work on another
person's property and perform certain services for them, whether paid or unpaid, together with being unable to alter
one's condition (application no. 7906/77, DR 17, p. 59; see also the Commission's report in the Van Droogenbroeck
case of 9 July 1980, Series B, Vol. 44, p. 30, paragraphs 78 to 80). The Chamber adhered to this conception in
paragraph 123 of _Siliadin, but added in § 124, that servitude was characterised as “an obligation to provide one's_
services that is imposed by the use of coercion, and is to be linked with the concept of “slavery”” and thus dropping the
space element of the European Commission's concept. The Explanatory Report to the Council of Europe AntiTrafficking Convention, para. 95, takes a slightly different position, stating that this “particularly serious form of denial of
freedom” is to be regarded as “a particular form of slavery, differing from it less in character than in degree.”

118   Siliadin, cited above, § 123.

119   Rantsev v. Cyprus and Russia, no. 25965/04, ECHR 2010 (extracts). When monitoring the parties to the AntiTrafficking Convention, GRETA takes account of the conclusions of this judgment in its assessment (GRETA 5[th]
meeting Conclusions, 2010, para. 15).

120   Rantsev, cited above, § 282.

121   Rantsev, cited above, § 279.

122   UNHRC General Comment 29, cited above, paras. 11-12.

123   Rantsev, cited above, § 285.

124   Rantsev, cited above, § 286.

125   Rantsev, cited above, § 287.

126 _Rantsev, cited above, § 288. On the empowerment of victims see_ _L.E. v. Greece, no. 71545/12, 21 January_
2016, and O.G.O. v. the United Kingdom (dec.), 18 February 2014.

127   Rantsev, cited above, § 289.

128   As had already been pointed out by the Office of the High Commissioner for Human Rights, Recommended
Principles and Guidelines, cited above.

129   The ILO supervisory bodies have emphasised that, where work or services are imposed (for instance, by
exploiting the worker's vulnerability) under the menace of detrimental consequences, such exploitation ceases to be
merely a situation of poor employment conditions and triggers the protection of ILO Convention No. 29 (UNODC, The
concept of “exploitation”, cited above, p. 31).

130   Janie Chuang, “Exploitation Creep and the Unmaking of Human Trafficking Law”, 108 (4) American Journal of
International Law (2014).

131   In Barar v. Sweden (dec.), no. 42367/98, 19January 1999, the Court held that the expulsion of a person to a
State where he would be subjected to slavery might raise an issue under Article 4, but the risk had not been
substantiated.

132   UNHRC General Comment No. 29, cited above, paras. 11-12. See also paragraph 3 of the Miami Declaration,
cited above.

133   See Osman v. the United Kingdom, 28 October 1998, § 115-17, Reports of Judgments and Decisions 1998‑VIII,

and Mahmut Kaya v Turkey no 22535/93 § 115 ECHR 2000 III It should be noted that the Special Rapporteur on


-----

Torture expanded the definition of torture to include trafficking as a form of torture in the private sphere (A/HRC/7/3, 15
January 2008, paras. 56-58).

134   See Arbeitsgruppe “Menschenhandel zum Zweck der Arbeitsausbeutung” des Bundesministeriums für Arbeit,
Soziales and Konsumentenschutz, Bericht für die Jahre 2012-2014; Hajdu _et al., Arbeitsausbeutung. Ein sozial–_
ökonomisches Phänomen?, Frauenhandel bzw. Menschenhandel zum Zweck der Arbeitsausbeutung von Ungarinnen
und Ungarn in Österreich, Vienna, 2014; ACTnow, Anti-child-trafficking, Rechtliche Herausforderung im Kampf gegen
Kinderhandel, lexisnexis, 2013; Zingerle and Alionis, Männer als Betroffene von Menschenhandel in Österreich, 2013;
Bericht des Menschenrechtsbeirates zu Identifizierung und Schutz von Opfern des Menschenhandels, 2012; and
Planitzer and Sax, Combating THB for Labour Exploitation in Austria, in Rijken (ed.), Combating Trafficking in Human
Beings for Labour Exploitation, 2011, pp. 1-72.

135   GRETA Report on Austria, GRETA (2011)10, para. 137.

136   As will be shown below, the concept of exploitation is too strict (see the description in Tipold in Höpfel/Ratz,
Wiener Kommentar zum Strafgesetzbuch[2], Vienna, notes 7-9 to Article 116 of the FPG). For example, both the
legislator and the doctrine deny exploitation when the salary and social disparities between the country of origin and
the country of destination are exploited.

137   Tipold, cited above, note 6.

138   As quite rightly pointed out by Tipold, Stellungsnahme zum Entwurf eines Sexualstrafrechtsänderungsgesetz, 4
March 2013, para. 3.

139   See the Explanatory Report of the 2004 Strafrechtänderungsgesetz (“EBRV StRÄG 2004”), 12.

140   EBRV StRÄG 2004, 11.

141   EBRV StRÄG 2004, 11.

142   Government's Reply to GRETA's Questionnaire, published in August 2010, reply to question 21.

143   Ibid., reply to question 18.

144   Schwaighofer, in Höpfel/Ratz, Wiener Kommentar zum Strafgesetzbuch[2], Vienna, note 15 to Article 104a.

145   The Austrian case law requires a “targeted influence” (gezielte Einflussnahme) of the trafficker on the trafficked
person, but not the exercise of pressure of the former over the latter (Nimmervoll, in Triffterer Otto et al., Salzburger
Kommentar zum Strafgesetzbuch, lexis nexis, notes 32 and 33 to Article 104a).

146 EBRV StRÄG 2004, 13: in any form. See also the Explanatory Report of the 2013
_Sexualstrafrechtänderungsgesetz (“EBRV SexualStRÄG 2013”), 3: even for a short period of time._

147   EBRV StRÄG 2004, 13: reception of the victim in the final destination or a stopover. EBRV SexualStRÄG 2013:
surveillance over the victim suffices, like attribution of clients or work time.

148   It is not clear if the mere organisation of transportation by third persons or the purchase of travel tickets for a
public transport suffices, as EBRV StRÄG 2004, 13, and EBRV SexualStRÄG 2013, 4, suggest, but Schwaighofer,
cited above, note 5 to Article 104a, contests.

149   EBRV StRÄG 2004, 13: includes offers made to concrete persons and offers not directed to concrete persons.

150   EBRV StRÄG 2004, 13: any form of handing over or transmission of a person to another person, including the
purchase, exchange, inheritance, or any other form of assignment of a person.

151   EBRV StRÄG 2004, 13: this concept must be interpreted according to Article 212, which limits considerably the
relevant categories of perpetrators (Nimmervoll, cited above, note 22 to article 104a).

152   EBRV StRÄG 2004, 13: it includes situations of social and economic distress such as drug addiction, unlawful
stay in the country, homelessness, youth who have abandoned the family house.

153   EBRV StRÄG 2004, 14: it suffices that a psychological situation is created in which the victim can no longer
freely decide out of fear.

154   EBRV StRÄG 2004, 14: situation equated to the purchase of a person; but the demand or acceptance of money
f h i i f hi h d i d ffi (S h i h f i d b 6 A i l 104 )


-----

155   EBRV SexualStRÄG 2013, 4-5, and EBRV StRÄG 2004, 12: exploitation requires “ruthless and sustainable
oppression of vital interests” (rücksichtslose, nachhaltige Unterdrückung vitaler Interessen) of the victim. Thus, the
oppression must be prolonged in time (Schwaighofer, cited above, note 8 to Article 104a, Nimmervoll, cited above,
notes 76-78 to Article 104a, and Fabrizy, Strafgesetzbuch Kurzkommentar, Vienna, notes 6 and 9 to Article 104a).
Case-law and doctrine are sharply divided on the interpretation of the concept, some judgements even requiring a
“significant limitation of the victim's way of life” (see the cases cited in footnote 173 by Nimmervoll in his comment of
Article 104a, and Tipold, cited above, note 7 to Article 116 FPG). The EBRV SexualStRÄG 2013, 4, follows this latter
position.

156   EBRV StRÄG 2004, 13: exploitation for organ transplant is exceptional, since it requires taking of human
organs, parts of organs, human tissues and bodily fluids with such regularity and in such quantity that the danger of
permanent and grave health consequences would occur.

157   EBRV StRÄG 2004, 13: includes significant and permanent decrease of minimum working standards, other than
grave decrease of salary. EBRV SexualStRÄG 2013, 5: the relevant legal and collective agreement based labour
standards are those of Austria.

158   GRETA Report, cited above, para. 143.

159   GRETA Report, cited above, para. 155. The Government responded that “The Working Group on Labour
Exploitation will focus on the review of existing indicators for labour exploitation and on improving their applicability in
order to better assist the relevant authorities in the identification of victims.” In fact, the Arbeitsgruppe
“Menschenhandel zum Zweck der Arbeitsausbeutung” Bericht 2012-2014, cited above, pp. 16-17, refers to several lists
of indicators.

160   See EBRV SexualStRÄG 2013, and Tipold, Stellungsnahme zum Entwurf, cited above; Schwaighofer and
Venier, Stellungnahme zum Entwurf eines Sexualstrafrechtänderungsgesetzes, 25 February 2013; Beclin,
Stellungnahme zum Entwurf eines Bundesgesetzes, mit dem das Strafgesetzbuch geändert werden soll
(Sexualstrafrechtsänderungsgesetz 2013), 27 February, 2013, and Ergänzende Stellungnahme zum Entwurf eines
Bundesgesetzes, mit dem das Strafgesetzbuch geändert werden soll (Sexualstrafrechtsänderungsgesetz 2013), 8
March 2013; Florian, Punktuelle Stellungnahme zum Ministerialentwurf BMJ-S318.033/0002- IV 1/2013 betreffend ein
Bundesgesetz, mit dem das Strafgesetzbuch geändert wird (Sexualstrafrechtsänderungsgesetz 2013), 6 March 2013,
all available on the Government's website.

161   The lacuna was already noticed by Tipold, _Stellungsnahme zum Entwurf, cited above, para. 10. Nimmervoll,_
cited above, note 54 to article 104a, also criticised this “partial decriminalisation”.

162   EBRV SexualStRÄG 2013, 6: includes active and purely passive begging. The doctrine is divided on the amount
of earned money that the beggar must have been deprived of (Nimmervoll, cited above, note 98 to Article 104a, but
Schwaighofer, cited above, note 13c to the same Article).

163   EBRV SexualStRÄG 2013, 3: it does not include administrative criminal offences (Verwaltungsstrafrecht).

164   EBRV SexualStRÄG 2013, 3.

165   EBRV SexualStRÄG 2013, 3 and 7. See for the various, contradicting positions in the doctrine, Nimmervoll,
cited above, note 140 to article 140a, Schwaighofer, cited above, note 21 to the same Article, and Tipold, cited above,
note 15 to Article 116 FPG.

166   GRETA Report on Austria, GRETA (2011) 10, para. 137.

167   The provision was adopted in order to implement Article 37 of the Council of Europe Convention on preventing
and combating violence against women and domestic violence (ETS no. 210).

168   As the EU Network of Independent Experts on Fundamental Rights Commentary of the Charter, 2006, has
pointed out. Along the same line of reasoning, the Appeals Chamber of the ICTY.

169   The lesson of _Pohl et al. judgment, cited above, p. 969, should not be forgotten: even in the absence of_
evidence of ill-treatment, people may have been exploited if they were deprived of their freedom to reject certain
working conditions.

170 UNODC Th f “ l i i ” i d b 11


-----

**End of Document**

171   The same error was committed by the public prosecutor of Vienna: “First it does not result from the victims'
declarations that they were also exploited in Austria, since they managed to run away some few days after having
arrived in Austria.”

172   See paragraphs 8-24 of the judgment.

173   The denounced offence modalities of Beherbergen, sonstigen Aufnehmen and Befördern have the nature of a
“continuing criminal offence” or Dauerdelikt (Nimmervoll, cited above, note 6 to Article 104a; see also Rohlena v. the
_Czech Republic [GC], no. 59552/08, § 28, ECHR 2015)._

174   See paragraph 39 of the judgment.

175   In fact, in the United Arab Emirates Federal Law No. 51 of 2006 concerning Trafficking in Human Beings,
generally follows the Palermo Protocol and a National Committee to Combat Human Trafficking is active (UNODC, The
concept of “exploitation”, cited above, pp. 45-48). Moreover, the Anti-Human Trafficking Coordinating Unit created
within the Legal Affairs Department of the Arab League monitors the phenomenon of trafficking in the Arab region and
serves as a coordinating unit for the Arab States in their national implementation of laws against trafficking. The
Austrian authorities did not take these facts in account.

176   See paragraph 26 of the judgement. See also the UNGA Resolution on the UN Global plan of action to Combat
Trafficking in Persons, A/RES/64/293, 12 august 2010, the EU Declaration on trafficking in Human Beings, Towards
Global EU Action against Trafficking in Human Beings, 20 October 2009, and the Brussels Declaration on Preventing
and combating Trafficking in Human Beings, 29 November 2002, which all called for national law enforcement and
judicial agencies to take advantage of the operative support provided by existing international organisms on the fight
against trafficking.

177   Government's Reply to GRETA's Questionnaire, published in August 2010, Reply to question 53 (duty to
investigate ex officio).

178   See the 2016 USA Department of State Trafficking in Persons Report recommendations on Austria: “Sentence
convicted traffickers proportionate to the gravity of the crime; expand and enhance efforts to identify victims among
irregular migrants, asylum seekers, and individuals in prostitution; continue to sensitize judges on the challenges
trafficking victims face in testifying against their exploiters”; and along the same lines, the very useful recommendations
of the Arbeitsgruppe “Menschenhandel zum Zweck der Arbeitsausbeutung” Bericht 2012-2014, cited above, pp. 25-27,
d h B i h d M h h b i i d b 81 83


-----

