# R (on the application of T) v Secretary of State for the Home Department

 [2024] EWHC 640 (Admin)

King's Bench Division, Administrative Court (London)

Judge Dunne (sitting as a High Court judge)

22 March 2024Judgment

**Ms Harriet Short (instructed by Duncan Lewis Solicitors) for the Claimant**

**Ms Sian Reeves (instructed by the Government Legal Department) for the Defendant**

Hearing date: 5[th ]March 2024

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 22[nd] March 2024 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

**His Honour Judge Antony Dunne (sitting as a Judge of the High Court):**

**Introduction**

1. This is an application by the Claimant, MT, challenging the decision of the Secretary of State for the
Home Department ('SSHD') dated 14 September 2022 that there were no reasonable grounds to conclude
that the Claimant is a victim of modern slavery.

**Factual background and procedural history**

2. The Claimant is an Albanian national with a date of birth of 24[th] July 1995. On 9[th] May 2022 the
Claimant attempted to enter the UK in a small boat. On 10[th] May 2022 the Claimant claimed asylum which
was refused on 6[th] June 2022 on third country grounds and the Claimant was served with removal
directions. On 13[th] June 2022 the Claimant was referred into the National Referral Mechanism by Home
Office Immigration enforcement on the basis of **_modern slavery in Albania. A negative reasonable_**
grounds decision was made by the Immigration Enforcement Competent Authority (“IECA”) on the 14[th]
June 2022 which was reconsidered and again rejected on 17[th] June 2022. The Claimant requested
reconsideration of the negative reasonable grounds decision on 17[th] August 2022, and on 14[th] September
2022 the IECA made a further negative reasonable grounds decision giving reasons.

3. In its decision letter of the 14[th] September 2022, the IECA accepted, to the reasonable grounds
standard, the Claimant's factual account of working as a construction worker in Albania and accepted that
two of the three elements of the definition of modern slavery were made out to the reasonable grounds
standard; namely, that the Claimant was subject to the “action” of recruitment and the “means” of violence
were used against him. However, the IECA did not accept that the Claimant was recruited for the
“purposes of exploitation”, whether in the form of forced labour or forced criminality. The IECA therefore


-----

found, applying the reasonable grounds standard, that the third element of the definition of **_modern_**
**_slavery was not met. This is the decision under challenge._**

4. On 7[th] November 2022, the Claimant served a pre-action protocol letter upon the Defendant and on 14[th]
December 2022 the Claimant issued judicial review proceedings challenging the IECA's negative
reasonable grounds decision of 14[th] September 2022.

**Grounds of review and permission to apply for judicial review**

5. The grounds of judicial review are set out in the Claimant's statement of facts and grounds as follows:

“3. MT contends that IECA's decision is unlawful in that in finding that MT was not recruited for the
purposes of exploitation, the IECA has confined her analysis to MT's work on the construction site. MT's
case is that the unpaid work on the construction site made him vulnerable. His employers intended to
exploit him by forcing him into drug dealing. The IECA discounts consideration of this because MT escaped
before he was exploited. MT contends that this approach errs in law.”.

6. Permission was granted on the papers on 28[th] March 2023 on the following grounds:

“4. The SCA concluded, however, that the Claimant was not recruited for the purpose of exploitation. The
SCA reason given for that conclusion was in essence that the Claimant chose to work until he was not
paid, and then he decided to leave; and that he successfully resisted the employer's attempt to make him
sell drugs (and never did so).

5. In my judgment it is arguable that this reasoning failed properly to grapple with the key question, i.e. the
purpose of the employer, in the context of the factual background that had already been accepted as being
true and the other findings about how the Claimant had been recruited and treated.”

7. The parties therefore agree that the sole issue that arises in this claim is a narrow one, namely whether
the IECA erred in law in its assessment that the Claimant was not recruited for the purposes of exploitation.

**The Claimant's account**

8. The Claimant provided the IECA with an account in support of his claim that he is a victim of modern
**_slavery. This account was repeated in the IECA's decision of 14[th] September 2022 and as the IECA's_**
decision letter is adopted by the Claimant as containing an accurate record of the Claimant's account I set
it out in full below.

“You are [MT], a male national of Albania, born on 24.07.1995. You were looking for work in Shkoder,
Albania. You were offered a job in construction and agreed to work 9-10 hours a day, for €20 a day. You
started work in November 2021 and worked in construction for approximately for 5-6 months. You worked
for as long as they asked you to and you finished around 6-7 and then were given permission to go back
home. You would plaster and carry rocks around the site. You worked every day of the week and only
received a 20-minute break per day. Often, you were forced to work an extra 1-2 hours at the end of the
day before being allowed to go home. You used your own tools as you were not provided with any tools.
You asked for your money every month and your employer would make excuses, telling you, you would be
paid next month. You continued to work for your employer as you thought you would eventually be paid.
You were informed there were others who did not receive their salary. You were not given any food to eat
or any money to buy food and brought your own food to work from home. You were beaten once when you
asked for money, and your employer attempted to make you sell drugs, but you refused and decided to
leave. Your employer threatened you to come back and told you, if you did not return you would owe
€15,000. You chose not to return to work. Your employer threatened you and then you decided to leave
Albania.”

9. The Claimant supplemented this account in his witness statement dated 17[th] August 2022 as follows:

“19. It had been such a long time since I had any money, I still had not given any money to my mother and
I did not know what to do. I was scared because I did not know what was going to happen and what they
would do to me. I was so frightened that they would find and beat me again.


-----

20. My employer began to continuously call me and threaten me. I was told that if I did not agree to sell the
drugs, I owed him 15,000€. He told me it was pointless and I had nowhere to go.

21. Consequently, I changed my telephone number so that he could not contact me anymore. Despite this,
he discovered my new number and continued to harass and threaten me. I was told that I could not escape
him and anywhere he went, he would be able to find me.

22. Due to the threats that I was receiving, I knew I had to flee Albania. Albania is the kind of country where
everyone knows your business, and you have to register to do anything, so I knew that if I tried to go to a
different part of the country, he would find me. He had already traced my phone number. I was terrified for
my life. I was also scared that they would harm my family as they harmed me, especially as I was living
with my mother in Albania.”

**The Negative reasonable grounds decision of the IECA on 14th September 2022**

10. On 14[th] September 2022 the Defendant concluded that there were not reasonable grounds to believe
the Claimant was a victim of modern slavery and wrote to the Claimant explaining its decision.

11. In its decision letter the Defendant summarised the history of the claim and the Claimant's account in
the terms outlined at paragraph 8 above. The Defendant then summarised the US State Department's
2022 report on human trafficking in Albania which confirms that modern slavery occurs in Albania and it is
a country where individuals are subject to exploitation.

12. The Defendant then gave its reasons for its no reasonable grounds finding, as follows:

“The Reasonable Grounds decision applies the standard of proof 'I suspect but cannot prove'. This means
that to accept your account, it needs to be suspected that your version of events occurred as claimed and
that these events constitute **_modern slavery (human trafficking and or slavery, servitude and forced /_**
compulsory labour).

Careful consideration has been given to the assessment of the available information in your case. Looking
at the available sources of information [as listed earlier in the decision], it is recognised that you have been
broadly consistent in your account and there are not considered to be any significant credibility concerns
with your account.

Whilst your account is accepted applying the standard of proof 'I suspect but cannot prove', the
consideration below explains why the events are not deemed to constitute **_modern slavery (human_**
trafficking and or slavery, servitude and forced / compulsory labour).

CONSIDERATION

HUMAN TRAFFICKING

In order for a Reasonable Grounds decision to be made, the facts of your case have been considered in
line with the definition of trafficking above. The following is noted:

Incident 1: Construction work in Albania 2021

Action – part 'a'

In order to be considered to meet part 'a' you must have been subjected to an act of
transportation/recruitment/transfer/harbouring/receipt. You said you were looking for work in Albania to
support your family. You worked in construction site in Shkoder, Albanian, you agreed to work 9-10 hours a
day for €20 a day. It is, therefore, considered that you were subjected to an act of recruitment.

Means - part 'b'

In order to be considered a victim of trafficking you must have been transported / recruited / transferred /
harboured / received: “by means of threat or use of force or other form of coercion/of abduction/of fraud/of
deception/of abuse of power/of a position of vulnerability/of giving or receiving payments or benefits to
achieve the consent of a person having control over another person”. You said you worked for as long as
they asked you and you finished around 6-7 and were allowed to go back home You were not paid for the


-----

work during your time in construction. You were subjected to beating when you asked for your salary and
received threats to return to work. You decided not to return to work, subsequently you employer called
you and threatened you of €15,000 debt.

It is, therefore, considered that you experienced a threat or use of force and deception

Purpose – part 'c'

In applying part 'c' consideration must be given to whether you were
recruited/transported/transferred/harboured/received for the purpose of exploitation.

The description of forced labour is contained in the decision annex attached to this letter.

You said you were offered a job in construction and agreed to work 9-10 hours a day for €20 a day. You
worked for 5-6 months and were not paid for the time you worked. When you asked for your salary every
month and your employer would tell you, you would be paid next month. You chose to continue work for
your employer because you hoped that you would eventually be paid.

After 6 months you went to your employer to ask for your money, you were subjected to beating when you
asked for your money, and your employer attempted you to sell drugs, but you refused and decided to
leave. You then began to receive threats from your employer to return to work or you would have €15,000
debt.

It is noted that you employer informed you that you would be paid for the work which you undertook.
However, when you asked to be paid your employer informed you that his money was tied up but, you
would be paid. There were others who worked with you who were also not being paid, you were not alone
in this situation.

You made the conscious choice to continue working due to economic necessity as you have asserted you
needed to work due to your home situation. You continued working in the hope of payment and made the
choice to not return to work after you were beaten when asking for payment. It is therefore considered that
you voluntarily remained working for your employer out of economic necessity and when you realised that
you would receive no payment you left the employment.

Furthermore, you were not compelled to work, and you were not under any form of menace of penalty and
could have left the job at any time. After you had finished your work at the end of the day you were allowed
to go home. However, you choose to continue to work for the company as you were under the illusion that
you would be paid end of each month as promised, and this was not the case.

Additionally, you state that your employer attempted to make you sell drugs, but you refused and decided
to leave. It is clear to note that you did not sell drugs as when you were asked to sell drugs, you were not
willing to do so and therefore you left the employment, changed your number, and then subsequently left
the country to seek out employment abroad.

It is, therefore, considered that you were not subjected to forced labour or forced criminality, nor was there
an intention to subject you to this.

CONSIDERATION: SLAVERY, SERVITUDE AND FORCED OR COMPULSORY LABOUR

As you do not meet the three constituent elements of trafficking above, it is also considered that you do not
meet the two constituent parts of the definition of slavery, servitude and forced or compulsory labour.

SUMMARY

As you have not met either of the above, it is not necessary to consider whether you require a period of
recovery and reflection as per the Competent Authority guidance.

DECISION

Taken cumulatively, there are not considered to be reasonable grounds to believe that you were trafficked
within Albania and that you are a victim of modern slavery (human trafficking and or slavery, servitude, or
forced/compulsory labour).


-----

Consequently, a negative Reasonable Grounds decision has been made.”

13. The Defendant gave consideration as to whether it should modify its decision in its response to the
Claimant's pre-action correspondence. In its written response dated 19[th] December 2022, the Defendant
amplified its reasons for its decision that the “purpose of exploitation” definition and therefore the definition
of modern slavery was not met. The reasons were as follows:

“viii) It is considered that the intention of the employer was not to groom your client, but to recruit him in
order to offer construction work that he chose to enter into and continue doing over a period of time. The
employer then changed the work on offer to that of selling drugs; it is not considered that the period of
construction work was designed to groom your client for the role of selling drugs because of the level of
freedom afforded to the (sic,) him to attend work voluntarily due to his economic necessity.”

**Legal and Policy framework**

14. There was no dispute between the parties as to the applicable legal and policy framework in respect of
the identification of potential victims of trafficking (“PVOT”), an overview of which is set out below.

(a)          The definition of modern slavery

15. The applicable definition of human trafficking derives from the Protocol to Prevent, Suppress and
Punish Trafficking in Persons, Especially Women and Children, supplementing the United Nations
Convention against Transnational Organized Crime (the “Palermo Protocol”) and the Council of Europe
Convention on Action against Trafficking in Human Beings (“ECAT”).

16. Article 4(a) of ECAT defines “trafficking in human beings” as meaning:

“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
_force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position_
_of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person_
_having control over another person, for the purpose of exploitation. Exploitation shall include, at a_
_minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or_
_services, slavery or practices similar to slavery, servitude or the removal of organs;”_

17. Further guidance on the applicable definition of modern slavery is provided by the Explanatory Report
to ECAT, which explains that:

“4. In the definition, trafficking in human beings consists in a combination of three basic components, each
_to be found in a list given in the definition: –the action of: "recruitment, transportation, transfer, harbouring_
_or receipt of persons"; –by means of: "the threat or use of force or other forms of coercion, of abduction, of_
_fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of_
_payments or benefits to achieve the consent of a person having control over another person"; –for the_
_purpose of exploitation, which includes "at a minimum, the exploitation of the prostitution of others or other_
_forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or_
_the removal of organs”._

_75. Trafficking in human beings is a combination of these constituents and not the constituents taken in_
_isolation. For instance, "harbouring" of persons (action) involving the "threat or use of force" (means) for_
_"forced labour" (purpose) is conduct that is to be treated as trafficking in human beings. Similarly,_
_recruitment of persons (action) by deceit (means) for exploitation of prostitution (purpose)._

_76. For there to be trafficking in human beings ingredients from each of the three categories (action,_
_means, purpose) must be present together…_

_78. The actions the Convention is concerned with are “recruitment, transportation, transfer, harbouring or_
_receipt of persons”. The definition endeavours to encompass the whole sequence of actions that leads to_
_exploitation of the victim.”_

18. The explanatory report also provides further guidance as to the meaning of the “purpose” aspect of the
definition as follows:


-----

“87Under the definition, it is not necessary that someone has been exploited for there to be trafficking in
_human beings. It is enough that they have been subjected to one of the actions referred to in the definition_
_and by one of the means specified “for the purpose of” exploitation. Trafficking in human beings is_
_consequently present before the victim's actual exploitation.”_

19. The National Referral Mechanism (“NRM”) is the UK's framework for identifying and supporting victims
of **_modern slavery. Relevant guidance in respect of the NRM is set out in statutory guidance, namely_**
“Modern Slavery: Statutory Guidance for England and Wales (under s49 of the **_Modern Slavery Act_**
2015) and Non-Statutory Guidance for Scotland and Northern Ireland” (“the MSA Guidance”). Version 2.10
(which was published in June 2022) was the applicable version in place at the time of the reasonable
grounds decision on 14 September 2022. Chapter 2 of the MSA Guidance provides information about the
definition of modern slavery.

20. The MSA guidance provides the following assistance in relation to the key issue in this case, the
“purpose” aspect of the decision:

“Trafficked for the 'purpose of exploitation' – what if someone hasn't yet been exploited?

_2.23. Under the Convention on action Against Trafficking in Human Beings (ECAT), a person is a 'victim'_
_even if they haven't been exploited yet, for example because a police raid takes place before the_
_exploitation happens._

_2.24. This is because, under the definition of trafficking, trafficking occurs once certain acts are carried out_
_for the purpose of exploitation. So, it is the purpose which is key, rather than whether or not exploitation_
_has actually occurred. Even if the UK authorities intervene and prevent exploitation taking place in the UK,_
_victims may have experienced serious trauma in their home country or on the way to the UK and may still_
_be in need of support.”_

21. It is therefore clear that the definition of the “purpose of exploitation” includes acts using the required
means for the purpose of exploitation where exploitation has not taken place. Whether an act using the
required means is “for the purpose of exploitation” where exploitation has not taken place is a question
which was considered by the Court of Appeal in the case of MN & IXU v Secretary of State for the Home
_Department_ _[2020] EWCA Civ 1746 [2021] WLR 1956 (“MN & IXU”). IXU was a woman who had been_
subject to female genital mutilation and had, some years later, been trafficked to the UK where she was
married. The issue arose as to whether the “act” of female genital mutilation was for the “purpose” of
exploitation, when the alleged exploitation took place many years later. In the case of IXU this was termed
the “nexus” issue. It was suggested by Counsel for the Secretary of State in IXU that the Court should take
the following approach in narrowing the definition of “purpose” (at paragraph 340):

“The correct principles were that:

(1) any act of exploitation must be closely linked to the other acts which make up the elements of the
trafficking definition;

(2) an application of the definition of trafficking which allows experiences which are disparate in time to be
shoehorned together into a trafficking case risks broadening the definition of trafficking until it is rendered
hopelessly broad;

(3) where the line is to be drawn is a question of fact and degree to be decided in each case.”

22. At paragraph 342 of its judgment the Court of Appeal gave limited guidance on this question as
follows:

“342. In our view only limited general guidance can be given on the nexus issue. The concept of "purpose"
must be applied as a matter of ordinary language and common sense, having regard to what may
reasonably be supposed to be the intended scope of ECAT: in that regard there is real force in Mr Irwin's
second principle, though we should not be taken to be endorsing its precise wording. Taking that approach
to a case involving FGM (or, more accurately, taking a child away to be subjected to FGM), we accept Mr
Irwin's submission that it is necessary to assess the degree of the connection between the performing of


-----

the FGM and the intention (if proved) to force the child into marriage in any particular case. It is easy
enough at either extreme. If, say, the intended husband had said that he wanted to marry the child in
question but that she must undergo FGM first, it would be a natural use of language, and in accordance
with the aims of ECAT, to describe the FGM (or, rather, any associated taking away) as being for the
purpose of the forced marriage (which, as already established, constitutes exploitation). At the other
extreme, if the evidence were only that in a particular culture (1) girls were routinely taken away and
subjected to FGM at a young age in order to render them marriageable and (2) girls and women are
generally given no choice about who they have to marry, we do not think that that it would be natural to
describe the FGM, or the taking away, as being done for the purpose of exploitation. In between those two
extremes there will be a wide variety of circumstances, and it would not be appropriate for us to offer
guidance divorced from the particular facts found. The distinction between the two cases could be
characterised in terms of the degree of proximacy (the judge's term) or closeness (Mr Irwin's) of the act to
the intended exploitation; but we are wary of introducing glosses of this kind which may distract decisionmakers from the language of article 4 (a) itself. We certainly think that it is dangerous to substitute a test of
"immediacy": the distance of time between the act and any possible future exploitation will be relevant to
an assessment of whether the one is done for the purpose of the other, but it cannot be the touchstone.”

(b) The process of identifying victims of modern slavery

23. As set out above, a NRM has been established. Provision is made for the IECA to make decisions to
determine whether there are reasonable grounds to consider that an individual is a victim of trafficking ("a
Reasonable Grounds decision"). The statutory guidance in force at the time, provided further guidance on
the standard to be applied when considering a reasonable grounds decision, as follows:

_“14.50. The test that competent authority staff must apply is whether the statement:_

_'I suspect but cannot prove' the person is a victim of_ **_modern slavery (human trafficking or slavery,_**
_servitude, or forced or compulsory labour)'_

_• is true; or_

_• whether a reasonable person having regard to the information in the mind of the decision maker, would_
_think there are Reasonable Grounds to believe the individual is a victim of_ **_modern slavery (human_**
_trafficking or slavery, servitude or forced or compulsory labour.”_

24. If the IECA make a positive reasonable grounds decision, this is followed by a recovery and reflection
period before a decision is made by the Competent Authority whether there are conclusive grounds to find
that an individual is a victim of trafficking ("a Conclusive Grounds decision").

25. In this case the decision under challenge is the IECA's reasonable grounds decision.

**The parties submissions**

The Claimant

26. The Claimant's grounds are set out at paragraph 5 above. They were developed orally and in writing
as follows.

27. The Claimant's case was that he was recruited to the construction site for the purposes of exploitation,
even if that exploitation did not happen immediately. The Claimant accepts that his unpaid work at the
construction site did not amount to exploitation in the form of forced labour because he attended the site
voluntarily. The exploitation in the present case took the form of forced criminality, namely forced drug
dealing, even though the Claimant fled before that action was completed.

28. The Claimant submits

(a) The IECA's reason for discounting the attempt to sell drugs is on the basis that the exploitation had not
yet happened. The Claimant submits that this approach is unlawful, in reliance on paragraph 87 of the
ECAT Explanatory Report and the MSA guidance because the definition of “purpose of exploitation” does


-----

not require exploitation to have taken place and that trafficking in human beings is consequently present
before the victim's actual exploitation.

(b) The Defendant's claim that the sentence in its decision letter “that you were not subjected to forced
labour or forced criminality, nor was there an intention to subject you to this” refers to the intention to
subject the Claimant to forced criminality is irrational. This interpretation is said to be inconsistent with the
previous statement in the decision letter “You were beaten once when you asked for money, and your
employer attempted to make you sell drugs” because the plain meaning of this sentence is that the
employer intended to subject the Claimant to forced Criminality. In oral submissions the Claimant said that
the act of recruitment was a continuing one and therefore the attempt to force the Claimant to supply drugs
was contemporaneous with the act of recruitment. The employer must therefore have had the intention to
force the Claimant into criminality and exploit him at the same time as he was recruited.

(c) The Defendant's reliance upon the reasoning set out in the PAP response dated 19 December 2022
referred to in paragraph 13 above wants of reason. It is submitted, the employer did not 'change the work
on offer'. Instead, when the Claimant tried to leave, and/or tried to ask for the money he was due, the
Employer threatened to force him into criminality. He intended to force him into criminality, but was
thwarted by the Claimant's escape. The threat of drug dealing was enforced by the menace of a penalty.
While the unpaid work was essential to understanding the context and background to the alleged
exploitation, it was the threat of forced criminality which the Claimant contends makes out the “for the
purposes of exploitation” element of the definition.

(d) The Defendant's reference to the case of MN & IXU and the nexus issue should be disregarded. First it
is claimed there was no reference to the “nexus” issue in the decision letter. Second, the recruitment,
deprivation of his wages, and intention to force him into criminality were all part of a continuing chain of
events for the purposes of exploiting him.

The Defendant

29. The Defendant observes that the Claimant contends that the reasonable grounds decision is unlawful
because of an error of law and refers to the statement of grounds quoted at paragraph 5 above. The
Defendant infers from the Claimant's pleaded case the Claimant's error of law challenge is put on two
bases:

(a) First, that the IECA has “confined her analysis to MT's work on the construction site”.

(b) Second, it is said that the IECA has discounted consideration of his employer's intention to exploit him
by forcing him into selling drugs because the Claimant escaped before he was exploited. The Claimant
contends that this is an error of law because the component elements of trafficking may be present before
actual exploitation, by reference to §87 of the Explanatory Report to ECAT.

30. In relation to the basis of claim, the Defendant submits the IECA did consider the Claimant's account
of his employer's attempt to make him sell drugs. The IECA adequately and lawfully directed itself to
whether the Claimant's account amounted to forced criminality and as to whether it satisfied the “purpose”
component of the definition.

31. The Defendant submits the IECA considered the Claimant's case that the intention of the employer
was to groom the Claimant into a position of vulnerability and whether this was for the purposes of
exploiting him into forced criminality and lawfully concluded that it did not. That this broader context was
considered is clear from the following part of the decision letter, which follows an analysis of both the
Claimant's work on the construction site and the threats that he must sell drugs:

“It is, therefore, considered that you were not subjected to forced labour or forced criminality, nor was there
an intention to subject you to this.”

32. The Defendant also submits that the PAP response demonstrates that the IECA had taken account of
the purpose of the employer at the time of the recruitment and had reasonably concluded that the purpose
of the recruitment at the time was to offer construction work.


-----

33. The Defendant submits the IECA's conclusion on intention and whether the act of recruitment was for
the purpose of forced criminality is also supported by the lack of proximity or nexus between the initial
recruitment and the threat to sell drugs. On the Claimant's own case, the attempt to force him into selling
drugs occurred some 5-6 months after he started work on the construction site.

34. The Defendant submits the IECA were entitled to find that the initial recruitment and subsequent
attempt to force the Claimant to sell drugs were not part of a continuing chain of events. They say there
was no error of law in the IECA's approach to this issue or the conclusion that “the intention of the
employer was not to groom your client, but to recruit him in order to offer construction work that he chose
to enter into and continue doing over a period of time”.

**Discussion and conclusions**

35. I will deal with the issues by reference to the Claimant's submissions as set out at paragraph 28
above.

The Defendant unlawfully discounted the attempt to force the Claimant to supply drugs (Paragraph 28(a))

36. The Claimant's primary submission is that the IECA discounted the attempt by the Claimant's
employer to force the Claimant to sell drugs because it had not yet happened. The Claimant submits this
approach is unlawful because the definition of “purpose of exploitation” specifically excludes the need for
the exploitation to have taken place.

37. The Claimant's submission is, in my view, based upon a flawed reading of the Defendant's decision
letter. The Claimant correctly points out that the Defendant makes observations about the Claimant's
account as follows:

“Furthermore, you were not compelled to work, and you were not under any form of menace of penalty and
could have left the job at any time. After you had finished your work at the end of the day you were allowed
to go home. However, you choose to continue to work for the company as you were under the illusion that
you would be paid end of each month as promised, and this was not the case.

Additionally, you state that your employer attempted to make you sell drugs, but you refused and decided
to leave. It is clear to note that you did not sell drugs as when you were asked to sell drugs, you were not
willing to do so and therefore you left the employment, changed your number, and then subsequently left
the country to seek out employment abroad.”

38. However, I accept the Defendant's submissions that these paragraphs do not record the Defendant's
conclusion as to whether the Claimant's account fulfilled the “purpose of exploitation” element of the
definition. That conclusion is reached in the next paragraph of the decision letter as follows:

“It is, therefore, considered that you were not subjected to forced labour or forced criminality, nor was there
an intention to subject you to this.” (my emphasis)

39. In this paragraph the Defendant did conclude that the Claimant was not exploited either in the form of
forced labour or forced criminality. This was a factually correct conclusion based upon the Defendant's
analysis of the Claimant's account. It is said by the Claimant this conclusion means that the Defendant
erred in its approach to the definition of the “purposes of exploitation” because it discounted the attempt to
force the Claimant to sell drugs. But, crucially, the Defendant's conclusion on this issue did not end there.
The Defendant went on to say “nor was there an intention to subject you to this”. The obvious meaning of
this conclusion by the Defendant is that there was no intention to subject the Claimant to either forced
labour or forced criminality because the word “this” in the phrase “nor was there an intention to subject you
to this” must refer to both forced labour and forced criminality.

40. The Claimant says that this cannot be the correct interpretation because the Defendant could not
rationally reach the conclusion there was no intention to subject the Claimant to forced criminality. The
Defendant had recorded in the preceding paragraph “You were beaten once when you asked for money,
and your employer attempted to make you sell drugs” and the plain meaning of that sentence is that the
employer intended to subject the Claimant to forced criminality


-----

41. I disagree with the Claimant's submissions on this point. In my view, the plain meaning of the
Defendant's conclusion “It is, therefore, considered that you were not subjected to forced labour or forced
criminality, nor was there an intention to subject you to this.” was that there was no intention to subject the
Claimant to either forced labour or forced criminality. This interpretation is not altered by considerations of
rationality because, for reasons I will explain later in this judgment, this was a conclusion the Defendant
was entitled to reach.

42. The Defendant did not therefore discount the attempt to force the Claimant to sell drugs, because the
Defendant did consider whether there was an intention on the part of the employer to force the Claimant to
sell drugs and concluded, to the reasonable grounds standard, that there was not. I conclude the
Defendant therefore applied the definition of the “purposes of exploitation” correctly and correctly followed
the MSA guidance. The Defendant did not make an error of law.

The Defendant could not rationally reach the conclusion there was no intention to exploit the Claimant
(Paragraphs 28(b), (c) and (d))

43. The Claimant submits the Defendant could not have rationally reached the conclusion there was no
intention to exploit the Claimant and that the “purpose of exploitation” definition was not met.

44. The Defendant complained that this submission was an irrationality challenge which went beyond the
Claimant's grounds for review set out at paragraph 5 above and the scope of permission set out at
paragraph 6 above. During the hearing I asked counsel for the Claimant whether she wished to amend the
grounds of review to include a claim that the Defendant had acted irrationally. She said she did not.

45. The Claimant's submissions that the Defendant could not rationally reach the conclusion that there
was no intention to subject the Claimant to forced criminality and that the “purposes of exploitation”
definition was not met, in my view, do go beyond the grounds of review for which permission was granted.

46. In any event, the Claimant's submissions lack merit. The Defendant's decision that the “purposes of
exploitation” definition was not met was a decision it was entitled to come to and was not irrational. I reach
that conclusion for the reasons set out below.

47. The ECAT definition of trafficking and the ECAT guidance states that the actions of “recruitment,
transportation, transfer, harbouring or receipt of persons” must be for the “purposes of exploitation”.

48. In this case, it is agreed by the parties, the Claimant was first recruited to work on the construction site
six months before the demand was made to him that he supply drugs.

49. The Defendant, in its letter of 19[th] December 2022, explained that, in its view, the purpose of the
recruitment was to offer the Claimant construction work and that at the time of the recruitment the employer
did not have the intention to groom the Claimant into selling drugs six months later. The Claimant
submitted that the employer pursued a continuous course of conduct of exploiting him and it could
therefore be inferred that the purpose of the employer when he recruited the claimant was to exploit him by
forcing him into crime if he refused to continue to work on the construction site. In my view, in the absence
of evidence from the employer, the conclusions of the Defendant and the Claimant are both inferences that
could possibly be drawn from the evidence of the Claimant's account. However, in my view, the inference
that the Defendant has drawn is the more plausible conclusion because: (a) the demand to sell drugs was
made six months after recruitment; (b) the Claimant worked for the Defendant in this period, but was
allowed to go home at the end of every day; and (c) the suggestion that the employer had always intended
to exploit the Claimant and had been grooming him for purposes of crime for the 6 month period is too
speculative. In my view, it cannot possibly be said that the Defendant acted irrationally when it concluded
to the reasonable grounds standard that there was no intention to exploit the Claimant at the time of
recruitment.

50. In reaching the above conclusion I have applied the common sense guidance from the Court of Appeal
in the case of MN & IXU, in particular the following passages from paragraph 342 of the judgment:

“The concept of "purpose" must be applied as a matter of ordinary language and common sense, having
d t h t bl b d t b th i t d d f ECAT”


-----

and

“We certainly think that it is dangerous to substitute a test of "immediacy": the distance of time between the
act and any possible future exploitation will be relevant to an assessment of whether the one is done for
the purpose of the other, but it cannot be the touchstone”

I have not applied any test of “immediacy” or “nexus” in reaching my conclusions.

51. The Claimant made additional oral submissions that the Claimant's recruitment was a process that
continued throughout his employment. The Claimant submitted that as a result the “act” of recruitment was
ongoing when the Claimant was asked to sell drugs six months into his employment. The Claimant submits
that because the act of recruitment was contemporaneous with the demand to sell drugs, the employer
must have intended to recruit the Claimant for the purpose of selling drugs.

52. In my view the Claimant's suggested definition of “recruitment” distorts the natural meaning of the
word. The word “recruitment” means the process of selecting people for work. Recruitment is therefore an
action that takes place at the start of the employment relationship and is not a continuing process. In the
context of **_modern slavery, the ECAT guidance provides some support for this interpretation of the_**
definition of recruitment, or at the very least does not undermine it. Paragraph 78 of the ECAT guidance
states that the ECAT definition of recruitment, transportation, transfer, harbouring or receipt of persons
“endeavours to encompass the whole sequence of actions that leads to exploitation of the victim”.
“Recruitment” is the first of those actions in the sequence, which is consistent with the natural meaning of
the word. In my view, the Defendant's conclusion, to the reasonable grounds standard: (a) that the
Claimant was recruited at the time he was asked to work on the building site six months before he was
asked to supply drugs; and (b) that it could not therefore have been the employer's purpose at the time of
the act of recruitment to exploit the claimant; was a conclusion that was neither wrong in law nor did the
Defendant act irrationally in reaching it.

**Conclusion**

53. For all of the above reasons the application for judicial review is refused.

**End of Document**


-----

