# R v Parczewska [2021] EWCA Crim 750

CA, CRIMINAL DIVISION

202000955/C1

Singh LJ, Hilliard J, HHJ Bate

Friday 23 April 2021

23/04/2021

1. MR JUSTICE HILLIARD: On 22 February 2019, in the Crown Court at Birmingham, the appellant was convicted
of three offences of conspiracy. On 8 March 2019, she was sentenced as follows: count 5, conspiracy to require
another to perform forced or compulsory labour, 6 years' imprisonment; count 6, conspiracy to control another for
the purposes of labour exploitation, 8 years' imprisonment; count 7, conspiracy to acquire criminal property, 6 years'
imprisonment. All those sentences were ordered to run concurrently, making a total sentence of 8 years'
imprisonment.

2. On 16 May 2019, her appeal against sentence was allowed by this Court _[[2019] EWCA Crim 1026. The](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VXS-GW82-D6MY-P1V6-00000-00&context=1519360)_

sentence on count 5 was reduced to five‑and‑a‑half years' imprisonment, on count 6 to five‑and‑a‑half years'

imprisonment and on count 7 to 4 years' imprisonment. Again all the sentences were to run concurrently, making

five‑and‑a‑half years' imprisonment in all. On 14 February 2020, the appellant was ordered in the Crown Court to

pay a confiscation order in the sum of £88,000, pursuant to section 6 of the Proceeds of Crime Act 2002.

3. There were a number of co‑accused. Merek Chowaniec was sentenced to a total of 11 years' imprisonment;

Marek Brzenzinski to 9 years' imprisonment; Juliana Chodakiewicz to 7 years' imprisonment; Natalia Zmuda to 4
years and 6 months' imprisonment; and Ignacy Brzezinski to 11 years' imprisonment.

4. The appellant appeals against the confiscation order with the leave of the single judge. She has the advantage
of having been represented before us by Mr Rose of counsel who has said everything that could be said on her
behalf but in a focused and structured way which has been of considerable assistance to us.

5. The case concerned the activities between 2012 and 2017 of an organised crime group led by Adam Brzezinski
(the son of the appellant) and Ignacy Brzezinski. All three lived at 22 Beechwood Road in West Bromwich. The
victims in the case were all Polish nationals who were recruited in Poland and duped into travelling to the United

Kingdom with the promise of well‑paid employment and accommodation. Upon arrival, they were given

employment but most of their wages were taken from them and they were forced to live in overcrowded, inadequate
and insanitary conditions. They were required to open bank accounts so that their wages could be paid into them
but they did not receive the banking paperwork or the cards associated with the accounts. A large proportion of
their wages would be withheld from them to cover the costs of transport, accommodation and food. They were

bullied and intimidated and, on occasions, beaten. Thirty‑one properties were used to house the trafficked workers.

The court heard from 66 complainants. There were over 200 other individuals who featured. Some of these were
complainants who had provided statements to the police but then fell out of contact or who did not want to assist in
the investigation.


-----

6. Marek Brzenzinski is a cousin of Ignacy Brzezinski. Merek Chowaniec is a friend of the family and referred to as

"the right‑hand man" of Adam Brzezinski. Chowaniec was in a relationship with the co‑accused, Natalia Zmuda.

Juliana Chodakiewicz worked at an employment agency in Worcester and provided advice to Merek Chowaniec as
to how the victims could be trafficked into regular work under the control of the conspirators.

7. The appellant was described as “the matriarch" of the Brzezinski family. It was the prosecution case that she
facilitated the smooth operation of the family business from her home at Beechwood Road. Her home was often
the first arrival point for the trafficked men and women. She kept bank cards. Money was withdrawn from the bank
accounts of complainants and others. On occasion, she visited the houses in which they were kept. She also
concealed the identity of a deceased man who had been living in one of the houses. When the property at
Beechwood Road was searched, a large amount of banking documentation was found there.

8. Before turning to the judge's ruling on confiscation, it is as well to set out at this stage what Davis LJ said when
giving the Court's judgment on the appellant's appeal against sentence. He said this at paragraph 74:

"It is plain enough that she had a general knowledge, in general terms, of what was going on. But, on the judge's
findings, her active participation was relatively limited, even if she could be described as 'the matriarch'. In effect,
she had left strategic decisions to others and she personally had been kind to complainants; certainly some of them
had in evidence spoken out favourably of her. Clearly she must have had some awareness of the squalid living
conditions in which some of the complainants were living because she visited one or two of the properties, and of
course she had had various specific involvements in keeping of bank cards and obtaining money withdrawals in
some cases, and in concealing the identity of a deceased man who had been living in one of the houses in one
other specific instance. But overall, even on the judge's own findings, she does seem to have been very much lower
down in the scheme of things as compared to others, such as Merek Chowaniec and Marek Brzezinski. We think
that there is real force in Mr Rose's complaint that the judge took too high a starting point in her particular case.

Moreover, in her case we think it important to give significant weight to her major health issues, both physical and
psychological. That was an important aspect of mitigation in her case."

9. The court went on to reduce her sentences in the way we have indicated.

10. Subsequently, the prosecution sought a confiscation order, under section 6(3)(a) of the Proceeds of Crime Act
2002. The benefit figure was put at £1,714,671.61 and the prosecution argued that the appellant was for, practical
purposes, an equity partner who obtained the full amount which accordingly should be declared as her benefit. The
£1.7 million figure included wages and benefits payments paid into a large number of accounts totalling over £1.5
million.

11. On the appellant's behalf, it was argued that she could not have been said to have obtained the property or be
considered an equity partner in the enterprise for the purposes of section 76 of the 2002 Act. It was said that her
role was very limited and that to treat her as an equity partner was not supported by the evidence.

12. The judge reminded herself that, in contrast to the sentencing exercise, for the purposes of asset recovery,
findings were made on the balance of probabilities. She said that when applying the civil standard, the prosecution
assessment of the total benefit was very fair to all the defendants. Whilst for sentencing purposes the appellant's
involvement was not at the most significant and strategic level, for the purposes of asset recovery she was a

co‑obtainer of the total benefit. She was, said the judge, at the heart of the operation and the judge did not accept

the assertion that her involvement had stopped by 2015.  The judge said that although the appellant's active
participation was more limited than that of some of the others, it did not mean her benefit was equally limited. She
merely had to work less hard for it as befitted an elder, respected family member. As the matriarch of the family
business of human trafficking, she was an equity partner or joint obtainer.

13. Addressing the argument that the Court of Appeal found that the appellant had been "very much lower down in
the scheme of things as compared to the others" and that her active participation was relatively limited, the judge
said that those findings were made for sentencing to the criminal standard and not for the purposes of asset


-----

confiscation. She concluded that the evidence proved to the civil standard that the appellant had obtained the
money together with the major conspirators and jointly benefited from it. She was an obtainer of the £13,000 cash
found at her house and also of the contents of the bank accounts of the bank cards with the PIN numbers written on

the back. The judge did not consider that the appellant was in thrall to her son or merely a money mule ‑ she in fact

controlled the house. The judge said that the Act did not require the court to adjudicate on shares of benefit jointly
obtained but there was sufficient evidence, and the prosecution had proved to the civil standard, that the appellant
had obtained the assets together with other senior family members.

14. For completeness sake, we should add that the judge found that Ignacy Brzezinski was, like the appellant (his
partner), an equity partner in what was effectively the family business and enjoyed the full fruits of the benefits of
what was "a highly profitable conspiracy". His benefit was assessed in the same figure. However, since no assets
could be traced in relation to him, a nominal order was made in the sum of £1.

15. Although the trial had been a long and complex one, the issues for us are more straightforward. There is no
dispute about the applicable statutory provisions, or about how they should be interpreted following the decision of
the Supreme Court in R v Ahmad [2014] UKSC 14. It comes down to this: had the respondent proved to the civil
standard that the appellant had obtained the property in question? It was argued before the judge in the Crown
Court, and before us today that the evidence was insufficient to enable the judge to come to such a conclusion; that

the appellant was in no different position to co‑accused where a different conclusion was reached; and that the

conclusions set out by the Court of Appeal when allowing the appeal against sentence ought to govern the position
here too.

16. Notwithstanding the way in which the argument has been put, we do not agree.  The judge was engaged in a
different exercise as she was well aware when looking at the question of benefit to the civil standard of proof, from
the exercise of looking to see what could be established to the criminal standard for the purposes of sentence. On
any view, the judge was well placed to decide these matters having conducted a trial which had lasted for many
months. By the time she came to give her decision as to proceeds of crime she knew what this Court had said
when allowing this appellant's appeal against sentence. We cannot do better than set out some of what the judge
said about the appellant:

"Whilst for sentencing purposes her involvement was not at the most significant and strategic level of that of some

of her other family members, I have no doubt that for asset recovery purposes she was a co‑obtainer of the total

benefit. She was at the heart of the operation and I do not accept the assertion that her involvement stopped by 21
October 2015, although it is correct that by that date the police investigation had already succeeded in disrupting
the conspiracy to a considerable degree. She may well also have stopped playing such a visible role after she
became known to the police who had searched her house by that time, and other family members were brought in
to help to withdraw cash from cashpoints.

But as is made clear in Ahmad, role and reward are not synonymous; in other words, although her active
participation was more limited than some of the others it does not mean her benefit was equally limited. She merely
had to work less hard for it as befits an elder, respected family member. But she was still active and hands on. As
the matriarch of the family business of human trafficking and forced labour and other forms of exploitation, she was
an equity partner or joint obtainer.

Her friendliness towards the complainants is neither here nor there in analysing the level of her benefit although it
was an important feature of the sentencing exercise to bear in mind that she was kind to some of them. She also
misled and duped them. For example, reassuring one of them that her son would never not pay them the wages
they were due when she must have known the contrary to be the case.

Addressing the argument that the Court of Appeal found that she had been very much lower down in the scheme of
things as compared to the others and that her active participation was relatively limited, those findings were made
for sentencing, not asset confiscation purposes, on the criminal standard. The evidence proved to the civil standard
that she obtained the money together with the major conspirators and jointly benefited from it. I find that she was


-----

an obtainer of the £13,000 cash found at her house and also of the contents of the bank accounts of the bank cards
with the PIN numbers written on the back that were found in her house. She controlled the house. Similarly, the
fact that she had major physical and psychological health issues is not relevant to her obtaining a benefit together
with other central family members although it was of course important personal mitigation when it came to her
sentence.

Also problematic for her in her denial of obtaining any benefit over any of the fruits of the conspiracy is the gap
between her ostensibly living only on benefits and, prior to that, a minimal wage cleaning job and the manner of her
living at 22 Beechwood Road with all its contents and immaculate and expensive decoration, and her own assertion

that she also sent £50‑£70 payments to Poland to her parents could not be supported only by State benefits. A

telling insight into the extent to which it was a family operation is gleaned from the photograph in pride of place, next
to the television in her living room alongside other family photographs, which showed two young girls in Burberry
dresses posing in her living room at 22 Beechwood Road, sitting on a heap of cash and waving bundles of notes at
the camera in a quite literal sense demonstrating that the family was 'in the money'. It was business from which the
family benefited and her links to the cash, the cards, the properties and the complainants demonstrate that she

jointly obtained the benefit from it. She was not a stand apart wife and mother but an actively involved hands‑on,

inner circle, close family business member co‑obtainer, even if not at a strategic decision‑making level. The Act

does not require the court to adjudicate on shares of benefit jointly obtained but there is sufficient evidence before
the court that the prosecution have proved, to the civil standard, from all the evidence before the court during her

5‑month trial, that she obtained the assets together with other high up family members in the conspiracy, as

demonstrated by her house as head office, her direct involvement with bank cards, dealings with the trafficked
workers, the properties they were housed in and cash handling."

17. In our judgment, the judge correctly directed herself as to the law. No error has been shown. As far as the
evidence is concerned, the passage we have quoted is a sufficient justification for the conclusions that she reached
and is expressed in clear and comprehensive terms.

18. We come to the second ground, although Mr Rose conceded that if the first ground failed, for all practical
purposes, so would the second. The second ground of appeal is that the judge was wrong to include the value of a
property that the appellant owns in Poland in the assessment of the available amount. The property was valued at
£76,000. Mr Rose argues that this was disproportionate and an unjustified interference with the appellant's right to
the peaceful enjoyment of her possessions pursuant to Article 1 of protocol 1 to the European Convention on
Human Rights. Mr Rose says that assuming the appellant returns to Poland, she would live in this property.

19. The respondent points out that the Proceeds of Crime legislation is there to deprive people in the appellant's
situation of the proceeds of crime.  The respondent argues that having lived off the proceeds of modern slavery
offences for many years and jointly obtained over £1.7 million, it cannot be said that to deprive her of an asset
valued at £76,000 is disproportionate. The appellant did not give evidence in the confiscation proceedings to say,
for example, that she would not be able to live with relatives or, if necessary, seek the support of the Polish
authorities. We think that there is force in all those submissions for the purposes of this particular case.

20. Again, notwithstanding the way the argument has been put, in our judgment, the judge was justified, on the
basis of the material before her, in including the value of the house in the available amount. In those circumstances
the appeal must be dismissed.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk


-----

**End of Document**


-----

