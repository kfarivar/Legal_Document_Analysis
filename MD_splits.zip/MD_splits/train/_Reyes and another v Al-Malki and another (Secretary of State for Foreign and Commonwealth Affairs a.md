others intervening) [2015] EWCA Civ 32

# *Reyes and another v Al-Malki and another (Secretary of State for Foreign
 and Commonwealth Affairs and others intervening) [2015] EWCA Civ 32

Court of Appeal, Civil Division

Lord Dyson, MR, Lady Justice Arden and Lord Justice Lloyd Jones

5 February 2015

**Constitutional law — Diplomatic privilege — Immunity from legal process — Claimant domestic workers**
**issuing proceedings against defendant Saudi diplomatic agent and wife in employment tribunal —**
**Defendants claiming diplomatic immunity — Employment Appeal Tribunal upholding claim to immunity, but**
**finding service being validly effected — Claimants appealing and defendants cross-appealing — Whether**
**defendants being entitled to immunity — Whether service being validly effected — Human Rights Act 1998,**
**s 3 — European Convention on Human Rights, arts 4, 6 — Vienna Convention on Diplomatic Relations**
**1961, arts 22, 29, 31, 37 — Vienna Convention on the Law of Treaties 1969.**

**Race relations — Discrimination — Employment — Claimant domestic workers issuing proceedings**
**against defendant Saudi diplomatic agent and wife in employment tribunal — Defendants claiming**
**diplomatic immunity — Employment Appeal Tribunal upholding claim to immunity, but finding service**
**being validly effected — Claimants appealing and defendants cross-appealing — Whether defendants being**
**entitled to immunity — Whether service being validly effected — Human Rights Act 1998, s 3 — European**
**Convention on Human Rights, arts 4, 6 — Vienna Convention on Diplomatic Relations 1961, arts 22, 29, 31,**
**37 — Vienna Convention on the Law of Treaties 1969.**
Judgment

**Mr Timothy Otty QC and** **Mr Paul Luckhurst (instructed by** **ATLEU at Islington Law Centre) for the**
**Appellants**

**Sir Daniel Bethlehem QC and Mr Sudhanshu Swaroop (instructed by Reynolds Porter Chamberlain**
**LLP) for the Respondents**

**Mr Tim Eicke QC and Ms Jessica Wells (instructed by The Treasury Solicitor) for the 1st Intervener**

**Dr Tom Hickman (instructed by Deighton Pierce Glynn) for the 2nd Intervener**

**Mr Arfan Khan and Mr Tahir Ashraf (instructed by 4A Law) for the 3rd Intervener**

JUDGMENT: APPROVED BY THE COURT FOR HANDING DOWN (SUBJECT TO EDITORIAL CORRECTIONS)

LORD DYSON MR:

1. In 2011, the claimants were employed as domestic workers by the respondents, a Saudi diplomatic agent and his
wife. The claimants worked at the first respondent's official diplomatic residence. The UK Visas and Immigration
(“UKV1”), which is a division of the Home Office, has determined that both women are the victims of trafficking. The
respondents have now left the UK.


-----

others intervening) [2015] EWCA Civ 32

2. Ms Reyes (who is a Philippine national) worked for the respondents from the date of her arrival in the UK on 11
January 2011 until 14 March 2011, when she left with the assistance of the police. The respondents then replaced
Ms Reyes with Ms Suryadi (who is an Indonesian national). She worked for the respondents from the date of her
arrival in the UK on 16 May 2011 until 19 September 2011, when she left the residence whilst Mr Al-Malki was away
and Mrs Al-Malki was asleep.

3. Both claimants made claims to the Employment Tribunal (“ET”) alleging, inter alia, that they had suffered racial
discrimination and harassment, and had been paid less than the national minimum wage. The proceedings were
served by post on the respondents' solicitors and by post to their private residence. The respondents claimed
diplomatic immunity pursuant to articles 31 and 37 of the Vienna Convention on Diplomatic Relations (“the 1961
Convention”) which is incorporated into English law by virtue of section 2 of the Diplomatic Privileges Act 1964 (“the
1964 Act”).

4. Article 31(1)(c) of the 1961 Convention lies at the heart of this appeal. It provides:

“A diplomatic agent shall….enjoy immunity from the receiving State's civil and administrative jurisdiction,
except in the case of:

…

(c) an action relating to any professional or commercial activity exercised by the diplomatic agent in the
receiving State outside his official functions.”

5. Four issues arise on this appeal. These are: (i) whether, applying the principles of interpretation set out in the
Vienna Convention on the Law of Treaties 1969 (“the VCLT”), a contract of employment entered into by a serving
diplomatic agent with a domestic worker is to be characterised as “commercial activity exercised by the diplomatic
agent in the receiving State outside his official functions” and is therefore within the exception to diplomatic
immunity contained in article 31(1)(c) of the 1961 Convention; (ii) if not, whether granting a serving diplomat
immunity in respect of a claim under a contract of employment with a domestic worker in accordance with article
31(1) of the 1961 Convention constitutes a breach of article 6 of the European Convention on Human Rights (“the
ECHR”); and (iii) whether, on the assumption that Ms Reyes is able to prove that she was trafficked, granting
immunity to a serving diplomat constitutes a breach of article 4 of the ECHR; and (iv) whether, regardless of the
issue of immunity, a diplomat also has immunity from formal service of proceedings.

6. The claimants were successful before the ET. Judge Lewis held that “the exception under art 31(1)(c) of the
Vienna Convention, read consistently with art 6 of the European Convention on Human Rights, applied”. On appeal
to the Employment Appeal Tribunal (“EAT”), Langstaff J (President) upheld the claim to immunity. He held first that
the activity of employing a domestic worker was not within the scope of the Mr Al-Malki's official functions as a
diplomat (the claimant having conceded for the purposes of the appeal to the EAT that this was not a “commercial
activity”). Secondly, the assertion of diplomatic immunity in the present case was not in breach of article 6 of the
ECHR. Thirdly, the ET's jurisdiction, being statutory, did not extend to the investigation of trafficking and therefore
the claim based on article 4 of the ECHR would be rejected. Fourthly, he held that service had been validly effected:
by post on the respondents' solicitors, who were already acting for them, and/or by post to the respondents'
residence.

7. Ms Reyes appeals against the EAT's decision, seeking a restoration of the ET's finding that “the first and second
respondents do not have diplomatic immunity from the claims”. The respondents cross-appeal against the decision
on the issue of service. Ms Suryadi had ceased to take part in the appeal by the time of the hearing.

_Article 31(1)(c) of the 1961 Convention_

8. Mr Otty QC submits that the proceedings fall with the scope of article 31(1)(c) of the 1961 Convention. There are
several strands to his argument. First (and at its most basic level), he says that a contract of employment by a
diplomatic agent of a person to provide domestic services is “commercial activity”. He also (and separately) says
that it is activity “outside [the diplomatic agent's] official functions”. Secondly, and in any event, he says that a


-----

others intervening) [2015] EWCA Civ 32

contract to employ such a person where he or she is the victim of trafficking is a “commercial activity outside his
official functions”. He submits that both of these conclusions are reached by giving the language of article 31(1)(c)
its natural and ordinary meaning, taking account of other material provisions of the 1961 Convention to which I shall
refer later. Thirdly, he submits that this interpretation is supported by (i) the common law principle that statutes (in
this case, the 1964 Act) are to be interpreted in a manner which is consistent with the United Kingdom's obligations
in international law; (ii) the statutory interpretative obligation imposed by section 3 of the Human Rights Act 1998
(“the HRA”) by reference to articles 4 and 6 of the ECHR that, so far as it is possible to do so, primary legislation
“must be read and given effect in a way which is compatible with the [ECHR] rights”; (iii) the statutory interpretative
obligation flowing as a matter of European Union law from section 2(1) of the European Communities Act and
article 47 of the Charter of Fundamental Rights of the European Union (“the Charter”); and (iv) a proper application
of the interpretative principles set out in the Vienna Convention on the Law of Treaties (“VCLT”).

9. I prefer to start with the question of whether, on a proper application of the interpretative principles set out in the
VCLT, an ordinary contract of employment between a diplomat and a domestic worker for the provision of domestic
services at the diplomat's official residence is a “commercial activity” without reference to any other principles of
interpretation. By “ordinary contract of employment”, I mean a contract which is not infected by trafficking.

10. Article 31 of the VCLT provides, so far as material:

“1. A treaty shall be interpreted in good faith in accordance with the ordinary meaning to be given to the
terms of the treaty in their context and in the light of its object and purpose.”

_Ordinary meaning_

11. I shall start with ordinary meaning. The first instance decision of Laws J in _Propend Finance Pty Ltd v Sing_
(1997) 111 ILR 611 is the only domestic authority to have addressed the meaning of “commercial activity” in article
31(1)(c). Laws J referred to article 42 of the 1961 Convention which provides:

“A diplomatic agent shall not in the receiving State practise for personal profit any professional or
commercial activity.”

12. He said (at p.635) that the phrase “professional or commercial activity” means the same in article 42 as in article
31(1)(c) and continued:

“….the phrase refers to activity which might be carried on by the diplomat on his own account for profit;
such “professional” activity would arise, for example, in the perhaps unlikely event that the diplomat was a
qualified doctor who engaged in some medical practice during his tour of duty”.

He added that the very rationale of article 31(1)(c) is to ensure that no immunity enures for the benefit of a diplomat
where for one reason or another his activities do not comply with the article 42 prohibition.

13. This approach has been adopted in the United States where the leading authority is Tabion v Mufti 73F. 3d, 535
(4th Cir, 1996), 107 ILR 452 (United States). In that case, the appellant worked as a domestic servant in the home
of the respondent diplomats. The appellant brought proceedings claiming damages for breach of the terms of her
contract of employment. The court held that the commercial activity exception to diplomatic immunity under article
31(1)(c) did not apply. Mr Otty submits that Tabion is of little assistance as an authority outside the United States
because (i) the US State Department indicated in a “statement of interest” that “commercial activity” “focuses on the
pursuit of trade or business activity; it does not encompass contractual relationships for goods or services incidental
to the daily life of the diplomat and his family in the receiving state”; and (ii) “substantial deference” is due to the
State Department's conclusion. But it is important to note that the court went on to say (with apparent approval) that
“legal commentators similarly characterise the exception as covering only a diplomat's participation in trade or
business, and not his everyday transactions”. The court also cited with approval the views (to similar effect) of
Eileen Denza in _Diplomatic Law: Commentary on the Vienna Convention on Diplomatic Relations (1976) and_
concluded:


-----

others intervening) [2015] EWCA Civ 32

“It is evident from the foregoing authorities that the phrase 'commercial activity', as it appears in the Article
31(1)(c) exception, was intended by the signatories to mean 'commercial activity exercised by the
diplomatic agent in the receiving State outside his official functions'. Day-to-day living services such as dry
cleaning or domestic help were not meant to be treated as outside a diplomat's official functions. Because
these services are incidental to daily life, diplomats are to be immune from disputes arising out of them.”

14. This meaning of article 31(1)(c) has the support of Eileen Denza's Diplomatic Law (3rd ed 2009) at p 305. I do
not, therefore, accept that the authority of the decision in Tabion (which reflects US jurisprudence) can be brushed
aside in the way that Mr Otty suggests. It is true that the court said that substantial deference was due to the State
Department's conclusion. But as the court said, it was a view shared by legal commentators. In my view, it is
correct. I would hold that, as a matter of ordinary language, a contract for the provision of services which are
incidental to family or domestic daily life is not “commercial activity”.

_Context_

15. The ordinary meaning of the words is consistent with the picture which emerges from a consideration of the
scheme of the 1961 Convention as a whole. Other relevant provisions of the Convention include the following.
Article 34 provides:

“A diplomatic agent shall be exempt from all dues and taxes, personal or real, national, regional or
municipal, except:

…….

(d) dues and taxes on private income having its source in the receiving State and capital taxes on
investments made in commercial undertakings in the receiving State.”

16. This provision is illustrative of the principle which underlies diplomatic immunity. If a diplomatic agent does what
he is sent to the receiving State to do, then the activities which are incidental to his life as a diplomatic agent are
covered by the immunity. Private income and capital receipts from private investments made by the diplomatic
agent in the receiving State are not the fruits of activities which are incidental to the life of a diplomatic agent: they
are extraneous to it. Article 34 does, however, provide immunity from taxes payable by virtue of the diplomatic
agent's activities as a diplomatic agent. Thus if the diplomatic agent does in the receiving State what he is sent by
the sending State to do, what he does (including activities which are incidental to diplomatic life) is covered by
immunity. But if he embarks on a private activity for profit, he becomes subject to the jurisdiction of the receiving
State in relation to that activity. The use of the same words in article 31(1)(c) and article 42 shows that there is a
clear link between the two provisions. The link is that, if the diplomatic agent acts in breach of article 42, he will not
enjoy the immunity that article 31(1)(c) would otherwise afford him.

17. I have set out article 42 at para 11 above. I agree with what Laws J said about it in Propend. The use of the
same phrase “professional or commercial activity” as appears in article 31(1)(c) is significant. Mr Otty submits that
article 42 does not support the respondents' construction because article 31(1)(c) would be superfluous if it merely
dovetailed with article 42 and it is unlikely that article 31(1)(c) was intended to be no more than a policing
mechanism for article 42. It seems to me, however, to be entirely plausible that article 31(1)(c) and article 42 should
have been intended to complement each other. As for the alleged superfluity, arguments based on surplusage
rarely have much weight. In any event, as the respondents point out, article 31(1)(c) also exists to exclude immunity
in situations not covered by article 42 where a diplomatic agent's family practises a profession or commercial
activity.

18. The fourth recital to the 1961 Convention explains that “the purpose of [the immunities conferred] is not to
benefit individuals but to ensure the efficient performance of the functions of diplomatic missions as representing
States”. These functions are listed in article 3(1) of the 1961 Convention as follows:

“(a) Representing the sending State in the receiving State;


-----

others intervening) [2015] EWCA Civ 32

(b) protecting in the receiving State the interests of the sending State and of its nationals, within the limits
permitted by international law;

(c) negotiating with the Government of the receiving State;

(d) ascertaining by all lawful means conditions and developments in the receiving State, and reporting
thereon to the Government of the sending State;

(e) promoting friendly relations between the sending State and the receiving State, and developing their
economic, cultural and scientific relations”.

19. The employment of individuals to provide domestic services in a diplomatic mission or an official diplomatic
residence in the receiving State is conducive to the performance of diplomatic functions. It is not an action relating
to any “commercial activity” undertaken for the financial benefit of the diplomatic agent; still less is it an action
relating to any commercial activity “outside his official functions”.

_Object and purpose_

20. It is also clear from the drafting history of article 31(1)(c) that this provision was only intended to apply to
situations where the diplomatic agent, his family or other members of the mission carried out activities for personal
profit, rather than covering ordinary contracts incidental to diplomatic life in the receiving State. This is illustrated by
a number of extracts from the travaux preparatoires. In 1958, the commentary on the International Law Commission
Draft Articles on Diplomatic Intercourse and Immunities (“ILC”) records:

“The third exception arises in the case of proceedings relating to a professional or commercial activity
exercised by the diplomatic agent outside his official functions. It was urged that activities of these kinds
are normally wholly inconsistent with the position of a diplomatic agent, and that one possible consequence
of his engaging in them might be that he would be declared persona non grata. Nevertheless, such cases
may occur and should be provided for, and if they do occur, the persons with whom the diplomatic agent
has had commercial or professional relations cannot be deprived of their ordinary remedies.”

21. I accept the submission of Mr Eicke QC that the act of engaging domestic staff for the diplomatic agent's official
residence was not within the contemplation of the ILC in drafting this provision: such an act could not sensibly be
described as “wholly inconsistent with the position of a diplomatic agent” or an act which was likely to lead to the
diplomatic agent being declared persona non grata.

22. I also accept his submission that the representations made at the 1961 Vienna Conference confirm that the
prohibition on “professional and commercial activities” imposed by article 42 (which was not included in the ILC
Draft Articles but was introduced as an additional provision at the Vienna Conference) was directed at commercial
activity for personal profit. The new provision was proposed by the Colombian delegation, who submitted that the
incompatibility between the performance of diplomatic functions and the exercise of a liberal profession or
commercial activities was “universally admitted, but it was nevertheless essential to state it explicitly in the
Convention”. The suggested addition was widely approved. For example, the representative of Venezuela
commented that “the exercise of gainful outside activities by a diplomatic officer would be detrimental to the dignity
of his office”; and the representative of Ceylon noted that the proposed new article was directed at “a regular
professional activity from which a permanent income was derived, and not an occasional activity, particularly of a
cultural character.”

23. Furthermore, the comments made in respect of article 29(1)(c) (which became article 31(1)(c)) and the
proposed new article 42 illustrate that the two articles were closely inter-related. Thus (i) Colombia proposed
deleting article 29(1)(c), as a corollary of inserting the new article 42; (ii) the Guatemalan delegate agreed with this
proposed deletion, commenting that “…a diplomatic agent should devote himself exclusively to his diplomatic
functions. Paragraph 1(c) as it stood might be interpreted as an implicit authorisation for the diplomatic agent to
engage in a professional or commercial activity in the receiving State”; (iii) the Japanese representative supported
the proposed addition of article 42, but pointed out that article 29(1)(c) was still necessary as it “applied not to


-----

others intervening) [2015] EWCA Civ 32

diplomatic agents only, but also applied, in virtue of article 36 [now article 37] to members of a diplomatic agent's
family forming part of his household and to the administrative and technical staff of the mission”.

24. Moreover, the Yugoslav delegate expressly noted that he would have been inclined to add other exceptions to
the immunity granted by article 29 (as it then was), particularly _“actions arising out of an employment agreement_
relating to a locally employed servant of a foreign diplomatic mission”. But this suggestion was not adopted.

25. It is therefore clear that the participants in the Vienna Conference (i) did not consider that contracts of
employment for the provision of domestic services at a mission were already included within the concept of
“professional and commercial activities”; and (ii) did not favour enlarging the scope of the exception to a diplomatic
agent's immunity to include such contracts of employment.

26. Mr Otty (supported by the written submissions for the intervener, Kalayaan) submits that any person who is
employed for remuneration is engaged in commercial activity, since he or she provides services for profit; and since
the arrangement is one of mutual benefit for employer and employee, the employer is also engaged in commercial
activity. He relies on the decision of the Supreme Court of Canada in Re Labour Code [1992] 2 SCR 50 in which it
was held that the employment of workers is a commercial activity. That case concerned workers who were
employed at a US military base as tradesmen and firefighters. Section 5 of the Canadian State Immunity Act SC
1980 provides an exception to state immunity for proceedings that “relate to any commercial activity of the foreign
state”. La Forest J said (at pp 79-80) that “a bare contract for employment services at the base is, in and of itself,
generally a commercial activity” and that employment by foreign states is generally to be regarded as a commercial
activity carried out by the foreign state. Mr Otty submits that this reasoning was not influenced by the context of
state (rather than diplomatic) immunity. But this was a decision on Canadian legislation concerned with state
immunity. In my view, it is of limited relevance to the interpretation of a treaty on diplomatic immunity. Its reasoning
is insufficient to outweigh the combined effect of the points that I have set out at paras 11 to 25 above.

27. Mr Otty also relies on _Fonseca v Larren, Portugal Supreme Court, 30 January 1991, which held that article_
31(1)(c) of the 1961 Convention is apt to allow claims to be brought by domestic workers against a serving
diplomatic agent. The court said in relation to article 31:

“it was intended to exclude all activities outside of the diplomat's diplomatic functions and amongst these is
the contracting of a domestic maid to perform services in the diplomat's private residence.”

But there is no analysis in support of this assertion, and I am unable to agree with it.

28. Finally, Mr Otty relies on the US decision in Park v Shin 313 F.3d 1138 (9th Cir 2002). In that case, the plaintiff
brought proceedings in respect of claims arising from her employment as a personal domestic servant at the
Korean Consulate in San Francisco. The Foreign Sovereign Immunities Act provides that a foreign state shall not
be immune from the jurisdiction of the courts of the United States in any case “in which the action is based upon a
commercial activity carried on in the United States by the foreign state”. There is a line of US authority to the effect
that “an activity is commercial unless it is one that only a sovereign state could perform” (para 32 of the judgment).
The court held that, since the hiring of a domestic servant is not an inherently public act that only a government
could perform, the defendants were not entitled to sovereign immunity. But this is not a decision on the 1961
Convention. I would decline to follow it for the same reasons as I have given for not following the Canadian decision
in Re Labour Code.

29. I cannot accept the broad interpretation of “commercial activity” for which Mr Otty contends. It has little support
in the jurisprudence or the commentaries. It would frustrate the principle of reciprocity and importance of diplomatic
immunity. It would mean that there was no diplomatic immunity in respect of any contract made between a
diplomatic agent and another person for the supply by that other person of goods or services for profit. Moreover,
as Sir Daniel Bethlehem QC points out, effect has also to be given to the important words “outside his official
functions” in article 31(1)(c) of the 1961 Convention. There is no immunity in the case of an action relating to “any
professional or commercial activity exercised….outside his official functions”. The employment of a domestic


-----

others intervening) [2015] EWCA Civ 32

servant at a mission is an activity which is incidental to the daily life of a diplomatic agent and enables him to
perform his official functions.

30. I conclude, therefore, that article 31(1)(c) does not deprive a diplomatic agent of immunity from civil suit by a
person employed at his official residence to carry out domestic services where the contract is not infected by any
allegation of trafficking. The next question is whether a contract of employment which is otherwise not a commercial
activity is rendered a commercial activity because the employee has been the subject of trafficking.

_The trafficking dimension_

31. As I have said, the UKVI has determined that both claimants are the victims of trafficking. In the case of Ms
Reyes, it concluded that there was movement from one place to another (the Philippines to the UK) for the
purposes of exploitation (domestic servitude) and that there was deception as to her pay. The 10 indicators of
trafficking identified by the UKVI in Ms Reyes' case are pleaded in her claim form. Mr Otty submits that these
proceedings relate to trafficking, although he accepts that trafficking claims as such do not fall within the jurisdiction
of the ET (and on appeal to the EAT). In summary, his argument is as follows. Ms Reyes has been determined by
the UKVI to be a victim of trafficking and the ET and EAT proceeded on the assumed basis that the allegations in
her pleaded case were true. The accepted international definition of trafficking was set out by Lord Wilson in
_Hounga v Allen [2014] 1 WLR 2889 at para 37:_

“The accepted international definition of trafficking is contained in the UN Protocol to Prevent, Suppress
and Punish Trafficking in Persons (“the Palermo Protocol”) signed in 2000 and ratified by the UK on 9
February 2006. Article 3 provides:

'(a) 'Trafficking in persons' shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of
deception, of the abuse of power or of a position of vulnerability… for the purpose of exploitation.
Exploitation shall include, at a minimum, … sexual exploitation, forced labour or services, slavery or
practices similar to slavery, servitude or the removal of organs;

(b) The consent of a victim of trafficking in persons to the intended exploitation set forth in subparagraph
(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation
shall be considered 'trafficking in persons' even if this does not involve any of the means set forth in
subparagraph (a) of this article'.”

32. A threshold question arises as to whether the claims are based on an allegation of trafficking. The respondents
say that the pleaded claims (for example, for direct and indirect racial discrimination) are not based on an allegation
of trafficking. I am prepared to proceed on the basis that this is no impediment to considering whether the claimant
can rely on the alleged trafficking to defeat the defence of immunity. In Hounga, the Supreme Court (by a majority)
held that claims of discrimination relating to acts of trafficking were sufficiently closely connected to trafficking to
require the remedial protections for victims of trafficking specified in the Council of Europe's Anti-Trafficking
Convention (“ATC”): per Lord Wilson at para 50. There is force in the submission of Mr Otty that it would be an
overly technical approach to contend that, since the formal causes of action relied on by Ms Reyes lie in the field of
employment law, her claims do not relate to trafficking.

_Ordinary language_

33. Before I consider the various interpretative principles relied on by Mr Otty (supported by Kalayaan), I need to
address the submission that, as a matter of ordinary language, engagement by a diplomatic agent in an
employment relationship which meets the international definition of trafficking can constitute commercial activity on
the part of the diplomatic agent. Mr Otty submits that trafficking has, by virtue of its economically exploitative
aspect, an inherently commercial nature. He says that the phrase “commercial activity” is, as a matter of ordinary
language, wide enough to embrace an employment relationship at least, where the elements of that relationship
meet the international definition of trafficking The Modern Slavery Bill E idence Re ie Panel noted that the “fast


-----

others intervening) [2015] EWCA Civ 32

growing modern slavery and human trafficking trade” is worth at least US$ 32 billion a year and is the second or
third most profitable of all illicit trades. Mr Otty submits that the engagement of a diplomatic agent in an employment
relationship which meets the international definition of trafficking meets the definition of commercial activity even if
the definition is considered to require some element of profit motive.

34. Even if the claims relate to trafficking, the question remains whether such claims relate to a commercial activity
outside the respondents' diplomatic functions. I shall assume that Kalayaan are right when they say that (i)
intermediaries, from informal labour brokers to registered employment agencies, generate vast profits both from
employers and from migrant workers themselves; and (ii) employers benefit financially by paying sub-market
wages, demanding unlawful working hours and by levying charges and withholding benefits to which workers are
legally entitled. But these features of the trafficking industry do not shed light on the question whether a particular
diplomatic agent who employs a particular trafficked employee to carry out domestic services at a mission is
engaging in a commercial activity within the meaning of article 31(1)(c), still less whether he is doing so outside his
official functions. In my judgment, it is clear that, as a matter of ordinary language, he is not doing so. The fact that
an employer derives economic benefit from paying his employee wages that are lower than the market rate does
not mean that he is engaging in a commercial activity. Still less does it mean that he is engaging in an activity
outside his official functions. As a matter of ordinary language, the question whether an employer is engaged in
commercial activity when employing an individual depends on what the individual is employed to do, and not the
rate of remuneration which he or she is paid for doing it or the background circumstances which led to the contract
of employment in the first place. I should add that, if the position were otherwise, there would be considerable
uncertainty as to the scope of the exception to immunity provided by article 31(1)(c). On this footing, whether an
action relates to commercial activity might involve a difficult fact-finding exercise as to the terms of the contract of
employment and the background events which led to the making of the contract. It would be surprising if the parties
to the 1961 Convention had intended that article 31(1)(c) should generate such an inquiry.

_Human trafficking in international law_

35. I turn now to consider the submissions of Mr Otty (again supported by Kalayaan) that article 31(1)(c) should be
construed in the light of the high status of the prohibition on human trafficking in international law and the
incompatibility of engagement in such practices with the proper discharge of diplomatic functions. He says that,
given the international law context of the exception to civil immunity at issue in this appeal, it is important to
recognise the gravity with which international law regards human trafficking.

36. 164 of the 193 members of the United Nations (including the UK and Saudi Arabia) are parties to the Protocol to
Prevent, Suppress and Punish Trafficking in Persons, Especially Women and Children 2000 (“the Palermo
Protocol”). The purposes of the Palermo Protocol include:

“(a) To prevent and combat trafficking in persons, paying particular attention to women and children;

(b) To protect and assist the victims of such trafficking, with full respect for their human rights”.

37. Article 6 provides:

“6. Each State Party shall ensure that its domestic legal system contains measures that offer victims of
trafficking in persons the possibility of obtaining compensation for damage suffered.”

38. Trafficking is widely recognised as a contemporary form of slavery or a slavery-like practice: see, for example,
paras 30 and 62 of the report of the Office of the United Nations Commissioner for Human Rights on “abolishing
Slavery and its Contemporary Forms” (2002). Article 5 of the EU Charter of Fundamental Rights (“the Charter”)
under the heading “Prohibition of slavery and forced labour” provides: “(3) Trafficking in human beings is
prohibited”.

39. In Rantsev v Cyprus and Russia (2010) 51 EHRR 1, the ECtHR had to consider a complaint of a violation, inter
alia, of article 4 of the ECHR which provides:

“1 No one shall be held in slavery or servitude


-----

others intervening) [2015] EWCA Civ 32

2. No one shall be required to perform forced or compulsory labour.”

40. At para 282, the court said:

“There can be no doubt that trafficking threatens the human dignity and fundamental freedoms of its
victims and cannot be considered compatible with a democratic society and the values expounded in the
Convention. In view of its obligation to interpret the convention in light of present-day conditions, the court
considers it unnecessary to identify whether the treatment about which the applicant complains constitutes
'slavery', 'servitude; or 'forced and compulsory labour'. Instead, the Court concludes that trafficking itself,
within the meaning of art.3(a) of the Palermo Protocol and art.4(a) of the Anti-Trafficking Convention, falls
within the scope of art.4 of the Convention. The Russian Government's objection of incompatibility ratione
_materiae is accordingly dismissed.”_

41. Article 15(3) of the ATC provides: “Each Party shall provide, in its internal law, for the right of victims to
compensation from the perpetrators”.

42. Mr Otty submits that, against this background, it must follow that involvement by a diplomat in trafficking would
be contrary to, and inconsistent with, the proper discharge of diplomatic functions and would be sufficient to justify
treating the diplomat as _persona non grata pursuant to article 9 of the 1961 Convention. He submits that_
international law requires “commercial activity” to be construed so as to include the employment of a victim of
trafficking to provide domestic services at a diplomatic mission. He says that this construction is required (i) by the
common law route of interpreting domestic law (article 31(1)(c) of the 1961 Convention which has been
incorporated into our domestic law by the 1964 Act) in accordance with the UK's international obligations; (ii) by
applying section 3 of the HRA with particular reference to articles 4 and 6 of the ECHR; and (iii) by applying the
Charter. Since it is accepted that arguments by reference to the Charter add nothing to the arguments by reference
to the ECHR, I shall say no more about the Charter.

_Common law interpretation_

43. Mr Otty relies on the well-established principle that there is a strong presumption in favour of interpreting
English law (whether common law or statute) in a way which does not place the UK in breach of an international
obligation. This principle was applied in _Hounga at paras 50 to 52. Mr Otty submits that article 15(3) of the ATC_
would be breached by the adoption of a narrow meaning of the term “commercial activity” so as to bar Ms Reyes'
claims. Barring these claims would also lead to a breach of article 6(6) of the Palermo Protocol.

44. The respondents counter this by saying that the court is being asked to construe the words of an international
treaty as enacted in UK law and accordingly should seek to adopt a meaning that accords with international practice
(and should not adopt a national or regional meaning): see Fothergill v Monarch Airlines Ltd [1981] AC 251, 281A283D. The court should, therefore, apply international rules of treaty interpretation (as contained in articles 31 and
32 of VCLT) rather than domestic canons of construction.

45. As we have seen, article 15(3) of the ATC requires each Contracting State to provide in its internal law for the
right of victims to compensation from the perpetrators. By contrast, article 6(6) of the Palermo Protocol merely
requires a legal system which contains measures that offer victims “the possibility of obtaining compensation for
damage suffered”. It does not prescribe the means by which such possibility may be offered. For example, a
criminal injuries compensation scheme would appear to suffice. (See, generally, Hounga v. Allen per Lord Hughes
JSC at [65].)

46. I reject the submission that common law rules of statutory interpretation are relevant in the context of this
appeal. Article 31(1)(c) must be interpreted in accordance with the VCLT like any other international treaty. Resort
to domestic law principles of statutory interpretation of international instruments is inappropriate here. Furthermore,
I am in any event unable to see how article 15(3) of the ATC or article 6(6) of the Palermo Protocol could, by means
of a common law principle of interpretation, lead to the conclusion for which Mr. Otty contends. These provisions of


-----

others intervening) [2015] EWCA Civ 32

the ATC and the Palermo Protocol do not address diplomatic immunity which is the specific subject matter of the
1961 Convention and the 1964 Act.

_Section 3 of the HRA: articles 4 and 6 of the ECHR_

_Article 4_

47. Mr Otty relies on Rantsev for the proposition that article 4 of the Convention requires Member States to take
positive steps to protect victims of trafficking outside the framework of criminal investigations and prosecutions
(paras 200 to 202). At para 285, the court identified the positive obligations inherent in article 4 as being (i) to
penalise and prosecute “any act aimed at maintaining a person in a situation of slavery, servitude or forced or
compulsory labour”, (ii) “to put in place a legislative and administrative framework to prohibit and punish trafficking”.
The court referred to both the Palermo Protocol and the ATC and said:

“It is clear from the provisions of these two instruments that the contracting states, including almost all of
the Member States of the Council of Europe, have formed the view that only a combination of measures
addressing all three aspects can be effective in the fight against trafficking.”

48. Basing himself on this passage, Mr Otty submits that these positive obligations would be breached in three
respects if the claim of Ms Reyes were to be barred by reason of article 31(1)(c) of the 1961 Convention.

49. The first respect in which there would be a breach is in relation to the right to compensation vouchsafed by
article 15(3) of the ATC. He submits that, given the ECtHR's endorsement of the requirements of the ATC as being
a necessary part of the positive obligation to prevent trafficking, protect victims and punish traffickers, a failure to
fulfil the obligation under article 15(3) (which is an essential part of that framework) would breach article 4 of the
ECHR.

50. The second respect in which there would be a breach is in relation to the “positive obligation to put in place an
appropriate legislative and administrative framework” to give practical and effective protection against trafficking
and exploitation. The barring of an entire class of employment claims by domestic workers, namely claims against
persons asserting diplomatic immunity, would represent a severe weakness in the legislative and administrative
framework in the UK that failed effectively to discourage trafficking. Mr Otty submits that the EAT erred in holding
(paras 53 and 56) that the UK's positive obligation was met by the criminalisation of slavery, servitude and forced or
compulsory labour. As was stated at para 285 in Rantsev, the duty to penalise and prosecute trafficking is only one
aspect of the Member States' general undertaking to combat trafficking.

51. The third respect in which there would be a breach is in relation to the obligation to provide for an effective
investigation. The availability of civil proceedings may in some circumstances be the only way in which the
investigative obligation can be discharged. In the present case, the Saudi authorities have refused to waive
immunity to allow a police investigation to proceed.

52. I reject these submissions essentially for the reasons given by the respondents. The fundamental point is that
article 4 of the ECHR (like article 6 to which I shall come) must be interpreted in accordance with the principles of
international law, including the principles of diplomatic immunity contained in the 1961 Convention. In Rantsev itself,
the court affirmed that “….the Convention should so far as possible be interpreted in harmony with other rules of
international law of which it forms part” (para 274). On that basis, it concluded that trafficking as defined by the
Palermo Protocol and the ATC was within the scope of article 4 of the Convention, even though article 4 does not
specifically mention trafficking (para 282).

53. But Rantsev was not concerned with issues of diplomatic immunity. Mr Otty must establish the existence of a
superior rule of international law which entails an exception to the principle of diplomatic immunity. The important
decision of Jones v Saudi Arabia [2007] 1 AC 270is illuminating in this regard. The claimants alleged that they had
been tortured while imprisoned in Saudi Arabia and claimed damages for psychological injury. The defendants
claimed state immunity. It was held by the House of Lords inter alia that Part I of the State Immunity Act 1978 was
not disproportionate as being inconsistent with a peremptory norm or ius cogens of international law and its


-----

others intervening) [2015] EWCA Civ 32

application did not infringe the claimants' rights under article 6 of the ECHR (assuming it to apply). The claims to
state immunity were, therefore, upheld.

54. At para 14, Lord Bingham said:

“Thirdly, the claimants must show that the restriction is not directed to a legitimate objective and is
disproportionate. They seek to do so by submitting that the grant of immunity to the Kingdom on behalf of
itself or its servants would be inconsistent with a peremptory norm of international law, a jus cogens
applicable erga omnes and superior in effect to other rules of international law, which requires that the
practice of torture should be suppressed and the victims of torture compensated.”

55. Although the prohibition of torture is a jus cogens, it was held that it did not take precedence over another rule
of international law, namely state immunity. The House reached this conclusion by examining various sources of
international law. Lord Bingham relied inter alia on the UN Immunity Convention of 2004 as being “the most
authoritative statement available on the current international understanding of the limits of state immunity in civil
cases” and said that “the absence of a torture or jus cogens exception is wholly inimical to the claimants'
contention” (para 26).

56. Lord Hoffmann examined the relevant sources of international law at paras 44 to 63 in some detail. As he said
(para 45), to produce a conflict with state immunity, it is necessary to show that the prohibition on torture has
generated an ancillary procedural rule which, by way of exception to state immunity, entitles or requires states to
assume civil jurisdiction over other states in cases in which torture is alleged. Having considered various treaties
and judicial decisions of international and national courts, Lord Hoffmann concluded that the claimants had not
established that the prohibition of torture was a peremptory norm or jus cogens which takes precedence over other
rules of international law, including the rules of state immunity. Accordingly, the claimants were barred from
pursuing their claims for compensation under the UN Convention against Torture and other Cruel, Inhuman or
Degrading Treatment or Punishment 1984. In adopting this approach, the House of Lords were considering all the
“normal” sources of international law as set out in the Statute of the International Court of Justice, including treaties,
international custom, the general principles of law recognised by civilised nationals, judicial decisions and the
teachings of publicists.

57. Mr Otty accepts that the prohibition on trafficking is not a peremptory norm or jus cogens. Nevertheless, he
submits that it is a prohibition of “high status” sufficient amongst the norms of international law to qualify or displace
an obligation to grant procedural immunity in a range of civil suits.

58. It would be remarkable if a prohibition which is a peremptory norm were not recognised in international law as
sufficient to displace a procedural immunity, but a prohibition which is not a peremptory norm were recognised in
international law as sufficient to have that effect. It is difficult to think of any rational basis for such a distinction.

59. However, as the respondents submit, the relevant question is not the status of the international prohibition of
trafficking. It is whether this rule (which I am prepared to accept is correctly described as a rule of international law)
takes precedence over the international rule of diplomatic immunity (subject to the exceptions contained in article
31(1)(c) of the 1961 Convention). There has been no attempt to establish the existence of a rule which has that
effect by reference to the relevant sources of international law or at all.

60. At most, the ATC and the Palermo Protocol contain provisions on compensation for trafficking (articles 15(3)
and 6(6) respectively). But there is no indication that these provisions are norms which entail an exception to
diplomatic immunity. Mr Otty has not cited any material from any of the other recognised sources of international
law. This is significant. As Lord Bingham said in Jones at para 27:

“Fourthly, there is no evidence that states have recognised or given effect to an international law obligation
to exercise universal jurisdiction over claims arising from alleged breaches of peremptory norms of
international law, nor is there any consensus of judicial and learned opinion that they should. This is
significant, since these are sources of international law. But this lack of evidence is not neutral: since the


-----

others intervening) [2015] EWCA Civ 32

rule on immunity is well-understood and established, and no relevant exception is generally accepted, the
rule prevails.”

61. So too Lord Hoffmann at para 63:

“But the same approach cannot be adopted in international law, which is based upon the common consent
of nations. It is not for a national court to 'develop' international law by unilaterally adopting a version of that
law which, however desirable, forward-looking and reflective of values it may be, is simply not accepted by
other states. (See Al-Adsani 34 EHRR 273, 297, para O-II9 in the concurring opinion of judges Pellonpää
and Bratza).”

62. Mr Otty submits that the ECtHR has repeatedly emphasised the obligation to construe an ambiguous
international measure in a manner that best secures compliance with fundamental rights (which in this case he
submits would include the various positive obligations under article 4 of the ECHR). He relies, for example, on the
decision in _Al-Dulimi and Montana Management Inc v Switzerland (Appl No. 5809/08, 26 November 2013). The_
rights in issue in that case included article 6 of the ECHR. The applicants alleged that there had been a violation of
the right of access to a court to challenge the merits of a decision to freeze and confiscate their assets. The court
found that there had been a violation despite the fact that Switzerland was under a clear international obligation,
pursuant to article 25 of the UN Charter, to implement the terms of a Security Council resolution requiring the
applicants' assets to be frozen in this manner. At para 112, the court said:

“…the Convention cannot be interpreted in a vacuum but must be interpreted in harmony with the general
principles of international law. Account should be taken, as indicated in Article 31(1)(c) of the Vienna
Convention on the Law of Treaties of 1969, of 'any relevant rules of international law applicable in the
relations between the parties, and in particular the rules concerning the international protection of human
rights'”.

63. The court then went on to make its findings in the light of the particular context of the international obligations
arising from the state's membership of an international organisation (the UN). Mr Otty submits that, since
fundamental rights must take precedence over an unambiguous UN Security Council resolution, the ambiguous
terms of article 31(1)(c) of the 1961 Convention must be subordinated to the UK's obligations under the ECHR. The
other authorities to which Mr Otty refers are Al-Jedda (2011) 53 EHRR 23 and Nada v Switzerland (2013) 56 EHRR
18. In the former, the right in issue was article 5 of the ECHR. The ECtHR held that the international measure relied
on by the respondent state had to be interpreted in a manner that minimised the extent to which arbitrary detention
was sanctioned or required. In the latter case, the rights in issue included article 8 and the respondent state was
held to be under an obligation to interpret and implement the relevant international measure in the manner that
interfered to the least extent possible with the right to private life. None of these cases was concerned with the wellestablished international law rules relating to immunity. None of them casts doubt on the correctness of the
approach adopted in cases such as _Jones of upholding a well-established rule of international law unless it is_
required to yield to another rule of international law.

64. For the reasons I have already given, there is no established rule of international law relating to trafficking which
takes precedence over the international law rules relating to diplomatic immunity. I should add for completeness
that, for these purposes, there is no material distinction between diplomatic and state immunity. What unites them is
that they are both well-established rules of international law.

_Article 6_

65. I shall assume that article 6 of the ECHR is engaged, although the contrary is strongly arguable: see Holland v
_Lampen-Wolfe [2000] 1 WLR 1573per Lord Millett and Jones at para 14 (per Lord Bingham) and para 101 (per Lord_
Hoffmann).

66. Mr Otty submits that the interpretation of article 31(1)(c) for which he contends is the appropriate construction in
a case in which fundamental rights such as article 6 are at stake. In summary, he submits that the contrary
interpretation would involve a disproportionate interference with Ms Reyes' right of access to a court or tribunal


-----

others intervening) [2015] EWCA Civ 32

67. Before I examine the parties' submissions in any detail, I need to refer to the important decision of the ECtHR in
_Fogarty v UK (2002) 34 EHRR 12. The applicant applied unsuccessfully for posts at the US Embassy in London._
She issued proceedings claiming that she was the victim of sex discrimination. The US Government claimed state
immunity under section 16(1)(a) of the State Immunity Act 1978. She contended that this constituted a violation of
article 6(1) of the ECHR taken together with article 14. Her complaint was rejected by the Grand Chamber of the
ECtHR.

68. The court held that the article 6(1) right of access to court is not absolute (para 33). It first considered whether
the limitation of the right (in that case state immunity) pursued a legitimate aim (para 34). It held that the grant of
sovereign immunity to a state in civil proceedings pursues the legitimate aim “of complying with international law to
promote comity and good relations between States through respect of another State's sovereignty”. I would hold
that, by analogy, the recognition of diplomatic immunity in civil proceedings pursues the legitimate aim of complying
with a State's international law obligations to prevent hindrance to the diplomat in performing his functions. I do not
believe this to be controversial.

69. The court next assessed whether the restriction was proportionate to the aim pursued. It said:

“36. It follows that measures taken by a High Contracting Party which reflect generally recognised rules of
public international law on State immunity cannot in principle be regarded as imposing a disproportionate
restriction on the right of access to court as embodied in Article 6 § 1. Just as the right of access to court is
an inherent part of the fair trial guarantee in that Article, so some restrictions on access must likewise be
regarded as inherent, an example being those limitations generally accepted by the community of nations
as part of the doctrine of State immunity.

37. The Court observes that, on the material before it, there appears to be a trend in international and
comparative law towards limiting State immunity in respect of employment-related disputes. However,
where the proceedings relate to employment in a foreign mission or embassy, international practice is
divided on the question whether State immunity continues to apply and, if it does so apply, whether it
covers disputes relating to the contracts of all staff or only more senior members of the mission. Certainly,
it cannot be said that the United Kingdom is alone in holding that immunity attaches to suits by employees
at diplomatic missions or that, in affording such immunity, the United Kingdom falls outside any currently
accepted international standards.

38. The Court further observes that the proceedings which the applicant wished to bring did not concern
the contractual rights of a current embassy employee, but instead related to alleged discrimination in the
recruitment process. Questions relating to the recruitment of staff to missions and embassies may by their
very nature involve sensitive and confidential issues, related, inter alia, to the diplomatic and organisational
policy of a foreign State. The Court is not aware of any trend in international law towards a relaxation of the
rule of State immunity as regards issues of recruitment to foreign missions. In this respect, the Court notes
that it appears clearly from the materials referred to above (see paragraph 19) that the International Law
Commission did not intend to exclude the application of State immunity where the subject of proceedings
was recruitment, including recruitment to a diplomatic mission.

39. In these circumstances, the Court considers that, in conferring immunity on the United States in the
present case by virtue of the provisions of the 1978 Act, the United Kingdom cannot be said to have
exceeded the margin of appreciation allowed to States in limiting an individual's access to court.

70. In short, the court held that compliance with a state's international law obligations is conclusive on the issue of
proportionality. In my view, although there are important differences between state immunity and diplomatic
immunity, these differences are immaterial to the point of principle that the court enunciated at para 36. The central
point is that restrictions on the right of access to court which reflect generally recognised rules of public international
law cannot in principle be regarded as disproportionate. The court added that this is so even if international practice
as to the meaning or scope of an international obligation is inconsistent, provided that the interpretation applied by
the state in question is reasonable and falls within currently accepted international standards.


-----

others intervening) [2015] EWCA Civ 32

71. Mr Otty's submissions may be summarised as follows. First, the right of access to a court is one of the key
rights in a democratic society governed by the rule of law and any ambiguity in article 31(1)(c) should be resolved in
favour of a meaning which promotes access to justice. Secondly, the obligation to secure to individuals in the
United Kingdom the rights afforded by the ECHR is not displaced by subsequently entering into international
treaties which interfere with those rights. Thirdly, the relaxation of the scope of state immunity in relation to
employment law disputes (as set out in the United Nations Convention on Jurisdictional Immunities of States and
their Property 2004) (“the 2004 Convention”) is relevant to the consideration of proportionality under article 6 of the
ECHR in the context of claims against diplomatic agents. Mr Otty also relies on Cudak v Lithuania (2010) 51 EHRR
15 and Sabeh El Leil v France (2012) 54 EHRR 14. Fourthly, to engage in trafficking would not be “incidental” to the
performance of a diplomatic function, but would be wholly inimical to it and to the dignity of the mission.

72. I would reject these submissions largely for the reasons given by the respondents and the Secretary of State.
Nobody would dispute that the right of access to court is a fundamental right in a democratic society which is
governed by the rule of law. But the article 6(1) right of access to court is not absolute and may be subject to
limitations “since the right of access by its very nature calls for regulation by the State” and states “enjoy a margin of
appreciation”: Fogarty para 33.

73. There is a clear distinction between state immunity and diplomatic immunity as regards the detailed principles
and the aims of each doctrine. As the ECtHR recognised in Fogarty at para 34:

“……..sovereign immunity is a concept of international law, developed out of the principle par in parem non
habet imperium, by virtue of which one State shall not be subject to the jurisdiction of another State. The
Court considers that the grant of sovereign immunity to a State in civil proceedings pursues the legitimate
aim of complying with international law to promote comity and good relations between States through the
respect of another State's sovereignty.”

74. Diplomatic immunity by contrast is functional in nature. The preamble to the 1961 Convention records that “the
purpose of such privileges and immunities is not to benefit individuals but to ensure the efficient performance of the
functions of diplomatic missions as representing States”. Thus, as Mr Eicke says, even if the detailed rules of
international law relating to state immunity have been altered by the 2004 Convention, it does not follow that the
international law principles relating to diplomatic immunity must follow suit. Those negotiating the 2004 Convention
may have felt that a recalibration between the interests of state sovereignty and the interests of enforcement of the
receiving state's employment law was appropriate. There is no suggestion that the international community feels
that a similar adjustment is required in relation to diplomatic immunity. Mr Otty cites the decision of the Supreme
Court of Portugal in Fonseca v Larren as indicating that other signatories to the 1961 Convention do not regard it as
requiring immunity to be afforded to diplomatic agents in respect of claims brought by domestic workers. But this is
a solitary authority. It is, therefore, of little value as evidence of the contents of international law: see also para 27
above. As Mr Eicke says, the 1961 Convention remains an authoritative statement of international law on diplomatic
immunity.

75. The authorities are clear that, in this context, the compatibility of the limitation on access to a court with the
state's international law obligations is determinative. This has recently been emphasised by the ECtHR in Jones v
_United Kingdom (2014) 59 EHRR 1. The court said:_

“189. As to the proportionality of the restriction, the need to interpret the Convention so far as possible in
harmony with other rules of international law of which it forms part, including those relating to the grant of
State immunity, has led to the Court to conclude that measures taken by a State which reflect generally
recognised rules of public international law on State immunity cannot in principle be regarded as imposing
a disproportionate restriction on the right of access to a court as embodied in Article 6 § 1. The Court
explained that just as the right of access to court is an inherent part of the fair trial guarantee in Article 6 §
1, so some restrictions must likewise be regarded as inherent, an example being those limitations generally
accepted by the community of nations as part of the doctrine of State…..

191. In Al-Adsani (cited above) decided in 2001, the Court found that it had not been established that there
as et acceptance in international la of the proposition that States ere not entitled to imm nit in


-----

others intervening) [2015] EWCA Civ 32

respect of civil claims for damages concerning alleged torture committed outside the forum State. There
was therefore no violation of Article 6 § 1 where the domestic courts had struck out the applicant's claim
against Kuwait for civil damages for torture in application of the rules of State immunity contained in the
1978 Act. The same conclusion was reached in 2002 in Kalogeropoulou and Others, cited above, in
respect of the refusal of the Greek Minister of Justice to grant leave to the applicants to expropriate
German property in Greece following a judgment in their favour concerning crimes against humanity
committed in 1944. However, the Court there indicated that its finding in Al-Adsani did not preclude a
development in customary international law in the future….

193. The applicants argued that the Court should depart from the approach of the Grand Chamber in AlAdsani to the extent that the latter had failed to conduct a substantive proportionality assessment, including
an assessment of the circumstances and merits of the individual case, and in particular to consider
whether alternative means of redress existed.

194. In Al-Adsani the decisive question when assessing the proportionality of the measure was whether the
immunity rules applied by the domestic courts reflected generally recognised rules of public international
law on State immunity.

195. Having regard to the precedent established by Al-Adsani and the detailed examination in that
judgment of the relevant legal issues by reference to this Court's case-law and international law, the Court
does not consider it appropriate to relinquish the present case to the Grand Chamber. In elaborating the
relevant test under Article 6 § 1 in its Al-Adsani judgment, the Court was acting in accordance with its
obligation to take account of the relevant rules and principles of international law and to interpret the
Convention so far as possible in harmony with other rules of international law of which it forms part……”

76. It follows that the international law obligations in relation to diplomatic immunity are not incompatible with article
6 of the ECHR. The ECHR must be interpreted so far as possible in conformity with other rules of international law.
For the reasons I have given above, on the true interpretation of article 31(1)(c) of the 1961 Convention, diplomatic
immunity is not excluded in relation to claims for compensation by domestic workers who have been trafficked.

_Conclusion on the article 31(1)(c) issues_

77. For the reasons that I have given, the President of the EAT was right to uphold the respondents' claim to
immunity in answer to the claim made by Ms Reyes. This may appear to be an affront to one's sense of justice and
fairness, but as Sir Daniel Bethlehem says in his skeleton argument, it is salutary to bear in mind the concluding
words of the decision in Tabion:

“….there may appear to be some unfairness to the person against whom the invocation occurs. But it must
be remembered that the outcome merely reflects policy choices already made. Policymakers….have
believed that diplomatic immunity not only ensures the efficient functioning of diplomatic missions in foreign
states, but fosters good will and enhances relations among nations. Thus, they have determined that
apparent inequity to a private individual is outweighed by the great injury to the public that would arise from
permitting suit against the entity or its agent calling for application of immunity. ”

_The service issue_

78. The following methods of service were attempted in this case: (i) the ET1 claim form was sent to the
respondents' domestic address; (ii) the ET1 claim form was sent to the Saudi Arabian Embassy; and (iii) the ET3
response to claim form was sent to the respondents' solicitors. In each case, the document was sent by post.

79. The Tribunal rules in force at the relevant time were The Employment Tribunals (Constitution and Rules of
Procedure) Regulations 2004 (SI/2004/1861) (“the Tribunal rules”). Service by each of the methods attempted was
effective service in accordance with the Tribunal Rules: see, in particular, rule 61(1)(a) which explicitly permits
service by post.

80 The question of service was dealt with by the President of the EAT as follows:


-----

others intervening) [2015] EWCA Civ 32

“47. There remain two further matters. The first was a further ground of appeal: that the Tribunal erred in
law in regarding service of proceedings as having been validly effected. Mr Sethi relies heavily on the
inviolability of a diplomatic agent; and on _Adams v Director of Public Prosecution [2000] IEHC 45. He is_
supported by the views of Eileen Denza, _Diplomatic Law, pp 268-269, since personal service is a_
'manifestation of the enforcement jurisdiction of the receiving State and therefore a contravention of
personal inviolability' just as 'service of process even by post on inviolable premises…..is a breach of their
inviolability.'”

48. The answer to this given by Mr Luckhurst is that these principles relate to personal service, and do not
apply to service by post on solicitors who were already acting for them (as occurred in the present cases).
In any event, the fact that there are some categories of civil proceedings which are expressly contemplated
as being outside the scope of diplomatic immunity necessarily envisages the service of proceedings in
such cases, so that there can be no blanket prohibition on such service. No decided case supports the
contention that service cannot be effected by post on a diplomatic residence. Moreover, if the rights
secured by article 6 were broken by the assertion of diplomatic privilege, the provisions as to service
should be applied in a manner which provided effective protection of that right.

49. In my view, the conclusions to which the Employment Judge came at paragraphs 72 and 73 of her
reasons, accepting and adopting the arguments Mr Luckhurst advanced, are correct. For these reasons,
the appeal on this ground fails.”

81. Sir Daniel Bethlehem submits that all attempts to effect service on the respondents were invalid. The attempt to
serve by post on the Embassy was invalid due to the inviolability of diplomatic mission premises. Article 22(1) of the
1961 Convention provides: “The premises of the mission shall be inviolable”. The attempt to serve the proceedings
at the residence of the respondents (as well as by personal service on the respondents) was also precluded by the
principle of inviolability. Article 29 provides: “The person of a diplomatic agent shall be inviolable”; and article 30(1)
provides that “the private residence of a diplomatic agent shall enjoy the same inviolability and protection as the
premises of the mission”. In response to the holding that service was validly effected on the respondents' solicitors,
Sir Daniel relies on the fact that the solicitors had expressly stated (in their letter dated 10 October 2011) that they
were not authorised to accept service. The President adopted the view expressed at para 73 of the judgment of the
ET, namely: “this was just a device…the solicitors were acting for [the respondents] before and after. They have
appeared to argue the issue today….”

82. The respondents say that (i) there cannot be valid service of proceedings on a solicitor who does not have
authority to accept service; and (ii) it is standard practice (and not a “device”) for a solicitor who is not authorised to
accept service to say so.

83. It would be odd if service were not possible. It is true that the 1961 Convention (i) makes clear that the person of
a diplomatic agent is inviolable and a mission and the private residence of a diplomatic agent are inviolable, and (ii)
generally accords a diplomatic agent immunity from civil and administrative jurisdiction. But the Convention clearly
precludes immunity in three situations, including in respect of actions relating to commercial activity outside the
diplomatic agent's official functions. If service could never be effected on a diplomatic agent (except by consent),
the three carefully crafted exclusions to immunity would be futile. It is pointless to say in one breath that a
diplomatic agent may be liable to suit in civil and administrative proceedings, but in the next breath that such
proceedings may never be served on a diplomatic agent (except with his consent). The parties to the 1961
Convention could not have intended such a state of affairs. Such an interpretation of the Convention would be
incompatible with one of the core principles of treaty interpretation, namely that “the object and purpose” of the
treaty should be taken into account: see article 31(1) of the VCLT.

84. I agree with the respondents that personal service at the _mission is prohibited by article 22 of the 1961_
Convention. I also agree that all personal service on the diplomatic agent is prohibited by article 29: see Hellenic
_Lines Ltd v Moore 345 F.2d 978 (D.C. Cir. 1965) per Chief Judge Bazelon which decided that, as a matter of_
international law, personal service of a claim against the state of Tunisia could not be effected on the Tunisian
Ambassador. See also Eileen Denza, Diplomatic Law at p. 268.


-----

others intervening) [2015] EWCA Civ 32

85. It is right to mention that the US Court of Appeals (2nd Circuit) decision in Tachiona v United States 386 F. 3d
205, 221-224 suggested that personal service of proceedings is not prohibited in cases which fall within the
exceptions to immunity set out in article 31(1) of the 1961 Convention. But in my view the language of article 29 is
uncompromisingly clear. On its face, it admits of no exceptions. It is difficult to see how an exception from the
principle of personal inviolability that is enshrined in article 29 can be carved out to accommodate the service of
claims which fall within the exceptions to diplomatic immunity. The inviolability of the diplomatic agent is central to
the 1961 Convention. If it had been intended to exclude the operation of article 29 as regards the service of claims
which fall within the exception to immunity, it would have been easy enough so to provide. But the Convention does
not do so expressly. I accept that, if personal service were the only means by which claims within the exceptions to
immunity could be served on a diplomatic agent, there would be an argument for holding that article 29 must, by
necessary implication, be interpreted as permitting personal service in respect of such claims. For the reasons that
follow, however, I accept the submission of Mr Otty that service of proceedings which fall within the exceptions to
immunity can be effected by post.

86. I need to repeat that article 30 of the 1961 Convention provides that “the private residence of a diplomatic agent
shall enjoy the same inviolability and protection as the premises of the mission”; and that article 22(1) provides that
“the premises of the mission shall be inviolable. The agents of the receiving State may not enter them, except with
the consent of the head of the mission”. As a matter of ordinary language, it is difficult to see why posting
documents to the private residence of a diplomatic agent by way of service of proceedings on him infringes the
inviolability of his residence. It certainly does not involve entry into the residence by agents of the receiving State.

87. In _Renchard v Humphreys and Harding 59 FRD 530 (1973), 63 ILR 21 the District Court of the District of_
Columbia found that service on the state of Brazil had been validly effected by registered post to the Brazilian
Embassy. The court held at p 23 that the purposes of diplomatic immunity were not violated by registered mail
service on an embassy. The reasons it gave for this conclusion were that, unlike the situation where a federal
marshal attempts service on an ambassador personally, the delivery of a letter to the embassy does not affront the
ambassador's personal dignity. Nor does service by registered mail cause public embarrassment to the
ambassador or cause him to restrict his movements to avoid being served with process. The _Hellenic Lines_
decision was distinguishable because that case was concerned with personal service and not service by post.

88. I find the reasoning in Renchard persuasive. The question of whether service by post on a mission or the private
residence of a diplomatic agent is valid does not appear to have received much attention from judges or academic
commentators. In Volume II of the Yearbook of the ILC of 1958, paragraph (5) of the commentary on article 20
(which became article 22) stated that a special application of the principle of the inviolability of a mission was that
no writ may be served within the premises of the mission. It said that process servers may not enter the premises or
carry out their duty at the door: “The service of such documents should be effected in some other way”. It
continued: “There is nothing to prevent service through the post if it can be effected in that way”. It is also relevant
that at the meeting of 4 June 1958 Sir Gerald Fitzmaurice said:

“The last sentence in paragraph 2 of the commentary was unnecessarily categorical in saying that all
judicial notices of that nature must be served through the Minister of Foreign Affairs of the receiving State.
There was in fact no reason why judicial notices should not be sent through the post” (para 24).

89. That seems clear enough. But I should refer to a comment made by Japan when withdrawing a proposed
amendment at the 1961 Vienna Conference. Japan had proposed an amendment which would have prohibited
service by a process server within the mission premises. The Conference records that the Japanese amendment
was withdrawn “on the understanding that it was the unanimous interpretation of the Committee that no writ could
be served, even by post, within the premises of a diplomatic mission” (emphasis added). However, Volume II of the
Official Records of the Conference contains the comment that the Japanese delegation wished the issue of postal
service to be “clarified one way or the other”. It stated: “The Japanese Government is prepared to accept whatever
decision this conference will make on this point”.

90. Moreover, the records of the Conference appear to show that the states were largely content to leave draft
article 20 in the form in which it had previously been drafted Many states were opposed to any amendment and


-----

others intervening) [2015] EWCA Civ 32

little attention was paid to the Japanese proposal or the basis on which it was withdrawn. This is perhaps not
surprising in view of the relaxed attitude adopted by the Japanese delegation. In fact, the Turkish delegation was
one of the few to comment on the proposed amendment. Mr Asiroglu said that his delegation “had some doubts of
the value of the Japanese amendment, since a writ could well be transmitted through the Ministry of Foreign Affairs
or even by post”: see Volume I of the Official Records of the Conference (paragraph 31 of the 22nd meeting).

91. It seems to me that the position in relation to service by post is not as clear as one would wish. There appears
to be no clear jurisprudence in support of the proposition that article 22 _prohibits service of proceedings on a_
mission or on the private residence of a diplomatic agent by post. There is some support in the jurisprudence and in
the travaux preparatoires for the 1961 Convention for the proposition that service can be effected by post. I have
already said that I find the reasoning in Renchard to be persuasive.

92. For the reasons I have given at para 83 above, the parties to the 1961 Convention must have intended that
service could be effected on diplomatic agents in cases which come within the exceptions to immunity. The only
realistic possibilities are personal service or service by post (and now by fax and email). I have rejected personal
service for the reasons I have given at paras 84 and 85 above. Service through diplomatic channels remains to be
considered. The difficulty with this lies in its unreliability: the receiving state may refuse to effect service by these
means. The likelihood of this occurring was noted by the UK delegate at the UN session in 1958: see paragraph 36
of Volume I of the records in the Yearbook of the ILC for that year. The same point was recorded by Chief Judge
Bazelon at footnote 3 to his judgment in Hellenic Lines.

93. In some jurisdictions, service may be effected by sending the relevant document to the respondent's authorised
representative or by means of substituted service. But such mechanisms for service are not universal. I do not
consider that the parties to the 1961 Convention would have intended this to be the sole means of effecting service.

94. I conclude therefore that, subject to the rules of the relevant court or tribunal, service within the jurisdiction can
be effected by posting the documents to a mission and to the private residence of a diplomatic agent.

95. In the present case, the ET found that Ms Reyes' claim form was served at the respondents' private residence.
In my view, that was good service.

_Overall conclusion_

96. For the reasons I have given, I would dismiss both the appeal and the cross-appeal.

LADY JUSTICE ARDEN:

97. I agree.

LORD JUSTICE LLOYD JONES:

98. I also agree.

**End of Document**


-----

