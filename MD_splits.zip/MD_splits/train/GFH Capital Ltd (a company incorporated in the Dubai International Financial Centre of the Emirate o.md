Haigh and others

# GFH Capital Ltd (a company incorporated in the Dubai International
 Financial Centre of the Emirate of Dubai) v Haigh and others [2020] EWHC
 1269 (Comm)

Queen's Bench Division (Commercial Court)

Henshaw J

19 May 2020Judgment

**James Ramsden QC, Daniel Benedyk and Robert Dougans (instructed by Preiskel & Co LLP) for the**
**Claimant**

**The First Defendant (acting in person) for himself and the Second, Third, Fifth and Sixth Defendants**

Hearing dates: 10 and 14 February 2020.

Further written submissions received 19 and 21 February 2020 and 8 March 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment and that
copies of this version as handed down may be treated as authentic.

.............................

**Covid-19 Protocol: This judgment was handed down by the judge remotely by circulation to the**
**parties' representatives by email and release to Bailii. The date and time for hand-down is deemed to be 19**
**May 2020 at 3:30 pm.**

**Mr Justice Henshaw:**

(A) INTRODUCTION 4

(B) FACTUAL BACKGROUND 6

(1) The parties 6

(2) The DIFC Claim 6

(3) Other proceedings 9

(C) LEGAL BACKGROUND 10

(1) Enforcement of DIFC judgments 10

(2) Applications under the CPR 12

(D) PRINCIPAL ISSUES 14


-----

Haigh and others

(E) CLAIM AGAINST MR HAIGH 15

(1) Final and conclusive 15

(2) Definite sum of money 15

(3) Court of competent jurisdiction 15

(a) Presence 16

(b) Counterclaim 16

(c) Submission by voluntary appearance 20

(d) Position under UAE / Dubai law 21

(4) Impeachability 21

(a) Fraud 22

(b) Public policy 30

(c) Natural justice 34

(F) MR HAIGH'S DEFENCE AND COUNTERCLAIM 46

(G) GFH'S PROPRIETARY CLAIMS AGAINST THE FIRST, SECOND, THIRD, FIFTH AND SIXTH DEFENDANTS
48

(1) The DIFC Judgment 48

(2) GFH's proprietary claims 50

(3) Legal principles: constructive trust 51

(4) Legal principles: privity 53

(5) Application to facts 55

(H) ANY OTHER COMPELLING REASON FOR A TRIAL 57

(I) CONCLUSIONS 58

(A) INTRODUCTION

1. The Claimant (“GFH”) brings these proceedings, in their current amended form, in order to enforce at
common law a judgment against the First Defendant **_(“Mr Haigh”) made on 4 July 2018 by Justice Sir_**
Jeremy Cooke in the Court of First Instance of the Dubai International Finance Centre Courts (“the DIFC
**_Court”) in the matter of GFH Capital Limited v David Lawrence Haigh (claim number: CFI-020-2014) (“the_**
**_DIFC Judgment”); and to trace the sums that were declared in the Judgment to be held by Mr Haigh on_**
constructive trust for GFH into assets of all the Defendants.

This judgment follows the hearing of an application by GFH made by notice dated 30 October 2019 for summary
judgment and/or to strike-out the defences of the First to Seventh Defendants and the counterclaim of the First
Defendant. Where a statement of case in proceedings based on a foreign judgment has been served on a
defendant, and the defendant has acknowledged service or filed a defence, then the claimant may apply for
summary judgment under CPR 24.2 on the ground that the defendant has no real prospect of successfully
defending the claim.

2. Mr Haigh appears on behalf of himself as well as the Second, Third, Fifth and Sixth Defendants. He
resists GFH's application on the grounds that the Defendants' Defences and Counterclaims have real
prospects of success, and that in any event that there are compelling reasons for a trial.


-----

Haigh and others

3. GFH does not, on the present application, seek declarations against the Fourth and Seventh
Defendants, which have been the subject of compulsory strike-off from the register of companies. GFH
states that it has a pending application to restore the Fourth Defendant to the register. The Seventh
Defendant is a Guernsey company whose restoration GFH does not currently consider to be proportionate.
The Eighth Defendant accepts the declarations sought against her, and has stated that she will transfer to
GFH her entire interest in Apartments 4 and 5 of the Lamorna apartments referred to below, and account
for any benefit derived by her from the conveyance.

The hearing of GFH's application took place on 10 and 14 February 2020, with Mr Haigh participating by telephone.
Mr Haigh made an oral application for an adjournment at the start of the hearing, which was unsuccessful for the
reasons I gave in a detailed oral judgment. The background, briefly, was that Mr Haigh had had GFH's substantive
evidence for this application since May 2019. The hearing of GFH's application had already been adjourned twice,
from 23 October 2019 and from 20 December 2019. Mr Haigh had requested an adjournment of the 23 October
2019 hearing, but the judge also gave permission to GFH “permission to file and serve, within 7 days of the date of
_this Order, an amended Application Notice to include its claim for summary judgment and a further witness_
_statement in support of the Application for the purposes of making the statements required by the Practice Direction_
_to Part 24 of the Civil Procedure Rules”. The adjournment on 20 December 2019 resulted from the recusal of the_
judge who had been listed to hear it.

When the matter came before me, Mr Haigh's GP had provided a letter dated 3 January 2020 and a statutory sick
pay form signing Mr Haigh off work for 12 weeks. However, the correspondence indicated that in December 2019
Mr Haigh had proposed a hearing date in February 2020. On 18 December 2019 he filed an 83-paragraph witness
statement with voluminous exhibits, and a skeleton argument. After parties were notified on 6 January 2020 that
the hearing had been listed for 10 February 2020, Mr Haigh made no objection and sought copies of the bundle for
his preparation. On 30 January 2020 Mr Haigh made a detailed data subject access request to GFH's solicitors.
These events indicated in my view that Mr Haigh retained the capacity to deal with, and indeed initiate, legal
matters.

4. Mr Haigh's GP's letter of 5 February 2020 provided no details of the timing or effect of the surgery Mr
Haigh said was scheduled, and contained no statement to the effect that Mr Haigh was unable to attend
the imminent court hearing. Mr Haigh signed his 24th witness statement, with exhibits, on 6 February
2020. On Friday 7 February 2020 Mr Haigh sent an email requesting that he be permitted to attend the
hearing by telephone.  After giving GFH an opportunity to comment, I directed as follows:

“I note that Males J in his order of 11.12.18 (Judgments bundle tab 58] § 11) directed that in future Mr Haigh must
provide independent medical evidence concerning any inability to attend any hearing in person if he wishes to
attend by telephone, setting out the details of his medical condition(s) and why he needs to attend by telephone.

Having reviewed Mr Haigh's witness statement dated 6.2.20 and its exhibits, I am not persuaded that he has
provided such evidence. However, given the history of this matter, I am willing to take the pragmatic view that
(rather than risking Mr Haigh's non-attendance) he should be permitted to attend by telephone subject to the
following provisos:

1       Mr Haigh will be responsible for ensuring that he is available and equipped at 10.30am on Monday 10
February, the time listed for the hearing, to attend the hearing by telephone.

2       Mr Haigh must ensure he has telephone equipment sufficiently powered so as to able him to remain
connected for whole duration of the hearing, which is listed for a full day. In practice that may is likely to require the
use of a land line rather than relying on a mobile phone, and it is also likely to involve having a back-up phone to
hand in case of any failure.

3       If, as it appears has occurred in past, the Court is unable to reach or remain in contact with Mr Haigh by
telephone, the hearing will proceed nevertheless. In other words, if Mr Haigh wishes to seek to attend by
telephone, he does so at his own risk.”


-----

Haigh and others

On 9 February 2020 Mr Haigh provided a revised skeleton and his 25th witness statement, along with a case
management note and a lengthy witness statement of a Mr O'Rourke. He stated that various people had helped
him produce them. He made submissions articulately during the first part of the hearing on 10 February 2020.

In all the circumstances, I was not satisfied that the interests of justice required the hearing to be adjourned on
medical grounds, and so the hearing proceeded. In the event, Mr Haigh continued to engage with the application,
participating in the hearing by telephone over two full days, providing a 19-page speaking note for oral closing
submissions, and filing further submissions and evidence on 19 February, 21 February and 8 March 2020.
Regardless of the extent to which those materials are admissible (to which I return later), they confirm in my view
that Mr Haigh had, and availed himself of, a full and fair opportunity to participate in the hearing.

For the reasons set out below, I have come to the conclusion that Mr Haigh has no real prospect of successfully
defending the claim for enforcement of the DIFC Judgment and there is no other compelling reason why the matter
should be disposed of at a trial. I have also concluded that none of the Second, Third, Fifth and Sixth Defendants
has a real prospect of successfully defending GFH's claims for declarations against them and there is no other
compelling reason why those issues should be disposed of at a trial.

(B) FACTUAL BACKGROUND

(1) The parties

5. GFH is a company registered in the Dubai International Financial Centre of the Emirate of Dubai
**_(“DIFC”) which carries on business in financial services, investment and wealth management._**

6. Mr Haigh was the Deputy Chief Executive Officer of GFH until 14 March 2014. He was held in custody
by the Dubai authorities from 18 May 2014 to around 24 March 2016 and says he was subjected to various
forms of mistreatment.

7. The Second Defendant is a company incorporated in the United Kingdom which holds the freehold
estate of a complex of 15 holiday apartments at Lamorna, Penzance, Cornwall, TR19 6XH known or
formerly known as the 'Lamorna Cove Hotel' (“the Lamorna apartments”).

8. The Third, Fifth and Sixth Defendants hold the leasehold estate to two each of the Lamorna apartments.
The Fourth Defendant was dissolved on 22 May 2018; prior to this, it held the leasehold estate to one of
the apartments.

(2) The DIFC Claim

9. By a claim form dated 28 May 2014, GFH commenced proceedings against Mr Haigh before the DIFC
Court for breach of contract and fiduciary duty (“the DIFC Claim”). In brief, GFH contended that Mr Haigh
had procured payments of GFH's funds which were purportedly made to third parties (namely Lincoln
Associates FZE, Millnet Limited, GPW Group and Mr David Murray) but were in fact made to Mr Haigh
himself or to his order.

10. The relief sought by GFH was a money judgment and a declaration that the sums received by Mr
Haigh in breach of fiduciary duty were held on constructive trust for GFH.

11. Mr Haigh was in prison in Dubai at this stage, having been arrested on 18 May 2014 in response to a
criminal complaint made by GFH. It is Mr Haigh's case that he had left Dubai more than a year previously,
when he took up a full-time position as CEO of Leeds United Football Club, but that GFH lured him back to
Dubai by deception in order to bring about his arrest.

12. GFH obtained a worldwide freezing injunction against Mr Haigh in the DIFC Court on 3 June 2014
(continued until further order on 17 June 2014), and a freezing injunction against him in this court on 3
August 2014. The latter was expanded to include the Second to Eight Defendants on 5 December 2014.

13. Mr Haigh filed an acknowledgment of service in the DIFC proceedings on 10 June 2014 stating that he
intended to defend the claim. He did not indicate on the form an intention to contest jurisdiction.


-----

Haigh and others

14. Mr Haigh subsequently filed a defence to the DIFC claim on 21 December 2014. He “averred that the

_[DIFC Court] does not have jurisdiction to determine this matter” (§15) and denied GFH's claim “in its_
_entirety”. Mr Haigh accepted, with very few exceptions, that the payments were received by him as_
alleged, and that the document trail to support those payments in GFH's records was fraudulent. He
alleged, however, that those payments were received by him as legitimate payments of salary, expenses
and commissions and that GFH had fabricated its own records in order to conceal the true reason for the
payments from its own Board and its local regulator. Mr Haigh alleged that GFH engaged regularly in false
invoicing and false accounting in order to conceal projects and payments from its Board and regulator.

IMAGE NOT AVAILABLE

15. On 17 March 2015, GFH filed an application for immediate judgment in the DIFC Court (the equivalent of
summary judgment). By a judgment dated 18 October 2016 **_(“the Immediate Judgment”), Justice Roger Giles_**
QC determined that Mr Haigh (who was not present or represented) had been properly served with the application
and had had a proper opportunity to respond to it.  He awarded Immediate Judgment to GFH in the amounts of
AED8,735,340, US$50,000 and £2,039,793.70, together with interest, and declared that those sums were held by
Mr Haigh on constructive trust for GFH when he received them. On 10 November 2016, Justice Roger Giles QC
awarded the costs of the proceedings to GFH, insofar as they had not already been determined, on the indemnity
basis.

16. In the meantime, Mr Haigh had been released from prison on 21 March 2016, and returned to
England.

17. After his return, Mr Haigh on 17 January 2017 applied for permission to appeal the Immediate
Judgement. In making that application, Mr Haigh again raised jurisdiction challenges and also contested
the case on the merits. His application was considered by the DIFC Court of Appeal at hearings on 18
September 2016 and 13-14 September 2017, the latter of which Mr Haigh participated in (in person) by
telephone.

18. In an Order with Reasons issued on 28 February 2017, the DIFC Court of Appeal rejected Mr Haigh's
contention that the proceedings should be stayed on various grounds, including pending the resolution of
his alleged civil claim against GFH in the courts of Dubai (noting that it had become clear that there was no
such civil claim). The court also rejected Mr Haigh's request for a referral to the Joint Judicial Committee
for the DIFC Courts and the Dubai Courts (the committee primarily tasked with resolving conflicts of
jurisdiction between the DIFC and the Dubai Courts), stating that it was for Mr Haigh himself to apply
directly to that Committee.

19. However, on Mr Haigh's substantive appeal, the DIFC Court of Appeal granted permission to appeal
out of time, and by Orders dated 24 September 2017 and 22 November 2017 set aside the Immediate
Judgment, remitted the claim to the DIFC Court for an expedited trial, and directed Mr Haigh to file an
Amended Defence.

20. Mr Haigh duly filed a document entitled “Amended Defence and Counterclaim” dated 28 September
2017. By his proposed amendments, he withdrew certain of his admissions as to receipt of GFH's funds,
maintained his assertion that such funds as he received were legitimate payments of salary, expenses and
commissions, alleged that GFH used false invoicing to make payments to other employees too, and
alleged that the claim had been fabricated by GFH to prevent Mr Haigh from 'whistleblowing” with respect
to certain unparticularised allegations against GFH and its parent company of regulatory infringements. Mr
Haigh also sought to bring counterclaims/Part 21 (third party) claims:

i) against GFH for commission and referral fees, and other sums, said to be due under his employment
contract;

ii) against GFH, and Mr Al Reyes and Mr Patel of GFH, for luring him back to Dubai in breach of his
contract of employment and/or by deceit;

iii) against GFH and Mr Al Reyes for malicious prosecution false imprisonment and conspiracy;


-----

Haigh and others

iv) against GFH and Mr Patel for libel and slander;

v)  against the United Arab Emirates for unlawful arrest, false imprisonment, personal injury, torture,
misfeasance in public office, and numerous breaches of the UN Declaration of Human Rights/the UAE
Constitution, all relating to his imprisonment and mistreatment in Dubai for around 20 months in 2014/15.

The DIFC Court (Justice Sir Jeremy Cooke) by orders dated 25 November 2017 and 11 January 2018 treated Mr
Haigh's “Amended Defence and Counterclaim” as an application for permission to amend, and disallowed
counterclaims (ii)-(v) above together with certain amendments relating to abuse of process/obstruction of just
disposal of the proceedings, on the basis that they had no realistic prospects of success. These orders followed a
hearing on 13 and 14 December 2017 which Mr Haigh had by email asked the judge to adjourn. The judge refused
the adjournment, giving reasons, and Mr Haigh did not participate in the hearing.

21. In addition to considering the amendment issues, in his Reasons for the Orders dated 11 January
2018 (“the January 2018 Order with Reasons”) Sir Jeremy Cooke considered and rejected Mr Haigh's
complaint (not embodied in any formal application) that the DIFC Court lacked jurisdiction over the claim,
because (in summary):

i) a gateway existed under DIFC law because the claimant, GFH, was a DIFC entity;

ii) under the procedural rules, any jurisdiction challenge had to be made within 14 days of filing an
acknowledgement of service and supported by evidence with a statement of truth, which had not been
done; and by filing an acknowledgement without having taken such steps Mr Haigh was deemed to have
accepted the court's jurisdiction;

iii) that point was not simply a technical one, because:

“Mr Haigh has not only filed a defence in this matter but has made numerous applications and appeals to this court
for it to exercise its jurisdiction in his favour. Although in his original defence he purported to reserve his right to
challenge the court's jurisdiction, not only do the rules not provide for that but, in taking all the steps that he has, Mr
Haigh has unequivocally submitted to the jurisdiction of this court for the purposes of this action.”

iv) there was no basis for Mr Haigh's assertion that the Criminal Court in 'onshore' Dubai (a convenient
expression for referring to Dubai excluding the DIFC) had determined any civil claim for compensation; and

v) it might be the case that the DIFC Court of Appeal had already effectively decided the point against Mr
Haigh.

22. Mr Haigh thereafter took no further active part in the DIFC proceedings other than to seek
adjournments or seek permission to appeal case management decisions.

23. The trial of the DIFC Claim was heard by Justice Sir Jeremy Cooke between 1-3 July 2018. Mr Haigh
did not attend and was not represented, though emails were sent to the court shortly before and during the
trial seeking its adjournment. The DIFC Judgment was delivered on 4 July 2018. Sir Jeremy Cooke found
that Mr Haigh is a “fraudster”, who “caused to be paid into his own bank account and that of his close
_friend, monies belonging to the Claimant in the sums of £2,039,793.70, AED 8,735,340 and US$50,000”._
GFH was awarded damages in those amounts, together with interest, and a declaration that those
amounts when received by or on behalf of Mr Haigh were held on constructive trust for GFH. Mr Haigh
was further ordered to pay GFH's costs, insofar as they had not already been determined, on the indemnity
basis.

24. Time for seeking permission to appeal the DIFC Judgment expired on 25 July 2018 pursuant to rule
44.10 of The Rules of the Dubai International Financial Centre Courts 2014. It appears that no appeal was
filed by that date. The evidence indicates that Mr Haigh subsequently filed papers, at least by email,
including a request for waiver or deferral of the appeal fee, which he said he could not pay without release
of funds to which GFH has not consented.

(3) Other proceedings


-----

Haigh and others

25. There were several related proceedings taking place at the same time as the DIFC Claim and the
present claim.

i) _Dubai Criminal Proceedings. As noted earlier, Mr Haigh was arrested by the Dubai authorities on 18_
May 2014. In August 2015 he was convicted of breach of trust, the court having found that he
misappropriated funds from GFH. That conviction which was upheld on appeal in October 2015. Mr Haigh
was re-arrested and further detained on a charge of 'cyberslander' by Twitter towards GFH in November
2015 and acquitted in March 2016. He was released on 24 March 2016.

ii) High Court claim. Mr Haigh brought a claim in the High Court (QBD) in October 2014 against GFH and
related persons for alleged misconduct in his return to Dubai. I have not been directed to any evidence of
this claim having been pursued.

iii) _Private prosecution._ Mr Haigh brought a private prosecution against GFH and related persons in
January 2015, which he ceased to pursue in June 2015 (by reason, he says, of ongoing duress as he was
in prison in Dubai at this time). By an order on 30 September 2015, Mr Haigh was ordered to pay the costs
of those proceedings. Mr Haigh applied for judicial review of the costs order in the High Court; in February
2017 the court reduced the costs order by 15% but otherwise dismissed Mr Haigh's application.

(C) LEGAL BACKGROUND

(1) Enforcement of DIFC judgments

26. There is no treaty dealing with the recognition and enforcement of judgments between the United
Kingdom and United Arab Emirates (“UAE”). As such, judgments of the DIFC courts can be enforced only
at common law.

27. At common law, where a foreign court of competent jurisdiction determines that a certain sum is due
from one person to another, a legal obligation arises on the debtor to pay that sum, which can be enforced
in the courts of England & Wales. The relevant common law principles are summarised in Dicey, Morris &
Collins on the _Conflict of Laws (15th ed) (“Dicey”) § 14R-020 (Rule 24) and in the Memorandum of_
Guidance as to Enforcement between the DIFC Courts and the Commercial Court, Queen's Bench
Division, England and Wales issued in January 2013 (“the Memorandum”).

28. The Memorandum includes a helpful summary of the requirements for common law enforcement of
foreign judgments:

“10.  In order to be sued upon in the Commercial Court, a judgment of the DIFC Courts must be final and
conclusive. It may be final and conclusive even though it is subject to an appeal.

11.  The Commercial Court will not enforce certain types of DIFC Court judgments, for example judgments
ordering the payment of taxes, fines or penalties.

12. The DIFC Courts must have had jurisdiction, according to the English rules of the conflict of laws, to
determine the subject matter of the dispute. The Commercial Court will generally consider the DIFC Courts
to have had the required jurisdiction only where the person against whom the judgment was given:

a. was, at the time the proceedings were commenced, present in the jurisdiction; or

b. was the claimant, or counterclaimant, in the proceedings; or

c. submitted to the jurisdiction of the DIFC Courts; or

d. agreed, before commencement, in respect of the subject matter of the proceedings, to submit to the
jurisdiction of the DIFC Courts.

13. Where the above requirements are established to the satisfaction of the Commercial Court, a DIFC
Court judgment may be challenged in the Commercial Court only on limited grounds. Those grounds
include (but are not limited to):

a where the judgment was obtained by fraud;


-----

Haigh and others

b. where the judgment is contrary to English public policy; and

c. where the proceedings were conducted in a manner which the Commercial Court regards as contrary to
the principles of natural justice.

14. The Commercial Court will not re-examine the merits of a DIFC Court judgment. The judgment may
not be challenged on the grounds that it contains an error of fact or law. A DIFC Court judgment will be
enforced on the basis that the defendant has a legal obligation, recognised by the English court, to satisfy
a judgment of the DIFC Courts.

…

26. In most cases, a party will be entitled to apply to obtain summary judgment without trial under Part 24
of the Civil Procedure Rules 1998 (as amended), unless the debtor can satisfy the Court that it has a real
prospect of establishing at trial one of the grounds set out in paragraph 13 above. Applications for
summary judgment are dealt with swiftly, without the need for oral evidence.”

(footnote omitted)

29. Following _Miliangos v George Frank (Textiles) Ltd_ [1976] A.C. 443, a claim for enforcement of a
foreign judgment may be made for the amount of the judgment in the currency in which it was rendered:
Dicey § 14-029.

(2) Applications under the CPR

30. GFH has made an application for summary judgment and/or strike-out pursuant to the Civil Procedure
Rules. The relevant rules are set out below:

“CPR 3.4(2) The court may strike out a statement of case if it appears to the court –

(a) that the statement of case discloses no reasonable grounds for bringing or defending the claim;

(b) that the statement of case is an abuse of the court's process or is otherwise likely to obstruct the just
disposal of the proceedings; or

(c) that there has been a failure to comply with a rule, practice direction or court order.

…

CPR 24.2 The court may give summary judgment against a claimant or defendant on the whole of a claim
or on a particular issue if –

(a) it considers that –

(i) that claimant has no real prospect of succeeding on the claim or issue; or

(ii) that defendant has no real prospect of successfully defending the claim or issue; and

(b) there is no other compelling reason why the case or issue should be disposed of at a trial.”

[31. The Court of Appeal in The LCD Appeals [2018] EWCA Civ 220 §§ 38-39 set out the principles to be](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RNF-CH41-F0JY-C07M-00000-00&context=1519360)
applied to applications for summary judgment and strike-out:

“The court may strike out a statement of case if, amongst other things, it appears that it discloses no reasonable
grounds for bringing the claim: CPR 3.4(2)(a). It may grant reverse summary judgment where it considers that
there is no real prospect of the claimant succeeding on the claim or issue and there is no other compelling reason
why the case should be disposed of at trial: CPR 24.2(a)(i) and (b). In order to defeat an application for summary
judgment it is only necessary to show that there is a real as opposed to a fanciful prospect of success. Although it
is necessary to have a case which is better than merely arguable, a party is not required to show that they will
probably succeed at trial. A case may have a real prospect of success even if it is improbable. Furthermore, an
application for summary judgment is not appropriate to resolve a complex question of law and fact.”


-----

Haigh and others

32. The Court of Appeal quoted with approval the following considerations applicable to summary
judgment applications, taken from passages in Easyair Ltd v Opal Telecom Ltd _[[2009] EWHC 339 (Ch) and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7V4P-T340-Y96Y-H141-00000-00&context=1519360)_
_Swain v Hillman_ _[[2001] 1 All ER 91 at 94:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-607F-00000-00&context=1519360)_

i) the court must consider whether the claimant has a "realistic" as opposed to a "fanciful" prospect of
success: Swain v Hillman _[[2001] 1 All ER 91;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-607F-00000-00&context=1519360)_

ii) a "realistic" claim is one that carries some degree of conviction. This means a claim that is more than
merely arguable: ED & F Man Liquid Products v Patel _[[2003] EWCA Civ 472 § 8;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N2W3-00000-00&context=1519360)_

iii) in reaching its conclusion the court must not conduct a "mini-trial": Swain v Hillman;

iv) this does not mean that the court must take at face value and without analysis everything that a
claimant says in his statements before the court. In some cases it may be clear that there is no real
substance in factual assertions made, particularly if contradicted by contemporaneous documents: ED & F
_Man Liquid Products v Patel § 10;_

v) however, in reaching its conclusion the court must take into account not only the evidence actually
placed before it on the application for summary judgment, but also the evidence that can reasonably be
expected to be available at trial: Royal Brompton Hospital NHS Trust v Hammond (No 5) _[2001] EWCA Civ_
_550;_

vi) although a case may turn out at trial not to be really complicated, it does not follow that it should be
decided without the fuller investigation into the facts at trial than is possible or permissible on summary
judgment. Thus the court should hesitate about making a final decision without a trial, even where there is
no obvious conflict of fact at the time of the application, where reasonable grounds exist for believing that a
fuller investigation into the facts of the case would add to or alter the evidence available to a trial judge and
so affect the outcome of the case: Doncaster Pharmaceuticals Group Ltd v Bolton Pharmaceutical Co 100
_Ltd [2007] FSR 3;_

vii) on the other hand, it is not uncommon for an application under Part 24 to give rise to a short point of
law or construction and, if the court is satisfied that it has before it all the evidence necessary for the proper
determination of the question and that the parties have had an adequate opportunity to address it in
argument, it should grasp the nettle and decide it. If it is possible to show by evidence that although
material in the form of documents or oral evidence that would put the documents in another light is not
currently before the court, such material is likely to exist and can be expected to be available at trial, it
would be wrong to give summary judgment because there would be a real, as opposed to a fanciful,
prospect of success. However, it is not enough simply to argue that the case should be allowed to go to
trial because something may turn up which would have a bearing on the question of construction: _ICI_
_Chemicals & Polymers Ltd v TTE Training Ltd_ _[[2007] EWCA Civ 725; and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFW1-DYBP-P2K3-00000-00&context=1519360)_

viii) a judge in appropriate cases should make use of the powers contained in Part 24. In doing so he or
she gives effect to the overriding objective as contained in Part 1. It saves expense; it achieves expedition;
it avoids the court's resources being used up on cases where this serves no purpose; and it is in the
interests of justice. If the claimant has a case which is bound to fail, then it is in the claimant's interest to
know as soon as possible that that is the position: Swain v Hillman _[[2001] 1 All ER 91 § 94.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-607F-00000-00&context=1519360)_

(D) PRINCIPAL ISSUES

33. The key issues may be summarised as follows:

**Claim against Mr Haigh:**

i) Does Mr Haigh have a real prospect (in the sense outlined above) of successfully arguing that:

a) the DIFC Judgment is not final and conclusive;

b) the DIFC Judgment is not for a definite sum of money (other than a sum payable in respect of taxes or
other charges of a like nature);


-----

Haigh and others

c) the DIFC Court was not a court of competent jurisdiction; or

d) the DIFC Judgment is impeachable on the basis that it is –

i) obtained by fraud,

ii) contrary to public policy, or

iii) contrary to the principles of natural justice?

If not, is there any other compelling reason for a trial?

**Mr Haigh's counterclaim: does Mr Haigh have a real prospect of avoiding the conclusion that the**
allegations set out in his counterclaim are barred by issue estoppel, by reason of having been decided
against him by the DIFC either in the January 2018 Order with Reasons or in the DIFC Judgment? If not,
is there any other compelling reason for a trial?

**Claims against Second, Third, Fifth and Sixth Defendants:** do any of these defendants have a real
prospect of defending GFH's claims for declarations? If not, is there any other compelling reason for a
trial?

(E) CLAIM AGAINST MR HAIGH

(1) Final and conclusive

34. The test of finality in this context is the treatment of the judgment by the foreign court as res judicata. A
judgment is final and conclusive even if it can be appealed or is subject to a pending appeal: see Nouivon v
_Freeman (1889) 15 App. Cas. 1per Lord Herschell at pp 9-10._

35. The DIFC Judgment is final and conclusive on its face, and Mr Haigh's submissions did not in
substance take issue with the finality of the DIFC Judgment. Although he sought to rely on his alleged
outstanding appeal from the DIFC Judgment, he accepted that “a judgment may be enforced which is
_subject to appeal”._

36. Mr Haigh did, however, submit that it would be “clearly inappropriate” for the court to make an order for
summary judgment or strike-out at this stage, and that these proceedings “should await the hearing of the
_appeal”. These submissions, considered in section (H) below, go to the question of whether there is a_
compelling reason for a trial or there should be a stay of execution of any judgment.

(2) Definite sum of money

37. There is no dispute that the DIFC Judgment is for a definite and ascertained sum of money. That
concept can include a final order for costs: see Dicey § 14-022.

38. The DIFC Judgment does not order the payment of taxes, fines or penalties. It relates to a civil claim
between a business and a former employee.

(3) Court of competent jurisdiction

39. The judgment of a foreign court is enforceable at common law only if that court had jurisdiction
according to the English rules of the conflict of laws. Dicey Rule 43(1) to (4) indicates that such a court will
have jurisdiction if the person against whom judgment was given:

i) was, at the time the proceedings were instituted, present in the foreign country;

ii) was claimant, or counterclaimed, in the proceedings in the foreign court;

iii) submitted to the jurisdiction of that court by voluntarily appearing in the proceedings; or

iv) had before the commencement of the proceedings agreed, in respect of the subject matter of the
proceedings, to submit to the jurisdiction of that court or of the courts of that country.


-----

Haigh and others

40. The first three of these sub-rules were referred to in the proceedings, and Mr Haigh also made
submissions on the position under UAE/Dubai law.

41. Section 33 of the Civil Jurisdiction and Judgments Act 1982 provides:

“33. Certain steps not to amount to submission to jurisdiction of overseas court

(1) For the purposes of determining whether a judgment given by a court of an overseas country should be
recognised or enforced in England and Wales or Northern Ireland the person against whom the judgment
was given shall not be regarded as having submitted to the jurisdiction of the court by reason only of the
fact that he appeared (conditionally or otherwise) in the proceedings for all or any of the following
purposes, namely 
(a) to contest the jurisdiction of the court;

(b) to ask the court to dismiss or stay the proceedings on the ground that the dispute in question should be
submitted to arbitration or to the courts of another country;

(c) to protect or obtain the release of property seized or threatened with seizure in the proceedings.

(2) Nothing in this section shall affect the recognition or enforcement in England and Wales or Northern
Ireland of a judgment which is required to be recognised or enforced there under the 1968 [Brussels]
Convention or the Lugano Convention or the [Brussels I] Regulation ….”

(a) Presence

42. Mr Haigh contended that the DIFC Court did not have jurisdiction by reference to his presence in the
DIFC. At the time that the DIFC Claim was issued, he was being held in Bur Dubai prison in the Emirate of
Dubai. Mr Haigh submits that the Emirate of Dubai and the DIFC are separate territorial jurisdictions for
the purposes of the English rules of the conflict of laws. However, GFH does not seek to rely, upon the
present application, on jurisdiction based on presence. It is therefore unnecessary to consider this issue
further. I note in passing that in _Adams v Cape Industries Plc [1990] Ch. 433, 518, the Court of Appeal_
accepted a submission that “the temporary presence of a defendant in the foreign country will suffice
_provided at least that it is voluntary (i.e. not induced by compulsion, fraud or duress)” (my emphasis). It_
may therefore have been open to Mr Haigh to argue that he was in any event not voluntarily present in any
jurisdiction in Dubai.

(b) Counterclaim

43. Dicey Rule 43(2) states that a foreign court is of competent jurisdiction as against a person who makes
a claim or counterclaim before it. The four-fold classification in Dicey referred to in § 46, including the
counterclaim limb, was cited with apparent approval by the Court of Appeal in Adams at pp 509-510 and by
the Supreme Court in Rubin v Eurofinance SA _[[2013] 1 AC 236§ 7. A potential illustration of submission by](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6BRS-6VP3-RRVT-G1NM-00000-00&context=1519360)_
counterclaim is provided by the court's observations in Adams regarding the facts of Carrick v Hancock:

“In Carrick v. Hancock, 12 T.L.R. 59, the principle of territorial dominion was again referred to. In that case an action
was brought upon a monetary judgment obtained in Sweden by an Englishman domiciled in Sweden against a
defendant who resided and carried on business at Newcastle. The writ was served on the defendant during a short
visit he was paying to Sweden and he duly appeared to answer it. Though he did not himself remain in Sweden, he
was represented throughout the subsequent proceedings. He put in a defence and counterclaim and on three
separate occasions appealed to the Court of Appeal at Gota. It may be that in those circumstances, notwithstanding
his protestations that he had "only appeared under pressure, duress and compulsion of law," the English court
could properly have enforced the foreign judgment on the ground that the defendant had submitted to the
jurisdiction of the Swedish court.” (pp. 516-517)

albeit, as the Court of Appeal in Adams went on to note, the court in Carrick decided the issue based on
territorial presence.


-----

Haigh and others

44. The logic of regarding the bringing of a counterclaim as a form of submission is stated in Dicey § 14068:

“It is obvious that a person who applies to a tribunal as claimant is bound to submit to its judgment, should that
judgment go against him, if for no other reason than that fairness to the defendant demands this. It is no less
obvious that a claimant exposes himself to acceptance of jurisdiction of a foreign court as regards any set-off,
counterclaim or cross-action which may be brought against him by the defendant.256 By the same token, a
defendant who resorts to a counterclaim or like cross-proceeding in a foreign court clearly submits to the jurisdiction
thereof.” (footnote omitted)

45. It is also consistent with the provision in section 32 of the Civil Jurisdiction and Judgments Act that an
overseas judgment given in proceedings brought in breach of a jurisdiction agreement is not enforceable
provided _inter alia_ that the defendant to the judgment _“did not counter claim in the proceedings or_
_otherwise submit to the jurisdiction of that court” ._

46. On the question of when submission to a court's jurisdiction should be regarded as having been
voluntary, the Supreme Court in Rubin said:

“161 The characterisation of whether there has been a submission for the purposes of the enforcement of foreign
judgments in England depends on English law. The court will not simply consider whether the steps taken abroad
would have amounted to a submission in English proceedings. The international context requires a broader
approach. Nor does it follow from the fact that a foreign court would have regarded steps taken in the foreign
proceedings as a submission that the English court will so regard them. Conversely it does not necessarily follow
that because the foreign court would not regard the steps as a submission that they will not be so regarded by an
English court as a submission for the purposes of the enforcement of a judgment of the foreign court. The question
whether there has been a submission is to be inferred from all the facts.”

As Andrews J stated in Desarrollo Immobiliario Y Negocios Industriales De Alta v Kader Holdings Company Limited

_[2014] EWHC 1460 (QB):_

“… the party concerned must not be put in the invidious position of having to choose between losing his right to
challenge the jurisdiction and losing his right to defend himself. If he has no choice but to participate in the hearing
of the substance of the dispute and to wait to appeal a decision on jurisdiction until after the decision on the merits
has been reached, his appearance at the substantive hearing will not, without more, be characterised as voluntary:
see e.g. AES Ust-Kamenogorsk Hydropower Plant LLP v AES UST-Kamenogorsk Hydropower Plant JSC [2012] 1
WLR 920. On the other hand, a party who is seen to be “playing the system” by litigating the merits in the hope of
getting a judgment in his favour and then cynically turning round to challenge the validity of the judgment on
grounds of want of jurisdiction if he loses, will get short shrift from the English courts.” (§ 67)

In the case cited there, _AES Ust-Kamenogorsk Hydropower Plant, the Court of Appeal held that a claimant in_
England relying on an arbitration clause, who had when sued in Kazakhstan done all it could to preserve its
challenge to the jurisdiction there, had not submitted to the jurisdiction of the Kazakh court. Having lost on
jurisdiction it joined issue on the merits pending renewing its jurisdiction challenge on appeal. There was Kazakh
legal evidence that an appeal on a jurisdiction challenge could be filed only after a decision on the merits, giving the
relevant party no realistic option but to participate in the court hearing on the merits in order to pave the way to an
appeal (see §§ 167 and 200). Dicey suggests that:

“… The general thrust of the authorities, which were all examined in AES Ust-Kamenogorsk Hydropower Plant LLP
_v AES Ust-Kamenogorsk Hydropower Plant JSC is that for so long as the defendant asserted, and is obviously still_
asserting, as his primary defence that the court has no jurisdiction over him in relation to the merits of the claim,
then even if he also takes steps which are purposeful in relation to the merits of the claim, his doing so should not
be taken to mean that he has submitted to the jurisdiction for the purposes of the common law of submission, and
has abandoned his challenge for the purpose of s.33. The real question for the English court should not be whether
the defendant has taken a step in proceedings which prepare for the trial of the merits, but whether he has chosen


-----

Haigh and others

to abandon his challenge to the jurisdiction. In answering this, the English court is not bound to follow the law of the
foreign court on whether a defendant has succumbed to its jurisdiction; and if the defendant had “no real option but
_to act as it did”, as it was put in_ _AES Ust-Kamenogorsk Hydropower Plant LLP v AES Ust-Kamenogorsk_
_Hydropower Plant JSC, the court may be reluctant to find that it has submitted to the jurisdiction.” (§ 14-073,_
footnotes omitted)

Andrews J in _Desarrollo_ reasoned (obiter, since she had also concluded that there was a binding jurisdiction
agreement) that the same approach will be relevant in some cases where a counterclaim has been brought in the
foreign court:

“However, even if all those steps were to be regarded as no more than compulsory defensive steps (which I do not
accept they were) Kader also raised a counterclaim and a cross-claim. In some foreign jurisdictions the rules of
procedure may require affirmative defences to be brought by way of counterclaim – for example, set-off or
abatement. It is therefore relevant when looking at a counterclaim to consider whether it is purely defensive in
nature, or whether the party concerned is invoking the jurisdiction of the court to decide claims in its favour, in a
manner that goes beyond what is reasonably necessary to defend itself. As I have mentioned, Kader's primary line
of defence was that it had been released from liability as surety by material variations to the Lease without its
consent. It did not need to make a counterclaim in order to run that argument, but if the counterclaim did no more
than repeat what was in the defence, or raise affirmative arguments that, if accepted, would reduce or extinguish
Kader's liability as guarantor, it would probably not suffice to indicate a voluntary appearance for the purposes of
enforcement of a foreign judgment.” (§ 82)

In the present case, Mr Haigh denied that the DIFC Court had jurisdiction by virtue of his counterclaim in the DIFC
Claim. The gist of his case is that his participation in the proceedings was under duress, and that he had disputed
jurisdiction at all material times.

I am unable to accept that submission, for two reasons.

First, the DIFC Court of Appeal and Justice Sir Jeremy Cooke made clear that Mr Haigh had not taken the steps
necessary to preserve his challenge to the DIFC Court's jurisdiction: see §§24 and 28 above.

Secondly, and in any event, following the DIFC Court of Appeal's decision Mr Haigh filed the Amended Defence
and Counterclaim referred to in § 26 above. Paragraph 18 of that document repeated Mr Haigh's assertion that the
DIFC “does not have jurisdiction to determine this matter and that the correct jurisdiction to determine this matter is
_Dubai. The Defendant reserves the right to apply to the DIFC Court to challenge the DIFC Court's jurisdiction under_
_Part 12 of the Rules of the DIFC Courts 2014”. However, Mr Haigh's Counterclaims invoked the jurisdiction of the_
DIFC Court on the merits. Moreover, even if his counterclaims for commission, referral fees and other sums said to
be due under his employment contract could possibly be construed as 'defensive' counterclaims, relied on by way
of set-off, of the kind contemplated by Andrews J in Desarrollo:

i) there is no evidence that they were compulsory steps, in the sense that Mr Haigh was required or had
no realistic option but to advance those arguments on the merits pending the outcome of a jurisdiction
challenge;

ii) he did not pursue any jurisdiction challenge after putting forward his Amended Defence and
Counterclaim; and

iii) his other Counterclaims went well beyond what could on any view be regarded as 'defensive'
pleadings. Even though they were later disallowed on the grounds of lack of realistic prospects of success,
by making them Mr Haigh submitted to the merits jurisdiction of the DIFC Court.

Mr Haigh's submission to the DIFC Court's jurisdiction cannot be disregarded on the ground that it was caused by
duress or fraud. By the time he appealed to the DIFC Court of Appeal and subsequently filed his Amended
Defence and Counterclaim, Mr Haigh was back in the UK and not subject to any continuing duress from the Dubai
authorities or from GFH itself. Even leaving aside the fact that Mr Haigh appears to have had professional


-----

Haigh and others

representation in the DIFC proceedings from a leading London firm for a time during his imprisonment in Dubai, I do
not accept Mr Haigh's contentions that (i) any duress continued after he left Dubai due to the illness and disability
he suffered as a result of being in custody, (ii) he cannot have submitted to the DIFC jurisdiction after his return to
the UK as “the notion of two submissions to the jurisdiction in the same case is non-sensical”, or (iii) GFH is
estopped from relying on a 'second submission' after Mr Haigh's return to the UK due to its alleged involvement with
his arrest. After returning to the UK, Mr Haigh could have restricted himself to contesting the jurisdiction of the
DIFC Court, or even ignored it altogether. Despite this, he voluntary chose to defend the proceedings on the
merits, and to advance positive counterclaims, without pursuing his jurisdictional objection.

(c) Submission by voluntary appearance

47. Dicey Rule 43(3) states that a foreign court is of competent jurisdiction as against a person who
submitted to the jurisdiction of that court by voluntarily appearing in the proceedings.

“This case rests on the simple and universally admitted principle that a litigant who has voluntarily
submitted himself to the jurisdiction of a court by appearing before it cannot afterwards dispute its
jurisdiction. Where such a litigant, though a defendant rather than a claimant, appears and pleads to the
merits without contesting the jurisdiction there is clearly a voluntary submission. The same is the case
where he does indeed contest the jurisdiction but nevertheless proceeds further to plead to the merits, or
agrees to a consent order dismissing the claims and crossclaims, or where he fails to appear in
proceedings at first instance but appeals on the merits.” (Dicey § 14-069)

48. Since I have found that Mr Haigh submitted to the jurisdiction of the DIFC Court by counterclaiming, it
is not strictly necessary to consider submission by voluntary appearance in the broader sense. However, I
am inclined to think that even without the counterclaim Mr Haigh submitted to DIFC jurisdiction by
defending GFC's claim on the merits in circumstances where:

i) he did not take the steps necessary to preserve his challenge to the DIFC court's jurisdiction (albeit I
note that Mr Haigh was in prison in Dubai at this time when his acknowledgment of service was filed, and
he says in his 23rd witness statement that it was signed on his behalf by a pro bono lawyer whom he had
met only briefly and in difficult circumstances);

ii) there is no evidence that he was required to defend the case on the merits in order to challenge
jurisdiction, or that he had no realistic option but to advance arguments on the merits pending the outcome
of a jurisdiction challenge; and

iii) Mr Haigh continued to contest the DIFC Claim on the merits after his release from prison in Dubai and
his return to England, by which stage he could not realistically be said to have been subject to any duress
(even assuming he had previously been subject to duress).

(d) Position under UAE / Dubai law

49. Mr Haigh makes a number of contentions about the jurisdiction of the DIFC Court under the law of
Dubai and/or the UAE. He argues that the DIFC Court did not have jurisdiction to make findings of fraud,
and that it did not have jurisdiction when there were proceedings before the 'onshore' Dubai court at the
same time.

50. However, in the context of the present application, the question of jurisdiction is a matter of the English
rules of conflict of laws. Whether a foreign judgment was given by a court of competent jurisdiction
according to the law of that foreign country is not relevant: see Rule 49(2) of Dicey & Morris. In any event,
however, the evidence before me provides no good reason to doubt the conclusions as to jurisdiction
reached by the DIFC Court of Appeal and Justice Sir Jeremy Cooke referred to in §§ 24-28 above, and on
that basis I am satisfied that the DIFC Court had jurisdiction according to its own law.

(4) Impeachability

51. The general position is that a foreign judgment is final and conclusive as to any matter adjudicated by
it, regardless of any error of fact or law: see Dicey § 14R-118.


-----

Haigh and others

52. There are three circumstances in which a foreign judgment might be impeached: where it was
obtained by fraud, its enforcement would be contrary to public policy, or the proceedings in which it was
obtained were opposed to the principles of natural justice: see Dicey §§ 14R-137, 14R-152 and 14R-162.
Mr Haigh relied on all three of these exceptions.

(a) Fraud

53. A foreign judgment cannot be enforced where it has been obtained by fraud, by either the parties or
the court itself.

54. The legal principles were summarised by in Royal Bank of Scotland v Highland Finance Partners LP

_[2013] EWCA Civ 238 § 106:_

“The principles are, briefly: first, there has to be a 'conscious and deliberate dishonesty' in relation to the relevant
evidence given, or action taken, statement made or matter concealed, which is relevant to the judgment now sought
to be impugned. Secondly, the relevant evidence, action, statement or concealment (performed with conscious and
deliberate dishonesty) must be 'material'. 'Material' means that the fresh evidence that is adduced after the first
judgment has been given is such that it demonstrates that the previous relevant evidence, action, statement or
concealment was an operative cause of the court's decision to give judgment in the way it did. Put another way, it
must be shown that the fresh evidence would have entirely changed the way in which the first court approached
and came to its decision. Thus the relevant conscious and deliberate dishonesty must be causative of the impugned
judgment being obtained in the terms it was. Thirdly, the question of materiality of the fresh evidence is to be
assessed by reference to its impact on the evidence supporting the original decision, not by reference to its impact
on what decision might be made if the claim were to be retried on honest evidence.” (footnotes omitted)

55. The same principles apply to foreign judgments, except that there is no requirement to produce newly
discovered evidence: see JSC VTB Bank v Skurikhin _[2014] EWHC 271 (Comm). The Supreme Court's_
decision in Takhar v Gracefield Developments [2019] SC 19 makes clear that where no allegation of fraud
was raised at the trial leading to the impugned judgment, a party seeking to set aside the judgment is not
required to show that the fraud could not have been uncovered with reasonable diligence in advance of the
obtaining of the judgment.

56. Dicey § 14-142 refers to “the common law rule that, as long as there can be shown to be a prima facie
_case for investigation, a foreign judgment may be impeached for fraud”. For example, in Owens Bank Ltd_
_v Bracco [1992] 2 A.C. 443(a case on registration of a judgment under the Administration of Justice 1920)_
the House of Lords held the question to be whether a prima facie case of fraud had been shown, in which
case the English court must try the fraud allegation for itself.

57. In _Haber Bank v Ahmed_ _[[2001] EWCA Civ 1270, an application to set aside the registration of a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFR1-DYBP-P454-00000-00&context=1519360)_
[judgment under the Foreign Judgments (Reciprocal Enforcement) Act 1933,the Court of Appeal noted at §](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61W0-TWPY-Y1B9-00000-00&context=1519360)
32 that it was “common ground that the burden is on Mr Ahmed to prove fraud “to a high degree of
_probability”: Bater v. Bater [1951] P 35”. Under section 4(1)(a)(iv) of the 1933 Act, the registration would_
be set aside if the registering court were _“satisfied …that the judgment was obtained by fraud.” Bater_
concerned the standard of proof of cruelty in a divorce case, where the statute required the court to be
“satisfied” before pronouncing a decree. The Court of Appeal held that the case accordingly needed to be
proven beyond reasonable doubt.

Combining these two lines of authority, Dicey § 14-142 footnote 512 states:

_“The question is whether there is a prima facie that the particular foreign court was defrauded in the_
_particular case. According to Habib Bank Ltd v Ahmed_ _[[2001] EWCA Civ 1270, [2002] 1 Lloyd's Rep. 444, an](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFR1-DYBP-P454-00000-00&context=1519360)_
_allegation of fraud has eventually to be proved “to a high degree of probability”. There must, therefore, be a prima_
_facie case that this demanding standard can be reached at trial”._

58. Since in Habib the standard of proof was common ground rather than being the subject of a decision, I
am not persuaded that the authorities support the view that proof of fraud in the context of enforcement of


-----

Haigh and others

a foreign judgment (under statute or at common law) requires an augmented standard of proof. That
approach would also diverge from the general approach to proof of fraud in English civil law (see e.g.
_Hornal v Neuberger Products [1957] 1 Q.B. 247(CA) relating to proof of deceit). Whilst considerations of_
comity might support a different approach when dealing with foreign judgments, it is questionable how
compelling such considerations would be if the enforcing court considered it proven on the balance of
probabilities that the foreign judgment had been obtained by fraud. I therefore proceed on the basis that
the question is simply whether there is a prima facie case that the DIFC Judgment was obtained by fraud.

59. In considering that question, though, it is appropriate to bear in mind the statement of Lord Collins in
_AK Investment CJSC v Kyrgyz Mobil Tel Ltd_ _[2011] UKPC 7 § 116 about the need for a “nuanced_
_approach…depending on the reliability of the foreign legal system, the scope for challenge in the foreign_
_court, and the type of fraud alleged”. The DIFC Court is a well-established and reputable foreign legal_
system, with procedures and rules similar to the CPR, and Justice Sir Jeremy Cooke is a former Judge in
Charge of the Commercial Court in England & Wales.

60. Where an allegation of fraud was raised or could have been raised in the foreign court, then the
following considerations are also relevant:

i) There is a general principle that a decision by a foreign court that a judgment from the courts of that
country was not obtained by fraud can create an estoppel in English proceedings to enforce that judgment:
_Owens Bank Ltd v Bracco [1992] 2 A.C. 443(Court of Appeal) per Parker LJ at pp 470 and 472,_
commenting upon House of Spring Gardens Ltd v Waite _[[1991] 1 Q.B. 241.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CXX-0W41-DYHY-B3SX-00000-00&context=1519360)_

ii) It may also be an abuse of process of the English court to raise for a second time an argument which
was raised and disposed of in the foreign court: House of Spring Gardens Ltd v Waite _[[1991] 1 Q.B. 241per](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CXX-0W41-DYHY-B3SX-00000-00&context=1519360)_
Stuart-Smith LJ at pp 254-255. In Owens Bank Ltd v Etoile Commerciale SA [1995] 1 WLR 44a French
court gave judgment in favour of Etoile on a bank guarantee, rejecting the bank's allegation of fraud and
forgery on the part of the plaintiff. A claim brought by the bank in St Vincent against Etoile for damages for
fraud was struck out by the court. In subsequent proceedings in St. Vincent to enforce the French
judgment, the Privy Council struck out, as an abuse of process, the bank's attempt to plead fraud as a
defence.

61. Mr Haigh contends that the judgment is impeachable on the basis of several allegations of fraud.
These allegations can conveniently be divided into three categories.

62. First, Mr Haigh alleges that:

i) he received considerable sums from GFH as legitimate commission/salary/expenses (and that others
were paid in the same way);

ii) he was in a position to 'whistle-blow' on alleged illegal activity by GFH, and also in a position to cause
GFH financial harm;

iii) GFH fabricated an audit trail in order to allege in the DIFC proceedings that these legitimate payments
to him were in fact fraudulent; and

iv) GFH lured Mr Haigh to return to Dubai, then knowingly supplied false information to the Dubai police to
secure Mr Haigh's arrest and imprisonment, and commenced a knowingly fictitious claim against him in the
DIFC in order to freeze his assets, leaving him unable to defend himself properly.

63. I agree with GFH that the substance of this case has already been considered by the DIFC Court and
resolved in GFH's favour.  The relevant allegations in Mr Haigh's current Defence and Counterclaim dated
8 April 2019 are essentially those addressed in the third witness statement of Mr Patel of GFH dated 16
March 2015, which was before the DIFC Court. In the hearing before Justice Sir Jeremy Cooke in July
2018, Mr Patel was examined in chief and (in the absence of the Mr Haigh) questioned by the judge under
oath.


-----

Haigh and others

The judge considered and rejected Mr Haigh's claims for entitlement to salary, fees and commissions in §§ 60-73 of
the DIFC Judgment, concluding that:

“The cross-claims have all hallmarks of a fictitious invention of a desperate defendant seeking to find some way of
challenging sums which are indisputably due from him as a result of his own fraud. No credence can be given to
any of the allegations made by the Defendant in this regard. No evidence has been adduced to make good any
claims against LUFC or the Claimant for any part of the entitlement claimed and the cross claims must therefore be
dismissed.”

('LUFC' referred to Leeds United Football Club, into which GFH had made an investment and by which Mr
Haigh was employed as managing director.)

64. The judge considered Mr Haigh's allegations of fabrication by GFH in §§ 42-57 of the Judgment. He
concluded at §58 that “[t]he evidence clearly establishes [Mr Haigh's] involvement in the procuring and
_preparation of false invoices, stamping of invoices and signature of bank transfer forms or other requests_
_for payment of the Claimant's monies into his own bank accounts”, adding at § 59 that:_

“When the Defendant's bank statements are examined what is shown is a series of interbank transfers made for no
apparent reason other than to obfuscate and hide the source from which the original payments came.”

65. In reaching these conclusions the judge considered the witness statements of Mr Asim Al Raisi and Mr
Abduramanov which Mr Haigh had put forward in support of his case of fabrication by GFH.

66. Mr Haigh complains that the judge did not also consider a witness statement dated 15 February 2017
of Ms Lilibet Echavez, who had worked at GFH as a cleaner and administrative assistant, and was the
cleaner for Mr Patel and Mr Haigh. Ms Echavez stated that she had cleaned Mr Haigh's home and helped
him with household duties from 2007 to 2014, with a key and full access to his home from 2008 to 2014,
but did not see him again after he left jail. In April 2016 she began working for Mr Haigh remotely and was
_“presently employed by Mr Haigh w[h]ere I assist him, remotely, with various administrative duties”._
Among other things, Ms Echavez stated that in the office early one day in summer 2013 she saw Mr Biju of
GFH with cut-out logos of entities to whom Mr Haigh had allegedly procured transfers of funds, and pieces
of paper with Mr Haigh's signature on them, together with invoices with these logos and signatures stuck
onto them. She said she saw that Mr Biju had Mr Haigh's stamp on his desk, and referred to Mr Biju's
furtive manner when she encountered him. Ms Echavez ended by stating that _“I did not see Mr Haigh_
_again so did not think to tell him” (notwithstanding, I note, that Ms Echavez had said she continued working_
for Mr Haigh at his home until 2014, i.e. at least six months after the event she describes).

67. Leaving aside any questions of the reliability of this evidence, its substance is essentially the same in
this regard as that of Mr Aburamonov and Mr Al Raisi, which Justice Sir Jeremy Cooke considered along
with that of Mr Patel who gave oral evidence before him. Mr Patel's evidence included his account of
interviews of Mr Biju and the conclusions drawn from them (including that Mr Biju was acting on Mr Haigh's
instructions). In these circumstances, the evidence of Ms Echavez adds nothing of substance to the
material already considered by the DIFC Court and is not 'material' in the sense that it would have changed
(still less entirely changed) the way in which the DIFC Court approached and came to its decision (see
_Royal Bank of Scotland quoted in § 69 above). Moreover, since Ms Echavez's evidence was summarised_
in § 27(f)(iii) of Mr Haigh's Amended Defence and Counterclaim which was before Justice Sir Jeremy
Cooke, it is likely that the judge had regard to its substance in any event.

68. Mr Haigh also relied on handwriting evidence in support of his fabrication allegations. The bundle
indices indicate that the expert report of Mr Radley was before the DIFC Court, but it appears that no
expert on handwriting was made available to give evidence at trial. Mr Patel gave evidence to the DIFC
Court (including in his 3rd witness statement) about the fabrication issue, including in particular the
handwriting report of Mr Radley adduced by Mr Haigh and the conclusions that could be drawn from it.
Among other things, Mr Patel demonstrated from contemporaneous emails that Mr Haigh gave specific
instructions to colleagues to affix his signature to payment instructions and other documents, and explains


-----

Haigh and others

why Mr Haigh's thesis that GFH fabricated the audit trail in order to incriminate Mr Haigh lacks any
credibility.

69. I do not consider that Mr Haigh can arguably establish a prima facie case, or indeed any case, that the
claim against him in the DIFC Court was fictitious such that the DIFC Judgment was procured by fraud. On
the contrary, as Justice Sir Jeremy Cooke said at § 5 of the Judgment, “no-one has ever come forward with
_a coherent explanation for the fact that large sums of money found their way into the bank accounts of the_
_Defendant and that false invoices were created with payment instructions which disguised the receipt of_
_those sums by the Defendant.”_

70. Turning to Mr Haigh's allegation that GFH lured him back to Dubai, Mr Haigh states in his 22nd
witness statement that (a) his false imprisonment and mistreatment in Dubai is the subject of several
United Nations complaints against the UAE (including for arbitrary detention, torture and a nonindependent judiciary); (b) the Metropolitan Police Modern Slavery and Kidnap unit, which handles human
trafficking, has referred his complaint of human trafficking and conspiracy against GFH, Mr Al Reyes and
GFH's solicitors to the Crown Prosecution Service and the National Crime Agency; (c) that Metropolitan
Police SO15 is investigating the UAE parties Mr Haigh states are responsible for his mistreatment; and (d)
the Swiss authorities are also investigating his mistreatment.

71. Mr Haigh further relies in this context on the decision of Sheriff T Welsh QC on 17 November 2017 in
an extradition case in which Mr Haigh gave evidence, _The Lord Advocate (for the Government of the_
_United Arab Emirates) v Garnet Douglas Black. The Sheriff was not persuaded that there were substantial_
grounds established that would enable him to conclude that there was a real risk of an Article 6 violation if
the respondent to that case were extradited on the basis of a number of alleged systemic problems.
However, he refused extradition on the basis that it had not been shown that the respondent (who had
been convicted in his absence) would receive an ECHR-compliant retrial. In addition, the Sheriff found that
the respondent would be unable to afford legal representation and could not in practical terms defend
himself (against complicated charges in a tribunal conducted entirely in Arabic with limited translation into
English), and would have refused extradition on that ground too. The Sheriff's judgment includes a long
account of Mr Haigh's evidence about GFH having lured him back to Dubai in 2014 and his misstatement
at the hands of the authorities there. The Sheriff returned to Mr Haigh's evidence later in his judgment
when considering, obiter, whether he would have accepted the contents of a report by Lord Rowbotham (a
former Chief Inspector for prisons in the UK) about conditions in UAE prisons, based on a one-day visit to
Dubai. The Sheriff stated:

“David Haigh struck me as an honest intelligent witness who gave his evidence with calm dignity. He was obviously
a man who had been significantly physically and psychologically damaged by his ordeal in the UAE and was in the
process of what I consider will be a long recovery. I cannot reach any conclusion about the merits of the commercial
dispute he has with his former employers because I have only heard his side of the story and the present case is
not about that. The focus of his evidence before me related to why he was in Dubai in May 2014 and what
happened to him, in police detention, during the trial process there and in prison custody after his conviction. With
regard to these matters, I believed him when he said he was lured to Dubai. I believed his evidence when he
indicated that high ranking Emiratis have influence over and access to the police and other aspects of civil society. I
have no doubt he was telling the truth about seeing a civilian lawyer who acted for his former employers, in Bur
Dubai Police Station in the company of a police officer pointing at him, before being questioned and beaten by
police. The clear inference that that civilian lawyer had influence as to how he was badly treated and abused by the
police, is irresistible. I fully accept he was repeatedly seriously assaulted by Dubai police officers and Tasered
while detained at Bur Dubai Police Station. I accept he was interrogated and forced to sign a document in Arabic
the content of which he could not understand. Thereafter, I believed the account he gave of squalid, overcrowded
and insanitary detention conditions in Bur Dubai Police Station. I further believe he was sexually assaulted and
raped in the car park of that Police station during his detention. I am also satisfied that the evidence he gave about
poor consular access and no consular protection while in custody is true. In addition I believed him when he said
the police authorities were both actively engaged in institutionalised racism against non-Muslims and non-Emiratis
within the detention block and complicit in the racial abuse administered to non-Muslims by local prisoners within


-----

Haigh and others

the detention centre. Albeit, I held Lord Rowbotham's document inadmissible in evidence, if I had to judge between
its content based upon a single day's observation in one detention centre/prison in Dubai and the sustained ordeal
endured by David Haigh who was held in 4 different custodial settings in Dubai over almost two years, I would have
had little hesitation in preferring the direct tested evidence of David Haigh over the untested and limited narrative in
the Lord Rowbotham document.” (§ 71)

72. Although the Sheriff in the course of this passage stated that he believed Mr Haigh's evidence that he
was lured to Dubai, the Sheriff also pointed out that he had not heard from GFH. The Sheriff's conclusions
are entitled to respect, but they do not amount to a binding finding as between GFH and Mr Haigh as to the
circumstances in which Mr Haigh returned to Dubai in early 2014. Mr Haigh put forward this aspect of his
case to the DIFC Court, but it was rejected on its merits as part of Justice Sir Jeremy Cooke's January
2018 Order with Reasons.

73. Moreover, even if Mr Haigh were lured back to Dubai by GFH in order to bring about his arrest, I do
not consider that that would provide arguable grounds to impugn the DIFC Judgment (or the January 2018
Order with Reasons), both of which occurred long after Mr Haigh's release from Dubai and his return to the
UK. It would be unrealistic in my view to suggest that because the DIFC proceedings were originally
commenced while Mr Haigh was detained in Dubai, any deceit involved in procuring his presence there
means that DIFC decisions made years after his release were procured by fraud.

74. In all the circumstances, I accept GFH's submission that Mr Haigh's attempt to raise these issues is:

(in part) contrary to the general principle that a decision by a foreign court that a judgment from the courts of that
country was not obtained by fraud creates an estoppel in English proceedings to enforce that judgment;

an abuse of process of the English court, since the issues were raised and disposed of in the foreign court;

hopeless on the merits; and

immaterial to the DIFC Judgment having been obtained on the terms that it was.

75. Secondly, Mr Haigh alleges that witnesses in the DIFC Claim were bribed. In principle, bribing
witnesses might render a judgment impeachable: see Dicey § 14-138. Mr Haigh relies in particular on
witness statement evidence provided by a Mr Simon O'Rourke, who states that he provided graphic and
web design services to Mr Haigh from 2016 to May 2019, and booking managing services from 2017 to
May 2019 for companies of which Mr Haigh was a director. Mr O'Rourke explains that he had a dispute
with Mr Haigh but is now reconciled with him, and that he is “presently sitting with [Mr Haigh] at his cottage
_in Cornwall as I write this statement” viz Mr O'Rourke's first witness statement._

76. Mr O'Rourke alleges that Mr Patel approached him to give evidence and “made numerous suggestions
_to me that payments and other financial inducements from the Claimants would be paid to me or provided_
_to me”. Mr O'Rourke among other things alleges that while he was dealing with GFH's solicitors, they_
provided benefits totalling about £5,000 in the form of train tickets, hotel accommodation, cash advances of
at least £320 and a £1,000 payment in November 2019 for the supply of confidential emails and
information of Mr Haigh. Mr O'Rourke's witness statement contains no evidence of any actual payment,
still less any improper payment, to Mr Patel himself or to any other witness who gave evidence in or for the
DIFC trial. Equally, Mr Haigh in his 23rd witness statement states merely _“I believe it reasonable to_
_assume that Mr … Patel has also similarly been paid and offered significant financial and other benefits for_
_providing evidence, which I say is false. Mr Patel is the claimant's main witness in its application to enforce_
_and in the DIFC proceedings notwithstanding he was not at the Claimant at any material time and has_
_since left the Claimants group for the second time”._

77. At the hearing before me on 14 February 2020, I gave permission for the parties to submit shortly after
the hearing evidence on one specific topic, namely the difficulties Mr Haigh alleges he had encountered in
communicating by telephone with the DIFC Court on or around the time of the DIFC trial on 1-4 July 2018
(a topic to which I return later). GFH filed documents in response to that direction, comprising emails


-----

Haigh and others

between Mr Haigh and the DIFC Court dated between 28 June and 2 July 2018. Mr Haigh filed his 27th
witness statement and exhibits, parts of which deal with that topic.

78. However, other parts of Mr Haigh's 27th witness statement deal with other topics, and Mr Haigh also
submitted without permission an unsigned second witness statement of Mr O'Rourke. On 8 March 2020
Mr Haigh submitted, again without permission, a signed third witness statement of Mr O'Rourke dated 6
March 2020. Those statements contain further, new, allegations including allegations to the effect that Mr
Patel of GFH had told Mr O'Rourke that GFH (for whom he no longer worked) was paying him, for his
evidence “and to lie”, “a lot and enough to be spending a significant amount of his time”; and that Mr Patel
had admitted that he was lying in his evidence in order to “get Haigh and bring justice to him”. The third
statement of Mr O'Rourke goes even further, setting out extensive purported recollections of conversations
with Mr Patel in which Mr Patel told Mr O'Rourke that the payments Mr Haigh received from GFH had been
approved by Mr Al Reyes and that GFH's claim against Mr Haigh had been fabricated and untruthful.

79. No formal application was made to adduce these unsolicited materials in evidence, and I decline to
admit them. GFH's summary judgment application was made more than a year ago, in April 2019, and Mr
Haigh has had more than ample opportunity to adduce evidence in support of his case. Between the issue
of GFH's application and the hearing before me, Mr Haigh adduced his 22nd witness statement (17
October 2019), his 23rd witness statement (18 December 2019), his 24th witness statement (6 February
2020), the first witness statement of Mr O'Rourke (6 February 2020), Mr Haigh's 25th witness statement (9
February 2020) and his 26th witness statement (12 February 2020). As I have already noted, Mr
O'Rourke's first witness statement stated that it was written while sitting at Mr Haigh's cottage: an indication
that Mr Haigh had ample opportunity to obtain such evidence from Mr O'Rourke as Mr Haigh considered
appropriate in order to support his case/defence.

80. Mr Haigh has put forward no good justification for seeking to put forward new evidence from Mr
O'Rourke or from Mr Haigh himself, going beyond the evidence previously adduced, and making new and
serious allegations against Mr Patel unsupported by any documentary evidence. Mr Haigh's and Mr
O'Rourke's statements provided on 8 March 2020 refer to Mr Haigh's illness and to Mr O'Rourke being
_“effectively homeless and living in temporary accommodation”. However, Mr O'Rourke provided a 24-page_
first witness statement on 6 February 2020. If there were any truth in the new allegations, it is impossible
to understand why Mr O'Rourke did not set them out in his first witness statement, and neither he nor Mr
Haigh gives any satisfactory explanation for his failure to do so. Mr Haigh's suggestion in his letter of 12
March 2020 that Mr O'Rourke in his second and third witness statements _“has simply detailed those_
_allegations [in his 1st statement] further following more time been [sic] available to him” (a) is simply wrong,_
since the allegations in the 2nd and 3rd statements go far beyond those in the 1st, and (b) indicate that
there is no good reason for the extreme lateness of the proposed evidence. In all the circumstances I do
not find the evidence remotely credible. In any event, I do not consider it would be fair to permit this new
and extremely late evidence to be adduced now, with the inevitable need for responsive evidence and
consequent further delay in dealing with GFH's application. The late evidence Mr Haigh seeks to put
forward does not arise from any new and unexpected evidence from GFH's side, but rather has the
appearance of an attempt by Mr Haigh to embellish his case in the light of the arguments made at the
hearing.

81. Thirdly, Mr Haigh makes allegations of misconduct by GFH by 'concealing' evidence from the DIFC
Court.  In particular, Mr Haigh submits in his skeleton argument that:

i) GFH's witness statements to the DIFC Court in May 2014 “all conceal the fact that jurisdiction had been
_asserted before the onshore court and accepted by that court; and, worse, they conceal the criminal_
_conduct leading to [Mr Haigh's] incarceration in Dubai”; and_

ii) GFH concealed relevant evidence before Justice Sir Jeremy Cooke in July 2018.

82. Any concealment of the kind mentioned in (i) above (which, for the avoidance of doubt, I do not find to
have occurred) cannot have affected the Judgment GFH now seeks to enforce, viz the July 2018 judgment,
since that judgment followed a full rehearing of the case on the merits and Mr Haigh was able to and did


-----

Haigh and others

advance before Justice Sir Jeremy Cooke his arguments regarding jurisdiction and the events leading to
his incarceration.

83. As to (ii) above, Mr Haigh's skeleton cross-refers to §§ 71-73 of his witness statement dated 19
December 2019. He thereby refers to the witness statement of Ms Echavez which I consider in §§ 83 and
84 above, together with:

“multiple reports from PWC, forensic accounts Samuels LLP finding use of false invoices in payment of other
Claimant staff and multi millions were due to me, and IT expert report of BR Consult and Robert Bradley [sc.
Radley] forensics laboratories who I believe to be the leading handwriting expert in the country confirming my
signature had been forged multiple times with attempts to cover up those forgeries on transfer forms none of these
witness reports were referred to at all in the judgment of Justice Cooke. I cannot say if they were included as I was
not served the hearing bundle and I was also in hospital.”

84. GFH provided me during the hearing with a Note attaching copies of the trial bundle indices for the
July 2018 hearing before Justice Sir Jeremy Cooke, which indicates that four reports from PWC, two
reports from Samuels LLP, an expert report of Robert Radley, a report from BR Consult and a witness
statement of Ian Monk (about whose omission Mr Haigh has also complained) were in the hearing bundles.
Therefore – and regardless of whether these materials were specifically cited – there can be no merit in
any suggestion that they were fraudulently concealed from the DIFC Court.

(b) Public policy

The parties did not cite any exhaustive statement of the circumstances when a foreign judgment may be impeached
on public policy grounds. Examples of such circumstances are:

where a judgment is inconsistent with a previous decision of a competent English court in proceedings between the
same parties or their privies, _res judicata being capable of expression as a rule of public policy (Dicey § 14-156_
citing Vervaeke v Smith [1983] 1 A.C. 145, 160G);

where a judgment has been obtained in disobedience of an injunction not to proceed with the action in a foreign
court, in circumstances of evidently discreditable behaviour on the part of the court concerned (Dicey § 14-156
citing AK Investment CJSC v Kyrgyz Mobil Tel Ltd _[2011] UKPC 7);_

where enforcement of a foreign judgment would be contrary to the European Convention on Human Rights (that
[being the effect of the Human Rights Act 1998). There is arguable authority in support of the proposition that where](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
a foreign court (such as the DIFC Court) is not a party to the Convention, such shortcomings must be “flagrant”
(Government of USA v Montgomery (No.2) [2004] UKHL 37, discussed at Dicey § 14-160); and

(possibly) where the foreign judgment is exemplary or punitive or for manifestly excessive damages (Dicey § 14157).

85. Mr Haigh submits that:

the circumstances of his detention and criminal prosecution in Dubai violated his human rights; and

the DIFC Court was not independent and impartial, either in general or given Mr Haigh's role as a human rights
activist.

86. The circumstances of Mr Haigh's detention and prosecution in Dubai do not affect the DIFC Judgment.
Mr Haigh returned to England in March 2016 and has remained at liberty ever since. The DIFC Court of
Appeal in September 2017 directed that the case against Mr Haigh be re-heard, which it was culminating in
the trial in July 2018. Mr Haigh was permitted to serve an Amended Defence and Counterclaim and to
defend GFH's claim afresh.

87. In relation to the DIFC Court, Mr Haigh relies on the following points:


-----

Haigh and others

i) The Divisional Court concluded in Lodhi v Secretary of State for the Home Department [2010] EWHC
_567 (Admin) that there was a real risk that if a national of Pakistan were extradited to the United Arab_
Emirates, his human rights would be breached either before trial or during imprisonment after conviction,
as the general conditions of custody encouraged harsh treatment, especially of foreigners, and brutality in
punishments.

ii) The US State Department Country Report in the section on Civil Judicial Procedures and Remedies
refers to the civil courts' lack of independence including by reason of the involvement of the local rulers'
“diwans” who report to the Minister of the Interior.

iii) The DIFC is a Dubai court established in the name of the Ruler of Dubai, Sheikh Mohammed bin
Rashid al Maktoum, and whose judges swear an oath of office to the Ruler. Dubai is a dictatorship.

iv) At present a third of the judges of the DIFC courts are Emirati from the onshore Dubai courts. Mr Haigh
makes specific reference to three DIFC judges. First, H.E. Justice Omar al Muhairi, who became Deputy
Chief Justice of the DIFC courts in November 2018, had previously served as a Dubai Public Prosecutor.
Secondly, H.E. Justice Shamlan al Sawalehi, who became a DIFC Court of Appeal judge in 2017, had
served as Director of Strategic Affairs at the Executive Office of Sheikh Maktoum, as well as having worked
as a Dubai Public Prosecutor and represented the Dubai Government in high value cases. Thirdly, H.E. Ali
Shamis al Madhani, a judge of the DIFC Court of Appeal since 2008, had previously served as a Dubai
Public Prosecutor.

v) Jurisdiction disputes between the DIFC Court and the onshore Dubai courts are decided not by
individual courts but by the Joint Judicial Committee (on which H.E. Ali Shamis al Madhani, among others,
has served). Mr Haigh says he tried to refer his case to the Committee but could not pay for the required
Arabic translation by reason of the asset freezing order which GFH obtained in the DIFC.

vi) Mr Haigh refers to Articles 149, 175, 176, 180 and 182 of the Dubai Penal Code. These provisions
include prohibitions on damaging the sovereignty, independence or unity of the State (Article 149), and
deliberately and publicly insulting the State President, flag or national emblem (Article 176). Mr Haigh
refers to a Human Rights Watch report on Emirati human rights defender Ahmed Mansoor, which he says
shows that the provisions of the Penal Code are interpreted as making it an offence to criticise the UAE,
Dubai, the DIFC, the courts or the Ruler, and are often used to jail human rights defenders and even
judges.

vii) Mr Haigh notes that after he pointed out the Penal Code provisions to Mr Ali Malek QC, who had been
listed to hear the present application in December 2019, Mr Malek recused himself on conflict grounds by
reason of his position on the Dubai Financial Markets Tribunal (and thus, Mr Haigh says, ultimately
employed by Sheikh Maktoum).

viii) The Freedom House 2019 report on the UAE states inter alia that “[t]he judiciary is not independent,
_with court rulings subject to review by the political leadership. Judges are appointed by executive decree,_
_and the judiciary as an institution is managed largely by executive officials. Many judges are foreigners_
_working on short-term contracts.” (section 17 § F1)._

88. Taking these points in turn:

i) The _Lodhi decision about treatment of detainees in the UAE has no direct bearing on the DIFC_
Judgment and cannot amount to a public policy ground for declining to enforce it.

ii) The US State Department Country Report relates to the Dubai onshore courts, not the DIFC.

iii) It is common for judges to be appointed formally in the name of, and swear an oath to, a head of state.
That fact does not impair judges' ability to make rulings against the state's government or ministers, and
cannot constitute a public policy objection to enforcement.

iv) Even if the fact that some DIFC judges have previously worked as Dubai public prosecutors, or (in one
case) for the Executive Office of the Ruler of Dubai, were capable of making it inappropriate for them to sit


-----

Haigh and others

in certain cases, there is no reason to believe that would be the case in the present case. Still less could
that fact arguably mean that Justice Sir Jeremy Cooke lacked independence or impartiality in relation to the
present case.

v) The constitution of the Joint Judicial Committee, and Mr Haigh's apparent attempt to seek from it a
ruling that the onshore Dubai court should hear the case, have no bearing on the independence or
impartiality of Justice Sir Jeremy Cooke.

vi) Even if one assumes for present purposes Mr Haigh's submissions about the practical impact of the
Dubai Penal Code to be correct, they provide no public policy reason to decline to enforce the DIFC
Judgment. The claimant, GFH, is neither the Dubai State nor its Ruler, nor an emanation of either.
Counsel for GFH told me that GFH is a publicly owned company in which a stake is held by the state
investment vehicle of Abu Dhabi, another member of the UAE (though the documents also contain
reference to the state of Bahrain having a stake in GFH). Mr Haigh's main point in this context was that the
Penal Code would mean that Justice Sir Jeremy Cooke could not safely criticise Dubai or its Ruler in
connection with the circumstances and conditions of Mr Haigh's arrest and detention in Dubai. However,
Mr Haigh's complaints in that regard were not relevant to the merits of GFH's claim against him, and
(following Justice Sir Jeremy Cooke's ruling referred to in § 27 above) they formed no part of the DIFC trial
in July 2018. In these circumstances, any alleged inhibition on the judge's ability to criticise the State or
Ruler of Dubai cannot provide any arguably public policy objection to the enforcement of the DIFC
Judgment.

vii) The reasons for Mr Malek's decision to recuse himself have no bearing on the independence or
impartiality of Justice Sir Jeremy Cooke.

viii) It is unclear whether the quotation from the Freedom House Report has any application to the DIFC.
There is no evidence that the DIFC Court's decisions are subject to political review, and so the comments
are presumably directed to the onshore Dubai courts. It may well be the case that many DIFC judges are
foreign nationals working on short-term contracts. That would not, however, amount to an arguable
independence-based public policy objection to the enforcement of its judgments. _A fortiori_ I do not
consider that the short-term nature of the appointment of a person, such as Justice Sir Jeremy Cooke, who
has already had a full career as a High Court judge in England and Wales (or the equivalent in another
jurisdiction outside Dubai), and accepts appointment to the DIFC as a follow-on career, arguably impairs
that person's independence such as to found a public policy ground for declining to enforce his or her
judgments.

89. Mr Haigh's claimed role as a human rights activist prior to his incarceration in Dubai is contested by
GFH, but he provides some evidence of having campaigned against Dubai from periods between such
incarceration and the DIFC trial. However, GFH's claim against Mr Haigh and the issues at the DIFC trial
do not concern those activities of Mr Haigh's, and there is no reason to believe his campaigning activities
had any influence over DIFC Court process or its outcome.

90. On 8 March 2020 Mr Haigh submitted, without permission, his 28th witness statement. For the
reasons given earlier, I decline to admit it in evidence. This statement includes reference to judgments of
Sir Andrew McFarlane in Re Al M dating from December 2019 and January 2020 but previously subject to
reporting restrictions ([2019] EWHC 3415 (Fam), [2020] EWHC 67 (Fam) and [2020] EWHC 122 (Fam)).
Mr Haigh says these show that the Ruler of Dubai used a _“campaign of fear and intimidation”,_ including
death threats and false imprisonment attempts against HRH Princess Haya and those assisting her
(including while she was in England), due to her attempts to help Princesses Latifa and Shamsa; that both
Princesses were abducted by the Ruler (the latter from the streets of Cambridge); and that the Ruler had
not been open and honest with the English court. Mr Haigh is mentioned in the first of the judgments cited
above as having been contacted by Princess Latifa while on the yacht Nostromo on which she had sought
to escape.

91. Mr Haigh says in his 28th witness statement that the DIFC Court knew about his activities assisting
Princess Latifa not least from letters he wrote to that court He adds that he has also represented or


-----

Haigh and others

assisted Princess Shamsa, the Ruler's first ex-wife Sheikha Randa al Banna, and his estranged wife HRH
Princess Haya of Jordan. Mr Haigh submits that the Dubai courts, including the DIFC courts, “the head of
_whom is … the ruler of Dubai, to whom each of the judges swear an oath to and are ultimately paid by on_
_short term contracts”, are biased against him. Further, he says he has been prevented since 2014 from_
travelling to Dubai or otherwise being able to engage with the DIFC Court.

92. Had I considered this particular material to be relevant, I would have been inclined to admit it in
evidence on the basis that Sir Andrew McFarlane's judgments became publicly available only some time
after the appellate decision in _Maktoum v Hussein [2020] EWCA Civ 283, handed down on 28 February_
2020, post-dating the hearing before me. However, the matters on which Mr Haigh relies do not add
anything material to the present case over and above the matters I consider in §§ 105-107 above. There is
no arguable case that Justice Sir Jeremy Cooke was biased against Mr Haigh by reason of Mr Haigh's
association with and activities in support of members of the family of the Ruler of Dubai.

93. Accordingly, there is in my judgment no arguable public policy objection to the enforcement of the
DIFC Judgment.

(c) Natural justice

94. Dicey summarises the relevant principles as follows:

“In a celebrated passage in his judgment in Pemberton v Hughes (a case on the recognition of a foreign divorce
decree), Lord Lindley observed: “If a judgment is pronounced by a foreign court over persons within its jurisdiction
_and in a matter with which it is competent to deal, English courts never investigate the propriety of the proceedings_
_in the foreign court, unless they offend against English views of substantial justice.”_ This passage refers to
irregularity in the proceedings, for it is clear that a foreign judgment, which is manifestly wrong on the merits or has
misapplied English law or foreign law, is not impeachable on that ground. Nor is it impeachable because the court
admitted evidence which is inadmissible in England or did not admit evidence which is admissible in England or
otherwise followed a practice different from English law. In Jacobson v Frachon Atkin L.J., after referring to the use
of the expression “principles of natural justice,” said: “Those principles seem to me to involve this, first of all that the
_court being a court of competent jurisdiction, has given notice to the litigant that they are about to proceed to_
_determine the rights between him and the other litigant; the other is that having given him that notice, it does afford_
_him an opportunity of substantially presenting his case before the court._

_Adams v Cape Industries Plc appears to have been the first English case in which the defence of breach_
of natural justice was established in relation to a judgment in personam. The Court of Appeal held that the defence
of breach of natural justice was not limited to the requirements of due notice of the hearing to a litigant and
opportunity to put a case to the foreign court. It confirmed that the basic question was that stated in Pemberton v
_Hughes, namely whether there was a procedural defect which constituted a breach of the English court's view of_
substantial justice, which would depend on the nature of the proceedings under consideration. The principle was
applied in _Masters v Leaver, where the Court of Appeal considered that a substantial failure to follow its own_
procedure for an assessment of damages meant that proceedings before a Texas court had led to a judgment in
denial of substantial justice.

A mere procedural irregularity would not offend English concepts of substantial justice. In Adams v Cape Industries
_Plc the foreign judgment was for damages in default of appearance, and notice was given to the defendants of the_
application for a default judgment on an unliquidated claim. Under United States law (as under English law) the
assessment of damages is effected (even in cases of default) by the court, but the United States judge did not hold
any form of hearing, and the judgment was not based on an objective assessment by the judge of the evidence.
The Court of Appeal did not decide that a lack of judicial assessment of damages is per se a breach of natural
justice; but it is a breach where the foreign legal system contains provision for judicial assessment and the
judgment debtor therefore has a reasonable expectation that there will be a judicial assessment.” (§§ 14-163 to
165, footnotes omitted)

95. Mr Haigh submits that:


-----

Haigh and others

he was deprived of legal representation;

he was unable to participate in the proceedings before the DIFC Court and the hearing; and

he was medically unable to participate in those proceedings.

As to the first point (legal representation), Mr Haigh's access to funds was curtailed by freezing orders made by the
DIFC Court on 3 June 2014 and by this court on 13 August 2014 and 5 December 2014, and by a proprietary
injunction made by this court on 22 June 2017. On 11 April 2018, Bryan J refused Mr Haigh's application to sell
assets to fund legal representation at trial.

However, there is no automatic right to legal representation, and the evidence suggests that Mr Haigh has been
able to secure the services of lawyers at times. He was, for example, legally represented by leading counsel and
solicitors throughout the judicial review proceedings forming part of the background to the present application.
Justice Sir Jeremy Cooke, when declining to adjourn the trial before him, stated “When Mr. Haigh wishes to, he is
_able to find lawyers to represent him. When he does not wish to, he puts himself forward as a litigant in person who_
_is disabled and unable to present a case to Court” (Schedule of Reasons dated 2 July 2018, § 20)._

96. In an order of 11 July 2018 Bryan J noted that Mr Haigh had not fully complied with his previous order,
had not provided proof of certain asserted liabilities, and had not produced evidence in rebuttal of alleged
potential sources of income. GFH points out that Mr Haigh has given no disclosure of his earnings from
the Lamorna apartments and never explained remarks made by his then Leading Counsel on 28 April 2017
that Trevorian Farm could be bought by his parents for £500,000 to assist in funding the litigation.

In any event, the DIFC Court concluded – as had this court at the hearing before Phillips J on 28 April 2017 – that
Mr. Haigh is capable of representing himself: “As shown by his participation in the Court of Appeal, however, he has
_the ability to make such presentation as he wishes, he is a qualified solicitor, he is familiar with all the issues which_
_arise in the present matter which have been the subject of any number of applications over a period of some four_
_years” (Schedule of Reasons dated 2 July 2018, § 20). Those comments are borne out by Mr Haigh's detailed and_
articulate submissions before me.

97. As to the second point (inability to participate in DIFC trial), Mr Haigh was clearly able to contact the
DIFC Court by email on 2 July 2018, and the court had by its order of 7 June 2018 given permission to Mr
Haigh to attend the trial by Skype for Business, telephone or video conferencing. Justice Sir Jeremy
Cooke said at the outset of the DIFC Judgment:

“1. This litigation has a protracted procedural history, the details of which appear in Appendix 1 to this Judgment.
The Defendant, who has throughout the proceedings failed to comply with orders of the Court and sought to adjourn
hearings, did not appear at the trial, did not give disclosure of documents and did not put in any evidence. As had
occurred on previous occasions with interlocutory hearings, he also requested an adjournment of the hearing at the
last moment and made an application to do so on the second morning of the trial. He produced no contemporary
medical evidence of unfitness to attend despite it being made plain in previous pronouncements of the Court in
orders and directions that this would be required for any adjournment to be considered on such grounds.

2. On 9 June 2018 the Defendant was, in accordance with the Court's previously expressed statements, offered the
option of appearing in court in person, or if that was not possible because of immigration or other issues, of
appearing by video conference call, skype or telephone. He had appeared by telephone in the Court of Appeal
hearing last year. He chose not to avail himself of any of these options.

3. Following various exchanges of emails in which the Defendant claimed, contrary to all the evidence, that he had
not received various orders made by the Court nor documents from the Claimant and the failure of his last minute
email request for an adjournment, the Court, at his request, attempted to contact the Defendant by telephone on the
number given by him but received on three occasions, following two rings of the ordinary ringing tone a tone which
ordinarily signals that the number is not an accessible number or is otherwise unobtainable. Further emails
followed. This was followed by an application for an adjournment made on the proper form (but without paying fees)


-----

Haigh and others

sent by email with supporting witness statements. That was refused for reasons given separately. The Court had
made it plain and has continued to make it plain that the Defendant could participate in the trial by telephone or
other means, should he wish to do so. The Court was not however prepared to adjourn the hearing on the basis of
unsubstantiated assertions of illness and hospitalisation without proper medical evidence. In consequence the trial
took place in his absence with Counsel for the Claimant accepting the responsibility owed to the Court of explaining
the points which it would have been open for the Defendant properly to take by way of defence and drawing
attention to the points he had previously taken in witness statements and affidavits filed in interlocutory proceedings
and in the Defence and Amended Defence and Counterclaim.

4. The Court is entirely satisfied that the Defendant has had full and proper notice of these proceedings, has been
served with the Court's orders and all the trial documents. He has chosen not to appear by any of the means
offered and has over the period since the decision of the Court of Appeal following the hearing last year, ignored
Court orders and chosen not to produce any evidence which could properly support an application for, or justify, an
adjournment of the trial. He has had every opportunity to present his case and has elected not to do so.

5. During the course of these proceedings and in particular in the first 6 months thereof following the grant of a
freezing injunction on 3 June 2014, the Defendant was represented by no less than 4 firms of solicitors and two
leading counsel, who acted for him in seeking variations of the freezing order. He has instructed accountants and
received a report and advice from them. When the English proceedings are taken into account, the total number of
lawyers and accountants instructed exceeds those figures. Whilst seeking to enunciate some form of defence in
both jurisdictions, no-one has ever come forward with a coherent explanation for the fact that large sums of money
found their way into the bank accounts of the Defendant and that false invoices were created with payment
instructions which disguised the receipt of those sums by the Defendant. If there was any real defence to the claim,
it would have been put long since and the Defendant would be able, with or without lawyers, to put it now. Instead
he has embarked on a series of delaying tactics and made extravagant allegations against the Claimant.

6. Notwithstanding constant complaints about unavailability of documentation, the Defendant has, as the evidence
shows and his current solicitors in February 2015 stated, access to a computer outside Dubai containing documents
upon which he has been able to draw. He has not been slow to put forward documents which are said to support
his position and drafts of supposedly agreed contracts.

7. The Court, bearing in mind the seriousness of the allegations made, is satisfied on the evidence that the
Defendant is a fraudster who caused to be paid into his own bank accounts and that of his close friend, monies
belonging to the Claimant in the sums of £2,039,793.70, AED8,735,340 and US$50,000. Moreover, his conduct
throughout these proceedings has been entirely consistent with that finding, in seeking to delay matters, in failing to
give disclosure and in seeking to manipulate or play fast and loose with the court's procedures. This course of
conduct is evident from previous judgments given by judges of this court and from the procedural history set out in
Appendix 1.

8. The Court heard evidence from Mr Jinesh Patel, the former Senior Executive Officer of the Claimant appointed
just over a month before the resignation of the Defendant from his position as Deputy Chief Executive Officer on
March 14 2014. It also received in evidence affidavits and witness statements, as appears hereafter, and
extensively examined the documents, invoices, bank statements and accounting information in the trial bundles. It
has borne in mind the statements made by the Defendant and witness statements produced by him for the Court of
Appeal hearing even though not put in evidence at the trial. It has taken account of every explanation the
Defendant has offered in the course of these proceedings for the fact that so much of the Claimant's money was
transferred to his bank accounts.”

98. At the hearing before me, Mr Haigh alleged that his calls to the DIFC Court had been blocked, and as
a result he was unable to take part in the trial. In his 22nd witness statement, Mr Haigh recounted various
difficulties he said he had had in communicating with the DIFC Court in relation to his appeal between
August 2018 and October 2019, including emails apparently not received and difficulties logging in to the
E-registry until he set up a new account masking his name and IP address. However, he made no


-----

Haigh and others

suggestion in that witness statement, or his 23rd, 24th, 25th or 26th witness statements, that his attempts
to take part in the DIFC trial had been blocked.

99. As noted in § 94 above, after the hearing before me on 14 February 2020 the parties submitted (with
my permission) further materials relating to the difficulties Mr Haigh alleges he had encountered in
communicating by telephone with the DIFC Court on or around the time of the DIFC trial on 1-4 July 2018.
The parties submitted copies of emails between Mr Haigh and the DIFC Court from 28 June 2018 onwards
on this topic. In summary these indicate the following:

i) On 27 June 2018 Mr Haigh wrote a letter to the DIFC court complaining _inter alia_ that the court had
failed to telephone him for the progress monitoring hearing on 7 June 2018. Mr Haigh stated that he
wished to attend the trial in person, but had “some questions and requirements for reassurances before I
_fly”. Among other things Mr Haigh requested (a) confirmation that he would be able to enter and leave the_
UAE, and that there was no warrant out for his arrest, (b)“a pardon from the ruler of Dubai for acts in
_relation to my work for Princess Latifa … and his undertaking that I will be entitled to enter and leave the_
_country”; (c) the cost of a business class ticket and hotel accommodation (or permission to use his frozen_
funds to pay for them), (d) information about the appointment and activities of DIFC judges including
whether Justice Sir Jeremy Cooke or other judges had _“raised the illegal kidnapping and torture by the_
_ruler of Princess Latifa with the ruler or any other party since my reporting o[f] it, if not why not” and (e) the_
answer to the question “Where is Princess Latifa and is she alive or was she murdered by or on instruction
_of the ruler”. Mr Haigh also asked a series of questions about the alleged blocking of his email and other_
attempted communications with the DIFC Court.

ii) The DIFC sent a response the same day with the approval of the trial judge. Among other things the
response stated:

“2.  The Court has made every effort to contact you at every stage of this litigation to ensure that you are able to
participate in the litigation in which you are a party, taking account of both the evidence about, and your own
statements about, effective means of communication with you, in the interests of justice between the parties.

3.  You were not locked out of the Registry system as has been made plain to you in protracted correspondence
with you.

4.  The demands and questions in your letter are misplaced … It is not for the Court to respond to such demands
or questions.

5.  The DIFC Court is an independent Court with statutory jurisdiction. It cannot secure your attendance at the trial
fixed for 1 July and has no powers whether in relation to immigration matters or criminal matters in Dubai or the
UAE.

6.  You have been given the option of attending the trial in person at the DIFC Court or if you so wish (or if it is not
possible/practicable for any reason) of attending by video, skype or telephone, as set out in the Registry email of 9
June 2018. You attended the Court of Appeal by telephone.”

iii) A few hours later on 28 June 2018, Mr Haigh emailed GFH and the DIFC Court requesting an
adjournment of at least two weeks on the ground that a close friend had just been killed in London in tragic
circumstances and Mr Haigh was _“certainly now in no emotional or mental state to take part in any trial,_
_even if it were fair and I was allowed in the court room – which this is not. I will be travelling to London_
_tomorrow to assist with required arrangements. Whilst I have every expectation your client and the court_
_will carry on I want to give you the option”._

iv) On 30 June/1 July 2018, Mr Haigh sought an adjournment of 6 weeks, stating:

“I have not received a response to my previous letter

Further to my letter of last week seeking an adjournment following a deteriorating mental and physical state
following tragic death of my fe if and harassment of me by the DUbai state, I am being hospitalised in an


-----

Haigh and others

emergency basis. I have written notes and asked a friend to email this after putting it in a letter. Application.
tomorrow I have also asked them to send a letter from the hospital once recived

I will be in hospital for at least 1 to two weeks maybe 1 month. I will know more in Tuesday

I will be allowed no access to emails or persons involved in the harassment and torture of me which
includes the claimant and Dubai state as before. Full copies of previous medical this court has.

I fully anticipate the court to continue whilst I am in hospitals which is a result of the Dubai state and
claimants illegal acts. Not least due to my defending the brave Princess Latifa from her murdered of a
father. In whose names your Cour and judges act. All this will be bought to English and European courts

You are requested to adjourn for 6 weeks. Here is no presumed Prejudice in so doing

A fuller letter will be sent by my friend tomorrow.

I will have no email access”

v) The court registry responded that any application for an adjournment must be made formally with
supporting evidence, otherwise the court would proceed with the hearing _“which has commenced this_
_morning in the absence of attendance by you in any of the ways put forward in this Court's email of 9_
_June.”_

vi) At 10.29 on 1 July 2018, Mr Haigh sent a further email stating:

“As my treatment does not commence until the new week I have been allowed to keep my phone today for a couple
of hours given the distress the court sitting on my case in total violation of the concept of a fair and public hearing
has caused

I have tried to Call the court on my phone this morning but could not get through, I refer to my previous note that the
Dubai state security has banned my number in Dubai and the DIFC courts comedy response stating that the DIFC
court hadn't banned it, implying they know state security has.

I note no attempt was made to contact me on any number to dial me into the court…….. As pre the previous
hearing.

When every attempt is made to contact an involve the Claimant. I note I have been banned from coming to the
Court as well unless I wish to risk torture and inhumane an degrading reatment

1. I have not received a response to my email of last night or to my email of June requested an adjournment
following the tragic death of my gay friend

2. I am equally surprised (although really I'm not Dubai, the court and Cooke are corrupt) the court has sought to :

a. Lock me out the online system so I cannot engage in the court

b. Block and ban my phone numbers from calling Dubai

c. Prevent me from coming to the court, whilst the court invites me, knowing I would be tortured and
possibly murdered.

3. I understood from the latest order of Mr Cooke that GFH had to copy any emails from the Court to me and as
such can only presume there has been no response as no emails have been received

4. I have spoken with my Dr and medical team and they have allowed me a short call today at 11 to 1 UK time. I
may have up to one hour call in that time provided I am monitored, should I become visibly distressed the call will
be terminated. I am on high doses of medication and unable to focus. The court has details of this medication. This
is because my treatment will not commence until tomorrow.

5. I wish to understand why I have even prevented from enegeing in the process, including from discusloe


-----

Haigh and others

6. I have not been served the court bundles in accordance with last order of cooke. I have advised gfh of this. No
response – so even if I were well I could not enege with court

7. As such please there call me without fail during those house. I would propose 12 GMT

8. I wish to cover

a. Preventing me from enegeing in Court process

b. Preventing me from attending court

c. Refusal of court to contact me to dial me into repeated hearing

d. Murder / Kidnap of Sheikh Latifa

e. Illegal acts of Dubai state hacking my computer and records

f. Conflict of Dubai Court

g. Case

i. I wish to cross examine all witnesses of GFH in court and to bring verbal evidence from myself and all my
witnesses

1. Including [followed by a list of 15 named witnesses]

There is no other option for the court given its gross impotence at best and at worse shear corruption to adjourn this

farcical hearing until I am out of hospital

The court is on notice that even engeing in this email is damaging my recory.

My partner has an application to adjourn that they are working on, however it may be better that this is made
verbally by me.”

vii) At 10.59 on 1 July 2018 Mr Haigh sent an email stating _inter alia “I have access to my phone for_
_another hour and am waiting the courts call”._

viii) At 11.23 on 1 July 2018 the court registry emailed Mr Haigh stating that the court had attempted to
telephone him three times on the number he had provided, but had been unable to get through, adding:
_“The phone has rung twice on each occasion, before the Court then heard a tone indicating that the_
_number is unobtainable. Should you wish to participate in this trial, please call the Court on [number_
_stated]. Should you wish to make an application to adjourn the trial, please file this at once, supported by_
_evidence.”_

ix) Mr Haigh replied that his phone was working perfectly well and he had tested it three times. He added
_“It is noted that you waited until the end of my period to say this and only after I had reminded you. I will_
_ask the dr for a further period later today or tomorrow morning before treatment commences.”_

x) The court registry at 12.29 on 1 July 2018 indicated that the court was continuing with the hearing and
repeated the number Mr Haigh should call. The email added “Should you wish to make an application to
_adjourn the trial, please file this at once, supported by evidence. The Court will not be ringing you again.”_

xi) At 1.05am on 2 July 2018 four emails were sent on Mr Haigh's behalf, which included the following
message:

“This email is sent on behalf of David Haigh by way of service on the Claimant and the Court. Please acknowledge
safe receipt

I understand that David indicated this would come today.


-----

Haigh and others

Please find attached:

1. Application notice

2. Witness statement David Haigh and DH 20

3. Witness statement Herve Jaubert

4. Draft Order

David will be allowed to speak with the court from 11 GMT till 12 GMT tomorrow Monday and only that time by his
medical team. David has asked me to inform the court that all of his numbers are working. We have video of these
numbers working.

We have equally videoed Davids number calling the court and been unable to connect. This was set out by David
on various occasions and it is noted that the DIF Court has not confirmed the the Dubai site has not blocked such
numbers. The same is the case for the published number of Radha Stirling. Both David and Radha are working
against the UAE and the Dubai Ruler for their torture and kidnap of HRH Sheikh Latifa - who has publicly accused
Sheikh Mohamed of murder. The UAE and Dubai state have commenced a campaign of intimidation against Radha
and David.

Further David has indicated that even if he could connect to the court, he does not have the funds to pay for an
intentional call of any length and it is unreasonable and unjust to expect him to do so given the lack of fund is the
actions of the court and the Claimant.

David will have no access to email or his phone at any other time.

David reiterates that he wishes to attend court in person when he is released from hospital and renege fully in the
court process

David has sent these in hard copy as he has previously been locked out of the online system and despite reputed
rests and email for the registry saying they have done so he has not removed a new password.”

An email sent on Mr Haigh's behalf at 2.52am on 2 July 2018 repeated the suggestion that “clearly the DIFC Court
_has been barred from calling Davids number and vice versa”._

100. Thus Mr Haigh's position was that calls to his phone were being blocked, but in any event he could
not participate by phone for more than an hour. Reference was made in the email quoted at (xi) above to
video evidence of Mr Haigh attempting unsuccessfully to call the DIFC Court, though no such evidence
was adduced on the present application.

101. Justice Sir Jeremy Cooke gave immediate consideration to Mr Haigh's 2 July application to adjourn,
hearing counsel and issuing an Order with Reasons the same day. The order recited _inter alia_ that Mr
Haigh had _“communicated with the Court from multiple email addresses during the currency of the_
_proceedings”. The judge's 27-paragraph Schedule of Reasons, in addition to containing the observations_
quoted in §§ 115 and 117, addressed Mr Haigh's allegation of call blocking:

“1.This Court has received overnight and early this morning about 4 emails coming from Mr. Haigh's email address
at dhaighlegal@gmail.com. Those emails all have the sender as a Mr. L Lopez. The first of such email timed at
5:25am this morning, the beginning of words “this message bounced back so sending in four emails“. The email
was said to be sent on behalf of Mr Haigh quote by way of service on the Claimant and the Court, and attached the
application notice and a draft order. It also says that Mr. Haigh would be allowed to speak to the Court on 11 GMT
until 12 GMT on Monday, that is today.

2.A second email said to be two of four came in exactly the same terms as the first other than that numbering, also
sent at 5:28 am containing Mr. Haigh's witness statement and an exhibit to it which is a redacted letter dated the 4


-----

Haigh and others

of April 2018 of a Dr Muller- Pollard. The Witness statement was dated the 30 of June 2018 and throughout to some
49 pages and is apparently signed by Mr. Haigh.

3.The third email of 5:29am in identical terms save it was said to be 3/3 was accompanied by a witness statement
of a Mr. Herve Jaubert also dated 30th of June 2018 signed by him.

4.A fourth email timed at 5:52am refers to an early email sent to the Registry in relation to the application to adjourn
and asserted that DIFC Courts had been by calling Mr Haigh's number and vice versa.

5.All of this has to be seen in the context of the prior history of this matter. In particular, following the production of a
draft amended defence of the counterclaim which is the subject of this Court's consideration in some time ago, the
Defendant, Mr. Haigh, has failed to engage with the Court in any way until the 28 of June, the last business for a
date fixed for trial of which Mr Haigh was well aware, and Mr. Haigh had chosen to claim no task In the proceedings
in terms of providing disclosure, in terms of providing any witness statements, of submitting hearsay notices or
doing anything to indicate that he would participate in the trial process.

6.The reality of the matter is, as submitted by Mr Bodnar, is that Mr Haigh only engages with proceedings when he
wishes to do so and as the matter of almost invariable practice seeks adjournments of hearings rather interlocutory
hearing or other hearings at the last moment.

7.There is only one conceivable basis on which this Court could consider and grant an adjournment of the hearing
which has now been proceeding for a day in this Court and that would be on the basis of genuine medical unfitness
to attend the hearing.

8.The Court has gone out of its way in the past to seek to pursue the attendance of Mr. Haigh at this hearing
whether in any way which he chose, he could come personally to this Court if he were able to do so, though this
Court has no control of the immigration processes of Dubai or the UAE.

9.Bearing that in mind, the Court was willing to facilitate attendance by Mr. Haigh by Video Conference, by Skype or
by telephone. It is noteworthy that Mr. Haigh did attend the Court of Appeal hearing last year by telephone and was
able to participate in the hearing in that way and to make such submissions as he wished to make, despite
protestations to the country in the latest witness statement that had just been received from him.”

102. The judge noted Mr Haigh's propensity _“to put forward medical grounds or seeking adjournment_
_without any adequate medical evidence to support the assertions which he makes as to his incapacity or_
_inability to attend and participate in the proceedings”, and proceeded to analyse the latest evidence Mr_
Haigh had submitted. The judge concluded that it did not support the suggestion that Mr Haigh was
subject to emergency hospitalisation, nor show any grave medical condition such as would justify
adjournment; rather, the application was “again a late attempt to derail the proceedings …”. The judge was
also satisfied that Mr Haigh had received all the trial documents in hard copy and had full notice of all the
material presented. Further:

IMAGE NOT AVAILABLE

“ I am also satisfied because I am told I will be shortly receiving a witness statement to this effect that Mr. Haigh has
received all the trial documents in hard copy and he has had full notice of the proceedings and all the material
which has been presented in these proceedings.” (§ 24)

103. Mr Haigh's assertions about the blocking of calls between his phone and the DIFC Court were and
are unsupported by any independent verification, and Sir Jeremy Cooke rejected them as being simply part
and parcel of Mr Haigh's repeated history of attempts to derail the proceedings on spurious grounds,
including but not limited to spurious medical grounds. Before me (including in his 27th witness statement
filed on 19 February 2020), Mr Haigh has produced no new evidence but has simply repeated the same
allegations and produced copies of his previous communications. I see no reason why this court would
reach any different conclusion on the matter from that reached by Sir Jeremy Cooke, and I consider there


-----

Haigh and others

to be no realistic prospect of Mr Haigh establishing at trial that the DIFC trial took place in breach of the
principles of natural justice by reason of blocking of telephone calls.

104. Finally, as regards Mr Haigh's alleged medical problems, I have already noted that Justice Sir Jeremy
Cooke gave full consideration in his 2 July 2018 reasoned order to the medical evidence Mr Haigh put
forward in support of an adjournment of the DIFC trial. In the light of the history of the matter, the judge
stated “The Court is unable to take Mr. Haigh's say-so as representing the true situation. It needs medical
_evidence from qualified practitioners that set out the inability of Mr. Haigh to participate in the trial, if it is to_
_act on it. That has not been forthcoming.” The judge considered in detail, in §§ 10-19 of his Schedule of_
Reasons, whether Mr Haigh was unable to participate in the trial on medical grounds, concluding that Mr
Haigh's evidence was entirely unsatisfactory and there appeared to be no question of emergency
hospitalisation at all. Nothing in the evidence before me creates any arguable case that this court would
conclude that the DIFC trial, or the decision not to adjourn it, could properly be impugned on the ground
that Mr Haigh was medically unfit to participate in it.

105. In overall conclusion on these issues, I am satisfied that there is no realistic prospect of the DIFC
Judgment being impugned on public policy grounds.

(F) MR HAIGH'S DEFENCE AND COUNTERCLAIM

GFH submits that Mr Haigh's Defence and Counterclaim should be struck out on the grounds that (a) the
arguments it raises are precluded by cause of action and/or issue estoppel in the light of the DIFC Judgment; (b) it
raises matters which are in reality no more than an improper re-examination of the merits of the DIFC Judgment;
and/or (c) it represents an abuse of process by reason of factors (a) and/or (b).

106. A foreign judgment that is final and conclusive on the merits in favour of the defendant is at common
law a good defence to a claim in England for the same matter, regardless of which proceedings were
commenced first; there is no cause of action estoppel against a different remedy, although there may be an
issue estoppel if a relevant issue has been decided directly in the foreign action (see Dicey § 14-031).

107. A foreign judgment can give rise to an issue estoppel, preventing a party from denying any matter of
fact or law necessarily decided by the foreign court (see Carl Zeiss Stiftung v Rayner & Keeler Ltd (No.2)

[1967] 1 A.C. 853, 917, 925 and 967). Dicey § 14-032 sets out the requirements for issue estoppel:

the foreign judgment must be:

of a court of competent jurisdiction in relation to the party who is to be estopped;

final and conclusive; and

on the merits, i.e. a decision which establishes certain facts as proved or not in dispute, states what are the relevant
principles of law applicable to such facts, and expresses a conclusion with regard to the effect of applying those
principles to the factual situation concerned (DSV Silo und Verwaltungsgesellschaft mbH v Owners of the Sennar
_(The Sennar) (No.2) [1985] 1 W.L.R. 490, 499F-G per Lord Brandon);_

the parties to the English litigation must be the same parties (or their privies) as in the foreign litigation;

the issues raised must be identical; and

the decision on the relevant issue must have been necessary for the decision of the foreign court and not merely
[collateral (Good Challenger Navegante SA v Mineralexportimport SA [2003] EWCA Civ 1668, per Clarke LJ at §72).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTT1-DYBP-N4S3-00000-00&context=1519360)

108. Issue estoppel can arise from an interlocutory judgment of a foreign court, even a judgment on a
procedural (i.e. non-substantive) issue, if a specific issue of fact is raised before and decided finally by the
court (Desert Sun Loan Corp v Hill [1996] 2 All E.R. 847, 858-859 per Evans LJ). It follows, as GFH
submits, that issue estoppel can therefore arise not only from the DIFC Judgment but also from the
January 2018 Order with Reasons


-----

Haigh and others

109. Leaving aside the issues already addressed in this judgment, all the remaining contents of Mr Haigh's
Defence and Counterclaim before this court have in substance been raised before the DIFC Court and
rejected.

i) Mr Haigh's claims for commission and/or referral fees and/or for breach of his contract of employment,
save insofar as the latter related to his allegations of fabrication of evidence/luring him to Dubai, were
considered and rejected in §§ 58-73 of the DIFC Judgment.

ii) His claims for breach of his contract of employment, insofar as related to his allegations of fabrication of
evidence/luring him to Dubai, were struck out by Justice Sir Jeremy Cooke for the reasons given in the
January 2018 Order with Reasons.

iii) Mr Haigh's deceit and conspiracy allegations relating to luring him to Dubai (Defence and Counterclaim
§§ 159-208) were struck out by Justice Sir Jeremy Cooke as having no realistic prospect of success for the
reasons given in §§ 128-142 of the January 2018 Order with Reasons.

iv) His allegations of malicious prosecution, false imprisonment and conspiracy to injure in respect of the
Twitter charges (Defence and Counterclaim §§ 209-226) were struck out by Justice Sir Jeremy Cooke as
having no realistic prospect of success for the reasons given in §§ 108-118, 101-107 and 143-146
respectively of the January 2018 Order with Reasons.

110. There is no arguable basis on which either the DIFC Judgment or the January 2018 Order with
Reasons can properly be impeached. Accordingly, the pursuit of these defences and counterclaims in this
court is precluded by the principles of cause of action (insofar as Mr Haigh relies on them as a
counterclaim) and issue estoppel. It is also an abuse of process for him to seek to relitigate these matters
in the present proceedings.

111. I should add that I have, in this context, also had regard to the contents of the proposed Amended
Defence and Counterclaim exhibited to Mr Haigh's 23rd witness statement. Nothing in the contents of that
document alters the conclusions I set out above, and in the light of my overall conclusions I do not believe
any purpose would be served by considering whether or not permission to amend should be granted (if and
to the extent that Mr Haigh is to be taken as having sought it).

112. As a result, these parts of Mr Haigh's Defence and Counterclaim should be struck out. In any event,
none of them provides any basis on which the DIFC Judgment should not be enforced.

(G) GFH'S PROPRIETARY CLAIMS AGAINST THE FIRST, SECOND, THIRD, FIFTH AND SIXTH DEFENDANTS

(1) The DIFC Judgment

113. GFH's Particulars of Claim in the DIFC proceedings alleged inter alia that Mr Haigh “owed fiduciary
_duties to [GFH] to act at all times in the best interests of and honestly towards [GFH]”. That allegation was_
admitted in § 21 of Mr Haigh's Amended Defence and Counterclaim in the DIFC proceedings. In the DIFC
Judgment, Justice Sir Jeremy Cooke stated:

“What emerges from the evidence is a clear picture of the Defendant procuring payments of the Claimant's funds to
himself or to his order with the creation of false invoices in an attempt to conceal the reality of his defalcations.
Despite a number of risible explanations, there is no gainsaying the fact that money belonging to the Claimant
ended up in the bank accounts of the Defendant, who was a senior employee in what he admits was a fiduciary
position. None of the funds have been returned and there is, despite attempts to justify the receipt of funds, no
proper basis for the Defendant having received them or for retaining them.

It is common ground, as shown by the Defence which was drafted by lawyers and the Amended Defence and
Counterclaim which was evidently drafted with the assistance of lawyers, that the Defendant, as Deputy Chief
Executive Officer of the Claimant, owed the Claimant duties as a fiduciary to act at all times in the best interest of
the Clamant, and to act honestly towards the Claimant and that his contract of employment contained implied
terms to the same effect.” (§§ 9 and 10)


-----

Haigh and others

114. The judge referred to the exposition by Lord Neuberger in _FHR European Ventures LLP v Cedar_
_Capital Partners LLC [2015] AC 250§§ 5 ff of well-established principles relating to a fiduciary, including_
the obligations not to make a profit out of the trust imposed in him, not to place himself in a position where
his duty and interest may conflict and, where a benefit is received in breach of fiduciary duty, to account for
such a benefit and to pay, in effect, a sum equal to the profit by way of equitable compensation (DIFC
Judgment § 12).

115. At the end of the DIFC Judgment the judge concluded:

“In these circumstances and for these reasons, [GFH] succeeds in both its claim for the payment of the sums in
question and its claim that, as fiduciary, [Mr Haigh], when receiving such sums himself or for his benefit as
payments to his order, held them on constructive trust for [GFH].” (§ 75)

116. The DIFC Judgment also provided some relevant details of how the misappropriated sums had been
used:

“56. In that witness statement [the third witness statement of Mr Patel] the following (inter alia) is evidenced, in
addition to matters to which I have already referred:

a. The Defendant had no significant sources of income apart from what came from the Claimant by way of salary
and defalcation.

b. Just over 88% of the funds deposited between December 2012 and January 2014 in the Defendant's HSBC
Dubai accounts (approximately AED 9,696,341) can be attributed to fraudulent invoices and a figure corresponding
to that total (within AED 75,000) was transferred to the Defendant's HSBC UK accounts or paid to Lincoln
Associates.

c. 23 transfers were made from the Defendant's Co-Op accounts in the UK to his HSBC UK accounts totalling
£1,686,926.55, representing over 80% of the total funds paid into the Co-Op accounts which were supposedly
supported by false invoices from GPW and false fee notes from FCC.

d. Large amounts of the funds paid to the Defendant and attributable to the fraudulent invoices were used by the
Defendant to:

…

ii. Acquire and refurbish real estate in Cornwall, UK using the services of solicitors Chan Neill.

…

i. The use to which the money was put can be summarised as follows:

…

ii. £1,600,000 was transferred to Chan Neill Solicitors

…

vii. £54,000 was transferred to the Defendant's sister and brother-in-law to fund building work, which is
obviously connected to the Cornish properties purchased through Chan Neill.

…”

(2) GFH's proprietary claims

GFH makes proprietary claims in relation to:

Trevorian Farm, a freehold farmhouse with land outside Penzance whose full address is Trevorian Farm, Sancreed,
Penzance, Cornwall TR20 8RP. It is registered under title number CL303990 in the name of Mr Haigh. The Land


-----

Haigh and others

Registry records that Mr Haigh purchased the property on or about 20 December 2013 for a stated price of
£598,000.

The freehold and leases of several of the Lamorna apartments.

The amount of £980,000 paid on behalf of Leeds United Football Club to the client account of Guise Solicitors for
the benefit of the Seventh Defendant.

GFH's Re-Amended Particulars of Claim seek the following declarations in relation to those proprietary claims:

against Mr Haigh, declarations that he holds:

Trevorian Farm on constructive trust for GFH;

his interest in the assets of the Second to Seventh Defendants on constructive trust for GFH, and

his interest in the Second to Seventh Defendants on constructive trust for GFH;

against the Second Defendant, a declaration that it holds the freehold of The Cove on constructive trust for GFH;

against the Third Defendant, a declaration that it holds Apartments 1 and 2 of The Cove on constructive trust for
GFH;

against the Fourth Defendant, a declaration that it holds Apartment 7 of The Cove on constructive trust for GFH;

against the Fifth Defendant, a declaration that it holds Apartments 9 and 12 of The Cove on constructive trust for
GFH;

against the Sixth Defendant, a declaration that it holds Apartments 14 and 15 of The Cove on constructive trust for
GFH;

against the Seventh Defendant, a declaration that it holds the sum of £980,000 on constructive trust for GFH; and

against the Eight Defendant, a declaration that she holds Apartments 4 and 5 of The Cove on constructive trust for
GFH.

As noted earlier, GFH does not pursue its claims against the Fourth and Seventh Defendants in the present
application. The Eighth Defendant, in her Amended Defence, notes the judgment of the DIFC Court, states that she
_“feels uncomfortable with retaining any property that may be an indirect product of the conduct described therein”_
and agrees, subject to any other order by the court, to transfer her entire interest in Apartments 4 and 5 of The
Cove to GFH.

The basis for the declarations sought is set out in detail in GFH's Re-Amended Particulars of Claim and the third
witness statement of Mr Patel, which in summary provide evidence that (so far as relevant to the applications
currently pursued):

Mr Haigh purchased Trevorian Farm for £598,000 with title registered in his name in or about December 2013;

Mr Haigh purchased Apartments 4 and 5 of the Cove, and on 4 August 2013 transferred title in those apartments to
his sister, the Eighth Defendant;

Mr Haigh made loans to the Second, Third, Fifth and Sixth Defendants for the purposes of acquiring Apartments 1,
2, 9, 12, 14 and 15 of The Cove; and

in each of those case, those purchases, loans and/or advances were made by Mr Haigh with funds misappropriated
from GFH as described in the DIFC Judgment.


-----

Haigh and others

GFH submits that the Second, Third, Fifth and Sixth Defendants are bound by the conclusions of the DIFC
Judgment as Mr Haigh's privies, alternatively that they have no arguable defence to GFH's claim against them in
any event.

(3) Legal principles: constructive trust

Breach of fiduciary duty is a pre-requisite to equitable tracing: Agip (Africa) Ltd v Jackson [1991] Ch 547per Fox LJ
at p566G-H.

As noted in the DIFC Judgment, Lord Neuberger in _FHR European Ventures LLP v Cedar Capital Partners LLC_

[2015] AC 250§§ 5-8 stated inter alia the principles that an agent must not make a profit out of his trust; that where
an agent receives a benefit in breach of his fiduciary duty, the agent is obliged to account to the principal for such a
benefit, and to pay, in effect, a sum equal to the profit by way of equitable compensation (citing Regal (Hastings)
_Ltd v Gulliver (Note) [1967] 2 AC 134, 144–145 per Lord Russell of Killowen); and that the principal's right to seek_
an account of profits gives it a right to equitable compensation, which is the quantum of that benefit (subject to any
permissible deduction in favour of the agent—e.g. for expenses incurred). Where the facts of a particular case are
within the ambit of the rule, it is strictly applied: Keech v Sandford (1726) Sel Cas Ch 61.

A person who has been defrauded may trace property into the hands of the recipient; stolen monies are traceable in
equity as they are held by the thief under a constructive trust: Westdeutsche Landesbank Girozentrale v Islington
_London Borough Council [1996] A.C. 669(confirmed in Commerzbank v. IMB Morgan [2004] EWHC 2771 (Ch) per_
Lawrence Collins J at § 36 and Bank of Ireland v Pexxnet Ltd _[2010] EWHC 1872 (Comm) per Jonathan Hirst QC at_
§§ 55-57). Lord Browne-Wilkinson said in Westdeutsche:

“I agree that the stolen moneys are traceable in equity. But the proprietary interest which equity is enforcing in such
circumstances arises under a constructive, not a resulting, trust. Although it is difficult to find clear authority for the
proposition, when property is obtained by fraud equity imposes a constructive trust on the fraudulent recipient: the
property is recoverable and traceable in equity. Thus, an infant who has obtained property by fraud is bound in
equity to restore it: Stocks v. Wilson _[[1913] 2 K.B. 235, 244; R. Leslie Ltd. v. Sheill](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5CXX-0W21-DYHY-B1RV-00000-00&context=1519360)_ _[[1914] 3 K.B. 607. Moneys](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDM0-TWXJ-20JK-00000-00&context=1519360)_
stolen from a bank account can be traced in equity: Bankers D Trust Co. v. Shapiro [1980] 1 W.L.R. 1274, 1282CE: see also McCormick v. Grogan (1869) L.R. 4 H.L. 82, 97.” (p.715C-D)

The principal has a claim “to follow his property rights”, as described by Lord Millett in Foskett v McKeown [2001] 1
AC 102at p.129 F-G:

“… a plaintiff who brings an action like the present must show that the defendant is in receipt of property which
belongs beneficially to him or its traceable proceeds, but he need not show that the defendant has been enriched
by its receipt. He may, for example, have paid full value for the property, but he is still required to disgorge it if he
received it with notice of the plaintiff's interest.

… An action like the present is subject to the bona fide purchaser for value defence, which operates to clear the
defendant's title.”

_Foskett was:_

“… a straightforward case of a trustee who wrongfully misappropriated trust money, mixed it with his own, and used
it to pay for an asset for the benefit of his children. Even on the traditional approach, the equitable tracing rules are
available to the plaintiffs.” (p.129 B-C)

(4) Legal principles: privity

117. In order to establish privity of interest in respect of a prior judgment, it is necessary to show more
than that the alleged privy had “some interest in the outcome of litigation”: see Gleeson v Wippell & Co Ltd

[1977] 1 WLR 510, 515 per Megarry V-C. Megarry V-C in that case said:


-----

Haigh and others

“… it seems to me that the substratum of the doctrine is that a man ought not to be allowed to litigate a second time
what has already been decided between himself and the other party to the litigation. This is in the interest both of
the successful party and of the public. But I cannot see that this provides any basis for a successful defendant to
say that the successful defence is a bar to the plaintiff suing some third party, or for that third party to say that the
successful defence prevents the plaintiff from suing him, unless there is a sufficient degree of identity between the
successful defendant and the third party. I do not say that one must be the alter ego of the other: but it does seem
to me that, having due regard to the subject matter of the dispute, there must be a sufficient degree of identification
between the two to make it just to hold that the decision to which one was party should be binding in proceedings to
which the other is party. It is in that sense that I would regard the phrase 'privity of interest'. Thus in relation to trust
property I think there will normally be a sufficient privity between the trustees and their beneficiaries to make a
decision that is binding on the trustees also binding on the beneficiaries, and vice versa.” (p515)

That formulation was approved by Lord Bingham in Johnson v Gore Wood & Co [2002] 2 AC 1, 32.

118. In Resolution Chemicals v Lundbeck A/S [2013] EWCA Civ 924, Floyd LJ said:

“29. It can be seen that Sir Robert Megarry's test: “having due regard to the subject matter of the dispute, there
_must be a sufficient degree of identification between the two” embraces two concepts. The first is concerned with_
the interest which the subsequent litigant …has in the subject matter of the first action. In _Gleeson, Wippell was_
very interested, in one sense, in the subject matter of the action against Denne, as its design of shirt was impugned
in that action. But that was not a sufficient interest in circumstances where there was what Sir Robert Megarry
described as “a trade relationship between the two, in the course of which Denne, at Wippell's request, copied a
_Wippell shirt: but that is all”. The second concept concerns the identity of the parties. Thus in Zeiss No 2 [1967] 1_
AC 853at pages 911–2 Lord Reid suggested:

“A party against whom a previous decision was pronounced may employ a servant or engage a third party
to do something which infringes the right established in the earlier litigation and so raise the whole matter
again in his interest. Then, if the other party to the earlier litigation brings an action against the servant or
agent, the real defendant could be said to be the employer, who alone has the real interest, and it might
well be thought unjust if he could vex his opponent by relitigating the original question by means of the
device of putting forward his servant.”

30. In this example the new party has no interest in the previous litigation, but would be estopped because, in
effect, he represents the party in the first action. That party has the identical interest in the previous action. In
_Gleeson, there was no identity of parties in this sense._

31. It is not necessary for the purposes of this appeal to seek to define precisely what interest in the subject matter
of the previous litigation is required. The sort of interest dismissed by Sir Robert Megarry in _Gleeson in his first_
principle is clearly inadequate. ... At one level Arrow and Resolution had the same legal interest in the revocation of
the Patent, but that was a legal interest which they shared with all the world. If Resolution is to be bound, it must I
think be possible to identify some more concrete consequence for its business which revocation of the Patent would
have achieved. Unless that is so, although it can be said that Resolution could have joined the 2005 proceedings,
there is no reason to hold that they should.

32. Drawing this together, in my judgment a court which has the task of assessing whether there is privity of
interest between a new party and a party to previous proceedings needs to examine (a) the extent to which the new
party had an interest in the subject matter of the previous action; (b) the extent to which the new party can be said
to be, in reality, the party to the original proceedings by reason of his relationship with that party, and (c) against this
background to ask whether it is just that the new party should be bound by the outcome of the previous litigation.”

119. Floyd LJ went on to refer to _Johnson v Gore Wood, where the majority of the House of Lords_
considered (albeit it appears the point had been conceded: see p60D per Lord Millett) that there was privity
of interest where:


-----

Haigh and others

“… WWH was the corporate embodiment of Mr Johnson. He made decisions and gave instructions on its behalf. If
he had wished to include his personal claim in the company's action, or to issue proceedings in tandem with those
of the company, he had power to do so....”

120. In Standard Chartered Bank (Hong Kong) Ltd v Independent Power Tanzania Ltd _[2016] EWCA Civ_
_411 the Court of Appeal held that subsidiary companies (SCBHK and SCBMB) were not estopped from_
bringing English proceedings by their parent company SCB's acceptance, in proceedings in New York, that
Tanzania was the most appropriate forum. The court made the point, in particular, that a “general
_commercial interest in the litigation” was:_

IMAGE NOT AVAILABLE

“… not enough to show that SCBHK was “in reality party to the proceedings” against their parent company in tort.
As the judge said, that would be a failure to recognise the distinct corporate personalities in the case and lead to a
piercing of the corporate veil contrary to the limited scope ascribed to that doctrine in Prest v Prest [2013] 2 AC 415.
…” (§ 33)

121. It follows that mere ownership of a company does not itself equate to privity of interest. However,
privity may exist where a company is the “corporate embodiment” of an individual, as it was put in Johnson.
_Dadourian Group International Inc v Simms_ _[2006] EWHC 2973 (Ch) § 721 suggests that the matter is_
highly fact dependent.

(5) Application to facts

122. GFH alleges that the Second to Sixth Defendants are each _“vehicles for [Mr Haigh], interposed to_
_conceal the fact that he was the true actor in the purchases of the various properties within The Cove,_
_Cornwall”. Its Re-Amended Particulars of Claim and evidence describe in detail how the properties in_
question, including those registered in the names of and nominally purchased by the Second, Third, Fifth
and Sixth Defendants, were all in reality purchased using funds which Mr Haigh had misappropriated from
GFH.

123. GFH alleges that the directorships of the companies were changed shortly after Mr Haigh's arrest in
Dubai (to the Eighth Defendant in the case of the Second Defendant, and to Mr Haigh's fiduciary services
provider in the case of the Third to Sixth Defendants). GFH does not allege that Mr Haigh himself was a
_de iure director of the companies at the time of the transactions in question, though he is a director now_
and the Defence of the Second to Seventh Defendants is signed by Mr Haigh as their director. Mr Haigh in
his speaking note dated 12 February 2020 referred (in the context of a Part 20 claim which he advances
against the Eighth Defendant) to Apartments 4 and 5 at The Cove as being “key elements to the complex
_run by D2, D3, D4, D5, D6 of which [Mr Haigh] is a director”; and in his 25th witness statement stated that_
_“As the present director for each of those companies and the director of the shareholder I can confirm that_
_each of these Defendants work together on the holiday let apartments …”. Mr Haigh has stated as part of_
his corrections list that he “only became a director when fees to pay the corporate fiduciaries and trustee
_we[re] not available”._

124. The Defence of the Second to Seventh Defendants denies the allegations made, including the
allegation that they are legally or beneficially owned by Mr Haigh. It is also denied that the directorships
were changed as alleged, and it is averred that the directorship of the Second Defendant was changed to
the Eighth Defendant plus two additional directors. However, no positive case on the substantive merits is
advanced save as follows:

“… the First Defendant denies that the Second to Sixth Defendants are vehicle interposed to conceal the fact that
he was “the true actor in the purchase of the various properties within The Cove Cornwall”. It is averred that the
Claimant was fully aware of the involvement of the First Defendant in the Cove, him having repeatedly chased the
Claimant for payment of amounts due to him in salary and commission, the reason for the payment of the disputed
sums, in order that he may provide finance for the acquisition and management services. Further, it is averred that
the First Defendant offered to the Claimant and certain of its senior executives investment. The structure of the


-----

Haigh and others

Second to Sixth Defendants, of which the First Defendant is not the owner was established for clear wealth and
property estate management and acquisition purposes as part of an established trust structure administered by
Swiss regulatory fiduciary service providers and English solicitors.”

125. However, as GFH points out, none of the relevant Defendants has explained why Mr Haigh would
have paid the monies he received for GFH to the benefit of those other Defendants other than if he were
their ultimate beneficial owner, or at least retained a beneficial interest in the funds transferred or their
proceeds. Nor do any of the Second, Third, Fifth or Sixth Defendants make any attempt in their Defence to
counter GFH's analysis of the flow of funds, from sums Mr Haigh wrongfully obtained from GFH through to
the purchase of properties ultimately registered in those Defendants' names. Mr Haigh did not, in his
skeleton argument or speaking note before me, put forward any substantive arguments relating to the
specific positions of the Second, Third, Fifth or Sixth Defendants.

126. In these circumstances, and based on the evidence as a whole, I conclude as follows:

i) The Second, Third, Fifth and Sixth Defendant are to be regarded as corporate embodiments of Mr Haigh
for issue estoppel purposes, and there was a sufficient degree of identification between each of them and
Mr Haigh to make it just to hold that the DIFC Judgment should be binding against them in the present
proceedings.

ii) Even if I am wrong about (i) above, based on the parties' statements of case and other evidence before
me, I consider the Second, Third, Fifth and Sixth Defendants to have no realistic prospect of persuading
this court at trial that the relevant findings in the DIFC Judgment were incorrect in any material respect.

iii) Mr Haigh is liable to account in equity for the sums found in the DIFC Judgment to have been
misappropriated from GFH, and holds those sums, or the assets now representing them (including
Trevorian Farm), on constructive trust for GFH.

iv) Based on the parties' statements of case and other evidence before me, the Second, Third, Fifth and
Sixth Defendants' interests in properties at The Cove were purchased with funds misappropriated from
GFH by Mr Haigh, and those defendants have no bona fide purchase or other defence available to them.
They accordingly hold those interests on constructive trust for GFH.

127. As to whether it also follows that Mr Haigh holds his interests (as a whole) in the Second, Third, Fifth
and Sixth Defendants on constructive trust for GFH, or only part of his interests in those companies, it
appears to me that question may depend on the extent to which the companies held other assets i.e.
assets not purchased with the misappropriated funds: a matter which was not argued before me. I shall
hear further argument from the parties accordingly as to that issue and the appropriate form of relief.

(H) ANY OTHER COMPELLING REASON FOR A TRIAL

I have considered whether Mr Haigh's attempts to appeal from the DIFC Judgment, or any other features of this
case, provide either a compelling reason why this case should proceed to trial, or a reason for a stay of execution of
any judgment.

On the question of appeal, some assistance by way of analogy can be obtained from considering the usual
approach to whether an English judgment should be stayed pending appeal. A stay of an English judgment is at
least in practice the exception rather than the rule. As summarised in White Book (Vol 1), note 52.16.3, in Leicester
_Circuits Ltd v Coates Brothers plc_ _[[2002] EWCA Civ 474 §§ 12 and 13 the Court of Appeal stated that, while the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66S0-JGY3-CGX8-01XY-00000-00&context=1519360)_
general rule is that a stay of judgment will not be granted, (1) the court has an unfettered discretion, (2) no authority
can lay down rules for its exercise, (3) the proper approach is to make the order which best accords with the
interests of justice, (4) the court has to balance the alternatives to decide which is less likely to cause injustice, and
(5) where the justice of letting the general rule take effect is in doubt, the answer may well depend on the perceived
strength of the appeal. The Court added that it is relevant that the appellant may be unable to recover from the
respondent the sum awarded in the event of judgment being set aside on appeal. In Department for Environment,
_Food and Rural Affairs v Downs_ _[[2009] EWCA Civ 257 §§ 8 and 9, a single Lord Justice explained that “solid](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7VHC-FXY0-YBF6-7318-00000-00&context=1519360)_


-----

Haigh and others

_grounds” have to be put forward by the party seeking a stay. Those reasons are normally of some form of_
irremediable harm if no stay is granted because, for example, the appellant will be deported to a country where they
allege they will suffer persecution or torture, or because a threatened strike will occur or because some other form
of damage will be done which is irremediable; but it is unusual to grant a stay to prevent the kind of temporary
inconvenience that any appellant is bound to face because they have to live, at least temporarily, with the
consequences of an unfavourable judgment which they wish to challenge in the Court of Appeal.

In the present case, Mr Haigh's apparent continued wish to appeal from the DIFC Judgment to the DIFC Court of
Appeal does not in my judgment provide a compelling reason for either a trial or a stay. Quite apart from the fact
that Mr Haigh appears not so far to have obtained a fee waiver or permission to appeal out of time, he has not
demonstrated that his proposed appeal has merit. Having reviewed the grounds of appeal exhibited to his 23rd
witness statement, and listened to Mr Haigh's submissions, I am not persuaded that his proposed appeal has a
realistic chance of succeeding.

Mr Haigh also contends that this case should proceed to trial because it is of public importance since (a) GFH has
(he alleges) committed illegal acts and abuse of process, (b) this is the first time an application has been made to
enforce a DIFC judgment, (c) there are ongoing criminal and civil investigations against GFH in the UK and the
United Nations and (d) the case is high profile given Mr Haigh's work helping other victims of injustice in Dubai
(particularly HRH Sheikha Latifa Al Maktoum) and will set a precedent and raise questions of 'conflict of interest'. I
do not, however, consider that any of these matters has any potential bearing on the just resolution of GFH's
present claim or otherwise justifies a full trial.

Finally, Mr Haigh suggests in his 25th witness statement that it would be unfair and prejudicial for the matter to
proceed against other defendants while the Fourth Defendant and Seventh Defendant remain dissolved, as the
companies are “1 indistinguishable corporate group”. I see no merit in this suggestion. There is no reason why the
claim against the other defendants cannot fairly proceed now.

(I) CONCLUSIONS

128. For these reasons GFH's application succeeds. It is entitled to judgment against Mr Haigh based on
the DIFC Judgment, and to the declarations sought, subject to further argument as indicated above
regarding the precise scope and form of the declarations.

**End of Document**


-----

