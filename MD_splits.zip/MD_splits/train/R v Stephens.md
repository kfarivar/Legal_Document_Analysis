# R v Stephens [2022] EWCA Crim 410

Court of Appeal, Criminal Division

Whipple LJ, Baker J, and HHJ Lodder

22 March 2022Judgment

MR T. WAINWRIGHT and MISS S BEGUM appeared on behalf of the Applicant.

The Crown was not represented, did not attend.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

LADY JUSTICE WHIPPLE:

1 On 3 September 2020, the applicant pleaded guilty to conspiracy to supply class A drugs (counts 1 and
2 on the first indictment). On 7 May 2021, before His Honour Judge Kelleher at Inner London Crown
Court, the applicant was convicted unanimously on two counts, pursuant to section 2 (1) and section 3 (6),
under the **_[Modern Slavery Act 2015 (counts 3 and 4 on the first indictment). On 14 October 2021 the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
applicant pleaded guilty on a change of plea to two offences on the second indictment, namely possession
with intent to supply class B drugs and dangerous driving. For all of these counts, on 11 November 2021,
he was sentenced by His Honour Judge Kelleher to a total period of eight years and three months'
imprisonment. That sentence was structured as a lead sentence on count 1 with concurrent sentences on
the remaining counts, plus a period of 14 months' disqualification from driving until an extended driving test
was passed.

2 The counts on the first indictment involved a conspiracy to supply heroin and crack cocaine to drug
users living in Hastings, East Sussex. The drugs had been sourced from London. The prosecution case
was that the applicant was operating a county lines operation using vulnerable people to supply drugs in
that area. He was in a leading role and directed others beneath him in the hierarchy, including young
children. It was submitted that children were specifically chosen and exploited because of their
vulnerabilities. The prosecution case was that the applicant had trafficked three children, known by their
initials, each of whom was the subject of a count on the first indictment (counts 3, 4 and 5 on the first
indictment). In the event, the jury convicted the applicant on counts 3 and 4 and acquitted on count 5.

3 The defence case was that the applicant had nothing to do with the recruitment of children and did
nothing to arrange or facilitate their travel with a view to being exploited. He said he did not know that they
were under 18 and that there was insufficient evidence to prove otherwise. He himself was only 19 at the
time The defence relied on the fact that a significant number of people engaged in selling drugs in


-----

Hastings were over 18 and pointed to the previous convictions of the three boys. The jury were invited to
conclude that they could not be sure that the boys were chosen on the basis that they were children, nor
that an adult would be likely to refuse to be used for that purpose.

4 The issue for the jury on the judge's directions of law was whether the jury were sure that by the time the
applicant had arranged or facilitated each named boy's travel to Hastings, which travel arrangements he
admitted, the applicant had chosen that boy to supply drugs for reasons which included the fact that that
boy was a child and that he thought that an adult would be likely to refuse to supply drugs on his behalf.

5 The characterisation of the issue in this way reflected the language of section 2 (1) and specifically

[section 3 (6) of the Modern Slavery Act 2015. Section 2 (1) makes it an offence to arrange or facilitate ‑](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

"(1) ..... the travel of another person (V) with a view to (V) being exploited."

6 Section 3 defines exploitation by listing a number of activities that would count as exploitation, with
section 3 (6) identifying exploitation in terms of choosing a vulnerable person to conduct those activities.
Section 3(6) provides as follows:

"(6) Another person uses or attempts to use the person for a purpose within paragraph (a), (b) or (c) of

subsection (5), having chosen him or her for that purpose on the grounds that ‑

(a) he or she is a child, is mentally or physically ill or disabled, or has a family relationship with a particular
person, and

(b) an adult, or a person without the illness, disability, or family relationship, would be likely to refuse to be
used for that purpose."

7 The judge's directions to the jury were straightforward. In relation to the test in section 3 (6) the judge
directed the jury as follows:

"The second matter to be proved you must be sure that at the time he arranged or facilitated that travel of
the boy in question he intended that the boy would be exploited. The boy would be exploited if he was to
be used to provide the service of supplying drugs in Hastings, having been chosen because he was a child
and an adult would be likely to refuse to be used for that purpose. Now there may be a number of reasons
why a child is chosen by those who seek to use him to supply drugs for them. However, it is necessary for

both of those factors ‑ that is that he was a child and that an adult would be likely to refuse to be used for

that purpose ‑ to have formed part of the reasons for the choice."

8 So far as counts 3 to 5 are concerned, the judge provided the jury with a route to verdict and that posed

a single question which mirrored the part of the summing‑up to which I have just referred. The particular

question in the route to verdict was this:

"By the time [the applicant] arranged or facilitated the named boy's travel to Hastings, had he chosen that
boy to supply drugs, for reasons which included the fact that he was a child AND that he thought that an
adult would be likely to refuse to supply drugs for him? If sure: Verdict: guilty. If not sure: not guilty."

9 During the course of deliberations and shortly after the judge had given a majority direction, the judge
received a note from the jury asking this:

"Can you clarify the statement 'An adult would be likely to refuse to supply drugs for him.'? 'An adult'
sounds like the average UK adult, not those with previous convictions or a predilection towards
criminality'."

10 The judge discussed this question with counsel and resolved to answer the question in the following
way: that "adult" just meant adult and the jury should not be considering the position of an adult with
particular characteristics of the child in question.

11 Before the jury had been called back to court, the judge was informed that the jury had verdicts. When
the jury returned into court the judge gave them the following direction in answer to their question:


-----

"The words 'an adult' mean simply that: a person over 18. The words do not require you to consider
whether the defendant gave consideration to whether an adult with particular characteristics would be likely
to refuse to supply drugs for him, only that an adult would be likely to refuse."

12 The judge read the direction to the jury again. He then asked the jury if they needed more time as a
result of what he had just told them. The jury indicated that they did not require further time, and they
returned unanimous verdicts of guilty on counts 3 and 4.

13 The issue raised by the applicant on appeal is whether the judge's answer to the jury question was
correct in law. Mr Wainwright and Miss Begum appear before the court renewing their application for leave
which was refused by the single judge on the papers. They appear pro bono. We are very grateful to them
for the assistance that they have provided to us.

14 They argue that the defence case always challenged the assertion that the boys were chosen for their
youth. The jury were referred to previous convictions of the three boys to indicate that they had character
traits other than youth which would be of use in the role they fulfilled. Those traits were said to be a

willingness to be involved in criminal activity, a willingness to use violence and a reluctance to co‑operate

with the police. They say that section 3 (6) requires that the jury should consider the particular child in
question. So, they submit, the test under section 3 (6) (a) focuses on that particular child, and the test in
section 3 (6) (b) hypothetically takes that child, removes the fact of their youth and leaves their other
characteristics for consideration.

15 In other words, it is necessary for the jury to have regard to the particular characteristics of a child in
question when considering whether, as an adult, they would have been likely to have refused to be used
for an exploitative purpose. In this way, it is suggested that the test under section 3 (6) (b) is not an
objective test of what a reasonable adult would have done, but rather a test of what these children, if they
were adults, would have done. In this respect reliance is placed on R v Karamera [2019] Cr App R 14.

16 In a written respondent's notice the prosecution resist this application. The prosecution says that
section 3 (6) does not say that particular characteristics of the child are to be taken into account and that
those words should not be read in.

17 In our judgment, having considered the matter with some care, we come to the conclusion that the
applicant's argument is simply not sustainable. This is an issue of statutory construction to which ordinary
principles apply. We look first at the language and then at the purpose of the provision. As a matter of
ordinary language, the words "the particular characteristics of the child in question" do not appear in
section 3 (6) (b), nor do any similar words. Yet the words in the statute, as they stand, are comprehensible
and clear. There is no need to read any words in to make sense of the provision.

18 As a matter of purposive construction, it is obvious why those words do not appear. As was
established in R v Karamera, the purpose of context of section 3 (6) and indeed its predecessor (section 4
of the Asylum and Immigration (Treatment of Claimants, etc) Act 2004) was to protect the vulnerable from
being trafficked with a view to exploitation. Section 3 (6) establishes that there must be shown to be two
grounds or reasons for choosing the child in question: first, that they were a child, and, secondly, that an
adult would be likely to refuse to be used for that purpose. To amount to exploitation, these need only be
factors in the choice, they do not need to be the only factors: see R v Karamera again.

19 In this case, it was for the prosecution to prove that both factors formed part of the reasons for the
applicant to have chosen the three boys in question. In relation to the boys who are the subject of counts 3
and 4, the jury was satisfied about it. That there may have been other reasons for choosing them – for

example their criminal past ‑ was nothing to the point if youth was one of the reasons for them being

chosen. In relation to the boy who was the subject of count 5, the jury were not satisfied of that.

20 The jury rejected the defence case that youth had nothing to do with the choice of the boys who were
the subjects of counts 3 and 4. That was a conclusion to which they were entitled to come. It was, in
effect, to accept the prosecution case.


-----

21 We see no basis for construing section 3 (6) (b) in the manner suggested. There is no reason to adopt
a test which asks whether an adult assuming the same characteristics of that particular child would be
used. We consider such a reading of the section would be contrary to the words of the provision, its
obvious purpose and case law which has interpreted it.

22 Further, we consider the argument to start from an erroneous point, in suggesting that the child referred

to in the first limb ‑ (a) ‑ means the particular child, i.e. the victim of the trafficking who is the subject of the

count on the indictment, taking in all his or her characteristics; paragraph (a) is simply asking whether the
choice was made on grounds that the person in question was a child, regardless of what other reasons
there might have been. The purpose of (b) is to ask whether an adult, i.e. a person who is not a child,
would be likely to refuse to be so used. Section 3(6) focuses on the particular vulnerability in question, in
this case youth, and asks whether the person has been exploited because of their youth.

23 It follows that we also reject the applicant's arguments of construction relating to the other
vulnerabilities detailed in section 3 (6), those other vulnerabilities being mentally or physically ill, disabled
or with a family relationship. We conclude that the reading of section 3 (6) (a) and (b) in relation to those
other vulnerabilities is similar to the reading we consider correct in relation to youth.

24 In these circumstances we do not consider there to be arguable merit in the applicant's submissions.
Permission to appeal against conviction is, therefore, refused. Permission to appeal against sentence,
which was only sought in the event that permission to appeal against conviction was granted, is also
refused.

______________

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the Judgment or
part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

