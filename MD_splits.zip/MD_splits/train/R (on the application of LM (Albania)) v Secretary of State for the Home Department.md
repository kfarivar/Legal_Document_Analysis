# R (on the application of LM (Albania)) v Secretary of State for the Home
 Department [2022] EWCA Civ 977

Court of Appeal, Civil Division

Lewison, Baker and Dingemans LJJ

15 July 2022Judgment

**Nicola Braganza QC and Miranda Butler (instructed by Duncan Lewis) for the Appellant**

**Ben Keith (instructed by Government Legal Department) for the Respondent**

Hearing date : 22 June 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely by circulation to the parties' representatives by email and released to
The National Archives. The date and time for hand-down is deemed to be 10.30 hrs on 15 July 2022.

**Lord Justice Dingemans :**

**Introduction and issues**

1. This is an appeal against the order of Mrs Justice Whipple (“the judge”) dated 15 November 2021,
dismissing the claim for judicial review made by the appellant and claimant (“LM”) to quash the negative
Conclusive Grounds decision made by the Secretary of State for the Home Department (“the Secretary of
State”). LM is bringing an asylum claim that has not yet been determined. LM's name is anonymised
pursuant to “Practice Guidance – Anonymisation of parties to asylum and immigration cases in the Court of
Appeal” dated 23 March 2022.

2. LM is a citizen of Albania. She claims that she is the victim of trafficking, and she has been diagnosed
with Post Traumatic Stress Disorder (“PTSD”), complex PTSD and a moderate to severe depressive
disorder. As is well known the Europe Convention on Action against Trafficking in Human Beings (“ECAT”)
was ratified by the United Kingdom in December 2008. The provisions of Chapter III of ECAT have not
been embodied in domestic legislation but the Government has implemented its provisions through
published guidance. Statutory provision for that guidance is now made in section 49 of the **_Modern_**
**_Slavery Act 2015, see generally_** _EOG v Secretary of State for the Home Department [2022] EWCA Civ_
_307 at paragraphs 5 to 17._

3. A National Referral Mechanism (“NRM”) has been established. Provision is made for the Single
Competent Authority (“SCA”) to make decisions to determine whether there are reasonable grounds to
consider that an individual is a victim of trafficking (“a Reasonable Grounds decision”). This is followed by
a recovery and reflection period before a decision is made by the SCA whether there are conclusive
grounds to find that an individual is a victim of trafficking (“a Conclusive Grounds decision”).

4. A positive Reasonable Grounds decision was made on 28 October 2019 in respect of LM. However on
11 November 2020 the SCA made a negative Conclusive Grounds decision.


-----

5. LM issued a claim for judicial review to quash the negative Conclusive Grounds decision on 12
February 2021 and was granted permission to apply for judicial review on 15 June 2021. A substantive
hearing took place on 3 November 2021 and by a judgment dated 15 November 2021 the judge dismissed
LM's claim.

6. There are three grounds of appeal. These are: the judge erred in accepting that LM's account could
properly be rejected on the grounds of her admitted dishonesty, without considering the reasons given by
LM for her dishonesty; the Secretary of State was wrong to attribute LM's PTSD to causes other than
trafficking without expert evidence to that effect; and the judge failed to apply anxious scrutiny to LM's case
and take into account every factor which supported her case.

7. In further written and oral submissions Ms Braganza QC on behalf of LM identified that there were two
principal issues namely whether: (1) the judge failed to apply anxious scrutiny to LM's claim. It was
submitted that if anxious scrutiny had been applied to the negative Conclusive Grounds decision it would
have been quashed and particular emphasis was placed on the medical evidence about psychological
evidence of torture; and (2) the judge erred in failing to give herself a Lucas lies direction when assessing
LM's admitted dishonesty about being trafficked in the UK.

8. Mr Keith on behalf of the Secretary of State submitted that the SCA's decision was right and there was
no proper basis for quashing it. The judge had scrutinised the SCA's decision with care, and had properly
directed herself as to the effect of the lies told by LM. This was a case where it was not possible to accept
LM's case about trafficking.

9. I am very grateful to Ms Braganza and Ms Butler, Mr Keith, and their respective legal teams for the
helpful written and oral submissions.

**Relevant background**

10. LM is a national of Albania and was born on 25 September 1994. As the judge noted many of the
facts which underpin LM's case are in dispute and so the judge set out a neutral summary of the
background to the entry to the UK to provide context.

11. LM attempted to enter the UK for the first time on 29 June 2017. She was stopped by the UK Border
Force on a minibus in Calais in possession of false Romanian identity documents. She was refused leave
to enter and issued with a one year ban on re-entry. LM accepted that she gave a false account when
interviewed by immigration officials on that occasion.

12. LM attempted to enter the UK for a second time on 20 July 2017. The UK Border Force in the UK
Control Zone in Lille stopped her, and she was found to be in possession of a false Greek identity
document. She was in the company of SC, who was her sister's boyfriend. LM said that SC was her
boyfriend, which it is common ground was not true. LM was removed from the Control Zone and refused
entry.

13. LM managed to enter the UK in July 2017. LM started working illegally at Poundstretcher in Brighton,
assuming a false identity and using false documents to do so.  Her wages were paid into SC's bank
account who was, as noted above, her sister's boyfriend.

14. In the early hours of 25 April 2018, a member of the public called police to report that they had seen a
female, who was LM, in a distressed state standing on a traffic island in Brighton. Her hands were bound
with duct tape. She was wearing torn fishnet stockings and was covered in bruises and scratches. The
police attended and LM was interviewed.

15. LM provided a detailed account of horrific experiences at the hands of traffickers since her arrival in
the UK in July 2017. She told of kidnap, forced prostitution and physical abuse at the hands of a man from
whom she said she had escaped from that night. She told the police about a group of women being held
against their will at a brothel in the UK. A substantial police investigation, subsequently costed at £60,000,
was launched but no evidence was found to support LM's account.  On 25 April 2018 Sussex Police
referred LM to the NRM.


-----

16. On 3 May 2018, LM was interviewed under caution in the presence of a solicitor. LM admitted that the
story she had given after she had been picked up on 25 April 2018 was a lie. LM maintained, however,
that she had been a victim of trafficking outside the UK. This is the account which LM maintains in these
proceedings is true. LM gave a different account of what had led to her being picked up on 25 April 2018,
namely that she had taped up her own wrists before running out onto the traffic island. She did not answer
some questions put to her. She was remanded in custody.

17. On 17 May 2018 the SCA made a negative Reasonable Grounds decision.

18. On 1 June 2018, LM pleaded guilty to perverting the course of justice, by lying to the police about her
experiences in the UK, and dishonestly making false representations in relation to her illegal work at
Poundstretcher. A Pre-Sentence Report (“PSR”) was obtained. LM said she had lied to the police
because she wanted to stay in the UK. The author of the PSR said that LM had also told lies to the effect
that LM had represented Albania (as Miss Albania) in Malaysia. The author of the PSR recorded that LM
had a “well established and possibly habitual pattern of lying to those in authority”.

19. On 6 July 2018 LM was sentenced to 19 months' imprisonment in the Crown Court at Lewes. The
judge recorded that LM had told lies and that her lies had caused Sussex Police to spend substantial sums
investigating false allegations wasting a great deal of police time.

20. On 12 July 2018 LM filed representations resisting removal. The Court was provided with a typed
transcript of this account. This account stated that LM had been Miss Albania and had represented
Albania in an international competition in Malaysia. LM had a manager from Kosovo who offered her a job
as a model in Turkey. She had travelled to Turkey with him and other girls and had ended up as a sex
worker. She had then been returned to Albania, albeit separated from her family, and then to Belgium.
The “boss” had tried to get LM to London and then told LM to travel to and stay with her sister. The boss
had been arrested in France. He then escaped and was arrested again, but had been directing her by text.
LM had tried to get engaged in the UK and her boss had texted her again making her very scared.

21. LM was released from prison on 12 February 2019.

22. On 15 October 2019, after receiving representations, the SCA agreed to reconsider the negative
reasonable grounds decision and a positive reasonable grounds decision was made on 28 October 2019.
This was expressed to be on the basis that the SCA suspected, but could not at that stage prove, that LM
was a victim of **_modern slavery (human trafficking and/or slavery, servitude or forced or compulsory_**
labour).

23. There was a further investigation of LM's claim.  During that investigation, LM provided a further
account of what happened on the night of 24/25 April 2018, namely that she was assaulted by her
boyfriend who beat her and bound her wrists together, and then told her to leave but not to say his name.

24. LM relied on a report from Dr Lisa Wootton, consultant Forensic Psychiatrist, dated 1 April 2019. Dr
Wootton's view, based on a single assessment of LM, was that LM was suffering from PTSD/complex
PTSD and a moderate/severe depressive disorder. In answer to a specific question “please can you
consider the likely causes of any mental health condition, with reference to the Istanbul protocol” Dr
Wootton said that LM's “psychological findings are consistent with her alleged report of torture”. Further, in
Dr Wootton's professional opinion, the symptoms, presentation and other evidence were consistent with a
person with the history disclosed by LM who was not feigning or exaggerating her symptoms.  Dr Wootton
listed the traumatic experiences that LM reported that she had had in her life. These were listed at
paragraph 13 of the report. Those events included trafficking and sexual exploitation, but also included
childhood experiences of domestic abuse and violence, sexual abuse by a relative in childhood, other
family trauma, violence at the hands of her boyfriend more recently, her experience of being interviewed by
Sussex police when in fear about whether she would be entitled to remain in the country, and being in
prison. Dr Wootton did not think it was possible to separate out each event and comment on it individually
as the effects were complex and cumulative. Dr Wootton concluded that it was the trafficking in Albania,
Turkey and en route to the UK which were the traumatic events which had precipitated her PTSD, but that
she was already predisposed by virtue of experiences as a child and her condition was being perpetuated


-----

by stresses she had continued to experience. As to causation of LM's symptoms, Dr Wootton's view was
that the events which caused LM's mental health problems were various.

25. LM also relied on a letter dated 14 February 2019 from Dr Dunmore, Clinical Psychologist, who saw
her at HMP Peterborough just before she was released. Dr Dunmore noted that LM was difficult to assess;
and that there had been inconsistencies in her accounts.

26. LM relied on a Trafficking Identification Report dated 10 October 2019 from Mirjam Thullesen, a
Psychologist practising as a psychotherapist who worked in the development of the Poppy Project, a
support service for female survivors of human trafficking. Ms Thullesen's assessment of LM's potential
trafficking was based on a scrutiny of LM's documents. Ms Thullesen concluded that LM's account
contained a significant number of trafficking indicators, based on LM's account and all the other evidence
Ms Thullesen had seen. LM's presentation was consistent with that of other victims of trafficking for sexual
exploitation. The diagnosis was consistent with her experiences and likely to be compounded by the
disbelief of her account by British authorities and by uncertainty as to her immigration and legal status.

**The negative Conclusive Grounds decision**

27. The SCA produced the negative Conclusive Grounds decision on 11 November 2020. The decision
was addressed to LM's legal representative and stated that the SCA had “decided there are not currently
Conclusive Grounds to accept” that LM was a victim of trafficking. The decision listed all of the information
provided to the SCA and which had been considered. This included false documents and Border Force
paperwork dated 29 June 2017 and further information received from Sussex Police Force on 13 July
2020. The decision ran to 15 pages before a further page of next steps to be taken by LM.

28. The decision set out a chronology of known encounters and then summarised LM's various accounts
and her current accommodation. The decision then referred to information known about Albania, Turkey,
Belgium, France and the UK and their respective trafficking profiles.

29. On page 9 of the decision it was recorded that “competent authority guidance on credibility is
contained in the attached decision annex”. It was common ground that the SCA had published guidance
on, among other matters, assessing credibility.

30. The decision noted that LM had provided a detailed account of events which is “broadly in line with
wider external evidence on victims of **_modern slavery from Albania”. It was also recorded that LM had_**
provided evidence showing attendance at a beauty pageant in Malaysia. The report, however, identified
the story told by LM on 29 June 2017 to Border Force officials that LM's father had borrowed money, lost it
gambling and that LM wanted to come to the UK to work to pay it back. The decision records that LM had
explained that this was said when LM had a fake Romanian ID card and that LM had given a false story to
the Border Force. The decision letter recorded that the false account was specific and fairly detailed.

31. The decision letter then recounted LM's discovery with taped hands in Brighton and her report to the
police about being trafficked into the UK, and then trafficked within the UK. The police investigations were
summarised, which showed that DNA had been found on LM which matched an individual who the police
believed might have been a trafficker, but who turned out to be LM's boyfriend. The decision letter
recorded that LM had not answered police questions about why her boyfriend's DNA was on the tape
around her hands, and whether he had been involved in taping her, and why her sister's boyfriend had
suggested that LM was going to do something before she was found on the street in Brighton.

32. The decision letter recorded that LM had given false evidence about a woman whose photograph was
shown to the police being sexually exploited and noted LM's conviction for perverting the course of justice.
The decision letter also recorded that in a later account of what had happened on the night LM had said
that her boss (whose name was given) had wanted to kill her. This was inconsistent with earlier accounts.
LM's sister's boyfriend's understanding was that LM had come to work in the UK because she was working
in journalism and that she had lost her job after refusing sexual advances. This was put to LM in police
interview and LM did not respond.


-----

33. At page 11 of the decision it was stated that “consideration has been given as to whether there are any
mitigating circumstances in relation to your account”. The medical reports which had been submitted were
summarised. This was the report dated 1 April 2019 from consultant forensic psychologist Dr Lisa
Wootton. The decision recorded that “the professional opinion of the author was you fulfil the ICD criteria
for the diagnosis of PTSD/Complex PTSD, Moderate/Severe depressive disorder and further state you
present with severe symptoms of anxiety”. It was recorded that the report recorded traumatic experiences
being: “domestic violence by your father towards you, your sisters and your mother. Sexual abuse by your
cousin. Your brother accusing you of being in a relationship with another student and attacking you with a
knife. Experience of being trafficked, sexual exploitation and threats made against your family and
violence against you and being forced at gunpoint to tell your father you were not coming back. Being
caught illegally working at Poundstretcher. Violence towards you from your boyfriend. Being interviewed
by police and the time you spent in prison in the UK”. The decision also recorded that the report provided
information about fitness to be interviewed. At page 12 of the decision it was noted that the report had
stated that it was difficult for victims of trauma to relive traumatic events and the ability to recall traumatic
accounts may be over general or lacking in detail and consistency. The decision stated “it is considered
that the accounts you have provided have been detailed and coherent and whilst there have been
inconsistencies in your accounts, this has mostly been already addressed by your admission that you have
provided false accounts. It is considered that the report does not provide any information to indicate that
you did not have capacity to make informed decisions or to understand the consequences of your actions.
Therefore, little weight has been attributed to this”.

34. The decision went on to state “It is acknowledged that although you are displaying the above
symptoms, these alone do not mitigate for the inconsistencies between your accounts and your mental
health and can be attributed to the problems you faced with your family in Albania and problems you face
in the UK with the police and time spent in prison. Considerable weight is placed on reports by qualified
professionals; however emphasis must be placed on the fact that these professionals are not always privy
to the vast amounts of information that the Home Office has access to and therefore can only comment on
information before them. It is considered that the account provided is of a self-serving nature, based on
what you have told the them; and what they have accepted in good faith”.

35. Reference was also made to the Trafficking Identification Report dated 10 October 2019 from Mirjam
Klann Thullesen who is a qualified and licensed psychotherapist who had experience with modern slavery
and trafficking. The decision recorded that professional opinion of the report was that LM's account was
consistent with that of other victims of trafficking for domestic servitude. The diagnosis of PTSD and
depressive disorder made by Dr Lisa Wootton was consistent with experience of abuse, control, trafficking
and exploitation. The decision noted that Ms Thullesen had referred to domestic servitude and wondered
whether this was an error because LM's case was that she had been the victim of trafficking for sexual
exploitation. The decision noted that Ms Thullesen had said that delayed disclosure and limited details
might result from a range of issues (including fear of exploiters, instructions to provide a false account
among others) but the decision recorded that LM had provided a detailed account and it was unclear which
elements of the account the author considered to be limited in detail. The decision also recorded these
were only suggested as possible reasons. This part of the decision concluded “considerable weight is
placed on reports by qualified professionals; however, emphasis must be placed on the fact that these
professionals are not always privy to the vast amounts of information that the Home Office has access to
and therefore can only comment on information before them. It is considered that the account provided is
of a self-serving nature, based on what you have told the them; and what they have accepted in good
faith”.

36. The decision also referred to the letter dated 14 February 2019 from Dr Rebecca Dunmore, senior
clinical psychologist for the Mental Health in Reach team at HMP Peterborough.

37. The decision summarised points for LM's case, and information considered to go against LM's case.
The decision concluded on page 14 “looking at the available evidence in the round of your case, it is
considered that whilst there is some information that supports your account, looking at all the pieces of


-----

information cumulatively, the credibility issues outweigh the evidence in support of your account. As such,
it is not considered that you have met the required evidentiary standard”.

**The judgment below**

38. In paragraphs 1 to 4 the judge summarised the three grounds of claim and set out the procedural
history. The grounds of claim were: (1) the defendant failed to apply anxious scrutiny to the Conclusive
Grounds decision; (2) that the defendant misdirected herself as to the correct approach to credibility; and
(3) that the defendant had misdirected herself as to the correct approach to expert evidence.

39. The judge then summarised the background in paragraphs 5 to 17 of the judgment and the expert
evidence at paragraphs 18 to 21 of the judgment. The judge addressed the Conclusive Grounds decision
at paragraphs 22 to 28 of the judgment.

40. The judge summarised the relevant law and guidance from paragraphs 29 to 34 noting that there was
no dispute between the parties as to the law. The judge summarised parts of the relevant guidance
published pursuant to section 49 of the **_Modern Slavery Act 2015. The judge expressly recorded in_**
paragraph 31 that the Secretary of State must demonstrate “a high standard of reasoning” and apply
anxious scrutiny and show by her reasoning that every factor which tells in favour of the applicant has been
properly taken into account, and referred to R(MN) v Secretary of State for the Home Department [2020]
_EWCA Civ 1746; [2021] 1 WLR 1956. In paragraph 32 the judge recorded that “expert evidence must be_
taken into account and may support an applicant's credibility” and that it was for the decision maker to
reach a decision on the totality of the evidence viewed holistically.

41. The judge stated in paragraph 33 that the fact that a person has lied to the authorities is not
determinative of whether they are a victim of trafficking, and referred to MA (Somalia) v Secretary of State
_[for the Home Department [2010] UKSC 49; [2011] 2 All ER 65.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:52HJ-R1C1-DYBP-M495-00000-00&context=1519360)_

42. The judge also recorded that on judicial review the Court must consider the decision with particular
care, by reference to paragraph 244 of R(MN).

43. The judge then addressed the grounds of challenge in paragraphs 35 to 43 of the judgment and
dismissed them. The judge said “this CG decision is careful and thorough. It demonstrates a high standard
of reasoning”.

44. The judge refused an application to adduce further witness statements from LM and her sister, noting
that they were not relevant to the issue of whether the decision maker erred in law, and were in any event
“yet more evidence to try to explain away the inconsistencies and conflicts of the existing accounts given
by the claimant”.

**Duties on the SCA when making decisions**

45. The duties on the Secretary of State in relation to Conclusive Grounds decisions were examined by
the Court of Appeal in R(MN). In R(MN) the Court of Appeal addressed the approach to be taken to expert
evidence by the SCA. Decision makers should take all relevant evidence, including expert evidence, into
account when assessing credibility, see _R(MN)_ at paragraph 108. It is an error to come to a negative
assessment and then ask whether that assessment is displaced by expert evidence. This error has been
referred to as the Mibanga error, following the judgment of the Court of Appeal in Mibanga v Secretary of
_State for the Home Department [2005] INLR 377. The Court of Appeal in R(MN) at paragraphs 110 to 124_
addressed the weight that should be given to expert evidence where there are expressions of consistency,
and whether the expert evidence has shown more than “mere consistency”.

46. In paragraphs 125 to 128 of R(MN) the Court of Appeal specifically commented on the Guidance given
to the SCA caseworkers on how to assess credibility. This referred to “mitigating circumstances which can
affect whether a potential victim's account of human trafficking or **_modern slavery is credible”. The_**
guidance went on to list factors, including trauma, mistrust of authorities and painful memories, that might
explain why such a victim was incoherent, inconsistent or delayed in giving accounts. As the Court of
Appeal pointed out in paragraph 126 of R(MN) the use of the phrase “mitigating circumstances” was not an
apt phrase This was because it had overtones of criminal procedure and was describing situations which


-----

might cause the alleged victim of trafficking to have delayed in reporting being trafficked, or to have given
incoherent or inconsistent accounts. It might be noted that the decision making in LM's case pre-dated the
judgment of the Court of Appeal in _R(MN)_ and it appears that the guidance to the SCA was in material
respects the same as that considered in R(MN).

**The judge applied anxious scrutiny (revised ground one)**

47. It is established that “a high quality of reasoning is required in a conclusive grounds decision, which
engages fully with the case advanced by the putative victim of trafficking”, see R(MN) at paragraph 242.
This is emphasised in the guidance. On a judicial review challenge the court must “consider the decision
with particular care”. “The intensity of review is high”, and it is important to establish whether the decisionmaker has observed Carnwath LJ's direction that “every factor which tells in favour of the putative victim's
case has been properly taken into account”, see R(MN) at paragraph 244.

48. As noted above, the judge specifically directed herself that “the Court must consider the decision with
particular care” and referred to _R(MN)_ at paragraph 244. It is also apparent that the judge did establish
whether the decision maker had considered whether every factor which told in favour of LM's case was
considered. The judge accurately summarised the expert evidence (on which particular reliance was
placed on behalf of LM) in paragraphs 18 to 21 of the judgment below, and the terms of the Conclusive
Grounds decision in paragraphs 22 to 28 of the judgment. The judge rejected the criticism that the
decision maker had reached a conclusion on credibility by reference to LM's conflicting accounts, accepting
the submission on behalf of the Secretary of State that the conclusion on credibility was reached “on the
basis of a holistic assessment of all the material before the decision-maker”.

49. Ms Braganza submitted that the judge's reasons were very summary, but brevity in any judgment is a
virtue so long as the relevant arguments are fairly addressed. In my judgment the judge had properly and
fairly addressed the relevant arguments. Ms Braganza went through the Conclusive Grounds decision in
an attempt to show that the judge's conclusion about that decision was wrong. This exercise served only
to confirm that the decision maker had fairly assessed LM's credibility as a whole. The differing stories set
out by LM had been set out, and then the decision has specifically addressed “mitigating circumstances”.
This included the expert evidence, before coming to a conclusion “looking at the available evidence in the
round of your case”. I agree with the judgment of the Court of Appeal in R(MN) that the phrase “mitigating
circumstances” was an inappropriate phrase because what the guidance was highlighting was possible
explanations for, among other matters, inconsistencies, incoherence and delayed reporting.

50. I agree with Ms Braganza that the decision letter writer must have used a form template ending to the
parts of the decision which dealt with the relevant expert evidence. This template ending was
“considerable weight is placed on reports by qualified professionals; however, emphasis must be placed on
the fact that these professionals are not always privy to the vast amounts of information that the Home
Office has access to and therefore can only comment on information before them. It is considered that the
account provided is of a self-serving nature, based on what you have told the them; and what they have
accepted in good faith”. The part “what you have told the them” (underlining added) does not seem to
have been completed properly because it seems likely that the “them” should have been replaced with the
name of the relevant expert.

51. It is possible that the part of the passage about “professionals are not always privy to the vast amounts
of information that the Home Office has access to” was based on dicta from paragraph 17 of a judgment of
Ouseley J in _HE (Democratic Republic of Congo) v Secretary of State for the Home Department_ _[[2004]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4HJR-NPR0-TWYV-R043-00000-00&context=1519360)_
_[UKIAT 321; [2005] Imm AR 119. Ouseley J had recorded, in the context of a challenge to a First-tier](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4HJR-NPR0-TWYV-R043-00000-00&context=1519360)_
Tribunal decision in an asylum case, that a doctor does not usually assess the credibility of an application
because it is not usually appropriate in respect of a patient or client and said “that is in any event the task
of the fact-finder who will have often more material than the doctor, and will have heard the evidence
tested”. The Court of Appeal in R(MN) addressed these dicta and at paragraph 121(2) and (3) stated that
where a doctor's report expressed mere consistency it was necessarily neutral on whether that account
was truthful, but it was open for a doctor to express an opinion that findings went beyond mere consistency
meaning that opinion should therefore be taken into account by the decision maker. I should record that as


-----

a result of references made in the oral submissions to the medical evidence and its assessment under the
Istanbul Protocol dated 9 August 1999, the Court was provided by the parties with a copy of the Istanbul
Protocol after the hearing. Chapter VI of the Protocol deals with psychological evidence of torture and its
assessment.

52. If the decision maker in this case had only included the “template ending” when commenting on the
expert evidence then I would have accepted that the decision maker had not applied anxious scrutiny to
the decision, and that the judge below would have failed to identify that error. However it is apparent that
the decision maker had summarised accurately the expert evidence and had reflected on that evidence
when assessing whether it was more likely than not that LM was a victim of trafficking. As Mr Keith had
pointed out in argument, some of the conclusions were expressed in terms of “mere consistency”, and it
was apparent that there were numerous factors causing mental health issues which LM had reported:
“domestic violence by your father towards you, your sisters and your mother. Sexual abuse by your
cousin. Your brother accusing you of being in a relationship with another student and attacking you with a
knife. Experience of being trafficked, sexual exploitation and threats made against your family and
violence against you and being forced at gunpoint to tell your father you were not coming back. Being
caught illegally working at Poundstretcher. Violence towards you from your boyfriend. Being interviewed
by police and the time you spent in prison in the UK”. The existence of these other factors necessarily
affected the support to LM's case which could be taken from both the expert evidence and the diagnosis of
complex PTSD and a moderate to severe depressive disorder.

**Proper consideration of the lies told by LM (revised ground two)**

53. The ground of appeal relating to a lies direction is a reference to the decision of the Court of Appeal
Criminal Division in R v Lucas [1981] QB 720 at 724. Lord Lane CJ said “To be capable of amounting to
corroboration the lie told out of court must first of all be deliberate. Secondly it must relate to a material
issue. Thirdly the motive for the lie must be a realisation of guilt and a fear of the truth. The jury should in
appropriate circumstances be reminded that people lie, for example in an attempt to bolster up a just
cause, or out of shame or out of a wish to conceal disgraceful behaviour from their family.” The
circumstances in which a lies direction will be required to be given in a criminal trial has generated a
number of appellate decisions, see generally Blackstone's Criminal Practice 2022 at F1.25 and Archbold
2022 at 4-461. It should be noted that the particular need for a Lucas lies direction to be given to a jury in
a criminal case is because the burden of proof in a criminal case is on the prosecution to make a jury sure
that the defendant committed the offence, and to warn juries against the risk of assuming that just because
a defendant has lied, he is guilty of the offence.

54. The context in an immigration case is different. The Supreme Court considered lies in MA (Somalia).
In that case the Supreme Court stated that where the relevant Tribunal had correctly directed itself as to
the impact of an asylum seeker's lies, the Court of Appeal should have been slow to find that it had applied
that direction incorrectly. Lord Dyson stated at paragraph 32 that: “Where the appellant has given a totally
incredible account of the relevant facts, the tribunal must decide what weight to give to the lie, as well as to
all the other evidence in the case, including the general evidence. Suppose, for example, that at the
interview stage the appellant made an admission which, if true, would destroy his claim; and at the hearing
before the AIT he withdraws the admission, saying that his answer at interview was wrongly recorded or
that he misunderstood what he was being asked. If the AIT concludes that his evidence at the hearing on
this point is dishonest, it is likely that his lies will assume great importance. They will almost certainly lead
the tribunal to find that his original answers were true and dismiss his appeal. In other cases, the
significance of an appellant's dishonest testimony may be less clear-cut. The AIT in the present case was
rightly alive to the danger of falling into the trap of dismissing an appeal merely because the appellant had
told lies.” Lord Dyson then referred to the Lucas lies direction and at paragraph 33 made it clear that the
“significance of lies will vary from case to case”.

55. In this case the judge specifically reminded herself that “the fact that a person has lied to the
authorities is not determinative of whether they are a victim of trafficking” in paragraph 33 of the judgment
below, and referred to the judgment of the Supreme Court in _MA (Somalia). This is the answer to the_
second revised ground of appeal set out in paragraph 7 above which was to the effect that the judge


-----

should have given herself a _Lucas_ lies direction. As Ms Braganza recognised in submissions, however,
the real issue relates to the approach taken by the decision maker for the Conclusive Grounds decision.
The judge considered the Conclusive Grounds decision and recorded that the decision maker was aware
that inconsistencies or lies do not necessarily mean that the claim must be rejected. In my judgment the
judge was right to make that assessment. This is because it is apparent from the terms of the Conclusive
Grounds decision that the decision maker assessed LM's account with all the relevant evidence. This
included for example trafficking profiles for the respective countries through which LM was trafficked. It is
apparent that the decision maker fairly reflected on all the matters relating to LM's credibility, but rejected
LM's account.

**No other basis for allowing the appeal**

56. I have revisited the original grounds of appeal but they do not, in my judgment, form a basis for
allowing the appeal. This is because the judge was right to accept that LM's account could properly be
rejected on the grounds of her admitted dishonesty. LM's account was central to the case that she was a
victim of trafficking, and there was not sufficient evidence to show that she had been a victim of trafficking.
There were some features of the case which were not immediately consistent with LM being a victim of
trafficking, for example: being with her sister's boyfriend when travelling to the UK, when it was common
ground that he had nothing to do with trafficking; keeping her earnings from her work with Poundstretchers;
and not being controlled in the UK, when her case was that she was forced to travel to the UK. None of
these matters were determinative against LM, but they do show that absent some legal error, there was no
basis for setting aside the Conclusive Grounds decision.

57. In addition, the Secretary of State was entitled to attribute LM's PTSD to causes other than trafficking.
This was because the expert evidence had itself identified a series of causes other than trafficking. The
ground of appeal about anxious scrutiny has been addressed above.

**Conclusion**

58. For the detailed reasons set out above I would dismiss this appeal.

**Lord Justice Baker**

59. I agree.

**Lord Justice Lewison**

60. I also agree.

**End of Document**


-----

