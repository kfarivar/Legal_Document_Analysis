# Nosworthy v Instinctif Partners Ltd UKEAT/0100/18

SLADE DBE J, SMITH OBE DL, WORTHINGTON

4 OCTOBER 2018, 28 FEBRUARY 2019

28 FEBRUARY 2019

E Nosworthy, M Nosworthy for the Appellant

L Harris (of Counsel) for the Respondent

Messrs Osborne Clarke Solicitors

_SUMMARY_

_UNLAWFUL DEDUCTION FROM WAGES_

_CONTRACT OF EMPLOYMENT - Implied term/variation/construction of term_

The Claimant was given a small shareholding in her employer as a condition of its sale to the Respondent and sold
the shares to them under a Share Purchase Agreement. Part of the consideration for the shares were deferred
earn-out shares and loan notes. By reason of that agreement, other agreements and the Articles of Association a
Bad Leaver forfeited their loan notes and their shares were re-acquired. An employee who voluntarily resigned was
defined in the relevant documentation as a Bad Leaver. The Claimant resigned and was treated as a Bad Leaver.
The Employment Tribunal did not err in holding that the Bad Leaver provisions were not unconscionable or a
penalty. The criteria for setting aside an agreement as unconscionable explained in Alec Lobb (Garages) Ltd v Total
_Oil (GB) Ltd [1983] 1 WLR 87and Brian Strydom v Vendside Ltd [2009] EWHC 2130 were not satisfied. The ET did_
not err in holding that the Bad Leaver provisions were not a penalty as they were not imposed on breach of contract
by the Claimant. _Cavendish Square Holdings BV v Makdessi [2016] AC 1172considered. The ET did not err in_
holding that the Bad Leaver provisions were not a deduction from wages within the meaning of the _[Employment](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y0CH-00000-00&context=1519360)_
_[Rights Act 1996 as the claim was excluded by s 27(2)(e). The Claimant was not permitted to pursue an argument](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y0CH-00000-00&context=1519360)_
that the Bad Leaver provisions were a restraint of trade. This point had not been taken in the ET and it would have
required additional findings of fact. The Blackpool Fylde and Wyre Society for the Blind v Begg UKEAT/0035/05 and
_Rance v Secretary of State for Health_ _[[2007] IRLR 665 applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W4DB-00000-00&context=1519360)_

**SLADE DBE J:**

(reading the judgment of the court)

**[1] Miss Eloise Nosworthy (the Claimant) appeals from the decision of an Employment Tribunal (Employment**
Judge Glennie and members, Mrs J Griffiths and Mr J Carroll) (“the ET”). By a Judgment with Reasons sent to the
parties on 6 July 2017 (“the Judgment”) amongst other orders the ET upheld her complaint of breach of contract but
decided no remedy was due and dismissed her complaint of unlawful deduction from wages. The Claimant appeals
from the decision to make no award for breach of contract and from the dismissal of her claim for deduction from
wages.


-----

**[2] The appeal by the Claimant, who has acted in person assisted by her father as she was before the ET, has**
been advanced both in writing and orally clearly and thoughtfully displaying careful and thorough research. Mr
Lance Harris, counsel for the Respondent who appeared at the ET, also presented helpful submissions.

**[3] The contract and deduction from wages claims in respect of which the Claimant appeals turned on the effect of**
documents entered into in July 2013 by the Claimant when the company she originally joined, Communication
Operations Limited (“COL”), was sold to the Respondent, then named College Hill Holdings Limited.

**[4] In 2008 Mr Macfarlane set up COL to produce films for corporate communication and marketing purposes. COL**
had about three employees when the Claimant joined the company on 7 September 2011 as a Business
Development Associate.

**[5] The ET held that in connection with its acquisition by the Respondent, the Claimant was issued with 2% of the**
share capital of COL. The ET recorded at para 15 that Mr Macfarlane gave evidence that he had been required by
the Respondent to do so. He said “Instictif made it a term of the deal that I give equity to other people in the
business to ensure continuity post acquisition”. He also gave Mr Ryan, another employee, 8% of the shares
retaining 90% for himself. The percentages given to the Claimant and Mr Ryan reflected “their relative value to the
business and the impact their departure would have”.

**[6] The Claimant's relationship with the Respondent was governed by a number of documents she signed on 25**
July 2013.

**[7] On 25 July 2013 the Claimant entered into a contract of employment with COL. Her salary was stated to be**
£25,000. The Contract of Employment provided for no other benefits and contained no post termination restraints
on her occupation. It was stated that the Claimant's continuous employment with COL had commenced on 7
September 2011.

**[8] By a Deed made on 26 July 2013 between vendors of shares in COL, including the Claimant and College Hill**
Limited which changed its name to Instinctif Partners Ltd, the Respondent, the vendors agreed to sell their shares
on the terms there set out (“the Share Purchase Agreement”). The consideration agreed to be paid to the vendors
was made up of the Initial Consideration and Deferred Consideration. It is the Deferred Consideration which is the
subject of the Claimant's claims.

**[9] The Deferred Consideration was set out in cl 4.1 which provided:**

“4.1. Subject to cl 4.5, each Earn-out Payment shall consist of:

(a) subject to cl 4.4, Earn-out Shares and Earn-out Loan Notes to be issued, if any, pursuant to sub cl 4.2 and
4.3; and/or

(b) Earn-out Cash Payments, if any, as become payable in accordance with sub cl 4.2, 4.3 and 4.4.

…

4.5. Each Earn-out Payment shall be subject to the following conditions:

…

(c) if any Vendor is a Bad Leaver, such Bad Leaver shall not be entitled to receive any Earn-out Payments that
are or that become payable after the date of termination of such Bad Leaver's employment.”

**[10] “Good Leaver” is defined in the Share Purchase Agreement to include a Vendor:**

“… [who] (f) is dismissed other than summarily for cause.”

“Bad Leaver” is defined in the Share Purchase Agreement to include a Vendor:


-----

“… who leaves the employment of the Company or any member of the Purchaser's Group in circumstances
where he or she is not a Good Leaver, including in circumstances where the relevant Vendor:

(a) voluntarily resigns his or her employment or engagement (whether or not in accordance with his or her
service or employment contract); or

(b) has (or, if his or her employment is terminated on other grounds, could have had) his or her employment
terminated by the Company or any Purchaser Group Company summarily for cause (including, but not limited
to, gross misconduct or any material breach of any shareholder arrangements including any articles of
association, shareholders' or investment agreement and/or his or her service contract) and where such breach
has not been (or cannot be) remedied.”

**[11] Clause 19 under the heading “Protection of Goodwill” sets out restrictive undertakings given by the Warrantor,**
Mr Macfarlane. These include his agreement that he would not during the restricted period, two years from
completion, endeavour to entice away from any Group Company any Senior Employee. Senior Employee is defined
as each of the Vendors. Further, he undertook that during that period he would not employ or otherwise engage any
Senior Employee. By 19.3, each of the Vendors, which included the Claimant, severally agreed that having regard
to matters set out and having taken professional advice the restrictions in cl 19 were reasonable and necessary for
the protection of the legitimate business interests of the Purchaser.

**[12] By a deed of adherence entered into on 26 July 2013 between the Claimant and College Group Topco Ltd**
(“the Deed of Adherence”) the Claimant undertook to the “continuing parties” to “comply with the provisions of, and
to perform all the obligations in, the Principal Agreement of a Manager so far as they may remain to be observed
and performed and, upon the issue of Relevant Shares to the Acquiror, the Acquiror shall become a party to the
Principal Agreement as if the Acquiror were named in the Principal Agreement as a Manager holding the Relevant
Shares in addition to the Existing Investors”. Relevant shares are defined as shares and loan notes issued to the
Claimant under the Share Purchase Agreement. The Principal Agreement is defined as the Investment Agreement
dated 6 October 2011 between College Group Topco Ltd and others as amended from time to time.

**[13] The Principal Agreement provided that “Bad Leaver” has the meaning given in the Articles of Association:**

“7.23. Each Manager holding Management Loan Notes severally covenants that he shall not become a Bad
Leaver. If any Manager breaches this covenant, the Company is entitled to claim from such Manager an
amount (if any) equal to the aggregate amount which is payable to that Manager in respect of the Loan Notes
held by him at the time at which such Loan Notes are redeemed and such claim shall be satisfied by the Buyer
setting off an amount equal to such sum from the total amount (if any) payable to such Manager under such
Loan Notes.

…

8.1. Subject to cl 13, each Party agrees to observe and comply fully and promptly with the provisions of the
Articles to the intent and effect that each and every provision thereof shall be enforceable by the Parties to this
Agreement between themselves and in whatever capacity notwithstanding that any such provision might not
have been so enforceable in the absence of this cl 8.”

**[14] The Articles of Association of the Respondent included the following provisions. Article 15 applies to a Leaver**
in relation to any Leaver's Shares and Loan Notes:

“15.2.2. a “Leaver” shall mean:

(a) any Shareholder who ceases to be a Relevant Employee …”

A “Relevant Employee” is an employee of any Group Company.

Article 15.3 provides that a leaver is required to transfer Leaver Shares and Loan Notes (“Leaver's Securities”) at a
price in accordance with the Articles in the section titled “Price for Leaver's Securities”:


-----

“15.6. Subject to art 15.8 … the price ultimately payable for Leaver Shares shall be:

…

15.6.2. in the case of a Bad Leaver the lower of Acquisition Cost and Fair Value for the Leaver Shares.

15.7. Subject to art 15.8, any Leaver holding Loan Notes:

…

15.7.2. in the case of a Bad Leaver, shall forfeit such Loan Notes in whatever way the Remuneration
Committee may determine (acting reasonably and in good faith and with a view to tax efficiency), including for
example exercising its rights pursuant to cl 7.23 of the Investment Agreement …

15.9. For the purposes of this art 15, the classification of a Good Leaver or a Bad Leaver status shall be
determined by the Remuneration Committee based on the following criteria:

15.9.1. a Leaver shall be deemed to be a “Good Leaver” in circumstances where the relevant person:

…

(f) is dismissed other than summarily for cause;

15.9.2. a Leaver shall be deemed to be a “Bad Leaver” if he is not a Good Leaver, including in circumstances
when the relevant person:

(a) voluntarily resigns his employment or engagement (whether or not in accordance with his
service/employment contract); …

15.9.3. the “Vested” and “Non-Vested” Share entitlements referred to in art 15.6 are shall be calculated in
accordance with [a table set out in 15.9.3].”

**[15] The Articles of Association of the Respondent art 13 provides that unless the context requires otherwise any**
provision in the Articles requiring a transfer of Shares by a Manager shall be deemed to include a reference to
require a transfer of, as closely as possible, a similar proportion of Loan Notes to the Shares so transferred.

**[16] On 1 January 2014 the Claimant's salary was increased to £34,000 and on 1 November 2014 her job title was**
changed to Associate Partner. Another senior person was brought into the business at a much higher salary. The
Claimant's salary was increased to £40,000 in April 2015.

**[17] The Claimant resigned with notice given on 3 May 2016 which terminated her employment on 2 August 2016.**
The third earn-out period for the Deferred Consideration expired on 31 December 2015.

**[18] By letter of 17 August 2016 the Claimant was required to transfer her shares to the Respondent. Relying on**
the Articles of Association the Respondent treated the Claimant as a Bad Leaver. The Claimant was informed that
in accordance with art 15.6.2 she would receive the lower of the acquisition cost and the fair value of the shares
determined by the Remuneration Committee. The Remuneration Committee decided that she would receive the
acquisition cost of £1 per share and therefore £143. Further, by reason of art 15.7.2, the Claimant as a Bad Leaver
forfeited her Loan Notes.

_THE JUDGMENT OF THE ET_

**[19] The ET held at the second paragraph numbered para 72 that in accordance with the Articles of Association**
the Respondent was entitled to treat the Claimant as a Bad Leaver as she had resigned. Accordingly the Claimant
was required to transfer her shares back to the Respondent. The price for a Bad Leaver's shares was to be
determined in accordance with art 15.6 of the Articles of Association. That was the lower of the acquisition cost and
fair value for the leaver's shares. The ET found at para 77 that the acquisition cost of the shares was nil.


-----

**[20] The ET did not make a finding in respect of the forfeiture of the loan notes.**

**[21] The ET considered three challenges to the Bad Leaver provisions made by Mr Nosworthy. They rejected the**
argument that the provisions under which the Claimant was to receive nothing for her shares was unconscionable.
They held that this was not a situation in which the parties were making a bargain. They observed “The Claimant
was not buying the shares, she was being given them. She did not negotiate a purchase of the shares”. The ET
further held that the remedy sought relying on the unconscionability of a bargain was to set it aside. In this case the
ET considered that this would result in the Claimant not having the shares at all.

**[22] As for the second challenge to the Bad Leaver provisions, the ET rejected the contention that they amounted**
to a penalty and should be held to be unenforceable. The ET accepted the submission of Mr Harris for the
Respondent that a penalty is a sum to be paid on breach of contract. The Claimant was not in breach of contract in
resigning from her employment. They also rejected that argument advanced by Mr Nosworthy that in respect of loan
notes the Claimant was in breach of cl 7.23 of the Principal Agreement. Under that provision each manager holding
loan notes covenants that he shall not become a Bad Leaver and that in the event of breach of that covenant the
company was entitled to claim compensation. The ET accepted the contention of Mr Harris that as the Respondent
was not seeking to rely on that covenant the question of penalty did not arise.

**[23] The ET rejected the third point made on behalf of the Claimant by Mr Nosworthy that the contract was illegal in**
[that it involved a contravention of the Modern Slavery Act 2015 because the covenant at cl 7.23 of the Principal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
Agreement constituted forced or compulsory labour. The ET said at para 83 that the Claimant took up employment
as a volunteer and when she was no longer wishing to continue working for the Respondent she resigned. The ET
commented that reasons that may have operated on her mind that could have discouraged an earlier resignation
would be applicable to any employment and any employee who was considering resigning. One of those factors
that might encourage them not to resign would be the loss of salary and benefits.

**[24] The ET therefore rejected the challenges to the Bad Leaver provisions.**

**[25] At para 87the ET found that the Respondent was not in breach of the Articles of Association and therefore was**
not in breach of contract for failure to pay remuneration. The Respondent could have paid nothing as the shares did
not cost anything to acquire. The ET went on to comment that if there had been technically a breach of contract
then they would find there would be no remedy as the contract could have been performed by paying no
compensation.

**[26] An element of deferred consideration under the Share Purchase Agreement was staged cash payments. The**
Respondent admitted that they had not paid the third tranche of such payment payable at the end of July 2016.
£230 was due and had not been paid at the correct time.

**[27] The ET therefore held that the complaint of breach of contract was well-founded but that no remedy was**
applicable as £379 had been paid to the Claimant by the time of the hearing.

_THE RELEVANT STATUTORY PROVISIONS_

_[Employment Rights Act 1996 (“ERA”)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y0CH-00000-00&context=1519360)_

Section 13

(1) An employer shall not make a deduction from the wages of a worker employed by him unless 
(a) the deduction is required or authorised to be made by virtue of a statutory provision or a relevant
provision of the worker's contract, …

(2) In this section “relevant provision”, in relation to a worker's contract, means a provision of the contract
comprised 
(a) in one or more written terms of the contract of which the employer has given the worker a copy on an
occasion prior to the employer making the deduction in question,


-----

…

Section 14

(4) Section 13 does not apply to a deduction from a worker's wages made by his employer in pursuance of
any arrangements which have been established 
(a) in accordance with a relevant provision of his contract to the inclusion of which in the contract the
worker has signified his agreement or consent in writing, …

Section 27

(1) In this Part “wages”, in relation to a worker, means any sums payable to the worker in connection with
his employment, including 
(a) any fee, bonus, commission, holiday pay or other emolument referable to his employment, whether
payable under his contract [of employment] or otherwise, …

_EMPLOYMENT TRIBUNALS EXTENSION OF JURISDICTION (ENGLAND AND WALES) ORDER 1994_

Article 3

Proceedings may be brought before an employment tribunal in respect of a claim of an employee for the recovery of
damages or any other sum … if 
(a) the claim is one to which s 3(2) of the Employment Tribunals Act 1996 applies …

(b) the claim is not one to which art 5 applies; …

Article 5

This article applies to a claim for a breach of a contractual term of any of the following descriptions 
…

(e) a term which is a covenant in restraint of trade.

_THE GROUNDS OF APPEAL_

_GROUND 1_

**[28] The Claimant contended that the ET erred in rejecting the contention that the bargain determining the leaver**
provisions applicable to the Claimant's shares and loan notes pursuant to which she received no benefit was
unconscionable and should be set aside.

**[29] It was contended that the ET erred in holding at para 78 that the question of unconscionability did not arise**
because this was not a situation where the parties were making a bargain. As the Claimant was not buying the
shares, she was being given them.

**[30] The Claimant contended that the ET erred in holding that if the parties were put in the position they would**
have been had the bargain not been made, she would not have been given the shares at all.

**[31] It was submitted that the Claimant gave valuable consideration for her 2% share in COL as it was a condition**
of the sale of that company to the Respondent that she and the other employees have equity in the business.
Further it was said that in providing her services for three years post acquisition to ensure continuity the Claimant
provided consideration to the Respondent. It was contended that the Share Purchase Agreement provided that
Managers as employees receive shares and loan notes for performing their duties. Further it was said that the
provisions of the Share Purchase Agreement linked the grant of shares to remaining employed by the Respondent
until 31 December 2015.


-----

**[32] The basis for the contention that setting aside the Bad Leaver provisions as unconscionable would not affect**
entitlement to the shares and loan notes was that the leaver provisions sought to be set aside and the Share
Purchase Agreement under which the shares and loan notes were awarded were contained in two separate
agreements. Setting aside the agreement which contained the leaver provisions said to be unconscionable would
not affect the Share Purchase Agreement under which the shares and loan notes were claimed.

**[33] The Claimant with the assistance of Mr Nosworthy developed a legally sophisticated argument on**
unconscionability. They cited Lloyds Bank Ltd v Bundy [1974] EWCA Civ 8 in which it was held that:

“… English law gives relief to one who, without independent legal advice, enters into a contract or transfers
property for a consideration which is grossly inadequate, when his bargaining power is grievously impaired by
reason of his own needs or desires, or by his own ignorance or infirmity, coupled with undue influences or
pressures brought to bear on him for the benefit of the other.”

Reference was also made on behalf of the Claimant to Alec Lobb (Garages) Ltd v Total Oil (GB) Ltd [1983] 1 WLR
87, referred to in Brian Strydom, in which it was held that unconscionability involves a process whereby:

“… one party has been at a serious disadvantage to the other, whether through poverty, or ignorance, or lack
of advice, or otherwise, so that circumstances existed of which unfair advantage could be taken … secondly,
this weakness of the one party has been exploited by the other in some morally culpable manner … and thirdly,
the resulting transaction has been, not merely hard or improvident, but overreaching and oppressive. …”

**[34] It was submitted that the ET should have considered whether the Claimant had been treated fairly. If they had**
done so they would have concluded that it was unfair to deprive an employee who gave notice to terminate
employment of shares and loan notes whereas an employee whose contract was terminated by the Respondent,
including for their breach of contract, would retain theirs.

**[35] The Claimant contended that in accordance with the judgment in** _Yam Seng PTE Ltd v International Trade_
_Corporation Ltd_ _[2013] EWHC 111 (QB) the contracts entered into by the Claimant with the Respondent were_
“relational”. They involve expectations of loyalty which are not legislated for in the express terms of the contract. In
her skeleton argument the Claimant contended that the Respondent was not dealing fairly and used undue
influence over her as an employee to impose the Leaver Provisions which arose from an inequality of bargaining
power.

**[36] Mr Harris contended that the ET has no jurisdiction to consider the contract or deduction of wages claims. The**
breach of contract and deduction from wages claims were based on a contention that the leaver provisions in the
Articles of Association were unconscionable and therefore inapplicable. Mr Harris submitted that although
connected to her employment with the Respondent the payments sought under the breach of contract claim relate
to the Claimant's capacity as a shareholder and not as a worker.

**[37] Counsel submitted that the ET had no jurisdiction to set aside or rewrite a transaction. It was said that this is**
what the Claimant was seeking. The deferred consideration under which the entitlement arose was a benefit arising
on sale of shares not as a worker. The Share Purchase Agreement as well as the Principal Agreement to which the
Claimant adhered by a Deed of Adherence on 26 July 2013 contained a definition of “Bad Leaver” which included a
Vendor who voluntarily resigns. The Claimant fell within this definition. The Claimant held her shares and loan notes
on the terms of the Principal Agreement and the Articles of Association. It was said that the Claimant was asking
the ET to rewrite the contract and that it had no jurisdiction to do so.

**[38] Moreover it was submitted that, as the ET found in para 78, the remedy which the Claimant sought would**
result in the setting aside of the entire deferred consideration provision. The _Extension of Jurisdiction provisions_
gave no power to ETs to make such an order. Nor did a claim to set aside a contractual provision fall within a claim
under ERA s 13.

**[39] Even if the ET had jurisdiction to entertain the Claimant's claims, Mr Harris submitted that the Bad Leaver**
provisions were not unconscionable. The Claimant had not been compelled to accept the gift of the 2%


-----

shareholding, the sale of which included the deferred consideration provisions. Those provisions included a cash
consideration which was paid. Mr Harris referred to the judgment of Mr Justice Blair in Brian Strydom v Vendside
_Ltd [2009] EWHC 2130. Mr Justice Blair held at para 36 that three elements have to be satisfied before the burden_
passes to the other party to show that the transaction was fair, just and reasonable. Mr Harris contended that none
of these elements was present in the case of the Claimant let alone all three as required.

**[40] Mr Harris commented that it would have been better if the ET had referred to the Contract of Employment.**
Further counsel recognised that the ET did not expressly deal with the loan notes. However as the forfeiture of the
loan notes arose from the same contractual Bad Leaver provisions as applied to the shares it was submitted that
this omission made no difference to the outcome.

_DISCUSSION - GROUND 1_

**[41] The Claimant entered into a contract of employment with the Respondent on 25 July 2013. The ET did not find**
nor is it suggested by the Claimant that that employment was conditional in entering into the Share Purchase
Agreement and Deed of Adherence. The contract of employment included no requirement to sell her 2%
shareholding in COL to the Respondent.

**[42] The Share Purchase Agreement executed as a Deed included the terms upon which the earn-out shares and**
loan notes become payable. By the date of giving notice the third tranche of earn-out shares and loan notes had
become payable. The Bad Leaver provision in the Share Purchase Agreement was not relied upon by the
Respondent. It did not apply as the deferred consideration became payable before the Claimant gave notice of
termination of her employment.

**[43] It was a condition of the issue to her of the shares and loan notes, the subject of the Share Purchase**
Agreement, that the Claimant enter into the Deed of Adherence. The Claimant did so on 26 July 2013. In our
judgment, therefore, the shares and loan notes in the numbers and at the times provided in the Share Purchase
Agreement were issued and held on the terms agreed between the parties, the Principal Agreement.

**[44] In our judgment, therefore, the terms under which the Claimant held the shares and loan notes and what**
would happen to them on her terminating her employment were those set out in the Principal Agreement. The
Claimant was a “Bad Leaver” as defined in the Principal Agreement. Clause 8.1 of the Principal Agreement
provided that the parties, which by the Deed of Adherence included the Claimant, agreed to comply fully with the
Articles of Association. The Respondent dealt with the Claimant's shares and loan notes in accordance with the
Articles of Association.

**[45] Accordingly in our judgment the ET did not err in failing to hold that the Leaver Provisions contained in the**
Principal Agreement formed a separate bargain and did not apply to the deferred consideration provisions in the
Share Purchase Agreement.

**[46] Further in our judgment the Bad Leaver provisions in the Share Purchase Agreement and in the Principal**
Agreement are not in conflict. The Bad Leaver provisions in the Share Purchase Agreement provide that no earnout benefits become payable after the termination of a Bad Leaver's employment. The shares and loan notes
already payable are held on the terms of the Principal Agreement and Articles of Association which determine in the
case of the shares their value on compulsory transfer, and in the case of loan notes, their forfeiture.

**[47] We agree with Mr Nosworthy that the Shares and Loan Notes were not a gift. They were deferred**
consideration for the purchase of the Claimant's 2% shareholding in COL. However the consideration provided by
the Claimant was the transfer of her 2% shareholding, not as suggested by Mr Nosworthy, the provision of nonmonetary consideration, her work. The consideration for the Claimant's services was that provided in her contract of
employment. The Share Purchase Agreement as supplemented by the Principal Agreement formed a separate
bargain governing the transfer and holding of shares and loan notes.

**[48] The Claimant with the help of her father, Mr Nosworthy contended that the Bad Leaver provisions in the**
Principal Agreement and the Articles of Association should be set aside as unconscionable.


-----

**[49] As has been established in Alec Lobb, more recently relied upon by Mr Justice Blair in Brian Strydom in para**
36:

“… before the court will consider setting a contract aside as an unconscionable bargain, one party has to have
been disadvantaged in some relevant way as regards the other party, that other party must have exploited that
disadvantage in some morally culpable manner, and the resulting transaction must be overreaching and
oppressive. No single one of these factors is sufficient - all three elements must be proved, otherwise the
enforceability of contracts is undermined (see the reasoning in Goff & Jones, The Law of Restitution, 7th edn,
para 12-006). Where all these requirements are met, the burden then passes to the other party to satisfy the
court that the transaction was fair, just and reasonable (Snell's Equity, 31st edn, para 8-47).”

The court in _Alec Lobb gave examples of the first element: serious disadvantage whether through poverty, or_
ignorance or lack of advice or otherwise leaving the individual vulnerable to unfair disadvantage. There is no
suggestion in the findings of fact that any of these elements was present in this case. There was no evidence that
the Claimant did not have access to legal advice. There is no suggestion that the Claimant did not or could not have
taken advice before entering into the various agreements she entered into in July 2013. Indeed by cl 19.3 of the
Share Purchase Agreement the Claimant and the other vendors warranted that they had taken professional advice
and agreed that the restrictions in cl 19 were reasonable.

**[50] Whether or not the ET were right to hold that if the bargain under which the “Bad Leaver” provisions were**
relied upon by the Respondent was unconscionable the entire Share Purchase Agreement would be set aside, in
our judgment the contention advanced on behalf of the Claimant does not surmount even the first of the three
hurdles in Brian Strydom. Mr Harris rightly relied upon Alec Lobb and Brian Strydom. The findings of the ET would
not support a finding that the agreement between the parties dealing with shares and loan notes in the event that
the Claimant was a Bad Leaver was unconscionable.

**[51] Mr Harris contended that the Claimant's claim did not fall within the jurisdiction of the ET under the Extension**
_of Jurisdiction Order as the remedy sought was a setting aside of a contractual provision rather than for a certain_
sum or for damages for breach of a contract connected with employment. As acknowledged in his skeleton
argument the claim for the value of shares and loan notes under the Share Purchase Agreement is under a
“contract connected with employment” within the meaning of art 3(a) and the _[Employment Tribunals Act 1996 s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6190-TWPY-Y07H-00000-00&context=1519360)_
3(2). Subject to the Bad Leaver provisions the earn-out payments are dependent upon the Claimant remaining in
the Respondent's employment until after 31 December 2015. The claim was therefore brought under a contract
“connected with employment”. In our judgment the means of advancing that claim, by disapplying the Bad Leaver
provisions, does not alter the claim itself.

**[52] However, in our judgment the claim of the Claimant for payment of or in respect of her earn-out shares and**
loan notes does not fall within ERA s 23 as a deduction from wages within the meaning of s 27. Section 27 provides
that wages mean:

“… any sums payable to the worker in connection with his employment …”

including “any fee, bonus, commission, holiday pay or other emolument referable to his employment” but excluding
by reason of s 27(2)(e) “any payment to the worker otherwise than in his capacity as a worker”. Whilst the claim in
respect of earn-out shares and loan notes could be said to be payable in connection with employment, they are
deferred consideration for the sale by the Claimant of her shares in COL. They were provided to the Claimant as a
vendor of shares, not in her capacity as a worker.

**[53] Notwithstanding the conclusion that the ET had jurisdiction under the Extension of Jurisdiction Order to hear**
the Claimant's claim in respect of shares and loan notes, ground 1 of the appeal does not succeed.

_GROUND 2_


-----

**[54] The Claimant contended that the ET erred in concluding at para 72 that the Respondent acted in good faith**
with regards to dealing fairly and exercising a duty of care in applying the Bad Leaver provisions when requested to
use its discretion, as permitted by the Articles of Association, to treat the Claimant as a Good Leaver.

**[55] Mr Nosworthy and the Claimant contended that applying** _Yam Seng PTE Ltd, treating her as a Bad Leaver_
would be regarded as commercially unacceptable by reasonable and honest people. It was submitted that
reasonable people would view as unreasonable treating an employee who gave notice to terminate her employment
as a Bad Leaver when an employee who was dismissed, including someone who is dismissed for breach of
contract, is treated as a Good Leaver. However it is to be noted that a relevant person who is dismissed summarily
for cause is not treated as a Good Leaver.

**[56] Both Mr Nosworthy and Mr Harris commented on the absence of reference in the reasoning of the ET to the**
forfeiture of Loan Notes. Mr Nosworthy commented on the rationale referred to by the ET for shares held by a
departing employee who has no further active interest in the success of the company to be acquired by the
Respondent. He submitted that this rationale does not apply to the Loan Notes. These provide for the payment of a
fixed sum and interest. Their value is not dependent upon the success of the Respondent. The rationale for
transferring shares to the Respondent referred to by the ET in para 73 did not apply to loan notes.

**[57] Further it was contended that the Articles of Association gave the Remuneration Committee a discretion under**
art 15.11.2 to reclassify a Bad Leaver as a Good Leaver. It was submitted that the ET erred in failing to hold that the
Remuneration Committee acted unfairly in failing to do so.

**[58] Accordingly it was submitted that the ET erred in failing to hold that the Respondent had not acted fairly or in**
good faith in treating the Claimant as a Bad Leaver.

**[59] Mr Harris pointed out that pursuant to the Share Purchase Agreement the Claimant had been paid all the**
earn-out cash sums which were due in respect of each specified date albeit that part of the final amount was paid
late. These sums were not clawed back under the Bad Leaver provisions.

**[60] Mr Harris contended that the ET did not err by failing to hold that the Respondent did not act reasonably in**
failing to exercise its discretion to treat the Claimant as a Good Leaver. He referred to para 72 in which the ET held
that the Respondent was entitled to treat the Claimant as a Bad Leaver. The ET referred to the arguments
advanced before them that the Respondent was under an obligation to act in good faith, to deal fairly and to
exercise a duty of care in applying the Articles of Association. The ET did not err in concluding that the Respondent
was entitled to treat the Claimant as a Bad Leaver.

**[61] In our judgment the ET did not err by failing to hold that the Respondent acted unfairly or unreasonably by**
failing to exercise, by the Remuneration Committee, its discretion under art 15.11.2 to treat the Claimant as a Good
Leaver. The Articles to which the Claimant had subscribed were clear. An employee who gave notice to terminate
their employment was a “Bad Leaver”. However curious that may be, it was clearly spelled out in the Articles. There
were no exceptional circumstances which would be said to call into question the decision of the ET that the
Respondent was entitled to treat the Claimant as a Bad Leaver.

**[62] Ground 2 of the appeal does not succeed.**

_GROUND 3_

**[63] The Claimant contended that the ET erred by failing to hold that the Bad Leaver provisions in the Articles of**
Association were unenforceable as a penalty. Mr Nosworthy and the Claimant referred to cl 7.23 of the Principal
Agreement which provides:

“7.23. Each Manager holding Management Loan Notes severally covenants that he shall not become a Bad
Leaver. …”


-----

**[64] It was submitted on behalf of the Claimant that as she was a Bad Leaver Miss Nosworthy was in breach of cl**
7.23. The consequences were forfeiture of her Loan Notes and transfer of her shares for no value. It was said that
such actions were a penalty.

**[65] Reliance was placed on the joined cases of Cavendish Square Holdings BV v Talal El Makdessi; ParkingEye**
_Ltd v Beavis [2016] AC 1172in which three of the Supreme Court Judges held at para 32 that the:_

“… true test [of a penalty] was whether the impugned provision is a secondary obligation which imposes a
detriment on the contract-breaker out of all proportion to any legitimate interest of the innocent party in the
enforcement of the primary obligation. The innocent party can have no proper interest in simply punishing the
defaulter. His interest is in performance or in some appropriate alternative …”

Reference was also made to the speech of Lord Hodge in which he said at para 255:

“I therefore conclude that the correct test for a penalty is whether the sum or remedy stipulated as a
consequence of a breach of contract is exorbitant or unconscionable when regard is had to the innocent party's
interest in the performance of the contract. …”

**[66] The Claimant contended that giving notice to terminate her contract of employment caused the Respondent no**
loss. Accordingly the imposition of the double penalty of forfeiture of the Loan Notes and repurchase of the Shares
at minimal value was out of all proportion to any loss caused by her breach of contract by being a Bad Leaver.

**[67] Mr Harris referred to para 80 of the Judgment of the ET. The Respondent did not assert or rely on any breach**
of contract by the Claimant. The forfeiture of the Loan Notes and transfer of the Claimant's Shareholding were
consequences of being a Bad Leaver. The definition of “Bad Leaver” in art 15.9.2(a) does not depend on a breach
of contract. Its effect is not the consequence of a breach of a primary obligation. Mr Harris referred to Makdessi in
which Lord Neuberger held at para 13:

“… There is a fundamental difference between a jurisdiction to review the fairness of a contractual obligation
and a jurisdiction to regulate the remedy for its breach. Leaving aside challenges going to the reality of
consent, such as those based on fraud, duress or undue influence, the courts do not review the fairness of
men's bargains either at law or in equity. The penalty rule regulates only the remedies available for breach of a
party's obligations, not the primary obligations themselves. …”

**[68] Mr Harris summarised his contention on the effect of Makdessi in para 21 of his skeleton argument:**

“21. The fact that performance of the contract by a party in a particular way may result in a less advantageous
outcome for that party than performance of the contract in a different way, does not mean that a sanction is
being applied or that the party is being treated as effectively having breached the contract. To apply such an
approach would run counter to the reasoning of the Supreme Court in Makdessi.”

**[69] The ET held at para 81 that the answer to the allegation that the imposition of the Bad Leaver provisions**
amounted to a penalty was that these did not follow any breach of contract by the Claimant. The ET did not err in
concluding that the Respondent was not seeking to rely on cl 7.23 of the Principal Agreement. They did not seek to
assert that the Claimant was in breach of contract. The Respondent was simply applying the provisions of arts 15.6
and 15.7 as a consequence of the Claimant giving notice to terminate her contract of employment.

**[70] Although it does not affect the determination of appeal ground 3, it is to be noted that the consequence of a**
breach of cl 7.23 of the Principal Agreement is different from the consequence of being a Bad Leaver dealt with
under the Articles of Association. Clause 7.23 entitles the Respondent to claim an amount equal to the aggregate
amount in respect of Loan Notes held by him. Such claim is satisfied by a set off. No reference is made in cl 7.23 to
shares. The Respondent dealt with the Claimant's shares in accordance with the provisions of the Articles of
Association. Pursuant to art 15.7.2 the Bad Leaver forfeits Loan Notes in whatever way the Remuneration
Committee may determine. Although the ET made no express finding about the way in which the Claimant's Loan


-----

Notes were dealt with there is no suggestion that they were dealt with as set out in cl 7.23 of the Principal
Agreement.

**[71] The ET did not err in holding that the Respondent did not rely upon any breach of contract as entitling them to**
apply the Bad Leaver provisions. These were applied as a consequence not of any breach of contract but because
of the terms of the Articles of Association.

**[72] Ground 3 of the appeal does not succeed.**

**[73] No issue was raised in the Notice of Appeal as to the construction of the Bad Leaver provisions.**

_THE AMENDMENT TO THE GROUNDS OF APPEAL_

**[74] On 18 September 2018 His Honour David Richardson granted the Claimant permission to amend the Notice of**
Appeal in terms of the document entitled “New Point of Law - Restraint of Trade”. The Order states:

“… For the avoidance of doubt, this grant of permission does not prevent the Respondent from arguing that the
point is not open to the Appellant because it was not taken below.”

**[75] The Claimant formulated ground 4 as follows:**

“1. The Claimant contends that the 'Leaving Covenant' of the Investment Agreement, the 'Bad Leaver
Provisions' and the Valuation and Vesting mechanism included within these provisions constitute a Restraint
on Trade by creating a strong economic disincentive to leave one's employment, in line with the ruling in 20:20
_London Ltd v Riley_ _[2012] EWHC 1912 (Ch)._

…

3. The Claimant argues that the Leaving Covenant, the Bad Leaver Provisions and the Valuation mechanism
included within these provisions constitute a financial incentive to an employee not to exercise a right to
terminate his or her existing employment, and as such that the arrangement constitutes a Restraint of Trade.

4. Furthermore, the measures go far beyond the Respondent's business justification for the Leaver Provisions
and as such are not designed to protect a legitimate interest and are unreasonable.”

**[76] The Claimant contended that the “Leaving Covenant” in cl 7.23 of the Principal Agreement and the Bad**
Leaver, Valuation and Vesting provisions in the Articles of Association constitute a Restraint of Trade by creating a
strong economic disincentive to leave employment. It was said that they go far beyond the Respondent's business
justification for the Leaver Provisions and are not designed to protect a legitimate interest and are unreasonable,
one-sided, unfair and oppressive.

**[77] Although the ET made no findings of fact on the issues, the Claimant sought to suggest that the Respondent's**
business justification for the Leaver Terms was the subject of oral evidence on the issue of penalty. The Claimant
suggested that the ET referred to the business justification for these terms in para 73 of their Judgment. The
Claimant referred to paras 21 and 22 of the Respondent's Answer to the original grounds of appeal as being
relevant to the justification for the Leaver Provisions.

**[78] Mr Nosworthy contended that in accordance with the overriding objective, the EAT should exercise our**
discretion to allow the restraint of trade argument to be taken on appeal. He said that the Claimant was selfrepresented and this was a complex area. He contended that the circumstances were exceptional and the new
point should be permitted to be taken. Mr Nosworthy referred to Rance v Secretary of State for Health _[[2007] IRLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W4DB-00000-00&context=1519360)_
_[665. Also he relied upon the conclusion that the contract entered into by a young Wayne Rooney was held in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W4DB-00000-00&context=1519360)_
_Proactive Sports Management Ltd v Rooney_ _[2010] EWHC 1807 (QB) to be a restraint of trade as was the contract_
in Schroeder Music Publishing Co Ltd v Macaulay [1974] 1 WLR 1308.


-----

**[79] Mr Harris for the Respondent contended that the EAT should not exercise our discretion to permit the new**
ground of appeal that the Bad Leaver covenant was a restraint of trade to be raised. Both parties are agreed that
this is a new point raised for the first time following the r 3(10) Hearing. He submitted that there are no exceptional
circumstances which would warrant the exercise of discretion to allow the new point to be taken. Further the issue
of whether the Bad Leaver provisions were an unjustified restraint of trade would require consideration by an ET on
the basis of evidence and findings of fact relevant to that issue.

**[80] Counsel for the Respondent referred to the judgment of the EAT in The Blackpool Fylde and Wyre Society for**
_the Blind v Begg UKEAT/0035/05 in which HH Judge McMullen QC set out a passage from his judgment in Orthet_
_Ltd v Sarah Vince-Cain UKEAT/0801/03 from which the Court of Appeal in 2004 refused permission to appeal and_
in which the EAT held:

“29. [as for] … 5 Court of Appeal and 4 EAT authorities dealing with the issue of new points, it is fair to say that
they point in one direction, which is that new points may only in exceptional circumstances be raised at the
EAT. …”

The same point was made in _Secretary of State for Health v Rance_ _[[2007] IRLR 665 relied upon by Mr Harris.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3R1-DYPB-W4DB-00000-00&context=1519360)_
Counsel submitted that the discretion to allow a new point to be raised for the first time is only to be exercised in
exceptional circumstances. There is nothing exceptional justifying raising this new point, that the Bad Leaver
provisions are a restraint of trade, at the appeal stage.

**[81] Further Mr Harris submitted that** _20:20 relied upon by the Claimant to support the exercise of discretion to_
allow the new restraint of trade point to be taken did not support the current application. That was not a case
concerning proceedings before an Employment Tribunal and it involved a summary judgment application. The court
was of the view that the matter needed to proceed to trial to consider all the evidence and argument on the issue.
_20:20 illustrates what is plainly the case, that an issue of restraint of trade requires evidence and findings of fact on_
the purpose of the provision under scrutiny, its justification and a decision if it is a restraint, whether it is reasonable
in all the circumstances.

**[82] Mr Harris also submitted that in any event the Bad Leaver provisions were not a restraint of trade. The**
Claimant could have rejected the offer to purchase her shares. Further the Share Purchase Agreement did not
prevent her from working elsewhere. Counsel accepted that there was some limited overlap of the restraint of trade
arguments with those on penalty, but evidence would have been required on whether the Bad Leaver provision was
a restraint of trade and if so whether it was reasonable in the circumstances.

**[83] Counsel submitted that in any event the ET did not have jurisdiction to determine a claim that the Bad Leaver**
provisions represented a restraint of trade. Mr Harris contended that a claim which relied on an argument that a
term was an unreasonable restraint of trade could not be pursued in an ET by reason of art 5(e) of the Extension of
_Jurisdiction Order._

**[84] In our judgment art 5(e) of the Extension of Jurisdiction Order would not have prevented the Claimant from**
raising in the ET an issue that the Bad Leaver provisions were a restraint of trade. Article 5 applies to a claim for a
breach of a contractual term of certain descriptions including “a term which is a covenant in restraint of trade”. The
claim made by the Claimant was a contract claim for sums of money in respect of shares and loan notes. It was not
a claim for a breach of a contractual term which is a covenant in restraint of trade. The restraint of trade argument
sought to disapply a barrier to the claim. There was no claim based on a breach of the Bad Leaver provisions.

**[85] In giving permission to amend the Notice of Appeal to include a ground of appeal that the Bad Leaver**
provisions were an unreasonable restraint of trade, HH David Richardson did so on the basis that the Respondent
could contend that the argument is not open to the Claimant to do so because the point was not taken in the ET.
HH David Richardson referring to _Rance recognised that this potentially was a very serious problem for the_
Claimant. The Judge considered it arguable that discretion should be exercised to allow the new point to be taken if
the view were that (1) the point is closely allied to the points which were taken below, and (2) the failure to take the
point was not tactical but rather resulted from a lack of specialist legal advice and appreciation of the law.


-----

**[86] The EAT has a discretion to allow amendment of grounds of appeal. Whilst the decision whether to grant such**
permission must depend upon the particular facts and circumstances, the parameters within which such discretion
is to be exercised have been explained in several authorities.

**[87] In para 48 of Rance the EAT cited the passage from the judgment of the Court of Appeal in Jones v Governing**
_Body of Burdett Coutts School_ _[[1998] IRLR 521 in which Robert Walker LJ held at para 20:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:565N-Y3S1-DYPB-W092-00000-00&context=1519360)_

“20. These authorities show that although the Employment Appeal Tribunal has a discretion to allow a new
point of law to be raised (or a conceded point to be reopened) the discretion should be exercised only in
exceptional circumstances, especially if the result would be to open up fresh issues of fact which (because the
point was not an issue) were not sufficiently investigated before the industrial tribunal. …”

In para 50 of Rance the EAT set out principles of law derived from the authorities on the exercise of discretion by
the EAT to permit a new point of law to be argued. These include:

“(3) The discretion is exercised only in exceptional circumstances;

(4) It would be even more exceptional to exercise the discretion where fresh issues of fact would have to be
investigated.”

**[88] The contentions on behalf of the Claimant concentrated more on the arguments on the new issue rather than**
whether the court should exercise their discretion to allow the restraint of trade ground of appeal to be advanced at
all.

**[89] By the additional ground of appeal the Claimant contends that the Bad Leaver and associated provisions**
constitute a financial incentive not to exercise a right to terminate the contract of employment and that this financial
incentive constitutes a restraint of trade. Further it is said that the measures go far beyond the business justification
for the Bad Leaver provisions, are not designed to protect a legitimate interest of the Respondent and are
unreasonable.

**[90] It can be readily seen that this new ground of appeal raises points of law which were not the subject of**
submissions before or decision by the ET. When does a financial incentive not to exercise a contractual right to
terminate employment constitute a restraint of trade? Further, if such were to be found, determining the issue of
business justification for a restraint, and its reasonableness requires relevant findings of fact. Decisions as to
justification and reasonableness would be determinative of the enforceability of the restraint.

**[91] Mr Nosworthy and the Claimant submitted that the ET heard evidence relevant to the restraint of trade issue**
when considering penalty. Whatever evidence may or may not have been given, the Employment Appeal Tribunal
can only base their deliberations on findings of fact. The findings of fact made by the ET are far from all of those
which would be required for determining the new issue.

**[92] The possibility referred to by HH David Richardson that the restraint of trade point may not have been taken**
from a lack of specialist legal advice and appreciation of the law was rightly not adopted or pursued by Mr
Nosworthy and the Claimant. There was no evidence that the Claimant had no access to legal advice. Indeed in
para 19.3 of the Share Purchase Agreement she had agreed that having taken professional advice the restrictions
in that clause which could be said to be a restraint of trade were reasonable and necessary for the protection of the
legitimate business interests of the Respondent.

**[93] In our judgment whatever may be the demerits or merits of the new ground of appeal, as anticipated by HH**
David Richardson, the argument advanced by the Respondent, that it is not open to the Claimant as it was not
taken below, succeeds. The circumstances in which the new point is sought to be advanced are not exceptional.
The discretion of the EAT is not exercised to allow it to proceed.

**[94] All grounds of appeal are dismissed.**

Appeal dismissed


-----

**End of Document**


-----

