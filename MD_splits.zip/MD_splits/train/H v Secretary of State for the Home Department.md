# H v Secretary of State for the Home Department [2018] EWHC 2191 (Admin)

Queen's Bench Division, Administrative Court (London)

Nicol J

16 August 2018Judgment

**Samantha Knights QC (instructed by Duncan Lewis) for the Claimant**

**John-Paul Waite (instructed by Government Legal Department) for the Defendant**

Hearing dates: 18th & 19th July 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

IMAGE NOT AVAILABLE

**Mr Justice Nicol :**

1. The central issue in this application for judicial review is whether the Secretary of State for the Home
Department ('SSHD') breached his legal duties to provide support and assistance for the Claimant who had
been trafficked as a youngster into the UK. The Claimant also alleges that the treatment he received is
illustrative of systemic failings in the treatment of victims of trafficking such that the Court should grant
declaratory relief.

**The factual background**

2. The Claimant is a Vietnamese national. He was born on 7th May 1996. He claims that he arrived in the
UK in early 2013. He was then 16 or 17. His case, subsequently accepted by the Defendant, was that he
was trafficked to work on a cannabis growing unit. He also alleges that the Vietnamese gang who trafficked
him tortured and sexually abused him.

3. On 25th October 2013 he was arrested in Chesterfield and charged with production of cannabis
contrary to _[Misuse of Drugs Act 1971 s.4(2)(a). He was then 17. He was interviewed that night and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XS0-TWPY-Y0KF-00000-00&context=1519360)_
effectively admitted his involvement in the production of cannabis. He was held overnight at the police
station. He could speak little English. He was produced before a magistrates' court the following day and
was released or remanded into the care of a local authority who placed him in a hotel.

4. On 30th October 2013 the Claimant absconded.

5. He remained at large until 11th February 2016 when he was arrested in Liverpool and it was discovered
that there were outstanding criminal proceedings against him.

6. On 12th February 2016 the Claimant was interviewed by an Immigration Officer who authorised his
detention under _Immigration Act 1971 Schedule 2 paragraph 16(2). The Claimant said he had a fear of_
returning to Vietnam and described how he had been trafficked to the UK. He underwent a screening
interview.


-----

7. The Immigration Officer, also on 12th February 2016, referred the Claimant for consideration as a
trafficked individual. He completed a National Referral Mechanism ('NRM') form that day. By then the
Claimant was 19. The Immigration Officer used a form appropriate for an adult victim of trafficking. At the
time when he had been trafficked, the Claimant was still a minor. There is a separate form for minors who
claim to be the victims of trafficking because the relevant criteria in their case are different. The form used
in the Claimant's case was therefore inappropriate.

8. On 13th February 2016 the Claimant was remanded in custody by the Derbyshire Magistrates' Court,
but on 23rd February 2016 he was transferred to a Young Offenders' Institution.

9. The next stage of the NRM is for the Competent Authority (in this case the Home Office) to make a
decision as to whether there are reasonable grounds to believe that the individual was a victim of
trafficking.

10. On 25th February 2016 the Home Office decided that there were reasonable grounds to believe that
he had been trafficked.

11. The 'reasonable grounds' decision has consequences. The first is that steps have to be taken to reach
a conclusive decision as to whether he was trafficked. The hope (not always achieved and not achieved in
this case) is that the Conclusive Grounds decision will be taken as soon as possible after the expiration of
the 45 day 'recovery and reflection period' which follows the making of a reasonable grounds decision.
There are other consequences which I will defer describing until I come to the law.

12. By 14th/15th March 2016 the Claimant had instructed Immigration solicitors, Malik and Malik, who on
that date notified the Defendant that the Claimant wished to claim asylum.

13. On 16th March 2016 the Claimant appeared at Derby Crown Court. He pleaded guilty that day to the
charge of producing cannabis. He was sentenced by HHJ Bennett to 8 months detention in a Young
Offenders' Institution.

[14. On the 24th March 2016 the Defendant had made a decision to deport the Claimant under Immigration](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8J0-TWPY-Y0MX-00000-00&context=1519360)
_[Act 1971 s.5 because, in view of his criminal conviction, his deportation was considered to be conducive to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8J0-TWPY-Y0MX-00000-00&context=1519360)_
the public good – see _[Immigration Act 1971 s.3(5)(a). It was recognised that the Claimant had an](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y09P-00000-00&context=1519360)_
outstanding asylum/ human rights claim. He was invited to make any further submissions in relation to that
claim within a specified time.

15. As is usual, of the 8 month sentence, the Claimant was required to serve only half. That period came
to an end on 14th June 2016. The Claimant was then 'released' on licence for the remainder of his
sentence. In his case 'release' was notional because he continued to be detained under Immigration Act
powers. Initially, his detention continued under _Immigration Act 1971 Schedule 2 paragraph 16(2). From_
14th July 2016 his detention continued under 1971 Act Schedule 3 paragraph 2(2), pending the making of
a deportation order.

16. The Claimant's complaints in relation to support and assistance principally concern the inadequacies
of his medical treatment. I shall postpone giving an account of his dealings with medical services while in
immigration detention until later in this judgment.

17. The Claimant was interviewed in relation to his asylum claim on 22nd June 2016.

18. On 9th August 2016, as the Competent Authority, the Home Office made a Conclusive Grounds
decision that the Claimant had _not been trafficked to the UK. In the reasons which accompanied the_
decision, it was clear that the Home Office had continued to treat the Claimant as an adult victim of
trafficking who therefore had to satisfy more stringent tests than if he had been treated (as he should have
been) as someone who had been a child when the trafficking took place.

19. By this stage the Claimant was instructing Wilsons, as his immigration solicitors. They requested that
the Claimant be granted temporary admission. That was refused on 22nd August 2016, as was an
application for bail on 4th October 2016.


-----

20. On 25th November 2016 an official within the Home Office appreciated that the Conclusive Grounds
Decision of the Home Office as the Competent Authority might have been wrong because the Claimant
had been a minor at the time of the alleged trafficking. Wilsons were told that the Conclusive Grounds
Decision would be reconsidered.

21. No fresh decision had been taken by the Competent Authority by 1st March 2017 when the Claimant
was served with a Deportation Order.

22. On 4th March 2017 the Defendant refused the Claimant asylum and humanitarian protection. The
human rights and asylum claims were certified.

23. On 23rd March 2017 the Claimant instructed Duncan Lewis as his immigration solicitors.

24. On 12th May 2017 the Home Office as the Competent Authority made a fresh Conclusive Grounds
Decision and this time decided that the Claimant was a victim of trafficking. However, the SSHD refused to
grant the Claimant discretionary leave.

25. On 17th May 2017 removal directions were set for 26th May 2017.

26. This application for judicial review was issued on 22nd May 2017. It sought to challenge (1) the
certification of the asylum and human rights claims; (2) the decisions to detain and maintain detention; (3)
the decision of the Competent Authority to refuse leave to remain in the UK (I take it that this was the
refusal of discretionary leave); and (4) the decision to remove the Claimant from the UK.

27. On 24th May 2017 the removal directions were deferred.

28. On 8th June 2017 Lavender J. ordered that the Claimant be anonymised for the purpose of these
proceedings which is why in this judgment he is referred to as 'H'. Lavender J. also set a timetable for the
Claimant to file and serve Amended Grounds for seeking Judicial Review.

29. On 13th June 2017 a judge of the First-tier Tribunal granted the Claimant bail. He was released on
14th June 2017.

30. The Claimant's Amended Grounds are dated 3rd July 2017. As before he challenged the refusal of
discretionary leave, the decision to certify his asylum and human rights claims and alleged that his
detention was unlawful. There followed a section headed 'Other breaches' which read:

'The Claimant submits that the Defendant's treatment of his case discloses a number of serious errors in
approach including (1) the failure to refer the Claimant to the NRM in October 2013; (2) the failure to
conduct a fully detailed interview as part of the NRM once he was referred; (3) the failure to assess the
Claimant correctly as a minor both at the stage of the reasonable grounds and initial conclusive grounds
decision; (4) the failure to notify the relevant authorities including the CPS of the reasonable grounds
decision when it was made; (5) the failure to adhere to decision-making deadlines; (6) the failure to provide
the Claimant with the required support and assistance following the reasonable grounds decision and at
any time thereafter. These failings give rise to claims for misfeasance, breaches of policy, a breach of
Article 4 ECHR and the EU Directive 2011/36/EU. They also expose a wider problem in the Defendant's
treatment of VOTs [Victims of Trafficking].'

31. I have mentioned that when the Claimant's asylum and human rights claim were refused on 4th March
2017, the claims were certified with the effect that the Claimant could not then appeal against the refusals
to the First-tier Tribunal. On 12th July 2017 the SSHD confirmed that he was willing to withdraw the
certification.

32. The Defendant's Acknowledgement of Service and Summary Grounds of Defence were filed on 4th
September 2017. The Claimant served a Reply and additional evidence on 22nd September 2017.

33. On 16th October 2017 Robin Puchas QC sitting as a Deputy High Court Judge refused the Claimant
permission to apply for judicial review. The Claimant renewed his application for permission on 23rd
October 2017 and, at a hearing on 23rd November 2017, Sir Stephen Silber, sitting as a Deputy High Court
Judge, granted permission to apply for judicial review on various grounds. The preamble to the order noted


-----

that the SSHD had agreed to withdraw the decision of 4th March 2017 to refuse the human rights and
asylum claims and their certification. The only one of the grounds for which permission was granted that is
still material is Ground 2 which, in summary, concerns the alleged insufficiency of support and assistance
with which the Claimant was provided.

34. The Claimant served Re-Amended Grounds for seeking judicial review on 4th December 2017.

35. On 2nd February 2018 by consent Mostyn J. ordered that there should be a rolled-up hearing of what
is referred to as Ground 4 (in summary whether declaratory relief should be granted in view of alleged
systemic failures in the procedures for dealing with trafficked individuals).

36. The Claimant served Re-Re-amended Statement of Facts and Grounds for seeking judicial review on
14th March 2018.

37. The Defendant eventually served detailed Grounds of Defence on 11th May 2018. Notably, the
Defendant accepted that the Claimant had been unlawfully detained throughout the period that he was in
immigration detention.

38. On 16th May 2018 Ouseley J. made further orders. The Defendant had by then conceded that the
Claimant had been unlawfully detained between 9th June 2016 and 16th June 2017 and that the Claimant
was entitled to substantial damages for that period. The SSHD had also accepted that the decisions of
12th and 16th May to refuse the Claimant discretionary leave had been unlawful. Ouseley J. made
declarations to this effect. He quashed the refusals of discretionary leave of 12th and 16th May 2017. He
also made directions. The Claimant was given permission to file further evidence in response to the
Defendant's Detailed Grounds. The Claimant took advantage of that permission and, on 15th June 2018
served his 3rd witness statement of that date.

39. On 27th June 2018 the Defendant decided to refuse the Claimant's applications for asylum and
humanitarian protection. However, that decision was withdrawn a few days later on 29th June 2018
because the SSHD realised that one of the medical reports which the Claimant had provided had been
overlooked.

40. On 6th July 2018 Ouseley J. ordered the Defendant to make a decision on the Claimant's application
for discretionary leave within 7 days. The SSHD did so and refused the application for discretionary leave
on 13th July 2018.

**The present position in summary**

41. The Claimant's present immigration position, therefore, is that:

i) The Competent Authority has decided that there are Conclusive Grounds that the Claimant is a victim of
human trafficking.

ii) His application for discretionary leave has been refused.

iii) His applications for asylum and humanitarian protection remain outstanding.

iv) There is an extant deportation order against him.

v) No removal directions are in place, nor could they be set until a final decision has been made on his
applications for asylum and humanitarian protection. Even if those applications are refused, the Claimant
would have a right of appeal to the First-tier Tribunal unless the claims were certified.

42. The Defendant has accepted that the Claimant is entitled to substantial (i.e. not merely nominal) damages for
unlawful detention. It is not my task to assess those damages, although the Claimant argues that findings in his
favour on Ground 2 will, or may be, of assistance in calculating what those damages will be. As part of his order on
16th May 2018 Ouseley J. also said that I should consider what directions, if any, should be given for the quantum
hearing of the unlawful detention claim.

43. The Claimant has permission to argue his Ground 2. I have to determine that. I have also to decide
whether to grant permission for Ground 4 and, if permission is granted, to rule on that matter as well.


-----

44. The Claimant has other outstanding proceedings. These are:

i) An application to the Court of Appeal Criminal Division for an extension of time and for permission to
appeal against his conviction and sentence on 16th March 2016. Those applications have yet to be
considered by a Single Judge.

ii) A claim against Morton Hall Immigration Removal Centre and the Secretary of State for Justice
(HQ18M01357). This concerns alleged failures by the Centre when it failed to take proper steps after the
Claimant complained that another male detainee had attempted to rape him.

iii) A claim against the Derbyshire Police (HQ18X01978).

iv) A claim against the Merseyside Police (HQ18X01977).

The last three matters are claims for damages. I am told that in each case the claim forms have been
issued but not yet served.

**Legal Obligations to Victims of Trafficking and Potential Victims of Trafficking**

45. The following sources need to be considered:

i) **_The Council of Europe Convention on Action against Trafficking in Human Beings 2005 ('the_**
**_Anti-Trafficking Convention')_**

I will comment below on the extent to which this Convention has been incorporated into English law by
statute. Primarily, though, the SSHD's position is that effect has been given to the Convention by the NRM
and other administrative measures to which I shall also refer below.

ii) Directive 2011/36/EU of the European Parliament and of the Council ('the Directive) 5th April 2011

The UK has opted into this measure. By Article 22 the date by which Members States must implement the
Directive is 6th April 2013. The Court of Appeal has said that consequently the Directive has direct effect –
see EM v SSHD [2018] EWCA Civ 1070 at [23].

[iii) Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

The only provision of this which might have a bearing on the Claimant's position is s.45 which provides a
defence in relation to certain offences for trafficking victims. That section came into force on 31st July
2015. The offence with which the Claimant was charged was committed before then. The Court of Appeal
has said that s.45 was not drafted to provide retrospective protection, but the regime developed by the
courts prior to then in respect of victims of trafficking may still be relevant – see R v Joseph (Verna) and
_others [2017] 1 Cr App. R. 33 CA. That, however, will be a matter for the Court of Appeal to consider._

iv) Home Office Guidance: 'Victims of Modern Slavery - Competent Authority Guidance' 21st March
**_2016_**

This was not the first edition of this Guidance (indeed, it speaks of the NRM having been set up in 2009)
and it has since been superseded, but it was the Guidance operative at the times material to the Claimant's
claim.

v)  The European Convention on Human Rights

Article 4 of the ECHR prohibits slavery, servitude and forced labour. In Rantsev v Cyprus and Russia App.
_No. 25965/04 (2010) EHRR 1, the European Court of Human Rights found that Article 4 required in certain_
circumstances Member States to take positive measures to ensure that the rights guaranteed by Article 4
were practical and effective. In some situations, this could require operational measures to be taken to
protect victims or potential victims and to provide for their physical safety while they were in their territories.
In Chowdhury v Greece App. No. 21884/15 the Court said at [110] that the protection measures included
'assisting victims in their physical, psychological and social recovery.'

[vi) Detention Centre Rules 2001 SI 2001 No. 238](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-S3R0-TX08-H0XH-00000-00&context=1519360)


-----

These apply to all immigration detainees, not just those who were the victims of trafficking.

a) Rule 34 provides,

'1.  Every detained person shall be given a physical and mental examination by the medical practitioner

[from r.33 this is a reference to a GP] ... within 24 hours of his admission to the detention centre.

2.  Nothing in paragraph (1) shall allow an examination to be given in any case where the detained person
does not consent to it.

3. If a detained person does not consent to an examination under paragraph (1), he shall be entitled to this
examination at any subsequent time upon request.

b) Rule 35 provides,

'....

3. The medical practitioner shall report to the manager on the case of any detained person who he is
concerned may have been the victim of torture.

4. The manager shall send a copy of any report under paragraphs (1), (2) or (3) to the Secretary of State
without delay.

5. The medical practitioner shall pay special attention to any detained person whose mental condition
appears to require it, and make any special arrangements including counselling arrangements) which
appear necessary for his supervision or care.'

46. Returning to the Directive, the operative provision of particular importance for Ground 2 is Article 11.
This is headed 'Assistance and support for victims of trafficking in human beings'. So far as material, it
says,

'1. Member States shall take the necessary measures to ensure that assistance and support are provided
to victims before, during and for an appropriate period after the conclusion of criminal proceedings in order
to enable them to exercise the rights set out in the Framework Decision 2001/220/ JHA [I was told that the
UK had opted into this Framework Decision as well] and in this Directive.

2. Member States shall take the necessary measures to ensure that a person is provided with assistance
and support as soon as the competent authorities have a reasonable grounds indication for believing that
the person might have been subjected to any of the offences referred to in Articles 2 and 3 [I take the
reference to 'criminal proceedings' in paragraph 1 of Article 11 to be to proceedings against the alleged
traffickers rather than against their victims].

3.  Member States shall take the necessary measures to ensure that assistance and support for a victim
are not made conditional on the victim's willingness to cooperate in the criminal investigation, prosecution
or trial, without prejudice to Directive 2004/81/EC or similar national rules.

4. Member States shall take the necessary measures to establish appropriate mechanisms aimed at the
early identification of, assistance to and support for victims, in cooperation with relevant support
organisations.

5.  The assistance and support measures referred to in paragraphs 1 and 2 shall be provided on a
consensual and informed basis, and shall include at least standards of living capable of ensuring victims'
subsistence through measures such as the provision of appropriate and safe accommodation and material
assistance as well as necessary medical treatment including psychological assistance, counselling and
information and translation and interpretation services where appropriate....

7. Member States shall attend to victims with special needs, where those derive in particular, from whether
they are pregnant, their health, a disability, a mental or psychological disorder they have, or a serious form
of psychological physical or sexual violence they have suffered.'

47. Ms Knights also relied on Article 14 of the Directive. This is entitled 'Assistance support to child
victims'. It says,


-----

'1.  Member States shall take the necessary measures to ensure that the specific actions to assist and
support child victims of trafficking in human beings, in the short and long term, in their physical and psychosocial recovery, are undertaken following an individual assessment of the special circumstances of each
particular child victim, taking due account of the child's views, needs and concerns with a view to finding a
durable solution for the child. Within a reasonable time, Member States shall provide access to education
for child victims and the children of victims who are given assistance and support in accordance with Article
11, in accordance with their national law.

2.  Member States shall appoint a guardian or a representative for a child victim of trafficking in human
beings from the moment the child is identified by the authorities where, by national law, the holders of
parental responsibility are, as a result of a conflict of interest between them and the child victim, precluded
from ensuring the child's best interest and/or from representing the child.

3.  Member States shall take measures, where appropriate and possible, to provide assistance and
support to the family of a child victim of trafficking in human beings when the family is in the territory of the
Member State. In particular, Member States shall, where appropriate and possible, apply Article 4 of
Framework Decision 2001/220/JHA to the family.

4.  This Article shall apply without prejudice to Article 11.'

48. It is right that the Claimant was a child when he was trafficked to the UK and when he was first
arrested in 2013. However, the period with which I am concerned is between 2016 and 2017. By then, the
Claimant was 19 and an adult. On its face, Article 14 of the Directive would not then have applied to him.
On the contrary, the reference to education in paragraph (1) and to a guardian or representative in
paragraph (2) strongly suggest that the Article is concerned exclusively with support for people who have
been trafficked and who are still children.

49. The Home Office Guidance specifically addresses the situation of 'potential child victims of **_modern_**
**_slavery who are now adults'. It says,_**

'In some cases, a potential victim of modern slavery may have been a victim as a child, but only identified
and referred into the NRM after reaching adulthood. In those circumstances, the Competent Authority
should treat the potential victim as having been a child at the time of the **_modern slavery incident and_**
follow the guidance governing children within the NRM decision making process. This means assessing
the case as if they were a child to make a reasonable grounds and conclusive grounds decision.

_However, an adult who enters the NRM who may have been a victim as a child would be treated as an_
_adult for the purposes of support, services and safeguarding, for the purposes of requiring consent to enter_
_the NRM and for immigration leave purposes.' [emphasis added]_

50. That, if I may respectfully say so, seems a sensible approach. It supports my view that the Claimant
can take no assistance from Article 14 of the Directive because, at the relevant time, he was not a child.

51. As is well known, the preamble to a Directive can provide assistance in its interpretation. In this case,
paragraphs 18 – 23 of the preamble to the present Directive concern the obligations to provide assistance and
support to victims of trafficking. Ms Knights QC on the Claimant's behalf drew my attention in particular to
paragraphs 18 and 21 which say,

'18.  It is necessary for the victims of trafficking in human beings to be able to exercise their rights
effectively. Therefore, assistance and support should be available to them before, during and for an
appropriate time after criminal proceedings. Member States should provide for resources to support victim
assistance, support and protection. The assistance and support provided should include at least a
minimum set of measures that are necessary to enable the victim to recover and escape from their
traffickers. The practical implementation of such measures should, on the basis of an individual
assessment carried out in accordance with national procedures take into account the circumstances,
cultural context and needs of the person concerned. A person should be provided with assistance and
support as soon as there is a reasonable grounds indication for believing that he or she might have been
trafficked and irrespective of his or her willingness to act as a witness...


-----

21.  Assistance and support measures should be provided to victims on a consensual and informed basis.
Victims should therefore be informed of the important aspects of those measures and they should not be
imposed on the victims. A victim's refusal of assistance or support measures should not entail obligations
for the competent authorities of the Member State concerned to provide the victim with alternative
measures.'

52. Article 11 of the Directive is broadly equivalent to Article 12 of the Anti-Trafficking Convention. In _R_
_(PK (Ghana)) v SSHD_ _[2018] EWCA Civ 98 at [46] the Court recorded the agreement of counsel for the_
Appellant and counsel for the SSHD that 'if a Conclusive Grounds decision is made, the state's obligations
under Article 12, once arisen, continue irrespective of any other rights they might have, unless and until the
victim is returned to another state.' Mr Waite, on behalf of the SSHD in the present case said that the
SSHD made the same concession in the present case.

**Ground 2: Alleged failure to provide proper support**

53. At the hearing, Ms Knights limited this ground to the alleged deficiencies in the support which the
Claimant had received in immigration custody. She did not pursue the complaint that, after his release, the
Claimant had not received the counselling with which he should have been provided.

54. In custody, of course, the Claimant was necessarily provided with accommodation and sustenance.
Ms Knights argued that he had not, however, been given the medical assistance which he ought also to
have received.

55. I shall summarise the principal events on which Ms Knights relied:

i) On 28th June 2016 the Claimant was transferred to IRC Morton Hall. He was seen by a nurse. Ms
Knights submits and Mr Waite accepted, that a nurse's examination would not be sufficient to comply with
Rule 34 of the Detention Centre Rules. However, the medical notes record 'Declined to see GP but is
aware of how to access healthcare if necessary.' As can be seen from the quotation of Rule 34 above, a
medical examination by a doctor is not required if the detained person does not consent to it.

ii) On 10th September 2016 the Claimant was transferred to IRC Tinsley House. He saw a nurse the
following day (11th September 2016). There was a note in his records that he did not attend the Arrivals
clinic appointment with the Tinsley House doctor on 12th September 2016.

iii) On 18th September 2016 the Claimant saw a staff nurse. The medical notes record that he brought
with him a solicitors' letter referring to bad treatment which he had suffered at the hands of traffickers. He
told the nurse that he had been a victim of torture, he had been assaulted with sticks and cut with a knife.
He also said he had been raped on several occasions. That was having an impact on his mental health
and he had nightmares when he remembered what had occurred. He was given an appointment for a Rule
35 assessment.

iv) On 20th September 2016, the Claimant was seen by Dr Oozeerally and the Claimant gave to him a
similar account of torture and ill treatment. Dr Oozeerally noted that the allegation was not of official
government torture and that there had been a delayed presentation. It seems that Dr Oozeerally was
applying criteria of 'torture' then favoured by UNCAT and the Home Office but which are no longer applied.
The same day the Claimant was seen in a mental health clinic.

v) On 25th September 2016 the Claimant was seen by a staff nurse and requested a r.35 appointment. He
was booked to see a Medical Officer on 28th September 2016. However, before that could happen he was
transferred back to IRC Morton Hall  on 26th September 2016.

vi) He was seen by a nurse on his arrival in IRC Morton Hall. He asked about the r.35 appointment. He
was advised to raise this with his solicitor.

vii) On 2nd October 2016 he was seen by Dr Sarah Fletcher. He reported that he had lost weight 'although
this appears stable'. Various blood tests were commissioned and the results were noted on 5th October
2016.


-----

viii) On 23rd February 2017 he was seen by a nurse who noted that the Claimant declined a mental health
assessment, but when the matter was followed up the Claimant denied having received an appointment
slip. He reported having felt in a low mood a few days previously but said he was feeling better now. He
asked for a further appointment with an interpreter. He did have another appointment with a doctor on 24th
February 2017 and another with a nurse on 27th February 2017. On the later occasion it was noted 'No
evidence of an underlying mental health problem requiring ongoing support from the mental health team at
this time.'

ix) On 9th March 2017 the Claimant was transferred to IRC Brook House. He was first seen by a nurse
who noted that his English was poor. Later that day he saw a doctor who recorded that the Claimant told
him he felt tired.

x) On 10th April 2017 he was again seen by Dr Oozeerally who noted that the Claimant claimed to have
been tortured. He said on one occasion he had tried to escape from the traffickers. They had applied
something sharp to his penis and had also implanted a device in him which they said would allow them to
track his whereabouts. The doctor noted scars which the Claimant showed him and a small pellet shaped
mass on his penis. A r.35 report was sent to the Home Office following this.

xi) On 30th May 2017 the Claimant was seen by Dr Frank Arnold, a specialist in problems of wound
healing, who had been instructed by Duncan Lewis. Dr Arnold provided a preliminary report on 7th June
2017 which said that the Claimant had physical evidence consistent with torture. Dr Arnold considered that
detention was having an adverse effect on the Claimant's mental health and that he had symptoms in
keeping with PTSD. Dr Arnold's final report dated 16th June 2017 was to like effect.

xii) On 15th September 2017 the Claimant's solicitors served the report of Dr Rachel Thomas, a consultant
clinical psychologist, who had interviewed the Claimant on 5th August 2017. She considered that the
Claimant had moderately severe symptoms of major depressive disorder.

56. Ms Knights argues that there were the following deficiencies in the support provided to the Claimant:

i) The support duty arose when the reasonable grounds decision was taken on 25th February 2016. Within
a short period of then, his welfare needs should have been assessed but were not.

ii) His solicitor wrote on 18th September 2016 to health care staff setting out his history of torture, but that
did not lead to an individualised assessment of his needs. Dr Oozeerally was not sufficiently probing with
his questions and there were interpretation problems.

iii) There had been four occasions when the Claimant had been transferred to a different immigration
removal centre. On each occasion he should have been provided with a r.34 examination by a doctor but
he was not.

iv) A r.34 examination was carried out on 10th April 2017 and did lead to a r.35 report by Dr Oozeerally,
but his conclusion that there was 'no evidence of severe mental health issues' did not bear scrutiny in light
of the contrary findings by Dr Arnold and Dr Thomas.

v) Although there were occasions when the Claimant declined to be seen by a doctor, those decisions
have to be seen in the context of his poor English which, in turn, meant that his decisions were not based
on full information.

57. On the Defendant's behalf, Mr Waite's starting submission was that Ground 2 served no useful
purpose. The Claimant was entitled to damages for unlawful detention and the Court considering the
quantification of his damages could take account of any additional loss caused by the alleged deficiencies
in his health care.

58. Mr Waite also argued that a distinction was to be drawn between the obligations imposed by, for
instance, Rules 34 and 35 and the requirements of support in the various sources of law on which the
Claimant relied as a victim of trafficking. There was nothing, for instance, in any of those sources which
required a victim of trafficking to be seen within 24 hours of his arrival in immigration detention.


-----

59. The Court of Appeal had considered the nature of the support obligation to victims of trafficking who
were detained in R (EM) v SSHD _[2018] EWCA Civ 1070. At [66] the Court had said this,_

'As to the element of the duty that requires the provision of necessary medical treatment including
psychological assistance, counselling and information, the treatment provided must respond to the welfare
needs of the individual objectively assessed in each case. The obligations arising under the Directive and
the Guidance, read alongside the Convention, do not extend to a requirement that the assessment of
treatment must be provided by specialists in trafficking, or that it be targeted towards one aspect of an
individual's needs (the consequence of trafficking) as opposed to his or her overall psychological needs.
The support duty calls for the provision of support, not the accomplishment of physical, psychological or
social recovery. There is nothing in the Convention, Directive or Guidance to warrant the extended
interpretation of the duty argued for by the Claimant. That interpretation would require significant additions
to the texts to prescribe specific obligations that would undoubtedly have been spelt out, had they been
intended.'

60. Mr Waite submitted that the differences between Dr Arnold and Dr Oozeerally was a clinical
disagreement between two doctors and the evidence did not allow me to decide that Dr Oozeerally's view
was defective or deficient.

61. The support duty must necessarily depend to some degree at least on self -reporting and it is apparent
from the health records that the Claimant did, on occasions, decline to see a doctor.

62. Overall, he submitted, the complaint in ground 2 had not been made out.

63. I agree with the Defendant that the Claimant has not made out Ground 2.

i) I agree with Mr Waite that a distinction has to be made between the obligations to the Claimant as a
victim of trafficking and other obligations which may arise. They are not hermetically sealed from each
other. Thus the r.34 examination may also serve as a means to assessing a victim of trafficking's needs for
medical services. However, r.34 may include obligations which do not have their counterpart in the support
obligations for victims of trafficking. Thus, for instance, r.34 requires an examination by a doctor (as
opposed to a nurse) and must be accomplished within 24 hours. I do not see a basis for similar obligations
in the regime for victims of trafficking. EM cautions against the reading of additional duties into the latter.

ii) This is a judicial review. It is not a procedure well suited for investigating factual disputes. Ordinarily on
factual questions, the defendant's evidence is accepted. Ms Knights argued that it was clear from the
Claimant's evidence that he had not understood all that the health care staff had said to him. While that
matches what some of the health professionals reported, others appeared to have had no significant
language difficulties in communicating with the Claimant with such assistance as was available. On
occasions, according to the medical notes, the Claimant declined to be seen by a doctor. That was his right
under the Detention Centre Rules and, no doubt, was also his right as a victim of trafficking. In the context
of the present proceedings, I am simply unable to investigate whether his view was based on a linguistic
misunderstanding.

iii) Similarly, a judicial review is not an appropriate vehicle for assessing whether the examinations by Dr
Oozeerally were beyond the range of what could be expected from a clinician in his position. Dr Arnold and
Dr Thomas reached different views to Dr Oozeerally, although based on somewhat later examinations of
the Claimant.

iv) I also have in mind that there is still to be a quantification of the loss to which the Claimant will be entitled for his
unlawful detention. Ordinarily, damages in tort are intended to put a claimant in as good a position (so far as money
can do so) as if the tort had not been committed. If the Claimant had not been unlawfully detained he would have
been at liberty. Dr Arnold has said in his report of 16th June 2017, 'It is highly likely that [the Claimant's] experience
of detention in the UK has compounded psychological damage through its recapitulation of his previous adverse
experiences of sexual abuse and violent assault.' If that feature is admitted or proved, it may increase the damages
to which the Claimant would be entitled for his unlawful detention. It might be thought in those circumstances that
there is no purpose in comparing the treatment he in fact received in detention with the treatment he ought to have


-----

received in detention. It would be different, possibly, if the treatment in detention made his experience of detention
worse. But I am conscious that I am in danger of slipping into territory which will be the responsibility of the Judge
who has to decide the quantification of his loss for unlawful detention, and that is not me.

64. I note also that Ms Knights contends that the obligation to carry out an individualised assessment of
the Claimant's medical and psychiatric needs arose when the Reasonable Grounds decision was made on
25th February 2016. At that time, though and for some weeks afterwards, he was not in immigration
detention or under the control of the SSHD: he was in detention awaiting the Crown Court hearing and then
serving his sentence. His medical records while in detention include those while he was held on remand
and during his sentence. I can see from these that, as it happened, he was seen by a doctor on 29th
February 2016 who examined him. The doctor noted that the Claimant reported worry about a
psychological problem, but this seemed connected with immigration problems.

65. I have focussed on the way Ms Knights put the Claimant's case based on the Directive, but, having
found that he does not succeed on that basis, I do not consider that Ground 2 fares any better if measured
against the requirements of the Anti-Trafficking Convention, Article 4 of the ECHR or the Home Office
policy.

**Ground 4**

66. Ms Knights argues that there were numerous errors in the way in which the Claimant's case was
handled by the Defendant. Thus,

i) The original NRM referral was on a form for adult victims of trafficking. As already noted, the Home
Office Guidance specifically addressed the issue of people who were trafficked while children but who have
since become adults: the guidance concerning children was to be followed.

ii) The first conclusive grounds decision was erroneously taken by applying to the Claimant the criteria for
an adult victim of trafficking when he should have been assessed as a child victim.

iii) The Home Office as the Competent Authority had failed to notify other relevant authorities of its
Reasonable Grounds decision on 25th February 2016. According to the Home Office Guidance 'Victims of
**_modern slavery- Competent Authority Guidance' it should have notified the police and asked them to_**
notify the Crown Prosecution Service. That is important because Article 8 of the Directive and Article 26 of
the Anti-Trafficking Convention in summary require Member States to take necessary measures to ensure
that victims of trafficking need not be prosecuted for offences which they were compelled to perform in
consequence of being trafficked. On 26th May 2017 the CPS wrote to Duncan Lewis and said that 'the
CPS had not been informed by the police as to the decision made regarding your client's status as a
trafficked individual.' They noted that the Claimant had not raised any trafficking issues in his interview with
the police. They added,

'However, having considered the guidance that is now available, a decision may have been made to stop
the prosecution on public interest grounds. It is clear that by 16th March the Crown should have been
made aware by the Competent Authority that a decision had been made on 26th February 2016 that your
client had received a positive Reasonable Grounds decision. Had the Crown known about this, a different
decision regarding prosecuting could have been taken and may have been taken.'

iv) On 4th March 2017 the Defendant had refused the Claimant's asylum and human rights applications.
By that stage the Defendant had already agreed, on 28th November 2016 to reconsider the negative
Conclusive Grounds decision but no further Conclusive Grounds decision had been made by 4th March
2017. 'Victims of Modern Slavery – Competent Authority Guidance' says,

'The Home Office should not make a negative decision on an asylum claim whilst a person is being
considered un the NRM process.'

v) The negative Conclusive Grounds decision was improperly delayed. It was taken on 9th August 2016.
The Reasonable Grounds decision had been taken on 25th February 2016. The Home Office Guidance
says,


-----

'The expectation is that a Conclusive Grounds decision will be made as soon as possible following day 45
of the recovery and reflection period. There is no target to make a conclusive grounds decision within 45
days. The timescale for making a conclusive grounds decision will be based on all the circumstances of the
case.'

The 'recovery and reflection period' runs from the making of a positive Reasonable Grounds decision. In
this case that occurred on 25th February 2016. Day 45 would therefore have been 9th April 2016. There
was nothing particularly complicated about the Claimant's case and the delay in making a Conclusive
Grounds decision was excessive.

67. The Claimant argues that the many errors and omissions in his case were not isolated incidents but
exemplify more general problems with the Home Office's procedures for dealing with victims of trafficking.
Ms Knights refers me to the 36th Report of the Public Accounts Committee for the session 2017-2019
'Reducing **_Modern Slavery' (HC 886). Similar criticisms have been made by The Snowdrop Project (a_**
charity helping victims of trafficking), Women Against Rape, Medical Justice, the Helen Bamber Foundation
and in a witness statement by a solicitor at Duncan Lewis. Very recently the government published its
response to the PAC report in which it accepted all of the Committee's recommendations. Ms Knights
submitted that I should make a declaration that the Defendant should undertake a review of the processes
and policy relevant to these issues. She noted that the declaration made by the Court of Appeal in R (PK
_(Ghana) v SSHD [2018 EWCA Civ 98 had led to an ongoing review of policy and that illustrated the value_
of such a declaration as she sought.

68. Mr Waite noted that the Home Office was dealing with a large volume of referrals. In 2016 there had
been 3,805 referrals to the NRM. There were operational challenges in view of the numbers and that the
scheme for dealing with victims of trafficking was still relatively new. However, the SSHD was
acknowledging the problems and seeking to address them as its response to the PAC report showed.

69. He accepted that the wrong form had been used by the Immigration Officer in the Claimant's case, but
his claim to have been trafficked had been processed.

70. A note on the Home office data base showed that some information had been passed to the police, but
it was unclear precisely what. There was also some information from the Claimant's previous immigration
solicitors (Wilsons) to suggest that 'his status as a victim of trafficking was known in the criminal
proceedings'.

71. More generally, Mr Waite argued, that if the Claimant's case showed errors or omissions they
remained evidence of deficiencies in his particular case. They did not allow me to conclude that there were
systemic errors which should lead to any declaration from the Court.

72. In my judgment, there were undoubtedly some errors in the handling of the Claimant's own claim to
have been a victim of trafficking. The Immigration Officer who was what the Guidance calls a 'First
Responder' properly transmitted the Claimant's claim that he had been trafficked. The Claimant was at that
stage an adult, but the adult form did not prompt the First Responder to inquire when the trafficking was
alleged to have occurred and the Claimant's age at that time. Had it done so, the Immigration Officer may
have appreciated that the Claimant was then a child and, in accordance with the Guidance the Immigration
Officer should have appreciated that he was still to be treated as a child.

73. Notwithstanding the initial error the Competent Authority did make a positive Reasonable Grounds
decision. As Ms Knights has explained this should have been communicated to the police. Whether it was
so communicated is unclear on the evidence before me. The print out from the Home Office data base is
ambiguous. The Claimant's criminal representatives may have understood that he claimed to be a victim of
trafficking, but that would not be the same as the Competent Authority accepting that he had shown
Reasonable Grounds that he had been trafficked. As the letter from the CPS shows, the prosecution was,
apparently, unaware of this decision and, had it been informed of this, it might have made a difference to
its decision to continue the prosecution. These are all matters which may yet need to be considered by the
Court of Appeal Criminal Division.


-----

74. I do not accept that the first Conclusive Grounds decision was unlawful because of delay. The Home
Office Guidance says in terms that no target is set for making such decisions. The time taken was not so
egregious as to make the delay unlawful in any event. Besides, that decision is not the subject of judicial
review and could not have been once the SSHD acknowledged that it would, in any case, have to be
retaken.

75. Because the age of the Claimant at the date of the trafficking was not appreciated, the first Conclusive
Decision was wrongly made. The error was (eventually) acknowledged.

76. The decisions to refuse asylum and humanitarian protection were made before the Conclusive
Grounds Decision was remade on 12th May 2017. That was contrary to the Home Office Guidance.
However, the SSHD has already conceded that those refusals could not stand and has agreed that they
should be reconsidered. That also deals with the substance of the Claimant's complaint that deportation
was premature prior to the reconsideration of the Conclusive Grounds Decision.

77. The role of the Court is to adjudicate on specific legal disputes. Bodies such as the Public Accounts
Committee and the Anti-Slavery Commissioner have a wider remit. They can survey the performance of
the Home Office more generally in discharging its anti-trafficking functions and make recommendations.
That is not the function of the Court. The position in PK (Ghana) was different. In that case the Claimant
alleged that the Guidance was unlawful because it failed properly to reflect Article 14(1)(a) of the AntiTrafficking Convention – see [35]. The Court of Appeal agreed - see [61] and it was for this reason that a
declaration was granted – see [62].

78. A declaration is a discretionary remedy and, so far as Ms Knights has been able to establish errors of
law in the treatment of the Claimant's own case, I do not consider that a declaration would serve any
purpose. The wider declaration which Ms Knights seeks as to systemic problems with the procedures for
dealing with victims of trafficking is anyway inappropriate for the reasons I have already given.

79. I would, therefore, refuse the Claimant permission to argue ground 4.

**Overall conclusion**

80. Permission is refused on Ground 4. The claim for judicial review on Ground 2 is dismissed.

81. I will invite the parties to agree or propose directions for the further conduct of the quantification of
damages for unlawful detention.

**End of Document**


-----

