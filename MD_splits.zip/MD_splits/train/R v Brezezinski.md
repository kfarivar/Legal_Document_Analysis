# R v Brezezinski [2021] EWCA Crim 749

CA, CRIMINAL DIVISION

201902755/C1

Singh LJ, Hilliard J, HHJ Bate

Friday 23 April 2021

23/04/2021

1. MR JUSTICE HILLIARD: On 26 June 2019, in the Crown Court at Birmingham, the appellant was convicted of
five offences of conspiracy. On 5 July 2019, he was sentenced as follows. On counts 3 and 4, conspiracy to
arrange or facilitate the travel of persons within the UK with a view to exploitation, 11 years' imprisonment on each
count; on count 5, conspiracy to require another to perform forced or compulsory labour, 11 years' imprisonment;
on count 6, conspiracy to control another for the purposes of labour exploitation, 11 years' imprisonment; on count
7, conspiracy to acquire criminal property, 6 years' imprisonment. All the sentences were ordered to run
concurrently, making 11 years' imprisonment in all.

2. Following the return of verdicts, the appellant had absconded and was sentenced in his absence. It is believed
that he is now in custody in Poland. We are satisfied that in the circumstances which were outlined to us, he has
impliedly given authority for this appeal to be mounted.

3. A co‑accused, Wojciech Nowakowski, was convicted on three counts of conspiracy and sentenced to a total of

six‑and‑a‑half years' imprisonment. Jan Sadowski pleaded guilty to three counts of conspiracy and was sentenced

to a total of 3 years' imprisonment. The appellant's was the second of two trials. At an earlier trial, Merek
Chowaniec was convicted of conspiracy to traffick persons into the United Kingdom for the purposes of labour
exploitation, conspiracy to arrange or facilitate the travel of persons within the United Kingdom with a view to
exploitation, conspiracy to require another to perform forced or compulsory labour, conspiracy to control another for
the purposes of labour exploitation and conspiracy to acquire criminal property. He was sentenced to a total of 11
years' imprisonment.

4. Marek Brzezinski was convicted of conspiracy to traffick persons into the United Kingdom for the purposes of
labour exploitation, conspiracy to arrange or facilitate the travel of persons into the United Kingdom with a view to
exploitation, conspiracy to control another for the purposes of labour exploitation and conspiracy to acquire criminal
property. He was sentenced to a total of 9 years' imprisonment.

5. Juliana Chodakiewicz was convicted of conspiracy to require another to perform forced or compulsory labour,
conspiracy to control another for the purposes of labour exploitation and conspiracy to acquire criminal property.
She was sentenced to a total of 7 years' imprisonment.

6. Justyna Parczewska received a sentence totalling five‑and‑a‑half years' imprisonment after a successful appeal

against sentence for the same conspiracy offences as Juliana Chodakiewicz. She is the appellant's partner.

7. Natalia Zmuda was convicted of conspiracy to traffick persons into the United Kingdom for the purposes of
labour exploitation, conspiracy to arrange or facilitate the travel of persons within the United Kingdom with a view to


-----

exploitation, conspiracy to require another to perform forced or compulsory labour, conspiracy to control another for
the purposes of labour exploitation and conspiracy to acquire criminal property. She was sentenced to a total of 4
years and 6 months' imprisonment.

[8. Sentence appeals in the earlier cases are reported under the name of R v MC, MB, JP and JC [2019] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VXS-GW82-D6MY-P1V6-00000-00&context=1519360)
_[Crim 1026. We adopt what was said there about the level of sentence in a case of this kind and about the gravity of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VXS-GW82-D6MY-P1V6-00000-00&context=1519360)_
this case in particular.

9. The appellant now appeals against sentence with the leave of the single judge. The appellant's convictions in
the second trial followed a lengthy police investigation concerning a number of conspiracies to traffick people into
and within the United Kingdom and various offences under the Modern Slavery Act. The indictment spanned the
period from 1 June 2012 to 31 October 2017.

10. The facts of the case were as follows. The appellant is the partner of Justyna Parczewska and lived with their
son, Adam Brzezinski, at an address in Beechwood Road, West Bromwich. This address was acknowledged to be
the nerve centre and head office of all the conspiracies and Adam Brzezinski was the alleged main perpetrator.

11. The victims were all Polish nationals who were duped into travelling to the United Kingdom with the promise of
well paid employment and accommodation.  The victims targeted were vulnerable and desperate: some had just
been released from prison or were recruited outside homeless shelters or off licences. Many were in a fragile state
of health and very few of them spoke any English.  The victims were told that they would receive wages of £250 to
£400 per week with their travel costs to the United Kingdom to be repaid in instalments once they were in
employment. All the arrangements would be made for them. The victims arrived in the United Kingdom, usually by
coach. The coaches would often go directly to the home address of the appellant and his partner.

12. Over the course of all the conspiracies, 31 properties were used to house the trafficked workers. The
accommodation was squalid and overcrowded. Two to four people were crammed into tiny rooms with
unsatisfactory bedding. At one property, both toilets were broken. At some houses, there was no hot water,
cooking facilities, furniture or heating. None of the properties was licensed as a house of multiple occupation and
there was no compliance with regulations. The accommodation at Queen's Head Road was amongst the worst,
described as "flea ridden and bug infested" and was an address where people slept on the floor of the kitchen.
Florence Road was rented after the appellant was made subject to an Interim Slavery and Trafficking Risk Order
which we will return to. Complainants who lived at Florence Road described the fear they were in.

13. The appellant had direct links with Queen's Head Road and Florence Road. These were properties rented by
him and he drove between them and ensured they were able to fulfil the purposes of the organisation. He was the
registered owner of a Bentley motor car.

14. The victims were also often moved from house to house, and would not know where they were or the address

they were living at. They were given inadequate supplies of out‑of‑date food. Occasionally the victims would start

work straightaway but often they were in the properties for days or weeks with no money. The victims were also
escorted to various banks and tricked into having multiple bank accounts opened in their names over which they
had no control. Forged utility bills and other forms of identification were created and used to open the bank
accounts. There were over 100 bank accounts opened and other unsuccessful attempts.  The labourers were
taken to employment agencies and job centres to obtain national insurance numbers and escorted to work,
sometimes several hours' drive from where they were staying. The victims complained that they were subjected to
actual or threatened physical or sexual violence or other forms of intimidation. Some were regularly beaten and
others were told that retribution would be visited on their families back home. Those who complained were denied
food and had their pay further reduced.  The victims were encouraged to spy on each other and report back to the
conspirators.

15. Some found the confidence to seek help through a soup kitchen operated by a church in West Bromwich.
Others did not come forward until approached by the police after being identified through the employment agencies
and banking records. Some of them had been forced labourers for over 2 years.


-----

16. The court heard from over 50 complainants and the prosecution established that 200 individuals or more were
trafficked during the course of the operation. In relation to count 7, it was common ground that the sum involved
was in the order of £1 million.

17. When the police searched 22 Beechwood Road, they recovered vast numbers of bank cards in the names of
complainants and others, many with PIN numbers written on the back, and account opening letters to complainants
at addresses which were under the control of the organisation.

18. There were a number of victim impact statements to the general effect that we have already indicated. It is
also of note that the appellant had been made the subject of an Interim Slavery and Trafficking Risk Order on 11
July 2016 by the Birmingham Magistrates' Court. He breached that order and was sentenced to 28 months and 3
weeks' imprisonment on 4 September 2017.

19. The judge had passed sentence on 8 March 2019 in relation to the first trial that we have mentioned. She had
referred then to the nature and scale of the conspiracy. When she came to sentence the appellant, she said that he
was the head of the family and set the tone of the operation. Despite being an alcoholic, she said that he was high
functioning much of the time and as the head of the family in a patriarchal society, his role was a highly significant

one. Consistent with his elder statesman role, he had less hands‑on involvement in day‑to‑day matters than some

of the others but he lived in the nerve centre of the organisation and was directly involved in the UK side of the
operations. His direct control of Queen's Head Road was noteworthy and the conditions in that property were truly
appalling. He enjoyed the fruits of the conspiracy, riding around in a Bentley car and with a fleet of other high
performance cars at his disposal. His life of leisure and alcohol was financed by the victims.

20. The judge said that deterrent sentences were required in human trafficking and forced labour cases since the
crimes consisted of the wilful devaluation of another person's life. The victims, she said, were robbed of their
dignity and autonomy and suffered lasting damage as a result of the degrading treatment that they suffered.

21. The judge reminded herself of the final sentences in the first trial to ensure consistency. The closest
comparable authority at that time was the case of R v Zielinski [2017] EWCA Crim 758, but the judge said that the
scale of the instant case was much larger. She said that in an ideal world all the defendants in both trials would
have been sentenced together but it was not feasible in this case. The judge said that there was evidence of the
appellant's involvement throughout the indictment period, apart from the time when he was in custody for breaching
the Interim Order.  The judge said that the starting point was 14 years' custody. However, the appellant was
entitled to credit for three matters: first, he had served the sentence for breach of the Interim Order; secondly, he
was in poor physical health; and thirdly, he had been living for approximately 1 year under onerous bail conditions.
He would accordingly receive an allowance of 3 years, resulting in an overall sentence of 11 years' imprisonment.
We note that the bail conditions were obviously not so onerous, nor his health so poor, as to prevent him leaving
the country.  The judge's sentencing remarks are extremely clear and concise and we have found them to be of
considerable assistance.

22. The appellant is now aged 55. There was no pre‑sentence report prepared for the lower court, nor was it

necessary to obtain one.

23. It is argued on the appellant's behalf, cogently and persuasively by Mr Copeland, that the sentence passed was
too long as a matter of generality, and that there were in addition some specific errors in the judge's approach. We
can take the first point shortly because, in our judgment, the gravity of this case and of the alleged role of the
appellant did justify the sentence passed upon him if there was a satisfactory evidential foundation for the particular
conclusions that the judge came to about his role. As to those, it is said 1), that there was no evidence that the
appellant was high functioning. The agreed facts demonstrated that he suffered from alcoholism and was unable to
speak English, and he had a physical disability affecting one of his arms. 2) It is said that he was not the head of
the family. No complainant described him in this way. His son, Adam, had the master bedroom at the family home
and the appellant slept on a sofa bed in the living room. Adam was seen by complainants driving the family cars.

3) It is said that the lack of complainant evidence was because his role was less hands‑on. The evidence


-----

suggested that the appellant could not speak English and required support from his family to engage with others. 4)
Several complainants stayed at two addresses rented in his name without mentioning him at all. 5) He did benefit
from the proceeds of the conspiracy to an extent but there was no evidence of a life of leisure. 6) It is submitted
that without any direct evidence at his trial from any complainant to the effect that he was the head of the
organisation, it was inappropriate for the judge to describe him as the "head" in a patriarchal society where all the
evidence pointed to his son Adam being the controlling force in the family and with the complainants. 7) It is said
that the appellant's partner also lived at the nerve centre of the conspiracy and there was more direct evidence of
her dealing with complainants, of her handing out money to complainants and taking food to properties. Her

sentence of 8 years' imprisonment was reduced on appeal to one of five‑and‑a‑half years. It is said that the

appellant should have received a sentence somewhere between her sentence and the sentence passed on Merek
Chowaniec. Finally, it is argued that the custodial term served by the appellant for his offence of breaching the
Interim Order should have resulted in a greater reduction in sentence.

24. We have had the benefit of assistance, in writing, from Mr Hearn for the respondent. He argues that the judge
heard ample evidence to justify the conclusions she reached in relation to the appellant's role. A number of the
judge's conclusions had been urged upon her in the Crown's sentencing note prepared by trial counsel which set
out in a little more detail the evidence upon which they were based.

25. The prosecution had said that although clearly a man with alcohol dependency issues, the appellant was well
able to drive between addresses, and those addresses which he controlled were able to fulfil the purposes of the
organisation. They said that the appellant was at the heart of the family, the father of the two main alleged
participants and, on his own admission, slept in the room that was the core of the operation. His partner was
convicted during the first trial for her role in counts 5, 6 and 7. It is said that the appellant lived at the address
where multiple documents, identity cards, cash and evidence of the means deployed by the organisation were
found, together with evidence of the high value cars that the family bought and used. He is described as handing
out money and more directly, as the controller of both Queen's Head Road and later on Florence Road. Although in
receipt of Disability Allowance as his only legitimate source of income, he was also the owner of a series of high
value cars including the Bentley. His phone use and contents also reflected his knowledge of the work that was
being undertaken. There was, it was said, evidence which reflected his disregard for the victims' financial situation
and his placing of his own position above all else.  The accommodation at Queen's Head Road, as we have
already noted, was among the worst. Florence Road was rented after the imposition of the Interim Order and with
the full knowledge that what was being done was unacceptable and yet it carried on. It is said that the appellant
continued offending despite multiple arrests and searches and although he had been sentenced for the breaches of
the Interim Order he was not sentenced, it is said, for the underlying conduct.

26. It is submitted that the judge's use of the term of "high functioning" meant no more than that the appellant,
although alcohol dependent, was able to carry out activities in furtherance of the conspiracy, such as recruiting
complainants, renting addresses at which they could be housed, controlling those addresses by, for example,
making rental payments and controlling the bank cards of the complainants.

27. Next, Mr Hearn says that the appellant was the senior member of the Brzezinski family ‑ the judge did not

suggest that he was the leader of the conspiracy. The Crown's case was that the conspiracy was led by Adam
Brzezinski, this appellant's son.  The appellant was not sentenced on the basis that he was the leader of the
conspiracy; a much greater sentence would have been imposed if he had been. However, his senior status within
the family and his enjoyment of the proceeds of the conspiracy demonstrated, it is said, that his role was indeed
highly significant as the judge found.

28. Finally, it is said that the mere fact that not all the residents of Queen's Head Road or Florence Road had direct
contact with the appellant does not undermine the Crown's case that he was in control of those properties. His
control was amply demonstrated by the evidence of the ultimate landlords of the properties who gave evidence that
they were rented to him and that he made cash payments to them.


-----

29. It is not in the event necessary for us to adjudicate ourselves upon these various competing arguments. It is
sufficient for us to say that, in our judgment, there was sufficient material to justify the conclusions which the judge
came to and she was well placed to make her assessment, in particular as between this appellant and his partner
and any other defendant. She had the advantage of having seen and heard all the evidence in both cases rather
than only particular features which pointed in one direction or another. We are also satisfied that the allowance that
the judge made for the sentence served by the appellant for the breach of the Interim Order was within the range
that was reasonably open to her. Again, she was well placed to assess this factor in the context of the case as a
whole and with totality in mind. To the extent that the sentence of 28 months and 3 weeks' imprisonment may have
reflected punishment for underlying conduct rather than the breach of a court order, the judge reduced the
appellant's sentence by 12 months.  The judge had actually sentenced the appellant for breaching the order and
could not therefore have been more familiar with the factual situation.

30. For all these reasons, notwithstanding the way in which the arguments have been put, we are satisfied that the
sentence passed upon the appellant was in no way wrong in principle and neither was it manifestly excessive. In
those circumstances, this appeal must be dismissed.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

